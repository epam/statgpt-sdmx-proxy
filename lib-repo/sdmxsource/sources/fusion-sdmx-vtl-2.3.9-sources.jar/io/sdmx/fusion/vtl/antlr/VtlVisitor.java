package io.sdmx.fusion.vtl.antlr;

import static java.util.Objects.isNull;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.antlr.v4.runtime.tree.TerminalNode;

/**
 * A note regarding this class:
 * The ctx.getChild() method is used to access the children of a parse tree node.
 * When you parse the VTL (using ANTLR), the parser generates a tree structure, where each node represents a rule from the grammar,
 * and its children represent the components of that rule.
 * <p>
 * If the rule is parsing an expression like x + y:
 * ctx.getChild(0) - will return the left-hand side of the expression (x)
 * ctx.getChild(0) - will return the operator (+)
 * ctx.getChild(2) - will return the right-hand side of the expression (y)
 */
public class VtlVisitor extends VtlBaseVisitor<Map<String, String>> implements IVtlVisitor<Map<String, String>> {
	
    @Override
    public Map<String, String> visitStart(VtlParser.StartContext ctx) {
        Map<String, String> results = new HashMap<>();
        for (int i = 0; i < ctx.getChildCount(); i++) {
            if (ctx.getChild(i) instanceof TerminalNode) {
                int nodeType = ((TerminalNode) ctx.getChild(i)).getSymbol().getType();
            } else if (ctx.getChild(i) instanceof VtlParser.PersistAssignmentContext || (ctx.getChild(i) instanceof VtlParser.TemporaryAssignmentContext)){
                Map<String, String> resultArray = visit(ctx.getChild(i));
                if (!isNull(resultArray)){
                    results.putAll(resultArray);
                }
            } else {
                Map<String, String> resultArray = visit(ctx.getChild(i));
                if (!isNull(resultArray)){
                    results.putAll(resultArray);
                }
            }
        }
        return results;
    }

    @Override
    public Map<String, String> visitDefDatapointRuleset(VtlParser.DefDatapointRulesetContext ctx){
        Map<String, String>  results = new HashMap<>();
        for (int i = 0; i < ctx.getChildCount(); i++){
            if(!(ctx.getChild(i) instanceof TerminalNode)){
                Map<String, String>  result = visit(ctx.getChild(i));
                if(!isNull(result)){
                    results.putAll(result);
                }
            }
        }
        return results;
    }

    @Override
    public Map<String, String> visitRulesetSignature(VtlParser.RulesetSignatureContext ctx){
        Map<String, String>  results = new HashMap<>();
        for (int i=0; i< ctx.getChildCount(); i++){
            if(!(ctx.getChild(i) instanceof  TerminalNode)){
                Map<String, String>  result = visit(ctx.getChild(i));
                if(!isNull(result)){
                    result.replaceAll((k,v) -> ctx.getChild(0).getText());
                    results.putAll(result);
                }
            }
        }
        return  results;
    }

    @Override
    public Map<String, String> visitSignature(VtlParser.SignatureContext ctx){
        Map<String, String>  results = new HashMap<>();
        for (int i=0; i< ctx.getChildCount(); i++){
            if(ctx.getChild(i) instanceof VtlParser.VarIDContext){
                Map<String, String>  result = visit(ctx.getChild(i));
                if(!isNull(result)){
                    results.putAll(result);
                }
            }
        }
        return  results;
    }

    @Override
    public Map<String, String> visitArithmeticExprOrConcat(VtlParser.ArithmeticExprOrConcatContext ctx) {
        Map<String, String> results = new HashMap<>();
        results.putAll(visit(ctx.getChild(0)));
        results.putAll(visit(ctx.getChild(2)));

        return results;
    }

    @Override
    public Map<String, String> visitPersistAssignment(VtlParser.PersistAssignmentContext ctx) {
        // visit right side of assignment only
    	Map<String, String> visitMap = visit(ctx.getChild(2));
    	
    	Map<String, String> results;
    	if (visitMap == null) {
    		results = new HashMap<>();
    	} else {
    		results = new HashMap<>(visitMap);
    	}
        results.putAll(visit(ctx.getChild(0)));
        return results;
    }

    @Override
    public Map<String, String> visitTemporaryAssignment(VtlParser.TemporaryAssignmentContext ctx) {
        // visit right side of assignment only
    	Map<String, String> visitMap = visit(ctx.getChild(2));
    	
    	Map<String, String> results;
    	if (visitMap == null) {
    		results = new HashMap<>();
    	} else {
    		results = new HashMap<>(visitMap);
    	}
        results.putAll(visit(ctx.getChild(0)));
        return results;
    }

    @Override
    public Map<String, String> visitArithmeticExpr(VtlParser.ArithmeticExprContext ctx){
        Map<String, String>  results = new HashMap<>();
        results.putAll(visit(ctx.getChild(0)));
        results.putAll(visit(ctx.getChild(2)));

        return results;
    }

    @Override
    public Map<String, String> visitParenthesisExpr(VtlParser.ParenthesisExprContext ctx) {
        return visit(ctx.getChild(1));
    }

    @Override
    public Map<String, String> visitVarIdExpr(VtlParser.VarIdExprContext ctx) {
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText(), "VarIdExpr");
        return element;
    }

    @Override
    public Map<String, String> visitVarID(VtlParser.VarIDContext ctx){
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText(), "VarID");
        return element;
    }

    @Override
    public Map<String, String> visitConstantExpr(VtlParser.ConstantExprContext ctx){
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText(), "ConstantExpr");
        return element;
    }

    @Override
    public Map<String, String> visitMembershipExpr(VtlParser.MembershipExprContext ctx){
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText().replace("'", ""), "membership");
        return element;
    }

    @Override
    public Map<String, String> visitSimpleComponentId(VtlParser.SimpleComponentIdContext ctx){
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText(), "component");
        return element;
    }

    @Override
    public Map<String, String> visitValueDomainSignature(VtlParser.ValueDomainSignatureContext ctx){
        Map<String, String>  results = new HashMap<>();
        for (int i=0; i< ctx.getChildCount(); i++){
            Map<String, String>  result = visit(ctx.getChild(i));
            if(!isNull(result)){
                results.putAll(result);
            }
        }
        return  results;
    }

    @Override
    public Map<String, String> visitCodeItemRelation(VtlParser.CodeItemRelationContext ctx){
        Map<String, String>  results = new HashMap<>();
        for (int i=0; i< ctx.getChildCount(); i++){
            Map<String, String>  result = visit(ctx.getChild(i));
            if(!isNull(result)){
                results.putAll(result);
            }
        }
        return  results;
    }

    @Override
    public Map<String, String> visitValueDomainValue(VtlParser.ValueDomainValueContext ctx){
        Map<String, String>  element = new HashMap<>();
        element.put(ctx.getText(), "valuedomainvalue");
        return element;
    }


    @Override
    public Map<String, String> aggregateResult (Map<String, String> aggregate, Map<String, String> nextResult){
        Map<String, String> results = new HashMap<>();
        if(!isNull(aggregate)){
            results.putAll(aggregate);
        }
        if(!isNull(nextResult)){
            results.putAll(nextResult);
        }
        return results;
    }

}
