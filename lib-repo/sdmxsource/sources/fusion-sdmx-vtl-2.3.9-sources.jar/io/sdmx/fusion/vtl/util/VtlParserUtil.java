package io.sdmx.fusion.vtl.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.utils.sdmx.xs.VersionRef;
import org.antlr.v4.runtime.ANTLRErrorListener;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ConsoleErrorListener;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.fusion.vtl.antlr.SyntaxError;
import io.sdmx.fusion.vtl.antlr.SyntaxErrorListener;
import io.sdmx.fusion.vtl.antlr.VtlLexer;
import io.sdmx.fusion.vtl.antlr.VtlParser;
import io.sdmx.fusion.vtl.antlr.VtlVisitor;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

import static io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE.CODE_LIST;
import static io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME;
import static io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE.DATAFLOW;
import static java.util.Objects.isNull;

public class VtlParserUtil {

    /**
     * Creates a VTLParser with required ErrorListeners for a VTL Statement
     * The lexer generates a token stream from the character stream. The token stream is used as input for the VtlParser.
     * @param VTL statement as CharStream
     * @return
     */
    public static VtlParser getVtlParser(CharStream stream){
        VtlLexer lexer = new VtlLexer(stream);
        CommonTokenStream tokenStream = new CommonTokenStream(lexer);
        VtlParser parser = new VtlParser(tokenStream);

        //remove ConsoleErrorListener to avoid printing to the console.
        parser.removeErrorListener(ConsoleErrorListener.INSTANCE);
        //add SyntaxErrorListener which collects and returns syntax errors.
        SyntaxErrorListener listener = new SyntaxErrorListener();
        parser.addErrorListener(listener);
        return parser;
    }

    /**
     * Retrieves syntax errors from the SyntaxErrorListener of the VTL parser.
     * @param parser: VTL parser from which syntax errors should be retrieved.
     * @return
     */
    public static List<SyntaxError> getSyntaxErrors(VtlParser parser){
        List<SyntaxError> syntaxErrors = new ArrayList<>();
        for(ANTLRErrorListener listener : parser.getErrorListeners()){
            if(listener.getClass() == SyntaxErrorListener.class){
                syntaxErrors.addAll(((SyntaxErrorListener) listener).getSyntaxErrors());
            }
        }
        return syntaxErrors;
    }


    /**
     * Parse a VTL expression stored in a VTL parser generated with Antlr4 based on the VTL grammar.
     * Using VtlParser.StartContext a parse tree is created which is traversed by the visitor to extract the VTL
     * objects and its associated node type (as defined by VTL grammar). The node type is relevant for further processing.
     * Example:
     * VTL expression stored in parser: DS_r<-DS1+DS2
     * Result: Map("DS_r":"DS_r", "DS1":"VarIdExpr", "DS2":"VarIdExpr")
     *
     * @param VtlParser
     * @return map of VTL objects and their associated node type extracted from VTL program
     */
    public static Map<String, String>  parseVtlInput(VtlParser parser){
        //reset parser to handle potential previous parsing of tree
        parser.reset();
        Map<String, String>  result;
        VtlVisitor arrayVisitor = new VtlVisitor();
        VtlParser.StartContext tree = parser.start();
        result = arrayVisitor.visit(tree);

        return result;

    }

    /**
     * splits a VTL object (SDMX URN or partial URN) extracted from a transformation/ruleset definition into its parts and generates a valid SDMX URN from the parts.
     * The agency of the transformation scheme / ruleset scheme is passed to the function and used if no agency can be extracted
     * from the VTL object. The classObject contains the SDMX_STRUCTURE_TYPE for which the URN should be generated. If
     * no classObject is provided the structure type is determined based on the respective part of the VTL object. If no
     * structure type exists in the VTL object DATAFLOW is used as default.
     * Example:
     * input: ACY1:DSD_r(1.0.0)
     * output: urn:sdmx:org.sdmx.infomodel.datastructure.DataStructure=ACY:DSD_r(1.0.0)
     *
     * Note: This Can return a URN resolving to a Dataflow which also includes a refernce to an Identifiable ID, this can be interprested as a Component ID in the 
     * context of a Dataflow (indirect reference)
     *
     * @param input: VTL object as string
     * @param vtlAgencyId: Agency of the transformation scheme / ruleset scheme
     * @return

     */
    public static IURN<?> extractSdmxElementFromVtlObject(String input, SDMX_STRUCTURE_TYPE providedClass) {

        //Clean input string
        input = input.trim();
        // Remove leading and trailing single quotes
        if (input.charAt(0) ==  '\''){
            input = input.substring(1, input.length() - 1);
        }

        // Build IURN from String if all information needed is present
        if (input.contains("urn:sdmx:org.sdmx.infomodel")) {
            // Build URN from string if its not a component (identified by #)
            if (!input.contains("#") && input.contains("(") && input.contains(")")) {
                IURN<?> urn = URN.builder(input).build();
                if (!(Arrays.asList(CODE_LIST, SDMX_STRUCTURE_TYPE.DATAFLOW, SDMX_STRUCTURE_TYPE.CONCEPT, SDMX_STRUCTURE_TYPE.CODE).contains(urn.getSdmxStructure()))) {
                    throw new SdmxSyntaxException("The provided structure type " + urn.getSdmxStructure().toString() + " is not allowed in a VTL statement");
                }
                return urn;
            }
            input = input.substring(nthIndexOf(input, ".", 4) + 1);
        }

        URNBuilder urnBuilder = URN.builder();

        if(!isNull(providedClass)){
            urnBuilder.structure(providedClass);
        }

        //Split of class object if exist (detectable through "=")
        if(input.contains("=")){
            String classObject = input.substring(0, input.indexOf("="));
            switch(classObject.toLowerCase()){
                case "dataflow": urnBuilder.structure(DataflowBean.class);break;
                case "concept": urnBuilder.structure(ConceptSchemeBean.class); break;
                case "codelist": urnBuilder.structure(CodelistBean.class); break;
                case "datastructure": urnBuilder.structure(DataStructureBean.class); break;
                default: throw new SdmxSyntaxException("The provided class is not allowed in a VTL statement");
            }
            input = input.substring(input.indexOf("=")+1);
        }

        if(input.contains(":")) {
        	urnBuilder.agencyId(input.substring(0, input.indexOf(":")));
            input = input.substring(input.indexOf((":"))+1);
        }
        // Extract maintId and version
        if (input.contains(")")) {
            urnBuilder.maintId(input.substring(0, input.indexOf("(")));
            urnBuilder.versionRef(VersionRef.getInstance(input.substring(input.indexOf("(") + 1, input.indexOf(")"))));
            input = input.substring(input.indexOf(")") + 1);
        } else if (!input.contains("#")&& providedClass != SDMX_STRUCTURE_TYPE.CODE) {
            urnBuilder.maintId(input);
        }

        if (!input.isEmpty()) {
            // Access the element at the specified index
            if(input.contains("#") || input.contains(("."))){
                if(input.indexOf("#")>0){
                    urnBuilder.maintId(input.substring(0,input.indexOf("#")));
                }
                urnBuilder.identifableId(input.substring(1));
                if (providedClass == CODE_LIST){
                    urnBuilder.structure(SDMX_STRUCTURE_TYPE.CODE);
                } else if(providedClass == CONCEPT_SCHEME){
                    urnBuilder.structure(SDMX_STRUCTURE_TYPE.CONCEPT);
                }
                else if (providedClass == DATAFLOW){
                    urnBuilder.structure(IDataStructureComponentBean.class);
                }
            }
        }

        return urnBuilder.build();
    }


    /**
     * Get the index of the nth occurrence of a substring in a string.
     * @param input: String to search substring in
     * @param substring
     * @param nth
     * @return index of the nth occurence
     */
    public static int nthIndexOf(String input, String substring, int nth) {
        if (nth == 1) {
            return input.indexOf(substring);
        } else {
            return input.indexOf(substring, nthIndexOf(input, substring, nth - 1) + substring.length());
        }
    }
}
