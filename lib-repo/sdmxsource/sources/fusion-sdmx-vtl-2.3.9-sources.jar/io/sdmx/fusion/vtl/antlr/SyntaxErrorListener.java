package io.sdmx.fusion.vtl.antlr;

import org.antlr.v4.runtime.BaseErrorListener;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;

import java.util.ArrayList;
import java.util.List;

public class SyntaxErrorListener extends BaseErrorListener {
    private boolean error;
    private final List<SyntaxError> syntaxErrors = new ArrayList<>();

    /**
     * Listener which collects the syntax errors the VTL parser detects when parsing a VTL statement.
     */
    public SyntaxErrorListener(){
        super();
        error = false;
    }

    public List<SyntaxError> getSyntaxErrors(){
        return syntaxErrors;
    }

    @Override
    public void syntaxError(Recognizer<?,?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e){
        syntaxErrors.add(new SyntaxError(recognizer, offendingSymbol, line, charPositionInLine, msg, e));
    }

}
