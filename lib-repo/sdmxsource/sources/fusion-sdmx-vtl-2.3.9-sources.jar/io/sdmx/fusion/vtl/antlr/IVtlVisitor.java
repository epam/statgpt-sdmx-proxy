// Generated from org/sdmx/vtl/Vtl.g4 by ANTLR 4.13.2
package io.sdmx.fusion.vtl.antlr;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link VtlParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface IVtlVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link VtlParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(VtlParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by the {@code temporaryAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemporaryAssignment(VtlParser.TemporaryAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code persistAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPersistAssignment(VtlParser.PersistAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defineExpression}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefineExpression(VtlParser.DefineExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code varIdExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarIdExpr(VtlParser.VarIdExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code membershipExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMembershipExpr(VtlParser.MembershipExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code inNotInExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInNotInExpr(VtlParser.InNotInExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code booleanExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanExpr(VtlParser.BooleanExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comparisonExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExpr(VtlParser.ComparisonExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExpr(VtlParser.UnaryExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionsExpression}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionsExpression(VtlParser.FunctionsExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfExpr(VtlParser.IfExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code clauseExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClauseExpr(VtlParser.ClauseExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arithmeticExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticExpr(VtlParser.ArithmeticExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenthesisExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthesisExpr(VtlParser.ParenthesisExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code constantExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstantExpr(VtlParser.ConstantExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arithmeticExprOrConcat}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticExprOrConcat(VtlParser.ArithmeticExprOrConcatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arithmeticExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticExprComp(VtlParser.ArithmeticExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfExprComp(VtlParser.IfExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comparisonExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExprComp(VtlParser.ComparisonExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionsExpressionComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionsExpressionComp(VtlParser.FunctionsExpressionCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code compId}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompId(VtlParser.CompIdContext ctx);
	/**
	 * Visit a parse tree produced by the {@code constantExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstantExprComp(VtlParser.ConstantExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arithmeticExprOrConcatComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticExprOrConcatComp(VtlParser.ArithmeticExprOrConcatCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenthesisExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthesisExprComp(VtlParser.ParenthesisExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code inNotInExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInNotInExprComp(VtlParser.InNotInExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExprComp(VtlParser.UnaryExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code booleanExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanExprComp(VtlParser.BooleanExprCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code genericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericFunctionsComponents(VtlParser.GenericFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringFunctionsComponents(VtlParser.StringFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericFunctionsComponents(VtlParser.NumericFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comparisonFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonFunctionsComponents(VtlParser.ComparisonFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeFunctionsComponents(VtlParser.TimeFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code conditionalFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionalFunctionsComponents(VtlParser.ConditionalFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code aggregateFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregateFunctionsComponents(VtlParser.AggregateFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code analyticFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnalyticFunctionsComponents(VtlParser.AnalyticFunctionsComponentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code joinFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinFunctions(VtlParser.JoinFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code genericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericFunctions(VtlParser.GenericFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringFunctions(VtlParser.StringFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericFunctions(VtlParser.NumericFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comparisonFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonFunctions(VtlParser.ComparisonFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeFunctions(VtlParser.TimeFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetFunctions(VtlParser.SetFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code hierarchyFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHierarchyFunctions(VtlParser.HierarchyFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code validationFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidationFunctions(VtlParser.ValidationFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code conditionalFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionalFunctions(VtlParser.ConditionalFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code aggregateFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregateFunctions(VtlParser.AggregateFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code analyticFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnalyticFunctions(VtlParser.AnalyticFunctionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#datasetClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatasetClause(VtlParser.DatasetClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#renameClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRenameClause(VtlParser.RenameClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#aggrClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggrClause(VtlParser.AggrClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#filterClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterClause(VtlParser.FilterClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#calcClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCalcClause(VtlParser.CalcClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#keepOrDropClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeepOrDropClause(VtlParser.KeepOrDropClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#pivotOrUnpivotClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivotOrUnpivotClause(VtlParser.PivotOrUnpivotClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#customPivotClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCustomPivotClause(VtlParser.CustomPivotClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#subspaceClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubspaceClause(VtlParser.SubspaceClauseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code joinExpr}
	 * labeled alternative in {@link VtlParser#joinOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinExpr(VtlParser.JoinExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defOperator}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefOperator(VtlParser.DefOperatorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defDatapointRuleset}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefDatapointRuleset(VtlParser.DefDatapointRulesetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defHierarchical}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefHierarchical(VtlParser.DefHierarchicalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallDataset(VtlParser.CallDatasetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code evalAtom}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvalAtom(VtlParser.EvalAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code castExprDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCastExprDataset(VtlParser.CastExprDatasetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallComponent(VtlParser.CallComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code castExprComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCastExprComponent(VtlParser.CastExprComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code evalAtomComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvalAtomComponent(VtlParser.EvalAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#parameterComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameterComponent(VtlParser.ParameterComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter(VtlParser.ParameterContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryStringFunction}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryStringFunction(VtlParser.UnaryStringFunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code substrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubstrAtom(VtlParser.SubstrAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code replaceAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplaceAtom(VtlParser.ReplaceAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code instrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstrAtom(VtlParser.InstrAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryStringFunctionComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryStringFunctionComponent(VtlParser.UnaryStringFunctionComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code substrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubstrAtomComponent(VtlParser.SubstrAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code replaceAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplaceAtomComponent(VtlParser.ReplaceAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code instrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstrAtomComponent(VtlParser.InstrAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryNumeric(VtlParser.UnaryNumericContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryWithOptionalNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryWithOptionalNumeric(VtlParser.UnaryWithOptionalNumericContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryNumeric(VtlParser.BinaryNumericContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryNumericComponent(VtlParser.UnaryNumericComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryWithOptionalNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryWithOptionalNumericComponent(VtlParser.UnaryWithOptionalNumericComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryNumericComponent(VtlParser.BinaryNumericComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code betweenAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetweenAtom(VtlParser.BetweenAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code charsetMatchAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharsetMatchAtom(VtlParser.CharsetMatchAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code isNullAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsNullAtom(VtlParser.IsNullAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code existInAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExistInAtom(VtlParser.ExistInAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code betweenAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetweenAtomComponent(VtlParser.BetweenAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code charsetMatchAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharsetMatchAtomComponent(VtlParser.CharsetMatchAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code isNullAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsNullAtomComponent(VtlParser.IsNullAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code periodAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeriodAtom(VtlParser.PeriodAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fillTimeAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFillTimeAtom(VtlParser.FillTimeAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code flowAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFlowAtom(VtlParser.FlowAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeShiftAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeShiftAtom(VtlParser.TimeShiftAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeAggAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeAggAtom(VtlParser.TimeAggAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code currentDateAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCurrentDateAtom(VtlParser.CurrentDateAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code periodAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeriodAtomComponent(VtlParser.PeriodAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fillTimeAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFillTimeAtomComponent(VtlParser.FillTimeAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code flowAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFlowAtomComponent(VtlParser.FlowAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeShiftAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeShiftAtomComponent(VtlParser.TimeShiftAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code timeAggAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTimeAggAtomComponent(VtlParser.TimeAggAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code currentDateAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCurrentDateAtomComponent(VtlParser.CurrentDateAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unionAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnionAtom(VtlParser.UnionAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code intersectAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntersectAtom(VtlParser.IntersectAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setOrSYmDiffAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetOrSYmDiffAtom(VtlParser.SetOrSYmDiffAtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#hierarchyOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHierarchyOperators(VtlParser.HierarchyOperatorsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code validateDPruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidateDPruleset(VtlParser.ValidateDPrulesetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code validateHRruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidateHRruleset(VtlParser.ValidateHRrulesetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code validationSimple}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidationSimple(VtlParser.ValidationSimpleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nvlAtom}
	 * labeled alternative in {@link VtlParser#conditionalOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNvlAtom(VtlParser.NvlAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nvlAtomComponent}
	 * labeled alternative in {@link VtlParser#conditionalOperatorsComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNvlAtomComponent(VtlParser.NvlAtomComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code aggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggrComp(VtlParser.AggrCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code countAggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCountAggrComp(VtlParser.CountAggrCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code aggrDataset}
	 * labeled alternative in {@link VtlParser#aggrOperatorsGrouping}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggrDataset(VtlParser.AggrDatasetContext ctx);
	/**
	 * Visit a parse tree produced by the {@code anSimpleFunction}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnSimpleFunction(VtlParser.AnSimpleFunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code lagOrLeadAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLagOrLeadAn(VtlParser.LagOrLeadAnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ratioToReportAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRatioToReportAn(VtlParser.RatioToReportAnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code anSimpleFunctionComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnSimpleFunctionComponent(VtlParser.AnSimpleFunctionComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code lagOrLeadAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLagOrLeadAnComponent(VtlParser.LagOrLeadAnComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rankAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRankAnComponent(VtlParser.RankAnComponentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ratioToReportAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRatioToReportAnComponent(VtlParser.RatioToReportAnComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#renameClauseItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRenameClauseItem(VtlParser.RenameClauseItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#aggregateClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregateClause(VtlParser.AggregateClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#aggrFunctionClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggrFunctionClause(VtlParser.AggrFunctionClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#calcClauseItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCalcClauseItem(VtlParser.CalcClauseItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#subspaceClauseItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubspaceClauseItem(VtlParser.SubspaceClauseItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code simpleScalar}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimpleScalar(VtlParser.SimpleScalarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code scalarWithCast}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScalarWithCast(VtlParser.ScalarWithCastContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#joinClauseWithoutUsing}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinClauseWithoutUsing(VtlParser.JoinClauseWithoutUsingContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#joinClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinClause(VtlParser.JoinClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#joinClauseItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinClauseItem(VtlParser.JoinClauseItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#joinBody}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinBody(VtlParser.JoinBodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#joinApplyClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinApplyClause(VtlParser.JoinApplyClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#partitionByClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartitionByClause(VtlParser.PartitionByClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#orderByClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderByClause(VtlParser.OrderByClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#orderByItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderByItem(VtlParser.OrderByItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#windowingClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWindowingClause(VtlParser.WindowingClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#signedInteger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignedInteger(VtlParser.SignedIntegerContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#limitClauseItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLimitClauseItem(VtlParser.LimitClauseItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code groupByOrExcept}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupByOrExcept(VtlParser.GroupByOrExceptContext ctx);
	/**
	 * Visit a parse tree produced by the {@code groupAll}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupAll(VtlParser.GroupAllContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#havingClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHavingClause(VtlParser.HavingClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#parameterItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameterItem(VtlParser.ParameterItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#outputParameterType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutputParameterType(VtlParser.OutputParameterTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#outputParameterTypeComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutputParameterTypeComponent(VtlParser.OutputParameterTypeComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#inputParameterType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputParameterType(VtlParser.InputParameterTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#rulesetType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRulesetType(VtlParser.RulesetTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#scalarType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScalarType(VtlParser.ScalarTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#componentType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComponentType(VtlParser.ComponentTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#datasetType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatasetType(VtlParser.DatasetTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#evalDatasetType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvalDatasetType(VtlParser.EvalDatasetTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#scalarSetType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScalarSetType(VtlParser.ScalarSetTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dataPoint}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDataPoint(VtlParser.DataPointContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dataPointVd}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDataPointVd(VtlParser.DataPointVdContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dataPointVar}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDataPointVar(VtlParser.DataPointVarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code hrRulesetType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHrRulesetType(VtlParser.HrRulesetTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code hrRulesetVdType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHrRulesetVdType(VtlParser.HrRulesetVdTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code hrRulesetVarType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHrRulesetVarType(VtlParser.HrRulesetVarTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#valueDomainName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValueDomainName(VtlParser.ValueDomainNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#rulesetID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRulesetID(VtlParser.RulesetIDContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#rulesetSignature}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRulesetSignature(VtlParser.RulesetSignatureContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#signature}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignature(VtlParser.SignatureContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#ruleClauseDatapoint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuleClauseDatapoint(VtlParser.RuleClauseDatapointContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#ruleItemDatapoint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuleItemDatapoint(VtlParser.RuleItemDatapointContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#ruleClauseHierarchical}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuleClauseHierarchical(VtlParser.RuleClauseHierarchicalContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#ruleItemHierarchical}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuleItemHierarchical(VtlParser.RuleItemHierarchicalContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#hierRuleSignature}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHierRuleSignature(VtlParser.HierRuleSignatureContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#valueDomainSignature}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValueDomainSignature(VtlParser.ValueDomainSignatureContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#codeItemRelation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCodeItemRelation(VtlParser.CodeItemRelationContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#codeItemRelationClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCodeItemRelationClause(VtlParser.CodeItemRelationClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#valueDomainValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValueDomainValue(VtlParser.ValueDomainValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code conditionConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionConstraint(VtlParser.ConditionConstraintContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rangeConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeConstraint(VtlParser.RangeConstraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#compConstraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompConstraint(VtlParser.CompConstraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#multModifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultModifier(VtlParser.MultModifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#validationOutput}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidationOutput(VtlParser.ValidationOutputContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#validationMode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValidationMode(VtlParser.ValidationModeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#conditionClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionClause(VtlParser.ConditionClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#inputMode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputMode(VtlParser.InputModeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#imbalanceExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImbalanceExpr(VtlParser.ImbalanceExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#inputModeHierarchy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputModeHierarchy(VtlParser.InputModeHierarchyContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#outputModeHierarchy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutputModeHierarchy(VtlParser.OutputModeHierarchyContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlias(VtlParser.AliasContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#varID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarID(VtlParser.VarIDContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#simpleComponentId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimpleComponentId(VtlParser.SimpleComponentIdContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#componentID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComponentID(VtlParser.ComponentIDContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#lists}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLists(VtlParser.ListsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#erCode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitErCode(VtlParser.ErCodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#erLevel}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitErLevel(VtlParser.ErLevelContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#comparisonOperand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonOperand(VtlParser.ComparisonOperandContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#optionalExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionalExpr(VtlParser.OptionalExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#optionalExprComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionalExprComponent(VtlParser.OptionalExprComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#componentRole}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComponentRole(VtlParser.ComponentRoleContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#viralAttribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitViralAttribute(VtlParser.ViralAttributeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#valueDomainID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValueDomainID(VtlParser.ValueDomainIDContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#operatorID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperatorID(VtlParser.OperatorIDContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#routineName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRoutineName(VtlParser.RoutineNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#constant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant(VtlParser.ConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#basicScalarType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBasicScalarType(VtlParser.BasicScalarTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VtlParser#retainType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRetainType(VtlParser.RetainTypeContext ctx);
}