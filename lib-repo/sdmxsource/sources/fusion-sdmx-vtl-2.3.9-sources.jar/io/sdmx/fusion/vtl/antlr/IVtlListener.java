// Generated from org/sdmx/vtl/Vtl.g4 by ANTLR 4.13.2
package io.sdmx.fusion.vtl.antlr;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link VtlParser}.
 */
public interface IVtlListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link VtlParser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(VtlParser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(VtlParser.StartContext ctx);
	/**
	 * Enter a parse tree produced by the {@code temporaryAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterTemporaryAssignment(VtlParser.TemporaryAssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code temporaryAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitTemporaryAssignment(VtlParser.TemporaryAssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code persistAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterPersistAssignment(VtlParser.PersistAssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code persistAssignment}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitPersistAssignment(VtlParser.PersistAssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code defineExpression}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterDefineExpression(VtlParser.DefineExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code defineExpression}
	 * labeled alternative in {@link VtlParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitDefineExpression(VtlParser.DefineExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code varIdExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVarIdExpr(VtlParser.VarIdExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code varIdExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVarIdExpr(VtlParser.VarIdExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code membershipExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMembershipExpr(VtlParser.MembershipExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code membershipExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMembershipExpr(VtlParser.MembershipExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code inNotInExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterInNotInExpr(VtlParser.InNotInExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code inNotInExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitInNotInExpr(VtlParser.InNotInExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code booleanExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBooleanExpr(VtlParser.BooleanExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code booleanExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBooleanExpr(VtlParser.BooleanExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code comparisonExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExpr(VtlParser.ComparisonExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code comparisonExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExpr(VtlParser.ComparisonExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpr(VtlParser.UnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpr(VtlParser.UnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code functionsExpression}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFunctionsExpression(VtlParser.FunctionsExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code functionsExpression}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFunctionsExpression(VtlParser.FunctionsExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIfExpr(VtlParser.IfExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIfExpr(VtlParser.IfExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code clauseExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterClauseExpr(VtlParser.ClauseExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code clauseExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitClauseExpr(VtlParser.ClauseExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arithmeticExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArithmeticExpr(VtlParser.ArithmeticExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arithmeticExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArithmeticExpr(VtlParser.ArithmeticExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenthesisExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParenthesisExpr(VtlParser.ParenthesisExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenthesisExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParenthesisExpr(VtlParser.ParenthesisExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code constantExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstantExpr(VtlParser.ConstantExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code constantExpr}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstantExpr(VtlParser.ConstantExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arithmeticExprOrConcat}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArithmeticExprOrConcat(VtlParser.ArithmeticExprOrConcatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arithmeticExprOrConcat}
	 * labeled alternative in {@link VtlParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArithmeticExprOrConcat(VtlParser.ArithmeticExprOrConcatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arithmeticExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterArithmeticExprComp(VtlParser.ArithmeticExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arithmeticExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitArithmeticExprComp(VtlParser.ArithmeticExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterIfExprComp(VtlParser.IfExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitIfExprComp(VtlParser.IfExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code comparisonExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExprComp(VtlParser.ComparisonExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code comparisonExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExprComp(VtlParser.ComparisonExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code functionsExpressionComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterFunctionsExpressionComp(VtlParser.FunctionsExpressionCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code functionsExpressionComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitFunctionsExpressionComp(VtlParser.FunctionsExpressionCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code compId}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterCompId(VtlParser.CompIdContext ctx);
	/**
	 * Exit a parse tree produced by the {@code compId}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitCompId(VtlParser.CompIdContext ctx);
	/**
	 * Enter a parse tree produced by the {@code constantExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterConstantExprComp(VtlParser.ConstantExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code constantExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitConstantExprComp(VtlParser.ConstantExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arithmeticExprOrConcatComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterArithmeticExprOrConcatComp(VtlParser.ArithmeticExprOrConcatCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arithmeticExprOrConcatComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitArithmeticExprOrConcatComp(VtlParser.ArithmeticExprOrConcatCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenthesisExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterParenthesisExprComp(VtlParser.ParenthesisExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenthesisExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitParenthesisExprComp(VtlParser.ParenthesisExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code inNotInExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterInNotInExprComp(VtlParser.InNotInExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code inNotInExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitInNotInExprComp(VtlParser.InNotInExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExprComp(VtlParser.UnaryExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExprComp(VtlParser.UnaryExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code booleanExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void enterBooleanExprComp(VtlParser.BooleanExprCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code booleanExprComp}
	 * labeled alternative in {@link VtlParser#exprComponent}.
	 * @param ctx the parse tree
	 */
	void exitBooleanExprComp(VtlParser.BooleanExprCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code genericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterGenericFunctionsComponents(VtlParser.GenericFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code genericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitGenericFunctionsComponents(VtlParser.GenericFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterStringFunctionsComponents(VtlParser.StringFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitStringFunctionsComponents(VtlParser.StringFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code numericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterNumericFunctionsComponents(VtlParser.NumericFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code numericFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitNumericFunctionsComponents(VtlParser.NumericFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code comparisonFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterComparisonFunctionsComponents(VtlParser.ComparisonFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code comparisonFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitComparisonFunctionsComponents(VtlParser.ComparisonFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterTimeFunctionsComponents(VtlParser.TimeFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitTimeFunctionsComponents(VtlParser.TimeFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code conditionalFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterConditionalFunctionsComponents(VtlParser.ConditionalFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code conditionalFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitConditionalFunctionsComponents(VtlParser.ConditionalFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code aggregateFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterAggregateFunctionsComponents(VtlParser.AggregateFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code aggregateFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitAggregateFunctionsComponents(VtlParser.AggregateFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code analyticFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void enterAnalyticFunctionsComponents(VtlParser.AnalyticFunctionsComponentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code analyticFunctionsComponents}
	 * labeled alternative in {@link VtlParser#functionsComponents}.
	 * @param ctx the parse tree
	 */
	void exitAnalyticFunctionsComponents(VtlParser.AnalyticFunctionsComponentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code joinFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterJoinFunctions(VtlParser.JoinFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code joinFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitJoinFunctions(VtlParser.JoinFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code genericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterGenericFunctions(VtlParser.GenericFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code genericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitGenericFunctions(VtlParser.GenericFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterStringFunctions(VtlParser.StringFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitStringFunctions(VtlParser.StringFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code numericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterNumericFunctions(VtlParser.NumericFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code numericFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitNumericFunctions(VtlParser.NumericFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code comparisonFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterComparisonFunctions(VtlParser.ComparisonFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code comparisonFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitComparisonFunctions(VtlParser.ComparisonFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterTimeFunctions(VtlParser.TimeFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitTimeFunctions(VtlParser.TimeFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code setFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterSetFunctions(VtlParser.SetFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code setFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitSetFunctions(VtlParser.SetFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code hierarchyFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterHierarchyFunctions(VtlParser.HierarchyFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code hierarchyFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitHierarchyFunctions(VtlParser.HierarchyFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code validationFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterValidationFunctions(VtlParser.ValidationFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code validationFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitValidationFunctions(VtlParser.ValidationFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code conditionalFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterConditionalFunctions(VtlParser.ConditionalFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code conditionalFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitConditionalFunctions(VtlParser.ConditionalFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code aggregateFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterAggregateFunctions(VtlParser.AggregateFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code aggregateFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitAggregateFunctions(VtlParser.AggregateFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code analyticFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void enterAnalyticFunctions(VtlParser.AnalyticFunctionsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code analyticFunctions}
	 * labeled alternative in {@link VtlParser#functions}.
	 * @param ctx the parse tree
	 */
	void exitAnalyticFunctions(VtlParser.AnalyticFunctionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#datasetClause}.
	 * @param ctx the parse tree
	 */
	void enterDatasetClause(VtlParser.DatasetClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#datasetClause}.
	 * @param ctx the parse tree
	 */
	void exitDatasetClause(VtlParser.DatasetClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#renameClause}.
	 * @param ctx the parse tree
	 */
	void enterRenameClause(VtlParser.RenameClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#renameClause}.
	 * @param ctx the parse tree
	 */
	void exitRenameClause(VtlParser.RenameClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#aggrClause}.
	 * @param ctx the parse tree
	 */
	void enterAggrClause(VtlParser.AggrClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#aggrClause}.
	 * @param ctx the parse tree
	 */
	void exitAggrClause(VtlParser.AggrClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#filterClause}.
	 * @param ctx the parse tree
	 */
	void enterFilterClause(VtlParser.FilterClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#filterClause}.
	 * @param ctx the parse tree
	 */
	void exitFilterClause(VtlParser.FilterClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#calcClause}.
	 * @param ctx the parse tree
	 */
	void enterCalcClause(VtlParser.CalcClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#calcClause}.
	 * @param ctx the parse tree
	 */
	void exitCalcClause(VtlParser.CalcClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#keepOrDropClause}.
	 * @param ctx the parse tree
	 */
	void enterKeepOrDropClause(VtlParser.KeepOrDropClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#keepOrDropClause}.
	 * @param ctx the parse tree
	 */
	void exitKeepOrDropClause(VtlParser.KeepOrDropClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#pivotOrUnpivotClause}.
	 * @param ctx the parse tree
	 */
	void enterPivotOrUnpivotClause(VtlParser.PivotOrUnpivotClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#pivotOrUnpivotClause}.
	 * @param ctx the parse tree
	 */
	void exitPivotOrUnpivotClause(VtlParser.PivotOrUnpivotClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#customPivotClause}.
	 * @param ctx the parse tree
	 */
	void enterCustomPivotClause(VtlParser.CustomPivotClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#customPivotClause}.
	 * @param ctx the parse tree
	 */
	void exitCustomPivotClause(VtlParser.CustomPivotClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#subspaceClause}.
	 * @param ctx the parse tree
	 */
	void enterSubspaceClause(VtlParser.SubspaceClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#subspaceClause}.
	 * @param ctx the parse tree
	 */
	void exitSubspaceClause(VtlParser.SubspaceClauseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code joinExpr}
	 * labeled alternative in {@link VtlParser#joinOperators}.
	 * @param ctx the parse tree
	 */
	void enterJoinExpr(VtlParser.JoinExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code joinExpr}
	 * labeled alternative in {@link VtlParser#joinOperators}.
	 * @param ctx the parse tree
	 */
	void exitJoinExpr(VtlParser.JoinExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code defOperator}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void enterDefOperator(VtlParser.DefOperatorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code defOperator}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void exitDefOperator(VtlParser.DefOperatorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code defDatapointRuleset}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void enterDefDatapointRuleset(VtlParser.DefDatapointRulesetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code defDatapointRuleset}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void exitDefDatapointRuleset(VtlParser.DefDatapointRulesetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code defHierarchical}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void enterDefHierarchical(VtlParser.DefHierarchicalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code defHierarchical}
	 * labeled alternative in {@link VtlParser#defOperators}.
	 * @param ctx the parse tree
	 */
	void exitDefHierarchical(VtlParser.DefHierarchicalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void enterCallDataset(VtlParser.CallDatasetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void exitCallDataset(VtlParser.CallDatasetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code evalAtom}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void enterEvalAtom(VtlParser.EvalAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code evalAtom}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void exitEvalAtom(VtlParser.EvalAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code castExprDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void enterCastExprDataset(VtlParser.CastExprDatasetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code castExprDataset}
	 * labeled alternative in {@link VtlParser#genericOperators}.
	 * @param ctx the parse tree
	 */
	void exitCastExprDataset(VtlParser.CastExprDatasetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterCallComponent(VtlParser.CallComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitCallComponent(VtlParser.CallComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code castExprComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterCastExprComponent(VtlParser.CastExprComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code castExprComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitCastExprComponent(VtlParser.CastExprComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code evalAtomComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterEvalAtomComponent(VtlParser.EvalAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code evalAtomComponent}
	 * labeled alternative in {@link VtlParser#genericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitEvalAtomComponent(VtlParser.EvalAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#parameterComponent}.
	 * @param ctx the parse tree
	 */
	void enterParameterComponent(VtlParser.ParameterComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#parameterComponent}.
	 * @param ctx the parse tree
	 */
	void exitParameterComponent(VtlParser.ParameterComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterParameter(VtlParser.ParameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitParameter(VtlParser.ParameterContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryStringFunction}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void enterUnaryStringFunction(VtlParser.UnaryStringFunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryStringFunction}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void exitUnaryStringFunction(VtlParser.UnaryStringFunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code substrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void enterSubstrAtom(VtlParser.SubstrAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code substrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void exitSubstrAtom(VtlParser.SubstrAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code replaceAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void enterReplaceAtom(VtlParser.ReplaceAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code replaceAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void exitReplaceAtom(VtlParser.ReplaceAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code instrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void enterInstrAtom(VtlParser.InstrAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code instrAtom}
	 * labeled alternative in {@link VtlParser#stringOperators}.
	 * @param ctx the parse tree
	 */
	void exitInstrAtom(VtlParser.InstrAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryStringFunctionComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterUnaryStringFunctionComponent(VtlParser.UnaryStringFunctionComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryStringFunctionComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitUnaryStringFunctionComponent(VtlParser.UnaryStringFunctionComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code substrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterSubstrAtomComponent(VtlParser.SubstrAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code substrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitSubstrAtomComponent(VtlParser.SubstrAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code replaceAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterReplaceAtomComponent(VtlParser.ReplaceAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code replaceAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitReplaceAtomComponent(VtlParser.ReplaceAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code instrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterInstrAtomComponent(VtlParser.InstrAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code instrAtomComponent}
	 * labeled alternative in {@link VtlParser#stringOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitInstrAtomComponent(VtlParser.InstrAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void enterUnaryNumeric(VtlParser.UnaryNumericContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void exitUnaryNumeric(VtlParser.UnaryNumericContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryWithOptionalNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void enterUnaryWithOptionalNumeric(VtlParser.UnaryWithOptionalNumericContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryWithOptionalNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void exitUnaryWithOptionalNumeric(VtlParser.UnaryWithOptionalNumericContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void enterBinaryNumeric(VtlParser.BinaryNumericContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryNumeric}
	 * labeled alternative in {@link VtlParser#numericOperators}.
	 * @param ctx the parse tree
	 */
	void exitBinaryNumeric(VtlParser.BinaryNumericContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterUnaryNumericComponent(VtlParser.UnaryNumericComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitUnaryNumericComponent(VtlParser.UnaryNumericComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryWithOptionalNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterUnaryWithOptionalNumericComponent(VtlParser.UnaryWithOptionalNumericComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryWithOptionalNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitUnaryWithOptionalNumericComponent(VtlParser.UnaryWithOptionalNumericComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterBinaryNumericComponent(VtlParser.BinaryNumericComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryNumericComponent}
	 * labeled alternative in {@link VtlParser#numericOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitBinaryNumericComponent(VtlParser.BinaryNumericComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code betweenAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void enterBetweenAtom(VtlParser.BetweenAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code betweenAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void exitBetweenAtom(VtlParser.BetweenAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code charsetMatchAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void enterCharsetMatchAtom(VtlParser.CharsetMatchAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code charsetMatchAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void exitCharsetMatchAtom(VtlParser.CharsetMatchAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code isNullAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void enterIsNullAtom(VtlParser.IsNullAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code isNullAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void exitIsNullAtom(VtlParser.IsNullAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code existInAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void enterExistInAtom(VtlParser.ExistInAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code existInAtom}
	 * labeled alternative in {@link VtlParser#comparisonOperators}.
	 * @param ctx the parse tree
	 */
	void exitExistInAtom(VtlParser.ExistInAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code betweenAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterBetweenAtomComponent(VtlParser.BetweenAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code betweenAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitBetweenAtomComponent(VtlParser.BetweenAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code charsetMatchAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterCharsetMatchAtomComponent(VtlParser.CharsetMatchAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code charsetMatchAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitCharsetMatchAtomComponent(VtlParser.CharsetMatchAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code isNullAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterIsNullAtomComponent(VtlParser.IsNullAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code isNullAtomComponent}
	 * labeled alternative in {@link VtlParser#comparisonOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitIsNullAtomComponent(VtlParser.IsNullAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code periodAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterPeriodAtom(VtlParser.PeriodAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code periodAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitPeriodAtom(VtlParser.PeriodAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code fillTimeAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterFillTimeAtom(VtlParser.FillTimeAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code fillTimeAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitFillTimeAtom(VtlParser.FillTimeAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code flowAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterFlowAtom(VtlParser.FlowAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code flowAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitFlowAtom(VtlParser.FlowAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeShiftAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterTimeShiftAtom(VtlParser.TimeShiftAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeShiftAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitTimeShiftAtom(VtlParser.TimeShiftAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeAggAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterTimeAggAtom(VtlParser.TimeAggAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeAggAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitTimeAggAtom(VtlParser.TimeAggAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code currentDateAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void enterCurrentDateAtom(VtlParser.CurrentDateAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code currentDateAtom}
	 * labeled alternative in {@link VtlParser#timeOperators}.
	 * @param ctx the parse tree
	 */
	void exitCurrentDateAtom(VtlParser.CurrentDateAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code periodAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterPeriodAtomComponent(VtlParser.PeriodAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code periodAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitPeriodAtomComponent(VtlParser.PeriodAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code fillTimeAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterFillTimeAtomComponent(VtlParser.FillTimeAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code fillTimeAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitFillTimeAtomComponent(VtlParser.FillTimeAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code flowAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterFlowAtomComponent(VtlParser.FlowAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code flowAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitFlowAtomComponent(VtlParser.FlowAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeShiftAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterTimeShiftAtomComponent(VtlParser.TimeShiftAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeShiftAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitTimeShiftAtomComponent(VtlParser.TimeShiftAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code timeAggAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterTimeAggAtomComponent(VtlParser.TimeAggAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code timeAggAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitTimeAggAtomComponent(VtlParser.TimeAggAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code currentDateAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterCurrentDateAtomComponent(VtlParser.CurrentDateAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code currentDateAtomComponent}
	 * labeled alternative in {@link VtlParser#timeOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitCurrentDateAtomComponent(VtlParser.CurrentDateAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unionAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void enterUnionAtom(VtlParser.UnionAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unionAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void exitUnionAtom(VtlParser.UnionAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code intersectAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void enterIntersectAtom(VtlParser.IntersectAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code intersectAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void exitIntersectAtom(VtlParser.IntersectAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code setOrSYmDiffAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void enterSetOrSYmDiffAtom(VtlParser.SetOrSYmDiffAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code setOrSYmDiffAtom}
	 * labeled alternative in {@link VtlParser#setOperators}.
	 * @param ctx the parse tree
	 */
	void exitSetOrSYmDiffAtom(VtlParser.SetOrSYmDiffAtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#hierarchyOperators}.
	 * @param ctx the parse tree
	 */
	void enterHierarchyOperators(VtlParser.HierarchyOperatorsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#hierarchyOperators}.
	 * @param ctx the parse tree
	 */
	void exitHierarchyOperators(VtlParser.HierarchyOperatorsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code validateDPruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void enterValidateDPruleset(VtlParser.ValidateDPrulesetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code validateDPruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void exitValidateDPruleset(VtlParser.ValidateDPrulesetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code validateHRruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void enterValidateHRruleset(VtlParser.ValidateHRrulesetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code validateHRruleset}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void exitValidateHRruleset(VtlParser.ValidateHRrulesetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code validationSimple}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void enterValidationSimple(VtlParser.ValidationSimpleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code validationSimple}
	 * labeled alternative in {@link VtlParser#validationOperators}.
	 * @param ctx the parse tree
	 */
	void exitValidationSimple(VtlParser.ValidationSimpleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nvlAtom}
	 * labeled alternative in {@link VtlParser#conditionalOperators}.
	 * @param ctx the parse tree
	 */
	void enterNvlAtom(VtlParser.NvlAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nvlAtom}
	 * labeled alternative in {@link VtlParser#conditionalOperators}.
	 * @param ctx the parse tree
	 */
	void exitNvlAtom(VtlParser.NvlAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nvlAtomComponent}
	 * labeled alternative in {@link VtlParser#conditionalOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void enterNvlAtomComponent(VtlParser.NvlAtomComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nvlAtomComponent}
	 * labeled alternative in {@link VtlParser#conditionalOperatorsComponent}.
	 * @param ctx the parse tree
	 */
	void exitNvlAtomComponent(VtlParser.NvlAtomComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code aggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 */
	void enterAggrComp(VtlParser.AggrCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code aggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 */
	void exitAggrComp(VtlParser.AggrCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code countAggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 */
	void enterCountAggrComp(VtlParser.CountAggrCompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code countAggrComp}
	 * labeled alternative in {@link VtlParser#aggrOperators}.
	 * @param ctx the parse tree
	 */
	void exitCountAggrComp(VtlParser.CountAggrCompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code aggrDataset}
	 * labeled alternative in {@link VtlParser#aggrOperatorsGrouping}.
	 * @param ctx the parse tree
	 */
	void enterAggrDataset(VtlParser.AggrDatasetContext ctx);
	/**
	 * Exit a parse tree produced by the {@code aggrDataset}
	 * labeled alternative in {@link VtlParser#aggrOperatorsGrouping}.
	 * @param ctx the parse tree
	 */
	void exitAggrDataset(VtlParser.AggrDatasetContext ctx);
	/**
	 * Enter a parse tree produced by the {@code anSimpleFunction}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void enterAnSimpleFunction(VtlParser.AnSimpleFunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code anSimpleFunction}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void exitAnSimpleFunction(VtlParser.AnSimpleFunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code lagOrLeadAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void enterLagOrLeadAn(VtlParser.LagOrLeadAnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code lagOrLeadAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void exitLagOrLeadAn(VtlParser.LagOrLeadAnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ratioToReportAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void enterRatioToReportAn(VtlParser.RatioToReportAnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ratioToReportAn}
	 * labeled alternative in {@link VtlParser#anFunction}.
	 * @param ctx the parse tree
	 */
	void exitRatioToReportAn(VtlParser.RatioToReportAnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code anSimpleFunctionComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void enterAnSimpleFunctionComponent(VtlParser.AnSimpleFunctionComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code anSimpleFunctionComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void exitAnSimpleFunctionComponent(VtlParser.AnSimpleFunctionComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code lagOrLeadAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void enterLagOrLeadAnComponent(VtlParser.LagOrLeadAnComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code lagOrLeadAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void exitLagOrLeadAnComponent(VtlParser.LagOrLeadAnComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rankAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void enterRankAnComponent(VtlParser.RankAnComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rankAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void exitRankAnComponent(VtlParser.RankAnComponentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ratioToReportAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void enterRatioToReportAnComponent(VtlParser.RatioToReportAnComponentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ratioToReportAnComponent}
	 * labeled alternative in {@link VtlParser#anFunctionComponent}.
	 * @param ctx the parse tree
	 */
	void exitRatioToReportAnComponent(VtlParser.RatioToReportAnComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#renameClauseItem}.
	 * @param ctx the parse tree
	 */
	void enterRenameClauseItem(VtlParser.RenameClauseItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#renameClauseItem}.
	 * @param ctx the parse tree
	 */
	void exitRenameClauseItem(VtlParser.RenameClauseItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#aggregateClause}.
	 * @param ctx the parse tree
	 */
	void enterAggregateClause(VtlParser.AggregateClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#aggregateClause}.
	 * @param ctx the parse tree
	 */
	void exitAggregateClause(VtlParser.AggregateClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#aggrFunctionClause}.
	 * @param ctx the parse tree
	 */
	void enterAggrFunctionClause(VtlParser.AggrFunctionClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#aggrFunctionClause}.
	 * @param ctx the parse tree
	 */
	void exitAggrFunctionClause(VtlParser.AggrFunctionClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#calcClauseItem}.
	 * @param ctx the parse tree
	 */
	void enterCalcClauseItem(VtlParser.CalcClauseItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#calcClauseItem}.
	 * @param ctx the parse tree
	 */
	void exitCalcClauseItem(VtlParser.CalcClauseItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#subspaceClauseItem}.
	 * @param ctx the parse tree
	 */
	void enterSubspaceClauseItem(VtlParser.SubspaceClauseItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#subspaceClauseItem}.
	 * @param ctx the parse tree
	 */
	void exitSubspaceClauseItem(VtlParser.SubspaceClauseItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code simpleScalar}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 */
	void enterSimpleScalar(VtlParser.SimpleScalarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code simpleScalar}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 */
	void exitSimpleScalar(VtlParser.SimpleScalarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code scalarWithCast}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 */
	void enterScalarWithCast(VtlParser.ScalarWithCastContext ctx);
	/**
	 * Exit a parse tree produced by the {@code scalarWithCast}
	 * labeled alternative in {@link VtlParser#scalarItem}.
	 * @param ctx the parse tree
	 */
	void exitScalarWithCast(VtlParser.ScalarWithCastContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#joinClauseWithoutUsing}.
	 * @param ctx the parse tree
	 */
	void enterJoinClauseWithoutUsing(VtlParser.JoinClauseWithoutUsingContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#joinClauseWithoutUsing}.
	 * @param ctx the parse tree
	 */
	void exitJoinClauseWithoutUsing(VtlParser.JoinClauseWithoutUsingContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoinClause(VtlParser.JoinClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoinClause(VtlParser.JoinClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#joinClauseItem}.
	 * @param ctx the parse tree
	 */
	void enterJoinClauseItem(VtlParser.JoinClauseItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#joinClauseItem}.
	 * @param ctx the parse tree
	 */
	void exitJoinClauseItem(VtlParser.JoinClauseItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#joinBody}.
	 * @param ctx the parse tree
	 */
	void enterJoinBody(VtlParser.JoinBodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#joinBody}.
	 * @param ctx the parse tree
	 */
	void exitJoinBody(VtlParser.JoinBodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#joinApplyClause}.
	 * @param ctx the parse tree
	 */
	void enterJoinApplyClause(VtlParser.JoinApplyClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#joinApplyClause}.
	 * @param ctx the parse tree
	 */
	void exitJoinApplyClause(VtlParser.JoinApplyClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#partitionByClause}.
	 * @param ctx the parse tree
	 */
	void enterPartitionByClause(VtlParser.PartitionByClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#partitionByClause}.
	 * @param ctx the parse tree
	 */
	void exitPartitionByClause(VtlParser.PartitionByClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#orderByClause}.
	 * @param ctx the parse tree
	 */
	void enterOrderByClause(VtlParser.OrderByClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#orderByClause}.
	 * @param ctx the parse tree
	 */
	void exitOrderByClause(VtlParser.OrderByClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#orderByItem}.
	 * @param ctx the parse tree
	 */
	void enterOrderByItem(VtlParser.OrderByItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#orderByItem}.
	 * @param ctx the parse tree
	 */
	void exitOrderByItem(VtlParser.OrderByItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#windowingClause}.
	 * @param ctx the parse tree
	 */
	void enterWindowingClause(VtlParser.WindowingClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#windowingClause}.
	 * @param ctx the parse tree
	 */
	void exitWindowingClause(VtlParser.WindowingClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#signedInteger}.
	 * @param ctx the parse tree
	 */
	void enterSignedInteger(VtlParser.SignedIntegerContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#signedInteger}.
	 * @param ctx the parse tree
	 */
	void exitSignedInteger(VtlParser.SignedIntegerContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#limitClauseItem}.
	 * @param ctx the parse tree
	 */
	void enterLimitClauseItem(VtlParser.LimitClauseItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#limitClauseItem}.
	 * @param ctx the parse tree
	 */
	void exitLimitClauseItem(VtlParser.LimitClauseItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code groupByOrExcept}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 */
	void enterGroupByOrExcept(VtlParser.GroupByOrExceptContext ctx);
	/**
	 * Exit a parse tree produced by the {@code groupByOrExcept}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 */
	void exitGroupByOrExcept(VtlParser.GroupByOrExceptContext ctx);
	/**
	 * Enter a parse tree produced by the {@code groupAll}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 */
	void enterGroupAll(VtlParser.GroupAllContext ctx);
	/**
	 * Exit a parse tree produced by the {@code groupAll}
	 * labeled alternative in {@link VtlParser#groupingClause}.
	 * @param ctx the parse tree
	 */
	void exitGroupAll(VtlParser.GroupAllContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#havingClause}.
	 * @param ctx the parse tree
	 */
	void enterHavingClause(VtlParser.HavingClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#havingClause}.
	 * @param ctx the parse tree
	 */
	void exitHavingClause(VtlParser.HavingClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#parameterItem}.
	 * @param ctx the parse tree
	 */
	void enterParameterItem(VtlParser.ParameterItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#parameterItem}.
	 * @param ctx the parse tree
	 */
	void exitParameterItem(VtlParser.ParameterItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#outputParameterType}.
	 * @param ctx the parse tree
	 */
	void enterOutputParameterType(VtlParser.OutputParameterTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#outputParameterType}.
	 * @param ctx the parse tree
	 */
	void exitOutputParameterType(VtlParser.OutputParameterTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#outputParameterTypeComponent}.
	 * @param ctx the parse tree
	 */
	void enterOutputParameterTypeComponent(VtlParser.OutputParameterTypeComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#outputParameterTypeComponent}.
	 * @param ctx the parse tree
	 */
	void exitOutputParameterTypeComponent(VtlParser.OutputParameterTypeComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#inputParameterType}.
	 * @param ctx the parse tree
	 */
	void enterInputParameterType(VtlParser.InputParameterTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#inputParameterType}.
	 * @param ctx the parse tree
	 */
	void exitInputParameterType(VtlParser.InputParameterTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#rulesetType}.
	 * @param ctx the parse tree
	 */
	void enterRulesetType(VtlParser.RulesetTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#rulesetType}.
	 * @param ctx the parse tree
	 */
	void exitRulesetType(VtlParser.RulesetTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#scalarType}.
	 * @param ctx the parse tree
	 */
	void enterScalarType(VtlParser.ScalarTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#scalarType}.
	 * @param ctx the parse tree
	 */
	void exitScalarType(VtlParser.ScalarTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#componentType}.
	 * @param ctx the parse tree
	 */
	void enterComponentType(VtlParser.ComponentTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#componentType}.
	 * @param ctx the parse tree
	 */
	void exitComponentType(VtlParser.ComponentTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#datasetType}.
	 * @param ctx the parse tree
	 */
	void enterDatasetType(VtlParser.DatasetTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#datasetType}.
	 * @param ctx the parse tree
	 */
	void exitDatasetType(VtlParser.DatasetTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#evalDatasetType}.
	 * @param ctx the parse tree
	 */
	void enterEvalDatasetType(VtlParser.EvalDatasetTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#evalDatasetType}.
	 * @param ctx the parse tree
	 */
	void exitEvalDatasetType(VtlParser.EvalDatasetTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#scalarSetType}.
	 * @param ctx the parse tree
	 */
	void enterScalarSetType(VtlParser.ScalarSetTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#scalarSetType}.
	 * @param ctx the parse tree
	 */
	void exitScalarSetType(VtlParser.ScalarSetTypeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dataPoint}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void enterDataPoint(VtlParser.DataPointContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dataPoint}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void exitDataPoint(VtlParser.DataPointContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dataPointVd}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void enterDataPointVd(VtlParser.DataPointVdContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dataPointVd}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void exitDataPointVd(VtlParser.DataPointVdContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dataPointVar}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void enterDataPointVar(VtlParser.DataPointVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dataPointVar}
	 * labeled alternative in {@link VtlParser#dpRuleset}.
	 * @param ctx the parse tree
	 */
	void exitDataPointVar(VtlParser.DataPointVarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code hrRulesetType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void enterHrRulesetType(VtlParser.HrRulesetTypeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code hrRulesetType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void exitHrRulesetType(VtlParser.HrRulesetTypeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code hrRulesetVdType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void enterHrRulesetVdType(VtlParser.HrRulesetVdTypeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code hrRulesetVdType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void exitHrRulesetVdType(VtlParser.HrRulesetVdTypeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code hrRulesetVarType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void enterHrRulesetVarType(VtlParser.HrRulesetVarTypeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code hrRulesetVarType}
	 * labeled alternative in {@link VtlParser#hrRuleset}.
	 * @param ctx the parse tree
	 */
	void exitHrRulesetVarType(VtlParser.HrRulesetVarTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#valueDomainName}.
	 * @param ctx the parse tree
	 */
	void enterValueDomainName(VtlParser.ValueDomainNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#valueDomainName}.
	 * @param ctx the parse tree
	 */
	void exitValueDomainName(VtlParser.ValueDomainNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#rulesetID}.
	 * @param ctx the parse tree
	 */
	void enterRulesetID(VtlParser.RulesetIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#rulesetID}.
	 * @param ctx the parse tree
	 */
	void exitRulesetID(VtlParser.RulesetIDContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#rulesetSignature}.
	 * @param ctx the parse tree
	 */
	void enterRulesetSignature(VtlParser.RulesetSignatureContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#rulesetSignature}.
	 * @param ctx the parse tree
	 */
	void exitRulesetSignature(VtlParser.RulesetSignatureContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#signature}.
	 * @param ctx the parse tree
	 */
	void enterSignature(VtlParser.SignatureContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#signature}.
	 * @param ctx the parse tree
	 */
	void exitSignature(VtlParser.SignatureContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#ruleClauseDatapoint}.
	 * @param ctx the parse tree
	 */
	void enterRuleClauseDatapoint(VtlParser.RuleClauseDatapointContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#ruleClauseDatapoint}.
	 * @param ctx the parse tree
	 */
	void exitRuleClauseDatapoint(VtlParser.RuleClauseDatapointContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#ruleItemDatapoint}.
	 * @param ctx the parse tree
	 */
	void enterRuleItemDatapoint(VtlParser.RuleItemDatapointContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#ruleItemDatapoint}.
	 * @param ctx the parse tree
	 */
	void exitRuleItemDatapoint(VtlParser.RuleItemDatapointContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#ruleClauseHierarchical}.
	 * @param ctx the parse tree
	 */
	void enterRuleClauseHierarchical(VtlParser.RuleClauseHierarchicalContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#ruleClauseHierarchical}.
	 * @param ctx the parse tree
	 */
	void exitRuleClauseHierarchical(VtlParser.RuleClauseHierarchicalContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#ruleItemHierarchical}.
	 * @param ctx the parse tree
	 */
	void enterRuleItemHierarchical(VtlParser.RuleItemHierarchicalContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#ruleItemHierarchical}.
	 * @param ctx the parse tree
	 */
	void exitRuleItemHierarchical(VtlParser.RuleItemHierarchicalContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#hierRuleSignature}.
	 * @param ctx the parse tree
	 */
	void enterHierRuleSignature(VtlParser.HierRuleSignatureContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#hierRuleSignature}.
	 * @param ctx the parse tree
	 */
	void exitHierRuleSignature(VtlParser.HierRuleSignatureContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#valueDomainSignature}.
	 * @param ctx the parse tree
	 */
	void enterValueDomainSignature(VtlParser.ValueDomainSignatureContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#valueDomainSignature}.
	 * @param ctx the parse tree
	 */
	void exitValueDomainSignature(VtlParser.ValueDomainSignatureContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#codeItemRelation}.
	 * @param ctx the parse tree
	 */
	void enterCodeItemRelation(VtlParser.CodeItemRelationContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#codeItemRelation}.
	 * @param ctx the parse tree
	 */
	void exitCodeItemRelation(VtlParser.CodeItemRelationContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#codeItemRelationClause}.
	 * @param ctx the parse tree
	 */
	void enterCodeItemRelationClause(VtlParser.CodeItemRelationClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#codeItemRelationClause}.
	 * @param ctx the parse tree
	 */
	void exitCodeItemRelationClause(VtlParser.CodeItemRelationClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#valueDomainValue}.
	 * @param ctx the parse tree
	 */
	void enterValueDomainValue(VtlParser.ValueDomainValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#valueDomainValue}.
	 * @param ctx the parse tree
	 */
	void exitValueDomainValue(VtlParser.ValueDomainValueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code conditionConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 */
	void enterConditionConstraint(VtlParser.ConditionConstraintContext ctx);
	/**
	 * Exit a parse tree produced by the {@code conditionConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 */
	void exitConditionConstraint(VtlParser.ConditionConstraintContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rangeConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 */
	void enterRangeConstraint(VtlParser.RangeConstraintContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rangeConstraint}
	 * labeled alternative in {@link VtlParser#scalarTypeConstraint}.
	 * @param ctx the parse tree
	 */
	void exitRangeConstraint(VtlParser.RangeConstraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#compConstraint}.
	 * @param ctx the parse tree
	 */
	void enterCompConstraint(VtlParser.CompConstraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#compConstraint}.
	 * @param ctx the parse tree
	 */
	void exitCompConstraint(VtlParser.CompConstraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#multModifier}.
	 * @param ctx the parse tree
	 */
	void enterMultModifier(VtlParser.MultModifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#multModifier}.
	 * @param ctx the parse tree
	 */
	void exitMultModifier(VtlParser.MultModifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#validationOutput}.
	 * @param ctx the parse tree
	 */
	void enterValidationOutput(VtlParser.ValidationOutputContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#validationOutput}.
	 * @param ctx the parse tree
	 */
	void exitValidationOutput(VtlParser.ValidationOutputContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#validationMode}.
	 * @param ctx the parse tree
	 */
	void enterValidationMode(VtlParser.ValidationModeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#validationMode}.
	 * @param ctx the parse tree
	 */
	void exitValidationMode(VtlParser.ValidationModeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#conditionClause}.
	 * @param ctx the parse tree
	 */
	void enterConditionClause(VtlParser.ConditionClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#conditionClause}.
	 * @param ctx the parse tree
	 */
	void exitConditionClause(VtlParser.ConditionClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#inputMode}.
	 * @param ctx the parse tree
	 */
	void enterInputMode(VtlParser.InputModeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#inputMode}.
	 * @param ctx the parse tree
	 */
	void exitInputMode(VtlParser.InputModeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#imbalanceExpr}.
	 * @param ctx the parse tree
	 */
	void enterImbalanceExpr(VtlParser.ImbalanceExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#imbalanceExpr}.
	 * @param ctx the parse tree
	 */
	void exitImbalanceExpr(VtlParser.ImbalanceExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#inputModeHierarchy}.
	 * @param ctx the parse tree
	 */
	void enterInputModeHierarchy(VtlParser.InputModeHierarchyContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#inputModeHierarchy}.
	 * @param ctx the parse tree
	 */
	void exitInputModeHierarchy(VtlParser.InputModeHierarchyContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#outputModeHierarchy}.
	 * @param ctx the parse tree
	 */
	void enterOutputModeHierarchy(VtlParser.OutputModeHierarchyContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#outputModeHierarchy}.
	 * @param ctx the parse tree
	 */
	void exitOutputModeHierarchy(VtlParser.OutputModeHierarchyContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#alias}.
	 * @param ctx the parse tree
	 */
	void enterAlias(VtlParser.AliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#alias}.
	 * @param ctx the parse tree
	 */
	void exitAlias(VtlParser.AliasContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#varID}.
	 * @param ctx the parse tree
	 */
	void enterVarID(VtlParser.VarIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#varID}.
	 * @param ctx the parse tree
	 */
	void exitVarID(VtlParser.VarIDContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#simpleComponentId}.
	 * @param ctx the parse tree
	 */
	void enterSimpleComponentId(VtlParser.SimpleComponentIdContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#simpleComponentId}.
	 * @param ctx the parse tree
	 */
	void exitSimpleComponentId(VtlParser.SimpleComponentIdContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#componentID}.
	 * @param ctx the parse tree
	 */
	void enterComponentID(VtlParser.ComponentIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#componentID}.
	 * @param ctx the parse tree
	 */
	void exitComponentID(VtlParser.ComponentIDContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#lists}.
	 * @param ctx the parse tree
	 */
	void enterLists(VtlParser.ListsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#lists}.
	 * @param ctx the parse tree
	 */
	void exitLists(VtlParser.ListsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#erCode}.
	 * @param ctx the parse tree
	 */
	void enterErCode(VtlParser.ErCodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#erCode}.
	 * @param ctx the parse tree
	 */
	void exitErCode(VtlParser.ErCodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#erLevel}.
	 * @param ctx the parse tree
	 */
	void enterErLevel(VtlParser.ErLevelContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#erLevel}.
	 * @param ctx the parse tree
	 */
	void exitErLevel(VtlParser.ErLevelContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#comparisonOperand}.
	 * @param ctx the parse tree
	 */
	void enterComparisonOperand(VtlParser.ComparisonOperandContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#comparisonOperand}.
	 * @param ctx the parse tree
	 */
	void exitComparisonOperand(VtlParser.ComparisonOperandContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#optionalExpr}.
	 * @param ctx the parse tree
	 */
	void enterOptionalExpr(VtlParser.OptionalExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#optionalExpr}.
	 * @param ctx the parse tree
	 */
	void exitOptionalExpr(VtlParser.OptionalExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#optionalExprComponent}.
	 * @param ctx the parse tree
	 */
	void enterOptionalExprComponent(VtlParser.OptionalExprComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#optionalExprComponent}.
	 * @param ctx the parse tree
	 */
	void exitOptionalExprComponent(VtlParser.OptionalExprComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#componentRole}.
	 * @param ctx the parse tree
	 */
	void enterComponentRole(VtlParser.ComponentRoleContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#componentRole}.
	 * @param ctx the parse tree
	 */
	void exitComponentRole(VtlParser.ComponentRoleContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#viralAttribute}.
	 * @param ctx the parse tree
	 */
	void enterViralAttribute(VtlParser.ViralAttributeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#viralAttribute}.
	 * @param ctx the parse tree
	 */
	void exitViralAttribute(VtlParser.ViralAttributeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#valueDomainID}.
	 * @param ctx the parse tree
	 */
	void enterValueDomainID(VtlParser.ValueDomainIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#valueDomainID}.
	 * @param ctx the parse tree
	 */
	void exitValueDomainID(VtlParser.ValueDomainIDContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#operatorID}.
	 * @param ctx the parse tree
	 */
	void enterOperatorID(VtlParser.OperatorIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#operatorID}.
	 * @param ctx the parse tree
	 */
	void exitOperatorID(VtlParser.OperatorIDContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#routineName}.
	 * @param ctx the parse tree
	 */
	void enterRoutineName(VtlParser.RoutineNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#routineName}.
	 * @param ctx the parse tree
	 */
	void exitRoutineName(VtlParser.RoutineNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#constant}.
	 * @param ctx the parse tree
	 */
	void enterConstant(VtlParser.ConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#constant}.
	 * @param ctx the parse tree
	 */
	void exitConstant(VtlParser.ConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#basicScalarType}.
	 * @param ctx the parse tree
	 */
	void enterBasicScalarType(VtlParser.BasicScalarTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#basicScalarType}.
	 * @param ctx the parse tree
	 */
	void exitBasicScalarType(VtlParser.BasicScalarTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VtlParser#retainType}.
	 * @param ctx the parse tree
	 */
	void enterRetainType(VtlParser.RetainTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VtlParser#retainType}.
	 * @param ctx the parse tree
	 */
	void exitRetainType(VtlParser.RetainTypeContext ctx);
}