package io.sdmx.fusion.vtl.constant;

public class VtlConstants {

    public static final String PERSISTENT_OPERATOR = "<-";
    public static final String NON_PERSISTENT_OPERATOR = ":=";
    public static final String END_OF_FILE_SYMBOL = ";";
}
