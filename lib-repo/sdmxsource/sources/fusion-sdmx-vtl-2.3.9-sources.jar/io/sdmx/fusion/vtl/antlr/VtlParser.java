// Generated from org/sdmx/vtl/Vtl.g4 by ANTLR 4.13.2
package io.sdmx.fusion.vtl.antlr;
import java.util.List;

import org.antlr.v4.runtime.FailedPredicateException;
import org.antlr.v4.runtime.NoViableAltException;
import org.antlr.v4.runtime.Parser;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.RuntimeMetaData;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.Vocabulary;
import org.antlr.v4.runtime.VocabularyImpl;
import org.antlr.v4.runtime.atn.ATN;
import org.antlr.v4.runtime.atn.ATNDeserializer;
import org.antlr.v4.runtime.atn.ParserATNSimulator;
import org.antlr.v4.runtime.atn.PredictionContextCache;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.tree.ParseTreeListener;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;
import org.antlr.v4.runtime.tree.TerminalNode;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class VtlParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LPAREN=1, RPAREN=2, QLPAREN=3, QRPAREN=4, GLPAREN=5, GRPAREN=6, EQ=7,
		LT=8, MT=9, ME=10, NEQ=11, LE=12, PLUS=13, MINUS=14, MUL=15, DIV=16, COMMA=17,
		POINTER=18, COLON=19, ASSIGN=20, MEMBERSHIP=21, EVAL=22, IF=23, THEN=24,
		ELSE=25, USING=26, WITH=27, CURRENT_DATE=28, ON=29, DROP=30, KEEP=31,
		CALC=32, ATTRCALC=33, RENAME=34, AS=35, AND=36, OR=37, XOR=38, NOT=39,
		BETWEEN=40, IN=41, NOT_IN=42, NULL_CONSTANT=43, ISNULL=44, EX=45, UNION=46,
		DIFF=47, SYMDIFF=48, INTERSECT=49, KEYS=50, INTYEAR=51, INTMONTH=52, INTDAY=53,
		CHECK=54, EXISTS_IN=55, TO=56, RETURN=57, IMBALANCE=58, ERRORCODE=59,
		ALL=60, AGGREGATE=61, ERRORLEVEL=62, ORDER=63, BY=64, RANK=65, ASC=66,
		DESC=67, MIN=68, MAX=69, FIRST=70, LAST=71, INDEXOF=72, ABS=73, KEY=74,
		LN=75, LOG=76, TRUNC=77, ROUND=78, POWER=79, MOD=80, LEN=81, CONCAT=82,
		TRIM=83, UCASE=84, LCASE=85, SUBSTR=86, SUM=87, AVG=88, MEDIAN=89, COUNT=90,
		DIMENSION=91, MEASURE=92, ATTRIBUTE=93, FILTER=94, MERGE=95, EXP=96, ROLE=97,
		VIRAL=98, CHARSET_MATCH=99, TYPE=100, NVL=101, HIERARCHY=102, OPTIONAL=103,
		INVALID=104, VALUE_DOMAIN=105, VARIABLE=106, DATA=107, STRUCTURE=108,
		DATASET=109, OPERATOR=110, DEFINE=111, PUT_SYMBOL=112, DATAPOINT=113,
		HIERARCHICAL=114, RULESET=115, RULE=116, END=117, ALTER_DATASET=118, LTRIM=119,
		RTRIM=120, INSTR=121, REPLACE=122, CEIL=123, FLOOR=124, SQRT=125, ANY=126,
		SETDIFF=127, STDDEV_POP=128, STDDEV_SAMP=129, VAR_POP=130, VAR_SAMP=131,
		GROUP=132, EXCEPT=133, HAVING=134, FIRST_VALUE=135, LAST_VALUE=136, LAG=137,
		LEAD=138, RATIO_TO_REPORT=139, OVER=140, PRECEDING=141, FOLLOWING=142,
		UNBOUNDED=143, PARTITION=144, ROWS=145, RANGE=146, CURRENT=147, VALID=148,
		FILL_TIME_SERIES=149, FLOW_TO_STOCK=150, STOCK_TO_FLOW=151, TIMESHIFT=152,
		MEASURES=153, NO_MEASURES=154, CONDITION=155, BOOLEAN=156, DATE=157, TIME_PERIOD=158,
		NUMBER=159, STRING=160, TIME=161, INTEGER=162, FLOAT=163, LIST=164, RECORD=165,
		RESTRICT=166, YYYY=167, MM=168, DD=169, MAX_LENGTH=170, REGEXP=171, IS=172,
		WHEN=173, FROM=174, AGGREGATES=175, POINTS=176, POINT=177, TOTAL=178,
		PARTIAL=179, ALWAYS=180, INNER_JOIN=181, LEFT_JOIN=182, CROSS_JOIN=183,
		FULL_JOIN=184, MAPS_FROM=185, MAPS_TO=186, MAP_TO=187, MAP_FROM=188, RETURNS=189,
		PIVOT=190, CUSTOMPIVOT=191, UNPIVOT=192, SUBSPACE=193, APPLY=194, CONDITIONED=195,
		PERIOD_INDICATOR=196, SINGLE=197, DURATION=198, TIME_AGG=199, UNIT=200,
		VALUE=201, VALUEDOMAINS=202, VARIABLES=203, INPUT=204, OUTPUT=205, CAST=206,
		RULE_PRIORITY=207, DATASET_PRIORITY=208, DEFAULT=209, CHECK_DATAPOINT=210,
		CHECK_HIERARCHY=211, COMPUTED=212, NON_NULL=213, NON_ZERO=214, PARTIAL_NULL=215,
		PARTIAL_ZERO=216, ALWAYS_NULL=217, ALWAYS_ZERO=218, COMPONENTS=219, ALL_MEASURES=220,
		SCALAR=221, COMPONENT=222, DATAPOINT_ON_VD=223, DATAPOINT_ON_VAR=224,
		HIERARCHICAL_ON_VD=225, HIERARCHICAL_ON_VAR=226, SET=227, LANGUAGE=228,
		INTEGER_CONSTANT=229, NUMBER_CONSTANT=230, BOOLEAN_CONSTANT=231, STRING_CONSTANT=232,
		IDENTIFIER=233, WS=234, EOL=235, ML_COMMENT=236, SL_COMMENT=237;
	public static final int
		RULE_start = 0, RULE_statement = 1, RULE_expr = 2, RULE_exprComponent = 3,
		RULE_functionsComponents = 4, RULE_functions = 5, RULE_datasetClause = 6,
		RULE_renameClause = 7, RULE_aggrClause = 8, RULE_filterClause = 9, RULE_calcClause = 10,
		RULE_keepOrDropClause = 11, RULE_pivotOrUnpivotClause = 12, RULE_customPivotClause = 13,
		RULE_subspaceClause = 14, RULE_joinOperators = 15, RULE_defOperators = 16,
		RULE_genericOperators = 17, RULE_genericOperatorsComponent = 18, RULE_parameterComponent = 19,
		RULE_parameter = 20, RULE_stringOperators = 21, RULE_stringOperatorsComponent = 22,
		RULE_numericOperators = 23, RULE_numericOperatorsComponent = 24, RULE_comparisonOperators = 25,
		RULE_comparisonOperatorsComponent = 26, RULE_timeOperators = 27, RULE_timeOperatorsComponent = 28,
		RULE_setOperators = 29, RULE_hierarchyOperators = 30, RULE_validationOperators = 31,
		RULE_conditionalOperators = 32, RULE_conditionalOperatorsComponent = 33,
		RULE_aggrOperators = 34, RULE_aggrOperatorsGrouping = 35, RULE_anFunction = 36,
		RULE_anFunctionComponent = 37, RULE_renameClauseItem = 38, RULE_aggregateClause = 39,
		RULE_aggrFunctionClause = 40, RULE_calcClauseItem = 41, RULE_subspaceClauseItem = 42,
		RULE_scalarItem = 43, RULE_joinClauseWithoutUsing = 44, RULE_joinClause = 45,
		RULE_joinClauseItem = 46, RULE_joinBody = 47, RULE_joinApplyClause = 48,
		RULE_partitionByClause = 49, RULE_orderByClause = 50, RULE_orderByItem = 51,
		RULE_windowingClause = 52, RULE_signedInteger = 53, RULE_limitClauseItem = 54,
		RULE_groupingClause = 55, RULE_havingClause = 56, RULE_parameterItem = 57,
		RULE_outputParameterType = 58, RULE_outputParameterTypeComponent = 59,
		RULE_inputParameterType = 60, RULE_rulesetType = 61, RULE_scalarType = 62,
		RULE_componentType = 63, RULE_datasetType = 64, RULE_evalDatasetType = 65,
		RULE_scalarSetType = 66, RULE_dpRuleset = 67, RULE_hrRuleset = 68, RULE_valueDomainName = 69,
		RULE_rulesetID = 70, RULE_rulesetSignature = 71, RULE_signature = 72,
		RULE_ruleClauseDatapoint = 73, RULE_ruleItemDatapoint = 74, RULE_ruleClauseHierarchical = 75,
		RULE_ruleItemHierarchical = 76, RULE_hierRuleSignature = 77, RULE_valueDomainSignature = 78,
		RULE_codeItemRelation = 79, RULE_codeItemRelationClause = 80, RULE_valueDomainValue = 81,
		RULE_scalarTypeConstraint = 82, RULE_compConstraint = 83, RULE_multModifier = 84,
		RULE_validationOutput = 85, RULE_validationMode = 86, RULE_conditionClause = 87,
		RULE_inputMode = 88, RULE_imbalanceExpr = 89, RULE_inputModeHierarchy = 90,
		RULE_outputModeHierarchy = 91, RULE_alias = 92, RULE_varID = 93, RULE_simpleComponentId = 94,
		RULE_componentID = 95, RULE_lists = 96, RULE_erCode = 97, RULE_erLevel = 98,
		RULE_comparisonOperand = 99, RULE_optionalExpr = 100, RULE_optionalExprComponent = 101,
		RULE_componentRole = 102, RULE_viralAttribute = 103, RULE_valueDomainID = 104,
		RULE_operatorID = 105, RULE_routineName = 106, RULE_constant = 107, RULE_basicScalarType = 108,
		RULE_retainType = 109;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "statement", "expr", "exprComponent", "functionsComponents",
			"functions", "datasetClause", "renameClause", "aggrClause", "filterClause",
			"calcClause", "keepOrDropClause", "pivotOrUnpivotClause", "customPivotClause",
			"subspaceClause", "joinOperators", "defOperators", "genericOperators",
			"genericOperatorsComponent", "parameterComponent", "parameter", "stringOperators",
			"stringOperatorsComponent", "numericOperators", "numericOperatorsComponent",
			"comparisonOperators", "comparisonOperatorsComponent", "timeOperators",
			"timeOperatorsComponent", "setOperators", "hierarchyOperators", "validationOperators",
			"conditionalOperators", "conditionalOperatorsComponent", "aggrOperators",
			"aggrOperatorsGrouping", "anFunction", "anFunctionComponent", "renameClauseItem",
			"aggregateClause", "aggrFunctionClause", "calcClauseItem", "subspaceClauseItem",
			"scalarItem", "joinClauseWithoutUsing", "joinClause", "joinClauseItem",
			"joinBody", "joinApplyClause", "partitionByClause", "orderByClause",
			"orderByItem", "windowingClause", "signedInteger", "limitClauseItem",
			"groupingClause", "havingClause", "parameterItem", "outputParameterType",
			"outputParameterTypeComponent", "inputParameterType", "rulesetType",
			"scalarType", "componentType", "datasetType", "evalDatasetType", "scalarSetType",
			"dpRuleset", "hrRuleset", "valueDomainName", "rulesetID", "rulesetSignature",
			"signature", "ruleClauseDatapoint", "ruleItemDatapoint", "ruleClauseHierarchical",
			"ruleItemHierarchical", "hierRuleSignature", "valueDomainSignature",
			"codeItemRelation", "codeItemRelationClause", "valueDomainValue", "scalarTypeConstraint",
			"compConstraint", "multModifier", "validationOutput", "validationMode",
			"conditionClause", "inputMode", "imbalanceExpr", "inputModeHierarchy",
			"outputModeHierarchy", "alias", "varID", "simpleComponentId", "componentID",
			"lists", "erCode", "erLevel", "comparisonOperand", "optionalExpr", "optionalExprComponent",
			"componentRole", "viralAttribute", "valueDomainID", "operatorID", "routineName",
			"constant", "basicScalarType", "retainType"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "')'", "'['", "']'", "'{'", "'}'", "'='", "'<'", "'>'",
			"'>='", "'<>'", "'<='", "'+'", "'-'", "'*'", "'/'", "','", "'->'", "':'",
			"':='", "'#'", "'eval'", "'if'", "'then'", "'else'", "'using'", "'with'",
			"'current_date'", "'on'", "'drop'", "'keep'", "'calc'", "'attrcalc'",
			"'rename'", "'as'", "'and'", "'or'", "'xor'", "'not'", "'between'", "'in'",
			"'not_in'", "'null'", "'isnull'", "'ex'", "'union'", "'diff'", "'symdiff'",
			"'intersect'", "'keys'", "'intyear'", "'intmonth'", "'intday'", "'check'",
			"'exists_in'", "'to'", "'return'", "'imbalance'", "'errorcode'", "'all'",
			"'aggr'", "'errorlevel'", "'order'", "'by'", "'rank'", "'asc'", "'desc'",
			"'min'", "'max'", "'first'", "'last'", "'indexof'", "'abs'", "'key'",
			"'ln'", "'log'", "'trunc'", "'round'", "'power'", "'mod'", "'length'",
			"'||'", "'trim'", "'upper'", "'lower'", "'substr'", "'sum'", "'avg'",
			"'median'", "'count'", "'identifier'", "'measure'", "'attribute'", "'filter'",
			"'merge'", "'exp'", "'componentRole'", "'viral'", "'match_characters'",
			"'type'", "'nvl'", "'hierarchy'", "'_'", "'invalid'", "'valuedomain'",
			"'variable'", "'data'", "'structure'", "'dataset'", "'operator'", "'define'",
			"'<-'", "'datapoint'", "'hierarchical'", "'ruleset'", "'rule'", "'end'",
			"'alterDataset'", "'ltrim'", "'rtrim'", "'instr'", "'replace'", "'ceil'",
			"'floor'", "'sqrt'", "'any'", "'setdiff'", "'stddev_pop'", "'stddev_samp'",
			"'var_pop'", "'var_samp'", "'group'", "'except'", "'having'", "'first_value'",
			"'last_value'", "'lag'", "'lead'", "'ratio_to_report'", "'over'", "'preceding'",
			"'following'", "'unbounded'", "'partition'", "'rows'", "'range'", "'current'",
			"'valid'", "'fill_time_series'", "'flow_to_stock'", "'stock_to_flow'",
			"'timeshift'", "'measures'", "'no_measures'", "'condition'", "'boolean'",
			"'date'", "'time_period'", "'number'", "'string'", "'time'", "'integer'",
			"'float'", "'list'", "'record'", "'restrict'", "'yyyy'", "'mm'", "'dd'",
			"'maxLength'", "'regexp'", "'is'", "'when'", "'from'", "'aggregates'",
			"'points'", "'point'", "'total'", "'partial'", "'always'", "'inner_join'",
			"'left_join'", "'cross_join'", "'full_join'", "'maps_from'", "'maps_to'",
			"'map_to'", "'map_from'", "'returns'", "'pivot'", "'customPivot'", "'unpivot'",
			"'sub'", "'apply'", "'conditioned'", "'period_indicator'", "'single'",
			"'duration'", "'time_agg'", "'unit'", "'Value'", "'valuedomains'", "'variables'",
			"'input'", "'output'", "'cast'", "'rule_priority'", "'dataset_priority'",
			"'default'", "'check_datapoint'", "'check_hierarchy'", "'computed'",
			"'non_null'", "'non_zero'", "'partial_null'", "'partial_zero'", "'always_null'",
			"'always_zero'", "'components'", "'all_measures'", "'scalar'", "'component'",
			"'datapoint_on_valuedomains'", "'datapoint_on_variables'", "'hierarchical_on_valuedomains'",
			"'hierarchical_on_variables'", "'set'", "'language'", null, null, null,
			null, null, null, "';'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "LPAREN", "RPAREN", "QLPAREN", "QRPAREN", "GLPAREN", "GRPAREN",
			"EQ", "LT", "MT", "ME", "NEQ", "LE", "PLUS", "MINUS", "MUL", "DIV", "COMMA",
			"POINTER", "COLON", "ASSIGN", "MEMBERSHIP", "EVAL", "IF", "THEN", "ELSE",
			"USING", "WITH", "CURRENT_DATE", "ON", "DROP", "KEEP", "CALC", "ATTRCALC",
			"RENAME", "AS", "AND", "OR", "XOR", "NOT", "BETWEEN", "IN", "NOT_IN",
			"NULL_CONSTANT", "ISNULL", "EX", "UNION", "DIFF", "SYMDIFF", "INTERSECT",
			"KEYS", "INTYEAR", "INTMONTH", "INTDAY", "CHECK", "EXISTS_IN", "TO",
			"RETURN", "IMBALANCE", "ERRORCODE", "ALL", "AGGREGATE", "ERRORLEVEL",
			"ORDER", "BY", "RANK", "ASC", "DESC", "MIN", "MAX", "FIRST", "LAST",
			"INDEXOF", "ABS", "KEY", "LN", "LOG", "TRUNC", "ROUND", "POWER", "MOD",
			"LEN", "CONCAT", "TRIM", "UCASE", "LCASE", "SUBSTR", "SUM", "AVG", "MEDIAN",
			"COUNT", "DIMENSION", "MEASURE", "ATTRIBUTE", "FILTER", "MERGE", "EXP",
			"ROLE", "VIRAL", "CHARSET_MATCH", "TYPE", "NVL", "HIERARCHY", "OPTIONAL",
			"INVALID", "VALUE_DOMAIN", "VARIABLE", "DATA", "STRUCTURE", "DATASET",
			"OPERATOR", "DEFINE", "PUT_SYMBOL", "DATAPOINT", "HIERARCHICAL", "RULESET",
			"RULE", "END", "ALTER_DATASET", "LTRIM", "RTRIM", "INSTR", "REPLACE",
			"CEIL", "FLOOR", "SQRT", "ANY", "SETDIFF", "STDDEV_POP", "STDDEV_SAMP",
			"VAR_POP", "VAR_SAMP", "GROUP", "EXCEPT", "HAVING", "FIRST_VALUE", "LAST_VALUE",
			"LAG", "LEAD", "RATIO_TO_REPORT", "OVER", "PRECEDING", "FOLLOWING", "UNBOUNDED",
			"PARTITION", "ROWS", "RANGE", "CURRENT", "VALID", "FILL_TIME_SERIES",
			"FLOW_TO_STOCK", "STOCK_TO_FLOW", "TIMESHIFT", "MEASURES", "NO_MEASURES",
			"CONDITION", "BOOLEAN", "DATE", "TIME_PERIOD", "NUMBER", "STRING", "TIME",
			"INTEGER", "FLOAT", "LIST", "RECORD", "RESTRICT", "YYYY", "MM", "DD",
			"MAX_LENGTH", "REGEXP", "IS", "WHEN", "FROM", "AGGREGATES", "POINTS",
			"POINT", "TOTAL", "PARTIAL", "ALWAYS", "INNER_JOIN", "LEFT_JOIN", "CROSS_JOIN",
			"FULL_JOIN", "MAPS_FROM", "MAPS_TO", "MAP_TO", "MAP_FROM", "RETURNS",
			"PIVOT", "CUSTOMPIVOT", "UNPIVOT", "SUBSPACE", "APPLY", "CONDITIONED",
			"PERIOD_INDICATOR", "SINGLE", "DURATION", "TIME_AGG", "UNIT", "VALUE",
			"VALUEDOMAINS", "VARIABLES", "INPUT", "OUTPUT", "CAST", "RULE_PRIORITY",
			"DATASET_PRIORITY", "DEFAULT", "CHECK_DATAPOINT", "CHECK_HIERARCHY",
			"COMPUTED", "NON_NULL", "NON_ZERO", "PARTIAL_NULL", "PARTIAL_ZERO", "ALWAYS_NULL",
			"ALWAYS_ZERO", "COMPONENTS", "ALL_MEASURES", "SCALAR", "COMPONENT", "DATAPOINT_ON_VD",
			"DATAPOINT_ON_VAR", "HIERARCHICAL_ON_VD", "HIERARCHICAL_ON_VAR", "SET",
			"LANGUAGE", "INTEGER_CONSTANT", "NUMBER_CONSTANT", "BOOLEAN_CONSTANT",
			"STRING_CONSTANT", "IDENTIFIER", "WS", "EOL", "ML_COMMENT", "SL_COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Vtl.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public VtlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StartContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(VtlParser.EOF, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public List<TerminalNode> EOL() { return getTokens(VtlParser.EOL); }
		public TerminalNode EOL(int i) {
			return getToken(VtlParser.EOL, i);
		}
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(225);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DEFINE || _la==IDENTIFIER) {
				{
				{
				setState(220);
				statement();
				setState(221);
				match(EOL);
				}
				}
				setState(227);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(228);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementContext extends ParserRuleContext {
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
	 
		public StatementContext() { }
		public void copyFrom(StatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DefineExpressionContext extends StatementContext {
		public DefOperatorsContext defOperators() {
			return getRuleContext(DefOperatorsContext.class,0);
		}
		public DefineExpressionContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDefineExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDefineExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDefineExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TemporaryAssignmentContext extends StatementContext {
		public VarIDContext varID() {
			return getRuleContext(VarIDContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(VtlParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TemporaryAssignmentContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTemporaryAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTemporaryAssignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTemporaryAssignment(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PersistAssignmentContext extends StatementContext {
		public VarIDContext varID() {
			return getRuleContext(VarIDContext.class,0);
		}
		public TerminalNode PUT_SYMBOL() { return getToken(VtlParser.PUT_SYMBOL, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PersistAssignmentContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterPersistAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitPersistAssignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitPersistAssignment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_statement);
		try {
			setState(239);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				_localctx = new TemporaryAssignmentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(230);
				varID();
				setState(231);
				match(ASSIGN);
				setState(232);
				expr(0);
				}
				break;
			case 2:
				_localctx = new PersistAssignmentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(234);
				varID();
				setState(235);
				match(PUT_SYMBOL);
				setState(236);
				expr(0);
				}
				break;
			case 3:
				_localctx = new DefineExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(238);
				defOperators();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VarIdExprContext extends ExprContext {
		public VarIDContext varID() {
			return getRuleContext(VarIDContext.class,0);
		}
		public VarIdExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterVarIdExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitVarIdExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitVarIdExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MembershipExprContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode MEMBERSHIP() { return getToken(VtlParser.MEMBERSHIP, 0); }
		public SimpleComponentIdContext simpleComponentId() {
			return getRuleContext(SimpleComponentIdContext.class,0);
		}
		public MembershipExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterMembershipExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitMembershipExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitMembershipExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InNotInExprContext extends ExprContext {
		public ExprContext left;
		public Token op;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode IN() { return getToken(VtlParser.IN, 0); }
		public TerminalNode NOT_IN() { return getToken(VtlParser.NOT_IN, 0); }
		public ListsContext lists() {
			return getRuleContext(ListsContext.class,0);
		}
		public ValueDomainIDContext valueDomainID() {
			return getRuleContext(ValueDomainIDContext.class,0);
		}
		public InNotInExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInNotInExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInNotInExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInNotInExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BooleanExprContext extends ExprContext {
		public ExprContext left;
		public Token op;
		public ExprContext right;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode AND() { return getToken(VtlParser.AND, 0); }
		public TerminalNode OR() { return getToken(VtlParser.OR, 0); }
		public TerminalNode XOR() { return getToken(VtlParser.XOR, 0); }
		public BooleanExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBooleanExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBooleanExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBooleanExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonExprContext extends ExprContext {
		public ExprContext left;
		public ComparisonOperandContext op;
		public ExprContext right;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ComparisonOperandContext comparisonOperand() {
			return getRuleContext(ComparisonOperandContext.class,0);
		}
		public ComparisonExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComparisonExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComparisonExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComparisonExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryExprContext extends ExprContext {
		public Token op;
		public ExprContext right;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(VtlParser.MINUS, 0); }
		public TerminalNode NOT() { return getToken(VtlParser.NOT, 0); }
		public UnaryExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FunctionsExpressionContext extends ExprContext {
		public FunctionsContext functions() {
			return getRuleContext(FunctionsContext.class,0);
		}
		public FunctionsExpressionContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFunctionsExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFunctionsExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFunctionsExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IfExprContext extends ExprContext {
		public ExprContext conditionalExpr;
		public ExprContext thenExpr;
		public ExprContext elseExpr;
		public TerminalNode IF() { return getToken(VtlParser.IF, 0); }
		public TerminalNode THEN() { return getToken(VtlParser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(VtlParser.ELSE, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public IfExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterIfExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitIfExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitIfExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ClauseExprContext extends ExprContext {
		public ExprContext dataset;
		public DatasetClauseContext clause;
		public TerminalNode QLPAREN() { return getToken(VtlParser.QLPAREN, 0); }
		public TerminalNode QRPAREN() { return getToken(VtlParser.QRPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public DatasetClauseContext datasetClause() {
			return getRuleContext(DatasetClauseContext.class,0);
		}
		public ClauseExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterClauseExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitClauseExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitClauseExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticExprContext extends ExprContext {
		public ExprContext left;
		public Token op;
		public ExprContext right;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MUL() { return getToken(VtlParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(VtlParser.DIV, 0); }
		public ArithmeticExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterArithmeticExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitArithmeticExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitArithmeticExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParenthesisExprContext extends ExprContext {
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ParenthesisExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterParenthesisExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitParenthesisExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitParenthesisExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ConstantExprContext extends ExprContext {
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public ConstantExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConstantExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConstantExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConstantExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticExprOrConcatContext extends ExprContext {
		public ExprContext left;
		public Token op;
		public ExprContext right;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(VtlParser.MINUS, 0); }
		public TerminalNode CONCAT() { return getToken(VtlParser.CONCAT, 0); }
		public ArithmeticExprOrConcatContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterArithmeticExprOrConcat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitArithmeticExprOrConcat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitArithmeticExprOrConcat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 4;
		enterRecursionRule(_localctx, 4, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(258);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				{
				_localctx = new ParenthesisExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(242);
				match(LPAREN);
				setState(243);
				expr(0);
				setState(244);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new FunctionsExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(246);
				functions();
				}
				break;
			case 3:
				{
				_localctx = new UnaryExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(247);
				((UnaryExprContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 549755838464L) != 0)) ) {
					((UnaryExprContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(248);
				((UnaryExprContext)_localctx).right = expr(10);
				}
				break;
			case 4:
				{
				_localctx = new IfExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(249);
				match(IF);
				setState(250);
				((IfExprContext)_localctx).conditionalExpr = expr(0);
				setState(251);
				match(THEN);
				setState(252);
				((IfExprContext)_localctx).thenExpr = expr(0);
				setState(253);
				match(ELSE);
				setState(254);
				((IfExprContext)_localctx).elseExpr = expr(3);
				}
				break;
			case 5:
				{
				_localctx = new ConstantExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(256);
				constant();
				}
				break;
			case 6:
				{
				_localctx = new VarIdExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(257);
				varID();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(292);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(290);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
					case 1:
						{
						_localctx = new ArithmeticExprContext(new ExprContext(_parentctx, _parentState));
						((ArithmeticExprContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(260);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(261);
						((ArithmeticExprContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==MUL || _la==DIV) ) {
							((ArithmeticExprContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(262);
						((ArithmeticExprContext)_localctx).right = expr(10);
						}
						break;
					case 2:
						{
						_localctx = new ArithmeticExprOrConcatContext(new ExprContext(_parentctx, _parentState));
						((ArithmeticExprOrConcatContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(263);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(264);
						((ArithmeticExprOrConcatContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS || _la==CONCAT) ) {
							((ArithmeticExprOrConcatContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(265);
						((ArithmeticExprOrConcatContext)_localctx).right = expr(9);
						}
						break;
					case 3:
						{
						_localctx = new ComparisonExprContext(new ExprContext(_parentctx, _parentState));
						((ComparisonExprContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(266);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(267);
						((ComparisonExprContext)_localctx).op = comparisonOperand();
						setState(268);
						((ComparisonExprContext)_localctx).right = expr(8);
						}
						break;
					case 4:
						{
						_localctx = new BooleanExprContext(new ExprContext(_parentctx, _parentState));
						((BooleanExprContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(270);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(271);
						((BooleanExprContext)_localctx).op = match(AND);
						setState(272);
						((BooleanExprContext)_localctx).right = expr(6);
						}
						break;
					case 5:
						{
						_localctx = new BooleanExprContext(new ExprContext(_parentctx, _parentState));
						((BooleanExprContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(273);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(274);
						((BooleanExprContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==OR || _la==XOR) ) {
							((BooleanExprContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(275);
						((BooleanExprContext)_localctx).right = expr(5);
						}
						break;
					case 6:
						{
						_localctx = new ClauseExprContext(new ExprContext(_parentctx, _parentState));
						((ClauseExprContext)_localctx).dataset = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(276);
						if (!(precpred(_ctx, 12))) throw new FailedPredicateException(this, "precpred(_ctx, 12)");
						setState(277);
						match(QLPAREN);
						setState(278);
						((ClauseExprContext)_localctx).clause = datasetClause();
						setState(279);
						match(QRPAREN);
						}
						break;
					case 7:
						{
						_localctx = new MembershipExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(281);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(282);
						match(MEMBERSHIP);
						setState(283);
						simpleComponentId();
						}
						break;
					case 8:
						{
						_localctx = new InNotInExprContext(new ExprContext(_parentctx, _parentState));
						((InNotInExprContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(284);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(285);
						((InNotInExprContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==IN || _la==NOT_IN) ) {
							((InNotInExprContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(288);
						_errHandler.sync(this);
						switch (_input.LA(1)) {
						case GLPAREN:
							{
							setState(286);
							lists();
							}
							break;
						case IDENTIFIER:
							{
							setState(287);
							valueDomainID();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						}
						break;
					}
					}
				}
				setState(294);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprComponentContext extends ParserRuleContext {
		public ExprComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exprComponent; }
	 
		public ExprComponentContext() { }
		public void copyFrom(ExprComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticExprCompContext extends ExprComponentContext {
		public ExprComponentContext left;
		public Token op;
		public ExprComponentContext right;
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public TerminalNode MUL() { return getToken(VtlParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(VtlParser.DIV, 0); }
		public ArithmeticExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterArithmeticExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitArithmeticExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitArithmeticExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IfExprCompContext extends ExprComponentContext {
		public ExprComponentContext conditionalExpr;
		public ExprComponentContext thenExpr;
		public ExprComponentContext elseExpr;
		public TerminalNode IF() { return getToken(VtlParser.IF, 0); }
		public TerminalNode THEN() { return getToken(VtlParser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(VtlParser.ELSE, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public IfExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterIfExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitIfExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitIfExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonExprCompContext extends ExprComponentContext {
		public ExprComponentContext left;
		public ExprComponentContext right;
		public ComparisonOperandContext comparisonOperand() {
			return getRuleContext(ComparisonOperandContext.class,0);
		}
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public ComparisonExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComparisonExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComparisonExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComparisonExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FunctionsExpressionCompContext extends ExprComponentContext {
		public FunctionsComponentsContext functionsComponents() {
			return getRuleContext(FunctionsComponentsContext.class,0);
		}
		public FunctionsExpressionCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFunctionsExpressionComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFunctionsExpressionComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFunctionsExpressionComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CompIdContext extends ExprComponentContext {
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public CompIdContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCompId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCompId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCompId(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ConstantExprCompContext extends ExprComponentContext {
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public ConstantExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConstantExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConstantExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConstantExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticExprOrConcatCompContext extends ExprComponentContext {
		public ExprComponentContext left;
		public Token op;
		public ExprComponentContext right;
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(VtlParser.MINUS, 0); }
		public TerminalNode CONCAT() { return getToken(VtlParser.CONCAT, 0); }
		public ArithmeticExprOrConcatCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterArithmeticExprOrConcatComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitArithmeticExprOrConcatComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitArithmeticExprOrConcatComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParenthesisExprCompContext extends ExprComponentContext {
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ParenthesisExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterParenthesisExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitParenthesisExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitParenthesisExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InNotInExprCompContext extends ExprComponentContext {
		public ExprComponentContext left;
		public Token op;
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode IN() { return getToken(VtlParser.IN, 0); }
		public TerminalNode NOT_IN() { return getToken(VtlParser.NOT_IN, 0); }
		public ListsContext lists() {
			return getRuleContext(ListsContext.class,0);
		}
		public ValueDomainIDContext valueDomainID() {
			return getRuleContext(ValueDomainIDContext.class,0);
		}
		public InNotInExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInNotInExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInNotInExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInNotInExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryExprCompContext extends ExprComponentContext {
		public Token op;
		public ExprComponentContext right;
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(VtlParser.MINUS, 0); }
		public TerminalNode NOT() { return getToken(VtlParser.NOT, 0); }
		public UnaryExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryExprComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BooleanExprCompContext extends ExprComponentContext {
		public ExprComponentContext left;
		public Token op;
		public ExprComponentContext right;
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public TerminalNode AND() { return getToken(VtlParser.AND, 0); }
		public TerminalNode OR() { return getToken(VtlParser.OR, 0); }
		public TerminalNode XOR() { return getToken(VtlParser.XOR, 0); }
		public BooleanExprCompContext(ExprComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBooleanExprComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBooleanExprComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBooleanExprComp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprComponentContext exprComponent() throws RecognitionException {
		return exprComponent(0);
	}

	private ExprComponentContext exprComponent(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprComponentContext _localctx = new ExprComponentContext(_ctx, _parentState);
		ExprComponentContext _prevctx = _localctx;
		int _startState = 6;
		enterRecursionRule(_localctx, 6, RULE_exprComponent, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(312);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				_localctx = new ParenthesisExprCompContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(296);
				match(LPAREN);
				setState(297);
				exprComponent(0);
				setState(298);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new FunctionsExpressionCompContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(300);
				functionsComponents();
				}
				break;
			case 3:
				{
				_localctx = new UnaryExprCompContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(301);
				((UnaryExprCompContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 549755838464L) != 0)) ) {
					((UnaryExprCompContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(302);
				((UnaryExprCompContext)_localctx).right = exprComponent(10);
				}
				break;
			case 4:
				{
				_localctx = new IfExprCompContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(303);
				match(IF);
				setState(304);
				((IfExprCompContext)_localctx).conditionalExpr = exprComponent(0);
				setState(305);
				match(THEN);
				setState(306);
				((IfExprCompContext)_localctx).thenExpr = exprComponent(0);
				setState(307);
				match(ELSE);
				setState(308);
				((IfExprCompContext)_localctx).elseExpr = exprComponent(3);
				}
				break;
			case 5:
				{
				_localctx = new ConstantExprCompContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(310);
				constant();
				}
				break;
			case 6:
				{
				_localctx = new CompIdContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(311);
				componentID();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(338);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(336);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
					case 1:
						{
						_localctx = new ArithmeticExprCompContext(new ExprComponentContext(_parentctx, _parentState));
						((ArithmeticExprCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(314);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(315);
						((ArithmeticExprCompContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==MUL || _la==DIV) ) {
							((ArithmeticExprCompContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(316);
						((ArithmeticExprCompContext)_localctx).right = exprComponent(10);
						}
						break;
					case 2:
						{
						_localctx = new ArithmeticExprOrConcatCompContext(new ExprComponentContext(_parentctx, _parentState));
						((ArithmeticExprOrConcatCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(317);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(318);
						((ArithmeticExprOrConcatCompContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS || _la==CONCAT) ) {
							((ArithmeticExprOrConcatCompContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(319);
						((ArithmeticExprOrConcatCompContext)_localctx).right = exprComponent(9);
						}
						break;
					case 3:
						{
						_localctx = new ComparisonExprCompContext(new ExprComponentContext(_parentctx, _parentState));
						((ComparisonExprCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(320);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(321);
						comparisonOperand();
						setState(322);
						((ComparisonExprCompContext)_localctx).right = exprComponent(8);
						}
						break;
					case 4:
						{
						_localctx = new BooleanExprCompContext(new ExprComponentContext(_parentctx, _parentState));
						((BooleanExprCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(324);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(325);
						((BooleanExprCompContext)_localctx).op = match(AND);
						setState(326);
						((BooleanExprCompContext)_localctx).right = exprComponent(6);
						}
						break;
					case 5:
						{
						_localctx = new BooleanExprCompContext(new ExprComponentContext(_parentctx, _parentState));
						((BooleanExprCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(327);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(328);
						((BooleanExprCompContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==OR || _la==XOR) ) {
							((BooleanExprCompContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(329);
						((BooleanExprCompContext)_localctx).right = exprComponent(5);
						}
						break;
					case 6:
						{
						_localctx = new InNotInExprCompContext(new ExprComponentContext(_parentctx, _parentState));
						((InNotInExprCompContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_exprComponent);
						setState(330);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(331);
						((InNotInExprCompContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==IN || _la==NOT_IN) ) {
							((InNotInExprCompContext)_localctx).op = _errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(334);
						_errHandler.sync(this);
						switch (_input.LA(1)) {
						case GLPAREN:
							{
							setState(332);
							lists();
							}
							break;
						case IDENTIFIER:
							{
							setState(333);
							valueDomainID();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						}
						break;
					}
					}
				}
				setState(340);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionsComponentsContext extends ParserRuleContext {
		public FunctionsComponentsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionsComponents; }
	 
		public FunctionsComponentsContext() { }
		public void copyFrom(FunctionsComponentsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NumericFunctionsComponentsContext extends FunctionsComponentsContext {
		public NumericOperatorsComponentContext numericOperatorsComponent() {
			return getRuleContext(NumericOperatorsComponentContext.class,0);
		}
		public NumericFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterNumericFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitNumericFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitNumericFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringFunctionsComponentsContext extends FunctionsComponentsContext {
		public StringOperatorsComponentContext stringOperatorsComponent() {
			return getRuleContext(StringOperatorsComponentContext.class,0);
		}
		public StringFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterStringFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitStringFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitStringFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonFunctionsComponentsContext extends FunctionsComponentsContext {
		public ComparisonOperatorsComponentContext comparisonOperatorsComponent() {
			return getRuleContext(ComparisonOperatorsComponentContext.class,0);
		}
		public ComparisonFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComparisonFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComparisonFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComparisonFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeFunctionsComponentsContext extends FunctionsComponentsContext {
		public TimeOperatorsComponentContext timeOperatorsComponent() {
			return getRuleContext(TimeOperatorsComponentContext.class,0);
		}
		public TimeFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionsComponentsContext extends FunctionsComponentsContext {
		public GenericOperatorsComponentContext genericOperatorsComponent() {
			return getRuleContext(GenericOperatorsComponentContext.class,0);
		}
		public GenericFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterGenericFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitGenericFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitGenericFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnalyticFunctionsComponentsContext extends FunctionsComponentsContext {
		public AnFunctionComponentContext anFunctionComponent() {
			return getRuleContext(AnFunctionComponentContext.class,0);
		}
		public AnalyticFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAnalyticFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAnalyticFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAnalyticFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ConditionalFunctionsComponentsContext extends FunctionsComponentsContext {
		public ConditionalOperatorsComponentContext conditionalOperatorsComponent() {
			return getRuleContext(ConditionalOperatorsComponentContext.class,0);
		}
		public ConditionalFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConditionalFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConditionalFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConditionalFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionsComponentsContext extends FunctionsComponentsContext {
		public AggrOperatorsContext aggrOperators() {
			return getRuleContext(AggrOperatorsContext.class,0);
		}
		public AggregateFunctionsComponentsContext(FunctionsComponentsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggregateFunctionsComponents(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggregateFunctionsComponents(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggregateFunctionsComponents(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionsComponentsContext functionsComponents() throws RecognitionException {
		FunctionsComponentsContext _localctx = new FunctionsComponentsContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_functionsComponents);
		try {
			setState(349);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				_localctx = new GenericFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(341);
				genericOperatorsComponent();
				}
				break;
			case 2:
				_localctx = new StringFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(342);
				stringOperatorsComponent();
				}
				break;
			case 3:
				_localctx = new NumericFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(343);
				numericOperatorsComponent();
				}
				break;
			case 4:
				_localctx = new ComparisonFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(344);
				comparisonOperatorsComponent();
				}
				break;
			case 5:
				_localctx = new TimeFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(345);
				timeOperatorsComponent();
				}
				break;
			case 6:
				_localctx = new ConditionalFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(346);
				conditionalOperatorsComponent();
				}
				break;
			case 7:
				_localctx = new AggregateFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(347);
				aggrOperators();
				}
				break;
			case 8:
				_localctx = new AnalyticFunctionsComponentsContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(348);
				anFunctionComponent();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionsContext extends ParserRuleContext {
		public FunctionsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions; }
	 
		public FunctionsContext() { }
		public void copyFrom(FunctionsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HierarchyFunctionsContext extends FunctionsContext {
		public HierarchyOperatorsContext hierarchyOperators() {
			return getRuleContext(HierarchyOperatorsContext.class,0);
		}
		public HierarchyFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHierarchyFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHierarchyFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHierarchyFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringFunctionsContext extends FunctionsContext {
		public StringOperatorsContext stringOperators() {
			return getRuleContext(StringOperatorsContext.class,0);
		}
		public StringFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterStringFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitStringFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitStringFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ValidationFunctionsContext extends FunctionsContext {
		public ValidationOperatorsContext validationOperators() {
			return getRuleContext(ValidationOperatorsContext.class,0);
		}
		public ValidationFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidationFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidationFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidationFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionsContext extends FunctionsContext {
		public GenericOperatorsContext genericOperators() {
			return getRuleContext(GenericOperatorsContext.class,0);
		}
		public GenericFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterGenericFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitGenericFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitGenericFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ConditionalFunctionsContext extends FunctionsContext {
		public ConditionalOperatorsContext conditionalOperators() {
			return getRuleContext(ConditionalOperatorsContext.class,0);
		}
		public ConditionalFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConditionalFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConditionalFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConditionalFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionsContext extends FunctionsContext {
		public AggrOperatorsGroupingContext aggrOperatorsGrouping() {
			return getRuleContext(AggrOperatorsGroupingContext.class,0);
		}
		public AggregateFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggregateFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggregateFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggregateFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinFunctionsContext extends FunctionsContext {
		public JoinOperatorsContext joinOperators() {
			return getRuleContext(JoinOperatorsContext.class,0);
		}
		public JoinFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonFunctionsContext extends FunctionsContext {
		public ComparisonOperatorsContext comparisonOperators() {
			return getRuleContext(ComparisonOperatorsContext.class,0);
		}
		public ComparisonFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComparisonFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComparisonFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComparisonFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NumericFunctionsContext extends FunctionsContext {
		public NumericOperatorsContext numericOperators() {
			return getRuleContext(NumericOperatorsContext.class,0);
		}
		public NumericFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterNumericFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitNumericFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitNumericFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeFunctionsContext extends FunctionsContext {
		public TimeOperatorsContext timeOperators() {
			return getRuleContext(TimeOperatorsContext.class,0);
		}
		public TimeFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SetFunctionsContext extends FunctionsContext {
		public SetOperatorsContext setOperators() {
			return getRuleContext(SetOperatorsContext.class,0);
		}
		public SetFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSetFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSetFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSetFunctions(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnalyticFunctionsContext extends FunctionsContext {
		public AnFunctionContext anFunction() {
			return getRuleContext(AnFunctionContext.class,0);
		}
		public AnalyticFunctionsContext(FunctionsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAnalyticFunctions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAnalyticFunctions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAnalyticFunctions(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionsContext functions() throws RecognitionException {
		FunctionsContext _localctx = new FunctionsContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_functions);
		try {
			setState(363);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				_localctx = new JoinFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(351);
				joinOperators();
				}
				break;
			case 2:
				_localctx = new GenericFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(352);
				genericOperators();
				}
				break;
			case 3:
				_localctx = new StringFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(353);
				stringOperators();
				}
				break;
			case 4:
				_localctx = new NumericFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(354);
				numericOperators();
				}
				break;
			case 5:
				_localctx = new ComparisonFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(355);
				comparisonOperators();
				}
				break;
			case 6:
				_localctx = new TimeFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(356);
				timeOperators();
				}
				break;
			case 7:
				_localctx = new SetFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(357);
				setOperators();
				}
				break;
			case 8:
				_localctx = new HierarchyFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(358);
				hierarchyOperators();
				}
				break;
			case 9:
				_localctx = new ValidationFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(359);
				validationOperators();
				}
				break;
			case 10:
				_localctx = new ConditionalFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(360);
				conditionalOperators();
				}
				break;
			case 11:
				_localctx = new AggregateFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(361);
				aggrOperatorsGrouping();
				}
				break;
			case 12:
				_localctx = new AnalyticFunctionsContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(362);
				anFunction();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DatasetClauseContext extends ParserRuleContext {
		public RenameClauseContext renameClause() {
			return getRuleContext(RenameClauseContext.class,0);
		}
		public AggrClauseContext aggrClause() {
			return getRuleContext(AggrClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public CalcClauseContext calcClause() {
			return getRuleContext(CalcClauseContext.class,0);
		}
		public KeepOrDropClauseContext keepOrDropClause() {
			return getRuleContext(KeepOrDropClauseContext.class,0);
		}
		public PivotOrUnpivotClauseContext pivotOrUnpivotClause() {
			return getRuleContext(PivotOrUnpivotClauseContext.class,0);
		}
		public SubspaceClauseContext subspaceClause() {
			return getRuleContext(SubspaceClauseContext.class,0);
		}
		public DatasetClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datasetClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDatasetClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDatasetClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDatasetClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DatasetClauseContext datasetClause() throws RecognitionException {
		DatasetClauseContext _localctx = new DatasetClauseContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_datasetClause);
		try {
			setState(372);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RENAME:
				enterOuterAlt(_localctx, 1);
				{
				setState(365);
				renameClause();
				}
				break;
			case AGGREGATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(366);
				aggrClause();
				}
				break;
			case FILTER:
				enterOuterAlt(_localctx, 3);
				{
				setState(367);
				filterClause();
				}
				break;
			case CALC:
				enterOuterAlt(_localctx, 4);
				{
				setState(368);
				calcClause();
				}
				break;
			case DROP:
			case KEEP:
				enterOuterAlt(_localctx, 5);
				{
				setState(369);
				keepOrDropClause();
				}
				break;
			case PIVOT:
			case UNPIVOT:
				enterOuterAlt(_localctx, 6);
				{
				setState(370);
				pivotOrUnpivotClause();
				}
				break;
			case SUBSPACE:
				enterOuterAlt(_localctx, 7);
				{
				setState(371);
				subspaceClause();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RenameClauseContext extends ParserRuleContext {
		public TerminalNode RENAME() { return getToken(VtlParser.RENAME, 0); }
		public List<RenameClauseItemContext> renameClauseItem() {
			return getRuleContexts(RenameClauseItemContext.class);
		}
		public RenameClauseItemContext renameClauseItem(int i) {
			return getRuleContext(RenameClauseItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public RenameClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_renameClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRenameClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRenameClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRenameClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RenameClauseContext renameClause() throws RecognitionException {
		RenameClauseContext _localctx = new RenameClauseContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_renameClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(374);
			match(RENAME);
			setState(375);
			renameClauseItem();
			setState(380);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(376);
				match(COMMA);
				setState(377);
				renameClauseItem();
				}
				}
				setState(382);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggrClauseContext extends ParserRuleContext {
		public TerminalNode AGGREGATE() { return getToken(VtlParser.AGGREGATE, 0); }
		public AggregateClauseContext aggregateClause() {
			return getRuleContext(AggregateClauseContext.class,0);
		}
		public GroupingClauseContext groupingClause() {
			return getRuleContext(GroupingClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public AggrClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggrClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggrClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggrClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggrClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggrClauseContext aggrClause() throws RecognitionException {
		AggrClauseContext _localctx = new AggrClauseContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_aggrClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(383);
			match(AGGREGATE);
			setState(384);
			aggregateClause();
			setState(389);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUP) {
				{
				setState(385);
				groupingClause();
				setState(387);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(386);
					havingClause();
					}
				}

				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FilterClauseContext extends ParserRuleContext {
		public TerminalNode FILTER() { return getToken(VtlParser.FILTER, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public FilterClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_filterClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFilterClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFilterClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFilterClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FilterClauseContext filterClause() throws RecognitionException {
		FilterClauseContext _localctx = new FilterClauseContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_filterClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(391);
			match(FILTER);
			setState(392);
			exprComponent(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CalcClauseContext extends ParserRuleContext {
		public TerminalNode CALC() { return getToken(VtlParser.CALC, 0); }
		public List<CalcClauseItemContext> calcClauseItem() {
			return getRuleContexts(CalcClauseItemContext.class);
		}
		public CalcClauseItemContext calcClauseItem(int i) {
			return getRuleContext(CalcClauseItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public CalcClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_calcClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCalcClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCalcClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCalcClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CalcClauseContext calcClause() throws RecognitionException {
		CalcClauseContext _localctx = new CalcClauseContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_calcClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(394);
			match(CALC);
			setState(395);
			calcClauseItem();
			setState(400);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(396);
				match(COMMA);
				setState(397);
				calcClauseItem();
				}
				}
				setState(402);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class KeepOrDropClauseContext extends ParserRuleContext {
		public Token op;
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public TerminalNode KEEP() { return getToken(VtlParser.KEEP, 0); }
		public TerminalNode DROP() { return getToken(VtlParser.DROP, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public KeepOrDropClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keepOrDropClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterKeepOrDropClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitKeepOrDropClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitKeepOrDropClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final KeepOrDropClauseContext keepOrDropClause() throws RecognitionException {
		KeepOrDropClauseContext _localctx = new KeepOrDropClauseContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_keepOrDropClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(403);
			_localctx.op = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==DROP || _la==KEEP) ) {
				_localctx.op = _errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(404);
			componentID();
			setState(409);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(405);
				match(COMMA);
				setState(406);
				componentID();
				}
				}
				setState(411);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PivotOrUnpivotClauseContext extends ParserRuleContext {
		public Token op;
		public ComponentIDContext id_;
		public ComponentIDContext mea;
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public TerminalNode PIVOT() { return getToken(VtlParser.PIVOT, 0); }
		public TerminalNode UNPIVOT() { return getToken(VtlParser.UNPIVOT, 0); }
		public PivotOrUnpivotClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pivotOrUnpivotClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterPivotOrUnpivotClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitPivotOrUnpivotClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitPivotOrUnpivotClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PivotOrUnpivotClauseContext pivotOrUnpivotClause() throws RecognitionException {
		PivotOrUnpivotClauseContext _localctx = new PivotOrUnpivotClauseContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_pivotOrUnpivotClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(412);
			_localctx.op = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==PIVOT || _la==UNPIVOT) ) {
				_localctx.op = _errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(413);
			_localctx.id_ = componentID();
			setState(414);
			match(COMMA);
			setState(415);
			_localctx.mea = componentID();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CustomPivotClauseContext extends ParserRuleContext {
		public ComponentIDContext id_;
		public ComponentIDContext mea;
		public TerminalNode CUSTOMPIVOT() { return getToken(VtlParser.CUSTOMPIVOT, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode IN() { return getToken(VtlParser.IN, 0); }
		public List<ConstantContext> constant() {
			return getRuleContexts(ConstantContext.class);
		}
		public ConstantContext constant(int i) {
			return getRuleContext(ConstantContext.class,i);
		}
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public CustomPivotClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_customPivotClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCustomPivotClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCustomPivotClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCustomPivotClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CustomPivotClauseContext customPivotClause() throws RecognitionException {
		CustomPivotClauseContext _localctx = new CustomPivotClauseContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_customPivotClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(417);
			match(CUSTOMPIVOT);
			setState(418);
			_localctx.id_ = componentID();
			setState(419);
			match(COMMA);
			setState(420);
			_localctx.mea = componentID();
			setState(421);
			match(IN);
			setState(422);
			constant();
			setState(427);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(423);
				match(COMMA);
				setState(424);
				constant();
				}
				}
				setState(429);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubspaceClauseContext extends ParserRuleContext {
		public TerminalNode SUBSPACE() { return getToken(VtlParser.SUBSPACE, 0); }
		public List<SubspaceClauseItemContext> subspaceClauseItem() {
			return getRuleContexts(SubspaceClauseItemContext.class);
		}
		public SubspaceClauseItemContext subspaceClauseItem(int i) {
			return getRuleContext(SubspaceClauseItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public SubspaceClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subspaceClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSubspaceClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSubspaceClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSubspaceClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubspaceClauseContext subspaceClause() throws RecognitionException {
		SubspaceClauseContext _localctx = new SubspaceClauseContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_subspaceClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(430);
			match(SUBSPACE);
			setState(431);
			subspaceClauseItem();
			setState(436);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(432);
				match(COMMA);
				setState(433);
				subspaceClauseItem();
				}
				}
				setState(438);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinOperatorsContext extends ParserRuleContext {
		public JoinOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinOperators; }
	 
		public JoinOperatorsContext() { }
		public void copyFrom(JoinOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinExprContext extends JoinOperatorsContext {
		public Token joinKeyword;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public JoinClauseContext joinClause() {
			return getRuleContext(JoinClauseContext.class,0);
		}
		public JoinBodyContext joinBody() {
			return getRuleContext(JoinBodyContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode INNER_JOIN() { return getToken(VtlParser.INNER_JOIN, 0); }
		public TerminalNode LEFT_JOIN() { return getToken(VtlParser.LEFT_JOIN, 0); }
		public JoinClauseWithoutUsingContext joinClauseWithoutUsing() {
			return getRuleContext(JoinClauseWithoutUsingContext.class,0);
		}
		public TerminalNode FULL_JOIN() { return getToken(VtlParser.FULL_JOIN, 0); }
		public TerminalNode CROSS_JOIN() { return getToken(VtlParser.CROSS_JOIN, 0); }
		public JoinExprContext(JoinOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinOperatorsContext joinOperators() throws RecognitionException {
		JoinOperatorsContext _localctx = new JoinOperatorsContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_joinOperators);
		int _la;
		try {
			setState(451);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INNER_JOIN:
			case LEFT_JOIN:
				_localctx = new JoinExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(439);
				((JoinExprContext)_localctx).joinKeyword = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==INNER_JOIN || _la==LEFT_JOIN) ) {
					((JoinExprContext)_localctx).joinKeyword = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(440);
				match(LPAREN);
				setState(441);
				joinClause();
				setState(442);
				joinBody();
				setState(443);
				match(RPAREN);
				}
				break;
			case CROSS_JOIN:
			case FULL_JOIN:
				_localctx = new JoinExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(445);
				((JoinExprContext)_localctx).joinKeyword = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==CROSS_JOIN || _la==FULL_JOIN) ) {
					((JoinExprContext)_localctx).joinKeyword = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(446);
				match(LPAREN);
				setState(447);
				joinClauseWithoutUsing();
				setState(448);
				joinBody();
				setState(449);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DefOperatorsContext extends ParserRuleContext {
		public DefOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_defOperators; }
	 
		public DefOperatorsContext() { }
		public void copyFrom(DefOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DefOperatorContext extends DefOperatorsContext {
		public TerminalNode DEFINE() { return getToken(VtlParser.DEFINE, 0); }
		public List<TerminalNode> OPERATOR() { return getTokens(VtlParser.OPERATOR); }
		public TerminalNode OPERATOR(int i) {
			return getToken(VtlParser.OPERATOR, i);
		}
		public OperatorIDContext operatorID() {
			return getRuleContext(OperatorIDContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode IS() { return getToken(VtlParser.IS, 0); }
		public TerminalNode END() { return getToken(VtlParser.END, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public List<ParameterItemContext> parameterItem() {
			return getRuleContexts(ParameterItemContext.class);
		}
		public ParameterItemContext parameterItem(int i) {
			return getRuleContext(ParameterItemContext.class,i);
		}
		public TerminalNode RETURNS() { return getToken(VtlParser.RETURNS, 0); }
		public OutputParameterTypeContext outputParameterType() {
			return getRuleContext(OutputParameterTypeContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public DefOperatorContext(DefOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDefOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDefOperator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDefOperator(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DefHierarchicalContext extends DefOperatorsContext {
		public TerminalNode DEFINE() { return getToken(VtlParser.DEFINE, 0); }
		public List<TerminalNode> HIERARCHICAL() { return getTokens(VtlParser.HIERARCHICAL); }
		public TerminalNode HIERARCHICAL(int i) {
			return getToken(VtlParser.HIERARCHICAL, i);
		}
		public List<TerminalNode> RULESET() { return getTokens(VtlParser.RULESET); }
		public TerminalNode RULESET(int i) {
			return getToken(VtlParser.RULESET, i);
		}
		public RulesetIDContext rulesetID() {
			return getRuleContext(RulesetIDContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public HierRuleSignatureContext hierRuleSignature() {
			return getRuleContext(HierRuleSignatureContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode IS() { return getToken(VtlParser.IS, 0); }
		public RuleClauseHierarchicalContext ruleClauseHierarchical() {
			return getRuleContext(RuleClauseHierarchicalContext.class,0);
		}
		public TerminalNode END() { return getToken(VtlParser.END, 0); }
		public DefHierarchicalContext(DefOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDefHierarchical(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDefHierarchical(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDefHierarchical(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DefDatapointRulesetContext extends DefOperatorsContext {
		public TerminalNode DEFINE() { return getToken(VtlParser.DEFINE, 0); }
		public List<TerminalNode> DATAPOINT() { return getTokens(VtlParser.DATAPOINT); }
		public TerminalNode DATAPOINT(int i) {
			return getToken(VtlParser.DATAPOINT, i);
		}
		public List<TerminalNode> RULESET() { return getTokens(VtlParser.RULESET); }
		public TerminalNode RULESET(int i) {
			return getToken(VtlParser.RULESET, i);
		}
		public RulesetIDContext rulesetID() {
			return getRuleContext(RulesetIDContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public RulesetSignatureContext rulesetSignature() {
			return getRuleContext(RulesetSignatureContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode IS() { return getToken(VtlParser.IS, 0); }
		public RuleClauseDatapointContext ruleClauseDatapoint() {
			return getRuleContext(RuleClauseDatapointContext.class,0);
		}
		public TerminalNode END() { return getToken(VtlParser.END, 0); }
		public DefDatapointRulesetContext(DefOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDefDatapointRuleset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDefDatapointRuleset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDefDatapointRuleset(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DefOperatorsContext defOperators() throws RecognitionException {
		DefOperatorsContext _localctx = new DefOperatorsContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_defOperators);
		int _la;
		try {
			setState(503);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
			case 1:
				_localctx = new DefOperatorContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(453);
				match(DEFINE);
				setState(454);
				match(OPERATOR);
				setState(455);
				operatorID();
				setState(456);
				match(LPAREN);
				setState(465);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==IDENTIFIER) {
					{
					setState(457);
					parameterItem();
					setState(462);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(458);
						match(COMMA);
						setState(459);
						parameterItem();
						}
						}
						setState(464);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(467);
				match(RPAREN);
				setState(470);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==RETURNS) {
					{
					setState(468);
					match(RETURNS);
					setState(469);
					outputParameterType();
					}
				}

				setState(472);
				match(IS);
				{
				setState(473);
				expr(0);
				}
				setState(474);
				match(END);
				setState(475);
				match(OPERATOR);
				}
				break;
			case 2:
				_localctx = new DefDatapointRulesetContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(477);
				match(DEFINE);
				setState(478);
				match(DATAPOINT);
				setState(479);
				match(RULESET);
				setState(480);
				rulesetID();
				setState(481);
				match(LPAREN);
				setState(482);
				rulesetSignature();
				setState(483);
				match(RPAREN);
				setState(484);
				match(IS);
				setState(485);
				ruleClauseDatapoint();
				setState(486);
				match(END);
				setState(487);
				match(DATAPOINT);
				setState(488);
				match(RULESET);
				}
				break;
			case 3:
				_localctx = new DefHierarchicalContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(490);
				match(DEFINE);
				setState(491);
				match(HIERARCHICAL);
				setState(492);
				match(RULESET);
				setState(493);
				rulesetID();
				setState(494);
				match(LPAREN);
				setState(495);
				hierRuleSignature();
				setState(496);
				match(RPAREN);
				setState(497);
				match(IS);
				setState(498);
				ruleClauseHierarchical();
				setState(499);
				match(END);
				setState(500);
				match(HIERARCHICAL);
				setState(501);
				match(RULESET);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericOperatorsContext extends ParserRuleContext {
		public GenericOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericOperators; }
	 
		public GenericOperatorsContext() { }
		public void copyFrom(GenericOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EvalAtomContext extends GenericOperatorsContext {
		public TerminalNode EVAL() { return getToken(VtlParser.EVAL, 0); }
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public RoutineNameContext routineName() {
			return getRuleContext(RoutineNameContext.class,0);
		}
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public List<VarIDContext> varID() {
			return getRuleContexts(VarIDContext.class);
		}
		public VarIDContext varID(int i) {
			return getRuleContext(VarIDContext.class,i);
		}
		public List<ScalarItemContext> scalarItem() {
			return getRuleContexts(ScalarItemContext.class);
		}
		public ScalarItemContext scalarItem(int i) {
			return getRuleContext(ScalarItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode LANGUAGE() { return getToken(VtlParser.LANGUAGE, 0); }
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public TerminalNode RETURNS() { return getToken(VtlParser.RETURNS, 0); }
		public EvalDatasetTypeContext evalDatasetType() {
			return getRuleContext(EvalDatasetTypeContext.class,0);
		}
		public EvalAtomContext(GenericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterEvalAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitEvalAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitEvalAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CastExprDatasetContext extends GenericOperatorsContext {
		public TerminalNode CAST() { return getToken(VtlParser.CAST, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public BasicScalarTypeContext basicScalarType() {
			return getRuleContext(BasicScalarTypeContext.class,0);
		}
		public ValueDomainNameContext valueDomainName() {
			return getRuleContext(ValueDomainNameContext.class,0);
		}
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public CastExprDatasetContext(GenericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCastExprDataset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCastExprDataset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCastExprDataset(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CallDatasetContext extends GenericOperatorsContext {
		public OperatorIDContext operatorID() {
			return getRuleContext(OperatorIDContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ParameterContext> parameter() {
			return getRuleContexts(ParameterContext.class);
		}
		public ParameterContext parameter(int i) {
			return getRuleContext(ParameterContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public CallDatasetContext(GenericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCallDataset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCallDataset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCallDataset(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericOperatorsContext genericOperators() throws RecognitionException {
		GenericOperatorsContext _localctx = new GenericOperatorsContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_genericOperators);
		int _la;
		try {
			setState(562);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				_localctx = new CallDatasetContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(505);
				operatorID();
				setState(506);
				match(LPAREN);
				setState(515);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 54986027030306818L) != 0) || ((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -290482113411563613L) != 0) || ((((_la - 135)) & ~0x3f) == 0 && ((1L << (_la - 135)) & 2306898540376604703L) != 0) || ((((_la - 199)) & ~0x3f) == 0 && ((1L << (_la - 199)) & 33286002817L) != 0)) {
					{
					setState(507);
					parameter();
					setState(512);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(508);
						match(COMMA);
						setState(509);
						parameter();
						}
						}
						setState(514);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(517);
				match(RPAREN);
				}
				break;
			case EVAL:
				_localctx = new EvalAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(519);
				match(EVAL);
				setState(520);
				match(LPAREN);
				setState(521);
				routineName();
				setState(522);
				match(LPAREN);
				setState(525);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case IDENTIFIER:
					{
					setState(523);
					varID();
					}
					break;
				case NULL_CONSTANT:
				case CAST:
				case INTEGER_CONSTANT:
				case NUMBER_CONSTANT:
				case BOOLEAN_CONSTANT:
				case STRING_CONSTANT:
					{
					setState(524);
					scalarItem();
					}
					break;
				case RPAREN:
				case COMMA:
					break;
				default:
					break;
				}
				setState(534);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(527);
					match(COMMA);
					setState(530);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case IDENTIFIER:
						{
						setState(528);
						varID();
						}
						break;
					case NULL_CONSTANT:
					case CAST:
					case INTEGER_CONSTANT:
					case NUMBER_CONSTANT:
					case BOOLEAN_CONSTANT:
					case STRING_CONSTANT:
						{
						setState(529);
						scalarItem();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					setState(536);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(537);
				match(RPAREN);
				setState(540);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LANGUAGE) {
					{
					setState(538);
					match(LANGUAGE);
					setState(539);
					match(STRING_CONSTANT);
					}
				}

				setState(544);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==RETURNS) {
					{
					setState(542);
					match(RETURNS);
					setState(543);
					evalDatasetType();
					}
				}

				setState(546);
				match(RPAREN);
				}
				break;
			case CAST:
				_localctx = new CastExprDatasetContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(548);
				match(CAST);
				setState(549);
				match(LPAREN);
				setState(550);
				expr(0);
				setState(551);
				match(COMMA);
				setState(554);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case BOOLEAN:
				case DATE:
				case TIME_PERIOD:
				case NUMBER:
				case STRING:
				case TIME:
				case INTEGER:
				case DURATION:
				case SCALAR:
					{
					setState(552);
					basicScalarType();
					}
					break;
				case IDENTIFIER:
					{
					setState(553);
					valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(558);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(556);
					match(COMMA);
					setState(557);
					match(STRING_CONSTANT);
					}
				}

				setState(560);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericOperatorsComponentContext extends ParserRuleContext {
		public GenericOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericOperatorsComponent; }
	 
		public GenericOperatorsComponentContext() { }
		public void copyFrom(GenericOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EvalAtomComponentContext extends GenericOperatorsComponentContext {
		public TerminalNode EVAL() { return getToken(VtlParser.EVAL, 0); }
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public RoutineNameContext routineName() {
			return getRuleContext(RoutineNameContext.class,0);
		}
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public List<ScalarItemContext> scalarItem() {
			return getRuleContexts(ScalarItemContext.class);
		}
		public ScalarItemContext scalarItem(int i) {
			return getRuleContext(ScalarItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode LANGUAGE() { return getToken(VtlParser.LANGUAGE, 0); }
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public TerminalNode RETURNS() { return getToken(VtlParser.RETURNS, 0); }
		public OutputParameterTypeComponentContext outputParameterTypeComponent() {
			return getRuleContext(OutputParameterTypeComponentContext.class,0);
		}
		public EvalAtomComponentContext(GenericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterEvalAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitEvalAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitEvalAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CastExprComponentContext extends GenericOperatorsComponentContext {
		public TerminalNode CAST() { return getToken(VtlParser.CAST, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public BasicScalarTypeContext basicScalarType() {
			return getRuleContext(BasicScalarTypeContext.class,0);
		}
		public ValueDomainNameContext valueDomainName() {
			return getRuleContext(ValueDomainNameContext.class,0);
		}
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public CastExprComponentContext(GenericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCastExprComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCastExprComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCastExprComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CallComponentContext extends GenericOperatorsComponentContext {
		public OperatorIDContext operatorID() {
			return getRuleContext(OperatorIDContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ParameterComponentContext> parameterComponent() {
			return getRuleContexts(ParameterComponentContext.class);
		}
		public ParameterComponentContext parameterComponent(int i) {
			return getRuleContext(ParameterComponentContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public CallComponentContext(GenericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCallComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCallComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCallComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericOperatorsComponentContext genericOperatorsComponent() throws RecognitionException {
		GenericOperatorsComponentContext _localctx = new GenericOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_genericOperatorsComponent);
		int _la;
		try {
			setState(621);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				_localctx = new CallComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(564);
				operatorID();
				setState(565);
				match(LPAREN);
				setState(574);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 28037827551234L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & -6935543063158850279L) != 0) || ((((_la - 129)) & ~0x3f) == 0 && ((1L << (_la - 129)) & 15730631L) != 0) || ((((_la - 196)) & ~0x3f) == 0 && ((1L << (_la - 196)) & 266287973385L) != 0)) {
					{
					setState(566);
					parameterComponent();
					setState(571);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(567);
						match(COMMA);
						setState(568);
						parameterComponent();
						}
						}
						setState(573);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(576);
				match(RPAREN);
				}
				break;
			case CAST:
				_localctx = new CastExprComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(578);
				match(CAST);
				setState(579);
				match(LPAREN);
				setState(580);
				exprComponent(0);
				setState(581);
				match(COMMA);
				setState(584);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case BOOLEAN:
				case DATE:
				case TIME_PERIOD:
				case NUMBER:
				case STRING:
				case TIME:
				case INTEGER:
				case DURATION:
				case SCALAR:
					{
					setState(582);
					basicScalarType();
					}
					break;
				case IDENTIFIER:
					{
					setState(583);
					valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(588);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(586);
					match(COMMA);
					setState(587);
					match(STRING_CONSTANT);
					}
				}

				setState(590);
				match(RPAREN);
				}
				break;
			case EVAL:
				_localctx = new EvalAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(592);
				match(EVAL);
				setState(593);
				match(LPAREN);
				setState(594);
				routineName();
				setState(595);
				match(LPAREN);
				setState(598);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case IDENTIFIER:
					{
					setState(596);
					componentID();
					}
					break;
				case NULL_CONSTANT:
				case CAST:
				case INTEGER_CONSTANT:
				case NUMBER_CONSTANT:
				case BOOLEAN_CONSTANT:
				case STRING_CONSTANT:
					{
					setState(597);
					scalarItem();
					}
					break;
				case RPAREN:
				case COMMA:
					break;
				default:
					break;
				}
				setState(607);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(600);
					match(COMMA);
					setState(603);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case IDENTIFIER:
						{
						setState(601);
						componentID();
						}
						break;
					case NULL_CONSTANT:
					case CAST:
					case INTEGER_CONSTANT:
					case NUMBER_CONSTANT:
					case BOOLEAN_CONSTANT:
					case STRING_CONSTANT:
						{
						setState(602);
						scalarItem();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					setState(609);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(610);
				match(RPAREN);
				setState(613);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LANGUAGE) {
					{
					setState(611);
					match(LANGUAGE);
					setState(612);
					match(STRING_CONSTANT);
					}
				}

				setState(617);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==RETURNS) {
					{
					setState(615);
					match(RETURNS);
					setState(616);
					outputParameterTypeComponent();
					}
				}

				setState(619);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterComponentContext extends ParserRuleContext {
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public ParameterComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterComponent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterParameterComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitParameterComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitParameterComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterComponentContext parameterComponent() throws RecognitionException {
		ParameterComponentContext _localctx = new ParameterComponentContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_parameterComponent);
		try {
			setState(625);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
			case PLUS:
			case MINUS:
			case EVAL:
			case IF:
			case CURRENT_DATE:
			case NOT:
			case BETWEEN:
			case NULL_CONSTANT:
			case ISNULL:
			case RANK:
			case MIN:
			case MAX:
			case ABS:
			case LN:
			case LOG:
			case TRUNC:
			case ROUND:
			case POWER:
			case MOD:
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case SUBSTR:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case EXP:
			case CHARSET_MATCH:
			case NVL:
			case LTRIM:
			case RTRIM:
			case INSTR:
			case REPLACE:
			case CEIL:
			case FLOOR:
			case SQRT:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
			case LAG:
			case LEAD:
			case RATIO_TO_REPORT:
			case FILL_TIME_SERIES:
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
			case TIMESHIFT:
			case PERIOD_INDICATOR:
			case TIME_AGG:
			case CAST:
			case INTEGER_CONSTANT:
			case NUMBER_CONSTANT:
			case BOOLEAN_CONSTANT:
			case STRING_CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(623);
				exprComponent(0);
				}
				break;
			case OPTIONAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(624);
				match(OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterParameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitParameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_parameter);
		try {
			setState(629);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
			case PLUS:
			case MINUS:
			case EVAL:
			case IF:
			case CURRENT_DATE:
			case NOT:
			case BETWEEN:
			case NULL_CONSTANT:
			case ISNULL:
			case UNION:
			case SYMDIFF:
			case INTERSECT:
			case CHECK:
			case EXISTS_IN:
			case MIN:
			case MAX:
			case ABS:
			case LN:
			case LOG:
			case TRUNC:
			case ROUND:
			case POWER:
			case MOD:
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case SUBSTR:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case EXP:
			case CHARSET_MATCH:
			case NVL:
			case HIERARCHY:
			case LTRIM:
			case RTRIM:
			case INSTR:
			case REPLACE:
			case CEIL:
			case FLOOR:
			case SQRT:
			case SETDIFF:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
			case LAG:
			case LEAD:
			case RATIO_TO_REPORT:
			case FILL_TIME_SERIES:
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
			case TIMESHIFT:
			case INNER_JOIN:
			case LEFT_JOIN:
			case CROSS_JOIN:
			case FULL_JOIN:
			case PERIOD_INDICATOR:
			case TIME_AGG:
			case CAST:
			case CHECK_DATAPOINT:
			case CHECK_HIERARCHY:
			case INTEGER_CONSTANT:
			case NUMBER_CONSTANT:
			case BOOLEAN_CONSTANT:
			case STRING_CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(627);
				expr(0);
				}
				break;
			case OPTIONAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(628);
				match(OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StringOperatorsContext extends ParserRuleContext {
		public StringOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringOperators; }
	 
		public StringOperatorsContext() { }
		public void copyFrom(StringOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InstrAtomContext extends StringOperatorsContext {
		public ExprContext pattern;
		public OptionalExprContext startParameter;
		public OptionalExprContext occurrenceParameter;
		public TerminalNode INSTR() { return getToken(VtlParser.INSTR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<OptionalExprContext> optionalExpr() {
			return getRuleContexts(OptionalExprContext.class);
		}
		public OptionalExprContext optionalExpr(int i) {
			return getRuleContext(OptionalExprContext.class,i);
		}
		public InstrAtomContext(StringOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInstrAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInstrAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInstrAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryStringFunctionContext extends StringOperatorsContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode TRIM() { return getToken(VtlParser.TRIM, 0); }
		public TerminalNode LTRIM() { return getToken(VtlParser.LTRIM, 0); }
		public TerminalNode RTRIM() { return getToken(VtlParser.RTRIM, 0); }
		public TerminalNode UCASE() { return getToken(VtlParser.UCASE, 0); }
		public TerminalNode LCASE() { return getToken(VtlParser.LCASE, 0); }
		public TerminalNode LEN() { return getToken(VtlParser.LEN, 0); }
		public UnaryStringFunctionContext(StringOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryStringFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryStringFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryStringFunction(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SubstrAtomContext extends StringOperatorsContext {
		public OptionalExprContext startParameter;
		public OptionalExprContext endParameter;
		public TerminalNode SUBSTR() { return getToken(VtlParser.SUBSTR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public List<OptionalExprContext> optionalExpr() {
			return getRuleContexts(OptionalExprContext.class);
		}
		public OptionalExprContext optionalExpr(int i) {
			return getRuleContext(OptionalExprContext.class,i);
		}
		public SubstrAtomContext(StringOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSubstrAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSubstrAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSubstrAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ReplaceAtomContext extends StringOperatorsContext {
		public ExprContext param;
		public TerminalNode REPLACE() { return getToken(VtlParser.REPLACE, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public OptionalExprContext optionalExpr() {
			return getRuleContext(OptionalExprContext.class,0);
		}
		public ReplaceAtomContext(StringOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterReplaceAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitReplaceAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitReplaceAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringOperatorsContext stringOperators() throws RecognitionException {
		StringOperatorsContext _localctx = new StringOperatorsContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_stringOperators);
		int _la;
		try {
			setState(679);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case LTRIM:
			case RTRIM:
				_localctx = new UnaryStringFunctionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(631);
				((UnaryStringFunctionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 81)) & ~0x3f) == 0 && ((1L << (_la - 81)) & 824633720861L) != 0)) ) {
					((UnaryStringFunctionContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(632);
				match(LPAREN);
				setState(633);
				expr(0);
				setState(634);
				match(RPAREN);
				}
				break;
			case SUBSTR:
				_localctx = new SubstrAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(636);
				match(SUBSTR);
				setState(637);
				match(LPAREN);
				setState(638);
				expr(0);
				setState(649);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,48,_ctx) ) {
				case 1:
					{
					setState(645);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==COMMA) {
						{
						{
						setState(639);
						match(COMMA);
						setState(640);
						((SubstrAtomContext)_localctx).startParameter = optionalExpr();
						}
						{
						setState(642);
						match(COMMA);
						setState(643);
						((SubstrAtomContext)_localctx).endParameter = optionalExpr();
						}
						}
					}

					}
					break;
				case 2:
					{
					setState(647);
					match(COMMA);
					setState(648);
					((SubstrAtomContext)_localctx).startParameter = optionalExpr();
					}
					break;
				}
				setState(651);
				match(RPAREN);
				}
				break;
			case REPLACE:
				_localctx = new ReplaceAtomContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(653);
				match(REPLACE);
				setState(654);
				match(LPAREN);
				setState(655);
				expr(0);
				setState(656);
				match(COMMA);
				setState(657);
				((ReplaceAtomContext)_localctx).param = expr(0);
				setState(660);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(658);
					match(COMMA);
					setState(659);
					optionalExpr();
					}
				}

				setState(662);
				match(RPAREN);
				}
				break;
			case INSTR:
				_localctx = new InstrAtomContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(664);
				match(INSTR);
				setState(665);
				match(LPAREN);
				setState(666);
				expr(0);
				setState(667);
				match(COMMA);
				setState(668);
				((InstrAtomContext)_localctx).pattern = expr(0);
				setState(671);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
				case 1:
					{
					setState(669);
					match(COMMA);
					setState(670);
					((InstrAtomContext)_localctx).startParameter = optionalExpr();
					}
					break;
				}
				setState(675);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(673);
					match(COMMA);
					setState(674);
					((InstrAtomContext)_localctx).occurrenceParameter = optionalExpr();
					}
				}

				setState(677);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StringOperatorsComponentContext extends ParserRuleContext {
		public StringOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringOperatorsComponent; }
	 
		public StringOperatorsComponentContext() { }
		public void copyFrom(StringOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ReplaceAtomComponentContext extends StringOperatorsComponentContext {
		public ExprComponentContext param;
		public TerminalNode REPLACE() { return getToken(VtlParser.REPLACE, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public OptionalExprComponentContext optionalExprComponent() {
			return getRuleContext(OptionalExprComponentContext.class,0);
		}
		public ReplaceAtomComponentContext(StringOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterReplaceAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitReplaceAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitReplaceAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryStringFunctionComponentContext extends StringOperatorsComponentContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode TRIM() { return getToken(VtlParser.TRIM, 0); }
		public TerminalNode LTRIM() { return getToken(VtlParser.LTRIM, 0); }
		public TerminalNode RTRIM() { return getToken(VtlParser.RTRIM, 0); }
		public TerminalNode UCASE() { return getToken(VtlParser.UCASE, 0); }
		public TerminalNode LCASE() { return getToken(VtlParser.LCASE, 0); }
		public TerminalNode LEN() { return getToken(VtlParser.LEN, 0); }
		public UnaryStringFunctionComponentContext(StringOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryStringFunctionComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryStringFunctionComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryStringFunctionComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SubstrAtomComponentContext extends StringOperatorsComponentContext {
		public OptionalExprComponentContext startParameter;
		public OptionalExprComponentContext endParameter;
		public TerminalNode SUBSTR() { return getToken(VtlParser.SUBSTR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public List<OptionalExprComponentContext> optionalExprComponent() {
			return getRuleContexts(OptionalExprComponentContext.class);
		}
		public OptionalExprComponentContext optionalExprComponent(int i) {
			return getRuleContext(OptionalExprComponentContext.class,i);
		}
		public SubstrAtomComponentContext(StringOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSubstrAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSubstrAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSubstrAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InstrAtomComponentContext extends StringOperatorsComponentContext {
		public ExprComponentContext pattern;
		public OptionalExprComponentContext startParameter;
		public OptionalExprComponentContext occurrenceParameter;
		public TerminalNode INSTR() { return getToken(VtlParser.INSTR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<OptionalExprComponentContext> optionalExprComponent() {
			return getRuleContexts(OptionalExprComponentContext.class);
		}
		public OptionalExprComponentContext optionalExprComponent(int i) {
			return getRuleContext(OptionalExprComponentContext.class,i);
		}
		public InstrAtomComponentContext(StringOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInstrAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInstrAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInstrAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringOperatorsComponentContext stringOperatorsComponent() throws RecognitionException {
		StringOperatorsComponentContext _localctx = new StringOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_stringOperatorsComponent);
		int _la;
		try {
			setState(729);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case LTRIM:
			case RTRIM:
				_localctx = new UnaryStringFunctionComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(681);
				((UnaryStringFunctionComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 81)) & ~0x3f) == 0 && ((1L << (_la - 81)) & 824633720861L) != 0)) ) {
					((UnaryStringFunctionComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(682);
				match(LPAREN);
				setState(683);
				exprComponent(0);
				setState(684);
				match(RPAREN);
				}
				break;
			case SUBSTR:
				_localctx = new SubstrAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(686);
				match(SUBSTR);
				setState(687);
				match(LPAREN);
				setState(688);
				exprComponent(0);
				setState(699);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,54,_ctx) ) {
				case 1:
					{
					setState(695);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==COMMA) {
						{
						{
						setState(689);
						match(COMMA);
						setState(690);
						((SubstrAtomComponentContext)_localctx).startParameter = optionalExprComponent();
						}
						{
						setState(692);
						match(COMMA);
						setState(693);
						((SubstrAtomComponentContext)_localctx).endParameter = optionalExprComponent();
						}
						}
					}

					}
					break;
				case 2:
					{
					setState(697);
					match(COMMA);
					setState(698);
					((SubstrAtomComponentContext)_localctx).startParameter = optionalExprComponent();
					}
					break;
				}
				setState(701);
				match(RPAREN);
				}
				break;
			case REPLACE:
				_localctx = new ReplaceAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(703);
				match(REPLACE);
				setState(704);
				match(LPAREN);
				setState(705);
				exprComponent(0);
				setState(706);
				match(COMMA);
				setState(707);
				((ReplaceAtomComponentContext)_localctx).param = exprComponent(0);
				setState(710);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(708);
					match(COMMA);
					setState(709);
					optionalExprComponent();
					}
				}

				setState(712);
				match(RPAREN);
				}
				break;
			case INSTR:
				_localctx = new InstrAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(714);
				match(INSTR);
				setState(715);
				match(LPAREN);
				setState(716);
				exprComponent(0);
				setState(717);
				match(COMMA);
				setState(718);
				((InstrAtomComponentContext)_localctx).pattern = exprComponent(0);
				setState(721);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,56,_ctx) ) {
				case 1:
					{
					setState(719);
					match(COMMA);
					setState(720);
					((InstrAtomComponentContext)_localctx).startParameter = optionalExprComponent();
					}
					break;
				}
				setState(725);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(723);
					match(COMMA);
					setState(724);
					((InstrAtomComponentContext)_localctx).occurrenceParameter = optionalExprComponent();
					}
				}

				setState(727);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericOperatorsContext extends ParserRuleContext {
		public NumericOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericOperators; }
	 
		public NumericOperatorsContext() { }
		public void copyFrom(NumericOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryNumericContext extends NumericOperatorsContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode CEIL() { return getToken(VtlParser.CEIL, 0); }
		public TerminalNode FLOOR() { return getToken(VtlParser.FLOOR, 0); }
		public TerminalNode ABS() { return getToken(VtlParser.ABS, 0); }
		public TerminalNode EXP() { return getToken(VtlParser.EXP, 0); }
		public TerminalNode LN() { return getToken(VtlParser.LN, 0); }
		public TerminalNode SQRT() { return getToken(VtlParser.SQRT, 0); }
		public UnaryNumericContext(NumericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryNumeric(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryNumeric(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryNumeric(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryWithOptionalNumericContext extends NumericOperatorsContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode ROUND() { return getToken(VtlParser.ROUND, 0); }
		public TerminalNode TRUNC() { return getToken(VtlParser.TRUNC, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public OptionalExprContext optionalExpr() {
			return getRuleContext(OptionalExprContext.class,0);
		}
		public UnaryWithOptionalNumericContext(NumericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryWithOptionalNumeric(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryWithOptionalNumeric(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryWithOptionalNumeric(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BinaryNumericContext extends NumericOperatorsContext {
		public Token op;
		public ExprContext left;
		public ExprContext right;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MOD() { return getToken(VtlParser.MOD, 0); }
		public TerminalNode POWER() { return getToken(VtlParser.POWER, 0); }
		public TerminalNode LOG() { return getToken(VtlParser.LOG, 0); }
		public BinaryNumericContext(NumericOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBinaryNumeric(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBinaryNumeric(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBinaryNumeric(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericOperatorsContext numericOperators() throws RecognitionException {
		NumericOperatorsContext _localctx = new NumericOperatorsContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_numericOperators);
		int _la;
		try {
			setState(752);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ABS:
			case LN:
			case EXP:
			case CEIL:
			case FLOOR:
			case SQRT:
				_localctx = new UnaryNumericContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(731);
				((UnaryNumericContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 73)) & ~0x3f) == 0 && ((1L << (_la - 73)) & 7881299356286981L) != 0)) ) {
					((UnaryNumericContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(732);
				match(LPAREN);
				setState(733);
				expr(0);
				setState(734);
				match(RPAREN);
				}
				break;
			case TRUNC:
			case ROUND:
				_localctx = new UnaryWithOptionalNumericContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(736);
				((UnaryWithOptionalNumericContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==TRUNC || _la==ROUND) ) {
					((UnaryWithOptionalNumericContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(737);
				match(LPAREN);
				setState(738);
				expr(0);
				setState(741);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(739);
					match(COMMA);
					setState(740);
					optionalExpr();
					}
				}

				setState(743);
				match(RPAREN);
				}
				break;
			case LOG:
			case POWER:
			case MOD:
				_localctx = new BinaryNumericContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(745);
				((BinaryNumericContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 76)) & ~0x3f) == 0 && ((1L << (_la - 76)) & 25L) != 0)) ) {
					((BinaryNumericContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(746);
				match(LPAREN);
				setState(747);
				((BinaryNumericContext)_localctx).left = expr(0);
				setState(748);
				match(COMMA);
				setState(749);
				((BinaryNumericContext)_localctx).right = expr(0);
				setState(750);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericOperatorsComponentContext extends ParserRuleContext {
		public NumericOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericOperatorsComponent; }
	 
		public NumericOperatorsComponentContext() { }
		public void copyFrom(NumericOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryNumericComponentContext extends NumericOperatorsComponentContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode CEIL() { return getToken(VtlParser.CEIL, 0); }
		public TerminalNode FLOOR() { return getToken(VtlParser.FLOOR, 0); }
		public TerminalNode ABS() { return getToken(VtlParser.ABS, 0); }
		public TerminalNode EXP() { return getToken(VtlParser.EXP, 0); }
		public TerminalNode LN() { return getToken(VtlParser.LN, 0); }
		public TerminalNode SQRT() { return getToken(VtlParser.SQRT, 0); }
		public UnaryNumericComponentContext(NumericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryNumericComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryNumericComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryNumericComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BinaryNumericComponentContext extends NumericOperatorsComponentContext {
		public Token op;
		public ExprComponentContext left;
		public ExprComponentContext right;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public TerminalNode MOD() { return getToken(VtlParser.MOD, 0); }
		public TerminalNode POWER() { return getToken(VtlParser.POWER, 0); }
		public TerminalNode LOG() { return getToken(VtlParser.LOG, 0); }
		public BinaryNumericComponentContext(NumericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBinaryNumericComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBinaryNumericComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBinaryNumericComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryWithOptionalNumericComponentContext extends NumericOperatorsComponentContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode ROUND() { return getToken(VtlParser.ROUND, 0); }
		public TerminalNode TRUNC() { return getToken(VtlParser.TRUNC, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public OptionalExprComponentContext optionalExprComponent() {
			return getRuleContext(OptionalExprComponentContext.class,0);
		}
		public UnaryWithOptionalNumericComponentContext(NumericOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnaryWithOptionalNumericComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnaryWithOptionalNumericComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnaryWithOptionalNumericComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericOperatorsComponentContext numericOperatorsComponent() throws RecognitionException {
		NumericOperatorsComponentContext _localctx = new NumericOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_numericOperatorsComponent);
		int _la;
		try {
			setState(775);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ABS:
			case LN:
			case EXP:
			case CEIL:
			case FLOOR:
			case SQRT:
				_localctx = new UnaryNumericComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(754);
				((UnaryNumericComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 73)) & ~0x3f) == 0 && ((1L << (_la - 73)) & 7881299356286981L) != 0)) ) {
					((UnaryNumericComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(755);
				match(LPAREN);
				setState(756);
				exprComponent(0);
				setState(757);
				match(RPAREN);
				}
				break;
			case TRUNC:
			case ROUND:
				_localctx = new UnaryWithOptionalNumericComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(759);
				((UnaryWithOptionalNumericComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==TRUNC || _la==ROUND) ) {
					((UnaryWithOptionalNumericComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(760);
				match(LPAREN);
				setState(761);
				exprComponent(0);
				setState(764);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(762);
					match(COMMA);
					setState(763);
					optionalExprComponent();
					}
				}

				setState(766);
				match(RPAREN);
				}
				break;
			case LOG:
			case POWER:
			case MOD:
				_localctx = new BinaryNumericComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(768);
				((BinaryNumericComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 76)) & ~0x3f) == 0 && ((1L << (_la - 76)) & 25L) != 0)) ) {
					((BinaryNumericComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(769);
				match(LPAREN);
				setState(770);
				((BinaryNumericComponentContext)_localctx).left = exprComponent(0);
				setState(771);
				match(COMMA);
				setState(772);
				((BinaryNumericComponentContext)_localctx).right = exprComponent(0);
				setState(773);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonOperatorsContext extends ParserRuleContext {
		public ComparisonOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparisonOperators; }
	 
		public ComparisonOperatorsContext() { }
		public void copyFrom(ComparisonOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BetweenAtomContext extends ComparisonOperatorsContext {
		public ExprContext op;
		public ExprContext from_;
		public ExprContext to_;
		public TerminalNode BETWEEN() { return getToken(VtlParser.BETWEEN, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BetweenAtomContext(ComparisonOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBetweenAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBetweenAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBetweenAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CharsetMatchAtomContext extends ComparisonOperatorsContext {
		public ExprContext op;
		public ExprContext pattern;
		public TerminalNode CHARSET_MATCH() { return getToken(VtlParser.CHARSET_MATCH, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public CharsetMatchAtomContext(ComparisonOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCharsetMatchAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCharsetMatchAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCharsetMatchAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsNullAtomContext extends ComparisonOperatorsContext {
		public TerminalNode ISNULL() { return getToken(VtlParser.ISNULL, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public IsNullAtomContext(ComparisonOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterIsNullAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitIsNullAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitIsNullAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExistInAtomContext extends ComparisonOperatorsContext {
		public ExprContext left;
		public ExprContext right;
		public TerminalNode EXISTS_IN() { return getToken(VtlParser.EXISTS_IN, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public RetainTypeContext retainType() {
			return getRuleContext(RetainTypeContext.class,0);
		}
		public ExistInAtomContext(ComparisonOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterExistInAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitExistInAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitExistInAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComparisonOperatorsContext comparisonOperators() throws RecognitionException {
		ComparisonOperatorsContext _localctx = new ComparisonOperatorsContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_comparisonOperators);
		int _la;
		try {
			setState(809);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BETWEEN:
				_localctx = new BetweenAtomContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(777);
				match(BETWEEN);
				setState(778);
				match(LPAREN);
				setState(779);
				((BetweenAtomContext)_localctx).op = expr(0);
				setState(780);
				match(COMMA);
				setState(781);
				((BetweenAtomContext)_localctx).from_ = expr(0);
				setState(782);
				match(COMMA);
				setState(783);
				((BetweenAtomContext)_localctx).to_ = expr(0);
				setState(784);
				match(RPAREN);
				}
				break;
			case CHARSET_MATCH:
				_localctx = new CharsetMatchAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(786);
				match(CHARSET_MATCH);
				setState(787);
				match(LPAREN);
				setState(788);
				((CharsetMatchAtomContext)_localctx).op = expr(0);
				setState(789);
				match(COMMA);
				setState(790);
				((CharsetMatchAtomContext)_localctx).pattern = expr(0);
				setState(791);
				match(RPAREN);
				}
				break;
			case ISNULL:
				_localctx = new IsNullAtomContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(793);
				match(ISNULL);
				setState(794);
				match(LPAREN);
				setState(795);
				expr(0);
				setState(796);
				match(RPAREN);
				}
				break;
			case EXISTS_IN:
				_localctx = new ExistInAtomContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(798);
				match(EXISTS_IN);
				setState(799);
				match(LPAREN);
				setState(800);
				((ExistInAtomContext)_localctx).left = expr(0);
				setState(801);
				match(COMMA);
				setState(802);
				((ExistInAtomContext)_localctx).right = expr(0);
				setState(805);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(803);
					match(COMMA);
					setState(804);
					retainType();
					}
				}

				setState(807);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonOperatorsComponentContext extends ParserRuleContext {
		public ComparisonOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparisonOperatorsComponent; }
	 
		public ComparisonOperatorsComponentContext() { }
		public void copyFrom(ComparisonOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsNullAtomComponentContext extends ComparisonOperatorsComponentContext {
		public TerminalNode ISNULL() { return getToken(VtlParser.ISNULL, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public IsNullAtomComponentContext(ComparisonOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterIsNullAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitIsNullAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitIsNullAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CharsetMatchAtomComponentContext extends ComparisonOperatorsComponentContext {
		public ExprComponentContext op;
		public ExprComponentContext pattern;
		public TerminalNode CHARSET_MATCH() { return getToken(VtlParser.CHARSET_MATCH, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public CharsetMatchAtomComponentContext(ComparisonOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCharsetMatchAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCharsetMatchAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCharsetMatchAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BetweenAtomComponentContext extends ComparisonOperatorsComponentContext {
		public ExprComponentContext op;
		public ExprComponentContext from_;
		public ExprComponentContext to_;
		public TerminalNode BETWEEN() { return getToken(VtlParser.BETWEEN, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public BetweenAtomComponentContext(ComparisonOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBetweenAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBetweenAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBetweenAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComparisonOperatorsComponentContext comparisonOperatorsComponent() throws RecognitionException {
		ComparisonOperatorsComponentContext _localctx = new ComparisonOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_comparisonOperatorsComponent);
		try {
			setState(832);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BETWEEN:
				_localctx = new BetweenAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(811);
				match(BETWEEN);
				setState(812);
				match(LPAREN);
				setState(813);
				((BetweenAtomComponentContext)_localctx).op = exprComponent(0);
				setState(814);
				match(COMMA);
				setState(815);
				((BetweenAtomComponentContext)_localctx).from_ = exprComponent(0);
				setState(816);
				match(COMMA);
				setState(817);
				((BetweenAtomComponentContext)_localctx).to_ = exprComponent(0);
				setState(818);
				match(RPAREN);
				}
				break;
			case CHARSET_MATCH:
				_localctx = new CharsetMatchAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(820);
				match(CHARSET_MATCH);
				setState(821);
				match(LPAREN);
				setState(822);
				((CharsetMatchAtomComponentContext)_localctx).op = exprComponent(0);
				setState(823);
				match(COMMA);
				setState(824);
				((CharsetMatchAtomComponentContext)_localctx).pattern = exprComponent(0);
				setState(825);
				match(RPAREN);
				}
				break;
			case ISNULL:
				_localctx = new IsNullAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(827);
				match(ISNULL);
				setState(828);
				match(LPAREN);
				setState(829);
				exprComponent(0);
				setState(830);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeOperatorsContext extends ParserRuleContext {
		public TimeOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeOperators; }
	 
		public TimeOperatorsContext() { }
		public void copyFrom(TimeOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FlowAtomContext extends TimeOperatorsContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode FLOW_TO_STOCK() { return getToken(VtlParser.FLOW_TO_STOCK, 0); }
		public TerminalNode STOCK_TO_FLOW() { return getToken(VtlParser.STOCK_TO_FLOW, 0); }
		public FlowAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFlowAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFlowAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFlowAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeShiftAtomContext extends TimeOperatorsContext {
		public TerminalNode TIMESHIFT() { return getToken(VtlParser.TIMESHIFT, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public SignedIntegerContext signedInteger() {
			return getRuleContext(SignedIntegerContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TimeShiftAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeShiftAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeShiftAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeShiftAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeAggAtomContext extends TimeOperatorsContext {
		public Token periodIndTo;
		public Token periodIndFrom;
		public OptionalExprContext op;
		public TerminalNode TIME_AGG() { return getToken(VtlParser.TIME_AGG, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> STRING_CONSTANT() { return getTokens(VtlParser.STRING_CONSTANT); }
		public TerminalNode STRING_CONSTANT(int i) {
			return getToken(VtlParser.STRING_CONSTANT, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public OptionalExprContext optionalExpr() {
			return getRuleContext(OptionalExprContext.class,0);
		}
		public TerminalNode FIRST() { return getToken(VtlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(VtlParser.LAST, 0); }
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public TimeAggAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeAggAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeAggAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeAggAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CurrentDateAtomContext extends TimeOperatorsContext {
		public TerminalNode CURRENT_DATE() { return getToken(VtlParser.CURRENT_DATE, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public CurrentDateAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCurrentDateAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCurrentDateAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCurrentDateAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PeriodAtomContext extends TimeOperatorsContext {
		public TerminalNode PERIOD_INDICATOR() { return getToken(VtlParser.PERIOD_INDICATOR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PeriodAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterPeriodAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitPeriodAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitPeriodAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FillTimeAtomContext extends TimeOperatorsContext {
		public TerminalNode FILL_TIME_SERIES() { return getToken(VtlParser.FILL_TIME_SERIES, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode SINGLE() { return getToken(VtlParser.SINGLE, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public FillTimeAtomContext(TimeOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFillTimeAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFillTimeAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFillTimeAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeOperatorsContext timeOperators() throws RecognitionException {
		TimeOperatorsContext _localctx = new TimeOperatorsContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_timeOperators);
		int _la;
		try {
			setState(880);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case PERIOD_INDICATOR:
				_localctx = new PeriodAtomContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(834);
				match(PERIOD_INDICATOR);
				setState(835);
				match(LPAREN);
				setState(837);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 54986027030306818L) != 0) || ((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -290482147771301981L) != 0) || ((((_la - 135)) & ~0x3f) == 0 && ((1L << (_la - 135)) & 2306898540376604703L) != 0) || ((((_la - 199)) & ~0x3f) == 0 && ((1L << (_la - 199)) & 33286002817L) != 0)) {
					{
					setState(836);
					expr(0);
					}
				}

				setState(839);
				match(RPAREN);
				}
				break;
			case FILL_TIME_SERIES:
				_localctx = new FillTimeAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(840);
				match(FILL_TIME_SERIES);
				setState(841);
				match(LPAREN);
				setState(842);
				expr(0);
				setState(845);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(843);
					match(COMMA);
					setState(844);
					_la = _input.LA(1);
					if ( !(_la==ALL || _la==SINGLE) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(847);
				match(RPAREN);
				}
				break;
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
				_localctx = new FlowAtomContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(849);
				((FlowAtomContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==FLOW_TO_STOCK || _la==STOCK_TO_FLOW) ) {
					((FlowAtomContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(850);
				match(LPAREN);
				setState(851);
				expr(0);
				setState(852);
				match(RPAREN);
				}
				break;
			case TIMESHIFT:
				_localctx = new TimeShiftAtomContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(854);
				match(TIMESHIFT);
				setState(855);
				match(LPAREN);
				setState(856);
				expr(0);
				setState(857);
				match(COMMA);
				setState(858);
				signedInteger();
				setState(859);
				match(RPAREN);
				}
				break;
			case TIME_AGG:
				_localctx = new TimeAggAtomContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(861);
				match(TIME_AGG);
				setState(862);
				match(LPAREN);
				setState(863);
				((TimeAggAtomContext)_localctx).periodIndTo = match(STRING_CONSTANT);
				setState(866);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,68,_ctx) ) {
				case 1:
					{
					setState(864);
					match(COMMA);
					setState(865);
					((TimeAggAtomContext)_localctx).periodIndFrom = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==OPTIONAL || _la==STRING_CONSTANT) ) {
						((TimeAggAtomContext)_localctx).periodIndFrom = _errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					break;
				}
				setState(870);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,69,_ctx) ) {
				case 1:
					{
					setState(868);
					match(COMMA);
					setState(869);
					((TimeAggAtomContext)_localctx).op = optionalExpr();
					}
					break;
				}
				setState(874);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(872);
					match(COMMA);
					setState(873);
					_la = _input.LA(1);
					if ( !(_la==FIRST || _la==LAST) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(876);
				match(RPAREN);
				}
				break;
			case CURRENT_DATE:
				_localctx = new CurrentDateAtomContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(877);
				match(CURRENT_DATE);
				setState(878);
				match(LPAREN);
				setState(879);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeOperatorsComponentContext extends ParserRuleContext {
		public TimeOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeOperatorsComponent; }
	 
		public TimeOperatorsComponentContext() { }
		public void copyFrom(TimeOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PeriodAtomComponentContext extends TimeOperatorsComponentContext {
		public TerminalNode PERIOD_INDICATOR() { return getToken(VtlParser.PERIOD_INDICATOR, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public PeriodAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterPeriodAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitPeriodAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitPeriodAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeShiftAtomComponentContext extends TimeOperatorsComponentContext {
		public TerminalNode TIMESHIFT() { return getToken(VtlParser.TIMESHIFT, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public SignedIntegerContext signedInteger() {
			return getRuleContext(SignedIntegerContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TimeShiftAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeShiftAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeShiftAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeShiftAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TimeAggAtomComponentContext extends TimeOperatorsComponentContext {
		public Token periodIndTo;
		public Token periodIndFrom;
		public OptionalExprComponentContext op;
		public TerminalNode TIME_AGG() { return getToken(VtlParser.TIME_AGG, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> STRING_CONSTANT() { return getTokens(VtlParser.STRING_CONSTANT); }
		public TerminalNode STRING_CONSTANT(int i) {
			return getToken(VtlParser.STRING_CONSTANT, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public OptionalExprComponentContext optionalExprComponent() {
			return getRuleContext(OptionalExprComponentContext.class,0);
		}
		public TerminalNode FIRST() { return getToken(VtlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(VtlParser.LAST, 0); }
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public TimeAggAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterTimeAggAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitTimeAggAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitTimeAggAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CurrentDateAtomComponentContext extends TimeOperatorsComponentContext {
		public TerminalNode CURRENT_DATE() { return getToken(VtlParser.CURRENT_DATE, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public CurrentDateAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCurrentDateAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCurrentDateAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCurrentDateAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FlowAtomComponentContext extends TimeOperatorsComponentContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode FLOW_TO_STOCK() { return getToken(VtlParser.FLOW_TO_STOCK, 0); }
		public TerminalNode STOCK_TO_FLOW() { return getToken(VtlParser.STOCK_TO_FLOW, 0); }
		public FlowAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFlowAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFlowAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFlowAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FillTimeAtomComponentContext extends TimeOperatorsComponentContext {
		public TerminalNode FILL_TIME_SERIES() { return getToken(VtlParser.FILL_TIME_SERIES, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode SINGLE() { return getToken(VtlParser.SINGLE, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public FillTimeAtomComponentContext(TimeOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterFillTimeAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitFillTimeAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitFillTimeAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeOperatorsComponentContext timeOperatorsComponent() throws RecognitionException {
		TimeOperatorsComponentContext _localctx = new TimeOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_timeOperatorsComponent);
		int _la;
		try {
			setState(928);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case PERIOD_INDICATOR:
				_localctx = new PeriodAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(882);
				match(PERIOD_INDICATOR);
				setState(883);
				match(LPAREN);
				setState(885);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 28037827551234L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & -6935543338036757223L) != 0) || ((((_la - 129)) & ~0x3f) == 0 && ((1L << (_la - 129)) & 15730631L) != 0) || ((((_la - 196)) & ~0x3f) == 0 && ((1L << (_la - 196)) & 266287973385L) != 0)) {
					{
					setState(884);
					exprComponent(0);
					}
				}

				setState(887);
				match(RPAREN);
				}
				break;
			case FILL_TIME_SERIES:
				_localctx = new FillTimeAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(888);
				match(FILL_TIME_SERIES);
				setState(889);
				match(LPAREN);
				setState(890);
				exprComponent(0);
				setState(893);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(891);
					match(COMMA);
					setState(892);
					_la = _input.LA(1);
					if ( !(_la==ALL || _la==SINGLE) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(895);
				match(RPAREN);
				}
				break;
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
				_localctx = new FlowAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(897);
				((FlowAtomComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==FLOW_TO_STOCK || _la==STOCK_TO_FLOW) ) {
					((FlowAtomComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(898);
				match(LPAREN);
				setState(899);
				exprComponent(0);
				setState(900);
				match(RPAREN);
				}
				break;
			case TIMESHIFT:
				_localctx = new TimeShiftAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(902);
				match(TIMESHIFT);
				setState(903);
				match(LPAREN);
				setState(904);
				exprComponent(0);
				setState(905);
				match(COMMA);
				setState(906);
				signedInteger();
				setState(907);
				match(RPAREN);
				}
				break;
			case TIME_AGG:
				_localctx = new TimeAggAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(909);
				match(TIME_AGG);
				setState(910);
				match(LPAREN);
				setState(911);
				((TimeAggAtomComponentContext)_localctx).periodIndTo = match(STRING_CONSTANT);
				setState(914);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,74,_ctx) ) {
				case 1:
					{
					setState(912);
					match(COMMA);
					setState(913);
					((TimeAggAtomComponentContext)_localctx).periodIndFrom = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==OPTIONAL || _la==STRING_CONSTANT) ) {
						((TimeAggAtomComponentContext)_localctx).periodIndFrom = _errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					break;
				}
				setState(918);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,75,_ctx) ) {
				case 1:
					{
					setState(916);
					match(COMMA);
					setState(917);
					((TimeAggAtomComponentContext)_localctx).op = optionalExprComponent();
					}
					break;
				}
				setState(922);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(920);
					match(COMMA);
					setState(921);
					_la = _input.LA(1);
					if ( !(_la==FIRST || _la==LAST) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(924);
				match(RPAREN);
				}
				break;
			case CURRENT_DATE:
				_localctx = new CurrentDateAtomComponentContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(925);
				match(CURRENT_DATE);
				setState(926);
				match(LPAREN);
				setState(927);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetOperatorsContext extends ParserRuleContext {
		public SetOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setOperators; }
	 
		public SetOperatorsContext() { }
		public void copyFrom(SetOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SetOrSYmDiffAtomContext extends SetOperatorsContext {
		public Token op;
		public ExprContext left;
		public ExprContext right;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SETDIFF() { return getToken(VtlParser.SETDIFF, 0); }
		public TerminalNode SYMDIFF() { return getToken(VtlParser.SYMDIFF, 0); }
		public SetOrSYmDiffAtomContext(SetOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSetOrSYmDiffAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSetOrSYmDiffAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSetOrSYmDiffAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IntersectAtomContext extends SetOperatorsContext {
		public ExprContext left;
		public TerminalNode INTERSECT() { return getToken(VtlParser.INTERSECT, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public IntersectAtomContext(SetOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterIntersectAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitIntersectAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitIntersectAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnionAtomContext extends SetOperatorsContext {
		public ExprContext left;
		public TerminalNode UNION() { return getToken(VtlParser.UNION, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public UnionAtomContext(SetOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterUnionAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitUnionAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitUnionAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetOperatorsContext setOperators() throws RecognitionException {
		SetOperatorsContext _localctx = new SetOperatorsContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_setOperators);
		int _la;
		try {
			setState(959);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNION:
				_localctx = new UnionAtomContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(930);
				match(UNION);
				setState(931);
				match(LPAREN);
				setState(932);
				((UnionAtomContext)_localctx).left = expr(0);
				setState(935);
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(933);
					match(COMMA);
					setState(934);
					expr(0);
					}
					}
					setState(937);
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==COMMA );
				setState(939);
				match(RPAREN);
				}
				break;
			case INTERSECT:
				_localctx = new IntersectAtomContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(941);
				match(INTERSECT);
				setState(942);
				match(LPAREN);
				setState(943);
				((IntersectAtomContext)_localctx).left = expr(0);
				setState(946);
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(944);
					match(COMMA);
					setState(945);
					expr(0);
					}
					}
					setState(948);
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==COMMA );
				setState(950);
				match(RPAREN);
				}
				break;
			case SYMDIFF:
			case SETDIFF:
				_localctx = new SetOrSYmDiffAtomContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(952);
				((SetOrSYmDiffAtomContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==SYMDIFF || _la==SETDIFF) ) {
					((SetOrSYmDiffAtomContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(953);
				match(LPAREN);
				setState(954);
				((SetOrSYmDiffAtomContext)_localctx).left = expr(0);
				setState(955);
				match(COMMA);
				setState(956);
				((SetOrSYmDiffAtomContext)_localctx).right = expr(0);
				setState(957);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HierarchyOperatorsContext extends ParserRuleContext {
		public ExprContext op;
		public Token hrName;
		public ComponentIDContext ruleComponent;
		public TerminalNode HIERARCHY() { return getToken(VtlParser.HIERARCHY, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public ConditionClauseContext conditionClause() {
			return getRuleContext(ConditionClauseContext.class,0);
		}
		public TerminalNode RULE() { return getToken(VtlParser.RULE, 0); }
		public ValidationModeContext validationMode() {
			return getRuleContext(ValidationModeContext.class,0);
		}
		public InputModeHierarchyContext inputModeHierarchy() {
			return getRuleContext(InputModeHierarchyContext.class,0);
		}
		public OutputModeHierarchyContext outputModeHierarchy() {
			return getRuleContext(OutputModeHierarchyContext.class,0);
		}
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public HierarchyOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hierarchyOperators; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHierarchyOperators(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHierarchyOperators(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHierarchyOperators(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HierarchyOperatorsContext hierarchyOperators() throws RecognitionException {
		HierarchyOperatorsContext _localctx = new HierarchyOperatorsContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_hierarchyOperators);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(961);
			match(HIERARCHY);
			setState(962);
			match(LPAREN);
			setState(963);
			_localctx.op = expr(0);
			setState(964);
			match(COMMA);
			setState(965);
			_localctx.hrName = match(IDENTIFIER);
			setState(967);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CONDITION) {
				{
				setState(966);
				conditionClause();
				}
			}

			setState(971);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,82,_ctx) ) {
			case 1:
				{
				setState(969);
				match(RULE);
				setState(970);
				_localctx.ruleComponent = componentID();
				}
				break;
			}
			setState(974);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (((((_la - 213)) & ~0x3f) == 0 && ((1L << (_la - 213)) & 63L) != 0)) {
				{
				setState(973);
				validationMode();
				}
			}

			setState(977);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DATASET || _la==RULE || _la==RULE_PRIORITY) {
				{
				setState(976);
				inputModeHierarchy();
				}
			}

			setState(980);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ALL || _la==COMPUTED) {
				{
				setState(979);
				outputModeHierarchy();
				}
			}

			setState(982);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValidationOperatorsContext extends ParserRuleContext {
		public ValidationOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_validationOperators; }
	 
		public ValidationOperatorsContext() { }
		public void copyFrom(ValidationOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ValidateHRrulesetContext extends ValidationOperatorsContext {
		public ExprContext op;
		public Token hrName;
		public TerminalNode CHECK_HIERARCHY() { return getToken(VtlParser.CHECK_HIERARCHY, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public ConditionClauseContext conditionClause() {
			return getRuleContext(ConditionClauseContext.class,0);
		}
		public TerminalNode RULE() { return getToken(VtlParser.RULE, 0); }
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public ValidationModeContext validationMode() {
			return getRuleContext(ValidationModeContext.class,0);
		}
		public InputModeContext inputMode() {
			return getRuleContext(InputModeContext.class,0);
		}
		public ValidationOutputContext validationOutput() {
			return getRuleContext(ValidationOutputContext.class,0);
		}
		public ValidateHRrulesetContext(ValidationOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidateHRruleset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidateHRruleset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidateHRruleset(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ValidateDPrulesetContext extends ValidationOperatorsContext {
		public ExprContext op;
		public Token dpName;
		public TerminalNode CHECK_DATAPOINT() { return getToken(VtlParser.CHECK_DATAPOINT, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public TerminalNode COMPONENTS() { return getToken(VtlParser.COMPONENTS, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public ValidationOutputContext validationOutput() {
			return getRuleContext(ValidationOutputContext.class,0);
		}
		public ValidateDPrulesetContext(ValidationOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidateDPruleset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidateDPruleset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidateDPruleset(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ValidationSimpleContext extends ValidationOperatorsContext {
		public ExprContext op;
		public ErCodeContext codeErr;
		public ErLevelContext levelCode;
		public Token output;
		public TerminalNode CHECK() { return getToken(VtlParser.CHECK, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ImbalanceExprContext imbalanceExpr() {
			return getRuleContext(ImbalanceExprContext.class,0);
		}
		public ErCodeContext erCode() {
			return getRuleContext(ErCodeContext.class,0);
		}
		public ErLevelContext erLevel() {
			return getRuleContext(ErLevelContext.class,0);
		}
		public TerminalNode INVALID() { return getToken(VtlParser.INVALID, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public ValidationSimpleContext(ValidationOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidationSimple(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidationSimple(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidationSimple(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValidationOperatorsContext validationOperators() throws RecognitionException {
		ValidationOperatorsContext _localctx = new ValidationOperatorsContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_validationOperators);
		int _la;
		try {
			setState(1045);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CHECK_DATAPOINT:
				_localctx = new ValidateDPrulesetContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(984);
				match(CHECK_DATAPOINT);
				setState(985);
				match(LPAREN);
				setState(986);
				((ValidateDPrulesetContext)_localctx).op = expr(0);
				setState(987);
				match(COMMA);
				setState(988);
				((ValidateDPrulesetContext)_localctx).dpName = match(IDENTIFIER);
				setState(998);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMPONENTS) {
					{
					setState(989);
					match(COMPONENTS);
					setState(990);
					componentID();
					setState(995);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(991);
						match(COMMA);
						setState(992);
						componentID();
						}
						}
						setState(997);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(1001);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL || _la==INVALID || _la==ALL_MEASURES) {
					{
					setState(1000);
					validationOutput();
					}
				}

				setState(1003);
				match(RPAREN);
				}
				break;
			case CHECK_HIERARCHY:
				_localctx = new ValidateHRrulesetContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1005);
				match(CHECK_HIERARCHY);
				setState(1006);
				match(LPAREN);
				setState(1007);
				((ValidateHRrulesetContext)_localctx).op = expr(0);
				setState(1008);
				match(COMMA);
				setState(1009);
				((ValidateHRrulesetContext)_localctx).hrName = match(IDENTIFIER);
				setState(1011);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==CONDITION) {
					{
					setState(1010);
					conditionClause();
					}
				}

				setState(1015);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==RULE) {
					{
					setState(1013);
					match(RULE);
					setState(1014);
					componentID();
					}
				}

				setState(1018);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 213)) & ~0x3f) == 0 && ((1L << (_la - 213)) & 63L) != 0)) {
					{
					setState(1017);
					validationMode();
					}
				}

				setState(1021);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DATASET || _la==DATASET_PRIORITY) {
					{
					setState(1020);
					inputMode();
					}
				}

				setState(1024);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL || _la==INVALID || _la==ALL_MEASURES) {
					{
					setState(1023);
					validationOutput();
					}
				}

				setState(1026);
				match(RPAREN);
				}
				break;
			case CHECK:
				_localctx = new ValidationSimpleContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1028);
				match(CHECK);
				setState(1029);
				match(LPAREN);
				setState(1030);
				((ValidationSimpleContext)_localctx).op = expr(0);
				setState(1032);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ERRORCODE) {
					{
					setState(1031);
					((ValidationSimpleContext)_localctx).codeErr = erCode();
					}
				}

				setState(1035);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ERRORLEVEL) {
					{
					setState(1034);
					((ValidationSimpleContext)_localctx).levelCode = erLevel();
					}
				}

				setState(1038);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==IMBALANCE) {
					{
					setState(1037);
					imbalanceExpr();
					}
				}

				setState(1041);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL || _la==INVALID) {
					{
					setState(1040);
					((ValidationSimpleContext)_localctx).output = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==ALL || _la==INVALID) ) {
						((ValidationSimpleContext)_localctx).output = _errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(1043);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConditionalOperatorsContext extends ParserRuleContext {
		public ConditionalOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionalOperators; }
	 
		public ConditionalOperatorsContext() { }
		public void copyFrom(ConditionalOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NvlAtomContext extends ConditionalOperatorsContext {
		public ExprContext left;
		public ExprContext right;
		public TerminalNode NVL() { return getToken(VtlParser.NVL, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public NvlAtomContext(ConditionalOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterNvlAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitNvlAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitNvlAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionalOperatorsContext conditionalOperators() throws RecognitionException {
		ConditionalOperatorsContext _localctx = new ConditionalOperatorsContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_conditionalOperators);
		try {
			_localctx = new NvlAtomContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(1047);
			match(NVL);
			setState(1048);
			match(LPAREN);
			setState(1049);
			((NvlAtomContext)_localctx).left = expr(0);
			setState(1050);
			match(COMMA);
			setState(1051);
			((NvlAtomContext)_localctx).right = expr(0);
			setState(1052);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConditionalOperatorsComponentContext extends ParserRuleContext {
		public ConditionalOperatorsComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionalOperatorsComponent; }
	 
		public ConditionalOperatorsComponentContext() { }
		public void copyFrom(ConditionalOperatorsComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NvlAtomComponentContext extends ConditionalOperatorsComponentContext {
		public ExprComponentContext left;
		public ExprComponentContext right;
		public TerminalNode NVL() { return getToken(VtlParser.NVL, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public NvlAtomComponentContext(ConditionalOperatorsComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterNvlAtomComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitNvlAtomComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitNvlAtomComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionalOperatorsComponentContext conditionalOperatorsComponent() throws RecognitionException {
		ConditionalOperatorsComponentContext _localctx = new ConditionalOperatorsComponentContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_conditionalOperatorsComponent);
		try {
			_localctx = new NvlAtomComponentContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(1054);
			match(NVL);
			setState(1055);
			match(LPAREN);
			setState(1056);
			((NvlAtomComponentContext)_localctx).left = exprComponent(0);
			setState(1057);
			match(COMMA);
			setState(1058);
			((NvlAtomComponentContext)_localctx).right = exprComponent(0);
			setState(1059);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggrOperatorsContext extends ParserRuleContext {
		public AggrOperatorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggrOperators; }
	 
		public AggrOperatorsContext() { }
		public void copyFrom(AggrOperatorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggrCompContext extends AggrOperatorsContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode SUM() { return getToken(VtlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(VtlParser.AVG, 0); }
		public TerminalNode COUNT() { return getToken(VtlParser.COUNT, 0); }
		public TerminalNode MEDIAN() { return getToken(VtlParser.MEDIAN, 0); }
		public TerminalNode MIN() { return getToken(VtlParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(VtlParser.MAX, 0); }
		public TerminalNode STDDEV_POP() { return getToken(VtlParser.STDDEV_POP, 0); }
		public TerminalNode STDDEV_SAMP() { return getToken(VtlParser.STDDEV_SAMP, 0); }
		public TerminalNode VAR_POP() { return getToken(VtlParser.VAR_POP, 0); }
		public TerminalNode VAR_SAMP() { return getToken(VtlParser.VAR_SAMP, 0); }
		public AggrCompContext(AggrOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggrComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggrComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggrComp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CountAggrCompContext extends AggrOperatorsContext {
		public TerminalNode COUNT() { return getToken(VtlParser.COUNT, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public CountAggrCompContext(AggrOperatorsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCountAggrComp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCountAggrComp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCountAggrComp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggrOperatorsContext aggrOperators() throws RecognitionException {
		AggrOperatorsContext _localctx = new AggrOperatorsContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_aggrOperators);
		int _la;
		try {
			setState(1069);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,99,_ctx) ) {
			case 1:
				_localctx = new AggrCompContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1061);
				((AggrCompContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -1152921504598982653L) != 0)) ) {
					((AggrCompContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1062);
				match(LPAREN);
				setState(1063);
				exprComponent(0);
				setState(1064);
				match(RPAREN);
				}
				break;
			case 2:
				_localctx = new CountAggrCompContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1066);
				match(COUNT);
				setState(1067);
				match(LPAREN);
				setState(1068);
				match(RPAREN);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggrOperatorsGroupingContext extends ParserRuleContext {
		public AggrOperatorsGroupingContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggrOperatorsGrouping; }
	 
		public AggrOperatorsGroupingContext() { }
		public void copyFrom(AggrOperatorsGroupingContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggrDatasetContext extends AggrOperatorsGroupingContext {
		public Token op;
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public TerminalNode SUM() { return getToken(VtlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(VtlParser.AVG, 0); }
		public TerminalNode COUNT() { return getToken(VtlParser.COUNT, 0); }
		public TerminalNode MEDIAN() { return getToken(VtlParser.MEDIAN, 0); }
		public TerminalNode MIN() { return getToken(VtlParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(VtlParser.MAX, 0); }
		public TerminalNode STDDEV_POP() { return getToken(VtlParser.STDDEV_POP, 0); }
		public TerminalNode STDDEV_SAMP() { return getToken(VtlParser.STDDEV_SAMP, 0); }
		public TerminalNode VAR_POP() { return getToken(VtlParser.VAR_POP, 0); }
		public TerminalNode VAR_SAMP() { return getToken(VtlParser.VAR_SAMP, 0); }
		public GroupingClauseContext groupingClause() {
			return getRuleContext(GroupingClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public AggrDatasetContext(AggrOperatorsGroupingContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggrDataset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggrDataset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggrDataset(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggrOperatorsGroupingContext aggrOperatorsGrouping() throws RecognitionException {
		AggrOperatorsGroupingContext _localctx = new AggrOperatorsGroupingContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_aggrOperatorsGrouping);
		int _la;
		try {
			_localctx = new AggrDatasetContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(1071);
			((AggrDatasetContext)_localctx).op = _input.LT(1);
			_la = _input.LA(1);
			if ( !(((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -1152921504598982653L) != 0)) ) {
				((AggrDatasetContext)_localctx).op = _errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1072);
			match(LPAREN);
			setState(1073);
			expr(0);
			setState(1078);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUP) {
				{
				setState(1074);
				groupingClause();
				setState(1076);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(1075);
					havingClause();
					}
				}

				}
			}

			setState(1080);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnFunctionContext extends ParserRuleContext {
		public AnFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anFunction; }
	 
		public AnFunctionContext() { }
		public void copyFrom(AnFunctionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LagOrLeadAnContext extends AnFunctionContext {
		public Token op;
		public SignedIntegerContext offet;
		public ScalarItemContext defaultValue;
		public PartitionByClauseContext partition;
		public OrderByClauseContext orderBy;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode LAG() { return getToken(VtlParser.LAG, 0); }
		public TerminalNode LEAD() { return getToken(VtlParser.LEAD, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public SignedIntegerContext signedInteger() {
			return getRuleContext(SignedIntegerContext.class,0);
		}
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public ScalarItemContext scalarItem() {
			return getRuleContext(ScalarItemContext.class,0);
		}
		public LagOrLeadAnContext(AnFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterLagOrLeadAn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitLagOrLeadAn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitLagOrLeadAn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RatioToReportAnContext extends AnFunctionContext {
		public Token op;
		public PartitionByClauseContext partition;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode RATIO_TO_REPORT() { return getToken(VtlParser.RATIO_TO_REPORT, 0); }
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public RatioToReportAnContext(AnFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRatioToReportAn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRatioToReportAn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRatioToReportAn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnSimpleFunctionContext extends AnFunctionContext {
		public Token op;
		public PartitionByClauseContext partition;
		public OrderByClauseContext orderBy;
		public WindowingClauseContext windowing;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode SUM() { return getToken(VtlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(VtlParser.AVG, 0); }
		public TerminalNode COUNT() { return getToken(VtlParser.COUNT, 0); }
		public TerminalNode MEDIAN() { return getToken(VtlParser.MEDIAN, 0); }
		public TerminalNode MIN() { return getToken(VtlParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(VtlParser.MAX, 0); }
		public TerminalNode STDDEV_POP() { return getToken(VtlParser.STDDEV_POP, 0); }
		public TerminalNode STDDEV_SAMP() { return getToken(VtlParser.STDDEV_SAMP, 0); }
		public TerminalNode VAR_POP() { return getToken(VtlParser.VAR_POP, 0); }
		public TerminalNode VAR_SAMP() { return getToken(VtlParser.VAR_SAMP, 0); }
		public TerminalNode FIRST_VALUE() { return getToken(VtlParser.FIRST_VALUE, 0); }
		public TerminalNode LAST_VALUE() { return getToken(VtlParser.LAST_VALUE, 0); }
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public WindowingClauseContext windowingClause() {
			return getRuleContext(WindowingClauseContext.class,0);
		}
		public AnSimpleFunctionContext(AnFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAnSimpleFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAnSimpleFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAnSimpleFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnFunctionContext anFunction() throws RecognitionException {
		AnFunctionContext _localctx = new AnFunctionContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_anFunction);
		int _la;
		try {
			setState(1128);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MIN:
			case MAX:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
				_localctx = new AnSimpleFunctionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1082);
				((AnSimpleFunctionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -1152921504598982653L) != 0) || _la==FIRST_VALUE || _la==LAST_VALUE) ) {
					((AnSimpleFunctionContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1083);
				match(LPAREN);
				setState(1084);
				expr(0);
				setState(1085);
				match(OVER);
				setState(1086);
				match(LPAREN);
				{
				setState(1088);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PARTITION) {
					{
					setState(1087);
					((AnSimpleFunctionContext)_localctx).partition = partitionByClause();
					}
				}

				setState(1091);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ORDER) {
					{
					setState(1090);
					((AnSimpleFunctionContext)_localctx).orderBy = orderByClause();
					}
				}

				setState(1094);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DATA || _la==RANGE) {
					{
					setState(1093);
					((AnSimpleFunctionContext)_localctx).windowing = windowingClause();
					}
				}

				}
				setState(1096);
				match(RPAREN);
				setState(1097);
				match(RPAREN);
				}
				break;
			case LAG:
			case LEAD:
				_localctx = new LagOrLeadAnContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1099);
				((LagOrLeadAnContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==LAG || _la==LEAD) ) {
					((LagOrLeadAnContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1100);
				match(LPAREN);
				setState(1101);
				expr(0);
				setState(1107);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(1102);
					match(COMMA);
					setState(1103);
					((LagOrLeadAnContext)_localctx).offet = signedInteger();
					setState(1105);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==NULL_CONSTANT || ((((_la - 206)) & ~0x3f) == 0 && ((1L << (_la - 206)) & 125829121L) != 0)) {
						{
						setState(1104);
						((LagOrLeadAnContext)_localctx).defaultValue = scalarItem();
						}
					}

					}
				}

				setState(1109);
				match(OVER);
				setState(1110);
				match(LPAREN);
				{
				setState(1112);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PARTITION) {
					{
					setState(1111);
					((LagOrLeadAnContext)_localctx).partition = partitionByClause();
					}
				}

				setState(1114);
				((LagOrLeadAnContext)_localctx).orderBy = orderByClause();
				}
				setState(1116);
				match(RPAREN);
				setState(1117);
				match(RPAREN);
				}
				break;
			case RATIO_TO_REPORT:
				_localctx = new RatioToReportAnContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1119);
				((RatioToReportAnContext)_localctx).op = match(RATIO_TO_REPORT);
				setState(1120);
				match(LPAREN);
				setState(1121);
				expr(0);
				setState(1122);
				match(OVER);
				setState(1123);
				match(LPAREN);
				{
				setState(1124);
				((RatioToReportAnContext)_localctx).partition = partitionByClause();
				}
				setState(1125);
				match(RPAREN);
				setState(1126);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnFunctionComponentContext extends ParserRuleContext {
		public AnFunctionComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anFunctionComponent; }
	 
		public AnFunctionComponentContext() { }
		public void copyFrom(AnFunctionComponentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnSimpleFunctionComponentContext extends AnFunctionComponentContext {
		public Token op;
		public PartitionByClauseContext partition;
		public OrderByClauseContext orderBy;
		public WindowingClauseContext windowing;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode SUM() { return getToken(VtlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(VtlParser.AVG, 0); }
		public TerminalNode COUNT() { return getToken(VtlParser.COUNT, 0); }
		public TerminalNode MEDIAN() { return getToken(VtlParser.MEDIAN, 0); }
		public TerminalNode MIN() { return getToken(VtlParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(VtlParser.MAX, 0); }
		public TerminalNode STDDEV_POP() { return getToken(VtlParser.STDDEV_POP, 0); }
		public TerminalNode STDDEV_SAMP() { return getToken(VtlParser.STDDEV_SAMP, 0); }
		public TerminalNode VAR_POP() { return getToken(VtlParser.VAR_POP, 0); }
		public TerminalNode VAR_SAMP() { return getToken(VtlParser.VAR_SAMP, 0); }
		public TerminalNode FIRST_VALUE() { return getToken(VtlParser.FIRST_VALUE, 0); }
		public TerminalNode LAST_VALUE() { return getToken(VtlParser.LAST_VALUE, 0); }
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public WindowingClauseContext windowingClause() {
			return getRuleContext(WindowingClauseContext.class,0);
		}
		public AnSimpleFunctionComponentContext(AnFunctionComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAnSimpleFunctionComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAnSimpleFunctionComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAnSimpleFunctionComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LagOrLeadAnComponentContext extends AnFunctionComponentContext {
		public Token op;
		public SignedIntegerContext offet;
		public ScalarItemContext defaultValue;
		public PartitionByClauseContext partition;
		public OrderByClauseContext orderBy;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode LAG() { return getToken(VtlParser.LAG, 0); }
		public TerminalNode LEAD() { return getToken(VtlParser.LEAD, 0); }
		public TerminalNode COMMA() { return getToken(VtlParser.COMMA, 0); }
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public SignedIntegerContext signedInteger() {
			return getRuleContext(SignedIntegerContext.class,0);
		}
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public ScalarItemContext scalarItem() {
			return getRuleContext(ScalarItemContext.class,0);
		}
		public LagOrLeadAnComponentContext(AnFunctionComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterLagOrLeadAnComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitLagOrLeadAnComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitLagOrLeadAnComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RankAnComponentContext extends AnFunctionComponentContext {
		public Token op;
		public PartitionByClauseContext partition;
		public OrderByClauseContext orderBy;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode RANK() { return getToken(VtlParser.RANK, 0); }
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public RankAnComponentContext(AnFunctionComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRankAnComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRankAnComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRankAnComponent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RatioToReportAnComponentContext extends AnFunctionComponentContext {
		public Token op;
		public PartitionByClauseContext partition;
		public List<TerminalNode> LPAREN() { return getTokens(VtlParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(VtlParser.LPAREN, i);
		}
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode OVER() { return getToken(VtlParser.OVER, 0); }
		public List<TerminalNode> RPAREN() { return getTokens(VtlParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(VtlParser.RPAREN, i);
		}
		public TerminalNode RATIO_TO_REPORT() { return getToken(VtlParser.RATIO_TO_REPORT, 0); }
		public PartitionByClauseContext partitionByClause() {
			return getRuleContext(PartitionByClauseContext.class,0);
		}
		public RatioToReportAnComponentContext(AnFunctionComponentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRatioToReportAnComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRatioToReportAnComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRatioToReportAnComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnFunctionComponentContext anFunctionComponent() throws RecognitionException {
		AnFunctionComponentContext _localctx = new AnFunctionComponentContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_anFunctionComponent);
		int _la;
		try {
			setState(1188);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MIN:
			case MAX:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
				_localctx = new AnSimpleFunctionComponentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1130);
				((AnSimpleFunctionComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 68)) & ~0x3f) == 0 && ((1L << (_la - 68)) & -1152921504598982653L) != 0) || _la==FIRST_VALUE || _la==LAST_VALUE) ) {
					((AnSimpleFunctionComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1131);
				match(LPAREN);
				setState(1132);
				exprComponent(0);
				setState(1133);
				match(OVER);
				setState(1134);
				match(LPAREN);
				{
				setState(1136);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PARTITION) {
					{
					setState(1135);
					((AnSimpleFunctionComponentContext)_localctx).partition = partitionByClause();
					}
				}

				setState(1139);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ORDER) {
					{
					setState(1138);
					((AnSimpleFunctionComponentContext)_localctx).orderBy = orderByClause();
					}
				}

				setState(1142);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DATA || _la==RANGE) {
					{
					setState(1141);
					((AnSimpleFunctionComponentContext)_localctx).windowing = windowingClause();
					}
				}

				}
				setState(1144);
				match(RPAREN);
				setState(1145);
				match(RPAREN);
				}
				break;
			case LAG:
			case LEAD:
				_localctx = new LagOrLeadAnComponentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1147);
				((LagOrLeadAnComponentContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==LAG || _la==LEAD) ) {
					((LagOrLeadAnComponentContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1148);
				match(LPAREN);
				setState(1149);
				exprComponent(0);
				setState(1155);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(1150);
					match(COMMA);
					setState(1151);
					((LagOrLeadAnComponentContext)_localctx).offet = signedInteger();
					setState(1153);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==NULL_CONSTANT || ((((_la - 206)) & ~0x3f) == 0 && ((1L << (_la - 206)) & 125829121L) != 0)) {
						{
						setState(1152);
						((LagOrLeadAnComponentContext)_localctx).defaultValue = scalarItem();
						}
					}

					}
				}

				setState(1157);
				match(OVER);
				setState(1158);
				match(LPAREN);
				{
				setState(1160);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PARTITION) {
					{
					setState(1159);
					((LagOrLeadAnComponentContext)_localctx).partition = partitionByClause();
					}
				}

				setState(1162);
				((LagOrLeadAnComponentContext)_localctx).orderBy = orderByClause();
				}
				setState(1164);
				match(RPAREN);
				setState(1165);
				match(RPAREN);
				}
				break;
			case RANK:
				_localctx = new RankAnComponentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1167);
				((RankAnComponentContext)_localctx).op = match(RANK);
				setState(1168);
				match(LPAREN);
				setState(1169);
				match(OVER);
				setState(1170);
				match(LPAREN);
				{
				setState(1172);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PARTITION) {
					{
					setState(1171);
					((RankAnComponentContext)_localctx).partition = partitionByClause();
					}
				}

				setState(1174);
				((RankAnComponentContext)_localctx).orderBy = orderByClause();
				}
				setState(1176);
				match(RPAREN);
				setState(1177);
				match(RPAREN);
				}
				break;
			case RATIO_TO_REPORT:
				_localctx = new RatioToReportAnComponentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1179);
				((RatioToReportAnComponentContext)_localctx).op = match(RATIO_TO_REPORT);
				setState(1180);
				match(LPAREN);
				setState(1181);
				exprComponent(0);
				setState(1182);
				match(OVER);
				setState(1183);
				match(LPAREN);
				{
				setState(1184);
				((RatioToReportAnComponentContext)_localctx).partition = partitionByClause();
				}
				setState(1185);
				match(RPAREN);
				setState(1186);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RenameClauseItemContext extends ParserRuleContext {
		public ComponentIDContext fromName;
		public ComponentIDContext toName;
		public TerminalNode TO() { return getToken(VtlParser.TO, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public RenameClauseItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_renameClauseItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRenameClauseItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRenameClauseItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRenameClauseItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RenameClauseItemContext renameClauseItem() throws RecognitionException {
		RenameClauseItemContext _localctx = new RenameClauseItemContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_renameClauseItem);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1190);
			_localctx.fromName = componentID();
			setState(1191);
			match(TO);
			setState(1192);
			_localctx.toName = componentID();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggregateClauseContext extends ParserRuleContext {
		public List<AggrFunctionClauseContext> aggrFunctionClause() {
			return getRuleContexts(AggrFunctionClauseContext.class);
		}
		public AggrFunctionClauseContext aggrFunctionClause(int i) {
			return getRuleContext(AggrFunctionClauseContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public AggregateClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggregateClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggregateClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggregateClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggregateClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggregateClauseContext aggregateClause() throws RecognitionException {
		AggregateClauseContext _localctx = new AggregateClauseContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_aggregateClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1194);
			aggrFunctionClause();
			setState(1199);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1195);
				match(COMMA);
				setState(1196);
				aggrFunctionClause();
				}
				}
				setState(1201);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggrFunctionClauseContext extends ParserRuleContext {
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(VtlParser.ASSIGN, 0); }
		public AggrOperatorsContext aggrOperators() {
			return getRuleContext(AggrOperatorsContext.class,0);
		}
		public ComponentRoleContext componentRole() {
			return getRuleContext(ComponentRoleContext.class,0);
		}
		public AggrFunctionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggrFunctionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAggrFunctionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAggrFunctionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAggrFunctionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggrFunctionClauseContext aggrFunctionClause() throws RecognitionException {
		AggrFunctionClauseContext _localctx = new AggrFunctionClauseContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_aggrFunctionClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1203);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (((((_la - 91)) & ~0x3f) == 0 && ((1L << (_la - 91)) & 135L) != 0) || _la==COMPONENT) {
				{
				setState(1202);
				componentRole();
				}
			}

			setState(1205);
			componentID();
			setState(1206);
			match(ASSIGN);
			setState(1207);
			aggrOperators();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CalcClauseItemContext extends ParserRuleContext {
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(VtlParser.ASSIGN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public ComponentRoleContext componentRole() {
			return getRuleContext(ComponentRoleContext.class,0);
		}
		public CalcClauseItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_calcClauseItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCalcClauseItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCalcClauseItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCalcClauseItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CalcClauseItemContext calcClauseItem() throws RecognitionException {
		CalcClauseItemContext _localctx = new CalcClauseItemContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_calcClauseItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1210);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (((((_la - 91)) & ~0x3f) == 0 && ((1L << (_la - 91)) & 135L) != 0) || _la==COMPONENT) {
				{
				setState(1209);
				componentRole();
				}
			}

			setState(1212);
			componentID();
			setState(1213);
			match(ASSIGN);
			setState(1214);
			exprComponent(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubspaceClauseItemContext extends ParserRuleContext {
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public TerminalNode EQ() { return getToken(VtlParser.EQ, 0); }
		public ScalarItemContext scalarItem() {
			return getRuleContext(ScalarItemContext.class,0);
		}
		public SubspaceClauseItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subspaceClauseItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSubspaceClauseItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSubspaceClauseItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSubspaceClauseItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubspaceClauseItemContext subspaceClauseItem() throws RecognitionException {
		SubspaceClauseItemContext _localctx = new SubspaceClauseItemContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_subspaceClauseItem);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1216);
			componentID();
			setState(1217);
			match(EQ);
			setState(1218);
			scalarItem();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ScalarItemContext extends ParserRuleContext {
		public ScalarItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalarItem; }
	 
		public ScalarItemContext() { }
		public void copyFrom(ScalarItemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ScalarWithCastContext extends ScalarItemContext {
		public TerminalNode CAST() { return getToken(VtlParser.CAST, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public BasicScalarTypeContext basicScalarType() {
			return getRuleContext(BasicScalarTypeContext.class,0);
		}
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public ScalarWithCastContext(ScalarItemContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterScalarWithCast(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitScalarWithCast(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitScalarWithCast(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SimpleScalarContext extends ScalarItemContext {
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public SimpleScalarContext(ScalarItemContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSimpleScalar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSimpleScalar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSimpleScalar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScalarItemContext scalarItem() throws RecognitionException {
		ScalarItemContext _localctx = new ScalarItemContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_scalarItem);
		int _la;
		try {
			setState(1232);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NULL_CONSTANT:
			case INTEGER_CONSTANT:
			case NUMBER_CONSTANT:
			case BOOLEAN_CONSTANT:
			case STRING_CONSTANT:
				_localctx = new SimpleScalarContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1220);
				constant();
				}
				break;
			case CAST:
				_localctx = new ScalarWithCastContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1221);
				match(CAST);
				setState(1222);
				match(LPAREN);
				setState(1223);
				constant();
				setState(1224);
				match(COMMA);
				{
				setState(1225);
				basicScalarType();
				}
				setState(1228);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(1226);
					match(COMMA);
					setState(1227);
					match(STRING_CONSTANT);
					}
				}

				setState(1230);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinClauseWithoutUsingContext extends ParserRuleContext {
		public List<JoinClauseItemContext> joinClauseItem() {
			return getRuleContexts(JoinClauseItemContext.class);
		}
		public JoinClauseItemContext joinClauseItem(int i) {
			return getRuleContext(JoinClauseItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public JoinClauseWithoutUsingContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinClauseWithoutUsing; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinClauseWithoutUsing(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinClauseWithoutUsing(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinClauseWithoutUsing(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinClauseWithoutUsingContext joinClauseWithoutUsing() throws RecognitionException {
		JoinClauseWithoutUsingContext _localctx = new JoinClauseWithoutUsingContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_joinClauseWithoutUsing);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1234);
			joinClauseItem();
			setState(1239);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1235);
				match(COMMA);
				setState(1236);
				joinClauseItem();
				}
				}
				setState(1241);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinClauseContext extends ParserRuleContext {
		public List<JoinClauseItemContext> joinClauseItem() {
			return getRuleContexts(JoinClauseItemContext.class);
		}
		public JoinClauseItemContext joinClauseItem(int i) {
			return getRuleContext(JoinClauseItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public TerminalNode USING() { return getToken(VtlParser.USING, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public JoinClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinClauseContext joinClause() throws RecognitionException {
		JoinClauseContext _localctx = new JoinClauseContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_joinClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1242);
			joinClauseItem();
			setState(1247);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1243);
				match(COMMA);
				setState(1244);
				joinClauseItem();
				}
				}
				setState(1249);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1259);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==USING) {
				{
				setState(1250);
				match(USING);
				setState(1251);
				componentID();
				setState(1256);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(1252);
					match(COMMA);
					setState(1253);
					componentID();
					}
					}
					setState(1258);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinClauseItemContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode AS() { return getToken(VtlParser.AS, 0); }
		public AliasContext alias() {
			return getRuleContext(AliasContext.class,0);
		}
		public JoinClauseItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinClauseItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinClauseItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinClauseItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinClauseItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinClauseItemContext joinClauseItem() throws RecognitionException {
		JoinClauseItemContext _localctx = new JoinClauseItemContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_joinClauseItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1261);
			expr(0);
			setState(1264);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1262);
				match(AS);
				setState(1263);
				alias();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinBodyContext extends ParserRuleContext {
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public CalcClauseContext calcClause() {
			return getRuleContext(CalcClauseContext.class,0);
		}
		public JoinApplyClauseContext joinApplyClause() {
			return getRuleContext(JoinApplyClauseContext.class,0);
		}
		public AggrClauseContext aggrClause() {
			return getRuleContext(AggrClauseContext.class,0);
		}
		public KeepOrDropClauseContext keepOrDropClause() {
			return getRuleContext(KeepOrDropClauseContext.class,0);
		}
		public RenameClauseContext renameClause() {
			return getRuleContext(RenameClauseContext.class,0);
		}
		public JoinBodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinBody; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinBody(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinBody(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinBody(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinBodyContext joinBody() throws RecognitionException {
		JoinBodyContext _localctx = new JoinBodyContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_joinBody);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1267);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FILTER) {
				{
				setState(1266);
				filterClause();
				}
			}

			setState(1272);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CALC:
				{
				setState(1269);
				calcClause();
				}
				break;
			case APPLY:
				{
				setState(1270);
				joinApplyClause();
				}
				break;
			case AGGREGATE:
				{
				setState(1271);
				aggrClause();
				}
				break;
			case RPAREN:
			case DROP:
			case KEEP:
			case RENAME:
				break;
			default:
				break;
			}
			setState(1275);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DROP || _la==KEEP) {
				{
				setState(1274);
				keepOrDropClause();
				}
			}

			setState(1278);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==RENAME) {
				{
				setState(1277);
				renameClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinApplyClauseContext extends ParserRuleContext {
		public TerminalNode APPLY() { return getToken(VtlParser.APPLY, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public JoinApplyClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinApplyClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterJoinApplyClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitJoinApplyClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitJoinApplyClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinApplyClauseContext joinApplyClause() throws RecognitionException {
		JoinApplyClauseContext _localctx = new JoinApplyClauseContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_joinApplyClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1280);
			match(APPLY);
			setState(1281);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PartitionByClauseContext extends ParserRuleContext {
		public TerminalNode PARTITION() { return getToken(VtlParser.PARTITION, 0); }
		public TerminalNode BY() { return getToken(VtlParser.BY, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public PartitionByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_partitionByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterPartitionByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitPartitionByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitPartitionByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PartitionByClauseContext partitionByClause() throws RecognitionException {
		PartitionByClauseContext _localctx = new PartitionByClauseContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_partitionByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1283);
			match(PARTITION);
			setState(1284);
			match(BY);
			setState(1285);
			componentID();
			setState(1290);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1286);
				match(COMMA);
				setState(1287);
				componentID();
				}
				}
				setState(1292);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderByClauseContext extends ParserRuleContext {
		public TerminalNode ORDER() { return getToken(VtlParser.ORDER, 0); }
		public TerminalNode BY() { return getToken(VtlParser.BY, 0); }
		public List<OrderByItemContext> orderByItem() {
			return getRuleContexts(OrderByItemContext.class);
		}
		public OrderByItemContext orderByItem(int i) {
			return getRuleContext(OrderByItemContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public OrderByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOrderByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOrderByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOrderByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderByClauseContext orderByClause() throws RecognitionException {
		OrderByClauseContext _localctx = new OrderByClauseContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_orderByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1293);
			match(ORDER);
			setState(1294);
			match(BY);
			setState(1295);
			orderByItem();
			setState(1300);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1296);
				match(COMMA);
				setState(1297);
				orderByItem();
				}
				}
				setState(1302);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderByItemContext extends ParserRuleContext {
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public TerminalNode ASC() { return getToken(VtlParser.ASC, 0); }
		public TerminalNode DESC() { return getToken(VtlParser.DESC, 0); }
		public OrderByItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderByItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOrderByItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOrderByItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOrderByItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderByItemContext orderByItem() throws RecognitionException {
		OrderByItemContext _localctx = new OrderByItemContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_orderByItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1303);
			componentID();
			setState(1305);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(1304);
				_la = _input.LA(1);
				if ( !(_la==ASC || _la==DESC) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WindowingClauseContext extends ParserRuleContext {
		public LimitClauseItemContext from_;
		public LimitClauseItemContext to_;
		public TerminalNode BETWEEN() { return getToken(VtlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(VtlParser.AND, 0); }
		public List<LimitClauseItemContext> limitClauseItem() {
			return getRuleContexts(LimitClauseItemContext.class);
		}
		public LimitClauseItemContext limitClauseItem(int i) {
			return getRuleContext(LimitClauseItemContext.class,i);
		}
		public TerminalNode RANGE() { return getToken(VtlParser.RANGE, 0); }
		public TerminalNode DATA() { return getToken(VtlParser.DATA, 0); }
		public TerminalNode POINTS() { return getToken(VtlParser.POINTS, 0); }
		public WindowingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_windowingClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterWindowingClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitWindowingClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitWindowingClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WindowingClauseContext windowingClause() throws RecognitionException {
		WindowingClauseContext _localctx = new WindowingClauseContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_windowingClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1310);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DATA:
				{
				{
				setState(1307);
				match(DATA);
				setState(1308);
				match(POINTS);
				}
				}
				break;
			case RANGE:
				{
				setState(1309);
				match(RANGE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1312);
			match(BETWEEN);
			setState(1313);
			_localctx.from_ = limitClauseItem();
			setState(1314);
			match(AND);
			setState(1315);
			_localctx.to_ = limitClauseItem();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SignedIntegerContext extends ParserRuleContext {
		public TerminalNode INTEGER_CONSTANT() { return getToken(VtlParser.INTEGER_CONSTANT, 0); }
		public SignedIntegerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signedInteger; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSignedInteger(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSignedInteger(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSignedInteger(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SignedIntegerContext signedInteger() throws RecognitionException {
		SignedIntegerContext _localctx = new SignedIntegerContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_signedInteger);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1317);
			match(INTEGER_CONSTANT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LimitClauseItemContext extends ParserRuleContext {
		public TerminalNode INTEGER_CONSTANT() { return getToken(VtlParser.INTEGER_CONSTANT, 0); }
		public TerminalNode PRECEDING() { return getToken(VtlParser.PRECEDING, 0); }
		public TerminalNode FOLLOWING() { return getToken(VtlParser.FOLLOWING, 0); }
		public TerminalNode CURRENT() { return getToken(VtlParser.CURRENT, 0); }
		public TerminalNode DATA() { return getToken(VtlParser.DATA, 0); }
		public TerminalNode POINT() { return getToken(VtlParser.POINT, 0); }
		public TerminalNode UNBOUNDED() { return getToken(VtlParser.UNBOUNDED, 0); }
		public LimitClauseItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_limitClauseItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterLimitClauseItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitLimitClauseItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitLimitClauseItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LimitClauseItemContext limitClauseItem() throws RecognitionException {
		LimitClauseItemContext _localctx = new LimitClauseItemContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_limitClauseItem);
		try {
			setState(1330);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,135,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1319);
				match(INTEGER_CONSTANT);
				setState(1320);
				match(PRECEDING);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1321);
				match(INTEGER_CONSTANT);
				setState(1322);
				match(FOLLOWING);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1323);
				match(CURRENT);
				setState(1324);
				match(DATA);
				setState(1325);
				match(POINT);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1326);
				match(UNBOUNDED);
				setState(1327);
				match(PRECEDING);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1328);
				match(UNBOUNDED);
				setState(1329);
				match(FOLLOWING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GroupingClauseContext extends ParserRuleContext {
		public GroupingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupingClause; }
	 
		public GroupingClauseContext() { }
		public void copyFrom(GroupingClauseContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupAllContext extends GroupingClauseContext {
		public TerminalNode GROUP() { return getToken(VtlParser.GROUP, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public GroupAllContext(GroupingClauseContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterGroupAll(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitGroupAll(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitGroupAll(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupByOrExceptContext extends GroupingClauseContext {
		public Token op;
		public TerminalNode GROUP() { return getToken(VtlParser.GROUP, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public TerminalNode BY() { return getToken(VtlParser.BY, 0); }
		public TerminalNode EXCEPT() { return getToken(VtlParser.EXCEPT, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public GroupByOrExceptContext(GroupingClauseContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterGroupByOrExcept(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitGroupByOrExcept(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitGroupByOrExcept(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupingClauseContext groupingClause() throws RecognitionException {
		GroupingClauseContext _localctx = new GroupingClauseContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_groupingClause);
		int _la;
		try {
			setState(1345);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,137,_ctx) ) {
			case 1:
				_localctx = new GroupByOrExceptContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1332);
				match(GROUP);
				setState(1333);
				((GroupByOrExceptContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==BY || _la==EXCEPT) ) {
					((GroupByOrExceptContext)_localctx).op = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1334);
				componentID();
				setState(1339);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(1335);
					match(COMMA);
					setState(1336);
					componentID();
					}
					}
					setState(1341);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 2:
				_localctx = new GroupAllContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1342);
				match(GROUP);
				setState(1343);
				match(ALL);
				setState(1344);
				exprComponent(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HavingClauseContext extends ParserRuleContext {
		public TerminalNode HAVING() { return getToken(VtlParser.HAVING, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public HavingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_havingClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHavingClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHavingClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHavingClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HavingClauseContext havingClause() throws RecognitionException {
		HavingClauseContext _localctx = new HavingClauseContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_havingClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1347);
			match(HAVING);
			setState(1348);
			exprComponent(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterItemContext extends ParserRuleContext {
		public VarIDContext varID() {
			return getRuleContext(VarIDContext.class,0);
		}
		public InputParameterTypeContext inputParameterType() {
			return getRuleContext(InputParameterTypeContext.class,0);
		}
		public TerminalNode DEFAULT() { return getToken(VtlParser.DEFAULT, 0); }
		public ScalarItemContext scalarItem() {
			return getRuleContext(ScalarItemContext.class,0);
		}
		public ParameterItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterParameterItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitParameterItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitParameterItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterItemContext parameterItem() throws RecognitionException {
		ParameterItemContext _localctx = new ParameterItemContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_parameterItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1350);
			varID();
			setState(1351);
			inputParameterType();
			setState(1354);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DEFAULT) {
				{
				setState(1352);
				match(DEFAULT);
				setState(1353);
				scalarItem();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OutputParameterTypeContext extends ParserRuleContext {
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public DatasetTypeContext datasetType() {
			return getRuleContext(DatasetTypeContext.class,0);
		}
		public ComponentTypeContext componentType() {
			return getRuleContext(ComponentTypeContext.class,0);
		}
		public OutputParameterTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_outputParameterType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOutputParameterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOutputParameterType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOutputParameterType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputParameterTypeContext outputParameterType() throws RecognitionException {
		OutputParameterTypeContext _localctx = new OutputParameterTypeContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_outputParameterType);
		try {
			setState(1359);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BOOLEAN:
			case DATE:
			case TIME_PERIOD:
			case NUMBER:
			case STRING:
			case TIME:
			case INTEGER:
			case DURATION:
			case SCALAR:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1356);
				scalarType();
				}
				break;
			case DATASET:
				enterOuterAlt(_localctx, 2);
				{
				setState(1357);
				datasetType();
				}
				break;
			case DIMENSION:
			case MEASURE:
			case ATTRIBUTE:
			case VIRAL:
			case COMPONENT:
				enterOuterAlt(_localctx, 3);
				{
				setState(1358);
				componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OutputParameterTypeComponentContext extends ParserRuleContext {
		public ComponentTypeContext componentType() {
			return getRuleContext(ComponentTypeContext.class,0);
		}
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public OutputParameterTypeComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_outputParameterTypeComponent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOutputParameterTypeComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOutputParameterTypeComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOutputParameterTypeComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputParameterTypeComponentContext outputParameterTypeComponent() throws RecognitionException {
		OutputParameterTypeComponentContext _localctx = new OutputParameterTypeComponentContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_outputParameterTypeComponent);
		try {
			setState(1363);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DIMENSION:
			case MEASURE:
			case ATTRIBUTE:
			case VIRAL:
			case COMPONENT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1361);
				componentType();
				}
				break;
			case BOOLEAN:
			case DATE:
			case TIME_PERIOD:
			case NUMBER:
			case STRING:
			case TIME:
			case INTEGER:
			case DURATION:
			case SCALAR:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(1362);
				scalarType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InputParameterTypeContext extends ParserRuleContext {
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public DatasetTypeContext datasetType() {
			return getRuleContext(DatasetTypeContext.class,0);
		}
		public ScalarSetTypeContext scalarSetType() {
			return getRuleContext(ScalarSetTypeContext.class,0);
		}
		public RulesetTypeContext rulesetType() {
			return getRuleContext(RulesetTypeContext.class,0);
		}
		public ComponentTypeContext componentType() {
			return getRuleContext(ComponentTypeContext.class,0);
		}
		public InputParameterTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inputParameterType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInputParameterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInputParameterType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInputParameterType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InputParameterTypeContext inputParameterType() throws RecognitionException {
		InputParameterTypeContext _localctx = new InputParameterTypeContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_inputParameterType);
		try {
			setState(1370);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BOOLEAN:
			case DATE:
			case TIME_PERIOD:
			case NUMBER:
			case STRING:
			case TIME:
			case INTEGER:
			case DURATION:
			case SCALAR:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1365);
				scalarType();
				}
				break;
			case DATASET:
				enterOuterAlt(_localctx, 2);
				{
				setState(1366);
				datasetType();
				}
				break;
			case SET:
				enterOuterAlt(_localctx, 3);
				{
				setState(1367);
				scalarSetType();
				}
				break;
			case DATAPOINT:
			case HIERARCHICAL:
			case RULESET:
			case DATAPOINT_ON_VD:
			case DATAPOINT_ON_VAR:
			case HIERARCHICAL_ON_VD:
			case HIERARCHICAL_ON_VAR:
				enterOuterAlt(_localctx, 4);
				{
				setState(1368);
				rulesetType();
				}
				break;
			case DIMENSION:
			case MEASURE:
			case ATTRIBUTE:
			case VIRAL:
			case COMPONENT:
				enterOuterAlt(_localctx, 5);
				{
				setState(1369);
				componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RulesetTypeContext extends ParserRuleContext {
		public TerminalNode RULESET() { return getToken(VtlParser.RULESET, 0); }
		public DpRulesetContext dpRuleset() {
			return getRuleContext(DpRulesetContext.class,0);
		}
		public HrRulesetContext hrRuleset() {
			return getRuleContext(HrRulesetContext.class,0);
		}
		public RulesetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rulesetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRulesetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRulesetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRulesetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RulesetTypeContext rulesetType() throws RecognitionException {
		RulesetTypeContext _localctx = new RulesetTypeContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_rulesetType);
		try {
			setState(1375);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RULESET:
				enterOuterAlt(_localctx, 1);
				{
				setState(1372);
				match(RULESET);
				}
				break;
			case DATAPOINT:
			case DATAPOINT_ON_VD:
			case DATAPOINT_ON_VAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(1373);
				dpRuleset();
				}
				break;
			case HIERARCHICAL:
			case HIERARCHICAL_ON_VD:
			case HIERARCHICAL_ON_VAR:
				enterOuterAlt(_localctx, 3);
				{
				setState(1374);
				hrRuleset();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ScalarTypeContext extends ParserRuleContext {
		public BasicScalarTypeContext basicScalarType() {
			return getRuleContext(BasicScalarTypeContext.class,0);
		}
		public ValueDomainNameContext valueDomainName() {
			return getRuleContext(ValueDomainNameContext.class,0);
		}
		public ScalarTypeConstraintContext scalarTypeConstraint() {
			return getRuleContext(ScalarTypeConstraintContext.class,0);
		}
		public TerminalNode NULL_CONSTANT() { return getToken(VtlParser.NULL_CONSTANT, 0); }
		public TerminalNode NOT() { return getToken(VtlParser.NOT, 0); }
		public ScalarTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalarType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterScalarType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitScalarType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitScalarType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScalarTypeContext scalarType() throws RecognitionException {
		ScalarTypeContext _localctx = new ScalarTypeContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_scalarType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1379);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BOOLEAN:
			case DATE:
			case TIME_PERIOD:
			case NUMBER:
			case STRING:
			case TIME:
			case INTEGER:
			case DURATION:
			case SCALAR:
				{
				setState(1377);
				basicScalarType();
				}
				break;
			case IDENTIFIER:
				{
				setState(1378);
				valueDomainName();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1382);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==QLPAREN || _la==GLPAREN) {
				{
				setState(1381);
				scalarTypeConstraint();
				}
			}

			setState(1388);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT || _la==NULL_CONSTANT) {
				{
				setState(1385);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(1384);
					match(NOT);
					}
				}

				setState(1387);
				match(NULL_CONSTANT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComponentTypeContext extends ParserRuleContext {
		public ComponentRoleContext componentRole() {
			return getRuleContext(ComponentRoleContext.class,0);
		}
		public TerminalNode LT() { return getToken(VtlParser.LT, 0); }
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public TerminalNode MT() { return getToken(VtlParser.MT, 0); }
		public ComponentTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_componentType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComponentType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComponentType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComponentType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComponentTypeContext componentType() throws RecognitionException {
		ComponentTypeContext _localctx = new ComponentTypeContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_componentType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1390);
			componentRole();
			setState(1395);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LT) {
				{
				setState(1391);
				match(LT);
				setState(1392);
				scalarType();
				setState(1393);
				match(MT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DatasetTypeContext extends ParserRuleContext {
		public TerminalNode DATASET() { return getToken(VtlParser.DATASET, 0); }
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public List<CompConstraintContext> compConstraint() {
			return getRuleContexts(CompConstraintContext.class);
		}
		public CompConstraintContext compConstraint(int i) {
			return getRuleContext(CompConstraintContext.class,i);
		}
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public DatasetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datasetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDatasetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDatasetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDatasetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DatasetTypeContext datasetType() throws RecognitionException {
		DatasetTypeContext _localctx = new DatasetTypeContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_datasetType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1397);
			match(DATASET);
			setState(1409);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GLPAREN) {
				{
				setState(1398);
				match(GLPAREN);
				setState(1399);
				compConstraint();
				setState(1404);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(1400);
					match(COMMA);
					setState(1401);
					compConstraint();
					}
					}
					setState(1406);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1407);
				match(GRPAREN);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EvalDatasetTypeContext extends ParserRuleContext {
		public DatasetTypeContext datasetType() {
			return getRuleContext(DatasetTypeContext.class,0);
		}
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public EvalDatasetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_evalDatasetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterEvalDatasetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitEvalDatasetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitEvalDatasetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EvalDatasetTypeContext evalDatasetType() throws RecognitionException {
		EvalDatasetTypeContext _localctx = new EvalDatasetTypeContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_evalDatasetType);
		try {
			setState(1413);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DATASET:
				enterOuterAlt(_localctx, 1);
				{
				setState(1411);
				datasetType();
				}
				break;
			case BOOLEAN:
			case DATE:
			case TIME_PERIOD:
			case NUMBER:
			case STRING:
			case TIME:
			case INTEGER:
			case DURATION:
			case SCALAR:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(1412);
				scalarType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ScalarSetTypeContext extends ParserRuleContext {
		public TerminalNode SET() { return getToken(VtlParser.SET, 0); }
		public TerminalNode LT() { return getToken(VtlParser.LT, 0); }
		public ScalarTypeContext scalarType() {
			return getRuleContext(ScalarTypeContext.class,0);
		}
		public TerminalNode MT() { return getToken(VtlParser.MT, 0); }
		public ScalarSetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalarSetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterScalarSetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitScalarSetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitScalarSetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScalarSetTypeContext scalarSetType() throws RecognitionException {
		ScalarSetTypeContext _localctx = new ScalarSetTypeContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_scalarSetType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1415);
			match(SET);
			setState(1420);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LT) {
				{
				setState(1416);
				match(LT);
				setState(1417);
				scalarType();
				setState(1418);
				match(MT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DpRulesetContext extends ParserRuleContext {
		public DpRulesetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dpRuleset; }
	 
		public DpRulesetContext() { }
		public void copyFrom(DpRulesetContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DataPointVdContext extends DpRulesetContext {
		public TerminalNode DATAPOINT_ON_VD() { return getToken(VtlParser.DATAPOINT_ON_VD, 0); }
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public List<ValueDomainNameContext> valueDomainName() {
			return getRuleContexts(ValueDomainNameContext.class);
		}
		public ValueDomainNameContext valueDomainName(int i) {
			return getRuleContext(ValueDomainNameContext.class,i);
		}
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<TerminalNode> MUL() { return getTokens(VtlParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(VtlParser.MUL, i);
		}
		public DataPointVdContext(DpRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDataPointVd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDataPointVd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDataPointVd(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DataPointVarContext extends DpRulesetContext {
		public TerminalNode DATAPOINT_ON_VAR() { return getToken(VtlParser.DATAPOINT_ON_VAR, 0); }
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public List<VarIDContext> varID() {
			return getRuleContexts(VarIDContext.class);
		}
		public VarIDContext varID(int i) {
			return getRuleContext(VarIDContext.class,i);
		}
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<TerminalNode> MUL() { return getTokens(VtlParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(VtlParser.MUL, i);
		}
		public DataPointVarContext(DpRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDataPointVar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDataPointVar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDataPointVar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DataPointContext extends DpRulesetContext {
		public TerminalNode DATAPOINT() { return getToken(VtlParser.DATAPOINT, 0); }
		public DataPointContext(DpRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterDataPoint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitDataPoint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitDataPoint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DpRulesetContext dpRuleset() throws RecognitionException {
		DpRulesetContext _localctx = new DpRulesetContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_dpRuleset);
		int _la;
		try {
			setState(1451);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DATAPOINT:
				_localctx = new DataPointContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1422);
				match(DATAPOINT);
				}
				break;
			case DATAPOINT_ON_VD:
				_localctx = new DataPointVdContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1423);
				match(DATAPOINT_ON_VD);
				setState(1435);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GLPAREN) {
					{
					setState(1424);
					match(GLPAREN);
					setState(1425);
					valueDomainName();
					setState(1430);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==MUL) {
						{
						{
						setState(1426);
						match(MUL);
						setState(1427);
						valueDomainName();
						}
						}
						setState(1432);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(1433);
					match(GRPAREN);
					}
				}

				}
				break;
			case DATAPOINT_ON_VAR:
				_localctx = new DataPointVarContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1437);
				match(DATAPOINT_ON_VAR);
				setState(1449);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GLPAREN) {
					{
					setState(1438);
					match(GLPAREN);
					setState(1439);
					varID();
					setState(1444);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==MUL) {
						{
						{
						setState(1440);
						match(MUL);
						setState(1441);
						varID();
						}
						}
						setState(1446);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(1447);
					match(GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HrRulesetContext extends ParserRuleContext {
		public HrRulesetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hrRuleset; }
	 
		public HrRulesetContext() { }
		public void copyFrom(HrRulesetContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HrRulesetVdTypeContext extends HrRulesetContext {
		public Token vdName;
		public TerminalNode HIERARCHICAL_ON_VD() { return getToken(VtlParser.HIERARCHICAL_ON_VD, 0); }
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public List<ValueDomainNameContext> valueDomainName() {
			return getRuleContexts(ValueDomainNameContext.class);
		}
		public ValueDomainNameContext valueDomainName(int i) {
			return getRuleContext(ValueDomainNameContext.class,i);
		}
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> MUL() { return getTokens(VtlParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(VtlParser.MUL, i);
		}
		public HrRulesetVdTypeContext(HrRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHrRulesetVdType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHrRulesetVdType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHrRulesetVdType(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HrRulesetVarTypeContext extends HrRulesetContext {
		public VarIDContext varName;
		public TerminalNode HIERARCHICAL_ON_VAR() { return getToken(VtlParser.HIERARCHICAL_ON_VAR, 0); }
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<VarIDContext> varID() {
			return getRuleContexts(VarIDContext.class);
		}
		public VarIDContext varID(int i) {
			return getRuleContext(VarIDContext.class,i);
		}
		public TerminalNode LPAREN() { return getToken(VtlParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(VtlParser.RPAREN, 0); }
		public List<TerminalNode> MUL() { return getTokens(VtlParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(VtlParser.MUL, i);
		}
		public HrRulesetVarTypeContext(HrRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHrRulesetVarType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHrRulesetVarType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHrRulesetVarType(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HrRulesetTypeContext extends HrRulesetContext {
		public TerminalNode HIERARCHICAL() { return getToken(VtlParser.HIERARCHICAL, 0); }
		public HrRulesetTypeContext(HrRulesetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHrRulesetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHrRulesetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHrRulesetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HrRulesetContext hrRuleset() throws RecognitionException {
		HrRulesetContext _localctx = new HrRulesetContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_hrRuleset);
		int _la;
		try {
			setState(1493);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case HIERARCHICAL:
				_localctx = new HrRulesetTypeContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1453);
				match(HIERARCHICAL);
				}
				break;
			case HIERARCHICAL_ON_VD:
				_localctx = new HrRulesetVdTypeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1454);
				match(HIERARCHICAL_ON_VD);
				setState(1471);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GLPAREN) {
					{
					setState(1455);
					match(GLPAREN);
					setState(1456);
					((HrRulesetVdTypeContext)_localctx).vdName = match(IDENTIFIER);
					setState(1468);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==LPAREN) {
						{
						setState(1457);
						match(LPAREN);
						setState(1458);
						valueDomainName();
						setState(1463);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==MUL) {
							{
							{
							setState(1459);
							match(MUL);
							setState(1460);
							valueDomainName();
							}
							}
							setState(1465);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(1466);
						match(RPAREN);
						}
					}

					setState(1470);
					match(GRPAREN);
					}
				}

				}
				break;
			case HIERARCHICAL_ON_VAR:
				_localctx = new HrRulesetVarTypeContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1473);
				match(HIERARCHICAL_ON_VAR);
				setState(1491);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GLPAREN) {
					{
					setState(1474);
					match(GLPAREN);
					setState(1475);
					((HrRulesetVarTypeContext)_localctx).varName = varID();
					setState(1487);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==LPAREN) {
						{
						setState(1476);
						match(LPAREN);
						setState(1477);
						varID();
						setState(1482);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==MUL) {
							{
							{
							setState(1478);
							match(MUL);
							setState(1479);
							varID();
							}
							}
							setState(1484);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(1485);
						match(RPAREN);
						}
					}

					setState(1489);
					match(GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueDomainNameContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public ValueDomainNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueDomainName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValueDomainName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValueDomainName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValueDomainName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueDomainNameContext valueDomainName() throws RecognitionException {
		ValueDomainNameContext _localctx = new ValueDomainNameContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_valueDomainName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1495);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RulesetIDContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public RulesetIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rulesetID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRulesetID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRulesetID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRulesetID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RulesetIDContext rulesetID() throws RecognitionException {
		RulesetIDContext _localctx = new RulesetIDContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_rulesetID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1497);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RulesetSignatureContext extends ParserRuleContext {
		public List<SignatureContext> signature() {
			return getRuleContexts(SignatureContext.class);
		}
		public SignatureContext signature(int i) {
			return getRuleContext(SignatureContext.class,i);
		}
		public TerminalNode VALUE_DOMAIN() { return getToken(VtlParser.VALUE_DOMAIN, 0); }
		public TerminalNode VARIABLE() { return getToken(VtlParser.VARIABLE, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public RulesetSignatureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rulesetSignature; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRulesetSignature(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRulesetSignature(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRulesetSignature(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RulesetSignatureContext rulesetSignature() throws RecognitionException {
		RulesetSignatureContext _localctx = new RulesetSignatureContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_rulesetSignature);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1499);
			_la = _input.LA(1);
			if ( !(_la==VALUE_DOMAIN || _la==VARIABLE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1500);
			signature();
			setState(1505);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1501);
				match(COMMA);
				setState(1502);
				signature();
				}
				}
				setState(1507);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SignatureContext extends ParserRuleContext {
		public VarIDContext varID() {
			return getRuleContext(VarIDContext.class,0);
		}
		public TerminalNode AS() { return getToken(VtlParser.AS, 0); }
		public AliasContext alias() {
			return getRuleContext(AliasContext.class,0);
		}
		public SignatureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signature; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSignature(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSignature(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSignature(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SignatureContext signature() throws RecognitionException {
		SignatureContext _localctx = new SignatureContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_signature);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1508);
			varID();
			setState(1511);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1509);
				match(AS);
				setState(1510);
				alias();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RuleClauseDatapointContext extends ParserRuleContext {
		public List<RuleItemDatapointContext> ruleItemDatapoint() {
			return getRuleContexts(RuleItemDatapointContext.class);
		}
		public RuleItemDatapointContext ruleItemDatapoint(int i) {
			return getRuleContext(RuleItemDatapointContext.class,i);
		}
		public List<TerminalNode> EOL() { return getTokens(VtlParser.EOL); }
		public TerminalNode EOL(int i) {
			return getToken(VtlParser.EOL, i);
		}
		public RuleClauseDatapointContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruleClauseDatapoint; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRuleClauseDatapoint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRuleClauseDatapoint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRuleClauseDatapoint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RuleClauseDatapointContext ruleClauseDatapoint() throws RecognitionException {
		RuleClauseDatapointContext _localctx = new RuleClauseDatapointContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_ruleClauseDatapoint);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1513);
			ruleItemDatapoint();
			setState(1518);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EOL) {
				{
				{
				setState(1514);
				match(EOL);
				setState(1515);
				ruleItemDatapoint();
				}
				}
				setState(1520);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RuleItemDatapointContext extends ParserRuleContext {
		public Token ruleName;
		public ExprComponentContext antecedentContiditon;
		public ExprComponentContext consequentCondition;
		public List<ExprComponentContext> exprComponent() {
			return getRuleContexts(ExprComponentContext.class);
		}
		public ExprComponentContext exprComponent(int i) {
			return getRuleContext(ExprComponentContext.class,i);
		}
		public TerminalNode COLON() { return getToken(VtlParser.COLON, 0); }
		public TerminalNode WHEN() { return getToken(VtlParser.WHEN, 0); }
		public TerminalNode THEN() { return getToken(VtlParser.THEN, 0); }
		public ErCodeContext erCode() {
			return getRuleContext(ErCodeContext.class,0);
		}
		public ErLevelContext erLevel() {
			return getRuleContext(ErLevelContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public RuleItemDatapointContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruleItemDatapoint; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRuleItemDatapoint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRuleItemDatapoint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRuleItemDatapoint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RuleItemDatapointContext ruleItemDatapoint() throws RecognitionException {
		RuleItemDatapointContext _localctx = new RuleItemDatapointContext(_ctx, getState());
		enterRule(_localctx, 148, RULE_ruleItemDatapoint);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1523);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,167,_ctx) ) {
			case 1:
				{
				setState(1521);
				_localctx.ruleName = match(IDENTIFIER);
				setState(1522);
				match(COLON);
				}
				break;
			}
			setState(1529);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHEN) {
				{
				setState(1525);
				match(WHEN);
				setState(1526);
				_localctx.antecedentContiditon = exprComponent(0);
				setState(1527);
				match(THEN);
				}
			}

			setState(1531);
			_localctx.consequentCondition = exprComponent(0);
			setState(1533);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERRORCODE) {
				{
				setState(1532);
				erCode();
				}
			}

			setState(1536);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERRORLEVEL) {
				{
				setState(1535);
				erLevel();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RuleClauseHierarchicalContext extends ParserRuleContext {
		public List<RuleItemHierarchicalContext> ruleItemHierarchical() {
			return getRuleContexts(RuleItemHierarchicalContext.class);
		}
		public RuleItemHierarchicalContext ruleItemHierarchical(int i) {
			return getRuleContext(RuleItemHierarchicalContext.class,i);
		}
		public List<TerminalNode> EOL() { return getTokens(VtlParser.EOL); }
		public TerminalNode EOL(int i) {
			return getToken(VtlParser.EOL, i);
		}
		public RuleClauseHierarchicalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruleClauseHierarchical; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRuleClauseHierarchical(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRuleClauseHierarchical(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRuleClauseHierarchical(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RuleClauseHierarchicalContext ruleClauseHierarchical() throws RecognitionException {
		RuleClauseHierarchicalContext _localctx = new RuleClauseHierarchicalContext(_ctx, getState());
		enterRule(_localctx, 150, RULE_ruleClauseHierarchical);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1538);
			ruleItemHierarchical();
			setState(1543);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EOL) {
				{
				{
				setState(1539);
				match(EOL);
				setState(1540);
				ruleItemHierarchical();
				}
				}
				setState(1545);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RuleItemHierarchicalContext extends ParserRuleContext {
		public Token ruleName;
		public CodeItemRelationContext codeItemRelation() {
			return getRuleContext(CodeItemRelationContext.class,0);
		}
		public TerminalNode COLON() { return getToken(VtlParser.COLON, 0); }
		public ErCodeContext erCode() {
			return getRuleContext(ErCodeContext.class,0);
		}
		public ErLevelContext erLevel() {
			return getRuleContext(ErLevelContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public RuleItemHierarchicalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruleItemHierarchical; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRuleItemHierarchical(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRuleItemHierarchical(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRuleItemHierarchical(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RuleItemHierarchicalContext ruleItemHierarchical() throws RecognitionException {
		RuleItemHierarchicalContext _localctx = new RuleItemHierarchicalContext(_ctx, getState());
		enterRule(_localctx, 152, RULE_ruleItemHierarchical);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1548);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,172,_ctx) ) {
			case 1:
				{
				setState(1546);
				_localctx.ruleName = match(IDENTIFIER);
				setState(1547);
				match(COLON);
				}
				break;
			}
			setState(1550);
			codeItemRelation();
			setState(1552);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERRORCODE) {
				{
				setState(1551);
				erCode();
				}
			}

			setState(1555);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERRORLEVEL) {
				{
				setState(1554);
				erLevel();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HierRuleSignatureContext extends ParserRuleContext {
		public TerminalNode RULE() { return getToken(VtlParser.RULE, 0); }
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public TerminalNode VALUE_DOMAIN() { return getToken(VtlParser.VALUE_DOMAIN, 0); }
		public TerminalNode VARIABLE() { return getToken(VtlParser.VARIABLE, 0); }
		public TerminalNode CONDITION() { return getToken(VtlParser.CONDITION, 0); }
		public ValueDomainSignatureContext valueDomainSignature() {
			return getRuleContext(ValueDomainSignatureContext.class,0);
		}
		public HierRuleSignatureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hierRuleSignature; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterHierRuleSignature(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitHierRuleSignature(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitHierRuleSignature(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HierRuleSignatureContext hierRuleSignature() throws RecognitionException {
		HierRuleSignatureContext _localctx = new HierRuleSignatureContext(_ctx, getState());
		enterRule(_localctx, 154, RULE_hierRuleSignature);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1557);
			_la = _input.LA(1);
			if ( !(_la==VALUE_DOMAIN || _la==VARIABLE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1560);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CONDITION) {
				{
				setState(1558);
				match(CONDITION);
				setState(1559);
				valueDomainSignature();
				}
			}

			setState(1562);
			match(RULE);
			setState(1563);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueDomainSignatureContext extends ParserRuleContext {
		public List<SignatureContext> signature() {
			return getRuleContexts(SignatureContext.class);
		}
		public SignatureContext signature(int i) {
			return getRuleContext(SignatureContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public ValueDomainSignatureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueDomainSignature; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValueDomainSignature(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValueDomainSignature(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValueDomainSignature(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueDomainSignatureContext valueDomainSignature() throws RecognitionException {
		ValueDomainSignatureContext _localctx = new ValueDomainSignatureContext(_ctx, getState());
		enterRule(_localctx, 156, RULE_valueDomainSignature);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1565);
			signature();
			setState(1570);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1566);
				match(COMMA);
				setState(1567);
				signature();
				}
				}
				setState(1572);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CodeItemRelationContext extends ParserRuleContext {
		public ValueDomainValueContext codetemRef;
		public List<CodeItemRelationClauseContext> codeItemRelationClause() {
			return getRuleContexts(CodeItemRelationClauseContext.class);
		}
		public CodeItemRelationClauseContext codeItemRelationClause(int i) {
			return getRuleContext(CodeItemRelationClauseContext.class,i);
		}
		public ValueDomainValueContext valueDomainValue() {
			return getRuleContext(ValueDomainValueContext.class,0);
		}
		public TerminalNode WHEN() { return getToken(VtlParser.WHEN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode THEN() { return getToken(VtlParser.THEN, 0); }
		public ComparisonOperandContext comparisonOperand() {
			return getRuleContext(ComparisonOperandContext.class,0);
		}
		public CodeItemRelationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_codeItemRelation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCodeItemRelation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCodeItemRelation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCodeItemRelation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CodeItemRelationContext codeItemRelation() throws RecognitionException {
		CodeItemRelationContext _localctx = new CodeItemRelationContext(_ctx, getState());
		enterRule(_localctx, 158, RULE_codeItemRelation);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1577);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHEN) {
				{
				setState(1573);
				match(WHEN);
				setState(1574);
				exprComponent(0);
				setState(1575);
				match(THEN);
				}
			}

			setState(1579);
			_localctx.codetemRef = valueDomainValue();
			setState(1581);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 8064L) != 0)) {
				{
				setState(1580);
				comparisonOperand();
				}
			}

			setState(1583);
			codeItemRelationClause();
			setState(1587);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==PLUS || _la==MINUS || ((((_la - 229)) & ~0x3f) == 0 && ((1L << (_la - 229)) & 19L) != 0)) {
				{
				{
				setState(1584);
				codeItemRelationClause();
				}
				}
				setState(1589);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CodeItemRelationClauseContext extends ParserRuleContext {
		public Token opAdd;
		public ValueDomainValueContext rightCodeItem;
		public ExprComponentContext rightCondition;
		public ValueDomainValueContext valueDomainValue() {
			return getRuleContext(ValueDomainValueContext.class,0);
		}
		public TerminalNode QLPAREN() { return getToken(VtlParser.QLPAREN, 0); }
		public TerminalNode QRPAREN() { return getToken(VtlParser.QRPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(VtlParser.MINUS, 0); }
		public CodeItemRelationClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_codeItemRelationClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCodeItemRelationClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCodeItemRelationClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCodeItemRelationClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CodeItemRelationClauseContext codeItemRelationClause() throws RecognitionException {
		CodeItemRelationClauseContext _localctx = new CodeItemRelationClauseContext(_ctx, getState());
		enterRule(_localctx, 160, RULE_codeItemRelationClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1591);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MINUS) {
				{
				setState(1590);
				_localctx.opAdd = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					_localctx.opAdd = _errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			setState(1593);
			_localctx.rightCodeItem = valueDomainValue();
			setState(1598);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==QLPAREN) {
				{
				setState(1594);
				match(QLPAREN);
				setState(1595);
				_localctx.rightCondition = exprComponent(0);
				setState(1596);
				match(QRPAREN);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueDomainValueContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public TerminalNode INTEGER_CONSTANT() { return getToken(VtlParser.INTEGER_CONSTANT, 0); }
		public TerminalNode NUMBER_CONSTANT() { return getToken(VtlParser.NUMBER_CONSTANT, 0); }
		public ValueDomainValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueDomainValue; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValueDomainValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValueDomainValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValueDomainValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueDomainValueContext valueDomainValue() throws RecognitionException {
		ValueDomainValueContext _localctx = new ValueDomainValueContext(_ctx, getState());
		enterRule(_localctx, 162, RULE_valueDomainValue);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1600);
			_la = _input.LA(1);
			if ( !(((((_la - 229)) & ~0x3f) == 0 && ((1L << (_la - 229)) & 19L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ScalarTypeConstraintContext extends ParserRuleContext {
		public ScalarTypeConstraintContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalarTypeConstraint; }
	 
		public ScalarTypeConstraintContext() { }
		public void copyFrom(ScalarTypeConstraintContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RangeConstraintContext extends ScalarTypeConstraintContext {
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public List<ScalarItemContext> scalarItem() {
			return getRuleContexts(ScalarItemContext.class);
		}
		public ScalarItemContext scalarItem(int i) {
			return getRuleContext(ScalarItemContext.class,i);
		}
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public RangeConstraintContext(ScalarTypeConstraintContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRangeConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRangeConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRangeConstraint(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ConditionConstraintContext extends ScalarTypeConstraintContext {
		public TerminalNode QLPAREN() { return getToken(VtlParser.QLPAREN, 0); }
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode QRPAREN() { return getToken(VtlParser.QRPAREN, 0); }
		public ConditionConstraintContext(ScalarTypeConstraintContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConditionConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConditionConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConditionConstraint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScalarTypeConstraintContext scalarTypeConstraint() throws RecognitionException {
		ScalarTypeConstraintContext _localctx = new ScalarTypeConstraintContext(_ctx, getState());
		enterRule(_localctx, 164, RULE_scalarTypeConstraint);
		int _la;
		try {
			setState(1617);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case QLPAREN:
				_localctx = new ConditionConstraintContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1602);
				match(QLPAREN);
				setState(1603);
				exprComponent(0);
				setState(1604);
				match(QRPAREN);
				}
				break;
			case GLPAREN:
				_localctx = new RangeConstraintContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1606);
				match(GLPAREN);
				setState(1607);
				scalarItem();
				setState(1612);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(1608);
					match(COMMA);
					setState(1609);
					scalarItem();
					}
					}
					setState(1614);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1615);
				match(GRPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CompConstraintContext extends ParserRuleContext {
		public ComponentTypeContext componentType() {
			return getRuleContext(ComponentTypeContext.class,0);
		}
		public ComponentIDContext componentID() {
			return getRuleContext(ComponentIDContext.class,0);
		}
		public MultModifierContext multModifier() {
			return getRuleContext(MultModifierContext.class,0);
		}
		public CompConstraintContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_compConstraint; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterCompConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitCompConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitCompConstraint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CompConstraintContext compConstraint() throws RecognitionException {
		CompConstraintContext _localctx = new CompConstraintContext(_ctx, getState());
		enterRule(_localctx, 166, RULE_compConstraint);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1619);
			componentType();
			setState(1622);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				{
				setState(1620);
				componentID();
				}
				break;
			case OPTIONAL:
				{
				setState(1621);
				multModifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MultModifierContext extends ParserRuleContext {
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public TerminalNode PLUS() { return getToken(VtlParser.PLUS, 0); }
		public TerminalNode MUL() { return getToken(VtlParser.MUL, 0); }
		public MultModifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multModifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterMultModifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitMultModifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitMultModifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultModifierContext multModifier() throws RecognitionException {
		MultModifierContext _localctx = new MultModifierContext(_ctx, getState());
		enterRule(_localctx, 168, RULE_multModifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1624);
			match(OPTIONAL);
			setState(1626);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MUL) {
				{
				setState(1625);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MUL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValidationOutputContext extends ParserRuleContext {
		public TerminalNode INVALID() { return getToken(VtlParser.INVALID, 0); }
		public TerminalNode ALL_MEASURES() { return getToken(VtlParser.ALL_MEASURES, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public ValidationOutputContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_validationOutput; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidationOutput(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidationOutput(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidationOutput(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValidationOutputContext validationOutput() throws RecognitionException {
		ValidationOutputContext _localctx = new ValidationOutputContext(_ctx, getState());
		enterRule(_localctx, 170, RULE_validationOutput);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1628);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==INVALID || _la==ALL_MEASURES) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValidationModeContext extends ParserRuleContext {
		public TerminalNode NON_NULL() { return getToken(VtlParser.NON_NULL, 0); }
		public TerminalNode NON_ZERO() { return getToken(VtlParser.NON_ZERO, 0); }
		public TerminalNode PARTIAL_NULL() { return getToken(VtlParser.PARTIAL_NULL, 0); }
		public TerminalNode PARTIAL_ZERO() { return getToken(VtlParser.PARTIAL_ZERO, 0); }
		public TerminalNode ALWAYS_NULL() { return getToken(VtlParser.ALWAYS_NULL, 0); }
		public TerminalNode ALWAYS_ZERO() { return getToken(VtlParser.ALWAYS_ZERO, 0); }
		public ValidationModeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_validationMode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValidationMode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValidationMode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValidationMode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValidationModeContext validationMode() throws RecognitionException {
		ValidationModeContext _localctx = new ValidationModeContext(_ctx, getState());
		enterRule(_localctx, 172, RULE_validationMode);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1630);
			_la = _input.LA(1);
			if ( !(((((_la - 213)) & ~0x3f) == 0 && ((1L << (_la - 213)) & 63L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConditionClauseContext extends ParserRuleContext {
		public TerminalNode CONDITION() { return getToken(VtlParser.CONDITION, 0); }
		public List<ComponentIDContext> componentID() {
			return getRuleContexts(ComponentIDContext.class);
		}
		public ComponentIDContext componentID(int i) {
			return getRuleContext(ComponentIDContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public ConditionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConditionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConditionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConditionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionClauseContext conditionClause() throws RecognitionException {
		ConditionClauseContext _localctx = new ConditionClauseContext(_ctx, getState());
		enterRule(_localctx, 174, RULE_conditionClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1632);
			match(CONDITION);
			setState(1633);
			componentID();
			setState(1638);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1634);
				match(COMMA);
				setState(1635);
				componentID();
				}
				}
				setState(1640);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InputModeContext extends ParserRuleContext {
		public TerminalNode DATASET() { return getToken(VtlParser.DATASET, 0); }
		public TerminalNode DATASET_PRIORITY() { return getToken(VtlParser.DATASET_PRIORITY, 0); }
		public InputModeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inputMode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInputMode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInputMode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInputMode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InputModeContext inputMode() throws RecognitionException {
		InputModeContext _localctx = new InputModeContext(_ctx, getState());
		enterRule(_localctx, 176, RULE_inputMode);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1641);
			_la = _input.LA(1);
			if ( !(_la==DATASET || _la==DATASET_PRIORITY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ImbalanceExprContext extends ParserRuleContext {
		public TerminalNode IMBALANCE() { return getToken(VtlParser.IMBALANCE, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ImbalanceExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_imbalanceExpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterImbalanceExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitImbalanceExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitImbalanceExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImbalanceExprContext imbalanceExpr() throws RecognitionException {
		ImbalanceExprContext _localctx = new ImbalanceExprContext(_ctx, getState());
		enterRule(_localctx, 178, RULE_imbalanceExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1643);
			match(IMBALANCE);
			setState(1644);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InputModeHierarchyContext extends ParserRuleContext {
		public TerminalNode RULE() { return getToken(VtlParser.RULE, 0); }
		public TerminalNode DATASET() { return getToken(VtlParser.DATASET, 0); }
		public TerminalNode RULE_PRIORITY() { return getToken(VtlParser.RULE_PRIORITY, 0); }
		public InputModeHierarchyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inputModeHierarchy; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterInputModeHierarchy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitInputModeHierarchy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitInputModeHierarchy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InputModeHierarchyContext inputModeHierarchy() throws RecognitionException {
		InputModeHierarchyContext _localctx = new InputModeHierarchyContext(_ctx, getState());
		enterRule(_localctx, 180, RULE_inputModeHierarchy);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1646);
			_la = _input.LA(1);
			if ( !(_la==DATASET || _la==RULE || _la==RULE_PRIORITY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OutputModeHierarchyContext extends ParserRuleContext {
		public TerminalNode COMPUTED() { return getToken(VtlParser.COMPUTED, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public OutputModeHierarchyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_outputModeHierarchy; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOutputModeHierarchy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOutputModeHierarchy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOutputModeHierarchy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputModeHierarchyContext outputModeHierarchy() throws RecognitionException {
		OutputModeHierarchyContext _localctx = new OutputModeHierarchyContext(_ctx, getState());
		enterRule(_localctx, 182, RULE_outputModeHierarchy);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1648);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==COMPUTED) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AliasContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public AliasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alias; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterAlias(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitAlias(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitAlias(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AliasContext alias() throws RecognitionException {
		AliasContext _localctx = new AliasContext(_ctx, getState());
		enterRule(_localctx, 184, RULE_alias);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1650);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VarIDContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public VarIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_varID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterVarID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitVarID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitVarID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VarIDContext varID() throws RecognitionException {
		VarIDContext _localctx = new VarIDContext(_ctx, getState());
		enterRule(_localctx, 186, RULE_varID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1652);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimpleComponentIdContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public SimpleComponentIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleComponentId; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterSimpleComponentId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitSimpleComponentId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitSimpleComponentId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleComponentIdContext simpleComponentId() throws RecognitionException {
		SimpleComponentIdContext _localctx = new SimpleComponentIdContext(_ctx, getState());
		enterRule(_localctx, 188, RULE_simpleComponentId);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1654);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComponentIDContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(VtlParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(VtlParser.IDENTIFIER, i);
		}
		public TerminalNode MEMBERSHIP() { return getToken(VtlParser.MEMBERSHIP, 0); }
		public ComponentIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_componentID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComponentID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComponentID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComponentID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComponentIDContext componentID() throws RecognitionException {
		ComponentIDContext _localctx = new ComponentIDContext(_ctx, getState());
		enterRule(_localctx, 190, RULE_componentID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1656);
			match(IDENTIFIER);
			setState(1659);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,187,_ctx) ) {
			case 1:
				{
				setState(1657);
				match(MEMBERSHIP);
				setState(1658);
				match(IDENTIFIER);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ListsContext extends ParserRuleContext {
		public TerminalNode GLPAREN() { return getToken(VtlParser.GLPAREN, 0); }
		public List<ScalarItemContext> scalarItem() {
			return getRuleContexts(ScalarItemContext.class);
		}
		public ScalarItemContext scalarItem(int i) {
			return getRuleContext(ScalarItemContext.class,i);
		}
		public TerminalNode GRPAREN() { return getToken(VtlParser.GRPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(VtlParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(VtlParser.COMMA, i);
		}
		public ListsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lists; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterLists(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitLists(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitLists(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ListsContext lists() throws RecognitionException {
		ListsContext _localctx = new ListsContext(_ctx, getState());
		enterRule(_localctx, 192, RULE_lists);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1661);
			match(GLPAREN);
			setState(1662);
			scalarItem();
			setState(1667);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(1663);
				match(COMMA);
				setState(1664);
				scalarItem();
				}
				}
				setState(1669);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1670);
			match(GRPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ErCodeContext extends ParserRuleContext {
		public TerminalNode ERRORCODE() { return getToken(VtlParser.ERRORCODE, 0); }
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public ErCodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_erCode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterErCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitErCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitErCode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ErCodeContext erCode() throws RecognitionException {
		ErCodeContext _localctx = new ErCodeContext(_ctx, getState());
		enterRule(_localctx, 194, RULE_erCode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1672);
			match(ERRORCODE);
			setState(1673);
			constant();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ErLevelContext extends ParserRuleContext {
		public TerminalNode ERRORLEVEL() { return getToken(VtlParser.ERRORLEVEL, 0); }
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public ErLevelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_erLevel; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterErLevel(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitErLevel(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitErLevel(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ErLevelContext erLevel() throws RecognitionException {
		ErLevelContext _localctx = new ErLevelContext(_ctx, getState());
		enterRule(_localctx, 196, RULE_erLevel);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1675);
			match(ERRORLEVEL);
			setState(1676);
			constant();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonOperandContext extends ParserRuleContext {
		public TerminalNode MT() { return getToken(VtlParser.MT, 0); }
		public TerminalNode ME() { return getToken(VtlParser.ME, 0); }
		public TerminalNode LE() { return getToken(VtlParser.LE, 0); }
		public TerminalNode LT() { return getToken(VtlParser.LT, 0); }
		public TerminalNode EQ() { return getToken(VtlParser.EQ, 0); }
		public TerminalNode NEQ() { return getToken(VtlParser.NEQ, 0); }
		public ComparisonOperandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparisonOperand; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComparisonOperand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComparisonOperand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComparisonOperand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComparisonOperandContext comparisonOperand() throws RecognitionException {
		ComparisonOperandContext _localctx = new ComparisonOperandContext(_ctx, getState());
		enterRule(_localctx, 198, RULE_comparisonOperand);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1678);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 8064L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OptionalExprContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public OptionalExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_optionalExpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOptionalExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOptionalExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOptionalExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OptionalExprContext optionalExpr() throws RecognitionException {
		OptionalExprContext _localctx = new OptionalExprContext(_ctx, getState());
		enterRule(_localctx, 200, RULE_optionalExpr);
		try {
			setState(1682);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
			case PLUS:
			case MINUS:
			case EVAL:
			case IF:
			case CURRENT_DATE:
			case NOT:
			case BETWEEN:
			case NULL_CONSTANT:
			case ISNULL:
			case UNION:
			case SYMDIFF:
			case INTERSECT:
			case CHECK:
			case EXISTS_IN:
			case MIN:
			case MAX:
			case ABS:
			case LN:
			case LOG:
			case TRUNC:
			case ROUND:
			case POWER:
			case MOD:
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case SUBSTR:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case EXP:
			case CHARSET_MATCH:
			case NVL:
			case HIERARCHY:
			case LTRIM:
			case RTRIM:
			case INSTR:
			case REPLACE:
			case CEIL:
			case FLOOR:
			case SQRT:
			case SETDIFF:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
			case LAG:
			case LEAD:
			case RATIO_TO_REPORT:
			case FILL_TIME_SERIES:
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
			case TIMESHIFT:
			case INNER_JOIN:
			case LEFT_JOIN:
			case CROSS_JOIN:
			case FULL_JOIN:
			case PERIOD_INDICATOR:
			case TIME_AGG:
			case CAST:
			case CHECK_DATAPOINT:
			case CHECK_HIERARCHY:
			case INTEGER_CONSTANT:
			case NUMBER_CONSTANT:
			case BOOLEAN_CONSTANT:
			case STRING_CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1680);
				expr(0);
				}
				break;
			case OPTIONAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1681);
				match(OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OptionalExprComponentContext extends ParserRuleContext {
		public ExprComponentContext exprComponent() {
			return getRuleContext(ExprComponentContext.class,0);
		}
		public TerminalNode OPTIONAL() { return getToken(VtlParser.OPTIONAL, 0); }
		public OptionalExprComponentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_optionalExprComponent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOptionalExprComponent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOptionalExprComponent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOptionalExprComponent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OptionalExprComponentContext optionalExprComponent() throws RecognitionException {
		OptionalExprComponentContext _localctx = new OptionalExprComponentContext(_ctx, getState());
		enterRule(_localctx, 202, RULE_optionalExprComponent);
		try {
			setState(1686);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
			case PLUS:
			case MINUS:
			case EVAL:
			case IF:
			case CURRENT_DATE:
			case NOT:
			case BETWEEN:
			case NULL_CONSTANT:
			case ISNULL:
			case RANK:
			case MIN:
			case MAX:
			case ABS:
			case LN:
			case LOG:
			case TRUNC:
			case ROUND:
			case POWER:
			case MOD:
			case LEN:
			case TRIM:
			case UCASE:
			case LCASE:
			case SUBSTR:
			case SUM:
			case AVG:
			case MEDIAN:
			case COUNT:
			case EXP:
			case CHARSET_MATCH:
			case NVL:
			case LTRIM:
			case RTRIM:
			case INSTR:
			case REPLACE:
			case CEIL:
			case FLOOR:
			case SQRT:
			case STDDEV_POP:
			case STDDEV_SAMP:
			case VAR_POP:
			case VAR_SAMP:
			case FIRST_VALUE:
			case LAST_VALUE:
			case LAG:
			case LEAD:
			case RATIO_TO_REPORT:
			case FILL_TIME_SERIES:
			case FLOW_TO_STOCK:
			case STOCK_TO_FLOW:
			case TIMESHIFT:
			case PERIOD_INDICATOR:
			case TIME_AGG:
			case CAST:
			case INTEGER_CONSTANT:
			case NUMBER_CONSTANT:
			case BOOLEAN_CONSTANT:
			case STRING_CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1684);
				exprComponent(0);
				}
				break;
			case OPTIONAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1685);
				match(OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComponentRoleContext extends ParserRuleContext {
		public TerminalNode MEASURE() { return getToken(VtlParser.MEASURE, 0); }
		public TerminalNode COMPONENT() { return getToken(VtlParser.COMPONENT, 0); }
		public TerminalNode DIMENSION() { return getToken(VtlParser.DIMENSION, 0); }
		public TerminalNode ATTRIBUTE() { return getToken(VtlParser.ATTRIBUTE, 0); }
		public ViralAttributeContext viralAttribute() {
			return getRuleContext(ViralAttributeContext.class,0);
		}
		public ComponentRoleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_componentRole; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterComponentRole(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitComponentRole(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitComponentRole(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComponentRoleContext componentRole() throws RecognitionException {
		ComponentRoleContext _localctx = new ComponentRoleContext(_ctx, getState());
		enterRule(_localctx, 204, RULE_componentRole);
		try {
			setState(1693);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MEASURE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1688);
				match(MEASURE);
				}
				break;
			case COMPONENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1689);
				match(COMPONENT);
				}
				break;
			case DIMENSION:
				enterOuterAlt(_localctx, 3);
				{
				setState(1690);
				match(DIMENSION);
				}
				break;
			case ATTRIBUTE:
				enterOuterAlt(_localctx, 4);
				{
				setState(1691);
				match(ATTRIBUTE);
				}
				break;
			case VIRAL:
				enterOuterAlt(_localctx, 5);
				{
				setState(1692);
				viralAttribute();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ViralAttributeContext extends ParserRuleContext {
		public TerminalNode VIRAL() { return getToken(VtlParser.VIRAL, 0); }
		public TerminalNode ATTRIBUTE() { return getToken(VtlParser.ATTRIBUTE, 0); }
		public ViralAttributeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_viralAttribute; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterViralAttribute(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitViralAttribute(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitViralAttribute(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ViralAttributeContext viralAttribute() throws RecognitionException {
		ViralAttributeContext _localctx = new ViralAttributeContext(_ctx, getState());
		enterRule(_localctx, 206, RULE_viralAttribute);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1695);
			match(VIRAL);
			setState(1696);
			match(ATTRIBUTE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueDomainIDContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public ValueDomainIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueDomainID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterValueDomainID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitValueDomainID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitValueDomainID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueDomainIDContext valueDomainID() throws RecognitionException {
		ValueDomainIDContext _localctx = new ValueDomainIDContext(_ctx, getState());
		enterRule(_localctx, 208, RULE_valueDomainID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1698);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OperatorIDContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public OperatorIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operatorID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterOperatorID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitOperatorID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitOperatorID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OperatorIDContext operatorID() throws RecognitionException {
		OperatorIDContext _localctx = new OperatorIDContext(_ctx, getState());
		enterRule(_localctx, 210, RULE_operatorID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1700);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RoutineNameContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(VtlParser.IDENTIFIER, 0); }
		public RoutineNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_routineName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRoutineName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRoutineName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRoutineName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RoutineNameContext routineName() throws RecognitionException {
		RoutineNameContext _localctx = new RoutineNameContext(_ctx, getState());
		enterRule(_localctx, 212, RULE_routineName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1702);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConstantContext extends ParserRuleContext {
		public TerminalNode INTEGER_CONSTANT() { return getToken(VtlParser.INTEGER_CONSTANT, 0); }
		public TerminalNode NUMBER_CONSTANT() { return getToken(VtlParser.NUMBER_CONSTANT, 0); }
		public TerminalNode BOOLEAN_CONSTANT() { return getToken(VtlParser.BOOLEAN_CONSTANT, 0); }
		public TerminalNode STRING_CONSTANT() { return getToken(VtlParser.STRING_CONSTANT, 0); }
		public TerminalNode NULL_CONSTANT() { return getToken(VtlParser.NULL_CONSTANT, 0); }
		public ConstantContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constant; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterConstant(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitConstant(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitConstant(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstantContext constant() throws RecognitionException {
		ConstantContext _localctx = new ConstantContext(_ctx, getState());
		enterRule(_localctx, 214, RULE_constant);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1704);
			_la = _input.LA(1);
			if ( !(_la==NULL_CONSTANT || ((((_la - 229)) & ~0x3f) == 0 && ((1L << (_la - 229)) & 15L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BasicScalarTypeContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(VtlParser.STRING, 0); }
		public TerminalNode INTEGER() { return getToken(VtlParser.INTEGER, 0); }
		public TerminalNode NUMBER() { return getToken(VtlParser.NUMBER, 0); }
		public TerminalNode BOOLEAN() { return getToken(VtlParser.BOOLEAN, 0); }
		public TerminalNode DATE() { return getToken(VtlParser.DATE, 0); }
		public TerminalNode TIME() { return getToken(VtlParser.TIME, 0); }
		public TerminalNode TIME_PERIOD() { return getToken(VtlParser.TIME_PERIOD, 0); }
		public TerminalNode DURATION() { return getToken(VtlParser.DURATION, 0); }
		public TerminalNode SCALAR() { return getToken(VtlParser.SCALAR, 0); }
		public BasicScalarTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_basicScalarType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterBasicScalarType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitBasicScalarType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitBasicScalarType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BasicScalarTypeContext basicScalarType() throws RecognitionException {
		BasicScalarTypeContext _localctx = new BasicScalarTypeContext(_ctx, getState());
		enterRule(_localctx, 216, RULE_basicScalarType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1706);
			_la = _input.LA(1);
			if ( !(((((_la - 156)) & ~0x3f) == 0 && ((1L << (_la - 156)) & 4398046511231L) != 0) || _la==SCALAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RetainTypeContext extends ParserRuleContext {
		public TerminalNode BOOLEAN_CONSTANT() { return getToken(VtlParser.BOOLEAN_CONSTANT, 0); }
		public TerminalNode ALL() { return getToken(VtlParser.ALL, 0); }
		public RetainTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_retainType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).enterRetainType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof IVtlListener ) ((IVtlListener)listener).exitRetainType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof VtlVisitor ) return ((IVtlVisitor<? extends T>)visitor).visitRetainType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RetainTypeContext retainType() throws RecognitionException {
		RetainTypeContext _localctx = new RetainTypeContext(_ctx, getState());
		enterRule(_localctx, 218, RULE_retainType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1708);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==BOOLEAN_CONSTANT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@Override
	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 2:
			return expr_sempred((ExprContext)_localctx, predIndex);
		case 3:
			return exprComponent_sempred((ExprComponentContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 9);
		case 1:
			return precpred(_ctx, 8);
		case 2:
			return precpred(_ctx, 7);
		case 3:
			return precpred(_ctx, 5);
		case 4:
			return precpred(_ctx, 4);
		case 5:
			return precpred(_ctx, 12);
		case 6:
			return precpred(_ctx, 11);
		case 7:
			return precpred(_ctx, 6);
		}
		return true;
	}
	private boolean exprComponent_sempred(ExprComponentContext _localctx, int predIndex) {
		switch (predIndex) {
		case 8:
			return precpred(_ctx, 9);
		case 9:
			return precpred(_ctx, 8);
		case 10:
			return precpred(_ctx, 7);
		case 11:
			return precpred(_ctx, 5);
		case 12:
			return precpred(_ctx, 4);
		case 13:
			return precpred(_ctx, 6);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u00ed\u06af\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007"+
		"\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007"+
		"\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007"+
		"\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007"+
		"\u001e\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007"+
		"\"\u0002#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007"+
		"\'\u0002(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007"+
		",\u0002-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u0007"+
		"1\u00022\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u0007"+
		"6\u00027\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007"+
		";\u0002<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007"+
		"@\u0002A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007"+
		"E\u0002F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007"+
		"J\u0002K\u0007K\u0002L\u0007L\u0002M\u0007M\u0002N\u0007N\u0002O\u0007"+
		"O\u0002P\u0007P\u0002Q\u0007Q\u0002R\u0007R\u0002S\u0007S\u0002T\u0007"+
		"T\u0002U\u0007U\u0002V\u0007V\u0002W\u0007W\u0002X\u0007X\u0002Y\u0007"+
		"Y\u0002Z\u0007Z\u0002[\u0007[\u0002\\\u0007\\\u0002]\u0007]\u0002^\u0007"+
		"^\u0002_\u0007_\u0002`\u0007`\u0002a\u0007a\u0002b\u0007b\u0002c\u0007"+
		"c\u0002d\u0007d\u0002e\u0007e\u0002f\u0007f\u0002g\u0007g\u0002h\u0007"+
		"h\u0002i\u0007i\u0002j\u0007j\u0002k\u0007k\u0002l\u0007l\u0002m\u0007"+
		"m\u0001\u0000\u0001\u0000\u0001\u0000\u0005\u0000\u00e0\b\u0000\n\u0000"+
		"\f\u0000\u00e3\t\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0003\u0001\u00f0\b\u0001\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0003\u0002\u0103\b\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0003\u0002\u0121\b\u0002\u0005\u0002\u0123\b"+
		"\u0002\n\u0002\f\u0002\u0126\t\u0002\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0003\u0003\u0139\b\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0003\u0003\u014f\b\u0003\u0005\u0003\u0151\b\u0003\n\u0003\f\u0003\u0154"+
		"\t\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001"+
		"\u0004\u0001\u0004\u0001\u0004\u0003\u0004\u015e\b\u0004\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005\u016c"+
		"\b\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0001\u0006\u0003\u0006\u0175\b\u0006\u0001\u0007\u0001\u0007\u0001"+
		"\u0007\u0001\u0007\u0005\u0007\u017b\b\u0007\n\u0007\f\u0007\u017e\t\u0007"+
		"\u0001\b\u0001\b\u0001\b\u0001\b\u0003\b\u0184\b\b\u0003\b\u0186\b\b\u0001"+
		"\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0005\n\u018f\b\n\n"+
		"\n\f\n\u0192\t\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0005"+
		"\u000b\u0198\b\u000b\n\u000b\f\u000b\u019b\t\u000b\u0001\f\u0001\f\u0001"+
		"\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0005\r\u01aa\b\r\n\r\f\r\u01ad\t\r\u0001\u000e\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0005\u000e\u01b3\b\u000e\n\u000e\f\u000e\u01b6"+
		"\t\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0003\u000f\u01c4\b\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0005\u0010\u01cd\b\u0010\n"+
		"\u0010\f\u0010\u01d0\t\u0010\u0003\u0010\u01d2\b\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0003\u0010\u01d7\b\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0003\u0010\u01f8"+
		"\b\u0010\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0005"+
		"\u0011\u01ff\b\u0011\n\u0011\f\u0011\u0202\t\u0011\u0003\u0011\u0204\b"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0003\u0011\u020e\b\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0003\u0011\u0213\b\u0011\u0005\u0011\u0215\b\u0011"+
		"\n\u0011\f\u0011\u0218\t\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0003"+
		"\u0011\u021d\b\u0011\u0001\u0011\u0001\u0011\u0003\u0011\u0221\b\u0011"+
		"\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0003\u0011\u022b\b\u0011\u0001\u0011\u0001\u0011"+
		"\u0003\u0011\u022f\b\u0011\u0001\u0011\u0001\u0011\u0003\u0011\u0233\b"+
		"\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0005"+
		"\u0012\u023a\b\u0012\n\u0012\f\u0012\u023d\t\u0012\u0003\u0012\u023f\b"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u0249\b\u0012\u0001\u0012\u0001"+
		"\u0012\u0003\u0012\u024d\b\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u0257"+
		"\b\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u025c\b\u0012"+
		"\u0005\u0012\u025e\b\u0012\n\u0012\f\u0012\u0261\t\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0003\u0012\u0266\b\u0012\u0001\u0012\u0001\u0012\u0003"+
		"\u0012\u026a\b\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u026e\b\u0012"+
		"\u0001\u0013\u0001\u0013\u0003\u0013\u0272\b\u0013\u0001\u0014\u0001\u0014"+
		"\u0003\u0014\u0276\b\u0014\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0003\u0015\u0286\b\u0015"+
		"\u0001\u0015\u0001\u0015\u0003\u0015\u028a\b\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0003\u0015\u0295\b\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0003\u0015\u02a0\b\u0015\u0001\u0015\u0001\u0015\u0003\u0015\u02a4\b"+
		"\u0015\u0001\u0015\u0001\u0015\u0003\u0015\u02a8\b\u0015\u0001\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0016\u0003\u0016\u02b8\b\u0016\u0001\u0016\u0001\u0016\u0003\u0016\u02bc"+
		"\b\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0003\u0016\u02c7\b\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0003\u0016\u02d2\b\u0016\u0001\u0016\u0001"+
		"\u0016\u0003\u0016\u02d6\b\u0016\u0001\u0016\u0001\u0016\u0003\u0016\u02da"+
		"\b\u0016\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0003\u0017\u02e6"+
		"\b\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0003\u0017\u02f1\b\u0017\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u02fd\b\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0308\b\u0018\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0003\u0019\u0326\b\u0019\u0001\u0019\u0001"+
		"\u0019\u0003\u0019\u032a\b\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001"+
		"\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001"+
		"\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001"+
		"\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0003"+
		"\u001a\u0341\b\u001a\u0001\u001b\u0001\u001b\u0001\u001b\u0003\u001b\u0346"+
		"\b\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0003\u001b\u034e\b\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0003\u001b\u0363\b\u001b\u0001"+
		"\u001b\u0001\u001b\u0003\u001b\u0367\b\u001b\u0001\u001b\u0001\u001b\u0003"+
		"\u001b\u036b\b\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0003"+
		"\u001b\u0371\b\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0003\u001c\u0376"+
		"\b\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0003\u001c\u037e\b\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0003\u001c\u0393\b\u001c\u0001"+
		"\u001c\u0001\u001c\u0003\u001c\u0397\b\u001c\u0001\u001c\u0001\u001c\u0003"+
		"\u001c\u039b\b\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0003"+
		"\u001c\u03a1\b\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001"+
		"\u001d\u0004\u001d\u03a8\b\u001d\u000b\u001d\f\u001d\u03a9\u0001\u001d"+
		"\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d"+
		"\u0004\u001d\u03b3\b\u001d\u000b\u001d\f\u001d\u03b4\u0001\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001"+
		"\u001d\u0001\u001d\u0003\u001d\u03c0\b\u001d\u0001\u001e\u0001\u001e\u0001"+
		"\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0003\u001e\u03c8\b\u001e\u0001"+
		"\u001e\u0001\u001e\u0003\u001e\u03cc\b\u001e\u0001\u001e\u0003\u001e\u03cf"+
		"\b\u001e\u0001\u001e\u0003\u001e\u03d2\b\u001e\u0001\u001e\u0003\u001e"+
		"\u03d5\b\u001e\u0001\u001e\u0001\u001e\u0001\u001f\u0001\u001f\u0001\u001f"+
		"\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f"+
		"\u0005\u001f\u03e2\b\u001f\n\u001f\f\u001f\u03e5\t\u001f\u0003\u001f\u03e7"+
		"\b\u001f\u0001\u001f\u0003\u001f\u03ea\b\u001f\u0001\u001f\u0001\u001f"+
		"\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f"+
		"\u0003\u001f\u03f4\b\u001f\u0001\u001f\u0001\u001f\u0003\u001f\u03f8\b"+
		"\u001f\u0001\u001f\u0003\u001f\u03fb\b\u001f\u0001\u001f\u0003\u001f\u03fe"+
		"\b\u001f\u0001\u001f\u0003\u001f\u0401\b\u001f\u0001\u001f\u0001\u001f"+
		"\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0003\u001f\u0409\b\u001f"+
		"\u0001\u001f\u0003\u001f\u040c\b\u001f\u0001\u001f\u0003\u001f\u040f\b"+
		"\u001f\u0001\u001f\u0003\u001f\u0412\b\u001f\u0001\u001f\u0001\u001f\u0003"+
		"\u001f\u0416\b\u001f\u0001 \u0001 \u0001 \u0001 \u0001 \u0001 \u0001 "+
		"\u0001!\u0001!\u0001!\u0001!\u0001!\u0001!\u0001!\u0001\"\u0001\"\u0001"+
		"\"\u0001\"\u0001\"\u0001\"\u0001\"\u0001\"\u0003\"\u042e\b\"\u0001#\u0001"+
		"#\u0001#\u0001#\u0001#\u0003#\u0435\b#\u0003#\u0437\b#\u0001#\u0001#\u0001"+
		"$\u0001$\u0001$\u0001$\u0001$\u0001$\u0003$\u0441\b$\u0001$\u0003$\u0444"+
		"\b$\u0001$\u0003$\u0447\b$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001"+
		"$\u0001$\u0001$\u0003$\u0452\b$\u0003$\u0454\b$\u0001$\u0001$\u0001$\u0003"+
		"$\u0459\b$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001$\u0001"+
		"$\u0001$\u0001$\u0001$\u0001$\u0001$\u0003$\u0469\b$\u0001%\u0001%\u0001"+
		"%\u0001%\u0001%\u0001%\u0003%\u0471\b%\u0001%\u0003%\u0474\b%\u0001%\u0003"+
		"%\u0477\b%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001"+
		"%\u0003%\u0482\b%\u0003%\u0484\b%\u0001%\u0001%\u0001%\u0003%\u0489\b"+
		"%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001"+
		"%\u0003%\u0495\b%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001"+
		"%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0003%\u04a5\b%\u0001&\u0001"+
		"&\u0001&\u0001&\u0001\'\u0001\'\u0001\'\u0005\'\u04ae\b\'\n\'\f\'\u04b1"+
		"\t\'\u0001(\u0003(\u04b4\b(\u0001(\u0001(\u0001(\u0001(\u0001)\u0003)"+
		"\u04bb\b)\u0001)\u0001)\u0001)\u0001)\u0001*\u0001*\u0001*\u0001*\u0001"+
		"+\u0001+\u0001+\u0001+\u0001+\u0001+\u0001+\u0001+\u0003+\u04cd\b+\u0001"+
		"+\u0001+\u0003+\u04d1\b+\u0001,\u0001,\u0001,\u0005,\u04d6\b,\n,\f,\u04d9"+
		"\t,\u0001-\u0001-\u0001-\u0005-\u04de\b-\n-\f-\u04e1\t-\u0001-\u0001-"+
		"\u0001-\u0001-\u0005-\u04e7\b-\n-\f-\u04ea\t-\u0003-\u04ec\b-\u0001.\u0001"+
		".\u0001.\u0003.\u04f1\b.\u0001/\u0003/\u04f4\b/\u0001/\u0001/\u0001/\u0003"+
		"/\u04f9\b/\u0001/\u0003/\u04fc\b/\u0001/\u0003/\u04ff\b/\u00010\u0001"+
		"0\u00010\u00011\u00011\u00011\u00011\u00011\u00051\u0509\b1\n1\f1\u050c"+
		"\t1\u00012\u00012\u00012\u00012\u00012\u00052\u0513\b2\n2\f2\u0516\t2"+
		"\u00013\u00013\u00033\u051a\b3\u00014\u00014\u00014\u00034\u051f\b4\u0001"+
		"4\u00014\u00014\u00014\u00014\u00015\u00015\u00016\u00016\u00016\u0001"+
		"6\u00016\u00016\u00016\u00016\u00016\u00016\u00016\u00036\u0533\b6\u0001"+
		"7\u00017\u00017\u00017\u00017\u00057\u053a\b7\n7\f7\u053d\t7\u00017\u0001"+
		"7\u00017\u00037\u0542\b7\u00018\u00018\u00018\u00019\u00019\u00019\u0001"+
		"9\u00039\u054b\b9\u0001:\u0001:\u0001:\u0003:\u0550\b:\u0001;\u0001;\u0003"+
		";\u0554\b;\u0001<\u0001<\u0001<\u0001<\u0001<\u0003<\u055b\b<\u0001=\u0001"+
		"=\u0001=\u0003=\u0560\b=\u0001>\u0001>\u0003>\u0564\b>\u0001>\u0003>\u0567"+
		"\b>\u0001>\u0003>\u056a\b>\u0001>\u0003>\u056d\b>\u0001?\u0001?\u0001"+
		"?\u0001?\u0001?\u0003?\u0574\b?\u0001@\u0001@\u0001@\u0001@\u0001@\u0005"+
		"@\u057b\b@\n@\f@\u057e\t@\u0001@\u0001@\u0003@\u0582\b@\u0001A\u0001A"+
		"\u0003A\u0586\bA\u0001B\u0001B\u0001B\u0001B\u0001B\u0003B\u058d\bB\u0001"+
		"C\u0001C\u0001C\u0001C\u0001C\u0001C\u0005C\u0595\bC\nC\fC\u0598\tC\u0001"+
		"C\u0001C\u0003C\u059c\bC\u0001C\u0001C\u0001C\u0001C\u0001C\u0005C\u05a3"+
		"\bC\nC\fC\u05a6\tC\u0001C\u0001C\u0003C\u05aa\bC\u0003C\u05ac\bC\u0001"+
		"D\u0001D\u0001D\u0001D\u0001D\u0001D\u0001D\u0001D\u0005D\u05b6\bD\nD"+
		"\fD\u05b9\tD\u0001D\u0001D\u0003D\u05bd\bD\u0001D\u0003D\u05c0\bD\u0001"+
		"D\u0001D\u0001D\u0001D\u0001D\u0001D\u0001D\u0005D\u05c9\bD\nD\fD\u05cc"+
		"\tD\u0001D\u0001D\u0003D\u05d0\bD\u0001D\u0001D\u0003D\u05d4\bD\u0003"+
		"D\u05d6\bD\u0001E\u0001E\u0001F\u0001F\u0001G\u0001G\u0001G\u0001G\u0005"+
		"G\u05e0\bG\nG\fG\u05e3\tG\u0001H\u0001H\u0001H\u0003H\u05e8\bH\u0001I"+
		"\u0001I\u0001I\u0005I\u05ed\bI\nI\fI\u05f0\tI\u0001J\u0001J\u0003J\u05f4"+
		"\bJ\u0001J\u0001J\u0001J\u0001J\u0003J\u05fa\bJ\u0001J\u0001J\u0003J\u05fe"+
		"\bJ\u0001J\u0003J\u0601\bJ\u0001K\u0001K\u0001K\u0005K\u0606\bK\nK\fK"+
		"\u0609\tK\u0001L\u0001L\u0003L\u060d\bL\u0001L\u0001L\u0003L\u0611\bL"+
		"\u0001L\u0003L\u0614\bL\u0001M\u0001M\u0001M\u0003M\u0619\bM\u0001M\u0001"+
		"M\u0001M\u0001N\u0001N\u0001N\u0005N\u0621\bN\nN\fN\u0624\tN\u0001O\u0001"+
		"O\u0001O\u0001O\u0003O\u062a\bO\u0001O\u0001O\u0003O\u062e\bO\u0001O\u0001"+
		"O\u0005O\u0632\bO\nO\fO\u0635\tO\u0001P\u0003P\u0638\bP\u0001P\u0001P"+
		"\u0001P\u0001P\u0001P\u0003P\u063f\bP\u0001Q\u0001Q\u0001R\u0001R\u0001"+
		"R\u0001R\u0001R\u0001R\u0001R\u0001R\u0005R\u064b\bR\nR\fR\u064e\tR\u0001"+
		"R\u0001R\u0003R\u0652\bR\u0001S\u0001S\u0001S\u0003S\u0657\bS\u0001T\u0001"+
		"T\u0003T\u065b\bT\u0001U\u0001U\u0001V\u0001V\u0001W\u0001W\u0001W\u0001"+
		"W\u0005W\u0665\bW\nW\fW\u0668\tW\u0001X\u0001X\u0001Y\u0001Y\u0001Y\u0001"+
		"Z\u0001Z\u0001[\u0001[\u0001\\\u0001\\\u0001]\u0001]\u0001^\u0001^\u0001"+
		"_\u0001_\u0001_\u0003_\u067c\b_\u0001`\u0001`\u0001`\u0001`\u0005`\u0682"+
		"\b`\n`\f`\u0685\t`\u0001`\u0001`\u0001a\u0001a\u0001a\u0001b\u0001b\u0001"+
		"b\u0001c\u0001c\u0001d\u0001d\u0003d\u0693\bd\u0001e\u0001e\u0003e\u0697"+
		"\be\u0001f\u0001f\u0001f\u0001f\u0001f\u0003f\u069e\bf\u0001g\u0001g\u0001"+
		"g\u0001h\u0001h\u0001i\u0001i\u0001j\u0001j\u0001k\u0001k\u0001l\u0001"+
		"l\u0001m\u0001m\u0001m\u0000\u0002\u0004\u0006n\u0000\u0002\u0004\u0006"+
		"\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,."+
		"02468:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082\u0084\u0086\u0088"+
		"\u008a\u008c\u008e\u0090\u0092\u0094\u0096\u0098\u009a\u009c\u009e\u00a0"+
		"\u00a2\u00a4\u00a6\u00a8\u00aa\u00ac\u00ae\u00b0\u00b2\u00b4\u00b6\u00b8"+
		"\u00ba\u00bc\u00be\u00c0\u00c2\u00c4\u00c6\u00c8\u00ca\u00cc\u00ce\u00d0"+
		"\u00d2\u00d4\u00d6\u00d8\u00da\u0000%\u0002\u0000\r\u000e\'\'\u0001\u0000"+
		"\u000f\u0010\u0002\u0000\r\u000eRR\u0001\u0000%&\u0001\u0000)*\u0001\u0000"+
		"\u001e\u001f\u0002\u0000\u00be\u00be\u00c0\u00c0\u0001\u0000\u00b5\u00b6"+
		"\u0001\u0000\u00b7\u00b8\u0003\u0000QQSUwx\u0004\u0000IIKK``{}\u0001\u0000"+
		"MN\u0002\u0000LLOP\u0002\u0000<<\u00c5\u00c5\u0001\u0000\u0096\u0097\u0002"+
		"\u0000gg\u00e8\u00e8\u0001\u0000FG\u0002\u000000\u007f\u007f\u0002\u0000"+
		"<<hh\u0003\u0000DEWZ\u0080\u0083\u0004\u0000DEWZ\u0080\u0083\u0087\u0088"+
		"\u0001\u0000\u0089\u008a\u0001\u0000BC\u0002\u0000@@\u0085\u0085\u0001"+
		"\u0000ij\u0001\u0000\r\u000e\u0002\u0000\u00e5\u00e6\u00e9\u00e9\u0002"+
		"\u0000\r\r\u000f\u000f\u0003\u0000<<hh\u00dc\u00dc\u0001\u0000\u00d5\u00da"+
		"\u0002\u0000mm\u00d0\u00d0\u0003\u0000mmtt\u00cf\u00cf\u0002\u0000<<\u00d4"+
		"\u00d4\u0001\u0000\u0007\f\u0002\u0000++\u00e5\u00e8\u0003\u0000\u009c"+
		"\u00a2\u00c6\u00c6\u00dd\u00dd\u0002\u0000<<\u00e7\u00e7\u0752\u0000\u00e1"+
		"\u0001\u0000\u0000\u0000\u0002\u00ef\u0001\u0000\u0000\u0000\u0004\u0102"+
		"\u0001\u0000\u0000\u0000\u0006\u0138\u0001\u0000\u0000\u0000\b\u015d\u0001"+
		"\u0000\u0000\u0000\n\u016b\u0001\u0000\u0000\u0000\f\u0174\u0001\u0000"+
		"\u0000\u0000\u000e\u0176\u0001\u0000\u0000\u0000\u0010\u017f\u0001\u0000"+
		"\u0000\u0000\u0012\u0187\u0001\u0000\u0000\u0000\u0014\u018a\u0001\u0000"+
		"\u0000\u0000\u0016\u0193\u0001\u0000\u0000\u0000\u0018\u019c\u0001\u0000"+
		"\u0000\u0000\u001a\u01a1\u0001\u0000\u0000\u0000\u001c\u01ae\u0001\u0000"+
		"\u0000\u0000\u001e\u01c3\u0001\u0000\u0000\u0000 \u01f7\u0001\u0000\u0000"+
		"\u0000\"\u0232\u0001\u0000\u0000\u0000$\u026d\u0001\u0000\u0000\u0000"+
		"&\u0271\u0001\u0000\u0000\u0000(\u0275\u0001\u0000\u0000\u0000*\u02a7"+
		"\u0001\u0000\u0000\u0000,\u02d9\u0001\u0000\u0000\u0000.\u02f0\u0001\u0000"+
		"\u0000\u00000\u0307\u0001\u0000\u0000\u00002\u0329\u0001\u0000\u0000\u0000"+
		"4\u0340\u0001\u0000\u0000\u00006\u0370\u0001\u0000\u0000\u00008\u03a0"+
		"\u0001\u0000\u0000\u0000:\u03bf\u0001\u0000\u0000\u0000<\u03c1\u0001\u0000"+
		"\u0000\u0000>\u0415\u0001\u0000\u0000\u0000@\u0417\u0001\u0000\u0000\u0000"+
		"B\u041e\u0001\u0000\u0000\u0000D\u042d\u0001\u0000\u0000\u0000F\u042f"+
		"\u0001\u0000\u0000\u0000H\u0468\u0001\u0000\u0000\u0000J\u04a4\u0001\u0000"+
		"\u0000\u0000L\u04a6\u0001\u0000\u0000\u0000N\u04aa\u0001\u0000\u0000\u0000"+
		"P\u04b3\u0001\u0000\u0000\u0000R\u04ba\u0001\u0000\u0000\u0000T\u04c0"+
		"\u0001\u0000\u0000\u0000V\u04d0\u0001\u0000\u0000\u0000X\u04d2\u0001\u0000"+
		"\u0000\u0000Z\u04da\u0001\u0000\u0000\u0000\\\u04ed\u0001\u0000\u0000"+
		"\u0000^\u04f3\u0001\u0000\u0000\u0000`\u0500\u0001\u0000\u0000\u0000b"+
		"\u0503\u0001\u0000\u0000\u0000d\u050d\u0001\u0000\u0000\u0000f\u0517\u0001"+
		"\u0000\u0000\u0000h\u051e\u0001\u0000\u0000\u0000j\u0525\u0001\u0000\u0000"+
		"\u0000l\u0532\u0001\u0000\u0000\u0000n\u0541\u0001\u0000\u0000\u0000p"+
		"\u0543\u0001\u0000\u0000\u0000r\u0546\u0001\u0000\u0000\u0000t\u054f\u0001"+
		"\u0000\u0000\u0000v\u0553\u0001\u0000\u0000\u0000x\u055a\u0001\u0000\u0000"+
		"\u0000z\u055f\u0001\u0000\u0000\u0000|\u0563\u0001\u0000\u0000\u0000~"+
		"\u056e\u0001\u0000\u0000\u0000\u0080\u0575\u0001\u0000\u0000\u0000\u0082"+
		"\u0585\u0001\u0000\u0000\u0000\u0084\u0587\u0001\u0000\u0000\u0000\u0086"+
		"\u05ab\u0001\u0000\u0000\u0000\u0088\u05d5\u0001\u0000\u0000\u0000\u008a"+
		"\u05d7\u0001\u0000\u0000\u0000\u008c\u05d9\u0001\u0000\u0000\u0000\u008e"+
		"\u05db\u0001\u0000\u0000\u0000\u0090\u05e4\u0001\u0000\u0000\u0000\u0092"+
		"\u05e9\u0001\u0000\u0000\u0000\u0094\u05f3\u0001\u0000\u0000\u0000\u0096"+
		"\u0602\u0001\u0000\u0000\u0000\u0098\u060c\u0001\u0000\u0000\u0000\u009a"+
		"\u0615\u0001\u0000\u0000\u0000\u009c\u061d\u0001\u0000\u0000\u0000\u009e"+
		"\u0629\u0001\u0000\u0000\u0000\u00a0\u0637\u0001\u0000\u0000\u0000\u00a2"+
		"\u0640\u0001\u0000\u0000\u0000\u00a4\u0651\u0001\u0000\u0000\u0000\u00a6"+
		"\u0653\u0001\u0000\u0000\u0000\u00a8\u0658\u0001\u0000\u0000\u0000\u00aa"+
		"\u065c\u0001\u0000\u0000\u0000\u00ac\u065e\u0001\u0000\u0000\u0000\u00ae"+
		"\u0660\u0001\u0000\u0000\u0000\u00b0\u0669\u0001\u0000\u0000\u0000\u00b2"+
		"\u066b\u0001\u0000\u0000\u0000\u00b4\u066e\u0001\u0000\u0000\u0000\u00b6"+
		"\u0670\u0001\u0000\u0000\u0000\u00b8\u0672\u0001\u0000\u0000\u0000\u00ba"+
		"\u0674\u0001\u0000\u0000\u0000\u00bc\u0676\u0001\u0000\u0000\u0000\u00be"+
		"\u0678\u0001\u0000\u0000\u0000\u00c0\u067d\u0001\u0000\u0000\u0000\u00c2"+
		"\u0688\u0001\u0000\u0000\u0000\u00c4\u068b\u0001\u0000\u0000\u0000\u00c6"+
		"\u068e\u0001\u0000\u0000\u0000\u00c8\u0692\u0001\u0000\u0000\u0000\u00ca"+
		"\u0696\u0001\u0000\u0000\u0000\u00cc\u069d\u0001\u0000\u0000\u0000\u00ce"+
		"\u069f\u0001\u0000\u0000\u0000\u00d0\u06a2\u0001\u0000\u0000\u0000\u00d2"+
		"\u06a4\u0001\u0000\u0000\u0000\u00d4\u06a6\u0001\u0000\u0000\u0000\u00d6"+
		"\u06a8\u0001\u0000\u0000\u0000\u00d8\u06aa\u0001\u0000\u0000\u0000\u00da"+
		"\u06ac\u0001\u0000\u0000\u0000\u00dc\u00dd\u0003\u0002\u0001\u0000\u00dd"+
		"\u00de\u0005\u00eb\u0000\u0000\u00de\u00e0\u0001\u0000\u0000\u0000\u00df"+
		"\u00dc\u0001\u0000\u0000\u0000\u00e0\u00e3\u0001\u0000\u0000\u0000\u00e1"+
		"\u00df\u0001\u0000\u0000\u0000\u00e1\u00e2\u0001\u0000\u0000\u0000\u00e2"+
		"\u00e4\u0001\u0000\u0000\u0000\u00e3\u00e1\u0001\u0000\u0000\u0000\u00e4"+
		"\u00e5\u0005\u0000\u0000\u0001\u00e5\u0001\u0001\u0000\u0000\u0000\u00e6"+
		"\u00e7\u0003\u00ba]\u0000\u00e7\u00e8\u0005\u0014\u0000\u0000\u00e8\u00e9"+
		"\u0003\u0004\u0002\u0000\u00e9\u00f0\u0001\u0000\u0000\u0000\u00ea\u00eb"+
		"\u0003\u00ba]\u0000\u00eb\u00ec\u0005p\u0000\u0000\u00ec\u00ed\u0003\u0004"+
		"\u0002\u0000\u00ed\u00f0\u0001\u0000\u0000\u0000\u00ee\u00f0\u0003 \u0010"+
		"\u0000\u00ef\u00e6\u0001\u0000\u0000\u0000\u00ef\u00ea\u0001\u0000\u0000"+
		"\u0000\u00ef\u00ee\u0001\u0000\u0000\u0000\u00f0\u0003\u0001\u0000\u0000"+
		"\u0000\u00f1\u00f2\u0006\u0002\uffff\uffff\u0000\u00f2\u00f3\u0005\u0001"+
		"\u0000\u0000\u00f3\u00f4\u0003\u0004\u0002\u0000\u00f4\u00f5\u0005\u0002"+
		"\u0000\u0000\u00f5\u0103\u0001\u0000\u0000\u0000\u00f6\u0103\u0003\n\u0005"+
		"\u0000\u00f7\u00f8\u0007\u0000\u0000\u0000\u00f8\u0103\u0003\u0004\u0002"+
		"\n\u00f9\u00fa\u0005\u0017\u0000\u0000\u00fa\u00fb\u0003\u0004\u0002\u0000"+
		"\u00fb\u00fc\u0005\u0018\u0000\u0000\u00fc\u00fd\u0003\u0004\u0002\u0000"+
		"\u00fd\u00fe\u0005\u0019\u0000\u0000\u00fe\u00ff\u0003\u0004\u0002\u0003"+
		"\u00ff\u0103\u0001\u0000\u0000\u0000\u0100\u0103\u0003\u00d6k\u0000\u0101"+
		"\u0103\u0003\u00ba]\u0000\u0102\u00f1\u0001\u0000\u0000\u0000\u0102\u00f6"+
		"\u0001\u0000\u0000\u0000\u0102\u00f7\u0001\u0000\u0000\u0000\u0102\u00f9"+
		"\u0001\u0000\u0000\u0000\u0102\u0100\u0001\u0000\u0000\u0000\u0102\u0101"+
		"\u0001\u0000\u0000\u0000\u0103\u0124\u0001\u0000\u0000\u0000\u0104\u0105"+
		"\n\t\u0000\u0000\u0105\u0106\u0007\u0001\u0000\u0000\u0106\u0123\u0003"+
		"\u0004\u0002\n\u0107\u0108\n\b\u0000\u0000\u0108\u0109\u0007\u0002\u0000"+
		"\u0000\u0109\u0123\u0003\u0004\u0002\t\u010a\u010b\n\u0007\u0000\u0000"+
		"\u010b\u010c\u0003\u00c6c\u0000\u010c\u010d\u0003\u0004\u0002\b\u010d"+
		"\u0123\u0001\u0000\u0000\u0000\u010e\u010f\n\u0005\u0000\u0000\u010f\u0110"+
		"\u0005$\u0000\u0000\u0110\u0123\u0003\u0004\u0002\u0006\u0111\u0112\n"+
		"\u0004\u0000\u0000\u0112\u0113\u0007\u0003\u0000\u0000\u0113\u0123\u0003"+
		"\u0004\u0002\u0005\u0114\u0115\n\f\u0000\u0000\u0115\u0116\u0005\u0003"+
		"\u0000\u0000\u0116\u0117\u0003\f\u0006\u0000\u0117\u0118\u0005\u0004\u0000"+
		"\u0000\u0118\u0123\u0001\u0000\u0000\u0000\u0119\u011a\n\u000b\u0000\u0000"+
		"\u011a\u011b\u0005\u0015\u0000\u0000\u011b\u0123\u0003\u00bc^\u0000\u011c"+
		"\u011d\n\u0006\u0000\u0000\u011d\u0120\u0007\u0004\u0000\u0000\u011e\u0121"+
		"\u0003\u00c0`\u0000\u011f\u0121\u0003\u00d0h\u0000\u0120\u011e\u0001\u0000"+
		"\u0000\u0000\u0120\u011f\u0001\u0000\u0000\u0000\u0121\u0123\u0001\u0000"+
		"\u0000\u0000\u0122\u0104\u0001\u0000\u0000\u0000\u0122\u0107\u0001\u0000"+
		"\u0000\u0000\u0122\u010a\u0001\u0000\u0000\u0000\u0122\u010e\u0001\u0000"+
		"\u0000\u0000\u0122\u0111\u0001\u0000\u0000\u0000\u0122\u0114\u0001\u0000"+
		"\u0000\u0000\u0122\u0119\u0001\u0000\u0000\u0000\u0122\u011c\u0001\u0000"+
		"\u0000\u0000\u0123\u0126\u0001\u0000\u0000\u0000\u0124\u0122\u0001\u0000"+
		"\u0000\u0000\u0124\u0125\u0001\u0000\u0000\u0000\u0125\u0005\u0001\u0000"+
		"\u0000\u0000\u0126\u0124\u0001\u0000\u0000\u0000\u0127\u0128\u0006\u0003"+
		"\uffff\uffff\u0000\u0128\u0129\u0005\u0001\u0000\u0000\u0129\u012a\u0003"+
		"\u0006\u0003\u0000\u012a\u012b\u0005\u0002\u0000\u0000\u012b\u0139\u0001"+
		"\u0000\u0000\u0000\u012c\u0139\u0003\b\u0004\u0000\u012d\u012e\u0007\u0000"+
		"\u0000\u0000\u012e\u0139\u0003\u0006\u0003\n\u012f\u0130\u0005\u0017\u0000"+
		"\u0000\u0130\u0131\u0003\u0006\u0003\u0000\u0131\u0132\u0005\u0018\u0000"+
		"\u0000\u0132\u0133\u0003\u0006\u0003\u0000\u0133\u0134\u0005\u0019\u0000"+
		"\u0000\u0134\u0135\u0003\u0006\u0003\u0003\u0135\u0139\u0001\u0000\u0000"+
		"\u0000\u0136\u0139\u0003\u00d6k\u0000\u0137\u0139\u0003\u00be_\u0000\u0138"+
		"\u0127\u0001\u0000\u0000\u0000\u0138\u012c\u0001\u0000\u0000\u0000\u0138"+
		"\u012d\u0001\u0000\u0000\u0000\u0138\u012f\u0001\u0000\u0000\u0000\u0138"+
		"\u0136\u0001\u0000\u0000\u0000\u0138\u0137\u0001\u0000\u0000\u0000\u0139"+
		"\u0152\u0001\u0000\u0000\u0000\u013a\u013b\n\t\u0000\u0000\u013b\u013c"+
		"\u0007\u0001\u0000\u0000\u013c\u0151\u0003\u0006\u0003\n\u013d\u013e\n"+
		"\b\u0000\u0000\u013e\u013f\u0007\u0002\u0000\u0000\u013f\u0151\u0003\u0006"+
		"\u0003\t\u0140\u0141\n\u0007\u0000\u0000\u0141\u0142\u0003\u00c6c\u0000"+
		"\u0142\u0143\u0003\u0006\u0003\b\u0143\u0151\u0001\u0000\u0000\u0000\u0144"+
		"\u0145\n\u0005\u0000\u0000\u0145\u0146\u0005$\u0000\u0000\u0146\u0151"+
		"\u0003\u0006\u0003\u0006\u0147\u0148\n\u0004\u0000\u0000\u0148\u0149\u0007"+
		"\u0003\u0000\u0000\u0149\u0151\u0003\u0006\u0003\u0005\u014a\u014b\n\u0006"+
		"\u0000\u0000\u014b\u014e\u0007\u0004\u0000\u0000\u014c\u014f\u0003\u00c0"+
		"`\u0000\u014d\u014f\u0003\u00d0h\u0000\u014e\u014c\u0001\u0000\u0000\u0000"+
		"\u014e\u014d\u0001\u0000\u0000\u0000\u014f\u0151\u0001\u0000\u0000\u0000"+
		"\u0150\u013a\u0001\u0000\u0000\u0000\u0150\u013d\u0001\u0000\u0000\u0000"+
		"\u0150\u0140\u0001\u0000\u0000\u0000\u0150\u0144\u0001\u0000\u0000\u0000"+
		"\u0150\u0147\u0001\u0000\u0000\u0000\u0150\u014a\u0001\u0000\u0000\u0000"+
		"\u0151\u0154\u0001\u0000\u0000\u0000\u0152\u0150\u0001\u0000\u0000\u0000"+
		"\u0152\u0153\u0001\u0000\u0000\u0000\u0153\u0007\u0001\u0000\u0000\u0000"+
		"\u0154\u0152\u0001\u0000\u0000\u0000\u0155\u015e\u0003$\u0012\u0000\u0156"+
		"\u015e\u0003,\u0016\u0000\u0157\u015e\u00030\u0018\u0000\u0158\u015e\u0003"+
		"4\u001a\u0000\u0159\u015e\u00038\u001c\u0000\u015a\u015e\u0003B!\u0000"+
		"\u015b\u015e\u0003D\"\u0000\u015c\u015e\u0003J%\u0000\u015d\u0155\u0001"+
		"\u0000\u0000\u0000\u015d\u0156\u0001\u0000\u0000\u0000\u015d\u0157\u0001"+
		"\u0000\u0000\u0000\u015d\u0158\u0001\u0000\u0000\u0000\u015d\u0159\u0001"+
		"\u0000\u0000\u0000\u015d\u015a\u0001\u0000\u0000\u0000\u015d\u015b\u0001"+
		"\u0000\u0000\u0000\u015d\u015c\u0001\u0000\u0000\u0000\u015e\t\u0001\u0000"+
		"\u0000\u0000\u015f\u016c\u0003\u001e\u000f\u0000\u0160\u016c\u0003\"\u0011"+
		"\u0000\u0161\u016c\u0003*\u0015\u0000\u0162\u016c\u0003.\u0017\u0000\u0163"+
		"\u016c\u00032\u0019\u0000\u0164\u016c\u00036\u001b\u0000\u0165\u016c\u0003"+
		":\u001d\u0000\u0166\u016c\u0003<\u001e\u0000\u0167\u016c\u0003>\u001f"+
		"\u0000\u0168\u016c\u0003@ \u0000\u0169\u016c\u0003F#\u0000\u016a\u016c"+
		"\u0003H$\u0000\u016b\u015f\u0001\u0000\u0000\u0000\u016b\u0160\u0001\u0000"+
		"\u0000\u0000\u016b\u0161\u0001\u0000\u0000\u0000\u016b\u0162\u0001\u0000"+
		"\u0000\u0000\u016b\u0163\u0001\u0000\u0000\u0000\u016b\u0164\u0001\u0000"+
		"\u0000\u0000\u016b\u0165\u0001\u0000\u0000\u0000\u016b\u0166\u0001\u0000"+
		"\u0000\u0000\u016b\u0167\u0001\u0000\u0000\u0000\u016b\u0168\u0001\u0000"+
		"\u0000\u0000\u016b\u0169\u0001\u0000\u0000\u0000\u016b\u016a\u0001\u0000"+
		"\u0000\u0000\u016c\u000b\u0001\u0000\u0000\u0000\u016d\u0175\u0003\u000e"+
		"\u0007\u0000\u016e\u0175\u0003\u0010\b\u0000\u016f\u0175\u0003\u0012\t"+
		"\u0000\u0170\u0175\u0003\u0014\n\u0000\u0171\u0175\u0003\u0016\u000b\u0000"+
		"\u0172\u0175\u0003\u0018\f\u0000\u0173\u0175\u0003\u001c\u000e\u0000\u0174"+
		"\u016d\u0001\u0000\u0000\u0000\u0174\u016e\u0001\u0000\u0000\u0000\u0174"+
		"\u016f\u0001\u0000\u0000\u0000\u0174\u0170\u0001\u0000\u0000\u0000\u0174"+
		"\u0171\u0001\u0000\u0000\u0000\u0174\u0172\u0001\u0000\u0000\u0000\u0174"+
		"\u0173\u0001\u0000\u0000\u0000\u0175\r\u0001\u0000\u0000\u0000\u0176\u0177"+
		"\u0005\"\u0000\u0000\u0177\u017c\u0003L&\u0000\u0178\u0179\u0005\u0011"+
		"\u0000\u0000\u0179\u017b\u0003L&\u0000\u017a\u0178\u0001\u0000\u0000\u0000"+
		"\u017b\u017e\u0001\u0000\u0000\u0000\u017c\u017a\u0001\u0000\u0000\u0000"+
		"\u017c\u017d\u0001\u0000\u0000\u0000\u017d\u000f\u0001\u0000\u0000\u0000"+
		"\u017e\u017c\u0001\u0000\u0000\u0000\u017f\u0180\u0005=\u0000\u0000\u0180"+
		"\u0185\u0003N\'\u0000\u0181\u0183\u0003n7\u0000\u0182\u0184\u0003p8\u0000"+
		"\u0183\u0182\u0001\u0000\u0000\u0000\u0183\u0184\u0001\u0000\u0000\u0000"+
		"\u0184\u0186\u0001\u0000\u0000\u0000\u0185\u0181\u0001\u0000\u0000\u0000"+
		"\u0185\u0186\u0001\u0000\u0000\u0000\u0186\u0011\u0001\u0000\u0000\u0000"+
		"\u0187\u0188\u0005^\u0000\u0000\u0188\u0189\u0003\u0006\u0003\u0000\u0189"+
		"\u0013\u0001\u0000\u0000\u0000\u018a\u018b\u0005 \u0000\u0000\u018b\u0190"+
		"\u0003R)\u0000\u018c\u018d\u0005\u0011\u0000\u0000\u018d\u018f\u0003R"+
		")\u0000\u018e\u018c\u0001\u0000\u0000\u0000\u018f\u0192\u0001\u0000\u0000"+
		"\u0000\u0190\u018e\u0001\u0000\u0000\u0000\u0190\u0191\u0001\u0000\u0000"+
		"\u0000\u0191\u0015\u0001\u0000\u0000\u0000\u0192\u0190\u0001\u0000\u0000"+
		"\u0000\u0193\u0194\u0007\u0005\u0000\u0000\u0194\u0199\u0003\u00be_\u0000"+
		"\u0195\u0196\u0005\u0011\u0000\u0000\u0196\u0198\u0003\u00be_\u0000\u0197"+
		"\u0195\u0001\u0000\u0000\u0000\u0198\u019b\u0001\u0000\u0000\u0000\u0199"+
		"\u0197\u0001\u0000\u0000\u0000\u0199\u019a\u0001\u0000\u0000\u0000\u019a"+
		"\u0017\u0001\u0000\u0000\u0000\u019b\u0199\u0001\u0000\u0000\u0000\u019c"+
		"\u019d\u0007\u0006\u0000\u0000\u019d\u019e\u0003\u00be_\u0000\u019e\u019f"+
		"\u0005\u0011\u0000\u0000\u019f\u01a0\u0003\u00be_\u0000\u01a0\u0019\u0001"+
		"\u0000\u0000\u0000\u01a1\u01a2\u0005\u00bf\u0000\u0000\u01a2\u01a3\u0003"+
		"\u00be_\u0000\u01a3\u01a4\u0005\u0011\u0000\u0000\u01a4\u01a5\u0003\u00be"+
		"_\u0000\u01a5\u01a6\u0005)\u0000\u0000\u01a6\u01ab\u0003\u00d6k\u0000"+
		"\u01a7\u01a8\u0005\u0011\u0000\u0000\u01a8\u01aa\u0003\u00d6k\u0000\u01a9"+
		"\u01a7\u0001\u0000\u0000\u0000\u01aa\u01ad\u0001\u0000\u0000\u0000\u01ab"+
		"\u01a9\u0001\u0000\u0000\u0000\u01ab\u01ac\u0001\u0000\u0000\u0000\u01ac"+
		"\u001b\u0001\u0000\u0000\u0000\u01ad\u01ab\u0001\u0000\u0000\u0000\u01ae"+
		"\u01af\u0005\u00c1\u0000\u0000\u01af\u01b4\u0003T*\u0000\u01b0\u01b1\u0005"+
		"\u0011\u0000\u0000\u01b1\u01b3\u0003T*\u0000\u01b2\u01b0\u0001\u0000\u0000"+
		"\u0000\u01b3\u01b6\u0001\u0000\u0000\u0000\u01b4\u01b2\u0001\u0000\u0000"+
		"\u0000\u01b4\u01b5\u0001\u0000\u0000\u0000\u01b5\u001d\u0001\u0000\u0000"+
		"\u0000\u01b6\u01b4\u0001\u0000\u0000\u0000\u01b7\u01b8\u0007\u0007\u0000"+
		"\u0000\u01b8\u01b9\u0005\u0001\u0000\u0000\u01b9\u01ba\u0003Z-\u0000\u01ba"+
		"\u01bb\u0003^/\u0000\u01bb\u01bc\u0005\u0002\u0000\u0000\u01bc\u01c4\u0001"+
		"\u0000\u0000\u0000\u01bd\u01be\u0007\b\u0000\u0000\u01be\u01bf\u0005\u0001"+
		"\u0000\u0000\u01bf\u01c0\u0003X,\u0000\u01c0\u01c1\u0003^/\u0000\u01c1"+
		"\u01c2\u0005\u0002\u0000\u0000\u01c2\u01c4\u0001\u0000\u0000\u0000\u01c3"+
		"\u01b7\u0001\u0000\u0000\u0000\u01c3\u01bd\u0001\u0000\u0000\u0000\u01c4"+
		"\u001f\u0001\u0000\u0000\u0000\u01c5\u01c6\u0005o\u0000\u0000\u01c6\u01c7"+
		"\u0005n\u0000\u0000\u01c7\u01c8\u0003\u00d2i\u0000\u01c8\u01d1\u0005\u0001"+
		"\u0000\u0000\u01c9\u01ce\u0003r9\u0000\u01ca\u01cb\u0005\u0011\u0000\u0000"+
		"\u01cb\u01cd\u0003r9\u0000\u01cc\u01ca\u0001\u0000\u0000\u0000\u01cd\u01d0"+
		"\u0001\u0000\u0000\u0000\u01ce\u01cc\u0001\u0000\u0000\u0000\u01ce\u01cf"+
		"\u0001\u0000\u0000\u0000\u01cf\u01d2\u0001\u0000\u0000\u0000\u01d0\u01ce"+
		"\u0001\u0000\u0000\u0000\u01d1\u01c9\u0001\u0000\u0000\u0000\u01d1\u01d2"+
		"\u0001\u0000\u0000\u0000\u01d2\u01d3\u0001\u0000\u0000\u0000\u01d3\u01d6"+
		"\u0005\u0002\u0000\u0000\u01d4\u01d5\u0005\u00bd\u0000\u0000\u01d5\u01d7"+
		"\u0003t:\u0000\u01d6\u01d4\u0001\u0000\u0000\u0000\u01d6\u01d7\u0001\u0000"+
		"\u0000\u0000\u01d7\u01d8\u0001\u0000\u0000\u0000\u01d8\u01d9\u0005\u00ac"+
		"\u0000\u0000\u01d9\u01da\u0003\u0004\u0002\u0000\u01da\u01db\u0005u\u0000"+
		"\u0000\u01db\u01dc\u0005n\u0000\u0000\u01dc\u01f8\u0001\u0000\u0000\u0000"+
		"\u01dd\u01de\u0005o\u0000\u0000\u01de\u01df\u0005q\u0000\u0000\u01df\u01e0"+
		"\u0005s\u0000\u0000\u01e0\u01e1\u0003\u008cF\u0000\u01e1\u01e2\u0005\u0001"+
		"\u0000\u0000\u01e2\u01e3\u0003\u008eG\u0000\u01e3\u01e4\u0005\u0002\u0000"+
		"\u0000\u01e4\u01e5\u0005\u00ac\u0000\u0000\u01e5\u01e6\u0003\u0092I\u0000"+
		"\u01e6\u01e7\u0005u\u0000\u0000\u01e7\u01e8\u0005q\u0000\u0000\u01e8\u01e9"+
		"\u0005s\u0000\u0000\u01e9\u01f8\u0001\u0000\u0000\u0000\u01ea\u01eb\u0005"+
		"o\u0000\u0000\u01eb\u01ec\u0005r\u0000\u0000\u01ec\u01ed\u0005s\u0000"+
		"\u0000\u01ed\u01ee\u0003\u008cF\u0000\u01ee\u01ef\u0005\u0001\u0000\u0000"+
		"\u01ef\u01f0\u0003\u009aM\u0000\u01f0\u01f1\u0005\u0002\u0000\u0000\u01f1"+
		"\u01f2\u0005\u00ac\u0000\u0000\u01f2\u01f3\u0003\u0096K\u0000\u01f3\u01f4"+
		"\u0005u\u0000\u0000\u01f4\u01f5\u0005r\u0000\u0000\u01f5\u01f6\u0005s"+
		"\u0000\u0000\u01f6\u01f8\u0001\u0000\u0000\u0000\u01f7\u01c5\u0001\u0000"+
		"\u0000\u0000\u01f7\u01dd\u0001\u0000\u0000\u0000\u01f7\u01ea\u0001\u0000"+
		"\u0000\u0000\u01f8!\u0001\u0000\u0000\u0000\u01f9\u01fa\u0003\u00d2i\u0000"+
		"\u01fa\u0203\u0005\u0001\u0000\u0000\u01fb\u0200\u0003(\u0014\u0000\u01fc"+
		"\u01fd\u0005\u0011\u0000\u0000\u01fd\u01ff\u0003(\u0014\u0000\u01fe\u01fc"+
		"\u0001\u0000\u0000\u0000\u01ff\u0202\u0001\u0000\u0000\u0000\u0200\u01fe"+
		"\u0001\u0000\u0000\u0000\u0200\u0201\u0001\u0000\u0000\u0000\u0201\u0204"+
		"\u0001\u0000\u0000\u0000\u0202\u0200\u0001\u0000\u0000\u0000\u0203\u01fb"+
		"\u0001\u0000\u0000\u0000\u0203\u0204\u0001\u0000\u0000\u0000\u0204\u0205"+
		"\u0001\u0000\u0000\u0000\u0205\u0206\u0005\u0002\u0000\u0000\u0206\u0233"+
		"\u0001\u0000\u0000\u0000\u0207\u0208\u0005\u0016\u0000\u0000\u0208\u0209"+
		"\u0005\u0001\u0000\u0000\u0209\u020a\u0003\u00d4j\u0000\u020a\u020d\u0005"+
		"\u0001\u0000\u0000\u020b\u020e\u0003\u00ba]\u0000\u020c\u020e\u0003V+"+
		"\u0000\u020d\u020b\u0001\u0000\u0000\u0000\u020d\u020c\u0001\u0000\u0000"+
		"\u0000\u020d\u020e\u0001\u0000\u0000\u0000\u020e\u0216\u0001\u0000\u0000"+
		"\u0000\u020f\u0212\u0005\u0011\u0000\u0000\u0210\u0213\u0003\u00ba]\u0000"+
		"\u0211\u0213\u0003V+\u0000\u0212\u0210\u0001\u0000\u0000\u0000\u0212\u0211"+
		"\u0001\u0000\u0000\u0000\u0213\u0215\u0001\u0000\u0000\u0000\u0214\u020f"+
		"\u0001\u0000\u0000\u0000\u0215\u0218\u0001\u0000\u0000\u0000\u0216\u0214"+
		"\u0001\u0000\u0000\u0000\u0216\u0217\u0001\u0000\u0000\u0000\u0217\u0219"+
		"\u0001\u0000\u0000\u0000\u0218\u0216\u0001\u0000\u0000\u0000\u0219\u021c"+
		"\u0005\u0002\u0000\u0000\u021a\u021b\u0005\u00e4\u0000\u0000\u021b\u021d"+
		"\u0005\u00e8\u0000\u0000\u021c\u021a\u0001\u0000\u0000\u0000\u021c\u021d"+
		"\u0001\u0000\u0000\u0000\u021d\u0220\u0001\u0000\u0000\u0000\u021e\u021f"+
		"\u0005\u00bd\u0000\u0000\u021f\u0221\u0003\u0082A\u0000\u0220\u021e\u0001"+
		"\u0000\u0000\u0000\u0220\u0221\u0001\u0000\u0000\u0000\u0221\u0222\u0001"+
		"\u0000\u0000\u0000\u0222\u0223\u0005\u0002\u0000\u0000\u0223\u0233\u0001"+
		"\u0000\u0000\u0000\u0224\u0225\u0005\u00ce\u0000\u0000\u0225\u0226\u0005"+
		"\u0001\u0000\u0000\u0226\u0227\u0003\u0004\u0002\u0000\u0227\u022a\u0005"+
		"\u0011\u0000\u0000\u0228\u022b\u0003\u00d8l\u0000\u0229\u022b\u0003\u008a"+
		"E\u0000\u022a\u0228\u0001\u0000\u0000\u0000\u022a\u0229\u0001\u0000\u0000"+
		"\u0000\u022b\u022e\u0001\u0000\u0000\u0000\u022c\u022d\u0005\u0011\u0000"+
		"\u0000\u022d\u022f\u0005\u00e8\u0000\u0000\u022e\u022c\u0001\u0000\u0000"+
		"\u0000\u022e\u022f\u0001\u0000\u0000\u0000\u022f\u0230\u0001\u0000\u0000"+
		"\u0000\u0230\u0231\u0005\u0002\u0000\u0000\u0231\u0233\u0001\u0000\u0000"+
		"\u0000\u0232\u01f9\u0001\u0000\u0000\u0000\u0232\u0207\u0001\u0000\u0000"+
		"\u0000\u0232\u0224\u0001\u0000\u0000\u0000\u0233#\u0001\u0000\u0000\u0000"+
		"\u0234\u0235\u0003\u00d2i\u0000\u0235\u023e\u0005\u0001\u0000\u0000\u0236"+
		"\u023b\u0003&\u0013\u0000\u0237\u0238\u0005\u0011\u0000\u0000\u0238\u023a"+
		"\u0003&\u0013\u0000\u0239\u0237\u0001\u0000\u0000\u0000\u023a\u023d\u0001"+
		"\u0000\u0000\u0000\u023b\u0239\u0001\u0000\u0000\u0000\u023b\u023c\u0001"+
		"\u0000\u0000\u0000\u023c\u023f\u0001\u0000\u0000\u0000\u023d\u023b\u0001"+
		"\u0000\u0000\u0000\u023e\u0236\u0001\u0000\u0000\u0000\u023e\u023f\u0001"+
		"\u0000\u0000\u0000\u023f\u0240\u0001\u0000\u0000\u0000\u0240\u0241\u0005"+
		"\u0002\u0000\u0000\u0241\u026e\u0001\u0000\u0000\u0000\u0242\u0243\u0005"+
		"\u00ce\u0000\u0000\u0243\u0244\u0005\u0001\u0000\u0000\u0244\u0245\u0003"+
		"\u0006\u0003\u0000\u0245\u0248\u0005\u0011\u0000\u0000\u0246\u0249\u0003"+
		"\u00d8l\u0000\u0247\u0249\u0003\u008aE\u0000\u0248\u0246\u0001\u0000\u0000"+
		"\u0000\u0248\u0247\u0001\u0000\u0000\u0000\u0249\u024c\u0001\u0000\u0000"+
		"\u0000\u024a\u024b\u0005\u0011\u0000\u0000\u024b\u024d\u0005\u00e8\u0000"+
		"\u0000\u024c\u024a\u0001\u0000\u0000\u0000\u024c\u024d\u0001\u0000\u0000"+
		"\u0000\u024d\u024e\u0001\u0000\u0000\u0000\u024e\u024f\u0005\u0002\u0000"+
		"\u0000\u024f\u026e\u0001\u0000\u0000\u0000\u0250\u0251\u0005\u0016\u0000"+
		"\u0000\u0251\u0252\u0005\u0001\u0000\u0000\u0252\u0253\u0003\u00d4j\u0000"+
		"\u0253\u0256\u0005\u0001\u0000\u0000\u0254\u0257\u0003\u00be_\u0000\u0255"+
		"\u0257\u0003V+\u0000\u0256\u0254\u0001\u0000\u0000\u0000\u0256\u0255\u0001"+
		"\u0000\u0000\u0000\u0256\u0257\u0001\u0000\u0000\u0000\u0257\u025f\u0001"+
		"\u0000\u0000\u0000\u0258\u025b\u0005\u0011\u0000\u0000\u0259\u025c\u0003"+
		"\u00be_\u0000\u025a\u025c\u0003V+\u0000\u025b\u0259\u0001\u0000\u0000"+
		"\u0000\u025b\u025a\u0001\u0000\u0000\u0000\u025c\u025e\u0001\u0000\u0000"+
		"\u0000\u025d\u0258\u0001\u0000\u0000\u0000\u025e\u0261\u0001\u0000\u0000"+
		"\u0000\u025f\u025d\u0001\u0000\u0000\u0000\u025f\u0260\u0001\u0000\u0000"+
		"\u0000\u0260\u0262\u0001\u0000\u0000\u0000\u0261\u025f\u0001\u0000\u0000"+
		"\u0000\u0262\u0265\u0005\u0002\u0000\u0000\u0263\u0264\u0005\u00e4\u0000"+
		"\u0000\u0264\u0266\u0005\u00e8\u0000\u0000\u0265\u0263\u0001\u0000\u0000"+
		"\u0000\u0265\u0266\u0001\u0000\u0000\u0000\u0266\u0269\u0001\u0000\u0000"+
		"\u0000\u0267\u0268\u0005\u00bd\u0000\u0000\u0268\u026a\u0003v;\u0000\u0269"+
		"\u0267\u0001\u0000\u0000\u0000\u0269\u026a\u0001\u0000\u0000\u0000\u026a"+
		"\u026b\u0001\u0000\u0000\u0000\u026b\u026c\u0005\u0002\u0000\u0000\u026c"+
		"\u026e\u0001\u0000\u0000\u0000\u026d\u0234\u0001\u0000\u0000\u0000\u026d"+
		"\u0242\u0001\u0000\u0000\u0000\u026d\u0250\u0001\u0000\u0000\u0000\u026e"+
		"%\u0001\u0000\u0000\u0000\u026f\u0272\u0003\u0006\u0003\u0000\u0270\u0272"+
		"\u0005g\u0000\u0000\u0271\u026f\u0001\u0000\u0000\u0000\u0271\u0270\u0001"+
		"\u0000\u0000\u0000\u0272\'\u0001\u0000\u0000\u0000\u0273\u0276\u0003\u0004"+
		"\u0002\u0000\u0274\u0276\u0005g\u0000\u0000\u0275\u0273\u0001\u0000\u0000"+
		"\u0000\u0275\u0274\u0001\u0000\u0000\u0000\u0276)\u0001\u0000\u0000\u0000"+
		"\u0277\u0278\u0007\t\u0000\u0000\u0278\u0279\u0005\u0001\u0000\u0000\u0279"+
		"\u027a\u0003\u0004\u0002\u0000\u027a\u027b\u0005\u0002\u0000\u0000\u027b"+
		"\u02a8\u0001\u0000\u0000\u0000\u027c\u027d\u0005V\u0000\u0000\u027d\u027e"+
		"\u0005\u0001\u0000\u0000\u027e\u0289\u0003\u0004\u0002\u0000\u027f\u0280"+
		"\u0005\u0011\u0000\u0000\u0280\u0281\u0003\u00c8d\u0000\u0281\u0282\u0001"+
		"\u0000\u0000\u0000\u0282\u0283\u0005\u0011\u0000\u0000\u0283\u0284\u0003"+
		"\u00c8d\u0000\u0284\u0286\u0001\u0000\u0000\u0000\u0285\u027f\u0001\u0000"+
		"\u0000\u0000\u0285\u0286\u0001\u0000\u0000\u0000\u0286\u028a\u0001\u0000"+
		"\u0000\u0000\u0287\u0288\u0005\u0011\u0000\u0000\u0288\u028a\u0003\u00c8"+
		"d\u0000\u0289\u0285\u0001\u0000\u0000\u0000\u0289\u0287\u0001\u0000\u0000"+
		"\u0000\u028a\u028b\u0001\u0000\u0000\u0000\u028b\u028c\u0005\u0002\u0000"+
		"\u0000\u028c\u02a8\u0001\u0000\u0000\u0000\u028d\u028e\u0005z\u0000\u0000"+
		"\u028e\u028f\u0005\u0001\u0000\u0000\u028f\u0290\u0003\u0004\u0002\u0000"+
		"\u0290\u0291\u0005\u0011\u0000\u0000\u0291\u0294\u0003\u0004\u0002\u0000"+
		"\u0292\u0293\u0005\u0011\u0000\u0000\u0293\u0295\u0003\u00c8d\u0000\u0294"+
		"\u0292\u0001\u0000\u0000\u0000\u0294\u0295\u0001\u0000\u0000\u0000\u0295"+
		"\u0296\u0001\u0000\u0000\u0000\u0296\u0297\u0005\u0002\u0000\u0000\u0297"+
		"\u02a8\u0001\u0000\u0000\u0000\u0298\u0299\u0005y\u0000\u0000\u0299\u029a"+
		"\u0005\u0001\u0000\u0000\u029a\u029b\u0003\u0004\u0002\u0000\u029b\u029c"+
		"\u0005\u0011\u0000\u0000\u029c\u029f\u0003\u0004\u0002\u0000\u029d\u029e"+
		"\u0005\u0011\u0000\u0000\u029e\u02a0\u0003\u00c8d\u0000\u029f\u029d\u0001"+
		"\u0000\u0000\u0000\u029f\u02a0\u0001\u0000\u0000\u0000\u02a0\u02a3\u0001"+
		"\u0000\u0000\u0000\u02a1\u02a2\u0005\u0011\u0000\u0000\u02a2\u02a4\u0003"+
		"\u00c8d\u0000\u02a3\u02a1\u0001\u0000\u0000\u0000\u02a3\u02a4\u0001\u0000"+
		"\u0000\u0000\u02a4\u02a5\u0001\u0000\u0000\u0000\u02a5\u02a6\u0005\u0002"+
		"\u0000\u0000\u02a6\u02a8\u0001\u0000\u0000\u0000\u02a7\u0277\u0001\u0000"+
		"\u0000\u0000\u02a7\u027c\u0001\u0000\u0000\u0000\u02a7\u028d\u0001\u0000"+
		"\u0000\u0000\u02a7\u0298\u0001\u0000\u0000\u0000\u02a8+\u0001\u0000\u0000"+
		"\u0000\u02a9\u02aa\u0007\t\u0000\u0000\u02aa\u02ab\u0005\u0001\u0000\u0000"+
		"\u02ab\u02ac\u0003\u0006\u0003\u0000\u02ac\u02ad\u0005\u0002\u0000\u0000"+
		"\u02ad\u02da\u0001\u0000\u0000\u0000\u02ae\u02af\u0005V\u0000\u0000\u02af"+
		"\u02b0\u0005\u0001\u0000\u0000\u02b0\u02bb\u0003\u0006\u0003\u0000\u02b1"+
		"\u02b2\u0005\u0011\u0000\u0000\u02b2\u02b3\u0003\u00cae\u0000\u02b3\u02b4"+
		"\u0001\u0000\u0000\u0000\u02b4\u02b5\u0005\u0011\u0000\u0000\u02b5\u02b6"+
		"\u0003\u00cae\u0000\u02b6\u02b8\u0001\u0000\u0000\u0000\u02b7\u02b1\u0001"+
		"\u0000\u0000\u0000\u02b7\u02b8\u0001\u0000\u0000\u0000\u02b8\u02bc\u0001"+
		"\u0000\u0000\u0000\u02b9\u02ba\u0005\u0011\u0000\u0000\u02ba\u02bc\u0003"+
		"\u00cae\u0000\u02bb\u02b7\u0001\u0000\u0000\u0000\u02bb\u02b9\u0001\u0000"+
		"\u0000\u0000\u02bc\u02bd\u0001\u0000\u0000\u0000\u02bd\u02be\u0005\u0002"+
		"\u0000\u0000\u02be\u02da\u0001\u0000\u0000\u0000\u02bf\u02c0\u0005z\u0000"+
		"\u0000\u02c0\u02c1\u0005\u0001\u0000\u0000\u02c1\u02c2\u0003\u0006\u0003"+
		"\u0000\u02c2\u02c3\u0005\u0011\u0000\u0000\u02c3\u02c6\u0003\u0006\u0003"+
		"\u0000\u02c4\u02c5\u0005\u0011\u0000\u0000\u02c5\u02c7\u0003\u00cae\u0000"+
		"\u02c6\u02c4\u0001\u0000\u0000\u0000\u02c6\u02c7\u0001\u0000\u0000\u0000"+
		"\u02c7\u02c8\u0001\u0000\u0000\u0000\u02c8\u02c9\u0005\u0002\u0000\u0000"+
		"\u02c9\u02da\u0001\u0000\u0000\u0000\u02ca\u02cb\u0005y\u0000\u0000\u02cb"+
		"\u02cc\u0005\u0001\u0000\u0000\u02cc\u02cd\u0003\u0006\u0003\u0000\u02cd"+
		"\u02ce\u0005\u0011\u0000\u0000\u02ce\u02d1\u0003\u0006\u0003\u0000\u02cf"+
		"\u02d0\u0005\u0011\u0000\u0000\u02d0\u02d2\u0003\u00cae\u0000\u02d1\u02cf"+
		"\u0001\u0000\u0000\u0000\u02d1\u02d2\u0001\u0000\u0000\u0000\u02d2\u02d5"+
		"\u0001\u0000\u0000\u0000\u02d3\u02d4\u0005\u0011\u0000\u0000\u02d4\u02d6"+
		"\u0003\u00cae\u0000\u02d5\u02d3\u0001\u0000\u0000\u0000\u02d5\u02d6\u0001"+
		"\u0000\u0000\u0000\u02d6\u02d7\u0001\u0000\u0000\u0000\u02d7\u02d8\u0005"+
		"\u0002\u0000\u0000\u02d8\u02da\u0001\u0000\u0000\u0000\u02d9\u02a9\u0001"+
		"\u0000\u0000\u0000\u02d9\u02ae\u0001\u0000\u0000\u0000\u02d9\u02bf\u0001"+
		"\u0000\u0000\u0000\u02d9\u02ca\u0001\u0000\u0000\u0000\u02da-\u0001\u0000"+
		"\u0000\u0000\u02db\u02dc\u0007\n\u0000\u0000\u02dc\u02dd\u0005\u0001\u0000"+
		"\u0000\u02dd\u02de\u0003\u0004\u0002\u0000\u02de\u02df\u0005\u0002\u0000"+
		"\u0000\u02df\u02f1\u0001\u0000\u0000\u0000\u02e0\u02e1\u0007\u000b\u0000"+
		"\u0000\u02e1\u02e2\u0005\u0001\u0000\u0000\u02e2\u02e5\u0003\u0004\u0002"+
		"\u0000\u02e3\u02e4\u0005\u0011\u0000\u0000\u02e4\u02e6\u0003\u00c8d\u0000"+
		"\u02e5\u02e3\u0001\u0000\u0000\u0000\u02e5\u02e6\u0001\u0000\u0000\u0000"+
		"\u02e6\u02e7\u0001\u0000\u0000\u0000\u02e7\u02e8\u0005\u0002\u0000\u0000"+
		"\u02e8\u02f1\u0001\u0000\u0000\u0000\u02e9\u02ea\u0007\f\u0000\u0000\u02ea"+
		"\u02eb\u0005\u0001\u0000\u0000\u02eb\u02ec\u0003\u0004\u0002\u0000\u02ec"+
		"\u02ed\u0005\u0011\u0000\u0000\u02ed\u02ee\u0003\u0004\u0002\u0000\u02ee"+
		"\u02ef\u0005\u0002\u0000\u0000\u02ef\u02f1\u0001\u0000\u0000\u0000\u02f0"+
		"\u02db\u0001\u0000\u0000\u0000\u02f0\u02e0\u0001\u0000\u0000\u0000\u02f0"+
		"\u02e9\u0001\u0000\u0000\u0000\u02f1/\u0001\u0000\u0000\u0000\u02f2\u02f3"+
		"\u0007\n\u0000\u0000\u02f3\u02f4\u0005\u0001\u0000\u0000\u02f4\u02f5\u0003"+
		"\u0006\u0003\u0000\u02f5\u02f6\u0005\u0002\u0000\u0000\u02f6\u0308\u0001"+
		"\u0000\u0000\u0000\u02f7\u02f8\u0007\u000b\u0000\u0000\u02f8\u02f9\u0005"+
		"\u0001\u0000\u0000\u02f9\u02fc\u0003\u0006\u0003\u0000\u02fa\u02fb\u0005"+
		"\u0011\u0000\u0000\u02fb\u02fd\u0003\u00cae\u0000\u02fc\u02fa\u0001\u0000"+
		"\u0000\u0000\u02fc\u02fd\u0001\u0000\u0000\u0000\u02fd\u02fe\u0001\u0000"+
		"\u0000\u0000\u02fe\u02ff\u0005\u0002\u0000\u0000\u02ff\u0308\u0001\u0000"+
		"\u0000\u0000\u0300\u0301\u0007\f\u0000\u0000\u0301\u0302\u0005\u0001\u0000"+
		"\u0000\u0302\u0303\u0003\u0006\u0003\u0000\u0303\u0304\u0005\u0011\u0000"+
		"\u0000\u0304\u0305\u0003\u0006\u0003\u0000\u0305\u0306\u0005\u0002\u0000"+
		"\u0000\u0306\u0308\u0001\u0000\u0000\u0000\u0307\u02f2\u0001\u0000\u0000"+
		"\u0000\u0307\u02f7\u0001\u0000\u0000\u0000\u0307\u0300\u0001\u0000\u0000"+
		"\u0000\u03081\u0001\u0000\u0000\u0000\u0309\u030a\u0005(\u0000\u0000\u030a"+
		"\u030b\u0005\u0001\u0000\u0000\u030b\u030c\u0003\u0004\u0002\u0000\u030c"+
		"\u030d\u0005\u0011\u0000\u0000\u030d\u030e\u0003\u0004\u0002\u0000\u030e"+
		"\u030f\u0005\u0011\u0000\u0000\u030f\u0310\u0003\u0004\u0002\u0000\u0310"+
		"\u0311\u0005\u0002\u0000\u0000\u0311\u032a\u0001\u0000\u0000\u0000\u0312"+
		"\u0313\u0005c\u0000\u0000\u0313\u0314\u0005\u0001\u0000\u0000\u0314\u0315"+
		"\u0003\u0004\u0002\u0000\u0315\u0316\u0005\u0011\u0000\u0000\u0316\u0317"+
		"\u0003\u0004\u0002\u0000\u0317\u0318\u0005\u0002\u0000\u0000\u0318\u032a"+
		"\u0001\u0000\u0000\u0000\u0319\u031a\u0005,\u0000\u0000\u031a\u031b\u0005"+
		"\u0001\u0000\u0000\u031b\u031c\u0003\u0004\u0002\u0000\u031c\u031d\u0005"+
		"\u0002\u0000\u0000\u031d\u032a\u0001\u0000\u0000\u0000\u031e\u031f\u0005"+
		"7\u0000\u0000\u031f\u0320\u0005\u0001\u0000\u0000\u0320\u0321\u0003\u0004"+
		"\u0002\u0000\u0321\u0322\u0005\u0011\u0000\u0000\u0322\u0325\u0003\u0004"+
		"\u0002\u0000\u0323\u0324\u0005\u0011\u0000\u0000\u0324\u0326\u0003\u00da"+
		"m\u0000\u0325\u0323\u0001\u0000\u0000\u0000\u0325\u0326\u0001\u0000\u0000"+
		"\u0000\u0326\u0327\u0001\u0000\u0000\u0000\u0327\u0328\u0005\u0002\u0000"+
		"\u0000\u0328\u032a\u0001\u0000\u0000\u0000\u0329\u0309\u0001\u0000\u0000"+
		"\u0000\u0329\u0312\u0001\u0000\u0000\u0000\u0329\u0319\u0001\u0000\u0000"+
		"\u0000\u0329\u031e\u0001\u0000\u0000\u0000\u032a3\u0001\u0000\u0000\u0000"+
		"\u032b\u032c\u0005(\u0000\u0000\u032c\u032d\u0005\u0001\u0000\u0000\u032d"+
		"\u032e\u0003\u0006\u0003\u0000\u032e\u032f\u0005\u0011\u0000\u0000\u032f"+
		"\u0330\u0003\u0006\u0003\u0000\u0330\u0331\u0005\u0011\u0000\u0000\u0331"+
		"\u0332\u0003\u0006\u0003\u0000\u0332\u0333\u0005\u0002\u0000\u0000\u0333"+
		"\u0341\u0001\u0000\u0000\u0000\u0334\u0335\u0005c\u0000\u0000\u0335\u0336"+
		"\u0005\u0001\u0000\u0000\u0336\u0337\u0003\u0006\u0003\u0000\u0337\u0338"+
		"\u0005\u0011\u0000\u0000\u0338\u0339\u0003\u0006\u0003\u0000\u0339\u033a"+
		"\u0005\u0002\u0000\u0000\u033a\u0341\u0001\u0000\u0000\u0000\u033b\u033c"+
		"\u0005,\u0000\u0000\u033c\u033d\u0005\u0001\u0000\u0000\u033d\u033e\u0003"+
		"\u0006\u0003\u0000\u033e\u033f\u0005\u0002\u0000\u0000\u033f\u0341\u0001"+
		"\u0000\u0000\u0000\u0340\u032b\u0001\u0000\u0000\u0000\u0340\u0334\u0001"+
		"\u0000\u0000\u0000\u0340\u033b\u0001\u0000\u0000\u0000\u03415\u0001\u0000"+
		"\u0000\u0000\u0342\u0343\u0005\u00c4\u0000\u0000\u0343\u0345\u0005\u0001"+
		"\u0000\u0000\u0344\u0346\u0003\u0004\u0002\u0000\u0345\u0344\u0001\u0000"+
		"\u0000\u0000\u0345\u0346\u0001\u0000\u0000\u0000\u0346\u0347\u0001\u0000"+
		"\u0000\u0000\u0347\u0371\u0005\u0002\u0000\u0000\u0348\u0349\u0005\u0095"+
		"\u0000\u0000\u0349\u034a\u0005\u0001\u0000\u0000\u034a\u034d\u0003\u0004"+
		"\u0002\u0000\u034b\u034c\u0005\u0011\u0000\u0000\u034c\u034e\u0007\r\u0000"+
		"\u0000\u034d\u034b\u0001\u0000\u0000\u0000\u034d\u034e\u0001\u0000\u0000"+
		"\u0000\u034e\u034f\u0001\u0000\u0000\u0000\u034f\u0350\u0005\u0002\u0000"+
		"\u0000\u0350\u0371\u0001\u0000\u0000\u0000\u0351\u0352\u0007\u000e\u0000"+
		"\u0000\u0352\u0353\u0005\u0001\u0000\u0000\u0353\u0354\u0003\u0004\u0002"+
		"\u0000\u0354\u0355\u0005\u0002\u0000\u0000\u0355\u0371\u0001\u0000\u0000"+
		"\u0000\u0356\u0357\u0005\u0098\u0000\u0000\u0357\u0358\u0005\u0001\u0000"+
		"\u0000\u0358\u0359\u0003\u0004\u0002\u0000\u0359\u035a\u0005\u0011\u0000"+
		"\u0000\u035a\u035b\u0003j5\u0000\u035b\u035c\u0005\u0002\u0000\u0000\u035c"+
		"\u0371\u0001\u0000\u0000\u0000\u035d\u035e\u0005\u00c7\u0000\u0000\u035e"+
		"\u035f\u0005\u0001\u0000\u0000\u035f\u0362\u0005\u00e8\u0000\u0000\u0360"+
		"\u0361\u0005\u0011\u0000\u0000\u0361\u0363\u0007\u000f\u0000\u0000\u0362"+
		"\u0360\u0001\u0000\u0000\u0000\u0362\u0363\u0001\u0000\u0000\u0000\u0363"+
		"\u0366\u0001\u0000\u0000\u0000\u0364\u0365\u0005\u0011\u0000\u0000\u0365"+
		"\u0367\u0003\u00c8d\u0000\u0366\u0364\u0001\u0000\u0000\u0000\u0366\u0367"+
		"\u0001\u0000\u0000\u0000\u0367\u036a\u0001\u0000\u0000\u0000\u0368\u0369"+
		"\u0005\u0011\u0000\u0000\u0369\u036b\u0007\u0010\u0000\u0000\u036a\u0368"+
		"\u0001\u0000\u0000\u0000\u036a\u036b\u0001\u0000\u0000\u0000\u036b\u036c"+
		"\u0001\u0000\u0000\u0000\u036c\u0371\u0005\u0002\u0000\u0000\u036d\u036e"+
		"\u0005\u001c\u0000\u0000\u036e\u036f\u0005\u0001\u0000\u0000\u036f\u0371"+
		"\u0005\u0002\u0000\u0000\u0370\u0342\u0001\u0000\u0000\u0000\u0370\u0348"+
		"\u0001\u0000\u0000\u0000\u0370\u0351\u0001\u0000\u0000\u0000\u0370\u0356"+
		"\u0001\u0000\u0000\u0000\u0370\u035d\u0001\u0000\u0000\u0000\u0370\u036d"+
		"\u0001\u0000\u0000\u0000\u03717\u0001\u0000\u0000\u0000\u0372\u0373\u0005"+
		"\u00c4\u0000\u0000\u0373\u0375\u0005\u0001\u0000\u0000\u0374\u0376\u0003"+
		"\u0006\u0003\u0000\u0375\u0374\u0001\u0000\u0000\u0000\u0375\u0376\u0001"+
		"\u0000\u0000\u0000\u0376\u0377\u0001\u0000\u0000\u0000\u0377\u03a1\u0005"+
		"\u0002\u0000\u0000\u0378\u0379\u0005\u0095\u0000\u0000\u0379\u037a\u0005"+
		"\u0001\u0000\u0000\u037a\u037d\u0003\u0006\u0003\u0000\u037b\u037c\u0005"+
		"\u0011\u0000\u0000\u037c\u037e\u0007\r\u0000\u0000\u037d\u037b\u0001\u0000"+
		"\u0000\u0000\u037d\u037e\u0001\u0000\u0000\u0000\u037e\u037f\u0001\u0000"+
		"\u0000\u0000\u037f\u0380\u0005\u0002\u0000\u0000\u0380\u03a1\u0001\u0000"+
		"\u0000\u0000\u0381\u0382\u0007\u000e\u0000\u0000\u0382\u0383\u0005\u0001"+
		"\u0000\u0000\u0383\u0384\u0003\u0006\u0003\u0000\u0384\u0385\u0005\u0002"+
		"\u0000\u0000\u0385\u03a1\u0001\u0000\u0000\u0000\u0386\u0387\u0005\u0098"+
		"\u0000\u0000\u0387\u0388\u0005\u0001\u0000\u0000\u0388\u0389\u0003\u0006"+
		"\u0003\u0000\u0389\u038a\u0005\u0011\u0000\u0000\u038a\u038b\u0003j5\u0000"+
		"\u038b\u038c\u0005\u0002\u0000\u0000\u038c\u03a1\u0001\u0000\u0000\u0000"+
		"\u038d\u038e\u0005\u00c7\u0000\u0000\u038e\u038f\u0005\u0001\u0000\u0000"+
		"\u038f\u0392\u0005\u00e8\u0000\u0000\u0390\u0391\u0005\u0011\u0000\u0000"+
		"\u0391\u0393\u0007\u000f\u0000\u0000\u0392\u0390\u0001\u0000\u0000\u0000"+
		"\u0392\u0393\u0001\u0000\u0000\u0000\u0393\u0396\u0001\u0000\u0000\u0000"+
		"\u0394\u0395\u0005\u0011\u0000\u0000\u0395\u0397\u0003\u00cae\u0000\u0396"+
		"\u0394\u0001\u0000\u0000\u0000\u0396\u0397\u0001\u0000\u0000\u0000\u0397"+
		"\u039a\u0001\u0000\u0000\u0000\u0398\u0399\u0005\u0011\u0000\u0000\u0399"+
		"\u039b\u0007\u0010\u0000\u0000\u039a\u0398\u0001\u0000\u0000\u0000\u039a"+
		"\u039b\u0001\u0000\u0000\u0000\u039b\u039c\u0001\u0000\u0000\u0000\u039c"+
		"\u03a1\u0005\u0002\u0000\u0000\u039d\u039e\u0005\u001c\u0000\u0000\u039e"+
		"\u039f\u0005\u0001\u0000\u0000\u039f\u03a1\u0005\u0002\u0000\u0000\u03a0"+
		"\u0372\u0001\u0000\u0000\u0000\u03a0\u0378\u0001\u0000\u0000\u0000\u03a0"+
		"\u0381\u0001\u0000\u0000\u0000\u03a0\u0386\u0001\u0000\u0000\u0000\u03a0"+
		"\u038d\u0001\u0000\u0000\u0000\u03a0\u039d\u0001\u0000\u0000\u0000\u03a1"+
		"9\u0001\u0000\u0000\u0000\u03a2\u03a3\u0005.\u0000\u0000\u03a3\u03a4\u0005"+
		"\u0001\u0000\u0000\u03a4\u03a7\u0003\u0004\u0002\u0000\u03a5\u03a6\u0005"+
		"\u0011\u0000\u0000\u03a6\u03a8\u0003\u0004\u0002\u0000\u03a7\u03a5\u0001"+
		"\u0000\u0000\u0000\u03a8\u03a9\u0001\u0000\u0000\u0000\u03a9\u03a7\u0001"+
		"\u0000\u0000\u0000\u03a9\u03aa\u0001\u0000\u0000\u0000\u03aa\u03ab\u0001"+
		"\u0000\u0000\u0000\u03ab\u03ac\u0005\u0002\u0000\u0000\u03ac\u03c0\u0001"+
		"\u0000\u0000\u0000\u03ad\u03ae\u00051\u0000\u0000\u03ae\u03af\u0005\u0001"+
		"\u0000\u0000\u03af\u03b2\u0003\u0004\u0002\u0000\u03b0\u03b1\u0005\u0011"+
		"\u0000\u0000\u03b1\u03b3\u0003\u0004\u0002\u0000\u03b2\u03b0\u0001\u0000"+
		"\u0000\u0000\u03b3\u03b4\u0001\u0000\u0000\u0000\u03b4\u03b2\u0001\u0000"+
		"\u0000\u0000\u03b4\u03b5\u0001\u0000\u0000\u0000\u03b5\u03b6\u0001\u0000"+
		"\u0000\u0000\u03b6\u03b7\u0005\u0002\u0000\u0000\u03b7\u03c0\u0001\u0000"+
		"\u0000\u0000\u03b8\u03b9\u0007\u0011\u0000\u0000\u03b9\u03ba\u0005\u0001"+
		"\u0000\u0000\u03ba\u03bb\u0003\u0004\u0002\u0000\u03bb\u03bc\u0005\u0011"+
		"\u0000\u0000\u03bc\u03bd\u0003\u0004\u0002\u0000\u03bd\u03be\u0005\u0002"+
		"\u0000\u0000\u03be\u03c0\u0001\u0000\u0000\u0000\u03bf\u03a2\u0001\u0000"+
		"\u0000\u0000\u03bf\u03ad\u0001\u0000\u0000\u0000\u03bf\u03b8\u0001\u0000"+
		"\u0000\u0000\u03c0;\u0001\u0000\u0000\u0000\u03c1\u03c2\u0005f\u0000\u0000"+
		"\u03c2\u03c3\u0005\u0001\u0000\u0000\u03c3\u03c4\u0003\u0004\u0002\u0000"+
		"\u03c4\u03c5\u0005\u0011\u0000\u0000\u03c5\u03c7\u0005\u00e9\u0000\u0000"+
		"\u03c6\u03c8\u0003\u00aeW\u0000\u03c7\u03c6\u0001\u0000\u0000\u0000\u03c7"+
		"\u03c8\u0001\u0000\u0000\u0000\u03c8\u03cb\u0001\u0000\u0000\u0000\u03c9"+
		"\u03ca\u0005t\u0000\u0000\u03ca\u03cc\u0003\u00be_\u0000\u03cb\u03c9\u0001"+
		"\u0000\u0000\u0000\u03cb\u03cc\u0001\u0000\u0000\u0000\u03cc\u03ce\u0001"+
		"\u0000\u0000\u0000\u03cd\u03cf\u0003\u00acV\u0000\u03ce\u03cd\u0001\u0000"+
		"\u0000\u0000\u03ce\u03cf\u0001\u0000\u0000\u0000\u03cf\u03d1\u0001\u0000"+
		"\u0000\u0000\u03d0\u03d2\u0003\u00b4Z\u0000\u03d1\u03d0\u0001\u0000\u0000"+
		"\u0000\u03d1\u03d2\u0001\u0000\u0000\u0000\u03d2\u03d4\u0001\u0000\u0000"+
		"\u0000\u03d3\u03d5\u0003\u00b6[\u0000\u03d4\u03d3\u0001\u0000\u0000\u0000"+
		"\u03d4\u03d5\u0001\u0000\u0000\u0000\u03d5\u03d6\u0001\u0000\u0000\u0000"+
		"\u03d6\u03d7\u0005\u0002\u0000\u0000\u03d7=\u0001\u0000\u0000\u0000\u03d8"+
		"\u03d9\u0005\u00d2\u0000\u0000\u03d9\u03da\u0005\u0001\u0000\u0000\u03da"+
		"\u03db\u0003\u0004\u0002\u0000\u03db\u03dc\u0005\u0011\u0000\u0000\u03dc"+
		"\u03e6\u0005\u00e9\u0000\u0000\u03dd\u03de\u0005\u00db\u0000\u0000\u03de"+
		"\u03e3\u0003\u00be_\u0000\u03df\u03e0\u0005\u0011\u0000\u0000\u03e0\u03e2"+
		"\u0003\u00be_\u0000\u03e1\u03df\u0001\u0000\u0000\u0000\u03e2\u03e5\u0001"+
		"\u0000\u0000\u0000\u03e3\u03e1\u0001\u0000\u0000\u0000\u03e3\u03e4\u0001"+
		"\u0000\u0000\u0000\u03e4\u03e7\u0001\u0000\u0000\u0000\u03e5\u03e3\u0001"+
		"\u0000\u0000\u0000\u03e6\u03dd\u0001\u0000\u0000\u0000\u03e6\u03e7\u0001"+
		"\u0000\u0000\u0000\u03e7\u03e9\u0001\u0000\u0000\u0000\u03e8\u03ea\u0003"+
		"\u00aaU\u0000\u03e9\u03e8\u0001\u0000\u0000\u0000\u03e9\u03ea\u0001\u0000"+
		"\u0000\u0000\u03ea\u03eb\u0001\u0000\u0000\u0000\u03eb\u03ec\u0005\u0002"+
		"\u0000\u0000\u03ec\u0416\u0001\u0000\u0000\u0000\u03ed\u03ee\u0005\u00d3"+
		"\u0000\u0000\u03ee\u03ef\u0005\u0001\u0000\u0000\u03ef\u03f0\u0003\u0004"+
		"\u0002\u0000\u03f0\u03f1\u0005\u0011\u0000\u0000\u03f1\u03f3\u0005\u00e9"+
		"\u0000\u0000\u03f2\u03f4\u0003\u00aeW\u0000\u03f3\u03f2\u0001\u0000\u0000"+
		"\u0000\u03f3\u03f4\u0001\u0000\u0000\u0000\u03f4\u03f7\u0001\u0000\u0000"+
		"\u0000\u03f5\u03f6\u0005t\u0000\u0000\u03f6\u03f8\u0003\u00be_\u0000\u03f7"+
		"\u03f5\u0001\u0000\u0000\u0000\u03f7\u03f8\u0001\u0000\u0000\u0000\u03f8"+
		"\u03fa\u0001\u0000\u0000\u0000\u03f9\u03fb\u0003\u00acV\u0000\u03fa\u03f9"+
		"\u0001\u0000\u0000\u0000\u03fa\u03fb\u0001\u0000\u0000\u0000\u03fb\u03fd"+
		"\u0001\u0000\u0000\u0000\u03fc\u03fe\u0003\u00b0X\u0000\u03fd\u03fc\u0001"+
		"\u0000\u0000\u0000\u03fd\u03fe\u0001\u0000\u0000\u0000\u03fe\u0400\u0001"+
		"\u0000\u0000\u0000\u03ff\u0401\u0003\u00aaU\u0000\u0400\u03ff\u0001\u0000"+
		"\u0000\u0000\u0400\u0401\u0001\u0000\u0000\u0000\u0401\u0402\u0001\u0000"+
		"\u0000\u0000\u0402\u0403\u0005\u0002\u0000\u0000\u0403\u0416\u0001\u0000"+
		"\u0000\u0000\u0404\u0405\u00056\u0000\u0000\u0405\u0406\u0005\u0001\u0000"+
		"\u0000\u0406\u0408\u0003\u0004\u0002\u0000\u0407\u0409\u0003\u00c2a\u0000"+
		"\u0408\u0407\u0001\u0000\u0000\u0000\u0408\u0409\u0001\u0000\u0000\u0000"+
		"\u0409\u040b\u0001\u0000\u0000\u0000\u040a\u040c\u0003\u00c4b\u0000\u040b"+
		"\u040a\u0001\u0000\u0000\u0000\u040b\u040c\u0001\u0000\u0000\u0000\u040c"+
		"\u040e\u0001\u0000\u0000\u0000\u040d\u040f\u0003\u00b2Y\u0000\u040e\u040d"+
		"\u0001\u0000\u0000\u0000\u040e\u040f\u0001\u0000\u0000\u0000\u040f\u0411"+
		"\u0001\u0000\u0000\u0000\u0410\u0412\u0007\u0012\u0000\u0000\u0411\u0410"+
		"\u0001\u0000\u0000\u0000\u0411\u0412\u0001\u0000\u0000\u0000\u0412\u0413"+
		"\u0001\u0000\u0000\u0000\u0413\u0414\u0005\u0002\u0000\u0000\u0414\u0416"+
		"\u0001\u0000\u0000\u0000\u0415\u03d8\u0001\u0000\u0000\u0000\u0415\u03ed"+
		"\u0001\u0000\u0000\u0000\u0415\u0404\u0001\u0000\u0000\u0000\u0416?\u0001"+
		"\u0000\u0000\u0000\u0417\u0418\u0005e\u0000\u0000\u0418\u0419\u0005\u0001"+
		"\u0000\u0000\u0419\u041a\u0003\u0004\u0002\u0000\u041a\u041b\u0005\u0011"+
		"\u0000\u0000\u041b\u041c\u0003\u0004\u0002\u0000\u041c\u041d\u0005\u0002"+
		"\u0000\u0000\u041dA\u0001\u0000\u0000\u0000\u041e\u041f\u0005e\u0000\u0000"+
		"\u041f\u0420\u0005\u0001\u0000\u0000\u0420\u0421\u0003\u0006\u0003\u0000"+
		"\u0421\u0422\u0005\u0011\u0000\u0000\u0422\u0423\u0003\u0006\u0003\u0000"+
		"\u0423\u0424\u0005\u0002\u0000\u0000\u0424C\u0001\u0000\u0000\u0000\u0425"+
		"\u0426\u0007\u0013\u0000\u0000\u0426\u0427\u0005\u0001\u0000\u0000\u0427"+
		"\u0428\u0003\u0006\u0003\u0000\u0428\u0429\u0005\u0002\u0000\u0000\u0429"+
		"\u042e\u0001\u0000\u0000\u0000\u042a\u042b\u0005Z\u0000\u0000\u042b\u042c"+
		"\u0005\u0001\u0000\u0000\u042c\u042e\u0005\u0002\u0000\u0000\u042d\u0425"+
		"\u0001\u0000\u0000\u0000\u042d\u042a\u0001\u0000\u0000\u0000\u042eE\u0001"+
		"\u0000\u0000\u0000\u042f\u0430\u0007\u0013\u0000\u0000\u0430\u0431\u0005"+
		"\u0001\u0000\u0000\u0431\u0436\u0003\u0004\u0002\u0000\u0432\u0434\u0003"+
		"n7\u0000\u0433\u0435\u0003p8\u0000\u0434\u0433\u0001\u0000\u0000\u0000"+
		"\u0434\u0435\u0001\u0000\u0000\u0000\u0435\u0437\u0001\u0000\u0000\u0000"+
		"\u0436\u0432\u0001\u0000\u0000\u0000\u0436\u0437\u0001\u0000\u0000\u0000"+
		"\u0437\u0438\u0001\u0000\u0000\u0000\u0438\u0439\u0005\u0002\u0000\u0000"+
		"\u0439G\u0001\u0000\u0000\u0000\u043a\u043b\u0007\u0014\u0000\u0000\u043b"+
		"\u043c\u0005\u0001\u0000\u0000\u043c\u043d\u0003\u0004\u0002\u0000\u043d"+
		"\u043e\u0005\u008c\u0000\u0000\u043e\u0440\u0005\u0001\u0000\u0000\u043f"+
		"\u0441\u0003b1\u0000\u0440\u043f\u0001\u0000\u0000\u0000\u0440\u0441\u0001"+
		"\u0000\u0000\u0000\u0441\u0443\u0001\u0000\u0000\u0000\u0442\u0444\u0003"+
		"d2\u0000\u0443\u0442\u0001\u0000\u0000\u0000\u0443\u0444\u0001\u0000\u0000"+
		"\u0000\u0444\u0446\u0001\u0000\u0000\u0000\u0445\u0447\u0003h4\u0000\u0446"+
		"\u0445\u0001\u0000\u0000\u0000\u0446\u0447\u0001\u0000\u0000\u0000\u0447"+
		"\u0448\u0001\u0000\u0000\u0000\u0448\u0449\u0005\u0002\u0000\u0000\u0449"+
		"\u044a\u0005\u0002\u0000\u0000\u044a\u0469\u0001\u0000\u0000\u0000\u044b"+
		"\u044c\u0007\u0015\u0000\u0000\u044c\u044d\u0005\u0001\u0000\u0000\u044d"+
		"\u0453\u0003\u0004\u0002\u0000\u044e\u044f\u0005\u0011\u0000\u0000\u044f"+
		"\u0451\u0003j5\u0000\u0450\u0452\u0003V+\u0000\u0451\u0450\u0001\u0000"+
		"\u0000\u0000\u0451\u0452\u0001\u0000\u0000\u0000\u0452\u0454\u0001\u0000"+
		"\u0000\u0000\u0453\u044e\u0001\u0000\u0000\u0000\u0453\u0454\u0001\u0000"+
		"\u0000\u0000\u0454\u0455\u0001\u0000\u0000\u0000\u0455\u0456\u0005\u008c"+
		"\u0000\u0000\u0456\u0458\u0005\u0001\u0000\u0000\u0457\u0459\u0003b1\u0000"+
		"\u0458\u0457\u0001\u0000\u0000\u0000\u0458\u0459\u0001\u0000\u0000\u0000"+
		"\u0459\u045a\u0001\u0000\u0000\u0000\u045a\u045b\u0003d2\u0000\u045b\u045c"+
		"\u0001\u0000\u0000\u0000\u045c\u045d\u0005\u0002\u0000\u0000\u045d\u045e"+
		"\u0005\u0002\u0000\u0000\u045e\u0469\u0001\u0000\u0000\u0000\u045f\u0460"+
		"\u0005\u008b\u0000\u0000\u0460\u0461\u0005\u0001\u0000\u0000\u0461\u0462"+
		"\u0003\u0004\u0002\u0000\u0462\u0463\u0005\u008c\u0000\u0000\u0463\u0464"+
		"\u0005\u0001\u0000\u0000\u0464\u0465\u0003b1\u0000\u0465\u0466\u0005\u0002"+
		"\u0000\u0000\u0466\u0467\u0005\u0002\u0000\u0000\u0467\u0469\u0001\u0000"+
		"\u0000\u0000\u0468\u043a\u0001\u0000\u0000\u0000\u0468\u044b\u0001\u0000"+
		"\u0000\u0000\u0468\u045f\u0001\u0000\u0000\u0000\u0469I\u0001\u0000\u0000"+
		"\u0000\u046a\u046b\u0007\u0014\u0000\u0000\u046b\u046c\u0005\u0001\u0000"+
		"\u0000\u046c\u046d\u0003\u0006\u0003\u0000\u046d\u046e\u0005\u008c\u0000"+
		"\u0000\u046e\u0470\u0005\u0001\u0000\u0000\u046f\u0471\u0003b1\u0000\u0470"+
		"\u046f\u0001\u0000\u0000\u0000\u0470\u0471\u0001\u0000\u0000\u0000\u0471"+
		"\u0473\u0001\u0000\u0000\u0000\u0472\u0474\u0003d2\u0000\u0473\u0472\u0001"+
		"\u0000\u0000\u0000\u0473\u0474\u0001\u0000\u0000\u0000\u0474\u0476\u0001"+
		"\u0000\u0000\u0000\u0475\u0477\u0003h4\u0000\u0476\u0475\u0001\u0000\u0000"+
		"\u0000\u0476\u0477\u0001\u0000\u0000\u0000\u0477\u0478\u0001\u0000\u0000"+
		"\u0000\u0478\u0479\u0005\u0002\u0000\u0000\u0479\u047a\u0005\u0002\u0000"+
		"\u0000\u047a\u04a5\u0001\u0000\u0000\u0000\u047b\u047c\u0007\u0015\u0000"+
		"\u0000\u047c\u047d\u0005\u0001\u0000\u0000\u047d\u0483\u0003\u0006\u0003"+
		"\u0000\u047e\u047f\u0005\u0011\u0000\u0000\u047f\u0481\u0003j5\u0000\u0480"+
		"\u0482\u0003V+\u0000\u0481\u0480\u0001\u0000\u0000\u0000\u0481\u0482\u0001"+
		"\u0000\u0000\u0000\u0482\u0484\u0001\u0000\u0000\u0000\u0483\u047e\u0001"+
		"\u0000\u0000\u0000\u0483\u0484\u0001\u0000\u0000\u0000\u0484\u0485\u0001"+
		"\u0000\u0000\u0000\u0485\u0486\u0005\u008c\u0000\u0000\u0486\u0488\u0005"+
		"\u0001\u0000\u0000\u0487\u0489\u0003b1\u0000\u0488\u0487\u0001\u0000\u0000"+
		"\u0000\u0488\u0489\u0001\u0000\u0000\u0000\u0489\u048a\u0001\u0000\u0000"+
		"\u0000\u048a\u048b\u0003d2\u0000\u048b\u048c\u0001\u0000\u0000\u0000\u048c"+
		"\u048d\u0005\u0002\u0000\u0000\u048d\u048e\u0005\u0002\u0000\u0000\u048e"+
		"\u04a5\u0001\u0000\u0000\u0000\u048f\u0490\u0005A\u0000\u0000\u0490\u0491"+
		"\u0005\u0001\u0000\u0000\u0491\u0492\u0005\u008c\u0000\u0000\u0492\u0494"+
		"\u0005\u0001\u0000\u0000\u0493\u0495\u0003b1\u0000\u0494\u0493\u0001\u0000"+
		"\u0000\u0000\u0494\u0495\u0001\u0000\u0000\u0000\u0495\u0496\u0001\u0000"+
		"\u0000\u0000\u0496\u0497\u0003d2\u0000\u0497\u0498\u0001\u0000\u0000\u0000"+
		"\u0498\u0499\u0005\u0002\u0000\u0000\u0499\u049a\u0005\u0002\u0000\u0000"+
		"\u049a\u04a5\u0001\u0000\u0000\u0000\u049b\u049c\u0005\u008b\u0000\u0000"+
		"\u049c\u049d\u0005\u0001\u0000\u0000\u049d\u049e\u0003\u0006\u0003\u0000"+
		"\u049e\u049f\u0005\u008c\u0000\u0000\u049f\u04a0\u0005\u0001\u0000\u0000"+
		"\u04a0\u04a1\u0003b1\u0000\u04a1\u04a2\u0005\u0002\u0000\u0000\u04a2\u04a3"+
		"\u0005\u0002\u0000\u0000\u04a3\u04a5\u0001\u0000\u0000\u0000\u04a4\u046a"+
		"\u0001\u0000\u0000\u0000\u04a4\u047b\u0001\u0000\u0000\u0000\u04a4\u048f"+
		"\u0001\u0000\u0000\u0000\u04a4\u049b\u0001\u0000\u0000\u0000\u04a5K\u0001"+
		"\u0000\u0000\u0000\u04a6\u04a7\u0003\u00be_\u0000\u04a7\u04a8\u00058\u0000"+
		"\u0000\u04a8\u04a9\u0003\u00be_\u0000\u04a9M\u0001\u0000\u0000\u0000\u04aa"+
		"\u04af\u0003P(\u0000\u04ab\u04ac\u0005\u0011\u0000\u0000\u04ac\u04ae\u0003"+
		"P(\u0000\u04ad\u04ab\u0001\u0000\u0000\u0000\u04ae\u04b1\u0001\u0000\u0000"+
		"\u0000\u04af\u04ad\u0001\u0000\u0000\u0000\u04af\u04b0\u0001\u0000\u0000"+
		"\u0000\u04b0O\u0001\u0000\u0000\u0000\u04b1\u04af\u0001\u0000\u0000\u0000"+
		"\u04b2\u04b4\u0003\u00ccf\u0000\u04b3\u04b2\u0001\u0000\u0000\u0000\u04b3"+
		"\u04b4\u0001\u0000\u0000\u0000\u04b4\u04b5\u0001\u0000\u0000\u0000\u04b5"+
		"\u04b6\u0003\u00be_\u0000\u04b6\u04b7\u0005\u0014\u0000\u0000\u04b7\u04b8"+
		"\u0003D\"\u0000\u04b8Q\u0001\u0000\u0000\u0000\u04b9\u04bb\u0003\u00cc"+
		"f\u0000\u04ba\u04b9\u0001\u0000\u0000\u0000\u04ba\u04bb\u0001\u0000\u0000"+
		"\u0000\u04bb\u04bc\u0001\u0000\u0000\u0000\u04bc\u04bd\u0003\u00be_\u0000"+
		"\u04bd\u04be\u0005\u0014\u0000\u0000\u04be\u04bf\u0003\u0006\u0003\u0000"+
		"\u04bfS\u0001\u0000\u0000\u0000\u04c0\u04c1\u0003\u00be_\u0000\u04c1\u04c2"+
		"\u0005\u0007\u0000\u0000\u04c2\u04c3\u0003V+\u0000\u04c3U\u0001\u0000"+
		"\u0000\u0000\u04c4\u04d1\u0003\u00d6k\u0000\u04c5\u04c6\u0005\u00ce\u0000"+
		"\u0000\u04c6\u04c7\u0005\u0001\u0000\u0000\u04c7\u04c8\u0003\u00d6k\u0000"+
		"\u04c8\u04c9\u0005\u0011\u0000\u0000\u04c9\u04cc\u0003\u00d8l\u0000\u04ca"+
		"\u04cb\u0005\u0011\u0000\u0000\u04cb\u04cd\u0005\u00e8\u0000\u0000\u04cc"+
		"\u04ca\u0001\u0000\u0000\u0000\u04cc\u04cd\u0001\u0000\u0000\u0000\u04cd"+
		"\u04ce\u0001\u0000\u0000\u0000\u04ce\u04cf\u0005\u0002\u0000\u0000\u04cf"+
		"\u04d1\u0001\u0000\u0000\u0000\u04d0\u04c4\u0001\u0000\u0000\u0000\u04d0"+
		"\u04c5\u0001\u0000\u0000\u0000\u04d1W\u0001\u0000\u0000\u0000\u04d2\u04d7"+
		"\u0003\\.\u0000\u04d3\u04d4\u0005\u0011\u0000\u0000\u04d4\u04d6\u0003"+
		"\\.\u0000\u04d5\u04d3\u0001\u0000\u0000\u0000\u04d6\u04d9\u0001\u0000"+
		"\u0000\u0000\u04d7\u04d5\u0001\u0000\u0000\u0000\u04d7\u04d8\u0001\u0000"+
		"\u0000\u0000\u04d8Y\u0001\u0000\u0000\u0000\u04d9\u04d7\u0001\u0000\u0000"+
		"\u0000\u04da\u04df\u0003\\.\u0000\u04db\u04dc\u0005\u0011\u0000\u0000"+
		"\u04dc\u04de\u0003\\.\u0000\u04dd\u04db\u0001\u0000\u0000\u0000\u04de"+
		"\u04e1\u0001\u0000\u0000\u0000\u04df\u04dd\u0001\u0000\u0000\u0000\u04df"+
		"\u04e0\u0001\u0000\u0000\u0000\u04e0\u04eb\u0001\u0000\u0000\u0000\u04e1"+
		"\u04df\u0001\u0000\u0000\u0000\u04e2\u04e3\u0005\u001a\u0000\u0000\u04e3"+
		"\u04e8\u0003\u00be_\u0000\u04e4\u04e5\u0005\u0011\u0000\u0000\u04e5\u04e7"+
		"\u0003\u00be_\u0000\u04e6\u04e4\u0001\u0000\u0000\u0000\u04e7\u04ea\u0001"+
		"\u0000\u0000\u0000\u04e8\u04e6\u0001\u0000\u0000\u0000\u04e8\u04e9\u0001"+
		"\u0000\u0000\u0000\u04e9\u04ec\u0001\u0000\u0000\u0000\u04ea\u04e8\u0001"+
		"\u0000\u0000\u0000\u04eb\u04e2\u0001\u0000\u0000\u0000\u04eb\u04ec\u0001"+
		"\u0000\u0000\u0000\u04ec[\u0001\u0000\u0000\u0000\u04ed\u04f0\u0003\u0004"+
		"\u0002\u0000\u04ee\u04ef\u0005#\u0000\u0000\u04ef\u04f1\u0003\u00b8\\"+
		"\u0000\u04f0\u04ee\u0001\u0000\u0000\u0000\u04f0\u04f1\u0001\u0000\u0000"+
		"\u0000\u04f1]\u0001\u0000\u0000\u0000\u04f2\u04f4\u0003\u0012\t\u0000"+
		"\u04f3\u04f2\u0001\u0000\u0000\u0000\u04f3\u04f4\u0001\u0000\u0000\u0000"+
		"\u04f4\u04f8\u0001\u0000\u0000\u0000\u04f5\u04f9\u0003\u0014\n\u0000\u04f6"+
		"\u04f9\u0003`0\u0000\u04f7\u04f9\u0003\u0010\b\u0000\u04f8\u04f5\u0001"+
		"\u0000\u0000\u0000\u04f8\u04f6\u0001\u0000\u0000\u0000\u04f8\u04f7\u0001"+
		"\u0000\u0000\u0000\u04f8\u04f9\u0001\u0000\u0000\u0000\u04f9\u04fb\u0001"+
		"\u0000\u0000\u0000\u04fa\u04fc\u0003\u0016\u000b\u0000\u04fb\u04fa\u0001"+
		"\u0000\u0000\u0000\u04fb\u04fc\u0001\u0000\u0000\u0000\u04fc\u04fe\u0001"+
		"\u0000\u0000\u0000\u04fd\u04ff\u0003\u000e\u0007\u0000\u04fe\u04fd\u0001"+
		"\u0000\u0000\u0000\u04fe\u04ff\u0001\u0000\u0000\u0000\u04ff_\u0001\u0000"+
		"\u0000\u0000\u0500\u0501\u0005\u00c2\u0000\u0000\u0501\u0502\u0003\u0004"+
		"\u0002\u0000\u0502a\u0001\u0000\u0000\u0000\u0503\u0504\u0005\u0090\u0000"+
		"\u0000\u0504\u0505\u0005@\u0000\u0000\u0505\u050a\u0003\u00be_\u0000\u0506"+
		"\u0507\u0005\u0011\u0000\u0000\u0507\u0509\u0003\u00be_\u0000\u0508\u0506"+
		"\u0001\u0000\u0000\u0000\u0509\u050c\u0001\u0000\u0000\u0000\u050a\u0508"+
		"\u0001\u0000\u0000\u0000\u050a\u050b\u0001\u0000\u0000\u0000\u050bc\u0001"+
		"\u0000\u0000\u0000\u050c\u050a\u0001\u0000\u0000\u0000\u050d\u050e\u0005"+
		"?\u0000\u0000\u050e\u050f\u0005@\u0000\u0000\u050f\u0514\u0003f3\u0000"+
		"\u0510\u0511\u0005\u0011\u0000\u0000\u0511\u0513\u0003f3\u0000\u0512\u0510"+
		"\u0001\u0000\u0000\u0000\u0513\u0516\u0001\u0000\u0000\u0000\u0514\u0512"+
		"\u0001\u0000\u0000\u0000\u0514\u0515\u0001\u0000\u0000\u0000\u0515e\u0001"+
		"\u0000\u0000\u0000\u0516\u0514\u0001\u0000\u0000\u0000\u0517\u0519\u0003"+
		"\u00be_\u0000\u0518\u051a\u0007\u0016\u0000\u0000\u0519\u0518\u0001\u0000"+
		"\u0000\u0000\u0519\u051a\u0001\u0000\u0000\u0000\u051ag\u0001\u0000\u0000"+
		"\u0000\u051b\u051c\u0005k\u0000\u0000\u051c\u051f\u0005\u00b0\u0000\u0000"+
		"\u051d\u051f\u0005\u0092\u0000\u0000\u051e\u051b\u0001\u0000\u0000\u0000"+
		"\u051e\u051d\u0001\u0000\u0000\u0000\u051f\u0520\u0001\u0000\u0000\u0000"+
		"\u0520\u0521\u0005(\u0000\u0000\u0521\u0522\u0003l6\u0000\u0522\u0523"+
		"\u0005$\u0000\u0000\u0523\u0524\u0003l6\u0000\u0524i\u0001\u0000\u0000"+
		"\u0000\u0525\u0526\u0005\u00e5\u0000\u0000\u0526k\u0001\u0000\u0000\u0000"+
		"\u0527\u0528\u0005\u00e5\u0000\u0000\u0528\u0533\u0005\u008d\u0000\u0000"+
		"\u0529\u052a\u0005\u00e5\u0000\u0000\u052a\u0533\u0005\u008e\u0000\u0000"+
		"\u052b\u052c\u0005\u0093\u0000\u0000\u052c\u052d\u0005k\u0000\u0000\u052d"+
		"\u0533\u0005\u00b1\u0000\u0000\u052e\u052f\u0005\u008f\u0000\u0000\u052f"+
		"\u0533\u0005\u008d\u0000\u0000\u0530\u0531\u0005\u008f\u0000\u0000\u0531"+
		"\u0533\u0005\u008e\u0000\u0000\u0532\u0527\u0001\u0000\u0000\u0000\u0532"+
		"\u0529\u0001\u0000\u0000\u0000\u0532\u052b\u0001\u0000\u0000\u0000\u0532"+
		"\u052e\u0001\u0000\u0000\u0000\u0532\u0530\u0001\u0000\u0000\u0000\u0533"+
		"m\u0001\u0000\u0000\u0000\u0534\u0535\u0005\u0084\u0000\u0000\u0535\u0536"+
		"\u0007\u0017\u0000\u0000\u0536\u053b\u0003\u00be_\u0000\u0537\u0538\u0005"+
		"\u0011\u0000\u0000\u0538\u053a\u0003\u00be_\u0000\u0539\u0537\u0001\u0000"+
		"\u0000\u0000\u053a\u053d\u0001\u0000\u0000\u0000\u053b\u0539\u0001\u0000"+
		"\u0000\u0000\u053b\u053c\u0001\u0000\u0000\u0000\u053c\u0542\u0001\u0000"+
		"\u0000\u0000\u053d\u053b\u0001\u0000\u0000\u0000\u053e\u053f\u0005\u0084"+
		"\u0000\u0000\u053f\u0540\u0005<\u0000\u0000\u0540\u0542\u0003\u0006\u0003"+
		"\u0000\u0541\u0534\u0001\u0000\u0000\u0000\u0541\u053e\u0001\u0000\u0000"+
		"\u0000\u0542o\u0001\u0000\u0000\u0000\u0543\u0544\u0005\u0086\u0000\u0000"+
		"\u0544\u0545\u0003\u0006\u0003\u0000\u0545q\u0001\u0000\u0000\u0000\u0546"+
		"\u0547\u0003\u00ba]\u0000\u0547\u054a\u0003x<\u0000\u0548\u0549\u0005"+
		"\u00d1\u0000\u0000\u0549\u054b\u0003V+\u0000\u054a\u0548\u0001\u0000\u0000"+
		"\u0000\u054a\u054b\u0001\u0000\u0000\u0000\u054bs\u0001\u0000\u0000\u0000"+
		"\u054c\u0550\u0003|>\u0000\u054d\u0550\u0003\u0080@\u0000\u054e\u0550"+
		"\u0003~?\u0000\u054f\u054c\u0001\u0000\u0000\u0000\u054f\u054d\u0001\u0000"+
		"\u0000\u0000\u054f\u054e\u0001\u0000\u0000\u0000\u0550u\u0001\u0000\u0000"+
		"\u0000\u0551\u0554\u0003~?\u0000\u0552\u0554\u0003|>\u0000\u0553\u0551"+
		"\u0001\u0000\u0000\u0000\u0553\u0552\u0001\u0000\u0000\u0000\u0554w\u0001"+
		"\u0000\u0000\u0000\u0555\u055b\u0003|>\u0000\u0556\u055b\u0003\u0080@"+
		"\u0000\u0557\u055b\u0003\u0084B\u0000\u0558\u055b\u0003z=\u0000\u0559"+
		"\u055b\u0003~?\u0000\u055a\u0555\u0001\u0000\u0000\u0000\u055a\u0556\u0001"+
		"\u0000\u0000\u0000\u055a\u0557\u0001\u0000\u0000\u0000\u055a\u0558\u0001"+
		"\u0000\u0000\u0000\u055a\u0559\u0001\u0000\u0000\u0000\u055by\u0001\u0000"+
		"\u0000\u0000\u055c\u0560\u0005s\u0000\u0000\u055d\u0560\u0003\u0086C\u0000"+
		"\u055e\u0560\u0003\u0088D\u0000\u055f\u055c\u0001\u0000\u0000\u0000\u055f"+
		"\u055d\u0001\u0000\u0000\u0000\u055f\u055e\u0001\u0000\u0000\u0000\u0560"+
		"{\u0001\u0000\u0000\u0000\u0561\u0564\u0003\u00d8l\u0000\u0562\u0564\u0003"+
		"\u008aE\u0000\u0563\u0561\u0001\u0000\u0000\u0000\u0563\u0562\u0001\u0000"+
		"\u0000\u0000\u0564\u0566\u0001\u0000\u0000\u0000\u0565\u0567\u0003\u00a4"+
		"R\u0000\u0566\u0565\u0001\u0000\u0000\u0000\u0566\u0567\u0001\u0000\u0000"+
		"\u0000\u0567\u056c\u0001\u0000\u0000\u0000\u0568\u056a\u0005\'\u0000\u0000"+
		"\u0569\u0568\u0001\u0000\u0000\u0000\u0569\u056a\u0001\u0000\u0000\u0000"+
		"\u056a\u056b\u0001\u0000\u0000\u0000\u056b\u056d\u0005+\u0000\u0000\u056c"+
		"\u0569\u0001\u0000\u0000\u0000\u056c\u056d\u0001\u0000\u0000\u0000\u056d"+
		"}\u0001\u0000\u0000\u0000\u056e\u0573\u0003\u00ccf\u0000\u056f\u0570\u0005"+
		"\b\u0000\u0000\u0570\u0571\u0003|>\u0000\u0571\u0572\u0005\t\u0000\u0000"+
		"\u0572\u0574\u0001\u0000\u0000\u0000\u0573\u056f\u0001\u0000\u0000\u0000"+
		"\u0573\u0574\u0001\u0000\u0000\u0000\u0574\u007f\u0001\u0000\u0000\u0000"+
		"\u0575\u0581\u0005m\u0000\u0000\u0576\u0577\u0005\u0005\u0000\u0000\u0577"+
		"\u057c\u0003\u00a6S\u0000\u0578\u0579\u0005\u0011\u0000\u0000\u0579\u057b"+
		"\u0003\u00a6S\u0000\u057a\u0578\u0001\u0000\u0000\u0000\u057b\u057e\u0001"+
		"\u0000\u0000\u0000\u057c\u057a\u0001\u0000\u0000\u0000\u057c\u057d\u0001"+
		"\u0000\u0000\u0000\u057d\u057f\u0001\u0000\u0000\u0000\u057e\u057c\u0001"+
		"\u0000\u0000\u0000\u057f\u0580\u0005\u0006\u0000\u0000\u0580\u0582\u0001"+
		"\u0000\u0000\u0000\u0581\u0576\u0001\u0000\u0000\u0000\u0581\u0582\u0001"+
		"\u0000\u0000\u0000\u0582\u0081\u0001\u0000\u0000\u0000\u0583\u0586\u0003"+
		"\u0080@\u0000\u0584\u0586\u0003|>\u0000\u0585\u0583\u0001\u0000\u0000"+
		"\u0000\u0585\u0584\u0001\u0000\u0000\u0000\u0586\u0083\u0001\u0000\u0000"+
		"\u0000\u0587\u058c\u0005\u00e3\u0000\u0000\u0588\u0589\u0005\b\u0000\u0000"+
		"\u0589\u058a\u0003|>\u0000\u058a\u058b\u0005\t\u0000\u0000\u058b\u058d"+
		"\u0001\u0000\u0000\u0000\u058c\u0588\u0001\u0000\u0000\u0000\u058c\u058d"+
		"\u0001\u0000\u0000\u0000\u058d\u0085\u0001\u0000\u0000\u0000\u058e\u05ac"+
		"\u0005q\u0000\u0000\u058f\u059b\u0005\u00df\u0000\u0000\u0590\u0591\u0005"+
		"\u0005\u0000\u0000\u0591\u0596\u0003\u008aE\u0000\u0592\u0593\u0005\u000f"+
		"\u0000\u0000\u0593\u0595\u0003\u008aE\u0000\u0594\u0592\u0001\u0000\u0000"+
		"\u0000\u0595\u0598\u0001\u0000\u0000\u0000\u0596\u0594\u0001\u0000\u0000"+
		"\u0000\u0596\u0597\u0001\u0000\u0000\u0000\u0597\u0599\u0001\u0000\u0000"+
		"\u0000\u0598\u0596\u0001\u0000\u0000\u0000\u0599\u059a\u0005\u0006\u0000"+
		"\u0000\u059a\u059c\u0001\u0000\u0000\u0000\u059b\u0590\u0001\u0000\u0000"+
		"\u0000\u059b\u059c\u0001\u0000\u0000\u0000\u059c\u05ac\u0001\u0000\u0000"+
		"\u0000\u059d\u05a9\u0005\u00e0\u0000\u0000\u059e\u059f\u0005\u0005\u0000"+
		"\u0000\u059f\u05a4\u0003\u00ba]\u0000\u05a0\u05a1\u0005\u000f\u0000\u0000"+
		"\u05a1\u05a3\u0003\u00ba]\u0000\u05a2\u05a0\u0001\u0000\u0000\u0000\u05a3"+
		"\u05a6\u0001\u0000\u0000\u0000\u05a4\u05a2\u0001\u0000\u0000\u0000\u05a4"+
		"\u05a5\u0001\u0000\u0000\u0000\u05a5\u05a7\u0001\u0000\u0000\u0000\u05a6"+
		"\u05a4\u0001\u0000\u0000\u0000\u05a7\u05a8\u0005\u0006\u0000\u0000\u05a8"+
		"\u05aa\u0001\u0000\u0000\u0000\u05a9\u059e\u0001\u0000\u0000\u0000\u05a9"+
		"\u05aa\u0001\u0000\u0000\u0000\u05aa\u05ac\u0001\u0000\u0000\u0000\u05ab"+
		"\u058e\u0001\u0000\u0000\u0000\u05ab\u058f\u0001\u0000\u0000\u0000\u05ab"+
		"\u059d\u0001\u0000\u0000\u0000\u05ac\u0087\u0001\u0000\u0000\u0000\u05ad"+
		"\u05d6\u0005r\u0000\u0000\u05ae\u05bf\u0005\u00e1\u0000\u0000\u05af\u05b0"+
		"\u0005\u0005\u0000\u0000\u05b0\u05bc\u0005\u00e9\u0000\u0000\u05b1\u05b2"+
		"\u0005\u0001\u0000\u0000\u05b2\u05b7\u0003\u008aE\u0000\u05b3\u05b4\u0005"+
		"\u000f\u0000\u0000\u05b4\u05b6\u0003\u008aE\u0000\u05b5\u05b3\u0001\u0000"+
		"\u0000\u0000\u05b6\u05b9\u0001\u0000\u0000\u0000\u05b7\u05b5\u0001\u0000"+
		"\u0000\u0000\u05b7\u05b8\u0001\u0000\u0000\u0000\u05b8\u05ba\u0001\u0000"+
		"\u0000\u0000\u05b9\u05b7\u0001\u0000\u0000\u0000\u05ba\u05bb\u0005\u0002"+
		"\u0000\u0000\u05bb\u05bd\u0001\u0000\u0000\u0000\u05bc\u05b1\u0001\u0000"+
		"\u0000\u0000\u05bc\u05bd\u0001\u0000\u0000\u0000\u05bd\u05be\u0001\u0000"+
		"\u0000\u0000\u05be\u05c0\u0005\u0006\u0000\u0000\u05bf\u05af\u0001\u0000"+
		"\u0000\u0000\u05bf\u05c0\u0001\u0000\u0000\u0000\u05c0\u05d6\u0001\u0000"+
		"\u0000\u0000\u05c1\u05d3\u0005\u00e2\u0000\u0000\u05c2\u05c3\u0005\u0005"+
		"\u0000\u0000\u05c3\u05cf\u0003\u00ba]\u0000\u05c4\u05c5\u0005\u0001\u0000"+
		"\u0000\u05c5\u05ca\u0003\u00ba]\u0000\u05c6\u05c7\u0005\u000f\u0000\u0000"+
		"\u05c7\u05c9\u0003\u00ba]\u0000\u05c8\u05c6\u0001\u0000\u0000\u0000\u05c9"+
		"\u05cc\u0001\u0000\u0000\u0000\u05ca\u05c8\u0001\u0000\u0000\u0000\u05ca"+
		"\u05cb\u0001\u0000\u0000\u0000\u05cb\u05cd\u0001\u0000\u0000\u0000\u05cc"+
		"\u05ca\u0001\u0000\u0000\u0000\u05cd\u05ce\u0005\u0002\u0000\u0000\u05ce"+
		"\u05d0\u0001\u0000\u0000\u0000\u05cf\u05c4\u0001\u0000\u0000\u0000\u05cf"+
		"\u05d0\u0001\u0000\u0000\u0000\u05d0\u05d1\u0001\u0000\u0000\u0000\u05d1"+
		"\u05d2\u0005\u0006\u0000\u0000\u05d2\u05d4\u0001\u0000\u0000\u0000\u05d3"+
		"\u05c2\u0001\u0000\u0000\u0000\u05d3\u05d4\u0001\u0000\u0000\u0000\u05d4"+
		"\u05d6\u0001\u0000\u0000\u0000\u05d5\u05ad\u0001\u0000\u0000\u0000\u05d5"+
		"\u05ae\u0001\u0000\u0000\u0000\u05d5\u05c1\u0001\u0000\u0000\u0000\u05d6"+
		"\u0089\u0001\u0000\u0000\u0000\u05d7\u05d8\u0005\u00e9\u0000\u0000\u05d8"+
		"\u008b\u0001\u0000\u0000\u0000\u05d9\u05da\u0005\u00e9\u0000\u0000\u05da"+
		"\u008d\u0001\u0000\u0000\u0000\u05db\u05dc\u0007\u0018\u0000\u0000\u05dc"+
		"\u05e1\u0003\u0090H\u0000\u05dd\u05de\u0005\u0011\u0000\u0000\u05de\u05e0"+
		"\u0003\u0090H\u0000\u05df\u05dd\u0001\u0000\u0000\u0000\u05e0\u05e3\u0001"+
		"\u0000\u0000\u0000\u05e1\u05df\u0001\u0000\u0000\u0000\u05e1\u05e2\u0001"+
		"\u0000\u0000\u0000\u05e2\u008f\u0001\u0000\u0000\u0000\u05e3\u05e1\u0001"+
		"\u0000\u0000\u0000\u05e4\u05e7\u0003\u00ba]\u0000\u05e5\u05e6\u0005#\u0000"+
		"\u0000\u05e6\u05e8\u0003\u00b8\\\u0000\u05e7\u05e5\u0001\u0000\u0000\u0000"+
		"\u05e7\u05e8\u0001\u0000\u0000\u0000\u05e8\u0091\u0001\u0000\u0000\u0000"+
		"\u05e9\u05ee\u0003\u0094J\u0000\u05ea\u05eb\u0005\u00eb\u0000\u0000\u05eb"+
		"\u05ed\u0003\u0094J\u0000\u05ec\u05ea\u0001\u0000\u0000\u0000\u05ed\u05f0"+
		"\u0001\u0000\u0000\u0000\u05ee\u05ec\u0001\u0000\u0000\u0000\u05ee\u05ef"+
		"\u0001\u0000\u0000\u0000\u05ef\u0093\u0001\u0000\u0000\u0000\u05f0\u05ee"+
		"\u0001\u0000\u0000\u0000\u05f1\u05f2\u0005\u00e9\u0000\u0000\u05f2\u05f4"+
		"\u0005\u0013\u0000\u0000\u05f3\u05f1\u0001\u0000\u0000\u0000\u05f3\u05f4"+
		"\u0001\u0000\u0000\u0000\u05f4\u05f9\u0001\u0000\u0000\u0000\u05f5\u05f6"+
		"\u0005\u00ad\u0000\u0000\u05f6\u05f7\u0003\u0006\u0003\u0000\u05f7\u05f8"+
		"\u0005\u0018\u0000\u0000\u05f8\u05fa\u0001\u0000\u0000\u0000\u05f9\u05f5"+
		"\u0001\u0000\u0000\u0000\u05f9\u05fa\u0001\u0000\u0000\u0000\u05fa\u05fb"+
		"\u0001\u0000\u0000\u0000\u05fb\u05fd\u0003\u0006\u0003\u0000\u05fc\u05fe"+
		"\u0003\u00c2a\u0000\u05fd\u05fc\u0001\u0000\u0000\u0000\u05fd\u05fe\u0001"+
		"\u0000\u0000\u0000\u05fe\u0600\u0001\u0000\u0000\u0000\u05ff\u0601\u0003"+
		"\u00c4b\u0000\u0600\u05ff\u0001\u0000\u0000\u0000\u0600\u0601\u0001\u0000"+
		"\u0000\u0000\u0601\u0095\u0001\u0000\u0000\u0000\u0602\u0607\u0003\u0098"+
		"L\u0000\u0603\u0604\u0005\u00eb\u0000\u0000\u0604\u0606\u0003\u0098L\u0000"+
		"\u0605\u0603\u0001\u0000\u0000\u0000\u0606\u0609\u0001\u0000\u0000\u0000"+
		"\u0607\u0605\u0001\u0000\u0000\u0000\u0607\u0608\u0001\u0000\u0000\u0000"+
		"\u0608\u0097\u0001\u0000\u0000\u0000\u0609\u0607\u0001\u0000\u0000\u0000"+
		"\u060a\u060b\u0005\u00e9\u0000\u0000\u060b\u060d\u0005\u0013\u0000\u0000"+
		"\u060c\u060a\u0001\u0000\u0000\u0000\u060c\u060d\u0001\u0000\u0000\u0000"+
		"\u060d\u060e\u0001\u0000\u0000\u0000\u060e\u0610\u0003\u009eO\u0000\u060f"+
		"\u0611\u0003\u00c2a\u0000\u0610\u060f\u0001\u0000\u0000\u0000\u0610\u0611"+
		"\u0001\u0000\u0000\u0000\u0611\u0613\u0001\u0000\u0000\u0000\u0612\u0614"+
		"\u0003\u00c4b\u0000\u0613\u0612\u0001\u0000\u0000\u0000\u0613\u0614\u0001"+
		"\u0000\u0000\u0000\u0614\u0099\u0001\u0000\u0000\u0000\u0615\u0618\u0007"+
		"\u0018\u0000\u0000\u0616\u0617\u0005\u009b\u0000\u0000\u0617\u0619\u0003"+
		"\u009cN\u0000\u0618\u0616\u0001\u0000\u0000\u0000\u0618\u0619\u0001\u0000"+
		"\u0000\u0000\u0619\u061a\u0001\u0000\u0000\u0000\u061a\u061b\u0005t\u0000"+
		"\u0000\u061b\u061c\u0005\u00e9\u0000\u0000\u061c\u009b\u0001\u0000\u0000"+
		"\u0000\u061d\u0622\u0003\u0090H\u0000\u061e\u061f\u0005\u0011\u0000\u0000"+
		"\u061f\u0621\u0003\u0090H\u0000\u0620\u061e\u0001\u0000\u0000\u0000\u0621"+
		"\u0624\u0001\u0000\u0000\u0000\u0622\u0620\u0001\u0000\u0000\u0000\u0622"+
		"\u0623\u0001\u0000\u0000\u0000\u0623\u009d\u0001\u0000\u0000\u0000\u0624"+
		"\u0622\u0001\u0000\u0000\u0000\u0625\u0626\u0005\u00ad\u0000\u0000\u0626"+
		"\u0627\u0003\u0006\u0003\u0000\u0627\u0628\u0005\u0018\u0000\u0000\u0628"+
		"\u062a\u0001\u0000\u0000\u0000\u0629\u0625\u0001\u0000\u0000\u0000\u0629"+
		"\u062a\u0001\u0000\u0000\u0000\u062a\u062b\u0001\u0000\u0000\u0000\u062b"+
		"\u062d\u0003\u00a2Q\u0000\u062c\u062e\u0003\u00c6c\u0000\u062d\u062c\u0001"+
		"\u0000\u0000\u0000\u062d\u062e\u0001\u0000\u0000\u0000\u062e\u062f\u0001"+
		"\u0000\u0000\u0000\u062f\u0633\u0003\u00a0P\u0000\u0630\u0632\u0003\u00a0"+
		"P\u0000\u0631\u0630\u0001\u0000\u0000\u0000\u0632\u0635\u0001\u0000\u0000"+
		"\u0000\u0633\u0631\u0001\u0000\u0000\u0000\u0633\u0634\u0001\u0000\u0000"+
		"\u0000\u0634\u009f\u0001\u0000\u0000\u0000\u0635\u0633\u0001\u0000\u0000"+
		"\u0000\u0636\u0638\u0007\u0019\u0000\u0000\u0637\u0636\u0001\u0000\u0000"+
		"\u0000\u0637\u0638\u0001\u0000\u0000\u0000\u0638\u0639\u0001\u0000\u0000"+
		"\u0000\u0639\u063e\u0003\u00a2Q\u0000\u063a\u063b\u0005\u0003\u0000\u0000"+
		"\u063b\u063c\u0003\u0006\u0003\u0000\u063c\u063d\u0005\u0004\u0000\u0000"+
		"\u063d\u063f\u0001\u0000\u0000\u0000\u063e\u063a\u0001\u0000\u0000\u0000"+
		"\u063e\u063f\u0001\u0000\u0000\u0000\u063f\u00a1\u0001\u0000\u0000\u0000"+
		"\u0640\u0641\u0007\u001a\u0000\u0000\u0641\u00a3\u0001\u0000\u0000\u0000"+
		"\u0642\u0643\u0005\u0003\u0000\u0000\u0643\u0644\u0003\u0006\u0003\u0000"+
		"\u0644\u0645\u0005\u0004\u0000\u0000\u0645\u0652\u0001\u0000\u0000\u0000"+
		"\u0646\u0647\u0005\u0005\u0000\u0000\u0647\u064c\u0003V+\u0000\u0648\u0649"+
		"\u0005\u0011\u0000\u0000\u0649\u064b\u0003V+\u0000\u064a\u0648\u0001\u0000"+
		"\u0000\u0000\u064b\u064e\u0001\u0000\u0000\u0000\u064c\u064a\u0001\u0000"+
		"\u0000\u0000\u064c\u064d\u0001\u0000\u0000\u0000\u064d\u064f\u0001\u0000"+
		"\u0000\u0000\u064e\u064c\u0001\u0000\u0000\u0000\u064f\u0650\u0005\u0006"+
		"\u0000\u0000\u0650\u0652\u0001\u0000\u0000\u0000\u0651\u0642\u0001\u0000"+
		"\u0000\u0000\u0651\u0646\u0001\u0000\u0000\u0000\u0652\u00a5\u0001\u0000"+
		"\u0000\u0000\u0653\u0656\u0003~?\u0000\u0654\u0657\u0003\u00be_\u0000"+
		"\u0655\u0657\u0003\u00a8T\u0000\u0656\u0654\u0001\u0000\u0000\u0000\u0656"+
		"\u0655\u0001\u0000\u0000\u0000\u0657\u00a7\u0001\u0000\u0000\u0000\u0658"+
		"\u065a\u0005g\u0000\u0000\u0659\u065b\u0007\u001b\u0000\u0000\u065a\u0659"+
		"\u0001\u0000\u0000\u0000\u065a\u065b\u0001\u0000\u0000\u0000\u065b\u00a9"+
		"\u0001\u0000\u0000\u0000\u065c\u065d\u0007\u001c\u0000\u0000\u065d\u00ab"+
		"\u0001\u0000\u0000\u0000\u065e\u065f\u0007\u001d\u0000\u0000\u065f\u00ad"+
		"\u0001\u0000\u0000\u0000\u0660\u0661\u0005\u009b\u0000\u0000\u0661\u0666"+
		"\u0003\u00be_\u0000\u0662\u0663\u0005\u0011\u0000\u0000\u0663\u0665\u0003"+
		"\u00be_\u0000\u0664\u0662\u0001\u0000\u0000\u0000\u0665\u0668\u0001\u0000"+
		"\u0000\u0000\u0666\u0664\u0001\u0000\u0000\u0000\u0666\u0667\u0001\u0000"+
		"\u0000\u0000\u0667\u00af\u0001\u0000\u0000\u0000\u0668\u0666\u0001\u0000"+
		"\u0000\u0000\u0669\u066a\u0007\u001e\u0000\u0000\u066a\u00b1\u0001\u0000"+
		"\u0000\u0000\u066b\u066c\u0005:\u0000\u0000\u066c\u066d\u0003\u0004\u0002"+
		"\u0000\u066d\u00b3\u0001\u0000\u0000\u0000\u066e\u066f\u0007\u001f\u0000"+
		"\u0000\u066f\u00b5\u0001\u0000\u0000\u0000\u0670\u0671\u0007 \u0000\u0000"+
		"\u0671\u00b7\u0001\u0000\u0000\u0000\u0672\u0673\u0005\u00e9\u0000\u0000"+
		"\u0673\u00b9\u0001\u0000\u0000\u0000\u0674\u0675\u0005\u00e9\u0000\u0000"+
		"\u0675\u00bb\u0001\u0000\u0000\u0000\u0676\u0677\u0005\u00e9\u0000\u0000"+
		"\u0677\u00bd\u0001\u0000\u0000\u0000\u0678\u067b\u0005\u00e9\u0000\u0000"+
		"\u0679\u067a\u0005\u0015\u0000\u0000\u067a\u067c\u0005\u00e9\u0000\u0000"+
		"\u067b\u0679\u0001\u0000\u0000\u0000\u067b\u067c\u0001\u0000\u0000\u0000"+
		"\u067c\u00bf\u0001\u0000\u0000\u0000\u067d\u067e\u0005\u0005\u0000\u0000"+
		"\u067e\u0683\u0003V+\u0000\u067f\u0680\u0005\u0011\u0000\u0000\u0680\u0682"+
		"\u0003V+\u0000\u0681\u067f\u0001\u0000\u0000\u0000\u0682\u0685\u0001\u0000"+
		"\u0000\u0000\u0683\u0681\u0001\u0000\u0000\u0000\u0683\u0684\u0001\u0000"+
		"\u0000\u0000\u0684\u0686\u0001\u0000\u0000\u0000\u0685\u0683\u0001\u0000"+
		"\u0000\u0000\u0686\u0687\u0005\u0006\u0000\u0000\u0687\u00c1\u0001\u0000"+
		"\u0000\u0000\u0688\u0689\u0005;\u0000\u0000\u0689\u068a\u0003\u00d6k\u0000"+
		"\u068a\u00c3\u0001\u0000\u0000\u0000\u068b\u068c\u0005>\u0000\u0000\u068c"+
		"\u068d\u0003\u00d6k\u0000\u068d\u00c5\u0001\u0000\u0000\u0000\u068e\u068f"+
		"\u0007!\u0000\u0000\u068f\u00c7\u0001\u0000\u0000\u0000\u0690\u0693\u0003"+
		"\u0004\u0002\u0000\u0691\u0693\u0005g\u0000\u0000\u0692\u0690\u0001\u0000"+
		"\u0000\u0000\u0692\u0691\u0001\u0000\u0000\u0000\u0693\u00c9\u0001\u0000"+
		"\u0000\u0000\u0694\u0697\u0003\u0006\u0003\u0000\u0695\u0697\u0005g\u0000"+
		"\u0000\u0696\u0694\u0001\u0000\u0000\u0000\u0696\u0695\u0001\u0000\u0000"+
		"\u0000\u0697\u00cb\u0001\u0000\u0000\u0000\u0698\u069e\u0005\\\u0000\u0000"+
		"\u0699\u069e\u0005\u00de\u0000\u0000\u069a\u069e\u0005[\u0000\u0000\u069b"+
		"\u069e\u0005]\u0000\u0000\u069c\u069e\u0003\u00ceg\u0000\u069d\u0698\u0001"+
		"\u0000\u0000\u0000\u069d\u0699\u0001\u0000\u0000\u0000\u069d\u069a\u0001"+
		"\u0000\u0000\u0000\u069d\u069b\u0001\u0000\u0000\u0000\u069d\u069c\u0001"+
		"\u0000\u0000\u0000\u069e\u00cd\u0001\u0000\u0000\u0000\u069f\u06a0\u0005"+
		"b\u0000\u0000\u06a0\u06a1\u0005]\u0000\u0000\u06a1\u00cf\u0001\u0000\u0000"+
		"\u0000\u06a2\u06a3\u0005\u00e9\u0000\u0000\u06a3\u00d1\u0001\u0000\u0000"+
		"\u0000\u06a4\u06a5\u0005\u00e9\u0000\u0000\u06a5\u00d3\u0001\u0000\u0000"+
		"\u0000\u06a6\u06a7\u0005\u00e9\u0000\u0000\u06a7\u00d5\u0001\u0000\u0000"+
		"\u0000\u06a8\u06a9\u0007\"\u0000\u0000\u06a9\u00d7\u0001\u0000\u0000\u0000"+
		"\u06aa\u06ab\u0007#\u0000\u0000\u06ab\u00d9\u0001\u0000\u0000\u0000\u06ac"+
		"\u06ad\u0007$\u0000\u0000\u06ad\u00db\u0001\u0000\u0000\u0000\u00c0\u00e1"+
		"\u00ef\u0102\u0120\u0122\u0124\u0138\u014e\u0150\u0152\u015d\u016b\u0174"+
		"\u017c\u0183\u0185\u0190\u0199\u01ab\u01b4\u01c3\u01ce\u01d1\u01d6\u01f7"+
		"\u0200\u0203\u020d\u0212\u0216\u021c\u0220\u022a\u022e\u0232\u023b\u023e"+
		"\u0248\u024c\u0256\u025b\u025f\u0265\u0269\u026d\u0271\u0275\u0285\u0289"+
		"\u0294\u029f\u02a3\u02a7\u02b7\u02bb\u02c6\u02d1\u02d5\u02d9\u02e5\u02f0"+
		"\u02fc\u0307\u0325\u0329\u0340\u0345\u034d\u0362\u0366\u036a\u0370\u0375"+
		"\u037d\u0392\u0396\u039a\u03a0\u03a9\u03b4\u03bf\u03c7\u03cb\u03ce\u03d1"+
		"\u03d4\u03e3\u03e6\u03e9\u03f3\u03f7\u03fa\u03fd\u0400\u0408\u040b\u040e"+
		"\u0411\u0415\u042d\u0434\u0436\u0440\u0443\u0446\u0451\u0453\u0458\u0468"+
		"\u0470\u0473\u0476\u0481\u0483\u0488\u0494\u04a4\u04af\u04b3\u04ba\u04cc"+
		"\u04d0\u04d7\u04df\u04e8\u04eb\u04f0\u04f3\u04f8\u04fb\u04fe\u050a\u0514"+
		"\u0519\u051e\u0532\u053b\u0541\u054a\u054f\u0553\u055a\u055f\u0563\u0566"+
		"\u0569\u056c\u0573\u057c\u0581\u0585\u058c\u0596\u059b\u05a4\u05a9\u05ab"+
		"\u05b7\u05bc\u05bf\u05ca\u05cf\u05d3\u05d5\u05e1\u05e7\u05ee\u05f3\u05f9"+
		"\u05fd\u0600\u0607\u060c\u0610\u0613\u0618\u0622\u0629\u062d\u0633\u0637"+
		"\u063e\u064c\u0651\u0656\u065a\u0666\u067b\u0683\u0692\u0696\u069d";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}