package io.sdmx.fusion.audit.model.query;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.service.audit.IAuditEventQuery;
import io.sdmx.utils.json.JsonObjectUtil;
import org.codehaus.jettison.json.JSONObject;

public class AuditEventQuery implements IAuditEventQuery {
	private Map<String, String> propertyValues = new HashMap<>();
	private Integer status;
	private String processId;
	private String eventType;
	private String parentId;
	private String ip;
	private Long startPeriod;
	private Long endPeriod;
	private String username;
	private String softwareVersion;
	private Integer offSet = 0;
	private Integer maxResults;
	private Integer maxDuration;
	private Integer minDuration;
	private Boolean persisted;
	private boolean includeChildren;
	private boolean orderAsc;
	private boolean includeAncestor;

	public AuditEventQuery(JSONObject json) {
		this.status = JsonObjectUtil.getInteger(json, "status", true);
		this.processId = JsonObjectUtil.getString(json, "process_id", true);
		this.eventType = JsonObjectUtil.getString(json, "event_type", true);
		this.parentId = JsonObjectUtil.getString(json, "parent", true);
		this.ip = JsonObjectUtil.getString(json, "ip", true);
		this.startPeriod = JsonObjectUtil.getLong(json, "process_start", true);
		this.endPeriod = JsonObjectUtil.getLong(json, "process_end", true);
		this.status = JsonObjectUtil.getInteger(json, "status", true);
		this.username = JsonObjectUtil.getString(json, "username", true);
		this.softwareVersion = JsonObjectUtil.getString(json, "software_version", true);
		this.offSet = JsonObjectUtil.getInteger(json, "offset", true);
		this.maxResults = JsonObjectUtil.getInteger(json, "limit", true);
		this.maxDuration = JsonObjectUtil.getInteger(json, "max_duration", true);
		this.minDuration = JsonObjectUtil.getInteger(json, "min_duration", true);
		this.includeChildren = JsonObjectUtil.getBoolean(json, "children", true);
		this.includeAncestor = JsonObjectUtil.getBoolean(json, "ancestors", true);
		this.persisted = JsonObjectUtil.getBoolean(json, "persisted", true);
		this.orderAsc = JsonObjectUtil.getBoolean(json, "order_asc", true);
	}
	
	public AuditEventQuery() {}
	
	public static AuditEventQuery builder() {
		return new AuditEventQuery();
	}

	@Override
	public boolean orderAsc() {
		return orderAsc;
	}

	@Override
	public Boolean getPersisted() {
		return persisted;
	}

	@Override
	public Integer getMaxDuration() {
		return maxDuration;
	}

	@Override
	public Integer getMinDuration() {
		return minDuration;
	}

	@Override
	public String getEventType() {
		return eventType;
	}

	@Override
	public Integer getOffset() {
		return offSet;
	}

	public void setOffSet(Integer offSet) {
		if(offSet == null || offSet < 0) {
			offSet = 0;
		}
		this.offSet = offSet;
	}
	
	@Override
	public String getIP() {
		return ip;
	}
	
	public void setIP(String ip) {
		this.ip = ip;
	}

	@Override
	public boolean isIncludeChildren() {
		return includeChildren;
	}

	public void setIncludeChildren(boolean bool) {
		this.includeChildren = bool;
	}

	@Override
	public boolean isIncludeAncestor() {
		return includeAncestor;
	}

	public void setIncludeAncestor(boolean includeAncestor) {
		this.includeAncestor = includeAncestor;
	}

	@Override
	public Map<String, String> getPropertyValues() {
		return propertyValues;
	}

	public AuditEventQuery addPropertyValue(String prop, String value) {
		propertyValues.put(prop, value);
		return this;
	}

	@Override
	public Integer getMaxResults() {
		return maxResults;
	}

	public AuditEventQuery setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
		return this;
	}


	@Override
	public Integer getStatus() {
		return status;
	}

	@Override
	public String getProcessId() {
		return processId;
	}

	@Override
	public String getParentId() {
		return parentId;
	}
	public Long getStartPeriod() {
		return startPeriod;
	}
	
	public Long getEndPeriod() {
		return endPeriod;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public String getSoftwareVersion() {
		return softwareVersion;
	}
	
	public AuditEventQuery setStartPeriod(Long startPeriod) {
		this.startPeriod = startPeriod;
		return this;
	}

	public AuditEventQuery setEndPeriod(Long endPeriod) {
		this.endPeriod = endPeriod;
		return this;
	}

	public AuditEventQuery orderAsc(Boolean orderAsc) {
		this.orderAsc = orderAsc;
		return this;
	}
	
	public AuditEventQuery setPersisted(Boolean persisted) {
		this.persisted = persisted;
		return this;
	}

	public AuditEventQuery setStatus(Integer status) {
		this.status = status;
		return this;
	}

	public AuditEventQuery setProcessId(String processId) {
		this.processId = processId;
		return this;
	}

	public AuditEventQuery setParentId(String parentId) {
		this.parentId = parentId;
		return this;
	}

	public AuditEventQuery setUsername(String username) {
		this.username = username;
		return this;
	}

	public AuditEventQuery setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
		return this;
	}
}
