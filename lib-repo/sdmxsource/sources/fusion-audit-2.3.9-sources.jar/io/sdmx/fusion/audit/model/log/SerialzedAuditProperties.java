package io.sdmx.fusion.audit.model.log;

import java.io.IOException;
import java.io.OutputStream;

import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.core.dao.model.serialised.GZipByteArrayPersistable;
import org.codehaus.jettison.json.JSONObject;

public class SerialzedAuditProperties extends GZipByteArrayPersistable {
	private static final long serialVersionUID = 1L;
	private Long eventTime = System.currentTimeMillis();
	
	public SerialzedAuditProperties() {}
	
	public static SerialzedAuditProperties getInstance(String auditId, JSONObject ser) {
		if(ser == null) {
			return null;
		}
		byte[] bytes = ser.toString().getBytes();
		if(bytes.length == 0) {
			return null;
		}
		return new SerialzedAuditProperties(auditId, bytes);
	}

	private SerialzedAuditProperties(String auditId, byte[] bytes) {
		super(auditId);
		try(OutputStream out = getOutputStream()) {
			out.write(bytes);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} 
	}

	public JSONObject getProperties() {
		return JsonObjectUtil.getJsonObject(joinBytes());
	}
	
	public Long getEventTime() {
		return eventTime;
	}

	public void setEventTime(Long eventTime) {
		this.eventTime = eventTime;
	}
}
