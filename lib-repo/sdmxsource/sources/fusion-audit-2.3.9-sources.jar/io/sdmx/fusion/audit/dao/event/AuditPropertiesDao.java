package io.sdmx.fusion.audit.dao.event;

import io.sdmx.fusion.audit.api.dao.event.IAuditPropertiesDao;
import io.sdmx.fusion.audit.model.log.SerialzedAuditProperties;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import org.codehaus.jettison.json.JSONObject;

public class AuditPropertiesDao implements IAuditPropertiesDao, IObjectDAOClient<SerialzedAuditProperties> {

	private IObjectDAO<SerialzedAuditProperties> dao;

	public AuditPropertiesDao(IObjectDAOFactory factory) {
		factory.register(this);
	}
	
	@Override
	public void setObjectDAO(IObjectDAO<SerialzedAuditProperties> dao) {
		this.dao = dao;
	}

	@Override
	public Class<SerialzedAuditProperties> toPersist() {
		return SerialzedAuditProperties.class;
	}

	@Override
	public void saveProperties(String auditId, JSONObject json) {
		SerialzedAuditProperties instance = SerialzedAuditProperties.getInstance(auditId, json);
		if(instance != null) {
			dao.save(instance);
		}
	}

	@Override
	public JSONObject getProperties(String auditId) {
		SerialzedAuditProperties props = dao.findById(auditId);
		if(props == null) {
			return new JSONObject();
		}
		return props.getProperties();
	}

	@Override
	public void deleteProperties(String auditId) {
		dao.deleteById(auditId);
	}
	

}
