package io.sdmx.fusion.audit.service;

import java.util.List;

import io.sdmx.api.service.audit.IErrorSubscriptionService;
import io.sdmx.fusion.audit.api.manager.error.IErrorEmailSubscriptionManager;
import io.sdmx.fusion.audit.api.manager.error.IErrorEmailSubscriptionRetrievalManager;
import io.sdmx.fusion.audit.model.error.ErrorSubscription;
import io.sdmx.utils.core.object.ObjectUtil;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class ErrorSubscriptionServiceActivator implements IErrorSubscriptionService {
	private IErrorEmailSubscriptionManager emailSubscriptionManager;
	private IErrorEmailSubscriptionRetrievalManager emailSubscriptionRetrievalManager;

	public ErrorSubscriptionServiceActivator(IErrorEmailSubscriptionManager emailSubscriptionManager,
											 IErrorEmailSubscriptionRetrievalManager emailSubscriptionRetrievalManager) {
		this.emailSubscriptionManager = ObjectUtil.assertNotNull(emailSubscriptionManager);
		this.emailSubscriptionRetrievalManager = ObjectUtil.assertNotNull(emailSubscriptionRetrievalManager);
	}

	@Override
	public JSONArray getSubscriptions(String email, String service, String category) {
		List<ErrorSubscription> subs = emailSubscriptionRetrievalManager.getSubscriptions(email, service, category);
		JSONArray responseArray = new JSONArray();
		try {
			for(ErrorSubscription currentSub : subs) {
				JSONObject subJson = new JSONObject();
				subJson.put("Email", currentSub.getEmail());
				subJson.put("Service", currentSub.getService());
				subJson.put("Category", currentSub.getCategory());
				responseArray.put(subJson);
			}
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return responseArray;
	}

	@Override
	public void subscribe(String email, String service, String category) {
		emailSubscriptionManager.subscribe(email, service, category);
	}

	@Override
	public void unsubscribe(String email, String service, String category) {
		emailSubscriptionManager.unsubscribe(email, service, category);
	}

}
