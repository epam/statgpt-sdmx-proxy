package io.sdmx.fusion.audit.comparator;

import java.util.Comparator;

import io.sdmx.api.audit.IFusionAuditEvent;

public class AuditEventComparator implements Comparator<IFusionAuditEvent> {
	
	public static final AuditEventComparator INSTANCE = new AuditEventComparator();
	
	private AuditEventComparator() {}

	@Override
	public int compare(IFusionAuditEvent o1, IFusionAuditEvent o2) {
		long rt =  o1.getProcessStart() - o2.getProcessStart();
		if(rt == 0) {
			return o1.getUid().compareTo(o2.getUid());
		}
		return rt > 0 ? 1 : -1;
	}
	
}
