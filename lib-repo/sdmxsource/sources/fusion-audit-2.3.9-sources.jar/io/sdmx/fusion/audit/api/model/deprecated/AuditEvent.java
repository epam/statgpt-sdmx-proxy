package io.sdmx.fusion.audit.api.model.deprecated;

import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;

/**
 * Defines an auditable event
 */
@Deprecated
public interface AuditEvent {

	/**
	 * Returns the unique identifier that can be used to group all log messages together
	 * @return
	 */
	String getUid();
	
	/**
	 * If this event resulted in a transaction, then this contains the identifier for the transaction
	 * @return
	 */
	Integer getTransactionId();

	/**
	 * Returns the unique identifier for virtual machine
	 * @return
	 */
	String getVmid();

	/**
	 * Returns the version of the Fusion Prodcut at the time of the audit
	 * @return
	 */
	String getFusionProductVersion();

	/**
	 * Returns the event typs
	 * @return
	 */
	AUDITABLE_TYPE getEventType();

	/**
	 * The name of the server e.g. localhost
	 * @return
	 */
	String getServerName();

	/**
	 * Example FusionRegistry
	 * @return
	 */
	String getServerContext();

	/**
	 * Example ws/rest
	 * @return
	 */
	String getServletPath();

	/**
	 * The path servletPath e.g codelist/ALL/ALL/ALL
	 * @return
	 */
	String getPathInfo();

	/**
	 * Any request parameters that were on the URL
	 * @return
	 */
	String getRequetParameters();

	/**
	 * Defines the protocol that was used HTTP/HTTPS
	 * @return
	 */
	String getProtocol();

	/**
	 * Returns the content negotiation that was supplied
	 * @return
	 */
	String getAcceptHeaders();

	/**
	 * Returns the Accept Language Header
	 * @return
	 */
	String getAcceptLanguage();

	/**
	 * Defines the method used to generate the request (SOAP,GET,POST)
	 * @return
	 */
	String getSubmissionMethod();

	/**
	 * Returns the HTTP Response Status from the request (200=ok)
	 * @return
	 */
	int getHttpResponseStatus();

	/**
	 * Returns the HTTP Server Port from the request
	 * @return
	 */
	int getServerPort();

	Long getRequestTime();

	/**
	 * The duration taken to process the request
	 * @return
	 */
	Long getDuration();

	/**
	 * The user who made the request
	 * @return
	 */
	String getUsername();

	/**
	 * The IP Address that the request originated from
	 * @return
	 */
	String getRequestIp();

	/**
	 * The full user agent string from the request
	 * @return
	 */
	String getUserAgent();

	String getMachineIdentifier();

	String getBrowserName();

	String getBrowserVersion();

	String getOperatingSystem();

}
