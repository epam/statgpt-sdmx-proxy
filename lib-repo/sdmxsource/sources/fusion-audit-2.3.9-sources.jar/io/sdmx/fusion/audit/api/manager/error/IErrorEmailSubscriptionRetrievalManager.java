package io.sdmx.fusion.audit.api.manager.error;

import java.util.List;
import java.util.Set;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.fusion.audit.model.error.ErrorSubscription;

public interface IErrorEmailSubscriptionRetrievalManager {

	/**
	 * Performs a search for subscriptions which match the parameters, all of which are optional
	 * @param email 
	 * @param service
	 * @param category
	 * @return the list of subscriptions or an empty list if none exist
	 */
	List<ErrorSubscription> getSubscriptions(String email, String service, String category) throws SdmxUnauthorisedException;
	
	/**
	 * @param report
	 * @return a set of subscriptions for the report, or an empty set if none match
	 */
	Set<String> getEmailSubscriptions(IErrorReport report);
}
