package io.sdmx.fusion.audit.model.persistable;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.core.dao.api.model.INoSQLCompatible;
import io.sdmx.utils.core.audit.AbstractFusionLogEvent;
import io.sdmx.utils.json.JsonObjectUtil;

/**
 * built from JSON or an {@link IFusionLogEvent}
 */
public class PersistableLogEvent extends AbstractFusionLogEvent implements INoSQLCompatible {

	/**
	 * Empty constructor for Hibernate
	 */
	private PersistableLogEvent() {}
	
	/**
	 * @param log
	 * @return the persistable instance, which is either the log argument downcasted or a new {@link PersistableLogEvent} using the copy constructor
	 */
	public static PersistableLogEvent asPersistable(IFusionLogEvent log) {
		if(log instanceof PersistableLogEvent) {
			return (PersistableLogEvent) log;
		}
		return new PersistableLogEvent(log);
	}
	
	/**
	 * Copy constructor
	 * @param log
	 */
	private PersistableLogEvent(IFusionLogEvent log) {
		this.logLevel = log.getLogLevel();
		this.loggerName = log.getLoggerName();
		this.message = log.getMessage();
		this.auditId = log.getAuditId();
		this.threadName = log.getThreadName();
		this.expires = log.getExpires();
		this.timestamp = log.getLogTime();
	}

	/**
	 * From JSON
	 * @param json
	 */
	public PersistableLogEvent(JSONObject json) {
		this.logLevel = JsonObjectUtil.getInteger(json, "Level", true);
		this.loggerName = JsonObjectUtil.getString(json, "Logger", true);
		this.message = JsonObjectUtil.getString(json, "Message", true);
		this.threadName = JsonObjectUtil.getString(json, "Thread", true);
		this.timestamp = JsonObjectUtil.getLong(json, "LogTime", true);
		this.expires = JsonObjectUtil.getLong(json, "Expires", true);
		this.auditId = JsonObjectUtil.getString(json, "AuditId", true);
	}
	
	@Override
	public String getIdColumn() {
		return null;  //there is no id column
	}
}
