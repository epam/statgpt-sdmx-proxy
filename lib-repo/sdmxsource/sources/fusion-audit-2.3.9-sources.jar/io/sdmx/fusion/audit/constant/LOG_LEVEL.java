package io.sdmx.fusion.audit.constant;

/**
 * Defines Log levels of:
 * <ol>
 *  <li>OFF - do not store any audits</li>
 *  <li>TRANSACTIONAL_EVENTS - only store log events relating to structure, registrations, or metadata submissions</li>
 *  <li>ON - store all logged events</li>
 * </ol>
 */
public enum LOG_LEVEL {
	OFF,
	TRANSACTIONAL_EVENTS,
	ON;
	
}
