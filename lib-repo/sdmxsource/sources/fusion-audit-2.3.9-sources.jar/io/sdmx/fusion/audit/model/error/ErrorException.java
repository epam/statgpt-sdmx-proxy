package io.sdmx.fusion.audit.model.error;

import java.io.Serializable;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.error.IErrorException;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name = "error_exception")
public class ErrorException implements IErrorException, Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id = UUID.randomUUID().toString();

	@Column(name = "class_name")
	private String className;

	@Column(name = "message")
	@Lob
	private String errorMessage;

	/**
	 * Hibernate
	 */
	private ErrorException() {}

	public ErrorException(JSONObject json) {
		this.className = JsonObjectUtil.getString(json, "ClassName", true);
		this.errorMessage = JsonObjectUtil.getString(json, "Message", true);
	}
	
	public ErrorException(Throwable th) {
		setExceptionClass(th.getClass().getCanonicalName());
		setExceptionMessage(th.getMessage() != null ? th.getMessage() : "Null");
	}

	public ErrorException(String className, String errorMessage) {
		this.className = className;
		this.errorMessage = errorMessage;
	}
	
	@Override
	public JSONObject getJson() {
		JSONObject error = new JSONObject();
		try {
			error.put("ClassName", getExceptionClass());
			error.put("Message", getExceptionMessage());
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return error;
	}

	@Override
	public String getExceptionClass() {
		return className;
	}

	@Override
	public String getExceptionMessage() {
		return errorMessage;
	}

	private void setExceptionClass(String className) {
		this.className = className;
	}

	private void setExceptionMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	private String getId() {
		return id;
	}

	private void setId(String id) {
		this.id = id;
	}

}
