package io.sdmx.fusion.audit.model.error;

import java.io.Serializable;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.error.IErrorStack;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "error_stack")
public class ErrorStack implements IErrorStack, Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id = UUID.randomUUID().toString();

	@Column(name = "Line")
	private Integer lineNumber;

	@Column(name = "Method")
	private String methodName;

	@Column(name = "ClassName")
	private String className;

	/**
	 * Hibernate
	 */
	private ErrorStack() {}
	
	public ErrorStack(JSONObject json) {
		this.className = JsonObjectUtil.getString(json, "ClassName", true);
		this.lineNumber  = JsonObjectUtil.getInteger(json, "Line", true);
		this.methodName = JsonObjectUtil.getString(json, "Method", true);
	}

	public ErrorStack(StackTraceElement el) {
		setLineNumber(el.getLineNumber());
		setMethodName(el.getMethodName());
		setClassName(el.getClassName());
	}

	public ErrorStack(String className, Integer lineNumber, String methodName) {
		this.lineNumber = lineNumber;
		this.methodName = methodName;
		this.className = className;
	}
	
	@Override
	public JSONObject getJson() {
		JSONObject stack = new JSONObject();
		try {
			stack.put("ClassName", getClassName());
			stack.put("Line", getLineNumber());
			stack.put("Method", getMethodName());
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return stack;
	}

	private String getId() {
		return id;
	}

	private void setId(String id) {
		this.id = id;
	}

	@Override
	public Integer getLineNumber() {
		return lineNumber;
	}

	@Override
	public String getMethodName() {
		return methodName;
	}

	@Override
	public String getClassName() {
		return className;
	}

	private void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	private void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	private void setClassName(String className) {
		this.className = className;
	}

//	@Override
//	public Document write(NitriteMapper mapper) {
//		Document document = new Document();
//		document.put("Class", this.getClassName());
//		document.put("Method", this.getMethodName());
//		document.put("Line", this.getLineNumber());
//		return document;
//	}
//
//	@Override
//	public void read(NitriteMapper mapper, Document document) {
//		setClassName((String)document.get("Class"));
//		setMethodName((String)document.get("Method"));
//		setLineNumber((Integer)document.get("Line"));
//
//	}
}
