package io.sdmx.fusion.audit.builder;

import java.util.Map;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorReport;

/**
 * Used to build a report when a system fault occurs
 */
public class ErrorReportBuilder {
	private FusionProductInformationRetrievalManager productRetrievalManager;
	private IAuditEventManager auditEventManager;
		
	public ErrorReportBuilder(FusionProductInformationRetrievalManager productRetrievalManager, IAuditEventManager auditEventManager) {
		this.productRetrievalManager = productRetrievalManager;
		this.auditEventManager = auditEventManager;
	}

	public IErrorReport buildErrorReport(IErrorNotifier errorNotifer, String categoryId, String errorDescription, Map<String, String> reportedProperties, Throwable throwable) {
		for(IErrorCategory ec : errorNotifer.getErrorCategories()) {
			if(ec.getId().equals(categoryId)) {
				return buildErrorReport(ec, errorDescription, reportedProperties, throwable);
			}
		}
		throw new IllegalArgumentException("Can not build error report - unknown error category:"+categoryId);
	}
	
	public IErrorReport buildErrorReport(IErrorCategory errorCategory, String errorDescription, Map<String, String> reportedProperties, Throwable throwable) {
		return buildErrorReport(errorCategory, errorDescription, null, reportedProperties, throwable);
	}
	
	public IErrorReport buildErrorReport(IErrorCategory errorCategory, String errorDescription, String auditId, Map<String, String> reportedProperties, Throwable throwable) {
		if(auditId == null) {
			auditId = auditEventManager.getCurrentAuditId();
		}
		FusionProductInformation fpi = productRetrievalManager.getFusionProductInformation();
		return new ErrorReport(fpi, errorCategory, errorDescription, reportedProperties, auditId, throwable);
	}
}
