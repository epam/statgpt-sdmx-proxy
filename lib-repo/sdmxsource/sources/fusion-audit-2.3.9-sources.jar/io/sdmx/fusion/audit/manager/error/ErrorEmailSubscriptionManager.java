package io.sdmx.fusion.audit.manager.error;

import java.util.List;
import java.util.Set;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.security.ISecurityAdminAuthorisationManager;
import io.sdmx.fusion.audit.api.dao.error.IErrorSubscriptionDao;
import io.sdmx.fusion.audit.api.manager.error.IErrorEmailSubscriptionManager;
import io.sdmx.fusion.audit.api.manager.error.IErrorEmailSubscriptionRetrievalManager;
import io.sdmx.fusion.audit.constant.AuditConstants;
import io.sdmx.fusion.audit.model.error.ErrorSubscription;
import io.sdmx.utils.core.object.ObjectUtil;

public class ErrorEmailSubscriptionManager implements IErrorEmailSubscriptionManager, IErrorEmailSubscriptionRetrievalManager {
	private IErrorSubscriptionDao errorSubscriptionDao;
	private ISecurityAdminAuthorisationManager adminAuthManager;
	
	public ErrorEmailSubscriptionManager(IErrorSubscriptionDao errorSubscriptionDao, ISecurityAdminAuthorisationManager adminAuthManager) {
		this.errorSubscriptionDao = ObjectUtil.assertNotNull(errorSubscriptionDao);
		this.adminAuthManager = ObjectUtil.assertNotNull(adminAuthManager);
	}

	@Override
	public void subscribe(String email, String service, String category) throws SdmxUnauthorisedException {
		adminAuthManager.authorise(AuditConstants.ERROR_SUB_SECURITY_FUNCTION);
		errorSubscriptionDao.saveErrorSubscription(new ErrorSubscription(email, service, category));
	}

	@Override
	public List<ErrorSubscription> getSubscriptions(String email, String service, String category) throws SdmxUnauthorisedException {
		adminAuthManager.authorise(AuditConstants.ERROR_SUB_SECURITY_FUNCTION);
		return errorSubscriptionDao.getSubscriptions(email, service, category);
	}

	@Override
	public void unsubscribe(String email, String service, String category) throws SdmxUnauthorisedException {
		adminAuthManager.authorise(AuditConstants.ERROR_SUB_SECURITY_FUNCTION);
		errorSubscriptionDao.deleteSubscriptions(email, service, category);
	}

	@Override
	public Set<String> getEmailSubscriptions(IErrorReport report) {
		return errorSubscriptionDao.getEmailSubscriptions(report);
	}

}
