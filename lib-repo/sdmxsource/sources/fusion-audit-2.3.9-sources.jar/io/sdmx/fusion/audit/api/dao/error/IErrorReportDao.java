package io.sdmx.fusion.audit.api.dao.error;

import java.util.List;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorReportQuery;

public interface IErrorReportDao {

	/**
	 * Saves the error report to the database
	 * @param errorReport
	 */
	void saveErrorReport(ErrorReport errorReport);
	
	/**
	 * @param uid
	 * @return error report or null if not found
	 */
	IErrorReport findByUid(String uid);
	
	/**
	 * All error reports 
	 */
	List<IErrorReport> getAllErrorReports();
	
	/**
	 * All error reports that match the query criteria, no query criteria results in all
	 * @param query
	 * @return
	 */
	List<IErrorReport> findReports(ErrorReportQuery query);
	
}
