package io.sdmx.fusion.audit.api.dao.error;

import java.util.List;
import java.util.Set;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorSubscription;

/**
 * CRUD operations for ErrorSubscritpion
 */
public interface IErrorSubscriptionDao {
	
	/**
	 * Saves the subscription
	 * @param errorSubscription
	 */
	void saveErrorSubscription(ErrorSubscription errorSubscription);
	
	/**
	 * Removes the subscription that matches the passed in subscription
	 * @param errorSubscription
	 */
	void removeSubscription(ErrorSubscription errorSubscription);
	
	/**
	 * @param report
	 * @return a set of subscriptions for the report, or an empty set if none match
	 */
	Set<String> getEmailSubscriptions(IErrorReport report);
	
	/**
	 * @return all error subscriptions or an empty list if none exist
	 */
	List<ErrorSubscription> getAllSubscriptions();
	
	/**
	 * Performs a seach for subscriptions which match the parameters, all of which are optional
	 * @param email 
	 * @param service
	 * @param category
	 * @return the list of subscriptions for the email address, or an empty list if none exist
	 */
	List<ErrorSubscription> getSubscriptions(String email, String service, String category);
	
	/**
	 * Removes all the subscriptions based on the parameters
	 * @param email
	 */
	void deleteSubscriptions(String email, String service, String category);
	
}
