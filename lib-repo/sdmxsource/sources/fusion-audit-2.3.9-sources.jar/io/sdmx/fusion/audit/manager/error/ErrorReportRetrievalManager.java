package io.sdmx.fusion.audit.manager.error;

import java.util.List;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.api.dao.error.IErrorReportDao;
import io.sdmx.fusion.audit.api.manager.error.IErrorReportRetrievalManager;
import io.sdmx.fusion.audit.model.error.ErrorReportQuery;
import io.sdmx.utils.core.object.ObjectUtil;

public class ErrorReportRetrievalManager implements IErrorReportRetrievalManager {
	
	private IErrorReportDao errorReportDao;
	
	public ErrorReportRetrievalManager(IErrorReportDao errorReportDao) {
		this.errorReportDao = ObjectUtil.assertNotNull(errorReportDao);
	}

	@Override
	public IErrorReport findByUid(String uid) {
		return errorReportDao.findByUid(uid);
	}

	@Override
	public List<IErrorReport> getAllErrorReports() {
		return errorReportDao.getAllErrorReports();
	}

	@Override
	public List<IErrorReport> find(ErrorReportQuery query) {
		return errorReportDao.findReports(query);
	}

}
