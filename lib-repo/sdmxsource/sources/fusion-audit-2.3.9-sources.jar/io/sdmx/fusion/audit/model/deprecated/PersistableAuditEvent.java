package io.sdmx.fusion.audit.model.deprecated;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.owasp.encoder.Encode;

import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;
import io.sdmx.fusion.audit.api.model.deprecated.AuditEvent;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

@Deprecated
/**
 * @deprecated use {@link IFusionAuditEvent}
 */
public class PersistableAuditEvent implements Comparable<PersistableAuditEvent>, Serializable, AuditEvent {
	private static final long serialVersionUID = -6456044564073367718L;

	private String uid;
	private AUDITABLE_TYPE eventType;
	private Integer transactionId;

	private String serverName;
	private String machineIdentifier;   //Identifier of machine it is running on
	private String serverContext;
	private String servletPath;
	private int serverPort;
	private String pathInfo;
	private String requetParameters;
	private String protocol;
	private String acceptHeaders;
	private String acceptLanguage;
	private String submissionMethod;
	private String vmid;  //A unique virtual machine id

	private String browserName;
	private String browserVersion;
	private String operatingSystem; // The OS version and name, For example (WINDOWS_7)

	private String userAgent;
	private String fusionProductVersion;

	private int httpResponseStatus;
	private Long requestTime;
	private Long duration;
	private String username = "anonymous";
	private String requestIp;
	private Integer day;
	private Integer month;
	private Integer year;
	private Integer hour;
	private Integer minute;
	private Integer second;
	private Integer millisecond;


	// Hibernate requires the default constructor and all of the getters and setters
	public PersistableAuditEvent() {}

	@Override
    public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Override
    public String getFusionProductVersion() {
		return fusionProductVersion;
	}

	public void setFusionProductVersion(String fusionProductVersion) {
		this.fusionProductVersion = fusionProductVersion;
	}

	@Override
    public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	@Override
    public String getAcceptLanguage() {
		return acceptLanguage;
	}

	public void setAcceptLanguage(String acceptLanguage) {
		this.acceptLanguage = acceptLanguage;
	}

	/**
	 * Give a String and a maximum length, ensure that the string does not exceed that length.
	 * If it does a truncated version is returned
	 * @param aStr The String to evaluate
	 * @param maxStringLength The maximum length of the String
	 * @return Either the original String, a truncated form of the String or null (if null is passed in)
	 */
	private String enforceMaxLength(String aStr, int maxStringLength) {
	    if (aStr == null) {
	        return null;
	    }
	    if (aStr.length() > maxStringLength) {
	        return aStr.substring(0, maxStringLength);
	    }
	    return aStr;
	}

	private String encode(String aString) {
		return Encode.forHtml(aString);
	}

	public Integer getEventTypeId() {
		if(this.eventType != null) {
			return this.eventType.getId();
		}
		return null;
	}

	public void setEventTypeId(Integer id) {
		this.eventType = AUDITABLE_TYPE.resolveId(id);
	}

	@Override
    public AUDITABLE_TYPE getEventType() {
		return eventType;
	}

	public void setEventType(AUDITABLE_TYPE eventType) {
		this.eventType = eventType;
	}

	public String getTimeFormatted() {
		return DateUtil.formatDate(new Date(requestTime));
	}

	@Override
    public String getVmid() {
		return vmid;
	}

	@Override
    public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	@Override
    public String getBrowserName() {
		return this.browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}

	@Override
    public String getBrowserVersion() {
		return this.browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

	@Override
    public String getOperatingSystem() {
		return this.operatingSystem;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public void setVmid(String vmid) {
		this.vmid = vmid;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getHour() {
		return hour;
	}

	public void setHour(Integer hour) {
		this.hour = hour;
	}

	public Integer getMinute() {
		return minute;
	}

	public void setMinute(Integer minute) {
		this.minute = minute;
	}

	public Integer getSecond() {
		return second;
	}

	public void setSecond(Integer second) {
		this.second = second;
	}

	public Integer getMillisecond() {
		return millisecond;
	}

	public void setMillisecond(Integer millisecond) {
		this.millisecond = millisecond;
	}

	@Override
    public String getServerContext() {
		return serverContext;
	}
	/**
	 * Returns the name of the server that issued the request that generated the Audit Event. Note this differs from machineIdentifier.
	 */
	@Override
    public String getServerName() {
		return serverName;
	}
	/**
	 * Returns the name of the server that generated this Audit Event. Note this differs from serverName.
	 */
	@Override
    public String getMachineIdentifier() {
		return machineIdentifier;
	}
	@Override
    public String getServletPath() {
		return servletPath;
	}
	@Override
    public String getPathInfo() {
		return pathInfo;
	}
	@Override
    public String getRequetParameters() {
		return requetParameters;
	}
	@Override
    public String getProtocol() {
		return protocol;
	}
	@Override
    public String getAcceptHeaders() {
		return acceptHeaders;
	}
	@Override
    public String getSubmissionMethod() {
		return submissionMethod;
	}
	@Override
    public int getHttpResponseStatus() {
		return httpResponseStatus;
	}
	@Override
    public int getServerPort() {
		return serverPort;
	}
	@Override
    public Long getRequestTime() {
		return requestTime;
	}
	@Override
    public Long getDuration() {
		return duration;
	}
	@Override
    public String getUsername() {
		return username;
	}
	@Override
    public String getRequestIp() {
		return requestIp;
	}

	/**
	 * Sets the name of the server that issued the request that generated the Audit Event. Note this differs from machineIdentifier.
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	/**
	 * Sets the name of the server that generated the Audit Event. Note this differs from serverName.
	 */
	public void setMachineIdentifier(String machineIdent) {
		this.machineIdentifier = machineIdent;
	}

	public void setServerContext(String serverContext) {
		this.serverContext = serverContext;
		// FR-3501: Do not allow nulls in serverContext
		if (!ObjectUtil.validString(this.serverContext)) {
		    this.serverContext = "/";
		}
	}

	public void setServletPath(String servletPath) {
		this.servletPath = servletPath;
	}

	public void setServerPort(int serverPort) {
		this.serverPort = serverPort;
	}

	public void setPathInfo(String pathInfo) {
		this.pathInfo = pathInfo;
	}

	public void setRequetParameters(String requetParameters) {
		if(requetParameters != null && requetParameters.length() > 700) {
			requetParameters = requetParameters.substring(0, 699);
		}
		this.requetParameters = requetParameters;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public void setAcceptHeaders(String acceptHeaders) {
		this.acceptHeaders = acceptHeaders;
	}

	public void setSubmissionMethod(String submissionMethod) {
		this.submissionMethod = submissionMethod;
	}

	public void setHttpResponseStatus(int httpResponseStatus) {
		this.httpResponseStatus = httpResponseStatus;
	}

	public void setRequestTime(Long requestTime) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(requestTime);
		this.day = cal.get(Calendar.DAY_OF_MONTH);
		this.month = cal.get(Calendar.MONTH);
		this.year = cal.get(Calendar.YEAR);
		this.hour = cal.get(Calendar.HOUR_OF_DAY);
		this.minute = cal.get(Calendar.MINUTE);
		this.second = cal.get(Calendar.SECOND);
		this.millisecond = cal.get(Calendar.MILLISECOND);


		this.requestTime = requestTime;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public void setUsername(String username) {
		if(ObjectUtil.validString(username)) {
			this.username = username;
		}
	}

	public void setRequestIp(String requestIp) {
		this.requestIp = requestIp;
	}



	@Override
	public int hashCode() {
		return getUid().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof PersistableAuditEvent) {
			PersistableAuditEvent that = (PersistableAuditEvent) obj;
			return this.getUid().equals(that.getUid());
		}
		return false;
	}

	@Override
	public int compareTo(PersistableAuditEvent o) {
		int i = this.getRequestTime() > o.getRequestTime() ? -1 : 1;
		if(i == 0) {
			return o.getUid().compareTo(this.getUid());
		}
		return i;
	}
}