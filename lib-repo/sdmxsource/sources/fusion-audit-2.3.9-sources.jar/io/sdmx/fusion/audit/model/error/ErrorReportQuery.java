package io.sdmx.fusion.audit.model.error;

public class ErrorReportQuery {
	private String notifierId;
	private String categoryId;
	private String auditId;
	private Long dateFrom;
	private Long dateTo;
	private Integer maxResults;
	private Integer offSet = 0;

	public Integer getOffset() {
		return offSet;
	}
	
	public void setOffSet(Integer offSet) {
		if(offSet == null || offSet < 0) {
			offSet = 0;
		}
		this.offSet = offSet;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

	public ErrorReportQuery setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
		return this;
	}

	
	public String getNotifierId() {
		return notifierId;
	}
	public ErrorReportQuery setNotifierId(String notifierId) {
		this.notifierId = notifierId;
		return this;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public ErrorReportQuery setCategoryId(String categoryId) {
		this.categoryId = categoryId;
		return this;
	}
	public String getAuditId() {
		return auditId;
	}
	public ErrorReportQuery setAuditId(String auditId) {
		this.auditId = auditId;
		return this;
	}
	public Long getDateFrom() {
		return dateFrom;
	}
	public ErrorReportQuery setDateFrom(Long dateFrom) {
		this.dateFrom = dateFrom;
		return this;
	}
	public Long getDateTo() {
		return dateTo;
	}
	public ErrorReportQuery setDateTo(Long dateTo) {
		this.dateTo = dateTo;
		return this;
	}

}
