package io.sdmx.fusion.audit.engine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.fusion.audit.api.dao.event.IAuditEventDao;
import io.sdmx.fusion.audit.api.dao.log.ILogEventDao;


public class AuditCleanUpEngine implements ApplicationStartupAware {
    private static final Logger LOG = LoggerFactory.getLogger(AuditCleanUpEngine.class);

	private AuditCleanUpRunner cleanUpRunner;
	private IAuditEventDao auditEventDao;
	private ILogEventDao loadDao;

	public AuditCleanUpEngine(IAuditEventDao auditEventDao, ILogEventDao loadDao) {
		this.auditEventDao = auditEventDao;
		this.loadDao = loadDao;
	}

	@Override
	public void applicationRestarting() {}

	@Override
	public void applicationStarted() {
		if(cleanUpRunner == null) {
			cleanUpRunner = new AuditCleanUpRunner();
			Thread t = new Thread(cleanUpRunner);
			t.setDaemon(true);
			t.start();
		}
	}

	@Override
	public Class[] getDependsOn() {
		return null;
	}

	/**
	 */
	private class AuditCleanUpRunner implements Runnable {

		@Override
		public void run() {
			while(this == cleanUpRunner) {
				try {
					LOG.info("Start Audit Backup");
					auditEventDao.backup();
					loadDao.backup();
					LOG.info("Start Log Backup");
					LOG.info("Backup Complete.  Recheck in " + TIME_FORMAT.DATE.getMillisInPeriod() + " millis");
				} catch (Throwable th) {
					LOG.error("Error attempting to remove audit events", th);
				}
				try {
					Thread.sleep(TIME_FORMAT.DATE.getMillisInPeriod());
				} catch (InterruptedException ie) {
					cleanUpRunner = null;
					applicationStarted();
					Thread.currentThread().interrupt();
				}
			}
		}
	}
}
