package io.sdmx.fusion.audit.util;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.fusion.audit.model.persistable.PersistableLogEvent;

public class AuditLogsUtil {

	
	public static List<PersistableLogEvent> toPerstiable(Collection<IFusionLogEvent> logEvents) {
		return logEvents.stream().map(e->PersistableLogEvent.asPersistable(e)).collect(Collectors.toList());
	}
	
}
