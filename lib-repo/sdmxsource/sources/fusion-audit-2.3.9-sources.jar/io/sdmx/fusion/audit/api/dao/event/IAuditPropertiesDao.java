package io.sdmx.fusion.audit.api.dao.event;

import org.codehaus.jettison.json.JSONObject;

public interface IAuditPropertiesDao {

	/**
	 * Saves properties against an audi
	 * @param auditId
	 * @param json
	 */
	void saveProperties(String auditId, JSONObject json);
	
	/**
	 * @param auditId
	 * @return properties recorded against audit
	 */
	JSONObject getProperties(String auditId);
	
	/**
	 * Deletes the audit properties
	 * @param auditId
	 */
	void deleteProperties(String auditId);
	
}
