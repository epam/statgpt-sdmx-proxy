package io.sdmx.fusion.audit.constant;

/**
 * Defines Audit levels of:
 * <ol>
 *  <li>OFF - do not store any audits</li>
 *  <li>TRANSACTIONAL_EVENTS - only store audits events relating to structure, registrations, or metadata submissions</li>
 *  <li>ON - store all audited events</li>
 * </ol>
 */
public enum AUDIT_LEVEL {
	OFF,
	TRANSACTIONAL_EVENTS,
	ON;
	
}
