package io.sdmx.fusion.audit.api.dao.log;

import java.util.Collection;
import java.util.List;

import io.sdmx.api.logging.IFusionLogEvent;

public interface ILogEventDao {
	
	/**
	 * Runs a backup process on the logs
	 */
	void backup();

	/**
	 * Save events against the audit id
	 * @param logEvents
	 * @param auditId
	 */
	void saveLogEvents(String auditId, Collection<IFusionLogEvent> logEvents);

	/**
	 * @param auditId
	 * @return log events for the audit with the given id
	 */
	List<? extends IFusionLogEvent> getLogEvents(String auditId);
}
