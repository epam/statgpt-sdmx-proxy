package io.sdmx.fusion.audit.model.error;

import io.sdmx.api.error.IErrorCategory;
import io.sdmx.utils.core.object.ObjectUtil;

public class SubscribedErrorCategory {
	private String errorNotifierId;  //Id or Wildcard (*)
	private String errorCategoryId;  //Id or Wildcard (*)

	/**
	 * @param errorNotifierId to match an IErrorNotifier or * / null to indicate all
	 * @param errorCategoryId to match an IErrorCategory or * / null to indicate all
	 */
	public SubscribedErrorCategory(String errorNotifierId, String errorCategoryId) {
		this.errorNotifierId = errorNotifierId;
		this.errorCategoryId = errorCategoryId;
		
		if(!ObjectUtil.validString(this.errorNotifierId)) {
			this.errorNotifierId = "*";
		}
		if(!ObjectUtil.validString(this.errorCategoryId)) {
			this.errorCategoryId = "*";
		}
	}

	public String getErrorNotifierId() {
		return errorNotifierId;
	}

	public String getErrorCategoryId() {
		return errorCategoryId;
	}
	
	public boolean isMatch(IErrorCategory errorCategory) {
		if(!errorNotifierId.equals("*") && !errorCategory.getErrorNotifier().getId().equals(errorNotifierId)) {
			return false;
		}
		if(!errorCategoryId.equals("*") && !errorCategory.getId().equals(errorNotifierId)) {
			return false;
		}
		return true;
	}
}
