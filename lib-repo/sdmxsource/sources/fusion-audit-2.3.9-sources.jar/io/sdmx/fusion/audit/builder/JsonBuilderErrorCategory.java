package io.sdmx.fusion.audit.builder;

import java.util.List;

import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.json.JsonObjectUtil;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class JsonBuilderErrorCategory {

	/**
	 * Builds an audit even as a JSON Object
	 * @param auditLogs
	 * @return
	 */
	public static JSONArray build(List<IErrorCategory> errorCategories) {
		JSONArray json = new JSONArray();
		if(errorCategories != null) {
			for(IErrorCategory category : errorCategories) {
				json.put(build(category));
			}
		}
		return json;
	}
	
	/**
	 * Builds an audit even as a JSON Object
	 * @param auditLogs
	 * @return
	 */
	public static JSONObject build(IErrorCategory errorCategory) {
		JSONObject json = new JSONObject();
		if(errorCategory != null) {
			JsonObjectUtil.writeString(json, "Id", errorCategory.getId());
			JsonObjectUtil.writeString(json, "Service", errorCategory.getErrorNotifier().getId());
			JsonObjectUtil.writeString(json, "Name", errorCategory.getErrorName());
			JsonObjectUtil.writeString(json, "Description", errorCategory.getErrorDescription());
			
			JSONObject propertiesJson = new JSONObject();
			for(String propId : errorCategory.getSupportedProperties().keySet()) {
				JsonObjectUtil.writeString(propertiesJson, propId, errorCategory.getSupportedProperties().get(propId));
			}
			try {
				json.put("Properties", propertiesJson);
			} catch (JSONException e) {
				throw new SdmxException(e, "Could not write Object property 'Properties' to JSON Object");
			}
		}
		return json;
	}
}
