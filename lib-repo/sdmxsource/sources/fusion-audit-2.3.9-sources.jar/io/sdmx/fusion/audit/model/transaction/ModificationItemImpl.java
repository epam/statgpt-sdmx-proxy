package io.sdmx.fusion.audit.model.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;

import io.sdmx.api.sdmx.model.diff.ModificationItem;

/**
 * The purpose of this class is for UI - to display information to the user.
 */
public class ModificationItemImpl implements ModificationItem {

	private String name;
	private String description;
	private String dateText;
	private String userId;
	private String action;
	private int changeCount;
	private String linkLocation;


	public ModificationItemImpl(String name, String description, long dateAsLong, String userId, String action, int countItemsChanged, String link) {
		this.name = name;
		this.description = description;
		Date date = new Date(dateAsLong);
        String dateText = new SimpleDateFormat("dd/MM/yy HH:mm:ss").format(date);
		this.dateText = dateText;
		this.userId = userId;
		this.action = action;
		this.changeCount = countItemsChanged;
		this.linkLocation = link;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getDate() {
		return dateText;
	}

	@Override
	public String getAction() {
		return action;
	}

	@Override
	public int getChangeCount() {
		return changeCount;
	}

	@Override
	public String getUserId() {
		return userId;
	}

	@Override
	public String getLinkLocation() {
		return linkLocation;
	}
}