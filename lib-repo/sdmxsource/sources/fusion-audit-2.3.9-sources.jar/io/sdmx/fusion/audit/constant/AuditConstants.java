package io.sdmx.fusion.audit.constant;

import io.sdmx.api.security.ISecurityAdminFunction;
import io.sdmx.utils.core.security.SecurityAdminFunction;

public class AuditConstants {

	public static final ISecurityAdminFunction AUDIT_SECURITY_FUNCTION = SecurityAdminFunction.getInstance("AUDIT", "Audit Manager", "Access to Audit information");
	public static final ISecurityAdminFunction ERROR_SUB_SECURITY_FUNCTION = SecurityAdminFunction.getInstance("ERROR_SUBSCRIBER", "Error Subscriber", "Ability to Subscribe to system error reports");
	
}
