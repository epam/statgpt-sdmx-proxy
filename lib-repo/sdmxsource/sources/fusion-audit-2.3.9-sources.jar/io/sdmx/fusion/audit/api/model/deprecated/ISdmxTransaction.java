package io.sdmx.fusion.audit.api.model.deprecated;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;

/**
 * Defines a transaction, which is a submission of one or more maintainable structures to be appended, updated, or deleted
 * @deprecated
 */
@Deprecated
public interface ISdmxTransaction extends Serializable {

	/**
	 * The unique identifier for the transaction
	 * @return
	 */
	Integer getId();
	
	/**
	 * The user who submitted the structures
	 * @return
	 */
	String getUser();

	/**
	 * The action associated with the transaction
	 * @return
	 */
	DATASET_ACTION getAction();
	
	/**
	 * Returns the type of transaction (Registration, Metadata, Structure)
	 * @return
	 */
	AUDITABLE_TYPE getTransactionType();
	
	/**
	 * If this transaction was a restoration of an old transaction, then this will be the id of the
	 * transaction that this restored
	 * @return
	 */
	Integer getRestoredTxId();
	
	/**
	 * If this transaction was a restoration of an old version of a maintainable, then this will be the urn of the
	 * maintainable that this restored
	 */
	String getRestoredMaintUrn();
	
	/**
	 * The time of the transaction
	 * @return
	 */
	Long getTransactionDate();
	
}
