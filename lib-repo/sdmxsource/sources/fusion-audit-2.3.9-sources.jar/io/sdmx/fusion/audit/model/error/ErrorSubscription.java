package io.sdmx.fusion.audit.model.error;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * represents a single email address subscribing to a single error report
 */
@Entity
@Table(name = "error_email_subscription")
public class ErrorSubscription implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "email")
	private String email;
	
	@Id
	@Column(name = "error_service")
	private String service;   //Id of IErrorNotifier or null to indicate all
	
	@Id
	@Column(name = "error_category")
	private String category;  //Id of IErrorCategory or null to indicate all

	public ErrorSubscription() {}

	public ErrorSubscription(String email, String service, String category) {
		this.email = email;
		if(service == null) {
			service = "*";
		}
		if(category == null) {
			category = "*";
		}
		this.service = service;
		this.category = category;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ErrorSubscription) {
			return obj.toString().equals(this.toString());
		}
		return super.equals(obj);
	}

	@Override
	public String toString() {
		return email + ";"+service+";"+category;
	}
}
