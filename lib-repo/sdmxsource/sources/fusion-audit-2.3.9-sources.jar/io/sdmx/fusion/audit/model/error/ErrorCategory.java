package io.sdmx.fusion.audit.model.error;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.object.ObjectUtil;

public class ErrorCategory implements IErrorCategory {
	private String id;
	private String errorName;
	private String errorDescription;
	private Map<String, String> supportedProperties;
	private IErrorNotifier errorNotifier;
	
	
	public ErrorCategory(String id, String errorName, String errorDescription, Map<String, String> supportedProperties, IErrorNotifier errorNotifier) {
		if(!ObjectUtil.validString(id)) {
			throw new SdmxException("Error Category is missing mandatory Error Id");
		}
		if(!ObjectUtil.validString(errorName)) {
			throw new SdmxException("Error Category is missing mandatory Error Name");
		}
		if(!ObjectUtil.validString(errorDescription)) {
			throw new SdmxException("Error Category is missing mandatory Error Description");
		}
		if(errorNotifier == null) {
			throw new SdmxException("Error Category is missing mandatory Error Notifier");
		}
		this.id = id;
		this.errorName = errorName;
		this.errorDescription = errorDescription;
		if(supportedProperties == null) {
			supportedProperties = new HashMap<>();
		}
		this.supportedProperties = Collections.unmodifiableMap(supportedProperties);
		this.errorNotifier = errorNotifier;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getErrorName() {
		return errorName;
	}

	@Override
	public String getErrorDescription() {
		return errorDescription;
	}

	@Override
	public Map<String, String> getSupportedProperties() {
		return supportedProperties;
	}

	@Override
	public IErrorNotifier getErrorNotifier() {
		return errorNotifier;
	}

}
