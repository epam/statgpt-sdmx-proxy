package io.sdmx.fusion.audit.engine.error;

import java.time.Duration;
import java.util.Date;
import java.util.Set;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.email.IEmailEngine;
import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorDistributionEngine;
import io.sdmx.api.error.IErrorException;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.fusion.audit.api.manager.error.IErrorEmailSubscriptionRetrievalManager;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Distributes system errors via email, if the email server has been configured, and there are subscriptions in the database
 */
public class ErrorEmailDistributionEngine implements IErrorDistributionEngine, InitializingBean {
	private static final Logger LOG = LoggerFactory.getLogger(ErrorEmailDistributionEngine.class);

	@Autowired
	private IErrorEmailSubscriptionRetrievalManager errorSubscriptionManager;

	@Autowired
	private IErrorReporterManager errorReportManager;
	
	@Autowired
	private IEmailEngine emailEngine;
	
	
	public ErrorEmailDistributionEngine(IErrorEmailSubscriptionRetrievalManager errorSubscriptionManager, IErrorReporterManager errorReportManager, IEmailEngine emailEngine) {
		this.errorSubscriptionManager = ObjectUtil.assertNotNull(errorSubscriptionManager);
		this.errorReportManager = ObjectUtil.assertNotNull(errorReportManager);
		this.emailEngine = ObjectUtil.assertNotNull(emailEngine);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		errorReportManager.registerDistributionEngine(this);
	}
	
	@Override
	public void distributeError(IErrorReport errorReport, IErrorNotifier notifier) {
		if(emailEngine.isMailServerConfigured()) {
			Set<String> distributionList = errorSubscriptionManager.getEmailSubscriptions(errorReport);
			if(!ObjectUtil.validCollection(distributionList)) {
				return;
			}
			LOG.info("Email Error report:" +errorReport.getUID());
            String[] distributionArray = new String[distributionList.size()];
        	distributionList.toArray(distributionArray);
        	String emailBody = getEmailBody(errorReport, notifier);
        	emailEngine.postMail("Error Notification: "+errorReport.getProductName(), emailBody, distributionArray);
		}
	}

	private String getEmailBody(IErrorReport errorReport, IErrorNotifier notifier) {
		String serviceId = errorReport.getNotifierId();
		String serviceName = notifier.getName();
		String serviceDescription = notifier.getDescription();
		String errorCategoryId = errorReport.getCategoryId();
		
		IErrorCategory category = notifier.getCategory(errorCategoryId);
		
		String errorDescription = errorReport.getErrorDescription();
		String errorTime = formatTimeStamp(errorReport.getTimeStamp());
		
		StringBuilder sb = new StringBuilder();
		
		writeSectionHeading(sb, "Error Service Details");
		writeKeyValuePair(sb, "Id", serviceId);
		writeKeyValuePair(sb, "Name", serviceName);
		writeKeyValuePair(sb, "Description", serviceDescription);
		writeSectionBreak(sb);
		
		writeSectionHeading(sb, "Error Category Details");
		writeKeyValuePair(sb, "Id", errorCategoryId);
		
		if(category != null) {
			writeKeyValuePair(sb, "Name",  category.getErrorName());
			writeKeyValuePair(sb, "Description",  category.getErrorDescription());
		}

		writeSectionBreak(sb);
		writeSectionHeading(sb, "Error Details");
		writeKeyValuePair(sb, "Time", errorTime);
		writeKeyValuePair(sb, "Description", errorDescription);
		if(errorReport.getAuditId() != null) {
			writeKeyValuePair(sb, "Audit Id", errorReport.getAuditId());
		}
		for(IErrorException ex : errorReport.getError()) {
			writeKeyValuePair(sb, ex.getExceptionClass(), ex.getExceptionMessage());
		}
		
		if(ObjectUtil.validMap(errorReport.getReportedProperties())) {
			for(String propertyId : errorReport.getReportedProperties().keySet()) {
				String propertyValue = errorReport.getReportedProperties().get(propertyId);
				if(propertyValue != null) {
					String propertyDescription = category != null ? category.getSupportedProperties().get(propertyId) : null;
					writeSectionBreak(sb);
					writeSectionHeading(sb, propertyId);
					if(propertyDescription != null) {
						writeKeyValuePair(sb, "Description", propertyDescription);	
					}
					writeKeyValuePair(sb, "Value", propertyValue);	
				}
			}
		}
	
		writeSectionBreak(sb);
		writeSectionHeading(sb, "System Details");
		writeKeyValuePair(sb, "Machine ID", errorReport.getSystemInformation().getMachineIdentifier());
		writeKeyValuePair(sb, "VM ID", errorReport.getSystemInformation().getVmIdentifier());
		writeKeyValuePair(sb, "LaunchDate", formatTimeStamp(errorReport.getSystemInformation().getLaunchDate()));	
		writeKeyValuePair(sb, "Uptime", Duration.ofMillis(errorReport.getTimeStamp() - errorReport.getSystemInformation().getLaunchDate()).toString());	
		
		return sb.toString();
	}
	
	private String formatTimeStamp(long date) {
		return DateUtil.formatDate(new Date(date), TIME_FORMAT.DATE_TIME);
	}
	
	private void writeSectionHeading(StringBuilder sb, String heading) {
		sb.append("<p><b><u>"+heading+"</u></b></p>");
	}
	private void writeSectionBreak(StringBuilder sb) {
		sb.append("<p><hr/></p>");
	}
	
	private void writeKeyValuePair(StringBuilder sb, String key, String value) {
		sb.append("<p><b>"+key+":</b> "+value+"</p>");
	}
}
