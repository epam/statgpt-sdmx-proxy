package io.sdmx.fusion.audit.dao.event;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.audit.IFusionAuditEvent;
import io.sdmx.api.dao.object.IObjectStoreDao;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.service.audit.IAuditEventQuery;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import io.sdmx.core.dao.base.TXLogDao;
import io.sdmx.core.dao.model.hql.Argument;
import io.sdmx.core.dao.model.hql.Argument.FUNCTION;
import io.sdmx.core.dao.model.hql.Argument.OPERATOR;
import io.sdmx.core.dao.model.objectstore.JsonArraySerialiser;
import io.sdmx.core.dao.model.objectstore.TXLog;
import io.sdmx.fusion.audit.api.dao.event.IAuditEventDao;
import io.sdmx.fusion.audit.api.dao.event.IAuditPropertiesDao;
import io.sdmx.fusion.audit.manager.error.LocalErrorManager;
import io.sdmx.fusion.audit.model.event.FusionAuditEvent;
import io.sdmx.fusion.audit.model.query.AuditEventQuery;
import io.sdmx.utils.core.object.ObjectUtil;

public class AuditEventDao implements IAuditEventDao, IObjectDAOClient<FusionAuditEvent>, ApplicationStartupAware {
	private static final Logger LOG = LoggerFactory.getLogger(AuditEventDao.class);

	private IObjectDAO<FusionAuditEvent> dao;

	private IAuditPropertiesDao auditPropertiesDao;
	private IObjectStoreDao auditBackupDao;

	private LocalErrorManager errorManager;
	private final String ERROR_ID = "AUDIT_EVENT";
	private final String CAT_PERSIST_ERROR = "AUDIT_PERSIST_ERROR";
	private final String PROP_EVENT_TYPE = "EVENT_TYPE";

	public AuditEventDao(IObjectDAOFactory factory,
			IAuditPropertiesDao auditPropertiesDao,
			IObjectStoreDao auditBackupDao) {
		factory.register(this);
		this.auditPropertiesDao = ObjectUtil.assertNotNull(auditPropertiesDao);
		this.auditBackupDao = ObjectUtil.assertNotNull(auditBackupDao);

		errorManager = new LocalErrorManager(ERROR_ID, "Audit Event", "Responsible for persisting and obtaining Audit Events to / from permanent storage");
		errorManager.addErrorCategory(CAT_PERSIST_ERROR,
				"Audit Event Error",
				"An Audit Event failed to be persisted to the underlying database",
				new String[] {PROP_EVENT_TYPE, "The type of Audit Event that failed to persist"});
	}

	@Override
	public void setObjectDAO(IObjectDAO<FusionAuditEvent> dao) {
		this.dao = dao;
	}

	@Override
	public Class<FusionAuditEvent> toPersist() {
		return FusionAuditEvent.class;
	}

	@Override
	public void applicationRestarting() {}

	@Override
	public void applicationStarted() {
	}

	@Override
	public Class[] getDependsOn() {
		return null;
	}

	@Override
	public void backup() {
		LOG.info("Run audit backup");
		
			final BackupRequired backup = new BackupRequired();
			
			//Keep audits for the last week (time now minus milliseconds in a week)
			Long endPeriod = System.currentTimeMillis() - TIME_FORMAT.WEEK.getMillisInPeriod();
			while(backup.value == true) {
				dao.getTxManager().voidTransaction(true, ()-> {
					backup.value = runBackup(endPeriod);
				});
			}
		
		LOG.info("Audit backup complete");
	}
	
	private class BackupRequired {
		private boolean value  = true;
	}

	/**
	 * Runs the backup, in chunks of 1000 audit events, does not backup any events
	 * that occured in the last 24 hours
	 * @return true if items were backed up, false if there were no events to backup
	 */
	private boolean runBackup(Long endPeriod) {
		AuditEventQuery eventQuery = AuditEventQuery.builder().
				setPersisted(false).
				setMaxResults(500000).
				setEndPeriod(endPeriod).
				orderAsc(true);
		List<FusionAuditEvent> events = findAudits(eventQuery);
		if(events.size() == 0) {
			return false;
		}
		LOG.info("Delete "+events.size() + " audit properties");
		JSONArray eventsJson = new JSONArray();
		for(FusionAuditEvent event : events) {
			attachProperties(event);
			eventsJson.put(event.getJson());
			auditPropertiesDao.deleteProperties(event.getUid());
		}
		LOG.info("Delete "+events.size() + " audits");

		dao.delete(events);
		TXLog tx = TXLog.getInstance(1, "audit");
		tx.setId(-1);
		tx.setCreated(events.get(0).getProcessStart());
		tx.setUsername("audit_backup");
		LOG.info("backup "+events.size() + " audits");
		TXLogDao.overrideTx(tx, ()-> {
			auditBackupDao.createObject(tx, "audit_backup", eventsJson, JsonArraySerialiser.INSTANCE);
		});
		return true;
	}

	@Override
	public void saveAudit(FusionAuditEvent process) {
		try {
			dao.getTxManager().voidTransaction(true, ()-> {
				dao.save(process);
			});
		} catch (Throwable th) {
			th.printStackTrace();
			errorManager.notifyError(CAT_PERSIST_ERROR, th.getMessage(), th, new String[] {PROP_EVENT_TYPE, process.getEventType()});
		}
	}

	@Override
	public void updateAudit(FusionAuditEvent process) {
		try {
			dao.getTxManager().voidTransaction(true, ()-> {
				dao.saveOrUpdate(process);
			});
		} catch (Throwable th) {
			th.printStackTrace();
			errorManager.notifyError(CAT_PERSIST_ERROR, th.getMessage(), th, new String[] {PROP_EVENT_TYPE, process.getEventType()});
		}
	}

	@Override
	public FusionAuditEvent getAudit(String id) {
		return	(FusionAuditEvent) dao.getTxManager().transaction(() -> {
			FusionAuditEvent event = dao.findById(id);
			attachProperties(event);
			return event;
		});
	}

	@Override
	public IFusionAuditEvent findAudit(IAuditEventQuery query) {
		List<FusionAuditEvent> event =  this.findAudits(query, 1);
		if(event.size() > 0) {
			return event.get(0);
		}
		return null;
	}
	@Override
	public List<FusionAuditEvent> findAudits(IAuditEventQuery query) {
		return this.findAudits(query, null);
	}


	@Override
	public List<FusionAuditEvent> getAuditsByUid(List<String> uid, boolean attachProperties) {
		List<FusionAuditEvent> events = dao.findList(Argument.getCollectionInstance("uid", uid));
		if(attachProperties) {
			attachProperties(events);
		}
		return events;
	}

	@Override
	public List<FusionAuditEvent> getChildren(List<String> parentId, boolean attachProperties) {
		List<FusionAuditEvent> events = dao.findList(Argument.getCollectionInstance("parent", parentId));
		if(attachProperties) {
			attachProperties(events);
		}
		return events;
	}

	private void attachProperties(List<FusionAuditEvent> events) {
		if(events != null) {
			for(FusionAuditEvent event : events) {
				attachProperties(event);
			}
		}
	}

	private void attachProperties(FusionAuditEvent event) {
		if(event != null) {
			JSONObject properties = auditPropertiesDao.getProperties(event.getUid());
			event.setAuditedProperties(properties);
		}
	}

	private List<FusionAuditEvent> findAudits(IAuditEventQuery query, Integer limit) {
		List<Argument> allArgs = new ArrayList<>();
		if(query != null) {
			if(query.getParentId() != null) {
				allArgs.add(Argument.getInstance("parent", query.getParentId()));
			}
			if(query.getSoftwareVersion() != null) {
				allArgs.add(Argument.getInstance("softwareVersion", query.getSoftwareVersion()));
			}
			if(query.getStatus() != null) {
				allArgs.add(Argument.getInstance("status", query.getStatus()));
			}
			if(query.getProcessId() != null) {
				allArgs.add(Argument.getInstance("process_id", query.getProcessId()));
			}
			if(query.getPersisted() != null) {
				if(query.getPersisted()) {
					allArgs.add(Argument.getInstance("persisted", 1));
				} else {
					Argument a1 = Argument.getInstance("persisted", 1, OPERATOR.NOT_EQUAL);
					Argument a2 = Argument.getInstance("persisted", null);
					allArgs.add(Argument.getInstance(a1, a2));
				}
			}
			if(query.getEventType() != null) {
				allArgs.add(Argument.getInstance("event_type", query.getEventType()));
			}
			if(query.getMinDuration() != null) {
				allArgs.add(Argument.getInstance("duration", query.getMinDuration(), OPERATOR.GT_EQUAL));
			}
			if(query.getMaxDuration() != null) {
				allArgs.add(Argument.getInstance("duration", query.getMaxDuration(), OPERATOR.LT_EQUAL));
			}
			if(query.getUsername() != null) {
				allArgs.add(Argument.getInstance("username", query.getUsername()));
			}
			if(query.getIP() != null) {
				allArgs.add(Argument.getInstance("ip", query.getIP()));
			}
			if(query.getStartPeriod() != null) {
				allArgs.add(Argument.getInstance("processStart", query.getStartPeriod(), OPERATOR.GT_EQUAL));
			}
			if(query.getEndPeriod() != null) {
				allArgs.add(Argument.getInstance("processEnd", query.getEndPeriod(), OPERATOR.LT_EQUAL));
			}
			//			if(ObjectUtil.validMap(query.getPropertyValues())) {
			//				for(String prop : query.getPropertyValues().keySet()) {
			//					allArgs.add(Argument.getInstance("Properties."+prop, query.getPropertyValues().get(prop)));
			//				}
			//			}
		}

		allArgs.add(Argument.getInstance(FUNCTION.ORDER_BY, "processStart"));
		allArgs.add(Argument.getInstance(FUNCTION.ORDER, query.orderAsc() ? "asc" : "desc"));
		Argument[] allArgsArray = new Argument[allArgs.size()];
		allArgs.toArray(allArgsArray);
		limit = query.getMaxResults() != null ? query.getMaxResults() : limit;
		if(limit != null) {
			return dao.findList(limit, allArgsArray);
		} else {
			return dao.findList(allArgsArray);
		}
	}

}
