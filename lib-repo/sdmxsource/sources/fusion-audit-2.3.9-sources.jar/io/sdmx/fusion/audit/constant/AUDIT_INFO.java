package io.sdmx.fusion.audit.constant;

public enum AUDIT_INFO {
	ACTION("action"),
	REQUEST_TIME("requestTime"),
	DURATION("duration"),
	REQUEST_IP("requestIp"),
	SERVER_CONTEXT("serverContext"),
	SERVER_NAME("servletName"),
	SERVLET_PATH("servletPath"),
	PATH_INFO("pathInfo"),
	REQUEST_PARAMS("requetParameters"),
	PROTOCOL("protocol"),
	USERNAME("username"),
	HTTP_RESPONSE_STATUS("httpResponseStatus"),
	SUBMISSION_METHOD ("submissionMethod");
	
	private String method;
	
	private AUDIT_INFO(String str) {
		this.method = str;
	}

	public String getMethod() {
		return method;
	}
	
	public static AUDIT_INFO getInfo(String infoStr) {
		for(AUDIT_INFO currentInfo : AUDIT_INFO.values()) {
			if(currentInfo.getMethod().equals(infoStr)) {
				return currentInfo;
			}
		}
		throw new IllegalArgumentException("Unknown AUDIT_INFO type: " + infoStr);
	}
}
