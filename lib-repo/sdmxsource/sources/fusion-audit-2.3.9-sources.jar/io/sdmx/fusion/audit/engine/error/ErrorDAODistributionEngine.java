package io.sdmx.fusion.audit.engine.error;

import io.sdmx.api.error.IErrorDistributionEngine;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.fusion.audit.api.dao.error.IErrorReportDao;
import io.sdmx.fusion.audit.model.error.ErrorReport;
import io.sdmx.utils.core.object.ObjectUtil;
import org.springframework.beans.factory.InitializingBean;

public class ErrorDAODistributionEngine implements IErrorDistributionEngine, InitializingBean {
	private IErrorReportDao errorReporDao;
	private IErrorReporterManager errorReporterManager;
	
	public ErrorDAODistributionEngine(IErrorReportDao errorReporDao, IErrorReporterManager errorReporterManager) {
		this.errorReporDao = ObjectUtil.assertNotNull(errorReporDao);
		this.errorReporterManager = ObjectUtil.assertNotNull(errorReporterManager);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		errorReporterManager.registerDistributionEngine(this);
	}
	
	@Override
	public void distributeError(IErrorReport errorReport, IErrorNotifier notifier) {
		if(errorReport instanceof ErrorReport) {
			errorReporDao.saveErrorReport((ErrorReport)errorReport);		
		}
	}

	
	
}
