package io.sdmx.fusion.audit.constant;


public enum BREAKDOWN_OPTION {
	DATE("Date"),
	USERNAME("Username"),
	IP("IP Address"),
	STRUCTURE_TYPE("Structure Type"),
	AGENCY("Agency"),
	STRUCTURE_ID("Structure Id"),
	FLOW("Dataflow"),
	PROVIDER("Provider"),
	RESPONSE_FORMAT("Response Format"),
	SECURITY_EVENT("Security Event"),
	BROWSER("Web Browser"),
	BROWSER_AND_VERSIPN("Web Browser and Version");
	private String displayName;

	private BREAKDOWN_OPTION(String displayName) {
		this.displayName = displayName;
	}
	
	public String getDisplayName() {
		return displayName;
	}

	public static BREAKDOWN_OPTION getOption(String optionStr) {
		if(optionStr != null) {
			for(BREAKDOWN_OPTION option : BREAKDOWN_OPTION.values()) {
				if(option.displayName.equals(optionStr)) {
					return option;
				}
			}
		}
		return USERNAME;
	}
}
