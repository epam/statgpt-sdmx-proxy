package io.sdmx.fusion.audit.api.dao.event;

import java.util.List;

import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.audit.IFusionAuditEvent;
import io.sdmx.api.service.audit.IAuditEventQuery;
import io.sdmx.fusion.audit.model.event.FusionAuditEvent;

public interface IAuditEventDao {
	
	/**
	 * Runs a backup which moves all audit events that are not persitable
	 * into the backup table
	 * @see IAuditEventManager.setPersisted
	 */
	void backup();

	/**
	 * Saves a new audit process to the database
	 * @param process
	 */
	void saveAudit(FusionAuditEvent process);

	/**
	 * updates an existing audited process
	 * @param process
	 */
	void updateAudit(FusionAuditEvent process);

	/**
	 * @param id
	 * @return process with the given id
	 */
	FusionAuditEvent getAudit(String id);

	/**
	 * Finds all the audit events that have a UID of one of the ids passed in
	 * @param uid - unique identifier for audit
	 * @param attachProperties - if true the audit properties will be attached, must be inside a transaction
	 * @return all matches or empty list if no matches found
	 */
	List<FusionAuditEvent> getAuditsByUid(List<String> uid, boolean attachProperties);

	/**
	 * Finds all the audit events that have a ParentId which matches one of the Ids passed in
	 * @param parentId
	 * @param attachProperties - if true the audit properties will be attached, must be inside a transaction
	 * @return child events for the parents passed in
	 */
	List<FusionAuditEvent> getChildren(List<String> parentId, boolean attachProperties);

	/**
	 * Finds a single audit based on the query parameters, the max results is set to 1 to ensure only 1 hit
	 * @param query
	 * @return an audit event that match the query filters, the last hit ordered by time if more then one match is found
	 */
	IFusionAuditEvent findAudit(IAuditEventQuery query);

	/**
	 * @param query
	 * @return all the audits that match the given query
	 */
	List<FusionAuditEvent> findAudits(IAuditEventQuery query);
}
