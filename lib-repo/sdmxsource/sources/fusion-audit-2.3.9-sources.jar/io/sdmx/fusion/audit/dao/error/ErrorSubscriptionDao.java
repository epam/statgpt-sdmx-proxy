package io.sdmx.fusion.audit.dao.error;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.api.dao.error.IErrorSubscriptionDao;
import io.sdmx.fusion.audit.model.error.ErrorSubscription;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import io.sdmx.core.dao.model.hql.Argument;


public class ErrorSubscriptionDao implements IErrorSubscriptionDao, IObjectDAOClient<ErrorSubscription> {

	private IObjectDAO<ErrorSubscription> dao;

	public ErrorSubscriptionDao(IObjectDAOFactory manager) {
		manager.register(this);
	}
	
	@Override
	public void setObjectDAO(IObjectDAO<ErrorSubscription> dao) {
		this.dao = dao;
	}

	@Override
	public Class<ErrorSubscription> toPersist() {
		return ErrorSubscription.class;
	}
	
	@Override
	public void saveErrorSubscription(ErrorSubscription errorSubscription) {
		dao.saveOrUpdate(errorSubscription);
	}

	@Override
	public void removeSubscription(ErrorSubscription errorSubscription) {
		dao.findUnique(Argument.getInstance("email", errorSubscription.getEmail()),
						Argument.getInstance("service", errorSubscription.getService()),
						Argument.getInstance("category", errorSubscription.getCategory()));
	}

	@Override
	public Set<String> getEmailSubscriptions(IErrorReport report) {
		String serviceId = report.getNotifierId();
		String categoryId = report.getCategoryId();
		return getSubscriptions(null, serviceId, categoryId).stream().map(e -> e.getEmail()).collect(Collectors.toSet());
	}

	@Override
	public List<ErrorSubscription> getAllSubscriptions() {
		return dao.findAll();
	}

	@Override
	public List<ErrorSubscription> getSubscriptions(String email, String service, String category) {
		Argument[] args = new Argument[3];
		if(email != null) {
			args[0] = Argument.getInstance("email", email);
		}
		if(service != null) {
			args[1] = Argument.getInstance(Argument.getInstance("service", "*"), Argument.getInstance("service", service));
		}		
		if(category != null) {
			args[2] = Argument.getInstance(Argument.getInstance("category", "*"), Argument.getInstance("category", category));
		}
		return dao.findList(args);
	}

	@Override
	public void deleteSubscriptions(String email, String service, String category) {
		Argument[] args = new Argument[3];
		if(email != null) {
			args[0] = Argument.getInstance("email", email);
		}
		if(service != null) {
			args[1] = Argument.getInstance("service", service);
		}		
		if(category != null) {
			args[2] = Argument.getInstance("category", category);
		}
		for(ErrorSubscription instance: dao.findList(args)) {
			dao.delete(instance);
		}
	}
}
