package io.sdmx.fusion.audit.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import io.sdmx.fusion.audit.api.dao.deprecated.AuditDao;
import io.sdmx.fusion.audit.model.deprecated.PersistableAuditEvent;
import io.sdmx.utils.hibernate.dao.HibernateDao;

public class AuditDaoImpl implements AuditDao, IObjectDAOClient<PersistableAuditEvent> {
	private static final Logger LOG = LoggerFactory.getLogger(AuditDaoImpl.class);
	private String auditTablePrefix = "e";

	private HibernateDao<PersistableAuditEvent> dao;

	public AuditDaoImpl(IObjectDAOFactory manager) {
		manager.register(this);
	}
	
	@Override
	public void setObjectDAO(IObjectDAO<PersistableAuditEvent> dao) {
		if(dao instanceof HibernateDao) {
			this.dao = (HibernateDao)dao;
		} else {
			throw new SdmxNotImplementedException("Audit DAO requires Hiberante DAO");
		}
	}

	@Override
	public Class<PersistableAuditEvent> toPersist() {
		return PersistableAuditEvent.class;
	}

	@Override
	public PersistableAuditEvent getByTransactionId(Integer transactionId) {
		return dao.findByProperty("transactionId", transactionId);
	}
}
