package io.sdmx.fusion.audit.comparator;

import java.util.Comparator;

import io.sdmx.api.audit.ITXLog;

/**
 * Compares transaction dates (these are epoch values of type "Long") and returns them in the order of most recent first.
 * See: DEV-1060 and FR-1787 
 */
public class TransactionComparator implements Comparator<ITXLog> {
	
	public static final TransactionComparator INSTANCE = new TransactionComparator();
	
	private TransactionComparator() {}

	@Override
	public int compare(ITXLog o1, ITXLog o2) {
		return o1.getCreated() > o2.getCreated() ? -1 : 1;
	}
	
}
