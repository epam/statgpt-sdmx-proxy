package io.sdmx.fusion.audit.builder;
import java.util.Collection;

import io.sdmx.api.error.IErrorReport;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

public class JsonBuilderErrorEvent {
	/**
	 * Builds an audit even as a JSON Object
	 * @param auditEvent
	 * @return
	 */
	public static JSONArray buildJson(Collection<IErrorReport> errorEvents, boolean asStub) {
		JSONArray returnObject = new JSONArray();
		for(IErrorReport errorReport : errorEvents) {
			returnObject.put(buildJson(errorReport, asStub));
		}
		return returnObject;
	}

	/**
	 * Builds an audit even as a JSON Object
	 * @param errorReport
	 * @return
	 */
	public static JSONObject buildJson(IErrorReport errorReport, boolean asStub) {
		return errorReport.getJson(asStub);
	}
}
