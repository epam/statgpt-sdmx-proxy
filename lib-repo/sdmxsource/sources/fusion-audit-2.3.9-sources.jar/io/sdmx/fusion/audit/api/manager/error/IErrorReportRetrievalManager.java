package io.sdmx.fusion.audit.api.manager.error;

import java.util.List;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorReportQuery;


/**
 * Gets the error reports from the persistence layer
 */
public interface IErrorReportRetrievalManager {
	
	/**
	 * @param uid
	 * @return error report or null if not found
	 */
	IErrorReport findByUid(String uid);
	
	/**
	 * @return all error reports
	 */
	List<IErrorReport> getAllErrorReports();
	
	/**
	 * @param uid
	 * @return error report by audit id, or an empty list if none found
	 */
	List<IErrorReport> find(ErrorReportQuery query);
	
	
}
