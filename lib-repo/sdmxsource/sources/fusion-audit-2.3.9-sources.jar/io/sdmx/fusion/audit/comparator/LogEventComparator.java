package io.sdmx.fusion.audit.comparator;

import java.util.Comparator;

import io.sdmx.api.logging.IFusionLogEvent;

public class LogEventComparator implements Comparator<IFusionLogEvent> {
	
	public static final LogEventComparator INSTANCE = new LogEventComparator();
	
	private LogEventComparator() {}

	@Override
	public int compare(IFusionLogEvent o1, IFusionLogEvent o2) {
		long rt =  o1.getLogTime() - o2.getLogTime();
		if(rt == 0) {
			return o1.hashCode() - o2.hashCode();
		}
		return rt > 0 ? 1 : -1;
	}
	
}
