package io.sdmx.fusion.audit.model.error;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorException;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorStack;
import io.sdmx.api.exception.ISdmxException;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.core.dao.api.model.INoSQLCompatible;
import io.sdmx.utils.core.application.SystemInformation;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "audit_error")
public class ErrorReport implements IErrorReport, INoSQLCompatible, Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", length=50)
	private String uid = UUID.randomUUID().toString();

	@Column(name = "category", length=30)
	private String categoryId;

	@Column(name = "service", length=30)
	private String notifierId;

	@Column(name = "description")
	@Lob
	private String errorDescription;

	@ElementCollection
	@CollectionTable(name = "error_property", joinColumns = {@JoinColumn(name = "error_id", referencedColumnName = "id")})
	@MapKeyColumn(name = "prop", length=50)
	@Column(name = "prop_val")
	@Lob
	private Map<String, String> reportedProperties;

	@Column(name = "audit_id", length=50)
	private String auditId;

	@Column(name = "time")
	private Long timeStamp = System.currentTimeMillis();

	@OneToMany(cascade=CascadeType.ALL)
	private List<ErrorStack> stack = Collections.emptyList();

	@OneToMany(cascade=CascadeType.ALL)
	private List<ErrorException> error = Collections.emptyList();

	@Column(name = "product_name")
	private String productName;
	
	@Column(name = "error_status")
	private Integer status = 500;

	/**
	 * Hibernate
	 */
	private ErrorReport() {}

	public ErrorReport(JSONObject json) {
		this.uid = JsonObjectUtil.getString(json, "UID", true);
		this.status = JsonObjectUtil.getInteger(json, "Status", true);
		this.auditId = JsonObjectUtil.getString(json, "AuditId", true);
		this.timeStamp = JsonObjectUtil.getLong(json, "Time", true);
		this.notifierId = JsonObjectUtil.getString(json, "Service", true);
		this.categoryId = JsonObjectUtil.getString(json, "Category", true);
		this.errorDescription = JsonObjectUtil.getString(json, "Description", true);
		this.productName = JsonObjectUtil.getString(json, "ProductName", true);
		
		this.reportedProperties = JsonObjectUtil.unpackMap(json, "Properties", true);
		if(this.reportedProperties == null) {
			this.reportedProperties = Collections.emptyMap();
		}
		
		this.error = new ArrayList<>();
		List<JSONObject> errorsJson = JsonObjectUtil.getArrayOfObjects(json, "Exceptions", true);
		if(errorsJson != null) {
			for(JSONObject errorJson : errorsJson) {
				this.error.add(new ErrorException(errorJson));
			}
		}
		this.stack = new ArrayList<>();
		List<JSONObject> stacksJson = JsonObjectUtil.getArrayOfObjects(json, "Stacks", true);
		if(stacksJson != null) {
			for(JSONObject stackJson : stacksJson) {
				this.stack.add(new ErrorStack(stackJson));
			}
		}
	}

	public ErrorReport(FusionProductInformation product, IErrorCategory errorCategory, String errorDescription, Map<String, String> reportedProperties, String auditId, Throwable throwable) {
		if(errorCategory == null) {
			throw new SdmxException("Error Report is missing mandatory Error Category");
		}
		if(!ObjectUtil.validString(errorDescription)) {
			errorDescription = "No Description Provided";
		}
		if(product == null) {
			throw new SdmxException("Error Report is missing mandatory Product Information");
		}
		this.categoryId = errorCategory.getId();
		this.notifierId = errorCategory.getErrorNotifier().getId();

		this.errorDescription = errorDescription;
		this.reportedProperties = reportedProperties;
		if(this.reportedProperties == null) {
			this.reportedProperties = new HashMap<>();
		}
		this.productName = product.getProductDetails().getProductName();
		this.reportedProperties = Collections.unmodifiableMap(this.reportedProperties);
		this.auditId = auditId;

		if(throwable != null) {
			if(throwable instanceof ISdmxException) {
				Integer restErrorCode = ((ISdmxException)throwable).getHttpRestErrorCode();
				if(restErrorCode != null) {
					status = restErrorCode;
				}
			}
			StackTraceElement[] stack = throwable.getStackTrace();

			if(stack != null) {
				List<ErrorStack> stackList = new ArrayList<>();
				for(int i=0; i < stack.length; i++) {
					stackList.add(new ErrorStack(stack[i]));
					if(i == 19) {
						break; //20 is plenty (hopefully!)
					}
				}
				this.stack = Collections.unmodifiableList(stackList);
			}

			List<ErrorException> error = new ArrayList<>();
			while(throwable != null && error.size() < 4) {
				error.add(new ErrorException(throwable));
				if(throwable.getCause() == throwable) {
					break;
				}
				throwable = throwable.getCause();
			}
			this.error = Collections.unmodifiableList(error);
		}
	}
//
//	@Override
//	public String getPrimaryKey() {
//		return getUID();
//	}

	@Override
	public String getUID() {
		return uid;
	}

	@Override
	public List<? extends IErrorStack> getStack() {
		return stack;
	}

	@Override
	public List<? extends IErrorException> getError() {
		return error;
	}

	@Override
	public String getNotifierId() {
		return notifierId;
	}

	@Override
	public String getCategoryId() {
		return categoryId;
	}

	@Override
	public String getErrorDescription() {
		return errorDescription;
	}

	@Override
	public Map<String, String> getReportedProperties() {
		return reportedProperties;
	}

	@Override
	public String getAuditId() {
		return auditId;
	}

	@Override
	public Long getTimeStamp() {
		return timeStamp;
	}

	@Override
	public SystemInformation getSystemInformation() {
		return SystemInformation.INSTANCE();
	}

	@Override
	public String getProductName() {
		return productName;
	}

	@Override
	public Integer getStatus() {
		return status;
	}

	private void setStatus(Integer status) {
		this.status = status;
	}

	private void setUID(String uid) {
		this.uid = uid;
	}

	private void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	private void setNotifierId(String notifierId) {
		this.notifierId = notifierId;
	}

	private void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	private void setReportedProperties(Map<String, String> reportedProperties) {
		this.reportedProperties = reportedProperties;
	}

	private void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	private void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}

	private void setStack(List<ErrorStack> stack) {
		this.stack = stack;
	}

	private void setError(List<ErrorException> error) {
		this.error = error;
	}

	private void setProductName(String productName) {
		this.productName = productName;
	}
	
	@Override
	public String getIdColumn() {
		return "UID";
	}
	
	@Override
	public JSONObject getJson() {
		return getJson(false);
	}

	@Override
	public JSONObject getJson(boolean asStub) {
		JSONObject document = new JSONObject();
		try {
			document.put("UID", this.getUID());
			document.put("Status", this.getStatus());
			if(getAuditId() != null) {
				document.put("AuditId", getAuditId());
			}
			if(getTimeStamp() != null) {
				document.put("Time", getTimeStamp());
			}
			if(getNotifierId() != null) {
				document.put("Service", getNotifierId());
			}
			if(getCategoryId() != null) {
				document.put("Category", getCategoryId());
			}
			if(getErrorDescription() != null) {
				document.put("Description", getErrorDescription());
			}
			if(getProductName() != null) {
				document.put("ProductName", getProductName());
			}
			if(asStub == false) {
				if(ObjectUtil.validMap(getReportedProperties())) {
					JsonObjectUtil.addMap(document, "Properties", getReportedProperties());
				}
				for(IErrorException ex : this.getError()) {
					document.append("Exceptions", ex.getJson());
				}
				for(IErrorStack ex : this.getStack()) {
					document.append("Stacks", ex.getJson());
				}
			}
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return document;
	}
	
	
}
