package io.sdmx.fusion.audit.model.log;

import io.sdmx.api.dao.serialised.SerializedStore;
import io.sdmx.fusion.audit.dao.event.BlobLogEventDao;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.dao.model.serialised.SerialzedPersistable;
import org.codehaus.jettison.json.JSONArray;

public class SerialzedLogs extends SerialzedPersistable<BlobLogEventDao, JSONArray> {
	private static final long serialVersionUID = 1L;
	private String auditId;
	private Long eventTime = System.currentTimeMillis();
	
	public SerialzedLogs() {}

	public SerialzedLogs(String auditId, JSONArray ser) {
		super(ser);
		this.auditId = auditId;
	}

	@Override
	protected JSONArray rebuildSerializedPersistable(StructureReaderManager spm, SerializedStore<BlobLogEventDao> serializedStore) {
		return null;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public Long getEventTime() {
		return eventTime;
	}

	public void setEventTime(Long eventTime) {
		this.eventTime = eventTime;
	}
}
