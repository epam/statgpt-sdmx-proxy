package io.sdmx.fusion.audit.model.transaction;

import java.util.Date;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.security.SecurityDetails;
import io.sdmx.fusion.audit.api.model.deprecated.ISdmxTransaction;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "sdmx_transaction")
public class SdmxTransactionImpl implements ISdmxTransaction  {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_column_sequence")
	@SequenceGenerator(name = "id_column_sequence", sequenceName = "id_column_sequence", allocationSize = 1)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "tx_user", nullable = true, unique = false)
	private String user;
	
	@Column(name = "tx_date", nullable = false, unique = false)
	private Long transactionDate;
	
	@Enumerated(EnumType.STRING) // maps enum to VARCHAR column
	@Column(name = "ds_action", nullable = false)
	private DATASET_ACTION action;
	
	// PRL this is not mapped - does it need to be?
	private AUDITABLE_TYPE txType;
	
	@Column(name = "restored_tx", nullable = true, unique = false)
	private Integer restoredTxId;
	
	@Column(name = "restored_maint_urn", nullable = true, unique = false)
	private String restoredMaintUrn;

	public SdmxTransactionImpl() {}
	
	public SdmxTransactionImpl(JSONObject txJson) {
		this.id = JsonObjectUtil.getInteger(txJson, "Id", false);
		this.transactionDate = JsonObjectUtil.getLong(txJson, "Date", false);
		this.user = JsonObjectUtil.getString(txJson, "User", "-");
		this.action = DATASET_ACTION.getAction(JsonObjectUtil.getString(txJson, "Action", DATASET_ACTION.REPLACE.getAction()));
		this.txType = AUDITABLE_TYPE.STRUCTURE_SUBMISSION;
	}

	public SdmxTransactionImpl(DATASET_ACTION action) {
		this.action = action;
		this.transactionDate = new Date().getTime();
		this.txType = (AUDITABLE_TYPE)ThreadLocalUtil.retrieveFromThread(AUDITABLE_TYPE.class.getName());
		SecurityDetails sd = FusionSecurityContext.CTX().getSecurityDetails();
		if(sd != null) {
			this.user = sd.getUsername();
		}
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public AUDITABLE_TYPE getTransactionType() {
		return txType;
	}

	public Integer getEventTypeId() {
		if(this.txType != null) {
			return this.txType.getId();
		}
		return null;
	}

	public void setEventTypeId(Integer id) {
		this.txType = AUDITABLE_TYPE.resolveId(id);
	}

	@Override
	public DATASET_ACTION getAction() {
		return action;
	}

	public void setAction(DATASET_ACTION action) {
		this.action = action;
	}

	@Override
	public Integer getRestoredTxId() {
		return restoredTxId;
	}

	public void setRestoredTxId(Integer restoredTxId) {
		this.restoredTxId = restoredTxId;
	}

	@Override
	public String getRestoredMaintUrn() {
		return restoredMaintUrn;
	}

	public void setRestoredMaintUrn(String restoredMaintUrn) {
		this.restoredMaintUrn = restoredMaintUrn;
	}

	@Override
	public Long getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Long transactionDate) {
		this.transactionDate = transactionDate;
	}
}
