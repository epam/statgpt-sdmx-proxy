package io.sdmx.fusion.audit.manager.application;

import java.util.Properties;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.application.IFusionContainer;
import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.fusion.audit.manager.error.LocalErrorManager;
import io.sdmx.utils.core.audit.AuditUtil;
import io.sdmx.utils.core.memory.MemoryUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.spring.ApplicationStarterImpl;

public class AuditingApplicationStarter extends ApplicationStarterImpl {
	
	private IAuditEventManager auditEventManager;
	private LocalErrorManager errorManager;
	
	private final String ERROR_ID = "APPLICATION_START";
	private final String CAT_STARTUP_ERROR = "CLASS_START_ERROR";
	private final String PROP_CLASS = "CLASS";
	
	public AuditingApplicationStarter(IAuditEventManager auditEventManager, SdmxBeanRetrievalManager beanRetrievalManager, String pluginPackage) {
		super(beanRetrievalManager, pluginPackage);
		this.auditEventManager = ObjectUtil.assertNotNull(auditEventManager);
		errorManager = new LocalErrorManager(ERROR_ID, "Application Starter", "Responsible for initating post launch configuration of Java Objects, for example pre-populating internal caches or connecting to external services such as databases or message queues");
		errorManager.addErrorCategory(CAT_STARTUP_ERROR,
				"Class Startup Error",
				"A Java Object failed to initialise properly on startup, this can cause instability in the system if the underlying error is not resolved",
				new String[] {PROP_CLASS, "The Java Class that failed to initialise"});
	}

	@Override
	public void startApplication(IFusionContainer fusionContainer) {
		String auditEvent = isStarted() ? "RESTART" : "START";
		auditEventManager.startAuditEvent("APPLICATION_START", auditEvent, () -> {
			System.gc();
			auditEventManager.addAuditProperty("MEM_FREE_START", Float.toString(MemoryUtil.getMemoryRemaining()));
			super.startApplication(fusionContainer);
			
			//Audit system properties after the application was started (properties may have been added/changed during startup)
			Properties props = System.getProperties();
			props.keySet().stream().forEach((key) -> {
				Object value = props.get(key);
				if(key != null && value != null) {
					auditEventManager.addAuditProperty(key.toString(), value.toString());
				}
			});
			System.gc();
			auditEventManager.addAuditProperty("MEM_FREE_END", Float.toString(MemoryUtil.getMemoryRemaining()));
		});
	}
	
	
	
	@Override
	protected void startupRequest(ApplicationStartupAware currentAsw) {
		AuditUtil.startAuditEvent("APPLICATION_START", "START_CLASS", ()-> {
			AuditUtil.addAuditProperty("Class", currentAsw.getClass().getCanonicalName());
			super.startupRequest(currentAsw);
		});
	}

	@Override
	protected void startupFailed(ApplicationStartupAware currentAsw, Throwable th) {
		super.startupFailed(currentAsw, th);
		errorManager.notifyError(CAT_STARTUP_ERROR, th.getMessage(), th, new String[] {PROP_CLASS, currentAsw.getClass().getCanonicalName()});
	}
}
