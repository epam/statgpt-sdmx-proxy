package io.sdmx.fusion.audit.constant;

public class BackupConstants {
	public static final String RECOVERING_TRANSACTION = "RECOVERING_TRANSACTION";
	public static final String RECOVERY_MAINTAINABLE = "RECOVERY_MAINTAINABLE";
	
}
