package io.sdmx.fusion.audit.model.event;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.application.FusionProduct;
import io.sdmx.api.audit.IFusionAuditEvent;
import io.sdmx.api.security.SecurityDetails;
import io.sdmx.core.dao.api.model.INoSQLCompatible;
import io.sdmx.utils.core.application.SystemInformation;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "audit_event",
       indexes = {
    		       @Index(columnList = "process_start"),
    		       @Index(columnList = "parent"),
    		       @Index(columnList = "process_id")
    		     }
      )
public class FusionAuditEvent implements IFusionAuditEvent, INoSQLCompatible, Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "audit_id", length=50)
	private String uid= UUID.randomUUID().toString();

	@Column(name = "parent", length=50)
	private String parentUid;

	@Column(name = "process_id", length=30)
	private String processId;

	@Column(name = "event_type", length=30)
	private String eventType;

	@Column(name = "vmid", length=50)
	private String VMID;

	@Column(name = "machine_id", length=100)
	private String machineId;

	@Column(name = "software_version", length=20)
	private String softwareVersion;

	@Column(name = "username", length=50)
	private String username;

	@Column(name = "ip", length=50)
	private String ip;

	@Column(name = "thread", length=50)
	private String thread;

	@Column(name = "process_start")
	private Long processStart = new Date().getTime();

	@Column(name = "process_end")
	private Long processEnd;

	@Column(name = "duration")
	private Long duration;

	@Column(name = "status", length=50)
	private Integer status = -1;

	@Column(name = "persisted", length=50)
	private Integer persisted = -1;
	
	@Transient
	private JSONObject auditedProperties = new JSONObject();

	/**
	 * hibernate
	 */
	private FusionAuditEvent() {}

	public FusionAuditEvent(JSONObject json) {
		this.uid = JsonObjectUtil.getString(json, "uid", true);
		this.parentUid = JsonObjectUtil.getString(json, "parent", true);
		this.processId= JsonObjectUtil.getString(json, "process_id", true);
		this.username = JsonObjectUtil.getString(json, "username", true);
		this.thread = JsonObjectUtil.getString(json, "thread", true);
		this.processStart = JsonObjectUtil.getLong(json, "process_start", true);
		this.processEnd = JsonObjectUtil.getLong(json, "process_end", true);
		this.duration = JsonObjectUtil.getLong(json, "duration", true);
		this.eventType = JsonObjectUtil.getString(json, "event_type", true);
		this.status = JsonObjectUtil.getInteger(json, "status", true);
		this.ip = JsonObjectUtil.getString(json, "ip", true);
		this.VMID = JsonObjectUtil.getString(json, "vmid", true);
		this.machineId = JsonObjectUtil.getString(json, "machine_id", true);
		this.softwareVersion = JsonObjectUtil.getString(json, "software_version", true);
		this.auditedProperties = JsonObjectUtil.getJsonObject(json, "properties", true);
		this.persisted = JsonObjectUtil.getInteger(json, "persisted", true);
	}

	public static FusionAuditEvent createProcess(String processId, String eventType, FusionProduct productInfo) {
		FusionAuditEvent process = new FusionAuditEvent();
		setCommonProperties(process);
		process.processId = processId;
		process.softwareVersion = productInfo.getVersion();
		process.VMID = SystemInformation.INSTANCE().getVmIdentifier();
		process.machineId = SystemInformation.INSTANCE().getMachineIdentifier();
		process.eventType = eventType;
		if(ThreadLocalUtil.getClientRequest() != null) {
			process.ip = ThreadLocalUtil.getClientRequest().getClientIP();
		}
		process.uid = UUID.randomUUID().toString();
		return process;
	}

	public static FusionAuditEvent createProcess(String processId, FusionProduct productInfo) {
		return createProcess(processId, null, productInfo);
	}

	public static FusionAuditEvent createSubProcess(String uid, String parentId, String processId, String eventType) {
		FusionAuditEvent process = new FusionAuditEvent();
		process.uid = UUID.randomUUID().toString();
		setCommonProperties(process);
		process.parentUid = parentId;
		process.eventType = eventType;
		process.processId = processId;
		return process;
	}

	private static void setCommonProperties(FusionAuditEvent process) {
		process.thread = StringUtils.abbreviate(Thread.currentThread().getName(), 50);
		SecurityDetails sd = FusionSecurityContext.CTX().getSecurityDetails();
		if(sd != null) {
			process.username = sd.getUsername();
		}
	}

	public void endProcess(int status) {
		if(this.status == -1) {
			this.status = status;
		}
		this.processEnd = new Date().getTime();
		this.duration = this.processEnd - this.processStart;
	}

	@Override
	public String getUid() {
		return uid;
	}

	public Integer getPersisted() {
		return this.persisted;
	}
	
	@Override
	public String getParentProcess() {
		return parentUid;
	}

	@Override
	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	private void setParentProcess(String uid) {
		this.parentUid = uid;
	}
	
	

	@Override
	public String getEventType() {
		return eventType;
	}

	private void setEventType(String eventType) {
		this.eventType = eventType;
	}

	@Override
	public String getVMID() {
		return VMID;
	}

	@Override
	public String getMachineId() {
		return machineId;
	}

	@Override
	public String getSoftwareVersion() {
		return softwareVersion;
	}

	public String getThread() {
		return thread;
	}

	public void setThread(String thread) {
		this.thread = thread;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public String getIp() {
		return ip;
	}

	private void setIp(String ip) {
		this.ip = ip;
	}

	@Override
	public Long getProcessStart() {
		return processStart;
	}

	@Override
	public Long getProcessEnd() {
		return processEnd;
	}

	@Override
	public Long getDuration() {
		if(this.duration != null) {
			return this.duration;
		}
		if(this.processEnd == null) {
			return null;
		}
		return this.processStart - this.processEnd;
	}

	private void setDuration(Long duration) {
		this.duration = duration;
	}

	@Override
	public Integer getStatus() {
		return status;
	}

	public void writeProperty(String key, Object value) {
		if (key == null) {
			return;
		}
		if(auditedProperties == null) {
			auditedProperties = new JSONObject();
		}
		try {
			if (key.toLowerCase().equals("password")) {
				value = "********";
			}
			auditedProperties.put(key, value);
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public JSONObject getAuditedProperties() {
		return auditedProperties;
	}

	public void setAuditedProperties(JSONObject auditedProperties) {
		this.auditedProperties = auditedProperties;
	}

	private void setUid(String uid) {
		this.uid = uid;
	}

	private void setVMID(String vMID) {
		VMID = vMID;
	}

	private void setMachineId(String machineId) {
		this.machineId = machineId;
	}

	private void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	private void setUsername(String user) {
		this.username = user;
	}

	private void setProcessStart(Long processStart) {
		this.processStart = processStart;
	}

	private void setProcessEnd(Long processEnd) {
		this.processEnd = processEnd;
	}
	
	public void setPersisted(Integer persisted) {
		this.persisted = persisted;
	}

	@Override
	public void setStatus(Integer status) {
		this.status = status;
	}

	@Override
	public String getIdColumn() {
		return "UID";
	}

	@Override
	public JSONObject getJson() {
		return getJson(false);
	}

	@Override
	public JSONObject getJson(boolean asStub) {
		JSONObject json = new JSONObject();
		try {
			json.put("uid", this.getUid());
			json.put("parent", this.getParentProcess());
			json.put("process_id", this.getProcessId());
			json.put("thread", this.getThread());
			json.put("event_type", this.getEventType());
			json.put("username", this.getUsername());
			json.put("ip", this.getIp());
			json.put("process_start", this.getProcessStart());
			json.put("process_end", this.getProcessEnd());
			json.put("duration", this.getDuration());
			json.put("status", this.getStatus());
			json.put("vmid", this.getVMID());
			json.put("machine_id", this.getMachineId());
			json.put("software_version", this.getSoftwareVersion());

			if(auditedProperties != null) {
				json.put("properties", auditedProperties);
			}
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return json;
	}

	@Override
	public String toString() {
		return getUid() + "_"+processId;
	}
}
