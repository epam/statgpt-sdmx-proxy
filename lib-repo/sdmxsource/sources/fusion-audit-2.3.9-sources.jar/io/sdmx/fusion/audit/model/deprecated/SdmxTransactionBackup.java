package io.sdmx.fusion.audit.model.deprecated;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.ReadableDataLocationFactory;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.fusion.audit.api.model.deprecated.ISdmxTransaction;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.InMemoryWriteableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;

@Deprecated
/**
 * @deprecated used only for upgrading from FMR11
 */
public class SdmxTransactionBackup implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final int BYTE_CHUNK_LENGTH = 4096;

	private transient StructureWriterManager structureWritingManager = SingletonStore.getSingleton(StructureWriterManager.class);
	private transient StructureReaderManager structureParsingManager = SingletonStore.getSingleton(StructureReaderManager.class);
	private transient StructureFormatManager structureFormatManager = SingletonStore.getSingleton(StructureFormatManager.class);
	private transient ReadableDataLocationFactory rdlFactory = SingletonStore.getSingleton(ReadableDataLocationFactory.class);

	private Integer transaction;
	private List<byte[]> sdmxBuffer = new ArrayList<>();

	private transient SdmxBeans beans;

	public SdmxTransactionBackup() {}

	public SdmxTransactionBackup(ISdmxTransaction tx,
			SdmxBeans beans) {
		this.transaction = tx.getId();
		storeSdmxByteArray(beans);
	}

	private void storeSdmxByteArray(SdmxBeans beans) {
		try {

			//3 Zip contents and store

			//1 Write Structures to ByteArray
			Map<StructureFormat, SdmxBeans> beansMap = new HashMap<>();
			for(MaintainableBean maint : beans.getAllMaintainables()) {
				StructureFormat sFormat = structureFormatManager.getDefaultFormat(maint.getDefaultStandard());
				SdmxBeans currentBeans = beansMap.get(sFormat);
				if(currentBeans == null) {
					currentBeans = new SdmxBeansImpl();
					currentBeans.setAction(beans.getAction());
					beansMap.put(sFormat, currentBeans);
				}
				currentBeans.addIdentifiable(maint);
			}

			byte[] bytes;
			if(beansMap.size() > 1) {
				//Multiple default formats

				ReadableDataLocation[] inFiles = new ReadableDataLocation[beansMap.size()];
				int i=0;
				for(StructureFormat sFormat : beansMap.keySet()) {
					WriteableDataLocation backup = new InMemoryWriteableDataLocation(false);
					structureWritingManager.writeStructures(beansMap.get(sFormat),sFormat,backup.getOutputStream());
					inFiles[i] = backup;
					i++;
				}
				InMemoryWriteableDataLocation wdl = new InMemoryWriteableDataLocation(true);
				ZipUtil.zipFile(wdl, inFiles);
				bytes = wdl.toByteArray();
				//Close resources
				wdl.close();
				for(ReadableDataLocation inFile : inFiles) {
					inFile.close();
				}
			} else {
				ByteArrayOutputStream zipStream = new ByteArrayOutputStream();
				GZIPOutputStream gzipstream = new GZIPOutputStream(new BufferedOutputStream(zipStream));
				for(StructureFormat sFormat : beansMap.keySet()) {
					structureWritingManager.writeStructures(beansMap.get(sFormat),sFormat,gzipstream);
				}
				gzipstream.close();
				bytes = zipStream.toByteArray();
			}

			StreamUtil.splitBytes(sdmxBuffer, bytes, BYTE_CHUNK_LENGTH, 0);

		} catch(IOException e) {
			throw new RuntimeException("I/O Error whilst trying to store maintainable", e);
		}
	}

	public SdmxBeans getSdmxBeans() {
		if(beans != null) {
			return beans;
		}
		InputStream is;
		try {
			is = new GZIPInputStream(StreamUtil.asStream(sdmxBuffer));
		} catch (IOException e) {
			throw new SdmxException("Error trying to deserialize SdmxBackup '"+this.transaction+"'");
		}
		ReadableDataLocation rdl = rdlFactory.getReadableDataLocation(is);
		try {
			if(ZipUtil.isAZip(rdl)) {
				List<ReadableDataLocation> rdls = ZipUtil.unzipFiles(rdl);
				beans = new SdmxBeansImpl();
				for(ReadableDataLocation currentRdl : rdls) {
					try {
						beans.merge(structureParsingManager.parseStructures(currentRdl));
					} catch(Throwable th) {
						th.printStackTrace();
					} finally {
						currentRdl.close();
					}
				}
			} else {
				beans = structureParsingManager.parseStructures(rdl);
			}
		} finally {
			rdl.close();
		}
		return beans;
	}

	public Integer getTransaction() {
		return transaction;
	}

	public void setTransaction(Integer transaction) {
		this.transaction = transaction;
	}

	public List<byte[]> getSdmxBuffer() {
		return sdmxBuffer;
	}

	public void setSdmxBuffer(List<byte[]> sdmxBuffer) {
		this.sdmxBuffer = sdmxBuffer;
	}
}
