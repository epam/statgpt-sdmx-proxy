package io.sdmx.fusion.audit.manager.event;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.application.FusionProduct;
import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.audit.IFusionAuditEvent;
import io.sdmx.api.audit.PROCESS_STATUS;
import io.sdmx.api.error.IErrorDistributionEngine;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.api.logging.ILogDistributionEngine;
import io.sdmx.api.process.IProcess;
import io.sdmx.api.process.IProcessWithResponse;
import io.sdmx.api.security.ISecureThread;
import io.sdmx.api.security.ISecurityAdminAuthorisationManager;
import io.sdmx.api.service.audit.IAuditEventQuery;
import io.sdmx.core.dao.api.tx.ITransactionManager;
import io.sdmx.fusion.audit.api.dao.event.IAuditEventDao;
import io.sdmx.fusion.audit.api.dao.event.IAuditPropertiesDao;
import io.sdmx.fusion.audit.api.dao.log.ILogEventDao;
import io.sdmx.fusion.audit.api.manager.retrieval.IAuditEventRetreivalManager;
import io.sdmx.fusion.audit.api.manager.retrieval.ILogEventRetreivalManager;
import io.sdmx.fusion.audit.builder.JsonBuilderAuditEvent;
import io.sdmx.fusion.audit.comparator.AuditEventComparator;
import io.sdmx.fusion.audit.comparator.LogEventComparator;
import io.sdmx.fusion.audit.constant.AuditConstants;
import io.sdmx.fusion.audit.manager.log.LogDistributionManager;
import io.sdmx.fusion.audit.model.error.ErrorException;
import io.sdmx.fusion.audit.model.error.ErrorStack;
import io.sdmx.fusion.audit.model.event.FusionAuditEvent;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.sdmx.application.FusionProductImpl;

public class AuditEventManager implements 	IAuditEventManager,
											IAuditEventRetreivalManager,
											IErrorDistributionEngine,
											ILogDistributionEngine,
											ILogEventRetreivalManager,
											ApplicationStartupAware {

	private static Logger LOG = LoggerFactory.getLogger(AuditEventManager.class);

	@Autowired
	private ISecurityAdminAuthorisationManager authManager;

	private FusionProductInformationRetrievalManager infoRetreival;
	private IErrorReporterManager errorReporterManager;
	private IAuditEventDao auditEventDao;
	private ILogEventDao logEventDao;
	private IAuditPropertiesDao auditPropertiesDao;

	private Map<Thread, LocalAuditInfo> auditInforForThread = new ConcurrentHashMap<>();
	private Map<String, LocalAuditInfo> auditInfo = new ConcurrentHashMap<>();  //Audit ID to LocalAuditInfo

	private static FusionProduct PRODUCT_INFO;

	private ITransactionManager txManager;

	public AuditEventManager(IErrorReporterManager errorReporterManager,
			IAuditEventDao auditEventDao,
			IAuditPropertiesDao auditPropertiesDao,
			ILogEventDao logEventDao,
			ITransactionManager txManager) {
		this.errorReporterManager = ObjectUtil.assertNotNull(errorReporterManager);
		this.auditPropertiesDao = ObjectUtil.assertNotNull(auditPropertiesDao);
		this.auditEventDao = ObjectUtil.assertNotNull(auditEventDao);
		this.logEventDao = ObjectUtil.assertNotNull(logEventDao);
		this.txManager = txManager;
		LogDistributionManager.setAuditManager(this);
		LogDistributionManager.addLogDistributionEngine(this);
		SingletonStore.registerInterest(FusionProductInformationRetrievalManager.class, (bean) -> {
			infoRetreival = bean;
		});
	}

	@Override
	public void applicationRestarting() {}

	@Override
	public Class[] getDependsOn() {
		return null;
	}

	@Override
	public void applicationStarted() {
		errorReporterManager.registerDistributionEngine(this);
	}

	public FusionProduct getProductInfo() {
		if(PRODUCT_INFO == null) {
			if(infoRetreival != null) {
				FusionProductInformation fpi = infoRetreival.getFusionProductInformation();
				if(fpi == null) {
					return new FusionProductImpl("unknown", "unknown", "unknown", "unknown");
				}
				PRODUCT_INFO = fpi.getProductDetails();
			}
		}
		return PRODUCT_INFO;
	}

	@Override
	public List<IFusionLogEvent> getLogEvents(String auditId, boolean includeChildren, boolean includeAncestors) {
		List<IFusionLogEvent> logs = new ArrayList<>();
		if(includeAncestors || includeChildren) {
			List<IFusionAuditEvent> auditEvents = this.findById(auditId, includeChildren, includeAncestors, false);
			for(IFusionAuditEvent auditEvent : auditEvents) {
				logs.addAll(logEventDao.getLogEvents(auditEvent.getUid()));
			}
		} else {
			logs.addAll(logEventDao.getLogEvents(auditId));
		}
		logs.sort(LogEventComparator.INSTANCE);
		return logs;
	}

	@Override
	public void logEvent(IFusionLogEvent loggingEvent) {
		LocalAuditInfo auditInfo = getFusionAuditProcess();
		if(auditInfo != null) {
			auditInfo.addLog(loggingEvent);
		}
	}

	@Override
	public void writeAudits(IAuditEventQuery query, OutputStream out) {
		txManager.voidTransaction(()-> {
			List<IFusionAuditEvent> auditEvents = this.findAudits(query);
			auditEvents.sort(AuditEventComparator.INSTANCE);
			try {
				out.write(JsonBuilderAuditEvent.buildJson(auditEvents, true).toString().getBytes());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		});
	}

	@Override
	public void writeAudits(String uid, boolean includeChildren, boolean includeAncestors, OutputStream out) {
		txManager.voidTransaction(()-> {
			try {
				List<IFusionAuditEvent> auditEvents = this.findById(uid, includeChildren, includeAncestors, true);
				auditEvents.sort(AuditEventComparator.INSTANCE);
				out.write(JsonBuilderAuditEvent.buildJson(auditEvents, false).toString().getBytes());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		});
	}

	@SuppressWarnings("unchecked")
	/**
	 * Even though this is an IFusionAuditEvent it will not have the properties map as it is lazy loaded, so we call it a
	 * IFusionAuditDesc to protect the user of the API from calling a getter on this map which will result in failure
	 */
	private List<IFusionAuditEvent> findAudits(IAuditEventQuery query) {
		authManager.authorise(AuditConstants.AUDIT_SECURITY_FUNCTION);
		List<FusionAuditEvent> result = auditEventDao.findAudits(query);
		resolve(result, query.isIncludeChildren(), query.isIncludeAncestor(), false);
		return (List)result;
	}

	private List<IFusionAuditEvent> findById(String uid, boolean includeChildren, boolean includeAncestors, boolean attachProperties) {
		authManager.authorise(AuditConstants.AUDIT_SECURITY_FUNCTION);
		List<FusionAuditEvent> returnList = new ArrayList<>();
		FusionAuditEvent event = (FusionAuditEvent)findById(uid);
		if(event != null) {
			returnList.add(event);
		}
		resolve(returnList, includeChildren, includeAncestors, attachProperties);
		return (List)returnList;
	}

	private void resolve(List<FusionAuditEvent> result, boolean resolveChildren, boolean resolveAncestors, boolean attachProperties) {
		List<FusionAuditEvent> ancestors = new ArrayList<>();
		List<FusionAuditEvent> children = new ArrayList<>();
		if(result.size() > 0) {
			if(resolveAncestors) {
				List<String> parentIds = getParentIds(result);
				while(parentIds.size() > 0) {
					List<FusionAuditEvent> nextParents = auditEventDao.getAuditsByUid(parentIds, attachProperties);
					ancestors.addAll(nextParents);
					parentIds = getParentIds(nextParents);
				}
			}

			if(resolveChildren) {
				List<FusionAuditEvent> nextChildren = auditEventDao.getChildren(result.stream().map(e -> e.getUid()).collect(Collectors.toList()), attachProperties);
				while(nextChildren.size() > 0) {
					children.addAll(nextChildren);
					nextChildren = auditEventDao.getChildren(nextChildren.stream().map(e -> e.getUid()).collect(Collectors.toList()), attachProperties);
				}
			}
		}
		result.addAll(ancestors);
		result.addAll(children);
	}

	private List<String> getParentIds(List<FusionAuditEvent> audits) {
		Set<String> parentIds = new HashSet<>();
		for(FusionAuditEvent e : audits) {
			if(e.getParentProcess() != null) {
				parentIds.add(e.getParentProcess());
			}
		}
		return new ArrayList<>(parentIds);
	}

	private IFusionAuditEvent findById(String id) {
		authManager.authorise(AuditConstants.AUDIT_SECURITY_FUNCTION);
		LocalAuditInfo info = auditInfo.get(id);
		if(info != null) {
			return info.currentAudit;
		}
		return auditEventDao.getAudit(id);
	}

	@Override
	public String startAuditEvent(String processId, String eventType, IProcess auditProcss) {
		FusionAuditEvent parentEvent = getFusionAuditProcess() != null ? getFusionAuditProcess().currentAudit : null;
		return startAuditEvent(processId, eventType, parentEvent == null ? null : parentEvent.getUid(), auditProcss);
	}


	@Override
	public <T> T startAuditEventWithResponse(String processId, String eventType, IProcessWithResponse<T> auditProcss) {
		FusionAuditEvent parentEvent = getFusionAuditProcess() != null ? getFusionAuditProcess().currentAudit : null;
		return startAuditEvent(processId, eventType, parentEvent == null ? null : parentEvent.getUid(), false, auditProcss);
	}

	@Override
	public String startAuditEvent(String processId, String eventType, String parentId, IProcess auditProcss) {
		return startAuditEvent(processId, eventType, parentId, false,  ()-> {
			auditProcss.runProcess();
			return this.getCurrentAuditId();
		});
	}

	@Override
	public String prepareAudit(String processId, String eventType, IProcess auditProcss) {
		return startAuditEvent(processId, eventType, null, true, ()-> {
			auditProcss.runProcess();
			return this.getCurrentAuditId();
		});
	}

	private <T> T startAuditEvent(String processId, String eventType, String parentId, boolean prepare, IProcessWithResponse<T> auditProcss) {
		if(this.infoRetreival == null) {
			applicationStarted();
		}
		FusionAuditEvent event;
		if(parentId != null) {
			event = FusionAuditEvent.createSubProcess(null, parentId, processId, eventType);
		} else {
			event = FusionAuditEvent.createProcess(processId, eventType, getProductInfo());
		}
		LocalAuditInfo auditInfo = storeAudit(event, prepare);
		return runProcess(auditProcss, auditInfo);
	}

	@Override
	public String startNewThread(String subProcessId, String eventType, boolean copyThreadLocal, IProcess process) {
		LocalAuditInfo preThreadInfo = getFusionAuditProcess();
		final FusionAuditEvent parent = preThreadInfo != null ? preThreadInfo.currentAudit : null;
		final String newAuditId = UUID.randomUUID().toString();
		ISecureThread thread = FusionSecurityContext.CTX().createSecureThread(copyThreadLocal);
		thread.runProcess(() -> {

			//ThreadLocalUtil.clearFromThread(THREAD_KEY); //do not keep audit key from previous thread
			PROCESS_STATUS status = PROCESS_STATUS.SERVER_ERR_INTERNAL_ERROR; //error until it is success
			LocalAuditInfo auditInfo = null;
			try {
				FusionAuditEvent audit;
				if(parent != null) {
					audit = FusionAuditEvent.createSubProcess(newAuditId, parent.getUid(), subProcessId, eventType);
				} else {
					audit = FusionAuditEvent.createProcess(subProcessId, eventType, PRODUCT_INFO);
				}
				auditInfo = storeAudit(audit, false);
				runProcess(()-> {
					process.runProcess();
					return true;
				}, auditInfo);
				auditInfo = null;
			} finally {
				if(auditInfo != null) {
					auditInfo.closeAudit(status != null ? status.getStatusCode() : 0);  //0 is unknown
				}
			}
		});
		return newAuditId;
	}

	private <T> T runProcess(IProcessWithResponse<T> auditProcess, LocalAuditInfo auditInfo) {
		int status = 200;
		try {
			return auditProcess.runProcess();
		} catch(Throwable th) {
			status = ErrorUtil.getHTTPStatusCode(th);
			if(status != 404) {
				try {
					ErrorException ex = new ErrorException(th);
					JSONObject error = ex.getJson();
					StackTraceElement[] stack = th.getStackTrace();

					if(stack != null) {
						int max = stack.length > 3 ? 3 : stack.length;
						JSONArray stackArray = new JSONArray();
						for(int i=0; i < max; i++) {
							stackArray.put(new ErrorStack(stack[i]).getJson());
						}
						error.put("StackTrace", stackArray);
					}
					addAuditProperty("UncaughtException", error);
				} catch(Throwable th2) {}
			}
			throw th;
		} finally {
			auditInfo.closeAudit(status);
		}
	}

	@Override
	public void addAuditProperty(String propertyId, Object propertyValue) {
		if(propertyId != null) {
			LocalAuditInfo proc = getFusionAuditProcess();
			if(proc != null) {
				proc.currentAudit.writeProperty(propertyId, propertyValue);
			}
		}
	}



	@Override
	public IFusionAuditEvent getCurrentAudit() {
		LocalAuditInfo proc = getFusionAuditProcess();
		if(proc != null) {
			FusionAuditEvent currentAudit = proc.currentAudit;
			if(currentAudit != null) {
				return currentAudit;
			}
		}
		return null;
	}

	@Override
	public String getCurrentAuditId() {
		IFusionAuditEvent currentAudit = getCurrentAudit();
		if(currentAudit != null) {
			return currentAudit.getUid();
		}
		return null;
	}

	@Override
	public void distributeError(IErrorReport errorReport, IErrorNotifier notifier) {
		if(errorReport.getAuditId() != null) {
			synchronized(auditInfo) {
				String auditId = errorReport.getAuditId();
				LocalAuditInfo event = this.auditInfo.get(auditId);
				if(event != null && event.currentAudit != null) {
					event.currentAudit.setStatus(errorReport.getStatus());
				} else {
					FusionAuditEvent audit = auditEventDao.getAudit(auditId);
					if(audit != null) {
						if(audit.getStatus() == null && errorReport.getStatus() != null) {
							audit.setStatus(errorReport.getStatus());
							auditEventDao.updateAudit(audit);
						}
					}
				}
			}
		}
	}
	
	@Override
	public void setPersisted() {
		LocalAuditInfo localInfo = getFusionAuditProcess();
		if(localInfo != null && localInfo.isPersisted == false) {
			localInfo.setPersisted();
		}
	}

	private LocalAuditInfo getFusionAuditProcess() {
		return this.auditInforForThread.get(Thread.currentThread());
	}

	private LocalAuditInfo storeAudit(FusionAuditEvent audit, boolean prepareMode) {
		LocalAuditInfo auditInfo = getFusionAuditProcess();
		if(auditInfo == null || auditInfo.currentAudit == null) {
			auditInfo = new LocalAuditInfo(audit, prepareMode);
			this.auditInforForThread.put(Thread.currentThread(), auditInfo);
		} else {
			auditInfo.addAudit(audit, prepareMode);
		}
		this.auditInfo.put(audit.getUid(),  auditInfo);
		if(!prepareMode) {
			auditEventDao.saveAudit(audit);
		}
		return auditInfo;
	}

	private class LocalAuditLogs {
		List<IFusionLogEvent> logs = new ArrayList<>();
	}

	private class LocalAuditInfo {
		private Deque<FusionAuditEvent> stack = new ArrayDeque<>();
		private Deque<LocalAuditLogs> logStack = new ArrayDeque<>();
		private List<FusionAuditEvent> closed = new ArrayList<>(5);
		private FusionAuditEvent currentAudit;
		private LocalAuditLogs currentLogs;
		//indicates that the audit is prepared in case sub audit events are captured, if they are not then the prepared audit is discarded
		//this allows for the capture of high level information in a stack which does not know if it is needed or not
		private boolean isPrepareMode;
		private boolean isPersisted;

		public LocalAuditInfo(FusionAuditEvent audit, boolean prepareMode) {
			this.currentAudit = audit;
			this.isPrepareMode = prepareMode;
			currentLogs = new LocalAuditLogs();
		}
		
		private void setPersisted() {
			isPersisted = true;
			if(currentAudit != null) {
				currentAudit.setPersisted(1);
			}
			stack.forEach((e) -> {
				e.setPersisted(1);
			});
			closed.forEach((e)-> {
				e.setPersisted(1);
				auditEventDao.updateAudit(e);
			});
		}

		private void popAudit() {
			if(stack.size() > 0) {
				currentAudit = stack.pop();
				currentLogs = logStack.pop();
			} else {
				currentAudit = null;
				currentLogs = null;
			}
		}

		private void addLog(IFusionLogEvent loggingEvent) {
			if(currentLogs != null) {
				currentLogs.logs.add(loggingEvent);
			}
		}

		private void addAudit(FusionAuditEvent event, boolean prepareMode) {
			if(!prepareMode && this.isPrepareMode) {
				isPrepareMode = false;
				auditEventDao.saveAudit(currentAudit);
			}
			if(isPersisted) {
				event.setPersisted(1);
			}
			stack.push(currentAudit);
			logStack.push(currentLogs);
			currentAudit = event;
			currentLogs = new LocalAuditLogs();
		}

		private void closeAudit(int status) {
			if(currentAudit == null) {
				auditInforForThread.remove(Thread.currentThread());
				return;
			}
			FusionAuditEvent saveAudit = currentAudit;
			LocalAuditLogs saveLogs = currentLogs;
			popAudit();
			if(currentAudit == null) {
				auditInforForThread.remove(Thread.currentThread());
			}
			if(auditInfo != null) {
				if(!isPrepareMode) {
					try {
						saveAudit.endProcess(status);
						synchronized(auditInfo) {
							auditInfo.remove(saveAudit.getUid());
							auditEventDao.updateAudit(saveAudit);
							auditPropertiesDao.saveProperties(saveAudit.getUid(), saveAudit.getAuditedProperties());
							if(saveAudit != null && saveLogs.logs.size() > 0 && logEventDao != null) {
								logEventDao.saveLogEvents(saveAudit.getUid(), saveLogs.logs);
							}
							closed.add(saveAudit);
						}
					} catch(Throwable th) {
						LOG.error("save audit error", th);
					}
				} else {
					synchronized(auditInfo) {
						auditInfo.remove(saveAudit.getUid());
					}
				}
			}
		}
	}
}
