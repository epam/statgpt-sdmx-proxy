package io.sdmx.fusion.audit.service;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.api.service.audit.IErrorService;
import io.sdmx.core.dao.api.tx.ITransactionManager;
import io.sdmx.fusion.audit.api.manager.error.IErrorReportRetrievalManager;
import io.sdmx.fusion.audit.builder.JsonBuilderErrorCategory;
import io.sdmx.fusion.audit.builder.JsonBuilderErrorEvent;
import io.sdmx.fusion.audit.model.error.ErrorReportQuery;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.process.ReturnProcess;

public class ErrorServiceActivator implements IErrorService {
	private IErrorReporterManager errorReporterManager;
	private IErrorReportRetrievalManager errorReportRetrievalManager;
	private ITransactionManager txManager;
	
	public ErrorServiceActivator(IErrorReporterManager errorReporterManager, IErrorReportRetrievalManager errorReportRetrievalManager, ITransactionManager txManager) {
		this.errorReporterManager = ObjectUtil.assertNotNull(errorReporterManager);
		this.errorReportRetrievalManager = ObjectUtil.assertNotNull(errorReportRetrievalManager);
		this.txManager = txManager;
	}

	@Override
	public JSONArray getErrorNotifiers() {
		JSONArray responseArray = new JSONArray();
		for(IErrorNotifier notifier :  errorReporterManager.getErrorNotifiers()) {
			JSONObject notifierJson = new JSONObject();
			try {
				notifierJson.put("Id", notifier.getId());
				notifierJson.put("Name", notifier.getName());
				notifierJson.put("Description", notifier.getDescription());
				responseArray.put(notifierJson);
			} catch (JSONException e) {
				throw new RuntimeException(e);
			}
		}
		return responseArray;
	}

	@Override
	public JSONArray getErrorCategories(String errorNotifierId) {
		JSONArray responseArray = new JSONArray();
		for(IErrorNotifier notifier :  errorReporterManager.getErrorNotifiers()) {
			if(notifier.getId().equals(errorNotifierId)) {
				responseArray = JsonBuilderErrorCategory.build(notifier.getErrorCategories());
				break;
			}
		}
		return responseArray;
	}

	@Override
	public JSONArray getCategories() {
		List<IErrorCategory> categories = new ArrayList<>();
		for(IErrorNotifier notifier :  errorReporterManager.getErrorNotifiers()) {
			categories.addAll(notifier.getErrorCategories());
		}
		return JsonBuilderErrorCategory.build(categories);
	}

	@Override
	public JSONArray getErrorReports(String errorNotifierId, String categoryId, String auditId, String from, String to, boolean full, Integer limit, Integer offset) {
		ErrorReportQuery query = new ErrorReportQuery();
		query.setNotifierId(errorNotifierId);
		query.setAuditId(auditId);
		query.setCategoryId(categoryId);
		if(from != null) {
			query.setDateFrom(SdmxDateImpl.getSdmxDate(from).getDate().getTime());
		}
		if(to != null) {
			query.setDateTo(SdmxDateImpl.getSdmxDate(to).getDate().getTime());
		}
		query.setMaxResults(limit);
		query.setOffSet(offset);
		
		ReturnProcess<JSONArray> process = new ReturnProcess<JSONArray>() {
			@Override
            public void runProcess() {
				super.setReturnObj(JsonBuilderErrorEvent.buildJson(errorReportRetrievalManager.find(query), full == false));
			}
		};
		txManager.voidTransaction(process);
		return process.getReturnObj();
	}

	@Override
	public JSONObject getErrorReport(String id) {
		ReturnProcess<JSONObject> process = new ReturnProcess<JSONObject>() {
			@Override
            public void runProcess() {
				IErrorReport report = errorReportRetrievalManager.findByUid(id);
				if(report != null) {
					super.setReturnObj(JsonBuilderErrorEvent.buildJson(report, false));
				}
			}
		};
		txManager.voidTransaction(process);
		return process.getReturnObj();
	}
}
