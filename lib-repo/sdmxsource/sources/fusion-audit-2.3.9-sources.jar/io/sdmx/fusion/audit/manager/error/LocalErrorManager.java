package io.sdmx.fusion.audit.manager.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.error.IErrorCategory;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.fusion.audit.builder.ErrorReportBuilder;
import io.sdmx.fusion.audit.model.error.ErrorCategory;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * NOT A SINGLETON
 * 
 * This class is used to report errors to the error notifier on behalf of another process, it contains the id, name, and description of the process, and the error categories
 * it can report against
 */
public class LocalErrorManager implements IErrorNotifier {
	private IErrorReporterManager errorReporterManager;
	private ErrorReportBuilder errorReportBuilder;

	private List<IErrorCategory> errorCategories = new ArrayList<>();
	private Map<String, IErrorCategory> errorCategoryMap = new HashMap<>();
	private String id;
	private String name;
	private String description;
	
	public LocalErrorManager(String id, String name, String decription) {
		this.id = id;
		this.description = decription;
		this.name = name;
		SingletonStore.registerInterest(IErrorReporterManager.class, (clz) -> {
			errorReporterManager = clz;
			errorReporterManager.registerNotifier(this);
		});
		SingletonStore.registerInterest(ErrorReportBuilder.class, (clz) -> {
			errorReportBuilder = clz;
		});
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getDescription() {
		return description;
	}

	public List<IErrorCategory> getErrorCategories() {
		return Collections.unmodifiableList(this.errorCategories);
	}
	
	public void addErrorCategory(String id, String errorName, String errorDescription, String[]... supportedProperties) {
		IErrorCategory errorCategory = new ErrorCategory(id, errorName, errorDescription, toMap(supportedProperties), this);
		this.errorCategories.add(errorCategory);
		if(this.errorCategoryMap.containsKey(id)) {
			throw new IllegalArgumentException("Error Category '"+id+"' is already defined");
		}
		this.errorCategoryMap.put(id, errorCategory);
	}

	/**
	 * Notifies of error and returns the unique error id
	 * @param categoryId
	 * @param errorDesc
	 * @param th
	 * @param reportedProperties an array of key value pairs 
	 * @return
	 */
	public String notifyError(String categoryId, String errorDesc, Throwable th, String[]...reportedProperties) {
		return notifyError(categoryId, errorDesc, null, th, reportedProperties);
	}
	
	/**
	 * Notifies of error and returns the unique error id
	 * @param categoryId
	 * @param errorDesc
	 * @param th
	 * @param reportedProperties an array of key value pairs 
	 * @return
	 */
	public String notifyError(String categoryId, String errorDesc, String auditId, Throwable th, String[]...reportedProperties) {
		IErrorCategory category = errorCategoryMap.get(categoryId);
		if(category == null) {
			throw new IllegalArgumentException("Can not build error report - unknown error category:"+categoryId);
		}
		if(errorReportBuilder != null) {
			IErrorReport errorReport = errorReportBuilder.buildErrorReport(category, errorDesc, auditId, toMap(reportedProperties), th);
			errorReporterManager.reportError(errorReport);
			return errorReport.getUID();
		}
		return null;
	}
	
	private Map<String, String> toMap(String[]...varArgArr) {
		Map<String, String> returnMap = new HashMap<>();
		
		if(varArgArr != null) {
			for(String[] varArg : varArgArr) {
				returnMap.put(varArg[0], varArg[1]);
			}
		}
		return returnMap;
	}
	
}
