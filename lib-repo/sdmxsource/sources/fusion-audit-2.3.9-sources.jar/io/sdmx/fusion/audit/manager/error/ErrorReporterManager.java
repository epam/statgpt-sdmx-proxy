package io.sdmx.fusion.audit.manager.error;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.error.IErrorDistributionEngine;
import io.sdmx.api.error.IErrorNotifier;
import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.error.IErrorReporterManager;
import io.sdmx.api.exception.SdmxSemmanticException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ErrorReporterManager implements IErrorReporterManager {
	private static final Logger LOG = LoggerFactory.getLogger(ErrorReporterManager.class);
	
	private Set<IErrorDistributionEngine> errorDistributionEngines = new HashSet<>();
	private Map<String, IErrorNotifier> errorNotifiers = new HashMap<>();
	
	@Override
	public void reportError(IErrorReport report) {
		IErrorNotifier notifier = errorNotifiers.get(report.getNotifierId());
		if(notifier == null) {
			throw new SdmxSemmanticException("Error Report is against an un-registered notifier: "+report.getNotifierId()+"");
		}
		for(IErrorDistributionEngine distributionEngine : errorDistributionEngines) {
			try {
				distributionEngine.distributeError(report, notifier);
			} catch(Throwable th) {
				//Oh dear
				LOG.error("Error while attemping to distribute error to Engine: "+distributionEngine.getClass().getCanonicalName());
			}
		}
	}

	@Override
	public void registerNotifier(IErrorNotifier notifier) {
		this.errorNotifiers.put(notifier.getId(), notifier);
	}

	@Override
	public void registerDistributionEngine(IErrorDistributionEngine distributionEngine) {
		synchronized(this) {
			//Create a local copy and add, to prevent concurrent modification exception, without having to syncronize this set
			Set<IErrorDistributionEngine> errorDistributionEngines = new HashSet<>(this.errorDistributionEngines);
			errorDistributionEngines.add(distributionEngine);
			this.errorDistributionEngines = errorDistributionEngines;
		}
	}

	@Override
	public Set<IErrorNotifier> getErrorNotifiers() {
		return Collections.unmodifiableSet(new HashSet<>(this.errorNotifiers.values()));
	}

}
