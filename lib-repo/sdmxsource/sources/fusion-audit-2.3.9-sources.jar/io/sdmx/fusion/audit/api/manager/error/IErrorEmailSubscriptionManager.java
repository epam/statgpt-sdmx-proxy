package io.sdmx.fusion.audit.api.manager.error;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.api.exception.SdmxUnauthorisedException;

/**
 * Subscribe and un-subscribe email addresses to IErrorReports.
 * <p/>
 * This interface is intended for Admin users only
 * 
 * @see IErrorReport
 */
public interface IErrorEmailSubscriptionManager {

	/**
	 * Subscribes an email to the service and category
	 * @param email
	 * @param service service id or null to indicate all
	 * @param category category id or null to indicate all
	 * 
	 * @throws SdmxUnauthorisedException if the current user is not Admin
	 */
	void subscribe(String email, String service, String category) throws SdmxUnauthorisedException;
	
	/**
	 * Removes all the subscriptions based on the parameters
	 * @param email
	 */
	void unsubscribe(String email, String service, String category) throws SdmxUnauthorisedException;
	
	
}
