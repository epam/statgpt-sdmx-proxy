package io.sdmx.fusion.audit.dao.error;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.error.IErrorReport;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import io.sdmx.core.dao.model.hql.Argument;
import io.sdmx.core.dao.model.hql.Argument.FUNCTION;
import io.sdmx.core.dao.model.hql.Argument.OPERATOR;
import io.sdmx.fusion.audit.api.dao.error.IErrorReportDao;
import io.sdmx.fusion.audit.model.error.ErrorReport;
import io.sdmx.fusion.audit.model.error.ErrorReportQuery;

/**
 * This DAO should use a object store (Mongo DB) to support find be properties
 */
public class ErrorReportDao implements IErrorReportDao, IObjectDAOClient<ErrorReport> {

	private IObjectDAO<ErrorReport> dao;

	public ErrorReportDao(IObjectDAOFactory factory) {
		factory.register(this);
	}
	
	@Override
	public void setObjectDAO(IObjectDAO<ErrorReport> dao) {
		this.dao = dao;
	}

	@Override
	public Class<ErrorReport> toPersist() {
		return ErrorReport.class;
	}
	
	@Override
	public void saveErrorReport(ErrorReport errorReport) {
		dao.save(errorReport);
	}

	@Override
	public IErrorReport findByUid(String uid) {
		return (IErrorReport) dao.getTxManager().transaction(()-> {
			IErrorReport report = dao.findById(uid);
//			if(report != null) {
//				Hibernate.initialize(report.getError());
//				Hibernate.initialize(report.getStack());
//				Hibernate.initialize(report.getReportedProperties());
//			}
			return report;
		});
	}

	@Override
	public List<IErrorReport> getAllErrorReports() {
		return (List)dao.findAll();
	}

	@Override
	public List<IErrorReport> findReports(ErrorReportQuery query) {
		List<Argument> allArgs = new ArrayList<>();
		if(query != null) {
			if(query.getNotifierId() != null) {
				allArgs.add(Argument.getInstance("notifierId", query.getNotifierId()));
			}
			if(query.getCategoryId() != null) {
				allArgs.add(Argument.getInstance("categoryId", query.getCategoryId()));
			}
			if(query.getAuditId() != null) {
				allArgs.add(Argument.getInstance("auditId", query.getAuditId()));
			}
			if(query.getDateFrom() != null) {
				allArgs.add(Argument.getInstance("dateFrom", query.getDateFrom(), OPERATOR.GT_EQUAL));
			}
			if(query.getDateTo() != null) {
				allArgs.add(Argument.getInstance("dateTo", query.getDateTo(), OPERATOR.LT_EQUAL));
			}
		}

		allArgs.add(Argument.getInstance(FUNCTION.ORDER_BY, "timeStamp"));
		allArgs.add(Argument.getInstance(FUNCTION.ORDER, "desc"));
		Argument[] allArgsArray = new Argument[allArgs.size()];
		allArgs.toArray(allArgsArray);
		return (List)dao.findList(allArgsArray);
	}
}
