package io.sdmx.fusion.audit.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.api.service.audit.IAuditEventQuery;
import io.sdmx.api.service.audit.IAuditService;
import io.sdmx.fusion.audit.api.manager.retrieval.IAuditEventRetreivalManager;
import io.sdmx.fusion.audit.api.manager.retrieval.ILogEventRetreivalManager;
import io.sdmx.fusion.audit.model.query.AuditEventQuery;
import io.sdmx.utils.core.audit.JsonBuilderLogEvent;
import io.sdmx.utils.core.object.ObjectUtil;

public class AuditServiceActivator implements IAuditService {

	private IAuditEventRetreivalManager auditRetreivalManager;
	private ILogEventRetreivalManager logRetreivalManager;

	public AuditServiceActivator(IAuditEventRetreivalManager auditRetreivalManager, 
			ILogEventRetreivalManager logRetreivalManager) {
		this.auditRetreivalManager = ObjectUtil.assertNotNull(auditRetreivalManager);
		this.logRetreivalManager = ObjectUtil.assertNotNull(logRetreivalManager);
	}

	@Override
	public void writeAuditLogs(String auditId, Boolean includeChildren, Boolean includeAncestor, OutputStream out) {
		boolean incChildren = includeChildren != null && includeChildren;
		boolean incAncestor = includeAncestor != null && includeAncestor;
		List<IFusionLogEvent> auditLogs = logRetreivalManager.getLogEvents(auditId, incChildren, incAncestor);
		try {
			out.write(JsonBuilderLogEvent.build(auditLogs).toString().getBytes());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void writeAudits(String auditId, Boolean includeChildren, Boolean includeAncestor, OutputStream out) {
		boolean incChildren = includeChildren != null && includeChildren;
		boolean incAncestor = includeAncestor != null && includeAncestor;
		auditRetreivalManager.writeAudits(auditId, incChildren, incAncestor, out);
	}
	
	@Override
	public void writeAudits(JSONObject json, OutputStream out) {
		IAuditEventQuery query = new AuditEventQuery(json);
		auditRetreivalManager.writeAudits(query, out);
	}
}
