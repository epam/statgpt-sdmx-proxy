package io.sdmx.fusion.audit.builder;
import java.util.Collection;

import io.sdmx.api.audit.IFusionAuditEvent;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

public class JsonBuilderAuditEvent {


	/**
	 * Builds an audit even as a JSON Object
	 * @param auditEvent
	 * @return
	 * <pre>
	 *   [
	 *     { see buildJson }
	 *   ]
	 * 
	 * </pre>
	 * 
	 */
	public static JSONArray buildJson(Collection<IFusionAuditEvent> auditEvents, boolean asStub) {
		JSONArray returnObject = new JSONArray();
		for(IFusionAuditEvent audit : auditEvents) {
			audit.getJson();
			returnObject.put(buildJson(audit, asStub));
		}
		return returnObject;
	}

	/**
	 * Builds an audit even as a JSON Object
	 * @param auditEvent
	 * @return
	 * 
	 *  <pre>
	 *   {
	 *   	"UID" : "uid",
	 *   	"Parent" : null,
	 *   	"ProcessId" : "SAVE_DATA",
	 *   	"Username" : "mnelson",
	 *   	"ProcessStart" : 1234567,
	 *   	"ProcessEnd" : 12345678,
	 *   	"Status" : 200,
	 *   	"IsError" : false,
	 *   	"UID" : "",
	 *   	"Properties" : {					--only if not a stub
	 *   		"key" : "value"
	 *      },
	 *      "VMID" : "",
	 *      "MachineId" : "",
	 *      "SoftwareVersion" : "",
	 * </pre>
	 */
	private static JSONObject buildJson(IFusionAuditEvent auditEvent, boolean asStub) {
		return auditEvent.getJson(asStub);
	}

}
