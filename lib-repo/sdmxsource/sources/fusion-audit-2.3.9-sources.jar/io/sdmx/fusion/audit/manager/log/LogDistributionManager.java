package io.sdmx.fusion.audit.manager.log;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.LogbackException;
import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.logging.ILogDistributionEngine;
import io.sdmx.api.logging.ILogDistributionManager;
import io.sdmx.api.process.IProcess;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.audit.FusionLogEvent;

/**
 * This is an appender which can be added to logback.xml using the following XML
 * 
 * This appender distributes the log to all classes that implement {@link ILogDistributionEngine}
 * 
 * <appender name="fusionaudit" class="com.metadatatechnology.fcee.manager.audit.impl.LogDistributionManager"></appender>
 */
public class LogDistributionManager  extends AppenderBase<ILoggingEvent> implements ILogDistributionManager {

	private static IAuditEventManager auditEventManager;
	private static List<ILogDistributionEngine> engines = new ArrayList<>();
	private static Map<Integer, Long> expireTime = null;
	
	public LogDistributionManager() {
		SingletonStore.registerInstance(this);
	}

	
	@Override
	public void append(ILoggingEvent event) throws LogbackException {
		String auditId = auditEventManager == null ? null : auditEventManager.getCurrentAuditId();
		FusionLogEvent fusionLogEvent = new FusionLogEvent(event, auditId, expireTime);
		for(ILogDistributionEngine engine : engines) {
			engine.logEvent(fusionLogEvent);
		}
	}
	
	/**
	 * optional, sets the audit event manager, used to get the current audit id for the logs
	 * @param auditEventManager
	 */
	public static void setAuditManager(IAuditEventManager auditEventManager) {
		LogDistributionManager.auditEventManager = auditEventManager;
	}
	
	/**
	 * Advisory for systems to know how long to keep the logs for.
	 * 
	 * @param expires key is the log level (trace=0,debug=1,info=2,warn=3,error=4,all=-1,off=-10), value is the
	 * length of time to keep the log for
	 */
	public static void setExpireTime(Map<Integer, Long> expires) {
		LogDistributionManager.expireTime = expires;
	}
	
	public static void addLogDistributionEngine(ILogDistributionEngine distEngine) {
		List<ILogDistributionEngine> engines = new ArrayList<>(LogDistributionManager.engines);
		engines.add(distEngine);
		LogDistributionManager.engines = engines;
	}


	@Override
	public void runProcessWithTempDistributionEngine(ILogDistributionEngine distEngine, IProcess p) {
		addDistributionEngine(distEngine);
		try {
			p.runProcess();
		} finally {
			removeDistributionEngine(distEngine);
		}
	}


	@Override
	public void addDistributionEngine(ILogDistributionEngine distEngine) {
		addLogDistributionEngine(distEngine);
	}


	@Override
	public void removeDistributionEngine(ILogDistributionEngine distEngine) {
		int idx = LogDistributionManager.engines.indexOf(distEngine);
		if(idx >= 0) {
			List<ILogDistributionEngine> engines = new ArrayList<>(LogDistributionManager.engines);
			engines.remove(idx);
			LogDistributionManager.engines = engines;
		}
	}
	
	

}
