package io.sdmx.fusion.audit.model.event;

import java.util.Map;

import io.sdmx.utils.core.application.UniqueProcess;

public class EventsForProcess implements Comparable<EventsForProcess> {
	private UniqueProcess process;
	Map<Long, Long> countOfEvents;

	public EventsForProcess(UniqueProcess process, Map<Long, Long> countOfEvents) {
		this.process = process;
		this.countOfEvents = countOfEvents;
	}

	public UniqueProcess getProcess() {
		return process;
	}

	public Map<Long, Long> getCountOfEvents() {
		return countOfEvents;
	}

	@Override
	public int compareTo(EventsForProcess o) {
		return o.getProcess().compareTo(this.getProcess());
	}

	@Override
	public int hashCode() {
		return process.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof EventsForProcess) {
			EventsForProcess that = this;
			return that.getProcess().equals(this.getProcess());
		}
		return false;
	}



}
