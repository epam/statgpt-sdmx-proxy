package io.sdmx.fusion.audit.dao.event;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.core.dao.api.dao.IObjectDAO;
import io.sdmx.core.dao.api.dao.IObjectDAOClient;
import io.sdmx.core.dao.api.factory.IObjectDAOFactory;
import io.sdmx.core.dao.model.hql.Argument;
import io.sdmx.core.dao.model.hql.Argument.OPERATOR;
import io.sdmx.fusion.audit.api.dao.log.ILogEventDao;
import io.sdmx.fusion.audit.model.log.SerialzedLogs;
import io.sdmx.fusion.audit.model.persistable.PersistableLogEvent;

/**
 * Stores log events as a serialized and compressed JSON Array
 *
 */
public class BlobLogEventDao implements ILogEventDao, IObjectDAOClient<SerialzedLogs> {
	private IObjectDAO<SerialzedLogs> dao;

	public BlobLogEventDao(IObjectDAOFactory manager) {
		manager.register(this);
	}
	
	@Override
	public void setObjectDAO(IObjectDAO<SerialzedLogs> dao) {
		this.dao = dao;
	}

	@Override
	public Class<SerialzedLogs> toPersist() {
		return SerialzedLogs.class;
	}
	
	@Override
	public void backup() {
		dao.deleteWhere(Argument.getInstance("eventTime", TIME_FORMAT.WEEK.getMillisInPeriod(), OPERATOR.LT));
	}

	@Override
	public void saveLogEvents(String auditId, Collection<IFusionLogEvent> logEvents) {
		JSONArray arr = new JSONArray();
		for(IFusionLogEvent log : logEvents) {
			arr.put(log.getJson());
		}
		SerialzedLogs logs = new SerialzedLogs(auditId, arr);
		dao.save(logs);
	}

	@SuppressWarnings({ "unchecked"})
	@Override
	public List<? extends IFusionLogEvent> getLogEvents(String auditId) {
		try {
			return (List<PersistableLogEvent>) dao.getTxManager().transaction(()-> {
				SerialzedLogs logs = dao.findById(auditId);
				List<PersistableLogEvent> logEvents = new ArrayList<>();
				if(logs != null) {
					JSONArray arr = logs.getSerialzed(null, null);
					if(arr != null) {
						for(int i=0; i < arr.length(); i++)  {
							try {
								logEvents.add(new PersistableLogEvent(arr.getJSONObject(i)));
							} catch (JSONException e) {
								e.printStackTrace();
							}		
						}
					}
				}
				return logEvents;
			});
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return Collections.emptyList();
	}

}
