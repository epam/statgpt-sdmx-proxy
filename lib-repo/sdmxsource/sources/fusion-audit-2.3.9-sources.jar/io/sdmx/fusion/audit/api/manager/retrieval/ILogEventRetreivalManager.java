package io.sdmx.fusion.audit.api.manager.retrieval;

import java.util.List;

import io.sdmx.api.logging.IFusionLogEvent;

public interface ILogEventRetreivalManager {

	/**
	 * @param auditId
	 * @return log events for the audit or null if none exist
	 */
	List<IFusionLogEvent> getLogEvents(String auditId, boolean includeChildren, boolean includeAncestors);

}
