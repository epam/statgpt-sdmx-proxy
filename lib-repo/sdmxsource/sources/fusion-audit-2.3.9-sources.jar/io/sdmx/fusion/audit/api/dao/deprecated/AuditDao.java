package io.sdmx.fusion.audit.api.dao.deprecated;

import io.sdmx.fusion.audit.api.dao.event.IAuditEventDao;
import io.sdmx.fusion.audit.model.deprecated.PersistableAuditEvent;

@Deprecated 
/**
 * @deprecated use {@link IAuditEventDao}
 */
public interface AuditDao {

	/**
	 * Returns the audit event for the given transaction
	 * @param transactionId
	 * @return
	 */
	PersistableAuditEvent getByTransactionId(Integer transactionId);

}
