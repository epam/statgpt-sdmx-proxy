package io.sdmx.fusion.audit.model.error;

import java.util.Set;

public class ErrorEmailSubscription {
	private String emailAddress;
	private Set<String> subscribedErrors;
	
	public ErrorEmailSubscription() {}

	public ErrorEmailSubscription(String emailAddress, Set<String> subscriedErrors) {
		this.emailAddress = emailAddress;
		this.subscribedErrors = subscriedErrors;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Set<String> getSubscribedErrors() {
		return subscribedErrors;
	}

	public void setSubscribedErrors(Set<String> subscribedErrors) {
		this.subscribedErrors = subscribedErrors;
	}
	
}
