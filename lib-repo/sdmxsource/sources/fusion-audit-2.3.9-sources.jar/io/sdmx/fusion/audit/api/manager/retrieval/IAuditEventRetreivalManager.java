package io.sdmx.fusion.audit.api.manager.retrieval;

import java.io.OutputStream;

import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.service.audit.IAuditEventQuery;

/**
 * For finding audit events
 * @see IAuditEventManager for creating Audit Events
 */
public interface IAuditEventRetreivalManager {

	/**
	 * @param query
	 * @return any audit events that match the query filters, or an empty list if none exist
	 */
	void writeAudits(IAuditEventQuery query, OutputStream out);


	/**
	 * @param uid
	 * @return event with the given id or an empty list if there is no match
	 */
	void writeAudits(String uid, boolean includeChildren, boolean includeAncestors, OutputStream out);

}
