package io.sdmx.api.dao.settings;

import java.io.Serializable;
import java.util.List;

public interface SerializableFusionSetting extends Serializable {
    /**
     * @return The id to save in the database
     */
	String getId();
	
	/**
     * @return The serializable
     */
	Serializable getValue();
	
	/**
     * @return The serializable in its List of data form
     */
	List<SerializableFusionSettingData> getSerData();
}
