package io.sdmx.api.dao.object;

import java.util.List;

import io.sdmx.api.audit.ITXLog;
import io.sdmx.api.io.IObjectSerialiser;

public interface IObjectStoreDao {

	/**
	 * @param query can be null to indicate a count of all
	 * @return a count of how many objects match the query
	 */
	int count(IObjectStoreQuery query);
	
	/**
	 * Creates and saves a new Object (keyed by URN) in the store.  If any object exists in the store with the same URN it will be
	 * discontinued with this version becoming the live version.
	 * 
	 * @param <V>
	 * @param txLog
	 * @param urn the identity of the object
	 * @param object the object to save
	 * @param serialiser the class that will serialise the object into a byte array for storage
	 * @return true if the object was replaced, false to indicate it was a creation of a new object without replacing a previous
	 */
	<V extends Object> boolean createObject(ITXLog txLog, String urn, V object, IObjectSerialiser<V> serialiser);

	/**
	 * Finds a list of objects that match the query
	 * @param <V>
	 * @param query
	 * @param readAs
	 * @return
	 */
    <V extends Object> List<V> find(IObjectStoreQuery query, Class<V> readAs);
	
	/**
	 * 
	 * @param id the unique id for the object
	 * @return the input stream for the ID against which the Object was stored, returns null if the object could not be found or there was an error retrieving the Object
	 */
    Object readObject(String id);
	
	/**
	 * @param id
	 * @return the object definition (not the full object)
	 */
	IObjectPersistable getObject(String id);
	
	/**
	 * @param type
	 * @param urn
	 * @param validOn
	 * @return the persisted object definition, or null if it does not exist
	 */
	IObjectPersistable findObject(String type, String urn, Long validOn);
	
	/**
	 * 
	 * @param urn urn of object
	 * @param validOn the time the object was, null to read the live object
	 * @return the input stream for the ID against which the Object was stored, returns null if the object could not be found or there was an error retrieving the Object
	 */
	Object readObject(String type, String urn, Long validOn);
	
	/**
	 * Deletes the object permanently from the object store
	 * @param id the unique identifier for the object
	 */
	void delete(String id);
	
	/**
	 * Discontinues the object with the given URN by setting the live objects valid to date to that of the transaction
	 * @param urn the URN of the object to delete
	 * @param type
	 * @param validToTime
	 * @param permanent if true the object is permanently removed
	 * @return true if there was an existing object
	 */
	boolean discontinueObject(ITXLog log, String urn, boolean permanent);
	
	/**
	 * @param urn
	 * @return the object transaction that is live (it has not been superseded, null if there is no live object
	 */
	IObjectPersistable getLiveObject(String type, String urn);
	
	/**
	 * @param type
	 * @return list of live objects by type
	 */
	List<IObjectPersistable> getLiveObjects(String type);
	
	/**
	 * @param type the type of object
	 * @return a list of URNs which contain the live reference metadata
	 */
	List<String> getLiveUrns(String type);
	
}
