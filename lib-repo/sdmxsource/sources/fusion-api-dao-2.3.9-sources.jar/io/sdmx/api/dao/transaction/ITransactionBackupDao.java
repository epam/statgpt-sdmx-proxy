package io.sdmx.api.dao.transaction;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

@Deprecated 
/**
 *
 * @deprecated use {@link MaintainableDao} with TemporalUtil to set time based on {@link ITXLogDao} 
 */
public interface ITransactionBackupDao {

	/**
	 * Loads the SdmxBeans found for the transaction with the given id
	 * @param id
	 * @return
	 * @throws SdmxException if the transaction could not be found with the given id
	 */
	SdmxBeans loadItemsFromTransaction(Integer id) throws SdmxException;

}
