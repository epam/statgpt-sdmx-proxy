package io.sdmx.api.dao.cors;

import java.util.List;

import io.sdmx.api.http.CORSBase;

/***
 * CORSSettings Database Access Object
 * Allows saving, retrieving and deleting CorsSettings objects.
 */
public interface ICORSSettingsDao {

	/***
	 * Save the given list of CORS settings. Not null.
	 * @param corsEntries
	 */
	void saveCORSSettings(List<CORSBase> corsEntries);

	/***
	 * Save or update the given list of CORS settings. Not null.
	 * @param corsEntries
	 */
	void saveOrUpdateCORSSetting(CORSBase corsEntry);

	/**
	 * Deletes the CORS settings entry referenced by the URL.
	 * @param url
	 */
	void deleteCORSSetting(String url);

	/***
	 * deletes all saved CORS settings.
	 */
	void deleteCORSSettings();

	/**
	 * Returns the CORS settings entries.
	 * @return
	 */
	List<CORSBase> getCORSSettings();
}
