package io.sdmx.api.dao.settings;

import java.util.List;
import java.util.Locale;

import io.sdmx.api.lang.LocaleOverride;

/**
 * Manages settings relating to the format of data output by the Registry. 
 */
public interface DataFormattingSettingsManager {

	/**
	 * @return Whether to use the Locale from the Message Header (the field "Accept-Language")
	 */
	boolean useLocaleFromMessageHeader();

	/**
	 * Specifies whether to use the Locale from the Message Header (the field "Accept-Language")
	 * @param aValue 
	 */
	void setUseLocaleFromMessageHeader(boolean aValue);

	/**
	 * @return the default Locale or null if one has not been set
	 */
	Locale getDefaultLocale();

	/**
	 * Sets what the defaultLocale should be 
	 * @param defaultLocale
	 */
	void setDefaultLocale(Locale defaultLocale);

	/**
	 * @return a JSON string of the override locales
	 */
	List<LocaleOverride> getOverrideLocales();

	/**
	 * Specifies the Locale Overrides from a JSONArray 
	 * @param overrideLocales
	 */
	void setLocaleOverrides(List<LocaleOverride> overrideLocales);

	/**
	 * Check whether this locale has an override
	 * @param aLocale the locale to check
	 * @return true / false 
	 */
	boolean hasLocaleOverride(Locale aLocale);

	/**
	 * Returns the group separator character for this locale
	 * @param specifiedLocale
	 * @return
	 */
	Character getGroupSeparator(Locale specifiedLocale);

	/**
	 * Returns the decimal separator character for this locale
	 * @param specifiedLocale
	 * @return
	 */
	Character getDecimalSeparator(Locale specifiedLocale);
}