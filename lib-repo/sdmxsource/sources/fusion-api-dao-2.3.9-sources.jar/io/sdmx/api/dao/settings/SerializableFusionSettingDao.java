package io.sdmx.api.dao.settings;

import java.util.List;

public interface SerializableFusionSettingDao {
	
    /**
     * Saves, or overwrites the current setting
     */
    void saveSettings(List<SerializableFusionSettingData> sfs);
	
	/**
	 * Removes a setting with the given name
	 * @param name
	 */
	void removeSetting(String id);
	
	/**
	 * Returns the String value of the setting, or null if the value does not exist
	 * @param name
	 * @return
	 */
	List<SerializableFusionSettingData> findSerializableValueById(String id);
}