package io.sdmx.api.dao.security;

import java.util.Collection;
import java.util.List;

public interface FusionADRoleMappingDao {

	/**
	 * Returns all role mappings, or an empty list if none exist
	 * @return
	 */
	List<IFusionActiveDirectoryMapping> getAllMappings();

	/**
	 * Deletes all the mapped roles for the given AD Role
	 * @param adRole
	 */
	void deleteByAdRole(String adRole);

	/**
	 * Changes the active directory role id
	 * @param oldRole
	 * @param newRole
	 */
	void changeByAdRole(String oldRole, String newRole);

	/**
	 * Saves an instance of the role mapping
	 * @param adMapping
	 */
	void saveRoleMapping(IFusionActiveDirectoryMapping adMapping);

	/**
	 * Deletes the role mapping if it exists
	 * @param adMapping
	 */
	void deleteByInstance(IFusionActiveDirectoryMapping adMapping);

	/**
	 * Bulk save a set of FusionActiveDirectoryMapping
	 * @param toSave
	 */
	void bulkSave(Collection<IFusionActiveDirectoryMapping> toSave);

	/**
	 * Bulk remove a set of Settings
	 * Note: Although the info is an array, the actual delete is done one by one
	 * @param toSave
	 */
	void bulkDelete(Collection<IFusionActiveDirectoryMapping> toSave);

	/**
	 * Deletes all the role mappings
	 */
	void clearTable();

}
