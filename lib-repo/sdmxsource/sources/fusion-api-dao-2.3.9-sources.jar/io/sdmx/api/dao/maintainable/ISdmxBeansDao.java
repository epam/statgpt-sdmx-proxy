package io.sdmx.api.dao.maintainable;

import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

public interface ISdmxBeansDao {

	/**
	 * Saves the beans in the container
	 * @param beans
	 * @return event containing the structures that were added, modified, and deleted
	 */
	ITransactionalBeansEvent saveBeans(SdmxBeans beans);
	
}
