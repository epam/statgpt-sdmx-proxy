package io.sdmx.api.dao.settings;

import java.util.Collection;
import java.util.List;

import io.sdmx.api.notification.PropertyChangeNotifier;

public interface FusionProductSettingsDao<T extends FusionSetting> extends PropertyChangeNotifier {
	
	/**
	 * Saves, or overwrites the current setting
	 * @param instance
	 */
	void saveSettings(T instance);

	/**
	 * Saves a setting, if the value is null, then the setting will be removed
	 * @param name
	 * @param value
	 */
	void saveSetting(String name, Object value);
	
	/**
	 * Removes a setting with the given name
	 * @param name
	 */
	void removeSetting(String name);
	
	T findByName(Enum<?> name);

	
	T findByName(String name);
	
	void clearTable();
	
	List<T> getAllResult();
	
	/**
	 * Bulk save a set of Settings   <br />
	 * Note: Although the info is an array, the actual save is done one by one
	 * @param toSave
	 */
	void bulkSave(Collection<T> toSave);
	
	/**
	 * delete an item from the database by instance
	 * @param instance
	 */
	void deleteByInstance(T instance);
	
	/**
	 * Bulk remove a set of Settings
	 * Note: Although the info is an array, the actual delete is done one by one
	 * @param toSave
	 */
	void bulkDelete(Collection<T> toSave);
	
	/**
	 * Returns the String value of the setting, or null if the value does not exist
	 * @param name
	 * @return
	 */
	String findStringValueByName(String name);
	
	/**
	 * Returns the Integer value of the setting, or null if the value does not exist
	 * @param name
	 * @return
	 */
	Integer findIntegerValueByName(String name);
	
	/**
	 * Returns the Boolean value of the setting, or Boolean.FALSE if the value does not exist
	 * @param name
	 * @return
	 */
	Boolean findBooleanValueByName(String name);
	
	/**
	 * Returns the Boolean value of the setting, or the default value if the value does not exist
	 * @param name
	 * @param defaultValue
	 * @return
	 */
	Boolean findBooleanValueByName(String name, boolean defaultValue);
}
