package io.sdmx.api.dao.security;

import java.util.Collection;

/**
 * Saves and retrieves settings for the current user
 */
public interface FusionUserSettingsDao {

	/**
	 * Stores the setting for the user
	 * @param name
	 * @param value
	 */
	@SuppressWarnings("rawtypes")
	void saveSetting(String username, Enum setting, String value);
	
	/**
	 * Stores the setting for the user
	 * @param name
	 * @param value
	 */
	void saveSetting(String username, String name, String value);
	
	/**
	 * Removes the setting for the user
	 * @param name
	 */
	void removeSetting(String username, String settingName);
	
	/**
	 * Retrieves the setting for the user
	 * @param name
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	String getSetting(String username, Enum setting);
	
	/**
	 * Retrieves the setting for the user
	 * @param name
	 * @return
	 */
	String getSetting(String username, String settingName);

	/**
	 * Returns all the settings for the user
	 * @return
	 */
	Collection<FusionUserSettings> getSettings(String username);
	
}
