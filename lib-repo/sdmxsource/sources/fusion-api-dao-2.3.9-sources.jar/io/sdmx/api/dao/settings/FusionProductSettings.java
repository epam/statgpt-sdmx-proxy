package io.sdmx.api.dao.settings;

/**
 * Name/Value pair for a Setting
 */
public interface FusionProductSettings extends FusionSetting {

	/**
	 * Returns the name for the setting
	 * @return
	 */
	@Override
	String getName();

	/**
	 * Returns the value for the setting
	 * @return
	 */
	@Override
	String getValue();
	
}
