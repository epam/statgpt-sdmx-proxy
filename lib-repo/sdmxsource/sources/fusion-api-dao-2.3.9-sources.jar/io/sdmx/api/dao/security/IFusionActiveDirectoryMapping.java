package io.sdmx.api.dao.security;

import java.io.Serializable;

public interface IFusionActiveDirectoryMapping extends Serializable {

	String getAlias();

	String getUrn();
	
}
