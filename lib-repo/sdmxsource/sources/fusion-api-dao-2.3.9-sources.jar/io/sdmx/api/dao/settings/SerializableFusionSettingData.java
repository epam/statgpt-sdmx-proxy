package io.sdmx.api.dao.settings;

import java.io.Serializable;

/**
 * Represents an object which is all or a chunk of data against an ID. The line Number of this object states
 * its position in the overall data.
 *
 * A database of these items would look like:
 * ID             line_no   serialized_data
 * -------------  -------   ----------------
 * registry.logo  0         <first 4096 bytes>           
 * registry.logo  1         <4096  - 8192 bytes>
 * registry.logo  2         <remaining 808 bytes>
 */
public interface SerializableFusionSettingData extends Serializable {
    /**
     * @return the ID of the setting to save
     */
    String getId();
    
    /**
     * @return the line no of the chunk
     */
    Integer getLineNo();
    
    /**
     * @return a block of data
     */
    byte[] getSerializedData();
}