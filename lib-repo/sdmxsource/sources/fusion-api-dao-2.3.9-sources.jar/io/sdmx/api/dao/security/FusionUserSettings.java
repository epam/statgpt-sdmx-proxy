package io.sdmx.api.dao.security;

import java.io.Serializable;

/**
 * Defines a system setting value for a user
 */
public interface FusionUserSettings extends Serializable {

	/**
	 * Returns the username who owns this setting value
	 * @return
	 */
	String getUsername();

	/**
	 * Returns the setting name
	 * @return
	 */
	String getSettingName();

	/**
	 * Returns the setting value
	 * @return
	 */
	String getSettingValue();
	
}
