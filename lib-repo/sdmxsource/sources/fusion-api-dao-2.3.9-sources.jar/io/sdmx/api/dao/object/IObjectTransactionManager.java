package io.sdmx.api.dao.object;

import java.util.List;
import java.util.Set;

import io.sdmx.api.audit.ITXLog;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.tx.ITransactionQuery;

public interface IObjectTransactionManager {

	/**
	 * Returns the transaction with the given id
	 * @param dateFrom
	 * @return
	 */
	ITXLog getTransaction(Integer txId);
	
    /**
     * Returns all the transactions for the given maintainable urn
     * @param urn
     * @return
     */
    List<ITXLog> getTransactions(IURNMaintainable<?> urn);
    
    /**
     * returns the last transaction for the maintainable structure with the given URN
     * @param urn
     * @return
     */
    ITXLog getLastTransaction(IURNMaintainable<?> urn);

    /**
     * @return the last transaction in the system
     */
    ITXLog getLastTransaction();  //TODO by type (i.e structure)
    
    /**
     * @param tx
     * @return the transaction that follows the one passed in, or null if there are none
     */
    ITXLog getNextTransaction(Integer txId);
    
    /**
     * @param txId
     * @return all the items in the transaction
     */
    SdmxBeans getTransactionBeans(Integer txId);
    
    /**
     * @param sRefUrn the maintainable URN of the structure to return
     * @param txId the transaction to which the maintainable was involved
     * @return the MaintainableBean for the specified URN and for the specified transaction id 
     */
    MaintainableBean getTransactionItem(IURNMaintainable<?> sRefUrn, Integer txId);
    
    /**
     * Returns all the transactions for the query
     * @param query
     * @return
     */
    List<ITXLog> getTransactions(ITransactionQuery query);

    /**
     * Returns all the unique URNs for all the structures in the manager
     * @return
     */
    Set<IURNMaintainable<?>> getUniqueUrns();
   
}
