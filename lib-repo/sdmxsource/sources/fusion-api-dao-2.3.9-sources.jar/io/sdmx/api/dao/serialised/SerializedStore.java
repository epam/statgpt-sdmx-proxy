package io.sdmx.api.dao.serialised;


/**
 * A serialized store is one which serializsed the structure as a SerialzedPersistable and if it can not deserialize then it will rebuild
 * and restore itself
 * @param <T>
 */
public interface SerializedStore<T> {

	void restoreSerializeable(T ser);
}
