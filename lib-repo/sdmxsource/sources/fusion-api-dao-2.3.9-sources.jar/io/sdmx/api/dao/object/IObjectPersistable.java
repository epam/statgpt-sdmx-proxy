package io.sdmx.api.dao.object;

import java.io.InputStream;
import java.io.Serializable;

/**
 * Describes an object which has been persisted
 */
public interface IObjectPersistable extends Serializable {
	
	/**
	 * @return not null, the transaction ID under which this object was persisted
	 */
	Integer getTxId();
	
	/**
	 * @return not null, the serialiser ID used to save this object
	 */
	String getSerialiserId();
	
	/**
	 * @return not null globally unique identity for this item in the table 
	 */
	Integer getId();

	/**
	 * @return not null the unique identity of the object (but multiple urns may exist in the same table with different validity period)
	 */
	String getUrn();

	/**
	 * @return not null the type object that is stored (i.e. live_structure, test_structure)  
	 */
	String getType();
	

	/**
	 * @return not null a timestamp of when the object was stored
	 */
	Long getValidFrom();
	

	/**
	 * @return nullable a timestamp of when the object was discontinued
	 */
	Long getValidTo();
	
	/**
	 * @return the object as a byte array 
	 */
	InputStream read();
}
