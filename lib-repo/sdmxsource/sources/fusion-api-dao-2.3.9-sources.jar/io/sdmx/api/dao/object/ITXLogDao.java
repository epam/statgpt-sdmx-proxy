package io.sdmx.api.dao.object;

import java.util.List;

import io.sdmx.api.audit.ITXLog;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.tx.ITransactionQuery;

public interface ITXLogDao {

	/**
	 * @return a new transaction record storing a unique id, related audit id, username, created date
	 */
	ITXLog createTransaction(DATASET_ACTION action, String store);
	
	/**
	 * 
	 * @param txLog
	 */
	void createTransaction(ITXLog txLog);
	
	
	/**
	 * Queries transactions by zero to many properties
	 * 
	 * @param query
	 * @return list of matched transaction logs
	 */
	List<ITXLog> getTransactions(ITransactionQuery query);
	
	/**
	 * @param id
	 * @return transaction with the given ID or null if it does not exist
	 */
	ITXLog getTransaction(Integer id);
	
	/**
	 * @param id
	 * @return next transaction in the sequence
	 */
	ITXLog getNextTransaction(Integer id);
	
}
