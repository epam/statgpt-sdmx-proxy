package io.sdmx.api.dao.settings;

import java.io.Serializable;

public interface FusionSetting extends Serializable {
	
	/**
	 * Get readable name mapping
	 * @return
	 */
	String getName();
	
	
	/**
	 * Get readable name value
	 * @return
	 */
	String getValue();

}
