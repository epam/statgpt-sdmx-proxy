package io.sdmx.api.dao.maintainable;

import io.sdmx.api.application.CacheManager;
import io.sdmx.api.dao.serialised.SerializedStore;

/**
 * Provides save and retrieval methods for maintainables
 * @author Matt Nelson
 *
 */
public interface MaintainableDao<T> extends SerializedStore<T>, ISdmxBeansDao, CacheManager  {
	public String CACHE_TYPE = "STRUCTURE";
	
	

}
