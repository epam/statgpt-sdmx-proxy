package io.sdmx.api.dao.object;

import io.sdmx.api.audit.ITXLog;

/**
 * Provides the ability to query for multiple objects from the object store, all properties are filters and all are optional
 * @see IObjectStoreDao
 */
public interface IObjectStoreQuery {

	/**
	 * @return nullable, the type of object
	 */
	String getType();

	/**
	 * @return nullable, the URN of the object
	 */
	String getUrn();

	/**
	 * @return nullable, the transaction that the object was saved against
	 */
	ITXLog getTx();

	/**
	 * @return nullable, mutually exclusive with getTx, the point in time for which the object was valid
	 */
	Long getValidOn();
	
}
