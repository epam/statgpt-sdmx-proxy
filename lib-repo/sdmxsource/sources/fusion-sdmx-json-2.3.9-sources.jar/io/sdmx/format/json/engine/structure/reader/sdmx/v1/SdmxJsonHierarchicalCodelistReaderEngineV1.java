package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonIdentifiableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonRepresentationUtil;
import io.sdmx.im.mutable.codelist.HierarchicalCodelistMutableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodelistRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonHierarchicalCodelistReaderEngineV1 extends AbstractSdmxJsonReaderEngine<HierarchicalCodelistMutableBean> implements IFusionSingleton {
    private static final String THREAD_LOCAL_KEY2 = "_ALIAS_LIST_";
    private static SdmxJsonHierarchicalCodelistReaderEngineV1 INSTANCE;

    public static SdmxJsonHierarchicalCodelistReaderEngineV1 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxJsonHierarchicalCodelistReaderEngineV1();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }


    @Override
    public String getContainerElement() {
        return "hierarchicalCodelists";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return HierarchicalCodelistBean.class;
    }

    @Override
    protected HierarchicalCodelistMutableBean getMutable() {
        return new HierarchicalCodelistMutableBeanImpl();
    }
    
    @Override
    protected HierarchicalCodelistMutableBean build(JsonReader jReader, IBeansBuilder beanBuilder,
            SdmxBeanRetrievalManager beanRetrievalManager) {
        List<StructureReferenceBeanImpl> storedRefs = new ArrayList<>();
        ThreadLocalUtil.storeOnThread(THREAD_LOCAL_KEY2, storedRefs);
        try {
            HierarchicalCodelistMutableBean mutable = super.build(jReader, beanBuilder, beanRetrievalManager);
            if(storedRefs.size() > 0) {
                for(StructureReferenceBeanImpl storedRef : storedRefs) {
                    String alias = storedRef.getMaintainableId().toUpperCase();
                    Map<String, StructureReferenceBean> codeAliasMap =mutable.getCodelistRef().stream().collect(Collectors.toMap(e->e.getAlias(), e->e.getCodelistReference()));
                    if(codeAliasMap != null) {
                        StructureReferenceBean clRef = codeAliasMap.get(alias);
                        if(clRef == null) {
                            throw new SdmxSemmanticException("Hierarchical Codelist reference not found by alias: " +alias);
                        }
                        storedRef.setAgencyId(clRef.getAgencyId());
                        storedRef.setMaintainableId(clRef.getMaintainableId());
                        storedRef.setVersion(clRef.getVersion());
                    }
                }
            }
            return mutable;
        } finally {
            ThreadLocalUtil.clearFromThread(THREAD_LOCAL_KEY2);
        }
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, HierarchicalCodelistMutableBean mutable, JsonReader reader) {
        switch(fieldName) {
        case "includedCodelists":
            readIncludedCodes(reader, mutable);
            return true;
        case "hierarchies":
            readHierarchies(reader, mutable);
            return true;
        }
        return false;
    }

    private void readHierarchies(JsonReader jReader, HierarchicalCodelistMutableBean mutable) {
        List<HierarchyMutableBean> retList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            HierarchyMutableBean hBean = new HierarchyMutableBeanImpl();
            while(jReader.moveNext()) {
                if(jReader.isEndObject()) {
                    break;
                }
                String fieldName = jReader.getCurrentFieldName();
                if(SdmxJsonNameableUtil.processBean(hBean, jReader)) {
                    continue;
                }
                switch(fieldName) {
                case "leveled":
                    boolean levled = jReader.getValueAsBoolean();
                    hBean.setFormalLevels(levled);
                    break;
                case "hierarchicalCodes":
                    hBean.setHierarchicalCodeBeans(readHrefBeans(jReader));
                    break;
                case "level":
                    LevelMutableBean level = readLevel(jReader);
                    hBean.setChildLevel(level);
                    break;
                }
            }
            mutable.addHierarchies(hBean);
        }
    }

    private List<CodeRefMutableBean> readHrefBeans(JsonReader jReader) {
        List<CodeRefMutableBean> retList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            CodeRefMutableBean hRefBean = new CodeRefMutableBeanImpl();
            String codelistAlias = null;
            String codeId = null;
            while(jReader.moveNext()) {
                if(jReader.isEndObject()) {
                    break;
                }
                String value = jReader.getValueAsString();
                if(SdmxJsonIdentifiableUtil.processBean(hRefBean, jReader)) {
                    continue;
                }
                String fieldName = jReader.getCurrentFieldName();
                switch(fieldName) {
                case "validFrom":
                    hRefBean.setStartDate(DateUtil.formatDate(value, true));
                    break;
                case "validTo":
                    hRefBean.setEndDate(DateUtil.formatDate(value, true));
                    break;
                case "version":
                    hRefBean.setVersion(value);
                    break;
                case "code":
                    hRefBean.setCodeReference(new StructureReferenceBeanImpl(value));
                    break;
                case "codeID":
                    codeId = value;
                    break;
                case "codelistAliasRef":
                    codelistAlias  = value.toUpperCase();
                    break;
                case "hierarchicalCodes":
                    hRefBean.setCodeRefs(readHrefBeans(jReader));
                    break;
                case "level":
                    StructureReferenceBean levelRef = StructureReferenceBeanImpl.buildAndVerify(value, SDMX_STRUCTURE_TYPE.LEVEL);
                    String fullLevelIdWithHierarchy = levelRef.getFullId();
                    hRefBean.setLevelReference(fullLevelIdWithHierarchy.substring(fullLevelIdWithHierarchy.indexOf(".")+1));
                    break;
                }
            }
            if(hRefBean.getCodeReference() == null && codelistAlias != null && codeId != null) {
                //Placeholder to say it is an alias
                List<StructureReferenceBean> storedRefs = (List<StructureReferenceBean>) ThreadLocalUtil.retrieveFromThread(THREAD_LOCAL_KEY2);
                StructureReferenceBean partialRef = new StructureReferenceBeanImpl(null, codelistAlias, "1.0", SDMX_STRUCTURE_TYPE.CODE, codeId);
                storedRefs.add(partialRef);
                hRefBean.setCodeReference(partialRef);
            }
            retList.add(hRefBean);
        }
        return retList;
    }

    private LevelMutableBean readLevel(JsonReader jReader) {
        LevelMutableBean ret = new LevelMutableBeanImpl();
        while(jReader.moveNext()) {
            if(jReader.isEndObject()) {
                break;
            }
            if(SdmxJsonNameableUtil.processBean(ret, jReader)) {
                continue;
            }
            String fieldName = jReader.getCurrentFieldName();
            switch(fieldName) {
            case "codingFormat":
                TextFormatMutableBean readTextFormat = SdmxJsonRepresentationUtil.readTextFormat(jReader, false);
                ret.setCodingFormat(readTextFormat);
                break;
            case "level":
                LevelMutableBean readLevel = readLevel(jReader);
                ret.setChildLevel(readLevel);
                break;
            }
        }

        return ret;
    }

    private void readIncludedCodes(JsonReader jReader, HierarchicalCodelistMutableBean mutable) {
        Map<String, String> codeAliasToUrn = jReader.readStringMap();
        codeAliasToUrn.forEach((codeAlias, urn) -> {
            CodelistRefMutableBean clRef = new CodelistRefMutableBeanImpl();
            clRef.setAlias(codeAlias.toUpperCase());
            clRef.setCodelistReference(new StructureReferenceBeanImpl(urn));
            mutable.addCodelistRef(clRef);
        });
    }

}

