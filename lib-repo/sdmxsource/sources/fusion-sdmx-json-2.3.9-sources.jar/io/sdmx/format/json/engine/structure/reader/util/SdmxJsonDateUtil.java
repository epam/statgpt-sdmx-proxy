package io.sdmx.format.json.engine.structure.reader.util;

import java.util.Date;

import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonDateUtil {


	public static Date readDate(JsonReader jReader) {
		// This is represented in the JSON as a number so convert the String into a number first
//		long l;
//		try {
//			l = Long.parseLong(jReader.getValueAsString());
//		} catch (NumberFormatException e) {
//			throw new SdmxSemmanticException("Unable to parse the 'startDate' value since it is not a valid integer. Value supplied: " + jReader.getValueAsString());
//		}
//		return new Date(l);
		return DateUtil.formatDate(jReader.getValueAsString(), true);
	}

}
