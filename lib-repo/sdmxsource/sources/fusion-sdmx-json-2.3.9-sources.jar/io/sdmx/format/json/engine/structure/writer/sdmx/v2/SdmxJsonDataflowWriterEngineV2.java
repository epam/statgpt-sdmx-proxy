package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonDataflowWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<DataflowBean> implements IFusionSingleton {
	private static SdmxJsonDataflowWriterEngineV2 INSTANCE;

	public static SdmxJsonDataflowWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataflowWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonDataflowWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.DATAFLOW);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataflowBean aDataflow) throws JsonGenerationException, IOException {
		ICrossReferenceBean<DataStructureBean> dataStructureRef = aDataflow.getDataStructureRef();
		if(dataStructureRef != null) {
			jsonGenerator.writeStringField("structure", dataStructureRef.getReference().getURN());
		}
	}

}
