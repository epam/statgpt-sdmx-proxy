package io.sdmx.format.json.api.manager;

import java.io.OutputStream;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Writes the structure, including all referenced structures
 */
public interface JsonStructureWritingManager {

	/**
	 * Writes all the structures as JSON
	 * @param out
	 */
	void writeStructures(SdmxBeans beans, OutputStream out);
	
	/**
	 * Writes the bean out to the output location in the format specified by the implementation 
	 * @param beans
	 * @param schemaVersion
	 */
	void writeStructure(MaintainableBean bean, OutputStream out);
	
}
