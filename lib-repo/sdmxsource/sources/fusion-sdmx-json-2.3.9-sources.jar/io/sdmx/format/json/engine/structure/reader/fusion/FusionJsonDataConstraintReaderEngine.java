package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.ArrayUtils;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * V3.0 (syntax changed from content constraint)
 */
public class FusionJsonDataConstraintReaderEngine  extends FusionJsonMaintainableBeanReaderEngineImpl<ContentConstraintBean, ContentConstraintMutableBean> implements IFusionSingleton {
	private Set<IMaintainableStructureType<?>> reliesOn;

	private static FusionJsonDataConstraintReaderEngine INSTANCE;

	public static FusionJsonDataConstraintReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataConstraintReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}


	@Override
	protected ContentConstraintMutableBean getMutable() {
		return new ContentConstraintMutableBeanImpl();
	}

	@Override
    public Set<IMaintainableStructureType<?>> getReliesOn() {
        if(reliesOn == null) {
            reliesOn = new HashSet<>();
            reliesOn.add(StructureTypes.getMaintStructureType(DataStructureBean.class));
            reliesOn.add(StructureTypes.getMaintStructureType(DataflowBean.class));
            reliesOn.add(StructureTypes.getMaintStructureType(ProvisionAgreementBean.class));
            reliesOn = Collections.unmodifiableSet(reliesOn);
        }
        return reliesOn;
    }

	@Override
	protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean mutable, JsonReader reader) {
		//This method is not called - the override processMaintainableProperty with beanRetrievalManager prevents this from being called
		return false;
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean constraint, JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
		Map<String, ComponentBean> components = new HashMap<>();
		if (fieldName.equals("attachments")) {
			ConstraintAttachmentMutableBean attach = new ContentConstraintAttachmentMutableBeanImpl();
			for(String attachment : jReader.readStringArray()) {
				StructureReferenceBean sRef = new StructureReferenceBeanImpl(attachment);
				attach.addStructureReference(sRef);
			}
			constraint.setConstraintAttachment(attach);
		} else if(fieldName.equals("includeSeries")) {
			if(constraint.getStructureReferences() != null && constraint.getStructureReferences().size() >0) {
				constraint.setIncludedSeriesKeys(buildSeriesConstraint(jReader, constraint.getStructureReferences().get(0), beanRetrievalManager));
			}
		}  else if(fieldName.equals("excludeSeries")) {
			if(constraint.getStructureReferences() != null && constraint.getStructureReferences().size() >0) {
				constraint.setExcludedSeriesKeys(buildSeriesConstraint(jReader, constraint.getStructureReferences().get(0), beanRetrievalManager));
			}
		} else if(fieldName.equals("includeCube")) {
			constraint.setIncludedCubeRegion(buildCubeRegion(jReader, components));
		} else if(fieldName.equals("excludeCube")) {
			constraint.setExcludedCubeRegion(buildCubeRegion(jReader, components));
		} else if(fieldName.equals("definingDataPresent")) {
			constraint.setIsDefiningActualDataPresent(jReader.getValueAsBoolean());
		} else if(fieldName.equals("releaseCalendar")) {
			constraint.setReleaseCalendar(buildReleaseCalendar(jReader));
		} else {
			return false;
		}
		return true;
	}


	private ReleaseCalendarMutableBean buildReleaseCalendar(JsonReader jReader) {
		ReleaseCalendarMutableBean releaseCalendar = new ReleaseCalendarMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("periodicity")) {
				releaseCalendar.setPeriodicity(value);
			} else if (fieldName.equals("offset")) {
				releaseCalendar.setOffset(value);
			} else if (fieldName.equals("tolerance")) {
				releaseCalendar.setTolerance(value);
			}
		}
		return releaseCalendar;
	}

	/**
	 * "includeSeries": {
        "componentIds": [
          "FREQ",
          "REF_AREA",
          "INDICATOR",
          "COLLECTION",
          "UNIT"
        ],
        "rows": [
          [
            "A",
            "UK",
            "ABC",
            "A",
            "0"
          ]
        ]
      }
	 * @param jReader
	 * @param sRef
	 * @param beanRetrievalManager
	 * @return
	 */
	private ConstraintDataKeySetMutableBean buildSeriesConstraint(JsonReader jReader, StructureReferenceBean sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		ConstraintDataKeySetMutableBean cds = new ConstraintDataKeySetMutableBeanImpl();
		if(sRef == null) {
			return cds;
		}
		List<String[]> rows = new ArrayList<>();
		String[] dims = null;
		String[] comps = null;
			
		Map<Integer, String> rowValidityFromMap = new HashMap<>();
		Map<Integer, String> rowValidityToMap = new HashMap<>();
		while (jReader.moveNext()) {
			if(jReader.isStartObject()) {
				switch(jReader.getCurrentFieldName()) {
				case "validity" :
					processSeriesValidity(jReader, rowValidityFromMap, rowValidityToMap);
					break;
				}
			} else	if(jReader.isStartArray()) {
				switch(jReader.getCurrentFieldName()) {
				case "dims" :
					dims = CollectionUtil.toArray(jReader.readStringArray());
					break;
				case "comps" :
					comps = CollectionUtil.toArray(jReader.readStringArray());
					break;
				case "rows" :
					processConstrainedRows(jReader, rows);
					break;
				}
			} else if(jReader.isEndObject()) {
				break;
			}
		}
		String[] componentIds = ArrayUtils.addAll(dims, comps);
		if(componentIds == null && rows.size() > 0) {
			throw new SdmxSemmanticException("Missing componentIds");
		}
		
		for(int rowIdx=0; rowIdx < rows.size(); rowIdx++) {
			String[] row =  rows.get(rowIdx);
			ConstrainedDataKeyMutableBean key = new ConstrainedDataKeyMutableBeanImpl();
			key.setValidFrom(rowValidityFromMap.get(rowIdx));
			key.setValidTo(rowValidityToMap.get(rowIdx));
			cds.addConstrainedDataKey(key);
			for(int i=0; i < row.length; i++) {
				String codeId = row[i];
				// NPE defence
				if (codeId == null) {
					continue;
				}
				boolean removePrefix = codeId.length() > 0 && codeId.startsWith("~ ");
				if(removePrefix) {
					codeId = codeId.substring(2);
				}
				IConstrainedKeyValue kv = ConstrainedKeyValue.getInstance(componentIds[i], removePrefix, codeId);
				if(codeId != null && !codeId.equals("*")) {
					if(dims != null && dims.length > i) {
						key.addKeyValue(kv);
					} else {
						key.addComponentValues(kv);
					}
				}
			}
		}
		return cds;
	}
	
	private void processConstrainedRows(JsonReader jReader, List<String[]> rows) {
		while (jReader.moveNext()) {
			if(jReader.isStartArray()) {
				rows.add(CollectionUtil.toArray(jReader.readStringArray()));
			} else if(jReader.isEndArray()) {
				break;
			}
		}
	}
	
	private void processSeriesValidity(JsonReader jReader, Map<Integer, String> rowValidityFromMap, Map<Integer, String> rowValidityToMap) {
		while (jReader.moveNext()) {
			if(jReader.isStartObject()) {
				Integer rowIdx = Integer.parseInt(jReader.getCurrentFieldName());
				List<String> validity = jReader.readStringArray();
				String validFrom = validity.size() > 0 ? validity.get(0) : null;
				String validTo = validity.size() > 1 ? validity.get(1) : null;
				
				rowValidityFromMap.put(rowIdx, validFrom);
				rowValidityToMap.put(rowIdx, validTo);
			} else if(jReader.isEndObject()) {
				break;
			}
		}
	}

	private CubeRegionMutableBean buildCubeRegion(JsonReader jReader, Map<String, ComponentBean> componentsd) {
		CubeRegionMutableBean cube = new CubeRegionMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String componentId = jReader.getCurrentFieldName();
			KeyValuesMutable kvs = new KeyValuesMutableImpl();
			kvs.setId(componentId);
			while (jReader.moveNext()) {
				if(jReader.isStartObject()) {
					switch(jReader.getCurrentFieldName()) {
					case "validity" :
						processCubeValidity(jReader, kvs);
						break;
					}
				} else	if(jReader.isStartArray()) {
					switch(jReader.getCurrentFieldName()) {
					case "values" :
						kvs.setKeyValues(jReader.readStringArray());
						break;
					case "cascade" :
						kvs.setCascade(jReader.readStringArray());
						break;
					}
				} else if(jReader.isEndObject()) {
					break;
				} else {
					switch(jReader.getCurrentFieldName()) {
					case "removePrefix" :
						kvs.setRemovePrefix(jReader.getValueAsBoolean());
						break;
					}
				}
			}

			ComponentBean comp = componentsd.get(componentId);
			if(comp == null) {
				//This is true in the case where the attachement could not be found
				cube.addKeyValues(kvs);
			} else {
				if(comp.getStructureType() == SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
					cube.addAttributeValue(kvs);
				} else {
					cube.addKeyValues(kvs);
				}
			}
		}
		return cube;
	}

	private void processCubeValidity(JsonReader jReader, KeyValuesMutable kvs) {
		while (jReader.moveNext()) {
			if(jReader.isStartArray()) {
				String codeId = jReader.getCurrentFieldName();
				List<String> validity = jReader.readStringArray();
				String validFrom = validity.size() > 0 ? validity.get(0) : null;
				String validTo = validity.size() > 1 ? validity.get(1) : null;
				kvs.setValidity(codeId, validFrom, validTo);
			} else if(jReader.isEndObject()) {
				break;
			}
		}
	}

    @Override
    protected Class<ContentConstraintBean> getMaintainableType() {
        return ContentConstraintBean.class;
    }
}
