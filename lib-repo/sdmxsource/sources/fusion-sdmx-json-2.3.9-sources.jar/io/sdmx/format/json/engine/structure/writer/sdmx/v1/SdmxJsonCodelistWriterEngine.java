package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCodelistWriterEngine extends SdmxJsonItemSchemeWriterEngine<CodeBean, CodelistBean> implements IFusionSingleton {
	private static SdmxJsonCodelistWriterEngine INSTANCE;

	public static SdmxJsonCodelistWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCodelistWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonCodelistWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  CodeBean code) throws JsonGenerationException, IOException {
		if(code.getParentCode() != null) {
			jsonGenerator.writeStringField("parent", code.getParentCode());
		}
	}

	@Override
	protected String getItemName() {
		return "codes";
	}

}
