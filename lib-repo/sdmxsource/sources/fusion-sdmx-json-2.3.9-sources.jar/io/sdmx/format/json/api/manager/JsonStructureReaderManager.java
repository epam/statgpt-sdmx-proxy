package io.sdmx.format.json.api.manager;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Responsible for reading Structures in JSON format
 */
public interface JsonStructureReaderManager {

	/**
	 * Reads JSON and returns {@link SdmxBeans}
	 * @param rdl required
	 * @param beanBuilder optional, if not provided the default behaviour is used
	 * @param beanRetrievalManager
	 * @return
	 */
	SdmxBeans readJson(ReadableDataLocation rdl, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Use the default implementation for reading beans
	 * @param rdl
	 * @param beanRetrievalManager
	 * @return
	 */
	default SdmxBeans readJson(ReadableDataLocation rdl, SdmxBeanRetrievalManager beanRetrievalManager) {
	    return readJson(rdl, (mutable, beans)->beans.addIdentifiable(mutable.getImmutableInstance()), beanRetrievalManager);
	}
}
