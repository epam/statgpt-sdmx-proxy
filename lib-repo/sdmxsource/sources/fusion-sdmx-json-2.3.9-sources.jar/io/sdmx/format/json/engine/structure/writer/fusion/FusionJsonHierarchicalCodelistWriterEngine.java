package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonHierarchicalCodelistWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<HierarchyBean> implements IFusionSingleton {
	private static FusionJsonHierarchicalCodelistWriterEngine INSTANCE;

	public static FusionJsonHierarchicalCodelistWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonHierarchicalCodelistWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private FusionJsonHierarchicalCodelistWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY);
	}

	@Override
	public void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyBean hCodelist) throws JsonGenerationException, IOException {
		writeHierarchies(jsonGenerator, externalLinks, hCodelist);
	}


	private void writeHierarchies(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyBean hierarchyBean) throws JsonGenerationException, IOException {
		if (hierarchyBean != null) {
			jsonGenerator.writeBooleanField("formalLevels", hierarchyBean.hasFormalLevels());
			if (hierarchyBean.getLevel() != null) {
				jsonGenerator.writeArrayFieldStart("levels");
				writeLevel(hierarchyBean.getLevel(), externalLinks, jsonGenerator);
				jsonGenerator.writeEndArray();
			}

			List<HierarchicalCodeBean> hierarchicalCodeBeans = hierarchyBean.getHierarchicalCodeBeans();
			if (ObjectUtil.validCollection(hierarchicalCodeBeans)) {
				writeHierarchicalCodeBeans(jsonGenerator, externalLinks, hierarchicalCodeBeans);
			}
		}
	}

	private void writeLevel(LevelBean level, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		writeNameable(jsonGenerator, externalLinks, level);
		FusionJsonStaticHelper.writeTexFormat(jsonGenerator, level.getCodingFormat());
		jsonGenerator.writeEndObject();
		if(level.getChildLevel() != null) {
			writeLevel(level.getChildLevel(), externalLinks, jsonGenerator);
		}
	}

	private void writeHierarchicalCodeBeans(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<HierarchicalCodeBean> hierarchicalCodeBeans) throws IOException {
		jsonGenerator.writeArrayFieldStart("codes");
		for (HierarchicalCodeBean hierarchicalCodeBean : hierarchicalCodeBeans) {
			jsonGenerator.writeStartObject();
			super.writeIdentifiable(jsonGenerator, externalLinks, hierarchicalCodeBean);
			if(hierarchicalCodeBean.getLevel(false) != null) {
				jsonGenerator.writeStringField("level", hierarchicalCodeBean.getLevel(false).getFullIdPath(false));
			}
			ICrossReferenceBean<CodeBean> codeReference = hierarchicalCodeBean.getCodeReference();
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "code", codeReference.getTargetUrn());
			writeValidityDate(jsonGenerator, "validFrom", hierarchicalCodeBean.getValidFrom());
			writeValidityDate(jsonGenerator, "validTo", hierarchicalCodeBean.getValidTo());
			
			//Child Codes
			List<HierarchicalCodeBean> codeRefs = hierarchicalCodeBean.getCodeRefs();
			if (ObjectUtil.validCollection(codeRefs)) {
				writeHierarchicalCodeBeans(jsonGenerator, externalLinks, codeRefs);
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}


	private void writeValidityDate(JsonGenerator jsonGenerator, String fieldName, SdmxDate aDate) throws IOException {
		if (aDate == null) {
			return;
		} else {
			long startTime = aDate.getDate().getTime();
			jsonGenerator.writeNumberField(fieldName, startTime);
		}
	}
}
