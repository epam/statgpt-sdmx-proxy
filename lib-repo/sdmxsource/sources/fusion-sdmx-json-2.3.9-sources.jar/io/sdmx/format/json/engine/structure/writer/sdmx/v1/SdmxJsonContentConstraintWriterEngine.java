package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonContentConstraintWriterEngine extends SdmxJsonAbstractConstraintWriterEngine<ContentConstraintBean> implements IFusionSingleton {
	private static SdmxJsonContentConstraintWriterEngine INSTANCE;

	public static SdmxJsonContentConstraintWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonContentConstraintWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonContentConstraintWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ContentConstraintBean maint) throws IOException {
		jsonGenerator.writeStringField("type", maint.isDefiningActualDataPresent() ? "actual" : "allowed");
		if (!maint.isExternalReference()) {
            super.writeStructureInternal(jsonGenerator, externalLinks, maint);
            writeCubeRegion(getAsList(maint), jsonGenerator, maint);
            writeMetadataTargetRegion(maint.getMetadataTargetRegion(), jsonGenerator);
            writeReferencePeriod(maint.getReferencePeriod(), jsonGenerator);
            writeReleaseCalendar(maint.getReleaseCalendar(), jsonGenerator);
        }
	}

	private void writeReferencePeriod(ReferencePeriodBean refPeriod, JsonGenerator jsonGenerator) throws IOException {
		if(refPeriod != null) {
			jsonGenerator.writeObjectFieldStart("referencePeriod");
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "endTime", refPeriod.getEndTime().getDateInSdmxFormat());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "startTime", refPeriod.getStartTime().getDateInSdmxFormat());
			jsonGenerator.writeEndObject();
		}
	}


	private void writeReleaseCalendar(ReleaseCalendarBean relCal, JsonGenerator jsonGenerator) throws IOException {
		if(relCal != null) {
			jsonGenerator.writeObjectFieldStart("releaseCalendar");
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "offset", relCal.getOffset());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "periodicity", relCal.getPeriodicity());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "tolerance", relCal.getTolerance());
			jsonGenerator.writeEndObject();
		}
	}


	private void writeMetadataTargetRegion(MetadataTargetRegionBean metadataTargetRegion, JsonGenerator jsonGenerator) throws IOException {
		if(metadataTargetRegion == null) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("metadataTargetRegions");

		jsonGenerator.writeStartObject();
		jsonGenerator.writeBooleanField("include", metadataTargetRegion.isInclude());
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "metadataTarget", metadataTargetRegion.getMetadataTarget());
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "report", metadataTargetRegion.getReport());
		writeKeyValues(metadataTargetRegion.getTargetKeyValues(), jsonGenerator);
		writeKeyValues(metadataTargetRegion.getAttributes(),"attributes", jsonGenerator);
		jsonGenerator.writeEndObject();

		jsonGenerator.writeEndArray();
	}


	private void writeKeyValues(List<MetadataTargetKeyValuesBean> kvsList, JsonGenerator jsonGenerator) throws IOException {
		if(kvsList.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("keyValues");
		for(MetadataTargetKeyValuesBean kvs : kvsList) {
			jsonGenerator.writeStartObject();
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", kvs.getId());

			if(!kvs.getDatasetReferences().isEmpty()) {
				jsonGenerator.writeArrayFieldStart("dataSets");
				for(DataSetReferenceBean dsRef : kvs.getDatasetReferences()) {
					jsonGenerator.writeStartObject();
					SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "dataProvider", dsRef.getDataProviderReference().getTargetUrn());
					SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", dsRef.getDatasetId());
					jsonGenerator.writeEndObject();
				}
				jsonGenerator.writeEndArray();
			}

			if(!kvs.getObjectReferences().isEmpty()) {
				jsonGenerator.writeArrayFieldStart("objects");
				for(ICrossReferenceBean crs: kvs.getObjectReferences()) {
					jsonGenerator.writeString(crs.getTargetUrn());
				}
				jsonGenerator.writeEndArray();
			}

			writeTimeRange(jsonGenerator, kvs.getTimeRange());

			if(!kvs.getValues().isEmpty()) {
				jsonGenerator.writeArrayFieldStart("values");
				for(String value: kvs.getValues()) {
					jsonGenerator.writeString(value);
				}
				jsonGenerator.writeEndArray();
			}

			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}


	private void writeCubeRegion(List<CubeRegionBean> asList, JsonGenerator jsonGenerator, ContentConstraintBean maint) throws IOException {
		if(asList.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("cubeRegions");
		for (CubeRegionBean cubeRegionBean : asList) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeBooleanField("isIncluded", isCubeIncluded(cubeRegionBean, maint));
			writeKeyValues(cubeRegionBean.getKeyValues(), "keyValues", jsonGenerator);
			writeKeyValues(cubeRegionBean.getAttributeValues(), "attributes", jsonGenerator);
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeKeyValues(List<KeyValues> kvsList, String nodeName, JsonGenerator jsonGenerator) throws IOException {
		if(!ObjectUtil.validCollection(kvsList)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(nodeName);
		for(KeyValues kvs : kvsList) {
			writeKeyValues(kvs, jsonGenerator);
		}
		jsonGenerator.writeEndArray();
	}



	private void writeKeyValues(KeyValues kvs, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", kvs.getId());
		writeTimeRange(jsonGenerator, kvs.getTimeRange());
		if(!kvs.getValues().isEmpty()) {
			jsonGenerator.writeArrayFieldStart("values");
			for(String val : kvs.getValues()) {
				jsonGenerator.writeString(val);
			}
			jsonGenerator.writeEndArray();
		}
		if(!kvs.getCascadeValues().isEmpty()) {
			jsonGenerator.writeArrayFieldStart("cascadeValues");
			for(String val : kvs.getCascadeValues()) {
				jsonGenerator.writeString(val);
			}
			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndObject();
	}


	private void writeTimeRange(JsonGenerator jsonGenerator, TimeRangeBean timeRange) throws IOException {
		if(timeRange == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("timeRange");
		SdmxDate startDate = timeRange.getStartDate();
		SdmxDate endDate = timeRange.getEndDate();
		if(timeRange.isRange()) {
			jsonGenerator.writeObjectFieldStart("startPeriod");
			jsonGenerator.writeStringField("period", startDate.getDateInSdmxFormat());
			jsonGenerator.writeBooleanField("isInclusive", timeRange.isStartInclusive());
			jsonGenerator.writeEndObject();

			jsonGenerator.writeObjectFieldStart("endPeriod");
			jsonGenerator.writeStringField("period", endDate.getDateInSdmxFormat());
			jsonGenerator.writeBooleanField("isInclusive", timeRange.isEndInclusive());
			jsonGenerator.writeEndObject();
		}else {
			if(startDate == null) {
				jsonGenerator.writeObjectFieldStart("afterPeriod");
				jsonGenerator.writeStringField("period", endDate.getDateInSdmxFormat());
				jsonGenerator.writeBooleanField("isInclusive", timeRange.isEndInclusive());
				jsonGenerator.writeEndObject();
			}else {
				jsonGenerator.writeObjectFieldStart("beforePeriod");
				jsonGenerator.writeStringField("period", startDate.getDateInSdmxFormat());
				jsonGenerator.writeBooleanField("isInclusive", timeRange.isStartInclusive());
				jsonGenerator.writeEndObject();
			}
		}
		jsonGenerator.writeEndObject();
	}


	private List<CubeRegionBean> getAsList(ContentConstraintBean maint){
		List<CubeRegionBean> retList =  new ArrayList<>();
		CubeRegionBean includeCube = maint.getIncludedCubeRegion();
		CubeRegionBean excludeCube = maint.getExcludedCubeRegion();
		if(includeCube != null) {
			retList.add(includeCube);
		}

		if(excludeCube != null) {
			retList.add(excludeCube);
		}
		return retList;
	}

	private boolean isCubeIncluded(CubeRegionBean cube, ContentConstraintBean maint) {
		if(cube == maint.getIncludedCubeRegion()) {
			return true;
		}
		if(cube == maint.getExcludedCubeRegion()) {
			return false;
		}
		throw new RuntimeException("Unable to parse CubeRegion");
	}
}
