package io.sdmx.format.json.manager;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonAgencySchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonCategorisationReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonCategorySchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonCodelistReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonConceptSchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonContentConstraintReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonDataConsumerSchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonDataProviderSchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonDataStructureReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonDataflowReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonHierarchicalCodelistReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonMetadataStructureReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonMetadataflowReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonOrganisationUnitSchemeReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonProvisionAgreementReaderEngineV1;
import io.sdmx.format.json.engine.structure.reader.sdmx.v1.SdmxJsonStructureSetReaderEngineV1;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonStructureReaderManagerV1 extends AbstractJsonStructureReaderManager implements IFusionSingleton {
	private static SdmxJsonStructureReaderManagerV1 INSTANCE;

	public static SdmxJsonStructureReaderManagerV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureReaderManagerV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static void registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
	}

	private  SdmxJsonStructureReaderManagerV1() {
		registerReader(SdmxJsonAgencySchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonCategorisationReaderEngineV1.getInstance());
		registerReader(SdmxJsonCategorySchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonCodelistReaderEngineV1.getInstance());
		registerReader(SdmxJsonConceptSchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonContentConstraintReaderEngineV1.getInstance());
		registerReader(SdmxJsonDataConsumerSchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonDataflowReaderEngineV1.getInstance());
		registerReader(SdmxJsonDataProviderSchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonDataStructureReaderEngineV1.getInstance());
		registerReader(SdmxJsonHierarchicalCodelistReaderEngineV1.getInstance());
		registerReader(SdmxJsonMetadataflowReaderEngineV1.getInstance());
		registerReader(SdmxJsonMetadataStructureReaderEngineV1.getInstance());
		registerReader(SdmxJsonOrganisationUnitSchemeReaderEngineV1.getInstance());
		registerReader(SdmxJsonProvisionAgreementReaderEngineV1.getInstance());
		registerReader(SdmxJsonStructureSetReaderEngineV1.getInstance());
	}

	@Override
	protected boolean skipToData(JsonReader jReader, SdmxBeans sdmxBeans) {
		outer:
			while (jReader.moveNextStartObject()) {
				while(jReader.moveNext()) {
					String currentFieldName = jReader.getCurrentFieldName();
					switch(currentFieldName) {
					case "meta":
						readMetaInfo(jReader, sdmxBeans);
						break;
					case "errors":
						// process error info
						continue outer;
					case "data":
						jReader.moveNextStartArray();
						return true;
					}
				}
			}
	return false;
	}
}
