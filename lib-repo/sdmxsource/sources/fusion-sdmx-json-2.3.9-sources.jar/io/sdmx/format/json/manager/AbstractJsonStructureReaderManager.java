package io.sdmx.format.json.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.MultipleBeanRetrievalManager;
import io.sdmx.format.json.api.engine.JsonMaintainableBeanReaderEngine;
import io.sdmx.format.json.api.manager.JsonStructureReaderManager;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonContactUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.beans.base.ContactBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;

public abstract class AbstractJsonStructureReaderManager implements JsonStructureReaderManager {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractJsonStructureReaderManager.class);
	private Map<String, JsonMaintainableBeanReaderEngine> readers = new HashMap<>();

	/**
	 * Register a reader capable of processing JSON to the given format with the manager
	 * @param reader
	 */
	public void registerReader(JsonMaintainableBeanReaderEngine reader) {
		readers.put(reader.getContainerElement().toLowerCase(), reader);
	}

	@Override
	public SdmxBeans readJson(ReadableDataLocation rdl, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
	    if(beanBuilder == null) {
	        beanBuilder = (mutable, beans)->beans.addIdentifiable(mutable.getImmutableInstance());
	    }
		try(JsonReader jReader = new JsonReader(rdl);) {
			SdmxBeans sdmxBeans = new SdmxBeansImpl();
			jReader.reset();

			Map<String, JsonMaintainableBeanReaderEngine> toProcess = new HashMap<>();
			Set<IMaintainableStructureType<?>> processedTypes = new HashSet<>();

			SdmxBeanRetrievalManager wrappedRetrievalManager = beanRetrievalManager;
			if(!skipToData(jReader, sdmxBeans)) {
				// throw error
			}
			do{
				String fieldName = jReader.getCurrentFieldName();
				JsonMaintainableBeanReaderEngine reader = readers.get(fieldName.toLowerCase());
				if(reader == null) {
					LOG.warn("JSON structure reader, skipping unsupported structure: "+fieldName);
					jReader.moveToEndArray();
					continue;
				}
				Set<IMaintainableStructureType<?>> reliesOn = reader.getReliesOn();
				if(!reliesOn.isEmpty()) {
					if(!processedTypes.containsAll(reliesOn)) {
						toProcess.put(fieldName, reader);
						jReader.moveToEndArray();
						continue;
					}
				}
				reader.read(jReader, sdmxBeans, beanBuilder, wrappedRetrievalManager);
				processedTypes.add(reader.getBuiltType());
				InMemoryRetrievalManager localRetrievalManager = new InMemoryRetrievalManager(sdmxBeans);
				wrappedRetrievalManager = new MultipleBeanRetrievalManager(localRetrievalManager, beanRetrievalManager);
			}while(jReader.moveNextStartArray());
			//If the maintainable type was not part of the submission, then just add it as a type that was processed
			for(IMaintainableStructureType<?> maintainableType : StructureTypes.getMaintStructureTypes()) {
				if(!processedTypes.contains(maintainableType) && !toProcess.containsKey(maintainableType)) {
					processedTypes.add(maintainableType);
				}
			}
			while(!toProcess.isEmpty()) {
				jReader.reset();
				if(!skipToData(jReader, sdmxBeans)) {
					// throw error
				}
				do{
					String fieldName = jReader.getCurrentFieldName();
					JsonMaintainableBeanReaderEngine reader = toProcess.get(fieldName);
					if(reader != null && toProcess.containsKey(fieldName)) {
						if(!processedTypes.containsAll(reader.getReliesOn())) {
							jReader.moveToEndArray();
							continue;
						}
						reader.read(jReader, sdmxBeans, beanBuilder, wrappedRetrievalManager);
						processedTypes.add(reader.getBuiltType());
						toProcess.remove(fieldName);
						if(toProcess.isEmpty()) {
							break;
						}
					}else {
						jReader.moveToEndArray();
					}
				}while(jReader.moveNextStartArray());
			}
			return sdmxBeans;
		}
	}
	

	protected void readMetaInfo(JsonReader jReader, SdmxBeans sdmxBeans) {
		HeaderBean header =  new HeaderBeanImpl("Registry");
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String key = jReader.getCurrentFieldName();
			switch(key) {
			case "id":
				String id = jReader.getValueAsString();
				header.setId(id);
				break;
			case "test":
				boolean test = jReader.getValueAsBoolean();
				header.setTest(test);
				break;
			case "names":
				List<TextTypeWrapperMutableBean> names = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);

				for (TextTypeWrapperMutableBean nameMut : names) {
					TextTypeWrapper ttw = new TextTypeWrapperImpl(nameMut, "names", null);
					header.addName(ttw);
				}
				break;
			case "sender":
				PartyBean sender =  readParty(jReader);
				if(sender != null) {
					header.setSender(sender);
				}
				break;
			case "receivers":
				while (jReader.moveNext()) {
					if (jReader.isEndArray()) {
						break;
					}
					PartyBean pBean = readParty(jReader);
					if(pBean != null) {
						header.addReceiver(pBean);
					}
				}
				break;
			}
		}
		sdmxBeans.setHeader(header);
	}

	private List<TextTypeWrapper> convertTTwToImutable(List<TextTypeWrapperMutableBean> names, String prop){
		List<TextTypeWrapper> ret = new ArrayList<>();
		for (TextTypeWrapperMutableBean mut : names) {
			ret.add(new TextTypeWrapperImpl(mut, prop, null));
		}
		return ret;
	}

	private PartyBean readParty(JsonReader jReader) {
		class PartyWrapper {
			public List<TextTypeWrapper> names;
			public String id;
			public List<ContactBean> contacts;
		}
		PartyWrapper pWrapper = null;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			pWrapper = new PartyWrapper();
			String key = jReader.getCurrentFieldName();
			switch(key) {
			case "id":
				String id = jReader.getValueAsString();
				pWrapper.id = id;
				break;
			case "names":
				List<TextTypeWrapperMutableBean> names = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
				pWrapper.names = convertTTwToImutable(names, "names");
				break;
			case "contacts":
				List<ContactMutableBean> contactImut = SdmxJsonContactUtil.readContacts(jReader);
				List<ContactBean> contacts = contactImut.stream().map(ContactBeanImpl::new).collect(Collectors.toList());
				pWrapper.contacts = contacts;
				break;
			}
		}
		if(pWrapper != null) {
			return new PartyBeanImpl(pWrapper.names, pWrapper.id, pWrapper.contacts, null);
		}
		return null;
	}
	
	/**
	 * move to the Json Structure array
	 * @param rdl
	 * @return
	 */
	protected abstract boolean skipToData(JsonReader jReader, SdmxBeans sdmxBeans);
}
