package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.constant.JSON_SCHEMA;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;

public abstract class SdmxJsonIdentifiableStructureWriterEngine<T extends IdentifiableBean> {
	
	protected abstract void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,T identifiable) throws JsonGenerationException, IOException;
	
	protected void writeIdentifiable(JsonGenerator jsonGenerator, IdentifiableBean identifiable, IExternalMaintainableLinks externalLinks) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.writeIdentifiable(jsonGenerator, externalLinks, identifiable, JSON_SCHEMA.STRUCTURE_V1);
	}

	protected void writeComponent(ComponentBean componentBean, JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks) throws JsonGenerationException, IOException {
		writeIdentifiable(jsonGenerator, componentBean, externalLinks);
		if(componentBean.getRepresentation() != null) {
			SdmxJsonStaticHelper.writeRepresentation(jsonGenerator, componentBean.getRepresentation(), false, "localRepresentation");
		}
		if(componentBean.getConceptRef() != null) {
			jsonGenerator.writeStringField("conceptIdentity", componentBean.getConceptRef().getTargetUrn());
		}
	}
	
}
