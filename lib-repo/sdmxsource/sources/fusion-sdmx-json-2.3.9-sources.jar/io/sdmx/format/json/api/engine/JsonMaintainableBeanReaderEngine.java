package io.sdmx.format.json.api.engine;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.utils.json.JsonReader;

/**
 * Base interface for both new and custom JSON formats
 *
 * @param <T>
 */
public interface JsonMaintainableBeanReaderEngine {

	/**
	 * Builds a maintainable bean from a JsonReader
	 * @param reader
	 * @param beanBuilder required to build the immutable from the mutable
	 * @return the maintainable bean
	 */
    void read(JsonReader reader, SdmxBeans beans, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager);

    /**
     * @return the container 'root' element in the JSON message which contains these structures
     */
    String getContainerElement();
    
    /**
     * @return the type of structure this reader builds
     */
    IMaintainableStructureType<?> getBuiltType();
    
    /**
     * If the construction of this maintainable type relies on other maintainable types being constructed first, then this returns a set of
     * structure types this relies on.  Will return any empty Set if there is no reliance on other types.
     * @return
     */
    default Set<IMaintainableStructureType<?>> getReliesOn(){
        return Collections.emptySet();
    }
}
