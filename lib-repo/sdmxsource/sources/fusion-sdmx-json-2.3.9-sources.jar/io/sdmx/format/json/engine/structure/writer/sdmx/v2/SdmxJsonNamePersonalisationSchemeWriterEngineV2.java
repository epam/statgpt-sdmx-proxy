package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonNamePersonalisationSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<INamePersonalisationBean, INamePersonalisationSchemeBean> implements IFusionSingleton {
	private static SdmxJsonNamePersonalisationSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonNamePersonalisationSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonNamePersonalisationSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonNamePersonalisationSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME);
	}

	
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, INamePersonalisationSchemeBean maint) throws JsonGenerationException, IOException {
		if(maint.getVtlVersion() != null) {
			jsonGenerator.writeStringField("vtlVersion", maint.getVtlVersion());
		}
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, INamePersonalisationBean item) throws JsonGenerationException, IOException {
		if(item.getVtlDefaultName() != null) {
			jsonGenerator.writeStringField("vtlDefaultName", item.getVtlDefaultName());
		}
		if(item.getPersonalisedName() != null) {
			jsonGenerator.writeStringField("personalisedName", item.getPersonalisedName());
		}
		if(item.getVtlArtefact() != null) {
			jsonGenerator.writeStringField("vtlArtefact", item.getVtlArtefact());
		}
	}

	@Override
	protected String getItemName() {
		return "namePersonalisations";
	}
	
}
