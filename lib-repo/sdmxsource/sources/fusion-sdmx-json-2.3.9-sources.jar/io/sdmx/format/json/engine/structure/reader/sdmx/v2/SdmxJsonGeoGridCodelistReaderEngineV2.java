package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.codelist.GeoGridCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodelistMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonGeoGridCodelistReaderEngineV2 extends SdmxJsonItemSchemeReaderEngineV2<CodeMutableBean, IGeoGridCodelistMutableBean> implements IFusionSingleton {
	private static SdmxJsonGeoGridCodelistReaderEngineV2 INSTANCE;

	public static SdmxJsonGeoGridCodelistReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonGeoGridCodelistReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}


    @Override
    public String getContainerElement() {
        return "geoGridCodelists";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return CodelistBean.class;
    }

    @Override
    protected IGeoGridCodelistMutableBean getMutable() {
        return new GeoGridCodelistMutableBean();
    }
    
    @Override
    protected boolean processMaintainableProperty(String fieldName, IGeoGridCodelistMutableBean mutable, JsonReader reader) {
        if(fieldName.equals("gridDefinition")) {
            mutable.setGridDefinition(reader.getValueAsString());
            return true;
        }
        return super.processMaintainableProperty(fieldName, mutable, reader);
    }

	private CodeMutableBean readCodeBean(JsonReader jReader) {
		IGeoGridCodeMutableBean aCode = new GeoGridCodeMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(aCode, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parent")) {
				aCode.setParentCode(value);
			} else if (fieldName.equals("geoCell")) {
				aCode.setGeoCell(value);
			}
		}
		return aCode;
	}

	@Override
	protected List<CodeMutableBean> readItems(JsonReader jReader) {
		List<CodeMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				CodeMutableBean aCode = readCodeBean(jReader);
				returnList.add(aCode);
			}
		}
		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "geoGridCodes";
	}
}
