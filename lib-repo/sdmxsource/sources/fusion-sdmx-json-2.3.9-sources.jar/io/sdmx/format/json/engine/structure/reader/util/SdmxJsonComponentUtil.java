package io.sdmx.format.json.engine.structure.reader.util;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonComponentUtil {

	public static boolean processBean(ComponentMutableBean bean, JsonReader jReader, boolean isJsonVersion2) {
		String fieldName = jReader.getCurrentFieldName();
		if(SdmxJsonIdentifiableUtil.processBean(bean, jReader)) {
			return true;
		}
		
		if (fieldName.equals("usage")) {
			String value = jReader.getValueAsString().toLowerCase();
			if (!value.equals("optional") && !value.equals("mandatory")) {
				throw new RuntimeException("'usage' has illegal value of:" +value);
			}
			bean.setMandatory(!value.equals("optional"));
		} else if (fieldName.equals("localRepresentation")) {
			RepresentationMutableBean representation = bean.getRepresentation();
			if(representation == null) {
				representation = new RepresentationMutableBeanImpl();
				bean.setRepresentation(representation);
			}
			SdmxJsonRepresentationUtil.readRepresentation(representation, jReader, isJsonVersion2);
			return true;
		} else if (fieldName.equals("conceptIdentity")) {
			StructureReferenceBean conceptRef = new StructureReferenceBeanImpl(jReader.getValueAsString());
			bean.setConceptRef(conceptRef);
			return true;
		}
		return false;
	}
}
