package io.sdmx.format.json.factory.structure;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.StructureWriterFactory;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.format.json.engine.structure.writer.fusion.FusionJsonStructureWriterEngine;
import io.sdmx.format.json.model.FusionJsonStructureFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FusionJsonStructureWriterFactory implements StructureWriterFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(FusionJsonStructureWriterFactory.class);

	private static FusionJsonStructureWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	public static FusionJsonStructureWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static FusionJsonStructureWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private FusionJsonStructureWriterFactory() {}

	@Override
	public StructureWriterEngine getStructureWriterEngine(StructureFormat outputFormat) {
		if(outputFormat instanceof FusionJsonStructureFormat) {
			LOG.debug("Creating an FusionJsonStructureWriterEngine");
			return FusionJsonStructureWriterEngine.getInstance();
		}
		return null;
	}

	@Override
	public Integer getPriority() {
		return 1;
	}
}