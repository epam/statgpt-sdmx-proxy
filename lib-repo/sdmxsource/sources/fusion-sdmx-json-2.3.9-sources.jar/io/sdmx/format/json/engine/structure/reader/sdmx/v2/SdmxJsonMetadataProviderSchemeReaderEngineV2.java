package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.MetadataProviderMutableBean;
import io.sdmx.im.mutable.base.MetadataProviderSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonMetadataProviderSchemeReaderEngineV2 extends SdmxJsonOrganisationSchemeReaderEngineV2<IMetadataProviderMutableBean, IMetadataProviderSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonMetadataProviderSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonMetadataProviderSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataProviderSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    protected String getItemLabel() {
        return "metadataProviders";
    }

    @Override
    public String getContainerElement() {
        return "metadataProviderSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IMetadataProviderSchemeBean.class;
    }

    @Override
    protected IMetadataProviderSchemeMutableBean getMutable() {
        return new MetadataProviderSchemeMutableBean();
    }

	@Override
	protected List<IMetadataProviderMutableBean> readItems(JsonReader jReader) {
		List<IMetadataProviderMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				MetadataProviderMutableBean aDP = new MetadataProviderMutableBean();
				super.populateOrganisationMutableBean(jReader, aDP);
				returnList.add(aDP);
			}
		}
		return returnList;
	}
}
