package io.sdmx.format.json.model;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonStructureFormat implements StructureFormat, IFusionSingleton {

	private static final long serialVersionUID = 134354623553456L;
	private FormatDetails formatDetails;
	private SDMXJSON_VERSION version;

	private static SdmxJsonStructureFormat V1_INSTANCE;
	private static SdmxJsonStructureFormat V2_INSTANCE;


	public SdmxJsonStructureFormat(SDMXJSON_VERSION version, FormatDetails formatDetails) {
		this.version = version;
		this.formatDetails = formatDetails;
	}

	public static SdmxJsonStructureFormat getInstance(SDMXJSON_VERSION version) {
		if(version == null) {
			version = SDMXJSON_VERSION.V2;
		}
		switch(version) {
		case V1 :
			if(V1_INSTANCE == null) {
				V1_INSTANCE = new SdmxJsonStructureFormat(version, new FormatDetailsImpl("sdmx-json v1.0.0", MIME_TYPE.APPLICATION_JSON, false, "application/vnd.sdmx.structure+json;version=1.0.0"));
	            FusionBeanStore.registerInstance(V1_INSTANCE);
	        }
			return V1_INSTANCE;
		case V2 :
			if(V2_INSTANCE == null) {
				V2_INSTANCE = new SdmxJsonStructureFormat(version, new FormatDetailsImpl("sdmx-json v2.0.0", MIME_TYPE.APPLICATION_JSON, false, "application/vnd.sdmx.structure+json;version=2.0.0"));
	            FusionBeanStore.registerInstance(V2_INSTANCE);
	        }
			return V2_INSTANCE;
		}
        return null;
    }

    @Override
    public void destroyInstance() {
    	V1_INSTANCE = null;
    	V2_INSTANCE = null;
    }

	public SDMXJSON_VERSION getVersion() {
		return version;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	@Override
	public STRUCTURE_OUTPUT_FORMAT getSdmxOutputFormat() {
		return STRUCTURE_OUTPUT_FORMAT.JSON;
	}

	@Override
	public String getWebServiceFormat() {
		switch(version) {
		case V1 :
			return "sdmx-json&version=1.0.0";
		case V2 :
			return "sdmx-json&version=2.0.0";
		}
		throw new IllegalArgumentException("Unknown version: '" + version + "'");
	}

	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxJsonStructureFormat) {
			SdmxJsonStructureFormat that = (SdmxJsonStructureFormat)obj;
			return  formatDetails.getAcceptHeaders()[0].equals(that.getFormatDetails().getAcceptHeaders()[0]) && ObjectUtil.equivalent(that.getVersion(), this.getVersion());
		}
		return false;
	}

	@Override
	public String toString() {
		return formatDetails.getAcceptHeaders()[0];
	}
}
