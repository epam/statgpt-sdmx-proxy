package io.sdmx.format.json.engine.data.writer.fusionjson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Used for writing Cross-Sectional and Time-Series JSON
 */
public class SeriesDataWriter extends AbstractJsonDataWriter {
	private static final Logger LOG = LoggerFactory.getLogger(SeriesDataWriter.class);
	private boolean hasObs = false;


	public SeriesDataWriter(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(jsonGenerator, header, superBeanRetrievalManager);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... ann) {
		super.startDataset(structures, datasetHeader, datasetAttributes, ann);
		hasObs = false;
	}

	@Override
	public void writeHeader(HeaderBean header) {}

	// Write: root -> dataSets
	@Override
	protected void writeJsonDataSet(DatasetHeaderBean datasetHeader, AnnotationBean... ann) {
		try {
			super.writeJsonDataSet(datasetHeader, ann);
			// Non-flat now needs the series tag
			LOG.debug("{series}");
			jsonGenerator.writeObjectFieldStart("series");
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}

	@Override
	public void writeKey(Keyable key) {
		if(key.isSeries()) {
			super.writeKey(key);
			try {
				if(prevKey != null) {
					LOG.debug("{/}");
					jsonGenerator.writeEndObject();  // End current object
				}
				if (hasObs) {
					LOG.debug("{/observations}");
					jsonGenerator.writeEndObject();  // End Observations
				}
				LOG.debug("{series}");
				jsonGenerator.writeObjectFieldStart("" + currentKey);   // Start Series
				hasObs = false;
			
				LOG.debug("[attributes]");
				jsonGenerator.writeArrayFieldStart("attributes");
				
				String crossSectionalConcept = currentDatasetInfo.getCurrentDSDSuperBean().getTimeDimension() == null ? null : currentDatasetInfo.getCurrentDSDSuperBean().getTimeDimension().getId();
				List<AttributeBean> attr = currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getSeriesAttributes(crossSectionalConcept);
				attr.addAll(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getGroupAttributes());
				writeAttributes(attr, key.getAttributes());
				
				LOG.debug("[/attributes]");
				jsonGenerator.writeEndArray();
			} catch (Throwable th) {
				throw new RuntimeException(th);
			}
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		super.writeObservation(obs);
		hasObs = true;
		writeJsonObs(currentKey, prevKey, obs);
		prevKey = currentKey;
	}

	private void writeJsonObs(String currentKey, String prevKey, Observation obs) {
		int idx = currentDatasetInfo.getReportedIndex(obs.getDimensionId(), obs.getDimensionValue());

		if (currentKey.equals(prevKey)) {
			writeJsonObs(obs, idx);
		} else {
			try {
				prevKey = currentKey;

				List<AnnotationBean> annotations = obs.getSeriesKey().getAnnotations();
				if(ObjectUtil.validCollection(annotations)) {
					LOG.debug("[annotations]");
					jsonGenerator.writeArrayFieldStart("annotations");
					// Write the annotation values
					for(AnnotationBean currentAnnotation : obs.getSeriesKey().getAnnotations()) {
						if (!super.annotations.contains(currentAnnotation)) {
							super.annotations.add(currentAnnotation);
						}
						int index = annotations.indexOf(currentAnnotation);
						jsonGenerator.writeNumber(index);
					}
					LOG.debug("[/annotations]");
					jsonGenerator.writeEndArray();
				}

				LOG.debug("{observations}");
				jsonGenerator.writeObjectFieldStart("observations");

				writeJsonObs(obs, idx);
			} catch (Throwable th) {
				throw new RuntimeException(th);
			}
		}
	}
	
	protected void writeJsonObs(Observation obs, int idx) {
		String seriesKey = "" + idx;
		try {
			LOG.debug("[obs key: '"+seriesKey+"']");
			jsonGenerator.writeArrayFieldStart(seriesKey);

			// Write the observation value as the first array field
			//jsonGenerator.writeString(obs.getPrimaryMeasure().getCode());
			jsonGenerator.writeString(obs.getMeasureCode(PrimaryMeasureBean.FIXED_ID));

			// Write the attribute values
			List<Integer> obsAttrs = new ArrayList<>();
			List<AttributeBean> attr = currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getObservationAttributes(dimensionAtObservation);
			for(AttributeBean currentAttr : attr) {
				KeyValue kv = obs.getAttribute(currentAttr.getId());
				if(kv == null) {
					kv = obs.getSeriesKey().getAttribute(currentAttr.getId());
				}
				String attrValue = kv != null ? kv.getCode() : null;
				if(attrValue == null) {
					obsAttrs.add(null);
				} else {
					int index = currentDatasetInfo.getReportedIndex(currentAttr.getId(), attrValue);
					obsAttrs.add(index);
				}
			}

			// Only write out the attributes, if they are not all null and there are no annotations following
			if (ObjectUtil.validCollection(obsAttrs)) {
				if (!ObjectUtil.isAllNulls(obsAttrs) || obs.getAnnotations().size() > 0) {
					for (Integer attrIdx: obsAttrs) {
						if(attrIdx == null) {
							jsonGenerator.writeNull();
						} else {
							jsonGenerator.writeNumber(attrIdx);
						}
					}
				}
			}

			for(AnnotationBean currentAnnotation : obs.getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int index = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(index);
			}
			LOG.debug("[/'variable series key']");
			jsonGenerator.writeEndArray();
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}

	@Override
	public void close(FooterMessage... footer) {
		try {
			LOG.debug("{/0:0:0:0:0:0:}");
			jsonGenerator.writeEndObject();  // End the current series object
			if(hasObs) {
				LOG.debug("{/observations}");
				jsonGenerator.writeEndObject();  // End the current Observation object
			}

			LOG.debug("{/series}");
			jsonGenerator.writeEndObject();  // End the current series object

			writeDatasetAttributes();
			LOG.debug("{/}");

			// FR-1369 and FR-1530: Depending on what is being written it is possible that we are still inside the DataSet object
			// Attempt to close this, but if it fails (due to not being in this location in JSON writing), simply ignore the exception
			try {
				jsonGenerator.writeEndObject();  // End the dataset tag
				LOG.debug("[/dataSets]");
			} catch (Exception e) {
				// Ignore the exception
			}
			jsonGenerator.writeEndArray();   // End the dataSets array
			writeStructure(true);
		} catch(IOException e) {
			//throw new IllegalArgumentException(e);
		} finally {
			try {
				jsonGenerator.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	// Write: root -> structure -> dimensions -> series
	@Override
	protected void writeDimensionsSeries() throws JsonGenerationException, IOException {
		LOG.debug("[series]");
		jsonGenerator.writeArrayFieldStart("series");

		int i=0;
		DimensionSuperBean timeDimension = null;
		for(DimensionSuperBean dimension : currentDatasetInfo.getCurrentDSDSuperBean().getDimensions()) {
			if (dimension.getId().equals(dimensionAtObservation)) {
				continue;
			}
			if(dimension.getBuiltFrom().isTimeDimension()) {
				// Always write the time dimension at the end
				timeDimension = dimension;
			} else {
				writeComponent(dimension, i);
				i++;
			}
		}

		if (timeDimension != null) {
			writeComponent(timeDimension, i);
		}

		LOG.debug("[/series]");
		jsonGenerator.writeEndArray(); //End series array
	}

	// Write: root -> structure -> dimensions -> observations
	@Override
	protected void writeDimensionsObservation() throws JsonGenerationException, IOException {
		LOG.debug("[observation]");
		jsonGenerator.writeArrayFieldStart("observation");

		DimensionBean dimension = dsd.getDimension(dimensionAtObservation);
		DimensionSuperBean superBean = currentDatasetInfo.getCurrentDSDSuperBean().getDimensionById(dimensionAtObservation);
		// Note that a Dimensions' position is 1 indexed, but we need it 0-indexed, so subtract 1
		writeComponent(superBean, dimension.getPosition()-1);

		LOG.debug("[/observation]");
		jsonGenerator.writeEndArray(); //End observation array
	}

	@Override
	protected void writeAttributes() throws JsonGenerationException, IOException {
		LOG.debug("{attributes}");
		jsonGenerator.writeObjectFieldStart("attributes");

		jsonGenerator.writeArrayFieldStart("dataset");
		for(AttributeBean attribute : dsd.getDatasetAttributes()) {
			ComponentSuperBean attrSb = currentDatasetInfo.getCurrentDSDSuperBean().getComponentById(attribute.getId());
			writeComponent(attrSb, -1);
		}
		jsonGenerator.writeEndArray(); //End dataset array

		jsonGenerator.writeArrayFieldStart("series");

		List<AttributeBean> attr = dsd.getSeriesAttributes(dimensionAtObservation);
		attr.addAll(dsd.getGroupAttributes());
		for(AttributeBean attribute : attr) {
			ComponentSuperBean attrSb = currentDatasetInfo.getCurrentDSDSuperBean().getComponentById(attribute.getId());
			writeComponent(attrSb, -1);
		}
		writeAdditionalAttributes(currentDatasetInfo.getAdditionalSeriesAttributes());
		jsonGenerator.writeEndArray(); //End series array


		LOG.debug("[observation]");
		jsonGenerator.writeArrayFieldStart("observation");
		for(AttributeBean attribute : dsd.getObservationAttributes(dimensionAtObservation)) {
			ComponentSuperBean attrSb = currentDatasetInfo.getCurrentDSDSuperBean().getComponentById(attribute.getId());
			writeComponent(attrSb, -1);
		}
		writeAdditionalAttributes(currentDatasetInfo.getAdditionalObsAttributes());


		LOG.debug("[/observation]");
		jsonGenerator.writeEndArray(); //End observation array

		LOG.debug("{/attributes}");
		jsonGenerator.writeEndObject(); //End attributes
	}
	
	@Override
	protected boolean isSdmxJsonV2() {
		return false;
	}
}
