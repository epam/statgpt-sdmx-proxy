package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonDataStructureWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<DataStructureBean> implements IFusionSingleton {
	private static FusionJsonDataStructureWriterEngine INSTANCE;

	public static FusionJsonDataStructureWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataStructureWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private FusionJsonDataStructureWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DSD);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataStructureBean dsd) throws JsonGenerationException, IOException {
		if(dsd.getMSDRef() != null) {
			jsonGenerator.writeStringField("msd", dsd.getMSDRef().getTargetUrn());
		}
		writeDimensions(dsd, externalLinks, jsonGenerator);
		writeAttributes(dsd, externalLinks, jsonGenerator);
		writeMeasures(dsd, externalLinks, jsonGenerator);

		if (ObjectUtil.validCollection(dsd.getGroups())) {
			jsonGenerator.writeArrayFieldStart("groups");
			for(GroupBean group : dsd.getGroups()) {
				jsonGenerator.writeStartObject(); //Start Group

				jsonGenerator.writeStringField("id", group.getId());
				jsonGenerator.writeArrayFieldStart("dimensionReferences");
				for(String dimensionRef : group.getDimensionRefs()) {
					jsonGenerator.writeString(dimensionRef);
				}

				jsonGenerator.writeEndArray();   //End dimensionReferences
				jsonGenerator.writeEndObject();  //End Group
			}
			jsonGenerator.writeEndArray(); //End Groups
		}
	}

	private void writeDimensions(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart("dimensionList");
		jsonGenerator.writeArrayFieldStart("dimensions");
		DimensionListBean dimensionList = dsd.getDimensionList();
		for(DimensionBean dim : dimensionList.getDimensions()) {
			writeDimension(dim, externalLinks, jsonGenerator);
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	private void writeAttributes(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		if(dsd.getAttributeList() != null) {
			List<AttributeBean> attributeList = dsd.getAttributeList().getAttributes();
			if(ObjectUtil.validCollection(attributeList)) {
				jsonGenerator.writeObjectFieldStart("attributeList");
				jsonGenerator.writeArrayFieldStart("attributes");
				writeListOfAttributes(attributeList, externalLinks, jsonGenerator);
				jsonGenerator.writeEndArray();
				jsonGenerator.writeEndObject();
			}
		}
	}

	private void writeListOfAttributes(List<AttributeBean> attributes, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException, JsonGenerationException {
		for(AttributeBean attr : attributes) {
			jsonGenerator.writeStartObject();  //Start Component
			writeComponent(attr, externalLinks, jsonGenerator);
			jsonGenerator.writeBooleanField("mandatory", attr.isMandatory());
			jsonGenerator.writeStringField("attachmentLevel", 	attr.getAttachmentLevel().toString());
			switch(attr.getAttachmentLevel()) {
			case GROUP :
				jsonGenerator.writeStringField("attachmentGroup", 	attr.getAttachmentGroup());
				break;
			}
			if(ObjectUtil.validCollection(attr.getDimensionReferences())) {
				jsonGenerator.writeArrayFieldStart("dimensionReferences");
				for(String dimRef : attr.getDimensionReferences()) {
					jsonGenerator.writeString(dimRef);
				}
				jsonGenerator.writeEndArray();
			}
			if(ObjectUtil.validCollection(attr.getMeasureReferences())) {
				jsonGenerator.writeArrayFieldStart("measureReferences");
				for(String dimRef : attr.getMeasureReferences()) {
					jsonGenerator.writeString(dimRef);
				}
				jsonGenerator.writeEndArray();
			}
			jsonGenerator.writeEndObject(); //End Component
		}
	}

	private void writeMeasures(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		// "measures" array contains ALL measures EXCEPT primary measure
		jsonGenerator.writeArrayFieldStart("measures");
		for(MeasureDimensionBean measure : dsd.getMeasures()) {
			jsonGenerator.writeStartObject();  //Start Dimension
			writeComponent(measure, externalLinks, jsonGenerator);
			jsonGenerator.writeBooleanField("mandatory", measure.isMandatory());
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeDimension(DimensionBean dimBean, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();  //Start Dimension
		writeComponent(dimBean, externalLinks, jsonGenerator);
		if (dimBean.isTimeDimension()) {
			jsonGenerator.writeBooleanField("isTimeDimension", dimBean.isTimeDimension());
		}
		if (dimBean.isMeasureDimension()) {
			jsonGenerator.writeBooleanField("isMeasureDimension", dimBean.isMeasureDimension());
			if(dimBean.getConceptScheme() != null) {
				jsonGenerator.writeObjectFieldStart("representation");
				jsonGenerator.writeStringField("representation", dimBean.getConceptScheme().getURN());
				jsonGenerator.writeEndObject();
			}
		}
		jsonGenerator.writeEndObject(); // End Dimension
	}
}