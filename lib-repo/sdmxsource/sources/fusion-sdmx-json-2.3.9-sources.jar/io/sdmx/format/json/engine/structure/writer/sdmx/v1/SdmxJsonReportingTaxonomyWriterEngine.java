package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonReportingTaxonomyWriterEngine extends SdmxJsonItemSchemeWriterEngine<ReportingCategoryBean, ReportingTaxonomyBean> implements IFusionSingleton {
	private static SdmxJsonReportingTaxonomyWriterEngine INSTANCE;

	public static SdmxJsonReportingTaxonomyWriterEngine getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonReportingTaxonomyWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonReportingTaxonomyWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ReportingCategoryBean item) throws JsonGenerationException, IOException {
		if (ObjectUtil.validCollection(item.getProvisioningMetadata())) {
			List<ICrossReferenceBean<?>> provisioningMetadata = item.getProvisioningMetadata();
			jsonGenerator.writeArrayFieldStart("provisioningMetadata");
			for (ICrossReferenceBean<?> ref : provisioningMetadata) {
				jsonGenerator.writeString(ref.getTargetUrn());
			}
			jsonGenerator.writeEndArray();
		}

		if (item.hasChildren()) {
			super.writeItems(jsonGenerator, externalLinks, item.getItems());
		}

		if (ObjectUtil.validCollection(item.getStructuralMetadata())) {
			List<ICrossReferenceBean<?>> strucMeta = item.getStructuralMetadata();
			jsonGenerator.writeArrayFieldStart("structuralMetadata");
			for (ICrossReferenceBean<?> ref : strucMeta) {
				jsonGenerator.writeString(ref.getTargetUrn());
			}
			jsonGenerator.writeEndArray();
		}
	}

	@Override
	protected String getItemName() {
		return "reportingCategories";
	}
}
