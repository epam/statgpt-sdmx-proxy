package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.codelist.GeoFeatureSetCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeographicCodelistMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;

public class FusionJsonGeographicCodelistReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<IGeographicCodelistBean, IGeographicCodelistMutableBean, CodeMutableBean> implements IFusionSingleton {
	private static FusionJsonGeographicCodelistReaderEngine INSTANCE;

	public static FusionJsonGeographicCodelistReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonGeographicCodelistReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IGeographicCodelistMutableBean getMutable() {
		return new GeographicCodelistMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IGeographicCodelistMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			String value = jReader.getValueAsString();
			if (fieldName.equals("validityType")){
				mutable.setValidityType(MAINT_VALIDITY_TYPE.getValidityType(value));
			}
			return true;
		}
		return false;
	}

	@Override
    protected CodeMutableBean readItemBean(JsonReader jReader) {
		IGeoFeatureSetCodeMutableBean aCode = new GeoFeatureSetCodeMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(aCode, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parentCode")) {
				aCode.setParentCode(value);
			} else if (fieldName.equals("geoFeatureSet")) {
				aCode.setGeoFeatureSet(value);
			} else if (fieldName.equals("isInherited") && value.equalsIgnoreCase("true")) {
				return null;
			}
		}
		return aCode;
	}

    @Override
    public String getContainerElement() {
        return "GeographicCodelist";
    }

    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(CodelistBean.class);
    }

    @Override
    protected Class<IGeographicCodelistBean> getMaintainableType() {
        return IGeographicCodelistBean.class;
    }
}