package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.List;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCategorySchemeWriterEngine extends SdmxJsonItemSchemeWriterEngine<CategoryBean, CategorySchemeBean> implements IFusionSingleton {
	private static SdmxJsonCategorySchemeWriterEngine INSTANCE;

	public static SdmxJsonCategorySchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorySchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonCategorySchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CategoryBean item) throws JsonGenerationException, IOException {
		writeItems(jsonGenerator, externalLinks, item.getItems());
	}

	@Override
	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<CategoryBean> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(getItemName());
		for(CategoryBean currentItem : items) {
			writeItem(jsonGenerator, externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}

	@Override
	protected String getItemName() {
		return "categories";
	}

}
