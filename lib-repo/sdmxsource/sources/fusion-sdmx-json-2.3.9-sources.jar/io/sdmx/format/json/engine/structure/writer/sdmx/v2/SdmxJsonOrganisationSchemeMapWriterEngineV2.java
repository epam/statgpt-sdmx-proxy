package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonOrganisationSchemeMapWriterEngineV2 extends SdmxJsonItemSchemeMapWriterEngineV2<IOrganisationMapBean, IOrganisationSchemeMapBean> implements IFusionSingleton {
	private static SdmxJsonOrganisationSchemeMapWriterEngineV2 INSTANCE;

	public static SdmxJsonOrganisationSchemeMapWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonOrganisationSchemeMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonOrganisationSchemeMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME_MAP);
	}
}
