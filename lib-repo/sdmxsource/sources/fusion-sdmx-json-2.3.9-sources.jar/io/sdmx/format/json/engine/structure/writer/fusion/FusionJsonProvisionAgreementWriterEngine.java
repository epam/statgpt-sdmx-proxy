package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonProvisionAgreementWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<ProvisionAgreementBean> implements IFusionSingleton {
	private static FusionJsonProvisionAgreementWriterEngine INSTANCE;

	public static FusionJsonProvisionAgreementWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonProvisionAgreementWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonProvisionAgreementWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProvisionAgreementBean aProvisionAgreement) throws JsonGenerationException, IOException {
		ICrossReferenceBean<DataflowBean> structureUseage = aProvisionAgreement.getStructureUseage();
		jsonGenerator.writeStringField("structureUsage", structureUseage.getReference().getURN());

		ICrossReferenceBean<DataProviderBean> dataProviderRef = aProvisionAgreement.getDataproviderRef();
		jsonGenerator.writeStringField("dataproviderRef", dataProviderRef.getReference().getURN());
	}
}
