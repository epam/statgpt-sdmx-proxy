package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.format.json.engine.structure.writer.sdmx.v2.util.SdmxJsonCodelistWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCodelistWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<CodeBean, CodelistBean> implements IFusionSingleton {
	private static SdmxJsonCodelistWriterEngineV2 INSTANCE;

	public static SdmxJsonCodelistWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCodelistWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonCodelistWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}

	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CodelistBean maint) throws JsonGenerationException, IOException {
		SdmxJsonCodelistWriterUtilV2.writeInheritence(jsonGenerator, maint);
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CodeBean code) throws JsonGenerationException, IOException {
		if(code.getParentCode() != null) {
			jsonGenerator.writeStringField("parent", code.getParentCode());
		}
	}

	@Override
	protected String getItemName() {
		return "codes";
	}

}
