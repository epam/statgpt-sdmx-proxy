package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.object.ObjectUtil;

import java.io.IOException;
import java.util.List;

public abstract class SdmxJsonItemSchemeMapWriterEngineV2<R extends IItemMapBean, T extends IItemSchemeMapBean<R>> extends SdmxJsonMaintainableStructureWriterEngineV2<T> {

	public SdmxJsonItemSchemeMapWriterEngineV2(SDMX_STRUCTURE_TYPE supportedType) {
		super(supportedType);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator json, IExternalMaintainableLinks externalLinks, T identifiable) throws JsonGenerationException, IOException {
		List<R> items = identifiable.getItems();

		writeItems(json, items);
		json.writeStringField("source", identifiable.getSourceRef().getTargetUrn());
		json.writeStringField("target", identifiable.getTargetRef().getTargetUrn());
	}

	protected void writeItems(JsonGenerator json, List<R> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}
		json.writeArrayFieldStart("itemMaps");

		for (R currentItem : items) {
			writeItem(json, currentItem);
		}
		json.writeEndArray();
	}

	protected void writeItem(JsonGenerator json, R currentItem) throws JsonGenerationException, IOException {
		json.writeStartObject();
		SdmxJsonStaticHelper.writeAnnotable(json, currentItem);
		writeSourceValue(json, currentItem);

		if (currentItem.getTargetId() != null) {
			json.writeStringField("targetValue", currentItem.getTargetId());
		}
		SdmxPeriod period = currentItem.getValidityPeriod();
		if (period != null && !period.isAllPeriods()) {

			if (period.getStartPeriod() != null) {
				json.writeStringField("validFrom", period.getStartPeriod().getDateInSdmxFormat());
			}
			if (period.getEndPeriod() != null) {
				json.writeStringField("validTo", period.getEndPeriod().getDateInSdmxFormat());
			}
		}
		json.writeEndObject();
	}

	private void writeSourceValue(JsonGenerator json, R currentItem) throws IOException {
		json.writeObjectFieldStart("sourceValue");

		if (currentItem.getSourceId() != null) {
			json.writeStringField("value", currentItem.getSourceId());
		}
		if (currentItem.getSourceStartIdx() > 0) {
			json.writeNumberField("startIndex", currentItem.getSourceStartIdx());
		}
		if (currentItem.getSourceEndIdx() > 0) {
			json.writeNumberField("endIndex", currentItem.getSourceEndIdx());
		}
		json.writeBooleanField("isRegEx", currentItem.isSourceRegEx());

		json.writeEndObject();
	}
}
