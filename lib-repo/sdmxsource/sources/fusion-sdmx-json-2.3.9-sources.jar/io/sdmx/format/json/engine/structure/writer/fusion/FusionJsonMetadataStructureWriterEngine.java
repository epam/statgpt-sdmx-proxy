package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonMetadataStructureWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<MetadataStructureDefinitionBean> implements IFusionSingleton {
	private static FusionJsonMetadataStructureWriterEngine INSTANCE;

	public static FusionJsonMetadataStructureWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataStructureWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonMetadataStructureWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.MSD);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataStructureDefinitionBean msd) throws JsonGenerationException, IOException {
		writeMetadataAttributes(msd.getMetadataAttributes(), externalLinks, jsonGenerator);
	}

	private void writeMetadataAttributes(List<MetadataAttributeBean> mAttributes, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException  {
		if(ObjectUtil.validCollection(mAttributes)) {
			jsonGenerator.writeArrayFieldStart("metadataAttributes");
			for(MetadataAttributeBean currentAtt : mAttributes) {
				writeMetadataAttribute(currentAtt, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeMetadataAttribute(MetadataAttributeBean mAttribute, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException  {
		jsonGenerator.writeStartObject();
		writeComponent(mAttribute, externalLinks, jsonGenerator);
		RepresentationBean rep = mAttribute.getRepresentation();
		if(rep != null) {
			if(rep.getMinOccurs() != null) {
				jsonGenerator.writeNumberField("minOccurs", mAttribute.getMinOccurs());
			}
			if(rep.getMaxOccurs() != null) {
				jsonGenerator.writeNumberField("maxOccurs", mAttribute.getMaxOccurs());
			}
		}
		if(mAttribute.getPresentational() == TERTIARY_BOOL.TRUE) {
			jsonGenerator.writeBooleanField("presentational", mAttribute.getPresentational().isTrue());
		}
		writeMetadataAttributes(mAttribute.getMetadataAttributes(), externalLinks, jsonGenerator);
		jsonGenerator.writeEndObject();
	}


}
