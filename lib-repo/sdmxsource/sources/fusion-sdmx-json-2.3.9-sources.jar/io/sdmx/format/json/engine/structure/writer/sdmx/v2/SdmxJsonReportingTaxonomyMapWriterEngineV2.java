package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonReportingTaxonomyMapWriterEngineV2 extends SdmxJsonItemSchemeMapWriterEngineV2<IReportingCategoryMapBean, IReportingTaxonomyMapBean> implements IFusionSingleton {
	private static SdmxJsonReportingTaxonomyMapWriterEngineV2 INSTANCE;

	public static SdmxJsonReportingTaxonomyMapWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonReportingTaxonomyMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonReportingTaxonomyMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY_MAP);
	}
}
