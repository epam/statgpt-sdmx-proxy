package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;


public class SdmxJsonStructureMapWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<IStructureMapBean> implements IFusionSingleton {
	private static SdmxJsonStructureMapWriterEngineV2 INSTANCE;

	public static SdmxJsonStructureMapWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonStructureMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator writer, IExternalMaintainableLinks externalLinks, IStructureMapBean maint)  throws JsonGenerationException, IOException {
		writer.writeStringField("source", maint.getSourceRef().getTargetUrn());
		writer.writeStringField("target", maint.getTargetRef().getTargetUrn());

		writeEpochMaps(maint.getEpochMap(), writer);
		writeTimePatternMaps(maint.getTimePatternMaps(), writer);
		//TODO Frequency Format Mapping
		writeComponentMaps(maint.getComponentMaps(), writer);


		if(ObjectUtil.validMap(maint.getFixedInputs()) || ObjectUtil.validMap(maint.getFixedOutputs())) {
			writer.writeArrayFieldStart("fixedValueMaps");
			writeFixedValues(maint.getFixedInputs(), "source", writer);
			writeFixedValues(maint.getFixedOutputs(), "target", writer);
			writer.writeEndArray();
		}

	}

	private void writeEpochMaps(List<IEpochMapBean> maps, JsonGenerator writer) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			writer.writeArrayFieldStart("epochMaps");
			for(IEpochMapBean map : maps) {
				writer.writeStartObject();
				writer.writeStringField("basePeriod", map.getBasePeriod().getDateInSdmxFormat());
				writer.writeStringField("epochPeriod", map.getEpochInterval().toString());
				writeAbstractTimePatternMap(map, writer);
				writer.writeEndObject();
			}
			writer.writeEndArray();
		}
	}

	private void writeTimePatternMaps(List<ITimePatternMapBean> maps, JsonGenerator writer) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			writer.writeArrayFieldStart("datePatternMaps");
			for(ITimePatternMapBean map : maps) {
				writer.writeStartObject();
				writer.writeStringField("sourcePattern", map.getPattern());
				writer.writeStringField("locale", map.getLocale());
				writeAbstractTimePatternMap(map, writer);
				writer.writeEndObject();
			}
			writer.writeEndArray();
		}
	}

	private void writeAbstractTimePatternMap(ITimeComponentMapBean map, JsonGenerator writer) throws IOException {
		if(map.getPeriodResolution() != null) {
			String periodResolution = null;
			switch(map.getPeriodResolution()) {
			case END_PERIOD:
				periodResolution = "endOfPeriod";
				break;
			case MID_PERIOD:
				periodResolution = "midPeriod";
				break;
			case START_PERIOD:
				periodResolution = "startOfPeriod";
				break;
			}
			writer.writeStringField("resolvePeriod", periodResolution);
		}
		SdmxJsonStaticHelper.writeAnnotable(writer, map);
		writer.writeArrayFieldStart("mappedComponents");
		writer.writeStartObject();
		writer.writeStringField("source", map.getSourceComponent());
		writer.writeStringField("target", map.getTargetComponent());
		writer.writeEndObject();
		writer.writeEndArray();

		if(map.getOutputFrequencyId() != null) {
			writer.writeStringField("targetFrequencyID", map.getOutputFrequencyId());
		} else if(map.getOutputFrequencyDimId() != null) {
			writer.writeStringField("frequencyDimension", map.getOutputFrequencyDimId());
		}
	}

	private void writeComponentMaps(List<IComponentMapBean> maps, JsonGenerator writer) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			writer.writeArrayFieldStart("componentMaps");
			for(IComponentMapBean map : maps) {
				writer.writeStartObject();
				SdmxJsonStaticHelper.writeAnnotable(writer, map);
				JsonWriterUtil.writeStringArray(writer, "source", map.getSourceComponents());
				JsonWriterUtil.writeStringArray(writer, "target", map.getTargetComponents());
				if(map.getRepresentationMapRef() != null) {
					writer.writeStringField("representationMap", map.getRepresentationMapRef().getTargetUrn());
				}
				writer.writeEndObject();
			}
			writer.writeEndArray();
		}
	}

	private void writeFixedValues(Map<String, String> values, String refLabel, JsonGenerator writer) throws IOException {
		for(String compId : values.keySet()) {
			writer.writeStartObject();
			writer.writeStringField(refLabel, compId);
			JsonWriterUtil.writeStringArray(writer, "values", new String[] {values.get(compId)});
			writer.writeEndObject();
		}
	}

}
