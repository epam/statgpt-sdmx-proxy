package io.sdmx.format.json.engine.structure.writer.sdmx.v1;


import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.engine.structure.writer.sdmx.AbstractSdmxJsonStructureWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;


public class SdmxJsonStructureWriterEngine extends AbstractSdmxJsonStructureWriterEngine {
	private static SdmxJsonStructureWriterEngine INSTANCE;

	public static SdmxJsonStructureWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonStructureWriterEngine() {
		super(false, SDMX_STRUCTURE_TYPE.PUBLICATION_TABLE_DEF, SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE, SDMX_STRUCTURE_TYPE.VALIDATION_SCHEME);
		registerWriter(SdmxJsonAgencySchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonCategorisationWriterEngine.getInstance());
		registerWriter(SdmxJsonCategorySchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonCodelistWriterEngine.getInstance());
		registerWriter(SdmxJsonConceptSchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonContentConstraintWriterEngine.getInstance());
		registerWriter(SdmxJsonDataConsumerSchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonDataflowWriterEngine.getInstance());
		registerWriter(SdmxJsonDataProviderSchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonDataStructureWriterEngine.getInstance());
		registerWriter(SdmxJsonHierarchicalCodelistWriterEngine.getInstance());
		registerWriter(SdmxJsonMetadataflowWriterEngine.getInstance());
		registerWriter(SdmxJsonOrganisationUnitSchemeWriterEngine.getInstance());
		registerWriter(SdmxJsonProvisionAgreementWriterEngine.getInstance());
		registerWriter(SdmxJsonPDQWriterEngine.getInstance());
		registerWriter(SdmxJsonStructureSetWriterEngine.getInstance());
	}

	@Override
	protected String getSchemaLocation() {
		return SDMX_JSON_SCHEMA.STRUCTURE_V1;
	}
	

	@Override
	public boolean isSupportedType(MaintainableBean structure) {
		return super.isSupportedType(structure) && structure.isCompatible(SDMX_SCHEMA.VERSION_TWO_POINT_ONE);
	}
}

