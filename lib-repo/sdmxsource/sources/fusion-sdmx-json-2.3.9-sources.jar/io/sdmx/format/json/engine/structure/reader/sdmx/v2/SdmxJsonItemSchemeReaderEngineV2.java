package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.utils.json.JsonReader;

public abstract class SdmxJsonItemSchemeReaderEngineV2<Y extends ItemMutableBean, F extends ItemSchemeMutableBean<Y>> extends AbstractSdmxJsonReaderEngine<F> {

    
    @Override
    protected boolean processMaintainableProperty(String fieldName, F mutable, JsonReader reader) {
        if (fieldName.equals("isPartial")) {
            String value = reader.getValueAsString();
            if (value.equalsIgnoreCase("true")) {
                mutable.setPartial(true);
            } else if (value.equalsIgnoreCase("false")) {
                mutable.setPartial(false);
            } else {
                throw new SdmxSemmanticException("Illegal value for 'isPartial'. Valid values are 'true' or 'false' but the following value was supplied: " + value);
            }
            return true;
        }
        if (fieldName.equals(getItemLabel())) {
            List<Y> items = readItems(reader);
            for (Y itm : items) {
                mutable.addItem(itm);
            }
            return true;
        }
        return false;
    }
    
	protected abstract List<Y> readItems(JsonReader jReader);
	
	protected abstract String getItemLabel();
}
