package io.sdmx.format.json.manager;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.api.engine.JsonMaintainableBeanReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonAgencySchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonCategorisationReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonCategorySchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonCodelistReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonConceptSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonContentConstraintReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonCustomTypeSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonDataConstraintReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonDataConsumerSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonDataProviderSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonDataStructureReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonDataflowReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonGeoGridCodelistReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonGeographicCodelistReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonHierarchicalCodelistReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonHierarchyAssociationReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonHierarchyReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMetadataProviderSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMetadataProvisionReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMetadataStructureReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMetadataflowReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonNamePersonalisationSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonOrganisationUnitSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonPDQReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonProcessReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonProvisionAgreementReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonRegistrationReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonReportTemplateReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonReportingTaxonomyReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonRepresentationMapReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonRulesetSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonStructureMapReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonStructureSetReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonTransformationSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonUserDefinedOperatorSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonValidationSchemeReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonValueListReaderEngine;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonVtlMappingSchemeReaderEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonStructureReaderManager extends AbstractJsonStructureReaderManager implements IFusionSingleton {
	private static FusionJsonStructureReaderManager INSTANCE;
	
	private Map<String, JsonMaintainableBeanReaderEngine> registeredInstances = new HashMap<>();

	public static FusionJsonStructureReaderManager getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureReaderManager();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static void registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
	}

	private  FusionJsonStructureReaderManager() {
		registerReader(FusionJsonAgencySchemeReaderEngine.getInstance());
		registerReader(FusionJsonCategorisationReaderEngine.getInstance());
		registerReader(FusionJsonCategorySchemeReaderEngine.getInstance());
		registerReader(FusionJsonCodelistReaderEngine.getInstance());
		registerReader(FusionJsonConceptSchemeReaderEngine.getInstance());
		registerReader(FusionJsonContentConstraintReaderEngine.getInstance());
		registerReader(FusionJsonDataConstraintReaderEngine.getInstance());
		registerReader(FusionJsonDataConsumerSchemeReaderEngine.getInstance());
		registerReader(FusionJsonDataflowReaderEngine.getInstance());
		registerReader(FusionJsonDataProviderSchemeReaderEngine.getInstance());
		registerReader(FusionJsonDataStructureReaderEngine.getInstance());
		registerReader(FusionJsonGeoGridCodelistReaderEngine.getInstance());
        registerReader(FusionJsonGeographicCodelistReaderEngine.getInstance());
		registerReader(FusionJsonHierarchyAssociationReaderEngine.getInstance());
		registerReader(FusionJsonHierarchyReaderEngine.getInstance());
		registerReader(FusionJsonHierarchicalCodelistReaderEngine.getInstance());
		registerReader(FusionJsonMetadataflowReaderEngine.getInstance());
		registerReader(FusionJsonMetadataStructureReaderEngine.getInstance());
		registerReader(FusionJsonMetadataProviderSchemeReaderEngine.getInstance());
		registerReader(FusionJsonMetadataProvisionReaderEngine.getInstance());
		registerReader(FusionJsonOrganisationUnitSchemeReaderEngine.getInstance());
		registerReader(FusionJsonProvisionAgreementReaderEngine.getInstance());
		registerReader(FusionJsonPDQReaderEngine.getInstance());
		registerReader(FusionJsonProcessReaderEngine.getInstance());
		registerReader(FusionJsonReportTemplateReaderEngine.getInstance());
		registerReader(FusionJsonReportingTaxonomyReaderEngine.getInstance());
		registerReader(FusionJsonStructureSetReaderEngine.getInstance());
		registerReader(FusionJsonStructureMapReaderEngine.getInstance());
		registerReader(FusionJsonRepresentationMapReaderEngine.getInstance());
		registerReader(FusionJsonValidationSchemeReaderEngine.getInstance());
		registerReader(FusionJsonValueListReaderEngine.getInstance());
		registerReader(FusionJsonCustomTypeSchemeReaderEngine.getInstance());
		registerReader(FusionJsonNamePersonalisationSchemeReaderEngine.getInstance());
		registerReader(FusionJsonVtlMappingSchemeReaderEngine.getInstance());
		registerReader(FusionJsonRulesetSchemeReaderEngine.getInstance());
		registerReader(FusionJsonTransformationSchemeReaderEngine.getInstance());
		registerReader(FusionJsonUserDefinedOperatorSchemeReaderEngine.getInstance());
		registerReader(FusionJsonRegistrationReaderEngine.getInstance());
	}

	@Override
	protected boolean skipToData(JsonReader jReader, SdmxBeans sdmxBeans) {
		while (jReader.moveNext()) {
			if(jReader.isStartObject()) {
				if("meta".equals(jReader.getCurrentFieldName())) {
					readMetaInfo(jReader, sdmxBeans);
				}
			} else if (jReader.isStartArray()) {
				return true;
			}
		}
		return false;
	}
}
