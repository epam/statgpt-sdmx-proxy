package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;


public class SdmxJsonRulesetSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<IRulesetBean, IRulesetSchemeBean> implements IFusionSingleton {
	private static SdmxJsonRulesetSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonRulesetSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonRulesetSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonRulesetSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME);
	}

	
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IRulesetSchemeBean maint) throws JsonGenerationException, IOException {
		if(maint.getVtlVersion() != null) {
			jsonGenerator.writeStringField("vtlVersion", maint.getVtlVersion());
		}
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
		
		
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IRulesetBean item) throws JsonGenerationException, IOException {
		if(item.getRulesetDefinition() != null) {
			jsonGenerator.writeStringField("rulesetDefinition", item.getRulesetDefinition());
		}
		if(item.getRulesetScope() != null) {
			jsonGenerator.writeStringField("rulesetScope", item.getRulesetScope());
		}
		if(item.getRulesetType() != null) {
			jsonGenerator.writeStringField("rulesetType", item.getRulesetType());
		}
	}

	@Override
	protected String getItemName() {
		return "rulesets";
	}
}