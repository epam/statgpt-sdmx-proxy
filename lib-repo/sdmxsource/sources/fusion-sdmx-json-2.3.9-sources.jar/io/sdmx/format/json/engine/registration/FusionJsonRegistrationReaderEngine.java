package io.sdmx.format.json.engine.registration;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonMaintainableUtil;
import io.sdmx.im.RegistrationInformationImpl;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonRegistrationReaderEngine {

	public static List<RegistrationInformation> parse(ReadableDataLocation rdl) { 
		List<RegistrationInformation> returnList = new ArrayList<>();
		try(JsonReader jReader = new JsonReader(rdl)){
			while(jReader.moveNext()) {
				if(jReader.isStartArray()) {
					parseRegistrations(jReader, returnList);
				}
			}
		}
		return returnList;
	}
	
	private static void parseRegistrations(JsonReader jReader, List<RegistrationInformation> returnList) { 
		while(jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				returnList.add(parseRegistration(jReader));
			}
		}
	}
	
	private static RegistrationInformation parseRegistration(JsonReader jReader) { 
		RegistrationMutableBean registration = new RegistrationMutableBeanImpl();
		DATASET_ACTION action = DATASET_ACTION.APPEND;
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonMaintainableUtil.processBean(registration, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "action" :
				action = DATASET_ACTION.getAction(jReader.getValueAsString());
				break;
			case "dataSource" :
				registration.setDataSource(parseDatasource(jReader));
				break;
			case "provisionAgreementReference" :
				registration.setProvisionAgreementRef((StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT)));
				break;
			}
		}
		return new RegistrationInformationImpl(action, registration.getImmutableInstance());
	}
	
	private static DataSourceMutableBean parseDatasource(JsonReader jReader) { 
		DataSourceMutableBean datasource = new DataSourceMutableBeanImpl();
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "isRESTDatasource" :
				datasource.setRESTDatasource(jReader.getValueAsBoolean());
				break;
			case "isWebServiceDatasource" :
				datasource.setWebServiceDatasource(jReader.getValueAsBoolean());
				break;
			case "isSimpleDatasource" :
				datasource.setSimpleDatasource(jReader.getValueAsBoolean());
				break;
			case "dataUrl" :
				datasource.setDataUrl(jReader.getValueAsString());
				break;
			}
		}
		return datasource;
	}
}
