package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonProvisionAgreementReaderEngineV1 extends AbstractSdmxJsonReaderEngine<ProvisionAgreementMutableBean> implements IFusionSingleton {
	private static SdmxJsonProvisionAgreementReaderEngineV1 INSTANCE;

	public static SdmxJsonProvisionAgreementReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonProvisionAgreementReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	

    @Override
    public String getContainerElement() {
        return "provisionAgreements";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ProvisionAgreementBean.class;
    }

    @Override
    protected ProvisionAgreementMutableBean getMutable() {
        return new ProvisionAgreementMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ProvisionAgreementMutableBean mutable, JsonReader reader) {
        String value = reader.getValueAsString();
        switch(fieldName) {
        case "structureUsage":
            mutable.setStructureUsage(new StructureReferenceBeanImpl(value));
            return true;
        case "dataProvider":
            mutable.setDataproviderRef(new StructureReferenceBeanImpl(value));
            return true;
        }
        return false;
    }
}
