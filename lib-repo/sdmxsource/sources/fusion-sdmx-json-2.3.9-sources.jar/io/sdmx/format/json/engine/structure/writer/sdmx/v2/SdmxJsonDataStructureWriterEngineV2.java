package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonDataStructureWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<DataStructureBean> implements IFusionSingleton {
	private static SdmxJsonDataStructureWriterEngineV2 INSTANCE;

	public static SdmxJsonDataStructureWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataStructureWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonDataStructureWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.DSD);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataStructureBean dsd) throws JsonGenerationException, IOException {
		if(dsd.getMSDRef() != null) {
			jsonGenerator.writeStringField("metadata", dsd.getMSDRef().getTargetUrn());
		}
		writeDataStructureComponents(jsonGenerator, externalLinks, dsd);
	}

	private void writeDataStructureComponents(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataStructureBean dsd) throws IOException {
		jsonGenerator.writeObjectFieldStart("dataStructureComponents");

		writeAttributeList(dsd, externalLinks, jsonGenerator);
		writeDimensionList(dsd, externalLinks, jsonGenerator);
		writeGroups(dsd, externalLinks, jsonGenerator);
		writeMeasureList(dsd, externalLinks, jsonGenerator);

		jsonGenerator.writeEndObject();
	}

	private void writeAttributeList(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if(dsd.getAttributeList() != null) {
			jsonGenerator.writeObjectFieldStart("attributeList");
			AttributeListBean attributeList = dsd.getAttributeList();
			super.writeIdentifiable(jsonGenerator, attributeList, externalLinks);
			//			WriteReportingYearStartDays(attributeList, jsonGenerator);
			List<AttributeBean> attributeListArr = attributeList.getAttributes();
			if(ObjectUtil.validCollection(attributeListArr)) {
				jsonGenerator.writeArrayFieldStart("attributes");
				writeListOfAttributes(attributeListArr, externalLinks, jsonGenerator);
				jsonGenerator.writeEndArray();
			}
			jsonGenerator.writeEndObject();
		}
	}

	private void writeListOfAttributes(List<AttributeBean> attributes, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		for(AttributeBean attr : attributes) {
			jsonGenerator.writeStartObject();
			
			String usage = attr.isMandatory() ? "mandatory" : "optional";
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "usage", usage);
			writeAttributeRelationship(attr, jsonGenerator);

			if(!attr.getConceptRoles().isEmpty()) {
				writeConceptRoles(jsonGenerator, attr.getConceptRoles());
			}
			writeComponent(attr, externalLinks, jsonGenerator);
			jsonGenerator.writeEndObject();
		}
	}

	private void writeConceptRoles(JsonGenerator jsonGenerator, List<IDirectCrossReferenceBean<ConceptBean>> roles) throws IOException {
		jsonGenerator.writeArrayFieldStart("conceptRoles");
		for(ICrossReferenceBean<?> ref: roles) {
			jsonGenerator.writeString(ref.getTargetUrn());
		}
		jsonGenerator.writeEndArray();
	}

	/**
	 * <p>This method is used to create the attributeRelationship as defined in the JSON Schemea </p>
	 * <p>The only issue is that the Schema, the documentation and the samples are all contradicting eachover. </p>
	 * <p>The Schema wants things like AttachmentGroup and dimensionReferences to be URNS's where our JAVA returns these in IDs </p>
	 * <p>the official example. however uses ID~s like we do, and not URNS <a href="https://github.com/sdmx-twg/sdmx-json/blob/develop/structure-message/docs/1-sdmx-json-field-guide.md#attributerelationship">https://github.com/sdmx-twg/sdmx-json/blob/develop/structure-message/docs/1-sdmx-json-field-guide.md#attributerelationship</a> </p>
	 * <p>The description here, however backs up what the Schema says, So I am not sure what needs to be actually put here, if it is, indeed URNS. then we need a method on AttributeBean to get the actual group Object. and not the ID, and we need a way of getting the Dimension URN's instead of ID </p>
	 * <p>Also, attachmentLevel is not in the Schema, and the documentation says <q>The attachment level of the attribute will be determined by the data format and which dimensions are referenced.</q></p>
	 * @param attr
	 * @param jsonGenerator
	 * @throws IOException
	 */
	private void writeAttributeRelationship(AttributeBean attr, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("attributeRelationship");
		switch(attr.getAttachmentLevel()) {
		case DATA_SET:
			jsonGenerator.writeObjectFieldStart("dataflow");
			jsonGenerator.writeEndObject();
			// none
			break;
		case DIMENSION_GROUP:
			List<String> dimensionReferences = attr.getDimensionReferences();
			jsonGenerator.writeArrayFieldStart("dimensions");
			for(String dimId: dimensionReferences) {
				jsonGenerator.writeString(dimId);
			}
			jsonGenerator.writeEndArray();
			//dimensions
			break;
		case GROUP:
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "group", attr.getAttachmentGroup());
			//group
			break;
		case OBSERVATION:
			jsonGenerator.writeObjectFieldStart("observation");
			jsonGenerator.writeEndObject();
		
			break;
		default:
			// attachmentGroups in the schema is not supported here
			break;

		}
		jsonGenerator.writeEndObject();
		
		//measure relationship
		if(attr.getMeasureReferences().size() > 0) {
			jsonGenerator.writeArrayFieldStart("measureRelationship");
			for(String measure : attr.getMeasureReferences()) {
				jsonGenerator.writeString(measure);
			}
			jsonGenerator.writeEndArray();
		}
	
	}

	private void writeDimensionList(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("dimensionList");
		DimensionListBean dimensionList = dsd.getDimensionList();
		if(dimensionList != null) {
			writeIdentifiable(jsonGenerator, dimensionList, externalLinks);
		}

		List<DimensionBean> dimensions = dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION);
		if(!dimensions.isEmpty()) {
			jsonGenerator.writeArrayFieldStart("dimensions");
			for(DimensionBean dim : dimensions) {
				jsonGenerator.writeStartObject();
				writeDimension(dim, externalLinks, jsonGenerator);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}

		List<DimensionBean> timeDims = dsd.getDimensions(SDMX_STRUCTURE_TYPE.TIME_DIMENSION);
		if(!timeDims.isEmpty()) {
			if (timeDims.size() > 1) {
				throw new SdmxSemmanticException("SDMX-JSON V2 does not support the writing of multiple Time Dimensions");
			}
			jsonGenerator.writeObjectFieldStart("timeDimension");
			writeDimension(timeDims.get(0), externalLinks, jsonGenerator);
			jsonGenerator.writeEndObject();
		}

		jsonGenerator.writeEndObject();
	}

	private void writeDimension(DimensionBean dimBean, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if (!dimBean.isMeasureDimension() && !dimBean.isTimeDimension()) {
			// Only "standard" dimensions have a position field in Sdmx-JSON V2
			jsonGenerator.writeNumberField("position", dimBean.getPosition());
		}
		if(!dimBean.getConceptRole().isEmpty()) {
			writeConceptRoles(jsonGenerator, dimBean.getConceptRole());
		}
		writeComponent(dimBean, externalLinks, jsonGenerator);
	}

	private void writeGroups(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if (ObjectUtil.validCollection(dsd.getGroups())) {
			jsonGenerator.writeArrayFieldStart("groups");
			for(GroupBean group : dsd.getGroups()) {
				writeGroup(group, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeGroup(GroupBean group, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		writeIdentifiable(jsonGenerator, group, externalLinks);
		
		jsonGenerator.writeArrayFieldStart("groupDimensions");
		for(String dimensionRef : group.getDimensionRefs()) {
			jsonGenerator.writeString(dimensionRef);
		}
		jsonGenerator.writeEndArray();

		jsonGenerator.writeEndObject();
	}

	private void writeMeasureList(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		MeasureListBean measureList = dsd.getMeasureList();
		if(measureList == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("measureList");
		writeIdentifiable(jsonGenerator, measureList, externalLinks);
		writeMeasures(measureList, externalLinks, jsonGenerator);
		jsonGenerator.writeEndObject();
	}

	private void writeMeasures(MeasureListBean measureList, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeArrayFieldStart("measures");
		for(MeasureDimensionBean currentMeasure : measureList.getMeasures()) {
			jsonGenerator.writeStartObject();
			String usage = currentMeasure.isMandatory() ? "mandatory" : "optional";
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "usage", usage);
			writeComponent(currentMeasure, externalLinks, jsonGenerator);
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}
}
