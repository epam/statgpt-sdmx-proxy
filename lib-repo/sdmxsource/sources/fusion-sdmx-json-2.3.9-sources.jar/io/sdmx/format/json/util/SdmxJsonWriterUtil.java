package io.sdmx.format.json.util;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.IMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.json.JsonWriterUtil;

public class SdmxJsonWriterUtil {
	

	public static void writeMeta(JsonGenerator jWriter, IMetadataContainer container, String schema, KeyValue...additional) throws IOException {
		jWriter.writeObjectFieldStart("meta");
		HeaderBean header = container.getHeader();
		if(header == null) {
			header = new HeaderBeanImpl("FusionRegistry");
		}
		SdmxJsonStaticHelper.writeNonNullString(jWriter, "id", header.getId());
		jWriter.writeBooleanField("test", header.isTest());
		SdmxJsonStaticHelper.writeNonNullString(jWriter, "schema", schema);
		Date prepared = header.getPrepared() != null ? header.getPrepared() : new Date();
		SdmxJsonStaticHelper.writeNonNullString(jWriter, "prepared", DateUtil.formatDate(prepared) + "Z");

		JsonWriterUtil.writeStringArray(jWriter, "contentLanguages", container.getAllLocales());
		

		List<TextTypeWrapper> names = header.getName();
		SdmxJsonStaticHelper.writeTextTypeWrapperArray(jWriter, names, "names");
		PartyBean sender = header.getSender();
		if(sender != null) {
			writePartyBean(jWriter, sender, true);
		}

		List<PartyBean> receiver = header.getReceiver();
		if(!receiver.isEmpty()) {
			jWriter.writeArrayFieldStart("receivers");
			for (PartyBean partyBean : receiver) {
				writePartyBean(jWriter, partyBean, false);
			}
			jWriter.writeEndArray();
		}
		if(!container.getLinks().isEmpty()) {
			SdmxJsonStaticHelper.writeLinks(container.getLinks(), jWriter, true);
		}
		
		if(additional != null) {
			for(KeyValue kv : additional) {
				if(kv.hasMultipleValues()) {
					JsonWriterUtil.writeStringArray(jWriter, kv.getConcept(), kv.getValues());
				} else {
					SdmxJsonStaticHelper.writeNonNullString(jWriter,  kv.getConcept(), kv.getCode());
				}
			}
		}
		
		jWriter.writeEndObject();
	}
	

	private static void writePartyBean(JsonGenerator jWriter, PartyBean sender, boolean writeField) throws IOException {
		if(writeField) {
			jWriter.writeObjectFieldStart("sender");
		}else {
			jWriter.writeStartObject();
		}
		SdmxJsonStaticHelper.writeNonNullString(jWriter, "id", sender.getId());
		SdmxJsonStaticHelper.writeTextTypeWrapperArray(jWriter, sender.getName(), "names");
		List<ContactBean> contacts = sender.getContacts();
		if(!contacts.isEmpty()) {
			jWriter.writeArrayFieldStart("contacts");
			for (ContactBean contactBean : contacts) {
				SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeContact(jWriter, contactBean);
			}
			jWriter.writeEndArray();
		}
		jWriter.writeEndObject();
	}
	
}
