package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.TransformationMutableBean;
import io.sdmx.im.mutable.transformation.TransformationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonTransformationSchemeReaderEngine extends FusionJsonAbstractVTLSchemeReaderEngine<ITransformationSchemeBean, ITransformationSchemeMutableBean, ITransformationMutableBean> implements IFusionSingleton {
	private static FusionJsonTransformationSchemeReaderEngine INSTANCE;

	public static FusionJsonTransformationSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonTransformationSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ITransformationSchemeMutableBean getMutable() {
		return new TransformationSchemeMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ITransformationSchemeMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			switch(fieldName) {
			case "vtlMappingScheme" :
				mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			case "namePersonalisationScheme" :
				mutable.setNamePersonalisationSchemeRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			case "customTypeScheme" :
				mutable.setCustomTypeSchemeRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			case "rulesetSchemes" :
				mutable.setRulesetSchemeRef(processSRefArray(jReader));
				break;
			case "userDefinedOperatorScheme" :
				mutable.setUserDefinedOperatorSchemeRef(processSRefArray(jReader));
				break;
			default : return false;
			}
		}
		return true;
	}

	@Override
	protected ITransformationMutableBean readItemBean(JsonReader jReader) {
		ITransformationMutableBean item = new TransformationMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(!FusionJsonNameableUtil.processBean(item, jReader)) {
				String fieldName = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				if (fieldName.equals("isPersistent")) {
					item.setPersistent(jReader.getValueAsBoolean());
				} else if (fieldName.equals("expression")) {
					item.setExpression(value);
				} else if (fieldName.equals("result")) {
					item.setResult(value);
				}
			}
		}
		return item;
	}

    @Override
    protected Class<ITransformationSchemeBean> getMaintainableType() {
        return ITransformationSchemeBean.class;
    }
}
