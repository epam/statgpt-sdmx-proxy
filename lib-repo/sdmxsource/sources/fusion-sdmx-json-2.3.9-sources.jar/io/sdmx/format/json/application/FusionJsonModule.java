package io.sdmx.format.json.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.format.json.factory.data.FusionJsonDataReaderFactory;
import io.sdmx.format.json.factory.data.FusionJsonDataWriterFactory;
import io.sdmx.format.json.factory.error.JsonErrorWriterFactory;
import io.sdmx.format.json.factory.metadata.FusionJsonMetadataFormatFactory;
import io.sdmx.format.json.factory.metadata.FusionJsonMetadataReaderFactory;
import io.sdmx.format.json.factory.metadata.FusionJsonMetadataWriterFactory;
import io.sdmx.format.json.factory.registration.FusionJsonRegistrationReaderFactory;
import io.sdmx.format.json.factory.structure.FusionJsonStructureReaderFactory;
import io.sdmx.format.json.factory.structure.FusionJsonStructureWriterFactory;
import io.sdmx.format.json.factory.structure.JsonStructureFormatFactory;
import io.sdmx.format.json.factory.structure.StructureTransactionWriterFactoryJson;
import io.sdmx.format.json.manager.FusionJsonStructureReaderManager;
import io.sdmx.format.json.serialiser.YamlDefferedBeanSerialiser;

public class FusionJsonModule implements IFusionModule {

	public static void register() {
		//Data Factories
		FusionJsonDataReaderFactory.registerInstance();
		FusionJsonDataWriterFactory.registerInstance();
		
		//Error
		JsonErrorWriterFactory.registerInstance();

		//Structure Factories
		JsonStructureFormatFactory.registerInstance();
		FusionJsonStructureReaderFactory.registerInstance();
		FusionJsonStructureWriterFactory.registerInstance();
		FusionJsonStructureReaderManager.registerInstance();
		
		//Registration Factory
		FusionJsonRegistrationReaderFactory.registerInstance();
		
		//Metadata
		FusionJsonMetadataFormatFactory.registerInstance();
		FusionJsonMetadataReaderFactory.registerInstance();
		FusionJsonMetadataWriterFactory.registerInstance();
		
		//Misc
		StructureTransactionWriterFactoryJson.registerInstance();
		YamlDefferedBeanSerialiser.getInstance();
	}
	
}
