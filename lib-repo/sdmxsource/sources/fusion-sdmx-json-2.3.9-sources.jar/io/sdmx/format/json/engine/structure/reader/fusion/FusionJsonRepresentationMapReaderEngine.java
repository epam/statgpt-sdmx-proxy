package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapRefMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapRefMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonRepresentationMapReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<IRepresentationMapBean, IRepresentationMapMutableBean> implements IFusionSingleton {
	private static FusionJsonRepresentationMapReaderEngine INSTANCE;

	public static FusionJsonRepresentationMapReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRepresentationMapReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IRepresentationMapMutableBean getMutable() {
		return new RepresentationMapMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IRepresentationMapMutableBean mutable, JsonReader jReader) {
		switch(fieldName) {
		case "sources" :
			mutable.setSourceRef(readRefs(jReader));
			break;
		case "targets" :
			mutable.setTargetRef(readRefs(jReader));
			break;
		case "mappedRelationships" :
			readMappedRelationships(jReader, mutable);
			break;
			default : return false;
		}
		return true;
	}
	
	private List<IRepresentationMapRefMutableBean> readRefs(JsonReader reader) {
		 List<IRepresentationMapRefMutableBean> returnList = new ArrayList<>();
		 for(String item : reader.readStringArray()) {
			 IRepresentationMapRefMutableBean ref = new RepresentationMapRefMutableBean();
			 if(!ObjectUtil.validString(item)) {
				 ref.setTextType(TEXT_TYPE.STRING);
			 } else if(item.startsWith("urn")) {
				 ref.setEnumerationRef(new StructureReferenceBeanImpl(item));
			 } else {
				 ref.setTextType(TEXT_TYPE.parseString(item));
			 }
			 returnList.add(ref);
		 }
		 return returnList;
	}

	private void readMappedRelationships(JsonReader jReader, IRepresentationMapMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			} else if(jReader.isStartObject()) {
				readMappedRelationship(jReader, mutable.addMappedRelationship());
			}
		}
	}

	private void readMappedRelationship(JsonReader jReader, IMappedRelationshipMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			} else if(FusionJsonAnnotableUtil.processBean(mutable, jReader)) {
				continue;
			} else {
				String currentFeild = jReader.getCurrentFieldName();
				if(currentFeild != null) {
					switch(currentFeild) {
					case "validFrom" :
						mutable.setValidFrom(jReader.getValueAsString());
						break;
					case "validTo" :
						mutable.setValidTo(jReader.getValueAsString());
						break;
					case "target" :
						mutable.setTargetValue(jReader.readStringArray());
						break;
					case "source" :
						readMappedValues(jReader, mutable);
						break;
					}
				}
			}
		}
	}

	private void readMappedValues(JsonReader jReader, IMappedRelationshipMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			} else if(jReader.isStartObject()) {
				readMappedValue(jReader, mutable.addSourceValue());
			}
		}
	}

	private void readMappedValue(JsonReader jReader, IMappedValueMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			} else {
				String currentFeild = jReader.getCurrentFieldName();
				if(currentFeild != null) {
					switch(currentFeild) {
					case "value" :
						mutable.setValue(jReader.getValueAsString());
						break;
					case "startIdx" :
						mutable.setStartIndex(jReader.getValueAsInt());
						break;
					case "endIdx" :
						mutable.setEndIndex(jReader.getValueAsInt());
						break;
					case "regEx" :
						mutable.setRegEx(jReader.getValueAsBoolean());
						break;
					}
				}
			}
		}
	}

    @Override
    protected Class<IRepresentationMapBean> getMaintainableType() {
        return IRepresentationMapBean.class;
    }
}
