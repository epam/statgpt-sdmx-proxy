package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonVtlMappingSchemeWriterEngineV2  extends SdmxJsonItemSchemeWriterEngineV2<IVtlMappingBean, IVtlMappingSchemeBean> implements IFusionSingleton {
	private static SdmxJsonVtlMappingSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonVtlMappingSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonVtlMappingSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonVtlMappingSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME);
	}


	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IVtlMappingBean item) throws JsonGenerationException, IOException {
		String mappedType = "";
		switch(item.getMapped().getTargetReference()) {
		case DATAFLOW : mappedType = "dataflow";
		break;
		case CODE_LIST : mappedType = "codelist";
		break;
		case CONCEPT : mappedType = "concept";
		break;
		default : throw new SdmxNotAcceptableException("Unsupported mapping type '"+item.getMapped().getTargetReference().getType()+"' ");
		}
		jsonGenerator.writeStringField(mappedType, item.getMapped().getTargetUrn());
		if(item instanceof IVtlDataflowMappingBean) {
			IVtlDataflowMappingBean dataflowMapping = (IVtlDataflowMappingBean) item;
			if(dataflowMapping.getFromMethod() != null || dataflowMapping.getFromSubSpace().size() > 0) {
				writeMappingType(jsonGenerator, dataflowMapping.getFromMethod(), dataflowMapping.getFromSubSpace(), true);
			}
			if(dataflowMapping.getToMethod() != null || dataflowMapping.getToSubSpace().size() > 0) {
				writeMappingType(jsonGenerator, dataflowMapping.getToMethod(), dataflowMapping.getToSubSpace(), false);
			}
		}
		jsonGenerator.writeStringField("alias", item.getAlias());
	}
	
	private void writeMappingType(JsonGenerator jsonGenerator, String method, List<String> subspace, boolean isFrom) throws IOException {
		jsonGenerator.writeObjectFieldStart(isFrom ? "fromVtlMapping" : "toVtlMapping");
		if(method != null) {
			jsonGenerator.writeStringField("method", method);
		}
		if(subspace.size() > 0) {
			jsonGenerator.writeObjectFieldStart(isFrom? "fromVtlSuperSpace" : "toVtlSubSpace");
			jsonGenerator.writeArrayFieldStart("keys");
			for(String ss : subspace) {
				jsonGenerator.writeString(ss);
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndObject();
	}

	@Override
	protected String getItemName() {
		return "vtlMappings";
	}
	
}