package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonValueListReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<ValueListBean, ValueListMutableBean> implements IFusionSingleton {
	private static FusionJsonValueListReaderEngine INSTANCE;

	public static FusionJsonValueListReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonValueListReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ValueListMutableBean getMutable() {
		return new ValueListMutableBeanImpl();
	}

	/**
	 * Builds from expected JSON
	 *
	 * {
	 *   [all the maintainable stuff]
	 *   isPartial : true,
	 *   items : [
	 *   	{
	 *        id : "�",
	 *        names : [
	 *           {locale: "en", value : "A Name"},
	 *   		...
	 *        ],
	 *   	  descriptions : [
	 *           {locale: "en", value : "A Name"},
	 *   		...
	 *        ],
	 *      }
	 *   ]
	 * }
	 *
	 */
	@Override
	protected boolean processMaintainableProperty(String fieldName, ValueListMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("items")) {
			List<ValueItemMutableBean> items = readValueItems(jReader);
			mutable.setItems(items);
		} else {
			return false;
		}
		return true;
	}

	private List<ValueItemMutableBean> readValueItems(JsonReader jReader) {
		List<ValueItemMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ValueItemMutableBean valueItem = readeValueItem(jReader);
				returnList.add(valueItem);
			}
		}

		return returnList;
	}

	private ValueItemMutableBean readeValueItem(JsonReader jReader) {
		ValueItemMutableBean valueItem = new ValueItemMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonAnnotableUtil.processBean(valueItem, jReader);
			
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("id")) {
				valueItem.setId(value);
			} else if (fieldName.equals("names")) {
				List<TextTypeWrapperMutableBean> readTextTypeWrappers = FusionJsonNameableUtil.readTextTypeWrappers(jReader);
				for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
					valueItem.addName(ttw.getLocale(), ttw.getValue());
				}
			} else if (fieldName.equals("descriptions")) {
				List<TextTypeWrapperMutableBean> readTextTypeWrappers = FusionJsonNameableUtil.readTextTypeWrappers(jReader);
				for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
					valueItem.addDescription(ttw.getLocale(), ttw.getValue());
				}
			}
		}
		return valueItem;
	}

    @Override
    protected Class<ValueListBean> getMaintainableType() {
        return ValueListBean.class;
    }
}