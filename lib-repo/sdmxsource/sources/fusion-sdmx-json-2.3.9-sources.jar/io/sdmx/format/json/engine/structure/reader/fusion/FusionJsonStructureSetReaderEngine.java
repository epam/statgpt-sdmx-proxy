package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.mapping.CategorySchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodelistMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ComponentMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ConceptSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ItemMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.OrganisationSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.RepresentationMapRefMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonStructureSetReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<StructureSetBean, StructureSetMutableBean> implements IFusionSingleton {
	private static FusionJsonStructureSetReaderEngine INSTANCE;

	public static FusionJsonStructureSetReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureSetReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected StructureSetMutableBean getMutable() {
		return new StructureSetMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, StructureSetMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("structureMaps")) {
			mutable.setStructureMapList(readStructureMaps(jReader));
		} else if (fieldName.equals("codelistMaps")) {
			mutable.setCodelistMapList(readCodelistMaps(jReader));
		} else if (fieldName.equals("conceptSchemeMaps")) {
			mutable.setConceptSchemeMapList(readConceptSchemeMaps(jReader));
		} else if (fieldName.equals("categoryMaps")) {
			mutable.setCategorySchemeMapList(readCategorySchemeMaps(jReader));
		} else if (fieldName.equals("organisationMaps")) {
			mutable.setOrganisationSchemeMapList(readOrganisationSchemeMaps(jReader));
		}

		//FR-2588 It's not possible to change the Id of a Codelist Map which is used by a Structure Set
		if(mutable.getCodelistMapList() != null) {
			for(CodelistMapMutableBean clMap : mutable.getCodelistMapList()) {
				if(clMap.getOldId() != null) {
					String oldId = clMap.getOldId();
					if(mutable.getStructureMapList() != null) {
						for(StructureMapMutableBean sMap : mutable.getStructureMapList()) {
							if(sMap.getComponents() != null) {
								for(ComponentMapMutableBean cMap : sMap.getComponents()) {
									if(cMap.getRepMapRef() != null) {
										if(ObjectUtil.equivalent(cMap.getRepMapRef().getCodelistMapRef(), oldId)) {
											cMap.getRepMapRef().setCodelistMapRef(clMap.getId());
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return true;
	}

	private List<StructureMapMutableBean> readStructureMaps(JsonReader jReader) {
		List<StructureMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readStructureMap(jReader));
		}
		return returnList;
	}

	private StructureMapMutableBean readStructureMap(JsonReader jReader) {
		StructureMapMutableBean structureMap = new StructureMapMutableBeanImpl();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			if(readSchemeMap(jReader, structureMap)) {
				continue;
			}
			if(jReader.getCurrentFieldName().equals("componentMap")) {
				structureMap.setComponents(readComponentMaps(jReader));
			}
		}
		return structureMap;
	}

	private List<ComponentMapMutableBean> readComponentMaps(JsonReader jReader) {
		List<ComponentMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readComponentMap(jReader));
		}
		return returnList;

	}

	private ComponentMapMutableBean readComponentMap(JsonReader jReader) {
		ComponentMapMutableBean map = new ComponentMapMutableBeanImpl();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			if(FusionJsonAnnotableUtil.processBean(map, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			//Backward compatible source/target
			if(fieldName.equals("source")) {
				map.addMapConceptRef(jReader.getValueAsString());
			} else if(fieldName.equals("target")) {
				map.addMapTargetConceptRef(jReader.getValueAsString());
			} else if(fieldName.equals("sources")) {
				map.setMapConceptRef(jReader.readStringArray());
			} else if(fieldName.equals("targets")) {
				map.setMapTargetConceptRef(jReader.readStringArray());
			} else if(fieldName.equals("valueMap")) {
				RepresentationMapRefMutableBean repMap = new RepresentationMapRefMutableBeanImpl();
				repMap.setValueMappings(readValueMap(jReader));
				map.setRepMapRef(repMap);
			}  else if(fieldName.equals("codelistRef")) {
				String codelistRef = jReader.getValueAsString();
				if(ObjectUtil.validString(codelistRef)) {
					RepresentationMapRefMutableBean repMap = new RepresentationMapRefMutableBeanImpl();
					repMap.setCodelistMapRef(jReader.getValueAsString());
					map.setRepMapRef(repMap);
				}
			}
		}
		return map;
	}

	private Map<String, Set<String>> readValueMap(JsonReader jReader) {
		Map<String, Set<String>> returnMap = new LinkedHashMap<>();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			returnMap.put(jReader.getCurrentFieldName(), new HashSet<>(jReader.readStringArray()));
		}
		return returnMap;
	}

	private List<CodelistMapMutableBean> readCodelistMaps(JsonReader jReader) {
		List<CodelistMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readCodelistMap(jReader));
		}
		return returnList;
	}

	private List<ConceptSchemeMapMutableBean> readConceptSchemeMaps(JsonReader jReader) {
		List<ConceptSchemeMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readConceptSchemeMap(jReader));
		}
		return returnList;
	}

	private List<CategorySchemeMapMutableBean> readCategorySchemeMaps(JsonReader jReader) {
		List<CategorySchemeMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readCategoryMap(jReader));
		}
		return returnList;
	}

	private List<OrganisationSchemeMapMutableBean> readOrganisationSchemeMaps(JsonReader jReader) {
		List<OrganisationSchemeMapMutableBean> returnList = new ArrayList<>();
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			returnList.add(readOrgMap(jReader));
		}
		return returnList;
	}

	private CodelistMapMutableBean readCodelistMap(JsonReader jReader) {
		CodelistMapMutableBean bean = new CodelistMapMutableBeanImpl();
		readItemSchemeMap(bean, jReader);
		return bean;
	}


	private ConceptSchemeMapMutableBean readConceptSchemeMap(JsonReader jReader) {
		ConceptSchemeMapMutableBean bean = new ConceptSchemeMapMutableBeanImpl();
		readItemSchemeMap(bean, jReader);
		return bean;
	}

	private CategorySchemeMapMutableBean readCategoryMap(JsonReader jReader) {
		CategorySchemeMapMutableBean bean = new CategorySchemeMapMutableBeanImpl();
		readItemSchemeMap(bean, jReader);
		return bean;
	}

	private OrganisationSchemeMapMutableBean readOrgMap(JsonReader jReader) {
		OrganisationSchemeMapMutableBean bean = new OrganisationSchemeMapMutableBeanImpl();
		readItemSchemeMap(bean, jReader);
		return bean;
	}

	@SuppressWarnings("unchecked")
	private <T extends ItemMapMutableBean> void readItemSchemeMap(ItemSchemeMapMutableBean<T> map, JsonReader jReader) {
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			if(readSchemeMap(jReader, map)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();


			if(fieldName.equals("itemMap")) {
				if(jReader.isStartObject()){
					Map<String, Set<String>> itemMap = readValueMap(jReader);
					for(String source : itemMap.keySet()) {
						for(String target : itemMap.get(source)) {
							T mapItem = (T) new ItemMapMutableBeanImpl();
							if(map instanceof CodelistMapMutableBean){
								mapItem = (T) new CodeMapMutableBeanImpl();
							}
							mapItem.setSourceId(source);
							mapItem.setTargetId(target);
							map.addItem(mapItem);
						}
					}
				}else{
					readItemMaps(jReader, map);
				}
			}
		}
	}

	private <T extends ItemMapMutableBean> void readItemMaps(JsonReader jReader, ItemSchemeMapMutableBean<T> map){
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			readItemMap(jReader, map);
		}
	}

	@SuppressWarnings("unchecked")
	private <T extends ItemMapMutableBean> void readItemMap(JsonReader jReader, ItemSchemeMapMutableBean<T> map){
		T mapItem = (T) new ItemMapMutableBeanImpl();
		if(map instanceof CodelistMapMutableBean){
			mapItem = (T) new CodeMapMutableBeanImpl();
		}
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			FusionJsonAnnotableUtil.processBean(mapItem, jReader);
			String currentFieldName = jReader.getCurrentFieldName();
			String aValue = jReader.getValueAsString();
			if(currentFieldName.equals("src")) {
				mapItem.setSourceId(aValue);
			} else if(currentFieldName.equals("tgt")) {
				mapItem.setTargetId(aValue);
			}
		}
		if(mapItem instanceof ValidityPeriodMutableBean){ // CodeMapMutableBeanImpl
			ValidityPeriodUtil.processValidityAnnotations((ValidityPeriodMutableBean)mapItem);
		}
		map.addItem(mapItem);
	}

	private boolean readSchemeMap(JsonReader jReader, SchemeMapMutableBean schemeMap) {
		if(FusionJsonNameableUtil.processBean(schemeMap, jReader)) {
			return true;
		}
		String fieldName = jReader.getCurrentFieldName();
		if(fieldName.equals("source")) {
			schemeMap.setSourceRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			return true;
		} else if(fieldName.equals("target")) {
			schemeMap.setTargetRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			return true;
		}
		return false;
	}

    @Override
    protected Class<StructureSetBean> getMaintainableType() {
        return StructureSetBean.class;
    }
}
