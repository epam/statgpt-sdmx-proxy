package io.sdmx.format.json.api.engine;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Any Reader implemented this interface will be assumed to be part of the official JSON format. This will automatically be picked up by the JsonStructureReaderFormatFactory
 *
 * @param <T>
 */
public interface SdmxJsonMaintainableBeanReaderEngine<T extends MaintainableBean> extends JsonMaintainableBeanReaderEngine {

}
