package io.sdmx.format.json.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.format.json.factory.data.SdmxJsonDataFormatFactory;
import io.sdmx.format.json.factory.data.SdmxJsonDataReaderFactory;
import io.sdmx.format.json.factory.data.SdmxJsonDataWriterFactory;
import io.sdmx.format.json.factory.metadata.SdmxJsonMetadataFormatFactory;
import io.sdmx.format.json.factory.metadata.SdmxJsonMetadataReaderFactory;
import io.sdmx.format.json.factory.metadata.SdmxJsonMetadataWriterFactory;
import io.sdmx.format.json.factory.structure.FusionJsonStructureReaderFactory;
import io.sdmx.format.json.factory.structure.FusionJsonStructureWriterFactory;
import io.sdmx.format.json.factory.structure.JsonStructureFormatFactory;
import io.sdmx.format.json.factory.structure.SdmxJsonStructureWriterFactory;
import io.sdmx.format.json.manager.SdmxJsonStructureReaderManagerV1;
import io.sdmx.format.json.manager.SdmxJsonStructureReaderManagerV2;

public class SdmxJsonModule implements IFusionModule {
	
	public static void register() {
		//Data Factories
		SdmxJsonDataFormatFactory.registerInstance();
		SdmxJsonDataReaderFactory.registerInstance();
		SdmxJsonDataWriterFactory.registerInstance();
		
		//Structure Factories
		JsonStructureFormatFactory.registerInstance();
		FusionJsonStructureReaderFactory.registerInstance();
		FusionJsonStructureWriterFactory.registerInstance();
		SdmxJsonStructureWriterFactory.registerInstance();
		SdmxJsonStructureReaderManagerV1.registerInstance();
		
		SdmxJsonMetadataReaderFactory.registerInstance();
		SdmxJsonMetadataWriterFactory.registerInstance();
		SdmxJsonMetadataFormatFactory.registerInstance();
		
		SdmxJsonStructureReaderManagerV2.registerInstance();
	}
}
