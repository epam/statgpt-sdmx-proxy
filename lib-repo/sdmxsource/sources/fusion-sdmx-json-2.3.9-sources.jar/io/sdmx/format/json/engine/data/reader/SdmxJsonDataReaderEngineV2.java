package io.sdmx.format.json.engine.data.reader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.engine.data.AbstractDataReaderEngine;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.format.json.engine.data.reader.SdmxStructureIterator.AttraMapping;
import io.sdmx.format.json.engine.data.reader.SdmxStructureIterator.JsonDatasetStructuralMetadata;
import io.sdmx.format.json.model.SdmxJsonDataFormat;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonDataReaderEngineV2 extends AbstractDataReaderEngine {

	private static final Logger LOG = LoggerFactory.getLogger(SdmxJsonDataReaderEngineV2.class);
	private static final long serialVersionUID = 1260457180275L;

	private JsonReader jReader;
	private boolean isFlat = false;
	private Integer obsKey = null; // Obs Key (typically time)
	private List<List<String>> obsValues = null; // Obs Value, Obs Attributes, Obs Annotations
	private List<Integer> annotations;

	private String currentKeyEncoded;
	private List<KeyValue> currentDsAttributes; // current dataset attributes
	private JsonDatasetStructuralMetadata currentDsStructuralMetadata;
	private List<JsonDatasetStructuralMetadata> dsStructuralMetadata = new ArrayList<>();
	private Integer currentStructureIndex; // index of structure describing current dataset
	private List<Integer> structureIndexes = new ArrayList<>();
	private List<Integer> currentDsAttributeIndexes; // current dataset attribute indexes
	private List<List<Integer>> dsAttributeIndexes = new ArrayList<>(); // dataset attribute indexes

	private Map<String, Set<String>> groupMap;
	private Map<String, Set<String>> groupMapMandatoryElements;
	private List<Keyable> groupAndSeriesStack = new ArrayList<>();


	private ReadableDataLocation dataLocation;
	
	public SdmxJsonDataReaderEngineV2(ReadableDataLocation dataLocation, SdmxBeanRetrievalManager beanRetrieval, DataStructureBean defaultDsd, DataflowBean defaultDataflow, ProvisionAgreementBean defaultProvisionAgreement, DataReaderExceptionHandler exceptionHandler) {
		super(beanRetrieval, defaultDsd, defaultDataflow, defaultProvisionAgreement, exceptionHandler);
		this.dataLocation = dataLocation;
		preParseForDatasetAttributes();
		reset();
	}

	/**
	 * Read the JSON looking for the Dataset Attributes. If found, store them away for later usage
	 */
	private void preParseForDatasetAttributes() {
		try {
			jReader = new JsonReader(dataLocation);
			while (jReader.moveNext()) {
				// sdmxJson v2 has two different dataSets fields - one in data object and a new one in structure object
				if (jReader.getCurrentFieldName() != null && jReader.getCurrentFieldName().equals("dataSets") && jReader.isParentField("data")) {
					analyseDataSets();
				}
			}
		} catch (Exception e) {
			// If anything goes wrong, then abandon the search for the Dataset Attributes
			e.printStackTrace();
		} finally {
			jReader.close();
		}
	}

	/**
	 * Need to find the fields "attributes" and "structure" within the element "dataSets", which may not be present.
	 * "structure" contains the positional index of the structure describing this dataset
	 */
	private void analyseDataSets() {
		while (jReader.moveNext()) {
			switch (jReader.getCurrentFieldName()) {
				case "structure":
					// sdmxJson v2 uses structure field in dataset object to indicate the relevant structure
					structureIndexes.add(jReader.getValueAsInt());
					break;
				case "observations":
				case "series":
					// skip there can be attributes inside
					jReader.moveToEndCurrentObject();
					break;
				case "attributes":
					if (jReader.isStartArray()) {
						dsAttributeIndexes.add(jReader.readIntegerArray(true));
					}
					break;
			}
		}
		// sdmxJson v2 specifies the first structure as default if 'structure' field is omitted
		currentStructureIndex = structureIndexes.isEmpty()
				? 0 : structureIndexes.get(0);
		currentDsAttributeIndexes = dsAttributeIndexes.isEmpty()
				? new ArrayList<>() : dsAttributeIndexes.get(0);

	}

	@Override
	public void reset() {
		super.reset();

		if (jReader != null) {
			jReader.close();
		}
		jReader = new JsonReader(dataLocation);
		SdmxJsonMetadataIteratorV2 metadataIterator = new SdmxJsonMetadataIteratorV2(jReader, this.exceptionHandler);

		LOG.debug("Iterate JSON Data Message");
		jReader.iterate(metadataIterator);
		HeaderIterator header = metadataIterator.getHeaderIterator();
		if (header != null) {
			headerBean = header.getHeader();
		}

		List<SdmxStructureIterator> structureIterators = metadataIterator.getStructureIterators();
		if (structureIterators == null || structureIterators.isEmpty()) {
			throw new SdmxSemmanticException("Can not read JSON dataset, missing structure section");
		}

		structureIterators.forEach(i -> dsStructuralMetadata.add(i.getJsonDatasetStructuralMetadata()));

		currentDsStructuralMetadata = dsStructuralMetadata.get(currentStructureIndex);
		currentDsAttributes = decode(currentDsAttributeIndexes, currentDsStructuralMetadata.getDatasetAttributeList(), "attribute");

		LOG.debug("Reset JsonReader");
		jReader.reset();

		LOG.debug("Move to start of dataSets Array");
		while (jReader.moveNextStartArray()) {
			if ("dataSets".equals(jReader.getCurrentFieldName())) {
				datasetPosition = null;
				LOG.debug("Move successful");
				return;
			}
		}
		LOG.debug("dataSets Array not found - no data");
		super.hasNext = false;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_2_0_0, null).getFormatDetails();
	}

	@Override
	public String getDataFormat() {
		return "SDMX-JSON";
	}

	@Override
	public DataReaderEngine createCopy() {
		return new SdmxJsonDataReaderEngineV2(dataLocation.copy(), beanRetrieval, super.defaultDsd, super.defaultDataflow, super.defaultProvisionAgreement, exceptionHandler);
	}

	@Override
	protected IDatasetAttributes lazyLoadDatasetAttributes() {
		return DatasetAttributes.builder().attributes(currentDsAttributes).build();
	}

	@Override
	public List<FooterMessage> close() {
		jReader.close();
		dataLocation.close();
		return new ArrayList<>();
	}

	@Override
	public boolean moveNextDataset() {
		boolean result = super.moveNextDataset();
		// The creation of the map of groups MUST happen after the super call
		// as the DSD must be assigned

		currentStructureIndex = structureIndexes.get(getDatasetPosition());
		currentDsStructuralMetadata = dsStructuralMetadata.get(currentStructureIndex);
		currentDsAttributes = decode(currentDsAttributeIndexes, currentDsStructuralMetadata.getDatasetAttributeList(), "attribute");
		this.currentDatasetAttributes = lazyLoadDatasetAttributes();
		IDatasetStructures dsStructures = new DatasetStructures(currentDsStructuralMetadata.getDatasetStructureReference().getStructureReference(), beanRetrieval);
		currentDsd = dsStructures.getDataStructure();

		if (result) {
			// Create a Map of group name to elements in the Group (a Set of their IDs)
			groupMap = new HashMap<>();
			groupMapMandatoryElements = new HashMap<>();
			for (AttributeBean attributeBean : this.currentDsd.getGroupAttributes()) {
				Set<String> set = groupMap.get(attributeBean.getAttachmentGroup());
				if (set == null) {
					set = new HashSet<>();
					groupMap.put(attributeBean.getAttachmentGroup(), set);
				}
				set.add(attributeBean.getId());

				if (attributeBean.isMandatory()) {
					Set<String> setMandatory = groupMapMandatoryElements.get(attributeBean.getAttachmentGroup());
					if (setMandatory == null) {
						setMandatory = new HashSet<>();
						groupMapMandatoryElements.put(attributeBean.getAttachmentGroup(), setMandatory);
					}
					setMandatory.add(attributeBean.getId());
				}
			}

		}
		return result;
	}

	@Override
	protected boolean moveNextDatasetInternal() {
		while (jReader.moveNextStartObject()) {
			if (jReader.isParentField("dataSets")) {
				datasetPosition = DATASET_POSITION.DATASET;

				DATASET_ACTION action = DATASET_ACTION.INFORMATION;
				String datasetId = null;
				IURNAbsolute<DataProviderBean> dataProviderRef = null;
				Date reportingBeginDate = null;
				Date reportingEndDate = null;
				Date validFrom = null;
				Date validTo = null;
				int publicationYear = -1;
				String publicationPeriod = null;
				String reportingYearStartDate = null;
				DatasetStructureReferenceBean dsRef = currentDsStructuralMetadata.getDatasetStructureReference();
				outer:
				while (jReader.moveNext()) {
					String fieldName = jReader.getCurrentFieldName();
					switch (fieldName) {
						case "observations":
							isFlat = true;
							break outer;
						case "series":
							isFlat = false;
							break outer;
						case "annotations":
							annotations = jReader.readIntegerArray();
							break;
						case "attributes":
							// Skip it - the Dataset Attributes have been read earlier
							jReader.readIntegerArray();
							break;
						case "action":
							action = DATASET_ACTION.getAction(jReader.getValueAsString());
							break;
						case "reportingBegin":
							reportingBeginDate = DateUtil.formatDate(jReader.getValueAsString(), true);
							break;
						case "reportingEnd":
							reportingEndDate = DateUtil.formatDate(jReader.getValueAsString(), true);
							break;
						case "validFrom":
							validFrom = DateUtil.formatDate(jReader.getValueAsString(), true);
							break;
						case "validTo":
							validTo = DateUtil.formatDate(jReader.getValueAsString(), true);
							break;
						case "publicationYear":
							publicationYear = Integer.parseInt(jReader.getValueAsString());
							break;
						case "publicationPeriod":
							publicationPeriod = jReader.getValueAsString();
							break;
					}
				}
				super.datasetHeaderBean = new DatasetHeaderBeanImpl(datasetId, action, dsRef, dataProviderRef, reportingBeginDate,
						reportingEndDate, validFrom, validTo, publicationYear, publicationPeriod, reportingYearStartDate);
				return true;
			}
		}
		return false;
	}

	private List<KeyValue> decodeNested(List<List<Integer>> encodedValues, List<AttraMapping> decodeList, String nodeType) {
		Map<String, List<String>> returnMap = new HashMap<>();
		for (int i = 0; i < encodedValues.size(); i++) {
			List<Integer> list = encodedValues.get(i);
			if (list != null) {
				for (Integer val : list) {
					if (decodeList.size() > i) {
						AttraMapping m = decodeList.get(i);
						Map<Integer, KeyValue> kvMap = m.componentMap;
						boolean inBounds = (val >= 0) && (val < kvMap.size());
						if (!inBounds) {
							super.handleException(nodeType + " attribute '" + m.id + "' does not contain a value at index: " + val, true, SEVERITY.MEDIUM, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
						}
						KeyValue decoded = kvMap.get(val);
						if (decoded != null) {
							String concept = decoded.getConcept();
							String code = decoded.getCode();
							if (returnMap.containsKey(concept)) {
								returnMap.get(concept).add(code);
							} else {
								returnMap.put(concept, new ArrayList<>(Arrays.asList(code)));
							}
						}
					}
				}
			}
		}

		// create a multivalued KeyValue list to return
		List<KeyValue> returnList = new ArrayList<>();
		returnMap.forEach((k, vl) -> {
			String[] values = vl.toArray(new String[0]);
			returnList.add(KeyValueImpl.getInstance(k, values));
		});

		return returnList;
	}

	private List<KeyValue> decode(List<Integer> encodedValues, List<AttraMapping> decodeList, String nodeType) {
		List<KeyValue> returnList = new ArrayList<>();
		for (int i = 0; i < encodedValues.size(); i++) {
			Integer val = encodedValues.get(i);
			if (val != null && decodeList.size() > i) {
				AttraMapping m = decodeList.get(i);
				Map<Integer, KeyValue> kvMap = m.componentMap;
				boolean inBounds = (val >= 0) && (val < kvMap.size());
				if (!inBounds || val > kvMap.size()) {
					super.handleException(nodeType + " attribute '" + m.id + "' does not contain a value at index: " + val, true, SEVERITY.MEDIUM, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
				}
				KeyValue decoded = decodeList.get(i).componentMap.get(val);
				if (decoded != null) {
					returnList.add(decoded);
				}
			}
		}
		return returnList;
	}

	@Override
	protected boolean moveNextKeyableInternal() {
		if (!groupAndSeriesStack.isEmpty()) {
			return true;
		}

		if (datasetPosition == DATASET_POSITION.OBSERVATION && isFlat && jReader.isStartArray() && jReader.isParentField("observations")) {
			// We have already moved to the next key
			return true;
		}
		while (jReader.moveNext()) {
			if (isFlat) {
				if (jReader.isStartArray()) {
					datasetPosition = DATASET_POSITION.SERIES;
					String fieldName = jReader.getCurrentFieldName();
					String series = fieldName.substring(0, fieldName.lastIndexOf(":"));
					if (!series.equals(currentKeyEncoded)) {
						currentKeyEncoded = series;
						return true;
					}
				} else if (jReader.isEndObject() || jReader.isEndArray()) {
					String fieldName = jReader.getCurrentStackItem().getFieldName();
					if ("dataSets".equals(fieldName)) {
						return false;  // End dataSet
					}
				}
			} else {
				// Grouped by series
				if (jReader.isStartObject() && jReader.isParentField("series")) {
					datasetPosition = DATASET_POSITION.SERIES;
					currentKeyEncoded = jReader.getCurrentFieldName();
					return true;
				} else if (jReader.isEndObject()) {
					if (jReader.isParentField("observations")) {
						return false;  // End Observations
					}
					if (jReader.isParentField("dataSets")) {
						return false;  // End dataSet
					}
				}
			}
		}
		return false;
	}

	@Override
	protected boolean moveNextObservationInternal() {
		// FR-4626: If we are not on a series (
		if (currentKey == null || !currentKey.isSeries()) {
			return false;
		}

		datasetPosition = DATASET_POSITION.OBSERVATION;
		obsKey = null;
		obsValues = null;
		if (isFlat) {
			if (jReader.isStartArray()) {
				String[] keySplit = jReader.getCurrentFieldName().split(":");
				obsKey = Integer.parseInt(keySplit[keySplit.length - 1]);
				readObsValuesNestedArray();
				return true;
			}
			if (jReader.isEndArray()) {
				jReader.moveNext(); // Move to the next element, we expect this to be the start of the next array, otherwise there are no more observations
				if (jReader.isStartArray()) {
					String fieldName = jReader.getCurrentFieldName();
					String series = fieldName.substring(0, fieldName.lastIndexOf(":"));
					if (series.equals(currentKeyEncoded)) {
						String[] keySplit = fieldName.split(":");
						obsKey = Integer.parseInt(keySplit[keySplit.length - 1]);
						readObsValuesNestedArray();
						return true;
					} else {
						currentKeyEncoded = series;
					}
				}
				return false;
			}
		} else {
			jReader.moveNext();
			if (jReader.isStartArray()) {
				obsKey = Integer.parseInt(jReader.getCurrentFieldName());
				readObsValuesNestedArray();
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	private void readObsValuesNestedArray() {
		obsValues = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isStartArray()) {
				obsValues.add(jReader.readStringArray());
			} else if (jReader.isEndArray()) {
				break;
			} else {
				String val = jReader.getValueAsString();
				if (!ObjectUtil.validString(val)) {
					obsValues.add(null);
				} else {
					obsValues.add(Collections.singletonList(val));
				}
			}
		}
	}

	/**
	 * For Flat, we should be positioned at the start of an array, which we can read to give us the observation value, and indexes of all other
	 * attributes and annotations.
	 * <br/>
	 * For Series observations, the reader will be positioned at the start
	 */
	@Override
	protected Observation lazyLoadObservation() {
		List<AnnotationBean> annotations = new ArrayList<>();
		List<List<Integer>> obsAttributes = new ArrayList<>();
		int measuresSize = currentDsd.getMeasures().size();

		// For each obsValue, obtain the Attributes and Annotations and populate the appropriate List
		for (int i = measuresSize; i < obsValues.size(); i++) {
			List<String> obsVals = obsValues.get(i);
			// Create a boolean to determine whether annotations should be being processed.
			// This is determined by the length of the attribute list, taking into account the number of measures declared in the DSD
			boolean shouldProcessAnnotations = currentDsStructuralMetadata.getObsAttributeList().size() < i + 1 - measuresSize ;
			
			if (obsVals == null) {
				obsAttributes.add(null);
			} else if (obsVals.size() == 1) {
				int asInt = Integer.parseInt(obsVals.get(0));
				if (shouldProcessAnnotations) {
					if (currentDsStructuralMetadata.getAnnotationList().size() < asInt + 1) {
						super.handleException("Error in Series #" + (getKeyablePosition() + 1) + ", Observation #" + (getObsPosition() + 1) + ". Observation array length inconsistent with DSD and reported annotations", true, SEVERITY.MEDIUM, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
					} else {
						annotations.add(currentDsStructuralMetadata.getAnnotationList().get(asInt));
					}
				} else {
					obsAttributes.add(Collections.singletonList(asInt));
				}
			} else {
				obsAttributes.add(new ArrayList<>());
				for (String val : obsVals) {
					int asInt = Integer.parseInt(val);
					if (shouldProcessAnnotations) {
						if (currentDsStructuralMetadata.getAnnotationList().size() < asInt + 1) {
							super.handleException("Error in Series #" + (getKeyablePosition() + 1) + ", Observation #" + (getObsPosition() + 1) + ". Observation array length inconsistent with DSD and reported annotations", true, SEVERITY.MEDIUM, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
						} else {
							annotations.add(currentDsStructuralMetadata.getAnnotationList().get(asInt));
						}
					} else {
						obsAttributes.get(obsAttributes.size() - 1).add(asInt);
					}
				}
			}
		}
		List<KeyValue> attributes = decodeNested(obsAttributes, currentDsStructuralMetadata.getObsAttributeList(), "observation");

		List<KeyValue> measuresValues = new ArrayList<>();
		List<String> measureIds = currentDsStructuralMetadata.getMeasureIds();
		for (int i = 0; i < measureIds.size(); i++) {
			String concept = measureIds.get(i);
			List<String> values = obsValues.get(i);

			if (values != null) {
				if (values.size() == 1) {
					// read single-valued measure
					measuresValues.add(KeyValueImpl.getInstance(concept, values.get(0)));

				} else if (values.size() > 1) {
					// read multivalued measure
					measuresValues.add(KeyValueImpl.getInstance(concept, values.toArray(new String[0])));
				}
			}
		}

		AnnotationBean[] annArr = new AnnotationBean[annotations.size()];
		annotations.toArray(annArr);

		String obsTime = null;
		if (currentDsStructuralMetadata.getObsIds().size() <= obsKey) {
			super.handleException("Error in Series #" + (getKeyablePosition() + 1) + ", Observation #" + (getObsPosition() + 1) + ". Observation references a Time Period at an invalid index of '" + obsKey + "'", true, SEVERITY.MEDIUM, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
		} else {
			obsTime = currentDsStructuralMetadata.getObsIds().get(obsKey);
			if (obsTime != null) {
				int obsTimeLength = obsTime.length();
				if (obsTimeLength > 4 && obsTime.charAt(5) == 'W' && obsTimeLength != 8) {
					handleException("Weekly data for SDMX CSV is of the format YYYY-Www. Reported value is: " + obsTime, true, SEVERITY.HIGH, TYPE.INVALID_DATE, ERROR_POSITION.OBSERVATION);
				}
			}
		}
		return ObservationImpl.multipleMeasureTimeSeries(currentKey, obsTime, measuresValues, attributes, annArr);
	}

	@Override
	protected Keyable lazyLoadKey() {
		if (!groupAndSeriesStack.isEmpty()) {
			// Pop the first empty from the stack
			return groupAndSeriesStack.remove(0);
		}

		String[] keyParts = currentKeyEncoded.split(":");
		List<KeyValue> key = decode(keyParts, currentDsStructuralMetadata.getSeriesList(), "series");
		List<KeyValue> attributes = new ArrayList<>();
		AnnotationBean[] annotations = null;
		if (isFlat) {
			// Do Nothing
		} else {
			while (jReader.moveNext()) {
				if (jReader.isStartArray()) {
					if ("annotations".equals(jReader.getCurrentFieldName())) {
						annotations = decodeAnnotations(jReader.readIntegerArray());
					} else if ("attributes".equals(jReader.getCurrentFieldName())) {
						try {
							List<List<Integer>> readIntArray = new ArrayList<>();
							while (jReader.moveNext()) {
								if (jReader.isStartArray()) {
									readIntArray.add(jReader.readIntegerArray(true));
								} else if (jReader.isEndArray()) {
									break;
								} else {
									String val = jReader.getValueAsString();
									if (val == null) {
										readIntArray.add(null);
									} else {
										readIntArray.add(Collections.singletonList(Integer.parseInt(val)));
									}
								}
							}
							attributes = decodeNested(readIntArray, currentDsStructuralMetadata.getSeriesAttributeList(), "series");
						} catch (NumberFormatException e) {
							super.handleException("Unexpected attribute value: " + e.getMessage(), true, SEVERITY.LOW, TYPE.JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS);
							return null;
						}
					}
				} else if (jReader.isStartObject()) {
					if (jReader.getCurrentFieldName().equals("observations")) {
						break;
					}
				}
			}
		}

		if (currentDsd.getGroups().isEmpty()) {
			// No groups
			return KeyableImpl.seriesKey(currentDataflow, currentDsd, key, attributes, annotations);
		}

		List<KeyValue> serAtt = new ArrayList<>();
		List<KeyValue> grpAttributes = new ArrayList<>();

		// Determine the real series attributes and the group attributes
		for (KeyValue attr : attributes) {
			AttributeBean attribute = currentDsd.getAttribute(attr.getConcept());
			if (attribute == null) {
				// FR-4607: The attributes doesn't actually exist in the DSD so add it to the series attributes
				// It will report as an error in validation
				serAtt.add(attr);
			} else {
				ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel = attribute.getAttachmentLevel();
				if (attachmentLevel == ATTRIBUTE_ATTACHMENT_LEVEL.GROUP) {
					grpAttributes.add(attr);
				} else {
					serAtt.add(attr);
				}
			}
		}

		// Evaluate the groups to see if there is a match
		String grpName = null;
		List<KeyValue> dimensionsForGroup = new ArrayList<>();
		List<GroupBean> groups = currentDsd.getGroups();
		for (GroupBean groupBean : groups) {
			if (!groupMap.containsKey(groupBean.getId())) {
				continue;
			}
			List<String> dimensionRefs = groupBean.getDimensionRefs();

			Set<String> attSet = new HashSet<>();
			// Walk all the attributes of the defined group and where they match add to a set
			for (String aDim : groupMap.get(groupBean.getId())) {
				for (KeyValue kv : grpAttributes) {
					if (kv.getConcept().contentEquals(aDim)) {
						attSet.add(kv.getConcept());
					}
				}
			}

			Set<String> mandatoryElements = groupMapMandatoryElements.get(groupBean.getId());
			if (attSet.containsAll(mandatoryElements)) {
				// This is a match - get the dimension references
				grpName = groupBean.getId();

				for (String ref : dimensionRefs) {
					for (KeyValue kv : key) {
						if (kv.getConcept().equals(ref)) {
							dimensionsForGroup.add(kv);
							break;
						}
					}
				}
				break;
			}
		}

		if (grpName != null) {
			groupAndSeriesStack.add(KeyableImpl.groupKey(currentDataflow, currentDsd, grpName, dimensionsForGroup, grpAttributes));
		}
		groupAndSeriesStack.add(KeyableImpl.seriesKey(currentDataflow, currentDsd, key, serAtt, annotations));

		// Pop the first entry from the stack and return it
		return groupAndSeriesStack.remove(0);
	}

	private AnnotationBean[] decodeAnnotations(List<Integer> encodedValues) {
		List<AnnotationBean> annList = new ArrayList<>();
		for (Integer annIdx : encodedValues) {
			if (currentDsStructuralMetadata.getAnnotationList().size() > annIdx) {
				annList.add(currentDsStructuralMetadata.getAnnotationList().get(annIdx));
			} else {
				LOG.warn("Annotation not found at index '" + annIdx + "'");
			}
		}
		AnnotationBean[] returnArray = new AnnotationBean[annList.size()];
		return annList.toArray(returnArray);
	}

	private List<KeyValue> decode(String[] encodedValues, List<AttraMapping> decodeList, String nodeType) {
		List<Integer> l = new ArrayList<>();
		for (String str : encodedValues) {
			l.add(Integer.parseInt(str));
		}
		return decode(l, decodeList, nodeType);
	}
}
