package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonProcessWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<ProcessBean> implements IFusionSingleton {
	private static FusionJsonProcessWriterEngine INSTANCE;

	public static FusionJsonProcessWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonProcessWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private FusionJsonProcessWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.PROCESS);
	}
	
	
	@Override
	public void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProcessBean maint) throws JsonGenerationException, IOException {
		writeProcessSteps(jsonGenerator, externalLinks, maint.getProcessSteps());
	}
	
	private void writeProcessSteps(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<ProcessStepBean> processSteps) throws JsonGenerationException, IOException {
		if(ObjectUtil.validCollection(processSteps)) {
			jsonGenerator.writeArrayFieldStart("processSteps");
			for(ProcessStepBean processStep : processSteps) {
				writeProcessStep(jsonGenerator, externalLinks, processStep);
			}
			jsonGenerator.writeEndArray();
		}
	}
	
	private void writeProcessStep(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProcessStepBean processStep) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeNameable(jsonGenerator, null, processStep);
		if(ObjectUtil.validCollection(processStep.getInput())) {
			writeInputOutputs(jsonGenerator, processStep.getInput(), true);
		}
		if(ObjectUtil.validCollection(processStep.getOutput())) {
			writeInputOutputs(jsonGenerator, processStep.getOutput(), false);
		}
		if(processStep.getComputation() != null) {
			writeComputation(jsonGenerator, processStep.getComputation());
		}
		if(ObjectUtil.validCollection(processStep.getTransitions())) {
			writeTransitions(jsonGenerator, externalLinks, processStep.getTransitions());
		}
		writeProcessSteps(jsonGenerator, externalLinks, processStep.getProcessSteps());
		
		jsonGenerator.writeEndObject();
	}
	
	private void writeInputOutputs(JsonGenerator jsonGenerator, List<InputOutputBean> inputOutputs, boolean isInput) throws JsonGenerationException, IOException {
		jsonGenerator.writeArrayFieldStart(isInput ? "inputs" : "outputs");
		for(InputOutputBean processStep : inputOutputs) {
			writeInputOutput(jsonGenerator, processStep);
		}
		jsonGenerator.writeEndArray();
	}
	
	private void writeInputOutput(JsonGenerator jsonGenerator, InputOutputBean inputOutput) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, inputOutput);
		if(inputOutput.getLocalId() != null) {
			jsonGenerator.writeStringField("localId", inputOutput.getLocalId());
		}
		if(inputOutput.getStructureReference() != null) {
			jsonGenerator.writeStringField("structure", inputOutput.getStructureReference().getTargetUrn());
		}
		jsonGenerator.writeEndObject();
	}
	
	private void writeComputation(JsonGenerator jsonGenerator, ComputationBean computation) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart("computation");
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, computation);
		if(computation.getLocalId() != null) {
			jsonGenerator.writeStringField("localId", computation.getLocalId());
		}
		if(computation.getSoftwareLanguage() != null) {
			jsonGenerator.writeStringField("softwareLanguage", computation.getSoftwareLanguage());
		}
		if(computation.getSoftwarePackage() != null) {
			jsonGenerator.writeStringField("softwarePackage", computation.getSoftwarePackage());
		}
		if(computation.getSoftwareVersion() != null) {
			jsonGenerator.writeStringField("softwareVersion", computation.getSoftwareVersion());
		}
		if(computation.getDescription() != null) {
			FusionJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, computation.getDescription(), "description");
		}
		jsonGenerator.writeEndObject();
	}
	
	private void writeTransitions(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<TransitionBean> transition) throws JsonGenerationException, IOException {
		jsonGenerator.writeArrayFieldStart("transitions");
		for(TransitionBean processStep : transition) {
			writeTransition(jsonGenerator, externalLinks, processStep);
		}
		jsonGenerator.writeEndArray();
	}
	
	private void writeTransition(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, TransitionBean transition) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeIdentifiable(jsonGenerator, externalLinks,  transition);
		if(transition.getLocalId() != null) {
			jsonGenerator.writeStringField("localId", transition.getLocalId());
		}
		if(transition.getTargetStep() != null) {
			jsonGenerator.writeStringField("targetStep", transition.getTargetStep().getFullIdPath(false));
		}
		if(transition.getCondition() != null) {
			FusionJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, transition.getCondition(), "condition");
		}
		jsonGenerator.writeEndObject();
	}
	
}
