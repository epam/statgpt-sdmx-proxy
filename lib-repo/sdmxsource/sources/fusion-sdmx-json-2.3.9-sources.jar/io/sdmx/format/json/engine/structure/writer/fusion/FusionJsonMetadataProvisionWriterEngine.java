package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonMetadataProvisionWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<MetadataProvisionAgreementBean> implements IFusionSingleton {
	private static FusionJsonMetadataProvisionWriterEngine INSTANCE;

	public static FusionJsonMetadataProvisionWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataProvisionWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonMetadataProvisionWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVISION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataProvisionAgreementBean aProvisionAgreement) throws JsonGenerationException, IOException {
		ICrossReferenceBean<MetadataFlowBean> structureUseage = aProvisionAgreement.getMetadataflowRef();
		jsonGenerator.writeStringField("metadataflowRef", structureUseage.getReference().getURN());

		ICrossReferenceBean<IMetadataProviderBean> dataProviderRef = aProvisionAgreement.getMetadataProviderRef();
		jsonGenerator.writeStringField("metadataproviderRef", dataProviderRef.getTargetUrn());
		jsonGenerator.writeArrayFieldStart("targets");
		for(ICrossReferenceBeanBase sRef : aProvisionAgreement.getTargets()) {
			jsonGenerator.writeString(sRef.getReference().getURN());
		}
		jsonGenerator.writeEndArray();
	}
}
