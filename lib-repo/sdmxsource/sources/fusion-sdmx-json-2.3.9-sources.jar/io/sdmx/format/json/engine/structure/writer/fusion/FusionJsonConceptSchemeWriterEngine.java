package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonConceptSchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<ConceptSchemeBean> implements IFusionSingleton {
	private static FusionJsonConceptSchemeWriterEngine INSTANCE;

	public static FusionJsonConceptSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonConceptSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonConceptSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException  {
		ConceptBean concept = (ConceptBean)item;
		FusionJsonConceptWriterEngine.getInstance().writeStructureInternal(jsonGenerator, externalLinks, concept);
		if(concept.getParentConcept() != null) {
			jsonGenerator.writeStringField("parentConcept", concept.getParentConcept());
		}
		if(concept.getIsoConceptReference() != null) {
			jsonGenerator.writeStringField("isoConceptReference", concept.getIsoConceptReference().getTargetUrn());
		}
	}
}
