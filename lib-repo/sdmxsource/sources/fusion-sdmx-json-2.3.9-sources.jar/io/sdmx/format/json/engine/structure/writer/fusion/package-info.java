/**
 * TODO: Rename this and classes from RegistryJson to FusionJson
 */
package io.sdmx.format.json.engine.structure.writer.fusion;