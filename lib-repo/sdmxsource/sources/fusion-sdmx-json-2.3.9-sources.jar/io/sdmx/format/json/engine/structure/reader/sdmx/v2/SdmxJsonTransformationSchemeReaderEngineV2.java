package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.GenericJsonReaderUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.TransformationMutableBean;
import io.sdmx.im.mutable.transformation.TransformationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonTransformationSchemeReaderEngineV2  extends SdmxJsonVtlSchemeReaderEngine<ITransformationMutableBean, ITransformationSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonTransformationSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonTransformationSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonTransformationSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "transformationSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ITransformationSchemeBean.class;
    }

    @Override
    protected ITransformationSchemeMutableBean getMutable() {
        return new TransformationSchemeMutableBean();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ITransformationSchemeMutableBean mutable, JsonReader reader) {
		if("vtlMappingScheme".equals(fieldName)) {
			mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
			return true;
		}
		if("namePersonalisationScheme".equals(fieldName)) {
			mutable.setNamePersonalisationSchemeRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
			return true;
		}
		if("customTypeScheme".equals(fieldName)) {
			mutable.setCustomTypeSchemeRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
			return true;
		}
		if("rulesetSchemes".equals(fieldName)) {
			mutable.setRulesetSchemeRef(GenericJsonReaderUtil.readRefArray(reader));
			return true;
		}
		if("userDefinedOperatorSchemes".equals(fieldName)) {
			mutable.setUserDefinedOperatorSchemeRef(GenericJsonReaderUtil.readRefArray(reader));
			return true;
		}
		return super.processMaintainableProperty(fieldName, mutable, reader);
	}

	@Override
	protected List<ITransformationMutableBean> readItems(JsonReader jReader) {
		List<ITransformationMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ITransformationMutableBean mutable = readTransformation(jReader);
				returnList.add(mutable);
			}
		}
		return returnList;
	}
	
	private ITransformationMutableBean readTransformation(JsonReader jReader) {
		ITransformationMutableBean mutable = new TransformationMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(mutable, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "expression" :
				mutable.setExpression(jReader.getValueAsString());
				break;
			case "result" :
				mutable.setResult(jReader.getValueAsString());
				break;
			case "isPersistent" :
				mutable.setPersistent(jReader.getValueAsBoolean());
				break;
			}
		}
		return mutable;
	}
	
	@Override
	protected String getItemLabel() {
		return "transformations";
	}
}