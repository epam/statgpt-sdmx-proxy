package io.sdmx.format.json.engine.data.writer.fusionjson;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonDataWriterEngine extends DataWriterEngineProxy {
	private static final Logger LOG = LoggerFactory.getLogger(FusionJsonDataWriterEngine.class);

	protected OutputStream out;
	protected HeaderBean header;
	protected boolean headerWritten = false;
	protected SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	protected JsonGenerator jsonGenerator;

	protected boolean forceFlat;  //If true, then the output will always be flat

	public FusionJsonDataWriterEngine(OutputStream out, SdmxSuperBeanRetrievalManager superBeanRetrievalManager, boolean forceFlat) {
		this(null, out, superBeanRetrievalManager, null, forceFlat);
	}
	
	public FusionJsonDataWriterEngine(DataFormat df, 
			OutputStream out, 
			SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
			SdmxBeanRetrievalManager beanRetrievalManager,
			boolean forceFlat) {
		this.out = out;
		this.forceFlat = forceFlat;
		JsonFactory factory = new JsonFactory();
		try {
			jsonGenerator = factory.createGenerator(out, JsonEncoding.UTF8);
			jsonGenerator.writeStartObject();//The container for the message
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		this.superBeanRetrievalManager = superBeanRetrievalManager;
	}

	@Override
	public void writeHeader(HeaderBean header) {
		this.header = header;
		// Don't attempt to write the header yet, since the internalWriter object has not been set up.
		// The header will be written by the JSON DataWriterEngines before the first Dataset is written
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if(!headerWritten) {
			writeDocumentHeader();
			//End Header
			headerWritten = true;
			// Create the appropriate internal writer
			String dimensionAtObservation = null;
			if(header != null && header.getDataStructureReference() != null) {
				dimensionAtObservation = header.getDataStructureReference().getDimensionAtObservation();
			}
			if(!ObjectUtil.validString(dimensionAtObservation)) {
				dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
			}

			if (forceFlat || DatasetStructureReferenceBean.ALL_DIMENSIONS.equals(dimensionAtObservation)) {
				// FLAT
				super.setProxy(new FlatDataWriter(jsonGenerator, this.header, superBeanRetrievalManager));
			} else {
				// SERIES
				super.setProxy(new SeriesDataWriter(jsonGenerator, this.header, superBeanRetrievalManager));
			}
		}
		super.startDataset(structures, header, datasetAttributes, annotations);
	}

	protected void writeDocumentHeader() {
		try {
			String id;
			Date prepared;
			boolean isTest;
			if(header != null) {
				id = header.getId();
				prepared = header.getPrepared();
				isTest = header.isTest();
			} else {
				id =  UUID.randomUUID().toString();
				prepared = new Date();
				isTest = false;
			}
			LOG.debug("{Header}");
			jsonGenerator.writeObjectFieldStart("header");
			jsonGenerator.writeStringField("id", id);
			jsonGenerator.writeStringField("prepared", DateUtil.formatDate(prepared, TIME_FORMAT.DATE_TIME));
			jsonGenerator.writeBooleanField("test", isTest);

			writeSender();
			writeReceiver();
			//			writeLinks();

			jsonGenerator.writeEndObject();
			LOG.debug("{/Header}");

			headerWritten = true;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	
	protected void writeSender() throws JsonGenerationException, IOException {
		LOG.debug("{sender}");
		jsonGenerator.writeObjectFieldStart("sender");

		PartyBean sender = null;
		if (header != null) {
			sender = header.getSender();
		}
		writeContactDetails(sender);

		LOG.debug("{/sender}");
		jsonGenerator.writeEndObject();
	}

	protected void writeReceiver() throws JsonGenerationException, IOException {
		if (header == null || !ObjectUtil.validCollection(header.getReceiver())) {
			// Do not write receiver since it's empty
			return;
		}

		LOG.debug("{receiver}");
		jsonGenerator.writeObjectFieldStart("receiver");

		// Simply use the first receiver
		PartyBean receiver = header.getReceiver().get(0);
		writeContactDetails(receiver);

		LOG.debug("{/receiver}");
		jsonGenerator.writeEndObject();
	}

	private void writeContactDetails(PartyBean partyBean) throws JsonGenerationException, IOException {
		String senderName = null;
		String senderId = "unknown";
		if(partyBean != null) {
			senderId = partyBean.getId();
			if(ObjectUtil.validCollection(partyBean.getName())) {
				senderName = partyBean.getName().get(0).getValue();
			}
		}
		jsonGenerator.writeStringField("id", senderId);
		
		if (senderName != null) {
			jsonGenerator.writeStringField("name", senderName);
		}
	}

	@Override
	public void close(FooterMessage... footer) {
		try {
			super.close(footer);
		} finally {
			StreamUtil.closeStream(out);
		}
	}
}