package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.codelist.HierarchyAssociationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonHierarchyAssociationReaderEngineV2 extends AbstractSdmxJsonReaderEngine<HierarchyAssociationMutableBean> implements IFusionSingleton {
	private static SdmxJsonHierarchyAssociationReaderEngineV2 INSTANCE;

	public static SdmxJsonHierarchyAssociationReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonHierarchyAssociationReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "hierarchyAssociations";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return HierarchyAssociationBean.class;
    }

    @Override
    protected HierarchyAssociationMutableBean getMutable() {
        return new HierarchyAssociationMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, HierarchyAssociationMutableBean mutable, JsonReader reader) {
        switch(fieldName) {
        case "linkedHierarchy":
            mutable.setHierarchyRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "linkedObject":
            mutable.setLinkedStructure(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "contextObject":
            mutable.setContextStructure(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        }
        return false;
    }
}
