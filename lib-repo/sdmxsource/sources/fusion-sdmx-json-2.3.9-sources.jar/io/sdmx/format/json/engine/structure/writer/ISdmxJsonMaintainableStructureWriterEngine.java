package io.sdmx.format.json.engine.structure.writer;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface ISdmxJsonMaintainableStructureWriterEngine <T extends MaintainableBean> extends JsonMaintainableStructureWriterEngine<T> {

}
