package io.sdmx.format.json.engine.data.reader;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.json.JsonReader.Iterator;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.im.beans.base.AnnotationBeanImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;

public class AnnotationsIterator extends AbstractIterator {
    private List<AnnotationBean> annotations = new ArrayList<>();
    private AnnotationMutableBean annotation = null;
    
	public AnnotationsIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	@Override
	public void next(String fieldName) {
		if(annotation == null) {
			return;
		}
		if("title".equals(fieldName)) {
			annotation.setTitle(jReader.getValueAsString());
		} else if("type".equals(fieldName)) {
			annotation.setType(jReader.getValueAsString());
		} else if("uri".equals(fieldName)) {
			annotation.setUri(jReader.getValueAsString());
		} else if("text".equals(fieldName)) {
			annotation.addText("en", jReader.getValueAsString());
		} else if("id".equals(fieldName)) {
			annotation.setId(jReader.getValueAsString());
		}
	}

	@Override
	public Iterator start(String fieldName, boolean isObject) {
		annotation = new AnnotationMutableBeanImpl();
		 return this;
	}

	@Override
	public void end(String fieldName, boolean isObject) {
		if(annotation != null) {
			annotations.add(new AnnotationBeanImpl(annotation, null));
			annotation = null;
		}
 	}

	public List<AnnotationBean> getAnnotations() {
		return annotations;
	}
}
