package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorMutableBean;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonUserDefinedOperatorSchemeReaderEngine extends FusionJsonAbstractVTLSchemeReaderEngine<IUserDefinedOperatorSchemeBean, IUserDefinedOperatorSchemeMutableBean, IUserDefinedOperatorMutableBean>
                                                            implements IFusionSingleton {
	private static FusionJsonUserDefinedOperatorSchemeReaderEngine INSTANCE;


	public static FusionJsonUserDefinedOperatorSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonUserDefinedOperatorSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IUserDefinedOperatorSchemeMutableBean getMutable() {
		return new UserDefinedOperatorSchemeMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IUserDefinedOperatorSchemeMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			switch(fieldName) {
			case "vtlMappingScheme" :
				mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			case "rulesetSchemes" :
				mutable.setRulesetSchemeRef(processSRefArray(jReader));
				break;
			default : return false;
			}
		}
		return true;
	}

	@Override
	protected IUserDefinedOperatorMutableBean readItemBean(JsonReader jReader) {
		IUserDefinedOperatorMutableBean item =  new UserDefinedOperatorMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(item, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("operatorDefinition")) {
				item.setOperatorDefinition(value);
			}
		}
		return item;
	}

    @Override
    protected Class<IUserDefinedOperatorSchemeBean> getMaintainableType() {
        return IUserDefinedOperatorSchemeBean.class;
    }
}
