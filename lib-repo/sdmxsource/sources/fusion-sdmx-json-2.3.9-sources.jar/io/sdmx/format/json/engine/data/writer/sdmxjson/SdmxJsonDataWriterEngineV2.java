package io.sdmx.format.json.engine.data.writer.sdmxjson;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.engine.data.writer.fusionjson.FusionJsonDataWriterEngine;
import io.sdmx.format.json.model.FusionJsonDataFormat;
import io.sdmx.format.json.model.SdmxJsonDataFormat;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonDataWriterEngineV2 extends FusionJsonDataWriterEngine {

	private static final Logger LOG = LoggerFactory.getLogger(SdmxJsonDataWriterEngineV2.class);

	private IRESTGET rdq;

	public SdmxJsonDataWriterEngineV2(OutputStream out, SdmxSuperBeanRetrievalManager superBeanRetrievalManager, boolean forceFlat) {
		this(null, out, superBeanRetrievalManager, null, forceFlat);
	}

	public SdmxJsonDataWriterEngineV2(DataFormat df,
									  OutputStream out,
									  SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
									  SdmxBeanRetrievalManager beanRetrievalManager,
									  boolean forceFlat) {
		super(df, out, superBeanRetrievalManager, beanRetrievalManager, forceFlat);
		if (df != null && (df instanceof FusionJsonDataFormat || df instanceof SdmxJsonDataFormat)) {
			if (df instanceof FusionJsonDataFormat) {
				rdq = ((FusionJsonDataFormat) df).getRestDataQuery();
			} else {
				rdq = ((SdmxJsonDataFormat) df).getRestDataQuery();
			}
		}
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if (!headerWritten) {
			writeDocumentHeader();
			// End Header
			headerWritten = true;
			// Create the appropriate internal writer
			String dimensionAtObservation = null;
			if (header != null && header.getDataStructureReference() != null) {
				dimensionAtObservation = header.getDataStructureReference().getDimensionAtObservation();
			}
			if (!ObjectUtil.validString(dimensionAtObservation)) {
				dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
			}
			try {
				jsonGenerator.writeObjectFieldStart("data");
				if (forceFlat || DatasetStructureReferenceBean.ALL_DIMENSIONS.equals(dimensionAtObservation)) {
					// FLAT
					super.setProxy(new SdmxJsonFlatDataWriterV2(jsonGenerator, this.header, superBeanRetrievalManager));
				} else {
					// SERIES
					super.setProxy(new SdmxJsonSeriesDataWriterV2(jsonGenerator, this.header, superBeanRetrievalManager));
				}
			} catch (IOException e) {
				throw new SdmxException(e, e.getMessage());
			}
		}
		getProxy().startDataset(structures, header, datasetAttributes, annotations);
	}

	@Override
	protected void writeDocumentHeader() {
		try {
			String id;
			Date prepared;
			boolean isTest;
			if (header != null) {
				id = header.getId();
				prepared = header.getPrepared();
				isTest = header.isTest();
			} else {
				id = UUID.randomUUID().toString();
				prepared = new Date();
				isTest = false;
			}
			LOG.debug("{meta}");
			jsonGenerator.writeObjectFieldStart("meta");
			jsonGenerator.writeStringField("id", id);
			jsonGenerator.writeStringField("prepared", DateUtil.formatDate(prepared, TIME_FORMAT.DATE_TIME));
			jsonGenerator.writeBooleanField("test", isTest);
			if (header != null) {
				String headerVal;
				if (ObjectUtil.validString(header.getDatasetId())) {
					headerVal = header.getDatasetId();
				} else {
					headerVal = UUID.randomUUID().toString();
				}
				jsonGenerator.writeStringField("datasetId", headerVal);
			}

			writeSender();
			writeReceiver();
			if (this.rdq != null) {
				String restQuery = this.rdq.toString();
				ILinkBean link;
				try {
					link = new LinkBean("self", new URI(restQuery), new URI(SDMX_JSON_SCHEMA.DATA_V2), null, null, null);
					SdmxJsonWriterUtils.writeLinks(Arrays.asList(link), jsonGenerator);
				} catch (URISyntaxException e) {
					e.printStackTrace();
				}
			}

			jsonGenerator.writeEndObject();
			LOG.debug("{/Header}");

			headerWritten = true;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}