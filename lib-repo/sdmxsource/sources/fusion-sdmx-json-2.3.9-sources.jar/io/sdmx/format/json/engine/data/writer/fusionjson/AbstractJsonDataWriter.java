package io.sdmx.format.json.engine.data.writer.fusionjson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATA_POSITION;
import io.sdmx.api.sdmx.constants.DIMENSION_AT_OBSERVATION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.MeasureSuperBean;
import io.sdmx.core.data.engine.writer.DatasetInfoDataWriterEngine;
import io.sdmx.core.sdmx.empty.EmptySeriesObsDataWriterEngine;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public abstract class AbstractJsonDataWriter extends DataWriterEngineProxy {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractJsonDataWriter.class);

	protected String currentKey;
	protected String prevKey;

	protected JsonGenerator jsonGenerator;
	protected HeaderBean header;

	protected boolean headerWritten = false;

	private SdmxSuperBeanRetrievalManager superBeanRetrieval;
	private List<IDatasetStructures> datasetStructs = new ArrayList<>();
	private List<DatasetInfoDataWriterEngine> datasetInfos = new ArrayList<>();
	protected DatasetInfoDataWriterEngine currentDatasetInfo;
	
	protected List<AnnotationBean> annotations = new ArrayList<>();

	private IDatasetAttributes datasetAttributes;
	private List<String> keyOrder;

	private DataflowBean flow;
	protected DataStructureBean dsd;
	protected String dimensionAtObservation;
	
	private DATA_POSITION pos = DATA_POSITION.DATASET;
	
	public AbstractJsonDataWriter(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrieval) {
		super(EmptySeriesObsDataWriterEngine.INSTANCE);
		this.superBeanRetrieval = superBeanRetrieval;
		this.jsonGenerator = jsonGenerator;
		this.header = header;
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... ann) {
		datasetStructs.add(structures);
		this.datasetAttributes = datasetAttributes == null ? DatasetAttributes.EMPTY_ATTRIBUTES : datasetAttributes;
		this.dsd = structures.getDataStructure();
		this.flow = structures.getDataflow();

		if (currentDatasetInfo == null) {
			currentDatasetInfo = new DatasetInfoDataWriterEngine(superBeanRetrieval);
			datasetInfos.add(currentDatasetInfo);
			super.setProxy(currentDatasetInfo);
		}

		if (currentDatasetInfo.getCurrentDSDSuperBean() != null && !currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().deepEquals(dsd, true)) {
			if (!isSdmxJsonV2()) {
				throw new SdmxNotImplementedException("JSON V1 does not support multiple structures");
			}
			DatasetInfoDataWriterEngine newDatasetInfo = new DatasetInfoDataWriterEngine(superBeanRetrieval);
			currentDatasetInfo = newDatasetInfo;
			datasetInfos.add(newDatasetInfo);
			super.setProxy(newDatasetInfo);
		}
		
		super.startDataset(structures, datasetHeader, datasetAttributes, ann);
		
		if(ann != null) {
			for (AnnotationBean annotationBean : ann) {
				if(annotationBean != null) {
					if(annotations.indexOf(annotationBean) < 0) {
						annotations.add(annotationBean);
					}
				}
			}
		}

		if(datasetHeader != null && datasetHeader.getDataStructureReference() != null) {
			this.dimensionAtObservation = datasetHeader.getDataStructureReference().getDimensionAtObservation();
		}
		if(!ObjectUtil.validString(dimensionAtObservation)) {
			if(dsd.getTimeDimension() != null) {
				this.dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
			} else {
				this.dimensionAtObservation = DIMENSION_AT_OBSERVATION.ALL.getVal();
			}
		}
	
		if(dsd != null) {
			keyOrder = new ArrayList<>();
			String dimAtObs = null;
			if(datasetHeader != null &&  datasetHeader.getDataStructureReference() != null) {
				dimAtObs = datasetHeader.getDataStructureReference().getDimensionAtObservation();
			}
			for(DimensionBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
				if(!dim.getId().equals(dimAtObs)) {
					keyOrder.add(dim.getId());
				}
			}

			if(dimAtObs != null &&
					dsd.getTimeDimension() != null &&
					(!DimensionBean.TIME_DIMENSION_FIXED_ID.equals(dimAtObs) && !dimAtObs.equalsIgnoreCase("AllDimensions") )) {
				keyOrder.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
			}
		}
		try {
			if(pos != DATA_POSITION.DATASET) {
				if(!currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().equals(dsd)) {
					throw new SdmxNotImplementedException("JSON Does not support multiple datasets conforming to different data structures");
				}
				prevKey = null;
				currentKey = null;
				if(this instanceof FlatDataWriter) {
					//END DataSet
					LOG.debug("{/observations}");
					jsonGenerator.writeEndObject(); //End observations

					writeDatasetAttributes();

					LOG.debug("{/dataset}");
					jsonGenerator.writeEndObject(); //End dataset
				} else {
					if(pos == DATA_POSITION.OBSERVATION) {
						LOG.debug("{/observations}");
						jsonGenerator.writeEndObject();  // End the current Observation object
					}
					//
					LOG.debug("{/0:0:0}");
					jsonGenerator.writeEndObject();  // End observations
					//
					LOG.debug("{/series}");
					jsonGenerator.writeEndObject();  // End the current series object

					writeDatasetAttributes();
					//
					LOG.debug("{/}");
					jsonGenerator.writeEndObject();  //End the dataset tag
				}

			}  else {
				LOG.debug("[dataSets]");

				jsonGenerator.writeArrayFieldStart("dataSets");
				// Start the JSON "datasSets" section
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		datasetAttributes = null;
		writeJsonDataSet(datasetHeader, ann);
		pos = DATA_POSITION.DATASET;
	}

	protected void writeDatasetAttributes() throws IOException {
		if(ObjectUtil.validCollection(datasetAttributes.getAttributes())) {
			LOG.debug("[attributes]");
			jsonGenerator.writeArrayFieldStart("attributes");
			for(KeyValue dsAttr : datasetAttributes.getAttributes()) {
				jsonGenerator.writeNumber(currentDatasetInfo.getReportedIndex(dsAttr.getConcept(), dsAttr.getCode()));
			}
			LOG.debug("[/attributes]");
			jsonGenerator.writeEndArray();
		}
	}

	@Override
	public void writeKey(Keyable key) {
		pos = DATA_POSITION.SERIES_KEY;
		super.writeKey(key);
		StringBuilder sb = new StringBuilder();

		String delimiter = "";
		for(String dimId : keyOrder) {
			String reportedval = key.getReportedValue(dimId);

			int currentIndex = currentDatasetInfo.getReportedIndex(dimId, reportedval);
			sb.append(delimiter + currentIndex);
			delimiter = ":";
		}
		if (currentKey != null) {
			prevKey = currentKey.toString();
		}
		currentKey = sb.toString();
	}
	
	@Override
	public void writeObservation(Observation obs) {
		pos = DATA_POSITION.OBSERVATION;
		super.writeObservation(obs);
	}

	private void writeAnnotations() throws JsonGenerationException, IOException {
		if(ObjectUtil.validCollection(annotations)) {
			jsonGenerator.writeArrayFieldStart("annotations");
			for(AnnotationBean annotation : annotations) {
				writeAnnotation(annotation);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeAnnotation(AnnotationBean annotation) throws IOException {
		LOG.debug("{start annotations}");
		jsonGenerator.writeStartObject();

		if(annotation.getId() != null) {
			jsonGenerator.writeStringField("id", annotation.getId());
		}
		if(annotation.getTitle() != null) {
			jsonGenerator.writeStringField("title", annotation.getTitle());
		}
		if(annotation.getType() != null) {
			jsonGenerator.writeStringField("type", annotation.getType());
		}
		if(annotation.getUri() != null) {
			jsonGenerator.writeStringField("uri", annotation.getUri().toString());
		}

		if(annotation.getText().size() > 0) {
			List<TextTypeWrapper> text = annotation.getText();
			TextTypeWrapper defaultLocale = TextTypeUtil.getDefaultLocale(text);
			jsonGenerator.writeStringField("text", defaultLocale.getValue());
		}

		LOG.debug("{/}");
		jsonGenerator.writeEndObject();
	}

	protected void writeStructure(boolean wrapJsonNode) throws JsonGenerationException, IOException {
		if (isSdmxJsonV2()) {
			// write data.structures - array of structure objects

			for (DatasetInfoDataWriterEngine di : datasetInfos) {
				currentDatasetInfo = di;
				dsd = di.getCurrentDSDSuperBean().getBuiltFrom();
				
				jsonGenerator.writeStartObject();
				LOG.debug("{structure}");

				// write structure.links
				List<ILinkBean> links = new ArrayList<>();
				ConstrainableBean con = di.getStructures().getConstrainable();
				MaintainableBean maint = con.getMaintainableParent();
				links.add(new LinkBean(maint));
				SdmxJsonStaticHelper.writeLinks(links, jsonGenerator, true);

				if (this instanceof IJsonWriterMarker) {
					((IJsonWriterMarker) this).writeTextType(maint.getNames(), "names");
					((IJsonWriterMarker) this).writeTextType(maint.getDescriptions(), "descriptions");
				} else {
					jsonGenerator.writeStringField("name", maint.getName());
					jsonGenerator.writeStringField("description", maint.getDescription());
				}
				writeStructureDimensions();
				writeAttributes();
				writeStructureMeasures();
				writeAnnotations();

				// write structure.dataSets
				jsonGenerator.writeArrayFieldStart("dataSets");
				for (int i = 0; i < datasetStructs.size(); i++) {
					if (datasetStructs.get(i).getDataStructure().deepEquals(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom(), true)) {
						jsonGenerator.writeNumber(i);
					}
				}
				jsonGenerator.writeEndArray();

				LOG.debug("{/structure}");
				jsonGenerator.writeEndObject();
			}
		} else {
			// write data.structure - single structure object

			LOG.debug("{structure}");
			if (wrapJsonNode) {
				jsonGenerator.writeObjectFieldStart("structure");
			}

			ConstrainableBean con = currentDatasetInfo.getStructures().getConstrainable();
			MaintainableBean maint = con.getMaintainableParent();

			if (this instanceof IJsonWriterMarker) {
				((IJsonWriterMarker) this).writeTextType(maint.getNames(), "names");
				((IJsonWriterMarker) this).writeTextType(maint.getDescriptions(), "descriptions");
			} else {
				jsonGenerator.writeStringField("name", maint.getName());
				jsonGenerator.writeStringField("description", maint.getDescription());
			}
			writeStructureDimensions();
			writeAttributes();
			writeAnnotations();

			if (wrapJsonNode) {
				LOG.debug("{/structure}");
				jsonGenerator.writeEndObject();
			}
		}
	}

	protected void writeJsonDataSet(DatasetHeaderBean datasetHeader, AnnotationBean... ann) {
		try {
			LOG.debug("{start dataset}");
			jsonGenerator.writeStartObject();
			if(this instanceof IJsonWriterMarker && this.flow != null) {
				((IJsonWriterMarker)this).writeLink(Arrays.asList(new LinkBean(this.flow)));
			}
			DATASET_ACTION action = DATASET_ACTION.INFORMATION;
			if(datasetHeader != null) {
				action = datasetHeader.getAction();

				// Write the reporting begin date if possible
				Date reportingBeginDate;
				if (datasetHeader.getReportingBeginDate() != null) {
					reportingBeginDate = datasetHeader.getReportingBeginDate();
				} else {
					if (header == null) {
						reportingBeginDate = null;
					} else {
						reportingBeginDate = header.getReportingBegin();
					}
				}
				if (reportingBeginDate != null) {
					jsonGenerator.writeStringField("reportingBegin", DateUtil.formatDate(reportingBeginDate));
				}

				// Write the reporting end date if possible
				Date reportingEndDate;
				if (datasetHeader.getReportingEndDate() != null) {
					reportingEndDate = datasetHeader.getReportingEndDate();
				} else {
					if (header == null) {
						reportingEndDate = null;
					} else {
						reportingEndDate = header.getReportingEnd();
					}
				}
				if (reportingEndDate != null) {
					jsonGenerator.writeStringField("reportingEnd", DateUtil.formatDate(reportingEndDate));
				}

				if (datasetHeader.getValidFrom() != null) {
					jsonGenerator.writeStringField("validFrom", DateUtil.formatDate(datasetHeader.getValidFrom()));
				}
				if (datasetHeader.getValidTo() != null) {
					jsonGenerator.writeStringField("validTo", DateUtil.formatDate(datasetHeader.getValidTo()));
				}
				if (datasetHeader.getPublicationYear() > 0) {
					jsonGenerator.writeNumberField("publicationYear", datasetHeader.getPublicationYear());
				}
				if (ObjectUtil.validString(datasetHeader.getPublicationPeriod())) {
					jsonGenerator.writeStringField("publicationPeriod", datasetHeader.getPublicationPeriod());
				}
			}

			// write dataSets.structure
			if (isSdmxJsonV2()) {
				jsonGenerator.writeNumberField("structure", datasetInfos.indexOf(currentDatasetInfo));
			}
			
			jsonGenerator.writeStringField("action", action.getAction());

			if(ann != null && ann.length > 0) {
				LOG.debug("[annotations]");
				jsonGenerator.writeArrayFieldStart("annotations");

				// Write the annotation values
				for(AnnotationBean currentAnnotation : ann) {
					int idx = annotations.indexOf(currentAnnotation);
					jsonGenerator.writeNumber(idx);
				}
				LOG.debug("[/annotations]");
				jsonGenerator.writeEndArray();
			}


		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}

	protected void writeAttributes(List<AttributeBean> attributes, List<KeyValue>... reportedValues) throws IOException {
		// Write the attribute values (or null)
		Map<String, List<String>> attrKeyValues = new HashMap<>();

		for (List<KeyValue> repVals : reportedValues) {
			for (KeyValue kv : repVals) {
				if (kv.hasMultipleValues()) {
					attrKeyValues.put(kv.getConcept(), kv.getValues());
				} else {
					attrKeyValues.put(kv.getConcept(), new ArrayList<>(Collections.singletonList(kv.getCode())));
				}
			}
		}
		
		// Check to see if ALL of the attributes has a non-null value
		boolean allNulls = true;
		for(AttributeBean attr : attributes) {
			if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET) {
				continue;
			}
			if(attrKeyValues.get(attr.getId()) != null) {
				allNulls = false;
				break;
			}
		}

		if (allNulls) {
			// All values are null, so don't output anything
			return;
		}
		
		for (AttributeBean attr : attributes) {
			if (attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET) {
				continue;
			}

			String attrId = attr.getId();
			List<String> vals = attrKeyValues.get(attrId);
			if (vals == null) {
				jsonGenerator.writeNull();
			} else if (vals.size() == 1) {
				int idx = currentDatasetInfo.getReportedIndex(attrId, vals.get(0));
				jsonGenerator.writeNumber(idx);
				attrKeyValues.remove(attrId);
			} else {
				int[] idxs = new int[vals.size()];
				for (int i = 0; i < vals.size(); i++) {
					idxs[i] = currentDatasetInfo.getReportedIndex(attrId, vals.get(i));
				}
				jsonGenerator.writeArray(idxs, 0, idxs.length);
				attrKeyValues.remove(attrId);
			}
		}

		for (String additionalKey : attrKeyValues.keySet()) {
			if (dsd.getComponent(additionalKey) == null) {
				int idx = currentDatasetInfo.getReportedIndex(additionalKey, attrKeyValues.get(additionalKey).get(0));
				jsonGenerator.writeNumber(idx);
			}
		}
	}

	abstract protected void writeAttributes() throws JsonGenerationException, IOException;
	abstract protected void writeDimensionsSeries() throws JsonGenerationException, IOException;
	abstract protected void writeDimensionsObservation() throws JsonGenerationException, IOException;
	abstract protected boolean isSdmxJsonV2();

	/**
	 * Writing the JSON section:
	 * (root) --> structure --> dimensions
	 */
	protected void writeStructureDimensions() throws JsonGenerationException, IOException {
		LOG.debug("{dimensions}");
		jsonGenerator.writeObjectFieldStart("dimensions");

		writeDimensionsDataset();
		writeDimensionsSeries();
		writeDimensionsObservation();

		LOG.debug("{/dimensions}");
		jsonGenerator.writeEndObject();
	}


	private void writeDimensionsDataset() throws JsonGenerationException, IOException {
		// NOTE: In this release we are not writing this section.  Instead this information can be located under: root -> datasets
		jsonGenerator.writeArrayFieldStart("dataset");

		jsonGenerator.writeEndArray(); //End the dataset array
	}

	protected void writeStructureMeasures() throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart("measures");
		jsonGenerator.writeArrayFieldStart("observation");

		for (MeasureSuperBean msb : currentDatasetInfo.getCurrentDSDSuperBean().getMeasures()) {
			writeComponent(msb, -1);
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}
	
	protected void writeAdditionalAttributes(List<String> attributes) {
		try {
			for(String additionalAttributes : attributes) {
				LOG.debug("{start attribute}");
				jsonGenerator.writeStartObject(); // Start component
				jsonGenerator.writeStringField("id", additionalAttributes);
				jsonGenerator.writeStringField("name", additionalAttributes);

				LOG.debug("[values]");
				jsonGenerator.writeArrayFieldStart("values");
				List<String> allCodes = currentDatasetInfo.getReportedValues(additionalAttributes);

				for(String currentCode : allCodes) {
					writeCode(currentCode, false, null);
				}

				LOG.debug("[/values]");
				jsonGenerator.writeEndArray();
				LOG.debug("{/}");
				jsonGenerator.writeEndObject(); // End component
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected void writeComponent(ComponentSuperBean component, int position) throws JsonGenerationException, IOException {
		LOG.debug("{start component}");
		jsonGenerator.writeStartObject(); // Start component
		jsonGenerator.writeStringField("id", component.getId());
		jsonGenerator.writeStringField("name", component.getConcept().getBuiltFrom().getName());
		if(component.getConcept().getBuiltFrom().getDescription() != null) {
			jsonGenerator.writeStringField("description", component.getConcept().getBuiltFrom().getDescription());
		}

		if(position >= 0) {
			jsonGenerator.writeNumberField("keyPosition", position);
		}
		if(this instanceof IJsonWriterMarker && component instanceof AttributeSuperBean) {
			jsonGenerator.writeObjectFieldStart("relationship");
			AttributeSuperBean superCast = ((AttributeSuperBean) component);
			AttributeBean cast = superCast.getBuiltFrom();
			ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel = cast.getAttachmentLevel();
			switch(attachmentLevel) {
			case DATA_SET:
				jsonGenerator.writeObjectFieldStart("none");
				jsonGenerator.writeEndObject();
				break;
			case DIMENSION_GROUP:
				List<String> dimensionReferences = cast.getDimensionReferences();
				jsonGenerator.writeArrayFieldStart("dimensions");
				for (String string : dimensionReferences) {
					jsonGenerator.writeString(string);
				}
				jsonGenerator.writeEndArray();
				break;
			case GROUP:
				break;
			case OBSERVATION:
				//primaryMeasure
				for(String measure : cast.getMeasureReferences()) {
					if(measure.equals("OBS_VALUE")) {
						SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "primaryMeasure", measure);
					}
				}
				break;
			default:
				break;

			}
			jsonGenerator.writeEndObject();
		}

		boolean isTime = component.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID);
		if (isTime) {
			jsonGenerator.writeStringField("role", "time");
		} else {
			jsonGenerator.writeNullField("role");
		}

		List<String> allCodes = currentDatasetInfo.getReportedValues(component.getId());

		LOG.debug("[values]");
		jsonGenerator.writeArrayFieldStart("values");
		for (String currentCode : allCodes) {
			writeCode(currentCode, isTime, component);
		}
		LOG.debug("[/values]");
		jsonGenerator.writeEndArray();
		
		LOG.debug("{/}");
		jsonGenerator.writeEndObject(); // End component
	}

	protected void writeCode(String code, boolean isTime, ComponentSuperBean component) throws IOException {
		LOG.debug("{start code}");
		jsonGenerator.writeStartObject();  //Start code
		String id = code;
		String name = code;
		String description = null;
		if(isTime) {
			String start = DateUtil.formatDate(DateUtil.formatDate(code, true), TIME_FORMAT.DATE_TIME);
			String end = DateUtil.formatDate(DateUtil.formatDate(code, false), TIME_FORMAT.DATE_TIME);
			jsonGenerator.writeStringField("start", start);
			jsonGenerator.writeStringField("end", end);
		} else if(component != null){
			EnumeratedListBean<? extends EnumeratedItemBean> codelist = component.getCodelist(true);
			if(codelist != null) {
				EnumeratedItemBean codeBean = codelist.getItemById(code);
				if(codeBean != null) {
					id = codeBean.getId();
					name = codeBean.getName();
					description = codeBean.getDescription();
					if (includePosition()) {
					    jsonGenerator.writeNumberField("position", codeBean.getPosition());
					}
				}
			}
		}

		jsonGenerator.writeStringField("id", id);
		jsonGenerator.writeStringField("name", name);
		if(description != null) {
			jsonGenerator.writeStringField("description", description);
		}
		LOG.debug("{/}");
		jsonGenerator.writeEndObject(); //End code
	}

	/**
	 * @return whether the "position" attribute should be included when writing out coded items
	 */
	protected boolean includePosition() {
	    return true;
	}

	protected String getJsonGeneratorValue() throws IOException {
		this.jsonGenerator.flush();
		ByteArrayOutputStream outStr = (ByteArrayOutputStream)this.jsonGenerator.getOutputTarget();
		String value = new String(outStr.toByteArray(), StandardCharsets.UTF_8 );
		return value;
	}

	/**
	 * When writing JSON, this will allow links to be written at any point in the JSON creation
	 *
	 */
	public static interface IJsonWriterMarker{
		/**
		 * Write an array of links
		 * @param links
		 * @throws JsonGenerationException
		 * @throws IOException
		 */
		void writeLink(List<ILinkBean> links) throws JsonGenerationException, IOException;

		/**
		 *  Write both the name and the "names" array, the name tag will be written according to the localised best match text rules
		 * @param ttw
		 * @param type
		 * @throws JsonGenerationException
		 * @throws IOException
		 */
		void writeTextType(List<TextTypeWrapper> ttw, String type) throws JsonGenerationException, IOException;
	}

}
