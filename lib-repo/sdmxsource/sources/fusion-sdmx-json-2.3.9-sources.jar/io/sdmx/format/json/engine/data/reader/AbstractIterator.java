package io.sdmx.format.json.engine.data.reader;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.json.JsonReader.Iterator;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;

public class AbstractIterator implements JsonReader.Iterator {
	public JsonReader jReader;
	protected DataReaderExceptionHandler exceptionHandler;

	public AbstractIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		this.jReader = jReader;
		this.exceptionHandler = exceptionHandler;
	}

	@Override
	public void next(String fieldName) {
	}

	@Override
	public void end(String fieldName, boolean isObject) {

	}

	@Override
	public Iterator start(String fieldName, boolean isObject) {
		return null;
	}
}
