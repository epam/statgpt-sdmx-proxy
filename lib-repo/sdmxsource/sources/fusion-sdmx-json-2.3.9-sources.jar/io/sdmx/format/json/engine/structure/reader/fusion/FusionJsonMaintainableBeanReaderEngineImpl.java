package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.format.json.api.engine.FusionJsonMaintainableBeanReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonMaintainableUtil;
import io.sdmx.im.changecontrol.ChangeRequestHelper;
import io.sdmx.im.changecontrol.MaintainableMutableBeanWrapper;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public abstract class FusionJsonMaintainableBeanReaderEngineImpl<T extends MaintainableBean, V extends MaintainableMutableBean> implements FusionJsonMaintainableBeanReaderEngine<T> {

    @Override
    public String getContainerElement() {
        return getBuiltType().getUrnClass();
    }

    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(getMaintainableType());
    }
    
    protected abstract Class<T> getMaintainableType();
    
	@Override
	public void read(JsonReader jReader, SdmxBeans beans, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
		while (jReader.moveNext()) {
			if(jReader.isStartObject()) {
			    V mutable = build(jReader, beanRetrievalManager);
			    beanBuilder.build(mutable, beans);
			}
			if(jReader.isEndArray()) {
				break;
			}
		}
	}

	protected V build(JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
		V maint = getMutable();
		MaintainableMutableBeanWrapper mmbWrapper = new MaintainableMutableBeanWrapper(maint);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			if(!FusionJsonMaintainableUtil.processBean(mmbWrapper, jReader)) {
				String fieldName = jReader.getCurrentFieldName();
				if(!processMaintainableProperty(fieldName, maint, jReader, beanRetrievalManager)) {
					if(jReader.isStartArray()) {
						jReader.moveToEndArray();
					} else if(jReader.isStartObject()) {
						jReader.moveToEndObject();
					}
				}
			}
		}

		ChangeRequestHelper.determineChanges(mmbWrapper);
		return maint;
	}

	protected List<StructureReferenceBean> processSRefArray(JsonReader jReader) {
		List<StructureReferenceBean> returnArray = new ArrayList<>();
		for(String str : jReader.readStringArray()) {
			returnArray.add(new StructureReferenceBeanImpl(str));
		}
		return returnArray;
	}

	protected abstract V getMutable();

	protected boolean processMaintainableProperty(String fieldName, V mutable, JsonReader reader, SdmxBeanRetrievalManager beanRetrievalManager) {
		return processMaintainableProperty(fieldName, mutable, reader);
	}

	protected abstract boolean processMaintainableProperty(String fieldName, V mutable, JsonReader reader);
}
