package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeContainerBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonMetadataStructureWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<MetadataStructureDefinitionBean> implements IFusionSingleton {
	private static SdmxJsonMetadataStructureWriterEngineV2 INSTANCE;

	public static SdmxJsonMetadataStructureWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataStructureWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonMetadataStructureWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.MSD);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataStructureDefinitionBean mdp) throws JsonGenerationException, IOException {
		if(mdp.getMetadataAttributes() != null) {
			jsonGenerator.writeObjectFieldStart("metadataStructureComponents");
			jsonGenerator.writeObjectFieldStart("metadataAttributeList");
			jsonGenerator.writeStringField("id", "MetadataAttributeDescriptor");
			writeAttributes(jsonGenerator, externalLinks, mdp);
			jsonGenerator.writeEndObject();
			jsonGenerator.writeEndObject();
		}
	}

	private void writeAttributes(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataAttributeContainerBean attributeContainer) throws IOException {
		if(attributeContainer != null && attributeContainer.getMetadataAttributes().size() > 0) {
			jsonGenerator.writeArrayFieldStart("metadataAttributes");
			for(MetadataAttributeBean attribute : attributeContainer.getMetadataAttributes()) {
				writeAttribute(jsonGenerator, externalLinks, attribute);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeAttribute(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataAttributeBean attribute) throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeBooleanField("isPresentational", attribute.getPresentational() == TERTIARY_BOOL.TRUE);
		if(attribute.getMinOccurs() >=0) {
			jsonGenerator.writeNumberField("minOccurs", attribute.getMinOccurs());
		}
		if(attribute.getMaxOccurs() >=0 && attribute.getMaxOccurs() < Integer.MAX_VALUE) {
			jsonGenerator.writeNumberField("maxOccurs", attribute.getMaxOccurs());
		} else {
			jsonGenerator.writeStringField("maxOccurs", "unbounded");
		}
		writeComponent(attribute, externalLinks, jsonGenerator);
		writeAttributes(jsonGenerator, externalLinks, attribute);
		jsonGenerator.writeEndObject();
	}
	
	@Override
	protected boolean includeMinMaxInLocalRepresentation() {
		return true;
	}
}
