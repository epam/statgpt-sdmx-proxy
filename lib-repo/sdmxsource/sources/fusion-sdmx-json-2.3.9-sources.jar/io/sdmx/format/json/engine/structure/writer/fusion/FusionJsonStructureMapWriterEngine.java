package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;


public class FusionJsonStructureMapWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<IStructureMapBean> implements IFusionSingleton {
	private static FusionJsonStructureMapWriterEngine INSTANCE;

	public static FusionJsonStructureMapWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureMapWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonStructureMapWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IStructureMapBean structureMap) throws JsonGenerationException, IOException {
		FusionJsonStaticHelper.writeRef(jsonGenerator, structureMap.getSourceRef(), "source");
		FusionJsonStaticHelper.writeRef(jsonGenerator, structureMap.getTargetRef(), "target");
		FusionJsonStaticHelper.writeRef(jsonGenerator, structureMap.getTimeFormatMapping(), "timeFormatRef");
		writeFixedMaps(jsonGenerator, structureMap.getFixedOutputs(), true);
		writeFixedMaps(jsonGenerator, structureMap.getFixedInputs(), false);
		writeComponentMaps(jsonGenerator, structureMap.getComponentMaps());
		writeTimePatternMaps(jsonGenerator, structureMap.getTimePatternMaps());
		writeEpochMaps(jsonGenerator, structureMap.getEpochMap());
	}

	private void writeFixedMaps(JsonGenerator jsonGenerator, Map<String, String> fixed, boolean isOutput) throws IOException {
		if(ObjectUtil.validMap(fixed)) {
			JsonWriterUtil.writeStringMap(jsonGenerator, isOutput ? "fixedOutput" : "fixedInput", fixed);
		}
	}

	private void writeComponentMaps(JsonGenerator jsonGenerator, List<IComponentMapBean> maps)  throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("componentMaps");
			for(IComponentMapBean currentMap : maps) {
				writeComponentMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeTimePatternMaps(JsonGenerator jsonGenerator, List<ITimePatternMapBean> maps)  throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("timePatternMaps");
			for(ITimePatternMapBean currentMap : maps) {
				writeTimePatternMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeEpochMaps(JsonGenerator jsonGenerator, List<IEpochMapBean> maps)  throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("epochMaps");
			for(IEpochMapBean currentMap : maps) {
				writeEpochMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeComponentMap(JsonGenerator jsonGenerator, IComponentMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, map);
		FusionJsonStaticHelper.writeRef(jsonGenerator, map.getRepresentationMapRef(), "representationMapRef");
		JsonWriterUtil.writeStringArray(jsonGenerator, "sources", map.getSourceComponents());
		JsonWriterUtil.writeStringArray(jsonGenerator, "targets", map.getTargetComponents());
		jsonGenerator.writeEndObject();
	}

	private void writeTimePatternMap(JsonGenerator jsonGenerator, ITimePatternMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		writeTimeComponentMap(jsonGenerator, map);
		jsonGenerator.writeStringField("pattern", map.getPattern());
		jsonGenerator.writeStringField("locale", map.getLocale());
		jsonGenerator.writeEndObject();
	}

	private void writeEpochMap(JsonGenerator jsonGenerator, IEpochMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		writeTimeComponentMap(jsonGenerator, map);
		if(map.getBasePeriod() != null) {
			jsonGenerator.writeStringField("basePeriod", map.getBasePeriod().getDateInSdmxFormat());
		}
		if(map.getSourceComponent() != null) {
			jsonGenerator.writeStringField("epoch", map.getEpochInterval().toString());
		}
		jsonGenerator.writeEndObject();
	}

	private void writeTimeComponentMap(JsonGenerator jsonGenerator,  ITimeComponentMapBean map) throws IOException {
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, map);
		if(map.getSourceComponent() != null) {
			jsonGenerator.writeStringField("source", map.getSourceComponent());
		}
		if(map.getTargetComponent() != null) {
			jsonGenerator.writeStringField("target", map.getTargetComponent());
		}
		if(map.getOutputFrequencyDimId() != null) {
			jsonGenerator.writeStringField("freqDim", map.getOutputFrequencyDimId());
		}
		if(map.getOutputFrequencyId() != null) {
			jsonGenerator.writeStringField("freqId", map.getOutputFrequencyId());
		}
		if(map.getPeriodResolution() != null) {
			jsonGenerator.writeStringField("periodResolution", map.getPeriodResolution().toString());
		}
	}
}
