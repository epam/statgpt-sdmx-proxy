package io.sdmx.format.json.factory.data;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.data.factory.format.MetadataAwareDataWriterFactory;
import io.sdmx.format.json.engine.data.writer.fusionjson.FusionJsonDataWriterEngine;
import io.sdmx.format.json.model.FusionJsonDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonDataWriterFactory extends MetadataAwareDataWriterFactory implements IFusionSingleton {
	private static FusionJsonDataWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	public static FusionJsonDataWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static FusionJsonDataWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private FusionJsonDataWriterFactory() {}

	@Override
	public ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if (dataFormat instanceof FusionJsonDataFormat) {
			boolean forceFlat;
			String dimAtObs = null;
			if(dataQuery == null) {
				FusionJsonDataFormat jsonFormat = (FusionJsonDataFormat)dataFormat;
				if(jsonFormat.getRestDataQuery() != null) {
					dimAtObs = jsonFormat.getRestDataQuery().getStringParamValue("dimensionAtObservation");
				}
			} else {
				dimAtObs = dataQuery.dimensionAtObservation();
				if (ObjectUtil.validString(dimAtObs)) {
					if (!(dimAtObs.equalsIgnoreCase(DatasetStructureReferenceBean.ALL_DIMENSIONS) ||
							dimAtObs.equalsIgnoreCase(DimensionBean.TIME_DIMENSION_FIXED_ID))) {
						throw new SdmxNotImplementedException("The dimension at observation '" + dimAtObs + "' is not supported. Only the values '" + DatasetStructureReferenceBean.ALL_DIMENSIONS + "' and '" + DimensionBean.TIME_DIMENSION_FIXED_ID + "' are supported");
					}
				}
				forceFlat = DatasetStructureReferenceBean.ALL_DIMENSIONS.equalsIgnoreCase(dimAtObs);
			}
			if (ObjectUtil.validString(dimAtObs)) {
				if (!(dimAtObs.equalsIgnoreCase(DatasetStructureReferenceBean.ALL_DIMENSIONS) ||
						dimAtObs.equalsIgnoreCase(DimensionBean.TIME_DIMENSION_FIXED_ID))) {
					throw new SdmxNotImplementedException("The dimension at observation '" + dimAtObs + "' is not supported. Only the values '" + DatasetStructureReferenceBean.ALL_DIMENSIONS + "' and '" + DimensionBean.TIME_DIMENSION_FIXED_ID + "' are supported");
				}
			}
			forceFlat = DatasetStructureReferenceBean.ALL_DIMENSIONS.equalsIgnoreCase(dimAtObs);

			return new FusionJsonDataWriterEngine(dataFormat, out, getSuperBeanRetrievalManager(), getBeanRetrievalManager(), forceFlat);
		}
		return null;
	}
}