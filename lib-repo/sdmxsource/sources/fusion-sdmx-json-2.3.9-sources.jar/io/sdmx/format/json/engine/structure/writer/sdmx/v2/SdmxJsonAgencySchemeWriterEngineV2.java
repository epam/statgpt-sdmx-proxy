package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonAgencySchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<AgencyBean, AgencySchemeBean> implements IFusionSingleton {
	private static SdmxJsonAgencySchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonAgencySchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonAgencySchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonAgencySchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, AgencyBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);
	}

	@Override
	protected String getItemName() {
		return "agencies";
	}

}
