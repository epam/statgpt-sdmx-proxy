package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.writer.RegistryJsonMaintainableStructureWriterEngine;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class FusionJsonMaintainableStructureWriterEngineImpl<T extends MaintainableBean> extends FusionJsonNameableStructureWriterEngine<T> implements RegistryJsonMaintainableStructureWriterEngine<T> {
    private static final Logger LOG = LoggerFactory.getLogger(FusionJsonMaintainableStructureWriterEngineImpl.class);

	private SDMX_STRUCTURE_TYPE supportedType;


	public FusionJsonMaintainableStructureWriterEngineImpl(SDMX_STRUCTURE_TYPE sypportedType) {
		this.supportedType = sypportedType;
	}


	@Override
	public SDMX_STRUCTURE_TYPE getSupportedType() {
		return supportedType;
	}

	@Override
	public void writeStructure(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T maintainable) throws JsonGenerationException, IOException {
		writeMaintainable(jsonGenerator, maintainable, externalLinks, false);
	}

	protected void writeMaintainable(JsonGenerator jsonGenerator, T maintainable, IExternalMaintainableLinks externalLinks, boolean includeType) throws JsonGenerationException, IOException {
		if(includeType) {
			jsonGenerator.writeObjectFieldStart(maintainable.getStructureType().getUrnClass());
		} else {
			jsonGenerator.writeStartObject();
		}
		writeNameable(jsonGenerator, externalLinks, maintainable);
		if(maintainable.getServiceURL() != null) {
			jsonGenerator.writeStringField("serviceURL", maintainable.getServiceURL().toString());
		}
		if(maintainable.isExternalReference()) {
			jsonGenerator.writeBooleanField("externalReference", true);
		}
		if(maintainable.getStructureURL() != null) {
			jsonGenerator.writeStringField("structureURL", maintainable.getStructureURL().toString());
		}

		// The agency ID is the id of the agency. If we want the human readable form for any purpose write it to "agency"
		jsonGenerator.writeStringField("agencyId", maintainable.getAgencyId());
		jsonGenerator.writeStringField("version", maintainable.getVersion().toString());
		jsonGenerator.writeBooleanField("isFinal", maintainable.isFinal());

		if(maintainable.hasValidityPeriod()) {
			writeDate(jsonGenerator, "startDate", maintainable.getValidityPeriod().getStartPeriod());
			writeDate(jsonGenerator, "endDate", maintainable.getValidityPeriod().getEndPeriod());
		}
		if(maintainable.isExternalReference() && !ObjectUtil.validCollection(maintainable.getIdentifiableComposites()) && !ObjectUtil.validCollection(maintainable.getCrossReferences())) {
			LOG.debug("Do not output full structure, external Reference: "+maintainable.isExternalReference());
			writeAdditionalStubInformation(jsonGenerator, maintainable);
		} else {
			writeStructureInternal(jsonGenerator, externalLinks, maintainable);
		}
		jsonGenerator.writeEndObject();
	}

	/**
	 * For some maintainable structures, such as content constraints, additional information can be included on the attributes, for example isDefiningDataPresent
	 */
	protected void writeAdditionalStubInformation(JsonGenerator jsonGenerator, T maint) throws IOException {
		//Do nothing
	}

	private void writeDate(JsonGenerator jsonGenerator, String fieldName, SdmxDate aDate) throws IOException {
		if (aDate == null) {
			// Do not write out a number
		} else {
			long startTime = aDate.getDate().getTime();
			jsonGenerator.writeNumberField(fieldName, startTime);
		}
	}
}
