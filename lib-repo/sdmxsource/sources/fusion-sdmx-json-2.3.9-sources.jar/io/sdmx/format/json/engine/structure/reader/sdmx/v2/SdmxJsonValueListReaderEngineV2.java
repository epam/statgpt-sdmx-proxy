package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonValueListReaderEngineV2  extends AbstractSdmxJsonReaderEngine<ValueListMutableBean> implements IFusionSingleton {
	private static SdmxJsonValueListReaderEngineV2 INSTANCE;

	public static SdmxJsonValueListReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonValueListReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "valueLists";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ValueListBean.class;
    }

    @Override
    protected ValueListMutableBean getMutable() {
        return new ValueListMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ValueListMutableBean mutable, JsonReader reader) {
        return processItemSchemeField(mutable, reader, fieldName);
    }
    
    @Override
    protected ValueListMutableBean build(JsonReader jReader, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
        ValueListMutableBean built = super.build(jReader, beanBuilder, beanRetrievalManager);
        ValidityPeriodUtil.processValidityAnnotations(built);
        return built;
    }

	protected boolean processItemSchemeField(ValueListMutableBean itmSch, JsonReader jReader, String fieldName) {
		if (fieldName.equals("isPartial")) {
		    String value = jReader.getValueAsString();
			if (value.equalsIgnoreCase("true")) {
				itmSch.setPartial(true);
			} else if (value.equalsIgnoreCase("false")) {
				itmSch.setPartial(false);
			} else {
				throw new SdmxSemmanticException("Illegal value for 'isPartial'. Valid values are 'true' or 'false' but the following value was supplied: " + value);
			}
			return true;
		}
		if (fieldName.equals("valueItems")) {
			List<ValueItemMutableBean> items = readItems(jReader);
			itmSch.setItems(items);
			return true;
		}
		return false;
	}

	private List<ValueItemMutableBean> readItems(JsonReader jReader) {
		List<ValueItemMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ValueItemMutableBean mutable = readValueItem(jReader);
				returnList.add(mutable);
			}
		}
		return returnList;
	}
	
	private ValueItemMutableBean readValueItem(JsonReader jReader) {
		ValueItemMutableBean mutable = new ValueItemMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(processNode(mutable, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "id" :
				mutable.setId(jReader.getValueAsString());
				break;
			}
		}
		return mutable;
	}
	
	private static boolean processNode(ValueItemMutableBean nameableMutableBean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();

		if (fieldName.equals("names")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
			nameableMutableBean.setName(readTextTypeWrappers);
			return true;
		}
		if (fieldName.equals("descriptions")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
			nameableMutableBean.setDescription(readTextTypeWrappers);
			return true;
		}
		if(fieldName.equals("name")){
			if(!ObjectUtil.validCollection(nameableMutableBean.getNames())) {
				nameableMutableBean.addName("en", jReader.getValueAsString());
			}
			return true;
		} else if(fieldName.equals("description")) {
			if(!ObjectUtil.validCollection(nameableMutableBean.getDescriptions())) {
				nameableMutableBean.addDescription("en", jReader.getValueAsString());
			}
			return true;
		}
		return false;
	}
}