package io.sdmx.format.json.factory.error;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.engine.ErrorWriterEngine;
import io.sdmx.api.sdmx.factory.ErrorWriterFactory;
import io.sdmx.api.sdmx.model.validation.ErrorFormat;
import io.sdmx.format.json.engine.structure.writer.JsonErrorWriterEngine;
import io.sdmx.format.json.model.JsonErrorFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Returns the JSON error message writer
 */
public class JsonErrorWriterFactory implements ErrorWriterFactory, IFusionSingleton {
	private static JsonErrorWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	public static JsonErrorWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new JsonErrorWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static JsonErrorWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private JsonErrorWriterFactory() {}

	@Override
	public ErrorWriterEngine getErrorWriterEngine(ErrorFormat format) {
		if(format instanceof JsonErrorFormat) {
			return JsonErrorWriterEngine.INSTANCE;
		}
		return null;
	}

}
