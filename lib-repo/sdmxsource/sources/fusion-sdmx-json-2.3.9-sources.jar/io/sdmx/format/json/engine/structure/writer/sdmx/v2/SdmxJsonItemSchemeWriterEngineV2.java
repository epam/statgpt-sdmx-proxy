package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class SdmxJsonItemSchemeWriterEngineV2 <R extends ItemBean, T extends ItemSchemeBean<R>> extends SdmxJsonMaintainableStructureWriterEngineV2<T>{

	protected SdmxJsonItemSchemeWriterEngineV2(SDMX_STRUCTURE_TYPE sypportedType) {
		super(sypportedType);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T identifiable) throws JsonGenerationException, IOException {
		List<R> items = identifiable.getItems();
		jsonGenerator.writeBooleanField("isPartial", identifiable.isPartial());
		writeItems(jsonGenerator, externalLinks, items);
	}
	
	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<R> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(getItemName());
		for(R currentItem : items) {
			writeItem(jsonGenerator, externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}
	
	protected void writeItem(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, R currentItem) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		writeNameable(jsonGenerator, currentItem, externalLinks);
		writeItemDetails(jsonGenerator, externalLinks, currentItem);
		jsonGenerator.writeEndObject();
	}
	
	protected abstract void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, R item) throws JsonGenerationException, IOException;
	
	protected abstract String getItemName();
	

}
