package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.codelist.HierarchyAssociationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonHierarchyAssociationReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<HierarchyAssociationBean, HierarchyAssociationMutableBean> implements IFusionSingleton {
	private static FusionJsonHierarchyAssociationReaderEngine INSTANCE;

	public static FusionJsonHierarchyAssociationReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonHierarchyAssociationReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected HierarchyAssociationMutableBean getMutable() {
		return new HierarchyAssociationMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, HierarchyAssociationMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("hierarchyRef")) {
			mutable.setHierarchyRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
		} else if (fieldName.equals("linkedStructureRef")) {
			mutable.setLinkedStructure(new StructureReferenceBeanImpl(jReader.getValueAsString()));
		} else if (fieldName.equals("contextRef")) {
			mutable.setContextStructure(new StructureReferenceBeanImpl(jReader.getValueAsString()));
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<HierarchyAssociationBean> getMaintainableType() {
        return HierarchyAssociationBean.class;
    }
}