package io.sdmx.format.json.engine.structure.reader.sdmx;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.format.json.api.engine.JsonMaintainableBeanReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonMaintainableUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public abstract class AbstractSdmxJsonReaderEngine<T extends MaintainableMutableBean> implements JsonMaintainableBeanReaderEngine {

    
    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(getMaintainableType());
    }
    
    protected abstract Class<? extends MaintainableBean> getMaintainableType();
    
    @Override
    public void read(JsonReader jReader, SdmxBeans beans, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
        while (jReader.moveNext()) {
            if(jReader.isStartObject()) {
                T maint  = build(jReader, beanBuilder, beanRetrievalManager);
                beanBuilder.build(maint, beans);
            }
            if(jReader.isEndArray()) {
                break;
            }
        }
    }
    
    protected T build(JsonReader jReader, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
        T maint = getMutable();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }

            if(!SdmxJsonMaintainableUtil.processBean(maint, jReader)) {
                String fieldName = jReader.getCurrentFieldName();
                if(!processMaintainableProperty(fieldName, maint, jReader, beanRetrievalManager)) {
                    if(jReader.isStartArray()) {
                        jReader.moveToEndArray();
                    } else if(jReader.isStartObject()) {
                        jReader.moveToEndObject();
                    }
                }
            }
        }
        return maint;
    }

    protected List<StructureReferenceBean> processSRefArray(JsonReader jReader) {
        List<StructureReferenceBean> returnArray = new ArrayList<>();
        for(String str : jReader.readStringArray()) {
            returnArray.add(new StructureReferenceBeanImpl(str));
        }
        return returnArray;
    }

    protected abstract T getMutable();

    protected boolean processMaintainableProperty(String fieldName, T mutable, JsonReader reader, SdmxBeanRetrievalManager beanRetrievalManager) {
        return processMaintainableProperty(fieldName, mutable, reader);
    }

    protected abstract boolean processMaintainableProperty(String fieldName, T mutable, JsonReader reader);
}
