package io.sdmx.format.json.factory.metadata;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataFormatFactory;
import io.sdmx.format.json.model.FusionJsonMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonMetadataFormatFactory implements IMetadataFormatFactory, IFusionSingleton {
	private static FusionJsonMetadataFormatFactory INSTANCE;

	private Map<String, FormatDetails> supportedFormats = new HashMap<>(1);
	
	//Private constructor - lazy load instance
	public static FusionJsonMetadataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static FusionJsonMetadataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	
	private FusionJsonMetadataFormatFactory() {
		addSupportedFormat(FusionJsonMetadataFormat.getInstance());
		this.supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}
	
	private void addSupportedFormat(IMetadataFormat format) {
		supportedFormats.put(format.getFormatDetails().getAcceptHeaders()[0], format.getFormatDetails());
	}

	@Override
	public Class<IMetadataFormat> getFormatClass() {
		return IMetadataFormat.class;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public IMetadataFormat getFormat(String format, Request request) {
		if(format.equals("fusion-json")) {
			return FusionJsonMetadataFormat.getInstance();
		}
		return null;
	}

	@Override
	public IMetadataFormat getFormat(Request request, IVNDHeader vndHeader) {
		String vnd = vndHeader.getVnd();
		boolean fusionJson = vnd.startsWith("fusion.json");
		if(fusionJson) {
			return FusionJsonMetadataFormat.getInstance();
		}
		return null;
	}
}
