package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.OutputStream;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.writer.AbstractJsonStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.JsonMaintainableStructureWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonStructureWriterEngine extends AbstractJsonStructureWriterEngine implements IFusionSingleton {
	private static FusionJsonStructureWriterEngine JSON_INSTANCE;
	private static FusionJsonStructureWriterEngine YAML_INSTANCE;
	private JSON_COMPATIBLE_FORMAT format;
	
    public static FusionJsonStructureWriterEngine getInstance() {
	   
//        case JSON:
            if(JSON_INSTANCE == null) {
                JSON_INSTANCE = new FusionJsonStructureWriterEngine(JSON_COMPATIBLE_FORMAT.JSON);
                FusionBeanStore.registerInstance(JSON_INSTANCE);
            }
            return JSON_INSTANCE;
//        case YAML:
//        default:
//            if(YAML_INSTANCE == null) {
//                YAML_INSTANCE = new FusionJsonStructureWriterEngine(format);
//                FusionBeanStore.registerInstance(YAML_INSTANCE);
//            }
//            return YAML_INSTANCE;
//	    }
	}

	@Override
    public void destroyInstance() {
	    JSON_INSTANCE = null;
        YAML_INSTANCE = null;
    }

	private FusionJsonStructureWriterEngine(JSON_COMPATIBLE_FORMAT format) {
		super(true, SDMX_STRUCTURE_TYPE.getMaintainableStructureTypes());
		this.format = format;
		registerWriter(FusionJsonAgencySchemeWriterEngine.getInstance());
		registerWriter(FusionJsonCategorisationWriterEngine.getInstance());
		registerWriter(FusionJsonCategorySchemeWriterEngine.getInstance());
		registerWriter(FusionJsonCodelistWriterEngine.getInstance());
		registerWriter(FusionJsonConceptSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonContentConstraintWriterEngine.getInstance());
		registerWriter(FusionJsonDataConsumerSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonDataflowWriterEngine.getInstance());
		registerWriter(FusionJsonDataProviderSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonDataStructureWriterEngine.getInstance());
		registerWriter(FusionJsonHierarchyAssociationWriterEngine.getInstance());
		registerWriter(FusionJsonHierarchicalCodelistWriterEngine.getInstance());
		registerWriter(FusionJsonMetadataflowWriterEngine.getInstance());
		registerWriter(FusionJsonMetadataStructureWriterEngine.getInstance());
		registerWriter(FusionJsonMetadataProviderSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonMetadataProvisionWriterEngine.getInstance());
		registerWriter(FusionJsonOrganisationUnitSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonProvisionAgreementWriterEngine.getInstance());
		registerWriter(FusionJsonPDQWriterEngine.getInstance());
		registerWriter(FusionJsonProcessWriterEngine.getInstance());
		registerWriter(FusionJsonReportTemplateWriterEngine.getInstance());
		registerWriter(FusionJsonReportingTaxonomyWriterEngine.getInstance());
		registerWriter(FusionJsonRepresentationMapWriterEngine.getInstance());
		registerWriter(FusionJsonStructureMapWriterEngine.getInstance());
		registerWriter(FusionJsonValidationSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonValueListWriterEngine.getInstance());
		registerWriter(FusionJsonRegistrationWriterEngine.getInstance());
		registerWriter(FusionJsonCustomTypeSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonNamePersonalisationSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonTransformationSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonRulesetSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonUserDefinedOperatorSchemeWriterEngine.getInstance());
		registerWriter(FusionJsonVtlMappingSchemeWriterEngine.getInstance());
	}
	
	@Override
    protected JsonGenerator createWriter(OutputStream out) {
        return JsonWriterUtil.createJsonWriter(out, format);
    }

	@Override
	protected String getMaintainableJSONKey(SDMX_STRUCTURE_TYPE maintainableType) {
		return maintainableType.getUrnClass();
	}
	
	@Override
	protected String getSchemaLocation() {
		return null;
	}

	@Override
	protected String getGeographicCodelistJSONKey() {
		return "GeographicCodelist";
	}

	@Override
	protected String getGeoGridCodelistJSONKey() {
		return "GeoGridCodelist";
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeographicCodelistBean> getGeographicalCodelistWriter() {
		return FusionJsonGeographicCodelistWriterEngine.getInstance();
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeoGridCodelistBean> getGeoGridCodelistWriter() {
		return FusionJsonGeoGridCodelistWriterEngine.getInstance();
	}
}