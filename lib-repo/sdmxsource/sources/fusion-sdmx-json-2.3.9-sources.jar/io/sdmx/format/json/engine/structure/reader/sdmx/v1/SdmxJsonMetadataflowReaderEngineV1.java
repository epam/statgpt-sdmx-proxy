package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonMetadataflowReaderEngineV1 extends AbstractSdmxJsonReaderEngine<MetadataFlowMutableBean> implements IFusionSingleton {
	private static SdmxJsonMetadataflowReaderEngineV1 INSTANCE;

	public static SdmxJsonMetadataflowReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataflowReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    public String getContainerElement() {
        return "metadataflows";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return MetadataFlowBean.class;
    }

    @Override
    protected MetadataFlowMutableBean getMutable() {
        return new MetadataflowMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, MetadataFlowMutableBean mutable, JsonReader reader) {
        throw new SdmxNotImplementedException("Metadataflows are no longer supported in version 1.0 of SDMX JSON.  Please use version 2.0.0");
    }
}
