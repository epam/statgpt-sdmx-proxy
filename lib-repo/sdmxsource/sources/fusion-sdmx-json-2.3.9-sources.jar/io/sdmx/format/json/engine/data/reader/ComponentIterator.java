package io.sdmx.format.json.engine.data.reader;

public class ComponentIterator {

}
