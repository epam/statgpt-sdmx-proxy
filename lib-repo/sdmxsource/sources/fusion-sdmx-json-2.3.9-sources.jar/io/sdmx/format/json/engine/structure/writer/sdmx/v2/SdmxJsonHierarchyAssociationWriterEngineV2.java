package io.sdmx.format.json.engine.structure.writer.sdmx.v2;


import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonHierarchyAssociationWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<HierarchyAssociationBean> implements IFusionSingleton {
	private static SdmxJsonHierarchyAssociationWriterEngineV2 INSTANCE;

	public static SdmxJsonHierarchyAssociationWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonHierarchyAssociationWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonHierarchyAssociationWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyAssociationBean hCodelist) throws JsonGenerationException, IOException {
		if(hCodelist.getHierarchyRef() != null) {
			jsonGenerator.writeStringField("linkedHierarchy", hCodelist.getHierarchyRef().getTargetUrn());
		}
		if(hCodelist.getLinkedStructureRef() != null) {
			jsonGenerator.writeStringField("linkedObject", hCodelist.getLinkedStructureRef().getTargetUrn());
		}
		if(hCodelist.getContextStructureRef() != null) {
			jsonGenerator.writeStringField("contextObject", hCodelist.getContextStructureRef().getTargetUrn());

		}
	}
}
