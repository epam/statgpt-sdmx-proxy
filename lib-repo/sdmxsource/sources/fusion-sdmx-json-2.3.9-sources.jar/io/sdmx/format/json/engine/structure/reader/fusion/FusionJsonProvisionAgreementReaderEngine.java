package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonProvisionAgreementReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<ProvisionAgreementBean, ProvisionAgreementMutableBean> implements IFusionSingleton {
	private static FusionJsonProvisionAgreementReaderEngine INSTANCE;

	public static FusionJsonProvisionAgreementReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonProvisionAgreementReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ProvisionAgreementMutableBean getMutable() {
		return new ProvisionAgreementMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ProvisionAgreementMutableBean mutable, JsonReader jReader) {
		String value = jReader.getValueAsString();
		if (fieldName.equals("structureUsage")) {
			StructureReferenceBean structureUsage = new StructureReferenceBeanImpl(value);
			mutable.setStructureUsage(structureUsage);
		} else if (fieldName.equals("dataproviderRef")) {
			StructureReferenceBean dataproviderRef = new StructureReferenceBeanImpl(value);
			mutable.setDataproviderRef(dataproviderRef);
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<ProvisionAgreementBean> getMaintainableType() {
        return ProvisionAgreementBean.class;
    }
}