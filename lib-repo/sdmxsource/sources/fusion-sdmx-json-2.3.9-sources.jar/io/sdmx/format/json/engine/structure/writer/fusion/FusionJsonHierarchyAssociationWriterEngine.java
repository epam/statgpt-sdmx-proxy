package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonHierarchyAssociationWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<HierarchyAssociationBean> implements IFusionSingleton {
	private static FusionJsonHierarchyAssociationWriterEngine INSTANCE;

	public static FusionJsonHierarchyAssociationWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonHierarchyAssociationWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private FusionJsonHierarchyAssociationWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION);
	}

	@Override
	public void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyAssociationBean maint) throws JsonGenerationException, IOException {
		if(maint.getHierarchyRef() != null) {
			jsonGenerator.writeStringField("hierarchyRef", maint.getHierarchyRef().getTargetUrn());
		}
		if(maint.getLinkedStructureRef() != null) {
			jsonGenerator.writeStringField("linkedStructureRef", maint.getLinkedStructureRef().getTargetUrn());
		}
		if(maint.getContextStructureRef() != null) {
			jsonGenerator.writeStringField("contextRef", maint.getContextStructureRef().getTargetUrn());
		}
	}
}
