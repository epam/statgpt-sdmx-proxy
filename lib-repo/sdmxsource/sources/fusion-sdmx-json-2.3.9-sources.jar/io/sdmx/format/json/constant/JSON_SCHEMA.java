package io.sdmx.format.json.constant;

import java.net.URI;
import java.net.URISyntaxException;

public enum JSON_SCHEMA {
	STRUCTURE_V1(SDMX_JSON_SCHEMA.STRUCTURE_V1),
	STRUCTURE_V2(SDMX_JSON_SCHEMA.STRUCTURE_V2),
	REF_METADATA_V2(SDMX_JSON_SCHEMA.REF_METADATA_V2);
	
	private URI uri;
	
	private JSON_SCHEMA(String location) {
		try {
			this.uri = new URI(location);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	}
	
	public URI getURI() {
		return this.uri;
	}
}
