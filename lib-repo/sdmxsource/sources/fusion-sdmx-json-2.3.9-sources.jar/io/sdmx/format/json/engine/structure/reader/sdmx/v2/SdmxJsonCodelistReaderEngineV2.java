package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonCodelistReaderEngineV2 extends SdmxJsonItemSchemeReaderEngineV2<CodeMutableBean, CodelistMutableBean> implements IFusionSingleton {
	private static SdmxJsonCodelistReaderEngineV2 INSTANCE;

	public static SdmxJsonCodelistReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCodelistReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	

    @Override
    public String getContainerElement() {
        return "codelists";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return CodelistBean.class;
    }

    @Override
    protected CodelistMutableBean getMutable() {
        return new CodelistMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, CodelistMutableBean mutable, JsonReader reader) {
		if(fieldName.equals("codelistExtensions")) {
			while (reader.moveNext()) {
				if (reader.isStartObject()) {
					processCodelistExtension(mutable, reader);
				}
				if (reader.isEndArray()) {
					break;
				}
			}
			return true;
		}
		return super.processMaintainableProperty(fieldName, mutable, reader);
	}
	
	/**
	 * <pre>
	 *  {
            "prefix": "EX_",
            "codelist": "urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_REF_ARAEA(1.0.2)",
            "exclusiveCodeSelection": {
              "wildcardedMemberValues": [
                "%US",
                "%EU"
              ],
              "memberValues": [
                {
                  "value": "UK"
                }
              ]
            }
          }
	 * </pre>
	 */
	private void processCodelistExtension(CodelistMutableBean itmSch, JsonReader jReader) {
		ICodelistInheritanceRuleMutableBean rule = new CodelistInheritanceRuleMutableBean();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			boolean exclusive = false;
			String field = jReader.getCurrentFieldName();
			switch(field) {
			case "prefix" :
				rule.setPrefix(jReader.getValueAsString());
				break;
			case "codelist" :
				rule.setCodelistRef(new StructureReferenceBeanImpl(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.CODE_LIST));
				break;
			case "exclusiveCodeSelection" :
				exclusive = true;
			case "inclusiveCodeSelection" :
				List<String> memberValues = new ArrayList<>();
				List<String> cascadeValues = new ArrayList<>();
				processCodelistExtensionValues(memberValues, cascadeValues, jReader);
				if(exclusive) {
					rule.setExclusiveInheritenceIds(memberValues);
					rule.setExclusiveInheritenceCascades(new HashSet<>(cascadeValues));
				} else {
					rule.setInclusiveInheritenceIds(memberValues);
					rule.setInclusiveInheritenceCascades(new HashSet<>(cascadeValues));
				}
				break;
			}
		}
		itmSch.addInheritenceRules(rule);
	}
	
	private void processCodelistExtensionValues(List<String> memberValues, List<String> cascadeValues, JsonReader jReader) {
		while (jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			}
			String field = jReader.getCurrentFieldName();
			switch(field) {
			case "wildcardedMemberValues" :
				memberValues.addAll(jReader.readStringArray());
				break;
			case "memberValues" :
				processCodelistMemberValues(memberValues, cascadeValues, jReader);
				break;
			}
		}
	}
	
	private void processCodelistMemberValues(List<String> includedValues, List<String> cascadeValues, JsonReader jReader) {
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			}
			if(jReader.isStartObject()) {
				processCodelistMemberValue(includedValues, cascadeValues, jReader);
			}
		}
	}
	
	private void processCodelistMemberValue(List<String> includedValues, List<String> cascadeValues, JsonReader jReader) {
		boolean cascade = false;
		String memberValue = null;
		while (jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			String field = jReader.getCurrentFieldName();
			switch(field) {
			case "value" :
				memberValue = jReader.getValueAsString();
				break;
			case "cascadeValues" :
				cascade = jReader.getValueAsBoolean();
				break;
			}
		}
		if(memberValue != null) {
			if(cascade) {
				cascadeValues.add(memberValue);
			}
			includedValues.add(memberValue);
		}
	}

	private CodeMutableBean readCodeBean(JsonReader jReader) {
		CodeMutableBean aCode = new CodeMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(aCode, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parent")) {
				aCode.setParentCode(value);
			}
		}
		return aCode;
	}

	@Override
	protected List<CodeMutableBean> readItems(JsonReader jReader) {
		List<CodeMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				CodeMutableBean aCode = readCodeBean(jReader);
				returnList.add(aCode);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "codes";
	}
}
