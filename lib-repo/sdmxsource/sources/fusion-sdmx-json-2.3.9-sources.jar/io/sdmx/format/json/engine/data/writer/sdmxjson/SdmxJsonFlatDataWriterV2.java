package io.sdmx.format.json.engine.data.writer.sdmxjson;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.format.json.engine.data.writer.fusionjson.AbstractJsonDataWriter.IJsonWriterMarker;
import io.sdmx.format.json.engine.data.writer.fusionjson.FlatDataWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SdmxJsonFlatDataWriterV2 extends FlatDataWriter implements IJsonWriterMarker {

	private static final Logger LOG = LoggerFactory.getLogger(SdmxJsonFlatDataWriterV2.class);

	public SdmxJsonFlatDataWriterV2(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(jsonGenerator, header, superBeanRetrievalManager);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... ann) {
		super.startDataset(structures, datasetHeader, datasetAttributes, ann);
	}

	@Override
	protected void writeJsonObs(Observation obs, String seriesKey) {
		try {
			LOG.debug("[" + seriesKey + "]");
			jsonGenerator.writeArrayFieldStart(seriesKey);

			// write all observation values
			for (MeasureDimensionBean mdb : currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getMeasures()) {
				String id = mdb.getId();
				List<String> measureValues = obs.getMeasureValues(id);

				if (measureValues != null) {
					if (measureValues.size() == 1) {
						// write single-valued measure
						jsonGenerator.writeString(measureValues.get(0));

					} else if (measureValues.size() > 1) {
						// write multivalued measure
						jsonGenerator.writeArray(measureValues.toArray(new String[0]), 0, measureValues.size());
					}
				} else {
					jsonGenerator.writeNull();
				}
			}

			List<AttributeBean> attrs = new ArrayList<>(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getDimensionGroupAttributes());
			attrs.addAll(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getObservationAttributes());

			writeAttributes(attrs, obs.getAttributes(), obs.getSeriesKey().getAttributes());

			// Write the annotation values
			for (AnnotationBean currentAnnotation : obs.getSeriesKey().getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int idx = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(idx);
			}
			for (AnnotationBean currentAnnotation : obs.getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int idx = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(idx);
			}
			LOG.debug("[/'" + seriesKey + "]");
			jsonGenerator.writeEndArray();
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}

	@Override
	protected void writeStructure(boolean writeNode) throws JsonGenerationException, IOException {
		jsonGenerator.writeArrayFieldStart("structures");
		super.writeStructure(false);
		jsonGenerator.writeEndArray();
	}

	@Override
	public void writeLink(List<ILinkBean> links) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeLinks(links, this.jsonGenerator);
	}

	@Override
	public void writeTextType(List<TextTypeWrapper> ttw, String type) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeTextTypeWrapperArray(ttw, jsonGenerator, type);
	}

	@Override
	public boolean includePosition() {
		return false;
	}

	@Override
	protected boolean isSdmxJsonV2() {
		return true;
	}
}
