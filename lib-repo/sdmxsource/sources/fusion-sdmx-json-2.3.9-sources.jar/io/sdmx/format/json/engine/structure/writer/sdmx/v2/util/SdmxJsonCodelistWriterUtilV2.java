package io.sdmx.format.json.engine.structure.writer.sdmx.v2.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.utils.core.object.ObjectUtil;

import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCodelistWriterUtilV2 {

	/**
	 * Writes the inheritance rules if they are defined and if the Codelist is in its raw form 
	 * i.e. is not a materialisation of the full codelist with inherited codes present 
	 * 
	 * @param jsonGenerator
	 * @param cl
	 * @throws IOException
	 */
	public static void writeInheritence(JsonGenerator jsonGenerator, CodelistBean cl) throws IOException {
		if(!cl.isInherited() && ObjectUtil.validCollection(cl.getInheritedCodelists())) {
			jsonGenerator.writeArrayFieldStart("codelistExtensions");
			for(ICodelistInheritanceRuleBean clInheritance : cl.getInheritedCodelists()) {
				writeInheritanceRuleBean(clInheritance, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}
	}

	
	private static void writeInheritanceRuleBean(ICodelistInheritanceRuleBean rule, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		if(rule.getPrefix() != null) {
			jsonGenerator.writeStringField("prefix", rule.getPrefix());
		}
		jsonGenerator.writeStringField("codelist", rule.getCodelistRef().getTargetUrn());
		writeInheritanceMembers(rule.getInclusiveInheritenceIds(), rule.getInclusiveInheritenceCascades(), true, jsonGenerator);
		writeInheritanceMembers(rule.getExclusiveInheritenceIds(), rule.getExclusiveInheritenceCascades(), false, jsonGenerator);
		jsonGenerator.writeEndObject();
	}
	
	private static void writeInheritanceMembers(List<String> members, Set<String> cascade, boolean included, JsonGenerator writer) throws IOException {
		if(ObjectUtil.validCollection(members)) {
			String elementName = included ? "inclusiveCodeSelection" : "exclusiveCodeSelection";
			writer.writeObjectFieldStart(elementName);
			
			List<String> wildcaredMembers = new ArrayList<>(members.size());
			List<String> memberValues = new ArrayList<>(members.size());
			for(String member : members) {
				if(member.contains("%")) {
					wildcaredMembers.add(member);
				} else {
					memberValues.add(member);
				}
			}
			if(wildcaredMembers.size() > 0) {
				JsonWriterUtil.writeStringArray(writer, "wildcardedMemberValues", wildcaredMembers);
			}
			if(memberValues.size() > 0) {
				writeInheritanceMemberValues(memberValues, cascade, writer);
			}
			writer.writeEndObject();
		}
	}
	
	private static void writeInheritanceMemberValues(List<String> members, Set<String> cascade, JsonGenerator writer) throws IOException {
		writer.writeArrayFieldStart("memberValues");
		for(String member : members) {
			writeInheritanceMemberValue(member, cascade.contains(member), writer);
		}
		writer.writeEndArray();
	}
	
	private static void writeInheritanceMemberValue(String value, boolean cascade, JsonGenerator writer) throws IOException {
		writer.writeStartObject();
		writer.writeStringField("value", value);
		if(cascade) {
			writer.writeBooleanField("cascadeValues", cascade);
		}
		writer.writeEndObject();
	}
}
