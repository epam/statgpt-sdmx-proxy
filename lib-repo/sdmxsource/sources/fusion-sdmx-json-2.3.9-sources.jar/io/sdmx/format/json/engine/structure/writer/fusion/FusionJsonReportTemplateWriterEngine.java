package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateColourBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonReportTemplateWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<ReportingTemplateBean> implements IFusionSingleton {
	private static FusionJsonReportTemplateWriterEngine INSTANCE;

	public static FusionJsonReportTemplateWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonReportTemplateWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonReportTemplateWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE);
	}

	@Override
	/**
	 * Writes JSON Object
	 *  {
	 *     agencyId   : "acyId",
	 *     id   :    "id",
	 *     name   : {
	 *     		"en" : "name english",
	 *     		"fr" : "name french"
	 *     },
	 *     version : "1.0",
	 *     validFrom : "2001-07-18",
	 *     validTo : "2009-07-18",
	 *     instructionsheet : {
	 *     		title : ""
	 *     		name : "",
	 *          instructions : [ {
	 *             "content" : "the user instructions",
	 *             "border" : "none|thin|medium",
	 *             "width"    : 6,
	 *             "height"   : 12 }
	 *          ]
	 *     },
	 *     worksheets : [
	 *       {
	 *          constraint : "urn",
	 *          id   : "sheet_name",
	 *          tableRows : ["Dim1", "Dim2"],
	 *          tableCols : ["Dim3", "Dim4"],
	 *          fixedDimensions : {
	 *          	FREQ : A,
	 *              TIME : 2008
	 *          },
	 *          fixedAttributes : {
	 *          	OBS_STATUS : A,
	 *              UNIT_MULT : M
	 *          },
	 *          variableAttributes : ["PRE_BREAK"],
	 *          worksheetAttributes : ["FISH"],
	 *          colourAttribute : {
	 *          	id : "OBS_CONF",
	 *              defaultColour : "#C2C2C2",
	 *              colourCodes : {
	 *     				"A" : "#C2C2C2",
	 *     				"M" : "#E2E2E2",
	 *   			},
	 *              seriesColors [
	 *              	{
	 *              	 colour : "#D2D2D2",
	 *              	 series : ["A:UK:POP","A:FR:POP"]
	 *              	},....
	 *              ]
	 *          },
	 *          explicitHierarchy : {
	 *          	REF_AREA : "urn"
	 *          },
	 *          implicityHierarchy : ["INDICATOR", "BASKET"],
	 *          displayId : ["INDICATOR", "BASKET"]
	 *       }
	 *     ]
	 *  }
	 */
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ReportingTemplateBean reportingTemplate) throws JsonGenerationException, IOException {
		writeInstructionSheet(jsonGenerator, reportingTemplate.getInstructionSheet());
		jsonGenerator.writeBooleanField("includeCheckingTables", reportingTemplate.includeFormulaCheckingSummary());
		jsonGenerator.writeArrayFieldStart("worksheets");
		for(ReportingTemplateWorksheetBean worksheet : reportingTemplate.getWorksheets()) {
			writeWorksheet(jsonGenerator, externalLinks, worksheet);
		}
		jsonGenerator.writeEndArray();
	}

	private void writeWorksheet(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ReportingTemplateWorksheetBean worksheet) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		super.writeIdentifiable(jsonGenerator, externalLinks, worksheet);
		jsonGenerator.writeStringField("dataflow", worksheet.getDataflow().getTargetUrn());
		if(worksheet.getColMaxWidth() != null) {
			jsonGenerator.writeNumberField("colmaxwidth", worksheet.getColMaxWidth());
		}
		if(worksheet.getRoundDecimals() != null) {
			jsonGenerator.writeNumberField("round", worksheet.getRoundDecimals());
		}
		JsonWriterUtil.writeStringArray(jsonGenerator, "tableRows", worksheet.getTableRows());
		JsonWriterUtil.writeStringArray(jsonGenerator, "tableCols", worksheet.getTableCols());
		JsonWriterUtil.writeStringArray(jsonGenerator, "excludeDimensions", worksheet.getExcludeDimensions());
		JsonWriterUtil.writeStringMap(jsonGenerator, "fixedAttributes", worksheet.getFixedAttributesMap());
		JsonWriterUtil.writeStringArray(jsonGenerator, "variableAttributes", worksheet.getVariableAttributes());
		JsonWriterUtil.writeStringArray(jsonGenerator, "variableDimensions", worksheet.getVariableDimensions());
		JsonWriterUtil.writeStringArray(jsonGenerator, "worksheetAttributes", worksheet.getWorksheetAttributes());
		JsonWriterUtil.writeStringArray(jsonGenerator, "separateAttributes", worksheet.getSeparateAttributes());

		writeWorksheetConditionalAttributes(jsonGenerator, worksheet);
		writeWorksheetColour(jsonGenerator, worksheet.getColourAttribute());
		jsonGenerator.writeObjectFieldStart("explicitHierarchy");
		if(worksheet.getHierarhcyReferences() != null) {
			for(String str : worksheet.getHierarhcyReferences().keySet()) {
				jsonGenerator.writeStringField(str, worksheet.getHierarhcyReferences().get(str).getTargetUrn());
			}
		}
		jsonGenerator.writeEndObject();
		JsonWriterUtil.writeStringArray(jsonGenerator, "implicityHierarchy", worksheet.getImplicitHierarchices());

		//	JsonWriterUtil.writeStringArray(jsonGenerator, "displayId", worksheet.getDisplayById());
		jsonGenerator.writeObjectFieldStart("display");
		for(String componentId : worksheet.getTextDisplay().keySet()) {
			jsonGenerator.writeStringField(componentId, worksheet.getTextDisplay().get(componentId).toString());
		}

		jsonGenerator.writeEndObject();

		jsonGenerator.writeEndObject();
	}

	/**
	 * instructionsheet : {
	 *     		title : ""
	 *     		name : "",
	 *          instructions : [ {
	 *             "content" : "the user instructions",
	 *             "border" : "none|thin|medium",
	 *             "width"    : 6,
	 *             "height"   : 12 }
	 *          ]
	 *     },
	 */
	private void writeInstructionSheet(JsonGenerator jsonGenerator, ReportTemplateInstructionSheetBean instructionSheet) throws JsonGenerationException, IOException {
		if(instructionSheet == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("instructionsheet");
		jsonGenerator.writeStringField("name", instructionSheet.getName());
		if(instructionSheet.getTitle() != null) {
			jsonGenerator.writeStringField("title", instructionSheet.getTitle());
		}
		jsonGenerator.writeArrayFieldStart("instructions");
		writeInstructionText(jsonGenerator, instructionSheet.getInstructions());
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	/**
	 *  "content" : "the user instructions",
	 *  "border" : "none|thin|medium",
	 *  "width"    : 6,
	 *  "height"   : 12 }
	 */
	private void writeInstructionText(JsonGenerator jsonGenerator, List<ReportTemplateInstructionTextBean> instructionText) throws JsonGenerationException, IOException {
		for(ReportTemplateInstructionTextBean currentText : instructionText) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("content", currentText.getContent());
			jsonGenerator.writeNumberField("height", currentText.getColHeight());
			jsonGenerator.writeNumberField("width", currentText.getColWidth());
			jsonGenerator.writeEndObject();
		}
	}
	/**
	 * 	 colourAttribute : {
	 *     id : "OBS_CONF",
	 *     defaultColour : "#C2C2C2",
	 *     colourCodes : {
	 *       "A" : "#C2C2C2",
	 *       "M" : "#E2E2E2",
	 *     },
	 *     seriesColors [
	 *        {
	 *         colour : "#D2D2D2",
	 *         series : ["A:UK:POP","A:FR:POP"]
	 *        },....
	 *      ]
	 *  },
	 * @param jsonGenerator
	 * @param wsColour
	 * @throws JsonGenerationException
	 * @throws IOException
	 */
	private void writeWorksheetColour(JsonGenerator jsonGenerator, ReportingTemplateColourBean wsColour) throws JsonGenerationException, IOException {
		if(wsColour != null) {
			jsonGenerator.writeObjectFieldStart("colourAttribute");
			jsonGenerator.writeStringField("id", wsColour.getAttributeId());
			jsonGenerator.writeStringField("defaultColour", wsColour.getDefaultColour());
			JsonWriterUtil.writeStringMap(jsonGenerator, "colourCodes", wsColour.getColourCodes());
			jsonGenerator.writeArrayFieldStart("seriesColors");
			for(Set<String> series : wsColour.getSeriesColours().keySet()) {
				String colour = wsColour.getSeriesColours().get(series);
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField("colour", colour);
				JsonWriterUtil.writeStringArray(jsonGenerator, "series", series);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
	}

	/**
	 * conditionalAttributes : {
	 *   OBS_STATUS : {
	 *     A : {
	 *     		rule : dv
	 *     },
	 *     M : {
	 *     		rule : mv
	 *     }
	 *     E : {
	 *     		rule : ov,
	 *     		details: gt.100
	 *     }
	 *   }
	 * }
	 * @param jsonGenerator
	 * @param worksheet
	 * @throws JsonGenerationException
	 * @throws IOException
	 */
	private void writeWorksheetConditionalAttributes(JsonGenerator jsonGenerator, ReportingTemplateWorksheetBean worksheet) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart("conditionalAttributes");
		for(ReportingTemplateConditionalAttributeBean conditionalAttr : worksheet.getConditionalAttributes()) {
			jsonGenerator.writeObjectFieldStart(conditionalAttr.getAttributeId());
			for(ConditionalAttributeMappingBean condition : conditionalAttr.getConditions()) {
				jsonGenerator.writeObjectFieldStart(condition.getAttributeValue());
				jsonGenerator.writeStringField("rule", condition.getCondition().toString());
				String details = condition.getConditionDetail();
				if(details != null) {
					jsonGenerator.writeStringField("details",details);
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndObject();
	}
}
