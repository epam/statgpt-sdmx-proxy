package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonCategorisationReaderEngineV1 extends AbstractSdmxJsonReaderEngine<CategorisationMutableBean> implements IFusionSingleton {
	private static SdmxJsonCategorisationReaderEngineV1 INSTANCE;

	public static SdmxJsonCategorisationReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorisationReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	
	@Override
    protected CategorisationMutableBean getMutable() {
        return new CategorisationMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, CategorisationMutableBean mutable, JsonReader reader) {
        String value = reader.getValueAsString();

        switch(fieldName) {
        case "source" :
            /**
               "source": {
                    "$ref": "#/definitions/urn",
                    "description": "Source is a urn reference to an object to be categorized."
                }
             */
            StructureReferenceBean structureReference = new StructureReferenceBeanImpl(value);
            mutable.setStructureReference(structureReference);
            return true;
        case "target" :
            /**
               "target": {
                    "$ref": "#/definitions/urn",
                    "description": "Target is a urn reference to the category that the referenced object is to be mapped to.""
                }
             */
            StructureReferenceBean categoryRef = new StructureReferenceBeanImpl(value);
            mutable.setCategoryReference(categoryRef);
            return true;
              
        }
        return false;
    }

    @Override
    public String getContainerElement() {
        return "categorisations";
    }

    @Override
    protected Class<CategorisationBean> getMaintainableType() {
        return CategorisationBean.class;
    }
}
