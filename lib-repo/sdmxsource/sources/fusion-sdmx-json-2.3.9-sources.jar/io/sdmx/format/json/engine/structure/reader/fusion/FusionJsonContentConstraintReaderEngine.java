package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * reads in pre SDMX 2.1 ContentConstraint, this changed to a DataConstraint and the syntax was decoupled from the need to get back to the DSD in order to process
 */
public class FusionJsonContentConstraintReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<ContentConstraintBean, ContentConstraintMutableBean> implements IFusionSingleton {
	private Set<IMaintainableStructureType<?>> reliesOn;

	private static FusionJsonContentConstraintReaderEngine INSTANCE;

	public static FusionJsonContentConstraintReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonContentConstraintReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ContentConstraintMutableBean getMutable() {
		return new ContentConstraintMutableBeanImpl();
	}

	@Override
	public Set<IMaintainableStructureType<?>> getReliesOn() {
		if(reliesOn == null) {
			reliesOn = new HashSet<>();
			reliesOn.add(StructureTypes.getMaintStructureType(DataStructureBean.class));
			reliesOn.add(StructureTypes.getMaintStructureType(DataflowBean.class));
			reliesOn.add(StructureTypes.getMaintStructureType(ProvisionAgreementBean.class));
			reliesOn = Collections.unmodifiableSet(reliesOn);
		}
		return reliesOn;
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean mutable, JsonReader reader) {
		//This method is not called - the override processMaintainableProperty with beanRetrievalManager prevents this from being called
		return false;
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean constraint, JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
		Map<String, ComponentBean> components = new HashMap<>();
		if (fieldName.equals("attachments")) {
			ConstraintAttachmentMutableBean attach = new ContentConstraintAttachmentMutableBeanImpl();
			for(String attachment : jReader.readStringArray()) {
				StructureReferenceBean sRef = new StructureReferenceBeanImpl(attachment);
				attach.addStructureReference(sRef);
				if(sRef.getTargetReference() == SDMX_STRUCTURE_TYPE.DATA_PROVIDER) {
					String providerUrn = sRef.getTargetUrn();
					for(ProvisionAgreementBean prov : beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class))) {
						if(prov.getDataproviderRef().getTargetUrn().equals(providerUrn)) {
							addComponentsToMap(prov.getStructureUseage().getReference(), components, beanRetrievalManager);
						}
					}
				} else {
					IURNSingle<? extends IDSDRelatedBean> urn = URN.getInstanceSingle(IDSDRelatedBean.class, attachment);
					addComponentsToMap(urn, components, beanRetrievalManager);
				}
			}
			constraint.setConstraintAttachment(attach);
		} else if(fieldName.equals("includeSeries")) {
			if(constraint.getStructureReferences() != null && constraint.getStructureReferences().size() >0) {
				constraint.setIncludedSeriesKeys(buildSeriesConstraint(jReader, constraint.getStructureReferences().get(0), beanRetrievalManager));
			}
		}  else if(fieldName.equals("excludeSeries")) {
			if(constraint.getStructureReferences() != null && constraint.getStructureReferences().size() >0) {
				constraint.setExcludedSeriesKeys(buildSeriesConstraint(jReader, constraint.getStructureReferences().get(0), beanRetrievalManager));
			}
		} else if(fieldName.equals("includeCube")) {
			constraint.setIncludedCubeRegion(buildCubeRegion(jReader, components));
		} else if(fieldName.equals("excludeCube")) {
			constraint.setExcludedCubeRegion(buildCubeRegion(jReader, components));
		} else if(fieldName.equals("definingDataPresent")) {
			constraint.setIsDefiningActualDataPresent(jReader.getValueAsBoolean());
		} else if(fieldName.equals("releaseCalendar")) {
			constraint.setReleaseCalendar(buildReleaseCalendar(jReader));
		} else {
			return false;
		}
		return true;
	}

	private void addComponentsToMap(IURNSingle<? extends IDSDRelatedBean> sRef, Map<String, ComponentBean> components, SdmxBeanRetrievalManager beanRetrievalManager) {
		DataStructureBean dsd = getDsd(sRef, beanRetrievalManager);
		for(ComponentBean component : dsd.getComponents()) {
			components.put(component.getId(), component);
		}
	}

	private DataStructureBean getDsd(IURNSingle<? extends IDSDRelatedBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		return new DatasetStructures(sRef, beanRetrievalManager).getDataStructure();
	}


	private ReleaseCalendarMutableBean buildReleaseCalendar(JsonReader jReader) {
		ReleaseCalendarMutableBean releaseCalendar = new ReleaseCalendarMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("periodicity")) {
				releaseCalendar.setPeriodicity(value);
			} else if (fieldName.equals("offset")) {
				releaseCalendar.setOffset(value);
			} else if (fieldName.equals("tolerance")) {
				releaseCalendar.setTolerance(value);
			}
		}
		return releaseCalendar;
	}

	private ConstraintDataKeySetMutableBean buildSeriesConstraint(JsonReader jReader, StructureReferenceBean sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		ConstraintDataKeySetMutableBean cds = new ConstraintDataKeySetMutableBeanImpl();
		if(sRef == null) {
			return cds;
		}
		DataStructureBean dsd = getDsd(URN.getInstanceSingle(IDSDRelatedBean.class, sRef.getTargetUrn()), beanRetrievalManager);
		List<DimensionBean> dimensions = dsd.getDimensions();

		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			ConstrainedDataKeyMutableBean key = new ConstrainedDataKeyMutableBeanImpl();
			cds.addConstrainedDataKey(key);
			int count = 0;
			for(String code : jReader.readStringArray()) {
				DimensionBean compId = dimensions.get(count);
				String dimId = compId.getId();
				if(ObjectUtil.validString(code) && !code.equals("*")) {
					key.addKeyValue(KeyValueImpl.getInstance(dimId, code));
				}
				count++;
			}
		}
		return cds;
	}

	private CubeRegionMutableBean buildCubeRegion(JsonReader jReader, Map<String, ComponentBean> componentsd) {
		CubeRegionMutableBean cube = new CubeRegionMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String componentId = jReader.getCurrentFieldName();
			KeyValuesMutable kvs = new KeyValuesMutableImpl();
			kvs.setId(componentId);
			while (jReader.moveNext()) {
				if(jReader.isStartArray()) {
					if(jReader.getCurrentFieldName().equals("values")) {
						kvs.setKeyValues(jReader.readStringArray());
					} else if(jReader.getCurrentFieldName().equals("cascade")) {
						kvs.setCascade(jReader.readStringArray());
					}
				}
				if(jReader.isEndObject()) {
					break;
				}
			}

			ComponentBean comp = componentsd.get(componentId);
			if(comp == null) {
				//This is true in the case where the attachement could not be found
				cube.addKeyValues(kvs);
			} else {
				if(comp.getStructureType() == SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
					cube.addAttributeValue(kvs);
				} else {
					cube.addKeyValues(kvs);
				}
			}
		}
		return cube;
	}

    @Override
    public String getContainerElement() {
        return "ContentConstraint";
    }

    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(ContentConstraintBean.class);
    }

    @Override
    protected Class<ContentConstraintBean> getMaintainableType() {
        return ContentConstraintBean.class;
    }
}
