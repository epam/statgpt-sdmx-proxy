package io.sdmx.format.json.engine;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

/**
 * Provides the core constructs for a JSON API spec JSON message, to be extended by classes to
 * provide the meta and the data content
 * 
 * @param <T> any object that is to be written in the meta and data part of the message
 */
public abstract class AbstractJsonMetaAndDataWriter<T> {
    private JSON_COMPATIBLE_FORMAT format;
    
	public AbstractJsonMetaAndDataWriter(JSON_COMPATIBLE_FORMAT format) {
        this.format = format;
    }

    /**
	 * Writes JSON where the format is based on the JSON API spec which requires a meta and data section
	 * 
	 * {
	 *   "meta" : {  content here  }
	 *   "data" : {  content here  }
	 *   "errors" : [ array of errors ]
	 * }
	 * 
	 * @param obj
	 * @param out
	 */
	protected void writeObject(T obj, OutputStream out) {
		JsonGenerator jsonWriter = JsonWriterUtil.createJsonWriter(out, format);
		try {
			jsonWriter.writeStartObject();
			jsonWriter.writeObjectFieldStart("meta");
			writeMeta(obj, jsonWriter);
			jsonWriter.writeEndObject();
			jsonWriter.writeObjectFieldStart("data");
			writeData(obj, jsonWriter);
			jsonWriter.writeEndObject();
			jsonWriter.writeEndObject();
			jsonWriter.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * the header (meta) section of the message
	 * @param obj
	 * @param jsonWriter
	 */
	protected abstract void writeMeta(T obj, JsonGenerator jsonWriter) throws IOException;
	
	/**
	 * the content section of the message
	 * @param obj
	 * @param jsonWriter
	 */
	protected abstract void writeData(T obj, JsonGenerator jsonWriter) throws IOException;
	
	/**
	 * Default implementation does nothing, can be overridden
	 * @param obj
	 * @param jsonWriter
	 */
	protected void writeErrors(T obj, JsonGenerator jsonWriter) throws IOException {
		//Default is to do nothing
	}
	
	
}
