package io.sdmx.format.json.factory.data;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.format.json.model.FusionJsonDataFormat;
import io.sdmx.format.json.model.SdmxJsonDataFormat;
import io.sdmx.format.json.util.SdmxJsonUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.http.RESTGET;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonDataFormatFactory implements DataFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();
	
	private static SdmxJsonDataFormatFactory INSTANCE;

	//Private constructor - lazy load instance
	public static SdmxJsonDataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxJsonDataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private SdmxJsonDataFormatFactory() {
		addSupportedFormat(new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_1_0_0,null));
		addSupportedFormat(new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_2_0_0,null));
		addSupportedFormat(new FusionJsonDataFormat(null));
		supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}

	@Override
	public Class<DataFormat> getFormatClass() {
		return DataFormat.class;
	}

	private void addSupportedFormat(DataFormat df) {
		String[] acceptHeaders = df.getFormatDetails().getAcceptHeaders();
		for(String acceptHeader : acceptHeaders) {
			supportedFormats.put(acceptHeader, df.getFormatDetails());
		}
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}
	
	@Override
	/**
	 * Will process something like the following:
	 *
	 * sdmx.genericdata+xml;version=2.1
	 * sdmx.structurespecificdata+xml;version=2.1
	 * sdmx.generictimeseriesdata+xml;version=2.1
	 * sdmx.structurespecifictimeseriesdata+xml;version=2.1
	 * sdmx.genericmetadata+xml;version=2.1
	 * sdmx.structurespecificmetadata+xml;version=2.1
	 */
	public DataFormat getFormat(Request request, IVNDHeader vndHeader) {
		String applicationVnd = vndHeader.getVnd();
		String version = vndHeader.getParameterValue("version");
		if(applicationVnd.equals("sdmx.json") ||
				applicationVnd.equals("sdmx.data+json") ||
				applicationVnd.equals("fusion.json") ||
				applicationVnd.equals("fusion.data+json")) {
			IRESTGET get =  request == null ? null : new RESTGET(request, null);
			if(SdmxJsonUtil.LEGACY_MODE) {
				return new FusionJsonDataFormat(get);
			}
			if (applicationVnd.equals("fusion.json") ||  applicationVnd.equals("fusion.data+json")) {
				if (version != null && !version.equals("1.0.0")) {
					throw new SdmxNotAcceptableException("Unsupported Accept format: " + vndHeader.getOriginalVND());
				}
				return new FusionJsonDataFormat(get);
			} else if(applicationVnd.equals("sdmx.json") ||  applicationVnd.equals("sdmx.data+json")) {
				if (version != null && !version.equals("1.0.0") && !version.equals("2.0.0")) {
					throw new SdmxNotAcceptableException("Unsupported Accept format: " + vndHeader.getOriginalVND());
				}
				if (version == null || version.equals("1.0.0")) {
					return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_1_0_0, get);
				} else {
					return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_2_0_0, get);
				}
			}
		}
		return null;
	}

	@Override
	public DataFormat getFormat(String format, Request request) {
		if(format == null) {
			return null;
		}
		String[] split = format.split("-");
		if(split.length == 1) {
			return null;
		}
		format = split[0];
		if(!format.equals("sdmx") && !format.equals("fusion")) {
			return null;
		}
		String sdmxType = split[1];
		String version = split.length == 3 ? split[2] : null;
		if(sdmxType != null) {
			if(sdmxType.equals("json")) {
				IRESTGET getRequest = null;
				try {
					getRequest = new RESTGET(request, null);
				} catch(Throwable th) {}
				if(SdmxJsonUtil.LEGACY_MODE) {
					return new FusionJsonDataFormat(getRequest);
				} else {
					if(format.equals("fusion")) {
						return new FusionJsonDataFormat(getRequest);
					} else {
						if (version == null || version.equals("1.0.0")) {
							return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_1_0_0, getRequest);
						} else if (version.equals("2.0.0")) {
							return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_2_0_0, getRequest);
						}
					}
				}
			}
		}
		return null;
	}

	@Override
	public DataFormat getDataFormat(ReadableDataLocation sourceData) {
		FILE_FORMAT format = sourceData.getFormat();
		if (format == FILE_FORMAT.JSON) {
			try (JsonReader reader = new JsonReader(sourceData);) {
				while (reader.moveNext()) {

					if (reader.isStartObject()) {
						String fieldName = reader.getCurrentFieldName();
						if (fieldName != null) {
							// look for the unique fusionJson 'header' object field
							if ("header".equals(fieldName)) {
								return FusionJsonDataFormat.INSTANCE;
							}
							// look for the unique sdmxJsonV1 'structure' object field
							if ("structure".equals(fieldName)) {
								return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_1_0_0, null);
							}
						}

					} else if (reader.isStartArray()) {
						// look for the unique sdmxJsonV2 'structures' array field
						if ("structures".equals(reader.getCurrentFieldName())) {
							return new SdmxJsonDataFormat(DATA_TYPE.SDMXJSON_2_0_0, null);
						}
					}
				}
			}
		}
		return null;
	}
}
