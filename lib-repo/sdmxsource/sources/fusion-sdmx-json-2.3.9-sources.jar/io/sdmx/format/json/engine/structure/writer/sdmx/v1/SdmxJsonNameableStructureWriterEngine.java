package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;

public abstract class SdmxJsonNameableStructureWriterEngine <T extends NameableBean> extends SdmxJsonIdentifiableStructureWriterEngine<T> {
	
	protected void writeNameable(JsonGenerator jsonGenerator,  NameableBean nameable, IExternalMaintainableLinks externalLinks) throws JsonGenerationException, IOException {
		super.writeIdentifiable(jsonGenerator, nameable, externalLinks);
		SdmxJsonStaticHelper.writeNameable(jsonGenerator, nameable);
	}
}
