package io.sdmx.format.json.engine.metadata.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonMaintainableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;
import io.sdmx.im.mutable.base.TextTypeMutableBeanImpl;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataAttributeMutableBean;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataSetMutableBean;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonMetadataSetReaderEngineV2 implements IMetadataReaderEngine {
	private static final SdmxJsonMetadataSetReaderEngineV2 INSTANCE = new SdmxJsonMetadataSetReaderEngineV2();
	
	private SdmxJsonMetadataSetReaderEngineV2() {}

	public static SdmxJsonMetadataSetReaderEngineV2 getInstance() {
		return INSTANCE;
	}
	
	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) {
		IReferenceMetadataContainer returnContainer = new ReferenceMetadataContainer();
		//TODO HEADER
		try(JsonReader jReader = new JsonReader(rdl)){
			while(jReader.moveNext()) {
				if(jReader.isStartArray() && jReader.getCurrentFieldName().equals("metadataSets")) {
					parseMetadataSets(jReader, returnContainer);
				}
			}
		}
		return returnContainer;
	}
	
	private static void parseMetadataSets(JsonReader jReader, IReferenceMetadataContainer returnContainer) {
		while(jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				returnContainer.addReferenceMetadata(parseMetadataSet(jReader));
			}
		}
	}
	
	private static IReportedMetadataSetBean parseMetadataSet(JsonReader jReader) {
		IReportedMetadataSetMutableBean mds = new ReportedMetadataSetMutableBean();
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonMaintainableUtil.processBean(mds, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "metadataflow" :
				mds.setStructure(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.METADATA_FLOW));
				break;
			case "metadataprovision" :
				mds.setStructure(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.METADATA_PROVISION));
				break;
			case "targets" :
				for(String target : jReader.readStringArray()) {
					mds.addTarget(new StructureReferenceBeanImpl(target));
				}
				break;
			case "attributes" :
				mds.setAttributes(parseAttributes(jReader));
				break;
			}
		}
		return mds.getImmutableInstance();
	}
	
	private static List<IReportedMetadataAttributeMutableBean> parseAttributes(JsonReader jReader) {
		List<IReportedMetadataAttributeMutableBean> attributes = new ArrayList<>();
		while(jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				attributes.add(parseAttribute(jReader));
			}
		}
		return attributes;
	}
	
	
	private static IReportedMetadataAttributeMutableBean parseAttribute(JsonReader jReader) {
		IReportedMetadataAttributeMutableBean attribute = new ReportedMetadataAttributeMutableBean();
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonAnnotableUtil.processBean(attribute, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "id" :
				attribute.setId(jReader.getValueAsString());
				break;
			case "value" :
				if(jReader.isStartObject()) {
					List<TextTypeWrapperMutableBean> text = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
					TextTypeMutableBean tt = new TextTypeMutableBeanImpl();
					tt.setText(text);
					attribute.setStructuredValues(tt);
				} else {
					attribute.setValue(jReader.getValueAsString());
				}
				break;
			case "attributes" :
				attribute.setAttributes(parseAttributes(jReader));
				break;
			}
		}
		return attribute;
	}
}
