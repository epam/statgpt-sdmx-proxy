package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.RulesetMutableBean;
import io.sdmx.im.mutable.transformation.RulesetSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonRulesetSchemeReaderEngineV2 extends SdmxJsonVtlSchemeReaderEngine<IRulesetMutableBean, IRulesetSchemeMutableBean> implements IFusionSingleton {
    private static SdmxJsonRulesetSchemeReaderEngineV2 INSTANCE;

    public static SdmxJsonRulesetSchemeReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxJsonRulesetSchemeReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "rulesetSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IRulesetSchemeBean.class;
    }

    @Override
    protected IRulesetSchemeMutableBean getMutable() {
        return new RulesetSchemeMutableBean();
    }
    
    @Override
    protected boolean processMaintainableProperty(String fieldName, IRulesetSchemeMutableBean mutable, JsonReader reader) {
        if ("vtlMappingScheme".equals(fieldName)) {
            mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        }
        return super.processMaintainableProperty(fieldName, mutable, reader);
    }
    
    @Override
    protected List<IRulesetMutableBean> readItems(JsonReader jReader) {
        List<IRulesetMutableBean> returnList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            if (jReader.isStartObject()) {
                IRulesetMutableBean mutable = readRuleset(jReader);
                returnList.add(mutable);
            }
        }
        return returnList;
    }

    private IRulesetMutableBean readRuleset(JsonReader jReader) {
        IRulesetMutableBean mutable = new RulesetMutableBean();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            if(SdmxJsonNameableUtil.processBean(mutable, jReader)) {
                continue;
            }
            String fieldName = jReader.getCurrentFieldName();
            switch(fieldName) {
            case "rulesetDefinition" :
                mutable.setRulesetDefinition(jReader.getValueAsString());
                break;
            case "rulesetScope" :
                mutable.setRulesetScope(jReader.getValueAsString());
                break;
            case "rulesetType" :
                mutable.setRulesetType(jReader.getValueAsString());
                break;
            }
        }
        return mutable;
    }

    @Override
    protected String getItemLabel() {
        return "rulesets";
    }
}