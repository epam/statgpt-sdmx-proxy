package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonContentConstraintReaderEngineV2 extends SdmxJsonAbstractConstraintReaderEngineV2<ContentConstraintBean, ContentConstraintMutableBean> implements IFusionSingleton {
	
	private static SdmxJsonContentConstraintReaderEngineV2 INSTANCE;

	public static SdmxJsonContentConstraintReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonContentConstraintReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    public String getContainerElement() {
        return "dataConstraints";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ContentConstraintBean.class;
    }

    @Override
    protected ContentConstraintMutableBean getMutable() {
        return new ContentConstraintMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean mutable, JsonReader reader) {
        if(super.readConstraint(mutable, reader)) {
           return true;
        }
        switch(fieldName) {
        case "role":
            mutable.setIsDefiningActualDataPresent(reader.getValueAsString().equals("Actual"));
            return true;
        case "cubeRegions":
            List<DescribedCube> cubes = readCubeReg(reader);
            for (DescribedCube describedSube : cubes) {
                if(describedSube.isIncluded) {
                    mutable.setIncludedCubeRegion(describedSube.cube);
                }else {
                    mutable.setExcludedCubeRegion(describedSube.cube);
                }
            }
            return true;
        case "releaseCalendar":
            Map<String, String> relCalObj = reader.readStringMap();
            ReleaseCalendarMutableBean relCalMut = new ReleaseCalendarMutableBeanImpl();
            String offset = relCalObj.get("offset");
            String periodicity = relCalObj.get("periodicity");
            String tolerance = relCalObj.get("tolerance");
            if(ObjectUtil.validString(offset)) {
                relCalMut.setOffset(offset);
            }
            if(ObjectUtil.validString(periodicity)) {
                relCalMut.setPeriodicity(periodicity);
            }
            if(ObjectUtil.validString(tolerance)) {
                relCalMut.setTolerance(tolerance);
            }
            mutable.setReleaseCalendar(relCalMut);
            return true;
        }
        return false;
    }

	private List<KeyValuesMutable> readKeyValues(JsonReader jReader) {
		List<KeyValuesMutable> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			KeyValuesMutable kv = new KeyValuesMutableImpl();
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String currentFieldName = jReader.getCurrentFieldName();
				switch(currentFieldName) {
				case "id":
					kv.setId(jReader.getValueAsString());
					break;
				case "values":
					readValues(kv, jReader);
					break;
				case "removePrefix" :
					kv.setRemovePrefix(jReader.getValueAsBoolean());
					break;
				default:
					continue;
				}
			}
			ret.add(kv);
		}
		return ret;
	}
	
	private void readValues(KeyValuesMutable kv, JsonReader jReader) {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				readValue(kv, jReader);
			}
		}
	}
	
	private void readValue(KeyValuesMutable kv, JsonReader jReader) {
		String constrainedValue = null;
		boolean excludeRoot = false;
		boolean cascade = false;
		String validFrom = null;
		String validTo = null;
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			String value = jReader.getValueAsString();
			switch(jReader.getCurrentFieldName()) {
			case "value" :
				constrainedValue = value;
				break;
			case "validFrom" :
				validFrom = value;
				break;
			case "validTo" :
				validTo = value;
				break;
			case "cascadeValues" :
				if(value.equals("excluderoot")) {
					excludeRoot = true;
				} else if(value.equalsIgnoreCase("true")) {
					cascade = true;
				}
				break;
			}
		}
		if(!excludeRoot) {
			kv.addValue(constrainedValue);
			if(cascade) {
				kv.addCascade(constrainedValue);
			}
		} else {
			kv.addCascade(constrainedValue);
		}
		if(ObjectUtil.validOneString(validFrom, validTo)) {
			kv.setValidity(constrainedValue, validFrom, validTo);
		}
	}

	private List<DescribedCube> readCubeReg(JsonReader jReader) {
		List<DescribedCube> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			if(!jReader.isStartObject()) {
				continue;
			}
			DescribedCube cubeWrapper = new DescribedCube(new CubeRegionMutableBeanImpl());
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				switch(fieldName) {
				case "include":
					cubeWrapper.isIncluded = jReader.getValueAsBoolean();
					break;
				case "components":
					List<KeyValuesMutable> attras = readKeyValues(jReader);
					cubeWrapper.cube.setAttributeValues(attras);
					break;
				case "keyValues":
					List<KeyValuesMutable> kvs = readKeyValues(jReader);
					cubeWrapper.cube.setKeyValues(kvs);
					break;
				}
			}
			ret.add(cubeWrapper);
		}
		return ret;
	}

	/**
	 *
	 * Describes if this Cube region is "included" or not
	 */
	private class DescribedCube{
		public CubeRegionMutableBean cube;
		public boolean isIncluded;

		public DescribedCube(CubeRegionMutableBean cube) {
			this.cube = cube;
		}
	}
}
