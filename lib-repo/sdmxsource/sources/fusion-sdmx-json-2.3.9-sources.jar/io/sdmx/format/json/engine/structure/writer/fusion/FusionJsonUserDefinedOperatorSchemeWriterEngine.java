package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonUserDefinedOperatorSchemeWriterEngine extends FusionJsonAbstractVTLSchemeWriterEngine<IUserDefinedOperatorSchemeBean> implements IFusionSingleton {
	private static FusionJsonUserDefinedOperatorSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonUserDefinedOperatorSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME);
	}

	public static FusionJsonUserDefinedOperatorSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonUserDefinedOperatorSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IUserDefinedOperatorSchemeBean maint) throws JsonGenerationException, IOException {
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
		if(maint.getRulesetSchemeRef() != null) {
			List<String> urns = maint.getRulesetSchemeRef().stream().map(e->e.getTargetUrn()).collect(Collectors.toList());
			JsonWriterUtil.writeStringArray(jsonGenerator, "rulesetSchemes", urns);
		}
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		IUserDefinedOperatorBean item =  (IUserDefinedOperatorBean)itemBean;
		if(item.getOperatorDefinition() != null) {
			jsonGenerator.writeStringField("operatorDefinition", item.getOperatorDefinition());
		}
	}
}
