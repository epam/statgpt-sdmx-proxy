package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;


public class SdmxJsonTransformationSchemeWriterEngineV2  extends SdmxJsonItemSchemeWriterEngineV2<ITransformationBean, ITransformationSchemeBean> implements IFusionSingleton {
	private static SdmxJsonTransformationSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonTransformationSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonTransformationSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonTransformationSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME);
	}

	
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ITransformationSchemeBean maint) throws JsonGenerationException, IOException {
		if(maint.getVtlVersion() != null) {
			jsonGenerator.writeStringField("vtlVersion", maint.getVtlVersion());
		}
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
		if(maint.getNamePersonalisationSchemeRef() != null) {
			jsonGenerator.writeStringField("namePersonalisationScheme", maint.getNamePersonalisationSchemeRef().getTargetUrn());
		}
		if(maint.getCustomTypeSchemeRef() != null) {
			jsonGenerator.writeStringField("customTypeScheme", maint.getCustomTypeSchemeRef().getTargetUrn());
		}
		writeXSArray(jsonGenerator, maint.getRulesetSchemeRef(), "rulesetSchemes");
		writeXSArray(jsonGenerator, maint.getUserDefinedOperatorSchemeRef(), "userDefinedOperatorSchemes");
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}
	
	//TODO How to best fix with generics?
	private void writeXSArray(JsonGenerator jsonGenerator, List<? extends ICrossReferenceBean<?>> refs, String arrayName) throws IOException {
		if(ObjectUtil.validCollection(refs)) {
			jsonGenerator.writeArrayFieldStart(arrayName);
			for(ICrossReferenceBean<?> xsRef : refs) {
				jsonGenerator.writeString(xsRef.getTargetUrn());
			}
			jsonGenerator.writeEndArray();
		}
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ITransformationBean item) throws JsonGenerationException, IOException {
		if(item.getExpression() != null) {
			jsonGenerator.writeStringField("expression", item.getExpression());
		}
		if(item.getResult() != null) {
			jsonGenerator.writeStringField("result", item.getResult());
		}
		jsonGenerator.writeBooleanField("isPersistent", item.isPersistent());
	}

	@Override
	protected String getItemName() {
		return "transformations";
	}
	
}