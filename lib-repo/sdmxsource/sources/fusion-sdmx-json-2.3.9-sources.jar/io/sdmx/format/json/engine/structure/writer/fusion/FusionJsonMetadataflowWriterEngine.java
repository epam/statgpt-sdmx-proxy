package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonMetadataflowWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<MetadataFlowBean> implements IFusionSingleton {
	private static FusionJsonMetadataflowWriterEngine INSTANCE;

	public static FusionJsonMetadataflowWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataflowWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonMetadataflowWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator,IExternalMaintainableLinks externalLinks, MetadataFlowBean aMetadataflow) throws JsonGenerationException, IOException {
		ICrossReferenceBean<MetadataStructureDefinitionBean> metadataStructureRef = aMetadataflow.getMetadataStructureRef();
		jsonGenerator.writeStringField("metadataStructureRef", metadataStructureRef.getReference().getURN());
		jsonGenerator.writeArrayFieldStart("targets");
		for(ICrossReferenceBeanBase sRef : aMetadataflow.getTargets()) {
			jsonGenerator.writeString(sRef.getReference().getURN());
		}
		jsonGenerator.writeEndArray();
	}
}
