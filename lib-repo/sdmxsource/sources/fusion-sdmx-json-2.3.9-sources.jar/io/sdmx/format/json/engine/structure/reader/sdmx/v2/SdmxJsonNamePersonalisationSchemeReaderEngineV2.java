package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.NamePersonalisationMutableBean;
import io.sdmx.im.mutable.transformation.NamePersonalisationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonNamePersonalisationSchemeReaderEngineV2 extends SdmxJsonVtlSchemeReaderEngine<INamePersonalisationMutableBean, INamePersonalisationSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonNamePersonalisationSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonNamePersonalisationSchemeReaderEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonNamePersonalisationSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}


    @Override
    public String getContainerElement() {
        return "namePersonalisationSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return INamePersonalisationSchemeBean.class;
    }

    @Override
    protected INamePersonalisationSchemeMutableBean getMutable() {
        return new NamePersonalisationSchemeMutableBean();
    }

	@Override
	protected List<INamePersonalisationMutableBean> readItems(JsonReader jReader) {
		List<INamePersonalisationMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				INamePersonalisationMutableBean mutable = readNamePersonalisation(jReader);
				returnList.add(mutable);
			}
		}
		return returnList;
	}

	private INamePersonalisationMutableBean readNamePersonalisation(JsonReader jReader) {
		INamePersonalisationMutableBean mutable = new NamePersonalisationMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if (SdmxJsonNameableUtil.processBean(mutable, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch (fieldName) {
				case "vtlDefaultName":
					mutable.setVtlDefaultName(jReader.getValueAsString());
					break;
				case "personalisedName":
					mutable.setPersonalisedName(jReader.getValueAsString());
					break;
				case "vtlArtefact":
					mutable.setVtlArtefact(jReader.getValueAsString());
					break;
			}
		}
		return mutable;
	}

	@Override
	protected String getItemLabel() {
		return "namePersonalisations";
	}
}
