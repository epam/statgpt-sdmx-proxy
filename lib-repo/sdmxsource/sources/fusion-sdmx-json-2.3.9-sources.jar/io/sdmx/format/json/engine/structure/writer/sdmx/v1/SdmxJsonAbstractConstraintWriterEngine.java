package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.reference.DataAndMetadataSetReference;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;

public abstract class SdmxJsonAbstractConstraintWriterEngine<T extends ConstraintBean> extends SdmxJsonMaintainableStructureWriterEngine<T> {


	protected SdmxJsonAbstractConstraintWriterEngine(SDMX_STRUCTURE_TYPE sypportedType) {
		super(sypportedType);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  T maint) throws JsonGenerationException, IOException {
		writeConstraintAttachement(maint.getConstraintAttachment(), jsonGenerator);
		List<ConstraintDataKeySetBean> constraintList = getAsList(maint);
		writeKeySet(constraintList, jsonGenerator, maint);
	}

	private List<ConstraintDataKeySetBean> getAsList(T maint){
		List<ConstraintDataKeySetBean> retList =  new ArrayList<>();
		ConstraintDataKeySetBean includedSeriesKeys = maint.getIncludedSeriesKeys();
		ConstraintDataKeySetBean excludedSeriesKeys = maint.getExcludedSeriesKeys();

		if(includedSeriesKeys != null) {
			retList.add(includedSeriesKeys);
		}

		if(excludedSeriesKeys != null) {
			retList.add(excludedSeriesKeys);
		}
		return retList;
	}

	private boolean isIncluded(ConstraintDataKeySetBean keySet, T maint) {
		if(keySet == maint.getIncludedSeriesKeys()) {
			return true;
		}
		if(keySet == maint.getExcludedSeriesKeys()) {
			return false;
		}
		throw new RuntimeException("Unable to parse ConstraintDataKeySetBean");
	}


	private void writeKeySet(List<ConstraintDataKeySetBean> keySet, JsonGenerator jsonGenerator, T maint) throws IOException {
		if(keySet.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("dataKeySets");
		for(ConstraintDataKeySetBean dataKey: keySet) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeBooleanField("isIncluded", isIncluded(dataKey, maint));
			jsonGenerator.writeArrayFieldStart("keys");
			for(ConstrainedDataKeyBean key : dataKey.getConstrainedDataKeys()) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeArrayFieldStart("keyValues");
				for(KeyValue kv : key.getKeyValues()) {
					jsonGenerator.writeStartObject();
					SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", kv.getConcept());
					SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "value", kv.getCode());
					jsonGenerator.writeEndObject();
				}
				jsonGenerator.writeEndArray();

				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	//TODO: check this
	private void writeConstraintAttachement(ConstraintAttachmentBean constraintAttachment, JsonGenerator jsonGenerator) throws IOException {
		if(constraintAttachment == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("constraintAttachment");
		if(constraintAttachment.getDataOrMetadataSetReference() != null) {
			//TODO test
			DataAndMetadataSetReference dsRef = constraintAttachment.getDataOrMetadataSetReference();
			if(dsRef.isDataSetReference()) {
				jsonGenerator.writeObjectFieldStart("dataSet");
			}else {
				jsonGenerator.writeObjectFieldStart("metadataSet");
			}
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "dataProvider", dsRef.getDataSetReference().getTargetUrn());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", dsRef.getSetId());
			jsonGenerator.writeEndObject();
		}
		if(!constraintAttachment.getStructureReference().isEmpty()) {
			Set<IDirectCrossReferenceBean<?>> structureReferences = constraintAttachment.getStructureReference();
			Set<IDirectCrossReferenceBean<?>> dsdRefs = filterCrossRef(SDMX_STRUCTURE_TYPE.DSD, structureReferences);
			Set<IDirectCrossReferenceBean<?>> dataFlowRefs = filterCrossRef(SDMX_STRUCTURE_TYPE.DATAFLOW, structureReferences);
			Set<IDirectCrossReferenceBean<?>> msdRefs = filterCrossRef(SDMX_STRUCTURE_TYPE.MSD, structureReferences);
			Set<IDirectCrossReferenceBean<?>> metadataflowRefs = filterCrossRef(SDMX_STRUCTURE_TYPE.METADATA_FLOW, structureReferences);
			Set<IDirectCrossReferenceBean<?>> paRefs = filterCrossRef(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, structureReferences);
			if(!dsdRefs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("dataStructures");
				for(ICrossReferenceBean<?> ref: dsdRefs) {
					writeReference(ref, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}
			if(!dataFlowRefs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("dataflows");
				for(ICrossReferenceBean<?> ref: dataFlowRefs) {
					writeReference(ref, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}
			if(!msdRefs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("metadataStructures");
				for(ICrossReferenceBean<?> ref: msdRefs) {
					writeReference(ref, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}
			if(!metadataflowRefs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("metadataflows");
				for(ICrossReferenceBean<?> ref: metadataflowRefs) {
					writeReference(ref, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}
			if(!paRefs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("provisionAgreements");
				for(ICrossReferenceBean<?> ref: paRefs) {
					writeReference(ref, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}

		}
		if(constraintAttachment.getDataSources() != null && !constraintAttachment.getDataSources().isEmpty()) {
			DataSourceBean simpleDs = constraintAttachment.getDataSources().stream()
					.filter(DataSourceBean::isSimpleDatasource)
					.findFirst()
					.orElse(null);
			if(simpleDs != null){
				SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "simpleDataSource", simpleDs.getDataUrl().toString());
			}

			List<DataSourceBean> queryDs = constraintAttachment.getDataSources().stream()
					.filter(ds -> !ds.isSimpleDatasource())
					.collect(Collectors.toList());
			if(!queryDs.isEmpty()) {
				jsonGenerator.writeArrayFieldStart("queryableDataSources");
				for(DataSourceBean qDs: queryDs) {
					jsonGenerator.writeStartObject();
					jsonGenerator.writeBooleanField( "isRESTDatasource", qDs.isRESTDatasource());
					jsonGenerator.writeBooleanField( "isWebServiceDatasource", qDs.isWebServiceDatasource());
					if( qDs.getDataUrl() != null) {
						SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "dataURL", qDs.getDataUrl().toString());
					}
					if( qDs.getWadlUrl() != null) {
						SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "wadlURL", qDs.getWadlUrl().toString());
					}
					if( qDs.getWSDLUrl() != null) {
						SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "wsdlURL", qDs.getWSDLUrl().toString());
					}
					jsonGenerator.writeEndObject();
				}
				jsonGenerator.writeEndArray();
			}
		}
		jsonGenerator.writeEndObject();
	}

	private void writeReference(ICrossReferenceBean<?> xsRef, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeString(xsRef.getTargetUrn());
	}
	private Set<IDirectCrossReferenceBean<?>> filterCrossRef(SDMX_STRUCTURE_TYPE strucType, Set<IDirectCrossReferenceBean<?>> set){
		return set.stream().filter(xsRef -> xsRef.getTargetReference() == strucType).collect(Collectors.toSet());
	}
}
