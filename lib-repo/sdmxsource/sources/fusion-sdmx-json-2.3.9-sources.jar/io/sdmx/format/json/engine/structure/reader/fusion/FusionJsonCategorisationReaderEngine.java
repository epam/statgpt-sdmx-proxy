package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonCategorisationReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<CategorisationBean, CategorisationMutableBean> implements IFusionSingleton {
	private static FusionJsonCategorisationReaderEngine INSTANCE;

	public static FusionJsonCategorisationReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCategorisationReaderEngine();
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected CategorisationMutableBean getMutable() {
		return new CategorisationMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, CategorisationMutableBean mutable, JsonReader jReader) {
		String value = jReader.getValueAsString();
		if (fieldName.equals("structureReference")) {
			mutable.setStructureReference(new StructureReferenceBeanImpl(value));
		} else if (fieldName.equals("categoryReference")) {
			mutable.setCategoryReference(new StructureReferenceBeanImpl(value));
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<CategorisationBean> getMaintainableType() {
        return CategorisationBean.class;
    }
}