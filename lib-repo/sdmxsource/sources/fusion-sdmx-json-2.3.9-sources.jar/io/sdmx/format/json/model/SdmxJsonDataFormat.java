package io.sdmx.format.json.model;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonDataFormat extends SdmxDataFormat implements DataFormat {
	private static final long serialVersionUID = -1461535945154796477L;

	private final FormatDetails formatDetails;
	private final IRESTGET dataQuery;

	public SdmxJsonDataFormat(DATA_TYPE dataType, IRESTGET dataQuery) {
		super(dataType);
		this.dataQuery = dataQuery;

		if (dataType == DATA_TYPE.SDMXJSON_1_0_0) {
			formatDetails = new FormatDetailsImpl("SDMX-JSON-V1", MIME_TYPE.APPLICATION_JSON, true, true, "application/vnd.sdmx.data+json;version=1.0.0");
		} else if (dataType == DATA_TYPE.SDMXJSON_2_0_0) {
			formatDetails = new FormatDetailsImpl("SDMX-JSON-V2", MIME_TYPE.APPLICATION_JSON, true, true, "application/vnd.sdmx.data+json;version=2.0.0");
		} else {
			throw new IllegalArgumentException("SdmxJsonDataFormat can only take formats DATA_TYPE.SDMXJSON_1_0_0 or DATA_TYPE.SDMXJSON_2_0_0");
		}
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	public IRESTGET getRestDataQuery() {
		return dataQuery;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxJsonDataFormat) {
			SdmxJsonDataFormat that = (SdmxJsonDataFormat)obj;
			
			return ObjectUtil.equivalent(that.getRestDataQuery(), this.getRestDataQuery());
		}
		return false;
	}

	@Override
	public String toString() {
		if(dataQuery != null) {
			return formatDetails.getAcceptHeaders()[0] +dataQuery.toURL();
		}
		return formatDetails.getAcceptHeaders()[0];
	}
}
