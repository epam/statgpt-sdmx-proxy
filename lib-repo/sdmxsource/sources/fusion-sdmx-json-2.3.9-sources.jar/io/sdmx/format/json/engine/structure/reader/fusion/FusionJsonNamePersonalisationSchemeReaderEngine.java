package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.NamePersonalisationMutableBean;
import io.sdmx.im.mutable.transformation.NamePersonalisationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonNamePersonalisationSchemeReaderEngine extends FusionJsonAbstractVTLSchemeReaderEngine<INamePersonalisationSchemeBean, INamePersonalisationSchemeMutableBean, INamePersonalisationMutableBean>
                                                            implements IFusionSingleton {
	private static FusionJsonNamePersonalisationSchemeReaderEngine INSTANCE;

	public static FusionJsonNamePersonalisationSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonNamePersonalisationSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected INamePersonalisationSchemeMutableBean getMutable() {
		return new NamePersonalisationSchemeMutableBean();
	}

	@Override
	protected INamePersonalisationMutableBean readItemBean(JsonReader jReader) {
		INamePersonalisationMutableBean item =  new NamePersonalisationMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(item, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("vtlArtefact")) {
				item.setVtlArtefact(value);
			} else if (fieldName.equals("vtlDefaultName")) {
				item.setVtlDefaultName(value);
			} else if (fieldName.equals("personalisedName")) {
				item.setPersonalisedName(value);
			}
		}
		return item;
	}

    @Override
    protected Class<INamePersonalisationSchemeBean> getMaintainableType() {
        return INamePersonalisationSchemeBean.class;
    }
}
