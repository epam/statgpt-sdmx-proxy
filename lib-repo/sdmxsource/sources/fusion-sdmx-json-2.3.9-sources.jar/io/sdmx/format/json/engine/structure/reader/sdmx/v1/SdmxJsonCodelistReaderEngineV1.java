package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonCodelistReaderEngineV1 extends SdmxJsonItemSchemeReaderEngineV1<CodeMutableBean, CodelistMutableBean> implements IFusionSingleton {
	private static SdmxJsonCodelistReaderEngineV1 INSTANCE;

	public static SdmxJsonCodelistReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCodelistReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    protected CodelistMutableBean build(JsonReader jReader, IBeansBuilder beanBuilder, SdmxBeanRetrievalManager beanRetrievalManager) {
	    CodelistMutableBean mutable = super.build(jReader, beanBuilder, beanRetrievalManager);
	    ValidityPeriodUtil.processValidityAnnotations(mutable);
	    return mutable;
	}
	
	private CodeMutableBean readCodeBean(JsonReader jReader) {
		CodeMutableBean aCode = new CodeMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(aCode, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parent")) {
				aCode.setParentCode(value);
			}
		}
		return aCode;
	}

	@Override
	protected List<CodeMutableBean> readItems(JsonReader jReader) {
		List<CodeMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				CodeMutableBean aCode = readCodeBean(jReader);
				returnList.add(aCode);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "codes";

	}

    @Override
    protected CodelistMutableBean getMutable() {
        return new CodelistMutableBeanImpl();
    }

    @Override
    public String getContainerElement() {
        return "codelists";
    }

    @Override
    protected Class<CodelistBean> getMaintainableType() {
        return CodelistBean.class;
    }
}
