package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.metadatastructure.MetadataProvisionAgreementMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonMetadataProvisionReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<MetadataProvisionAgreementBean, IMetadataProvisionAgreementMutableBean> implements IFusionSingleton {
	private static FusionJsonMetadataProvisionReaderEngine INSTANCE;

	public static FusionJsonMetadataProvisionReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataProvisionReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IMetadataProvisionAgreementMutableBean getMutable() {
		return new MetadataProvisionAgreementMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IMetadataProvisionAgreementMutableBean mutable, JsonReader jReader) {
		String value = jReader.getValueAsString();
		if (fieldName.equals("metadataflowRef")) {
			StructureReferenceBean structureUsage = new StructureReferenceBeanImpl(value);
			mutable.setMetadataflowRef(structureUsage);
		} else if (fieldName.equals("metadataproviderRef")) {
			StructureReferenceBean dataproviderRef = new StructureReferenceBeanImpl(value);
			mutable.setMetadataProviderRef(dataproviderRef);
		} else if (fieldName.equals("targets")) {
			for(String target : jReader.readStringArray()) {
				StructureReferenceBean targetRef = new StructureReferenceBeanImpl(target);
				mutable.addTarget(targetRef);
			}
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<MetadataProvisionAgreementBean> getMaintainableType() {
        return MetadataProvisionAgreementBean.class;
    }
}