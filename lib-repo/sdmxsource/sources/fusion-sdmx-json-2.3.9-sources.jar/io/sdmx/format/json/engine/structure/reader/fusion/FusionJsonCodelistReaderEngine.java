package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonCodelistReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<CodelistBean, CodelistMutableBean, CodeMutableBean> implements IFusionSingleton {
	private static FusionJsonCodelistReaderEngine INSTANCE;

	public static FusionJsonCodelistReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCodelistReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected CodelistMutableBean getMutable() {
		return new CodelistMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, CodelistMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			if (fieldName.equals("validityType")){
				String value = jReader.getValueAsString();
				mutable.setValidityType(MAINT_VALIDITY_TYPE.getValidityType(value));
			} else if (fieldName.equals("extends")) {
				readExtensions(mutable, jReader);
			} else if(fieldName.equals("inheritanceResolved")) {
				mutable.setInherited(jReader.getValueAsBoolean());
				
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
    protected CodeMutableBean readItemBean(JsonReader jReader) {
		CodeMutableBean aCode = new CodeMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(aCode, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parentCode")) {
				aCode.setParentCode(value);
			}
			if (fieldName.equals("isInherited") && value.equalsIgnoreCase("true")) {
				aCode.setInherited(true);  //important change, this is now preseerved on read
			}
		}
		return aCode;
	}
	
	private void readExtensions(CodelistMutableBean cl, JsonReader jReader) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				readInheritanceRuleBean(cl, jReader);
			}
		}
	}

	private void readInheritanceRuleBean(CodelistMutableBean cl, JsonReader jReader) {
		ICodelistInheritanceRuleMutableBean rule = new CodelistInheritanceRuleMutableBean();
		cl.addInheritenceRules(rule);
		
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("prefix")) {
				rule.setPrefix(jReader.getValueAsString());
			} else if(fieldName.equals("codelistRef")) {
				rule.setCodelistRef(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.CODE_LIST));
			} else if(fieldName.equals("include")) {
				readInheritanceMembers(rule, true, jReader);
			} else if(fieldName.equals("exclude")) {
				readInheritanceMembers(rule, false, jReader);
			}
		}
	}
	
	private void readInheritanceMembers(ICodelistInheritanceRuleMutableBean rule, boolean included, JsonReader jReader)  {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("values")) {
				if(included) {
					rule.setInclusiveInheritenceIds(jReader.readStringArray());
				} else {
					rule.setExclusiveInheritenceIds(jReader.readStringArray());
				}
			} else if(fieldName.equals("cascade")) {
				if(included) {
					rule.setInclusiveInheritenceCascades(jReader.readStringSet());
				} else {
					rule.setExclusiveInheritenceCascades(jReader.readStringSet());
				}
			}
		}
	}

    @Override
    protected Class<CodelistBean> getMaintainableType() {
        return CodelistBean.class;
    }
}