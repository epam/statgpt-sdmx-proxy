package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonConceptWriterEngine extends FusionJsonNameableStructureWriterEngine<ConceptBean> implements IFusionSingleton {
	private static FusionJsonConceptWriterEngine INSTANCE;

	public static FusionJsonConceptWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonConceptWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonConceptWriterEngine() {}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ConceptBean concept) throws JsonGenerationException, IOException {
		if(concept.getRepresentation() != null) {
			FusionJsonStaticHelper.writeRepresentation(jsonGenerator, concept.getRepresentation());
		}
		if(concept.getIsoConceptReference() != null) {
			jsonGenerator.writeStringField("isoConceptReference",concept.getIsoConceptReference().getReference().getURN());
		}
	}
}
