package io.sdmx.format.json.engine.structure.reader.util;

import java.util.Map;

import io.sdmx.api.sdmx.constants.LINK_REL;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonLinkableUtil {

	public static boolean processBean(MutableBean bean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		if (fieldName.equals("links")) {
			while (jReader.moveNext()) {
				if(jReader.isEndArray()) {
					break;
				}
				if(jReader.isStartObject()) {
					Map<String, String> kvMap = jReader.readStringMap();
					String relStr = kvMap.get("rel");

					if(relStr == null) {
						continue;
					}
					if(relStr.equals(LINK_REL.SELF.toString())) {
						continue;
					}
					String uri = kvMap.get("uri");
					if(ObjectUtil.validString(uri)) {
						if(bean instanceof IdentifiableMutableBean) {
							((IdentifiableMutableBean) bean).setUri(uri);
						}
					}

					String href = kvMap.get("href");
					if(ObjectUtil.validString(href)) {
						if(bean instanceof MaintainableMutableBean) {
							((MaintainableMutableBean) bean).setExternalReference(true);
							((MaintainableMutableBean) bean).setStructureURL(href);
						}
					}

				}
			}
			return true;
		}
		return false;
	}
}
