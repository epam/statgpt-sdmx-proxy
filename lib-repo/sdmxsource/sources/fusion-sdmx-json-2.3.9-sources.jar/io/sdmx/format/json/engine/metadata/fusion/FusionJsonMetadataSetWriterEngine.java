package io.sdmx.format.json.engine.metadata.fusion;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.writer.fusion.FusionJsonMaintainableStructureWriterEngineImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonMetadataSetWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<IReportedMetadataSetBean>   {
	private static final FusionJsonMetadataSetWriterEngine INSTANCE = new FusionJsonMetadataSetWriterEngine();

	private FusionJsonMetadataSetWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.METADATA_SET);
	}

	public static FusionJsonMetadataSetWriterEngine getInstance() {
		return INSTANCE;
	}
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonWriter, IExternalMaintainableLinks externalLinks, IReportedMetadataSetBean mds) throws JsonGenerationException, IOException {
		ICrossReferenceBean<? extends IMetadataTargetIdentifier> crb = mds.getStructure();
		if (crb != null) {
			if (crb.getMaintainableStructureType() == SDMX_STRUCTURE_TYPE.METADATA_PROVISION) {
				jsonWriter.writeStringField(FusionJsonMetadataSyntaxConstants.METADATAPROVISION, mds.getStructure().getTargetUrn());
			} else {
				jsonWriter.writeStringField(FusionJsonMetadataSyntaxConstants.METADATAFLOW, mds.getStructure().getTargetUrn());
			}
		}
		JsonWriterUtil.writeStringArray(jsonWriter, FusionJsonMetadataSyntaxConstants.TARGETS, mds.getTargets().stream().map(e->e.getReference().getURN()).collect(Collectors.toList()));
		writeMetadataAttributes(mds.getAttributes(), externalLinks, jsonWriter);
	}


	private void writeMetadataAttributes(List<IReportedMetadataAttributeBean> attributes, IExternalMaintainableLinks externalLinks, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeArrayFieldStart(FusionJsonMetadataSyntaxConstants.ATTRIBUTES);
		for(IReportedMetadataAttributeBean attribute : attributes) {
			writeMetadataAttribute(attribute, externalLinks, jsonWriter);
		}
		jsonWriter.writeEndArray();
	}

	private void writeMetadataAttribute(IReportedMetadataAttributeBean attribute, IExternalMaintainableLinks externalLinks, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeStartObject();
		jsonWriter.writeStringField("id", attribute.getId());
		if(attribute.getValue() != null) {
			jsonWriter.writeStringField(FusionJsonMetadataSyntaxConstants.SIMPLE_VALUE, attribute.getValue());
		}
		if(attribute.getStructuredValue() != null) {
			jsonWriter.writeObjectFieldStart(FusionJsonMetadataSyntaxConstants.COMPLEX_VALUE);
			for (TextTypeWrapper textTypeWrapper : attribute.getStructuredValue().getText()) {
				jsonWriter.writeStringField(textTypeWrapper.getLocale(), textTypeWrapper.getValue());
			}
			jsonWriter.writeEndObject();
		}
		if(ObjectUtil.validCollection(attribute.getAttributes())) {
			writeMetadataAttributes(attribute.getAttributes(), externalLinks, jsonWriter);
		}
		jsonWriter.writeEndObject();
	}
}
