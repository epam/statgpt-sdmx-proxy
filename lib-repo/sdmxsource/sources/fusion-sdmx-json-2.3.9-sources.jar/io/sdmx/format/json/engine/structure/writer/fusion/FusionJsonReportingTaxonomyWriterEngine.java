package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonReportingTaxonomyWriterEngine extends FusionJsonItemSchemeWriterEngine<ReportingTaxonomyBean> implements IFusionSingleton {
	private static FusionJsonReportingTaxonomyWriterEngine INSTANCE;

	public static FusionJsonReportingTaxonomyWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonReportingTaxonomyWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonReportingTaxonomyWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  ItemBean item) throws JsonGenerationException, IOException  {
		ReportingCategoryBean hItem = (ReportingCategoryBean)item;
		writeReferences(jsonGenerator, "structuralMetadata", hItem.getStructuralMetadata());
		writeReferences(jsonGenerator, "provisioningMetadata", hItem.getProvisioningMetadata());
		writeItems(jsonGenerator,  externalLinks, hItem.getItems());
	}
	
	private void writeReferences(JsonGenerator jsonGenerator, String arrayName, List<ICrossReferenceBean<?>> refs) throws IOException {
		if(!ObjectUtil.validCollection(refs)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(arrayName);
		for(ICrossReferenceBean<?> ref : refs) {
			jsonGenerator.writeString(ref.getTargetUrn());
		}
		jsonGenerator.writeEndArray();
	}

	@Override
	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  List<? extends ItemBean> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}

		jsonGenerator.writeArrayFieldStart("items");
		for(ItemBean currentItem : items) {
			writeItem(jsonGenerator, externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}
}