package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.mapping.v3.OrganisationMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.OrganisationSchemeMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonOrganisationSchemeMapReaderEngineV2 extends SdmxJsonItemSchemeMapReaderEngineV2<IOrganisationMapMutableBean, IOrganisationSchemeMapMutableBean> implements IFusionSingleton {
	private static SdmxJsonOrganisationSchemeMapReaderEngineV2 INSTANCE;

	public static SdmxJsonOrganisationSchemeMapReaderEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonOrganisationSchemeMapReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "organisationSchemeMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IOrganisationSchemeMapBean.class;
    }

    @Override
    protected IOrganisationSchemeMapMutableBean getMutable() {
        return new OrganisationSchemeMapMutableBean();
    }
    
	@Override
	protected IOrganisationMapMutableBean getItemMapMutable() {
		return new OrganisationMapMutableBean();
	}
}
