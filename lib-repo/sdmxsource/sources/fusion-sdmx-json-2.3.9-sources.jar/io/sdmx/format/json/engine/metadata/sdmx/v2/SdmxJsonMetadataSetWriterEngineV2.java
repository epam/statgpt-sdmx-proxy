package io.sdmx.format.json.engine.metadata.sdmx.v2;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.engine.metadata.fusion.FusionJsonMetadataSyntaxConstants;
import io.sdmx.format.json.engine.structure.writer.sdmx.v2.SdmxJsonMaintainableStructureWriterEngineV2;
import io.sdmx.format.json.util.SdmxJsonWriterUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

public class SdmxJsonMetadataSetWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<IReportedMetadataSetBean> implements IMetadataWriterEngine   {
	private static final SdmxJsonMetadataSetWriterEngineV2 INSTANCE = new SdmxJsonMetadataSetWriterEngineV2();

	private SdmxJsonMetadataSetWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.METADATA_SET);
	}

	public static SdmxJsonMetadataSetWriterEngineV2 getInstance() {
		return INSTANCE;
	}

	@Override
	public void write(IReferenceMetadataContainer container, OutputStream out) {
		try(JsonGenerator jsonWriter = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)) {
			jsonWriter.writeStartObject();
			SdmxJsonWriterUtil.writeMeta(jsonWriter, container, SDMX_JSON_SCHEMA.REF_METADATA_V2);
			writeDataSection(container, null, jsonWriter);  //it could be that we have links in the future, so leave all these in place as they do no harm
			jsonWriter.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private void writeDataSection(IReferenceMetadataContainer metadata, IExternalMaintainableLinks externalLinks, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeObjectFieldStart("data");
		jsonWriter.writeArrayFieldStart("metadataSets");
		for(IReportedMetadataSetBean mds : metadata.getReferenceMetadata()) {
			writeStructure(jsonWriter, externalLinks, mds);
		}
		jsonWriter.writeEndArray();
		jsonWriter.writeEndObject();
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonWriter, IExternalMaintainableLinks externalLinks, IReportedMetadataSetBean mds) throws JsonGenerationException, IOException {
		if(mds.getStructure() != null) {
			String type = mds.getStructure().getReference().isType(MetadataProvisionAgreementBean.class) ? FusionJsonMetadataSyntaxConstants.METADATAPROVISION : FusionJsonMetadataSyntaxConstants.METADATAFLOW;
			jsonWriter.writeStringField(type, mds.getStructure().getReference().toURNString());
		}
		JsonWriterUtil.writeStringArray(jsonWriter, "targets", mds.getTargets().stream().map(e->e.getReference().toURNString()).collect(Collectors.toList()));
		writeMetadataAttributes(mds.getAttributes(), externalLinks, jsonWriter);
	}


	private void writeMetadataAttributes(List<IReportedMetadataAttributeBean> attributes, IExternalMaintainableLinks externalLinks, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeArrayFieldStart("attributes");
		for(IReportedMetadataAttributeBean attribute : attributes) {
			writeMetadataAttribute(attribute, externalLinks, jsonWriter);
		}
		jsonWriter.writeEndArray();
	}

	private void writeMetadataAttribute(IReportedMetadataAttributeBean attribute, IExternalMaintainableLinks externalLinks, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeStartObject();
		jsonWriter.writeStringField("id", attribute.getId());
		if(attribute.getValue() != null) {
			jsonWriter.writeStringField("value", attribute.getValue());
		}
		if(attribute.getStructuredValue() != null) {
			jsonWriter.writeObjectFieldStart("value");
			for (TextTypeWrapper textTypeWrapper : attribute.getStructuredValue().getText()) {
				jsonWriter.writeStringField(textTypeWrapper.getLocale(), textTypeWrapper.getValue());
			}
			jsonWriter.writeEndObject();
		}
		if(ObjectUtil.validCollection(attribute.getAttributes())) {
			writeMetadataAttributes(attribute.getAttributes(), externalLinks, jsonWriter);
		}
		jsonWriter.writeEndObject();
	}
}
