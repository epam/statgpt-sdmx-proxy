package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.writer.ISdmxJsonMaintainableStructureWriterEngine;

public abstract class SdmxJsonMaintainableStructureWriterEngine <T extends MaintainableBean> extends SdmxJsonNameableStructureWriterEngine<T> implements ISdmxJsonMaintainableStructureWriterEngine<T>{

	private SDMX_STRUCTURE_TYPE supportedType;

	protected SdmxJsonMaintainableStructureWriterEngine(SDMX_STRUCTURE_TYPE sypportedType) {
		this.supportedType = sypportedType;
	}

	@Override
	public void writeStructure(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T maintainable) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		super.writeNameable(jsonGenerator, maintainable, externalLinks);
		jsonGenerator.writeStringField("version", maintainable.getVersion().toString());
		jsonGenerator.writeStringField("agencyID", maintainable.getAgencyId());
		jsonGenerator.writeBooleanField("isExternalReference", maintainable.isExternalReference());
		jsonGenerator.writeBooleanField("isFinal", maintainable.isFinal());
		if(maintainable.hasValidityPeriod()) {
			writeDate(jsonGenerator, "validFrom", maintainable.getValidityPeriod().getStartPeriod());
			writeDate(jsonGenerator, "validTo", maintainable.getValidityPeriod().getEndPeriod());
		}
		writeStructureInternal(jsonGenerator, externalLinks, maintainable);
		jsonGenerator.writeEndObject();
	}

	private void writeDate(JsonGenerator jsonGenerator, String fieldName, SdmxDate aDate) throws IOException {
		if (aDate == null) {
			return;
		}
		String date = aDate.getDateInSdmxFormat();
		jsonGenerator.writeStringField(fieldName, date);
	}

	@Override
	public SDMX_STRUCTURE_TYPE getSupportedType() {
		return this.supportedType;
	}
}
