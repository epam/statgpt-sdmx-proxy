package io.sdmx.format.json.engine.structure.reader.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonNameableUtil {


	public static boolean processBean(NameableMutableBean nameable, JsonReader jReader) {
		return SdmxJsonIdentifiableUtil.processBean(nameable, jReader) || processNode(nameable, jReader);
	}

	private static boolean processNode(NameableMutableBean nameableMutableBean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();

		if (fieldName.equals("names")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = readTextTypeWrappers(jReader);
			nameableMutableBean.setNames(new ArrayList<>());
			for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
				nameableMutableBean.addName(ttw);
			}
			return true;
		}
		if (fieldName.equals("descriptions")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = readTextTypeWrappers(jReader);
			nameableMutableBean.setDescriptions(new ArrayList<>());
			for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
				nameableMutableBean.addDescription(ttw);
			}
			return true;
		} 
		
		if(fieldName.equals("name")){
			if(!ObjectUtil.validCollection(nameableMutableBean.getNames())) {
				nameableMutableBean.addName("en", jReader.getValueAsString());
			}
			return true;
		} else if(fieldName.equals("description")) {
			if(!ObjectUtil.validCollection(nameableMutableBean.getDescriptions())) {
				nameableMutableBean.addDescription("en", jReader.getValueAsString());
			}
			return true;
		}
		return false;
	}

	public static List<TextTypeWrapperMutableBean> readTextTypeWrappers(JsonReader jReader) {
		// JReader is at the start of an object
		List<TextTypeWrapperMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			TextTypeWrapperMutableBean ttw = addTextTypeWrapper(jReader);
			if (ttw != null) {
				returnList.add(ttw);
			}
		}
		return returnList;
	}

	private static TextTypeWrapperMutableBean addTextTypeWrapper(JsonReader jReader) {
		TextTypeWrapperMutableBean ttw = new TextTypeWrapperMutableBeanImpl();
		String locale = jReader.getCurrentFieldName();
		String value = jReader.getValueAsString();
		ttw.setLocale(locale);
		ttw.setValue(value);
		if (ObjectUtil.validString(ttw.getValue()) && ObjectUtil.validString(ttw.getLocale())) {
			return ttw;
		}
		return null;
	}
}