package io.sdmx.format.json.engine.structure.reader.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonContactUtil {
	public static List<ContactMutableBean> readContacts(JsonReader jReader){
		List<ContactMutableBean> retList = new ArrayList<>();
		String fieldName = jReader.getCurrentFieldName();
		if (fieldName.equals("contacts")) {
			List<ContactMutableBean> contacts = readContactsList(jReader);
			for (ContactMutableBean aContact : contacts) {
				retList.add(aContact);
			}
		}
		return retList;
	}
	
	private static List<ContactMutableBean> readContactsList(JsonReader jReader) {
		List<ContactMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ContactMutableBean aContact = readContact(jReader);
				returnList.add(aContact);
			}
		}
		return returnList;
	}
	
	private static ContactMutableBean readContact(JsonReader jReader) {
		ContactMutableBean aContact = new ContactMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("departments")) {
				List<TextTypeWrapperMutableBean> departments = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setDepartments(departments);
			} else if (fieldName.equals("roles")) {
				List<TextTypeWrapperMutableBean> roles = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setRoles(roles);
			} else if (fieldName.equals("names")) {
				List<TextTypeWrapperMutableBean> names = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setNames(names);
			} else if (fieldName.equals("telephones")) {
				if (value != null) {
					aContact.addTelephone(value);
				}
			} else if (fieldName.equals("faxes")) {
				if (value != null) {
					aContact.addFax(value);
				}
			} else if (fieldName.equals("emails")) {
				if (value != null) {
					aContact.addEmail(value);
				}
			} else if (fieldName.equals("x400s")) {
				if (value != null) {
					aContact.addX400(value);
				}
			} else if (fieldName.equals("uris")) {
				if (value != null) {
					aContact.addUri(value);
				}
			}  else if (fieldName.equals("id")) {
				if (value != null) {
					aContact.setId(value);
				}
			}
		}

		return aContact;
	}
}
