package io.sdmx.format.json.engine.metadata.fusion;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.format.json.util.SdmxJsonWriterUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonMetadataWriterEngine implements IMetadataWriterEngine {

	private static final FusionJsonMetadataWriterEngine INSTANCE = new FusionJsonMetadataWriterEngine();

	private FusionJsonMetadataWriterEngine() {}

	public static FusionJsonMetadataWriterEngine getInstance() {
		return INSTANCE;
	}

	@Override
	public void write(IReferenceMetadataContainer container, OutputStream out) {
		try(JsonGenerator jsonWriter = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)) {
			jsonWriter.writeStartObject();
			SdmxJsonWriterUtil.writeMeta(jsonWriter, container, null, KeyValueImpl.getInstance("format", "fusionjson"));
			jsonWriter.writeObjectFieldStart("data");
			jsonWriter.writeArrayFieldStart(FusionJsonMetadataSyntaxConstants.METADATASETS);
			for(IReportedMetadataSetBean mds : container.getReferenceMetadata()) {
				FusionJsonMetadataSetWriterEngine.getInstance().writeStructure(jsonWriter, null, mds);
			}
			jsonWriter.writeEndArray();
			jsonWriter.writeEndObject();
			jsonWriter.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
