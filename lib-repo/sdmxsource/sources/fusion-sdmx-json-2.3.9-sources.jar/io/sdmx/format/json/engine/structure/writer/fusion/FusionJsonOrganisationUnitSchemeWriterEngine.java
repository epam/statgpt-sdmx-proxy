package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonOrganisationUnitSchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<OrganisationUnitSchemeBean> implements IFusionSingleton {
	private static FusionJsonOrganisationUnitSchemeWriterEngine INSTANCE;

	public static FusionJsonOrganisationUnitSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonOrganisationUnitSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonOrganisationUnitSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException {
		OrganisationUnitBean orgUnit = (OrganisationUnitBean) item;
		if(orgUnit.getParentUnit() != null) {
			jsonGenerator.writeStringField("parentUnit", orgUnit.getParentUnit());
		}
		FusionJsonOrganisationWriterEngine.getInstance().writeStructure(jsonGenerator, orgUnit);
	}
}