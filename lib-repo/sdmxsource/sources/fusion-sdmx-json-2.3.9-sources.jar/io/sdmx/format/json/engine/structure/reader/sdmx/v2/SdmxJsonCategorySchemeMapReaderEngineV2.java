package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.mapping.v3.CategoryMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.CategorySchemeMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonCategorySchemeMapReaderEngineV2 extends SdmxJsonItemSchemeMapReaderEngineV2<ICategoryMapMutableBean, ICategorySchemeMapMutableBean> implements IFusionSingleton {
    private static SdmxJsonCategorySchemeMapReaderEngineV2 INSTANCE;

    public static SdmxJsonCategorySchemeMapReaderEngineV2 getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SdmxJsonCategorySchemeMapReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "categorySchemeMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ICategorySchemeMapBean.class;
    }

    @Override
    protected ICategorySchemeMapMutableBean getMutable() {
        return new CategorySchemeMapMutableBean();
    }

    @Override
    protected ICategoryMapMutableBean getItemMapMutable() {
        return new CategoryMapMutableBean();
    }
}
