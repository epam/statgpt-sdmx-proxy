package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.net.URL;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonRegistrationWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<RegistrationBean> implements IFusionSingleton {
	private static FusionJsonRegistrationWriterEngine INSTANCE;

	public static FusionJsonRegistrationWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRegistrationWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonRegistrationWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.REGISTRATION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, RegistrationBean registrationBean) throws JsonGenerationException, IOException {
		jsonGenerator.writeBooleanField("isIndexed", registrationBean.isIndexed());
		writeTertiaryBools(jsonGenerator, registrationBean);

		SdmxDate lastUpdated = registrationBean.getLastUpdated();
		if(lastUpdated != null) {
			jsonGenerator.writeNumberField("lastUpdated", lastUpdated.getDate().getTime());
		}

		SdmxDate validFrom = registrationBean.getValidFrom();
		if(validFrom != null) {
			jsonGenerator.writeNumberField("validFrom", validFrom.getDate().getTime());
		}

		SdmxDate validTo = registrationBean.getValidTo();
		if(validTo != null) {
			jsonGenerator.writeNumberField("validTo", validTo.getDate().getTime());
		}

		writeDataSource(jsonGenerator, registrationBean);

		ICrossReferenceBean<ProvisionAgreementBean> provisionAgreementRef = registrationBean.getProvisionAgreementRef();
		if(provisionAgreementRef != null) {
			jsonGenerator.writeStringField("provisionAgreementReference", provisionAgreementRef.getTargetUrn());
		}
	}

	private void writeTertiaryBools(JsonGenerator jsonGenerator, RegistrationBean registrationBean) throws IOException {
		TERTIARY_BOOL indexTimeSeries = registrationBean.getIndexTimeSeries();
		if(indexTimeSeries.isSet()) {
			jsonGenerator.writeBooleanField("indexTimeSeries", indexTimeSeries.isTrue());
		}
		TERTIARY_BOOL indexDataset = registrationBean.getIndexDataset();
		if(indexDataset.isSet()) {
			jsonGenerator.writeBooleanField("indexDataset", indexDataset.isTrue());
		}
		TERTIARY_BOOL indexAttributes = registrationBean.getIndexAttributes();
		if(indexAttributes.isSet()) {
			jsonGenerator.writeBooleanField("indexAttributes", indexAttributes.isTrue());
		}
		TERTIARY_BOOL indexReportingPeriod = registrationBean.getIndexReportingPeriod();
		if(indexReportingPeriod.isSet()) {
			jsonGenerator.writeBooleanField("indexReportingPeriod", indexReportingPeriod.isTrue());
		}
	}

	/**
	 * this could be extracted? not sure if anyone else uses one of these
	 * @throws IOException
	 */
	private void writeDataSource(JsonGenerator jsonGenerator, RegistrationBean registrationBean) throws IOException {
		DataSourceBean dataSource = registrationBean.getDataSource();
		if(dataSource == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("dataSource");
		jsonGenerator.writeBooleanField("isRESTDatasource", dataSource.isRESTDatasource());
		jsonGenerator.writeBooleanField("isWebServiceDatasource", dataSource.isWebServiceDatasource());
		jsonGenerator.writeBooleanField("isSimpleDatasource", dataSource.isSimpleDatasource());
		URL dataUrl = dataSource.getDataUrl();
		if(dataUrl != null) {
			jsonGenerator.writeStringField("dataUrl", dataUrl.toString());
		}
		URL wsdlUrl = dataSource.getWSDLUrl();
		if(wsdlUrl != null) {
			jsonGenerator.writeStringField("wSDLUrl", wsdlUrl.toString());
		}
		URL wadlUrl = dataSource.getWadlUrl();
		if(wadlUrl != null) {
			jsonGenerator.writeStringField("wadlUrl", wadlUrl.toString());
		}
		jsonGenerator.writeEndObject();
	}
}
