package io.sdmx.format.json.constant;

public enum SDMXJSON_VERSION {
	V1,
	V2
}
