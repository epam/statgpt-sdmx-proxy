package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonRegistrationReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<RegistrationBean, RegistrationMutableBean> implements IFusionSingleton {
	private static FusionJsonRegistrationReaderEngine INSTANCE;

	public static FusionJsonRegistrationReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRegistrationReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected RegistrationMutableBean getMutable() {
		return new RegistrationMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, RegistrationMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("indexTimeSeries")) {
			mutable.setIndexTimeSeries(TERTIARY_BOOL.parseBoolean(jReader.getValueAsBoolean()));
		} else if (fieldName.equals("indexAttributes")) {
			mutable.setIndexAttributes(TERTIARY_BOOL.parseBoolean(jReader.getValueAsBoolean()));
		} else if (fieldName.equals("indexReportingPeriod")) {
			mutable.setIndexReportingPeriod(TERTIARY_BOOL.parseBoolean(jReader.getValueAsBoolean()));
		} else if (fieldName.equals("indexDataset")) {
			mutable.setIndexDataset(TERTIARY_BOOL.parseBoolean(jReader.getValueAsBoolean()));
		} else if (fieldName.equals("lastUpdated")) {
			mutable.setLastUpdated(jReader.getValueAsDate());
		} else if (fieldName.equals("dataSource")) {
			processDataSource(mutable, jReader);
		} else if (fieldName.equals("provisionAgreementReference")) {
			mutable.setProvisionAgreementRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
		} else {
			return false;
		}
		return true;
	}

	private void processDataSource(RegistrationMutableBean mutable, JsonReader jReader) {
		DataSourceMutableBean ds = new DataSourceMutableBeanImpl();
		mutable.setDataSource(ds);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("isRESTDatasource")) {
				ds.setRESTDatasource(jReader.getValueAsBoolean());
			} else if (fieldName.equals("isWebServiceDatasource")) {
				ds.setWebServiceDatasource(jReader.getValueAsBoolean());
			}  else if (fieldName.equals("isSimpleDatasource")) {
				ds.setSimpleDatasource(jReader.getValueAsBoolean());
			}  else if (fieldName.equals("dataUrl")) {
				ds.setDataUrl(jReader.getValueAsString());
			}
		}
	}

    @Override
    protected Class<RegistrationBean> getMaintainableType() {
        return RegistrationBean.class;
    }
}