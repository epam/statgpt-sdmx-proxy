package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonDataflowReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<DataflowBean, DataflowMutableBean> implements IFusionSingleton {
	private static FusionJsonDataflowReaderEngine INSTANCE;

	public static FusionJsonDataflowReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataflowReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected DataflowMutableBean getMutable() {
		return new DataflowMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, DataflowMutableBean mutable, JsonReader jReader) {
		String value = jReader.getValueAsString();
		if (fieldName.equals("dataStructureRef")) {
			StructureReferenceBean keyFamilyRef = new StructureReferenceBeanImpl(value);
			mutable.setDataStructureRef(keyFamilyRef);
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<DataflowBean> getMaintainableType() {
        return DataflowBean.class;
    }
}