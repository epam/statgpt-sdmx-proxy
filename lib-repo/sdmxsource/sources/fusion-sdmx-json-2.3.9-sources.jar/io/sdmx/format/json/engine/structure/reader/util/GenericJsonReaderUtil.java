package io.sdmx.format.json.engine.structure.reader.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class GenericJsonReaderUtil {
	
	public static List<StructureReferenceBean> readRefArray(JsonReader jReader) {
		return jReader.readStringArray().stream().map(StructureReferenceBeanImpl::new).collect(Collectors.toList());
	}

	
	/**
	 * Populates the Identifiable with 'id' and 'uri' attribute values read from the current XML node.
	 * @param identifiableBean
	 * @param staxReader
	 */
	public static boolean processLinks(IdentifiableMutableBean identifiableBean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		if (jReader.isStartArray() && fieldName.equals("links")) {
			while(jReader.moveNext()) {
				if(jReader.isStartObject()) {
					processLink(identifiableBean, jReader);
				}
				if(jReader.isEndArray()) {
					return true;
				}
			}
		} 
		return false;
	}
	
	/**
	 * Populates the Identifiable with 'id' and 'uri' attribute values read from the current XML node.
	 * @param identifiableBean
	 * @param staxReader
	 */
	private static boolean processLink(IdentifiableMutableBean identifiableBean, JsonReader jReader) {
		String rel = null;
		URI href = null;
		URI uri = null;
		IURN<?> urn = null;
		String type = null;
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				if(href != null && "self".equals(rel) && identifiableBean instanceof MaintainableMutableBean) {
					((MaintainableMutableBean)identifiableBean).setStructureURL(href.toString());
					href = null;
				} 
				identifiableBean.addLink(new LinkBean(rel, href, uri, urn, type, null));
				return true;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "rel" : 
				rel = jReader.getValueAsString();
				break;
			case "href" :
					href = toURI(jReader.getValueAsString());
				break;
			case "type" :
				type = jReader.getValueAsString();
				break;
			case "urn" : urn = URN.getInstance(jReader.getValueAsString());
				break;
			}
		}
		return false;
	}
	
	private static URI toURI(String value) {
		if(value == null) {
			return null;
		}
		try {
			return new URI(value);
		} catch (URISyntaxException e) {
			throw new SdmxSemmanticException(e, "Link contains illegal URI : "+value);
		}
	}
	
}
