package io.sdmx.format.json.util;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonUtil {
	/**
	 * If legacy mode is enabled, then vnd.sdmx.json will return "FusionJson" and Official SDMX json will be unavailable
	 */
	public static final boolean LEGACY_MODE = Boolean.parseBoolean(System.getProperty("json.legacy.enabled", "false"));
	/**
	 * Returns the action from the header of the JSON.
	 *
	 * This method assumes:
	 * <ul>
	 * <li>the input rdl actually contains JSON</li>
	 * <li>the first block is "meta"</li>
	 * <li>the action is defined in meta in a field called "action" which can be anywhere in the "meta" block</li>
	 * </ul>
	 * This method will not error on failure, but will return null.
	 * @param rdl
	 * @return a Dataset Action or null
	 */
	public static DATASET_ACTION getAction(ReadableDataLocation rdl) {
		try(JsonReader jReader = new JsonReader(rdl);){
			jReader.reset();
			jReader.moveNextStartObject();
			jReader.moveNext();
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("meta")) {
				if (!jReader.getCurrentStackItem().getType().equals(JsonReader.STACK_TYPE.OBJECT)) {
					return null;
				}
				while (jReader.moveNext()) {
					if (jReader.isEndObject()) {
						return null;
					}

					fieldName = jReader.getCurrentFieldName();

					if (fieldName.equals("action")) {
						String val = jReader.getValueAsString();
						DATASET_ACTION action;
						try {
							action = DATASET_ACTION.getAction(val);
						} catch (Exception e) {
							throw new SdmxSemmanticException("Illegal value for 'Action'. Valid values are 'Replace', 'Append', 'Delete' but the following value was supplied: " + val);
						}
						return action;
					}
				}
			}
			return null;
		}
	}
	
	/**
	 * Checks if this is JSON, if it is attempts to find the schema field in the meta section of the message
	 * If this is not JSON or if the field is not present, null is returned
	 * @param rdl
	 * @return schema from the meta.schema section of the json message
	 */
	public static String getSchema(ReadableDataLocation rdl) {
		return getPathValue(rdl, "meta.schema");
	}
	
	/**
	 * This is a simple path mover, it does not handle arrays, it just moves to a position based on object fields, for example meta.schema
	 * Checks if this is JSON, if it is attempts to find the schema field in the meta section of the message
	 * If this is not JSON or if the field is not present, null is returned
	 * @param rdl
	 * @return schema from the meta.schema section of the json message
	 */
	public static String getPathValue(ReadableDataLocation rdl, String jsonPath) {
		JsonReader reader = moveToPath(rdl, jsonPath);
		if(reader != null) {
			try {
				return reader.getValueAsString();
			} finally {
				reader.close();
			}
		}
		return null;
	}
	
	/**
	 * This is a simple path mover, it does not handle arrays, it just moves to a position based on object fields, for example meta.schema
	 * Checks if this is JSON, if it is attempts to find the schema field in the meta section of the message
	 * If this is not JSON or if the field is not present, null is returned
	 * @param rdl
	 * @return schema from the meta.schema section of the json message
	 */
	public static JsonReader moveToPath(ReadableDataLocation rdl, String jsonPath) {
		if(rdl.getFormat() == FILE_FORMAT.JSON) {
			String[] path = jsonPath.split("\\.");
			int idx = 0;
			JsonReader jReader = new JsonReader(rdl);
			while(jReader.moveNext()) {
				String fieldName = jReader.getCurrentFieldName();
				if(fieldName != null) {
					if(fieldName.equals(path[idx])) {
						idx++;
						if(path.length == idx) {
							return jReader;
						}
					} else {
						if(jReader.isStartArray()) {
							jReader.moveToEndArray();
						} else if(jReader.isStartObject()){
							jReader.moveToEndObject();
						}
					}
				}
			}
			//Not found
			jReader.close();
		}
		return null;
	}

}
