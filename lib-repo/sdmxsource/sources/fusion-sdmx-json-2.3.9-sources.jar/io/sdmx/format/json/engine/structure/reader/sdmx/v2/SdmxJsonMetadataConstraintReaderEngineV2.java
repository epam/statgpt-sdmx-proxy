package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.MetadataConstraintMutableBean;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonMetadataConstraintReaderEngineV2 extends AbstractSdmxJsonReaderEngine<IMetadataConstraintMutableBean> implements IFusionSingleton {

    private static SdmxJsonMetadataConstraintReaderEngineV2 INSTANCE;

    public static SdmxJsonMetadataConstraintReaderEngineV2 getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SdmxJsonMetadataConstraintReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "metadataConstraints";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IMetadataConstraintBean.class;
    }

    @Override
    protected IMetadataConstraintMutableBean getMutable() {
        return new MetadataConstraintMutableBean();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, IMetadataConstraintMutableBean mutable, JsonReader reader) {
        switch (fieldName) {
        case "constraintAttachment":
            mutable.setAttachments(readAttachments(reader));
            return true;
        case "releaseCalendar":
            mutable.setReleaseCalendar(readReleaseCalendar(reader));
            return true;
        case "metadataTargetRegions":
            for (TargetInclusivityWrap targetWrap : readTargets(reader)) {
                if (targetWrap.isIncluded) {
                    mutable.setIncludedTarget(targetWrap.target);
                } else {
                    mutable.setExcludedTarget(targetWrap.target);
                }
            }
            return true;
        }
        return false;
    }

    private List<StructureReferenceBean> readAttachments(JsonReader json) {
        List<StructureReferenceBean> attachmentsMutable = new ArrayList<>();

        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            switch (json.getCurrentFieldName()) {
            case "metadataProvider":
            case "metadataProvisionAgreements":
            case "metadataflows":
            case "metadataStructures":
                for (String urn : json.readStringArray()) {
                    attachmentsMutable.add(new StructureReferenceBeanImpl(urn));
                }
            }
        }
        return attachmentsMutable;
    }

    private ReleaseCalendarMutableBean readReleaseCalendar(JsonReader json) {
        Map<String, String> releaseCalendarMap = json.readStringMap();

        ReleaseCalendarMutableBean releaseCalendarMutable = new ReleaseCalendarMutableBeanImpl();
        String offset = releaseCalendarMap.get("offset");
        String periodicity = releaseCalendarMap.get("periodicity");
        String tolerance = releaseCalendarMap.get("tolerance");

        if (ObjectUtil.validString(offset)) {
            releaseCalendarMutable.setOffset(offset);
        }
        if (ObjectUtil.validString(periodicity)) {
            releaseCalendarMutable.setPeriodicity(periodicity);
        }
        if (ObjectUtil.validString(tolerance)) {
            releaseCalendarMutable.setTolerance(tolerance);
        }
        return releaseCalendarMutable;
    }

    private List<TargetInclusivityWrap> readTargets(JsonReader json) {
        List<TargetInclusivityWrap> targetWraps = new ArrayList<>();

        while (json.moveNext()) {
            if (json.isEndArray()) {
                break;
            }
            if (!json.isStartObject()) {
                continue;
            }
            TargetInclusivityWrap targetWrap = new TargetInclusivityWrap(new ArrayList<>());
            while (json.moveNext()) {
                if (json.isEndObject()) {
                    break;
                }
                switch (json.getCurrentFieldName()) {
                case "include":
                    targetWrap.isIncluded = json.getValueAsBoolean();
                    break;
                case "components":
                    List<KeyValuesMutable> components = readComponents(json);
                    targetWrap.target.addAll(components);
                    break;
                }
            }
            targetWraps.add(targetWrap);
        }
        return targetWraps;
    }

    private List<KeyValuesMutable> readComponents(JsonReader json) {
        List<KeyValuesMutable> components = new ArrayList<>();

        while (json.moveNext()) {
            if (json.isEndArray()) {
                break;
            }
            KeyValuesMutable component = new KeyValuesMutableImpl();
            while (json.moveNext()) {
                if (json.isEndObject()) {
                    break;
                }
                switch (json.getCurrentFieldName()) {
                case "id":
                    component.setId(json.getValueAsString());
                    break;
                case "removePrefix":
                    component.setRemovePrefix(json.getValueAsBoolean());
                    break;
                case "values":
                    readValues(component, json);
                    break;
                case "timeRange":
                    component.setTimeRange(readTimeRange(json));
                    break;
                }
            }
            components.add(component);
        }
        return components;
    }

    private void readValues(KeyValuesMutable component, JsonReader json) {
        while (json.moveNext()) {
            if (json.isEndArray()) {
                break;
            }
            if (json.isStartObject()) {
                readValue(component, json);
            }
        }
    }

    private void readValue(KeyValuesMutable component, JsonReader json) {
        String constrainedValue = null;
        boolean cascade = false;
        String validFrom = null;
        String validTo = null;

        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            String value = json.getValueAsString();
            switch (json.getCurrentFieldName()) {
            case "value":
                constrainedValue = value;
                break;
            case "validFrom":
                validFrom = value;
                break;
            case "validTo":
                validTo = value;
                break;
            case "cascadeValues":
                if (value.equalsIgnoreCase("true")) {
                    cascade = true;
                }
                break;
            }
        }
        if (cascade) {
            component.addCascade(constrainedValue);
        } else {
            component.addValue(constrainedValue);
        }
        if (ObjectUtil.validOneString(validFrom, validTo)) {
            component.setValidity(constrainedValue, validFrom, validTo);
        }
    }

    private TimeRangeMutableBean readTimeRange(JsonReader json) {
        TimeRangeMutableBean timeRangeMutable = new TimeRangeMutableBeanImpl();

        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            switch (json.getCurrentFieldName()) {
            case "startPeriod":
            case "beforePeriod":
                readTimeRangePeriod(timeRangeMutable, true, json);
                break;
            case "endPeriod":
            case "afterPeriod":
                readTimeRangePeriod(timeRangeMutable, false, json);
                break;
            case "validFrom":
                timeRangeMutable.setValidFrom(SdmxDateImpl.getSdmxDate(json.getValueAsString()));
                break;
            case "validTo":
                timeRangeMutable.setValidTo(SdmxDateImpl.getSdmxDate(json.getValueAsString()));
                break;
            }
        }
        if (timeRangeMutable.getStartDate() != null && timeRangeMutable.getEndDate() != null) {
            timeRangeMutable.setIsRange(true);
        }
        return timeRangeMutable;
    }

    private void readTimeRangePeriod(TimeRangeMutableBean timeRangeMutable, boolean isStart, JsonReader json) {
        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            switch (json.getCurrentFieldName()) {
            case "period":
                if (isStart) {
                    timeRangeMutable.setStartDate(SdmxDateImpl.getSdmxDate(json.getValueAsString()));
                } else {
                    timeRangeMutable.setEndDate(SdmxDateImpl.getSdmxDate(json.getValueAsString()));
                }
                break;
            case "isInclusive":
                if (isStart) {
                    timeRangeMutable.setIsStartInclusive(json.getValueAsBoolean());
                } else {
                    timeRangeMutable.setIsEndInclusive(json.getValueAsBoolean());
                }
                break;
            }
        }
    }

    /**
     * Adds inclusivity information to the Target
     */
    private static class TargetInclusivityWrap {
        public List<KeyValuesMutable> target;
        public boolean isIncluded;

        public TargetInclusivityWrap(List<KeyValuesMutable> target) {
            this.target = target;
        }
    }
}
