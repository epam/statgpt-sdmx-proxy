package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.DataSetReferenceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetKeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.DataSetReferenceMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.MetadataTargetKeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.MetadataTargetRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.ReferencePeriodMutableBeanImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonContentConstraintReaderEngineV1 extends SdmxJsonAbstractConstraintReaderEngineV1<ContentConstraintMutableBean> implements IFusionSingleton {
	private static SdmxJsonContentConstraintReaderEngineV1 INSTANCE;

	public static SdmxJsonContentConstraintReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonContentConstraintReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    protected ContentConstraintMutableBean getMutable() {
        return new ContentConstraintMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ContentConstraintMutableBean mutable, JsonReader reader) {
        if(super.readConstraint(mutable, reader)) {
            return true;
        }
        String value = reader.getValueAsString();

        switch(fieldName) {
        case "type":
            mutable.setIsDefiningActualDataPresent(value.equals("actual"));
            return true;
        case "cubeRegions":
            List<DescribedCube> cubes = readCubeReg(reader);
            for (DescribedCube describedSube : cubes) {
                if(describedSube.isIncluded) {
                    mutable.setIncludedCubeRegion(describedSube.cube);
                }else {
                    mutable.setExcludedCubeRegion(describedSube.cube);
                }
            }
            return true;
        case "referencePeriod":
            Map<String, String> readStringMap = reader.readStringMap();
            String endTimeStr = readStringMap.get("endTime");
            String startTimeStr = readStringMap.get("startTime");
            ReferencePeriodMutableBean refp = new ReferencePeriodMutableBeanImpl();
            if(ObjectUtil.validString(endTimeStr)) {
                Date endDate = DateUtil.formatDate(endTimeStr, true);
                refp.setEndTime(endDate);
            }
            if(ObjectUtil.validString(startTimeStr)) {
                Date startDate = DateUtil.formatDate(startTimeStr, true);
                refp.setStartTime(startDate);
            }
            mutable.setReferencePeriod(refp);
            return true;
        case "releaseCalendar":
            Map<String, String> relCalObj = reader.readStringMap();
            ReleaseCalendarMutableBean relCalMut = new ReleaseCalendarMutableBeanImpl();
            String offset = relCalObj.get("offset");
            String periodicity = relCalObj.get("periodicity");
            String tolerance = relCalObj.get("tolerance");
            if(ObjectUtil.validString(offset)) {
                relCalMut.setOffset(offset);
            }
            if(ObjectUtil.validString(periodicity)) {
                relCalMut.setPeriodicity(periodicity);
            }
            if(ObjectUtil.validString(tolerance)) {
                relCalMut.setTolerance(tolerance);
            }
            mutable.setReleaseCalendar(relCalMut);
            return true;
        case "metadataTargetRegions":
            List<MetadataTargetRegionMutableBean> metadataTargetRegionBeanList = readMetadataTargetRegionBeans(reader);
            // the JSON schema says this is an array, but the API only takes One MetadataTargetRegionMutableBean
            if(!metadataTargetRegionBeanList.isEmpty()) {
                mutable.setMetadataTargetRegion(metadataTargetRegionBeanList.get(0));
            }
            return true;
        }
        return false;
    }

	private List<MetadataTargetRegionMutableBean> readMetadataTargetRegionBeans(JsonReader jReader) {
		List<MetadataTargetRegionMutableBean> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			MetadataTargetRegionMutableBean mt = new MetadataTargetRegionMutableBeanImpl();
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(fieldName) {
				case "include":
					boolean include = Boolean.parseBoolean(value);
					mt.setIsInclude(include);
					break;
				case "metadataTarget":
					mt.setMetadataTarget(value);
					break;
				case "report":
					mt.setReport(value);
					break;
				case "attributes":
					List<KeyValuesMutable> attraKeyValues = readKeyValues(jReader);
					mt.setAttributes(attraKeyValues);
					break;
				case "keyValues":
					List<MetadataTargetKeyValuesMutable> keyValues = readKeyValueForMetadataTarget(jReader);
					mt.setKey(keyValues);
				}
			}
			ret.add(mt);
		}
		return ret;
	}

	private List<MetadataTargetKeyValuesMutable> readKeyValueForMetadataTarget(JsonReader jReader){
		List<MetadataTargetKeyValuesMutable> retList = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			MetadataTargetKeyValuesMutable metadataTargetKv = new MetadataTargetKeyValuesMutableImpl();
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(fieldName) {
				case "id":
					metadataTargetKv.setId(value);
					break;
				case "dataKeys":
					throw new UnsupportedOperationException("Data Keys not supported");
				case "dataSets":
					List<DataSetReferenceMutableBean> dataSetRefs = new ArrayList<>();
					while (jReader.moveNext()) {
						if(jReader.isEndArray()) {
							break;
						}
						DataSetReferenceMutableBean ref = new DataSetReferenceMutableBeanImpl();
						while(jReader.moveNext()) {
							if(jReader.isEndObject()) {
								break;
							}
							switch(jReader.getCurrentFieldName()) {
							case "dataProvider":
								ref.setDataProviderReference(new StructureReferenceBeanImpl(jReader.getValueAsString()));
								break;
							case "id":
								ref.setDatasetId(jReader.getValueAsString());
							}
						}
						dataSetRefs.add(ref);
					}
					metadataTargetKv.setDatasetReferences(dataSetRefs);
					break;
				case "objects":
					List<String> objects = jReader.readStringArray();
					List<StructureReferenceBean>  objectRefs = objects.stream()
							.map(StructureReferenceBeanImpl::new)
							.collect(Collectors.toList());
					metadataTargetKv.setObjectReferences(objectRefs);
					break;
				case "timeRange":
					TimeRangeMutableBean readTimeRange = readTimeRange(jReader);
					metadataTargetKv.setTimeRange(readTimeRange);
					break;
				case "values":
					List<String> valueArray = jReader.readStringArray();
					metadataTargetKv.setKeyValues(valueArray);
				}
			}
			retList.add(metadataTargetKv);
		}
		return retList;
	}

	private TimeRangeMutableBean readTimeRange(JsonReader jReader) {
		if(!jReader.getCurrentFieldName().equals("timeRange")) {
			throw new RuntimeException("Attempting to parse time range failed, expected node to be 'timeRange' got: " + jReader.getCurrentFieldName());
		}
		TimeRangeMutableBean ret = new TimeRangeMutableBeanImpl();

		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			Map<String, String> value = jReader.readStringMap();
			boolean isInclusive = Boolean.parseBoolean(value.get("isInclusive"));
			if(!value.containsKey("period")) {
				break;
			}
			SdmxDate p = SdmxDateImpl.getSdmxDate(value.get("period"));
			switch(fieldName) {
			case "startPeriod":
			case "beforePeriod":
				ret.setIsStartInclusive(isInclusive);
				ret.setStartDate(p);
				break;
			case "afterPeriod":
			case "endPeriod":
				ret.setIsEndInclusive(isInclusive);
				ret.setEndDate(p);
				break;
			}
		}
		if(ret.getStartDate() != null && ret.getEndDate() != null) {
			ret.setIsRange(true);
		}
		return ret;
	}

	private List<KeyValuesMutable> readKeyValues(JsonReader jReader) {
		List<KeyValuesMutable> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			KeyValuesMutable kv = new KeyValuesMutableImpl();
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String currentFieldName = jReader.getCurrentFieldName();
				switch(currentFieldName) {
				case "id":
					kv.setId(jReader.getValueAsString());
					break;
				case "timeRange":
					TimeRangeMutableBean readTimeRange = readTimeRange(jReader);
					kv.setTimeRange(readTimeRange);
					break;
				case "values":
					List<String> valueArray = jReader.readStringArray();
					for (String value : valueArray) {
						kv.addValue(value);
					}
					break;
				case "cascadeValues":
					List<String> cascadeValueArray = jReader.readStringArray();
					for (String value : cascadeValueArray) {
						kv.addCascade(value);
					}
					break;
				default:
					continue;
				}
			}
			ret.add(kv);
		}
		return ret;
	}


	private List<DescribedCube> readCubeReg(JsonReader jReader) {
		List<DescribedCube> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			if(!jReader.isStartObject()) {
				continue;
			}
			DescribedCube cubeWrapper = new DescribedCube(new CubeRegionMutableBeanImpl());
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				switch(fieldName) {
				case "isIncluded":
					cubeWrapper.isIncluded = jReader.getValueAsBoolean();
					break;
				case "attributes":
					List<KeyValuesMutable> attras = readKeyValues(jReader);
					cubeWrapper.cube.setAttributeValues(attras);
					break;
				case "keyValues":
					List<KeyValuesMutable> kvs = readKeyValues(jReader);
					cubeWrapper.cube.setKeyValues(kvs);
					break;
				}
			}
			ret.add(cubeWrapper);
		}
		return ret;
	}

	/**
	 *
	 * Describes if this Cube region is "included" or not
	 */
	private class DescribedCube{
		public CubeRegionMutableBean cube;
		public boolean isIncluded;

		public DescribedCube(CubeRegionMutableBean cube) {
			this.cube = cube;
		}
	}

    @Override
    public String getContainerElement() {
        return "contentConstraints";
    }

    @Override
    protected Class<ContentConstraintBean> getMaintainableType() {
        return ContentConstraintBean.class;
    }
}
