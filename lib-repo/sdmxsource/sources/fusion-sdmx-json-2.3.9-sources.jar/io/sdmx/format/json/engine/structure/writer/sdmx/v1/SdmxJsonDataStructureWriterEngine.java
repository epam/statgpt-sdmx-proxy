package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;;

public class SdmxJsonDataStructureWriterEngine extends SdmxJsonMaintainableStructureWriterEngine<DataStructureBean> implements IFusionSingleton {
	private static SdmxJsonDataStructureWriterEngine INSTANCE;

	public static SdmxJsonDataStructureWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataStructureWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonDataStructureWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DSD);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator,  IExternalMaintainableLinks externalLinks, DataStructureBean dsd) throws JsonGenerationException, IOException {
		writeDataStructureComponents(jsonGenerator, externalLinks, dsd);
	}

	private void writeDataStructureComponents(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataStructureBean dsd) throws IOException {
		jsonGenerator.writeObjectFieldStart("dataStructureComponents");

		writeAttributeList(dsd, externalLinks, jsonGenerator);
		writeDimensionList(dsd, externalLinks, jsonGenerator);
		writeGroups(dsd, externalLinks, jsonGenerator);
		writeMeasureList(dsd, externalLinks, jsonGenerator);

		jsonGenerator.writeEndObject();
	}

	private void writeAttributeList(DataStructureBean dsd, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if(dsd.getAttributeList() != null) {
			jsonGenerator.writeObjectFieldStart("attributeList");
			AttributeListBean attributeList = dsd.getAttributeList();
			super.writeIdentifiable(jsonGenerator, attributeList, externalLinks);
			//			WriteReportingYearStartDays(attributeList, jsonGenerator);
			List<AttributeBean> attributeListArr = attributeList.getAttributes();
			if(ObjectUtil.validCollection(attributeListArr)) {
				jsonGenerator.writeArrayFieldStart("attributes");
				writeListOfAttributes(attributeListArr, externalLinks, jsonGenerator);
				jsonGenerator.writeEndArray();
			}
			jsonGenerator.writeEndObject();
		}
	}

	private void writeListOfAttributes(List<AttributeBean> attributes,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		for(AttributeBean attr : attributes) {
			jsonGenerator.writeStartObject();
			String asVal = attr.isMandatory() ? "Mandatory": "Conditional";
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "assignmentStatus", asVal);
			writeAttributeRelationship(attr, jsonGenerator);

			if(!attr.getConceptRoles().isEmpty()) {
				writeConceptRoles(jsonGenerator, attr.getConceptRoles());
			}
			writeComponent(attr, jsonGenerator, externalLinks);
			jsonGenerator.writeEndObject();
		}
	}

	private void writeConceptRoles(JsonGenerator jsonGenerator, List<IDirectCrossReferenceBean<ConceptBean>> roles) throws IOException {
		jsonGenerator.writeArrayFieldStart("conceptRoles");
		for(ICrossReferenceBean<ConceptBean> ref: roles) {
			jsonGenerator.writeString(ref.getTargetUrn());
		}
		jsonGenerator.writeEndArray();
	}

	/**
	 * <p>This method is used to create the attributeRelationship as defined in the JSON Schemea </p>
	 * <p>The only issue is that the Schema, the documentation and the samples are all contradicting eachover. </p>
	 * <p>The Schema wants things like AttachmentGroup and dimensionReferences to be URNS's where our JAVA returns these in IDs </p>
	 * <p>the official example. however uses ID~s like we do, and not URNS <a href="https://github.com/sdmx-twg/sdmx-json/blob/develop/structure-message/docs/1-sdmx-json-field-guide.md#attributerelationship">https://github.com/sdmx-twg/sdmx-json/blob/develop/structure-message/docs/1-sdmx-json-field-guide.md#attributerelationship</a> </p>
	 * <p>The description here, however backs up what the Schema says, So I am not sure what needs to be actually put here, if it is, indeed URNS. then we need a method on AttributeBean to get the actual group Object. and not the ID, and we need a way of getting the Dimension URN's instead of ID </p>
	 * <p>Also, attachmentLevel is not in the Schema, and the documentation says <q>The attachment level of the attribute will be determined by the data format and which dimensions are referenced.</q></p>
	 * @param att
	 * @param jsonGenerator
	 * @throws IOException
	 */
	private void writeAttributeRelationship(AttributeBean attr, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("attributeRelationship");
		switch(attr.getAttachmentLevel()) {
		case DATA_SET:
			jsonGenerator.writeObjectFieldStart("none");
			jsonGenerator.writeEndObject();
			// none
			break;
		case DIMENSION_GROUP:
			List<String> dimensionReferences = attr.getDimensionReferences();
			jsonGenerator.writeArrayFieldStart("dimensions");
			for(String dimId: dimensionReferences) {
				jsonGenerator.writeString(dimId);
			}
			jsonGenerator.writeEndArray();
			//dimensions
			break;
		case GROUP:
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "group", attr.getAttachmentGroup());
			//group
			break;
		case OBSERVATION:
			//primaryMeasure
			for(String measure : attr.getMeasureReferences()) {
				if(measure.equals("OBS_VALUE")) {
					SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "primaryMeasure", measure);
				}
			}
		
			break;
		default:
			// attachmentGroups in the schema is not supported here
			break;

		}
		jsonGenerator.writeEndObject();
	}

	private void writeDimensionList(DataStructureBean dsd,   IExternalMaintainableLinks externalLinks,JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("dimensionList");
		DimensionListBean dimensionList = dsd.getDimensionList();
		if(dimensionList != null) {
			writeIdentifiable(jsonGenerator, dimensionList, externalLinks);
		}
		List<DimensionBean> dimensions = dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION);
		if(!dimensions.isEmpty()) {
			jsonGenerator.writeArrayFieldStart("dimensions");
			for(DimensionBean dim : dimensions) {
				writeDimension(dim, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}

		List<DimensionBean> measureDims = dsd.getDimensions(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
		if(!measureDims.isEmpty()) {
			jsonGenerator.writeArrayFieldStart("measureDimensions");
			for(DimensionBean dim : measureDims) {
				writeDimension(dim, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}

		List<DimensionBean> timeDims = dsd.getDimensions(SDMX_STRUCTURE_TYPE.TIME_DIMENSION);
		if(!timeDims.isEmpty()) {
			jsonGenerator.writeArrayFieldStart("timeDimensions");
			for(DimensionBean dim : timeDims) {
				writeDimension(dim, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}


		jsonGenerator.writeEndObject();
	}

	private void writeDimension(DimensionBean dimBean,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();  //Start Dimension
		jsonGenerator.writeNumberField("position", dimBean.getPosition());
		if(dimBean.isMeasureDimension()) {
			jsonGenerator.writeStringField("type", "MeasureDimension");
			if(dimBean.getConceptScheme() != null) {
				jsonGenerator.writeObjectFieldStart("localRepresentation");
				jsonGenerator.writeStringField("enumeration", dimBean.getConceptScheme().getURN());
				jsonGenerator.writeEndObject();
			}
		}else if(dimBean.isTimeDimension()) {
			jsonGenerator.writeStringField("type", "TimeDimension");
		}else {
			jsonGenerator.writeStringField("type", "Dimension");
		}
		if(!dimBean.getConceptRole().isEmpty()) {
			writeConceptRoles(jsonGenerator, dimBean.getConceptRole());
		}
		writeComponent(dimBean, jsonGenerator, externalLinks);
		jsonGenerator.writeEndObject();

	}

	private void writeGroups(DataStructureBean dsd,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if (ObjectUtil.validCollection(dsd.getGroups())) {
			jsonGenerator.writeArrayFieldStart("groups");
			for(GroupBean group : dsd.getGroups()) {
				writeGroup(group, externalLinks, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeGroup(GroupBean group,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		writeIdentifiable(jsonGenerator, group, externalLinks);
		jsonGenerator.writeStringField("id", group.getId());

		jsonGenerator.writeArrayFieldStart("groupDimensions");
		for(String dimensionRef : group.getDimensionRefs()) {
			jsonGenerator.writeString(dimensionRef);
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	private void writeMeasureList(DataStructureBean dsd,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		MeasureListBean measureList = dsd.getMeasureList();
		if(measureList == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("measureList");
		writeIdentifiable(jsonGenerator, measureList, externalLinks);
		writePrimaryMeasure(measureList.getPrimaryMeasure(), externalLinks, jsonGenerator);
		jsonGenerator.writeEndObject();
	}

	private void writePrimaryMeasure(PrimaryMeasureBean primaryMeasure,  IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("primaryMeasure");
		writeComponent(primaryMeasure, jsonGenerator, externalLinks);
		jsonGenerator.writeEndObject();
	}

}
