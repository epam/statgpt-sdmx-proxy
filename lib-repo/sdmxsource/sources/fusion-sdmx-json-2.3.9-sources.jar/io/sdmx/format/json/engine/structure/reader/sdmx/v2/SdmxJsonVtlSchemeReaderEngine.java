package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlSchemeMutableBean;
import io.sdmx.utils.json.JsonReader;

public abstract class SdmxJsonVtlSchemeReaderEngine<Y extends ItemMutableBean, F extends IVtlSchemeMutableBean<Y>> extends SdmxJsonItemSchemeReaderEngineV2<Y, F> {

    @Override
    protected boolean processMaintainableProperty(String fieldName, F mutable, JsonReader reader) {
        if ("vtlVersion".equals(fieldName)) {
            mutable.setVtlVersion(reader.getValueAsString());
            return true;
        }
        return super.processMaintainableProperty(fieldName, mutable, reader);
    }
}
