package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonCustomTypeSchemeWriterEngine extends FusionJsonAbstractVTLSchemeWriterEngine<ICustomTypeSchemeBean> implements IFusionSingleton {
	private static FusionJsonCustomTypeSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonCustomTypeSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME);
	}

	public static FusionJsonCustomTypeSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCustomTypeSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		ICustomTypeBean item =  (ICustomTypeBean)itemBean;
		if(item.getVtlScalarType() != null) {
			jsonGenerator.writeStringField("vtlScalarType", item.getVtlScalarType());
		}
		if(item.getDataType() != null) {
			jsonGenerator.writeStringField("dataType", item.getDataType());
		}
		if(item.getVtlLiteralFormat() != null) {
			jsonGenerator.writeStringField("vtlLiteralFormat", item.getVtlLiteralFormat());
		}
		if(item.getOutputFormat() != null) {
			jsonGenerator.writeStringField("outputFormat", item.getOutputFormat());
		}
		if(item.getNullValue() != null) {
			jsonGenerator.writeStringField("nullValue", item.getNullValue());
		}
	}
}
