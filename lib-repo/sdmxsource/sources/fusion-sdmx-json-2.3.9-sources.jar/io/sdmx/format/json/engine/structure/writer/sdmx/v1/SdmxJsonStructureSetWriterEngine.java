package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.mapping.SchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;


/**
 * TODO: missing the following from the JSON schema:
 * <ul>
 * 	<li>hybridCodelistMaps</li>
 * 	<li>relatedStructures</li>
 * 	<li>reportingTaxonomyMaps</li>
 * </ul>
 *
 */
public class SdmxJsonStructureSetWriterEngine extends SdmxJsonMaintainableStructureWriterEngine<StructureSetBean> implements IFusionSingleton {
	private static SdmxJsonStructureSetWriterEngine INSTANCE;

	public static SdmxJsonStructureSetWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureSetWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonStructureSetWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_SET);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, StructureSetBean ss) throws JsonGenerationException, IOException {
		writeCategorySchemeMaps(jsonGenerator, externalLinks, ss.getCategorySchemeMapList());
		writeCodelistMaps(jsonGenerator, externalLinks, ss.getCodelistMapList());
		writeConceptSchemeMaps(jsonGenerator, externalLinks, ss.getConceptSchemeMapList());
		writeOrganisationSchemeMaps(jsonGenerator, externalLinks, ss.getOrganisationSchemeMapList());
		writeStructureMaps(jsonGenerator, externalLinks, ss.getStructureMapList());
	}

	private void writeCategorySchemeMaps(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<CategorySchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("categorySchemeMaps");
			for(CategorySchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, externalLinks, currentMap, "categoryMaps");
			}
			jsonGenerator.writeEndArray();
		}

	}

	private void writeOrganisationSchemeMaps(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<OrganisationSchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("organisationSchemeMaps");
			for(OrganisationSchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, externalLinks, currentMap, "organisationMaps");
			}
			jsonGenerator.writeEndArray();

		}

	}

	private void writeConceptSchemeMaps(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<ConceptSchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("conceptSchemeMaps");
			for(ConceptSchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, externalLinks, currentMap, "conceptMaps");
			}
			jsonGenerator.writeEndArray();
		}

	}

	private void writeCodelistMaps(JsonGenerator jsonGenerator,  IExternalMaintainableLinks externalLinks, List<CodelistMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("codelistMaps");
			for(CodelistMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, externalLinks, currentMap, "codeMaps");
			}
			jsonGenerator.writeEndArray();
		}

	}

	private <T extends ItemMapBean> void writeItemSchemeMap(JsonGenerator jsonGenerator,  IExternalMaintainableLinks externalLinks, ItemSchemeMapBean<T> map, String identFieldName) throws IOException {
		jsonGenerator.writeStartObject();
		super.writeNameable(jsonGenerator, map, externalLinks);
		writeSchemeMap(jsonGenerator, map);
		writeItemMapBean(jsonGenerator, map.getItems(), identFieldName);
		jsonGenerator.writeEndObject();

	}

	private <T extends ItemMapBean> void writeItemMapBean(JsonGenerator jsonGenerator, List<T> items, String identFieldName) throws IOException {
		jsonGenerator.writeArrayFieldStart(identFieldName);
		for (T currentItemMap : items) {
			jsonGenerator.writeStartObject();
			SdmxJsonStaticHelper.writeAnnotable(jsonGenerator, currentItemMap);
			String src = currentItemMap.getSourceId();
			String tgt = currentItemMap.getTargetId();
			jsonGenerator.writeStringField("source", src);
			jsonGenerator.writeStringField("target", tgt);
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeStructureMaps(JsonGenerator jsonGenerator,  IExternalMaintainableLinks externalLinks, List<StructureMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("structureMaps");
			for(StructureMapBean currentMap : maps) {
				writeStructureMap(jsonGenerator, externalLinks, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeStructureMap(JsonGenerator jsonGenerator,  IExternalMaintainableLinks externalLinks, StructureMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		super.writeNameable(jsonGenerator, map, externalLinks);
		jsonGenerator.writeBooleanField("isExtension", map.isExtension());
		writeSchemeMap(jsonGenerator, map);
		jsonGenerator.writeArrayFieldStart("componentMaps");
		for(ComponentMapBean componentMap : map.getComponents()) {
			writeComponentMap(jsonGenerator, componentMap);
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	private void writeSchemeMap(JsonGenerator jsonGenerator, SchemeMapBean schemeMap) throws IOException {
		jsonGenerator.writeStringField("source", schemeMap.getSourceRef().getTargetUrn());
		jsonGenerator.writeStringField("target", schemeMap.getTargetRef().getTargetUrn());
	}

	private void writeComponentMap(JsonGenerator jsonGenerator, ComponentMapBean compMap) throws IOException {
		jsonGenerator.writeStartObject();
		SdmxJsonStaticHelper.writeAnnotable(jsonGenerator, compMap);
		RepresentationMapRefBean repMapRef = compMap.getRepMapRef();
		if(repMapRef != null) {
			jsonGenerator.writeObjectFieldStart("representationMapping");
			RepresentationMapRefBean repMap = compMap.getRepMapRef();
			if(repMap.getCodelistMap() != null) {
				jsonGenerator.writeStringField("codelistMap", repMap.getCodelistMap().getId());
			}
			if(repMap.getToTextFormat() != null) {
				SdmxJsonStaticHelper.writeTexFormat(jsonGenerator, repMap.getToTextFormat(), "toTextFormat", false);
			}
			if(repMap.getToValueType() != null) {
				SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "toValueType", repMap.getToValueType().toString());
			}
			if(ObjectUtil.validMap(repMap.getValueMappings())) {
				writeValueMap(jsonGenerator, repMap.getValueMappings());
			}
			jsonGenerator.writeEndObject();
		}
		List<String> mapConceptRef = compMap.getMapConceptRef();
		if(ObjectUtil.validCollection(mapConceptRef)) {
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "source", mapConceptRef.get(0));
		}
		List<String> mapTargetConceptRef = compMap.getMapTargetConceptRef();
		if(ObjectUtil.validCollection(mapTargetConceptRef)) {
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "target", mapTargetConceptRef.get(0));
		}
		jsonGenerator.writeEndObject();
	}

	private void writeValueMap(JsonGenerator jsonGenerator, Map<String, Set<String>> valueMappings) throws IOException {
		jsonGenerator.writeObjectFieldStart("valueMap");
		if(!valueMappings.isEmpty()) {
			jsonGenerator.writeArrayFieldStart("valueMappings");
			jsonGenerator.writeStartObject();
			valueMappings.forEach((source, target) -> {
				try {
					jsonGenerator.writeStringField(source, target.iterator().next());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			});
			jsonGenerator.writeEndObject();
			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndObject();

	}

}
