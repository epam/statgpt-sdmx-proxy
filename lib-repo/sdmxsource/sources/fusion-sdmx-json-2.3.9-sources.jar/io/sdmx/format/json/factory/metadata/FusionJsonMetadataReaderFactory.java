package io.sdmx.format.json.factory.metadata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataReaderFactory;
import io.sdmx.format.json.engine.metadata.fusion.FusionJsonMetadataReaderEngine;
import io.sdmx.format.json.util.SdmxJsonUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonMetadataReaderFactory implements IMetadataReaderFactory, IFusionSingleton {
	private static FusionJsonMetadataReaderFactory INSTANCE;
	
	private static final Logger LOG = LoggerFactory.getLogger(FusionJsonMetadataReaderFactory.class);

	public static FusionJsonMetadataReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static FusionJsonMetadataReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	/**
	 * Has to be a larger number then {@link SdmxJsonMetadataReaderFactory} 
	 */
	public Integer getPriority() {
		return 11;
	}

	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) {
		if(rdl.getFormat() == FILE_FORMAT.JSON) {
			String format = SdmxJsonUtil.getPathValue(rdl, "meta.format");
			if(format != null && format.equals("fusionjson")) {
				return FusionJsonMetadataReaderEngine.getInstance().parse(rdl);
			}
		}
		return null;
	}
}
