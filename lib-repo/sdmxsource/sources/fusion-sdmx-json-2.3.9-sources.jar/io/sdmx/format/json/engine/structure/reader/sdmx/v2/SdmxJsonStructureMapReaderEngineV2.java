package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimeComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonAnnotableUtil;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonStructureMapReaderEngineV2 extends AbstractSdmxJsonReaderEngine<IStructureMapMutableBean> implements IFusionSingleton {
	private static SdmxJsonStructureMapReaderEngineV2 INSTANCE;

	public static SdmxJsonStructureMapReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureMapReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "structureMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IStructureMapBean.class;
    }

    @Override
    protected IStructureMapMutableBean getMutable() {
        return new StructureMapMutableBean();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, IStructureMapMutableBean mutable,
            JsonReader reader) {
        switch(fieldName)  {
        case "source" :
            mutable.setSourceRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "target":
            mutable.setTargetRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "epochMaps":
            processEpochMaps(reader, mutable);
            return true;
        case "datePatternMaps":
            processTimePatternMaps(reader, mutable);
            return true;
        case "frequencyFormatMappings":
            processFrequencyFormatMap(reader, mutable);
            return true;
        case "componentMaps":
            processComponentMaps(reader, mutable);
            return true;
        case "fixedValueMaps":
            processFixedValueMaps(reader, mutable);
            return true;
        }
        return false;
    }

	private void processEpochMaps(JsonReader jReader, IStructureMapMutableBean map) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			processEpochMap(jReader, map);
		}
	}
	
	private void processEpochMap(JsonReader jReader, IStructureMapMutableBean map) {
		IEpochMapMutableBean returnBean = map.addEpochMap();
		while(jReader.moveNext())  {
			if (jReader.isEndObject()) {
				break;
			}
			
			if(!processBaseTimeMap(jReader, returnBean)) {
				String nodeName = jReader.getCurrentFieldName();
				if(nodeName.equals("basePeriod")) {
					returnBean.setBasePeriod(jReader.getValueAsString());
				} else if(nodeName.equals("epochPeriod")) {
					returnBean.setEpochInterval(EPOCH.fromString(jReader.getValueAsString()));
				} else if(nodeName.equals("resolvePeriod")) {
					returnBean.setPeriodResolution(PERIOD_POSITION.fromString(jReader.getValueAsString()));
				}
			}
		}
	}
	

	private void processTimePatternMaps(JsonReader jReader, IStructureMapMutableBean map) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			processTimePatternMap(jReader, map);
		}
	}
	
	private void processTimePatternMap(JsonReader jReader, IStructureMapMutableBean map) {
		ITimePatternMapMutableBean returnBean = map.addTimePatternMap();
		while(jReader.moveNext())  {
			if (jReader.isEndObject()) {
				break;
			}
			if(!processBaseTimeMap(jReader, returnBean)) {
				String nodeName = jReader.getCurrentFieldName();
				if(nodeName.equals("resolvePeriod")) {
					returnBean.setPeriodResolution(PERIOD_POSITION.fromString(jReader.getValueAsString()));
				} else if(nodeName.equals("sourcePattern")) {
					returnBean.setPattern(jReader.getValueAsString());
				} else if(nodeName.equals("locale")) {
					returnBean.setLocale(jReader.getValueAsString());
				}
			}
		}
	}
	
	
	private boolean processBaseTimeMap(JsonReader jReader, ITimeComponentMapMutableBean returnBean) {
		if(SdmxJsonAnnotableUtil.processBean(returnBean, jReader)) {
			return true;
		}
		String nodeName = jReader.getCurrentFieldName();
		switch(nodeName) {
		case "mappedComponents" :
			while(jReader.moveNext()) {
				if(jReader.isEndArray()) {
					return true;
				}
				if(jReader.isEndObject()) {
					continue;
				}
				nodeName = jReader.getCurrentFieldName();
				if(nodeName.equals("source")) {
					returnBean.setSourceComponent(jReader.getValueAsString());
					
				} else if(nodeName.equals("target")) {
					returnBean.setTargetComponent(jReader.getValueAsString());
				}
			}
			break;
		case "frequencyDimension" :
			returnBean.setOutputFrequencyDimId(jReader.getValueAsString());
			return true;
		case "targetFrequencyID" :
			returnBean.setOutputFrequencyId(jReader.getValueAsString());
			return true;
		}
		return false;
	}
	

	private void processFrequencyFormatMap(JsonReader reader, IStructureMapMutableBean map) {
		//TODO - can not store this information as it is not modelled in the Bean
		reader.moveToEndArray();
	}
	
	private void processComponentMaps(JsonReader jReader, IStructureMapMutableBean map) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			processComponentMap(jReader, map);
		}
	}
	
	private void processComponentMap(JsonReader jReader, IStructureMapMutableBean map) {
		IComponentMapMutableBean returnBean = map.addComponentMap();
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			String nodeName = jReader.getCurrentFieldName();
			
			if(nodeName.equals("source")) {
				returnBean.setSourceComponents(jReader.readStringArray());
			} else if(nodeName.equals("target")) {
				returnBean.setTargetComponents((jReader.readStringArray()));
			} else if(nodeName.equals("representationMap")) {
				returnBean.setRepresentationMapRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			}
		}
	}
	
	private void processFixedValueMaps(JsonReader jReader, IStructureMapMutableBean map) {
		
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			}
			processFixedValueMap(jReader, map);
		}
	}
	
	private void processFixedValueMap(JsonReader jReader, IStructureMapMutableBean map) {
		String source = null;
		String target = null;
		String value = null;
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				if(source != null) {
					map.addFixedInput(source, value);
				} else if(target != null) {
					map.addFixedOutput(target, value);
				}
				break;
			}
			if(SdmxJsonAnnotableUtil.processBean(map, jReader)) {
				continue;
			}
			String nodeName = jReader.getCurrentFieldName();
			if(nodeName.equals("source")) {
				source = jReader.getValueAsString();
			} else if(nodeName.equals("target")) {
				target = jReader.getValueAsString();
			} else if(nodeName.equals("values")) {
				value = CollectionUtil.join(",", "", jReader.readStringArray());
			}
		}
	}
}
