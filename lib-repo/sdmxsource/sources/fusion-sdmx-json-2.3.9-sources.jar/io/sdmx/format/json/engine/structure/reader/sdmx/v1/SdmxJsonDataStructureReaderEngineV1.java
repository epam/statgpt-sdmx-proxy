package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonComponentUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonIdentifiableUtil;
import io.sdmx.im.mutable.datastructure.AttributeListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonDataStructureReaderEngineV1 extends AbstractSdmxJsonReaderEngine<DataStructureMutableBean> implements IFusionSingleton {
	private static SdmxJsonDataStructureReaderEngineV1 INSTANCE;

	public static SdmxJsonDataStructureReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataStructureReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	
    @Override
    public String getContainerElement() {
        return "dataStructures";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return DataStructureBean.class;
    }

    @Override
    protected DataStructureMutableBean getMutable() {
        return new DataStructureMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, DataStructureMutableBean mutable,JsonReader reader) {
        if(fieldName.equals("dataStructureComponents")) {
            buildDataStructure(reader, mutable);
            return true;
        }
        return false;
    }

	private void buildDataStructure(JsonReader jReader, DataStructureMutableBean dsdBean) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "attributeList":
				AttributeListMutableBean attras = getAttributes(jReader);
				dsdBean.setAttributeList(attras);
				break;
			case "dimensionList":
				DimensionListMutableBean dims = readDimensions(jReader);
				dsdBean.setDimensionList(dims);
				break;
			case "groups":
				List<GroupMutableBean> groups = readGroups(jReader);
				dsdBean.setGroups(groups);
				break;
			case "measureList":
				MeasureListMutableBean measureList = readMeasures(jReader);
				dsdBean.setMeasureList(measureList);
				break;
			}
		}
	}

	private MeasureListMutableBean readMeasures(JsonReader jReader) {
		MeasureListMutableBean ret = new MeasureListMutableBeanImpl();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonIdentifiableUtil.processBean(ret, jReader)) {
				continue;
			}
			if(jReader.getCurrentFieldName().equals("primaryMeasure")) {
				MeasureMutableBean pm = new PrimaryMeasureMutableBeanImpl();
				while(jReader.moveNext()) {
					if(jReader.isEndObject()) {
						break;
					}
					SdmxJsonComponentUtil.processBean(pm, jReader, false);
				}
				ret.addMeasures(pm);
			}
		}
		return ret;
	}

	private List<GroupMutableBean> readGroups(JsonReader jReader) {
		List<GroupMutableBean> retList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			GroupMutableBean group = new GroupMutableBeanImpl();
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				if(SdmxJsonIdentifiableUtil.processBean(group, jReader)) {
					continue;
				}
				switch(fieldName) {
				case "attachmentConstraint":
					String value = jReader.getValueAsString();
					group.setAttachmentConstraintRef(new StructureReferenceBeanImpl(value));
					break;
				case "groupDimensions":
					List<String> groupDimIds = jReader.readStringArray();
					group.setDimensionRef(groupDimIds);
					break;
				}
			}
			retList.add(group);
		}
		return retList;
	}

	private DimensionListMutableBean readDimensions(JsonReader jReader) {
		DimensionListMutableBean dimList = new DimensionListMutableBeanImpl();
		while(jReader.moveNext()) {
			if(SdmxJsonIdentifiableUtil.processBean(dimList, jReader)) {
				continue;
			}
			if(jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "dimensions":
				List<DimensionMutableBean> dims = readDims(jReader, SDMX_STRUCTURE_TYPE.DIMENSION);
				addDimensions(dims, dimList);
				break;
			case "measureDimensions":
				List<DimensionMutableBean> measures = readDims(jReader, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
				addDimensions(measures, dimList);
				break;
			case "timeDimensions":
				List<DimensionMutableBean> timeDims = readDims(jReader, SDMX_STRUCTURE_TYPE.TIME_DIMENSION);
				addDimensions(timeDims, dimList);
				break;
			}
		}
		return dimList;
	}

	private void addDimensions(List<DimensionMutableBean> dims, DimensionListMutableBean dimList) {
		dims.forEach(dimList::addDimension);
	}

	private List<DimensionMutableBean> readDims(JsonReader jReader, SDMX_STRUCTURE_TYPE dimensionType) {
		List<DimensionMutableBean> rtestList = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			DimensionMutableBean dim = new DimensionMutableBeanImpl();
			if(dimensionType == SDMX_STRUCTURE_TYPE.TIME_DIMENSION) {
				dim.setTimeDimension(true);
			}else if(dimensionType == SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION) {
				dim.setMeasureDimension(true);
			}
			while (jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				if(SdmxJsonComponentUtil.processBean(dim, jReader, false)) {
					continue;
				}
				switch(fieldName) {
				case "conceptRoles":
					List<StructureReferenceBean> concepts = readConceptRoles(jReader);
					dim.setConceptRole(concepts);
					break;
				}
			}
			rtestList.add(dim);
		}
		return rtestList;
	}

	private AttributeListMutableBean getAttributes(JsonReader jReader) {
		AttributeListMutableBean attrList = new AttributeListMutableBeanImpl();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			String currentFieldName = jReader.getCurrentFieldName();
			if(SdmxJsonIdentifiableUtil.processBean(attrList, jReader)) {
				continue;
			}
			if(currentFieldName.equals("attributes")){
				while (jReader.moveNext()) {
					if(jReader.isEndArray()) {
						break;
					}
					AttributeMutableBean atBean = new AttributeMutableBeanImpl();
					while (jReader.moveNext()) {
						if (jReader.isEndObject()) {
							break;
						}
						String fieldName = jReader.getCurrentFieldName();
						if(SdmxJsonComponentUtil.processBean(atBean, jReader, false)) {
							continue;
						}
						String value = jReader.getValueAsString();
						switch(fieldName) {
						case "assignmentStatus":
							boolean assignmentStatus;
							if (value.equals("Conditional")) {
								assignmentStatus = false;
							} else if (value.equals("Mandatory")) {
								assignmentStatus = true;
							} else {
								throw new SdmxSemmanticException("Illegal value specified for 'assignmentStatus'. Value is " + value);
							}
							atBean.setMandatory(assignmentStatus);
							break;
						case "attributeRelationship":
							readAttributeRelationship(jReader, atBean);
							break;
						case "conceptRoles":
							List<StructureReferenceBean> concepts = readConceptRoles(jReader);
							atBean.setConceptRoles(concepts);
							break;
						}
					}
					attrList.addAttribute(atBean);
				}
			}
		}
		return attrList;
	}

	private List<StructureReferenceBean> readConceptRoles(JsonReader jReader) {
		return jReader.readStringArray().stream().map(StructureReferenceBeanImpl::new).collect(Collectors.toList());
	}

	private void readAttributeRelationship(JsonReader jReader, AttributeMutableBean atBean) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			switch(fieldName) {
			case "attachmentGroups":
				break;
			case "dimensions":
				atBean.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
				List<String> dims = jReader.readStringArray();
				atBean.setDimensionReferences(dims);
				break;
			case "group":
				atBean.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP);
				atBean.setAttachmentGroup(value);
				break;
			case "none":
				atBean.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
				jReader.moveToEndObject();
				break;
			case "primaryMeasure":
				atBean.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
				atBean.addMeasureReference(value);
				break;
			}
		}
	}


}
