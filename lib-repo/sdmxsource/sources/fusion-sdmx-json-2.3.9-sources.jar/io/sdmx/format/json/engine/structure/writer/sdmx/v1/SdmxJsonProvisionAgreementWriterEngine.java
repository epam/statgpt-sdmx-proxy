package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonProvisionAgreementWriterEngine extends SdmxJsonMaintainableStructureWriterEngine<ProvisionAgreementBean> implements IFusionSingleton {
	private static SdmxJsonProvisionAgreementWriterEngine INSTANCE;

	public static SdmxJsonProvisionAgreementWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonProvisionAgreementWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonProvisionAgreementWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProvisionAgreementBean aProvisionAgreement) throws JsonGenerationException, IOException {
		ICrossReferenceBean<DataflowBean> structureUseage = aProvisionAgreement.getStructureUseage();
		jsonGenerator.writeStringField("structureUsage", structureUseage.getReference().getURN());

		ICrossReferenceBean<DataProviderBean> dataProviderRef = aProvisionAgreement.getDataproviderRef();
		jsonGenerator.writeStringField("dataProvider", dataProviderRef.getReference().getURN());

	}
}
