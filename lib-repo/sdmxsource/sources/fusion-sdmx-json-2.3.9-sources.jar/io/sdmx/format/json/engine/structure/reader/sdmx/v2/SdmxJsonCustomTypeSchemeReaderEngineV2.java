package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.CustomTypeMutableBean;
import io.sdmx.im.mutable.transformation.CustomTypeSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonCustomTypeSchemeReaderEngineV2 extends SdmxJsonVtlSchemeReaderEngine<ICustomTypeMutableBean, ICustomTypeSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonCustomTypeSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonCustomTypeSchemeReaderEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonCustomTypeSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
    protected String getItemLabel() {
        return "customTypes";
    }

    @Override
    public String getContainerElement() {
        return "customTypeSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ICustomTypeSchemeBean.class;
    }

    @Override
    protected ICustomTypeSchemeMutableBean getMutable() {
        return new CustomTypeSchemeMutableBean();
    }
	
	@Override
	protected List<ICustomTypeMutableBean> readItems(JsonReader json) {
		List<ICustomTypeMutableBean> returnList = new ArrayList<>();
		while (json.moveNext()) {
			if (json.isEndArray()) {
				break;
			}
			if (json.isStartObject()) {
				ICustomTypeMutableBean mutable = readCustomType(json);
				returnList.add(mutable);
			}
		}
		return returnList;
	}

	private ICustomTypeMutableBean readCustomType(JsonReader json) {
		ICustomTypeMutableBean mutable = new CustomTypeMutableBean();
		while (json.moveNext()) {
			if (json.isEndObject()) {
				break;
			}
			if (SdmxJsonNameableUtil.processBean(mutable, json)) {
				continue;
			}
			String fieldName = json.getCurrentFieldName();
			switch (fieldName) {
				case "vtlScalarType":
					mutable.setVtlScalarType(json.getValueAsString());
					break;
				case "dataType":
					mutable.setDataType(json.getValueAsString());
					break;
				case "vtlLiteralFormat":
					mutable.setVtlLiteralFormat(json.getValueAsString());
					break;
				case "outputFormat":
					mutable.setOutputFormat(json.getValueAsString());
					break;
				case "nullValue":
					mutable.setNullValue(json.getValueAsString());
					break;
			}
		}
		return mutable;
	}
}
