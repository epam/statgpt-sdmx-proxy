package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonHierarchicalCodelistWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<HierarchyBean> implements IFusionSingleton {

	private static SdmxJsonHierarchicalCodelistWriterEngineV2 INSTANCE;

	public static SdmxJsonHierarchicalCodelistWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonHierarchicalCodelistWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonHierarchicalCodelistWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyBean hCodelist) throws IOException {
		writeHierarchies(jsonGenerator, externalLinks, hCodelist);
	}

	private void writeHierarchies(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, HierarchyBean hierarchyBean) throws IOException {
		if (hierarchyBean != null) {
			jsonGenerator.writeBooleanField("hasFormalLevels", hierarchyBean.hasFormalLevels());
			List<HierarchicalCodeBean> hierarchicalCodeBeans = hierarchyBean.getHierarchicalCodeBeans();
			if (ObjectUtil.validCollection(hierarchicalCodeBeans)) {
				writeHierarchicalCodeBeans(jsonGenerator, externalLinks, hierarchicalCodeBeans);
			}
			if (hierarchyBean.getLevel() != null) {
				writeLevel(hierarchyBean.getLevel(), externalLinks, jsonGenerator);
			}
		}
	}

	private void writeLevel(LevelBean level, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("level");
		writeNameable(jsonGenerator, level, externalLinks);
		SdmxJsonStaticHelper.writeTexFormat(jsonGenerator, level.getCodingFormat(), "codingFormat", true);
		if (level.getChildLevel() != null) {
			writeLevel(level.getChildLevel(), externalLinks, jsonGenerator);
		}
		jsonGenerator.writeEndObject();
	}

	private void writeHierarchicalCodeBeans(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<HierarchicalCodeBean> hierarchicalCodeBeans) throws IOException {
		jsonGenerator.writeArrayFieldStart("hierarchicalCodes");
		for (HierarchicalCodeBean hierarchicalCodeBean : hierarchicalCodeBeans) {
			jsonGenerator.writeStartObject();
			super.writeIdentifiable(jsonGenerator, hierarchicalCodeBean, externalLinks);
			writeValidityDate(jsonGenerator, "validFrom", hierarchicalCodeBean.getValidFrom());
			writeValidityDate(jsonGenerator, "validTo", hierarchicalCodeBean.getValidTo());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "code", hierarchicalCodeBean.getCodeReference().getTargetUrn());
			if (hierarchicalCodeBean.hasChildren()) {
				writeHierarchicalCodeBeans(jsonGenerator, externalLinks, hierarchicalCodeBean.getCodeRefs());
			}
			if (hierarchicalCodeBean.getLevel(false) != null) {
				SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "level", hierarchicalCodeBean.getLevel(false).getUrn());
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeValidityDate(JsonGenerator jsonGenerator, String fieldName, SdmxDate aDate) throws IOException {
		if (aDate != null) {
			jsonGenerator.writeStringField(fieldName, aDate.getDateInSdmxFormat());
		}
	}
}
