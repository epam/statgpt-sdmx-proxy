package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonMetadataflowWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<MetadataFlowBean> implements IFusionSingleton {
	private static SdmxJsonMetadataflowWriterEngineV2 INSTANCE;

	public static SdmxJsonMetadataflowWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataflowWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonMetadataflowWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataFlowBean mdf) throws JsonGenerationException, IOException {
		ICrossReferenceBean<MetadataStructureDefinitionBean> metadataStructureRef = mdf.getMetadataStructureRef();
		jsonGenerator.writeStringField("structure", metadataStructureRef.getReference().getURN());
		
		jsonGenerator.writeArrayFieldStart("targets");
		for(ICrossReferenceBeanBase target : mdf.getTargets()) {
			jsonGenerator.writeString(target.getReference().getURN());
		}
		jsonGenerator.writeEndArray();
	}

}
