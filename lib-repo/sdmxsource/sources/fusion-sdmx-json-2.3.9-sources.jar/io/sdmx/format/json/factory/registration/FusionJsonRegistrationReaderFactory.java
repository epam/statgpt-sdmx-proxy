package io.sdmx.format.json.factory.registration;

import java.util.List;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.registration.IRegistrationReaderFactory;
import io.sdmx.format.json.engine.registration.FusionJsonRegistrationReaderEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Reads SDMX-ML Registration messages
 *
 */
public class FusionJsonRegistrationReaderFactory implements IRegistrationReaderFactory, IFusionSingleton {
	private static FusionJsonRegistrationReaderFactory INSTANCE;

	public static FusionJsonRegistrationReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRegistrationReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static FusionJsonRegistrationReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private FusionJsonRegistrationReaderFactory() {}

	@Override
	public List<RegistrationInformation> readRegistrations(ReadableDataLocation rdl) {
		if(rdl.getFormat() == FILE_FORMAT.JSON) {
			return FusionJsonRegistrationReaderEngine.parse(rdl);
		}
		return null;
	}
}
