package io.sdmx.format.json.serialiser;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.io.IDeferredDefinitionSerialiser;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.AbstractJsonMetaAndDataWriter;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.im.beans.base.LinkBean.LinkBuilder;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.io.InMemoryReadableDataLocation;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.json.JsonWriter;
import io.sdmx.utils.json.YAMLReader;

public class YamlDefferedBeanSerialiser extends AbstractJsonMetaAndDataWriter<IDeferredBeanDefinition>
implements IDeferredDefinitionSerialiser<IDeferredBeanDefinition>, IFusionSingleton {
    private static YamlDefferedBeanSerialiser INSTANCE;

    //Fields in the Output
    private static final String FIELD_ANNOTATIONS = "annotations";
    private static final String FIELD_ANNOTATION_ID = "id";
    private static final String FIELD_ANNOTATION_TITLE = "title";
    private static final String FIELD_ANNOTATION_TYPE = "type";
    private static final String FIELD_ANNOTATION_URI = "uri";
    private static final String FIELD_ANNOTATION_TEXT = "text";

    private static final String FIELD_LINKS = "links";
    private static final String FIELD_LINK_REL = "rel";
    private static final String FIELD_LINK_TYPE = "type";
    private static final String FIELD_LINK_HREF= "href";
    private static final String FIELD_LINK_URI= "uri";
    private static final String FIELD_LINK_URN = "urn";
    private static final String FIELD_LINK_TITLE = "title";
    

    private static final String FIELD_MAINT_URN = "urn";
    private static final String FIELD_MAINT_CHECKSUM = "checksum";
    private static final String FIELD_MAINT_NAME = "name";
    private static final String FIELD_MAINT_DESCRIPTION = "description";
    private static final String FIELD_MAINT_VALIDITY = "validity";
    private static final String FIELD_MAINT_STRUCTURE_URL = "structure_url";
    private static final String FIELD_MAINT_SERVICE_URL = "service_url";
    private static final String FIELD_MAINT_PROPERTY = "property";

    public static YamlDefferedBeanSerialiser getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new YamlDefferedBeanSerialiser();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    private YamlDefferedBeanSerialiser() {
        super(JSON_COMPATIBLE_FORMAT.YAML);
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getId() {
        return "yaml";
    }

    @Override
    public IDeferredBeanDefinition read(InputStream in) {
        JsonReader reader = new YAMLReader(new InMemoryReadableDataLocation(in));
        DefferedBeanBuilder builder = DeferredBeanDefinition.builder();
            reader.iterateFields(fieldName-> {
                if(fieldName.equals("meta")) {
                    reader.moveToEndCurrentObject();
                }
                if(fieldName.equals("data")) {
                    reader.iterateFields(field-> {
                        switch(reader.getCurrentFieldName()) {
                        case FIELD_MAINT_URN :
                            builder.urn(reader.getValueAsString());
                            break;
                        case FIELD_MAINT_CHECKSUM :
                            builder.checksum(reader.getValueAsString());
                            break;
                        case FIELD_MAINT_NAME :
                            builder.names(processMap(reader));
                            break;
                        case FIELD_MAINT_DESCRIPTION :
                            builder.descriptions(processMap(reader));
                            break;
                        case FIELD_MAINT_VALIDITY :
                            builder.validityPeriod(SdmxPeriodImpl.fromISOString(reader.getValueAsString()));
                            break;
                        case FIELD_MAINT_STRUCTURE_URL :
                            builder.structureURL(reader.getValueAsString());
                            break;
                        case FIELD_MAINT_SERVICE_URL :
                            builder.serviceURL(reader.getValueAsString());
                            break;
                        case FIELD_ANNOTATIONS :
                            builder.annotations(readAnnotations(reader));
                            break;
                        case FIELD_LINKS :
                            builder.links(readLinks(reader));
                            break;
                        case FIELD_MAINT_PROPERTY :
                            builder.properties(reader.readStringMap());
                        }
                    });
                }
            });
        IDeferredBeanDefinition deferred = builder.build();
        return deferred;
    }

    private List<AnnotationMutableBean> readAnnotations(JsonReader reader) {
        return reader.readObjectArray(reader, () -> {
            AnnotationMutableBean annotation = new AnnotationMutableBeanImpl();
            reader.iterateFields(field-> {
                switch(field) {
                case FIELD_ANNOTATION_ID :
                    annotation.setId(reader.getValueAsString());
                    break;
                case FIELD_ANNOTATION_TITLE :
                    annotation.setTitle(reader.getValueAsString());
                    break;
                case FIELD_ANNOTATION_TYPE :
                    annotation.setType(reader.getValueAsString());
                    break;
                case FIELD_ANNOTATION_URI :
                    annotation.setUri(reader.getValueAsString());
                    break;
                case FIELD_ANNOTATION_TEXT :
                    reader.readStringMap().forEach((k,v)-> {
                        annotation.addText(k, v);
                    });
                    break;
                }
            });
            return annotation;
        });
    }

    private List<ILinkBean> readLinks(JsonReader reader) {
        return reader.readObjectArray(reader, () -> {
            LinkBuilder linkBuilder = LinkBean.builder();
            reader.iterateFields(field-> {
                switch(field) {
                case FIELD_LINK_REL :
                    linkBuilder.rel(reader.getValueAsString());
                    break;
                case FIELD_LINK_TYPE :
                    linkBuilder.type(reader.getValueAsString());
                    break;
                case FIELD_LINK_HREF :
                    linkBuilder.href(reader.getValueAsString());
                    break;
                case FIELD_LINK_URI :
                    linkBuilder.uri(reader.getValueAsString());
                    break;
                case FIELD_LINK_URN :
                    linkBuilder.urn(reader.getValueAsString());
                    break;
                case FIELD_LINK_TITLE :
                    reader.readStringMap().forEach((k,v)-> {
                        linkBuilder.title(k, v);
                    });
                    break;
                }
            });
            return linkBuilder.build();
        });
    }

    private Map<String, String> processMap(JsonReader reader) {
        Map<String, String> returnMap = new HashMap<>();
        while(reader.moveNext()) {
            if(reader.isEndObject()) {
                break;
            }
            String locale = reader.getCurrentFieldName();
            String value = reader.getValueAsString();
            returnMap.put(locale, value);
        }
        return returnMap;
    }

    @Override
    public void write(IDeferredBeanDefinition defintion, OutputStream out) {
        super.writeObject(defintion, out);
    }

    @Override
    protected void writeMeta(IDeferredBeanDefinition bean, JsonGenerator jsonWriter) throws IOException {
        jsonWriter.writeStringField("format", "fusion-yaml");
        jsonWriter.writeStringField("version", "1.0.0");
    }

    @Override
    protected void writeData(IDeferredBeanDefinition definition, JsonGenerator jsonWriter) throws IOException {
        jsonWriter.writeStringField("urn", definition.getUrn().getURN());
        if(definition.getChecksum() != null) {
            jsonWriter.writeStringField(FIELD_MAINT_CHECKSUM, definition.getChecksum());
        }
        JsonWriter writer = new JsonWriter(jsonWriter);
        writer.writeMap(FIELD_MAINT_NAME, definition.getNames());
        writer.writeMap(FIELD_MAINT_DESCRIPTION, definition.getDescriptions());
        writer.writeMap(FIELD_MAINT_PROPERTY, definition.getProperties());
        writer.writeOptional(FIELD_MAINT_SERVICE_URL, definition.getServiceURL());
        writer.writeOptional(FIELD_MAINT_STRUCTURE_URL, definition.getStructureURL());
        writer.writeOptional(definition.getValidityPeriod(), validity -> writer.writeOptional(FIELD_MAINT_VALIDITY, validity.toISOString()));
        
        writeAnnotations(definition.getAnnotations(), writer);
        writeLinks(definition.getLinks(), writer);
    }

    private void writeAnnotations(List<AnnotationBean> annotations, JsonWriter jsonWriter) throws IOException {
        if(annotations.isEmpty()) {
            return;
        }
        jsonWriter.writeArray(FIELD_ANNOTATIONS, annotations, annotation -> {
            jsonWriter.writeOptional(FIELD_ANNOTATION_ID, annotation.getId());
            jsonWriter.writeOptional(FIELD_ANNOTATION_TITLE, annotation.getTitle());
            jsonWriter.writeOptional(FIELD_ANNOTATION_TYPE, annotation.getType());
            jsonWriter.writeOptional(FIELD_ANNOTATION_URI, annotation.getUri());
            //TODO refactor text type wrapper, simplify to a map<str, str> with obj
            writeText(annotation.getText(true), FIELD_ANNOTATION_TEXT, jsonWriter);
        });
    }

    private void writeLinks(List<ILinkBean> links, JsonWriter jsonWriter) throws IOException {
        if(links.isEmpty()) {
            return;
        }
        jsonWriter.writeArray(FIELD_LINKS, links, link-> {
            jsonWriter.writeOptional(FIELD_LINK_REL, link.getRel());
            jsonWriter.writeOptional(FIELD_LINK_TYPE, link.getType());
            jsonWriter.writeOptional(FIELD_LINK_HREF, link.getHRef());
            jsonWriter.writeOptional(FIELD_LINK_URI, link.getUri());
            jsonWriter.writeOptional(FIELD_LINK_URN, link.getUrn());
            writeText(link.getTitles(false), FIELD_LINK_TITLE, jsonWriter);
        });
    }

    private void writeText(List<TextTypeWrapper> tt, String field, JsonWriter jsonWriter) {
        if(tt.isEmpty()) {
            return;
        }
        jsonWriter.writeMap(field, tt, text-> {
            jsonWriter.writeOptional(text.getLocale(), text.getValue());
        });
    }
}
