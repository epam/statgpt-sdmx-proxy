package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;

public abstract class FusionJsonNameableStructureWriterEngine<T extends NameableBean> extends FusionJsonIdentifiableStructureWriterEngine<T> {

	@Override
	public void writeStructure(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T nameable) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart(nameable.getStructureType().getUrnClass());
		writeNameable(jsonGenerator, externalLinks, nameable);
		writeStructureInternal(jsonGenerator, externalLinks, nameable);
		jsonGenerator.writeEndObject();
	}
	
	void writeNameable(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, NameableBean nameable) throws JsonGenerationException, IOException {
		FusionJsonStaticHelper.writeNameable(jsonGenerator, externalLinks, nameable);
	}
}
