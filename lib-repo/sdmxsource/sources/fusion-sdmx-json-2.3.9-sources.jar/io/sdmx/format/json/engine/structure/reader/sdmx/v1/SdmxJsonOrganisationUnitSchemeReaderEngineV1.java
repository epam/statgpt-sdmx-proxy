package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonContactUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.base.OrganisationUnitMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonOrganisationUnitSchemeReaderEngineV1 extends SdmxJsonItemSchemeReaderEngineV1<OrganisationUnitMutableBean, OrganisationUnitSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonOrganisationUnitSchemeReaderEngineV1 INSTANCE;

	public static SdmxJsonOrganisationUnitSchemeReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonOrganisationUnitSchemeReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	

    @Override
    protected OrganisationUnitSchemeMutableBean getMutable() {
        return new OrganisationUnitSchemeMutableBeanImpl();
    }

    @Override
    public String getContainerElement() {
        return "organisationUnitSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return OrganisationUnitSchemeBean.class;
    }

	@Override
	protected List<OrganisationUnitMutableBean> readItems(JsonReader jReader) {
		List<OrganisationUnitMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				OrganisationUnitMutableBean anOrgUnit = readOrgUnit(jReader);
				returnList.add(anOrgUnit);
			}
		}

		return returnList;
	}

	private OrganisationUnitMutableBean readOrgUnit(JsonReader jReader) {
		OrganisationUnitMutableBean anOrgUnit = new OrganisationUnitMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(anOrgUnit, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("parent")) {
				anOrgUnit.setParentUnit(jReader.getValueAsString());
			} else {
				List<ContactMutableBean> contacts = SdmxJsonContactUtil.readContacts(jReader);
				if(contacts.size() > 0) {
					anOrgUnit.setContacts(contacts);
				}
			}
		}
		return anOrgUnit;
	}

	@Override
	protected String getItemLabel() {
		return "organisationUnits";
	}
}
