package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonProvisionAgreementWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<ProvisionAgreementBean> implements IFusionSingleton {
	private static SdmxJsonProvisionAgreementWriterEngineV2 INSTANCE;

	public static SdmxJsonProvisionAgreementWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonProvisionAgreementWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonProvisionAgreementWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProvisionAgreementBean aProvisionAgreement) throws JsonGenerationException, IOException {
		ICrossReferenceBean<DataflowBean> structureUseage = aProvisionAgreement.getStructureUseage();
		jsonGenerator.writeStringField("dataflow", structureUseage.getReference().getURN());

		ICrossReferenceBean<DataProviderBean> dataProviderRef = aProvisionAgreement.getDataproviderRef();
		jsonGenerator.writeStringField("dataProvider", dataProviderRef.getReference().getURN());

	}
}
