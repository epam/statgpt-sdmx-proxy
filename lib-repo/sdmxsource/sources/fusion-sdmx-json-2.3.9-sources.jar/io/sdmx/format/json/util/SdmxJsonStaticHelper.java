package io.sdmx.format.json.util;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.LINK_REL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.INamedBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.constant.JSON_SCHEMA;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxJsonStaticHelper{

	public static void writeIdentifiable(JsonGenerator jsonGenerator,
										 IExternalMaintainableLinks externalLinks,
										 IdentifiableBean identifiable, JSON_SCHEMA schema) throws JsonGenerationException, IOException {
		writeLinks(identifiable, schema, externalLinks, jsonGenerator);
		jsonGenerator.writeStringField("id", identifiable.getId());
		writeAnnotable(jsonGenerator, identifiable);
	}

	public static void writeLinks(IdentifiableBean ident, JSON_SCHEMA schema,
								  IExternalMaintainableLinks externalLinks,
								  JsonGenerator writer) throws IOException {
		Set<ILinkBean> links = externalLinks != null ? externalLinks.getLinks(ident.getURN()) : null;
		writer.writeArrayFieldStart("links");
		ISDMXStructureType<?, ?> type = ident.getStructureClass();
		
		SDMX_STRUCTURE_TYPE sdmxStructure = ident.getStructureType();
		if(sdmxStructure != null && sdmxStructure == SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION && ident.getId().equals("OBS_VALUE")) {
			sdmxStructure = SDMX_STRUCTURE_TYPE.PRIMARY_MEASURE;
		}
		String linkType = null;
		if(sdmxStructure != null) {
			linkType = sdmxStructure.getUrnClass().toLowerCase();
		} else {
			linkType = type.getUrnClass().toLowerCase();
		}
		
		final String selfLinkType = linkType;
		
		MaintainableBean maint = type.isMaintainable() ? ident.getMaintainableParent() : null;
		URI strUrl = null;
		if(maint != null) {
			try {
				strUrl = maint.getStructureURL() != null ? maint.getStructureURL().toURI() : null;
				if(strUrl == null) {
					strUrl = maint.getServiceURL() != null ? maint.getServiceURL().toURI() : null;
				}
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		final URI hRef = strUrl;
		
		writeLink(new ILinkBean() {

			@Override
			public IURN<?> getUrn() {
				return URN.getInstance(ident.getUrn());
			}

			@Override
			public URI getHRef() {
				return hRef;
			}

			@Override
			public URI getUri() {
				return schema.getURI();
			}
			
			@Override
			public String getType() {
				return selfLinkType;
			}

			@Override
			public List<TextTypeWrapper> getTitles(boolean disableLocaleFilter) {
				return null;
			}

			@Override
			public String getTitle(String locale) {
				return null;
			}

			@Override
			public String getTitle() {
				return null;
			}

			@Override
			public String getRel() {
				return LINK_REL.SELF.toString();
			}
		}, writer);

		writeLinks(links, writer, false);
		writeLinks(ident.getLinks(), writer, false);
		writer.writeEndArray();
	}

	public static void writeLinks(Collection<ILinkBean> links, JsonGenerator writer, boolean includeFieldName) throws IOException {
		if(ObjectUtil.validCollection(links)) {
			if(includeFieldName) {
				writer.writeArrayFieldStart("links");
			}
			for(ILinkBean link : links) {
				writeLink(link, writer);
			}
			if(includeFieldName) {
				writer.writeEndArray();
			}
		}
	}

	private static void writeLink(ILinkBean link, JsonGenerator writer) throws IOException {
		writer.writeStartObject();
		if(link.getRel() != null) {
			writer.writeStringField("rel", link.getRel());
		}
		if(link.getHRef() != null) {
			writer.writeStringField("href", link.getHRef().toString());
		}
		if(link.getType() != null) {
			writer.writeStringField("type", link.getType());
		}
		if(link.getUri() != null) {
			writer.writeStringField("uri", link.getUri().toString());
		}
		if(link.getUrn() != null) {
			writer.writeStringField("urn", link.getUrn().toString());
		}
		if(ObjectUtil.validCollection(link.getTitles(false))) {
			writeTextTypeWrapperArray(writer, link.getTitles(false), "titles");
		}
		writer.writeEndObject();
	}


	public static void writeAnnotable(JsonGenerator jsonGenerator, AnnotableBean annotable) throws IOException {
		if(annotable.getAnnotations().isEmpty()) {
			return;
		}
		List<AnnotationBean> annotations = annotable.getAnnotations();
		jsonGenerator.writeArrayFieldStart("annotations");
		for (AnnotationBean annotationBean : annotations) {
			jsonGenerator.writeStartObject();
			writeNonNullString(jsonGenerator, "id", annotationBean.getId());
			writeNonNullString(jsonGenerator, "title", annotationBean.getTitle());
			writeNonNullString(jsonGenerator, "type", annotationBean.getType());
			if(annotationBean.getUri() != null) {
				jsonGenerator.writeArrayFieldStart("links");
				jsonGenerator.writeStartObject();
				//TODO What is the link rel for an annotation?
				jsonGenerator.writeStringField("href", annotationBean.getUri().toString());
				jsonGenerator.writeEndObject();
				jsonGenerator.writeEndArray();
			}
			if (annotationBean.getText() != null && !annotationBean.getText().isEmpty()) {
				writeTextTypeWrapperArray(jsonGenerator, annotationBean.getText(), "texts");
			}
			jsonGenerator.writeEndObject();
		}
		//TODO: Link object contains props from Maintainable (urn). but can be attached to anything, and also is an array, Annotables do not have any fields that a Link Object has yet, so we shall ignore it for now
		//writeLinkableObject(jsonGenerator, annotable);
		jsonGenerator.writeEndArray();
	}

	public static void writeNameable(JsonGenerator jsonGenerator, INamedBean nameable) throws JsonGenerationException, IOException {
		//	writeIdentifiable(jsonGenerator, nameable);
		writeTextTypeWrapperArray(jsonGenerator, nameable.getNames(), "names");
		writeTextTypeWrapperArray(jsonGenerator, nameable.getDescriptions(), "descriptions");
	}

	/**
	 * Writes both the localisedBestMatchText and the text type array to the object
	 * @param jsonGenerator
	 * @param items
	 * @param objectFieldName
	 * @param request
	 * @throws JsonGenerationException
	 * @throws IOException
	 */
	public static void writeTextTypeWrapperArray(JsonGenerator jsonGenerator, List<TextTypeWrapper> items, String objectFieldName) throws JsonGenerationException, IOException {
		if (items.isEmpty()) {
			return;
		}
		String singular = StringUtil.chop(objectFieldName);
		writeLocalisedBestMatchText(jsonGenerator, items, singular);
		jsonGenerator.writeObjectFieldStart(objectFieldName);
		for (TextTypeWrapper textTypeWrapper : items) {
			writeNonNullString(jsonGenerator, textTypeWrapper.getLocale(), textTypeWrapper.getValue());
		}
		jsonGenerator.writeEndObject();

	}



	/**
	 *
	 * <p>A human-readable (best-language-match) description of the target link. This will default to the language from the accept-language header from the request, this should check "titles" for the title </p>
	 * <p>In case that there is no language match for a particular localisable element, it is optional to:</p>
	 * <ul>
	 * 	<li>return the element in a system-default language or alternatively to not return the element</li>
	 * 	<li>indicate available alternative languages for the element's maintainable artefact through links to underlying localised resources</li>
	 * </ul>
	 * <p><strong>It is recommended to indicate all languages used anywhere in the message for localised elements through http Content-Language response header (languages of the intended audience) and/or through a “contentLanguages” property in the meta tag. The main language used can be indicated through the “lang” property in the meta tag.</strong></p>
	 * @param jsonGenerator
	 * @param list
	 * @param fieldName
	 * @throws IOException
	 */
	private static void writeLocalisedBestMatchText(JsonGenerator jsonGenerator, List<TextTypeWrapper> list, String fieldName) throws IOException {
		TextTypeWrapper localisedBestMatch = TextTypeUtil.getDefaultLocale(list);
		if(localisedBestMatch != null) {
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, fieldName, localisedBestMatch.getValue());
		}
	}

	/**
	 * Only writes the value to the field if the value is not null
	 * @param jsonGenerator
	 * @param fieldName
	 * @param value
	 * @throws IOException
	 */
	public static void writeNonNullString(JsonGenerator jsonGenerator, String fieldName, String value) throws IOException {
		if (!ObjectUtil.validString(value)) {
			// Do nothing;
			return;
		}
		jsonGenerator.writeStringField(fieldName, value);
	}

	public static void writeRepresentation(JsonGenerator jsonGenerator, RepresentationBean representation, boolean isV2, String fieldName) throws IOException{
		if(representation == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart(fieldName);
		String textFormatNode = isV2 ? representation.getRepresentation() != null ? "enumerationFormat" : "format" : "textFormat";
		SdmxJsonStaticHelper.writeTexFormat(jsonGenerator, representation.getTextFormat(), textFormatNode, isV2);
		if(representation.getRepresentation() != null) {
			jsonGenerator.writeStringField("enumeration", representation.getRepresentation().getReference().getURN());
		}
		if(isV2 && representation.getMaintainableParent().getStructureType() != SDMX_STRUCTURE_TYPE.MSD) {
			if(representation.getMinOccurs() != null) {
				jsonGenerator.writeNumberField("minOccurs", representation.getMinOccurs());
			}
			if(representation.getMaxOccurs() != null) {
				jsonGenerator.writeNumberField("maxOccurs", representation.getMaxOccurs());
			}
		}
		jsonGenerator.writeEndObject();
	}

	public static void writeTexFormat(JsonGenerator jsonGenerator, TextFormatBean tf, String field, boolean isV2) throws JsonGenerationException, IOException {
		if(tf != null && (tf.getTextType()!=null || tf.hasRestrictions())) {
			if(!ObjectUtil.validString(field)) {
				field = "textFormat";
			}
			jsonGenerator.writeObjectFieldStart(field);
			if(tf.getDecimals() != null) {
				jsonGenerator.writeNumberField("decimals", tf.getDecimals().intValue());
			}
			if(tf.getEndTime() != null) {
				jsonGenerator.writeStringField("endTime", tf.getEndTime().getDateInSdmxFormat());
			}
			if(tf.getEndValue() != null) {
				jsonGenerator.writeNumberField("endValue", tf.getEndValue());
			}
			if(tf.getInterval() != null) {
				jsonGenerator.writeNumberField("interval", tf.getInterval());
			}
			if(tf.getMultiLingual() != null && tf.getMultiLingual().isSet()) {
				jsonGenerator.writeBooleanField("isMultiLingual", tf.getMultiLingual().isTrue());
			}
			if(tf.getSequence() != null && tf.getSequence().isSet()) {
				jsonGenerator.writeBooleanField("isSequence", tf.getSequence().isTrue());
			}
			if(tf.getMaxLength() != null) {
				jsonGenerator.writeNumberField("maxLength", tf.getMaxLength().intValue());
			}
			if(tf.getMaxValue() != null) {
				jsonGenerator.writeNumberField("maxValue", tf.getMaxValue());
			}
			if(tf.getMinLength() != null) {
				jsonGenerator.writeNumberField("minLength", tf.getMinLength().intValue());
			}
			if(tf.getMinValue() != null) {
				jsonGenerator.writeNumberField("minValue", tf.getMinValue());
			}
			if(tf.getPattern() != null) {
				jsonGenerator.writeStringField("pattern", tf.getPattern());
			}
			if(tf.getStartTime() != null) {
				jsonGenerator.writeStringField("startTime", tf.getStartTime().getDateInSdmxFormat());
			}
			if(tf.getStartValue() != null) {
				jsonGenerator.writeNumberField("startValue", tf.getStartValue());
			}
			if(tf.getTextType() != null) {
				if (isV2) {
					jsonGenerator.writeStringField("dataType", tf.getTextType().getSdmx21Value());
				} else {
					jsonGenerator.writeStringField("textType", tf.getTextType().getSdmx21Value());
				}
			}
			if(tf.getTimeInterval() != null) {
				jsonGenerator.writeStringField("timeInterval", tf.getTimeInterval());
			}
			jsonGenerator.writeEndObject();  // End Text Format
		}
	}

	public static class RegistryJsonOrganisationWriter{
		public static void writeStructure(JsonGenerator jsonGenerator, OrganisationBean identifiable) throws JsonGenerationException, IOException {
			if (!ObjectUtil.validCollection(identifiable.getContacts())) {
				return;
			}
			jsonGenerator.writeArrayFieldStart("contacts");
			for(ContactBean contact : identifiable.getContacts()) {
				writeContact(jsonGenerator, contact);
			}
			jsonGenerator.writeEndArray();
		}

		public static void writeContact(JsonGenerator jsonGenerator, ContactBean contact) throws JsonGenerationException, IOException {
			jsonGenerator.writeStartObject();

			if(contact.getId() != null) {
				jsonGenerator.writeStringField("id", contact.getId());
			}
			writeTextTypeWrapperArray(jsonGenerator, contact.getName(), "names");
			writeTextTypeWrapperArray(jsonGenerator, contact.getDepartments(), "departments");
			writeTextTypeWrapperArray(jsonGenerator, contact.getRole(), "roles");

			writeArray(jsonGenerator, contact.getTelephone(), "telephones");
			writeArray(jsonGenerator, contact.getFax(), "faxes");
			writeArray(jsonGenerator, contact.getX400(), "x400s");
			writeArray(jsonGenerator, contact.getUri(), "uris");
			writeArray(jsonGenerator, contact.getEmail(), "emails");

			jsonGenerator.writeEndObject();
		}

		private  static void writeArray(JsonGenerator jsonGenerator, List<String> array, String arrayName) throws JsonGenerationException, IOException {
			if (!ObjectUtil.validCollection(array)) {
				return;
			}
			jsonGenerator.writeArrayFieldStart(arrayName);
			for(String currentItem : array) {
				jsonGenerator.writeString(currentItem);
			}
			jsonGenerator.writeEndArray();
		}
	}
}
