package io.sdmx.format.json.engine.data.writer.sdmxjson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.format.json.engine.data.writer.fusionjson.AbstractJsonDataWriter.IJsonWriterMarker;
import io.sdmx.format.json.engine.data.writer.fusionjson.SeriesDataWriter;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonSeriesDataWriterV2 extends SeriesDataWriter implements IJsonWriterMarker {

	public SdmxJsonSeriesDataWriterV2(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(jsonGenerator, header, superBeanRetrievalManager);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... ann) {
		super.startDataset(structures, datasetHeader, datasetAttributes, ann);
	}

	@Override
	protected void writeJsonObs(Observation obs, int idx) {
		String seriesKey = "" + idx;
		try {
			jsonGenerator.writeArrayFieldStart(seriesKey);

			// write all observation values
			for (MeasureDimensionBean mdb : currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getMeasures()) {
				String id = mdb.getId();
				List<String> measureValues = obs.getMeasureValues(id);

				if (measureValues != null) {
					if (measureValues.size() == 1) {
						// write single-valued measure
						jsonGenerator.writeString(measureValues.get(0));

					} else if (measureValues.size() > 1) {
						// write multivalued measure
						jsonGenerator.writeArray(measureValues.toArray(new String[0]), 0, measureValues.size());
					}
				} else {
					jsonGenerator.writeNull();
				}
			}

			// Write the attribute values
			List<List<Integer>> attrIdx = new ArrayList<>();
			List<AttributeBean> dsdAttrs = currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getObservationAttributes(dimensionAtObservation);

			dsdAttrs.forEach(dsdAttr -> {
				KeyValue kv = obs.getAttribute(dsdAttr.getId());
				if (kv == null) {
					kv = obs.getSeriesKey().getAttribute(dsdAttr.getId());
				}

				if (kv == null) {
					attrIdx.add(null);
				} else {
					if (kv.hasMultipleValues()) {
						int obsAttrsIdx = attrIdx.size();
						attrIdx.add(new ArrayList<>());
						kv.getValues().forEach(v -> {
							int index = currentDatasetInfo.getReportedIndex(dsdAttr.getId(), v);
							attrIdx.get(obsAttrsIdx).add(index);
						});
					} else {
						int index = currentDatasetInfo.getReportedIndex(dsdAttr.getId(), kv.getCode());
						attrIdx.add(Collections.singletonList(index));
					}
				}
			});

			// Only write out the attributes, if they are not all null and there are no annotations following
			if (ObjectUtil.validCollection(attrIdx)) {
				if (!ObjectUtil.isAllNulls(attrIdx) || !obs.getAnnotations().isEmpty()) {
					for (List<Integer> attrIdxList : attrIdx) {
						if (attrIdxList == null) {
							jsonGenerator.writeNull();
						} else if (attrIdxList.size() == 1) {
							jsonGenerator.writeNumber(attrIdxList.get(0));
						} else {
							int[] attrIdxArr = attrIdxList.stream().mapToInt(i -> i).toArray();
							jsonGenerator.writeArray(attrIdxArr, 0, attrIdxList.size());
						}
					}
				}
			}

			for (AnnotationBean currentAnnotation : obs.getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int index = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(index);
			}
			jsonGenerator.writeEndArray();
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}

	@Override
	protected void writeStructure(boolean writeNode) throws JsonGenerationException, IOException {
		jsonGenerator.writeArrayFieldStart("structures");
		super.writeStructure(false);
		jsonGenerator.writeEndArray();
	}

	@Override
	public void writeLink(List<ILinkBean> links) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeLinks(links, this.jsonGenerator);
	}

	@Override
	public void writeTextType(List<TextTypeWrapper> ttw, String type) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeTextTypeWrapperArray(ttw, jsonGenerator, type);
	}

	@Override
	public boolean includePosition() {
		return false;
	}

	@Override
	protected boolean isSdmxJsonV2() {
		return true;
	}
}
