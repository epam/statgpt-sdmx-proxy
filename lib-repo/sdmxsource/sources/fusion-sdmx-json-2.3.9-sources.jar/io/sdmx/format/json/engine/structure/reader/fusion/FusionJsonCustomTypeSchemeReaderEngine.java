package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.CustomTypeMutableBean;
import io.sdmx.im.mutable.transformation.CustomTypeSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonCustomTypeSchemeReaderEngine extends FusionJsonAbstractVTLSchemeReaderEngine<ICustomTypeSchemeBean, ICustomTypeSchemeMutableBean, ICustomTypeMutableBean> implements IFusionSingleton {
	private static FusionJsonCustomTypeSchemeReaderEngine INSTANCE;

	public static FusionJsonCustomTypeSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCustomTypeSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ICustomTypeSchemeMutableBean getMutable() {
		return new CustomTypeSchemeMutableBean();
	}

	@Override
	protected ICustomTypeMutableBean readItemBean(JsonReader jReader) {
		ICustomTypeMutableBean item =  new CustomTypeMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(item, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("vtlScalarType")) {
				item.setVtlScalarType(value);
			} else if (fieldName.equals("dataType")) {
				item.setDataType(value);
			} else if (fieldName.equals("vtlLiteralFormat")) {
				item.setVtlLiteralFormat(value);
			} else if (fieldName.equals("outputFormat")) {
				item.setOutputFormat(value);
			} else if (fieldName.equals("nullValue")) {
				item.setNullValue(value);
			}
		}
		return item;
	}

    @Override
    protected Class<ICustomTypeSchemeBean> getMaintainableType() {
        return ICustomTypeSchemeBean.class;
    }
}
