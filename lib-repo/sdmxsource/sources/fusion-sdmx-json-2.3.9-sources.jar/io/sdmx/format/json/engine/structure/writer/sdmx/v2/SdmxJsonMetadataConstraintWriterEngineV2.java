package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonMetadataConstraintWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<IMetadataConstraintBean> implements IFusionSingleton {

	private static SdmxJsonMetadataConstraintWriterEngineV2 INSTANCE;

	public static SdmxJsonMetadataConstraintWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataConstraintWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonMetadataConstraintWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.METADATA_CONSTRAINT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator json, IExternalMaintainableLinks externalLinks, IMetadataConstraintBean bean) throws IOException {
		json.writeStringField("role", "Allowed");

		if (ObjectUtil.validCollection(bean.getAttachments())) {
			writeConstraintAttachments(bean.getAttachments(), json);
		}
		if (bean.getReleaseCalendar() != null) {
			writeReleaseCalendar(bean.getReleaseCalendar(), json);
		}
		if (ObjectUtil.validCollection(bean.getIncludedTarget()) || ObjectUtil.validCollection(bean.getExcludedTarget())) {
			writeMetadataTargetRegions(bean.getIncludedTarget(), bean.getExcludedTarget(), json);
		}
	}

	private void writeConstraintAttachments(List<IDirectCrossReferenceBean<?>> constraintAttachments, JsonGenerator json) throws IOException {
		json.writeObjectFieldStart("constraintAttachment");

		switch (constraintAttachments.get(0).getReference().getSdmxStructure()) {
			case METADATA_PROVIDER:
				json.writeArrayFieldStart("metadataProvider");
				break;
			case MSD:
				json.writeArrayFieldStart("metadataStructures");
				break;
			case METADATA_FLOW:
				json.writeArrayFieldStart("metadataflows");
				break;
			case METADATA_PROVISION:
				json.writeArrayFieldStart("metadataProvisionAgreements");
				break;
		}
		for (ICrossReferenceBean<?> attachment : constraintAttachments) {
			json.writeString(attachment.getTargetUrn());
		}
		json.writeEndArray();
		json.writeEndObject();
	}

	private void writeReleaseCalendar(ReleaseCalendarBean releaseCalendar, JsonGenerator json) throws IOException {
		json.writeObjectFieldStart("releaseCalendar");

		SdmxJsonStaticHelper.writeNonNullString(json, "offset", releaseCalendar.getOffset());
		SdmxJsonStaticHelper.writeNonNullString(json, "periodicity", releaseCalendar.getPeriodicity());
		SdmxJsonStaticHelper.writeNonNullString(json, "tolerance", releaseCalendar.getTolerance());

		json.writeEndObject();
	}

	private void writeMetadataTargetRegions(List<KeyValues> includedTarget, List<KeyValues> excludedTarget, JsonGenerator json) throws IOException {
		json.writeArrayFieldStart("metadataTargetRegions");

		if (ObjectUtil.validCollection(includedTarget)) {
			writeMetadataTargetRegion(includedTarget, true, json);
		}

		if (ObjectUtil.validCollection(excludedTarget)) {
			writeMetadataTargetRegion(excludedTarget, false, json);
		}
		json.writeEndArray();
	}

	private void writeMetadataTargetRegion(List<KeyValues> target, boolean isIncludedTarget, JsonGenerator json) throws IOException {
		json.writeStartObject();
		json.writeBooleanField("include", isIncludedTarget);
		json.writeArrayFieldStart("components");

		for (KeyValues component : target) {
			writeComponent(component, json);
		}
		json.writeEndArray();
		json.writeEndObject();
	}

	private void writeComponent(KeyValues component, JsonGenerator json) throws IOException {
		json.writeStartObject();

		json.writeStringField("id", component.getId());
		json.writeBooleanField("removePrefix", component.isRemovePrefix());

		if (component.getTimeRange() != null) {
			writeTimeRange(component.getTimeRange(), json);

		} else if (ObjectUtil.validCollection(component.getValues()) || ObjectUtil.validCollection(component.getCascadeValues())) {
			json.writeArrayFieldStart("values");

			if (ObjectUtil.validCollection(component.getValues())) {
				for (String value : component.getValues()) {
					writeValue(value, false, component.getValidityPeriod(value), json);
				}
			}
			if (ObjectUtil.validCollection(component.getCascadeValues())) {
				for (String cascadeValue : component.getCascadeValues()) {
					writeValue(cascadeValue, true, component.getValidityPeriod(cascadeValue), json);
				}
			}
			json.writeEndArray();
		}
		json.writeEndObject();
	}

	private void writeValue(String value, boolean isCascade, SdmxPeriod validity, JsonGenerator json) throws IOException {
		json.writeStartObject();

		json.writeStringField("value", value);
		if (isCascade) {
			json.writeBooleanField("cascadeValues", true);
		}
		if (validity.getStartPeriod() != null) {
			json.writeStringField("validFrom", validity.getStartPeriod().getDateInSdmxFormat());
		}
		if (validity.getEndPeriod() != null) {
			json.writeStringField("validTo", validity.getEndPeriod().getDateInSdmxFormat());
		}
		json.writeEndObject();
	}

	private void writeTimeRange(TimeRangeBean timeRange, JsonGenerator json) throws IOException {
		json.writeObjectFieldStart("timeRange");

		SdmxDate startDate = timeRange.getStartDate();
		SdmxDate endDate = timeRange.getEndDate();
		if (timeRange.isRange()) {
			json.writeObjectFieldStart("startPeriod");
			json.writeStringField("period", startDate.getDateInSdmxFormat());
			json.writeBooleanField("isInclusive", timeRange.isStartInclusive());
			json.writeEndObject();

			json.writeObjectFieldStart("endPeriod");
			json.writeStringField("period", endDate.getDateInSdmxFormat());
			json.writeBooleanField("isInclusive", timeRange.isEndInclusive());
			json.writeEndObject();
		} else {
			if (startDate == null) {
				json.writeObjectFieldStart("afterPeriod");
				json.writeStringField("period", endDate.getDateInSdmxFormat());
				json.writeBooleanField("isInclusive", timeRange.isEndInclusive());
				json.writeEndObject();
			} else {
				json.writeObjectFieldStart("beforePeriod");
				json.writeStringField("period", startDate.getDateInSdmxFormat());
				json.writeBooleanField("isInclusive", timeRange.isStartInclusive());
				json.writeEndObject();
			}
		}
		if (timeRange.getValidFrom() != null) {
			json.writeStringField("validFrom", timeRange.getValidFrom().getDateInSdmxFormat());
		}
		if (timeRange.getValidTo() != null) {
			json.writeStringField("validTo", timeRange.getValidTo().getDateInSdmxFormat());
		}
		json.writeEndObject();
	}
}
