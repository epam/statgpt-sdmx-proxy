package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonDataProviderSchemeReaderEngineV1 extends SdmxJsonOrganisationSchemeReaderEngineV1<DataProviderMutableBean, DataProviderSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonDataProviderSchemeReaderEngineV1 INSTANCE;

	public static SdmxJsonDataProviderSchemeReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataProviderSchemeReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	protected List<DataProviderMutableBean> readItems(JsonReader jReader) {
		List<DataProviderMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				DataProviderMutableBean aDP = new DataProviderMutableBeanImpl();
				populateOrganisationMutableBean(jReader, aDP);
				returnList.add(aDP);
			}
		}
		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "dataProviders";
	}

    @Override
    protected DataProviderSchemeMutableBean getMutable() {
        return new DataProviderSchemeMutableBeanImpl();
    }

    @Override
    public String getContainerElement() {
        return "dataProviderSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return DataProviderSchemeBean.class;
    }
}
