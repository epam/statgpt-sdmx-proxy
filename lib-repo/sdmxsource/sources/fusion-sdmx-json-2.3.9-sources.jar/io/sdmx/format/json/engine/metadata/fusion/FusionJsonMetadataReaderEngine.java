package io.sdmx.format.json.engine.metadata.fusion;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataReaderEngine;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonMetadataReaderEngine implements IMetadataReaderEngine {
	private static final FusionJsonMetadataReaderEngine INSTANCE = new FusionJsonMetadataReaderEngine();

	private FusionJsonMetadataReaderEngine() {}

	public static FusionJsonMetadataReaderEngine getInstance() {
		return INSTANCE;
	}
	
	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) {
		IReferenceMetadataContainer returnContainer = new ReferenceMetadataContainer();
		//TODO HEADER
		try(JsonReader jReader = new JsonReader(rdl)){
			while(jReader.moveNext()) {
				if(jReader.isStartArray() && jReader.getCurrentFieldName().equals(FusionJsonMetadataSyntaxConstants.METADATASETS)) {
					parseMetadataSets(jReader, returnContainer);
				}
			}
		}
		return returnContainer;
	}

	private static void parseMetadataSets(JsonReader jReader, IReferenceMetadataContainer returnContainer) {
		if(jReader.isStartArray()) {
			FusionJsonMetadataSetReaderEngine.getInstance().read(jReader, null, (mutable, beans) -> returnContainer.addReferenceMetadata((IReportedMetadataSetBean)mutable.getImmutableInstance()) , null);
		}
	}
}
