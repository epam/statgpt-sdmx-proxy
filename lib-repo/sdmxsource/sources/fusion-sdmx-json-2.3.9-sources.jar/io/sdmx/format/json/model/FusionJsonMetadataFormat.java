package io.sdmx.format.json.model;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;

/**
 *
 */
public class FusionJsonMetadataFormat implements IMetadataFormat, IFusionSingleton {
	private static final long serialVersionUID = -1461535945154796477L;
	private static FusionJsonMetadataFormat INSTANCE;
	private static final String asString = "FusionJson";
	private FusionJsonMetadataFormat() {}

	public static FusionJsonMetadataFormat getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FusionJsonMetadataFormat();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
	
	private FormatDetails formatDetails = new FormatDetailsImpl("Fusion-JSON", MIME_TYPE.APPLICATION_JSON, true, true, "application/vnd.fusion.json");
	

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	@Override
	public void destroyInstance() {
		 INSTANCE = null;
	}


	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj == this;
	}

	@Override
	public String toString() {
		return asString;
	}
}
