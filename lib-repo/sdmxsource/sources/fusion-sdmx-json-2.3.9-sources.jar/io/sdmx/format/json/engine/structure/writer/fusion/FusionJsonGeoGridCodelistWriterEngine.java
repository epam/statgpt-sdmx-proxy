package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.writer.fusion.util.FusionJsonCodelistWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Codelist output as following JSON:
 *
 * {
    "type" : "Codelist",
    "id" : "CL_FREQ",
    "urn" : "urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS_IMF:CL_FREQ(1.0)",
    "name" : "Code list for Frequency (FREQ)",
    "agency" : "BIS and IMF (joint exercise)",
    "uri" : "http://localhost:8080/FusionRegistry/ws/registry/ws/registry/view/codelist/BIS_IMF/CL_FREQ/1.0",
    "agencyUrl" : "http://localhost:8080/FusionRegistry/ws/registry/ws/registry/view/agencyscheme/SDMX/AGENCIES/1.0",
    "resourceUrl" : "http://localhost:8080/FusionRegistry/ws/registry/ws/rest/codelist/BIS_IMF/CL_FREQ/1.0",
    "agencyId" : "BIS_IMF",
    "version" : "1.0",
    "ispartial" : false,
    "items" : [{
        "type" : "Code",
        "id" : "A",
        "urn" : "urn:sdmx:org.sdmx.infomodel.codelist.Code=BIS_IMF:CL_FREQ(1.0).A",
        "name" : "Annual",
        "parentCode" : null
      },
      ...
      ]
   }
 *
 */
public class FusionJsonGeoGridCodelistWriterEngine extends FusionJsonItemSchemeWriterEngine<IGeoGridCodelistBean> implements IFusionSingleton {
	private static FusionJsonGeoGridCodelistWriterEngine INSTANCE;

	public static FusionJsonGeoGridCodelistWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonGeoGridCodelistWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonGeoGridCodelistWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IGeoGridCodelistBean cl) throws JsonGenerationException, IOException {
		FusionJsonCodelistWriterUtil.writeInheritence(jsonGenerator, cl);
		jsonGenerator.writeStringField("gridDefinition", cl.getGridDefinition());
		super.writeStructureInternal(jsonGenerator, externalLinks, cl);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException  {
		IGeoGridCodeBean code = (IGeoGridCodeBean)item;
		if(code.getParentCode() != null) {
			jsonGenerator.writeStringField("parentCode", code.getParentCode());
		}
		if(code.isInherited()) {
			jsonGenerator.writeBooleanField("isInherited", code.isInherited());
		}
		if(code.getGeoCell() != null) {
			jsonGenerator.writeStringField("geoCell", code.getGeoCell());
		}
	}
}
