package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonIdentifiableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonRepresentationUtil;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonHierarchicalCodelistReaderEngineV2 extends AbstractSdmxJsonReaderEngine<HierarchyMutableBean> implements IFusionSingleton {

    private static SdmxJsonHierarchicalCodelistReaderEngineV2 INSTANCE;

    public static SdmxJsonHierarchicalCodelistReaderEngineV2 getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SdmxJsonHierarchicalCodelistReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "hierarchies";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return HierarchyBean.class;
    }

    @Override
    protected HierarchyMutableBean getMutable() {
        return new HierarchyMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, HierarchyMutableBean mutable, JsonReader reader) {
        switch (fieldName) {
        case "hasFormalLevels":
            boolean levelled = reader.getValueAsBoolean();
            mutable.setFormalLevels(levelled);
            return true;
        case "hierarchicalCodes":
            List<CodeRefMutableBean> hRefBeans = readHrefBeans(reader);
            mutable.setHierarchicalCodeBeans(hRefBeans);
            return true;
        case "level":
            LevelMutableBean level = readLevel(reader);
            mutable.setChildLevel(level);
            return true;
        }
        return false;
    }

    private List<CodeRefMutableBean> readHrefBeans(JsonReader jReader) {
        List<CodeRefMutableBean> retList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            CodeRefMutableBean hRefBean = new CodeRefMutableBeanImpl();
            while (jReader.moveNext()) {
                if (jReader.isEndObject()) {
                    break;
                }
                String value = jReader.getValueAsString();
                if (SdmxJsonIdentifiableUtil.processBean(hRefBean, jReader)) {
                    continue;
                }
                String fieldName = jReader.getCurrentFieldName();
                switch (fieldName) {
                case "validFrom":
                    hRefBean.setStartDate(DateUtil.formatDate(value, true));
                    break;
                case "validTo":
                    hRefBean.setEndDate(DateUtil.formatDate(value, true));
                    break;
                case "code":
                    hRefBean.setCodeReference(new StructureReferenceBeanImpl(value));
                    break;
                case "hierarchicalCodes":
                    hRefBean.setCodeRefs(readHrefBeans(jReader));
                    break;
                case "level":
                    StructureReferenceBean levelRef = StructureReferenceBeanImpl.buildAndVerify(value, SDMX_STRUCTURE_TYPE.LEVEL);
                    String fullLevelIdWithHierarchy = levelRef.getFullId();
                    hRefBean.setLevelReference(fullLevelIdWithHierarchy.substring(fullLevelIdWithHierarchy.indexOf(".") + 1));
                    break;
                }
            }
            retList.add(hRefBean);
        }
        return retList;
    }

    private LevelMutableBean readLevel(JsonReader jReader) {
        LevelMutableBean ret = new LevelMutableBeanImpl();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            if (SdmxJsonNameableUtil.processBean(ret, jReader)) {
                continue;
            }
            String fieldName = jReader.getCurrentFieldName();
            switch (fieldName) {
            case "codingFormat":
                TextFormatMutableBean readTextFormat = SdmxJsonRepresentationUtil.readTextFormat(jReader, true);
                ret.setCodingFormat(readTextFormat);
                break;
            case "level":
                LevelMutableBean readLevel = readLevel(jReader);
                ret.setChildLevel(readLevel);
                break;
            }
        }
        return ret;
    }

}
