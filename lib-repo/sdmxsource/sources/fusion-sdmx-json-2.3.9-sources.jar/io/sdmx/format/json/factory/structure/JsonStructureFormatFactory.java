package io.sdmx.format.json.factory.structure;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.structure.StructureFormatFactory;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.model.FusionJsonStructureFormat;
import io.sdmx.format.json.model.SdmxJsonStructureFormat;
import io.sdmx.format.json.util.SdmxJsonUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class JsonStructureFormatFactory implements StructureFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();
	
	private static JsonStructureFormatFactory INSTANCE;

	public JsonStructureFormatFactory() {
		if(SdmxJsonUtil.LEGACY_MODE) {
			supportedFormats.put("application/vnd.fusion.json", FusionJsonStructureFormat.getInstance().getFormatDetails());
			supportedFormats.put("application/vnd.sdmx.structure+json;version=1.0.0",   FusionJsonStructureFormat.getInstance().getFormatDetails());
		}else {
			supportedFormats.put("application/vnd.sdmx.structure+json;version=1.0.0",   SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V1).getFormatDetails());
			supportedFormats.put("application/vnd.fusion.json", FusionJsonStructureFormat.getInstance().getFormatDetails());
		}
		supportedFormats.put("application/vnd.sdmx.structure+json;version=2.0.0",   SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V2).getFormatDetails());

	}

	//Private constructor - lazy load instance
	public static JsonStructureFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new JsonStructureFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static JsonStructureFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Class<StructureFormat> getFormatClass() {
		return StructureFormat.class;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public StructureFormat getFormat(String format, Request request) {
		String version = request.getParameter("version");
		if(format == null && request.getReadableDataLocation() != null) {
			if(JsonReader.isValidJson(request.getReadableDataLocation())) {
				if(SdmxJsonUtil.LEGACY_MODE) {
					return FusionJsonStructureFormat.getInstance();
				}else {
					return SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V1);
				}
			}
		}
		if(format != null) {
			if(SdmxJsonUtil.LEGACY_MODE && (format.equals("sdmx-json") || format.equals("fusion-json")) ) {
				return FusionJsonStructureFormat.getInstance();
			}
			if(format.equals("sdmx-json")) {
				if (version == null) {
					version = "1.0.0";
				}
				if(version.equals("1.0.0")) {
					return SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V1);
				} else if(version.equals("2.0.0")) {
					return SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V2);
				} else {
					throw new SdmxNotAcceptableException("Unsupported sdmx-json version: " +version + ". Supported versions are 1.0.0, 2.0.0");
				}
			}
			if(format.equals("fusion-json")) {
				return FusionJsonStructureFormat.getInstance();
			}

		}
		return null;
	}

	@Override
	public StructureFormat getFormat(Request request, IVNDHeader vndHeader) {
		String vnd = vndHeader.getVnd();
		boolean sdmxJson = vnd.startsWith("sdmx.structure+json");
		boolean fusionJson = vnd.startsWith("fusion.json");
		if(!sdmxJson && !fusionJson) {
			return null;
		}
		if (SdmxJsonUtil.LEGACY_MODE) {
			return FusionJsonStructureFormat.getInstance();
		}
		if (fusionJson) {
			return FusionJsonStructureFormat.getInstance();
		}
		// If a version is specified is must be 1.0.0
		String version = vndHeader.getParameterValue("version");
		if (version == null) {
			version = "1.0.0";
		}
		if(version.equals("1.0.0")) {
			return SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V1);
		} else if(version.equals("2.0.0")) {
			return SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V2);
		} else {
			throw new SdmxNotAcceptableException("Unsupported sdmx-json version: " +version + ". Supported versions are 1.0.0, 2.0.0");
		}
	}

}