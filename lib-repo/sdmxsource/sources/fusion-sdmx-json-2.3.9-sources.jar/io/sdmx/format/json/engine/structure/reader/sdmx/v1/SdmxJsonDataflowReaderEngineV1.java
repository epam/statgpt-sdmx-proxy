package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonDataflowReaderEngineV1 extends AbstractSdmxJsonReaderEngine<DataflowMutableBean> implements IFusionSingleton {
	private static SdmxJsonDataflowReaderEngineV1 INSTANCE;

	public static SdmxJsonDataflowReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataflowReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    protected DataflowMutableBean getMutable() {
        return new DataflowMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, DataflowMutableBean mutable, JsonReader reader) {
        if(fieldName.equals("structure")) {
            String value = reader.getValueAsString();
            mutable.setDataStructureRef(new StructureReferenceBeanImpl(value));
        }
        return false;
    }

    @Override
    public String getContainerElement() {
        return "dataflows";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return DataflowBean.class;
    }
}
