package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonComponentUtil;
import io.sdmx.im.mutable.datastructure.AttributeListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonDataStructureReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<DataStructureBean, DataStructureMutableBean> implements IFusionSingleton {
	private static FusionJsonDataStructureReaderEngine INSTANCE;

	public static FusionJsonDataStructureReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataStructureReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected DataStructureMutableBean getMutable() {
		return new DataStructureMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, DataStructureMutableBean mutable, JsonReader jReader) {
		  if (fieldName.equals("measures")) {
			MeasureListMutableBean measures = readMeasureList(jReader);
			MeasureListMutableBean persisted = mutable.getMeasureList();
			if(persisted != null && hasPrimaryMeasure(mutable)) {
				//This can only be here if there was a primary measure added
				for(MeasureMutableBean measure : measures.getMeasures()) {
					if(measure.getId() != null && measure.getId().equals(PrimaryMeasureBean.FIXED_ID)) {
						continue;
					}
					persisted.addMeasures(measure);
				}
			} else {
				mutable.setMeasureList(measures);
			}

		} else if (fieldName.equals("dimensionList")) {
			DimensionListMutableBean dimensions = readDimensionList(jReader);
			mutable.setDimensionList(dimensions);
		} else if(fieldName.equals("attributeList")){
			AttributeListMutableBean attributes = readAttributeList(jReader);
			mutable.setAttributeList(attributes);
		} else if (fieldName.equals("groups")) {
			List<GroupMutableBean> groups = readGroups(jReader);
			for (GroupMutableBean aGroup : groups) {
				mutable.addGroup(aGroup);
			}
		} else if (fieldName.equals("msd")) {
			mutable.setMSDReference(new StructureReferenceBeanImpl(jReader.getValueAsString()));
		} else if (fieldName.equals("primaryMeasure")) {
			MeasureMutableBean primaryMeasure = readPrimaryMeasure(jReader);
			if(!hasPrimaryMeasure(mutable)) {
				mutable.setPrimaryMeasure(primaryMeasure);
			}
		} else {
			return false;
		}
		return true;
	}

	/**
	 * @param dsd
	 * @return true if the DSD already has a measure with Id OBS_VALUE
	 */
	private boolean hasPrimaryMeasure(DataStructureMutableBean dsd) {
		if(dsd.getMeasureList() != null) {
			for(MeasureMutableBean meas : dsd.getMeasureList().getMeasures()) {
				if(meas.getId().equals(PrimaryMeasureBean.FIXED_ID)) {
					return true;
				}
			}
		}
		return false;
	}

	private List<GroupMutableBean> readGroups(JsonReader jReader) {
		List<GroupMutableBean> returnList = new ArrayList<>();

		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			GroupMutableBean groupMutableBean = readGroup(jReader);
			returnList.add(groupMutableBean);
		}
		return returnList;
	}

	private GroupMutableBean readGroup(JsonReader jReader) {
		GroupMutableBean groupMutableBean = new GroupMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("id")) {
				groupMutableBean.setId(value);
			} else if (fieldName.equals("dimensionReferences")) {
				List<String> dimensionRef = new ArrayList<>();
				while (jReader.moveNext()) {
					if (jReader.isEndArray()) {
						break;
					}
					dimensionRef.add(jReader.getValueAsString());
				}
				groupMutableBean.setDimensionRef(dimensionRef);
			}
		}
		return groupMutableBean;
	}

	private AttributeListMutableBean readAttributeList(JsonReader jReader) {
		AttributeListMutableBean returnList =  new AttributeListMutableBeanImpl();
		while (jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}

			if(jReader.getCurrentFieldName().equals("attributes")) {
				List<AttributeMutableBean> attributes = readAttributes(jReader);
				for (AttributeMutableBean attributeMutableBean : attributes) {
					returnList.addAttribute(attributeMutableBean);
				}
			}
		}
		return returnList;

	}
	private List<AttributeMutableBean> readAttributes(JsonReader jReader) {
		List<AttributeMutableBean> returnList = new ArrayList<>();

		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			AttributeMutableBean attrMutableBean = readAttribute(jReader);
			returnList.add(attrMutableBean);
		}
		return returnList;
	}

	private AttributeMutableBean readAttribute(JsonReader jReader) {
		AttributeMutableBean attrMutableBean = new AttributeMutableBeanImpl();
		attrMutableBean.setMandatory(false);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonComponentUtil.processBean(attrMutableBean, jReader)) {
				continue;
			}

			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("dimensionReferences")) {
				attrMutableBean.setDimensionReferences(jReader.readStringArray());
			} else if (fieldName.equals("measureReferences")) {
				attrMutableBean.setMeasureReferences(jReader.readStringArray());
			} else {
				String value = jReader.getValueAsString();
				if (fieldName.equals("mandatory")) {
					if (value.equalsIgnoreCase("true")) {
						attrMutableBean.setMandatory(true);
					}
				} else if (fieldName.equals("attachmentLevel")) {
					ATTRIBUTE_ATTACHMENT_LEVEL level;
					if (value.equals("DATA_SET")) {
						level = ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET;
					} else if (value.equals("GROUP")) {
						level = ATTRIBUTE_ATTACHMENT_LEVEL.GROUP;
					} else if (value.equals("DIMENSION_GROUP")) {
						level = ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP;
					} else if (value.equals("OBSERVATION")) {
						level = ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION;
					} else {
						throw new RuntimeException("Unknown value for attachmentLevel of: '" + value + "'");
					}
					attrMutableBean.setAttachmentLevel(level);
				} else if(fieldName.equals("attachmentGroup")) {
					attrMutableBean.setAttachmentGroup(value);
				} 
			}
		}
		return attrMutableBean;
	}

	private MeasureMutableBean readPrimaryMeasure(JsonReader jReader) {
		MeasureMutableBean primaryMeasure = new PrimaryMeasureMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonComponentUtil.processBean(primaryMeasure, jReader)) {
				continue;
			}
		}
		return primaryMeasure;
	}


	private MeasureListMutableBean readMeasureList(JsonReader jReader) {
		MeasureListMutableBean returnList = new MeasureListMutableBeanImpl();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				MeasureMutableBean aDim = readMeasureBean(jReader);
				returnList.addMeasures(aDim);
			}
		}
		return returnList;
	}

	private DimensionListMutableBean readDimensionList(JsonReader jReader) {
		DimensionListMutableBean returnList = new DimensionListMutableBeanImpl();
		while (jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			if(jReader.getCurrentFieldName().equals("dimensions")) {
				List<DimensionMutableBean> dimensions = readDimensions(jReader);
				for (DimensionMutableBean dimensionMutableBean : dimensions) {
					returnList.addDimension(dimensionMutableBean);
				}
			}
		}
		return returnList;
	}

	private List<DimensionMutableBean> readDimensions(JsonReader jReader) {
		List<DimensionMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				DimensionMutableBean aDim = readDimensionBean(jReader);
				returnList.add(aDim);
			}
		}
		return returnList;
	}

	private DimensionMutableBean readDimensionBean(JsonReader jReader) {
		DimensionMutableBean aDim = new DimensionMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonComponentUtil.processBean(aDim, jReader)) {
				continue;
			}

			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("isTimeDimension")) {
				try {
					aDim.setTimeDimension(jReader.getValueAsBoolean());
				} catch (Exception e) {
					throw new RuntimeException("Unexpected value for field 'isTimeDimension'. This is a boolean field. Supplied value was: '" + jReader.getValueAsString() + "'");
				}
			} else if (fieldName.equals("isMeasureDimension")) {
				try {
					aDim.setMeasureDimension(jReader.getValueAsBoolean());
				} catch (Exception e) {
					throw new RuntimeException("Unexpected value for field 'isTimeDimension'. This is a boolean field. Supplied value was: '" + jReader.getValueAsString() + "'");
				}
			}
		}
		return aDim;
	}

	private MeasureMutableBean readMeasureBean(JsonReader jReader) {
		MeasureMutableBean aDim = new MeasureMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonComponentUtil.processBean(aDim, jReader)) {
				continue;
			}
		}
		return aDim;
	}

    @Override
    protected Class<DataStructureBean> getMaintainableType() {
        return DataStructureBean.class;
    }
}