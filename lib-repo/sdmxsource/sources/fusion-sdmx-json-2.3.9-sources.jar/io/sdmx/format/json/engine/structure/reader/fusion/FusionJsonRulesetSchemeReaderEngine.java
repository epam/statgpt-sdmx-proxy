package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.RulesetMutableBean;
import io.sdmx.im.mutable.transformation.RulesetSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonRulesetSchemeReaderEngine extends FusionJsonAbstractVTLSchemeReaderEngine<IRulesetSchemeBean, IRulesetSchemeMutableBean, IRulesetMutableBean> implements IFusionSingleton {
	private static FusionJsonRulesetSchemeReaderEngine INSTANCE;

	public static FusionJsonRulesetSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRulesetSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IRulesetSchemeMutableBean getMutable() {
		return new RulesetSchemeMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IRulesetSchemeMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			if(fieldName.equals("vtlMappingScheme")) {
				mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				return true;
			}
		}
		return false;
	}

	@Override
	protected IRulesetMutableBean readItemBean(JsonReader jReader) {
		IRulesetMutableBean item =  new RulesetMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(item, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("rulesetType")) {
				item.setRulesetType(value);
			} else if (fieldName.equals("rulesetScope")) {
				item.setRulesetScope(value);
			} else if (fieldName.equals("rulesetDefinition")) {
				item.setRulesetDefinition(value);
			}
		}
		return item;
	}

    @Override
    protected Class<IRulesetSchemeBean> getMaintainableType() {
        return IRulesetSchemeBean.class;
    }
}
