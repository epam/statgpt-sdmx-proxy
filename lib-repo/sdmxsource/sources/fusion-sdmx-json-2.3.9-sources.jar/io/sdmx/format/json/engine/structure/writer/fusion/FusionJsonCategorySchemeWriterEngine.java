package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonCategorySchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<CategorySchemeBean> implements IFusionSingleton {
	private static FusionJsonCategorySchemeWriterEngine INSTANCE;

	public static FusionJsonCategorySchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCategorySchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonCategorySchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  ItemBean item) throws JsonGenerationException, IOException  {
		HierarchicalItemBean<CategoryBean> hItem = (HierarchicalItemBean<CategoryBean>)item;
		writeItems(jsonGenerator,  externalLinks, hItem.getItems());
	}


	@Override
	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  List<? extends ItemBean> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}

		jsonGenerator.writeArrayFieldStart("items");
		for(ItemBean currentItem : items) {
			writeItem(jsonGenerator, externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}
}