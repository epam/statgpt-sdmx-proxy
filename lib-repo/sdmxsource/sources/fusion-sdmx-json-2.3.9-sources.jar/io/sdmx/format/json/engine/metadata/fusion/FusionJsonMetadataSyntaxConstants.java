package io.sdmx.format.json.engine.metadata.fusion;

public class FusionJsonMetadataSyntaxConstants {
	public static final String METADATASETS = "metadatasets";
	public static final String METADATAFLOW = "metadataflow";
	public static final String METADATAPROVISION = "metadataprovision";
	public static final String TARGETS = "targets";
	public static final String ATTRIBUTES = "attributes";
	public static final String SIMPLE_VALUE = "value";
	public static final String COMPLEX_VALUE = "values";
}
