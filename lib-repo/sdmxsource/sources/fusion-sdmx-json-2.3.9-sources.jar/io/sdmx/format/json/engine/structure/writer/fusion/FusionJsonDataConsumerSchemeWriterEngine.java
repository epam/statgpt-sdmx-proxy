package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonDataConsumerSchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<DataConsumerSchemeBean> implements IFusionSingleton {
	private FusionJsonOrganisationWriterEngine jsonOrganisationStructureWriterEngine = FusionJsonOrganisationWriterEngine.getInstance();

	private static FusionJsonDataConsumerSchemeWriterEngine INSTANCE;

	public static FusionJsonDataConsumerSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataConsumerSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonDataConsumerSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator,IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException {
		jsonOrganisationStructureWriterEngine.writeStructure(jsonGenerator, (OrganisationBean) item);
	}

}
