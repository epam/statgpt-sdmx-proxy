package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingCategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.mapping.v3.ReportingCategoryMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ReportingTaxonomyMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonReportingTaxonomyMapReaderEngineV2 extends SdmxJsonItemSchemeMapReaderEngineV2<IReportingCategoryMapMutableBean, IReportingTaxonomyMapMutableBean> implements IFusionSingleton {
	private static SdmxJsonReportingTaxonomyMapReaderEngineV2 INSTANCE;

	public static SdmxJsonReportingTaxonomyMapReaderEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonReportingTaxonomyMapReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
    public String getContainerElement() {
        return "reportingTaxonomyMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IReportingTaxonomyMapBean.class;
    }

    @Override
    protected IReportingTaxonomyMapMutableBean getMutable() {
        return new ReportingTaxonomyMapMutableBean();
    }
    
	@Override
	protected IReportingCategoryMapMutableBean getItemMapMutable() {
		return new ReportingCategoryMapMutableBean();
	}
}
