package io.sdmx.format.json.engine.data.writer.sdmxjson;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.format.json.engine.data.writer.fusionjson.AbstractJsonDataWriter.IJsonWriterMarker;
import io.sdmx.format.json.engine.data.writer.fusionjson.FlatDataWriter;

public class SdmxJsonFlatDataWriter extends FlatDataWriter implements IJsonWriterMarker{
	private IDatasetStructures structures;
	
	public SdmxJsonFlatDataWriter(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(jsonGenerator, header, superBeanRetrievalManager);
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... ann) {
		super.startDataset(structures, datasetHeader, datasetAttributes, ann);
		this.structures = structures;
	}

	@Override
	protected void writeStructure(boolean writeNode) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart("structure");
		writeLink(SdmxJsonWriterUtils.getLinks(structures));
		super.writeStructure(false);
		jsonGenerator.writeEndObject();
	}

	@Override
	public void writeLink(List<ILinkBean> links) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeLinks(links, this.jsonGenerator);
	}

	@Override
	public void writeTextType(List<TextTypeWrapper> ttw, String type) throws JsonGenerationException, IOException {
		SdmxJsonWriterUtils.writeTextTypeWrapperArray(ttw, jsonGenerator, type);
	}

	@Override
    public boolean includePosition() {
        return false;
    }
}
