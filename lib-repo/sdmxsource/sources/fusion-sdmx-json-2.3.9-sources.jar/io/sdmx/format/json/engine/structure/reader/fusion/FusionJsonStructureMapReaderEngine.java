package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.Map;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimeComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonStructureMapReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<IStructureMapBean, IStructureMapMutableBean> implements IFusionSingleton {
	private static FusionJsonStructureMapReaderEngine INSTANCE;

	public static FusionJsonStructureMapReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureMapReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IStructureMapMutableBean getMutable() {
		return new StructureMapMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IStructureMapMutableBean mutable, JsonReader jReader) {
		switch(fieldName) {
		case "source" :
			mutable.setSourceRef(getRef(jReader));
			break;
		case "target" :
			mutable.setTargetRef(getRef(jReader));
			break;
		case "timeFormatRef" :
			mutable.setTimeFormatMapping(getRef(jReader));
			break;
		case "fixedOutput" :
			mutable.setFixedOutputs(jReader.readStringMap());
			break;
		case "fixedInput" :
			mutable.setFixedInputs(jReader.readStringMap());
			break;
		case "componentMaps" :
			readComponentMaps(jReader, mutable);
			break;
		case "timePatternMaps" :
			readTimePatternMaps(jReader, mutable);
			break;
		case "epochMaps" :
			readEpochMaps(jReader, mutable);
			break;
		default : return false;
		}
		return true;
	}

	private void readComponentMaps(JsonReader jReader, IStructureMapMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			} else if(jReader.isStartObject()) {
				readComponentMap(jReader, mutable.addComponentMap());
			}
		}
	}

	private void readTimePatternMaps(JsonReader jReader, IStructureMapMutableBean mutable)   {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			} else if(jReader.isStartObject()) {
				readTimePatternMap(jReader, mutable);
			}
		}
	}

	private void readEpochMaps(JsonReader jReader, IStructureMapMutableBean mutable)   {
		while(jReader.moveNext()) {
			if(jReader.isEndArray()) {
				return;
			} else if(jReader.isStartObject()) {
				readEpochMap(jReader, mutable.addEpochMap());
			}
		}
	}

	private StructureReferenceBean getRef(JsonReader jReader) {
		String ref = jReader.getValueAsString();
		if(ref != null) {
			return new StructureReferenceBeanImpl(ref);
		}
		return null;
	}

	private void readComponentMap(JsonReader jReader, IComponentMapMutableBean mutable) {
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			} else if(FusionJsonAnnotableUtil.processBean(mutable, jReader)) {
				continue;
			} else {
				String fieldName = jReader.getCurrentFieldName();
				switch(fieldName) {
				case "representationMapRef" :
					mutable.setRepresentationMapRef(getRef(jReader));
					break;
				case "sources" :
					mutable.setSourceComponents(jReader.readStringArray());
					break;
				case "targets" :
					mutable.setTargetComponents(jReader.readStringArray());
					break;
				}
			}
		}
	}

	private void readTimePatternMap(JsonReader jReader, IStructureMapMutableBean map) {
		ITimePatternMapMutableBean mutable = map.addTimePatternMap();
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			} else if(readTimeComponentMap(jReader, mutable)) {
				continue;
			}  else if(jReader.isStartObject() && jReader.getCurrentFieldName().equals("patterns")) {
				//V11 Beta
				Map<String, String> patterns = jReader.readStringMap();
				for(String pattern : patterns.keySet()) {
					mutable.setPattern(pattern);
					String outputFreq = patterns.get(pattern);
					if(outputFreq != null) {
						mutable.setOutputFrequencyId(outputFreq);
					}
				}
			} else if(jReader.getCurrentFieldName().equals("pattern")) {
				mutable.setPattern(jReader.getValueAsString());
			} else if(jReader.getCurrentFieldName().equals("locale")) {
				mutable.setLocale(jReader.getValueAsString());
			}
		}
	}


	private void readEpochMap(JsonReader jReader, IEpochMapMutableBean mutable)  {
		while(jReader.moveNext()) {
			if(jReader.isEndObject()) {
				return;
			} else if(readTimeComponentMap(jReader, mutable)) {
				continue;
			}  else {
				String fieldName = jReader.getCurrentFieldName();
				switch(fieldName) {
				case "basePeriod" :
					mutable.setBasePeriod(jReader.getValueAsString());
					break;
				case "epoch" :
					mutable.setEpochInterval(EPOCH.fromString(jReader.getValueAsString()));
					break;
				}
			}
		}
	}

	private boolean readTimeComponentMap(JsonReader jReader, ITimeComponentMapMutableBean mutable)  {
		if(FusionJsonAnnotableUtil.processBean(mutable, jReader)) {
			return true;
		}
		String fieldName = jReader.getCurrentFieldName();
		switch(fieldName) {
		case "source" :
			mutable.setSourceComponent(jReader.getValueAsString());
			return true;
		case "target" :
			mutable.setTargetComponent(jReader.getValueAsString());
			return true;
		case "freqDim" :
			mutable.setOutputFrequencyDimId(jReader.getValueAsString());
			return true;
		case "freqId" :
			mutable.setOutputFrequencyId(jReader.getValueAsString());
			return true;
		case "periodResolution" :
			mutable.setPeriodResolution(PERIOD_POSITION.fromString(jReader.getValueAsString()));
			return true;
		}
		return false;
	}

    @Override
    protected Class<IStructureMapBean> getMaintainableType() {
        return IStructureMapBean.class;
    }

}
