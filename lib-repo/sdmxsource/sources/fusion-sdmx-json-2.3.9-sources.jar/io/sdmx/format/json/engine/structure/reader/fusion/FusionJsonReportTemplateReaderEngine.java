package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonToken;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.CONDITION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionSheetMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionTextMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateColourMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateConditionalAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.im.mutable.base.ConditionalAttributeMappingBeanMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportTemplateInstructionSheetMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportTemplateInstructionTextMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateColourMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateConditionalAttributeMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateWorksheetMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class FusionJsonReportTemplateReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<ReportingTemplateBean, ReportingTemplateMutableBean> implements IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(FusionJsonReportTemplateReaderEngine.class);
	private static FusionJsonReportTemplateReaderEngine INSTANCE;

	public static FusionJsonReportTemplateReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonReportTemplateReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ReportingTemplateMutableBean getMutable() {
		return new ReportingTemplateMutableBeanImpl();
	}

	/**
	 * Built from JSON Object (report)
	 * <pre>
	 *  {
	 *     agencyId   : "acyId",
	 *     id   :    "id",
	 *     name   : {
	 *     		"en" : "name english",
	 *     		"fr" : "name french"
	 *     },
	 *     version : "1.0",
	 *     validFrom : "2001-07-18",
	 *     validTo : "2009-07-18",
	 *     instructionsheet : {
	 *     		title : ""
	 *     		name : "",
	 *          instructions : [ {
	 *             "content" : "the user instructions",
	 *             "border" : "none|thin|medium",
	 *             "width"    : 6,
	 *             "height"   : 12 }
	 *          ]
	 *     }
	 *     worksheets : [
	 *       {
	 *          constraint : "urn",
	 *          id : "id",
	 *          tableRows : ["Dim1", "Dim2"],
	 *          tableCols : ["Dim3", "Dim4"],
	 *          fixedAttributes : {
	 *          	OBS_STATUS : A,
	 *              UNIT_MULT : M
	 *          },
	 *          worksheetAttributes : ["FISH"],
	 *          variableAttributes : ["PRE_BREAK"],
	 *          colourAttribute : {
	 *          	id : "OBS_CONF",
	 *              defaultColour : "#C2C2C2",
	 *              colourCodes : {
	 *     				"A" : "#C2C2C2",
	 *     				"M" : "#E2E2E2",
	 *   			},
	 *              seriesColors [
	 *              	{
	 *              	 colour : "#D2D2D2",
	 *              	 series : ["A:UK:POP","A:FR:POP"]
	 *              	},....
	 *              ]
	 *          },
	 *          conditionalAttributes : {
	 *            OBS_STATUS : {
	 *              A : {
	 *     	       	  rule : dv
	 *              },
	 *              M : {
	 *     	       	  rule : mv
	 *              }
	 *              E : {
	 *     	     	  rule : ov,
	 *                details: gt.100
	 *              }
	 *            }
	 *          }
	 *          explicitHierarchy : {
	 *          	REF_AREA : "urn"
	 *          },
	 *          implicityHierarchy : ["INDICATOR", "BASKET"],
	 *          displayId : ["INDICATOR", "BASKET"],
	 *   		round : 3
	 *       }
	 *     ]
	 *  }
	 *
	 *  </pre>
	 */
	@Override
	protected boolean processMaintainableProperty(String fieldName, ReportingTemplateMutableBean mutable, JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
		if (fieldName.equals("worksheets")) {
			mutable.setWorksheets(readWorksheets(beanRetrievalManager, jReader));
		} else if (fieldName.equals("includeCheckingTables")) {
			mutable.setIncludeFormulaCheckingSummary(jReader.getValueAsBoolean());
		} else if (fieldName.equals("instructionsheet")) {
			mutable.setInstructionSheet(readInstructionSheet(jReader));
		} else {
			return false;
		}
		return true;
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ReportingTemplateMutableBean mutable, JsonReader reader) {
		//This method is not called - the override processMaintainableProperty with beanRetrievalManager prevents this from being called
		return false;
	}

	/**
	 * In the format
	 * <pre>
	 * {
	 *    title : ""
	 *    name : "",
	 *    instructions : [ {
	 *   "content" : "some text"
	 *   "width : 12,
	 *   "height" : 6,
	 *   "border" : 0|1|2
	 * 	}]
	 * }
	 * </pre>
	 * @param jReader
	 * @return
	 */
	private ReportTemplateInstructionSheetMutableBean readInstructionSheet(JsonReader jReader) {
		ReportTemplateInstructionSheetMutableBean returnType = new ReportTemplateInstructionSheetMutableBeanImpl();

		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("title")) {
				returnType.setTitle(jReader.getValueAsString());
			} else if (fieldName.equals("name")) {
				returnType.setName(jReader.getValueAsString());
			} else if (fieldName.equals("instructions")) {
				readInstructions(jReader, returnType);
			}
		}
		return returnType;
	}

	/**
	 * Reads array of instruction text adding it to the sheet
	 * @param jReader
	 * @param instructionSheet to add instruction text to
	 */
	private void readInstructions(JsonReader jReader, ReportTemplateInstructionSheetMutableBean instructionSheet) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				instructionSheet.addInstruction(readInstructionText(jReader));
			}
		}
	}
	/**
	 * In the format
	 * <pre>
	 * {
	 *   "content" : "some text"
	 *   "width : 12,
	 *   "height" : 6,
	 *   "border" : 0|1|2
	 * }
	 * </pre>
	 * @param jReader
	 * @return
	 */
	private ReportTemplateInstructionTextMutableBean readInstructionText(JsonReader jReader) {
		ReportTemplateInstructionTextMutableBean returnType = new ReportTemplateInstructionTextMutableBeanImpl();

		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("content")) {
				returnType.setContent(jReader.getValueAsString());
			} else if (fieldName.equals("width")) {
				returnType.setColWidth(jReader.getValueAsInt());
			} else if (fieldName.equals("height")) {
				returnType.setColHeight(jReader.getValueAsInt());
			} else if (fieldName.equals("border")) {
				//returnType.setColHeight(jReader.getValueAsInt());
			}
		}

		return returnType;
	}



	private List<ReportingTemplateWorksheetMutableBean> readWorksheets(SdmxBeanRetrievalManager beanRetrievalManager, JsonReader jReader) {
		List<ReportingTemplateWorksheetMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			returnList.add(readWorksheet(beanRetrievalManager, jReader));
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("worksheets")) {
				returnList.add(readWorksheet(beanRetrievalManager, jReader));
			}
		}
		return returnList;
	}

	/**
	 * {
	 *   name   : {
	 *     "en" : "name english",
	 *     "fr" : "name french"
	 *   },
	 *   constraint : "urn",
	 *   id   : ""id,
	 *   tableRows : ["Dim1", "Dim2"],
	 *   tableCols : ["Dim3", "Dim4"],
	 *   fixedAttributes : {
	 *     OBS_STATUS : A,
	 *     UNIT_MULT : M
	 *   },
	 *   excludeDimensions : ["DIMX"],
	 *   variableAttributes : ["PRE_BREAK"],
	 *   separateAttributes : ["TEST"],
	 *   colourAttribute : { *** sub object *** },
	 *   explicitHierarchy : {
	 *     REF_AREA : "urn"
	 *   },
	 *   implicityHierarchy : ["INDICATOR", "BASKET"],
	 *   displayId : ["INDICATOR", "BASKET"]
	 * }
	 * @param jReader
	 * @return
	 */
	private ReportingTemplateWorksheetMutableBean readWorksheet(SdmxBeanRetrievalManager beanRetrievalManager, JsonReader jReader) {
		ReportingTemplateWorksheetMutableBean returnBean = new ReportingTemplateWorksheetMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(FusionJsonIdentifiableUtil.processBean(returnBean, jReader)) {
				continue;
			}
			if (fieldName.equals("constraint")) {
				//FR-3305 Deprecated functionality - resolve the Dataflow for the Constraint and use that instead
				String urn = jReader.getValueAsString();
				if(beanRetrievalManager == null) {
					throw new SdmxNoResultsException("Constraint not found '"+urn +"' referenced by Reporting Template");
				}
				ContentConstraintBean constraint = beanRetrievalManager.getBean(URN.builder(urn).buildSingle(ContentConstraintBean.class));
				if(constraint == null) {
					throw new SdmxNoResultsException("Constraint not found '"+urn +"' referenced by Reporting Template");
				}
				StructureReferenceBean flowRef = null;
				for(ICrossReferenceBean<?> xsRef : constraint.getConstraintAttachment().getStructureReference()) {
					if(xsRef.getTargetReference() == SDMX_STRUCTURE_TYPE.DATAFLOW) {
						flowRef = xsRef.getReference().asMutable();
						break;
					}
				}
				if(flowRef == null) {
					throw new SdmxNoResultsException("Dataflow not found for Constraint '"+urn +"' referenced by Reporting Template");
				}
				returnBean.setDataflow(flowRef);
			} else if (fieldName.equals("dataflow")) {
				returnBean.setDataflow(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			} else if (fieldName.equals("colmaxwidth")) {
				returnBean.setColMaxWidth(jReader.getValueAsInt());
			} else if (fieldName.equals("tableRows")) {
				returnBean.setTableRows(jReader.readStringArray());
			} else if (fieldName.equals("tableCols")) {
				returnBean.setTableCols(jReader.readStringArray());
			}else if (fieldName.equals("excludeDimensions")) {
				returnBean.setExcludeDimensions(jReader.readStringSet());
			} else if (fieldName.equals("fixedAttributes")) {
				returnBean.setFixedAttributeValues(jReader.readStringMap());
			} else if (fieldName.equals("variableAttributes")) {
				returnBean.setVariableAttributes(jReader.readStringSet());
			} else if (fieldName.equals("variableDimensions")) {
				returnBean.setVariableDimensions(jReader.readStringSet());
			} else if (fieldName.equals("separateAttributes")) {
				returnBean.setSeparateAttributes(jReader.readStringSet());
			} else if (fieldName.equals("worksheetAttributes")) {
				returnBean.setWorksheetAttributes(jReader.readStringSet());
			} else if (fieldName.equals("colourAttribute")) {
				if(jReader.isStartObject()) {
					returnBean.setColourAttribute(readColourAttribute(jReader));
				}
			} else if (fieldName.equals("conditionalAttributes")) {
				if(jReader.isStartObject()) {
					returnBean.setConditionalAttributes(readConditionalAttributes(jReader));
				}
			} else if (fieldName.equals("explicitHierarchy")) {
				Map<String, String> hierarchyMapString = jReader.readStringMap();
				Map<String, StructureReferenceBean> hierarchyMap = new HashMap<>();
				for(String str : hierarchyMapString.keySet()) {
					hierarchyMap.put(str, new StructureReferenceBeanImpl(hierarchyMapString.get(str)));
				}
				returnBean.setHierarhcyReferences(hierarchyMap);
			} else if (fieldName.equals("implicityHierarchy")) {
				returnBean.setImplicitHierarchices(jReader.readStringSet());
			} else if (fieldName.equals("displayId")) {
				for(String componentId : jReader.readStringSet()) {
					returnBean.addTextDisplay(componentId, TEXT_DISPLAY.ID);
				}
			} else if (fieldName.equals("display")) {
				Map<String, String> textDisplay = jReader.readStringMap();
				for(String componentId : textDisplay.keySet()) {
					returnBean.addTextDisplay(componentId, TEXT_DISPLAY.valueOf(textDisplay.get(componentId)));
				}
			} else if (fieldName.equals("round")) {
				if(ObjectUtil.validString(jReader.getValueAsString())) {
					try {
						returnBean.setRoundDecimals(Integer.parseInt(jReader.getValueAsString()));
					} catch(NumberFormatException e) {
						throw new SdmxSemmanticException("JSON value 'round' expected to be an Integer value, got '"+jReader.getValueAsString()+"'");
					}
				}
			}  else if (fieldName.equals("fixedDimensions")) {
				jReader.moveToEndObject();  //deprecated, so skip to the end
			} else {
				if(jReader.getToken() == JsonToken.START_OBJECT) {
					LOG.warn("Unexpected Field: "+fieldName);
					jReader.moveToEndObject();
				} else if(jReader.getToken() == JsonToken.START_ARRAY) {
					jReader.moveToEndArray();
				}
			}
		}
		return returnBean;
	}

	/**
	 * {
	 *   id : "OBS_CONF",
	 *   defaultColour : "#C2C2C2",
	 *   colourCodes : {
	 *    "A" : "#C2C2C2",
	 *    "M" : "#E2E2E2",
	 *   },
	 *   seriesColors [
	 *    {
	 *      colour : "#D2D2D2",
	 *      series : ["A:UK:POP","A:FR:POP"]
	 *    },....
	 *   ]
	 *  }
	 * @param jReader
	 * @return
	 */
	private ReportingTemplateColourMutableBean readColourAttribute(JsonReader jReader) {
		ReportingTemplateColourMutableBean returnBean = null;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			} else if(returnBean == null) {
				returnBean = new ReportingTemplateColourMutableBeanImpl();
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("id")) {
				returnBean.setAttributeId(jReader.getValueAsString());
			} else if (fieldName.equals("defaultColour")) {
				returnBean.setDefaultColour(jReader.getValueAsString());
			} else if (fieldName.equals("colourCodes")) {
				returnBean.setColourCodes(jReader.readStringMap());
			} else if (fieldName.equals("seriesColors")) {
				returnBean.setSeriesColours(readSeriesColour(jReader));
			}
		}
		return returnBean;
	}

	/**
	 * conditionalAttributes : {
	 *   OBS_STATUS : {
	 *     A : {
	 *     		rule : dv
	 *     },
	 *     M : {
	 *     		rule : mv
	 *     }
	 *     E : {
	 *     		rule : ov,
	 *     		details: gt.100
	 *     }
	 *   }
	 * }
	 *
	 */
	private Set<ReportingTemplateConditionalAttributeMutableBean> readConditionalAttributes(JsonReader jReader) {
		Set<ReportingTemplateConditionalAttributeMutableBean> returnSet = new HashSet<>();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			returnSet.add(readConditionalAttribute(fieldName, jReader));
		}
		return returnSet;
	}

	/**
	 *   A : {
	 * 		rule : dv
	 *   },
	 *   M : {
	 * 		rule : mv
	 *   }
	 *   E : {
	 * 		rule : ov,
	 * 		details: gt.100
	 *   }
	 */
	private ReportingTemplateConditionalAttributeMutableBean readConditionalAttribute(String attrId, JsonReader jReader) {
		ReportingTemplateConditionalAttributeMutableBean mutable = new ReportingTemplateConditionalAttributeMutableBeanImpl();
		mutable.setAttributeId(attrId);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			mutable.addCondition(readReportingTemplateAttributeCondition(fieldName, jReader));
		}
		return mutable;
	}

	/**
	 * rule : ov,
	 * details: gt.100
	 */
	private ConditionalAttributeMappingBeanMutableBean readReportingTemplateAttributeCondition(String attrValue, JsonReader jReader) {
		ConditionalAttributeMappingBeanMutableBean mutable = new ConditionalAttributeMappingBeanMutableBeanImpl();
		mutable.setAttributeValue(attrValue);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();

			switch(fieldName) {
			case "rule" :
				mutable.setCondition(CONDITION.parseString(value));
				break;
			case "details" :
				mutable.setConditionDetail(value);
				break;
			}
		}
		return mutable;
	}


	/**
	 * [
	 *  {
	 *    colour : "#D2D2D2",
	 *    series : ["A:UK:POP","A:FR:POP"]
	 *  }
	 * ]
	 * @param jReader
	 * @return
	 */
	private Map<Set<String>, String> readSeriesColour(JsonReader jReader) {
		Map<Set<String>, String> returnMap = new HashMap<>();
		String key = null;
		Set<String> values = new HashSet<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				if (fieldName.equals("colour")) {
					key = jReader.getValueAsString();
				} else if (fieldName.equals("series")) {
					values = jReader.readStringSet();
				}
			}
			returnMap.put(values, key);
		}
		return returnMap;
	}

    @Override
    protected Class<ReportingTemplateBean> getMaintainableType() {
        return ReportingTemplateBean.class;
    }
}
