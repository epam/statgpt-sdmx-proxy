package io.sdmx.format.json.engine.data.writer.sdmxjson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.im.beans.base.LinkBean;

public class SdmxJsonWriterUtils {
	
	public static void writeLinks(List<ILinkBean> links, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.writeLinks(links, jsonGenerator, true);
	}
	
	public static void writeTextTypeWrapperArray(List<TextTypeWrapper> items, JsonGenerator jsonGenerator ,String objectFieldName) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, items, objectFieldName);
	}
	
	
	public static List<ILinkBean> getLinks(IDatasetStructures structures) throws JsonGenerationException, IOException {
		List<ILinkBean> links = new ArrayList<>();
		if(structures != null) {
			if(structures.getDataflow() != null) {
				links.add(new LinkBean(structures.getDataflow()));
			}
			
			if(structures.getProvisionAgreement() != null) {
				links.add(new LinkBean(structures.getProvisionAgreement()));
			}
			
			if(structures.getDataStructure() != null) {
				links.add(new LinkBean(structures.getDataStructure()));
			}
		}
		return links;
	}

	public static String prettifyJson(String uglyJson, boolean indentArrays) {
		ObjectMapper mapper = new ObjectMapper();
		Object object;
		String prettyJson;
		DefaultPrettyPrinter prettyPrinter = new DefaultPrettyPrinter();
		if (indentArrays) {
			prettyPrinter.indentArraysWith(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE);
		}
		try {
			object = mapper.readValue(uglyJson, Object.class);
			prettyJson = mapper.writer(prettyPrinter).writeValueAsString(object);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
		return prettyJson;
	}
}
