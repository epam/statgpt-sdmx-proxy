package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonCategorySchemeMapWriterEngineV2 extends SdmxJsonItemSchemeMapWriterEngineV2<ICategoryMapBean, ICategorySchemeMapBean> implements IFusionSingleton {
	private static SdmxJsonCategorySchemeMapWriterEngineV2 INSTANCE;

	public static SdmxJsonCategorySchemeMapWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorySchemeMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonCategorySchemeMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME_MAP);
	}
}
