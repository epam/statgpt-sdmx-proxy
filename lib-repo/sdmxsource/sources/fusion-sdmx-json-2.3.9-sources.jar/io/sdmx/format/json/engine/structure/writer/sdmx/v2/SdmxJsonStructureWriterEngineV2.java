package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.engine.structure.writer.JsonMaintainableStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.sdmx.AbstractSdmxJsonStructureWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonStructureWriterEngineV2 extends AbstractSdmxJsonStructureWriterEngine {
	
	private static SdmxJsonStructureWriterEngineV2 INSTANCE;

	public static SdmxJsonStructureWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonStructureWriterEngineV2() {
		super(false, SDMX_STRUCTURE_TYPE.PUBLICATION_TABLE_DEF, SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE, SDMX_STRUCTURE_TYPE.VALIDATION_SCHEME);
		registerWriter(SdmxJsonAgencySchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonCategorisationWriterEngineV2.getInstance());
		registerWriter(SdmxJsonCategorySchemeMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonCategorySchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonCodelistWriterEngineV2.getInstance());
		registerWriter(SdmxJsonConceptSchemeMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonConceptSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonContentConstraintWriterEngineV2.getInstance());
		registerWriter(SdmxJsonCustomTypeSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonDataConsumerSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonDataProviderSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonDataStructureWriterEngineV2.getInstance());
		registerWriter(SdmxJsonDataflowWriterEngineV2.getInstance());
		registerWriter(SdmxJsonHierarchicalCodelistWriterEngineV2.getInstance());
		registerWriter(SdmxJsonHierarchyAssociationWriterEngineV2.getInstance());
		registerWriter(SdmxJsonMetadataConstraintWriterEngineV2.getInstance());
		registerWriter(SdmxJsonMetadataProviderSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonMetadataProvisionWriterEngineV2.getInstance());
		registerWriter(SdmxJsonMetadataStructureWriterEngineV2.getInstance());
		registerWriter(SdmxJsonMetadataflowWriterEngineV2.getInstance());
		registerWriter(SdmxJsonNamePersonalisationSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonOrganisationSchemeMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonOrganisationUnitSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonPDQWriterEngineV2.getInstance());
		registerWriter(SdmxJsonProvisionAgreementWriterEngineV2.getInstance());
		registerWriter(SdmxJsonReportingTaxonomyWriterEngineV2.getInstance());
		registerWriter(SdmxJsonReportingTaxonomyMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonRepresentationMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonRulesetSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonStructureMapWriterEngineV2.getInstance());
		registerWriter(SdmxJsonTransformationSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonUserDefinedOperatorSchemeWriterEngineV2.getInstance());
		registerWriter(SdmxJsonValueListWriterEngineV2.getInstance());
		registerWriter(SdmxJsonVtlMappingSchemeWriterEngineV2.getInstance());
	}

	/**
	 * Returns the type as per the schema, or defaults to the lower case class name plus an 's' to make it plural
	 */
	@Override
	protected String getMaintainableJSONKey(SDMX_STRUCTURE_TYPE maintainableType) {
		switch (maintainableType) {
			case CONTENT_CONSTRAINT:
				return "dataConstraints";
			case REPRESENTATION_MAP:
				return "representationMaps";
			case STRUCTURE_MAP:
				return "structureMaps";
			case HIERARCHY:
				return "hierarchies";
			default:
				return super.getMaintainableJSONKey(maintainableType);
		}
	}

	@Override
	protected String getGeographicCodelistJSONKey() {
		return "geographicCodelists";
	}

	@Override
	protected String getGeoGridCodelistJSONKey() {
		return "geoGridCodelists";
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeographicCodelistBean> getGeographicalCodelistWriter() {
		return SdmxJsonGeographicCodelistWriterEngineV2.getInstance();
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeoGridCodelistBean> getGeoGridCodelistWriter() {
		return SdmxJsonGeoGridCodelistWriterEngineV2.getInstance();
	}

	@Override
	protected String getSchemaLocation() {
		return SDMX_JSON_SCHEMA.STRUCTURE_V2;
	}
	
	@Override
	public boolean isSupportedType(MaintainableBean structure) {
		return super.isSupportedType(structure) && structure.isCompatible(SDMX_SCHEMA.VERSION_THREE);
	}
}
