package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.MetadataProviderMutableBean;
import io.sdmx.im.mutable.base.MetadataProviderSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonMetadataProviderSchemeReaderEngine extends FusionJsonOrganisationSchemeReaderEngine<IMetadataProviderSchemeBean, IMetadataProviderSchemeMutableBean, IMetadataProviderMutableBean> implements IFusionSingleton {
	private static FusionJsonMetadataProviderSchemeReaderEngine INSTANCE;

	public static FusionJsonMetadataProviderSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataProviderSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	protected IMetadataProviderMutableBean readItemBean(JsonReader jReader) {
		IMetadataProviderMutableBean orgScheme = new MetadataProviderMutableBean();
		populateOrganisationMutableBean(jReader, orgScheme);
		return orgScheme;
	}

	@Override
	protected IMetadataProviderSchemeMutableBean getMutable() {
		return new MetadataProviderSchemeMutableBean();
	}

    @Override
    protected Class<IMetadataProviderSchemeBean> getMaintainableType() {
        return IMetadataProviderSchemeBean.class;
    }
}