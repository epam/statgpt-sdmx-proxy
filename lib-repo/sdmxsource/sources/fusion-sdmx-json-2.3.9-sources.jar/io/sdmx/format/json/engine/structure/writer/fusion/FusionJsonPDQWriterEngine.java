package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * 
 *  {
 *    virtual : true,
 *    dataflows : ["urn1", "urn2"],
 *    series : ["series1", ["series2"],
 *    parameters : {
 *    	"param1" : "param value",
 *    	"param2" : "param value2"
 *    },
 *    filters : [
 *    	{
 *    		component : "FREQ",
 *          "EQUALS" : "["A", "Q"]
 *      },
 *      ...
 *    ]
 *  }
 *
 *
 */
public class FusionJsonPDQWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<IPreDefinedQueryBean> implements IFusionSingleton {
	private static FusionJsonPDQWriterEngine INSTANCE;

	public static FusionJsonPDQWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonPDQWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonPDQWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.PREDEFINED_QUERY);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IPreDefinedQueryBean bean) throws JsonGenerationException, IOException {
		jsonGenerator.writeBooleanField("virtual", bean.isVirtualFlow());
		JsonWriterUtil.writeStringArray(jsonGenerator, "dataflow", SdmxCollectionUtil.refUrns(bean.getDataflow()));
		JsonWriterUtil.writeStringArray(jsonGenerator, "series", bean.getSeries());
		JsonWriterUtil.writeStringMap(jsonGenerator, "parameters", bean.getParameters());
		writerFilters(bean.getSelections(), jsonGenerator);
	}

	
	private void writerFilters(List<IPreDefinedQueryComponentFilterBean> filters, JsonGenerator jsonGenerator) throws IOException  {
		jsonGenerator.writeArrayFieldStart("filters");
		for(IPreDefinedQueryComponentFilterBean filter : filters) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("component", filter.getComponentId());
			for(MATCH_FUNCTION func : filter.getFilters().keySet()) {
				JsonWriterUtil.writeStringArray(jsonGenerator, func.getFunction(), filter.getFilters().get(func));
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}
}