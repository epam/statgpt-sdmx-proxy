package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonMaintainableUtil;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public abstract class SdmxJsonAbstractConstraintReaderEngineV2<T extends ConstraintBean, B extends ConstraintMutableBean> extends AbstractSdmxJsonReaderEngine<B> {

	protected boolean readConstraint(B toPopulate, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		if(SdmxJsonMaintainableUtil.processBean(toPopulate, jReader)) {
			return true;
		}
		switch(fieldName) {
		case "constraintAttachment":
			ConstraintAttachmentMutableBean attach = readAttachments(jReader);
			toPopulate.setConstraintAttachment(attach);
			return true;
		case "dataKeySets":
			List<DescribedDataKeySet> dataKeySets = readDataKeySets(jReader);
			for (DescribedDataKeySet describedDataKeySet : dataKeySets) {
				if(describedDataKeySet.isIncluded) {
					toPopulate.setIncludedSeriesKeys(describedDataKeySet.dataKeySet);
				}else {
					toPopulate.setExcludedSeriesKeys(describedDataKeySet.dataKeySet);
				}
			}
			return true;
		}
		return false;
	}

	private ConstraintAttachmentMutableBean readAttachments(JsonReader jReader) {
		ConstraintAttachmentMutableBean attach = new ContentConstraintAttachmentMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			switch(fieldName) {
			case "dataStructures":
			case "dataflows":
			case "metadataStructures":
			case "metadataflows":
			case "provisionAgreements":
				Set<StructureReferenceBean> readSet = jReader.readStringArray().stream()
				.map(StructureReferenceBeanImpl::new)
				.collect(Collectors.toSet());
				for(StructureReferenceBean strf: readSet) {
					attach.addStructureReference(strf);
				}
				break;
			case "simpleDataSource":
			{
				DataSourceMutableBean dsBean = new DataSourceMutableBeanImpl();
				dsBean.setSimpleDatasource(true);
				dsBean.setDataUrl(value);
				attach.addDataSource(dsBean);
			}
			break;
			case "queryableDataSources":
			{
				while (jReader.moveNext()) {
					if (jReader.isEndArray()) {
						break;
					}
					DataSourceMutableBean dsBean = new DataSourceMutableBeanImpl();
					Map<String, String> readStringMap = jReader.readStringMap();
					String isRESTDatasource = readStringMap.get("isRESTDatasource");
					if(ObjectUtil.validString(isRESTDatasource)) {
						dsBean.setRESTDatasource(Boolean.parseBoolean(isRESTDatasource));

					}
					String isWebServiceDatasource = readStringMap.get("isWebServiceDatasource");
					if(ObjectUtil.validString(isWebServiceDatasource)) {
						dsBean.setWebServiceDatasource(Boolean.parseBoolean(isWebServiceDatasource));
					}
					String dataURL = readStringMap.get("dataURL");
					if(ObjectUtil.validString(dataURL)) {
						dsBean.setDataUrl(dataURL);
					}
					String wadlURL = readStringMap.get("wadlURL");
					if(ObjectUtil.validString(wadlURL)) {
						dsBean.setWADLUrl(wadlURL);
					}
					String wsdlURL = readStringMap.get("wsdlURL");
					if(ObjectUtil.validString(wsdlURL)) {
						dsBean.setWSDLUrl(wsdlURL);
					}
					attach.addDataSource(dsBean);
				}
			}
			}
		}
		return attach;
	}



	private List<DescribedDataKeySet> readDataKeySets(JsonReader jReader) {
		List<DescribedDataKeySet> retList = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			DescribedDataKeySet d = new DescribedDataKeySet(new ConstraintDataKeySetMutableBeanImpl());
			while(jReader.moveNext()) {
				if(jReader.isEndObject()) {
					break;
				}
				String fieldName = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(fieldName) {
				case "isIncluded":
					boolean isIncluded = Boolean.parseBoolean(value);
					d.isIncluded = isIncluded;
					break;
				case "keys":
					while (jReader.moveNext()) {
						if(jReader.isEndArray()) {
							break;
						}
						ConstrainedDataKeyMutableBean dataKeyMut = new ConstrainedDataKeyMutableBeanImpl();
						while(jReader.moveNext()) {
							if(jReader.isEndObject()) {
								break;
							}
							if(jReader.getCurrentFieldName().equals("keyValues")) {
								while (jReader.moveNext()) {
									if(jReader.isEndArray()) {
										break;
									}
									Map<String, String> readStringMap = jReader.readStringMap();
									String conceptId = readStringMap.get("id");
									String codeId = readStringMap.get("value");
									boolean removePrefix = "true".equals(readStringMap.get("removePrefix"));
									if(!ObjectUtil.validString(conceptId,codeId)) {
										break;
									}
									IConstrainedKeyValue kv = ConstrainedKeyValue.getInstance(conceptId, removePrefix, codeId);
									dataKeyMut.addKeyValue(kv);
								}
							}
							if(jReader.getCurrentFieldName().equals("components")) {
								while (jReader.moveNext()) {
									if(jReader.isEndArray()) {
										break;
									}
									if(jReader.isStartObject()) {
										processConstrainedComponentValue(jReader, dataKeyMut);
									}
								}
							}
						}
						d.dataKeySet.addConstrainedDataKey(dataKeyMut);
					}
				}
			}
			retList.add(d);
		}
		return retList;
	}

	private void processConstrainedComponentValue(JsonReader jReader, ConstrainedDataKeyMutableBean dataKeyMut) {
		String concept = null;
		boolean removePrefix = false;
		List<String> codes = null;
		while (jReader.moveNext()) {
			if(jReader.isEndObject()) {
				break;
			}
			switch(jReader.getCurrentFieldName()) {
			case "id" :
				concept = jReader.getValueAsString();
				break;
			case "removePrefix" :
				removePrefix = jReader.getValueAsBoolean();
				break;
			case "values" :
				codes = readConstrainedCodes(jReader);
				break;
			}
		}
		if(concept != null & codes != null) {
			String[] codesArray = CollectionUtil.toArray(codes);
			dataKeyMut.addComponentValues(ConstrainedKeyValue.getInstance(concept, removePrefix, codesArray));
		}
	}
	
	private List<String> readConstrainedCodes(JsonReader jReader) {
		List<String> codes = new ArrayList<>();
		while (jReader.moveNext()) {
			if(jReader.isEndArray()) {
				break;
			}
			switch(jReader.getCurrentFieldName()) {
			case "value" :
				codes.add(jReader.getValueAsString());
				break;
			case "cascadeValues" :
				break;
			case "lang" :
				//TODO lang not supported
				break;
			}
		}
		return codes;
	}


	/**
	 * 
	 * Describes if this Constraint Data Key Set Mutable Bean is "included" or not
	 */
	private class DescribedDataKeySet{
		public ConstraintDataKeySetMutableBean dataKeySet;
		public boolean isIncluded;

		public DescribedDataKeySet(ConstraintDataKeySetMutableBean dataKeySet) {
			this.dataKeySet = dataKeySet;
		}
	}

}
