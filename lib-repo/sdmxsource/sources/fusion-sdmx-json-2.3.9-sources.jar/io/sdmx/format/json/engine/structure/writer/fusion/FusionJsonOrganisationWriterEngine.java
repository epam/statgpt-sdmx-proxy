package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonOrganisationWriterEngine implements IFusionSingleton {
	private static FusionJsonOrganisationWriterEngine INSTANCE;

	public static FusionJsonOrganisationWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonOrganisationWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonOrganisationWriterEngine() {}

	public void writeStructures(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, Collection<? extends OrganisationBean> organisations) throws JsonGenerationException, IOException {
		for(OrganisationBean currentItem : organisations) {
			jsonGenerator.writeStartObject();
			FusionJsonStaticHelper.writeIdentifiable(jsonGenerator, externalLinks, currentItem);
			FusionJsonStaticHelper.writeNameable(jsonGenerator, externalLinks, currentItem);
			writeStructure(jsonGenerator, currentItem);
			jsonGenerator.writeEndObject();
		}
	}

	public void writeStructure(JsonGenerator jsonGenerator, OrganisationBean identifiable) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(identifiable.getContacts())) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("contacts");
		for(ContactBean contact : identifiable.getContacts()) {
			writeContact(jsonGenerator, contact);
		}
		jsonGenerator.writeEndArray();
	}


	private void writeContact(JsonGenerator jsonGenerator, ContactBean contact) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();

		if(contact.getId() != null) {
			jsonGenerator.writeStringField("id", contact.getId());
		}
		writeTextType(jsonGenerator, contact.getDepartments(), "departments");
		writeTextType(jsonGenerator, contact.getRole(), "roles");
		writeTextType(jsonGenerator, contact.getName(), "names");

		writeArray(jsonGenerator, contact.getTelephone(), "telephone");
		writeArray(jsonGenerator, contact.getFax(), "fax");
		writeArray(jsonGenerator, contact.getEmail(), "email");
		writeArray(jsonGenerator, contact.getX400(), "x400");
		writeArray(jsonGenerator, contact.getUri(), "uri");

		jsonGenerator.writeEndObject();
	}

	private void writeTextType(JsonGenerator jsonGenerator, List<TextTypeWrapper> items, String fieldName) throws IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}

		jsonGenerator.writeArrayFieldStart(fieldName);
		for (TextTypeWrapper textTypeWrapper : items) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("locale", textTypeWrapper.getLocale());
			jsonGenerator.writeStringField("value", textTypeWrapper.getValue());
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeArray(JsonGenerator jsonGenerator, List<String> array, String arrayName) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(array)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(arrayName);
		for(String currentItem : array) {
			jsonGenerator.writeString(currentItem);
		}
		jsonGenerator.writeEndArray();
	}
}
