package io.sdmx.format.json.engine.data.reader;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.error.DataFormatErrorImpl;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class HeaderIterator extends AbstractIterator {
	private String id;
	private Date prepared;
	private Boolean test = false;
	private String datasetId;

	private PartyIterator senderIt;
	private PartyIterator recieverIt;

	public HeaderIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	public HeaderBean getHeader() {
		PartyBean sender = senderIt != null ? senderIt.getParty() : null;
		PartyBean reciever = recieverIt != null ? recieverIt.getParty() : null;
		List<PartyBean> recievers = new ArrayList<>();
		if(reciever != null) {
			recievers.add(reciever);
		}
		HeaderBeanImpl header = new HeaderBeanImpl(id, prepared, null, null, recievers, sender, test);
        header.setDatasetId(datasetId);
        return header;
	}


	@Override
	public void end(String fieldName, boolean isObject) {
		if(!ObjectUtil.validString(this.id) && this.exceptionHandler != null) {
			this.exceptionHandler.handleException(new DataFormatErrorImpl("Invalid header: missing required property 'id'", TYPE.INVALID_HEADER_CONTENT));
		}
		if(senderIt == null && this.exceptionHandler != null) {
			this.exceptionHandler.handleException(new DataFormatErrorImpl("Invalid header: missing required property 'sender'", TYPE.INVALID_HEADER_CONTENT));
		}
	}

	@Override
	public JsonReader.Iterator start(String fieldName, boolean isObject) {
		if(fieldName == null) {
			return null;
		}
		switch(fieldName) {
		case "sender":
			senderIt = new PartyIterator(jReader, this.exceptionHandler);
			return senderIt;
		case "receiver":
			recieverIt = new PartyIterator(jReader, this.exceptionHandler);
			return recieverIt;
		}
		return null;
	}

	@Override
	public void next(String fieldName) {
		if("id".equals(fieldName)) {
			id = jReader.getValueAsString();
		} else if("prepared".equals(fieldName)) {
			prepared = jReader.getValueAsDate();
		} else if("test".equals(fieldName)) {
			test = jReader.getValueAsBoolean();
		} else if("datasetId".equals(fieldName)) {
            datasetId = jReader.getValueAsString();
        }
	}

//	private class PartyIterator extends AbstractIterator {
//		private String id;
//		private List<TextTypeWrapper> names = new ArrayList<>();
//		private List<ContactBean> contacts = new ArrayList<>();
//		public PartyIterator(JsonReader jReader) {
//			super(jReader);
//		}
//
//		@Override
//		public void next(String fieldName) {
//			switch(fieldName) {
//			case "id":
//				id = jReader.getValueAsString();
//			}
//		}
//
//		public PartyBean getParty() {
//			return new PartyBeanImpl(this.names, id, contacts, null);
//		}
//
//		@Override
//		public JsonReader.Iterator start(String fieldName, boolean isObject) {
//			switch(fieldName) {
//			case "names":
//				List<TextTypeWrapperMutableBean> names = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
//				for (TextTypeWrapperMutableBean nameMut : names) {
//					TextTypeWrapper ttw = new TextTypeWrapperImpl(nameMut, "names", null);
//					this.names.add(ttw);
//				}
//				break;
//			case "contact":
//				List<ContactMutableBean> contactImut = SdmxJsonContactUtil.readContacts(jReader);
//				List<ContactBean> contacts = contactImut.stream().map(ContactBeanImpl::new).collect(Collectors.toList());
//				this.contacts = contacts;
//				break;
//			}
//			jReader.moveNextStartObject();
//			return JsonReader.SKIP_OBJECT_ITERATOR;
//		}
//	}

	private class PartyIterator extends AbstractIterator {
		private String id;
		private String name;

		public PartyIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
			super(jReader, exceptionHandler);
		}

		@Override
		public void next(String fieldName) {
			if("id".equals(fieldName)) {
				id = jReader.getValueAsString();
			} else if("name".equals(fieldName)) {
				name = jReader.getValueAsString();
			}
		}

		@Override
		public void end(String fieldName, boolean isObject) {
			if(!ObjectUtil.validString(this.id) && this.exceptionHandler != null) {
				this.exceptionHandler.handleException(new DataFormatErrorImpl("Invalid header: header party is missing required property ID", TYPE.INVALID_SENDER_RECIEVER));
			}
		}

		public PartyBean getParty() {
			List<TextTypeWrapper> nameList = new ArrayList<>();
			if(ObjectUtil.validString(name)) {
				nameList.add(new TextTypeWrapperImpl("en", name, null));
			}
			List<ContactBean> contactList = new ArrayList<>();
			return new PartyBeanImpl(nameList, id, contactList, null);  //TODO CONTACTS
		}

		@Override
		public JsonReader.Iterator start(String fieldName, boolean isObject) {
			//TODO Contact
			return JsonReader.SKIP_OBJECT_ITERATOR;
		}
	}
}
