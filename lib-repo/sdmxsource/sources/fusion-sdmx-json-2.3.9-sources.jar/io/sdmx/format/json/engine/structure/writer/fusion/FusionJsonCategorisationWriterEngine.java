package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonCategorisationWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<CategorisationBean> implements IFusionSingleton {
	private static FusionJsonCategorisationWriterEngine INSTANCE;

	public static FusionJsonCategorisationWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCategorisationWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonCategorisationWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CATEGORISATION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CategorisationBean aCategorisation) throws JsonGenerationException, IOException {
		ICrossReferenceBean structureRef = aCategorisation.getStructureReference();
		if(structureRef != null) {
			jsonGenerator.writeStringField("structureReference", structureRef.getTargetUrn());
		}
		ICrossReferenceBean categoryRef = aCategorisation.getCategoryReference();
		if(categoryRef != null) {
			jsonGenerator.writeStringField("categoryReference", categoryRef.getTargetUrn());
		}
	}
}
