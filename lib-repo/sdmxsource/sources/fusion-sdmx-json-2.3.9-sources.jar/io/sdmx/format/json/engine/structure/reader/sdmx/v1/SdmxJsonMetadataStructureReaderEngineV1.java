package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonComponentUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonIdentifiableUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataAttributeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataStructureDefinitionMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

/**
 * As the 2.1 model changes in v3.0 this reader only reads the metadata attributes - it strips off the target information
 */
public class SdmxJsonMetadataStructureReaderEngineV1 extends AbstractSdmxJsonReaderEngine<MetadataStructureDefinitionMutableBean> implements IFusionSingleton {
    private static SdmxJsonMetadataStructureReaderEngineV1 INSTANCE;

    public static SdmxJsonMetadataStructureReaderEngineV1 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxJsonMetadataStructureReaderEngineV1();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "metadataStructures";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return MetadataStructureDefinitionBean.class;
    }

    @Override
    protected MetadataStructureDefinitionMutableBean getMutable() {
        return new MetadataStructureDefinitionMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, MetadataStructureDefinitionMutableBean mutable,
            JsonReader reader) {
        if(fieldName.equals("metadataStructureComponents")) {
            readMsdComponents(mutable, reader);
            return true;
        }
        return false;
    }

    private void readMsdComponents(MetadataStructureDefinitionMutableBean ret, JsonReader jReader) {
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String key = jReader.getCurrentFieldName();
            switch(key) {
            case "metadataTargets":
                jReader.moveToEndArray();
                break;
            case "reportStructures":
                List<MetadataAttributeMutableBean> attributes = readReportStructures(jReader);
                ret.setMetadataAttributes(attributes);
                break;
            }
        }
    }

    private List<MetadataAttributeMutableBean> readReportStructures(JsonReader jReader) {
        List<MetadataAttributeMutableBean> ret = null;
        CodeMutableBean dummyIdentifiable = new CodeMutableBeanImpl();  //Just pass something into process the identifiable
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            while (jReader.moveNext()) {
                if (jReader.isEndObject()) {
                    break;
                }
                String key = jReader.getCurrentFieldName();
                if(SdmxJsonIdentifiableUtil.processBean(dummyIdentifiable, jReader)) {
                    continue;
                }
                switch(key) {
                case "metadataAttributes":
                    ret = readMetadataAttributes(jReader);
                    break;
                case "metadataTargets":
                    List<String> readStringArray = jReader.readStringArray();
                    break;
                }
            }
        }
        return ret;
    }

    private List<MetadataAttributeMutableBean> readMetadataAttributes(JsonReader jReader) {
        List<MetadataAttributeMutableBean> ret = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            MetadataAttributeMutableBean atra = new MetadataAttributeMutableBeanImpl();
            while (jReader.moveNext()) {
                if (jReader.isEndObject()) {
                    break;
                }
                String key = jReader.getCurrentFieldName();
                if(SdmxJsonComponentUtil.processBean(atra, jReader, false)) {
                    continue;
                }
                switch(key) {
                case "isPresentational":
                    Boolean isPresentational = jReader.getValueAsBoolean();
                    atra.setPresentational(TERTIARY_BOOL.parseBoolean(isPresentational));
                    break;
                case "maxOccurs":
                    atra.setMaxOccurs(jReader.getValueAsInt());
                    break;
                case "minOccurs":
                    atra.setMinOccurs(jReader.getValueAsInt());
                    break;
                case "metadataAttributes":
                    List<MetadataAttributeMutableBean> readMetadataAttributes = readMetadataAttributes(jReader);
                    readMetadataAttributes.forEach(atra::addMetadataAttributes);
                    break;
                }
            }
            ret.add(atra);
        }
        return ret;
    }

}
