package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemSchemeMapMutableBean;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonAnnotableUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public abstract class SdmxJsonItemSchemeMapReaderEngineV2<Y extends IItemMapMutableBean<?>, F extends IItemSchemeMapMutableBean<Y>> extends AbstractSdmxJsonReaderEngine<F> {

    @Override
    protected boolean processMaintainableProperty(String fieldName, F mutable, JsonReader reader) {
        switch (fieldName) {
        case "itemMaps":
            mutable.setItems(readItemMaps(reader));
            return true;
        case "source":
            mutable.setSourceRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "target":
            mutable.setTargetRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        }
        return false;
    }

    private List<Y> readItemMaps(JsonReader json) {
        List<Y> itemMapList = new ArrayList<>();

        while (json.moveNext()) {
            if (json.isEndArray()) {
                break;
            }
            if (json.isStartObject()) {
                itemMapList.add(readItemMap(json));
            }
        }
        return itemMapList;
    }

    private Y readItemMap(JsonReader json) {
        Y itemMap = getItemMapMutable();

        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            if (SdmxJsonAnnotableUtil.processBean(itemMap, json)) {
                continue;
            }
            switch (json.getCurrentFieldName()) {
            case "sourceValue":
                readSourceValue(itemMap, json);
                break;
            case "targetValue":
                itemMap.setTargetId(json.getValueAsString());
                break;
            case "validFrom":
                itemMap.setValidFrom(json.getValueAsString());
                break;
            case "validTo":
                itemMap.setValidTo(json.getValueAsString());
                break;
            }
        }
        return itemMap;
    }

    private void readSourceValue(Y itemMap, JsonReader json) {
        while (json.moveNext()) {
            if (json.isEndObject()) {
                break;
            }
            switch (json.getCurrentFieldName()) {
            case "value":
                itemMap.setSourceId(json.getValueAsString());
                break;
            case "isRegEx":
                itemMap.setSourceRegEx(json.getValueAsBoolean());
                break;
            case "startIndex":
                itemMap.setSourceStartIdx(json.getValueAsInt());
                break;
            case "endIndex":
                itemMap.setSourceEndIdx(json.getValueAsInt());
                break;
            }
        }
    }

    protected abstract Y getItemMapMutable();
}
