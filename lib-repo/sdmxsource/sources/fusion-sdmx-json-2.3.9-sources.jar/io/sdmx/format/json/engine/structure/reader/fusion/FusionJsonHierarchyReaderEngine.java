package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonDateUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonRepresentationUtil;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonHierarchyReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<HierarchyBean, HierarchyMutableBean> implements IFusionSingleton {
	private static FusionJsonHierarchyReaderEngine INSTANCE;

	public static FusionJsonHierarchyReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonHierarchyReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected HierarchyMutableBean getMutable() {
		return new HierarchyMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, HierarchyMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("formalLevels")) {
			mutable.setFormalLevels(jReader.getValueAsBoolean());
		} else if (fieldName.equals("levels")) {
			readLevel(mutable, jReader);
		} else if (fieldName.equals("codes")) {
			mutable.setHierarchicalCodeBeans(processHCodes(jReader));
		} else {
			return false;
		}
		return true;
	}

	private void readLevel(HierarchyMutableBean hie, JsonReader jReader) {
		LevelMutableBean level = null;
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				LevelMutableBean newLevel = readLevel(jReader);
				if(level == null) {
					hie.setChildLevel(newLevel);
				} else {
					level.setChildLevel(newLevel);
				}
				level = newLevel;
			}
		}
	}

	private LevelMutableBean readLevel(JsonReader jReader) {
		LevelMutableBean level = new LevelMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonNameableUtil.processBean(level, jReader)) {
				continue;
			}
			if (jReader.getCurrentFieldName().equals("textFormat")) {
				level.setCodingFormat(FusionJsonRepresentationUtil.readTextFormat(jReader));
			}
		}
		return level;
	}


	private List<CodeRefMutableBean> processHCodes(JsonReader jReader) {
		List<CodeRefMutableBean> codeRefs = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isStartObject()) {
				codeRefs.add(processCode(jReader));
			}
			if(jReader.isEndArray()) {
				break;
			}
		}
		return codeRefs;
	}

	private CodeRefMutableBean processCode(JsonReader jReader) {
		CodeRefMutableBean codeRef= new CodeRefMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonIdentifiableUtil.processBean(codeRef, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("codes")) {
				codeRef.setCodeRefs(processHCodes(jReader));
			} else {
				String value = jReader.getValueAsString();
				if (fieldName.equals("id")) {
					codeRef.setId(value);
				} else if (fieldName.equals("code")) {
					codeRef.setCodeReference(new StructureReferenceBeanImpl(value));
				} else if(fieldName.equals("validFrom")) {
					codeRef.setValidFrom(FusionJsonDateUtil.readDate(jReader));
				}  else if(fieldName.equals("validTo")) {
					codeRef.setValidTo(FusionJsonDateUtil.readDate(jReader));
				}
			}
		}
		return codeRef;
	}

    @Override
    protected Class<HierarchyBean> getMaintainableType() {
        return HierarchyBean.class;
    }
}