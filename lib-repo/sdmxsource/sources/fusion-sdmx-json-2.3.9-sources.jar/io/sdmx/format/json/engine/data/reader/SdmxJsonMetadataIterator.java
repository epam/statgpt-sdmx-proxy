package io.sdmx.format.json.engine.data.reader;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;


public class SdmxJsonMetadataIterator extends AbstractIterator {
	private HeaderIterator headerIterator;
	private SdmxStructureIterator structureIterator;
	
//	private List<DataSetInformation> dataSetInformation = new ArrayList<SdmxJsonMetadataIterator.DataSetInformation>();
	
	public SdmxJsonMetadataIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	@Override
	public JsonReader.Iterator start(String fieldName, boolean isObject) {
		if("meta".equals(fieldName)) {
			headerIterator = new HeaderIterator(jReader, this.exceptionHandler);
			return headerIterator;
		} else if("structure".equals(fieldName)) {
			structureIterator = new SdmxStructureIterator(jReader, this.exceptionHandler);
			return structureIterator;
		} else if("dataSets".equals(fieldName)) {
			if(structureIterator != null) {
				//We have everything we need to read the dataset, stop the iterator
				jReader.stopIterating();
			}
			return null;
		} else if("erorrs".equals(fieldName)) {
			//TODO ERRROS?
		} else {
			//TODO UNKNOWN NODE
		}
		return null;
	}

	public HeaderIterator getHeaderIterator() {
		return headerIterator;
	}

	public SdmxStructureIterator getStructureIterator() {
		return structureIterator;
	}
}
