package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonMetadataflowReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<MetadataFlowBean, MetadataFlowMutableBean> implements IFusionSingleton {
	private static FusionJsonMetadataflowReaderEngine INSTANCE;

	public static FusionJsonMetadataflowReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataflowReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected MetadataFlowMutableBean getMutable() {
		return new MetadataflowMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, MetadataFlowMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("metadataStructureRef")) {
			String value = jReader.getValueAsString();
			StructureReferenceBean msdRef = new StructureReferenceBeanImpl(value);
			mutable.setMetadataStructureRef(msdRef);
		} else if (fieldName.equals("targets")) {
			for(String target : jReader.readStringArray()) {
				StructureReferenceBean targetRef = new StructureReferenceBeanImpl(target);
				mutable.addTarget(targetRef);
			}
		} else {
			return false;
		}
		return true;
	}

    @Override
    protected Class<MetadataFlowBean> getMaintainableType() {
        return MetadataFlowBean.class;
    }
}