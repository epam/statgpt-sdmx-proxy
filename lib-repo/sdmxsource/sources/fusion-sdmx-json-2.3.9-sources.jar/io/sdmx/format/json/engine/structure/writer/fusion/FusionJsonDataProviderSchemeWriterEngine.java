package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonDataProviderSchemeWriterEngine  extends FusionJsonItemSchemeWriterEngine<DataProviderSchemeBean> implements IFusionSingleton {
	private static FusionJsonDataProviderSchemeWriterEngine INSTANCE;

	public static FusionJsonDataProviderSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataProviderSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonDataProviderSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException {
		FusionJsonOrganisationWriterEngine.getInstance().writeStructure(jsonGenerator, (OrganisationBean) item);
	}
}
