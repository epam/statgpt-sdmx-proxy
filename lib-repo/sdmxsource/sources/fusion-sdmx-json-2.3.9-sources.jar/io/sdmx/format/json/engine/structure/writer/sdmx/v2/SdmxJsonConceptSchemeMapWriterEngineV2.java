package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonConceptSchemeMapWriterEngineV2 extends SdmxJsonItemSchemeMapWriterEngineV2<IConceptMapBean, IConceptSchemeMapBean> implements IFusionSingleton {
	private static SdmxJsonConceptSchemeMapWriterEngineV2 INSTANCE;

	public static SdmxJsonConceptSchemeMapWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonConceptSchemeMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonConceptSchemeMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME_MAP);
	}
}
