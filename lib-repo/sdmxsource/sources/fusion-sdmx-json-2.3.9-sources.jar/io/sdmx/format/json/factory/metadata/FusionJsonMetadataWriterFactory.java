package io.sdmx.format.json.factory.metadata;

import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataWriterFactory;
import io.sdmx.format.json.engine.metadata.fusion.FusionJsonMetadataWriterEngine;
import io.sdmx.format.json.model.FusionJsonMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonMetadataWriterFactory implements IMetadataWriterFactory, IFusionSingleton {
	private static FusionJsonMetadataWriterFactory INSTANCE;
	
	//Private constructor - lazy load instance
	public static FusionJsonMetadataWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static FusionJsonMetadataWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	public IMetadataWriterEngine getMetadataWriterEngine(IMetadataFormat outputFormat) {
		if(outputFormat == FusionJsonMetadataFormat.getInstance()) {
			return FusionJsonMetadataWriterEngine.getInstance();
		}
		return null;
	}
}
