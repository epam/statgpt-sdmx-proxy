package io.sdmx.format.json.engine.structure.reader.util;

import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.changecontrol.MaintainableMutableBeanWrapper;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonMaintainableUtil {

	public static boolean processBean(MaintainableMutableBeanWrapper mmbWrapper, JsonReader jReader) {
		return FusionJsonNameableUtil.processBean(mmbWrapper.getMaintainableMutableBean(), jReader) || processAttributes(mmbWrapper, jReader);
	}

	private static boolean processAttributes(MaintainableMutableBeanWrapper mmbWrapper, JsonReader jReader) {
	    MaintainableMutableBean maint = mmbWrapper.getMaintainableMutableBean();
		String fieldName = jReader.getCurrentFieldName();
		String value = jReader.getValueAsString();

		if (fieldName.equals("externalReference")) {
			maint.setExternalReference(Boolean.parseBoolean(value));
			return true;
		}
		if (fieldName.equals("agencyId")) {
			maint.setAgencyId(value);
			return true;
		}
		if (fieldName.equals("isFinal")) {
			maint.setFinalStructure( Boolean.parseBoolean(value) );
			return true;
		}
		if (fieldName.equals("version")) {
			maint.setVersion(value);
			return true;
		}
		if (fieldName.equals("startDate")) {
			maint.setStartDate(FusionJsonDateUtil.readDate(jReader));
			return true;
		} 
		if (fieldName.equals("endDate")) {
			maint.setEndDate(FusionJsonDateUtil.readDate(jReader));
			return true;
		} 
		if (fieldName.equals("serviceURL")) {
			maint.setServiceURL(value);
			maint.setExternalReference(true);
			return true;
		}
		if (fieldName.equals("structureURL")) {
			maint.setStructureURL(value);
			if(!(maint instanceof AgencySchemeMutableBean)) {
				maint.setExternalReference(true);
			}
			return true;
		}
		if (fieldName.equals("oldAgencyId")) {
            mmbWrapper.setOldAgencyId(value);
            return true;
        }
        if (fieldName.equals("oldId")) {
            mmbWrapper.setOldId(value);
            return true;
        }
        if (fieldName.equals("oldVersion")) {
            mmbWrapper.setOldVersion(value);
            return true;
        }
		return false;
	}
}