package io.sdmx.format.json.engine.structure.reader.util;

import java.math.BigDecimal;
import java.math.BigInteger;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonRepresentationUtil {
	
	public static RepresentationMutableBean readRepresentation(JsonReader jReader, boolean isJsonVersion2) {
		RepresentationMutableBean representation = new RepresentationMutableBeanImpl();
		readRepresentation(representation, jReader, isJsonVersion2);
		return representation;
	}

	public static void readRepresentation(RepresentationMutableBean representation, JsonReader jReader, boolean isJsonVersion2) {
		String fieldName;
		String value;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "format" :
			case "textFormat" :
			case "enumerationFormat" :
				representation.setTextFormat(readTextFormat(jReader, isJsonVersion2));
				break;
			case "enumeration" :
				value = jReader.getValueAsString();
				if(ObjectUtil.validString(value)) {
					StructureReferenceBean representationRef = new StructureReferenceBeanImpl(value);
					representation.setRepresentation(representationRef);
				}
				break;
			case "minOccurs" :
				representation.setMinOccurs(jReader.getValueAsInt());
				break;
			case "maxOccurs" :
				representation.setMaxOccurs(jReader.getValueAsInt());
				break;
			}
		}
	}

	public static TextFormatMutableBean readTextFormat(JsonReader jReader, boolean isJsonVersion2) {
		TextFormatMutableBean tf = new TextFormatMutableBeanImpl();
		String fieldName;
		String value;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			fieldName = jReader.getCurrentFieldName();
			value = jReader.getValueAsString();
			switch(fieldName) {
			case "dataType":
				// This is only valid for SDMX-JSON V2
				if (!isJsonVersion2) {
					throw new SdmxSemmanticException("'dataType' is not a valid field for SdmxJson version 1");
				}
				tf.setTextType(TEXT_TYPE.parseString(value));
				break;
			case "textType":
				// Strictly this is only valid for SDMX-JSON V1 but allow this for V2 for leniency
				tf.setTextType(TEXT_TYPE.parseString(value));
				break;
			case "startTime":
				tf.setStartTime(DateUtil.formatDate(value, true));
				break;
			case "endTime":
				tf.setEndTime(DateUtil.formatDate(value, false));
				break;
			case "isSequence":
				tf.setSequence(TERTIARY_BOOL.parseBoolean(Boolean.valueOf(value)));
				break;
			case "minLength":
				tf.setMinLength(new BigInteger(value));
				break;
			case "maxLength":
				tf.setMaxLength(new BigInteger(value));
				break;
			case "startValue":
				tf.setStartValue(new BigDecimal(value));
				break;
			case "endValue":
				tf.setEndValue(new BigDecimal(value));
				break;
			case "maxValue":
				tf.setMaxValue(new BigDecimal(value));
				break;
			case "minValue":
				tf.setMinValue(new BigDecimal(value));
				break;
			case "interval":
				tf.setInterval(new BigDecimal(value));
				break;
			case "timeInterval":
				tf.setTimeInterval(value);
				break;
			case "decimals":
				tf.setDecimals(new BigInteger(value));
				break;
			case "pattern":
				tf.setPattern(value);
				break;
			case "isMultiLingual":
				tf.setMultiLingual(TERTIARY_BOOL.parseBoolean(Boolean.valueOf(value)));
				break;
			}
		}
		return tf;
	}
}
