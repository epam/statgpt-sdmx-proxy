package io.sdmx.format.json.engine.structure.writer;

import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.engine.ErrorWriterEngine;
import io.sdmx.api.sdmx.model.error.ISdmxError;
import io.sdmx.utils.core.object.ObjectUtil;

public class JsonErrorWriterEngine implements ErrorWriterEngine {
	public static final JsonErrorWriterEngine INSTANCE = new JsonErrorWriterEngine();
	
	private JsonErrorWriterEngine() {}
	
	@Override
	public void writeError(ISdmxError sdmxError, OutputStream out) {
		StringBuilder sb = new StringBuilder();
		String previousMessage = "";
		for(String currentMsg : sdmxError.getErrorMessage()) {
			if (!ObjectUtil.validString(previousMessage)) {
				sb.append(currentMsg);
			} else if(!currentMsg.equals(previousMessage)) {
				sb.append(System.getProperty("line.separator") + currentMsg);
			}
		}
		writeError(out, sdmxError.getSDMXCode(), sb.toString());
	}

	@Override
	public int writeError(Throwable th, OutputStream out) {
		int statusCode;
		if(th instanceof SdmxException) {
			SdmxException ex = (SdmxException)th;
			statusCode  = ex.getHttpRestErrorCode();
		} else {
			th.printStackTrace(System.err);
			statusCode = 500;
		}
		writeError(out, statusCode, processThrowable(th));
		return statusCode;
	}
	
	private void writeError(OutputStream out, int code, String message) {
		try {
			JSONObject response = new JSONObject();
			JSONArray errors = new JSONArray();
			response.put("errors", errors);
			JSONObject error = new JSONObject();
			error.put("code", code);
			error.put("message", message);
			errors.put(error);

			out.write(response.toString().getBytes("UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	private String processThrowable(Throwable th2) {
		StringBuilder sb = new StringBuilder();
		String previousMessage = "";
		while(th2 != null) {
			String newMessage = th2.getMessage();
			if(newMessage == null) {
				newMessage = "Null Pointer";
			} else if(newMessage.contains("Exception: ")) {
				newMessage = newMessage.split("Exception: ")[1];
			}

			if (!ObjectUtil.validString(previousMessage)) {
				sb.append(newMessage);
			} else if(!newMessage.equals(previousMessage)) {
				sb.append(System.getProperty("line.separator") + newMessage);
			}
			previousMessage = newMessage;
			th2 = th2.getCause();
		}

		return sb.toString();
	}
}
