package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonDataProviderSchemeReaderEngine extends FusionJsonOrganisationSchemeReaderEngine<DataProviderSchemeBean, DataProviderSchemeMutableBean, DataProviderMutableBean> implements IFusionSingleton {
	private static FusionJsonDataProviderSchemeReaderEngine INSTANCE;

	public static FusionJsonDataProviderSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataProviderSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected DataProviderMutableBean readItemBean(JsonReader jReader) {
		DataProviderMutableBean item = new DataProviderMutableBeanImpl();
		populateOrganisationMutableBean(jReader, item);
		return item;
	}

	@Override
	protected DataProviderSchemeMutableBean getMutable() {
		return new DataProviderSchemeMutableBeanImpl();
	}

    @Override
    protected Class<DataProviderSchemeBean> getMaintainableType() {
        return DataProviderSchemeBean.class;
    }
}