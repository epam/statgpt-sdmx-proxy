package io.sdmx.format.json.engine.structure.reader.util;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonComponentUtil {

	public static boolean processBean(ComponentMutableBean bean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		if(FusionJsonIdentifiableUtil.processBean(bean, jReader)) {
			return true;
		}

		if(fieldName.equals("mandatory")) {
			Boolean isMandatory = jReader.getValueAsBoolean();
			bean.setMandatory(isMandatory);
		} else if(fieldName.equals("representation")) {
			RepresentationMutableBean representation = bean.getRepresentation();
			if(representation == null) {
				representation = new RepresentationMutableBeanImpl();
				bean.setRepresentation(representation);
			}
			FusionJsonRepresentationUtil.readRepresentation(representation, jReader);
			return true;
		} else if (fieldName.equals("concept")) {
			StructureReferenceBean conceptRef = new StructureReferenceBeanImpl(jReader.getValueAsString());
			bean.setConceptRef(conceptRef);
			return true;
		}
		return false;
	}
}
