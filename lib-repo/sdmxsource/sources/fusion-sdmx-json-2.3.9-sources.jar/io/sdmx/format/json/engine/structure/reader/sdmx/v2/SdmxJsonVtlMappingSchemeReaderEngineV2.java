package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.VtlCodelistMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlConceptMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlDataflowMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlMappingSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonVtlMappingSchemeReaderEngineV2  extends SdmxJsonItemSchemeReaderEngineV2<IVtlMappingMutableBean, IVtlMappingSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonVtlMappingSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonVtlMappingSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonVtlMappingSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    public String getContainerElement() {
        return "vtlMappingSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IVtlMappingSchemeBean.class;
    }

    @Override
    protected IVtlMappingSchemeMutableBean getMutable() {
        return new VtlMappingSchemeMutableBean();
    }
    
	@Override
	protected List<IVtlMappingMutableBean> readItems(JsonReader jReader) {
		List<IVtlMappingMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				IVtlMappingMutableBean mutable = readMapping(jReader);
				returnList.add(mutable);
			}
		}
		return returnList;
	}
	
	private IVtlMappingMutableBean readMapping(JsonReader jReader) {
		VtlDataflowMappingMutableBean mutable = new VtlDataflowMappingMutableBean();
		
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(mutable, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "dataflow" :
			case "codelist" :
			case "concept" :
				mutable.setMapped(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			case "fromVtlMapping" :
				readDataflowMapping(jReader, mutable, true);
				break;
			case "toVtlMapping" :
				readDataflowMapping(jReader, mutable, false);
				break;
			case "alias" :
				mutable.setAlias(jReader.getValueAsString());
				break;
			}
		}
		
		IVtlMappingMutableBean returnMapping = null;
		if(mutable.getMapped() != null) {
			switch(mutable.getMapped().getTargetReference()) {
			case CODE_LIST :
				returnMapping = new VtlCodelistMappingMutableBean();
				break;
			case CONCEPT :
				returnMapping = new VtlConceptMappingMutableBean();
				break;
			}
		}
		if(returnMapping == null) {
			returnMapping = mutable;
		} else {
			returnMapping.setAlias(mutable.getAlias());
			returnMapping.setAnnotations(mutable.getAnnotations());
			returnMapping.setDescriptions(mutable.getDescriptions());
			returnMapping.setId(mutable.getId());
			returnMapping.setLinks(mutable.getLinks());
			returnMapping.setMapped(mutable.getMapped());
			returnMapping.setNames(mutable.getNames());
			returnMapping.setOldId(mutable.getOldId());
			returnMapping.setUri(mutable.getUri());
		}
		return returnMapping;
	}
	
	private void readDataflowMapping(JsonReader jReader, VtlDataflowMappingMutableBean mutable, boolean isFrom) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "method" :
				if(isFrom) {
					mutable.setFromMethod(jReader.getValueAsString());
				} else {
					mutable.setToMethod(jReader.getValueAsString());
				}
				break;
			case "fromVtlSuperSpace" :
				jReader.moveNextStartArray();
				mutable.setFromSubSpace(jReader.readStringArray());
				jReader.moveToEndObject();
				break;
			case "toVtlSubSpace" :
				jReader.moveNextStartArray();
				mutable.setToSubSpace(jReader.readStringArray());
				jReader.moveToEndObject();
				break;
			}
		}
	}

	@Override
	protected String getItemLabel() {
		return "vtlMappings";
	}
}