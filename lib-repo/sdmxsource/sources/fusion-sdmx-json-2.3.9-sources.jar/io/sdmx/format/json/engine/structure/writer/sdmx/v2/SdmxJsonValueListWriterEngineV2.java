package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;


public class SdmxJsonValueListWriterEngineV2  extends SdmxJsonMaintainableStructureWriterEngineV2<ValueListBean> implements IFusionSingleton {
	private static SdmxJsonValueListWriterEngineV2 INSTANCE;

	public static SdmxJsonValueListWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonValueListWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonValueListWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VALUE_LIST);
	}

	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ValueListBean identifiable) throws JsonGenerationException, IOException {
		List<ValueItemBean> items = identifiable.getItems();
		writeItems(jsonGenerator, externalLinks, items);
	}
	
	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<ValueItemBean> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("valueItems");
		for(ValueItemBean currentItem : items) {
			writeItem(jsonGenerator, externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}
	
	protected void writeItem(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ValueItemBean currentItem) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		SdmxJsonStaticHelper.writeNameable(jsonGenerator, currentItem);
		writeItemDetails(jsonGenerator, externalLinks, currentItem);
		jsonGenerator.writeEndObject();
	}

	private void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ValueItemBean item) throws JsonGenerationException, IOException {
		if(item.getId() != null) {
			jsonGenerator.writeStringField("id", item.getId());
		}
	}

}