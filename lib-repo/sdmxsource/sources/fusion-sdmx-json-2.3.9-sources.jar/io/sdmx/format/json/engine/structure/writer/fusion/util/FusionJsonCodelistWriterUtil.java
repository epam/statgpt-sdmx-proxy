package io.sdmx.format.json.engine.structure.writer.fusion.util;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.utils.core.object.ObjectUtil;

import com.fasterxml.jackson.core.JsonGenerator;

public class FusionJsonCodelistWriterUtil {

	public static void writeInheritence(JsonGenerator jsonGenerator, CodelistBean codelist) throws IOException {
		if(codelist.isInherited()) {
			jsonGenerator.writeBooleanField("inheritanceResolved", true);
		}
		if(ObjectUtil.validCollection(codelist.getInheritedCodelists())) {
			jsonGenerator.writeArrayFieldStart("extends");
			for(ICodelistInheritanceRuleBean clInheritance : codelist.getInheritedCodelists()) {
				writeInheritanceRuleBean(clInheritance, jsonGenerator);
			}
			jsonGenerator.writeEndArray();
		}
	}

	
	private static void writeInheritanceRuleBean(ICodelistInheritanceRuleBean rule, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		if(rule.getPrefix() != null) {
			jsonGenerator.writeStringField("prefix", rule.getPrefix());
		}
		jsonGenerator.writeStringField("codelistRef", rule.getCodelistRef().getTargetUrn());
		writeInheritanceMembers(rule.getInclusiveInheritenceIds(), rule.getInclusiveInheritenceCascades(), true, jsonGenerator);
		writeInheritanceMembers(rule.getExclusiveInheritenceIds(), rule.getExclusiveInheritenceCascades(), false, jsonGenerator);
		jsonGenerator.writeEndObject();
	}
	
	private static void writeInheritanceMembers(List<String> members, Set<String> cascade, boolean included, JsonGenerator writer) throws IOException {
		if(ObjectUtil.validCollection(members)) {
			String elementName = included ? "include" : "exclude";
			writer.writeObjectFieldStart(elementName);
			JsonWriterUtil.writeStringArray(writer, "values", members);
			JsonWriterUtil.writeStringArray(writer, "cascade", cascade);
			writer.writeEndObject();
		}
	}
}
