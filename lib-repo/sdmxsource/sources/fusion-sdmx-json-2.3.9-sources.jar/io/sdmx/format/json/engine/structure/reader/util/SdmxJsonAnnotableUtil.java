package io.sdmx.format.json.engine.structure.reader.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonAnnotableUtil {

	public static boolean processBean(AnnotableMutableBean bean, JsonReader jReader) {
		return doIt(bean, jReader) || SdmxJsonLinkableUtil.processBean(bean, jReader);

	}
	
	public static boolean doIt(AnnotableMutableBean bean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		if (fieldName.equals("annotations")) {
			List<AnnotationMutableBean> readAnnotations = readAnnotations(jReader);
			for (AnnotationMutableBean anAnnotation : readAnnotations) {
				bean.addAnnotation(anAnnotation);
			}
			return true;
		}
		return false;
	}

	private static List<AnnotationMutableBean> readAnnotations(JsonReader jReader) {
		List<AnnotationMutableBean> returnList = new ArrayList<>();

		while (jReader.moveNext()) {
			if(jReader.isStartObject()) {
				// Build an AnnotableMutableBean
				AnnotationMutableBean annotationBean = buildAnnotation(jReader);
				returnList.add(annotationBean);
			}
			if(jReader.isEndArray()) {
				break;
			}
		}

		return returnList;
	}

	private static AnnotationMutableBean buildAnnotation(JsonReader jReader) {
		AnnotationMutableBean anAnnotation = new AnnotationMutableBeanImpl();
		String annotationText = null;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();

			if (fieldName.equals("title")) {
				anAnnotation.setTitle(value);
			} else if (fieldName.equals("id")) {
				anAnnotation.setId(value);
			} else if (fieldName.equals("type")) {
				anAnnotation.setType(value);
			} else if (fieldName.equals("links")) {
				 SdmxJsonLinkableUtil.processBean(anAnnotation, jReader);
//				anAnnotation.setUri(value);
			} else if (fieldName.equals("texts")) {
				List<TextTypeWrapperMutableBean> readTextTypeWrappers = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
				for (TextTypeWrapperMutableBean textTypeWrapperMutableBean : readTextTypeWrappers) {
					anAnnotation.addText(textTypeWrapperMutableBean);
				}
			} else if (fieldName.equals("text")) {
				annotationText = value;
			}
		}
		//If there was not a texts field, and there was a text field - then use the text field, otherwise do not
		if(annotationText != null && !ObjectUtil.validCollection(anAnnotation.getText())) {
			anAnnotation.addText("en", annotationText);
		}
		return anAnnotation;
	}
}