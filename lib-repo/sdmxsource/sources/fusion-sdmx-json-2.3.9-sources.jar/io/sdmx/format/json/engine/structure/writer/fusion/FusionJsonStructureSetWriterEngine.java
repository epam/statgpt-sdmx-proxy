package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.mapping.SchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;


public class FusionJsonStructureSetWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<StructureSetBean> implements IFusionSingleton {
	private static FusionJsonStructureSetWriterEngine INSTANCE;

	public static FusionJsonStructureSetWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureSetWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonStructureSetWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_SET);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, StructureSetBean constraint) throws JsonGenerationException, IOException {
		writeStructureMaps(jsonGenerator, constraint.getStructureMapList());
		writeCodelistMaps(jsonGenerator, constraint.getCodelistMapList());
		writeConceptSchemeMaps(jsonGenerator, constraint.getConceptSchemeMapList());
		writeCategorySchemeMaps(jsonGenerator, constraint.getCategorySchemeMapList());
		writeOrganisationSchemeMaps(jsonGenerator, constraint.getOrganisationSchemeMapList());
	}

	private void writeStructureMaps(JsonGenerator jsonGenerator, List<StructureMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("structureMaps");
			for(StructureMapBean currentMap : maps) {
				writeStructureMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeStructureMap(JsonGenerator jsonGenerator, StructureMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		writeSchemeMap(jsonGenerator, map);
		jsonGenerator.writeArrayFieldStart("componentMap");
		for(ComponentMapBean componentMap : map.getComponents()) {
			writeComponentMap(jsonGenerator, componentMap);
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	private void writeComponentMap(JsonGenerator jsonGenerator, ComponentMapBean compMap) throws IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, compMap);

		jsonGenerator.writeArrayFieldStart("sources");
		for(String source : compMap.getMapConceptRef()) {
			jsonGenerator.writeString(source);
		}
		jsonGenerator.writeEndArray();

		jsonGenerator.writeArrayFieldStart("targets");
		for(String source : compMap.getMapTargetConceptRef()) {
			jsonGenerator.writeString(source);
		}
		jsonGenerator.writeEndArray();

		if(compMap.getRepMapRef() != null) {
			RepresentationMapRefBean repMap = compMap.getRepMapRef();
			if(ObjectUtil.validMap(repMap.getValueMappings())) {
				writeValueMap(jsonGenerator, repMap.getValueMappings());
			}
			if(repMap.getCodelistMap() != null) {
				jsonGenerator.writeStringField("codelistRef", repMap.getCodelistMap().getId());
			}
		}
		jsonGenerator.writeEndObject();
	}

	private void writeValueMap(JsonGenerator jsonGenerator, Map<String, Set<String>>  valueMap) throws IOException {
		jsonGenerator.writeObjectFieldStart("valueMap");
		for(String key : valueMap.keySet()) {
			jsonGenerator.writeArrayFieldStart(key);
			for (String currentValue : valueMap.get(key)) {
				jsonGenerator.writeString(currentValue);
			}
			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndObject();
	}

	private void writeCodelistMaps(JsonGenerator jsonGenerator, List<CodelistMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("codelistMaps");
			for(CodelistMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeConceptSchemeMaps(JsonGenerator jsonGenerator, List<ConceptSchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("conceptSchemeMaps");
			for(ConceptSchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeCategorySchemeMaps(JsonGenerator jsonGenerator, List<CategorySchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("categoryMaps");
			for(CategorySchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeOrganisationSchemeMaps(JsonGenerator jsonGenerator, List<OrganisationSchemeMapBean> maps) throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("organisationMaps");
			for(OrganisationSchemeMapBean currentMap : maps) {
				writeItemSchemeMap(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();

		}
	}

	private void writeItemMapBean(JsonGenerator jsonGenerator, List<ItemMapBean> itemBean) throws IOException{
		jsonGenerator.writeArrayFieldStart("itemMap");
		for (ItemMapBean currentItemMap : itemBean) {
			jsonGenerator.writeStartObject();
			FusionJsonStaticHelper.writeAnnotable(jsonGenerator, currentItemMap);
			String src = currentItemMap.getSourceId();
			String tgt = currentItemMap.getTargetId();
			jsonGenerator.writeStringField("src", src);
			jsonGenerator.writeStringField("tgt", tgt);
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeItemSchemeMap(JsonGenerator jsonGenerator, ItemSchemeMapBean map) throws IOException {
		jsonGenerator.writeStartObject();
		writeSchemeMap(jsonGenerator, map);
		writeItemMapBean(jsonGenerator, map.getItems());
		/*Map<String, Set<String>>  itemMap = new HashMap<String, Set<String>>();
		for(ItemMapBean currentItemMap : map.getItems()) {
			String src = currentItemMap.getSourceId();
			String tgt = currentItemMap.getTargetId();

			Set<String> targets = itemMap.get(src);
			if(targets == null) {
				targets = new HashSet<String>();
				itemMap.put(src, targets);
			}
			targets.add(tgt);
		}
		jsonGenerator.writeObjectFieldStart("itemMap");
		for(String key : itemMap.keySet()) {
			jsonGenerator.writeArrayFieldStart(key);
			for (String currentValue : itemMap.get(key)) {
				jsonGenerator.writeString(currentValue);
			}
			jsonGenerator.writeEndArray();
		}*/
		jsonGenerator.writeEndObject();

		//jsonGenerator.writeEndObject();
	}

	private void writeSchemeMap(JsonGenerator jsonGenerator, SchemeMapBean schemeMap) throws IOException {
		FusionJsonStaticHelper.writeNameable(jsonGenerator, null, schemeMap);
		jsonGenerator.writeStringField("source", schemeMap.getSourceRef().getTargetUrn());
		jsonGenerator.writeStringField("target", schemeMap.getTargetRef().getTargetUrn());
	}
}
