package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonDataConsumerSchemeReaderEngineV2 extends SdmxJsonOrganisationSchemeReaderEngineV2<DataConsumerMutableBean, DataConsumerSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonDataConsumerSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonDataConsumerSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataConsumerSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "dataConsumerSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return DataConsumerSchemeBean.class;
    }

    @Override
    protected DataConsumerSchemeMutableBean getMutable() {
        return new DataConsumerSchemeMutableBeanImpl();
    }

	@Override
	protected List<DataConsumerMutableBean> readItems(JsonReader jReader) {
		List<DataConsumerMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				DataConsumerMutableBean aDC = new DataConsumerMutableBeanImpl();
				populateOrganisationMutableBean(jReader, aDC);
				returnList.add(aDC);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "dataConsumers";
	}
}
