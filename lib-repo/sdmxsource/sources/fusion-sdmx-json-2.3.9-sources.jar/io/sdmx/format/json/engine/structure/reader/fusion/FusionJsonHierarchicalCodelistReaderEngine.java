package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonDateUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonRepresentationUtil;
import io.sdmx.im.mutable.codelist.HierarchicalCodelistMutableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodelistRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonHierarchicalCodelistReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<HierarchyBean, HierarchicalCodelistMutableBean> implements IFusionSingleton {
    private static final String THREAD_LOCAL_KEY2 = "_ALIAS_LIST_";

    private static FusionJsonHierarchicalCodelistReaderEngine INSTANCE;

    public static FusionJsonHierarchicalCodelistReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FusionJsonHierarchicalCodelistReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    protected HierarchicalCodelistMutableBean getMutable() {
        return new HierarchicalCodelistMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, HierarchicalCodelistMutableBean mutable,
            JsonReader reader) {

        switch(fieldName) {
        case "codelistRef":
            processCodelistReferences(reader, mutable);
            return true;
        case "hierarchies":
            mutable.setHierarchies(processHierarchies(reader));
            return true;
        }
        return false;
    }

    @Override
    protected HierarchicalCodelistMutableBean build(JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
        List<StructureReferenceBeanImpl> storedRefs = new ArrayList<>();
        ThreadLocalUtil.storeOnThread(THREAD_LOCAL_KEY2, storedRefs);
        try {
            HierarchicalCodelistMutableBean mutable = super.build(jReader, beanRetrievalManager);
            if(storedRefs.size() > 0) {
                for(StructureReferenceBeanImpl storedRef : storedRefs) {
                    String alias = storedRef.getMaintainableId().toUpperCase();
                    Map<String, StructureReferenceBean> codeAliasMap = mutable.getCodelistRef().stream().collect(Collectors.toMap(e->e.getAlias(), e->e.getCodelistReference()));
                    if(codeAliasMap != null) {
                        StructureReferenceBean clRef = codeAliasMap.get(alias);
                        if(clRef == null) {
                            throw new SdmxSemmanticException("Hierarchical Codelist reference not found by alias: " +alias);
                        }
                        storedRef.setAgencyId(clRef.getAgencyId());
                        storedRef.setMaintainableId(clRef.getMaintainableId());
                        storedRef.setVersion(clRef.getVersion());
                    }
                }
            }
            return mutable;
        } finally {
            ThreadLocalUtil.clearFromThread(THREAD_LOCAL_KEY2);
        }
    }

    /**
     * @param jReader
     * @return alias to codelist reference
     */
    private void processCodelistReferences(JsonReader jReader, HierarchicalCodelistMutableBean mutable) {
        while (jReader.moveNext()) {
            if(jReader.isStartObject()) {
                processCodelistReference(jReader, mutable);
            }
            if(jReader.isEndArray()) {
                break;
            }

        }
    }

    /**
     * @param jReader
     * @return
     */
    private void processCodelistReference(JsonReader jReader, HierarchicalCodelistMutableBean mutable) {
        String alias = null;
        StructureReferenceBean sRef = null;
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String fieldName = jReader.getCurrentFieldName();
            String value = jReader.getValueAsString();
            if (fieldName.equals("alias")) {
                alias = value.toUpperCase();
            } else if (fieldName.equals("structureReference")) {
                sRef = new StructureReferenceBeanImpl(value);
            }
        }
        if(alias != null && sRef != null) {
            CodelistRefMutableBean clRef = new CodelistRefMutableBeanImpl();
            clRef.setAlias(alias.toUpperCase());
            clRef.setCodelistReference(sRef);
            mutable.addCodelistRef(clRef);
        }
    }

    private List<HierarchyMutableBean> processHierarchies(JsonReader jReader) {
        List<HierarchyMutableBean> hierarchies = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isStartObject()) {
                hierarchies.add(processHierarchy(jReader));
            }
            if(jReader.isEndArray()) {
                break;
            }
        }
        return hierarchies;
    }

    private HierarchyMutableBean processHierarchy(JsonReader jReader) {
        HierarchyMutableBean hierarchy = new HierarchyMutableBeanImpl();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            FusionJsonNameableUtil.processBean(hierarchy, jReader);
            FusionJsonAnnotableUtil.processBean(hierarchy, jReader);

            String fieldName = jReader.getCurrentFieldName();
            String value = jReader.getValueAsString();
            if (fieldName.equals("formalLevels")) {
                boolean bValue = Boolean.parseBoolean(value);
                hierarchy.setFormalLevels(bValue);
            } else if (fieldName.equals("levels")) {
                readLevel(hierarchy, jReader);
            } else if (fieldName.equals("codes")) {
                hierarchy.setHierarchicalCodeBeans(processHCodes(jReader));
            }
        }
        return hierarchy;
    }

    private void readLevel(HierarchyMutableBean hie, JsonReader jReader) {
        LevelMutableBean level = null;
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            if (jReader.isStartObject()) {
                LevelMutableBean newLevel = readLevel(jReader);
                if(level == null) {
                    hie.setChildLevel(newLevel);
                } else {
                    level.setChildLevel(newLevel);
                }
                level = newLevel;
            }
        }
    }

    private LevelMutableBean readLevel(JsonReader jReader) {
        LevelMutableBean level = new LevelMutableBeanImpl();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            if(FusionJsonNameableUtil.processBean(level, jReader)) {
                continue;
            }
            if (jReader.getCurrentFieldName().equals("textFormat")) {
                level.setCodingFormat(FusionJsonRepresentationUtil.readTextFormat(jReader));
            }
        }
        return level;
    }


    private List<CodeRefMutableBean> processHCodes(JsonReader jReader) {
        List<CodeRefMutableBean> codeRefs = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isStartObject()) {
                codeRefs.add(processCode(jReader));
            }
            if(jReader.isEndArray()) {
                break;
            }
        }
        return codeRefs;
    }

    private CodeRefMutableBean processCode(JsonReader jReader) {
        CodeRefMutableBean codeRef= new CodeRefMutableBeanImpl();

        String codelistAlias = null;
        String codeId = null;
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            FusionJsonIdentifiableUtil.processBean(codeRef, jReader);

            String fieldName = jReader.getCurrentFieldName();
            if(fieldName.equals("codes")) {
                codeRef.setCodeRefs(processHCodes(jReader));
            } else {
                String value = jReader.getValueAsString();
                if (fieldName.equals("level")) {
                    codeRef.setLevelReference(value);
                } else if (fieldName.equals("codeReference")) {
                    codeRef.setCodeReference(new StructureReferenceBeanImpl(value));
                } else if(fieldName.equals("validFrom")) {
                    codeRef.setValidFrom(FusionJsonDateUtil.readDate(jReader));
                }  else if(fieldName.equals("validTo")) {
                    codeRef.setValidTo(FusionJsonDateUtil.readDate(jReader));
                }else if(fieldName.equals("codelistAliasRef")) {
                    codelistAlias = value.toUpperCase();
                } else if(fieldName.equals("codeId")) {
                    codeId = value;
                } else if(fieldName.equals("id")) {
                    codeRef.setId(value);
                }
            }
        }
        if(codeRef.getCodeReference() == null && codelistAlias != null) {
            //Placeholder to say it is an alias
            List<StructureReferenceBean> storedRefs = (List<StructureReferenceBean>) ThreadLocalUtil.retrieveFromThread(THREAD_LOCAL_KEY2);
            StructureReferenceBean partialRef = new StructureReferenceBeanImpl(null, codelistAlias, "1.0", SDMX_STRUCTURE_TYPE.CODE, codeId);
            storedRefs.add(partialRef);
            codeRef.setCodeReference(partialRef);
        }
        return codeRef;
    }

    @Override
    public String getContainerElement() {
        return "hierarchicalCodelist";
    }

    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(HierarchyBean.class);
    }

    @Override
    protected Class<HierarchyBean> getMaintainableType() {
        return HierarchyBean.class;
    }
}