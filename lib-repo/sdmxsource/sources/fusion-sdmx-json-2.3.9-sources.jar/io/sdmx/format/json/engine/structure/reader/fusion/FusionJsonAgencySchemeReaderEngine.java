package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonAgencySchemeReaderEngine extends FusionJsonOrganisationSchemeReaderEngine<AgencySchemeBean, AgencySchemeMutableBean, AgencyMutableBean> implements IFusionSingleton {

    private static FusionJsonAgencySchemeReaderEngine INSTANCE;

	public static FusionJsonAgencySchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonAgencySchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	protected AgencyMutableBean readItemBean(JsonReader jReader) {
		AgencyMutableBean anAgency = new AgencyMutableBeanImpl();
		populateOrganisationMutableBean(jReader, anAgency);
		return anAgency;
	}

	@Override
	protected AgencySchemeMutableBean getMutable() {
		return new AgencySchemeMutableBeanImpl();
	}

    @Override
    protected Class<AgencySchemeBean> getMaintainableType() {
        return AgencySchemeBean.class;
    }
}