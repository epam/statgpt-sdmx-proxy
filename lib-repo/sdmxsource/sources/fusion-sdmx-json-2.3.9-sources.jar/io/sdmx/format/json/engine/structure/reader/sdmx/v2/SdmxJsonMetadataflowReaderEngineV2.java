package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.GenericJsonReaderUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonMetadataflowReaderEngineV2 extends AbstractSdmxJsonReaderEngine<MetadataFlowMutableBean> implements IFusionSingleton {
    private static SdmxJsonMetadataflowReaderEngineV2 INSTANCE;

    public static SdmxJsonMetadataflowReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxJsonMetadataflowReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "metadataflows";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return MetadataFlowBean.class;
    }

    @Override
    protected MetadataFlowMutableBean getMutable() {
        return new MetadataflowMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, MetadataFlowMutableBean mutable,
            JsonReader reader) {
        switch(fieldName) {
        case "structure" :
            String value = reader.getValueAsString();
            mutable.setMetadataStructureRef(new StructureReferenceBeanImpl(value));
            return true;
        case "targets" :
            mutable.setTargets(GenericJsonReaderUtil.readRefArray(reader));
            return true;
        }
        return false;
    }
}
