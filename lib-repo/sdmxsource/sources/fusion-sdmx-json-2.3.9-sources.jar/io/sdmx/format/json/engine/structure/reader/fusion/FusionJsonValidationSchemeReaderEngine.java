package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleHierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.expression.ValidationRuleHierarchyMutableBeanImpl;
import io.sdmx.im.mutable.expression.ValidationRuleMutableBeanImpl;
import io.sdmx.im.mutable.expression.ValidationSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonValidationSchemeReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<ValidationSchemeBean, ValidationSchemeMutableBean, ValidationRuleMutableBean> implements IFusionSingleton {
	private static FusionJsonValidationSchemeReaderEngine INSTANCE;

	public static FusionJsonValidationSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonValidationSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ValidationSchemeMutableBean getMutable() {
		return new ValidationSchemeMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ValidationSchemeMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			if(fieldName.equals("attachment")) {
				mutable.setAttachment(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			} else {
				return false;
			}
		}
		return true;
	}

	@Override
	protected ValidationRuleMutableBean readItemBean(JsonReader jReader) {
		ValidationRuleMutableBean aRule = new ValidationRuleMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(aRule, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if(fieldName.equals("expression")) {
				aRule.setExpression(value);
			} else if(fieldName.equals("equality")) {
				aRule.setEqualityOperator(EQUALITY.fromString(value));
			} else if(fieldName.equals("resultant")) {
				aRule.setResultant(value);
			} else if(fieldName.equals("validationHierarchy")) {
				ValidationRuleHierarchyMutableBean vh = processHierarchy(jReader);
				aRule.setHierarchyReference(vh);
			}
		}
		return aRule;
	}

	private ValidationRuleHierarchyMutableBean processHierarchy(JsonReader jReader) {
		ValidationRuleHierarchyMutableBean vh = new ValidationRuleHierarchyMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if(fieldName.equals("dimensionReference")) {
				vh.setDimensionReference(new StructureReferenceBeanImpl(value));
			}else if(fieldName.equals("hierarchyReference")) {
				vh.setHierarchyReference(new StructureReferenceBeanImpl(value));
			}
		}
		return vh;
	}

    @Override
    protected Class<ValidationSchemeBean> getMaintainableType() {
        return ValidationSchemeBean.class;
    }
}
