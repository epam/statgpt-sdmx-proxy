package io.sdmx.format.json.model;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;

public class FusionYAMLStructureFormat implements StructureFormat, IFusionSingleton {
	private static final long serialVersionUID = -197308335629163350L;
	private FormatDetails formatDetails = new FormatDetailsImpl("Fusion-YAML", MIME_TYPE.APPLICATION_YAML, false, "application/vnd.fusion.yml");

	private static FusionYAMLStructureFormat INSTANCE;
	private static final String asString = "FusionYAML";
	private FusionYAMLStructureFormat() {}

	public static FusionYAMLStructureFormat getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FusionYAMLStructureFormat();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public STRUCTURE_OUTPUT_FORMAT getSdmxOutputFormat() {
		return null;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	@Override
	public String getWebServiceFormat() {
		return "fusion-yaml";
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj == this;
	}

	@Override
	public String toString() {
		return asString;
	}
}
