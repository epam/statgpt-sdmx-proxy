package io.sdmx.format.json.engine.structure.reader.util;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean.COMPONENT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonStaticHelper {

	public static void writeRef(JsonGenerator jsonGenerator, ICrossReferenceBean<?> ref, String feildName)  throws JsonGenerationException, IOException {
		if(ref != null) {
			jsonGenerator.writeStringField(feildName, ref.getTargetUrn());
		}
	}

	public static void writeRefs(JsonGenerator jsonGenerator, Collection<ICrossReferenceBean<?>> refs, String feildName)  throws JsonGenerationException, IOException {
		if(refs != null) {
			jsonGenerator.writeArrayFieldStart(feildName);
			for(ICrossReferenceBean<?> ref : refs) {
				if(ref == null) {
					jsonGenerator.writeNull();
				} else {
					jsonGenerator.writeString(ref.getTargetUrn());
				}
			}
			jsonGenerator.writeEndArray();
		}
	}

	public static void writeStructure(JsonGenerator jsonGenerator, IdentifiableBean identifiable) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart(identifiable.getStructureType().getUrnClass());
		jsonGenerator.writeStringField("type", identifiable.getStructureType().getUrnClass());

		jsonGenerator.writeEndObject();
	}

	public static void writeIdentifiable(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IdentifiableBean identifiable) throws JsonGenerationException, IOException {
		jsonGenerator.writeStringField("id", identifiable.getId());
		// FR-651: The "Old" id needs to be passed back to the client and is the same as the existing id
		jsonGenerator.writeStringField("urn", identifiable.getUrn());
		if(identifiable.getUri() != null) {
			jsonGenerator.writeStringField("uri", identifiable.getUri().toString());
		}
		writeLinks(identifiable, externalLinks, jsonGenerator);
		writeAnnotable(jsonGenerator, identifiable);
	}
	
	public static void writeLinks(IdentifiableBean ident, IExternalMaintainableLinks externalLinks, JsonGenerator writer) throws IOException {
		Set<ILinkBean> links = externalLinks != null ? externalLinks.getLinks(ident.getURN()) : null;
		if(ObjectUtil.validCollection(links) || ident.getLinks().size() > 0) {
			writer.writeArrayFieldStart("links");
			writeLinks(links, writer);
			writeLinks(ident.getLinks(), writer);
			writer.writeEndArray();
		}
	}
	
	private static void writeLinks(Collection<ILinkBean> links, JsonGenerator writer) throws IOException {
		if(links != null) {
			for(ILinkBean link : links) {
				writer.writeStartObject();
				if(link.getRel() != null) {
					writer.writeStringField("rel", link.getRel());
				}
				if(link.getHRef() != null) {
					writer.writeStringField("href", link.getHRef().toString());
				}
				if(link.getUri() != null) {
					writer.writeStringField("uri", link.getUri().toString());
				}
				if(link.getUrn() != null) {
					writer.writeStringField("urn", link.getUrn().toString());
				}
				if(link.getType() != null) {
					writer.writeStringField("type", link.getType());
				}
				if(ObjectUtil.validCollection(link.getTitles(false))) {
					writeTextTypeWrapperArray(writer, link.getTitles(false), "titles");
				}
				writer.writeEndObject();
			}
		}
	}

	public static void writeAnnotable(JsonGenerator jsonGenerator, AnnotableBean annotable) throws JsonGenerationException, IOException {
		if (annotable.getAnnotations().size() > 0) {
			List<AnnotationBean> annotations = annotable.getAnnotations();
			jsonGenerator.writeArrayFieldStart("annotations");
			for (AnnotationBean annotationBean : annotations) {
				jsonGenerator.writeStartObject();
				writeNonNullString(jsonGenerator, "id", annotationBean.getId());

				String uriString;
				if (annotationBean.getUri() == null) {
					uriString = null;
				} else {
					uriString = annotationBean.getUri().toString();
				}
				writeNonNullString(jsonGenerator, "uri", uriString);
				writeNonNullString(jsonGenerator, "title", annotationBean.getTitle());
				writeNonNullString(jsonGenerator, "type", annotationBean.getType());

				if (annotationBean.getText() != null && annotationBean.getText().size() > 0) {
					jsonGenerator.writeArrayFieldStart("text");
					List<TextTypeWrapper> text = annotationBean.getText();
					for (TextTypeWrapper textTypeWrapper : text) {
						jsonGenerator.writeStartObject();
						jsonGenerator.writeStringField("locale", textTypeWrapper.getLocale());
						jsonGenerator.writeStringField("value", textTypeWrapper.getValue());
						jsonGenerator.writeBooleanField("isHtml", textTypeWrapper.isHtml());
						jsonGenerator.writeEndObject();
					}
					jsonGenerator.writeEndArray();
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
	}

	/**
	 * Only writes the value to the field if the value is not null
	 * @param jsonGenerator
	 * @param fieldName
	 * @param value
	 * @throws IOException
	 */
	private static void writeNonNullString(JsonGenerator jsonGenerator, String fieldName, String value) throws IOException {
		if (!ObjectUtil.validString(value)) {
			// Do nothing;
			return;
		}
		jsonGenerator.writeStringField(fieldName, value);
	}

	public static void writeNameable(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, NameableBean nameable) throws JsonGenerationException, IOException {
		writeIdentifiable(jsonGenerator, externalLinks, nameable);
		writeTextTypeWrapperArray(jsonGenerator, nameable.getNames(), "names");
		writeTextTypeWrapperArray(jsonGenerator, nameable.getDescriptions(), "descriptions");
	}

	public static void writeTextTypeBean(JsonGenerator jsonGenerator, String fieldName, TextTypeBean tt) throws JsonGenerationException, IOException {
		if(tt != null) {
			writeTextTypeWrapperArray(jsonGenerator, tt.getText(), fieldName);
		}
	}


	public static void writeTextTypeWrapperArray(JsonGenerator jsonGenerator, List<TextTypeWrapper> items, String arrayFieldName) throws JsonGenerationException, IOException {
		if (items.size() > 0) {
			jsonGenerator.writeArrayFieldStart(arrayFieldName);
			for (TextTypeWrapper anItem : items) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField("locale", anItem.getLocale());
				jsonGenerator.writeStringField("value", anItem.getValue());
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
	}

	public static void writeTexFormat(JsonGenerator jsonGenerator, TextFormatBean tf) throws JsonGenerationException, IOException {
		if(tf != null && (tf.getTextType()!=null || tf.hasRestrictions())) {
			jsonGenerator.writeObjectFieldStart("textFormat");
			if(tf.getTextType() != null) {
				jsonGenerator.writeStringField("textType", tf.getTextType().getSdmx21Value());
			}
			if(tf.getStartTime() != null) {
				jsonGenerator.writeStringField("startTime", tf.getStartTime().getDateInSdmxFormat());
			}
			if(tf.getEndTime() != null) {
				jsonGenerator.writeStringField("endTime", tf.getEndTime().getDateInSdmxFormat());
			}
			if(tf.getSequence() != null && tf.getSequence().isSet()) {
				jsonGenerator.writeBooleanField("sequence", tf.getSequence().isTrue());
			}
			if(tf.getMinLength() != null) {
				jsonGenerator.writeNumberField("minLength", tf.getMinLength().intValue());
			}
			if(tf.getMaxLength() != null) {
				jsonGenerator.writeNumberField("maxLength", tf.getMaxLength().intValue());
			}
			if(tf.getStartValue() != null) {
				jsonGenerator.writeStringField("startValue", tf.getStartValue().toPlainString());
			}
			if(tf.getEndValue() != null) {
				jsonGenerator.writeStringField("endValue", tf.getEndValue().toPlainString());
			}
			if(tf.getMaxValue() != null) {
				jsonGenerator.writeStringField("maxValue", tf.getMaxValue().toPlainString());
			}
			if(tf.getMinValue() != null) {
				jsonGenerator.writeStringField("minValue", tf.getMinValue().toPlainString());
			}
			if(tf.getInterval() != null) {
				jsonGenerator.writeStringField("interval", tf.getInterval().toPlainString());
			}
			if(tf.getTimeInterval() != null) {
				jsonGenerator.writeStringField("timeInterval", tf.getTimeInterval());
			}
			if(tf.getDecimals() != null) {
				jsonGenerator.writeNumberField("decimals", tf.getDecimals().intValue());
			}
			if(tf.getPattern() != null) {
				jsonGenerator.writeStringField("pattern", tf.getPattern());
			}
			if(tf.getMultiLingual() != null && tf.getMultiLingual().isSet()) {
				jsonGenerator.writeBooleanField("multiLingual", tf.getMultiLingual().isTrue());
			}
			jsonGenerator.writeEndObject();  // End Text Format
		}
	}

	public static void writeRepresentation(JsonGenerator jsonGenerator, RepresentationBean representation) throws IOException {
		if(representation == null) {
			return;
		}
		boolean isMetadataAttribute = false;
		if(representation.getIdentifiableParent() instanceof ComponentBean) {
			ComponentBean parent = (ComponentBean) representation.getIdentifiableParent();
			isMetadataAttribute = parent.getType() == COMPONENT_TYPE.METADATA_ATTRIBUE;
		}
		if(isMetadataAttribute && representation.getTextFormat() == null && representation.getRepresentation() == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("representation");
		if(!isMetadataAttribute) {
			if(representation.getMinOccurs() != null) {
				jsonGenerator.writeNumberField("minOccurs", representation.getMinOccurs());
			}
			if(representation.getMaxOccurs() != null) {
				jsonGenerator.writeNumberField("maxOccurs", representation.getMaxOccurs());
			}
		}
		FusionJsonStaticHelper.writeTexFormat(jsonGenerator, representation.getTextFormat());
		if(representation.getRepresentation() != null) {
			jsonGenerator.writeStringField("representation", representation.getRepresentation().getReference().getURN());
		}
		jsonGenerator.writeEndObject();
	}

}
