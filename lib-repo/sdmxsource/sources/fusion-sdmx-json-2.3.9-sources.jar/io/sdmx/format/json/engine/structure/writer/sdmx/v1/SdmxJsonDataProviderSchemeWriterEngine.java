package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonDataProviderSchemeWriterEngine extends SdmxJsonItemSchemeWriterEngine<DataProviderBean, DataProviderSchemeBean> implements IFusionSingleton {
	private static SdmxJsonDataProviderSchemeWriterEngine INSTANCE;

	public static SdmxJsonDataProviderSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataProviderSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonDataProviderSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataProviderBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);
	}

	@Override
	protected String getItemName() {
		return "dataProviders";
	}

}
