package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonRulesetSchemeWriterEngine extends FusionJsonAbstractVTLSchemeWriterEngine<IRulesetSchemeBean> implements IFusionSingleton {
	private static FusionJsonRulesetSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonRulesetSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME);
	}

	public static FusionJsonRulesetSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRulesetSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IRulesetSchemeBean maint) throws JsonGenerationException, IOException {
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		IRulesetBean item =  (IRulesetBean)itemBean;
		if(item.getRulesetType() != null) {
			jsonGenerator.writeStringField("rulesetType", item.getRulesetType());
		}
		if(item.getRulesetScope() != null) {
			jsonGenerator.writeStringField("rulesetScope", item.getRulesetScope());
		}
		if(item.getRulesetDefinition() != null) {
			jsonGenerator.writeStringField("rulesetDefinition", item.getRulesetDefinition());
		}
	}
}
