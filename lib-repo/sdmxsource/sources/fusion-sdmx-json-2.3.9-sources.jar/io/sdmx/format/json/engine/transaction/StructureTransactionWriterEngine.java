package io.sdmx.format.json.engine.transaction;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.core.sdmx.api.engine.structure.IStructureTransactionWriterEngine;
import io.sdmx.format.json.engine.AbstractJsonMetaAndDataWriter;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

public class StructureTransactionWriterEngine extends AbstractJsonMetaAndDataWriter<ITransactionalBeansEvent> implements IStructureTransactionWriterEngine {

    private static StructureTransactionWriterEngine INSTANCE;
	
	//Private constructor - lazy load instance
	public static StructureTransactionWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureTransactionWriterEngine();
		}
		return INSTANCE;
	}
	
	public StructureTransactionWriterEngine() {
        super(JSON_COMPATIBLE_FORMAT.JSON);
    }
	
	@Override
	public void writeTransaction(ITransactionalBeansEvent event, OutputStream out) {
		super.writeObject(event, out);
	}
	
	
	@Override
	protected void writeMeta(ITransactionalBeansEvent obj, JsonGenerator jsonWriter) throws IOException {
		jsonWriter.writeNumberField("txId", obj.getTransactionId());
	}


	@Override
	protected void writeData(ITransactionalBeansEvent event, JsonGenerator jsonWriter) {
		writeURNArray("del", event.getDeletions(), jsonWriter);
		writeURNArray("ins", event.getAdditions(), jsonWriter);
		writeURNArray("upd", event.getModification(), jsonWriter);
	}
	

	private void writeURNArray(String field, SdmxBeans beans, JsonGenerator writer) {
		JsonWriterUtil.writeStringArray(writer, field, SdmxCollectionUtil.urnsString(beans.getAllMaintainables()));
	}
}
