package io.sdmx.format.json.factory.metadata;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataFormatFactory;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.model.SdmxJsonMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonMetadataFormatFactory implements IMetadataFormatFactory, IFusionSingleton {
	private static SdmxJsonMetadataFormatFactory INSTANCE;

	private Map<String, FormatDetails> supportedFormats = new HashMap<>(1);
	
	//Private constructor - lazy load instance
	public static SdmxJsonMetadataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxJsonMetadataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	
	private SdmxJsonMetadataFormatFactory() {
		addSupportedFormat(SdmxJsonMetadataFormat.getInstance(SDMXJSON_VERSION.V2));
		this.supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}
	
	private void addSupportedFormat(IMetadataFormat format) {
		supportedFormats.put(format.getFormatDetails().getAcceptHeaders()[0], format.getFormatDetails());
	}

	@Override
	public Class<IMetadataFormat> getFormatClass() {
		return IMetadataFormat.class;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public IMetadataFormat getFormat(String format, Request request) {
		if(format.equals("sdmx-json")) {
			return SdmxJsonMetadataFormat.getInstance(SDMXJSON_VERSION.V2);
		}
		return null;
	}

	@Override
	public IMetadataFormat getFormat(Request request, IVNDHeader vndHeader) {
		String vnd = vndHeader.getVnd();
		boolean sdmxJson = vnd.startsWith("sdmx.metadata+json");
		if(!sdmxJson) {
			return null;
		}
		// If a version is specified is must be 1.0.0
		String version = vndHeader.getParameterValue("version");
		if (version == null) {
			version = "2.0.0";
		}
		if(version.equals("2.0.0")) {
			return SdmxJsonMetadataFormat.getInstance(SDMXJSON_VERSION.V2);
		} else {
			throw new SdmxNotAcceptableException("Unsupported sdmx-json version: " +version + ". Supported versions are 1.0.0, 2.0.0");
		}
	}
}
