package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonRepresentationUtil;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonConceptSchemeReaderEngineV1 extends SdmxJsonItemSchemeReaderEngineV1<ConceptMutableBean, ConceptSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonConceptSchemeReaderEngineV1 INSTANCE;

	public static SdmxJsonConceptSchemeReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonConceptSchemeReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	protected List<ConceptMutableBean> readItems(JsonReader jReader) {
		List<ConceptMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ConceptMutableBean aConcept = readConceptBean(jReader);
				returnList.add(aConcept);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "concepts";
	}

	private ConceptMutableBean readConceptBean(JsonReader jReader) {
		ConceptMutableBean aConcept = new ConceptMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			if(SdmxJsonNameableUtil.processBean(aConcept, jReader)) {
				continue;
			}

			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parent")) {
				aConcept.setParentConcept(value);
			} else if (fieldName.equals("coreRepresentation")) {
				aConcept.setCoreRepresentation(SdmxJsonRepresentationUtil.readRepresentation(jReader, false));
			} else if (fieldName.equals("isoConceptReference")) {
				aConcept.setIsoConceptReference(new StructureReferenceBeanImpl(value));
			}
			ValidityPeriodUtil.processValidityAnnotations(aConcept);
		}
		return aConcept;
	}

    @Override
    protected ConceptSchemeMutableBean getMutable() {
        return new ConceptSchemeMutableBeanImpl();
    }

    @Override
    public String getContainerElement() {
        return "conceptSchemes";
    }

    @Override
    protected Class<ConceptSchemeBean> getMaintainableType() {
        return ConceptSchemeBean.class;
    }
}
