package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.categoryscheme.ReportingCategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonReportingTaxonomyReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<ReportingTaxonomyBean, ReportingTaxonomyMutableBean, ReportingCategoryMutableBean> implements IFusionSingleton {
	private static FusionJsonReportingTaxonomyReaderEngine INSTANCE;

	public static FusionJsonReportingTaxonomyReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonReportingTaxonomyReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected ReportingTaxonomyMutableBean getMutable() {
		return new ReportingTaxonomyMutableBeanImpl();
	}

	@Override
	protected ReportingCategoryMutableBean readItemBean(JsonReader jReader) {
		ReportingCategoryMutableBean aCategory = new ReportingCategoryMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(aCategory, jReader);

			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "items" :
				aCategory.setItems(readItems(jReader));
				break;
			case "structuralMetadata" :
				aCategory.setStructuralMetadata(readRefs(jReader));
				break;
			case "provisioningMetadata" :
				aCategory.setProvisioningMetadata(readRefs(jReader));
				break;
			}
		}
		return aCategory;
	}
	
	private List<StructureReferenceBean> readRefs(JsonReader jReader) {
		return jReader.readStringArray().stream().map(StructureReferenceBeanImpl::new).collect(Collectors.toList());
	}

    @Override
    protected Class<ReportingTaxonomyBean> getMaintainableType() {
        return ReportingTaxonomyBean.class;
    }
}