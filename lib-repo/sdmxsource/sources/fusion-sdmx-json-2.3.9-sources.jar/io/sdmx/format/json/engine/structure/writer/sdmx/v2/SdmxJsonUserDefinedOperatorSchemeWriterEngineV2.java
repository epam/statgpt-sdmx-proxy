package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;


public class SdmxJsonUserDefinedOperatorSchemeWriterEngineV2  extends SdmxJsonItemSchemeWriterEngineV2<IUserDefinedOperatorBean, IUserDefinedOperatorSchemeBean> implements IFusionSingleton {
	private static SdmxJsonUserDefinedOperatorSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonUserDefinedOperatorSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonUserDefinedOperatorSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonUserDefinedOperatorSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME);
	}

	
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IUserDefinedOperatorSchemeBean maint) throws JsonGenerationException, IOException {
		if(maint.getVtlVersion() != null) {
			jsonGenerator.writeStringField("vtlVersion", maint.getVtlVersion());
		}
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
		writeXSArray(jsonGenerator, maint.getRulesetSchemeRef(), "rulesetSchemes");
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}
	
	private void writeXSArray(JsonGenerator jsonGenerator, List<? extends ICrossReferenceBean<?>> refs, String arrayName) throws IOException {
		if(ObjectUtil.validCollection(refs)) {
			jsonGenerator.writeArrayFieldStart(arrayName);
			for(ICrossReferenceBean<?> xsRef : refs) {
				jsonGenerator.writeString(xsRef.getTargetUrn());
			}
			jsonGenerator.writeEndArray();
		}
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IUserDefinedOperatorBean item) throws JsonGenerationException, IOException {
		if(item.getOperatorDefinition() != null) {
			jsonGenerator.writeStringField("operatorDefinition", item.getOperatorDefinition());
		}
	}

	@Override
	protected String getItemName() {
		return "userDefinedOperators";
	}
	
}