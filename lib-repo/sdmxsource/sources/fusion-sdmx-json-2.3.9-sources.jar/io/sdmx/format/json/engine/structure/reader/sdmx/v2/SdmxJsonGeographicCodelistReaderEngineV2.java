package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.codelist.GeoFeatureSetCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeographicCodelistMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonGeographicCodelistReaderEngineV2 extends SdmxJsonItemSchemeReaderEngineV2<CodeMutableBean, IGeographicCodelistMutableBean> implements IFusionSingleton {
	private static SdmxJsonGeographicCodelistReaderEngineV2 INSTANCE;

	public static SdmxJsonGeographicCodelistReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonGeographicCodelistReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "geographicCodelists";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return CodelistBean.class;
    }

    @Override
    protected IGeographicCodelistMutableBean getMutable() {
        return new GeographicCodelistMutableBean();
    }
    
	private CodeMutableBean readCodeBean(JsonReader jReader) {
		IGeoFeatureSetCodeMutableBean aCode = new GeoFeatureSetCodeMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(aCode, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parent")) {
				aCode.setParentCode(value);
			} else if (fieldName.equals("value")) {
				aCode.setGeoFeatureSet(value);
			}
		}
		return aCode;
	}

	@Override
	protected List<CodeMutableBean> readItems(JsonReader jReader) {
		List<CodeMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				CodeMutableBean aCode = readCodeBean(jReader);
				returnList.add(aCode);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "geoFeatureSetCodes";
	}
}
