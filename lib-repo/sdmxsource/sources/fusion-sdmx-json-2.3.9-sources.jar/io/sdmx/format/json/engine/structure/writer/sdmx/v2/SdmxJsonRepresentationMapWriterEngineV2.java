package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;

public class SdmxJsonRepresentationMapWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<IRepresentationMapBean> implements IFusionSingleton {
	private static SdmxJsonRepresentationMapWriterEngineV2 INSTANCE;

	public static SdmxJsonRepresentationMapWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonRepresentationMapWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonRepresentationMapWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
	}

	
	@Override
	protected void writeStructureInternal(JsonGenerator writer, IExternalMaintainableLinks externalLinks, IRepresentationMapBean maint) throws JsonGenerationException, IOException {
		writeSourceOrTargetMappings(maint.getSourceRef(), writer, true);
		writeSourceOrTargetMappings(maint.getTargetRef(), writer, false);
		writeMappedValues(maint.getMappedValues(), writer);
	}
	
	private void writeSourceOrTargetMappings(List<IRepresentationMapRefBean> targets, JsonGenerator writer, boolean isSource) throws IOException {
		writer.writeArrayFieldStart(isSource ? "source" : "target");
		for(IRepresentationMapRefBean map : targets) {
			writer.writeStartObject();
			if(map.getEnumerationRef() == null) {
				writer.writeStringField("dataType",  map.getTextType().getSdmx21Value());
			} else {
				writer.writeStringField("codelist", map.getEnumerationRef().getTargetUrn());
			}
			writer.writeEndObject();
		}
		writer.writeEndArray();
	}
	
	private void writeMappedValues(List<IMappedRelationshipBean> maps, JsonGenerator writer) throws IOException {
		writer.writeArrayFieldStart("representationMappings");
		for(IMappedRelationshipBean map : maps) {
			writeMappedValue(map, writer);
		}
		writer.writeEndArray();
	}
	
	private void writeMappedValue(IMappedRelationshipBean map, JsonGenerator writer) throws IOException {
		writer.writeStartObject();
		if(map.getValidityPeriod() != null) {
			SdmxPeriod period = map.getValidityPeriod();
			if(period.hasStartPeriod()) {
				//NOTE SDMX Schema for 3.0 expects a full date, 2008 is invalid, 2008-01-01 is okay
				writer.writeStringField("validFrom", DateUtil.formatDate(period.getStartPeriod().getDate(), TIME_FORMAT.DATE));
			}
			if(period.hasEndPeriod()) {
				//NOTE SDMX Schema for 3.0 expects a full date, 2008 is invalid, 2008-12-31 is okay
				//NOTE SDMX Schema for 3.0 expects a full date, 2008 is invalid, 2008-01-01 is okay
				writer.writeStringField("validTo", DateUtil.formatDate(period.getEndPeriod().getDate(), TIME_FORMAT.DATE));
			}
		}
		SdmxJsonStaticHelper.writeAnnotable(writer, map);
		writeSourceValues(map.getSourceValue(), writer);
		writeTargetValues(map.getTargetValue(), writer);
		writer.writeEndObject();
	}
	
	private void writeSourceValues(List<IMappedValueBean> sourceValues, JsonGenerator writer) throws IOException {
		writer.writeArrayFieldStart("sourceValues");
		for(IMappedValueBean map : sourceValues) {
			writeSourceValue(map, writer);
		}
		writer.writeEndArray();
	}
	
	private void writeSourceValue(IMappedValueBean sourceValue, JsonGenerator writer) throws IOException {
		writer.writeStartObject();
		if(sourceValue.isRegEx()) {
			writer.writeBooleanField("isRegEx", sourceValue.isRegEx());
		} 
		if(sourceValue.getStartIndex() > 0) {
			writer.writeNumberField("startIndex", sourceValue.getStartIndex());
		}
		if(sourceValue.getEndIndex() > 0) {
			writer.writeNumberField("endIndex", sourceValue.getEndIndex());
		}
		writer.writeStringField("value", sourceValue.getValue());
		writer.writeEndObject();
	}


	private void writeTargetValues(List<String> targetValues, JsonGenerator writer) throws IOException {
		writer.writeArrayFieldStart("targetValues");
		for(String target : targetValues) {
			writer.writeString(target);
		}
		writer.writeEndArray();
	}

}
