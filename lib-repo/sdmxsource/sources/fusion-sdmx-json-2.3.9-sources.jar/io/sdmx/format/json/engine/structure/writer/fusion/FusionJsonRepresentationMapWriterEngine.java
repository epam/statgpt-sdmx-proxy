package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;


public class FusionJsonRepresentationMapWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<IRepresentationMapBean> implements IFusionSingleton {
	private static FusionJsonRepresentationMapWriterEngine INSTANCE;

	public static FusionJsonRepresentationMapWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonRepresentationMapWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonRepresentationMapWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IRepresentationMapBean structureMap) throws JsonGenerationException, IOException {
		writeRefs(jsonGenerator, structureMap.getSourceRef(), "sources");
		writeRefs(jsonGenerator, structureMap.getTargetRef(), "targets");
		writeMappedRelationships(jsonGenerator, structureMap.getMappedValues());
	}

	public static void writeRefs(JsonGenerator jsonGenerator, Collection<IRepresentationMapRefBean> refs, String feildName)  throws JsonGenerationException, IOException {
		if(refs != null) {
			jsonGenerator.writeArrayFieldStart(feildName);
			for(IRepresentationMapRefBean ref : refs) {
				if(ref.getEnumerationRef() == null) {
					jsonGenerator.writeString(ref.getTextType().getSdmx21Value());
				} else {
					jsonGenerator.writeString(ref.getEnumerationRef().getTargetUrn());
				}
			}
			jsonGenerator.writeEndArray();
		}
	}
	
	private void writeMappedRelationships(JsonGenerator jsonGenerator, List<IMappedRelationshipBean> maps)  throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("mappedRelationships");
			for(IMappedRelationshipBean currentMap : maps) {
				writeMappedRelationship(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeMappedRelationship(JsonGenerator jsonGenerator, IMappedRelationshipBean map) throws IOException {
		jsonGenerator.writeStartObject();
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, map);
		if(map.hasValidityPeriod()) {
			if(map.getValidityPeriod().getStartPeriod() != null) {
				jsonGenerator.writeStringField("validFrom", map.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
			}
			if(map.getValidityPeriod().getEndPeriod() != null) {
				jsonGenerator.writeStringField("validTo", map.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
			}
		}
		writeMappedValues(jsonGenerator, map.getSourceValue());
		JsonWriterUtil.writeStringArray(jsonGenerator, "target", map.getTargetValue());
		jsonGenerator.writeEndObject();
	}

	private void writeMappedValues(JsonGenerator jsonGenerator, List<IMappedValueBean> maps)  throws IOException {
		if(ObjectUtil.validCollection(maps)) {
			jsonGenerator.writeArrayFieldStart("source");
			for(IMappedValueBean currentMap : maps) {
				writeMappedValue(jsonGenerator, currentMap);
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writeMappedValue(JsonGenerator jsonGenerator, IMappedValueBean map) throws IOException {
		jsonGenerator.writeStartObject();
		if(map.getValue() != null) {
			jsonGenerator.writeStringField("value", map.getValue());
		}
		if(map.getStartIndex() > 0) {
			jsonGenerator.writeNumberField("startIdx", map.getStartIndex());
		}
		if(map.getEndIndex() > 0) {
			jsonGenerator.writeNumberField("endIdx", map.getEndIndex());
		}
		if(map.isRegEx()) {
			jsonGenerator.writeBooleanField("regEx", map.isRegEx());
		}
		jsonGenerator.writeEndObject();
	}
}
