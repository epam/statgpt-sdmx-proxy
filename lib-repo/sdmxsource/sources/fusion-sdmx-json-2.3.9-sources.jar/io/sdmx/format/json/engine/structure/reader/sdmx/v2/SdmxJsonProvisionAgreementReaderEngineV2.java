package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonProvisionAgreementReaderEngineV2 extends AbstractSdmxJsonReaderEngine<ProvisionAgreementMutableBean> implements IFusionSingleton {
	private static SdmxJsonProvisionAgreementReaderEngineV2 INSTANCE;

	public static SdmxJsonProvisionAgreementReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonProvisionAgreementReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "provisionAgreements";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ProvisionAgreementBean.class;
    }

    @Override
    protected ProvisionAgreementMutableBean getMutable() {
        return new ProvisionAgreementMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ProvisionAgreementMutableBean mutable,
            JsonReader reader) {
        switch(fieldName) {
        case "dataflow":
            mutable.setStructureUsage(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "structureUsage":
            // The schema states that this is not present in SDMX JSON V2, but preserve it for now for lenience
            mutable.setStructureUsage(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "dataProvider":
            mutable.setDataproviderRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        }
        return false;
    }
}
