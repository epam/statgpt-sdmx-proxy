package io.sdmx.format.json.factory.structure;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.structure.StructureReaderFactory;
import io.sdmx.format.json.api.manager.JsonStructureReaderManager;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.manager.FusionJsonStructureReaderManager;
import io.sdmx.format.json.manager.SdmxJsonStructureReaderManagerV1;
import io.sdmx.format.json.manager.SdmxJsonStructureReaderManagerV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonStructureReaderFactory implements StructureReaderFactory, IFusionSingleton {
	private SdmxBeanRetrievalManager beanRetrievalManager;

	private static FusionJsonStructureReaderFactory INSTANCE;

	public static FusionJsonStructureReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonStructureReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	public static FusionJsonStructureReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private FusionJsonStructureReaderFactory() {}

	protected JsonStructureReaderManager getReader(ReadableDataLocation rdl) {
		if(JsonReader.isValidJson(rdl)) {
			SDMXJSON_VERSION version = getSdmxJsonVersion(rdl);
			if(version == null) {
				return  FusionJsonStructureReaderManager.getInstance();
			}
			switch(version) {
			case V1 : return SdmxJsonStructureReaderManagerV1.getInstance();
			case V2 : {
				return SdmxJsonStructureReaderManagerV2.getInstance();
			}
			}
		}
		return null;
	}

	private SDMXJSON_VERSION getSdmxJsonVersion(ReadableDataLocation rdl) {
		try(JsonReader jReader = new JsonReader(rdl);){
			jReader.moveNextStartObject();
			while(jReader.getCurrentFieldName() == null) {
				if(!jReader.moveNext()) {
					return null;
				}
			}
			String fieldName = jReader.getCurrentFieldName();
			if(!fieldName.equals("meta")) {
				return null;
			}

			while(jReader.moveNext()) {
				String field = jReader.getCurrentFieldName();
				if(field.equals("schema")) {
					String schema = jReader.getValueAsString();
					switch (schema) {
				    case SDMX_JSON_SCHEMA.STRUCTURE_V1:
				    case SDMX_JSON_SCHEMA.STRUCTURE_V1_OLD:
				        return SDMXJSON_VERSION.V1;

				    case SDMX_JSON_SCHEMA.STRUCTURE_V2:
				    case SDMX_JSON_SCHEMA.STRUCTURE_V2_1:
				    case SDMX_JSON_SCHEMA.STRUCTURE_V2_OLD:
				        return SDMXJSON_VERSION.V2;

				    default:
				        return null;
					}
				}
				if(jReader.isStartObject()) {
					jReader.moveToEndObject();
				} else if(jReader.isEndObject()) {
					break;
				}
			}
			//No Schema definition, assume version 1.0
			if(jReader.moveNextStartObject()) {
				if("data".equals(jReader.getCurrentFieldName())) {
					return SDMXJSON_VERSION.V1;
				}
			}
			
		}
		return null;
	}

	@Override
	public Integer getPriority() {
		return 200;
	}

	@Override
	public SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder beanBuilder) {
		JsonStructureReaderManager reader = getReader(rdl);
		if(reader == null) {
			return null;
		}
		return reader.readJson(rdl, beanBuilder, beanRetrievalManager);
	}

	public void setBeanRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
}
