package io.sdmx.format.json.model;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.validation.ErrorFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Defines a JSON Error format
 */
public class JsonErrorFormat implements ErrorFormat, IFusionSingleton {
	private static JsonErrorFormat INSTANCE;

	public static JsonErrorFormat getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new JsonErrorFormat();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private JsonErrorFormat() { }

}
