package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryComponentFilterMutableBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.pdq.PreDefinedQueryComponentFilterMutableBean;
import io.sdmx.im.mutable.pdq.PreDefinedQueryMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * 
 *  {
 *    virtual : true,
 *    dataflows : ["urn1", "urn2"],
 *    series : ["series1", ["series2"],
 *    parameters : {
 *    	"param1" : "param value",
 *    	"param2" : "param value2"
 *    },
 *    filters : [
 *    	{
 *    		component : "FREQ",
 *          match : "EQUALS",
 *          values : "["A", "Q"]
 *      },
 *      ...
 *    ]
 *  }
 *
 *
 */
public class FusionJsonPDQReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<IPreDefinedQueryBean, IPreDefinedQueryMutableBean> implements IFusionSingleton {
	private static FusionJsonPDQReaderEngine INSTANCE;

	public static FusionJsonPDQReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonPDQReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IPreDefinedQueryMutableBean getMutable() {
		return new PreDefinedQueryMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IPreDefinedQueryMutableBean mutable, JsonReader jReader) {
			if (fieldName.equals("virtual")){
				mutable.setVirtualFlow(jReader.getValueAsBoolean());
			} else if (fieldName.equals("dataflow")) {
				for(String urn : jReader.readStringArray()) {
					mutable.addDataflow(StructureReferenceBeanImpl.buildAndVerify(urn, SDMX_STRUCTURE_TYPE.DATAFLOW));
				}
			} else if (fieldName.equals("series")) {
				mutable.setSeries(jReader.readStringSet());
			} else if (fieldName.equals("parameters")) {
				mutable.setParameters(jReader.readStringMap());
			} else if (fieldName.equals("filters")) {
				readFilters(mutable, jReader);
			} else {
				return false;
			}
		return false;
	}

	
	private void readFilters(IPreDefinedQueryMutableBean query, JsonReader jReader)  {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				query.addSelection(readFilter(jReader));
			}
		}
	}
	
	private IPreDefinedQueryComponentFilterMutableBean  readFilter(JsonReader jReader)  {
		IPreDefinedQueryComponentFilterMutableBean filter = new PreDefinedQueryComponentFilterMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("component")) {
				filter.setComponentId(jReader.getValueAsString());
			}  else {
				try {
					MATCH_FUNCTION function = MATCH_FUNCTION.parseString(fieldName, true);
					filter.addFilter(function, jReader.readStringArray());
				} catch(SdmxSemmanticException e) {
					throw new SdmxSemmanticException("Error paring Predefined Query, unexpected field '"+fieldName+"'");
				}
				
			}
		}
		return filter;
	}

    @Override
    protected Class<IPreDefinedQueryBean> getMaintainableType() {
        return IPreDefinedQueryBean.class;
    }
}