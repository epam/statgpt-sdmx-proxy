package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.mapping.v3.ConceptMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ConceptSchemeMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonConceptSchemeMapReaderEngineV2 extends SdmxJsonItemSchemeMapReaderEngineV2<IConceptMapMutableBean, IConceptSchemeMapMutableBean> implements IFusionSingleton {
    private static SdmxJsonConceptSchemeMapReaderEngineV2 INSTANCE;

    public static SdmxJsonConceptSchemeMapReaderEngineV2 getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SdmxJsonConceptSchemeMapReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerElement() {
        return "conceptSchemeMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IConceptSchemeMapBean.class;
    }

    @Override
    protected IConceptSchemeMapMutableBean getMutable() {
        return new ConceptSchemeMapMutableBean();
    }

    @Override
    protected IConceptMapMutableBean getItemMapMutable() {
        return new ConceptMapMutableBean();
    }
}
