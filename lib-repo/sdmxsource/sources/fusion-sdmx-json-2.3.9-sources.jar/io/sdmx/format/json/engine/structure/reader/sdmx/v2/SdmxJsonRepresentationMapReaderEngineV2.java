package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonAnnotableUtil;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonRepresentationMapReaderEngineV2 extends AbstractSdmxJsonReaderEngine<IRepresentationMapMutableBean> implements IFusionSingleton {
	private static SdmxJsonRepresentationMapReaderEngineV2 INSTANCE;

	public static SdmxJsonRepresentationMapReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonRepresentationMapReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
    public String getContainerElement() {
        return "representationMaps";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IRepresentationMapBean.class;
    }

    @Override
    protected IRepresentationMapMutableBean getMutable() {
        return new RepresentationMapMutableBean();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, IRepresentationMapMutableBean mutable,
            JsonReader reader) {
        switch(fieldName) {
        case "source":
            processSourceRefs(reader, mutable);
            return true;
        case "target":
            processTargetRefs(reader, mutable);
            return true;
        case "representationMappings":
            processMappedRelationships(reader, mutable);
            return true;
        }
        return false;
    }

	private void processTargetRefs(JsonReader jReader, IRepresentationMapMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.getCurrentFieldName() != null && jReader.getValueAsString() != null) {
				switch(jReader.getCurrentFieldName()) {
				case "dataType" :
					mutable.addTargetRef(TEXT_TYPE.parseString(jReader.getValueAsString()));
					break;
				case "codelist" :
					mutable.addTargetRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
					break;
				}
			}
		}
	}

	private void processSourceRefs(JsonReader jReader, IRepresentationMapMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.getCurrentFieldName() != null && jReader.getValueAsString() != null) {
				switch(jReader.getCurrentFieldName()) {
				case "dataType" :
					mutable.addSourceRef(TEXT_TYPE.parseString(jReader.getValueAsString()));
					break;
				case "codelist" :
					mutable.addSourceRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
					break;
				}
			}
		}
	}

	private void processMappedRelationships(JsonReader jReader, IRepresentationMapMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				processMappedRelationship(jReader, mutable);
			}
		}
	}


	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private void processMappedRelationship(JsonReader jReader, IRepresentationMapMutableBean mutable) {
		IMappedRelationshipMutableBean mr = mutable.addMappedRelationship();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonAnnotableUtil.processBean(mr, jReader)) {
				continue;
			}
			switch(jReader.getCurrentFieldName()) {
			case "validFrom" :
				mr.setValidFrom(jReader.getValueAsString());
				break;
			case "validTo" :
				mr.setValidTo(jReader.getValueAsString());
				break;
			case "sourceValues" :
				processSourceValues(jReader, mr);
				break;
			case "targetValues" :
				mr.setTargetValue(jReader.readStringArray());
				break;
			}
		}
	}

	private void processSourceValues(JsonReader jReader, IMappedRelationshipMutableBean mr) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				processSourceValue(jReader, mr);
			}
		}
	}

	private void processSourceValue(JsonReader jReader, IMappedRelationshipMutableBean mr) {
		IMappedValueMutableBean mv = mr.addSourceValue();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			switch(jReader.getCurrentFieldName()) {
			case "isRegEx" :
				mv.setRegEx(jReader.getValueAsBoolean());
				break;
			case "startIndex" :
				mv.setStartIndex(jReader.getValueAsInt());
				break;
			case "endIndex" :
				mv.setEndIndex(jReader.getValueAsInt());
				break;
			case "value" :
				mv.setValue(jReader.getValueAsString());
				break;
			}
		}
	}
}