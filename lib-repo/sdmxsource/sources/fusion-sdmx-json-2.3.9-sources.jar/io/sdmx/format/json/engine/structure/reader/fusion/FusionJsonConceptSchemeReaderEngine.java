package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonRepresentationUtil;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonConceptSchemeReaderEngine  extends FusionJsonAbstractItemSchemeReaderEngine<ConceptSchemeBean, ConceptSchemeMutableBean, ConceptMutableBean> implements IFusionSingleton {
	private static FusionJsonConceptSchemeReaderEngine INSTANCE;

	public static FusionJsonConceptSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonConceptSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected ConceptSchemeMutableBean getMutable() {
		return new ConceptSchemeMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, ConceptSchemeMutableBean mutable, JsonReader jReader, SdmxBeanRetrievalManager beanRetrievalManager) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			String value = jReader.getValueAsString();
			if (fieldName.equals("validityType")){
				mutable.setValidityType(MAINT_VALIDITY_TYPE.getValidityType(value));
			}
			return true;
		}
		return false;
	}

	@Override
    protected ConceptMutableBean readItemBean(JsonReader jReader) {
		ConceptMutableBean aConcept = new ConceptMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			FusionJsonNameableUtil.processBean(aConcept, jReader);

			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parentConcept")) {
				aConcept.setParentConcept(value);
			} else if (fieldName.equals("representation")) {
				aConcept.setCoreRepresentation(FusionJsonRepresentationUtil.readRepresentation(jReader));
			} else if (fieldName.equals("isoConceptReference")) {
				aConcept.setIsoConceptReference(new StructureReferenceBeanImpl(value));
			}

			ValidityPeriodUtil.processValidityAnnotations(aConcept);
		}

		return aConcept;
	}

    @Override
    protected Class<ConceptSchemeBean> getMaintainableType() {
        return ConceptSchemeBean.class;
    }
}