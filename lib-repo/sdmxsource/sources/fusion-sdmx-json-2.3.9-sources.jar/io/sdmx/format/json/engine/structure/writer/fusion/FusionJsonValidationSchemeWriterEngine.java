package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleHierarchyBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class FusionJsonValidationSchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<ValidationSchemeBean> implements IFusionSingleton {
	private static FusionJsonValidationSchemeWriterEngine INSTANCE;

	public static FusionJsonValidationSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonValidationSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonValidationSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VALIDATION_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean item) throws JsonGenerationException, IOException {
		ValidationRuleBean rule = (ValidationRuleBean)item;

		if(rule.getValidationHierarchy() != null) {
			ValidationRuleHierarchyBean hRule = rule.getValidationHierarchy();
			jsonGenerator.writeObjectFieldStart("validationHierarchy");
			jsonGenerator.writeStringField("dimensionReference", hRule.getDimensionReference().getTargetUrn());
			jsonGenerator.writeStringField("hierarchyReference", hRule.getHierarchyReference().getTargetUrn());
			jsonGenerator.writeEndObject();
		}
		if(ObjectUtil.validString(rule.getExpression())) {
			jsonGenerator.writeStringField("expression", rule.getExpression());
		}
		if(ObjectUtil.validString(rule.getResultant())) {
			jsonGenerator.writeStringField("resultant", rule.getResultant());
		}
		if(rule.getEqualityOperator() != null) {
			jsonGenerator.writeStringField("equality", rule.getEqualityOperator().toString());
		}
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ValidationSchemeBean identifiable) throws JsonGenerationException, IOException {
		if(identifiable.getAttachment() != null) {
			jsonGenerator.writeStringField("attachment", identifiable.getAttachment().getTargetUrn());
		}
		super.writeStructureInternal(jsonGenerator, externalLinks, identifiable);
	}
}
