package io.sdmx.format.json.engine.data.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.json.JsonReader.Iterator;
import io.sdmx.utils.sdmx.xs.URN;

public class StructureIterator extends AbstractIterator {
	private List<ComponentIterator> componentIterators = new ArrayList<>();
	private LEVEL currentLevel = null;
	private String uri;
	private boolean inAttributes = false;
	private AnnotationsIterator annotationIterator;

	private enum LEVEL {
		DATASET,
		SERIES,
		OBS,
		DATASET_ATTR,
		SERIES_ATTR,
		OBS_ATTR;
	}
	public StructureIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	public JsonDatasetStructuralMetadata getJsonDatasetStructuralMetadata() {
		return new JsonDatasetStructuralMetadata();
	}

	public class JsonDatasetStructuralMetadata {
		private DatasetStructureReferenceBean datasetStructureReference;
		private List<AnnotationBean> annotationList;
		private List<Map<Integer, KeyValue>> datasetAttributeList;
		private List<Map<Integer, KeyValue>> seriesAttributeList;
		private List<Map<Integer, KeyValue>> obsAttributeList;
		private List<Map<Integer, KeyValue>> seriesList;  //Series keys
		private List<String> obsIds;  //All the concepts at the observation level
		private String dimensionAtObservation;

		
		public JsonDatasetStructuralMetadata() {
			annotationList = annotationIterator != null ? annotationIterator.getAnnotations() : null;
			datasetAttributeList = getList(LEVEL.DATASET_ATTR);
			seriesAttributeList = getList(LEVEL.SERIES_ATTR);
			obsAttributeList = getList(LEVEL.OBS_ATTR);
			seriesList = getList(LEVEL.SERIES);
			
			Map<Integer, KeyValue> observationMap = null;
			if(seriesList.size() == 0) {
				//Flat - Observation Concept is last one in list
				seriesList =  getList(LEVEL.OBS);
				observationMap = seriesList.get(seriesList.size()-1);
				
			} else {
				ComponentIterator observationComp = null;
				for(ComponentIterator comp : componentIterators) {
					if(comp.getLevel() == LEVEL.OBS) {
						observationComp = comp;
						break;
					}
				}
				if(observationComp != null) {
					observationMap = observationComp.componentMap;
				}
			}
			if(observationMap == null) {
				throw new SdmxSemmanticException("Can not read JSON Data Message, missing Observation information in the Structure part of the message");
			}
			obsIds = new ArrayList<>();
			for(int i=0; i < Integer.MAX_VALUE; i++) {
				KeyValue kv = observationMap.get(i);
				if(kv == null) {
					break;
				}
				dimensionAtObservation = kv.getConcept();
				obsIds.add(kv.getCode());
			}
			
			if(uri != null) {
				String[] uriSplit = uri.split("/");
				if(uriSplit.length > 4) {
					String version = uriSplit[uriSplit.length-1];
					String id = uriSplit[uriSplit.length-2];
					String agency = uriSplit[uriSplit.length-3];
					SDMX_STRUCTURE_TYPE structureType = SDMX_STRUCTURE_TYPE.parseClass(uriSplit[uriSplit.length-4]);
					IURNSingle<IDSDRelatedBean> sRef = URN.builder(structureType, agency, id, version).buildSingle(IDSDRelatedBean.class);
					datasetStructureReference = new DatasetStructureReferenceBeanImpl(id, sRef, null, uri, dimensionAtObservation);
				}
			}
		}
		
		public DatasetStructureReferenceBean getDatasetStructureReference() {
			return datasetStructureReference;
		}

		public List<AnnotationBean> getAnnotationList() {
			return annotationList;
		}

		public List<Map<Integer, KeyValue>> getDatasetAttributeList() {
			return datasetAttributeList;
		}

		public List<Map<Integer, KeyValue>> getSeriesAttributeList() {
			return seriesAttributeList;
		}

		public List<Map<Integer, KeyValue>> getObsAttributeList() {
			return obsAttributeList;
		}

		public List<Map<Integer, KeyValue>> getSeriesList() {
			return seriesList;
		}

		public List<String> getObsIds() {
			return obsIds;
		}

		public String getDimensionAtObservation() {
			return dimensionAtObservation;
		}
	}
	
	private List<Map<Integer, KeyValue>> getList(LEVEL lvl) {
		List<Map<Integer, KeyValue>> returnList = new ArrayList<>();
		for(ComponentIterator comp : componentIterators) {
			if(comp.getLevel() == lvl) {
				returnList.add(comp.componentMap);
			}
		}
		return returnList;
	}
	

	@Override
	public JsonReader.Iterator start(String fieldName, boolean isObject) {
		if("dimensions".equals(fieldName)) {
			inAttributes = false;
			return this;
		} 

		if("attributes".equals(fieldName)) {
			inAttributes = true;
			return this;
		}
		
		if("annotations".equals(fieldName)) {
			annotationIterator = new AnnotationsIterator(jReader, exceptionHandler);
			return annotationIterator;
		}


		if("dataSet".equals(fieldName)) {
			if(inAttributes) {
				currentLevel = LEVEL.DATASET_ATTR;
			} else {
				currentLevel = LEVEL.DATASET;
			}
		} else if("series".equals(fieldName)) {
			if(inAttributes) {
				currentLevel = LEVEL.SERIES_ATTR;
			} else {
				currentLevel = LEVEL.SERIES;
			}
		}  else if("observation".equals(fieldName)) {
			if(inAttributes) {
				currentLevel = LEVEL.OBS_ATTR;
			} else {
				currentLevel = LEVEL.OBS;
			}
		} else if(fieldName == null) {
			//We are in an array at the level defined by currentLevel
			ComponentIterator componentIterator = new ComponentIterator(jReader, currentLevel, exceptionHandler);
			componentIterators.add(componentIterator);
			return componentIterator;
		}
		return null;
	}



	@Override
	public void next(String fieldName) {
		if("uri".equals(fieldName)) {
			uri = jReader.getValueAsString();
		}
	}

	private class ComponentIterator extends AbstractIterator {
		private LEVEL level;
		private String id;
		private Map<Integer, KeyValue> componentMap = new HashMap<>();

		private boolean inValues;
		private int pos;

		public ComponentIterator(JsonReader jReader, LEVEL level, DataReaderExceptionHandler exceptionHandler) {
			super(jReader, exceptionHandler);
			this.level = level;
		}

		@Override
		public void next(String fieldName) {
			if(inValues) {
				if("id".equals(fieldName)) {
					componentMap.put(pos, KeyValueImpl.getInstance(this.id, jReader.getValueAsString()));
					pos++;
				}
			} else if("id".equals(fieldName)) {
				this.id = jReader.getValueAsString();
			}
		}

		@Override
		public Iterator start(String fieldName, boolean isObject) {
			if("values".equals(fieldName)) {
				inValues = true;
			}
			return null;
		}

		public LEVEL getLevel() {
			return level;
		}
	}
}
