package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonCategorySchemeReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<CategorySchemeBean, CategorySchemeMutableBean, CategoryMutableBean> implements IFusionSingleton {
	private static FusionJsonCategorySchemeReaderEngine INSTANCE;

	public static FusionJsonCategorySchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonCategorySchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected CategorySchemeMutableBean getMutable() {
		return new CategorySchemeMutableBeanImpl();
	}


	@Override
	protected CategoryMutableBean readItemBean(JsonReader jReader) {
		CategoryMutableBean aCategory = new CategoryMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			FusionJsonNameableUtil.processBean(aCategory, jReader);

			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("items")) {
				aCategory.setItems(readItems(jReader));
			}
		}
		return aCategory;
	}

    @Override
    protected Class<CategorySchemeBean> getMaintainableType() {
        return CategorySchemeBean.class;
    }
}