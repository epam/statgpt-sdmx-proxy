package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonComponentUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataAttributeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataStructureDefinitionMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonMetadataStructureReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<MetadataStructureDefinitionBean, MetadataStructureDefinitionMutableBean> implements IFusionSingleton {
	private static FusionJsonMetadataStructureReaderEngine INSTANCE;

	public static FusionJsonMetadataStructureReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonMetadataStructureReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected MetadataStructureDefinitionMutableBean getMutable() {
		return new MetadataStructureDefinitionMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, MetadataStructureDefinitionMutableBean mutable, JsonReader jReader) {
		if (fieldName.equals("metadataAttributes")) {
			mutable.setMetadataAttributes(readMetadataAttributes(jReader));
		}  else if (fieldName.equals("reportStructures")) {
			mutable.setMetadataAttributes(readReportStructures(jReader));
		} else if (fieldName.equals("metadataTargets")) {
			jReader.moveToEndArray();  //Skip whole target setion
		} else {
			return false;
		}
		return true;
	}

	private List<MetadataAttributeMutableBean> readReportStructures(JsonReader jReader) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				return readReportStructure(jReader);
			}
		}
		return new ArrayList<>();
	}
//
	/**
	 * depreated format based on v2.1 of the SDMX-IM, - unpacks the metadata attributes from the report structure - discards everything else
	 * @param jReader
	 * @return
	 */
	private List<MetadataAttributeMutableBean> readReportStructure(JsonReader jReader) {
		CodeMutableBean dummyIdentifiable = new CodeMutableBeanImpl();  //Just pass something into process the identifiable
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(jReader.getCurrentFieldName().equals("targets")) {
				jReader.readStringArray();  //Read and discard
			} else if(jReader.getCurrentFieldName().equals("metadataAttributes")) {
				return readMetadataAttributes(jReader);
			}
			else {
				FusionJsonIdentifiableUtil.processBean(dummyIdentifiable, jReader);
			}
		}
		return new ArrayList<>();
	}
//
	private List<MetadataAttributeMutableBean> readMetadataAttributes(JsonReader jReader) {
		List<MetadataAttributeMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if(jReader.isStartObject()) {
				returnList.add(readMetadataAttribute(jReader));
			}
		}
		return returnList;
	}

	private MetadataAttributeMutableBean readMetadataAttribute(JsonReader jReader) {
		MetadataAttributeMutableBean ma = new MetadataAttributeMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(FusionJsonComponentUtil.processBean(ma, jReader)) {
				continue;
			}
			String field = jReader.getCurrentFieldName();
			if(field.equals("minOccurs")) {
				ma.setMinOccurs(Integer.parseInt(jReader.getValueAsString()));
			} else if(field.equals("maxOccurs")) {
				ma.setMaxOccurs(Integer.parseInt(jReader.getValueAsString()));
			} else if(field.equals("presentational")) {
				ma.setPresentational(TERTIARY_BOOL.parseBoolean(jReader.getValueAsBoolean()));
			} else if(field.equals("metadataAttributes")) {
				ma.setMetadataAttributes(readMetadataAttributes(jReader));
			}

		}
		if(ma.getPresentational() == TERTIARY_BOOL.TRUE) {
			if(ma.getRepresentation() != null) {
				ma.getRepresentation().setRepresentation(null);
				ma.getRepresentation().setTextFormat(null);;
			}
		}
		return ma;
	}

    @Override
    protected Class<MetadataStructureDefinitionBean> getMaintainableType() {
        return MetadataStructureDefinitionBean.class;
    }
}
