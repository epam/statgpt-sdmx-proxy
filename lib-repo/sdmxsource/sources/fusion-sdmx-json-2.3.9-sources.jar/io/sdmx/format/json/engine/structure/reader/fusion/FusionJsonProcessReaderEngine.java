package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.process.ComputationMutableBeanImpl;
import io.sdmx.im.mutable.process.InputOutputMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessStepMutableBeanImpl;
import io.sdmx.im.mutable.process.TransitionMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonProcessReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<ProcessBean, ProcessMutableBean> implements IFusionSingleton {
    private static FusionJsonProcessReaderEngine INSTANCE;

    public static FusionJsonProcessReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FusionJsonProcessReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    protected ProcessMutableBean getMutable() {
        return new ProcessMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, ProcessMutableBean mutable, JsonReader reader) {
        if (fieldName.equals("processSteps")) {
            mutable.setProcessSteps(readProcessSteps(reader));
        } else {
            return false;
        }
        return true;
    }

    private List<ProcessStepMutableBean> readProcessSteps(JsonReader jReader) {
        List<ProcessStepMutableBean> returnList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            if (jReader.isStartObject()) {
                returnList.add(readProcessStep(jReader));
            }
        }
        return returnList;
    }

    private ProcessStepMutableBean readProcessStep(JsonReader jReader) {
        ProcessStepMutableBean mutable = new ProcessStepMutableBeanImpl();

        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String fieldName = jReader.getCurrentFieldName();
            if(FusionJsonNameableUtil.processBean(mutable, jReader)) {
                continue;
            }
            switch(fieldName) {
            case "inputs":
                mutable.setInput(readInputOutputs(jReader));
                break;
            case "outputs":
                mutable.setOutput(readInputOutputs(jReader));
                break;
            case "computation":
                mutable.setComputation(readComputation(jReader));
                break;
            case "transitions":
                mutable.setTransitions(readTransitions(jReader));
                break;
            case "processSteps":
                mutable.setProcessSteps(readProcessSteps(jReader));
                break;
            default : throw new SdmxSemmanticException("unknown field: "+fieldName);
            }
        }
        return mutable;
    }

    private List<InputOutputMutableBean> readInputOutputs(JsonReader jReader) {
        List<InputOutputMutableBean> returnList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            if (jReader.isStartObject()) {
                returnList.add(readInputOutput(jReader));
            }
        }
        return returnList;
    }

    private InputOutputMutableBean readInputOutput(JsonReader jReader) {
        InputOutputMutableBean mutable = new InputOutputMutableBeanImpl();

        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String fieldName = jReader.getCurrentFieldName();
            if(FusionJsonAnnotableUtil.processBean(mutable, jReader)) {
                continue;
            }
            switch(fieldName) {
            case "localId":
                mutable.setLocalId(jReader.getValueAsString());
                break;
            case "structure":
                mutable.setStructureReference(new StructureReferenceBeanImpl(jReader.getValueAsString()));
                break;
            default : throw new SdmxSemmanticException("unknown field: "+fieldName);

            }
        }
        return mutable;
    }

    private ComputationMutableBean readComputation(JsonReader jReader) {
        ComputationMutableBean mutable = new ComputationMutableBeanImpl();

        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String fieldName = jReader.getCurrentFieldName();
            if(FusionJsonAnnotableUtil.processBean(mutable, jReader)) {
                continue;
            }
            switch(fieldName) {
            case "localId":
                mutable.setLocalId(jReader.getValueAsString());
                break;
            case "softwareLanguage":
                mutable.setSoftwareLanguage(jReader.getValueAsString());
            case "softwarePackage":
                mutable.setSoftwarePackage(jReader.getValueAsString());
                break;
            case "softwareVersion":
                mutable.setSoftwareVersion(jReader.getValueAsString());
                break;
            case "description":
                mutable.setDescriptions(FusionJsonNameableUtil.readTextTypeWrappers(jReader));
                break;
            default : throw new SdmxSemmanticException("unknown field: "+fieldName);

            }
        }
        return mutable;
    }

    private List<TransitionMutableBean> readTransitions(JsonReader jReader) {
        List<TransitionMutableBean> returnList = new ArrayList<>();
        while (jReader.moveNext()) {
            if (jReader.isEndArray()) {
                break;
            }
            if (jReader.isStartObject()) {
                returnList.add(readTransition(jReader));
            }
        }
        return returnList;
    }

    private TransitionMutableBean readTransition(JsonReader jReader) {
        TransitionMutableBean mutable = new TransitionMutableBeanImpl();
        while (jReader.moveNext()) {
            if (jReader.isEndObject()) {
                break;
            }
            String fieldName = jReader.getCurrentFieldName();
            if(FusionJsonIdentifiableUtil.processBean(mutable, jReader)) {
                continue;
            }
            switch(fieldName) {
            case "localId":
                mutable.setLocalId(jReader.getValueAsString());
                break;
            case "targetStep":
                mutable.setTargetStep(jReader.getValueAsString());
                break;

            case "condition":
                mutable.setConditions(FusionJsonNameableUtil.readTextTypeWrappers(jReader));
                break;
            default : throw new SdmxSemmanticException("unknown field: "+fieldName);

            }
        }

        return mutable;
    }

    @Override
    protected Class<ProcessBean> getMaintainableType() {
        return ProcessBean.class;
    }
}