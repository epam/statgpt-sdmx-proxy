package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonProcessWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<ProcessBean> implements IFusionSingleton {
	private static SdmxJsonProcessWriterEngineV2 INSTANCE;

	public static SdmxJsonProcessWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonProcessWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonProcessWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.PROCESS);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ProcessBean pro) throws JsonGenerationException, IOException {
		if(pro.getProcessSteps().isEmpty()) {
			return;
		}
		writeProcessStep(pro.getProcessSteps(), externalLinks, jsonGenerator);
	}

	private void writeProcessStep(List<ProcessStepBean> processSteps, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeArrayFieldStart("processSteps");
		for(ProcessStepBean processStep : processSteps) {
			writeProcessStep(processStep, externalLinks, jsonGenerator);
		}
		jsonGenerator.writeEndArray();
	}

	private void writeProcessStep(ProcessStepBean processStep, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		writeNameable(jsonGenerator, processStep, externalLinks);
		writeComputation(processStep.getComputation(), jsonGenerator);
		writeInputOutputBean(processStep.getInput(),jsonGenerator, "inputs");
		writeInputOutputBean(processStep.getOutput(), jsonGenerator, "outputs");
		writeProcessStep(processStep.getProcessSteps(), externalLinks, jsonGenerator);
		writeTransition(processStep.getTransitions(), externalLinks, jsonGenerator);
	}

	private void writeTransition(List<TransitionBean> transitions, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws IOException {
		if(transitions.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("transitions");
		for(TransitionBean transition : transitions) {
			writeIdentifiable(jsonGenerator, transition, externalLinks);
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "localID", transition.getLocalId());
			SdmxJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, transition.getCondition(), "conditions");
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "targetStep", transition.getTargetStep().getUrn());
		}
		jsonGenerator.writeEndArray();
	}

	private void writeInputOutputBean(List<InputOutputBean> inOutBeans, JsonGenerator jsonGenerator, String field) throws IOException {
		if(inOutBeans.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(field);
		for(InputOutputBean inOut : inOutBeans) {
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "localID", inOut.getLocalId());
			SdmxJsonStaticHelper.writeAnnotable(jsonGenerator, inOut);
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "objectReference", inOut.getStructureReference().getTargetUrn());

		}
		jsonGenerator.writeEndArray();
	}

	private void writeComputation(ComputationBean computation, JsonGenerator jsonGenerator) throws IOException {
		if(computation == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("computation");
		SdmxJsonStaticHelper.writeAnnotable(jsonGenerator, computation);
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "localID", computation.getLocalId());
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "softwareLanguage", computation.getSoftwareLanguage());
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "softwarePackage", computation.getSoftwarePackage());
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "softwareVersion", computation.getSoftwareVersion());
		SdmxJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, computation.getDescription(), "descriptions");
		jsonGenerator.writeEndObject();
	}
}
