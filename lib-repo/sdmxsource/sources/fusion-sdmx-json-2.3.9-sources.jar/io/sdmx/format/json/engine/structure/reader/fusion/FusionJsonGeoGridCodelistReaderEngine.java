package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.codelist.GeoGridCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodelistMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.structure.StructureTypes;

public class FusionJsonGeoGridCodelistReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<IGeoGridCodelistBean, IGeoGridCodelistMutableBean, CodeMutableBean> implements IFusionSingleton {
	private static FusionJsonGeoGridCodelistReaderEngine INSTANCE;

	public static FusionJsonGeoGridCodelistReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonGeoGridCodelistReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IGeoGridCodelistMutableBean getMutable() {
		return new GeoGridCodelistMutableBean();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, IGeoGridCodelistMutableBean mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader)) {
			String value = jReader.getValueAsString();
			if (fieldName.equals("validityType")) {
				mutable.setValidityType(MAINT_VALIDITY_TYPE.getValidityType(value));
			} else if (fieldName.equals("gridDefinition")) {
				mutable.setGridDefinition(value);
			}
			return true;
		}
		return false;
	}

	@Override
    protected CodeMutableBean readItemBean(JsonReader jReader) {
		IGeoGridCodeMutableBean aCode = new GeoGridCodeMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			FusionJsonNameableUtil.processBean(aCode, jReader);
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("parentCode")) {
				aCode.setParentCode(value);
			} else if (fieldName.equals("geoCell")) {
				aCode.setGeoCell(value);
			} else if (fieldName.equals("isInherited") && value.equalsIgnoreCase("true")) {
				return null;
			}
		}
		return aCode;
	}

	@Override
    public String getContainerElement() {
        return "GeoGridCodelist";
    }

    @Override
    public IMaintainableStructureType<?> getBuiltType() {
        return StructureTypes.getMaintStructureType(CodelistBean.class);
    }

    @Override
    protected Class<IGeoGridCodelistBean> getMaintainableType() {
        return IGeoGridCodelistBean.class;
    }
}