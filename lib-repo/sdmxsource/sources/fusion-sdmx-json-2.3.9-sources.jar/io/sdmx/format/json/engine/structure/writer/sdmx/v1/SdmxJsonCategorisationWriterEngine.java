package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCategorisationWriterEngine extends SdmxJsonMaintainableStructureWriterEngine<CategorisationBean> implements IFusionSingleton {
	private static SdmxJsonCategorisationWriterEngine INSTANCE;

	public static SdmxJsonCategorisationWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorisationWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonCategorisationWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CATEGORISATION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  CategorisationBean aCategorisation) throws JsonGenerationException, IOException {
		ICrossReferenceBean structureRef = aCategorisation.getStructureReference();
		if(structureRef != null) {
			jsonGenerator.writeStringField("source", structureRef.getTargetUrn());
		}
		
		ICrossReferenceBean categoryRef = aCategorisation.getCategoryReference();
		if(categoryRef != null) {
			jsonGenerator.writeStringField("target", categoryRef.getTargetUrn());
		}
	}

}
