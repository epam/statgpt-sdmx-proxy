package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonAgencySchemeReaderEngineV2 extends SdmxJsonOrganisationSchemeReaderEngineV2<AgencyMutableBean, AgencySchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonAgencySchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonAgencySchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonAgencySchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	@Override
    public String getContainerElement() {
        return "agencySchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return AgencySchemeBean.class;
    }

    @Override
    protected AgencySchemeMutableBean getMutable() {
        return new AgencySchemeMutableBeanImpl();
    }

	@Override
	protected List<AgencyMutableBean> readItems(JsonReader jReader) {
		List<AgencyMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				AgencyMutableBean anAgency = new AgencyMutableBeanImpl();
				populateOrganisationMutableBean(jReader, anAgency);
				returnList.add(anAgency);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "agencies";
	}
}
