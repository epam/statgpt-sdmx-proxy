package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonValueListWriterEngine  extends FusionJsonMaintainableStructureWriterEngineImpl<ValueListBean> implements IFusionSingleton {
	private static FusionJsonValueListWriterEngine INSTANCE;

	public static FusionJsonValueListWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonValueListWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonValueListWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VALUE_LIST);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ValueListBean valueList) throws JsonGenerationException, IOException {
		jsonGenerator.writeBooleanField("isPartial", valueList.isPartial());
		writeItems(jsonGenerator, valueList);
	}

	private void writeItems(JsonGenerator jsonGenerator, ValueListBean valueList) throws IOException {
		jsonGenerator.writeArrayFieldStart("items");
		for(ValueItemBean item : valueList.getItems()) {
			writeItem(jsonGenerator, item);
		}
		jsonGenerator.writeEndArray();
	}

	private void writeItem(JsonGenerator jsonGenerator, ValueItemBean valueItem) throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeStringField("id", valueItem.getId());
		FusionJsonStaticHelper.writeAnnotable(jsonGenerator, valueItem);
		FusionJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, valueItem.getNames(), "names");
		FusionJsonStaticHelper.writeTextTypeWrapperArray(jsonGenerator, valueItem.getDescriptions(), "descriptions");
		jsonGenerator.writeEndObject();
	}

}
