package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

/**
 * Codelist output as following JSON:
 *
 * {
    "type" : "Codelist",
    "id" : "CL_FREQ",
    "urn" : "urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS_IMF:CL_FREQ(1.0)",
    "name" : "Code list for Frequency (FREQ)",
    "agency" : "BIS and IMF (joint exercise)",
    "uri" : "http://localhost:8080/FusionRegistry/ws/registry/ws/registry/view/codelist/BIS_IMF/CL_FREQ/1.0",
    "agencyUrl" : "http://localhost:8080/FusionRegistry/ws/registry/ws/registry/view/agencyscheme/SDMX/AGENCIES/1.0",
    "resourceUrl" : "http://localhost:8080/FusionRegistry/ws/registry/ws/rest/codelist/BIS_IMF/CL_FREQ/1.0",
    "agencyId" : "BIS_IMF",
    "version" : "1.0",
    "ispartial" : false,
    "items" : [{
        "type" : "Code",
        "id" : "A",
        "urn" : "urn:sdmx:org.sdmx.infomodel.codelist.Code=BIS_IMF:CL_FREQ(1.0).A",
        "name" : "Annual",
        "parentCode" : null
      },
      ...
      ]
   }
 *
 */
public class SdmxJsonGeoGridCodelistWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<CodeBean, IGeoGridCodelistBean> implements IFusionSingleton {
	private static SdmxJsonGeoGridCodelistWriterEngineV2 INSTANCE;

	public static SdmxJsonGeoGridCodelistWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonGeoGridCodelistWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonGeoGridCodelistWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}
	
	

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, IGeoGridCodelistBean identifiable) throws JsonGenerationException, IOException {
		jsonGenerator.writeStringField("geoType", "GeoGridCodelist");
		jsonGenerator.writeStringField("gridDefinition", identifiable.getGridDefinition());
		super.writeStructureInternal(jsonGenerator, externalLinks, identifiable);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CodeBean item) throws JsonGenerationException, IOException  {
		IGeoGridCodeBean code = (IGeoGridCodeBean)item;
		if(code.getParentCode() != null) {
			jsonGenerator.writeStringField("parentCode", code.getParentCode());
		}
		if(code.getGeoCell() != null) {
			jsonGenerator.writeStringField("geoCell", code.getGeoCell());
		}
	}

	@Override
	protected String getItemName() {
		return "geoGridCodes";
	}
	
	
}
