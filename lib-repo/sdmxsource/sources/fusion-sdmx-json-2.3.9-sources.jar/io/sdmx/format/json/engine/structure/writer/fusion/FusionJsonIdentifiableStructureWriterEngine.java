package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;

public abstract class FusionJsonIdentifiableStructureWriterEngine<T extends IdentifiableBean> {

	public void writeStructure(T identifiable, IExternalMaintainableLinks externalLinks, OutputStream out) {
		JsonFactory jsonFactory = new JsonFactory();
		JsonGenerator jsonGenerator = null;
		try {
			jsonGenerator = jsonFactory.createGenerator(out, JsonEncoding.UTF8);
			writeStructure(jsonGenerator, externalLinks, identifiable);
		} catch (Throwable e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			try {
				if (jsonGenerator != null) {
				    jsonGenerator.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	protected void writeStructure(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T identifiable) throws JsonGenerationException, IOException {
		jsonGenerator.writeObjectFieldStart(identifiable.getStructureType().getUrnClass());
		jsonGenerator.writeStringField("type", identifiable.getStructureType().getUrnClass());
		writeStructureInternal(jsonGenerator, externalLinks, identifiable);
		jsonGenerator.writeEndObject();
	}

	protected void writeIdentifiable(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  IdentifiableBean identifiable) throws JsonGenerationException, IOException {
		FusionJsonStaticHelper.writeIdentifiable(jsonGenerator, externalLinks, identifiable);
	}

	void writeComponent(ComponentBean componentBean, IExternalMaintainableLinks externalLinks, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		writeIdentifiable(jsonGenerator, externalLinks, componentBean);
		FusionJsonStaticHelper.writeRepresentation(jsonGenerator, componentBean.getRepresentation());
		if(componentBean.getConceptRef() != null) {
			jsonGenerator.writeStringField("concept", componentBean.getConceptRef().getTargetUrn());
		}
	}

	protected abstract void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T identifiable) throws JsonGenerationException, IOException;
}
