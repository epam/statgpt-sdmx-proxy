package io.sdmx.format.json.engine.structure.reader.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonNameableUtil {

	
	public static boolean processBean(NameableMutableBean nameable, JsonReader jReader) {
        return FusionJsonIdentifiableUtil.processBean(nameable, jReader) || processNode(nameable, jReader);
    }

	
	private static boolean processNode(NameableMutableBean nameableMutableBean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();

		if (fieldName.equals("names")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = readTextTypeWrappers(jReader);
			for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
				nameableMutableBean.addName(ttw);
			}
			return true;
		}
		if (fieldName.equals("descriptions")) {
			List<TextTypeWrapperMutableBean> readTextTypeWrappers = readTextTypeWrappers(jReader);
			for (TextTypeWrapperMutableBean ttw : readTextTypeWrappers) {
				nameableMutableBean.addDescription(ttw);
			}
			return true;
		}
		return false;
	}

	/**
	 * Reads a json array of locale value pairs, example:
	 * 
	 * [
	 *   {locale: "en", value : "A Name"},
	 *   ...
	 * ]
	 * @param jReader
	 * @return
	 */
	public static List<TextTypeWrapperMutableBean> readTextTypeWrappers(JsonReader jReader) {
		// JReader is at the start of an array
		List<TextTypeWrapperMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}

			TextTypeWrapperMutableBean ttw = addTextTypeWrapper(jReader);
			if (ttw != null) {
			    returnList.add(ttw);
			}
		}
		return returnList;
	}

	/**
	 * Reads a JSON Object with locale and name, example:
	 * {locale: "en", value : "A Name"}
	 * 
	 * @param jReader
	 * @return
	 */
	private static TextTypeWrapperMutableBean addTextTypeWrapper(JsonReader jReader) {
		TextTypeWrapperMutableBean ttw = new TextTypeWrapperMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("locale")) {
			    if (ObjectUtil.validString(value)) {
				    ttw.setLocale(value);
			    }
			} else if (fieldName.equals("value")) {
			    if (ObjectUtil.validString(value)) {
				    ttw.setValue(value);
			    }
			}
		}
		if (ObjectUtil.validString(ttw.getValue()) && ObjectUtil.validString(ttw.getLocale())) {
		    return ttw;
		}
		return null;
	}
}