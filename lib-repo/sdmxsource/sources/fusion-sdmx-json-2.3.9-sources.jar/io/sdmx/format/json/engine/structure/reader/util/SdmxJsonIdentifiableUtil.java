package io.sdmx.format.json.engine.structure.reader.util;

import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonIdentifiableUtil {

	public static boolean processBean(IdentifiableMutableBean ident, JsonReader jReader) {
		return processAttributes(ident, jReader) || SdmxJsonAnnotableUtil.processBean(ident, jReader);
	}

	/**
	 * Populates the Identifiable with 'id' and 'uri' attribute values read from the current XML node.
	 * @param identifiableBean
	 * @param staxReader
	 */
	private static boolean processAttributes(IdentifiableMutableBean identifiableBean, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		String value = jReader.getValueAsString();
		if (fieldName.equals("id")) {
			identifiableBean.setId(value);
			return true;
		}
		if (fieldName.equals("urn")) {
			return true;
		}
		return false;
	}
}
