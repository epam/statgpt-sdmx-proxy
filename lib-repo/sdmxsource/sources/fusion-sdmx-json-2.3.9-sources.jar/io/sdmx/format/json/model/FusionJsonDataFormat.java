package io.sdmx.format.json.model;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

@Deprecated
/**
 * use SdmxJson
 * @author Matthew Nelson
 *
 */
public class FusionJsonDataFormat implements DataFormat {
	private static final long serialVersionUID = -1461535945154796477L;
	public static final FusionJsonDataFormat INSTANCE = new FusionJsonDataFormat(null);
	
	private FormatDetails formatDetails = new FormatDetailsImpl("Fusion-JSON", MIME_TYPE.APPLICATION_JSON, true, true, "application/vnd.fusion.json");
	private IRESTGET dataQuery;
	
	public FusionJsonDataFormat(IRESTGET dataQuery) {
		this.dataQuery = dataQuery;
	}
	

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	public IRESTGET getRestDataQuery() {
		return dataQuery;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxJsonDataFormat) {
			SdmxJsonDataFormat that = (SdmxJsonDataFormat)obj;
			
			return ObjectUtil.equivalent(that.getRestDataQuery(), this.getRestDataQuery());
		}
		return false;
	}

	@Override
	public String toString() {
		if(dataQuery != null) {
			return formatDetails.getAcceptHeaders()[0] +dataQuery.toURL();
		}
		return formatDetails.getAcceptHeaders()[0];
	}
}
