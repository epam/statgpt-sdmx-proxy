package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonNamePersonalisationSchemeWriterEngine extends FusionJsonAbstractVTLSchemeWriterEngine<INamePersonalisationSchemeBean> implements IFusionSingleton {
	private static FusionJsonNamePersonalisationSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonNamePersonalisationSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME);
	}

	public static FusionJsonNamePersonalisationSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonNamePersonalisationSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		INamePersonalisationBean item =  (INamePersonalisationBean)itemBean;
		jsonGenerator.writeStringField("vtlArtefact", item.getVtlArtefact());
		if(item.getVtlDefaultName() != null) {
			jsonGenerator.writeStringField("vtlDefaultName", item.getVtlDefaultName());
		}
		if(item.getPersonalisedName() != null) {
			jsonGenerator.writeStringField("personalisedName", item.getPersonalisedName());
		}
	}
}
