package io.sdmx.format.json.engine.structure.reader.util;

import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonMaintainableUtil {

	public static boolean processBean(MaintainableMutableBean maint, JsonReader jReader) {
		return GenericJsonReaderUtil.processLinks(maint, jReader) || SdmxJsonNameableUtil.processBean(maint, jReader) || processAttributes(maint, jReader);
	}

	private static boolean processAttributes(MaintainableMutableBean maint, JsonReader jReader) {
		String fieldName = jReader.getCurrentFieldName();
		String value = jReader.getValueAsString();

		if (fieldName.equals("isExternalReference")) {
			maint.setExternalReference(Boolean.parseBoolean(value));
			return true;
		}
		if (fieldName.equals("agencyID")) {
			maint.setAgencyId(value);
			return true;
		}
		if (fieldName.equals("isFinal")) {
			maint.setFinalStructure( Boolean.parseBoolean(value) );
			return true;
		}
		if (fieldName.equals("version")) {
			maint.setVersion(value);
			return true;
		}
		if (fieldName.equals("validFrom")) {
			maint.setStartDate(SdmxJsonDateUtil.readDate(jReader));
			return true;
		} 
		if (fieldName.equals("validTo")) {
			maint.setEndDate(SdmxJsonDateUtil.readDate(jReader));
			return true;
		} 
		return false;
	}
}