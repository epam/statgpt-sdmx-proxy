package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonOrganisationUnitSchemeWriterEngine extends SdmxJsonItemSchemeWriterEngine<OrganisationUnitBean, OrganisationUnitSchemeBean> implements IFusionSingleton {
	private static SdmxJsonOrganisationUnitSchemeWriterEngine INSTANCE;

	public static SdmxJsonOrganisationUnitSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonOrganisationUnitSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonOrganisationUnitSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, OrganisationUnitBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);
	}

	@Override
	protected String getItemName() {
		return "organisationUnits";
	}

}
