package io.sdmx.format.json.engine.structure.writer.sdmx;

import java.io.OutputStream;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.writer.AbstractJsonStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.JsonMaintainableStructureWriterEngine;
import io.sdmx.im.format.SDMXMetadataStandard;

public abstract class AbstractSdmxJsonStructureWriterEngine extends AbstractJsonStructureWriterEngine implements IFusionSingleton {

	protected AbstractSdmxJsonStructureWriterEngine(boolean include, SDMX_STRUCTURE_TYPE... types) {
		super(include, types);
	}

	@Override
	public void writeStructures(SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, OutputStream out) {
		try {
			super.writeStructures(beans, additionalLinks, out);
		}catch(Throwable th) {
			// TODO write error object
		}
	}

	public void loadInterceptors(INTERCEPTOR type, JsonGenerator gen, SdmxBeans beans) throws Exception {
		switch(type) {
		case BEFORE_WRITE:
			gen.writeObjectFieldStart("data");
			break;
		case AFTER_WRITE:
			gen.writeEndObject();
			break;
		}
	}

	@Override
	/**
	 * Returns the type as per the schema, or defaults to the lower case class name plus a 's' to make it plaural
	 */
	protected String getMaintainableJSONKey(SDMX_STRUCTURE_TYPE maintainableType) {
		switch(maintainableType) {
		case AGENCY_SCHEME : 			return "agencySchemes";
		case CATEGORISATION : 			return "categorisations";
		case CATEGORY_SCHEME : 			return "categorySchemes";
		case CATEGORY_SCHEME_MAP : 		return "categorySchemeMaps";
		case CODE_LIST : 				return "codelists";
		case CONCEPT_SCHEME : 			return "conceptSchemes";
		case CONCEPT_SCHEME_MAP : 		return "conceptSchemeMaps";
		case CONTENT_CONSTRAINT : 		return "contentConstraints";
		case DATAFLOW : 				return "dataflows";
		case DATA_CONSUMER_SCHEME :		return "dataConsumerSchemes";
		case DATA_PROVIDER_SCHEME :		return "dataProviderSchemes";
		case DSD :						return "dataStructures";
		case HIERARCHY :				return "hierarchicalCodelists";
		case HIERARCHY_ASSOCIATION :	return "hierarchyAssociations";
		case METADATA_CONSTRAINT :		return "metadataConstraints";
		case METADATA_FLOW :			return "metadataflows";
		case METADATA_PROVIDER_SCHEME :	return "metadataProviderSchemes";
		case METADATA_PROVISION :		return "metadataProvisionAgreements";
		case MSD :						return "metadataStructures";
		case ORGANISATION_SCHEME :		return "organisationUnitSchemes";
		case ORGANISATION_SCHEME_MAP :	return "organisationSchemeMaps";
		case ORGANISATION_UNIT_SCHEME :	return "organisationUnitSchemes";
		case PROCESS :					return "processes";
		case PROVISION_AGREEMENT :		return "provisionAgreements";
		case REPORTING_TAXONOMY :		return "reportingTaxonomies";
		case REPORTING_TAXONOMY_MAP :	return "reportingTaxonomyMaps";
		case STRUCTURE_SET :			return "structureSets";
		case VALUE_LIST :				return "valueLists";
		case VTL_CUSTOM_TYPE_SCHEME :	return "customTypeSchemes";
		case VTL_MAPPING_SCHEME :		return "vtlMappingSchemes";
		case VTL_NAME_PERSONALISATION_SCHEME : return "namePersonalisationSchemes";
		case VTL_RULESET_SCHEME :		return "rulesetSchemes";
		case VTL_TRANSFORMATION_SCHEME : return "transformationSchemes";
		case VTL_USER_DEFINED_OPERATOR_SCHEME : return "userDefinedOperatorSchemes";
		
		default :
			return maintainableType.getUrnClass().toLowerCase()+"s";
		}
	}
	
	@Override
	public boolean isSupportedType(MaintainableBean structure) {
		if(structure.getDefaultStandard() != SDMXMetadataStandard.getInstance()) {
			return false;
		}
		return super.isSupportedType(structure);
	}

	@Override
	protected String getGeographicCodelistJSONKey() {
		return null;
	}

	@Override
	protected String getGeoGridCodelistJSONKey() {
		return null;
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeographicCodelistBean> getGeographicalCodelistWriter() {
		return null;
	}

	@Override
	protected JsonMaintainableStructureWriterEngine<IGeoGridCodelistBean> getGeoGridCodelistWriter() {
		return null;
	}

}

