package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.json.JsonReader;

public abstract class FusionJsonAbstractItemSchemeReaderEngine<T extends ItemSchemeBean, V extends ItemSchemeMutableBean<X>, X extends ItemMutableBean> extends FusionJsonMaintainableBeanReaderEngineImpl<T, V> {

	@Override
	protected boolean processMaintainableProperty(String fieldName, V mutable, JsonReader jReader) {
		if (fieldName.equals("isPartial")) {
			String value = jReader.getValueAsString();
			if (value.equalsIgnoreCase("true")) {
				mutable.setPartial(true);
			} else if (value.equalsIgnoreCase("false")) {
				mutable.setPartial(false);
			} else {
				throw new SdmxSemmanticException("Illegal value for 'isPartial'. Valid values are 'true' or 'false' but the following value was supplied: " + value);
			}
			return true;
		} else if (fieldName.equals("items")) {
			List<X> itemList = readItems(jReader);
			mutable.setItems(itemList);
			ValidityPeriodUtil.processValidityAnnotations(mutable);
			return true;
		}
		return false;
	}

	protected List<X> readItems(JsonReader jReader) {
		List<X> itemList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				X aCode = readItemBean(jReader);
				if(aCode != null) {
					itemList.add(aCode);
				}
			}
		}
		return itemList;
	}
	
	protected abstract X readItemBean(JsonReader reader);
}
