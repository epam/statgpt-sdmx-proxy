package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonDataConsumerSchemeReaderEngine extends FusionJsonOrganisationSchemeReaderEngine<DataConsumerSchemeBean, DataConsumerSchemeMutableBean, DataConsumerMutableBean> implements IFusionSingleton {
	private static FusionJsonDataConsumerSchemeReaderEngine INSTANCE;

	public static FusionJsonDataConsumerSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataConsumerSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected DataConsumerMutableBean readItemBean(JsonReader jReader) {
		DataConsumerMutableBean item = new DataConsumerMutableBeanImpl();
		populateOrganisationMutableBean(jReader, item);
		return item;
	}

	@Override
	protected DataConsumerSchemeMutableBean getMutable() {
		return new DataConsumerSchemeMutableBeanImpl();
	}

    @Override
    protected Class<DataConsumerSchemeBean> getMaintainableType() {
        return DataConsumerSchemeBean.class;
    }
}