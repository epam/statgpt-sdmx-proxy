package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

import java.io.IOException;

public class SdmxJsonCustomTypeSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<ICustomTypeBean, ICustomTypeSchemeBean> implements IFusionSingleton {
	private static SdmxJsonCustomTypeSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonCustomTypeSchemeWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonCustomTypeSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonCustomTypeSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator json, IExternalMaintainableLinks externalLinks, ICustomTypeSchemeBean maint) throws JsonGenerationException, IOException {
		if (maint.getVtlVersion() != null) {
			json.writeStringField("vtlVersion", maint.getVtlVersion());
		}
		super.writeStructureInternal(json, externalLinks, maint);
	}

	@Override
	protected void writeItemDetails(JsonGenerator json, IExternalMaintainableLinks externalLinks, ICustomTypeBean item) throws JsonGenerationException, IOException {
		if (item.getVtlScalarType() != null) {
			json.writeStringField("vtlScalarType", item.getVtlScalarType());
		}
		if (item.getDataType() != null) {
			json.writeStringField("dataType", item.getDataType());
		}
		if (item.getVtlLiteralFormat() != null) {
			json.writeStringField("vtlLiteralFormat", item.getVtlLiteralFormat());
		}
		if (item.getOutputFormat() != null) {
			json.writeStringField("outputFormat", item.getOutputFormat());
		}
		if (item.getNullValue() != null) {
			json.writeStringField("nullValue", item.getNullValue());
		}
	}

	@Override
	protected String getItemName() {
		return "customTypes";
	}
}
