package io.sdmx.format.json.factory.structure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.IStructureTransactionWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.IStructureTransactionWriterFactory;
import io.sdmx.format.json.engine.transaction.StructureTransactionWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.GenericFormatJSON;

public class StructureTransactionWriterFactoryJson implements IStructureTransactionWriterFactory , IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(StructureTransactionWriterFactoryJson.class);

	private static StructureTransactionWriterFactoryJson INSTANCE;

	//Private constructor - lazy load instance
	public static StructureTransactionWriterFactoryJson getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureTransactionWriterFactoryJson();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	public static StructureTransactionWriterFactoryJson registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private StructureTransactionWriterFactoryJson() {}

	@Override
	public IStructureTransactionWriterEngine getStructureWriterEngine(InformationFormat format) {
		if(LOG.isDebugEnabled()) {
			LOG.debug("getStructureWriterEngine request "+format);
		}
		if(format == GenericFormatJSON.getInstance()) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("getStructureWriterEngine request return StructureTransactionWriterEngine");
			}
			return StructureTransactionWriterEngine.getInstance();
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("getStructureWriterEngine request return null");
		}
		return null;
	}

}
