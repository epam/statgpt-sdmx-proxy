package io.sdmx.format.json.engine.structure.writer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;

public interface JsonMaintainableStructureWriterEngine<T extends MaintainableBean> {

	/**
	 * Writes a maintainable object as a JSON object
	 * @param maint
	 */
	void writeStructure(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T maintainable)  throws JsonGenerationException, IOException ;
	
	/**
	 * Returns the supported structure type
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getSupportedType();
}
