package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonCategorySchemeReaderEngineV2 extends SdmxJsonItemSchemeReaderEngineV2<CategoryMutableBean, CategorySchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonCategorySchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonCategorySchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorySchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	

    @Override
    public String getContainerElement() {
        return "categorySchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return CategorySchemeBean.class;
    }

    @Override
    protected CategorySchemeMutableBean getMutable() {
        return new CategorySchemeMutableBeanImpl();
    }

	@Override
	protected List<CategoryMutableBean> readItems(JsonReader jReader) {
		List<CategoryMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				CategoryMutableBean aCategoryMutable = readCategoryBean(jReader);
				returnList.add(aCategoryMutable);
			}
		}

		return returnList;
	}

	private CategoryMutableBean readCategoryBean(JsonReader jReader) {
		CategoryMutableBean aCategory = new CategoryMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			if(SdmxJsonNameableUtil.processBean(aCategory, jReader)) {
                continue;
            }

			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals(getItemLabel())) {
				aCategory.setItems(readItems(jReader));
			}
		}

		return aCategory;
	}

	@Override
	protected String getItemLabel() {
		return "categories";
	}
}
