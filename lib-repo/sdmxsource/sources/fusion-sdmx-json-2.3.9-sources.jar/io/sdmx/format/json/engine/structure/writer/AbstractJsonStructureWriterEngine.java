package io.sdmx.format.json.engine.structure.writer;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.core.sdmx.engine.structure.AbstractStructureWriterEngine;
import io.sdmx.core.sdmx.util.StructureWriterUtil;
import io.sdmx.format.json.engine.structure.writer.sdmx.AbstractSdmxJsonStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.sdmx.v1.SdmxJsonStructureWriterEngine;
import io.sdmx.format.json.util.SdmxJsonWriterUtil;
import io.sdmx.im.util.ItemValidityPeriodHelper;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;

public abstract class AbstractJsonStructureWriterEngine  extends AbstractStructureWriterEngine  {
	private Map<SDMX_STRUCTURE_TYPE, JsonMaintainableStructureWriterEngine<? extends MaintainableBean>> writers = new HashMap<>();


	protected AbstractJsonStructureWriterEngine(boolean include, SDMX_STRUCTURE_TYPE... types) {
		super(include, types);
	}

	protected AbstractJsonStructureWriterEngine(boolean include, Collection<SDMX_STRUCTURE_TYPE> types) {
		super(include, types);
	}

	/**
	 * Register a reader capable of processing JSON to the given format with the manager
	 * @param writer
	 */
	public void registerWriter(JsonMaintainableStructureWriterEngine<? extends MaintainableBean> writer) {
		writers.put(writer.getSupportedType(), writer);
	}


	@Override
	public void writeStructure(MaintainableBean bean, IExternalMaintainableLinks additionalLinks, OutputStream out) {
		StructureWriterUtil.writeStructure(this, bean, additionalLinks, out);
	}
	
	protected JsonGenerator createWriter(OutputStream out) {
	    return JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON);
	}

	@Override
	public void writeStructures(SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, OutputStream out) {
		ThreadLocalUtil.storeOnThread(AnnotableBean.INCLUDE_INTERNAL_KEY, Boolean.TRUE);
		try(JsonGenerator jsonGenerator = createWriter(out)) {
			jsonGenerator.writeStartObject();
			writeMeta(jsonGenerator, beans);
			if(this instanceof AbstractSdmxJsonStructureWriterEngine) {
				((AbstractSdmxJsonStructureWriterEngine)this).loadInterceptors(INTERCEPTOR.BEFORE_WRITE, jsonGenerator, beans);
			}
			for(SDMX_STRUCTURE_TYPE maintainableType : SDMX_STRUCTURE_TYPE.getMaintainableStructureTypes()) {
				JsonMaintainableStructureWriterEngine<?> writer = writers.get(maintainableType);
				if(writer != null) {
					String arrayName = getMaintainableJSONKey(maintainableType);
					if(maintainableType == SDMX_STRUCTURE_TYPE.CODE_LIST) {
						Set<MaintainableBean> standardCodelists = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
						Set<IGeographicCodelistBean> geographicalCodelists = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
						Set<IGeoGridCodelistBean> geoCodelists = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);

						for(CodelistBean cl : beans.getCodelists()) {
							if(cl.isGeoCodelist()) {
								if(cl instanceof IGeographicCodelistBean) {
									geographicalCodelists.add((IGeographicCodelistBean)cl);
								} else if(cl instanceof IGeoGridCodelistBean) {
									geoCodelists.add((IGeoGridCodelistBean)cl);
								}
							} else {
								standardCodelists.add(cl);
							}
						}
						writeStructuresOfType(jsonGenerator, geographicalCodelists, additionalLinks, getGeographicCodelistJSONKey(), getGeographicalCodelistWriter());
						writeStructuresOfType(jsonGenerator, geoCodelists, additionalLinks, getGeoGridCodelistJSONKey(), getGeoGridCodelistWriter());
						writeStructuresOfType(jsonGenerator, standardCodelists, additionalLinks, arrayName, writer);
					} else {
						Set<MaintainableBean> maintainables = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
						maintainables.addAll(beans.getMaintainables(maintainableType));
						writeStructuresOfType(jsonGenerator, maintainables, additionalLinks, arrayName, writer);
					}
					
				}
			}
			jsonGenerator.writeEndObject();

			if(this instanceof SdmxJsonStructureWriterEngine) {
				((SdmxJsonStructureWriterEngine)this).loadInterceptors(INTERCEPTOR.AFTER_WRITE, jsonGenerator, beans);
			}
		} catch (Exception e) {
			throw new SdmxException(e,"Error writing structures in JSON");
		} finally {
			ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
		}
	}
	

	protected abstract String getSchemaLocation();
	
	public void writeMeta(JsonGenerator gen, SdmxBeans beans) throws IOException {
		SdmxJsonWriterUtil.writeMeta(gen, beans, getSchemaLocation());
	}
	
	private void writeStructuresOfType(JsonGenerator jsonGenerator, Set<? extends MaintainableBean> maintainables, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, String arrayName, JsonMaintainableStructureWriterEngine writer) throws IOException {
		if(ObjectUtil.validCollection(maintainables) && writer != null) {
			if(additionalLinks == null) {
				additionalLinks = Collections.emptyMap();
			}
			jsonGenerator.writeArrayFieldStart(arrayName);
			for(MaintainableBean maint : maintainables) {
				if(maint instanceof ValidatableBean){
					maint = ItemValidityPeriodHelper.potentiallyMutateIt((ValidatableBean<?>) maint);
				}else if(maint instanceof StructureSetBean){
					maint =  ItemValidityPeriodHelper.potentiallyMutateIt((StructureSetBean)maint);
				}
				writer.writeStructure(jsonGenerator, additionalLinks.get(maint.getURN()),  maint);
			}
			jsonGenerator.writeEndArray();
		}
	}

	/**
	 * returns the key to use for the maintainable array
	 */
	protected abstract String getMaintainableJSONKey(SDMX_STRUCTURE_TYPE maintainableType);
	protected abstract String getGeographicCodelistJSONKey();
	protected abstract String getGeoGridCodelistJSONKey();
	
	
	protected abstract JsonMaintainableStructureWriterEngine<IGeographicCodelistBean> getGeographicalCodelistWriter();
	protected abstract JsonMaintainableStructureWriterEngine<IGeoGridCodelistBean> getGeoGridCodelistWriter();

	protected static enum INTERCEPTOR{
		BEFORE_WRITE,
		AFTER_WRITE
	}
}
