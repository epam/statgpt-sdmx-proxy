package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonContentConstraintWriterEngineV2 extends SdmxJsonAbstractConstraintWriterEngineV2<ContentConstraintBean> implements IFusionSingleton {
	
	private static SdmxJsonContentConstraintWriterEngineV2 INSTANCE;

	public static SdmxJsonContentConstraintWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonContentConstraintWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonContentConstraintWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ContentConstraintBean maint) throws IOException {
		jsonGenerator.writeStringField("role", maint.isDefiningActualDataPresent() ? "Actual" : "Allowed");
		if (!maint.isExternalReference()) {
            super.writeStructureInternal(jsonGenerator, externalLinks, maint);
            writeCubeRegion(getAsList(maint), jsonGenerator, maint);
            writeReleaseCalendar(maint.getReleaseCalendar(), jsonGenerator);
        }
	}

	private void writeReleaseCalendar(ReleaseCalendarBean relCal, JsonGenerator jsonGenerator) throws IOException {
		if(relCal != null) {
			jsonGenerator.writeObjectFieldStart("releaseCalendar");
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "offset", relCal.getOffset());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "periodicity", relCal.getPeriodicity());
			SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "tolerance", relCal.getTolerance());
			jsonGenerator.writeEndObject();
		}
	}

	private void writeCubeRegion(List<CubeRegionBean> asList, JsonGenerator jsonGenerator, ContentConstraintBean maint) throws IOException {
		if(asList.isEmpty()) {
			return;
		}
		jsonGenerator.writeArrayFieldStart("cubeRegions");
		for (CubeRegionBean cubeRegionBean : asList) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeBooleanField("include", isCubeIncluded(cubeRegionBean, maint));
			writeKeyValues(cubeRegionBean.getKeyValues(), "keyValues", jsonGenerator);
			writeKeyValues(cubeRegionBean.getAttributeValues(), "components", jsonGenerator);
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeKeyValues(List<KeyValues> kvsList, String nodeName, JsonGenerator jsonGenerator) throws IOException {
		if(!ObjectUtil.validCollection(kvsList)) {
			return;
		}
		jsonGenerator.writeArrayFieldStart(nodeName);
		for(KeyValues kvs : kvsList) {
			writeKeyValues(kvs, jsonGenerator);
		}
		jsonGenerator.writeEndArray();
	}

	private void writeKeyValues(KeyValues kvs, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();
		SdmxJsonStaticHelper.writeNonNullString(jsonGenerator, "id", kvs.getId());
		if(kvs.isRemovePrefix()) {
			jsonGenerator.writeBooleanField("removePrefix", kvs.isRemovePrefix());
		}
		writeTimeRange(jsonGenerator, kvs.getTimeRange());
		if(!kvs.getValues().isEmpty()) {
			jsonGenerator.writeArrayFieldStart("values");
			writeKeyValues(kvs, kvs.getValues(), kvs.getCascadeValues(), false, jsonGenerator);
			writeKeyValues(kvs, kvs.getCascadeExcludeRoot(), kvs.getCascadeValues(), true, jsonGenerator);
			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndObject();
	}
	
	private void writeKeyValues(KeyValues kvs, Set<String> codesToIterate, Set<String> cascade, boolean excludeRoot, JsonGenerator jsonGenerator) throws IOException {
			for(String val : codesToIterate) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField("value", val);
				if(excludeRoot) {
					jsonGenerator.writeStringField("cascadeValues", "excluderoot");
				} else  if(cascade.contains(val)) {
					jsonGenerator.writeBooleanField("cascadeValues", true);
				}
				if(kvs.getValidityPeriod(val) != null) {
					SdmxPeriod period = kvs.getValidityPeriod(val);
					if(period.getStartPeriod() != null) {
						jsonGenerator.writeStringField("validFrom", period.getStartPeriod().getDateInSdmxFormat());
					}
					if(period.getEndPeriod() != null) {
						jsonGenerator.writeStringField("validTo", period.getEndPeriod().getDateInSdmxFormat());
					}
				}
				jsonGenerator.writeEndObject();
			}
	}

	private void writeTimeRange(JsonGenerator jsonGenerator, TimeRangeBean timeRange) throws IOException {
		if(timeRange == null) {
			return;
		}
		jsonGenerator.writeObjectFieldStart("timeRange");
		SdmxDate startDate = timeRange.getStartDate();
		SdmxDate endDate = timeRange.getEndDate();
		if(timeRange.isRange()) {
			jsonGenerator.writeObjectFieldStart("startPeriod");
			jsonGenerator.writeStringField("period", startDate.getDateInSdmxFormat());
			jsonGenerator.writeBooleanField("isInclusive", timeRange.isStartInclusive());
			jsonGenerator.writeEndObject();

			jsonGenerator.writeObjectFieldStart("endPeriod");
			jsonGenerator.writeStringField("period", endDate.getDateInSdmxFormat());
			jsonGenerator.writeBooleanField("isInclusive", timeRange.isEndInclusive());
			jsonGenerator.writeEndObject();
		}else {
			if(startDate == null) {
				jsonGenerator.writeObjectFieldStart("afterPeriod");
				jsonGenerator.writeStringField("period", endDate.getDateInSdmxFormat());
				jsonGenerator.writeBooleanField("isInclusive", timeRange.isEndInclusive());
				jsonGenerator.writeEndObject();
			}else {
				jsonGenerator.writeObjectFieldStart("beforePeriod");
				jsonGenerator.writeStringField("period", startDate.getDateInSdmxFormat());
				jsonGenerator.writeBooleanField("isInclusive", timeRange.isStartInclusive());
				jsonGenerator.writeEndObject();
			}
		}
		jsonGenerator.writeEndObject();
	}

	private List<CubeRegionBean> getAsList(ContentConstraintBean maint){
		List<CubeRegionBean> retList =  new ArrayList<>();
		CubeRegionBean includeCube = maint.getIncludedCubeRegion();
		CubeRegionBean excludeCube = maint.getExcludedCubeRegion();
		if(includeCube != null) {
			retList.add(includeCube);
		}

		if(excludeCube != null) {
			retList.add(excludeCube);
		}
		return retList;
	}

	private boolean isCubeIncluded(CubeRegionBean cube, ContentConstraintBean maint) {
		if(cube == maint.getIncludedCubeRegion()) {
			return true;
		}
		if(cube == maint.getExcludedCubeRegion()) {
			return false;
		}
		throw new RuntimeException("Unable to parse CubeRegion");
	}
}
