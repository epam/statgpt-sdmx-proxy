package io.sdmx.format.json.engine.metadata.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMaintainableBeanReaderEngineImpl;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.base.TextTypeMutableBeanImpl;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataAttributeMutableBean;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataSetMutableBean;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonMetadataSetReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<IReportedMetadataSetBean, IReportedMetadataSetMutableBean>  {
	private static final FusionJsonMetadataSetReaderEngine INSTANCE = new FusionJsonMetadataSetReaderEngine();
	
	public static FusionJsonMetadataSetReaderEngine getInstance() {
		return INSTANCE;
	}

	@Override
	protected IReportedMetadataSetMutableBean getMutable() {
		return new ReportedMetadataSetMutableBean();
	}
	
	@Override
    protected Class<IReportedMetadataSetBean> getMaintainableType() {
        return IReportedMetadataSetBean.class;
    }

	@Override
	protected boolean processMaintainableProperty(String fieldName, IReportedMetadataSetMutableBean mds, JsonReader jReader) {
		switch(fieldName) {
		case FusionJsonMetadataSyntaxConstants.METADATAFLOW :
			mds.setStructure(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.METADATA_FLOW));
			return true;
		case FusionJsonMetadataSyntaxConstants.METADATAPROVISION :
			mds.setStructure(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.METADATA_PROVISION));
			return true;
		case FusionJsonMetadataSyntaxConstants.TARGETS :
			for(String target : jReader.readStringArray()) {
				mds.addTarget(new StructureReferenceBeanImpl(target));
			}
			return true;
		case FusionJsonMetadataSyntaxConstants.ATTRIBUTES :
			mds.setAttributes(parseAttributes(jReader));
			return true;
		}
		return false;
	}
	
	private static List<IReportedMetadataAttributeMutableBean> parseAttributes(JsonReader jReader) {
		List<IReportedMetadataAttributeMutableBean> attributes = new ArrayList<>();
		while(jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				attributes.add(parseAttribute(jReader));
			}
		}
		return attributes;
	}
	
	
	private static IReportedMetadataAttributeMutableBean parseAttribute(JsonReader jReader) {
		IReportedMetadataAttributeMutableBean attribute = new ReportedMetadataAttributeMutableBean();
		while(jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "id" : 
				attribute.setId(jReader.getValueAsString());
				break;
			case FusionJsonMetadataSyntaxConstants.SIMPLE_VALUE :
				if(jReader.isStartObject()) {
					List<TextTypeWrapperMutableBean> text = SdmxJsonNameableUtil.readTextTypeWrappers(jReader);
					TextTypeMutableBean tt = new TextTypeMutableBeanImpl();
					tt.setText(text);
					attribute.setStructuredValues(tt);
				} else {
					attribute.setValue(jReader.getValueAsString());
				}
				break;
			case FusionJsonMetadataSyntaxConstants.ATTRIBUTES :
				attribute.setAttributes(parseAttributes(jReader));
				break;
			}
		}
		return attribute;
	}
}
