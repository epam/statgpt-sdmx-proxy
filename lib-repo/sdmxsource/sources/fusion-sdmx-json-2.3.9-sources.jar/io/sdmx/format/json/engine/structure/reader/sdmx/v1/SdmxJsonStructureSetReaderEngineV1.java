package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonAnnotableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonRepresentationUtil;
import io.sdmx.im.mutable.mapping.CategorySchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodelistMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ComponentMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ConceptSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ItemMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.OrganisationSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.RepresentationMapRefMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonStructureSetReaderEngineV1 extends AbstractSdmxJsonReaderEngine<StructureSetMutableBean> implements IFusionSingleton {
	private static SdmxJsonStructureSetReaderEngineV1 INSTANCE;

	public static SdmxJsonStructureSetReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureSetReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	
	@Override
    public String getContainerElement() {
        return "structureSets";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return StructureSetBean.class;
    }

    @Override
    protected StructureSetMutableBean getMutable() {
        return new StructureSetMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, StructureSetMutableBean ss,
            JsonReader jReader) {
        switch(fieldName) {
        case "categorySchemeMaps":
            try {
                List<CategorySchemeMapMutableBeanImpl> catSchemeMaps = readItemSchemeMapBeans(jReader, CategorySchemeMapMutableBeanImpl.class, "categoryMaps");
                for (CategorySchemeMapMutableBean catMap : catSchemeMaps) {
                    ss.addCategorySchemeMap(catMap);
                }
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            return true;
        case "codelistMaps":
            try {
                List<CodelistMapMutableBeanImpl> codelistMaps = readItemSchemeMapBeans(jReader, CodelistMapMutableBeanImpl.class, "codeMaps");
                for (CodelistMapMutableBean codelistMap : codelistMaps) {
                    ss.addCodelistMap(codelistMap);
                }
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            return true;
        case "conceptSchemeMaps":
            try {
                List<ConceptSchemeMapMutableBeanImpl> conceptMaps = readItemSchemeMapBeans(jReader, ConceptSchemeMapMutableBeanImpl.class, "conceptMaps");
                for (ConceptSchemeMapMutableBean conceptMap : conceptMaps) {
                    ss.addConceptSchemeMap(conceptMap);
                }
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            return true;
        case "hybridCodelistMaps":
        case "reportingTaxonomyMaps":
        case "relatedStructures":
            throw new SdmxNotImplementedException(fieldName+ " is not supported");
        case "organisationSchemeMaps":
            try {
                List<OrganisationSchemeMapMutableBeanImpl> orgSchemeMaps = readItemSchemeMapBeans(jReader, OrganisationSchemeMapMutableBeanImpl.class, "organisationMaps");
                for (OrganisationSchemeMapMutableBean orgMap : orgSchemeMaps) {
                    ss.addOrganisationSchemeMap(orgMap);
                }
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            return true;
        case "structureMaps":
            List<StructureMapMutableBean> structureMaps = readStructureMaps(jReader);
            ss.setStructureMapList(structureMaps);
            return true;
        }
        return false;
    }

	private List<StructureMapMutableBean> readStructureMaps(JsonReader jReader) {
		List<StructureMapMutableBean> retList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			StructureMapMutableBean sMap = new StructureMapMutableBeanImpl();
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				if(SdmxJsonNameableUtil.processBean(sMap, jReader)) {
					continue;
				}
				String key = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(key) {
				case "isExtension":
					sMap.setExtension(jReader.getValueAsBoolean());
					break;
				case "componentMaps":
					List<ComponentMapMutableBean> compMaps = readComponentMaps(jReader);
					sMap.setComponents(compMaps);
					break;
				case "source":
					sMap.setSourceRef(new StructureReferenceBeanImpl(value));
					break;
				case "target":
					sMap.setTargetRef(new StructureReferenceBeanImpl(value));
					break;
				default:
					throw new RuntimeException("unknown node: " + key);
				}
			}
			retList.add(sMap);
		}
		return retList;
	}

	private List<ComponentMapMutableBean> readComponentMaps(JsonReader jReader) {
		List<ComponentMapMutableBean> retList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			ComponentMapMutableBean compMap = new ComponentMapMutableBeanImpl();
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				if(SdmxJsonAnnotableUtil.processBean(compMap, jReader)) {
					continue;
				}
				String key = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(key) {
				case "representationMapping":
					RepresentationMapRefMutableBean repMap = readRepresentationMapRef(jReader);
					compMap.setRepMapRef(repMap);
					break;
				case "source":
					compMap.setMapConceptRef(Arrays.asList(value));
					break;
				case "target":
					compMap.setMapTargetConceptRef(Arrays.asList(value));
					break;
				}
			}
			retList.add(compMap);
		}
		return retList;
	}

	private RepresentationMapRefMutableBean readRepresentationMapRef(JsonReader jReader) {
		RepresentationMapRefMutableBean ret = new RepresentationMapRefMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String key = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			switch(key) {
			case "codelistMap":
				ret.setCodelistMapRef(value);
				break;
			case "toTextFormat":
				TextFormatMutableBean rep = SdmxJsonRepresentationUtil.readTextFormat(jReader, false);
				ret.setToTextFormat(rep);
				break;
			case "toValueType":
				TO_VALUE toValue = TO_VALUE.valueOf(value.toUpperCase());
				ret.setToValueType(toValue);
				break;
			case "valueMap":
				Map<String, Set<String>> valueMaps = readValueMappings(jReader);
				ret.setValueMappings(valueMaps);
				break;
			}
		}

		return ret;
	}

	private Map<String, Set<String>> readValueMappings(JsonReader jReader) {
		Map<String, Set<String>> retMap = new HashMap<>();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			while (jReader.moveNext()) {
				if (jReader.isEndArray()) {
					break;
				}
				while (jReader.moveNext()) {
					if (jReader.isEndObject()) {
						break;
					}
					String mapKey = jReader.getCurrentFieldName();
					String mapValue = jReader.getValueAsString();
					if(!ObjectUtil.validString(mapKey, mapValue)) {
						throw new SdmxSemmanticException("Unable to construct ComponentMap as source or target was missing");
					}
					if(retMap.containsKey(mapKey)) {
						retMap.get(mapKey).add(mapValue);
					}else {
						Set<String> v = new HashSet<>();
						v.add(mapValue);
						retMap.put(mapKey, v);
					}
				}
			}
		}
		return retMap;
	}

	private <R extends ItemMapMutableBean, T extends ItemSchemeMapMutableBean<R>> List<T> readItemSchemeMapBeans(JsonReader jReader, Class<T> clazz, String childrenKey) throws InstantiationException, IllegalAccessException {
		List<T> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			T itemMapScheme = clazz.newInstance();
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				String key = jReader.getCurrentFieldName();
				if(SdmxJsonNameableUtil.processBean(itemMapScheme, jReader)) {
					continue;
				}
				if(key.equals(childrenKey)) {
					List<ItemMapMutableBean> items = readItemMaps(jReader, itemMapScheme instanceof CodelistMapMutableBean);
					for (ItemMapMutableBean item : items) {
						itemMapScheme.addItem((R) item);
					}
				}else {
					String value = jReader.getValueAsString();
					switch(key) {
					case "source":
						itemMapScheme.setSourceRef(new StructureReferenceBeanImpl(value));
						break;
					case "target":
						itemMapScheme.setTargetRef(new StructureReferenceBeanImpl(value));
						break;
					}
				}
			}
			ret.add(itemMapScheme);
		}

		return ret;
	}

	private List<ItemMapMutableBean> readItemMaps(JsonReader jReader, boolean isCodeMap) {
		List<ItemMapMutableBean> ret = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			ItemMapMutableBean itemMap;
			if(isCodeMap) {
				itemMap = new CodeMapMutableBeanImpl();
			}else {
				itemMap = new ItemMapMutableBeanImpl();
			}
			while (jReader.moveNext()) {
				if (jReader.isEndObject()) {
					break;
				}
				if(SdmxJsonAnnotableUtil.processBean(itemMap, jReader)) {
					continue;
				}
				String key = jReader.getCurrentFieldName();
				String value = jReader.getValueAsString();
				switch(key) {
				case "source":
					itemMap.setSourceId(value);
					break;
				case "target":
					itemMap.setTargetId(value);
					break;
				}
			}
			ret.add(itemMap);
		}
		return ret;
	}

}
