package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonDataConsumerSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<DataConsumerBean, DataConsumerSchemeBean> implements IFusionSingleton {
	private static SdmxJsonDataConsumerSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonDataConsumerSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonDataConsumerSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonDataConsumerSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, DataConsumerBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);

	}

	@Override
	protected String getItemName() {
		return "dataConsumers";
	}

}
