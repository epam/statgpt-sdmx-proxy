package io.sdmx.format.json.engine.data.reader;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.json.JsonReader.Iterator;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;

public class DataSetIterator extends AbstractIterator {
	
	
	public DataSetIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	@Override
	public void next(String fieldName) {
		
		super.next(fieldName);
	}

	@Override
	public Iterator start(String fieldName, boolean isObject) {
		// TODO Auto-generated method stub
		return super.start(fieldName, isObject);
	}


	
	
}
