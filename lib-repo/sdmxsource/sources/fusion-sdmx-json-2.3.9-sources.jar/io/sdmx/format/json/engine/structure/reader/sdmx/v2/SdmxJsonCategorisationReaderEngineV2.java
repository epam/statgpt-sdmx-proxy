package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonCategorisationReaderEngineV2 extends AbstractSdmxJsonReaderEngine<CategorisationMutableBean> implements IFusionSingleton {
	private static SdmxJsonCategorisationReaderEngineV2 INSTANCE;

	public static SdmxJsonCategorisationReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorisationReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}
	

    @Override
    public String getContainerElement() {
        return "categorisations";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return CategorisationBean.class;
    }

    @Override
    protected CategorisationMutableBean getMutable() {
        return new CategorisationMutableBeanImpl();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, CategorisationMutableBean mutable,
            JsonReader reader) {
        String value = reader.getValueAsString();

        switch(fieldName) {
        case "source" :
            /**
               "source": {
                    "$ref": "#/definitions/urn",
                    "description": "Source is a urn reference to an object to be categorized."
                }
             */
            StructureReferenceBean structureReference = new StructureReferenceBeanImpl(value);
            mutable.setStructureReference(structureReference);
            return true;
        case "target" :
            /**
               "target": {
                    "$ref": "#/definitions/urn",
                    "description": "Target is a urn reference to the category that the referenced object is to be mapped to.""
                }
             */
            StructureReferenceBean categoryRef = new StructureReferenceBeanImpl(value);
            mutable.setCategoryReference(categoryRef);
            return true;
              
        }
        return false;
	}
}
