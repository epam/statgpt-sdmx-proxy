package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlSchemeMutableBean;
import io.sdmx.utils.json.JsonReader;

public abstract class FusionJsonAbstractVTLSchemeReaderEngine<T extends IVtlSchemeBean<? extends ItemBean>, V extends IVtlSchemeMutableBean<X>, X extends ItemMutableBean> extends FusionJsonAbstractItemSchemeReaderEngine<T, V, X> {

	@Override
	protected boolean processMaintainableProperty(String fieldName, V mutable, JsonReader jReader) {
		if(!super.processMaintainableProperty(fieldName, mutable, jReader) ) {
			if(fieldName.equals("vtlVersion")) {
				mutable.setVtlVersion(jReader.getValueAsString());
			} else {
				return false;
			}
		}
		return true;
	}
}
