package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonWriterUtil;

public class SdmxJsonMetadataProvisionWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<MetadataProvisionAgreementBean> implements IFusionSingleton {
	private static SdmxJsonMetadataProvisionWriterEngineV2 INSTANCE;

	public static SdmxJsonMetadataProvisionWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataProvisionWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonMetadataProvisionWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVISION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataProvisionAgreementBean mdp) throws JsonGenerationException, IOException {
		jsonGenerator.writeStringField("metadataflow", mdp.getMetadataflowRef().getTargetUrn());
		jsonGenerator.writeStringField("metadataProvider", mdp.getMetadataProviderRef().getTargetUrn());
		JsonWriterUtil.writeStringArray(jsonGenerator, "targets", mdp.getTargets().stream().map(e->e.getReference().toURNString()).toArray(String[]::new));
	}

}
