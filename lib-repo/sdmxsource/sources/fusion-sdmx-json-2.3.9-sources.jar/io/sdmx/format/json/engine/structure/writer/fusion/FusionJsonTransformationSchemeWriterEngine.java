package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonTransformationSchemeWriterEngine extends FusionJsonAbstractVTLSchemeWriterEngine<ITransformationSchemeBean> implements IFusionSingleton {
	private static FusionJsonTransformationSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonTransformationSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME);
	}

	public static FusionJsonTransformationSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonTransformationSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ITransformationSchemeBean maint) throws JsonGenerationException, IOException {
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
		if(maint.getVtlMappingSchemeRef() != null) {
			jsonGenerator.writeStringField("vtlMappingScheme", maint.getVtlMappingSchemeRef().getTargetUrn());
		}
		if(maint.getNamePersonalisationSchemeRef() != null) {
			jsonGenerator.writeStringField("namePersonalisationScheme", maint.getNamePersonalisationSchemeRef().getTargetUrn());
		}
		if(maint.getCustomTypeSchemeRef() != null) {
			jsonGenerator.writeStringField("customTypeScheme", maint.getCustomTypeSchemeRef().getTargetUrn());
		}
		if(maint.getRulesetSchemeRef() != null) {
			List<String> urns = maint.getRulesetSchemeRef().stream().map(e->e.getTargetUrn()).collect(Collectors.toList());
			JsonWriterUtil.writeStringArray(jsonGenerator, "rulesetSchemes", urns);
		}
		if(maint.getUserDefinedOperatorSchemeRef() != null) {
			List<String> urns = maint.getUserDefinedOperatorSchemeRef().stream().map(e->e.getTargetUrn()).collect(Collectors.toList());
			JsonWriterUtil.writeStringArray(jsonGenerator, "userDefinedOperatorScheme", urns);
		}
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		ITransformationBean item =  (ITransformationBean)itemBean;
		jsonGenerator.writeBooleanField("isPersistent", item.isPersistent());
		if(item.getExpression() != null) {
			jsonGenerator.writeStringField("expression", item.getExpression());
		}
		if(item.getResult() != null) {
			jsonGenerator.writeStringField("result", item.getResult());
		}
	}
}
