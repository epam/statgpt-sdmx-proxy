package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.sdmx.AbstractSdmxJsonReaderEngine;
import io.sdmx.format.json.engine.structure.reader.util.GenericJsonReaderUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataProvisionAgreementMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonMetadataProvisionReaderEngineV2 extends AbstractSdmxJsonReaderEngine<IMetadataProvisionAgreementMutableBean> implements IFusionSingleton {
	private static SdmxJsonMetadataProvisionReaderEngineV2 INSTANCE;

	public static SdmxJsonMetadataProvisionReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataProvisionReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "metadataProvisionAgreements";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return MetadataProvisionAgreementBean.class;
    }

    @Override
    protected IMetadataProvisionAgreementMutableBean getMutable() {
        return new MetadataProvisionAgreementMutableBean();
    }

    @Override
    protected boolean processMaintainableProperty(String fieldName, IMetadataProvisionAgreementMutableBean mutable, JsonReader reader) {
        switch(fieldName) {
        case "metadataProvider" :
            mutable.setMetadataProviderRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "metadataflow" :
            mutable.setMetadataflowRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        case "targets" :
            mutable.setTargets(GenericJsonReaderUtil.readRefArray(reader));
            return true;

        }
        return false;
    }
}
