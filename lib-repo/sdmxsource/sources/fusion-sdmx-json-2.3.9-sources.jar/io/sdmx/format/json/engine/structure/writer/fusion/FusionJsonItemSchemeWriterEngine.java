package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class FusionJsonItemSchemeWriterEngine<T extends ItemSchemeBean<? extends ItemBean>> extends FusionJsonMaintainableStructureWriterEngineImpl<T> {

	public FusionJsonItemSchemeWriterEngine(SDMX_STRUCTURE_TYPE sypportedType) {
		super(sypportedType);
	}
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, T identifiable) throws JsonGenerationException, IOException {
		List<? extends ItemBean> items = identifiable.getItems();
		jsonGenerator.writeBooleanField("isPartial", identifiable.isPartial());
		if (identifiable instanceof ValidatableBean) {
		    MAINT_VALIDITY_TYPE validitityType = ((ValidatableBean<?>) identifiable).getValidityType();
		    if(validitityType != null) {
		        jsonGenerator.writeStringField("validityType", validitityType.toString());
		    }
		}
		writeItems(jsonGenerator, externalLinks, items);
	}

	protected void writeItems(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, List<? extends ItemBean> items) throws JsonGenerationException, IOException {
		if (!ObjectUtil.validCollection(items)) {
			return;
		}

		jsonGenerator.writeArrayFieldStart("items");
		for(ItemBean currentItem : items) {
			writeItem(jsonGenerator,  externalLinks, currentItem);
		}
		jsonGenerator.writeEndArray();
	}

	protected void writeItem(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean currentItem) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartObject();
		writeNameable(jsonGenerator, externalLinks, currentItem);
		writeItemDetails(jsonGenerator, externalLinks, currentItem);
		jsonGenerator.writeEndObject();
	}

	protected abstract void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  ItemBean item) throws JsonGenerationException, IOException;
}
