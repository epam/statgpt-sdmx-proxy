package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.categoryscheme.ReportingCategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonReportingTaxonomyReaderEngineV2 extends SdmxJsonItemSchemeReaderEngineV2<ReportingCategoryMutableBean, ReportingTaxonomyMutableBean> implements IFusionSingleton {
	private static SdmxJsonReportingTaxonomyReaderEngineV2 INSTANCE;

	public static SdmxJsonReportingTaxonomyReaderEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonReportingTaxonomyReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "reportingTaxonomies";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return ReportingTaxonomyBean.class;
    }

    @Override
    protected ReportingTaxonomyMutableBean getMutable() {
        return new ReportingTaxonomyMutableBeanImpl();
    }

	@Override
	protected List<ReportingCategoryMutableBean> readItems(JsonReader jReader) {
		List<ReportingCategoryMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ReportingCategoryMutableBean reportTax = readReportingCategories(jReader);
				returnList.add(reportTax);
			}
		}
		return returnList;
	}

	private ReportingCategoryMutableBean readReportingCategories(JsonReader jReader) {
		ReportingCategoryMutableBean ret = new ReportingCategoryMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if (SdmxJsonNameableUtil.processBean(ret, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals(getItemLabel())) {
				ret.setItems(readItems(jReader));
			} else if (fieldName.equals("provisioningMetadata")) {
				while (jReader.moveNext()) {
					if (jReader.isEndArray()) {
						break;
					}
					ret.addProvisioningMetadata(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				}
			} else if (fieldName.equals("structuralMetadata")) {
				while (jReader.moveNext()) {
					if (jReader.isEndArray()) {
						break;
					}
					ret.addStructuralMetadata(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				}
			}
		}
		return ret;
	}

	@Override
	protected String getItemLabel() {
		return "reportingCategories";
	}
}
