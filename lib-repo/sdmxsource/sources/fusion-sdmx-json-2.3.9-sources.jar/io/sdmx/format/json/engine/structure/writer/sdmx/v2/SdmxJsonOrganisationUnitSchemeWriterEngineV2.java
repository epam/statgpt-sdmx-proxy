package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import java.io.IOException;

public class SdmxJsonOrganisationUnitSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<OrganisationUnitBean, OrganisationUnitSchemeBean> implements IFusionSingleton {
	private static SdmxJsonOrganisationUnitSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonOrganisationUnitSchemeWriterEngineV2 getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SdmxJsonOrganisationUnitSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private SdmxJsonOrganisationUnitSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, OrganisationUnitBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);

		if (item.hasParentUnit()) {
			jsonGenerator.writeStringField("parent", item.getParentUnit());
		}
	}

	@Override
	protected String getItemName() {
		return "organisationUnits";
	}
}
