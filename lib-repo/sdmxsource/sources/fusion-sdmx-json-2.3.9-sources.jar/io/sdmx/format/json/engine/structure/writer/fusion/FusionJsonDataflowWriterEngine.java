package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonDataflowWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<DataflowBean> implements IFusionSingleton {
	private static FusionJsonDataflowWriterEngine INSTANCE;

	public static FusionJsonDataflowWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonDataflowWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonDataflowWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.DATAFLOW);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator,IExternalMaintainableLinks externalLinks, DataflowBean aDataflow) throws JsonGenerationException, IOException {
		ICrossReferenceBean<DataStructureBean> dataStructureRef = aDataflow.getDataStructureRef();
		jsonGenerator.writeStringField("dataStructureRef", dataStructureRef.getReference().getURN());
	}
}
