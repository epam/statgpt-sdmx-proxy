package io.sdmx.format.json.constant;

public class SDMX_JSON_SCHEMA {

	public static final String STRUCTURE_V1_OLD =    "https://raw.githubusercontent.com/sdmx-twg/sdmx-json/develop/structure-message/tools/schemas/1.0/sdmx-json-structure-schema.json";
	public static final String STRUCTURE_V1 =        "https://json.sdmx.org/1.0/sdmx-json-structure-schema.json";
	public static final String STRUCTURE_V2_OLD =    "https://raw.githubusercontent.com/sdmx-twg/sdmx-json/develop/structure-message/tools/schemas/2.0.0/sdmx-json-structure-schema.json";
    public static final String STRUCTURE_V2 =        "https://json.sdmx.org/2.0.0/sdmx-json-structure-schema.json";
	public static final String STRUCTURE_V2_1 =      "https://json.sdmx.org/2.1.0/sdmx-json-structure-schema.json";

	public static final String REF_METADATA_V2_OLD = "https://raw.githubusercontent.com/sdmx-twg/sdmx-json/master/metadata-message/tools/schemas/2.0.0/sdmx-json-metadata-schema.json";
	public static final String REF_METADATA_V2 =     "https://json.sdmx.org/2.0.0/sdmx-json-metadata-schema.json";
	public static final String REF_METADATA_V2_1 =   "https://json.sdmx.org/2.1.0/sdmx-json-metadata-schema.json";
 
	public static final String DATA_V1_OLD =         "https://raw.githubusercontent.com/sdmx-twg/sdmx-json/develop/data-message/tools/schemas/1.0/sdmx-json-data-schema.json";
	public static final String DATA_V1 =             "https://json.sdmx.org/1.0/sdmx-json-data-schema.json";
	public static final String DATA_V2_OLD =         "https://raw.githubusercontent.com/sdmx-twg/sdmx-json/develop/data-message/tools/schemas/2.0.0/sdmx-json-data-schema.json";
	public static final String DATA_V2 =             "https://json.sdmx.org/2.0.0/sdmx-json-data-schema.json";
    public static final String DATA_V2_1 =           "https://json.sdmx.org/2.1.0/sdmx-json-data-schema.json";
}
