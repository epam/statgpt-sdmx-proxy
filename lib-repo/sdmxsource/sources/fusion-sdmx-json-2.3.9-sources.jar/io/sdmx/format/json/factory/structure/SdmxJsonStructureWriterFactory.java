package io.sdmx.format.json.factory.structure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.StructureWriterFactory;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.engine.structure.writer.sdmx.v1.SdmxJsonStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.sdmx.v2.SdmxJsonStructureWriterEngineV2;
import io.sdmx.format.json.model.SdmxJsonStructureFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonStructureWriterFactory implements StructureWriterFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxJsonStructureWriterFactory.class);
	private static SdmxJsonStructureWriterFactory INSTANCE;
	
	public static SdmxJsonStructureWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonStructureWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxJsonStructureWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private SdmxJsonStructureWriterFactory() {}

	@Override
	public StructureWriterEngine getStructureWriterEngine(StructureFormat outputFormat) {
		if(outputFormat == SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V1)) {
			LOG.debug("Creating an SdmxJsonStructureWriterEngine v1.0.0");
			return SdmxJsonStructureWriterEngine.getInstance();
		}
		if(outputFormat == SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V2)) {
			LOG.debug("Creating an SdmxJsonStructureWriterEngine v2.0.0");
			return SdmxJsonStructureWriterEngineV2.getInstance();
		}
		return null;
	}

	@Override
	public Integer getPriority() {
		return 1;
	}
}