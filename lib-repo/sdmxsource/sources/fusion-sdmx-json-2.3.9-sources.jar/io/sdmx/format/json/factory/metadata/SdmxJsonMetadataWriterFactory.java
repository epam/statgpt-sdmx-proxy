package io.sdmx.format.json.factory.metadata;

import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataWriterFactory;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.engine.metadata.sdmx.v2.SdmxJsonMetadataSetWriterEngineV2;
import io.sdmx.format.json.model.SdmxJsonMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxJsonMetadataWriterFactory implements IMetadataWriterFactory, IFusionSingleton {
	private static SdmxJsonMetadataWriterFactory INSTANCE;
	
	//Private constructor - lazy load instance
	public static SdmxJsonMetadataWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxJsonMetadataWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	public IMetadataWriterEngine getMetadataWriterEngine(IMetadataFormat outputFormat) {
		if(outputFormat == SdmxJsonMetadataFormat.getInstance(SDMXJSON_VERSION.V2)) {
			return SdmxJsonMetadataSetWriterEngineV2.getInstance();
		}
		return null;
	}
}
