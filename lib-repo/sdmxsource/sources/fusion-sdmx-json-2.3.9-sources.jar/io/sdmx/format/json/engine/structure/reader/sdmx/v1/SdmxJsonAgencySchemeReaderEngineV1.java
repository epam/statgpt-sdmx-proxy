package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

/**
 * https://json.sdmx.org/1.0/sdmx-json-structure-schema.json
 */
public class SdmxJsonAgencySchemeReaderEngineV1 extends SdmxJsonOrganisationSchemeReaderEngineV1<AgencyMutableBean, AgencySchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonAgencySchemeReaderEngineV1 INSTANCE;

	public static SdmxJsonAgencySchemeReaderEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonAgencySchemeReaderEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected List<AgencyMutableBean> readItems(JsonReader jReader) {
		List<AgencyMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				AgencyMutableBean anAgency = new AgencyMutableBeanImpl();
				populateOrganisationMutableBean(jReader, anAgency);
				returnList.add(anAgency);
			}
		}

		return returnList;
	}

	@Override
	protected String getItemLabel() {
		return "agencies";
	}

    @Override
    protected AgencySchemeMutableBean getMutable() {
        return new AgencySchemeMutableBeanImpl();
    }

    @Override
    public String getContainerElement() {
        return "agencySchemes";
    }

    @Override
    protected Class<AgencySchemeBean> getMaintainableType() {
        return AgencySchemeBean.class;
    }
}
