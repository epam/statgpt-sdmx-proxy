package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;

public class FusionJsonContentConstraintWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<ContentConstraintBean> implements IFusionSingleton {
	private static FusionJsonContentConstraintWriterEngine INSTANCE;

	public static FusionJsonContentConstraintWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonContentConstraintWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private FusionJsonContentConstraintWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  ContentConstraintBean constraint) throws JsonGenerationException, IOException {
		//SdmxJsonStaticHelper.writeIdentifiable(jsonGenerator, constraint);
		ConstraintAttachmentBean constraintAttachment = constraint.getConstraintAttachment();
		if(constraintAttachment == null) { // if there are none just return
			return;
		}
		writeAdditionalStubInformation(jsonGenerator, constraint);
		Set<ICrossReferenceBeanBase> crossReferences = new HashSet<>();
		constraintAttachment.getCrossReferences(crossReferences);
		jsonGenerator.writeArrayFieldStart("attachments");
		for (ICrossReferenceBeanBase crossReferenceBean : crossReferences) {
			jsonGenerator.writeString(crossReferenceBean.getTargetUrn());
		}
		jsonGenerator.writeEndArray();
		if(constraint.getStructureType() == SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR) {
			writeReleaseCalendar(jsonGenerator, constraint.getReleaseCalendar());
		} else if(constraint.isCubeRegion()) {
			writeCubeRegion(jsonGenerator, constraint.getIncludedCubeRegion(), "includeCube");
			writeCubeRegion(jsonGenerator, constraint.getExcludedCubeRegion(), "excludeCube");
		} else {
			ConstraintDataKeySetBean includedSeriesKeys = constraint.getIncludedSeriesKeys();
			ConstraintDataKeySetBean excludedSeriesKeys = constraint.getExcludedSeriesKeys();
			writeConstraintDataKeySetBean(jsonGenerator, includedSeriesKeys, "includeSeries");
			writeConstraintDataKeySetBean(jsonGenerator, excludedSeriesKeys, "excludeSeries");
		}
	}

	@Override
	protected void writeAdditionalStubInformation(JsonGenerator jsonGenerator, ContentConstraintBean constraint) throws IOException {
		jsonGenerator.writeBooleanField("definingDataPresent", constraint.isDefiningActualDataPresent());
		if(constraint.getStructureType() == SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR) {
			jsonGenerator.writeStringField("type", "AdvanceReleaseCalendar");
		} else if(constraint.isCubeRegion()) {
			jsonGenerator.writeStringField("type", "CubeRegionConstraint");
		} else {
			jsonGenerator.writeStringField("type", "SeriesConstraint");
		}
	}

	private void writeReleaseCalendar(JsonGenerator jsonGenerator, ReleaseCalendarBean releaseCalendar) throws IOException {
		if(releaseCalendar != null) {
			jsonGenerator.writeObjectFieldStart("releaseCalendar");
			jsonGenerator.writeStringField("tolerance", releaseCalendar.getTolerance().toString());
			jsonGenerator.writeStringField("offset", releaseCalendar.getOffset().toString());
			jsonGenerator.writeStringField("periodicity", releaseCalendar.getPeriodicity().toString());
			jsonGenerator.writeEndObject();
		}
	}

	private void writeCubeRegion(JsonGenerator jsonGenerator, CubeRegionBean cubeRegion, String type) throws IOException {
		if(cubeRegion != null) {
			jsonGenerator.writeObjectFieldStart(type);
			writeKVComponents(jsonGenerator, cubeRegion.getKeyValues());
			writeKVComponents(jsonGenerator, cubeRegion.getAttributeValues());
			jsonGenerator.writeEndObject();
		}
	}

	/**
	 * "DimOne": {
          "removePrefix": false,
          "values": ["_X","_Z"],
          "cascade": [],
          "cascadeExcludeRoot" : [],
          "validity" : {
          	"_Z" : ["", ""]
          }
        }
	 * @param jsonGenerator
	 * @param keyValues
	 * @throws IOException
	 */
    private void writeKVComponents(JsonGenerator jsonGenerator, List<KeyValues> keyValues) throws IOException {
        for (KeyValues keyValue : keyValues) {
        	jsonGenerator.writeObjectFieldStart(keyValue.getId());
        	jsonGenerator.writeBooleanField("removePrefix", keyValue.isRemovePrefix());
        	
        	Map<String, SdmxPeriod> periodRestrictedCodes = new HashMap<>();
        	
        	jsonGenerator.writeArrayFieldStart("values");
        	for (String currentValue : keyValue.getValues()) {
        		jsonGenerator.writeString(currentValue);
        		SdmxPeriod period = keyValue.getValidityPeriod(currentValue);
        		if(!period.isAllPeriods()) {
        			periodRestrictedCodes.put(currentValue, period);
        		}
        	}
        	jsonGenerator.writeEndArray();
        	
        	jsonGenerator.writeArrayFieldStart("cascade");
        	for (String currentValue : keyValue.getCascadeValues()) {
        		jsonGenerator.writeString(currentValue);
        	}
        	jsonGenerator.writeEndArray();
        	
//        	if(keyValue.getCascadeExcludeRoot().size() > 0) {
//        		jsonGenerator.writeArrayFieldStart("cascadeExcludeRoot");
//        		for (String currentValue : keyValue.getCascadeExcludeRoot()) {
//        			jsonGenerator.writeString(currentValue);
//        		}
//        		jsonGenerator.writeEndArray();
//        	}
        	
        	if(periodRestrictedCodes.size() > 0) {
        		jsonGenerator.writeObjectFieldStart("validity");
        		for(String codeId : periodRestrictedCodes.keySet()) {
        			SdmxPeriod period = periodRestrictedCodes.get(codeId);
        			jsonGenerator.writeArrayFieldStart(codeId);
        			jsonGenerator.writeString(period.hasStartPeriod() ? period.getStartPeriod().getDateInSdmxFormat() : null);
        			jsonGenerator.writeString(period.hasEndPeriod() ? period.getEndPeriod().getDateInSdmxFormat() : null);
            		jsonGenerator.writeEndArray();
        		}
        		jsonGenerator.writeEndObject();
        	}
        	jsonGenerator.writeEndObject();
        }
    }

    /**
     * "includeSeries" : {
     * 		rows : [
     * 			["A", "B", "C"],
     * 			["D", null, "F"]
     * 			["D", ["A", "B"], "F"]
     * 		],
     * 		validity : {
     * 			"2" :  ["2008", "2009"]
     * 		},
     * 		componentIds : ["FREQ", "OBS_CONF", "REF_AREA"]
     * }
     * 
     * @param jsonGenerator
     * @param cdk
     * @param type includeSeries or excludeSeries
     * @throws IOException
     */
	private void writeConstraintDataKeySetBean(JsonGenerator jsonGenerator, ConstraintDataKeySetBean cdk, String type) throws IOException {
		if(cdk != null) {
			jsonGenerator.writeObjectFieldStart(type);
//			Set<String> uniqueConcepts = cdk.getConstrainedDataKeys().stream().map(e->e.getKeyValues().stream().map(f->f.getConcept()).collect(Collectors.toSet())).collect(Collectors.toSet());
			Map<String, Integer> positionMap = new HashMap<>();
			for(ConstrainedDataKeyBean dataKey : cdk.getConstrainedDataKeys()) {
				for(IConstrainedKeyValue kv : dataKey.getKeyValues()) {
					if(!positionMap.containsKey(kv.getConcept())) {
						positionMap.put(kv.getConcept(), positionMap.size());
					}
				}
			}
			int compIdsStart = positionMap.size();
			for(ConstrainedDataKeyBean dataKey : cdk.getConstrainedDataKeys()) {
				for(IConstrainedKeyValue kv : dataKey.getComponentValues()) {
					if(!positionMap.containsKey(kv.getConcept())) {
						positionMap.put(kv.getConcept(), positionMap.size());
					}
				}
			}
			
			Map<Integer, SdmxPeriod> periodMap = new HashMap<>();
			int rowIdx = 0;
			String[] componentIds = new String[positionMap.size()];
			for(String compId : positionMap.keySet()) {
				int idx = positionMap.get(compId);
				componentIds[idx] = compId;
			}
			
			jsonGenerator.writeArrayFieldStart("dims");
			for(int i=0; i < compIdsStart; i++) {
				jsonGenerator.writeString(componentIds[i]);
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeArrayFieldStart("comps");
			for(int i=compIdsStart; i < componentIds.length; i++) {
				jsonGenerator.writeString(componentIds[i]);
			}
			jsonGenerator.writeEndArray();
			
			jsonGenerator.writeArrayFieldStart("rows");
			for(ConstrainedDataKeyBean dataKey : cdk.getConstrainedDataKeys()) {
				SdmxPeriod validity = dataKey.getValidityPeriod();
				if(!validity.isAllPeriods()) {
					periodMap.put(rowIdx, validity);
				}
				
				String[] arr = new String[positionMap.size()];
				int maxArr = -1;
				maxArr = addKeyToArray(dataKey.getKeyValues(), positionMap, arr, maxArr);
				maxArr = addKeyToArray(dataKey.getComponentValues(), positionMap, arr, maxArr);
				jsonGenerator.writeStartArray();  //start row
				int written = 0;
				for(String codeId : arr) {
					jsonGenerator.writeString(codeId);
					written++;
					if(written > maxArr) {
						break;
					}
				}
				jsonGenerator.writeEndArray();  //end row
				rowIdx++;
			}
			jsonGenerator.writeEndArray();  //End rows
			
			if(periodMap.size() > 0) {
				jsonGenerator.writeObjectFieldStart("validity");
				for(Integer rowId : periodMap.keySet()) {
					SdmxPeriod period = periodMap.get(rowId);
					jsonGenerator.writeArrayFieldStart(rowId.toString());
        			jsonGenerator.writeString(period.hasStartPeriod() ? period.getStartPeriod().getDateInSdmxFormat() : null);
        			jsonGenerator.writeString(period.hasEndPeriod() ? period.getEndPeriod().getDateInSdmxFormat() : null);
            		jsonGenerator.writeEndArray();
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndObject();
		}
	}
	
	private int addKeyToArray(List<IConstrainedKeyValue> kvs, Map<String, Integer> positionMap, String[] arr, int maxArr) {
		for(IConstrainedKeyValue kv : kvs) {
			int position = positionMap.get(kv.getConcept());
			if(position > maxArr) {
				maxArr = position;
			}
			String codeId = kv.getCode();
			if(kv.isRemovePrefix()) {
				codeId = "~ "+codeId;
			}
			arr[position] = codeId;
		}
		return maxArr;
	}
}
