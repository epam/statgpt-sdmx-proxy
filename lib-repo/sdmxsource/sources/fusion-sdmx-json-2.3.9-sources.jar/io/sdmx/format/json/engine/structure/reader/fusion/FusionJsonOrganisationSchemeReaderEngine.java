package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;
import io.sdmx.utils.json.JsonReader;

public abstract class FusionJsonOrganisationSchemeReaderEngine<T extends ItemSchemeBean<? extends ItemBean>, V extends ItemSchemeMutableBean<X>, X extends ItemMutableBean> extends FusionJsonAbstractItemSchemeReaderEngine<T, V, X> {

	protected void populateOrganisationMutableBean(JsonReader jReader, OrganisationMutableBean orgMutableBean) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			FusionJsonNameableUtil.processBean(orgMutableBean, jReader);

			String fieldName = jReader.getCurrentFieldName();

			if (fieldName.equals("contacts")) {
				List<ContactMutableBean> contacts = readContacts(jReader);
				for (ContactMutableBean aContact : contacts) {
					orgMutableBean.addContact(aContact);
				}
			} else {
				processField(fieldName, jReader, orgMutableBean);
			}
		}
	}
	
	protected boolean processField(String fieldName, JsonReader reader, OrganisationMutableBean mutable) {
		return false;
	}

	protected List<ContactMutableBean> readContacts(JsonReader jReader) {
		List<ContactMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				ContactMutableBean aContact = readContact(jReader);
				returnList.add(aContact);
			}
		}

		return returnList;
	}

	protected ContactMutableBean readContact(JsonReader jReader) {
		ContactMutableBean aContact = new ContactMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			if (fieldName.equals("departments")) {
				List<TextTypeWrapperMutableBean> departments = FusionJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setDepartments(departments);
			} else if (fieldName.equals("roles")) {
				List<TextTypeWrapperMutableBean> roles = FusionJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setRoles(roles);
			} else if (fieldName.equals("names")) {
				List<TextTypeWrapperMutableBean> names = FusionJsonNameableUtil.readTextTypeWrappers(jReader);
				aContact.setNames(names);
			} else if (fieldName.equals("telephone")) {
				if (value != null) {
					aContact.addTelephone(value);
				}
			} else if (fieldName.equals("fax")) {
				if (value != null) {
					aContact.addFax(value);
				}
			} else if (fieldName.equals("email")) {
				if (value != null) {
					aContact.addEmail(value);
				}
			} else if (fieldName.equals("x400")) {
				if (value != null) {
					aContact.addX400(value);
				}
			} else if (fieldName.equals("uri")) {
				if (value != null) {
					aContact.addUri(value);
				}
			}  else if (fieldName.equals("id")) {
				if (value != null) {
					aContact.setId(value);
				}
			}
		}

		return aContact;
	}
}