package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;

public abstract class FusionJsonAbstractVTLSchemeWriterEngine<T extends IVtlSchemeBean<? extends ItemBean>> extends FusionJsonItemSchemeWriterEngine<T> {

	protected FusionJsonAbstractVTLSchemeWriterEngine(SDMX_STRUCTURE_TYPE st) {
		super(st);
	}
	
	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks,  T maint) throws JsonGenerationException, IOException {
		jsonGenerator.writeStringField("vtlVersion", maint.getVtlVersion());
		super.writeStructureInternal(jsonGenerator, externalLinks, maint);
	}
}
