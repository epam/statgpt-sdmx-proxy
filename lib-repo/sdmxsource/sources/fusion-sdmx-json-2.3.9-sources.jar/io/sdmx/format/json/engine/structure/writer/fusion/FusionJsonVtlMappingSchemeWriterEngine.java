package io.sdmx.format.json.engine.structure.writer.fusion;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;

public class FusionJsonVtlMappingSchemeWriterEngine extends FusionJsonItemSchemeWriterEngine<IVtlMappingSchemeBean> implements IFusionSingleton {
	private static FusionJsonVtlMappingSchemeWriterEngine INSTANCE;

	//Private constructor - lazy load instance
	private FusionJsonVtlMappingSchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME);
	}

	public static FusionJsonVtlMappingSchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonVtlMappingSchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ItemBean itemBean) throws JsonGenerationException, IOException {
		IVtlMappingBean item =  (IVtlMappingBean)itemBean;
		jsonGenerator.writeStringField("alias", item.getAlias());
		jsonGenerator.writeStringField("mapped", item.getMapped().getTargetUrn());
		if(item.getStructureType() == SDMX_STRUCTURE_TYPE.VTL_DATAFLOW_MAPPING) {
			IVtlDataflowMappingBean dfMapping = (IVtlDataflowMappingBean)item;
			writeFlowMapping(dfMapping.getToMethod(), dfMapping.getToSubSpace(), false, jsonGenerator);
			writeFlowMapping(dfMapping.getFromMethod(), dfMapping.getFromSubSpace(), true, jsonGenerator);
		}
	}

	private void writeFlowMapping(String method, List<String> subspace, boolean isFrom, JsonGenerator writer) throws IOException {
		if(method == null && !ObjectUtil.validCollection(subspace)) {
			return;
		}
		if(method != null) {
			writer.writeStringField(isFrom ? "fromVtlMethod" : "toVtlMethod", method);
		}
		if(ObjectUtil.validCollection(subspace)) {
			JsonWriterUtil.writeStringArray(writer, isFrom ? "fromVtlSuperSpace" : "toVtlSubSpace", subspace);
		}
	}
}
