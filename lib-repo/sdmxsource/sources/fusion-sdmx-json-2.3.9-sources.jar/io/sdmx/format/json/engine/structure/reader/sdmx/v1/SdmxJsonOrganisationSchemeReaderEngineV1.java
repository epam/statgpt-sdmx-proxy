package io.sdmx.format.json.engine.structure.reader.sdmx.v1;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonContactUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.utils.json.JsonReader;

public abstract class SdmxJsonOrganisationSchemeReaderEngineV1<Y extends OrganisationMutableBean, F extends OrganisationSchemeMutableBean<Y>> extends SdmxJsonItemSchemeReaderEngineV1<Y, F>{

	protected void populateOrganisationMutableBean(JsonReader jReader, Y orgMutableBean) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}

			if(SdmxJsonNameableUtil.processBean(orgMutableBean, jReader)){
				continue;
			}
			List<ContactMutableBean> contacts = SdmxJsonContactUtil.readContacts(jReader);
			orgMutableBean.setContacts(contacts);
		}
	}
}
