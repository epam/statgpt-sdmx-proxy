package io.sdmx.format.json.engine.structure.reader.util;

import java.math.BigDecimal;
import java.math.BigInteger;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonRepresentationUtil {
	

	public static RepresentationMutableBean readRepresentation(JsonReader jReader) {
		RepresentationMutableBean representation = new RepresentationMutableBeanImpl();
		readRepresentation(representation, jReader);
		return representation;
		
	}

	public static void readRepresentation(RepresentationMutableBean representation, JsonReader jReader) {
		String fieldName;
		String value;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("representation")) {
				value = jReader.getValueAsString();
				if(ObjectUtil.validString(value)) {
					StructureReferenceBean representationRef = new StructureReferenceBeanImpl(value);
					representation.setRepresentation(representationRef);
				}
			} else if (fieldName.equals("textFormat")) {
				representation.setTextFormat(readTextFormat(jReader));
			} else if (fieldName.equals("maxOccurs")) {
				representation.setMaxOccurs(jReader.getValueAsInt());
			} else if (fieldName.equals("minOccurs")) {
				representation.setMinOccurs(jReader.getValueAsInt());
			}
		}
	}

	public static TextFormatMutableBean readTextFormat(JsonReader jReader) {
		TextFormatMutableBean tf = new TextFormatMutableBeanImpl();
		String fieldName;
		String value;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			fieldName = jReader.getCurrentFieldName();
			value = jReader.getValueAsString();
			if (fieldName.equals("textType")) {
				tf.setTextType(TEXT_TYPE.parseString(value));
			} else if (fieldName.equals("startTime")) {
				tf.setStartTime(DateUtil.formatDate(value, true));
			} else if (fieldName.equals("endTime")) {
				tf.setEndTime(DateUtil.formatDate(value, false));
			} else if (fieldName.equals("sequence")) {
				tf.setSequence(TERTIARY_BOOL.parseBoolean(Boolean.valueOf(value)));
			} else if (fieldName.equals("minLength")) {
				tf.setMinLength(new BigInteger(value));
			} else if (fieldName.equals("maxLength")) {
				tf.setMaxLength(new BigInteger(value));
			} else if (fieldName.equals("startValue")) {
				tf.setStartValue(new BigDecimal(value));
			} else if (fieldName.equals("endValue")) {
				tf.setEndValue(new BigDecimal(value));
			} else if (fieldName.equals("maxValue")) {
				tf.setMaxValue(new BigDecimal(value));
			} else if (fieldName.equals("minValue")) {
				tf.setMinValue(new BigDecimal(value));
			} else if (fieldName.equals("interval")) {
				tf.setInterval(new BigDecimal(value));
			} else if (fieldName.equals("timeInterval")) {
				tf.setTimeInterval(value);
			} else if (fieldName.equals("decimals")) {
				tf.setDecimals(new BigInteger(value));
			} else if (fieldName.equals("pattern")) {
				tf.setPattern(value);
			} else if (fieldName.equals("multiLingual")) {
				tf.setMultiLingual(TERTIARY_BOOL.parseBoolean(Boolean.valueOf(value)));
			}
		}
		return tf;
	}
}
