package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonMetadataflowWriterEngine extends SdmxJsonMaintainableStructureWriterEngine<MetadataFlowBean> implements IFusionSingleton {
	private static SdmxJsonMetadataflowWriterEngine INSTANCE;

	public static SdmxJsonMetadataflowWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataflowWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonMetadataflowWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, MetadataFlowBean mdf) throws JsonGenerationException, IOException {
		ICrossReferenceBean<MetadataStructureDefinitionBean> metadataStructureRef = mdf.getMetadataStructureRef();
		jsonGenerator.writeStringField("structure", metadataStructureRef.getReference().getURN());
	}

}
