package io.sdmx.format.json.engine.structure.reader.fusion;

import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.base.OrganisationUnitMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class FusionJsonOrganisationUnitSchemeReaderEngine extends FusionJsonOrganisationSchemeReaderEngine<OrganisationUnitSchemeBean, OrganisationUnitSchemeMutableBean, OrganisationUnitMutableBean>
                                                        implements IFusionSingleton {
	private static FusionJsonOrganisationUnitSchemeReaderEngine INSTANCE;

	public static FusionJsonOrganisationUnitSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonOrganisationUnitSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected OrganisationUnitSchemeMutableBean getMutable() {
		return  new OrganisationUnitSchemeMutableBeanImpl();
	}

	@Override
	protected OrganisationUnitMutableBean readItemBean(JsonReader jReader) {
		OrganisationUnitMutableBean anOrgUnit = new OrganisationUnitMutableBeanImpl();
		populateOrganisationMutableBean(jReader, anOrgUnit);
		return anOrgUnit;
	}

	@Override
	protected boolean processField(String fieldName, JsonReader reader, OrganisationMutableBean mutable) {
		if(fieldName.equals("parentUnit")) {
			((OrganisationUnitMutableBean) mutable).setParentUnit(reader.getValueAsString());
		}
		return super.processField(fieldName, reader, mutable);
	}

    @Override
    protected Class<OrganisationUnitSchemeBean> getMaintainableType() {
        return OrganisationUnitSchemeBean.class;
    }
}