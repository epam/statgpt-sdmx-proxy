package io.sdmx.format.json.engine.structure.reader.fusion;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonNameableUtil;
import io.sdmx.im.mutable.transformation.VtlCodelistMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlConceptMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlDataflowMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlMappingSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class FusionJsonVtlMappingSchemeReaderEngine extends FusionJsonAbstractItemSchemeReaderEngine<IVtlMappingSchemeBean, IVtlMappingSchemeMutableBean, IVtlMappingMutableBean> implements IFusionSingleton {
	private static FusionJsonVtlMappingSchemeReaderEngine INSTANCE;

	public static FusionJsonVtlMappingSchemeReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FusionJsonVtlMappingSchemeReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected IVtlMappingSchemeMutableBean getMutable() {
		return new VtlMappingSchemeMutableBean();
	}

	@Override
	protected IVtlMappingMutableBean readItemBean(JsonReader jReader) {
		//We don't know what the concrete sub type is until we have finished processing the nameable section, so for now
		//use a container for this information which can then be copied accross
		IVtlMappingMutableBean nameable = new VtlDataflowMappingMutableBean();

		//Dataflow mapping specific properties
		String fromMethod = null;
		String toMethod = null;
		List<String> fromSubSpace = null;
		List<String> toSubSpace = null;

		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(!FusionJsonNameableUtil.processBean(nameable, jReader)) {
				String fieldName = jReader.getCurrentFieldName();
				if (fieldName.equals("alias")) {
					nameable.setAlias(jReader.getValueAsString());
				} else if (fieldName.equals("mapped")) {
					StructureReferenceBean sRef = new StructureReferenceBeanImpl(jReader.getValueAsString());
					IVtlMappingMutableBean item = null;
					switch(sRef.getTargetReference()) {
					case CODE_LIST :
						item = new VtlCodelistMappingMutableBean();
						break;
					case CONCEPT :
						item = new VtlConceptMappingMutableBean();
						break;
					case DATAFLOW :
						item = new VtlDataflowMappingMutableBean();
						break;
					default : throw new SdmxSemmanticException("Unsupported VTL Mapping to structure:"+sRef.getTargetReference().getType());
					}
					//Copy nameable properties over
					item.setAlias(nameable.getAlias());
					item.setNames(nameable.getNames());
					item.setDescriptions(nameable.getDescriptions());
					item.setAnnotations(nameable.getAnnotations());
					item.setId(nameable.getId());
					item.setMapped(sRef);
					nameable = item;
				} else if (fieldName.equals("fromVtlMethod")) {
					fromMethod = jReader.getValueAsString();
				} else if (fieldName.equals("toVtlMethod")) {
					toMethod = jReader.getValueAsString();
				} else if (fieldName.equals("fromVtlSuperSpace")) {
					fromSubSpace = jReader.readStringArray();
				} else if (fieldName.equals("toVtlSubSpace")) {
					toSubSpace = jReader.readStringArray();
				}
			}
		}
		if(nameable instanceof VtlDataflowMappingMutableBean) {
			VtlDataflowMappingMutableBean flowMapping = (VtlDataflowMappingMutableBean) nameable;
			flowMapping.setFromMethod(fromMethod);
			flowMapping.setToMethod(toMethod);
			flowMapping.setFromSubSpace(fromSubSpace);
			flowMapping.setToSubSpace(toSubSpace);
		}
		return nameable;
	}

    @Override
    protected Class<IVtlMappingSchemeBean> getMaintainableType() {
        return IVtlMappingSchemeBean.class;
    }
}
