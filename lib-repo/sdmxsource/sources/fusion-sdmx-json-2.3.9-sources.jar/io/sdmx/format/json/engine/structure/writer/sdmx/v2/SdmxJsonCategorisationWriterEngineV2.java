package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonCategorisationWriterEngineV2 extends SdmxJsonMaintainableStructureWriterEngineV2<CategorisationBean> implements IFusionSingleton {
	private static SdmxJsonCategorisationWriterEngineV2 INSTANCE;

	public static SdmxJsonCategorisationWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonCategorisationWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonCategorisationWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CATEGORISATION);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, CategorisationBean aCategorisation) throws JsonGenerationException, IOException {
		ICrossReferenceBean<?> structureRef = aCategorisation.getStructureReference();
		if(structureRef != null) {
			jsonGenerator.writeStringField("source", structureRef.getTargetUrn());
		}
		
		ICrossReferenceBean<CategoryBean> categoryRef = aCategorisation.getCategoryReference();
		if(categoryRef != null) {
			jsonGenerator.writeStringField("target", categoryRef.getTargetUrn());
		}

	
	}

}
