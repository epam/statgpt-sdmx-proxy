package io.sdmx.format.json.engine.data.writer.fusionjson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.DIMENSION_AT_OBSERVATION;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class FlatDataWriter extends AbstractJsonDataWriter {
	private static final Logger LOG = LoggerFactory.getLogger(FlatDataWriter.class);

	public FlatDataWriter(JsonGenerator jsonGenerator, HeaderBean header, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(jsonGenerator, header, superBeanRetrievalManager);
	}


	@Override
	public void writeHeader(HeaderBean header) {}

	
	// Write: root -> dataSets
	@Override
	protected void writeJsonDataSet(DatasetHeaderBean datasetHeader, AnnotationBean... ann) {
		try {
			super.writeJsonDataSet(datasetHeader, ann);
			// This is flat, so do not write a series tag but go straight into the observations tag
			LOG.debug("{observations}");
			jsonGenerator.writeObjectFieldStart("observations");

		} catch(Throwable th) {
			throw new RuntimeException(th);
		}
	}

	@Override
	public void writeKey(Keyable key) {
		if(key.isSeries()) {
			super.writeKey(key);
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		super.writeObservation(obs);
		writeJsonObs(currentKey, prevKey, obs);
	}

	private void writeJsonObs(String currentKey, String prevKey, Observation obs) {
		String lookup;
		
		if (dimensionAtObservation.equals(DIMENSION_AT_OBSERVATION.ALL.getVal())) {
			lookup = DimensionBean.TIME_DIMENSION_FIXED_ID;
		} else {
			lookup = dimensionAtObservation;
		}
		
		String seriesKey = currentKey + ":" + currentDatasetInfo.getReportedIndex(lookup, obs.getDimensionValue());
		writeJsonObs(obs, seriesKey);
	}

	protected void writeJsonObs(Observation obs, String seriesKey) {
		try {
			LOG.debug("["+seriesKey+"]");
			jsonGenerator.writeArrayFieldStart(seriesKey);

			// Write the observation value as the first array field
			jsonGenerator.writeString(obs.getMeasureCode(PrimaryMeasureBean.FIXED_ID));

			List<AttributeBean> attrs = new ArrayList<>(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getDimensionGroupAttributes());
			attrs.addAll(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getObservationAttributes());
			
			writeAttributes(attrs, obs.getAttributes(), obs.getSeriesKey().getAttributes());

			// Write the annotation values
			for(AnnotationBean currentAnnotation : obs.getSeriesKey().getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int idx = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(idx);
			}
			for(AnnotationBean currentAnnotation : obs.getAnnotations()) {
				if (!annotations.contains(currentAnnotation)) {
					annotations.add(currentAnnotation);
				}
				int idx = annotations.indexOf(currentAnnotation);
				jsonGenerator.writeNumber(idx);
			}
			LOG.debug("[/'"+seriesKey+"]");
			jsonGenerator.writeEndArray();
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
	}


	// Write: root -> structure -> dimensions -> series
	@Override
	protected void writeDimensionsSeries() throws JsonGenerationException, IOException {
		// Flat data types do not need an entry in the series
		jsonGenerator.writeArrayFieldStart("series");
		jsonGenerator.writeEndArray(); //End series array
	}

	// Write structure -> dimensions -> observations
	@Override
	protected void writeDimensionsObservation() throws JsonGenerationException, IOException {
		LOG.debug("[observation]");
		jsonGenerator.writeArrayFieldStart("observation");

		int i=0;
		DimensionSuperBean timeDimension = null;
		for(DimensionSuperBean dimension : currentDatasetInfo.getCurrentDSDSuperBean().getDimensions()) {
			if(dimension.getBuiltFrom().isTimeDimension()) {
				// Always write the Time Dimension at the end
				timeDimension = dimension;
			} else {
				writeComponent(dimension, i);
				i++;
			}
		}

		if (timeDimension != null) {
			writeComponent(timeDimension, i);
		}

		jsonGenerator.writeEndArray(); //End observation array
		LOG.debug("[/observation]");
	}

	@Override
	protected void writeAttributes() throws JsonGenerationException, IOException {
		LOG.debug("{attributes}");
		jsonGenerator.writeObjectFieldStart("attributes");

		jsonGenerator.writeArrayFieldStart("dataset");
		for(AttributeBean attribute : dsd.getDatasetAttributes()) {
			ComponentSuperBean attrSb = currentDatasetInfo.getCurrentDSDSuperBean().getComponentById(attribute.getId());
			writeComponent(attrSb, -1);
		}
		jsonGenerator.writeEndArray(); //End dataset array


		jsonGenerator.writeArrayFieldStart("series");
		jsonGenerator.writeEndArray(); //End series array

		LOG.debug("[observation]");
		jsonGenerator.writeArrayFieldStart("observation");

		List<AttributeBean> attrs = new ArrayList<>(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getDimensionGroupAttributes());
		attrs.addAll(currentDatasetInfo.getCurrentDSDSuperBean().getBuiltFrom().getObservationAttributes());
		List<String> attIds = new ArrayList<>();
		for(AttributeBean att : attrs) {
			writeComponent(currentDatasetInfo.getCurrentDSDSuperBean().getComponentById(att.getId()), -1);
		}
		writeAdditionalAttributes(attIds);
		writeAdditionalAttributes(currentDatasetInfo.getAdditionalSeriesAttributes());
		writeAdditionalAttributes(currentDatasetInfo.getAdditionalObsAttributes());

		LOG.debug("[/observation]");
		jsonGenerator.writeEndArray(); //End observation array
		LOG.debug("{/attributes}");
		jsonGenerator.writeEndObject(); //End attributes
	}

	@Override
	public void close(FooterMessage... footer) {
		try {
			LOG.debug("{/observations}");
			jsonGenerator.writeEndObject();  // End observations
			writeDatasetAttributes();

			LOG.debug("{/}");
			jsonGenerator.writeEndObject(); //End dataset


			LOG.debug("[/dataSets]");
			jsonGenerator.writeEndArray();  // End dataSets array

			writeStructure(true);
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		} finally {
			try {
				jsonGenerator.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	protected boolean isSdmxJsonV2() {
		return false;
	}
}