package io.sdmx.format.json.model;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxJsonMetadataFormat implements IMetadataFormat, IFusionSingleton {
	private static final long serialVersionUID = 1L;
	private FormatDetails formatDetails;
	private SDMXJSON_VERSION version;
	
	private static SdmxJsonMetadataFormat V2_INSTANCE;
	
	private SdmxJsonMetadataFormat(SDMXJSON_VERSION version, FormatDetails formatDetails) {
		this.version = version;
		this.formatDetails = formatDetails;
	}

	public static SdmxJsonMetadataFormat defaultInstance() {
		return getInstance(SDMXJSON_VERSION.V2);
	}
	
	public static SdmxJsonMetadataFormat getInstance(SDMXJSON_VERSION version) {
		if(version == null) {
			version = SDMXJSON_VERSION.V2;
		}
		switch(version) {
		case V2 :
			if(V2_INSTANCE == null) {
				V2_INSTANCE = new SdmxJsonMetadataFormat(version, new FormatDetailsImpl("sdmx-json v2.0.0", MIME_TYPE.APPLICATION_JSON, false, "application/vnd.sdmx.metadata+json;version=2.0.0"));
	            FusionBeanStore.registerInstance(V2_INSTANCE);
	        }
			return V2_INSTANCE;
			default : throw new SdmxNotImplementedException("SDMX Json outupt in version: "+version);
		}
    }

	public SDMXJSON_VERSION getVersion() {
		return version;
	}

    @Override
    public void destroyInstance() {
    	V2_INSTANCE = null;
    }

    
	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxJsonMetadataFormat) {
			SdmxJsonMetadataFormat that = (SdmxJsonMetadataFormat)obj;
			return  formatDetails.getAcceptHeaders()[0].equals(that.getFormatDetails().getAcceptHeaders()[0]) && ObjectUtil.equivalent(that.getVersion(), this.getVersion());
		}
		return false;
	}

	@Override
	public String toString() {
		return formatDetails.getAcceptHeaders()[0];
	}
}
