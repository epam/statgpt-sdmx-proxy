package io.sdmx.format.json.engine.structure.reader.sdmx.v2;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.json.engine.structure.reader.util.GenericJsonReaderUtil;
import io.sdmx.format.json.engine.structure.reader.util.SdmxJsonNameableUtil;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorMutableBean;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class SdmxJsonUserDefinedOperatorSchemeReaderEngineV2  extends SdmxJsonVtlSchemeReaderEngine<IUserDefinedOperatorMutableBean, IUserDefinedOperatorSchemeMutableBean> implements IFusionSingleton {
	private static SdmxJsonUserDefinedOperatorSchemeReaderEngineV2 INSTANCE;

	public static SdmxJsonUserDefinedOperatorSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonUserDefinedOperatorSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
    public String getContainerElement() {
        return "userDefinedOperatorSchemes";
    }

    @Override
    protected Class<? extends MaintainableBean> getMaintainableType() {
        return IUserDefinedOperatorSchemeBean.class;
    }

    @Override
    protected IUserDefinedOperatorSchemeMutableBean getMutable() {
        return new UserDefinedOperatorSchemeMutableBean();
    }

	@Override
    protected boolean processMaintainableProperty(String fieldName, IUserDefinedOperatorSchemeMutableBean mutable, JsonReader reader) {
        if("vtlMappingScheme".equals(fieldName)) {
            mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl(reader.getValueAsString()));
            return true;
        }
        if("rulesetSchemes".equals(fieldName)) {
            mutable.setRulesetSchemeRef(GenericJsonReaderUtil.readRefArray(reader));
            return true;
        }
        return super.processMaintainableProperty(fieldName, mutable, reader);
    }

	@Override
	protected List<IUserDefinedOperatorMutableBean> readItems(JsonReader jReader) {
		List<IUserDefinedOperatorMutableBean> returnList = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				IUserDefinedOperatorMutableBean mutable = readUserDefinedOperator(jReader);
				returnList.add(mutable);
			}
		}
		return returnList;
	}
	
	private IUserDefinedOperatorMutableBean readUserDefinedOperator(JsonReader jReader) {
		IUserDefinedOperatorMutableBean mutable = new UserDefinedOperatorMutableBean();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			if(SdmxJsonNameableUtil.processBean(mutable, jReader)) {
				continue;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "operatorDefinition" :
				mutable.setOperatorDefinition(jReader.getValueAsString());
				break;
			}
		}
		return mutable;
	}

	@Override
	protected String getItemLabel() {
		return "userDefinedOperators";
	}
}