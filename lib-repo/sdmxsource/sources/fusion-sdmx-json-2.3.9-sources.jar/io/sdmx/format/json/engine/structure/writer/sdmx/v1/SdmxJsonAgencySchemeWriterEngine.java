package io.sdmx.format.json.engine.structure.writer.sdmx.v1;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonAgencySchemeWriterEngine extends SdmxJsonItemSchemeWriterEngine<AgencyBean, AgencySchemeBean> implements IFusionSingleton {
	private static SdmxJsonAgencySchemeWriterEngine INSTANCE;

	public static SdmxJsonAgencySchemeWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonAgencySchemeWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonAgencySchemeWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, AgencyBean item) throws JsonGenerationException, IOException {
		SdmxJsonStaticHelper.RegistryJsonOrganisationWriter.writeStructure(jsonGenerator, item);
	}

	@Override
	protected String getItemName() {
		return "agencies";
	}

}
