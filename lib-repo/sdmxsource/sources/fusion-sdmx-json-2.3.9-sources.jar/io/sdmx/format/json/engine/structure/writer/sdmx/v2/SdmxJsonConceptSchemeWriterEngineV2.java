package io.sdmx.format.json.engine.structure.writer.sdmx.v2;

import java.io.IOException;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.format.json.util.SdmxJsonStaticHelper;
import io.sdmx.utils.core.application.FusionBeanStore;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

public class SdmxJsonConceptSchemeWriterEngineV2 extends SdmxJsonItemSchemeWriterEngineV2<ConceptBean, ConceptSchemeBean> implements IFusionSingleton {
	private static SdmxJsonConceptSchemeWriterEngineV2 INSTANCE;

	public static SdmxJsonConceptSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonConceptSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxJsonConceptSchemeWriterEngineV2() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
	}

	@Override
	protected void writeItemDetails(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, ConceptBean item) throws JsonGenerationException, IOException  {
		ConceptBean concept = item;
		if(concept.getRepresentation() != null) {
			SdmxJsonStaticHelper.writeRepresentation(jsonGenerator, concept.getRepresentation(), true,"coreRepresentation");
		}
		if(concept.getIsoConceptReference() != null) {
			jsonGenerator.writeStringField("isoConceptReference", concept.getIsoConceptReference().getTargetUrn());
		}
		if(concept.getParentConcept() != null) {
			jsonGenerator.writeStringField("parent", concept.getParentConcept());
		}
	}

	@Override
	protected String getItemName() {
		return "concepts";
	}
}
