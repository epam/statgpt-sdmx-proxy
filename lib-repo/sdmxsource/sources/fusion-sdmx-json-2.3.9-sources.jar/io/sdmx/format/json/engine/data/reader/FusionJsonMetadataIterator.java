package io.sdmx.format.json.engine.data.reader;

import io.sdmx.utils.json.JsonReader;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;


public class FusionJsonMetadataIterator extends AbstractIterator {
	private HeaderIterator headerIterator;
	private StructureIterator structureIterator;
	
//	private List<DataSetInformation> dataSetInformation = new ArrayList<SdmxJsonMetadataIterator.DataSetInformation>();
	
	public FusionJsonMetadataIterator(JsonReader jReader, DataReaderExceptionHandler exceptionHandler) {
		super(jReader, exceptionHandler);
	}

	@Override
	public JsonReader.Iterator start(String fieldName, boolean isObject) {
		if("header".equals(fieldName)) {
			headerIterator = new HeaderIterator(jReader, null);
			return headerIterator;
		} else if("structure".equals(fieldName)) {
			structureIterator = new StructureIterator(jReader, exceptionHandler);
			return structureIterator;
		} else if("dataSets".equals(fieldName)) {
			if(structureIterator != null) {
				//We have everything we need to read the dataset, stop the iterator
				jReader.stopIterating();
			}
			return null;
		} else if("erorrs".equals(fieldName)) {
			//TODO ERRROS?
		} else {
			//TODO UNKNOWN NODE
		}
		return null;
	}

	public HeaderIterator getHeaderIterator() {
		return headerIterator;
	}

	public StructureIterator getStructureIterator() {
		return structureIterator;
	}
}
