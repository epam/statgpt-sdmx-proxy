package io.sdmx.format.json.factory.metadata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataReaderFactory;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.constant.SDMX_JSON_SCHEMA;
import io.sdmx.format.json.engine.metadata.sdmx.v2.SdmxJsonMetadataSetReaderEngineV2;
import io.sdmx.format.json.util.SdmxJsonUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.json.JsonReader;

public class SdmxJsonMetadataReaderFactory implements IMetadataReaderFactory, IFusionSingleton {
	private static SdmxJsonMetadataReaderFactory INSTANCE;
	
	private static final Logger LOG = LoggerFactory.getLogger(SdmxJsonMetadataReaderFactory.class);

	public static SdmxJsonMetadataReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxJsonMetadataReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxJsonMetadataReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) {
		if(rdl.getFormat() == FILE_FORMAT.JSON) {
			SDMXJSON_VERSION v = getSdmxJsonVersion(rdl);
			if(v != null) {
				switch(v) {
				case V2 :
					return SdmxJsonMetadataSetReaderEngineV2.getInstance().parse(rdl);
				}
			}
		}
		return null;
	}

	private SDMXJSON_VERSION getSdmxJsonVersion(ReadableDataLocation rdl) {
			String schema = SdmxJsonUtil.getSchema(rdl);
			if(schema != null) {
				if(schema.equals(SDMX_JSON_SCHEMA.REF_METADATA_V2) || schema.equals(SDMX_JSON_SCHEMA.REF_METADATA_V2_OLD)) {
					return SDMXJSON_VERSION.V2;
				}
				return null;
			}
			if(rdl.getFormat() == FILE_FORMAT.JSON) {
				try(JsonReader jReader = new JsonReader(rdl);){
				while(jReader.moveNext()) {
					if("data".equals(jReader.getCurrentFieldName())) {
						return SDMXJSON_VERSION.V2;
					}
				}
			}
		}
		return null;
	}
}
