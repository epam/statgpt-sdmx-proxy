package io.sdmx.fusion.search.api.engine;

import java.io.OutputStream;
import java.util.Collection;

import io.sdmx.api.sdmx.search.SearchResult;

/**
 * Responsible for writing  search results for external use
 */
public interface SearchResultsWriter {

	/**
	 * Writes the search results to the output stream, closes the stream on completion
	 * @param results
	 * @param out
	 */
	void writeResults(Collection<SearchResult> results, long time, OutputStream out);
	
}
