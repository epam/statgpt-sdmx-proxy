package io.sdmx.fusion.search.manager;

import io.sdmx.api.sdmx.search.ISdmxSearchIndexManager;
import io.sdmx.api.sdmx.search.SdmxSearchManager;

public class SdmxSearchIndexManager implements ISdmxSearchIndexManager {

	@Override
	public SdmxSearchManager createNewSearchManager() {
		return new SdmxSearchManagerImpl();
	}

}
