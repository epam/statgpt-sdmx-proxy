package io.sdmx.fusion.search.manager;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexNotFoundException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IOContext;
import org.apache.lucene.store.RAMDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.search.MATCH_ATTRIBUTE;
import io.sdmx.api.sdmx.search.MatchInformation;
import io.sdmx.api.sdmx.search.SdmxSearchManager;
import io.sdmx.api.sdmx.search.SearchResult;
import io.sdmx.fusion.search.model.MatchInformationImpl;
import io.sdmx.fusion.search.model.SearchResultImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.Lockable;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxSearchManagerImpl implements SdmxSearchManager, IStructureEventListener {
    private static final Logger LOG = LoggerFactory.getLogger(SdmxSearchManagerImpl.class);

	//String Key is the identifiable URN
    private SdmxBeanRetrievalManager brm;
	private Map<String, IdentifiableBean> identifiableMap = new HashMap<>();
	protected static final String URN_FIELD = "URN";
	private static final String LANG_FIELD = "LANG";

	private Lockable lock = new Lockable();

	private Directory directory;
	private Analyzer analyzer;
	private IndexWriter iWriter;
	private Thread t;
	private boolean isUpdating = false;

	public SdmxSearchManagerImpl() {
		directory = new RAMDirectory();
		analyzer = getAnalyzer();
	}

	public SdmxSearchManagerImpl(RAMDirectory dir, SdmxBeanRetrievalManager irm) {
		directory = dir;
		this.brm = irm;
		analyzer = getAnalyzer();
	}

	public SdmxSearchManagerImpl(Path index) {
		try {
			directory = new RAMDirectory(FSDirectory.open(index), IOContext.DEFAULT);
			analyzer = getAnalyzer();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public SdmxSearchManagerImpl(SdmxBeans beans) {
		this();
		new SearchIndexUpdater(this, beans, true).run();
	}

	@Override
	public void copySearchIndex(Path copyToPath) {
		Directory copyTo;
		try {
			copyTo = FSDirectory.open(copyToPath);
			for (String file : directory.listAll()) {
				copyTo.copyFrom(directory, file, file, IOContext.DEFAULT); // newFile can be either file, or a new name
			}
			copyTo.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private Analyzer getAnalyzer() {
		return new StandardAnalyzer();
	}
	
	
	@Override
	public void notifyStructureEvent(IStructureEvent beans) {
		// If this is only a Registration change, return.
		if (beans.getDeletions().getAllMaintainables().size() == 0) {
			if ((beans.getAdditions().getAllMaintainables(SDMX_STRUCTURE_TYPE.REGISTRATION).size() == 0) &&
					(beans.getModification().getAllMaintainables(SDMX_STRUCTURE_TYPE.REGISTRATION).size() == 0)) {
				return;
			}
		}

		// What is the purpose of this sleep?
		while(t != null) {
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
			    Thread.currentThread().interrupt();
			}
		}

		//TODO FIX ME
//		Thread t;
//		if (beans.getDeletions().getAllMaintainables().size() == 0 &&
//				beans.getModification().getAllMaintainables().size() == 0) {
//			t = new Thread(new SearchIndexUpdater(this, beans.getAdditions(), true));
//		} else {
//			t = new Thread(new SearchIndexUpdater(this, beans.getNewContainer(), false));
//		}
//		t.start();
	}

	private class SearchIndexUpdater implements Runnable {
		private SdmxSearchManagerImpl searchMgr;
		private SdmxBeans beans;
		private boolean additionsOnly;

		public SearchIndexUpdater(SdmxSearchManagerImpl s, SdmxBeans beans, boolean additionsOnly) {
			this.searchMgr = s;
			this.beans = beans;
			this.additionsOnly = additionsOnly;
		}

		@Override
		public void run() {
			try {
				lock.lock();
				isUpdating = true;
				Directory directory;
				Map<String, IdentifiableBean> identMap = identifiableMap;
				if (this.additionsOnly) {
					directory = this.searchMgr.directory;
					analyzer = this.searchMgr.analyzer;
					if (iWriter == null) {
						IndexWriterConfig config = new IndexWriterConfig(analyzer);
						config.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
						iWriter = new IndexWriter(directory, config);
					}
					if (identMap == null) {
						identMap = new HashMap<>();
					} else {
						identMap = new HashMap<>(identifiableMap);
					}
				} else {
					directory = new RAMDirectory();
					analyzer = getAnalyzer();

					IndexWriterConfig config = new IndexWriterConfig(analyzer);
					config.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
					if (iWriter != null) {
						iWriter.close();
					}
					iWriter = new IndexWriter(directory, config);

					identMap = new HashMap<>();
				}

				LOG.info("Update Search Index. No of items: " + beans.getAllMaintainables().size());

				for(MaintainableBean maint : beans.getAllMaintainables()) {
					indexIdentifiable(iWriter, maint);
					identMap.put(maint.getUrn(), maint);
					for(IdentifiableBean ident : maint.getIdentifiableComposites()) {
						indexIdentifiable(iWriter, ident);
						identMap.put(ident.getUrn(), ident);
					}
				}
				LOG.info("Search Index Updated");
				iWriter.commit();
				this.searchMgr.identifiableMap = identMap;
				this.searchMgr.directory = directory;
				this.searchMgr.analyzer = analyzer;
			} catch(Throwable th) {
				LOG.error("Search index update failure");
				throw new RuntimeException(th);
			} finally {
				isUpdating = false;
				lock.releaseLock(false);
			}
		}
	}

	@Override
	public Set<SearchResult> performSearch(String searchString) {
		while(lock.isLocked()) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return performSearch(searchString);
			}
		}
		Set<SearchResult> searchResult = new TreeSet<>();
		if(ObjectUtil.validString(searchString)) {
			performSearch(searchResult, searchString);
		}
		return searchResult;
	}

	private void indexIdentifiable(IndexWriter iwriter, IdentifiableBean identifiableBean) throws CorruptIndexException, IOException {
		if (identifiableBean instanceof RegistrationBean) {
			// Do not index Registrations
			return;
		}

		Document doc = new Document();
		doc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
		doc.add(new TextField(MATCH_ATTRIBUTE.ID.toString(), identifiableBean.getId(), Field.Store.YES));

		iwriter.addDocument(doc);

		if(identifiableBean instanceof NameableBean) {
			NameableBean nameable = (NameableBean)identifiableBean;
			for(TextTypeWrapper textType : nameable.getNames()) {
				Document nameDoc = new Document();
				nameDoc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
				nameDoc.add(new StringField(LANG_FIELD, textType.getLocale(), Field.Store.YES));
				nameDoc.add(new TextField(MATCH_ATTRIBUTE.NAME.toString(), textType.getValue(), Field.Store.YES));
				iwriter.addDocument(nameDoc);
			}
			for(TextTypeWrapper textType : nameable.getDescriptions()) {
				Document descDoc = new Document();
				descDoc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
				descDoc.add(new StringField(LANG_FIELD, textType.getLocale(), Field.Store.YES));
				descDoc.add(new TextField(MATCH_ATTRIBUTE.DESCRIPTION.toString(), textType.getValue(), Field.Store.YES));
				iwriter.addDocument(descDoc);
			}
		}
	}

	private void performSearch(Set<SearchResult> searchResult , String searchString) {
		Set<SearchResult> tmpResults = new HashSet<>();
		searchString = QueryParser.escape(searchString);
		searchString = searchString.split(" ").length > 1 ? "*"+searchString+"*" : searchString;

		performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.ID);
		performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.NAME);
		performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.DESCRIPTION);

		Map<MaintainableBean, SearchResult> results = new HashMap<>();
		for(SearchResult currentResult : tmpResults) {
			if(results.containsKey(currentResult.getMaintainableBean())) {
				SearchResult existingResult = results.get(currentResult.getMaintainableBean());
				for(MatchInformation mi : currentResult.getMatchInformation()) {
					existingResult.addMatchInformation(mi);
				}
			} else {
				results.put(currentResult.getMaintainableBean(), currentResult);
			}
		}
		for(SearchResult currentResult : results.values()) {
			searchResult.add(currentResult);
		}
	}


	@Override
	public List<String> getAutoCompleteSuggestions(String searchString,	int maxSuggestions) {
		while(lock.isLocked()) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return getAutoCompleteSuggestions(searchString, maxSuggestions);
			}
		}
		List<String> returnList = new ArrayList<>();
		searchString = QueryParser.escape(searchString);
		Map<ScoreDoc, Document> hits = getHits(searchString, MATCH_ATTRIBUTE.NAME, false);
		if(hits.size() == 0) {
		//	hits = getHits(searchString, MATCH_ATTRIBUTE.NAME, true);
		}

		// Iterate through the results:
		for (ScoreDoc hit : hits.keySet()) {
			Document hitDoc = hits.get(hit);
			String string = hitDoc.get(MATCH_ATTRIBUTE.NAME.toString());
			if(!returnList.contains(string)) {
				returnList.add(string);
				if(returnList.size() == maxSuggestions) {
					break;
				}
			}
		}
		return returnList;
	}

	private void performSearch(Set<SearchResult> searchResult , String searchString, MATCH_ATTRIBUTE searchOn) {
		Map<ScoreDoc, Document> hits = getHits(searchString, searchOn, false);

		// Iterate through the results:
		Map<MaintainableBean, SearchResult> searchResultsMap = new HashMap<>();
		for (ScoreDoc hit : hits.keySet()) {
			Document hitDoc = hits.get(hit);
			String urn = hitDoc.get(URN_FIELD);

			IdentifiableBean identifiable = identifiableMap.get(urn);
			if(identifiable == null && brm != null) {
				identifiable = brm.getBean(URN.builder(urn).buildAbsolute());
				identifiableMap.put(urn, identifiable);
			}
			if(identifiable == null) {
				LOG.warn("SDMX Search matches for structure with URN '"+urn+"', but Identitiable not found in cache");
			} else {
				String lang = hitDoc.get(LANG_FIELD);
				String matchString = "";
				switch(searchOn) {
				case DESCRIPTION :
					if(identifiable instanceof NameableBean) {
						matchString = getByLocale(((NameableBean)identifiable).getDescriptions(), lang);
					} else {
						LOG.error("Matched on Description, but bean is not Nameable " + identifiable);
					}
					break;
				case ID : matchString = identifiable.getId();
				break;
				case NAME :
					if(identifiable instanceof NameableBean) {
						matchString = getByLocale(((NameableBean)identifiable).getNames(), lang);
					} else {
						LOG.error("Matched on Name, but bean is not Nameable " + identifiable);
					}
					break;
				}
				MatchInformation matchInformation = new MatchInformationImpl(identifiable, searchOn, matchString, lang, hit.score);
				MaintainableBean maint = identifiable.getMaintainableParent();
				SearchResult result = searchResultsMap.get(maint);
				if(result == null) {
					result = new SearchResultImpl(maint);
					searchResultsMap.put(maint, result);
					searchResult.add(result);
				}
				result.addMatchInformation(matchInformation);
			}
		}
	}

	protected Map<ScoreDoc, Document> getHits(String searchString, MATCH_ATTRIBUTE searchOn, boolean includeFuzzy) {
		while(isUpdating) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				e.printStackTrace();
			}
		}
		try (IndexReader reader = DirectoryReader.open(directory)) {
			IndexSearcher isearcher = new IndexSearcher(reader);
			Query query;
			if(includeFuzzy) {
				query = new FuzzyQuery(new Term(searchOn.toString(), searchString.toLowerCase()));
			}else {
				QueryParser parser = new QueryParser(searchOn.toString(), analyzer);
				parser.setAllowLeadingWildcard(true);
				query = parser.parse(searchString);
			}
			TopScoreDocCollector collector = TopScoreDocCollector.create(100, 100);
			isearcher.search(query, collector);
			ScoreDoc[] hits = collector.topDocs().scoreDocs;
			Map<ScoreDoc, Document> hitMap = new HashMap<>();
			for (int i = 0; i < hits.length; i++) {
				ScoreDoc hit = hits[i];
				Document hitDoc = isearcher.doc(hit.doc);
				hitMap.put(hit, hitDoc);
			}
			return hitMap;
		} catch(IndexNotFoundException e) {
			// This can occurs when the index in the 'directory' variable does not exist (for example no data has been loaded into the system).
			// Rather than throw an exception, simply return an empty Map. The directory is empty.
			return new HashMap<>();
		} catch(IOException | ParseException e) {
			throw new RuntimeException(e);
		}
	}

	private String getByLocale(List<TextTypeWrapper> text, String locale) {
		for(TextTypeWrapper currentText : text) {
			if(currentText.getLocale().equals(locale)) {
				return currentText.getValue();
			}
		}
		return null;
	}

}
