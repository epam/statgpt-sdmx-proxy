package io.sdmx.fusion.search.manager;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.ByteBuffersDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IOContext;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.notification.CacheNotifier;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.manager.structure.IStructureHashRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.search.MATCH_ATTRIBUTE;
import io.sdmx.api.sdmx.search.MatchInformation;
import io.sdmx.api.sdmx.search.SdmxSearchManager;
import io.sdmx.api.sdmx.search.SearchResult;
import io.sdmx.fusion.search.model.MatchInformationImpl;
import io.sdmx.fusion.search.model.SearchResultImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.Lockable;
import io.sdmx.utils.sdmx.xs.URN;


//TODO: Should we rely on the assumption that first call to index data will be the whole persisted DB or create a seperate method?
//TODO: We'll try a seperate method to prevent assumptions which may change in the future.
//TODO this will not work since the v2.0.0 refector as the beans even no longer contains the full old and new container, only the diff - see todos in this class
/*NOTE: Only one instance of this class can exist with the same index path at any one point, as the
index directory doesn't support multiple instances.
*/
public class PersistentIndexSdmxSearchManagerImpl  implements SdmxSearchManager, IStructureEventListener {
    protected static final String URN_FIELD = "URN";
    private static final Logger LOG = LoggerFactory.getLogger(PersistentIndexSdmxSearchManagerImpl.class);
    private static final String LANG_FIELD = "LANG";
    private final Lockable lock = new Lockable();
    private final AtomicBoolean isUpdating = new AtomicBoolean(false);
    //TODO: If an event is invoked while updating, consider dumping current changes and restarting.
    private final AtomicBoolean isInitialised = new AtomicBoolean(false);
    //String Key is the identifiable URN
    private SdmxBeanRetrievalManager brm;
    private Map<String, IdentifiableBean> identifiableMap = new HashMap<>();
    private IStructureHashRetrievalManager hashManager;
    private Directory directory;
    private Analyzer analyzer;
    private IndexWriter iWriter;
    private Thread t;

    //TODO: Add a failsafe to write the index to WEB-INF & Deal with exception properly.
    //TODO: Also, look into platform-dependent implementation issues, specifically thread-blocking issue on Windows.
    private PersistentIndexSdmxSearchManagerImpl(Path fullIndexPath) {
        try {
            IndexWriterConfig config = new IndexWriterConfig();
            config.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);

            try {
                directory = FSDirectory.open(fullIndexPath);
                iWriter = new IndexWriter(directory, config);
            } catch (IOException e) {
                LOG.error("Cannot create Filesystem Index, falling back to RAM Directory.");
                try {
                    directory = new ByteBuffersDirectory();
                    iWriter = new IndexWriter(directory, config);
                } catch (Exception ex) {
                    throw new RuntimeException("Unable to open/create neither RAM Index directory nor Filesystem Index directory:" + fullIndexPath, e);
                }
            }
            analyzer = getAnalyzer();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public PersistentIndexSdmxSearchManagerImpl(Path fullIndex, IStructureHashRetrievalManager hashManager) {
        this(fullIndex);
        this.hashManager = hashManager;
    }

    private PersistentIndexSdmxSearchManagerImpl(String indexDirectory) {
        this(new File(getOrCreateMTDir(), indexDirectory).toPath());

    }

    public PersistentIndexSdmxSearchManagerImpl(String indexDirectory, IStructureHashRetrievalManager hashManager) {
        this(new File(getOrCreateMTDir(), indexDirectory).toPath());
        this.hashManager = hashManager;

    }

    public PersistentIndexSdmxSearchManagerImpl( IStructureHashRetrievalManager hashManager) {
        this("index");
        this.hashManager = hashManager;
    }

//    public PersistentIndexSdmxSearchManagerImpl() {
//        this("index");
//    }


    @Override
    public Set<SearchResult> performSearch(String searchString) {
        //TODO: Removing this will allow Index updating and searching at the same time, however, data will be
        // out of date, as IndexReaders take a snapshot of the index at a certain point in time when they are opened.
//        while (lock.isLocked()) {
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//                return performSearch(searchString);
//            }
//        }

        //If the search manager hasn't been initialised yet, wait for it to initialise.
        while (!isInitialised.get()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return performSearch(searchString);
            }
        }

        Set<SearchResult> searchResult = new TreeSet<>();
        if (ObjectUtil.validString(searchString)) {
            performSearch(searchResult, searchString);
        }
        return searchResult;
    }

    @Override
    public void copySearchIndex(Path copyToPath) {
        Directory copyTo;
        try {
            copyTo = FSDirectory.open(copyToPath);
            for (String file : directory.listAll()) {
                copyTo.copyFrom(directory, file, file, IOContext.DEFAULT); // newFile can be either file, or a new name
            }
            copyTo.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
	public List<String> getAutoCompleteSuggestions(String searchString, int maxSuggestions) {
//        while (lock.isLocked()) {
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//                return getAutoCompleteSuggestions(searchString, maxSuggestions);
//            }
//        }

        //If the search manager hasn't been initialised yet, wait for it to initialise.
        while (!isInitialised.get()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return getAutoCompleteSuggestions(searchString, maxSuggestions);
            }
        }

        List<String> returnList = new ArrayList<>();
        searchString = QueryParser.escape(searchString);
        Map<ScoreDoc, Document> hits = getHits(searchString, MATCH_ATTRIBUTE.NAME, false);

        // Iterate through the results:
        for (ScoreDoc hit : hits.keySet()) {
            Document hitDoc = hits.get(hit);
            String string = hitDoc.get(MATCH_ATTRIBUTE.NAME.toString());
            if (!returnList.contains(string)) {
                returnList.add(string);
                if (returnList.size() == maxSuggestions) {
                    break;
                }
            }
        }
        return returnList;
    }

    
    @Override
	public void notifyStructureEvent(IStructureEvent event) {
        // If this is only a Registration change, return.
        if (event.getDeletions().getAllMaintainables().isEmpty()) {
            if ((event.getAdditions().getAllMaintainables(SDMX_STRUCTURE_TYPE.REGISTRATION).isEmpty()) &&
                    (event.getModification().getAllMaintainables(SDMX_STRUCTURE_TYPE.REGISTRATION).isEmpty())) {
                return;
            }
        }

        //Assume the first invocation of this method when the class hasn't intialised yet, is the process of loading persisted structures.
        if (!isInitialised.get() && !isUpdating.get()) {
            loadOrCreatePersistedIndex(event);
            return;
        }

        // What is the purpose of this sleep?
        while (t != null) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        Thread t;

        t = new Thread(new PersistentIndexSdmxSearchManagerImpl.NewSearchIndexUpdater(this, event));
        t.start();
    }

    public void loadOrCreatePersistedIndex(IStructureEvent beans) {
        Thread t = new Thread(() -> {
                loadOrCreatePersistedIndexAsync(beans);
            }
        );

        t.start();
    }

    public void setHashManager(IStructureHashRetrievalManager hashManager) {
        this.hashManager = hashManager;
    }

    private void performSearch(Set<SearchResult> searchResult, String searchString) {
        Set<SearchResult> tmpResults = new HashSet<>();
        searchString = QueryParser.escape(searchString);
        searchString = searchString.split(" ").length > 1 ? "*" + searchString + "*" : searchString;

        performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.ID);
        performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.NAME);
        performSearch(tmpResults, searchString, MATCH_ATTRIBUTE.DESCRIPTION);

        Map<MaintainableBean, SearchResult> results = new HashMap<>();
        for (SearchResult currentResult : tmpResults) {
            if (results.containsKey(currentResult.getMaintainableBean())) {
                SearchResult existingResult = results.get(currentResult.getMaintainableBean());
                for (MatchInformation mi : currentResult.getMatchInformation()) {
                    existingResult.addMatchInformation(mi);
                }
            } else {
                results.put(currentResult.getMaintainableBean(), currentResult);
            }
        }
        searchResult.addAll(results.values());
    }

    private void performSearch(Set<SearchResult> searchResult, String searchString, MATCH_ATTRIBUTE searchOn) {
        Map<ScoreDoc, Document> hits = getHits(searchString, searchOn, false);

        // Iterate through the results:
        Map<MaintainableBean, SearchResult> searchResultsMap = new HashMap<>();
        for (ScoreDoc hit : hits.keySet()) {
            Document hitDoc = hits.get(hit);
            String urn = hitDoc.get(URN_FIELD);

            IdentifiableBean identifiable = identifiableMap.get(urn);
            if (identifiable == null && brm != null) {
                identifiable = brm.getBean(URN.builder(urn).buildAbsolute());
                identifiableMap.put(urn, identifiable);
            }
            if (identifiable == null) {
                LOG.warn("SDMX Search matches for structure with URN '" + urn + "', but Identitiable not found in cache");
            } else {
                String lang = hitDoc.get(LANG_FIELD);
                String matchString = "";
                switch (searchOn) {
                    case DESCRIPTION:
                        if (identifiable instanceof NameableBean) {
                            matchString = getByLocale(((NameableBean) identifiable).getDescriptions(), lang);
                        } else {
                            LOG.error("Matched on Description, but bean is not Nameable " + identifiable);
                        }
                        break;
                    case ID:
                        matchString = identifiable.getId();
                        break;
                    case NAME:
                        if (identifiable instanceof NameableBean) {
                            matchString = getByLocale(((NameableBean) identifiable).getNames(), lang);
                        } else {
                            LOG.error("Matched on Name, but bean is not Nameable " + identifiable);
                        }
                        break;
                }
                MatchInformation matchInformation = new MatchInformationImpl(identifiable, searchOn, matchString, lang, hit.score);
                MaintainableBean maint = identifiable.getMaintainableParent();
                SearchResult result = searchResultsMap.get(maint);
                if (result == null) {
                    result = new SearchResultImpl(maint);
                    searchResultsMap.put(maint, result);
                    searchResult.add(result);
                }
                result.addMatchInformation(matchInformation);
            }
        }
    }

    private void loadOrCreatePersistedIndexAsync(IStructureEvent beans) {
        try {
            lock.lock();
            isUpdating.set(true);

            // Prevents potential race condition.
            if (isInitialised.get()) {
                LOG.info("Re-index method called after Index initialisation.");
                return;
            }

            IndexInput hashFile = null;
            String hash;

            try {
                hashFile = directory.openInput("hash_file", IOContext.DEFAULT);
                hash = hashFile.readString();
            } catch (IOException e) {
                //Exception in opening the file probably means the file doesn't exist, create a new index and a new hash file.
                createNewIndex(beans);
                isInitialised.set(true);
                return;
            } finally {
            	if (hashFile != null) {
            		hashFile.close();
            	}
            }

            // Fix: To avoid the issue of comparison timing, use a getBytes() comparisson with MessageDigest
            if(MessageDigest.isEqual(hash.getBytes(), hashManager.getGlobalHash().getBytes())) {
                //Persisted Index is consistent.
                LOG.info("Persisted Index is consistent. Loading.");

                identifiableMap = new HashMap<>();

                for (MaintainableBean maint : getNewContainer(beans).getAllMaintainables()) {
                    identifiableMap.put(maint.getUrn(), maint);

                    for (IdentifiableBean ident : maint.getIdentifiableComposites()) {
                        identifiableMap.put(ident.getUrn(), ident);
                    }
                }
            } else {
                //Persisted index doesn't exist or is not consistent.
                createNewIndex(beans);
            }

            isInitialised.set(true);

        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            isUpdating.set(false);
            lock.releaseLock(false);
        }
    }
    
    private SdmxBeans getNewContainer(IStructureEvent event) {
    	return null;  //TODO 
    }
    private SdmxBeans getOldContainer(IStructureEvent event) {
    	return null;  //TODO 
    }
    
    private void createNewIndex(IStructureEvent beans) throws IOException {
        clearIndexDirectory(iWriter);
        new NewSearchIndexUpdater(this, beans).run();
    }

    private void clearIndexDirectory(IndexWriter iWriter) throws IOException {
        iWriter.deleteAll();
        iWriter.commit();
    }

    private void writeHashFile() throws IOException {

        try {
            //Delete file if it exists, if not, this throws an exception which can be ignored.
            directory.deleteFile("hash_file");
        } catch (IOException ignored) {
        }

        IndexOutput newHashFile = directory.createOutput("hash_file", IOContext.READ);
        try {
        	newHashFile.writeString(hashManager.getGlobalHash());
        } finally {
        	newHashFile.close();
        }
    }

    private void indexIdentifiable(IndexWriter iwriter, IdentifiableBean identifiableBean) throws IOException {
        if (identifiableBean instanceof RegistrationBean) {
            // Do not index Registrations
            return;
        }

        Document doc = new Document();
        doc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
        doc.add(new TextField(MATCH_ATTRIBUTE.ID.toString(), identifiableBean.getId(), Field.Store.YES));

        iwriter.addDocument(doc);

        if (identifiableBean instanceof NameableBean) {
            NameableBean nameable = (NameableBean) identifiableBean;
            for (TextTypeWrapper textType : nameable.getNames()) {
                Document nameDoc = new Document();
                nameDoc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
                nameDoc.add(new StringField(LANG_FIELD, textType.getLocale(), Field.Store.YES));
                nameDoc.add(new TextField(MATCH_ATTRIBUTE.NAME.toString(), textType.getValue(), Field.Store.YES));
                iwriter.addDocument(nameDoc);
            }
            for (TextTypeWrapper textType : nameable.getDescriptions()) {
                Document descDoc = new Document();
                descDoc.add(new StringField(URN_FIELD, identifiableBean.getUrn(), Field.Store.YES));
                descDoc.add(new StringField(LANG_FIELD, textType.getLocale(), Field.Store.YES));
                descDoc.add(new TextField(MATCH_ATTRIBUTE.DESCRIPTION.toString(), textType.getValue(), Field.Store.YES));
                iwriter.addDocument(descDoc);
            }
        }
    }

    private Analyzer getAnalyzer() {
        return new StandardAnalyzer();
    }

    protected Map<ScoreDoc, Document> getHits(String searchString, MATCH_ATTRIBUTE searchOn, boolean includeFuzzy) {
//        while (isUpdating) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//                e.printStackTrace();
//            }
//        }
        try (IndexReader reader = DirectoryReader.open(directory)) {
            IndexSearcher isearcher = new IndexSearcher(reader);
            Query query;
            if (includeFuzzy) {
                query = new FuzzyQuery(new Term(searchOn.toString(), searchString.toLowerCase()));
            } else {
                QueryParser parser = new QueryParser(searchOn.toString(), analyzer);
                parser.setAllowLeadingWildcard(true);
                query = parser.parse(searchString);
            }
            TopScoreDocCollector collector = TopScoreDocCollector.create(100, 100);
            isearcher.search(query, collector);
            ScoreDoc[] hits = collector.topDocs().scoreDocs;
            Map<ScoreDoc, Document> hitMap = new HashMap<>();
            for (ScoreDoc hit : hits) {
                Document hitDoc = isearcher.doc(hit.doc);
                hitMap.put(hit, hitDoc);
            }
            return hitMap;
        } catch (IOException | ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private String getByLocale(List<TextTypeWrapper> text, String locale) {
        for (TextTypeWrapper currentText : text) {
            if (currentText.getLocale().equals(locale)) {
                return currentText.getValue();
            }
        }
        return null;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();

        if (iWriter != null && iWriter.isOpen()) {
            iWriter.commit();
            iWriter.close();
        }

        if (directory != null) {
            directory.close();
        }

    }

    //TODO: Ensure that in case of major failure, any attempts to modify or delete the index are replaced with a full re-index.
    private class NewSearchIndexUpdater implements Runnable {
        private final PersistentIndexSdmxSearchManagerImpl searchMgr;
        private final IStructureEvent beansEvent;

        public NewSearchIndexUpdater(PersistentIndexSdmxSearchManagerImpl s, IStructureEvent beansEvent) {
            this.searchMgr = s;
            this.beansEvent = beansEvent;
        }

        @Override
        public void run() {
            try {
                //TODO: Lock will also be used when writing new Hash File. Assumption is that
                // writes can never happen concurrently.
                lock.lock();
                isUpdating.set(true);
                Directory directory;
                Map<String, IdentifiableBean> identMap = identifiableMap;

                directory = this.searchMgr.directory;
                analyzer = this.searchMgr.analyzer;


                //Process additions.
                {
                    if (!beansEvent.getAdditions().isEmpty()) {
                        for (MaintainableBean maint : beansEvent.getAdditions().getAllMaintainables()) {
                            if (identMap.containsKey(maint.getUrn()))
                                continue;

                            indexIdentifiable(iWriter, maint);
                            identMap.put(maint.getUrn(), maint);

                            for (IdentifiableBean ident : maint.getIdentifiableComposites()) {
                                indexIdentifiable(iWriter, ident);
                                identMap.put(ident.getUrn(), ident);
                            }
                        }
                    }
                }

                //Process modifications.
                {
                    if (!beansEvent.getModification().isEmpty()) {
                        for (MaintainableBean maint : beansEvent.getModification().getAllMaintainables()) {
                            //Delete old documents.
                            iWriter.deleteDocuments(new Term(URN_FIELD, maint.getUrn()));
                            indexIdentifiable(iWriter, maint);

                            if (identMap.containsKey(maint.getUrn())) {
                                identMap.replace(maint.getUrn(), maint);
                            } else {
                                identMap.put(maint.getUrn(), maint);
                            }

                            for (IdentifiableBean ident : getOldContainer(beansEvent).getMaintainable(maint.getUrn()).getIdentifiableComposites()) {
                                iWriter.deleteDocuments(new Term(URN_FIELD, ident.getUrn()));
                                identMap.remove(ident.getUrn());
                            }

                            for (IdentifiableBean ident : maint.getIdentifiableComposites()) {
                                indexIdentifiable(iWriter, ident);
                                identMap.put(ident.getUrn(), ident);
                            }
                        }
                    }
                }

                //Process Deletions.
                {
                    if (!beansEvent.getDeletions().isEmpty()) {
                        for (MaintainableBean maint : beansEvent.getDeletions().getAllMaintainables()) {
                            //Delete old documents.
                            //Assume the structure does NOT already exist in index. Back this assumption up later.
                            iWriter.deleteDocuments(new Term(URN_FIELD, maint.getUrn()));
                            identMap.remove(maint.getUrn());

                            for (IdentifiableBean ident : maint.getIdentifiableComposites()) {
                                iWriter.deleteDocuments(new Term(URN_FIELD, ident.getUrn()));
                                identMap.remove(ident.getUrn());
                            }
                        }
                    }

                }

                LOG.info("Update Search Index. No of items: " + getNewContainer(beansEvent).getAllMaintainables().size());

                LOG.info("Search Index Updated");
                iWriter.commit();
                writeHashFile();

                this.searchMgr.identifiableMap = identMap;
                this.searchMgr.directory = directory;
                this.searchMgr.analyzer = analyzer;

            } catch (Throwable th) {
                LOG.error("Search index update failure");
                throw new RuntimeException(th);
            } finally {
                isUpdating.set(false);
                lock.releaseLock(false);
            }
        }
    }

    /**
     * Returns a File object which is the location of the "MetadataTechnology" home directory.
     * Not sure this is the best way of doing this, but moving this specific method to this class.
     * @return a File object
     */
	private static File getOrCreateMTDir() {
		String userHome = System.getProperty("user.home");
		LOG.debug("System property user.home is: {}", userHome);
		if (!ObjectUtil.validString(userHome)) {
			throw new RuntimeException("System property 'user.home' has not been set");
		}

		File targetDir1 = new File(userHome, "MetadataTechnology");
		File targetDir2 = new File(targetDir1, "FusionRegistry");

		if (!targetDir2.exists() && !targetDir2.mkdirs()) {
			LOG.error("Unable to create directory: []", targetDir2.getAbsolutePath());
			throw new RuntimeException("Unable to open or create search index parent directories.");
		}

		return targetDir2;
	}
}
