package io.sdmx.fusion.search.engine;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.fusion.search.api.engine.AutocompleteWriter;

public class JSONAutoCompleteWriter implements AutocompleteWriter {

	@Override
	public void writeSuggestions(List<String> autoCompleteSuggestions, OutputStream out) {
		JsonFactory jsonFactory = new JsonFactory();
		
		try (JsonGenerator jsonGenerator = jsonFactory.createGenerator(out, JsonEncoding.UTF8) ) {
			jsonGenerator.writeStartArray();

			for(String currentSuggestion : autoCompleteSuggestions) {
				jsonGenerator.writeString(currentSuggestion);
			}
			
			jsonGenerator.writeEndArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}
