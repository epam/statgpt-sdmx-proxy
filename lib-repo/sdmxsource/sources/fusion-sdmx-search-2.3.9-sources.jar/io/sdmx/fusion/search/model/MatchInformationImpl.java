package io.sdmx.fusion.search.model;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.search.MATCH_ATTRIBUTE;
import io.sdmx.api.sdmx.search.MatchInformation;

public class MatchInformationImpl implements MatchInformation {
	private MATCH_ATTRIBUTE matchedOn;
	private String matchString;
	private String lang;
	private float score;
	private IdentifiableBean matchIdent;

	public MatchInformationImpl(IdentifiableBean matchIdent, MATCH_ATTRIBUTE matchedOn, String matchString, String lang, float score) {
		this.matchedOn = matchedOn;
		this.matchString = matchString;
		this.score = score;
		this.lang = lang;
		this.matchIdent = matchIdent;
	}
	

	@Override
	public IdentifiableBean getMatchIdentifiable() {
		return matchIdent;
	}



	@Override
	public MATCH_ATTRIBUTE getMatchedOn() {
		return matchedOn;
	}

	@Override
	public String getMatchString() {
		return matchString;
	}
	
	@Override
	public String getLang() {
		return lang;
	}

	@Override
	public float getScore() {
		return score;
	}

	@Override
	public int compareTo(MatchInformation o) {
		float score = this.score - o.getScore();
		if(score == 0) {
			score = this.matchedOn.compareTo(o.getMatchedOn());
			if(score == 0) {
				score = this.matchIdent.getUrn().compareTo(o.getMatchIdentifiable().getUrn());
			}
		}
		return score > 0 ? 1 : -1;
	}
}
