package io.sdmx.fusion.search.model;

import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.search.MatchInformation;
import io.sdmx.api.sdmx.search.SearchResult;

public class SearchResultImpl implements SearchResult {
	private MaintainableBean maintainableBean;
	private Set<MatchInformation> matchInformation = new TreeSet<>();
	
	public SearchResultImpl(MaintainableBean maintainableBean) {
		this.maintainableBean = maintainableBean;
	}
	
	@Override
	public float getTotalScore() {
		float totalScore = 0;
		for(MatchInformation currentMatch : matchInformation) {
			totalScore += currentMatch.getScore();
		}
		return totalScore;
	}
	
	@Override
	public void addMatchInformation(MatchInformation match) {
		this.matchInformation.add(match);
	}

	@Override
	public MaintainableBean getMaintainableBean() {
		return maintainableBean;
	}

	@Override
	public Set<MatchInformation> getMatchInformation() {
		return matchInformation;
	}
	
	@Override
	public int compareTo(SearchResult o) {
		float score = this.getTotalScore() - o.getTotalScore();
		if(score == 0) {
			return this.getMaintainableBean().getUrn().compareTo(o.getMaintainableBean().getUrn());
		}
		return score > 0 ? -1 : 1;
	}
}
