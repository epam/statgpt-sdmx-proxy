package io.sdmx.fusion.search.api.engine;

import java.io.OutputStream;
import java.util.List;

public interface AutocompleteWriter {

	void writeSuggestions(List<String> autoCompleteSuggestions, OutputStream out);
	
}
