package io.sdmx.fusion.search.engine;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.search.MatchInformation;
import io.sdmx.api.sdmx.search.SearchResult;
import io.sdmx.fusion.search.api.engine.SearchResultsWriter;

public class JSONSearchResultsWriter implements SearchResultsWriter {
	
	@Override
	public void writeResults(Collection<SearchResult> results, long time, OutputStream out) {
		JsonFactory jsonFactory = new JsonFactory();
		
		try ( JsonGenerator jsonGenerator = jsonFactory.createGenerator(out, JsonEncoding.UTF8) ) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeNumberField("time", time);
			
			Set<SDMX_STRUCTURE_TYPE> resultTypes = new HashSet<>();
			for(SearchResult currentResult : results) {
				resultTypes.add(currentResult.getMaintainableBean().getStructureType());
			}
			jsonGenerator.writeArrayFieldStart("resulttypes");
			for(SDMX_STRUCTURE_TYPE currentResult : resultTypes) {
				jsonGenerator.writeString(currentResult.getType());
			}
			
			jsonGenerator.writeEndArray();

			jsonGenerator.writeArrayFieldStart("results");
			for(SearchResult currentResult : results) {
				writeResult(currentResult, jsonGenerator);
			}
			
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private void writeResult(SearchResult result, JsonGenerator jsonGenerator) throws JsonGenerationException, IOException {
		jsonGenerator.writeStartArray(); //Start Search Result
		jsonGenerator.writeString(result.getMaintainableBean().getUrn());
		jsonGenerator.writeString(result.getMaintainableBean().getStructureType().getType());
		jsonGenerator.writeString(result.getMaintainableBean().getAgencyId());
		jsonGenerator.writeString(result.getMaintainableBean().getId());
		jsonGenerator.writeString(result.getMaintainableBean().getVersion().toString());
		jsonGenerator.writeString(result.getMaintainableBean().getName());
		jsonGenerator.writeNumber(result.getMatchInformation().size());
		jsonGenerator.writeStartArray();
		for(MatchInformation matchInfo : result.getMatchInformation()) {
			jsonGenerator.writeStartArray();
			jsonGenerator.writeString(matchInfo.getMatchString());
			jsonGenerator.writeString(matchInfo.getMatchIdentifiable().getFullIdPath(false));
			jsonGenerator.writeString(matchInfo.getMatchIdentifiable().getStructureType().getType());

			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndArray(); //End Search Result
	}
}
