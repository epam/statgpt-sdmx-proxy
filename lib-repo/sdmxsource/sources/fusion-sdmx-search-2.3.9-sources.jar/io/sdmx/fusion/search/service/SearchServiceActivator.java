package io.sdmx.fusion.search.service;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.sdmx.search.SdmxSearchManager;
import io.sdmx.api.sdmx.search.SearchResult;
import io.sdmx.api.service.search.ISearchService;
import io.sdmx.fusion.search.api.engine.AutocompleteWriter;
import io.sdmx.fusion.search.api.engine.SearchResultsWriter;

public class SearchServiceActivator implements ISearchService {

	private SdmxSearchManager sdmxSearchManager;
	private SearchResultsWriter searchResultsWriter;
	private AutocompleteWriter autocompleteWriter;
	
	public SearchServiceActivator(SdmxSearchManager sdmxSearchManager, SearchResultsWriter searchResultsWriter, AutocompleteWriter autocompleteWriter ) {
		this.sdmxSearchManager = sdmxSearchManager;
		this.searchResultsWriter = searchResultsWriter;
		this.autocompleteWriter = autocompleteWriter;
	}

	@Override
	public void writeAutoCompleteSuggestions(String searchTerm, int maxSuggestions, OutputStream out) {
		autocompleteWriter.writeSuggestions(sdmxSearchManager.getAutoCompleteSuggestions(searchTerm, 10), out);
	}

	@Override
	public void writeSearchResults(String searchTerm, OutputStream out) {
		long start = System.currentTimeMillis();
		Set<SearchResult> results = sdmxSearchManager.performSearch(searchTerm);
		searchResultsWriter.writeResults(results, System.currentTimeMillis()-start, out);
	}
	
}
