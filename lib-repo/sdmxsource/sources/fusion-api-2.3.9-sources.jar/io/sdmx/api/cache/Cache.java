package io.sdmx.api.cache;

public interface Cache {

	/**
	 * Clears the cache
	 */
	void clearCache();
}
