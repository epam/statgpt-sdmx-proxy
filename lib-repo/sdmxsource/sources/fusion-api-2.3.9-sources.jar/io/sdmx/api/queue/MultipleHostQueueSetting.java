package io.sdmx.api.queue;

/**
 * Defines the connection and port to a queue service such as Kafka
 */
public interface MultipleHostQueueSetting extends QueueSetting {

    /**
     * Returns a comma-separated list of host-pairs separated by colons.
     * e.g. localhost:8080 or localhost:8080,anotherserver:2000,serverthre:8080
     *
     * @return a string which is the comma-separated list of host-pairs
     */
    String getServers();

}
