package io.sdmx.api.queue;

/**
 * Marker interface which for a connection to a queue service such as Rabbit or Kafka
 */
public interface QueueSetting {

}
