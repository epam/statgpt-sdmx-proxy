package io.sdmx.api.queue;

public interface IntegrationManager<T extends QueueSetting> {

	/**
	 * Sets up the beans for the queue service defined in type
	 * @param connectionSettings
	 */
	void startup(T connectionSettings);
	
	/**
	 * Close the connection and unload beans to the listening types
	 */
	void shutdown();
}
