package io.sdmx.api.queue;

/**
 * Defines the connection and port to a queue service such as Rabbit
 */
public interface SingleHostQueueSetting extends QueueSetting {

	/**
	 * @return the port to connect to, this can not be null
	 */
    Integer getPort();


	/**
	 * @return the host of the service, can not be null
	 */
    String getHost();

}
