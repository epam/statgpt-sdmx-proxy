package io.sdmx.api.buider;

/**
 * Any Classes implementing this interface are capable of building an object of one type <K>
 * from an object of another type <V>.
 * @author Matt Nelson
 *
 * @param <K> The type of object that gets built by the builder.
 * @param <V> The type of object that the builder requires to build the object from.
 */
public interface Builder<K, V> {

	/**
	 * Builds an object of type <K> from an Object of type <V>.
	 * @param buildFrom An Object to build the output object from
	 * @return Object of type <K>
	 */
	K build(V buildFrom);
}
