package io.sdmx.api.thread;

import java.util.HashMap;
import java.util.Map;

public class LocalThreadStore extends ThreadLocal<Map<Object, Object>> {
    public static final LocalThreadStore INSTANCE = new LocalThreadStore();

    private LocalThreadStore() {}

    @Override
    public Map<Object, Object> initialValue() {
        return new HashMap<>();
    }
}
