package io.sdmx.api.collection;

import java.io.Serializable;
import java.util.List;

/**
 * Represents a hierarchy of objects of type T
 * @param <T>
 */
public interface IHierarchyElement<T> extends Serializable  {

	/**
	 * @return not null, child nodes of this node or empty list if there are none
	 */
	List<IHierarchyElement<T>> getChildren();

	/**
	 * @return nullable - value for this node
	 */
	T getValue();
	
	/**
	 * @return number of elements in this hierarchy
	 */
	default int getSize() {
		int size = 1;  //This element
		for(IHierarchyElement<T> child : getChildren()) {
			size += child.getSize();
		}
		return size;
	}
	
}
