
package io.sdmx.api.collection;

import java.io.Serializable;
import java.util.List;

/**
 * A Dimension point ties a code and concept together to represent an identifier
 * for an item of data
 */
public interface KeyValue extends Comparable<KeyValue>, Serializable  {

	/**
	 * @return concept:code where code =v1,v2,v3 when multiple values exist
	 */
	String getShortCode();
	
	/**
	 * Returns the code that the value is for
	 * @return
	 */
	String getCode();
	
	/**
	 * Returns the key (concept/dimension) that this KeyValue is for
	 * @return
	 */
	String getConcept();
	

	/**
	 * @return a list of values or null if only one value exists
	 */
	List<String> getValues();
	
	/**
	 * @return true if there are multiple values
	 */
	boolean hasMultipleValues();
		
}
