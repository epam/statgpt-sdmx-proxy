package io.sdmx.api.lang;

import java.util.Locale;

/**
 * An interface that wraps a locale and allows for the specification of decimal and group separators.
 * This is required since Java7 does not allow for the modification of a Locale. 
 */
public interface LocaleOverride {
	/**
	 * @return The wrapped locale
	 */
	Locale getLocale();

	/**
	 * @return The decimal separator for this wrapped locale. This may not be null. 
	 */
	Character getDecimalSeparator();

	/**
	 * @return The group separator for this wrapped locale. This may be null.
	 */
	Character getGroupSeparator();
}
