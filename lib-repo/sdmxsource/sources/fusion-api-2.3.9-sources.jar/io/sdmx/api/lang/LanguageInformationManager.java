package io.sdmx.api.lang;

import java.util.Set;

/**
 * Defines the supported languages in the system
 */
public interface LanguageInformationManager {

	/**
	 * @return immutable set of supported languages, not null, not empty
	 */
	Set<String> getSupportedLanguages();
	
}
