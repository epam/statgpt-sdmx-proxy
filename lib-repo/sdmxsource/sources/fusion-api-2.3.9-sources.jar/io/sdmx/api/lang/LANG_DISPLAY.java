package io.sdmx.api.lang;

// Specifies what is output when outputting a CSV
public enum LANG_DISPLAY {
    ID("ID"),
    NAME("NAME"),
    ID_AND_NAME ("ID_AND_NAME");

    private String propertyName;

	private LANG_DISPLAY(String prop) {
		this.propertyName = prop;
	}

	public String getPropertyName() {
		return propertyName;
	}
	
	/**
	 * From REST query parameter
	 * @param labels
	 * @return
	 */
	public static LANG_DISPLAY fromParam(String labels) {
		 // Check the parameterValues
        if(labels != null) {
            if (labels.equals("both")) {
                return LANG_DISPLAY.ID_AND_NAME;
            } else if (labels.equals("name")) {
            	return LANG_DISPLAY.NAME;
            } 
        }
        return LANG_DISPLAY.ID;
	}

	public static LANG_DISPLAY resolvePropertyName(String prop) {
		for(LANG_DISPLAY currentProp : LANG_DISPLAY.values()) {
			if(currentProp.getPropertyName().equals(prop)) {
				return currentProp;
			}
		}
		throw new IllegalArgumentException("Could not resolve property '"+prop+"' to a CSV Label type");
	}
}
