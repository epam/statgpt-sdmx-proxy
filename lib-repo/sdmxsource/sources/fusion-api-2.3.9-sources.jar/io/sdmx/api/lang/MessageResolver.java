package io.sdmx.api.lang;

import java.util.Locale;

/**
 * Used to resolve message codes to text strings based in the given locale.
 * @author Matt Nelson
 *
 */
public interface MessageResolver {

	/**
	 * Resolves the message against a resource which contains code->string mappings, inserting any args
	 * where there are placeholders.  If there is no resource found, or no mapping could be found
	 * for the messageCode, then the original messageCode will be returned.
	 * 
	 * @param message - the message to resolve
	 * @param locale - the locale to resolve the message in
	 * @return the resolved message, or the original if could not be resolved
	 */
	String resolveMessage(String messageCode, Locale locale, Object... args);
}
