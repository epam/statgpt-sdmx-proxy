package io.sdmx.api.lang;

import java.util.List;
import java.util.Locale;

public interface LocaleManager {

	/**
	 * Get the user's chosen locale, unless that isn't in the getLocales() list, 
	 * in which case return with getServerLocale().
	 * @return locale for current user or null
	 */
	Locale getCurrentLocale();

	/**
	 * Get the locale from given language, unless that isn't in the getLocales() list, 
	 * in which case return with getServerLocale().
	 * @return locale for given language or null
	 */
	Locale getLocale(String lang);
	
	/**
	 * Get the default Locale on the server, or English if server Locale isn't in the getLocales() list.
	 * @return server defaults locale or English, not null
	 */
	Locale getServerLocale();

	/**
	 * The full list of locales supported by properties files and resource bundles
	 * @return list of available locales
	 */
	List<Locale> getLocales();
}
