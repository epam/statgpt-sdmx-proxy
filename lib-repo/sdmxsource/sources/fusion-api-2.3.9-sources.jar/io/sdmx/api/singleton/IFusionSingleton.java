package io.sdmx.api.singleton;

/**
 * All objects that are singletons and have the static method "getInstance" should implement this interface
 */
public interface IFusionSingleton {

    /**
     * Destroys the instance, so the next time it is requested a "fresh" instance is obtained
     */
    void destroyInstance();
}
