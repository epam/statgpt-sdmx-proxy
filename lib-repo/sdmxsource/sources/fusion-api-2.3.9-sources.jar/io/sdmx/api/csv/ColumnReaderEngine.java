package io.sdmx.api.csv;

import java.io.Closeable;
import java.util.List;

import io.sdmx.api.format.FormatDetails;

/**
 * Reads information that is presented or can be read in a columnar format, for example Excel, or CSV which has a concept
 * of a Header Row followed by rows which provide content for those headers
 */
public interface ColumnReaderEngine extends Closeable {

	/**
	 * @return a copy of this reader which can be read independently of this one, reset back to the beginning of the stream.
	 */
	ColumnReaderEngine copy();

	/**
	 * Returns an immutable list of header items for the columnar data that is being read, this list
	 * is global for a reader and will never change as the data is being read
	 * @return
	 */
	List<String> readHeader();

	/**
	 * @return details of the format being read
	 */
	FormatDetails getFormatDetails();

	/**
	 * @return row index (zero indexed)
	 */
	int getPosition();

	/**
	 * resets the reader back to the beginning
	 */
	void reset();

	/**
	 * Moves the reader to the next row
	 * @return
	 */
	boolean moveNextRow();

	/**
	 * @return an immutable list of values for the row, each value corresponds with the header item at the same index
	 */
	List<String> readRow();

	/**
	 * releases any resources allocated by the engine
	 */
	@Override
	void close();

	/**
	 * @return current byte count for lineage notifications
	 */
	default long getCurrentByteCount() {
		return -1;
	}
}
