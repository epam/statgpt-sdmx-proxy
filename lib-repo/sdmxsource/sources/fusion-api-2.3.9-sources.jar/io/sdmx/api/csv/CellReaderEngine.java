package io.sdmx.api.csv;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.format.FormatDetails;

public interface CellReaderEngine {
	
	/**
	 * @return the format details of the underlying dataset, if this can not be expressed in FormatDetails, then null is returned
	 */
	FormatDetails getFormatDetails();
	
	/**
	 * Returns a human readable data format, for information purposes only
	 * @return
	 */
	String getDataFormat();
	
	/**
	 * Returns the cell reference as a Excel reference, e.g A2
	 * @return
	 */
	String getCellReference();

	/**
	 * Moves to the next worksheet returns true if there is a next worksheet to move to
	 * @return
	 */
	boolean moveNextWorkSheet();
	
	/**
	 * Returns the name of the worksheet, or null if there is no name
	 * @return
	 */
	String getSheetName();
	
	/**
	 * Returns true if the cell has additional comments 
	 * @return
	 */
	boolean hasComments();
	
	/**
	 * Returns a list of comments for the cell, or null if no comments exist
	 * @return
	 */
	List<String> getComments();
	
	default List<String> readRow() {
		List<String> returnList = new ArrayList<>();
		do {
			String value = getValue();
			if(value != null) {
				returnList.add(value);
			}
		} while(moveNextCell(true));
		return returnList;
	}
	
	/**
	 * Moves to the row at the given index, starting with zero 
	 * @param currentRow
	 * @return
	 */
	boolean setCurrentRow(int currentRow);
	
	/**
	 * Returns the row Index
	 * @return
	 */
	int getCurrentRowIdx();

	/**
	 * Moves to the next row, moves the column index back to the first column
	 * @param skipNulls if true will skip past empty rows
	 */
	boolean moveNextRow(boolean skipNulls);
	
	/**
	 * Moves to the cell at the given index, starting with zero 
	 * @param cellIdx
	 * @return
	 */
	boolean setCurrentCell(int cellIdx);

	/**
	 * Moves to the next Cell on the current row, returning true if there is a next cell to move to
	 * @param skipNulls if true will skip past empty cells
	 * @return
	 */
	boolean moveNextCell(boolean skipNulls);

	/**
	 * Returns the Cell Index
	 * @return
	 */
	int getCurrentCellIdx();

	/**
	 * Returns the value at the current row and cell
	 * @return
	 */
	String getValue();
	
	/**
	 * Returns the value at the given index for the given row
	 * @param colNo
	 * @return
	 */
	String getValue(int colNo);

	/**
	 * Returns true if the given cell for the current row is formatted as a Date
	 * @return
	 */
	boolean isDate();
	
	/**
	 * Returns the SDMX date value at the given cell index. If the date is not formatted as an SDMX date, use the getDate method instead.
	 * @param startOfPeriod formats the date to the start of the period, otherwise it will be end of period. The start of the period 2005 is 2005-01-01T00:00:00 and the end of the period 2005 is 2015-02-01T23:59:59
	 * @return
	 */
	SdmxDate getSdmxDate(boolean startOfPeriod);
	
	/**
	 * Returns the date value at the given cell index 
	 * @return
	 */
	Date getDate();
	
	/**
	 * Returns true if the given cell for the current row is formatted as a Date
	 * @param cellNo
	 * @return
	 */
	boolean isDate(int cellNo);
	
	/**
	 * Returns the SDMX date value at the given cell index.  If the date is not formatted as an SDMX date, use the getDate method instead.
	 * @param colNo
	 * @param startOfPeriod formats the date to the start of the period, otherwise it will be end of period. The start of the period 2005 is 2005-01-01T00:00:00 and the end of the period 2005 is 2015-02-01T23:59:59
	 * @return
	 */
	SdmxDate getSdmxDate(int colNo, boolean startOfPeriod);
	
	/**
	 * Returns the date value at the given cell index
	 * @param colNo
	 * @return
	 */
	Date getDate(int colNo);
	
	/**
	 * Resets the state back to the start
	 */
	void reset();

	/**
	 * Creates a copy of the CellReaderEngine
	 * @param is
	 * @return a copy
	 */
	CellReaderEngine createCopy(InputStream is);
	
	/**
	 * This will move to the next row,  if this row has content, true is returned.
	 * If this row has no content, it will move to the next row and so on...
	 * until the end of the file is reached. If the end of the file is reached, false is returned.
	 * @return true if a next non-empty row is encountered or false if the end of the file is reached before a non-empty row is encountered.
	 */
	boolean skipEmptyRows();
	
	/**
	 * @return number of rows skipped on last move row call
	 */
	int getSkippedRows();
	
	/**
	 * Reset the reader to the top of the current sheet
	 */
	void resetSheet();

	
	/**
	 * Returns whether the reader is at the end of the file or not
	 * @return
	 */
	boolean atEndOfFile();
	
	/**
	 * Closes off any resources
	 */
	void close();
}
