package io.sdmx.api.chars;

public enum CHARS {
	MINUS("-"),
	PERIOD("."),
	COLON(":"),
	SEMI_COLON(";"),
	WHITESPACE(" "),
	STAR("*"),
	OPEN_PARENTHESIS("("),
	CLOSE_PARENTHESIS(")"),
	OPEN_BRACE("{"),
	CLOSE_BRACE("}"),
	OPEN_BRACKET("["),
	CLOSE_BRACKET("]"),
	PLUS("+"),
	COMMA(","),
	SLASH("/"),
	BACKSLASH("\\");
	
	private char c;
	private byte b;
	
	private CHARS(String str) {
		this.c = str.charAt(0);
		b = str.getBytes()[0];
	}
	
	public char getChar() {
		return c;
	}
	
	public byte getByte() {
		return b;
	}
	
	public static char[] toCharArray(CHARS...chars) {
		char[] c = null;
		if(chars != null) {
			c = new char[chars.length];
			for(int i=0; i < chars.length; i++) {
				c[i] = chars[i].getChar();
			}
		}
		return c;
	}
}
