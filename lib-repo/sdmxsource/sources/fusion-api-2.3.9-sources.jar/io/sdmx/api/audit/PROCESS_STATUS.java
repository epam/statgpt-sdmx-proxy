package io.sdmx.api.audit;

/**
 * Outcome of a process, based on HTTP response status
 */
public enum PROCESS_STATUS {
	OK(200),
	REDIRECT_MOVED(301),
	REDIRECT_FOUND(302),
	REDIRECT_NOT_MODIFIED(304),
	
	/**
	 * The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the request without modifications.
	 */
	CLIENT_ERR_BAD_REQUEST(400),
	
	/**
	 * The request requires user authentication. 
	 * The response MUST include a WWW-Authenticate header field (section 14.47) containing a challenge applicable to the requested resource. 
	 * The client MAY repeat the request with a suitable Authorization header field (section 14.8). 
	 * If the request already included Authorization credentials, then the 401 response indicates that authorization has been refused for those credentials.
	 */
	CLIENT_ERR_UNAUTHORISED(401),
	
	/**
	 * The server understood the request, but is refusing to fulfill it. 
	 * Authorization will not help and the request SHOULD NOT be repeated. 
	 * If the request method was not HEAD and the server wishes to make public why the request has not been fulfilled, 
	 * it SHOULD describe the reason for the refusal in the entity. 
	 * If the server does not wish to make this information available to the client, the status code 404 (Not Found) can be used instead.
	 */
	CLIENT_ERR_FORBIDDEN(403),
	
	/**
	 * The server has not found anything matching the Request-URI. No indication is given of whether the condition is temporary or permanent. 
	 */
	CLIENT_ERR_NOT_FOUND(404),
	CLIENT_ERR_METHOD_NOT_ALLOWD(405),
	CLIENT_ERR_REQUEST_TOO_LARGE(413),
	
	/**
	 * The request entity has a media type which the server or resource does not support. 
	 * For example, the client uploads an image as image/svg+xml, but the server requires that images use a different format.
	 */
	CLIENT_ERR_UNSUPPORTED_MEDIA_TYPE(415),
	
	/**
	 * The 422 (Unprocessable Entity) status code means the server understands the content type of the request entity 
	 * (hence a 415(Unsupported Media Type) status code is inappropriate), 
	 * and the syntax of the request entity is correct (thus a 400 (Bad Request) status code is inappropriate) 
	 * but was unable to process the contained instructions. 
	 * 
	 * For example, this error condition may occur if an XML request body contains well-formed 
	 * (i.e., syntactically correct), but semantically erroneous, XML instructions.
	 */
	CLIENT_ERR_UNSUPPORTED_ENTITY(422),
	CLIENT_ERR_UPGRADE_REQUIRED(426),
	SERVER_ERR_INTERNAL_ERROR(500),
	SERVER_ERR_NOT_IMPLEMENTED(501),
	SERVER_ERR_BAD_GATEWAY(502),
	SERVER_ERR_SERVICE_UNAVAILABLE(503),
	SERVER_ERR_GATEWAY_TIMEOUT(504);
	
	private int statusCode;

	private PROCESS_STATUS(int statusCode) {
		this.statusCode = statusCode;
	}

	public int getStatusCode() {
		return statusCode;
	}
	
	public static PROCESS_STATUS getStatus(int i) {
		for(PROCESS_STATUS status : PROCESS_STATUS.values()) {
			if(status.statusCode == i) {
				return status;
			}
		}
		return null;
	}
}
