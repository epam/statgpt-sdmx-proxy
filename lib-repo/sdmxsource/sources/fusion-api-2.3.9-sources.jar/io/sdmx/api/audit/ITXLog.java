package io.sdmx.api.audit;

/**
 * Records a transactional event consisting of one or more objects to the object store
 * @see IObjectStoreDao
 * @see IObjectTXDao
 */
public interface ITXLog {  //TODO renamte to ITXEvent?
	
	/**
	 * @return not null the unique identification for this transaction
	 */
	Integer getId();
	
	/**
	 * @return 1=Append, 2=Replace, 3=Delete
	 */
	Integer getAction();
	
	/**
	 * @return ID of the store, i.e. structure, metadata
	 */
	String getStore();
	
	/**
	 * @return nullable the audit id for this transaction
	 */
	String getAuditId();
	
	/**
	 * @return not null timestamp when the transaction was created (Epoch Time)
	 */
	Long getCreated();
	
	/**
	 * @return nullable, user associated with the transaction
	 */
	String getUsername();
}
