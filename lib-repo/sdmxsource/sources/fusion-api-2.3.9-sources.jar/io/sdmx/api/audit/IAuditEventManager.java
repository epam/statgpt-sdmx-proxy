package io.sdmx.api.audit;

import io.sdmx.api.process.IProcess;
import io.sdmx.api.process.IProcessWithResponse;

/**
 * Central manager for creation audit entries
 * @see AuditUtil - a wrapper around this class
 */
public interface IAuditEventManager {
	
	/**
	 * @return the id of the current process being audited or null if nothing is being audited
	 */
	String getCurrentAuditId();
	
	/**
	 * Sets the current audit root event and all child events to be persisted on audit close
	 * A persisted audit is one which remains in the audit table at all times, and is not subject to removal
	 * during housekeeping operations
	 */
	void setPersisted();
	
	/**
	 * @return the current audit
	 */
	IFusionAuditEvent getCurrentAudit();

	/**
	 * Prepares an audit event, enabling the capture of high level audit information without committing to persisting the event.
	 * 
	 * A prepared audit is only persisted if a later process starts an audit event - if this does not happen, then the prepared audit is 
	 * discarded after the process is completed
	 * 
	 * @param processId
	 * @param eventType
	 * @param auditProcss
	 * @return
	 */
	String prepareAudit(String processId, String eventType, IProcess auditProcss);
	
	/**
	 * starts an audited event with the processId passed in, if there is already an audit in place, the new audit 
	 * will be a child of the current audit
	 * 
	 * @param processId ID of the process which is writing this event
	 * @param eventType The type of event (optional) for further refinement
	 * @param auditProcss - the interface which executes the process
	 * @return audit id
	 */
	<T> T startAuditEventWithResponse(String processId, String eventType, IProcessWithResponse<T> auditProcss);
	
	/**
	 * starts an audited event with the processId passed in, if there is already an audit in place, the new audit 
	 * will be a child of the current audit
	 * 
	 * @param processId ID of the process which is writing this event
	 * @param eventType The type of event (optional) for further refinement
	 * @param auditProcss - the interface which executes the process
	 * @return audit id
	 */
	String startAuditEvent(String processId, String eventType, IProcess auditProcss);
	
	/**
	 * starts an audited event with the processId passed in, if there is already an audit in place, the new audit 
	 * will be a child of the current audit
	 * 
	 * @param processId ID of the process which is writing this event
	 * @param eventType The type of event (optional) for further refinement
	 * @param parentId the ID of the parent event - this would be used if the process is started after the parent process audit has finished, for example if this
	 * process is started from a queue, and the owning process which added to the queue has subsequently completed
	 * @param auditProcss - the interface which executes the process
	 * @return audit id
	 */
	String startAuditEvent(String processId, String eventType, String parentId, IProcess auditProcss);
	
	/**
	 * starts a new thread with an audited process, if there is already an audit in place then the new thread's audit 
	 * will be a child of the current audit, otherwise it will be a new audited process
	 * @param subProcessId The ID of the process to run the new thread in
	 * @param eventType The type of event (optional) for further refinement
	 * @param copyThreadLocal if true ThreadLocale will be copied into the new thread
	 * @param process the interface which executes the process
	 */
	String startNewThread(String subProcessId, String eventType, boolean copyThreadLocal, IProcess process);
	
	/**
	 * Adds a property to this audit event or subprocess if in a subprocess
	 * @param propertyId
	 * @param propertyValue - properties are stored in a JSONObject, so a property value can be a String, Numerical (Integer, Double) JsonObject or JsonArray
	 */
	void addAuditProperty(String propertyId, Object propertyValue);

}
