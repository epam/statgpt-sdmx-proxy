package io.sdmx.api.audit;

/**
 * represents a new audited process which is run by the audit manager ensuring the audit process is started and stopped on execution and completion
 */
@FunctionalInterface
public interface IAuditedProcess<T> {

	/**
	 * runs the process returning the outcome as a status based on the HTTP codes
	 */
	T runProcess();
	
}
