package io.sdmx.api.audit;

import io.sdmx.api.format.IJsonCompatible;
import org.codehaus.jettison.json.JSONObject;

/**
 * Represents a process that is run in a Fusion software application, which is tracked and audited, extends the description by
 * adding audit properties
 */
public interface IFusionAuditEvent extends IJsonCompatible {
	
	/**
	 * @param asStub if true it will not contain any audited properties
	 * @return JSON Object
	 */
	JSONObject getJson(boolean asStub);
	
	
	/**
	 * @return unique identifier for this event
	 */
	String getUid();
	
	/**
	 * @return identifier for process example REST_QUERY, DATA_SUBMISSION
	 */
	String getProcessId();
	
	/**
	 * @return interval between process start and process end - or null if there is no process end
	 */
	Long getDuration();

	/**
	 * @return optional an event type for the process, example ProcessId = PORTAL EventType= ADD_DEFINITION
	 */
	String getEventType();
	
	/**
	 * @return time the process started
	 */
	Long getProcessStart();
	
	/**
	 * @return time the process finished
	 */
	Long getProcessEnd();
	
	/**
	 * Uses the HTTP status flag to indicate the outcome of the event, even if the event is not a HTTP request the
	 * available HTTP  status cover most use cases (security 403, server error 500, request error 402). -1 is the default status
	 * to indicate the request has not completed
	 * 
	 * @return status
	 */
	Integer getStatus();
	void setStatus(Integer status);
	
	/**
	 * @return IP of user who initiated the request, or null to indicate no filter
	 */
	String getIp();
	
	/**
	 * @return username of user which initiated this process or null if anonymous
	 */
	String getUsername();
	
	/**
	 * @return UID of parent process that initiated this process
	 */
	String getParentProcess();
	
	
	/**
	 * @return any audited properties
	 */
	JSONObject getAuditedProperties();
	
	/**
	 * @return virtual machine Identifier
	 */
	String getVMID();
	
	/**
	 * @return identifier for the hardware the application was running on
	 */
	String getMachineId();
	
	/**
	 * @return software version that ran the process
	 */
	String getSoftwareVersion();
	
}
