package io.sdmx.api.error;

/**
 * Responsible for distributing IErrorReports, example implementations would be an email service to which one could subscribe, a KafKa Topic, or an internal audit
 */
public interface IErrorDistributionEngine {

	/**
	 * Distributes the error to the endpoint(s) for this service
	 * @param errorReport
	 */
	void distributeError(IErrorReport errorReport, IErrorNotifier notifier);
	
}
