package io.sdmx.api.error;

import java.util.Map;

/**
 * To be used for ErrorNotifiers to report what errors they transmit
 * @see IErrorNotifier
 */
public interface IErrorCategory {

	/**
	 * Identifier which is unique to the Error Notifier, the combination of the ErrorNotifier's Id and this Id form a unique
	 * combination to identify this category
	 * @return
	 */
	String getId();
	
	/**
	 * Human readable name of error
	 * @return
	 */
	String getErrorName();
	
	/**
	 * Description of error
	 * @return
	 */
	String getErrorDescription();
	
	/**
	 * An immutable map of additional properties which are specific to the error being reported.  The 
	 * key to the map is the property Id, the value is a human readable the description of the property.
	 * <p/>
	 * This map is optional, if no additional properties are supported, an empty map  is returned
	 * 
	 * @return
	 */
	Map<String, String> getSupportedProperties();
	
	/**
	 * @return the parent notifier
	 */
	IErrorNotifier getErrorNotifier();
	
}
