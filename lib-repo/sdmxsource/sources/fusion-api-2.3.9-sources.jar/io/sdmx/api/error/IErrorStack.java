package io.sdmx.api.error;

import io.sdmx.api.format.IJsonCompatible;

/**
 * One line item of the java stack 
 */
public interface IErrorStack extends IJsonCompatible {

	/**
	 * @return line of code
	 */
	Integer getLineNumber();
	
	/**
	 * @return the Java method name
	 */
	String getMethodName();
	

	/**
	 * @return the Java class name
	 */
	String getClassName();
}
