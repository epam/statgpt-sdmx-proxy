package io.sdmx.api.error;

import io.sdmx.api.format.IJsonCompatible;

public interface IErrorException extends IJsonCompatible {

	/**
	 * @return class name of the exception
	 */
	String getExceptionClass();
	
	/**
	 * @return message from the exception
	 */
	String getExceptionMessage();
	
}
