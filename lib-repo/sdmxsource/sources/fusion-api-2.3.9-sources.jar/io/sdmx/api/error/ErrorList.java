
package io.sdmx.api.error;

import java.util.List;

/**
 * Contains a list of error messages
 * @author Matt Nelson
 *
 */
public interface ErrorList {
	
	/**
	 * Returns a copy of the list, the first in the list is the last error in the stack, the last item in the list is the 
	 * originating error message
	 * @return
	 */
	List<String> getErrorMessage();
	
	/**
	 * Returns true if this is just a warning
	 * @return
	 */
	boolean isWarning();
}
