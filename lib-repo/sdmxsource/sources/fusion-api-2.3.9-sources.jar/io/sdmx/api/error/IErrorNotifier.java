package io.sdmx.api.error;

import java.util.List;

/**
 * Implementations are capable of reporting errors to the ErrorReporterManager.
 */
public interface IErrorNotifier {

	/**
	 * A unique identifier to identify the notifier
	 */
	String getId();

	/**
	 * A human readable short name for this notifier
	 * @return
	 */
	String getName();
	
	/**
	 * A long human readable description for subscribers to understand the purpose of this notifier,
	 * what is the purpose, what does it notify 
	 */
	String getDescription();
	
	/**
	 * An immutable list of error categories that this notifier can report against
	 * @return
	 */
	List<IErrorCategory> getErrorCategories();
	
	/**
	 * @param id
	 * @return category with the given id or null if it does not exist
	 */
	default IErrorCategory getCategory(String id) {
		for(IErrorCategory category : getErrorCategories()) {
			if(category.getId().equals(id)) {
				return category;
			}
		}
		return null;
	}
	
}
