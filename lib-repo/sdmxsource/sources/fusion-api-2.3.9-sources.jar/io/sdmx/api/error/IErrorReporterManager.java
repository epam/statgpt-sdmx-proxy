package io.sdmx.api.error;

import java.util.Set;

/**
 * Distributes ErrorReports to subscribed parties.  
 */
public interface IErrorReporterManager {

	
	/**
	 * Report an error,the Report's IErrorNotifier must be registered with this manager
	 * @param report
	 */
	void reportError(IErrorReport report);
	
	/**
	 * Registers with the manager, giving the notifier the capabilities of reporting errors
	 * @param notifier
	 */
	void registerNotifier(IErrorNotifier notifier);
	
	/**
	 * Registers with the manager, to distribute errors to
	 * @param notifier
	 */
	void registerDistributionEngine(IErrorDistributionEngine distributionEngine);
	
	
	/**
	 * @return an immutable list of error notifiers that are registered with this manager
	 */
	Set<IErrorNotifier> getErrorNotifiers();
	
}
