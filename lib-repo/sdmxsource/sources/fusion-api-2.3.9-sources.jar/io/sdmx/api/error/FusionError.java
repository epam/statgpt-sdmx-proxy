package io.sdmx.api.error;

/**
 * Represents a combination of an error code and error message, allowing for unique error messages within the codebase
 */
public interface FusionError {
	
    String getErrorMessage();

    String getErrorCode();
}
