package io.sdmx.api.logging;

import io.sdmx.api.format.IJsonCompatible;

public interface IFusionLogEvent extends IJsonCompatible {
	
	/**
	 * @return the associated audit id or null if this is not an audited process
	 */
	String getAuditId();
	
	/**
	 * Returns the name of the logger used, typically the class name that the log message was generated from
	 * @return
	 */
	String getLoggerName();
	
	/**
	 * @return the name of the thread that the log was captured on
	 */
	String getThreadName();
	
	/**
	 * @return the level the log message was logged at
	 * Trace = 0
	 * Debug = 1
	 * Info = 2
	 * Warn = 3
	 * Error = 4
	 * All = -1
	 * Off = -10
	 */
	Integer getLogLevel();
	
	/**
	 * @return the expire time, or null if it should not expire
	 */
	Long getExpires();

	/**
	 * Returns the time the message was logged
	 * @return
	 */
	Long getLogTime();

	/**
	 * Returns the logged message
	 * @return
	 */
	String getMessage();
}
