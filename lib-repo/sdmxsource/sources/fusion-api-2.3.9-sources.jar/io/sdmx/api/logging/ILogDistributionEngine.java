package io.sdmx.api.logging;

public interface ILogDistributionEngine {

	/**
	 * Notified when a new logging event occurs
	 * @param loggingEvent
	 */
	void logEvent(IFusionLogEvent loggingEvent);
	
}
