package io.sdmx.api.logging;

import io.sdmx.api.process.IProcess;

/**
 * Provides a central manager for distributing system log events (IFusionLogEvent) to zero -> many output channels
 * which can be addede / removed dynamically
 */
public interface ILogDistributionManager {
	
	/**
	 * Adds a log distribution engine to receive system log events for the duration of the process
	 * @param distEngine
	 * @param p
	 */
	void runProcessWithTempDistributionEngine(ILogDistributionEngine distEngine, IProcess p);
	
	/**
	 * Adds a log distribution engine to recieve future system log events
	 * @param distEngine
	 */
	void addDistributionEngine(ILogDistributionEngine distEngine);
	
	/**
	 * Removes a log distribution engine from the manager
	 * @param distEngine
	 */
	void removeDistributionEngine(ILogDistributionEngine distEngine);
}
