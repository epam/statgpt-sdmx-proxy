package io.sdmx.api.notification;

public interface Notifier<T> {

	void addListener(Listener<T> listener);
	
	void removeListener(Listener<T> listener);
	
}