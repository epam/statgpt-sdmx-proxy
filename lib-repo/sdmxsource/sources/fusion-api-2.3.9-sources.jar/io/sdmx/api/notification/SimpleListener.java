package io.sdmx.api.notification;

/**
 * A class that can listen for actions and be invoked.
 */
@FunctionalInterface
public interface SimpleListener {
	
	/**
	 * Listens for changes to all objects that notify their changes.
	 */
	void invoke();
}
