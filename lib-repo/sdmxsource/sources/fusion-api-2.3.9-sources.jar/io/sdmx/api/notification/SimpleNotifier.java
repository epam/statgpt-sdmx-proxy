package io.sdmx.api.notification;


public interface SimpleNotifier {

	void addListener(SimpleListener listener);
	
	void removeListener(SimpleListener listener);
}