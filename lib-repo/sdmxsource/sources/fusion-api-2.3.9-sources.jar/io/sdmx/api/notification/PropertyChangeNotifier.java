package io.sdmx.api.notification;

public interface PropertyChangeNotifier {

	/**
	 * Adds a listener to be notified when a specific property has changed
	 * @param propertyName the property to listen for changes
	 * @param listener the listener to be notified
	 */
	void addListener(String propertyName, PropertyChangeListener listener);
	
}
