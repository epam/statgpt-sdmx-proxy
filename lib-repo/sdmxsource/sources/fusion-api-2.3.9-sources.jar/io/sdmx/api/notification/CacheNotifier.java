package io.sdmx.api.notification;

import io.sdmx.api.cache.Cache;

/**
 * A Cache that is capable of notifying any subscribed listeners when the cache has been updated
 *
 * @param <T> the notification object
 */
public interface CacheNotifier<T> extends Cache, Notifier<T> {

}
