package io.sdmx.api.notification;

public interface PropertyChangeListener {

	/**
	 * Notifies that a property has changed
	 * @param propertyName
	 * @param propertyValue
	 */
	void propertyChanged(String propertyName, String propertyValue);
	
}
