
package io.sdmx.api.notification;

/**
 * A class that can listen for actions and be invoked.
 */
public interface Listener<T> {
	
	/**
	 * Listens for changes to object of type T and is notified on change and is passed in T. 
	 * @param obj
	 */
	void invoke(T obj);

}
