package io.sdmx.api.io;

/**
 * A full instance of an object whose loading can be deferred allowing it to be lazy loaded
 * 
 * @param <T>
 * @see IDeferredObjectReaderManager
 * @see IDeferredDefinitionSerialiser
 * @see IDeferred
 */
public interface IDeferrable<T> {
 
    /**
     * @return the core properties that are required to build a {@link IDeferred} instance of this type
     */
    IDeferredDefinition<T> getDeferredDefinition();
    
}
