package io.sdmx.api.io;

/**
 * Provides the ability to load in {@link IDeferred} object instanced based on the {@link IDeferredDefinition} and
 * the {@link IDeferredLoader}
 * 
 * @param <K> the definition type
 * @param <T> the object type that is loaded
 */
public interface IDeferredObjectReaderManager<K extends IDeferredDefinition<T>, T extends IDeferrable<T>> {

    /**
     * Given a definition of a deferred bean, and a load, this method will return a concreate instance
     * of a class which can be cast to the interface of the full object type (T) but it itself is a {@link IDeferred}
     * instance, meaning it contains only a lightweight representation of the object T, with the main body of the object lazily
     * loaded when required (via the loader)
     * 
     * @param deferredDefinition - contains the definition of the object, enough to build the lightweight container
     * @param loader - provides the ability to load in the full object when required
     * @return a lightweight implementation of type T whose content is only loaded in when an API call is made on the object where the details are not held in the deferredDefinition
     */
    IDeferred<T> read(K deferredDefinition, IDeferredLoader<T> loader);
    
    /**
     * @param deferredDefinition
     * @return true if the definition can be built into a {@link IDeferred} instance
     */
    boolean supports(K deferredDefinition);
    
}
