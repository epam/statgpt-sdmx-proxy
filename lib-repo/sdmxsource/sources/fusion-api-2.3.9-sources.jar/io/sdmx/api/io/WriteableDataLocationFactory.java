
package io.sdmx.api.io;

import io.sdmx.api.format.FILE_FORMAT;

/**
 * Used to create WriteableDataLocation
 */
public interface WriteableDataLocationFactory {

	/**
	 * Returns a writeable data location, where data can be written to for temporary purposes
	 * @return
	 */
	WriteableDataLocation getTemporaryWriteableDataLocation();
	
	/**
	 * Returns a writeable data location of the specified format, where data can be written to for temporary purposes
	 * @param fileFormat the format for this WriteableDataLocation
	 * @return
	 */
	WriteableDataLocation getTemporaryWriteableDataLocation(FILE_FORMAT fileFormat);
	
}
