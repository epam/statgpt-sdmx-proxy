package io.sdmx.api.io;

import java.io.Closeable;
import java.io.OutputStream;

/**
 * Aan output stream which gzips the content before going to the target stream
 */
public interface IGzipResponseStream extends Closeable {

	/**
	 * @return itself as an output stream
	 */
	OutputStream getGZipStream();
	
	/**
	 * @return the underlying output stream which the gzip stream proxies
	 */
	OutputStream writeGZipDirectToStream();
	
	/**
	 * @param flushToGzipStream the condition where this is false is if the user has already written directly to the Stream using writeGZipDirectToStream()
	 */
	void close(boolean flushToGzipStream);
}
