package io.sdmx.api.io;

/**
 * Loads the full object type T from the {@link IDeferred} object of T
 * @param <T>
 */
public interface IDeferredLoader<T extends IDeferrable<T>> {

    /**
     * @return the full object loaded from the deferred instance
     */
    T load(IDeferred<T> deferred);
    
}
