package io.sdmx.api.io;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * @param <T>
 */
public interface IObjectSerialiser<T> {
	
	/**
	 * @return the ID of the serialiser
	 */
	String getId();

	/**
	 * Writes an object to the output stream
	 * @param object not null, object to write
	 * @param out closed on completion
	 */
	void write(T object, OutputStream out);
	
	/**
	 * Reads an object from the input stream
	 * @param in
	 * @return
	 */
	T read(InputStream in);
	
}
