package io.sdmx.api.io;

/**
 * Finds the {@link IObjectSerialiser} with the given ID
 */
public interface IObjectSerialiserRetrievalManager {

	/**
	 * @param id
	 * @return the serialiser with the given id or returns null if it can not be found
	 */
	IObjectSerialiser<?> getSerialiser(String id);
	
}
