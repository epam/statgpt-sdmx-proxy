package io.sdmx.api.io;

/**
 * An object which is a lightweight proxy on top of the <T> object instance, with the bulk of the
 * instance lazily loaded on demand.
 * 
 * A IDeferred object is of type T and can be safely cast to type T, critically the 'guts' of type T
 * are lazily loaded into the {@link IDeferred} instance on demand
 */
public interface IDeferred<T extends IDeferrable<T>> {

}
