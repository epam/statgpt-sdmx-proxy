package io.sdmx.api.io;

public interface CancelableWriteableDataLocation extends WriteableDataLocation {

	/**
	 * Cancels the data write and deletes any written information
	 */
	void cancel();
	
}
