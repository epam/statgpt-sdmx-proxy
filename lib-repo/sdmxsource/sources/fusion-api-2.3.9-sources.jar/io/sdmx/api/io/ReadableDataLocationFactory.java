
package io.sdmx.api.io;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;

/**
 * Used to create ReadableDataLocations from various sources of information
 */
public interface ReadableDataLocationFactory {

	
	/**
	 * Create a readable data location from a String, this may represent a URI (file or URL) 
	 * @param uriStr
	 * @return
	 */
	ReadableDataLocation getReadableDataLocation(String uriStr);
	
	ReadableDataLocation getReadableDataLocation(byte[] bytes);

	ReadableDataLocation getReadableDataLocation(File file);

	ReadableDataLocation getReadableDataLocation(URL url);
	
	ReadableDataLocation getReadableDataLocation(URI uri);
	
	ReadableDataLocation getReadableDataLocation(InputStream is);
	
	
}
