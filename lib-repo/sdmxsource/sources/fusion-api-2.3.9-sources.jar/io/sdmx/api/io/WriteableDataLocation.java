package io.sdmx.api.io;

import java.io.OutputStream;

/**
 * A WriteableDataLocation extends the capability of being able to read data by giving access to the OutputStream
 * to the source data.  This allows additional information to be written to the source
 *
 */
public interface WriteableDataLocation extends ReadableDataLocation {

	OutputStream getOutputStream();
	
}
