package io.sdmx.api.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Wraps a HTTP servlet output stream with a gzip stream
 */
public interface IGzipResponseWrapper {
	public static final String THREAD_KEY = "GZIPResponseWrapper";  //key used to store this on ThreadLocal
	/**
	 * Adds a header to the original response stream
	 * @param id
	 * @param value
	 */
	void addHeader(String id, String value);
	
	
	OutputStream getOutputStream()  throws IOException;
	
}
