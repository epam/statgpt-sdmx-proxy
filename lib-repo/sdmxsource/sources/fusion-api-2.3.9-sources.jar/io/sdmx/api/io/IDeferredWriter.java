package io.sdmx.api.io;

/**
 * Provides the ability to both write object T and be able to load in based on a {@link IDeferredDefinition}
 * @param <T>
 */
public interface IDeferredWriter<T extends IDeferrable<T>> extends IDeferredLoader<T> {

    /**
     * @param deferrable
     */
    void write(T deferrable);
    
}
