package io.sdmx.api.io;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Serialises and deserialises {@link IDeferredDefinition}
 * @param <T>
 */
public interface IDeferredDefinitionSerialiser<T extends IDeferredDefinition> {
	
	/**
	 * @return the ID of the serialiser
	 */
	String getId();

	/**
	 * Writes an object to the output stream
	 * @param object not null, object to write
	 * @param out closed on completion
	 */
	void write(T definition, OutputStream out);
	
	/**
	 * Reads a deferred definition from the input stream, builds the {@link IDeferred} proxy with the ability
	 * to load itself from the {@link IDeferredLoader}
	 * @param in
	 * @return
	 */
	T read(InputStream in);
	
}
