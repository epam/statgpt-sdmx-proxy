package io.sdmx.api.io;

import java.io.OutputStream;

public interface FileReader {

	/**
	 * Moves the reader back to the start of the document.
	 */
	void resetReader();
	
	/**
	 * Moves the file pointer to the next line.
	 * @return false if there is no next line
	 */
	boolean moveNext();
	
	/**
	 * Reads the current line - minus the prefix, if the prefix is unknown then an exception is thrown
	 * @return the current line
	 */
	String getCurrentLine();

	/**
	 * Move the file pointer to the next line and returns that line.
	 * Null is returned if there is no next line.
	 * This method is almost the same as calling moveNext() followed by getCurrentLine() the difference is if there is no next line,
	 * the call to getCurrentLine() will the same result as it did prior to this call
	 */
	String getNextLine();
	
	/**
	 * Returns the line number of the current line, the first line being '1'
	 * @return
	 */
	int getLineNumber();
	
	/**
	 * Returns the character offset of the current position. This is '1' indexed
	 * @return
	 */
	int getStartLineOffset();
	
	/**
	 * Returns the character offset of the current position. This is '1' indexed
	 * @return
	 */
	int getEndLineOffset();
	
	/**
	 * Returns true is the reader has flagged this to move back a line, as moving back a line does not actually change the current line
	 * details
	 * @return
	 */
	boolean isBackLine();
	
	/**
	 * Moves the reader back a single line.  This can not be called to iterate backwards - it will only move back one line
	 */
	void moveBackLine();
	
	/**
	 * Copies the EDI file to the specified OutputStream
	 * @param out
	 */
	void copyToStream(OutputStream out);
	
	/**
	 * Close the reader and any resources associated with the reader
	 */
	void close();

	/**
	 * @return whether the current line ends with the specified termination character
	 */
	boolean lineEndedWithTerminationCharacter();
	
	/**
	 * @return The end-line characters of the file (e.g. bytes 10 and 13)
	 */
	String getNewlineCharacters();
}
