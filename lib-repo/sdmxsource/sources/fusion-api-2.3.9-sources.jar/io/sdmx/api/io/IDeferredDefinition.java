package io.sdmx.api.io;

/**
 * Contains the details of a {@link IDeferrable} that can be used to create an {@link IDeferred} object
 * @param <T>
 */
public interface IDeferredDefinition<T> {

}
