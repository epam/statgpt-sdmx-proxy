package io.sdmx.api.io;

import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Path;
import java.util.List;

import io.sdmx.api.format.FILE_FORMAT;

/**
 * ReadableDataLocation is capable of reading and re-reading the same source of data many times
 */
public interface ReadableDataLocation extends Serializable, AutoCloseable {
    
    /**
     * Moves the bytes to the moveTo path and closes this stream on completion
     * 
     * @return
     */
    ReadableDataLocation move(Path moveTo);
    
    /**
     * @return stream size in bytes
     */
    long getSize();
	
	/**
	 * @return the format of the information this is reading
	 */
	FILE_FORMAT getFormat();

	/**
	 * This method is guaranteed to return a new InputStream on each method call.
	 * The InputStream will be reading the same underlying data source.
	 * @return a new InputStream
	 */
	InputStream getInputStream();
	
	/**
	 * If this ReadableDataLocation originated from a file, then this will be the original file name,
	 * regardless of where the stream is actually held.
	 * This method may return null if the name is not relevant.
	 * @return the name or null.
	 */
	String getName();
	
	/**
	 * Closes (and removes if appropriate) any resources that are held open
	 */
	@Override
	void close();
	
	/**
	 * Returns whether this ReadableDataLocation is closed or not.
	 * @return true if closed
	 */
	boolean isClosed();
	
	/**
	 * Returns a copy of this ReadableDataLocation.
	 * @return a new copy of this object.
	 */
	ReadableDataLocation copy();
	
	/**
	 * Returns true if protected
	 * @return
	 */
	boolean isProtected();
	
	/**
	 * Sets protected true/false, if true, the close method will not close this resource
	 * @param protect
	 */
	void setProtected(boolean protect);
	
	/**
	 * @return true if this {@link ReadableDataLocation} can be split into multiple {@link ReadableDataLocation}s, for example if this
	 * is a zip containing a collection of files
	 */
	boolean splitable(); //{

	/**
	 * If this {@link ReadableDataLocation} is splittable, this split will resolve to one or more {@link ReadableDataLocation}s which result
	 * @param closeSource if true this source {@link ReadableDataLocation} will be closed, the implementation must ensure the closure of this {@link ReadableDataLocation} will
	 * not result in the closure of the underlying {@link ReadableDataLocation}s
	 * @return list of split {@link ReadableDataLocation} - if this is not splitable, the returned list will contain only 1 item which is this {@link ReadableDataLocation}
	 */
	List<ReadableDataLocation> split(boolean closeSource);
}