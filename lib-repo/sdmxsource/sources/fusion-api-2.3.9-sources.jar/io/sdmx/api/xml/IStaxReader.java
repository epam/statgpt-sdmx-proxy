package io.sdmx.api.xml;

import java.util.Map;

import javax.xml.stream.XMLStreamException;

public interface IStaxReader {
	
	 public void reset();
     public boolean moveNextStartNode();
     public String getElementNamespace();
     public void skipCurrentNode();
     public boolean jumpToNode(String findNodeName);
     public void skipNode();

     /**
 	 * Moves to the next element, the state of the StaxReader is updated, but the next call to moveNextNode will 
 	 * not move the position forward
 	 * @return
 	 */
 	boolean peak();
 	
     /**
      * Moves the parser position forward to the next instance of the node with the given name
      * @param parser
      * @throws XMLStreamException
      */
     public boolean skipToNode(String nodeName);
     public boolean jumpToNode(String findNodeName, String doNotProcessPastNodeName);

     /**
      * Moves the parser position forward to the next instance of the end node given name
      * @param parser
      * @throws XMLStreamException
      */
     public boolean skipToEndNode(String nodeName);
     public String getAttributeValue(String attrId);
     public String getAttributeValue(String namespace, String attrId);
     /**
      * Moves to the next start or end node
      * @return
      */
     public boolean moveNextNode();

     /**
      * Returns the XML path to the current element, for example Root/Element1/ChildElemet
      * @return
      */
     public String getXMLPath();

     public String getElementName();

     public String getElementText();
     public boolean isStartElement();
     public Map<String, String> getAttributes();
     public boolean hasDocType();
     public int getAttributeCount();
     public String getAttributeLocalName(int i);
     public String getAttributeValue(int i);
     public String getAttributePrefix(int i);
     public void close();
}
