package io.sdmx.api.date;

import java.util.Map;
import java.util.Set;

/**
 * A periods container provides the means to store an contents against one or more periods.  
 * 
 * On first initialisation the PeriodsContainer will provide one continuous period (All Periods), for which there are contents.  
 * As content is added for specific periods, the PeriodsContainer will split up the continuous period, along with any contents into sub periods, the
 * periods container will always maintain a continuous, non-overlapping, period of contents, however the number of periods can increase as new content is store.
 * 
 * Example:
 * PeriodsContainer initialised to store a set of Strings which is empty
 * PeriodsContainer.addContents stores String 'A' for All periods
 * PeriodsContainer.addContents stores String 'B' for 2010 onwards - the container now has two periods  
 *   1. everything up to 2010 which holds 'A' 
 *   2. from 2010 onwards which holds     'A' and 'B'
 * 
 * PeriodsContainer.addContents stores String 'C' for 2008 to 2011 - the container now has two periods  
 *   1. everything up to 2008 which holds 'A' 
 *   2. from 2008 to 2010 which holds     'A', 'C' 
 *   3. from 2010 to 2011 which holds     'A', 'B', 'C'
 *   4. from 2011 onwards which holds     'A', 'B' 
 *   
 * 
 */
public interface PeriodsContainer<T> {

	/**
	 * Adds contents to this container for the specified period.
	 * 
	 * If the contents spans one or more periods, the contents will be added to all periods
	 * Example:
	 * Existing Periods: 2000-2002, 2003-2005
	 * Contents: 2000-2005
	 * Both Existing Periods have their contents updated with the contents passed in
	 * 
	 * If the contents overlaps one or more periods, the periods will be split into smaller periods and the contents added to each
	 * Example:
	 * Existing Periods: 2000-2002, 2003-2005
	 * Contents: 2001-2007
	 * New Periods: 2000-2000, 2001-2002, 2003-2005,2006-2007
	 * Where: 
	 * 2000-2000 = old contents
	 * 2001-2002 = old contents and new contents
	 * 2003-2005 = old contents and new contents
	 * 2006-2007 = new contents
	 * 
	 * @param contents
	 * @param period
	 */
	void addContents(T contents, SdmxPeriod period);
	
	/**
	 * Returns a set of all the distinct periods with contents
	 * @return
	 */
	Set<SdmxPeriod> getPeriods();
	
	/**
	 * Returns the contents for the given period
	 * @param period
	 * @return
	 */
	T getContents(SdmxPeriod period);

	/**
	 * Returns a map of SdmxPeriod to the stored contents
	 * @return
	 */
	Map<SdmxPeriod, T> getContents();
	
}
