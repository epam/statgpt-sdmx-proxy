package io.sdmx.api.date;

/**
 * Defines a base period P and the ability to perform date arithmetic on this base period - including adding removing periods, casting to another frequency, moving in another frequency
 */
public interface ITimePeriod {

	/**
	 * @return not null. The base period for this ITimePeriod - this is a fixed point in time for a specific frequency and it is immutable for this ITimePeriod
	 */
	SdmxDate getBasePeriod();
	
	/**
	 * @param expression
	 * @return true if the expression is a valid expression
	 */
	boolean isExpression(String expression);
	
	/**
	 * Executes an expression on the base period to return a new period of time, which may be in a different frequency:
	 * 
	 * <ul>
	 *   <li>A:UK:EMP               - default to current time period</li>
	 *   <li>A:UK:EMP:2009          - fix period 2009</li>
	 *   <li>A:UK:EMP:P             - Period P is this period</li>
	 *   <li>A:UK:EMP:P-1           - Step back 1 Period</li>
	 * </ul>
	 * <p/>
	 * <p><b>Frequency Conversion Function</b></p>
	 * <ul>
	 *   <li>A:UK:EMP:A(P)          - Convert to Annual</li>
	 *   <li>A:UK:EMP:A(P)-1        - Convert to Annual and step back 1 Period</li>
	 *   <li>A:UK:EMP:A(P-1)        - Step back 1 Period, then convert to Annual</li>
	 *   <li>A:UK:EMP:A(P-1)-1      - Step back 1 Period, Convert to Annual step back 1 period</li>
	 * 
	 * @param expression to execute
	 * @return a resolved time period
	 */
	SdmxDate getTimePeriod(String expression);
}
