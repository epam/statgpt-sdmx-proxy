package io.sdmx.api.date;

/**
 * Used to resolve time periods to absolute dates
 */
public enum PERIOD_POSITION {
	START_PERIOD("start"),
	MID_PERIOD("mid"),
	END_PERIOD("end");
	
	private String asString;

	private PERIOD_POSITION(String asString) {
		this.asString = asString;
	}

	public static PERIOD_POSITION fromString(String str) {
		if(str == null) {
			return null;
		}
		for(PERIOD_POSITION pos : PERIOD_POSITION.values()) {
			if(str.startsWith(pos.asString)) {
				return pos;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return asString;
	}
}
