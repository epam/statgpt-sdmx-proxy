package io.sdmx.api.date;

import java.util.HashMap;
import java.util.Map;

/**
 * Defines different time formats supported by SDMX-ML
 * @author Matt Nelson
 *
 */
public enum TIME_FORMAT {
	YEAR_RANGE("An", "Annual Range", 1, 31557600000l),
	YEAR("A", "Annual", 1, 31557600000l), //1000 * 60 * 60 * 24 * 365.25 (Julian year)
	HALF_OF_YEAR("S", "Semi-Annual", 2, 15778800000l), //As above divided by 2
	THIRD_OF_YEAR("T", "Trimesterly", 3, 10519200000l), //As above divided by 3
	QUARTER_OF_YEAR("Q", "Quarterly", 4, 7889400000l),   //As above divided by 3
	MONTH("M", "Monthly", 12, 2629800000l),   //As above divided by 12
	WEEK("W", "Weekly", 52, 604800000),  //1000 * 60 * 60 * 24 * 7
	DATE("D", "Daily", 356, 86400000),  //1000 * 60 * 60 * 24
	HOUR("H", "Hourly", 8766, 3600000), //1000 * 60 * 60
	DATE_TIME("I", "Date Time", 31557600000l, 1);  //1 millisecond

	private static Map<String, TIME_FORMAT> timeFormatMap;

	private String frequencyCode;
	private String readableCode;
	private long periodsPerYear; //Ranging from 1 (least) to Integer.MAX (most)
	private long millisInPeriod;

    // FR- 3882 - if the environment value for "alternate half-year" has been set
    private static boolean alternateHalfYear;
    public static void setUseAlternateHalfYear(boolean val) {
        alternateHalfYear = val;
    }

	private TIME_FORMAT(String frequencyCode, String readableCode, long periodsPerYear, long millisInPeriod) {
		this.frequencyCode = frequencyCode;
		this.readableCode = readableCode;
		this.periodsPerYear = periodsPerYear;
		this.millisInPeriod = millisInPeriod;
	}

	/**
	 * Returns a human readable string representation of this time format
	 * @return
	 */
	public String getReadableCode() {
		return readableCode;
	}

	/**
	 * @return count of periods in a year
	 */
	public long getPeriodsInAYear() {
		return periodsPerYear;
	}

	/**
	 * @return a count of the number of milliseconds in a period
	 */
	public long getMillisInPeriod() {
		return millisInPeriod;
	}

	/**
	 * Returns an Id representation of this TIME_FORMAT:
	 * <ul>
	 *  <li>A = TIME_FORMAT.YEAR</li>
	 *  <li>S = TIME_FORMAT.HALF_OF_YEAR</li>
	 *  <li>T = TIME_FORMAT.THIRD_OF_YEAR</li>
	 *  <li>Q = TIME_FORMAT.QUARTER_OF_YEAR</li>
	 *  <li>M = TIME_FORMAT.MONTH</li>
	 *  <li>W = TIME_FORMAT.WEEK</li>
	 *  <li>D = TIME_FORMAT.DATE</li>
	 *  <li>H = TIME_FORMAT.HOUR</li>
	 *  <li>I = TIME_FORMAT.DATE_TIME</li>
	 * </ul>
	 *
	 * @return
	 */
	public String getFrequencyCodeId() {
        if (this.equals(HALF_OF_YEAR) && alternateHalfYear) {
            return "H";
        }
		return frequencyCode;
	}

	/**
	 * Returns the time format from the code Id (case sensitive) - the code ids are listed in the getFrequencyCodeId() method
	 *
	 * @param codeId
	 * @return
	 * @throws IllegalArgumentException if the code Id does not match any ids
	 * @see getFrequencyCodeId
	 */
	public static TIME_FORMAT getTimeFormatFromCodeId(String codeId) {
		if(timeFormatMap == null) {
			Map<String, TIME_FORMAT> newMap = new HashMap<>();
			for(TIME_FORMAT format : TIME_FORMAT.values()) {
				newMap.put(format.getFrequencyCodeId(), format);
			}
			if (alternateHalfYear) {
				newMap.put("H", TIME_FORMAT.HALF_OF_YEAR);
			}
			timeFormatMap = newMap;
		}
		TIME_FORMAT tf = timeFormatMap.get(codeId);
		if(tf != null) {
			return tf;
		}

		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(TIME_FORMAT currentTimeFormat : TIME_FORMAT.values()) {
			sb.append(concat+currentTimeFormat.getFrequencyCodeId());
			concat = ",";
		}
		throw new IllegalArgumentException("Frequency : " + codeId + " is not supported. Allowed values for frequency are : " +sb.toString());
	}

	/**
	 * Returns whether the specified codeId is a legitimate ID supported by SDMX.
	 * @param codeId the ID to test
	 * @return
	 */
	public static boolean isValidCodeId(String codeId) {
		for(TIME_FORMAT tf : TIME_FORMAT.values()) {
			if (tf.getFrequencyCodeId().equals(codeId)) {
				return true;
			}
		}
		return false;
	}
}
