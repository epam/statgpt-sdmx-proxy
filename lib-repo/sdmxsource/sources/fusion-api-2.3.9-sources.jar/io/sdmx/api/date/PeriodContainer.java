package io.sdmx.api.date;

/**
 * Provides a container for objects of the same type, which belong to the same period,  
 *
 */
public interface PeriodContainer<T> {
	
	/**
	 * Returns the period for which the container is for
	 * @return
	 */
	SdmxPeriod getSdmxPeriod();
	
	/**
	 * Creates a copy for the specified period
	 * @param period
	 * @return
	 */
	PeriodContainer<T> copy(SdmxPeriod period);
	
	/**
	 * Returns the contents of this container
	 * @return
	 */
	PeriodContents<T> getPeriodContents();
	
	/**
	 * Returns the contents of this container
	 * @return
	 */
	T getContents();
	
}
