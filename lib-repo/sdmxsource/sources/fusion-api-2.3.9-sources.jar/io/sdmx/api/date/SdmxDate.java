package io.sdmx.api.date;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * An SDMX date contains a Java Date, and gives access to the String representation
 * and TIME_FORMAT which is used to define the date.
 */
public interface SdmxDate extends Serializable, Comparable<SdmxDate> {

	/**
	 * Returns a copy of the date which can never be null. The Date resolves to the SDMX Period, e.g. if the
	 * SDMX Date is 1970 and isStartPeriod() is true, the date will be Thu Jan 01 1970 00:00:00.000 and
	 * have time of 0 (0 milliseconds since 1970).  If isStartPeriod() is false the Date will resolve to the last period
	 * based on the {@link TIME_FORMAT}, for example if the SDMX Date is 1970-01-01 and the TIME_FORMAT is DAY and isStartPeriod is false,
	 * then the Java Date will resolve to Thu Jan 01 1970 23:59:59.000, the last second of the day. The highest resolution is 1 second,
	 * and the highest frequency is DATE_TIME, meaning an SdmxDate of DATE_TIME 1970-01-01T00:00.00 will be the same regardless of isStartPeriod
	 * being true or false
	 * 
	 * If {@link TIME_FORMAT} is Date
	 * @return
	 */
	Date getDate();
	
	/**
	 * Whilst the getDate resolves to the latest second, the getTimeMillis preserves the original
	 * millisecond information if it was provided on the construction of this SdmxDate
	 * @return
	 */
    long getTimeMillis();

	/**
	 * @return true if the returned Date resolved to the timestamp at the start of the period - i.e. if date is 2001-Q2, the date object would resolve to April 1st 2001
	 */
	boolean isStartPeriod();
	
	/**
	 * Returns the next or previous period for this date, keeping the time format the same as this date
	 * @param increment the number of steps to perform +1 move forward 1 period, -1 move backwards 1 period
	 * @return
	 */
	SdmxDate movePeriod(int increment);


	Calendar getDateAsCalendar();

	/**
	 * Returns the time format for the date - returns null if this information is not present
	 * @return
	 */
	TIME_FORMAT getTimeFormatOfDate();

	/**
	 * Returns the Date in SDMX format
	 */
	String getDateInSdmxFormat();

	/**
	 * Returns true if this date is later then the date provided
	 *
	 * @param date
	 * @return
	 */
	boolean isLater(SdmxDate date);

	/**
	 * Returns true if this date is earlier then the date provided
	 *
	 * @param date
	 * @return
	 */
	boolean isEarlier(SdmxDate date);
}