package io.sdmx.api.date;

/**
 * Contents of a PeriodContainer, which can be copied when a period is split
 * @author Matt Nelson
 *
 */
public interface PeriodContents<T> {

	/**
	 * Returns the contents
	 * @return
	 */
	T getContents();
	
	/**
	 * Returns a copy of the contents
	 * @return
	 */
	PeriodContents<T> copy();
	
	/**
	 * Merges new contents into the existing contents
	 * @param newContents
	 */
	void merge(T newContents);
}
