package io.sdmx.api.date;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * Defines a StartPeriod and EndPeriod, both start period and end period are optional, however an SdmxPeriod must contain at least one or the other (or both).
 *
 * Can be compared by first comparing the start period, and then the end period, where a null start period is seen as earlier then a specified start period, and
 * a null end period is seen as later then a specified end period
 *
 */
public interface SdmxPeriod extends Comparable<SdmxPeriod>, Serializable {

	/**
	 * @return a period string in the syntax <start period>/<end period>, example 2001/2009
	 */
	default String toISOString() {
		if(isAllPeriods()) {
			return "AllPeriods";
		}
		if(hasStartPeriod() && hasEndPeriod()) {
			return getStartPeriod().getDateInSdmxFormat() +"/"+getEndPeriod().getDateInSdmxFormat();
		}
		if(hasStartPeriod()) {
			return getStartPeriod().getDateInSdmxFormat() +"/";
		}
		if(hasEndPeriod()) {
			return "/"+getEndPeriod().getDateInSdmxFormat();
		}
		return "AllPeriods";
	}
	
	/**
	 * Returns how this period compares with the one passed in
	 * @param that the period to compare this period to, a null will result in PERIOD_OVERLAP.NOT_IN_PERIOD
	 * @return PERIOD_OVERLAP is how this period compares with the one passed in, a subset for example means this is a subset of that
	 */
	PERIOD_OVERLAP getOverlap(SdmxPeriod that);
	
	/**
	 * Splits this period up based on the passed in period, to create multiple new periods which together form one continuous period
	 * <p/>
	 * <p>For example if this period is <strong>2010 - 2020</strong></p>
	 * <p>The period passed in is <strong>2008 - 2015</strong></p>
	 * <p>The returned periods are: </p>
	 * <ol>
	 *  <li>2008-2009</li>
	 *  <li>2010-2015</li>
	 *  <li>2016-2020</li>
	 * </ol>
	 * Where the start of period and end of period are applied to the start and end dates respectively
	 * 
	 * <p>If the passed in period is an exact match with this period, that returned contains only this period</p>
	 * <p>If the passed in period does not overlap this period, both this and that periods are returned in the set</p>
	 * <p>If the passed in period is null this period is returned</p>
	 * 
	 * @param that
	 * @return
	 */
	Set<SdmxPeriod> split(SdmxPeriod that);
	
	/**
	 * @return true if this period represents all periods
	 */
	boolean isAllPeriods();
	

	/**
	 * Returns the start of the period, or null if there is no start specified
	 * @return
	 */
	SdmxDate getStartPeriod();

	/**
	 * Returns the end of the period, or null if there is no start specified
	 * @return
	 */
	SdmxDate getEndPeriod();

	/**
	 * Returns true if there is a start period
	 * @return
	 */
	boolean hasStartPeriod();

	/**
	 * Returns true if there is an end period
	 * @return
	 */
	boolean hasEndPeriod();

	/**
	 * Returns true if the given date is before the start period, if there is no start period this is deemed as the at beginning of time
	 * @param date
	 * @return
	 */
	boolean isBeforeStartPeriod(Date date);

	/**
	 * Returns true if the given date is after the end period, if there is no end period this is deemed as the end of time
	 * @param date
	 * @return
	 */
	boolean isAfterEndPeriod(Date date);

	/**
	 * Returns true if the given date is in the specified period
	 * @param date
	 * @return
	 */
	boolean isInPeriod(Date date);

	/**
	 * Returns true if either of the dates lies within this specified period
	 * @param date
	 * @return
	 */
	boolean isInPeriod(Date dateFrom, Date dateTo);

	/**
	 * Returns true if the passed in SdmxPeriod is not null and the dates specified by the SdmxPeriod argument lies inside OR overlaps this specified period
	 * @param period
	 * @return
	 */
	boolean isInPeriod(SdmxPeriod period);
	

	/**
	 * Returns true if the this period has the same start time as the one passed in
	 * @param period
	 * @return
	 */
	boolean isStartEqual(SdmxPeriod period);
	
	/**
	 * Returns true if the this period starts before the passed in period, a null start date is treated as start from the beginning of time
	 * If the two periods share the same start date, this will return false
	 * @param period
	 * @return
	 */
	boolean isBeforePeriod(SdmxPeriod period);
	
	/**
	 * Returns true if the this period has the same end time as the one passed in
	 * @param period
	 * @return
	 */
	boolean isEndEqual(SdmxPeriod period);
	
	/**
	 * Returns true if the this period ends after the passed in period, a null end date is treated as end from the end of time
	 * If the two periods share the same end date, this will return false
	 * @param period
	 * @return
	 */
	boolean isAfterPeriod(SdmxPeriod period);


	/**
	 * Returns true if the passed in SdmxPeriod is not null and the dates specified by the SdmxPeriod argument are FULLY contained within this SdmxPeriod
	 * 
	 * e.g. For an SdmxPeriod of 2000 -, passing in a Period of "2000 - 2060" would result in true.
	 * e.g. For an SdmxPeriod of 2000 - 2010, passing in a Period of "2000 - [nothing]" would result in false.
	 * 
	 * @param period
	 * @return
	 */
	boolean isFullyInPeriod(SdmxPeriod period);

}