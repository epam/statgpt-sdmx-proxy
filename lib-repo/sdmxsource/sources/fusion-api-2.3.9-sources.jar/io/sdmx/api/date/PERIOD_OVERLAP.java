package io.sdmx.api.date;

/**
 * Defines how two period overlap
 * <ul>
 *  <li>NOT_IN_PERIOD - Two periods have no overlap</li>
	<li>EXACT_MATCH - Two periods match start and end date exactly</li>
	<li>SUBSET - One period is fully contained within the other, it is a subset</li>
	<li>SUPERSET - One period fully contains the other, it is a superset</li>
	<li>OVERLAP - The two periods overlap at either at the beginning or the end of the periods, the start and end period are NOT the same</li>
  </ul>
 */
public enum PERIOD_OVERLAP {
	NOT_IN_PERIOD,
	EXACT_MATCH,
	SUBSET,
	SUPERSET,
	OVERLAP
}
