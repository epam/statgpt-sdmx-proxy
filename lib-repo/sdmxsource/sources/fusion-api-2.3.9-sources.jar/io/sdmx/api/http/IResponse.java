package io.sdmx.api.http;

import java.io.OutputStream;

/**
 * decoupled interface for HTTPServletResponse
 */
public interface IResponse {

	/**
	 * @return the response output stream
	 */
	OutputStream getOutputStream();
	
	/**
	 * Set the HTTP response status
	 * @param status
	 */
	void setStatus(int status);
	
	/**
	 * sets the content type of the response
	 * @param contentType
	 */
	void setContentType(String contentType);
	
	/**
	 * Sets the Header value on the response
	 * @param header
	 * @param value
	 */
	void setHeader(String header, String value);
	
	/**
	 * Sets the last updated header in epoch time milliseconds
	 * @param epochTime
	 */
	void setLastUpdated(Long epochTime);
	
	
	void sendError(int responseCode, String message);
}
