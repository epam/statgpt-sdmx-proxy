package io.sdmx.api.http;

import java.util.Map;

import io.sdmx.api.io.ReadableDataLocation;

/**
 * A Request for some information 
 */
public interface Request extends IHttpHeaderAware {

	/**
	 * @return the IP Address of the originalting request
	 */
	String getIP();
	
	/**
	 * Returns a hash of this request, which includes path, and all parameters
	 * @return
	 */
	String getHash();
	
	/**
	 * returns the method used in request
	 * @return
	 */
	HTTP_METHOD getMethod();
	
	
	/**
	 * Returns a stream of data if there was one provided
	 * @return
	 */
	ReadableDataLocation getReadableDataLocation();
	
	/**
	 * Returns the URL path the request came in on
	 * @return
	 */
	String getPath();

	/**
	 * @return not null - the restURL details
	 */
	IRESTURL getRestURL();
	
	
	default boolean hasParameter(String param) {
		return getRestURL().hasParameter(param);
	}
	
	/**
	 * Returns a request parameter value from a parameter name
	 * @param param
	 * @return
	 */
	default String getParameter(String param) {
		return getRestURL().getParameter(param);
	}
	
	/**
	 * Returns a map of all the parameters
	 * @return
	 */
	default Map<String, String> getParameters() {
		return getRestURL().getParameters();
	}

	
	/**
	 * Closes off any resources, deletes readable data location
	 */
	void close();
	
}
