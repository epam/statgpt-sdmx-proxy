package io.sdmx.api.http;

public enum HTTP_STATUS {
	 // --- 1xx Informational ---

    /** {@code 100 Continue} (HTTP/1.1 - RFC 2616) */
    SC_CONTINUE(100),
    /** {@code 101 Switching Protocols} (HTTP/1.1 - RFC 2616)*/
    SC_SWITCHING_PROTOCOLS(101),
    /** {@code 102 Processing} (WebDAV - RFC 2518) */
    SC_PROCESSING(102),

    // --- 2xx Success ---

    /** {@code 200 OK} (HTTP/1.0 - RFC 1945) */
    SC_OK(200),
    /** {@code 201 Created} (HTTP/1.0 - RFC 1945) */
    SC_CREATED(201),
    /** {@code 202 Accepted} (HTTP/1.0 - RFC 1945) */
    SC_ACCEPTED(202),
    /** {@code 203 Non Authoritative Information} (HTTP/1.1 - RFC 2616) */
    SC_NON_AUTHORITATIVE_INFORMATION(203),
    /** {@code 204 No Content} (HTTP/1.0 - RFC 1945) */
    SC_NO_CONTENT(204),
    /** {@code 205 Reset Content} (HTTP/1.1 - RFC 2616) */
    SC_RESET_CONTENT(205),
    /** {@code 206 Partial Content} (HTTP/1.1 - RFC 2616) */
    SC_PARTIAL_CONTENT(206),
    /**
     * {@code 207 Multi-Status} (WebDAV - RFC 2518)
     * or
     * {@code 207 Partial Update OK} (HTTP/1.1 - draft-ietf-http-v11-spec-rev-01?)
     */
    SC_MULTI_STATUS(207),

    // --- 3xx Redirection ---

    /** {@code 300 Mutliple Choices} (HTTP/1.1 - RFC 2616) */
    SC_MULTIPLE_CHOICES(300),
    /** {@code 301 Moved Permanently} (HTTP/1.0 - RFC 1945) */
    SC_MOVED_PERMANENTLY(301),
    /** {@code 302 Moved Temporarily} (Sometimes {@code Found}) (HTTP/1.0 - RFC 1945) */
    SC_MOVED_TEMPORARILY(302),
    /** {@code 303 See Other} (HTTP/1.1 - RFC 2616) */
    SC_SEE_OTHER(303),
    /** {@code 304 Not Modified} (HTTP/1.0 - RFC 1945) */
    SC_NOT_MODIFIED(304),
    /** {@code 305 Use Proxy} (HTTP/1.1 - RFC 2616) */
    SC_USE_PROXY(305),
    /** {@code 307 Temporary Redirect} (HTTP/1.1 - RFC 2616) */
    SC_TEMPORARY_REDIRECT(307),

    // --- 4xx Client Error ---

    /** {@code 400 Bad Request} (HTTP/1.1 - RFC 2616) */
    SC_BAD_REQUEST(400),
    /** {@code 401 Unauthorized} (HTTP/1.0 - RFC 1945) */
    SC_UNAUTHORIZED(401),
    /** {@code 402 Payment Required} (HTTP/1.1 - RFC 2616) */
    SC_PAYMENT_REQUIRED(402),
    /** {@code 403 Forbidden} (HTTP/1.0 - RFC 1945) */
    SC_FORBIDDEN(403),
    /** {@code 404 Not Found} (HTTP/1.0 - RFC 1945) */
    SC_NOT_FOUND(404),
    /** {@code 405 Method Not Allowed} (HTTP/1.1 - RFC 2616) */
    SC_METHOD_NOT_ALLOWED(405),
    /** {@code 406 Not Acceptable} (HTTP/1.1 - RFC 2616) */
    SC_NOT_ACCEPTABLE(406),
    /** {@code 407 Proxy Authentication Required} (HTTP/1.1 - RFC 2616)*/
    SC_PROXY_AUTHENTICATION_REQUIRED(407),
    /** {@code 408 Request Timeout} (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_TIMEOUT(408),
    /** {@code 409 Conflict} (HTTP/1.1 - RFC 2616) */
    SC_CONFLICT(409),
    /** {@code 410 Gone} (HTTP/1.1 - RFC 2616) */
    SC_GONE(410),
    /** {@code 411 Length Required} (HTTP/1.1 - RFC 2616) */
    SC_LENGTH_REQUIRED(411),
    /** {@code 412 Precondition Failed} (HTTP/1.1 - RFC 2616) */
    SC_PRECONDITION_FAILED(412),
    /** {@code 413 Request Entity Too Large} (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_TOO_LONG(413),
    /** {@code 414 Request-URI Too Long} (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_URI_TOO_LONG(414),
    /** {@code 415 Unsupported Media Type} (HTTP/1.1 - RFC 2616) */
    SC_UNSUPPORTED_MEDIA_TYPE(415),
    /** {@code 416 Requested Range Not Satisfiable} (HTTP/1.1 - RFC 2616) */
    SC_REQUESTED_RANGE_NOT_SATISFIABLE(416),
    /** {@code 417 Expectation Failed} (HTTP/1.1 - RFC 2616) */
    SC_EXPECTATION_FAILED(417),

    /**
     * Static constant for a 418 error.
     * {@code 418 Unprocessable Entity} (WebDAV drafts?)
     * or {@code 418 Reauthentication Required} (HTTP/1.1 drafts?)
     */
    // not used
    // SC_UNPROCESSABLE_ENTITY(418),

    /**
     * Static constant for a 419 error.
     * {@code 419 Insufficient Space on Resource}
     * (WebDAV - draft-ietf-webdav-protocol-05?)
     * or {@code 419 Proxy Reauthentication Required}
     * (HTTP/1.1 drafts?)
     */
    SC_INSUFFICIENT_SPACE_ON_RESOURCE(419),
    /**
     * Static constant for a 420 error.
     * {@code 420 Method Failure}
     * (WebDAV - draft-ietf-webdav-protocol-05?)
     */
    SC_METHOD_FAILURE(420),
    /** {@code 422 Unprocessable Entity} (WebDAV - RFC 2518) */
    SC_UNPROCESSABLE_ENTITY(422),
    /** {@code 423 Locked} (WebDAV - RFC 2518) */
    SC_LOCKED(423),
    /** {@code 424 Failed Dependency} (WebDAV - RFC 2518) */
    SC_FAILED_DEPENDENCY(424),

    // --- 5xx Server Error ---

    /** {@code 500 Server Error} (HTTP/1.0 - RFC 1945) */
    SC_INTERNAL_SERVER_ERROR(500),
    /** {@code 501 Not Implemented} (HTTP/1.0 - RFC 1945) */
    SC_NOT_IMPLEMENTED(501),
    /** {@code 502 Bad Gateway} (HTTP/1.0 - RFC 1945) */
    SC_BAD_GATEWAY(502),
    /** {@code 503 Service Unavailable} (HTTP/1.0 - RFC 1945) */
    SC_SERVICE_UNAVAILABLE(503),
    /** {@code 504 Gateway Timeout} (HTTP/1.1 - RFC 2616) */
    SC_GATEWAY_TIMEOUT(504),
    /** {@code 505 HTTP Version Not Supported} (HTTP/1.1 - RFC 2616) */
    SC_HTTP_VERSION_NOT_SUPPORTED(505),

    /** {@code 507 Insufficient Storage} (WebDAV - RFC 2518) */
    SC_INSUFFICIENT_STORAGE(507);
    
    private int httpStatus;

    private HTTP_STATUS(int httpStatus) {
		this.httpStatus = httpStatus;
	}

	public int getHttpStatus() {
		return httpStatus;
	}
	
	public static HTTP_STATUS fromCode(int status) {
		for(HTTP_STATUS currentStatus : HTTP_STATUS.values()) {
			if(currentStatus.httpStatus == status) {
				return currentStatus;
			}
		} 
		return null;
	}
     
}

