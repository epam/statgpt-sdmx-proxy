package io.sdmx.api.http;

public enum MIME_TYPE {
	APPLICATION_JSON("application/json", "json"),
	APPLICATION_YAML("application/yaml", "yaml"),
	APPLICATION_CSV("text/csv", "csv"),
	APPLICATION_XML("text/xml", "xml"),
	EXCEL("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx");
	
	private String mimeType;
	private String fileExtension;

	private MIME_TYPE(String mimeType, String extension) {
		this.mimeType = mimeType;
		this.fileExtension = extension;
	}

	/**
	 * @return HTTP mime type to use
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @return file extension for the mime type, or null if not known
	 */
	public String getFileExtension() {
		return fileExtension;
	}
}
