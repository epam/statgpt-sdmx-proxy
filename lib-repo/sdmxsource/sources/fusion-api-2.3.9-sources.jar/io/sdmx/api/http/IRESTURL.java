package io.sdmx.api.http;

import java.util.List;
import java.util.Map;

/**
 * Encapsulates a part URL to break it in its path parameters, and query parameters
 */
public interface IRESTURL {
		
	/**
	 * @return not null - the original URL - this can be a part URL e.g. /structure/dataflow/OECD?detail=AllStubs
	 */
	String getUrl();
	
	/**
	 * @return not null, immutable map of query parameters, e.g. detail -> AllStubs
	 */
	Map<String, String> getParameters();
	
	/**
	 * @param parameterName case insensitive
	 * @return the value for the query parameter, or null if no query parameter exists with for the parameterName
	 */
	String getParameter(String parameterName);
	
	default boolean hasParameter(String parameter) {
		return getParameter(parameter) != null;
	}
	
	/**
	 * @return not null, immutable list of parth parts, e.g. structure, dataflow, OECD
	 */
	List<String> getPathParts();
}
