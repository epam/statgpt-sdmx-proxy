package io.sdmx.api.http;

import java.util.List;

import org.codehaus.jettison.json.JSONString;

/**
 * CORSBase
 * Provides a base for CORS Settings entries. Each instance is an entry in the CORS Settings keyed by url.
 * @author Lyth
 *
 */
public interface CORSBase extends JSONString
{
	/**
	 * Retrieves the associated URL.
	 * @return
	 */
	String getUrl();

	/**
	 * Retrieves the associated, permitted HTTP Methods.
	 * @return
	 */
	List<String> getMethods();

	/**
	 * Retrieves the associated, permitted HTTP Headers.
	 * @return
	 */
	List <String> getHeaders();

	/**
	 * Retrieves the associated, permitted, exposed HTTP Headers.
	 * @return
	 */
	List <String> getExposedHeaders();

	/**
	 * Retrieves a boolean representing whether this domain is allowed to transmit credentials or not.
	 * @return
	 */
	boolean getAllowCreds();
}
