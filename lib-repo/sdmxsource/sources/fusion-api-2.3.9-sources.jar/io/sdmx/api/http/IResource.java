package io.sdmx.api.http;

/**
 * defines a REST resource
 */
public interface IResource {

	/**
	 * @return the resource as a string, this reflects the string in the URL path swhich is the resource
	 */
	String getResource();
	
}
