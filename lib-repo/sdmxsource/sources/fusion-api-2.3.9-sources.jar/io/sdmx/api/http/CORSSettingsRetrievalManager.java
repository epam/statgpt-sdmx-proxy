package io.sdmx.api.http;

import java.util.List;

import io.sdmx.api.notification.Listener;
/**
 * CORSSettingsRetrievalManager
 * Manager allowing retrieval of CORS Settings, as well as listener registration to listen for changes.
 * @author Lyth
 *
 */
public interface CORSSettingsRetrievalManager 
{
	/**
	 * Retrieve current CORS Settings.
	 * @return
	 */
	List<CORSBase> getCORSSettings();
	
	/**
	 * Called by other objects to be notified via invoke, when the CORS Settings change.
	 * @param listener
	 */
	void registerListener(Listener<List<CORSBase>> listener);
	
}
