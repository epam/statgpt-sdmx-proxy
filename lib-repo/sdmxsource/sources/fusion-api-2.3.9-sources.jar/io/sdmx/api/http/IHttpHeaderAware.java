package io.sdmx.api.http;

import java.util.Map;

/**
 * Provides ability to retrieve HTTP Header parameters
 */
public interface IHttpHeaderAware {

	/**
	 * @return not null, a wrapper around these headers to simplify cache header checks 
	 */
	ICacheHeaders getCacheHeaders();
	
	/**
	 * Returns true if there is a header element with the name, and it is not null and a non empty string
	 * @param header
	 * @return
	 */
	default boolean hasHeader(String header) {
		return getHeader(header) != null;
	}
	
	/**
	 * Returns a header parameter from a header name
	 * @param header
	 * @return
	 */
	default String getHeader(String header) {
		if(header == null) {
			return null;
		}
		return getHeaders().get(header.toLowerCase());
	}
	
	/**
	 * @return immutable, not null map of http headers where the header key is lowercase
	 */
	Map<String, String> getHeaders();
}
