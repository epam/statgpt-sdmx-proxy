package io.sdmx.api.http;

/**
 * Breaks an application/vnd. header into its parts.  
 * <p/>
 * <b>Example:</b><br/>
 * <i>application/vnd.sdmx.genericdata+xml;version=2.1</i>
 * <p/>
 * <b>Becomes:</b><br/>
 * <i>vnd=sdmx.genericdata+xml</i><br/>
 * <i>version=2.1</i>  
 * <p/>
 * Where version is a parameter and 2.1 is the parameter value
 * 
 */
public interface IVNDHeader {

	/**
	 * @return full VND Header example: application/vnd.sdmx.genericdata+xml;version=2.1
	 */
	String getOriginalVND();
	
	/**
	 * @param parameter
	 * @return true if the VND Header contains a value for the parameter, example application/vnd.sdmx.genericdata+xml;version=2.1 would contain true for "version"
	 */
	boolean hasParameter(String parameter);
	
	/**
	 * @param parameter
	 * @return the value for the parameter, example application/vnd.sdmx.genericdata+xml;version=2.1 would return "2.1" for "version"
	 */
	String getParameterValue(String parameter);
	
	/**
	 * @return the stripped down VND, everything after application.vnd. and no 
	 * parmeters included, example application/vnd.sdmx.genericdata+xml;version=2.1 would return "sdmx.genericdata+xml"
	 */
	String getVnd();
	
}
