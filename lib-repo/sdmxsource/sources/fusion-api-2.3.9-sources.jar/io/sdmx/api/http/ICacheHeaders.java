package io.sdmx.api.http;

/**
 * This contains the values for the Cache control headers passed in on an HTTP request.
 * 
 * This might not contain any cache headers, in which case all getters will return null.
 */
public interface ICacheHeaders {

	/**
	 * If this returns a not null value, and the resource which is being requested has a modified timestamp 
	 * which is earlier then this timestamp then an HTTP 304 (not modified) should be on the response header
	 * 
	 * @return nullable, timestamp to check when resource was modified against
	 */
	Long getIfModifiedSince();
	
	/**
	 * @param lastModifed
	 * @return true if there is no modified since header, or the modified since header is prior to the last modified time 
	 */
	boolean isModifiedSince(Long lastModifed);
	
	/**
	 * If this returns a not null value, and the resource which is being requested has a modified timestamp 
	 * after this timestamp return 412 (pre-condition failed)
	 * 
	 * @return nullable, timestamp to check when resource was modified against
	 */
	Long getIfUnmodifiedSince();
	
	/**
	 * If this returns a not null value, and the string matches the checksum of the requested resource, 
	 * return a 304 (not modified) otherwise return resource
	 * 
	 * @return nullable, a checksum of the resource to check the response against
	 */
	String getIfNonMatch();
	
	/**
	 * @param eTag
	 * @return true if the eTag matches the cache control header for If-None-Match
	 */
	default boolean isMatch(String eTag) {
		String nonMatch = getIfNonMatch();
		return nonMatch != null && nonMatch.equals(eTag);
	}
	
	/**
	 * If this returns a not null value, and the string matches the checksum of the requested resource, return the resource
	 * otherwise return 412 (pre-condition failed)
	 * 
	 * @return nullable, a checksum of the resource to check the response against
	 */
	String getIfMatch();
	
	
	
}
