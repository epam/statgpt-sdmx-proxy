package io.sdmx.api.http;

import java.io.Serializable;
import java.util.Locale;

/**
 * Contains information about a client / server call, contains the server and web application details, and the IP from which the client request
 * was generated
 * @author Agent96
 *
 */
public interface ClientRequest extends Serializable {
	
	public static final String API_VERSION = "API_VERSION";
	
	/**
	 * @return the URL of the server that the Registry is running on.
	 */
	String getServerUrl();
	
	/**
	 * @return the URL of the web service example/mypath/subpath
	 */
	String getServletPath();
	
	/**
	 * Returns the server name, port and context concatenated and postfixed onto http, to rebuild the path.  Example http://localhost:8080/MyWebApp
	 * @param includePath if true will also postfix the pathInfo, Example: http://localhost:8080/MyWebApp/mypath/subpath
	 */
	String getRequestPath(boolean includePath);
	
	/**
	 * Returns http / https / ftp
	 * @return
	 */
	String getScheme();
	
	/**
	 * Returns the server port the request was made to, example: 8080
	 * @return
	 */
	int getServerPort();
	
	/**
	 * Returns the server name the request was made to, example: localhost
	 * @return
	 */
	String getServerName();
	
	/**
	 * Returns the server context the request was made to, example: /MyWebApp
	 * @return
	 */
	String getServerContext();
	
	/**
	 * Returns the server path the request was made to following the context, example: /mypath/subpath
	 * @return
	 */
	String getPathInfo();
	
	/**
	 * Returns the server port the request was made to, example: 8080
	 * @return
	 */
	String getClientIP();
	
	/**
	 * Returns the preferred locale for the current request
	 * @return
	 */
	Locale getLocale();
	
}
