package io.sdmx.api.http;

import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;

/**
 * Holds the values expressed in a REST GET URL
 */
public interface IRESTGET extends IHttpHeaderAware {
	
	
	/**
	 * @return the path and parameters in REST GET syntax starting from the web servive entry point
	 * e.g. data/dataflow/ECB/EXR/1.0/all?c[FREQ]=A
	 */
	String toURL(String... removeParams);
	
	/**
	 * @param param - case sensitive
	 * @return the integer value of the parameter or null if there is none
	 * @throws SdmxSemmanticException if the parameter value is not null and not an SdmxDate format
	 */
	SdmxDate getSdmxDateParamValue(String param) throws SdmxSemmanticException;

	/**
	 * @param param - case sensitive
	 * @return the integer value of the parameter or null if there is none
	 * @throws SdmxSemmanticException if the parameter value is not null and not an integer
	 */
	Integer getIntegerParamValue(String param) throws SdmxSemmanticException;
	

	/**
	 * @param param - case sensitive
	 * @return the boolean value of the parameter or null if there is none
	 */
	Boolean getBooleanParamValue(String param);
	

	/**
	 * @param param - case sensitive
	 * @return the integer value of the parameter or null if there is none
	 */
	String getStringParamValue(String param);
	
	/**
	 * @return map of query parameters or an empty map in none exist, all keys lowercase
	 */
	Map<String, String> getQueryParameters();
	
	/**
	 * @return the path, starting from after the entry point to the resource
	 */
	List<String> getPath();
	
	/**
	 * @return the path parameter at the given index, or null if it does not exist
	 */
	String getPathParameter(int idx);
}
