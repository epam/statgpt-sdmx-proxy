package io.sdmx.api.http;

import java.util.HashMap;
import java.util.Map;

public enum HTTP_METHOD {
	GET("GET"),
	DELETE("DELETE"),
	HEAD("HEAD"),
    PUT("PUT"),
    OPTIONS("OPTIONS"),
    TRACE("TRACE"),
    CONNECT("CONNECT"),
    PATCH("PATCH"),
	POST("POST");
	
	
	private String method;
	private static Map<String, HTTP_METHOD> methods;

	private HTTP_METHOD(String method) {
		this.method = method;
	}

	public String getMethod() {
		return method;
	}
	
	public static HTTP_METHOD getMethod(String method) {
	    if(methods == null) {
	        Map<String, HTTP_METHOD> methods = new HashMap<>();
	        for(HTTP_METHOD currentMethod : HTTP_METHOD.values()) {
	            methods.put(currentMethod.getMethod(), currentMethod);
	        }
	        HTTP_METHOD.methods = methods;
	    }
	    return methods.get(method.toUpperCase());
        
    }
}
