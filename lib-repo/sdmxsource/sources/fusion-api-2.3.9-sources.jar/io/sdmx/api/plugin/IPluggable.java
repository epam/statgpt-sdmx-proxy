package io.sdmx.api.plugin;

/**
 *  A marker interface to note that adding new implementations of this Interface and registering them as a singleton will be automatically
 *  picked up and used by the relevent manager class
 */
public interface IPluggable {

}
