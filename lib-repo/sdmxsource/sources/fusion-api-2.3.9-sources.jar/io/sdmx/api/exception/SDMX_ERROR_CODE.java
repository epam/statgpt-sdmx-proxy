package io.sdmx.api.exception;

import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.thread.LocalThreadStore;

/**
 * Contains an enumerated list of the SDMX standard error codes, along with an English representation of the error
 * <p>
 * <h1>Error categories</h1>
	<p>
	The numbering of error messages divides the three types of messages up, and provides for web services to implement custom messages as well:
	</p>
	<ul>
		<li>000-499: Client errors</li>
		<li>500-999: Server errors</li>
		<li>1000 and up: Custom errors</li>
	</ul>
	<hr>
	<h1>Client errors</h1>
	<h2>No results found - 100</h2>
	<p>
	If the result from the query is empty the web service should return this message. This is a way to inform the client that the result is empty.
	</p>
	<h2>Unauthorized - 110</h2>
	
	For use when authentication is needed but has failed or has not yet been provided.
	
	<h2>Syntax error - 140</h2>
	
	This error code is used when the query string doesn't comply with the SDMX RESTful interface.
	
	<h2>Semantic error - 150</h2>
	
	A web service should return this error when a request is syntactically correct but fails a semantic validation or violates agreed business rules.
	
	<hr>
	<h1>Server errors</h1>
	
	<h2>Internal Server Error - 500</h2>
	
	The web service should return this error code when none of the other error codes better describes the reason for the failure of the service to provide a meaningful response.
	
	<h2>Not implemented - 501</h2>
	
	All SDMX web services should implement all the standard interfaces, even if their only function is to return this error message. This eases interoperability between SDMX compliant web services and it also eases the development of generic SDMX web services clients. If the web service has not yet implemented one of the methods defined in the API, then it should return this error.
	
	<h2>Service unavailable - 503</h2>
	
	If a web service is temporarily unavailable because of maintenance or for some other similar reasons, then it should return this error code.
	
	<h2>Response size exceeds service limit - 510</h2>
	
	The request results in a response that is larger than the server is willing or able to process. In case the service offers the possibility to users to download the results of large queries at a later stage (for instance, using asynchronous web services), the web service may choose to indicate the (future) location of the file, as part of the error message.
 *
 */
public enum SDMX_ERROR_CODE {
	NO_RESULTS_FOUND(100, "No Results Found", 404, 204),
	UNAUTHORISED(110, "Unauthorized", 401, 401),
	RESPONSE_TOO_LARGE(130, "Response Too Large", 413, 413),  //Response too large due to client request
	SYNTAX_ERROR(140, "Syntax Error", 400, 400),
	SEMANTIC_ERROR(150, "Semantic Error", 400, 422),
	NOT_MODIFIED(304, "Not Modified", 304, 304),
	NOT_ACCEPTABLE(406, "Not Acceptable", 406, 406),
	INTERNAL_SERVER_ERROR(500, "Internal Server Error", 500, 500),
	NOT_IMPLEMENTED(501, "Not Implemented", 501, 501),
	SERVICE_UNAVAILABLE(503, "Service Unavailable", 503, 503),
	RESPONSE_SIZE_EXCEEDS_SERVICE_LIMIT(510, "Response size exceeds service limit", 413, 413); //Response size exceeds service limit
	
	private Integer clientErrorCode;
	private String errorString;
	private Integer httpRestErrorCodeV1;
	private Integer httpRestErrorCodeV2;
	
	private SDMX_ERROR_CODE(Integer clientErrorCode, String errorString, int httpRestErrorCodeV1, int httpRestErrorCodeV2) {
		this.clientErrorCode = clientErrorCode;
		this.errorString = errorString;
		this.httpRestErrorCodeV1 = httpRestErrorCodeV1;
		this.httpRestErrorCodeV2 = httpRestErrorCodeV2;
	}

	/**
	 * Returns the SDMX error code as an Integer
	 * @return
	 */
	public Integer getClientErrorCode() {
		return clientErrorCode;
	}

	/**
	 * Returns a English representation of the error code
	 * @return
	 */
	public String getErrorString() {
		return errorString;
	}
	
	/**
	 * Returns the HTTP error code used by the REST interface which corresponds to the SDMX error.
	 * The V1 codes are defined in the SDMX Web Services Guidelines:
     * http://sdmx.org/wp-content/uploads/2012/05/SDMX_2_1-SECTION_07_WebServicesGuidelines_May2012.pdf
	 * The V2 codes in:
     * https://github.com/sdmx-twg/sdmx-rest/blob/master/doc/status.md
	 * @return
	 */
	public Integer getHttpRestErrorCode() {
		final String apiVersion = (String) LocalThreadStore.INSTANCE.get().get(ClientRequest.API_VERSION);
		if (apiVersion != null && apiVersion.equals("1")) {
			return httpRestErrorCodeV1;
		}
		return httpRestErrorCodeV2;
	}
	
	public static SDMX_ERROR_CODE parseHttpCode(int code) {
		for(SDMX_ERROR_CODE currentCode : values()) {
			if(currentCode.httpRestErrorCodeV1 == code || currentCode.httpRestErrorCodeV2 == code) {
				return currentCode;
			}
		}
		return null;
	}

	public static SDMX_ERROR_CODE parseClientCode(int code) {
		for(SDMX_ERROR_CODE currentCode : values()) {
			if(currentCode.getClientErrorCode() == code) {
				return currentCode;
			}
		}
		//Try the REST error code (sdmx-json uses 404 not 100)
		for(SDMX_ERROR_CODE currentCode : values()) {
			if(currentCode.getHttpRestErrorCode() == code) {
				return currentCode;
			}
		}
		return null;
	}
}
