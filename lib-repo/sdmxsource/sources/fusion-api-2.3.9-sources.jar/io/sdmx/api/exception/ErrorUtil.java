package io.sdmx.api.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ErrorUtil {
	private static final Logger LOG = LoggerFactory.getLogger(ErrorUtil.class);
	
	
	public static void rethrow(Throwable th) {
		if(th instanceof SdmxException) {
			throw (SdmxException) th;
		}
		if(th instanceof RuntimeException) {
			throw (RuntimeException) th;
		} 
		throw new SdmxException(th, th.getMessage());
	}
	
	/**
	 * Extracts the error message out of the throwable, handles null pointers, throwables with no error message
	 * @param th
	 * @return
	 */
	public static String getErrorMessage(Throwable th) {
		if(th.getMessage() == null) {
			if(th.getCause() != null && th.getCause() != th) {
				return getErrorMessage(th.getCause());
			} else {
				if(th instanceof NullPointerException) {
					LOG.error("Null Pointer", th);
					return "Null Pointer Exception";
				} else {
					return "No Error Message Provided";
				}
			}
		} else {
			return th.getMessage();
		}
	}

	public static int getHTTPStatusCode(Throwable th) {
		Integer statusCode = 500;
		if(th instanceof ISdmxException) {
			statusCode  = ((ISdmxException)th).getHttpRestErrorCode();
		}
		if(statusCode == null) {
			return 500;
		}
		return statusCode;
	}
}
