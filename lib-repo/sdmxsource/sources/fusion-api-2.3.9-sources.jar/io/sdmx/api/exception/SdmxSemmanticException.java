package io.sdmx.api.exception;

public class SdmxSemmanticException extends SdmxException {
	private static final long serialVersionUID = 1L;

	
	public SdmxSemmanticException(Throwable th, String errorMesage) {
		super(th, SDMX_ERROR_CODE.SEMANTIC_ERROR, errorMesage);
	}
	
	public SdmxSemmanticException(Throwable th, ExceptionCode code, Object... args) {
		super(th, SDMX_ERROR_CODE.SEMANTIC_ERROR, code, args);
	}

	public SdmxSemmanticException(ExceptionCode code, Object... args) {
		super(null, SDMX_ERROR_CODE.SEMANTIC_ERROR, code, args);
	}
	
	public SdmxSemmanticException(String str) {
		super(str, SDMX_ERROR_CODE.SEMANTIC_ERROR);
	}
}
