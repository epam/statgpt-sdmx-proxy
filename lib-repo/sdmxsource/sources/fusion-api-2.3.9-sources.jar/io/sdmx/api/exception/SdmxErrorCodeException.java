package io.sdmx.api.exception;

/**
 * Simple exception just to pass error codes
 */
public class SdmxErrorCodeException extends RuntimeException implements ISdmxException {
	private static final long serialVersionUID = 1L;
	private Integer errorCode;
	
	public SdmxErrorCodeException(Integer errorCode) {
		this.errorCode = errorCode;
	}
	
	public SdmxErrorCodeException(Integer errorCode, Throwable th) {
		super(th);
		this.errorCode = errorCode;
	}
	
	
	
	@Override
	public String getMessage() {
		String message = super.getMessage();
		if(message == null) {
			return "Error Code "+errorCode;
		}
		return "Error Code "+errorCode+", Message: "+message;
			
	}

	@Override
	public Integer getHttpRestErrorCode() {
		return this.errorCode;
	}
}
