package io.sdmx.api.exception;

public interface ISdmxException {

	/**
	 * @return an error code representing the error (aligned with the HTTP error codes)
	 */
	Integer getHttpRestErrorCode();
	
}
