package io.sdmx.api.exception;

public class HttpException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private int httpErrorCode;
	private String errorMessage;
	
	public HttpException(String errorMessage, int errorCode) {
		this.errorMessage = errorMessage;
		this.httpErrorCode = errorCode;
	}

	public int getHttpErrorCode() {
		return httpErrorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
}
