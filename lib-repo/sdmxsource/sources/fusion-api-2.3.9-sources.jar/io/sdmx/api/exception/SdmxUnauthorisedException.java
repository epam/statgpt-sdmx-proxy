package io.sdmx.api.exception;

/**
 * Access exception is a specialised form of SdmxException which 
 * has a fixed SDMX Exception type of SDMX_ERROR_CODE.UNAUTHORISED
 */
public class SdmxUnauthorisedException extends SdmxException {
	
	private static final long serialVersionUID = 6333338144646600587L;

	public SdmxUnauthorisedException(String message) {
		super(message, SDMX_ERROR_CODE.UNAUTHORISED);
	}
	
	public SdmxUnauthorisedException(ExceptionCode code, Object... args) {
		super(SDMX_ERROR_CODE.UNAUTHORISED, code, args);
	}

	@Override
	public String getErrorType() {
		return "Security Exception";
	}
}
