package io.sdmx.api.exception;

public class SdmxInternalServerException extends SdmxException {
	private static final long serialVersionUID = 985796365872067924L;

	public SdmxInternalServerException(String str) {
		super(str, SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR);
	}
}
