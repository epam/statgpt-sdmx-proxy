package io.sdmx.api.exception;

public class SdmxNotAcceptableException  extends SdmxException {
	private static final long serialVersionUID = 6830799169917227358L;

	public SdmxNotAcceptableException(String str) {
		super(str, SDMX_ERROR_CODE.NOT_ACCEPTABLE);
	}
	
	public SdmxNotAcceptableException(Object str) {
		super(str.toString(), SDMX_ERROR_CODE.NOT_ACCEPTABLE);
	}

}
