package io.sdmx.api.exception;

import java.io.IOException;
import java.io.InputStream;

public class UnrecognisedFormatException extends SdmxSemmanticException {
	private static final long serialVersionUID = 1L;

	public UnrecognisedFormatException(String errorMessage) {
		super(errorMessage);
	}

	public UnrecognisedFormatException(InputStream is) {
		super(readHeaderOfInputStream(is));
	}

	private static String readHeaderOfInputStream(InputStream is) {
		// Read the first 400 bytes from the Input Stream
		try {
			byte[] b = new byte[400];
			int count = 0;
			while (count < b.length) {
				int n;
				n = is.read(b, count, b.length-count);
				if (n==-1) {
					break;
				}
				count += n;
			}

			// Convert the bytes into a new Throwable object which will be passed to the super-class
			return "Unrecognised file format, contents of file are: "+ new String(b).replaceAll("\u0000", "");
		} catch (IOException e) {
			// There was an error processing the InputStream. Simply return null.
			return null;
		} finally {
			try {
				is.close();
			} catch (IOException e) {
			    // Do nothing
			}
		}
	}
}