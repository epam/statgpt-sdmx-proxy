package io.sdmx.api.exception;

public class SdmxXssViolationException extends SdmxSemmanticException {
	private static final long serialVersionUID = 1L;
	
	public SdmxXssViolationException(Throwable th, String errorMesage) {
		super(th, errorMesage);
	}

	public SdmxXssViolationException(Throwable th, ExceptionCode code, Object... args) {
		super(th, code, args);
	}

	public SdmxXssViolationException(ExceptionCode code, Object... args) {
		super(code, args);
	}

	public SdmxXssViolationException(String str) {
		super(str);
	}

}
