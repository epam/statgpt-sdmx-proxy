package io.sdmx.api.exception;

public class SdmxSyntaxException extends SdmxException {
	private static final long serialVersionUID = 2966382157011760240L;

	/**
	 * Creates Exception from an error String and an Error code
	 * @param str
	 * @param errorCode required
	 */
	public SdmxSyntaxException(ExceptionCode code, Object... args) {
		super(SDMX_ERROR_CODE.SYNTAX_ERROR, code, args);
	}

	public SdmxSyntaxException(String str) {
		super(str, SDMX_ERROR_CODE.SYNTAX_ERROR);
	}

	public SdmxSyntaxException(Throwable th) {
		super(th, SDMX_ERROR_CODE.SYNTAX_ERROR, null);
	}

	public SdmxSyntaxException(Throwable th, String message) {
		super(th, SDMX_ERROR_CODE.SYNTAX_ERROR, message);
	}

	public SdmxSyntaxException(Throwable th, ExceptionCode exceptionCode) {
		super(th, SDMX_ERROR_CODE.SYNTAX_ERROR, exceptionCode);
	}
}
