package io.sdmx.api.exception;

public class SdmxServiceUnavailableException extends SdmxException {
	private static final long serialVersionUID = 7924014513423640091L;

	public SdmxServiceUnavailableException(String str) {
		super(str, SDMX_ERROR_CODE.SERVICE_UNAVAILABLE);
	}

	public SdmxServiceUnavailableException(ExceptionCode code, Object... args) {
		super(SDMX_ERROR_CODE.SERVICE_UNAVAILABLE, code, args);
	}
	
	public SdmxServiceUnavailableException(Throwable th, ExceptionCode code, Object... args) {
		super(th, SDMX_ERROR_CODE.SERVICE_UNAVAILABLE, code, args);
	}
	
}
