package io.sdmx.api.exception;

public class SdmxNoResultsException extends SdmxException {
	private static final long serialVersionUID = -2155600427686504172L;

	public SdmxNoResultsException(String str) {
		super(str, SDMX_ERROR_CODE.NO_RESULTS_FOUND);
	}
	
	public SdmxNoResultsException(ExceptionCode code, Object... args) {
		super(null, SDMX_ERROR_CODE.NO_RESULTS_FOUND, code, args);
	}
}
