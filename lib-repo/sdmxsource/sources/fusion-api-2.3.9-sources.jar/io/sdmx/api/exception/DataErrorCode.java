package io.sdmx.api.exception;

import io.sdmx.api.error.FusionError;

public enum DataErrorCode implements FusionError {

    COMPONENT_NOT_EXIST_IN_DSD          ("201-001", "Component ''{0}'' does not exist in Data Structure"),
    DSD_ATTR_NOT_ATTACHED_TO_DATASET    ("201-002", "Data Structure Definition attribute ''{0}'' is not attached to the dataset, it is attached to the: {1}"),
    DSD_NOT_DEFINE_GROUP_WITH_ID        ("201-003", "Data Structure Definition does not define a Group with id ''{0}''"),
    OBS_NOT_REPORT_TIME_PERIOD          ("201-004", "Observation does not report a TIME_PERIOD"),
    TIME_PERIOD_SYNTAX_ERROR            ("201-005", "Syntax error in reported Time Period: ''{0}''"),
    MEASURE_DIM_NOT_VALID_REPRESENTATION("201-006", "Measure Dimension ''{0}'' is reporting value ''{1}'' which is not a valid representation in referenced Concept Scheme ''{2}''"),
    VALUE_INVALID_FOR_TIME_PERIOD       ("201-007", "The reported value ''{0}'' for ''{1}'' is not valid for time period ''{2}''"),
    // NOTE: Error code '201-008' is special and not defined here!

    OBS_INVALID_DATE_FORMAT             ("201-150", "Invalid Date Format ''{0}''"),
    OBS_INVALID_DATE_TO_EXPECTED        ("201-151", "The Observation Date does not match the expected format for the frequency Dimension: ''{0}''. Expected frequency format: ''{1}''. Observation Date is: ''{2}''."),

    DSD_NO_COMPONENT                    ("201-180", "Component ''{0}'' does not exist in Data Structure"),
    DSD_NO_ATTRIBUTE                    ("201-181", "Data Structure Definition does not define an Attribute with Id ''{0}''"),
    DSD_COMPONENT_NOT_ATTRIBUTE         ("201-182", "Data Structure Definition component ''{0}'' is not an attribute it is a {1}"),
    DSD_ATTRIBUTE_NOT_ON_DATASET        ("201-183", "Data Structure Definition attribute ''{0}'' is not attached to the dataset, it is attached to the: {1}"),
    DSD_NO_GROUP_WITH_ID                ("201-184", "Data Structure Definition does not define a Group with id ''{0}''"),
    DSD_NO_COMPONENT_IN_GROUP           ("201-185", "Data Structure Definition does not define Component ''{0}'' in Group ''{1}''"),
    DSD_MISSING_VALUE_FOR_DIMENSION     ("201-186", "Missing value for Dimension {0}"),
    DSD_ITEM_NOT_EXIST                  ("201-187", "{0}' does not exist in Data Structure"),
    DSD_SERIES_ATTR_NOT_EXIST           ("201-188", "Series Attribute ''{0}'' is not defined by Data Structure: {1}"),
    DSD_OBS_ATTR_NOT_EXIST              ("201-189", "Observation Attribute ''{0}'' is not defined by Data Structure: {1}"),
    DSD_GROUP_ATTR_NOT_EXIST            ("201-190", "Group {0} Attribute ''{1}'' is not defined by Data Structure: {2}"),

    INVALID_REPRESENTATION_IN_REFERENCE               ("201-200", "{0} is reporting value ''{1}'' which is not a valid representation in referenced {2} ''{3}''"),
    REPORTED_VALUE_NOT_EXPECTED_TYPE                  ("201-201", "Reported value ''{0}'' is not of expected type ''{1}''{2}"),
    REPORTED_VALUE_FOR_COMPONENT_NOT_EXPECTED_TYPE    ("201-202", "Reported value ''{0}'' for ''{1}'' is not of expected type ''{2}''"),
    REPORTED_VALUE_NOT_NUMERICAL                      ("201-203", "Reported value ''{0}'' for ''{1}'' is expected to be numerical"),
    REPORTED_VALUE_NOT_MATCH_PATTERN                  ("201-204", "Reported value ''{0}'' for ''{1}'' does not match expected pattern ''{2}''"),
    REPORTED_VALUE_EXCEEDS_MAX_DECIMAL_PLACES         ("201-205", "Reported value ''{0}'' for ''{1}'' exceeds the number of allowed decimal places of {2}"),
    REPORTED_VALUE_SHORTER_THAN_MINIMUM_ALLOWED       ("201-206", "Reported value ''{0}'' for ''{1}'' is shorter than the minimum allowed length of ''{2}''"),
    REPORTED_VALUE_GREATER_THAN_MAXIMUM_ALLOWED       ("201-207", "Reported value ''{0}'' for ''{1}'' is greater than the maximum allowed length of ''{2}''"),
    REPORTED_VALUE_LESS_THAN_SPECIFIED_START_VALUE    ("201-208", "Reported value ''{0}'' for ''{1}'' is less than the specified start value of {2}"),
    REPORTED_VALUE_GREATER_THAN_SPECIFIED_END_VALUE   ("201-209", "Reported value ''{0}'' for ''{1}'' is greater than the specified end value of {2}"),
    REPORTED_VALUE_NOT_FIT_ALLOWED_ITERVALS           ("201-210", "Reported value ''{0}'' for ''{1}'' do not fit the allowed intervals starting from {2} and increasing by {3}"),
    REPORTED_VALUE_LESS_THAN_SPECIFIED_MIN_VALUE      ("201-211", "Reported value ''{0}'' for ''{1}'' is less than the specified min value of {2}"),
    REPORTED_VALUE_GREATER_THAN_SPECIFIED_MAX_VALUE   ("201-212", "Reported value ''{0}'' for ''{1}'' is greater than the specified max value of {2}"),
    REPORTED_VALUE_BEFORE_ALLOWED_START_TIME          ("201-213", "Reported value ''{0}'' for ''{1}'' is before the allowed start time of {2}"),
    REPORTED_VALUE_AFTER_ALLOWED_END_TIME             ("201-214", "Reported value ''{0}'' for ''{1}'' is after the allowed start time of {2}"),
    REPORTED_VALUE_DUPLICATE_LANGUAGE                 ("201-215", "Duplicate language ''{0}'' for TextType"),
    VALUE_INVALUD_WITH_RESPECT_TO_PATTERN             ("201-216", "{0} invalid with respect to allowed string : {1}"),
    REPORTED_VALUES_EXCEEDS_MAX 	                  ("201-217", "{0} reported values for {1} exceeds limit of {2}"),
    REPORTED_VALUES_LESS_THAN_MIN					  ("201-218", "{0} reported value(s) for {1} is fewer then the minimum required of {2}"),
     

    CONSTRAINT_DISALLOWED_VALUE                    ("201-250", "Disallowed {0} Value: {1}={2}"),
    CONSTRAINT_NO_OBS_FOR_DATASET                  ("201-251", "No Observations are allowed for this dataset"),
    CONSTRAINT_NO_SERIES_FOR_DATASET               ("201-252", "No Series are allowed for this dataset"),
    CONSTRAINT_SERIES_CONTAINS_RESTRICTED_VALUES   ("201-253", "Series contains values which have been restricted"),
    CONSTRAINT_GROUP_CONTAINS_RESTRICTED_VALUES    ("201-254", "Group ''{0}'' contains values which have been restricted"),

    EDI_OBS_TOO_LONG                       ("201-300", "Illegal observation value - it exceeds 15 characters. Observation value: {0}"),
    EDI_OBS_INVALID                        ("201-301", "The observation: {0} is invalid."),
    EDI_OBS_FIRST_EMPTY                    ("201-302", "The first observation of the time series {0} is empty. This is not permitted for a time range."),
    EDI_OBS_LAST_EMPTY                     ("201-303", "The last observation of the time series {0} is empty. This is not permitted for a time range."),

    EDI_OBS_STATUS_TOO_LONG                ("201-310", "The length of the OBS_STATUS value is greater than the maximum permitted for an EDI Message, which is 35 characters. Supplied value: {0}"),
    EDI_OBS_STATUS_MISSING                 ("201-311", "No observation attribute 'OBS_STATUS' present on DSD, but the data contains a value for this attribute"),
    EDI_OBS_CONF_TOO_LONG                  ("201-312", "The length of the OBS_CONF value is greater than the maximum permitted for an EDI Message, which is 35 characters. Supplied value: {0}"),
    EDI_OBS_CONF_MISSING                   ("201-313", "No observation attribute 'OBS_CONF' present on DSD, but the data contains a value for this attribute"),
    EDI_OBS_PRE_BREAK_TOO_LONG             ("201-314", "The length of the OBS_PRE_BREAK value is greater than the maximum permitted for an EDI Message, which is 15 characters. Supplied value: {0}"),
    EDI_OBS_PRE_BREAK_MISSING              ("201-315", "No observation attribute 'OBS_PRE_BREAK' present on DSD, but the data contains a value for this attribute"),

    EDI_ERROR_IN_ATTRIBUTE                 ("201-320", "Error processing attribute on line: {0} . Cause: {1}"),

    EDI_DELETE_MSG_OBS_PRESENT             ("201-320", "Observation Value should not be present in a delete message."),
    EDI_DELETE_MSG_OBS_STATUS_PRESENT      ("201-321", "OBS_STATUS should not be present in a delete message."),
    EDI_DELETE_MSG_OBS_CONF_PRESENT        ("201-322", "OBS_CONF should not be present in a delete message."),
    EDI_DELETE_MSG_OBS_PRE_BREAK_PRESENT   ("201-323", "OBS_PRE_BREAK should not be present in a delete message.");


    private String errorCode;
    private String errorMessage;

    private DataErrorCode(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getErrorMessage() {
        return errorMessage;
    }

}
