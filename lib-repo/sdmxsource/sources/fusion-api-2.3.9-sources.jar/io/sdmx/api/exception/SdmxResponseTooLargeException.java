package io.sdmx.api.exception;

public class SdmxResponseTooLargeException extends SdmxException {
	private static final long serialVersionUID = 7173306367897822821L;

	public SdmxResponseTooLargeException(String str) {
		super(str, SDMX_ERROR_CODE.RESPONSE_TOO_LARGE);
	}
}
