package io.sdmx.api.exception;

public class SdmxNotImplementedException extends SdmxException {
	private static final long serialVersionUID = 6830799169917227358L;

	public SdmxNotImplementedException(String str) {
		super(str, SDMX_ERROR_CODE.NOT_IMPLEMENTED);
	}
	
	public SdmxNotImplementedException(ExceptionCode code, Object... args) {
		this(null, code, args);
	}
	
	public SdmxNotImplementedException(Object... args) {
		this(null,ExceptionCode.UNSUPPORTED, args);
	}
	
	public SdmxNotImplementedException(Throwable th) {
		this(th, null);
	}
	
	public SdmxNotImplementedException(Throwable e, ExceptionCode code, Object... args) {
		super(e, SDMX_ERROR_CODE.NOT_IMPLEMENTED, code, args);
	}
	
	@Override
	public String getErrorType() {
		return "Not Implemented Exception";
	}
}
