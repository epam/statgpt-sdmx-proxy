package io.sdmx.api.exception;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import io.sdmx.api.lang.MessageResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Abstract class to be sub-classed by all custom Exceptions in the system.
 * <p/>
 * If the exceptions are multi-lingual, this class provides the means
 * for retrieving exception messages in different languages.
 * <p/>
 * The Exceptions that sub-class this are all Checked Exceptions
 */
public class SdmxException extends RuntimeException implements ISdmxException {
    private static final Logger LOG = LoggerFactory.getLogger(SdmxException.class);
    private static final String DISABLE_EXCEPTIONS = "DISABLE_EXCEPTIONS";

	private static final long serialVersionUID = 7230038232116051945L;
	private static MessageResolver messageResolver = null;
	private ExceptionCode code;
	private String codeStr;
	private Object[] args;
	private final Throwable th;
	private SDMX_ERROR_CODE errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
	

	private static final LocalObjectStore localObjectStore = new LocalObjectStore();

	private static class LocalObjectStore extends ThreadLocal<Map<Object, Object>> {
		@Override
		public Map<Object, Object> initialValue() {
		    return new HashMap<>();
		}
    }
	
	public static boolean isDisabledExceptionTrace() {
		return localObjectStore.get().containsKey(DISABLE_EXCEPTIONS);
	}

	public static void disableExceptionTrace(boolean bool) {
		//Disable on local
		if(LOG.isDebugEnabled()) {
			LOG.debug("disableExceptionTrace="+bool);
		}
		if(bool) {
			localObjectStore.get().put(DISABLE_EXCEPTIONS, true);
		} else {
			localObjectStore.get().remove(DISABLE_EXCEPTIONS);
		}
	}

	private void displayExceptionTrace() {
		if (!isDisabledExceptionTrace() && !(this instanceof SdmxNoResultsException)) {
			LOG.error(this.getMessage(), this);
		}
	}

	@Override
	public void printStackTrace() {
		if (!localObjectStore.get().containsKey(DISABLE_EXCEPTIONS) && !(this instanceof SdmxNoResultsException)) {
			super.printStackTrace();
		} else if(LOG.isDebugEnabled()) {
			LOG.debug(this.getFullMessage());
		}
	}

	/**
	 * Creates Exception from an error string
	 * @param errorMessage
	 */
	public SdmxException(String errorMessage) {
		this(null, null, errorMessage);
	}
	
	/**
	 * Creates Exception from an ExceptionCode
	 * @param code required
	 */
	public SdmxException(ExceptionCode code) {
		this(SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR, code);
	}

	/**
	 * Creates Exception from an error String and an Error code
	 * @param errorMessage
	 * @param errorCode required
	 */
	public SdmxException(String errorMessage, SDMX_ERROR_CODE errorCode) {
		this(null, errorCode, errorMessage);
	}

	/**
	 * Creates an exception from a Throwable, if the Throwable is a SdmxException - then the
	 * error code will be used, if it is not, then InternalServerError will be used
	 * @param th
	 * @param str
	 */
	public SdmxException(Throwable th, String str) {
		this(th, null, str);
	}

	/**
	 * Creates Exception from an error String and an Error code
	 * @param th
	 * @param errorCode required
	 * @param message
	 */
	public SdmxException(Throwable th, SDMX_ERROR_CODE errorCode, String message) {
		super(message, th);
		this.th = th;
		if(errorCode != null) {
			this.errorCode = errorCode;
		}
		if(th != null && errorCode == null) {
			if(th instanceof SdmxException) {
				this.errorCode = ((SdmxException) th).getSdmxErrorCode();
			}
		}
		displayExceptionTrace();
	}

	public SdmxException(Throwable th, ExceptionCode code, Object... args) {
		this(th, null, code, args);
	}

	/**
	 * Creates Exception from an error String and an Error code
	 * @param str
	 * @param errorCode required
	 */
	public SdmxException(SDMX_ERROR_CODE errorCode, ExceptionCode code, Object... args) {
		this(null, errorCode, code, args);
	}

	/**
	 * Creates Exception from an error String and an Error code
	 * @param str
	 * @param errorCode required
	 */
	public SdmxException(Throwable th, SDMX_ERROR_CODE errorCode, ExceptionCode code, Object... args) {
		super(th);
		this.th = th;
		this.errorCode = errorCode;
		this.args = args;
		if(th != null &&  errorCode == null) {
			if(th instanceof SdmxException) {
				this.errorCode = ((SdmxException) th).getSdmxErrorCode();
			}
		}
		if(code != null) {
			this.code = code;
			this.codeStr = code.getCode();
		}
		displayExceptionTrace();
	}

	public SDMX_ERROR_CODE getSdmxErrorCode() {
		if(errorCode == null) {
			return SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
		}
		return errorCode;
	}

	@Override
	public Integer getHttpRestErrorCode() {
		if(errorCode == null) {
			return null;
		}
		return errorCode.getHttpRestErrorCode();
	}

	@Override
	public String getMessage() {
		if(codeStr == null) {
			return super.getMessage();
		}
		return getMessage(th, codeStr, args);
	}

	public String getFullMessage() {
		if(codeStr == null) {
			StringBuilder sb = new StringBuilder();
			sb.append(super.getMessage());
			if(this.getCause() != null) {
				sb.append("  - caused by "+ System.lineSeparator());
				if(this.getCause() instanceof SdmxException) {
					sb.append(((SdmxException)this.getCause()).getFullMessage());
				} else {
					sb.append(this.getCause().getMessage());
				}
			}
			return sb.toString();
		}
		return getFullMessage(th, codeStr, args);
	}

	public String getMessage(Locale loc) {
		return getMessage(th, codeStr, args, loc);
	}

	public ExceptionCode getCode() {
		if(code == null && th != null && th instanceof SdmxException) {
			return ((SdmxException)th).getCode();
		}
		return code;
	}


	public String getMessage(Throwable th, String code, Object[] args) {
		String nestedMessage = "";
//		if(th != null) {
//			nestedMessage = "Nested Message : " + th.getMessage();
//		}
		if(code == null) {
			return nestedMessage;
		}
//		if(ObjectUtil.validString(nestedMessage)) {
//			return resolveMessage(code, args) + "\n\n" + nestedMessage;
//		}
		return resolveMessage(code, args);
	}

	public String getFullMessage(Throwable th, String code, Object[] args) {
		String nestedMessage = "";
		if(th != null) {
			if(th instanceof SdmxException) {
				SdmxException ex = (SdmxException)th;
				nestedMessage = "Nested Message : " + ex.getFullMessage();
			} else {
				nestedMessage = "Nested Message : " + th.getMessage();
			}

		}
		if(code == null) {
			return nestedMessage;
		}
		if(nestedMessage.length() > 0) {
			return resolveMessage(code, args) + "\n\n" + nestedMessage;
		}
		return resolveMessage(code, args);
	}

	public String getMessage(Throwable th, String code, Object[] args, Locale loc) {
		String nestedMessage = "";
		if(th != null) {
			if(th instanceof SdmxException) {
				nestedMessage = ((SdmxException)th).getMessage(loc);
			} else {
			    nestedMessage = th.getMessage();
			}
		}
		if(code == null) {
			return nestedMessage;
		}
		if(nestedMessage != null && nestedMessage.length() > 0) {
			return resolveMessage(code, args, loc) + "\n\n" + nestedMessage;
		}
		return resolveMessage(code, args, loc);
	}

	public String resolveMessage(String code, Object[] args) {
		if(messageResolver == null) {
			return code;
		}
		StringBuilder sb = new StringBuilder();
		// Try preferred locale first
		Locale myLoc = null;
		String message;

		myLoc = Locale.ENGLISH;

		sb.append(myLoc);
		sb.append("\n\n");
		message = messageResolver.resolveMessage(code, myLoc, args);
		if(message != null && message.length() > 0) {
			return message;
		}

		return "Exception message could not be resolved for code : " + code + " the following locales were checked: " + sb.toString();
	}

	public String resolveMessage(String code, Object[] args, Locale loc) {
		if(messageResolver == null) {
			return code;
		}
		String message = messageResolver.resolveMessage(code, loc, args);
		if(message != null && message.length() > 0) {
			return message;
		}
		return "Exception message could not be resolved for code : " + code + " for the following locale " + loc;
	}

	public String getErrorType() {
		return "Sdmx Exception";
	}

	public static void setMessageResolver(MessageResolver messageResolver) {
		SdmxException.messageResolver = messageResolver;
	}
}

