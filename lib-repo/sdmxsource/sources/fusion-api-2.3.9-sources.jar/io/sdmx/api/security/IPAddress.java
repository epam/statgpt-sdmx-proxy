package io.sdmx.api.security;

import java.io.Serializable;

/**
 * Specifies a full or wildcarded ip address, or a IP range
 */
public interface IPAddress extends Serializable {

	/**
	 * Returns true if this is specifying a range
	 * @return
	 */
	boolean isRange();
	
	/**
	 * Returns the IP address from.  This will always return an Array.
	 * 
	 * each period separator in the IP address has its contents stored
	 * in a separate array index.  Example 192.145.132.12 would be new Integer[] {192, 168, 132, 12}
	 * <p/>
	 * Zero represents a wildcard.
	 * 
	 * @return
	 */
	Integer[] getIpAddressFrom();
	
	/**
	 * Returns the getIpAddressFrom as a String with '.' separators.
	 * @return
	 */
	String getIpAddressFromAsString();
	
	/**
	 * 
	 * Returns the IP address from.  This will be null if isRange() is false, otherwise it will return an Array
	 * 
	 * Each period seperator in the IP address has its contents stored
	 * in a separate array index.  Example 192.145.132.12 would be new Integer[] {192, 168, 132, 12}
	 * <p/>
	 * Zero represents a wildcard
	 * 
	 * @return
	 */
	Integer[] getIpAddressTo();
	
	/**
	 * Returns the getIpAddressTo as a String with '.' separators.
	 * @return
	 */
	String getIpAddressToAsString();
	
	/**
	 * Returns true if the IP address is a match, or falls within the allowed range
	 * @param IPAddress
	 * @return
	 */
	boolean isMatch(String IPAddress);
	
}
