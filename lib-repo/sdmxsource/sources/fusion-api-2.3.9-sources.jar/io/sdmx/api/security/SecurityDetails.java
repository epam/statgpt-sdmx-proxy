package io.sdmx.api.security;

import java.util.Set;

/**
 * Extends the Spring Framework UserDetails object by adding a Salt and IPAddresses
 */
public interface SecurityDetails {
	/**
	 * Returns the password used to authenticate the user.
	 *
	 * @return the password
	 */
	String getPassword();

	/**
	 * Returns the username used to authenticate the user. Cannot return <code>null</code>.
	 *
	 * @return the username (never <code>null</code>)
	 */
	String getUsername();

	/**
	 * Returns true if this user is the root user
	 * @return
	 */
	boolean isRootUser();
	
	/**
	 * Returns true if this user is an admin user
	 * @return
	 */
	boolean isAdmin();
	
	/**
	 * Returns the user's name  (not null)
	 * @return
	 */
	String getName();
	
	/**
	 * Returns the user's email address (not null)
	 * @return
	 */
	String getEmail();
	
	/**
	 * Returns a list of allowed IP addresses.
	 * 
	 * Returns an empty list if all IPs are allowed.
	 * @return
	 */
	Set<IPAddress> getAllowedIPs();
	
	/**
	 * @return set of roles
	 */
	Set<String> getRoles();
}
