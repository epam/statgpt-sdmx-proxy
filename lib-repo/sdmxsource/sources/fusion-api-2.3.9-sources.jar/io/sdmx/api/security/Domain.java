package io.sdmx.api.security;

public interface Domain {
	String getAlias();
	
	String getUri();
}