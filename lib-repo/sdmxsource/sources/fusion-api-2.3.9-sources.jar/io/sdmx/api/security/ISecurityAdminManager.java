package io.sdmx.api.security;

/**
 * A manager that is responsible for administration of one or more functions that require authorisation
 */
public interface ISecurityAdminManager {

	/**
	 * @return the administrative function that this manager provides CRUD operations for, enabling users to be assigned the 
	 * authority to manage this function independently
	 */
	ISecurityAdminFunction getAdminFunction();
}
