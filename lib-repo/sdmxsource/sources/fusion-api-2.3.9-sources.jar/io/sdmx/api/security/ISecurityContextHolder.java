package io.sdmx.api.security;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.process.IProcess;

public interface ISecurityContextHolder {
	
	/**
	 * The returned value will be sanitised so any characters that are not A-Z,a-z,0-9,* @ _ $   are replaced by underscores
	 * @return
	 */
	default public String getSanitisedUserName() {
		SecurityDetails sd = getSecurityDetails();
		if(sd == null) {
			return null;
		}
		String retValue = sd.getUsername();
		if(retValue == null) {
			return null;
		}
		retValue = retValue.replaceAll("[^\\w\\*@_\\$]", "_");
		return retValue;
	}
	
	default Set<String> getCurrentUserGroups() {
		SecurityDetails sd = getSecurityDetails();
		if(sd == null) {
			return Collections.emptySet();
		}
		return sd.getRoles();
	}

	/**
	 * @return security details for currently authenticated user, or null if no user is authenticated
	 */
	SecurityDetails getSecurityDetails();
	
	default boolean hasCurrentUser() {
		return getSecurityDetails() != null;
	}
	
	boolean isAuthenticated();
	
	/**
	 * A SecureThread enables a process to run in a new thread with security details copied to the new thread.
	 * 
	 * @param copyThreadLocal if true the content of thread local will also be copied
	 * @return secure thread which can be started with a process
	 */
	ISecureThread createSecureThread(boolean copyThreadLocal);
	
	/**
	 * Runs a process as a root user
	 * @param process
	 */
	void runAsRoot(IProcess process);
	
	/**
	 * runs the process as the given user - stores the current user so it can reset it back at the end of the process
	 * @param sd
	 * @param process
	 */
	void runAsUser(SecurityDetails sd, IProcess process);
	
}
