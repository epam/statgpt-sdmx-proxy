package io.sdmx.api.security;

public interface ISecurityDetailsFromPrincipleBuilder {

	/**
	 * Converts a Principle to a SecurityDetails implementation
	 * @param principle
	 * @return
	 */
	SecurityDetails convertToSecurityDetails(Object principle);
	
}
