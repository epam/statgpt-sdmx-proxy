package io.sdmx.api.security;

import java.util.Set;

/**
 * Describes an admin function which can be independantly secured 
 */
public interface ISecurityAdminFunction {

	/**
	 * @return unique identification of the function
	 */
	String getId();
	
	/**
	 * @return human readable name for UI
	 */
	String getName();

	/**
	 * @return human readable description for UI
	 */
	String getDescription();
	
	/**
	 * @return any parent functions that this security admin function extends
	 */
	Set<String> parentFunctionIds();
}
