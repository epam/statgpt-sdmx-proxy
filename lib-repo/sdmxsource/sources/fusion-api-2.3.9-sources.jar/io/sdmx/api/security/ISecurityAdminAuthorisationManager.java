package io.sdmx.api.security;

import io.sdmx.api.exception.SdmxUnauthorisedException;

/**
 * Authorises a user to perform an admin function
 */
public interface ISecurityAdminAuthorisationManager {

	/**
	 * @param adminFunction
	 * @return true if the user has the authority for the given admin function
	 */
	default boolean isAuthorised(ISecurityAdminFunction adminFunction) {
		if(adminFunction == null) {
			throw new IllegalArgumentException("Admin Function required");
		}
		return isAuthorised(adminFunction.getId());
	}

	/**
	 * @param adminFunction
	 * @return true if the user has the authority for the given admin function
	 */
	boolean isAuthorised(String adminFunctionId);
	
	/**
	 * @param adminFunctionId - the identity of the admin function
	 * @throws SdmxUnauthorisedException if the current user is not authorised to submit the registration
	 */
	default void authorise(String adminFunctionId) throws SdmxUnauthorisedException {
		if(!isAuthorised(adminFunctionId)) {
			throw new SdmxUnauthorisedException("unauthorised");
		}
	}
	
	/**
	 * @param adminFunction
	 * @throws SdmxUnauthorisedException if the current user is not authorised to submit the registration
	 */
	default void authorise(ISecurityAdminFunction adminFunction) throws SdmxUnauthorisedException {
		if(adminFunction == null) {
			throw new IllegalArgumentException("Admin Function required");
		}
		authorise(adminFunction.getId());
	}
}
