package io.sdmx.api.security;

import io.sdmx.api.process.IProcess;

/**
 * Thread which has copied across user's security details
 */
public interface ISecureThread extends Runnable {

	/**
	 * runs the process in this new thread
	 * @param process
	 */
	 void runProcess(IProcess process);
	
}
