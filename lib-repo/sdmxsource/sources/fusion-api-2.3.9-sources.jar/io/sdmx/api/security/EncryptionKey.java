package io.sdmx.api.security;

import java.math.BigInteger;

/**
 * Contains the modulus and exponent used to encrypt/decrypt public/private key encryption
 */
public interface EncryptionKey {

	/**
	 * Returns the modulus, cannot be null
	 * @return
	 */
	BigInteger getModulus();

	/**
	 * Returns the exponent, cannot be null
	 * @return
	 */
	BigInteger getExponent();
	
	
}
