package io.sdmx.api.security;

import java.util.List;

/**
 * Retrieve all security admin managers from the system
 */
public interface ISecurityAdminFunctionRetreivalManager {

	
	void registerAdminFunction(ISecurityAdminFunction function);
	
	List<ISecurityAdminFunction> getAdminFunctions();
}
