package io.sdmx.api.security;

/**
 * One half of the public/private key used to encrypt data.  The embargoKey contains
 * the public key, and a UID that can be used to retrieve the private key
 */
public interface EmbargoKey {
	
	/**
	 * A unique identifier that can be used to retrieve the private key
	 * @return
	 */
	String getUid();
	
	/**
	 * The public key that can be used to encrypt data
	 * @return
	 */
	EncryptionKey getPublicKey();
	
}
