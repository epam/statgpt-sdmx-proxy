package io.sdmx.api.settings;

import java.util.Properties;

public interface PropertiesAwareManager {
	/**
	 * Analyses the Properties file to extract any properties relevant to configure this manager
	 * @param props
	 */
    void analyseProperties(Properties props);
    
}
