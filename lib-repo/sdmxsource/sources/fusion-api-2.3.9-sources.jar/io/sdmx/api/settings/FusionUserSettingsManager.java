package io.sdmx.api.settings;

import java.util.Map;

public interface FusionUserSettingsManager {

	/**
	 * Saves the setting for the current user
	 * @param settingName
	 * @param settingValue
	 */
	void storeSetting(String settingName, String settingValue);
	
	/**
	 * Removes the setting for the current user
	 * @param settingName
	 * @param settingValue
	 */
	void removeSetting(String settingName);
	
	/**
	 * Returns the setting value for the current user
	 * @param settingName
	 * @return
	 */
	String getSetting(String settingName);
	
	
	/**
	 * Returns all the settings for the currently authenticated user 
	 * @return
	 */
	Map<String, String> getSettings();
	
}
