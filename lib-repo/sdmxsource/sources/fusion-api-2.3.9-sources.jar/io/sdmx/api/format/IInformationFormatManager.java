package io.sdmx.api.format;

import java.util.Collection;
import java.util.Map;

import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;

/**
 * Used to retrieve the InformationFormat for a request
 */
public interface IInformationFormatManager {
	
	/**
	 * adds a default format for the given InformationFormat
	 * @param claz
	 * @param format
	 */
	<T extends InformationFormat> void addDefaultFormat(Class<T> claz, InformationFormat format);
	
	/**
	 * @param <T>
	 * @param request
	 * @param classType
	 * @return the format being requested of the given type
	 */
	default <T extends InformationFormat> T getFormat(Request request, Class<T> classType) {
		return getFormat(request, classType, true);
	}
	
	/**
	 * @param <T>
	 * @param request the Request to determine the format from
	 * @param classType
	 * @param includeDefaultFormats whether any of the Default Formats that are have been set in this class should be used when determining the output format. 
	 * @return the format being requested of the given type. May return null.
	 */
	<T extends InformationFormat> T getFormat(Request request, Class<T> classType, boolean includeDefaultFormats);
	
	/**
	 * @param vndHeader
	 * @return the format being requested or null if the factory is unable to determine the format
	 */
	<T extends InformationFormat> T getFormat(Request request, IVNDHeader vndHeader, Class<T> classType);
	
	/**
	 * @param classType the InformationFormat to return the map for
	 * @return immutable map of VND header to Format
	 */
	<T extends InformationFormat> Map<String, FormatDetails> getSupportedFormats(Class<T> classType);
	
	/**
	 * @param <T>
	 * @param ofType
	 * @return a collection of sorted factories for the given InformationFormat type
	 */
	<T extends InformationFormat> Collection<IFormatFactory<T>> getFormatFactories(Class<T> ofType);
	
}
