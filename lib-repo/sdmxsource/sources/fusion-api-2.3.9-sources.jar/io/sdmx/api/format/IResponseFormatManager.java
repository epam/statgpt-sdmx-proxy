package io.sdmx.api.format;

import io.sdmx.api.http.IResource;
import io.sdmx.api.http.Request;

/**
 *  responsible for obtaining the response format for the request
 */
public interface IResponseFormatManager {

	
	/**
	 * @param request
	 * @param resource
	 * @return the response format for the request
	 */
	InformationFormat getInformationFormat(Request request, IResource resource);
	
}
