package io.sdmx.api.format;

public interface FormatDetails {
	
	/**
	 * Returns a string representation of the format, that can be used for auditing and debugging purposes.
	 * <p/>
	 * This is expected to return a not null response.
	 * @return
	 */
	String getFormatAsString();

	/**
	 * Returns the file extension used for this data format, for example
	 * if the data format is an SDMX-ML format, this will return the String "xml"
	 * @return
	 */
	String getFileExtension();
	
	/**
	 * Returns the mime type to set on an HTTP Header
	 * @return
	 */
	String getMimeType();
	
	/**
	 * Returns all the HTTP Accept Headers that can be used to describe this format
	 * @return
	 */
	String[] getAcceptHeaders();
	
	/**
	 * Returns true if this response format varies when the Accept-Language HTTP header changes
	 * @return
	 */
	boolean isVaryWithAcceptLanguage();
	
	/**
	 * Returns true if this file format should always be saved rather than attempted to be displayed in the browser
	 * @return
	 */
	boolean isSaveOnly();
}
