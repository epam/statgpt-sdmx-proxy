package io.sdmx.api.format;

import io.sdmx.api.http.IResource;
import io.sdmx.api.http.Request;
import io.sdmx.api.plugin.IPluggable;

/** 
 * A plugin engine to support response format of web services, to be used by the IResponseFormatManager
 */
public interface IResponseFormatFactory extends IPluggable {

	/**
	 * @param request
	 * @param resource
	 * @return the response format for the request if this engine supports the request path
	 */
	InformationFormat getInformationFormat(Request request, IResource resource);
	
	/**
	 * Sets a default format to use on this factory
	 * @param resource the rest resource, i.e 'data', 'structure', 'metadata'
	 * @param vndHeader a string representation of the format e.g. 'application/vnd.sdmx+json'
	 * @throws IllegalArgumentException if the resource of vndHeader are not known
	 */
	void setDefaultFormat(String resource, String vndHeader) throws IllegalArgumentException;
	
	/**
	 * @return default response format for the resource, null if the resource is not supported
	 */
	String getDefaultFormat(String resource);
}
