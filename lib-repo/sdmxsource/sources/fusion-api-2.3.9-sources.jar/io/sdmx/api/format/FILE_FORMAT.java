package io.sdmx.api.format;

/**
 * Describes various file (or stream) formats
 */
public enum FILE_FORMAT {
	BINARY("bin"),
	EDI("edi"),
	XML("xml"),
	CSV("csv"),
	XLSX("xlsx"),
	HTML("html"),
	TEXT("txt"),
	JSON("json"),
	ZIP("zip"),
	GZIP("gzip"),
	MULTIPART("multipart"),
	MIXED("mixed"),
	EMPTY("empty");

	private String extension;

	private FILE_FORMAT(String extension) {
		this.extension = extension;
	}

	public static FILE_FORMAT getFormat(String extension) {
		for(FILE_FORMAT format : FILE_FORMAT.values()) {
			if(format.getExtension().equals(extension)) {
				return format;
			}
			if(format.getExtension().equalsIgnoreCase(extension)) {
				return format;
			}
		}
		return null;
	}

	public String getExtension() {
		return extension;
	}

}
