package io.sdmx.api.format;

import java.io.Serializable;

public interface InformationFormat extends Serializable {

	
	FormatDetails getFormatDetails();
		
}
