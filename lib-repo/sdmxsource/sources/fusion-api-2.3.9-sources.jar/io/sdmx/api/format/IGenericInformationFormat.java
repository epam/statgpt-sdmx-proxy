package io.sdmx.api.format;

/**
 * Used to describe generic format types such as XLSX, CSV, JSON without being more specific
 */
public interface IGenericInformationFormat extends InformationFormat {

}
