package io.sdmx.api.format;

import java.util.Map;

import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.plugin.IPluggable;

/**
 * Implementations of this factory are able to return the format definitions for formats that they know about
 * based on the Request or vnd header
 * 
 * @param <T>
 */
public interface IFormatFactory<T extends InformationFormat> extends Comparable<IFormatFactory<T>>, IPluggable {
	
	/**
	 * @return a definition of the class that this factory returns
	 */
	Class<T> getFormatClass();
	
	/**
	 * @return VND Header to Format, supported by this factory
	 */
	Map<String, FormatDetails> getSupportedFormats();
	
	
	/**
	 * Analyses the Request details to determine what format is being requested.  
	 * 
	 * For example the request may contain query parameters which specify format
	 * 
	 * @param format - if the request has a format parameter
	 * @param request 
	 * @return the format that is being requested or null if this factory is unable to determine the format
	 */
	T getFormat(String format, Request request);
	
	/**
	 * @param vndHeader
	 * @return the format being requested or null if hte factory is unable to determine the format
	 */
	T getFormat(Request request, IVNDHeader vndHeader);
	
	/**
	 * @return priority of factory, a higher number lowers the priority
	 */
	default int getPriority() {
		return 1;
	}
	
	@Override
	default int compareTo(IFormatFactory<T> that) {
		Integer priority_this = getPriority();
		Integer priority_that = that.getPriority();
		int compare = priority_this - priority_that;
		if(compare != 0) {
			return compare;
		}
		return this.getClass().getCanonicalName().compareTo(that.getClass().getCanonicalName());
	}
}
