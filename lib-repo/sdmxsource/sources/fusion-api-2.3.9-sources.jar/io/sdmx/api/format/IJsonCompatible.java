package io.sdmx.api.format;

import org.codehaus.jettison.json.JSONObject;

/**
 * This object is able to write itself out as JSON, implementations are strongly advised to also contain 
 * a constructor taking a {@link JSONObject} in order to build itself in the same way that it writes itself 
 */
public interface IJsonCompatible {

	/**
	 * @return this object in JSON representation
	 */
	JSONObject getJson();
	
}
