package io.sdmx.api.email;

import java.io.File;

/**
 * Responsible for sending emails via a main email server, if configured
 */
public interface IEmailEngine {
	
	/**
	 * Returns true if the SMTP server and port has been set
	 * @return
	 */
	boolean isMailServerConfigured();

	/**
	 * Sends an email with a subject and body to the recipient list
	 * @param subject
	 * @param message
	 * @param recipients
	 */
	default void postMail(String subject, String message, String... recipients) { 
		postMail(subject, message, null, recipients);
	}

	/**
	 * Sends an email with subject, body, and attachement to the recipient list
	 * @param subject
	 * @param message
	 * @param attach
	 * @param recipients
	 */
	void postMail(String subject, String message, File attach, String... recipients);

}
