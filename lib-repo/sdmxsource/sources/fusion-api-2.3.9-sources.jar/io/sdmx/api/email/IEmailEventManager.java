package io.sdmx.api.email;

import java.io.File;

/**
 * A generic API to retrieve email addresses for any event the application can produce
 */
public interface IEmailEventManager {

	/**
	 * @param id unique identifier for the type of email that is required, i.e. registry.support
	 * @return the registered email address for the given id or null if no email registered
	 */
	String getRegisteredEmail(String id);
	
	/**
	 * Updates the email address registered for the given event
	 * @param id unique identifier for the event
	 * @param email valid email address
	 */
	void updateEmail(String id, String email);
	
	/**
	 * deregister from the event
	 * @param id unique identifier for the event
	 */
	void removeEmail(String id);
	
	/**
	 * Sends an email for the event, if no email address is registered or the email server is not set up then this 
	 * post request will be ignored
	 * 
	 * @param subject email subject header
	 * @param message email body
	 * @param attach file attachment (optional)
	 */
	void postMail(String eventId, String subject, String message, File attach);
}
