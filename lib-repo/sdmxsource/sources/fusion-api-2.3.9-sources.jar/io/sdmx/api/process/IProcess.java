package io.sdmx.api.process;

/**
 * Functional interface for running processes
 */
public interface IProcess {

	/**
	 * Runs a process
	 */
	void runProcess();
	
}
