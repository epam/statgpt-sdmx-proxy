package io.sdmx.api.process;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.notification.SimpleNotifier;

/**
 * A Stoppable has the ability to be started and stopped and give information about its current status
 */
public interface Stoppable extends SimpleNotifier {
	
	/**
	 * Startup the stoppable.
	 * If the stoppable is not in state stopped then this command is ignored.
	 * 
	 * @throws SystemException if there is a problem with the startup 
	 */
	void startUp() throws SdmxException;
	
	/**
	 * Shutdown the stoppable.
	 * This command is ignored if the stoppable is not in status started.
	 * 
	 * @throws SystemException if there is a problem with the shutdown 
	 */
	void shutdown() throws SdmxException;
	
	/**
	 * Shuts down the stoppable and starts it.  
	 *  If the stoppable is not in state start or stopped then this command is ignored.
	 * If the stoppable is stopped then this command will have the effect of just performing a startup.
	 * 
	 * @throws SystemException if there is a problem with the restart 
	 */
	void restart() throws SdmxException;
	
	/**
	 * Returns the current status of this stoppable artifact
	 * @return
	 */
	STOPPABLE_STATUS getStoppableStatus();
	
	/**
	 * Returns the length of time the stoppable has been in the status for
	 * @return
	 */
	long getStatusDuration();
	
	/**
	 * The status of a stoppable artifact
	 */
	enum STOPPABLE_STATUS {
		STARTING,
		STARTED,
		SHUTTING_DOWN,
		STOPPED
	}
}