package io.sdmx.api.process;

import io.sdmx.api.notification.SimpleNotifier;

/**
 * A Processor is something that can be running and processing or idle
 */
public interface Processor extends SimpleNotifier {

	/**
	 * Returns how long in milliseconds the processor has been in its current status for 
	 * @return
	 */
	long getProcessorStatusRuntime();
	
	/**
	 * Returns the current status of this stoppable artifact
	 * @return
	 */
	PROCESSOR_STATUS getProcessorStatus();

	/**
	 * Returns true if the processor is PROCESSOR_STATUS.PROCESSING
	 */
	boolean isProcessing();
		
	/**
	 * The status of the processor
	 */
	enum PROCESSOR_STATUS {
		IDLE,
		PROCESSING
	}	
}