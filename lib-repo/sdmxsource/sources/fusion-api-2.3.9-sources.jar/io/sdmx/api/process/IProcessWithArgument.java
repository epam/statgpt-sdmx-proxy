package io.sdmx.api.process;

/**
 * Functional interface for running processes
 */
public interface IProcessWithArgument<T> {

	/**
	 * Runs a process, returns the response
	 */
	void runProcess(T arg);
	
}
