package io.sdmx.api.process;

public interface IVisitor<T> {

	void visit(T el);
	
}
