package io.sdmx.api.process;

/**
 * Functional interface for running processes
 */
public interface IProcessWithArguments {

	/**
	 * Runs a process
	 */
	void runProcess(Object...args);
	
}
