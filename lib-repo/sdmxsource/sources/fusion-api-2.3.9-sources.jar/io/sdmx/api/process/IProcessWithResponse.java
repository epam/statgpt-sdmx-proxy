package io.sdmx.api.process;

/**
 * Functional interface for running processes
 */
public interface IProcessWithResponse<T> {

	/**
	 * Runs a process, returns the response
	 */
	T runProcess();
	
}
