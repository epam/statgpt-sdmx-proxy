package io.sdmx.api.process;

public interface IProcessArgResponse<V, K> {

	K runProcess(V arg);
	
}
