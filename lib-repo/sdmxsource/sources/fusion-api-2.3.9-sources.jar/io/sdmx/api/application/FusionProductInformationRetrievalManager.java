package io.sdmx.api.application;

public interface FusionProductInformationRetrievalManager {
	/**
	 * Returns fusion product information
	 * @return
	 */
	FusionProductInformation getFusionProductInformation();
}
