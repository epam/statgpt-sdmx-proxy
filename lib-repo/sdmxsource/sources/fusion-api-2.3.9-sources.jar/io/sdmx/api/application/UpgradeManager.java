package io.sdmx.api.application;

public interface UpgradeManager {
	/**
	 * Will run a process to move the system from the currentVersion to the applicationVersion. The
	 * applicationVersion is the version that the application believes it is. The currentVersion is 
	 * a values obtained from some part of persistent storage (such as a file or database).
	 * @param applicationVersion
	 * @param currentVersion
	 */
	public void performUpgrade(String applicationVersion, String currentVersion);
}
