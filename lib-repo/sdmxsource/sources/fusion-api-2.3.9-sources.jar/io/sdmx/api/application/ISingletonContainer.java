package io.sdmx.api.application;


/**
 * API for retrieving singleton classes, this is to mimic the behaviour of the ApplicationContext from Spring
 * where registered beans can be retrieved by passing in their interface.
 */
public interface ISingletonContainer {

	/**
	 * returns the singleton of the given type registered with the container
	 * @param <T>
	 * @param type
	 * @return
	 * @throws BeansException
	 */
	<T> T getSingleton(Class<T> type);
	
	/**
	 * returns the class of the given type, identified uniquely by the given name
	 * @param <T>
	 * @param type
	 * @return
	 * @throws BeansException
	 */
	<T> T getSingleton(Class<T> type, String name);
}
