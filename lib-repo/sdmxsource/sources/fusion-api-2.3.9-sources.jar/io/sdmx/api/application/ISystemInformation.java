package io.sdmx.api.application;

public interface ISystemInformation {

	/**
	 * @return the time in milliseconds that the application was launched
	 */
	long getLaunchDate();

	/**
	 * Information about
	 * Example: DESKTOP-SN38HUC/10.0.75.1
	 * @return
	 */
	String getMachineIdentifier();

	/**
	 * Identifier which is unique when the JVM launched, it is not tied to the machine, it is simple a Global GUID which is generated on JVM launch
	 * Example: DESKTOP-SN38HUC/10.0.75.1
	 * @return
	 */
	String getVmIdentifier();
	
}
