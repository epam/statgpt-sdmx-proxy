package io.sdmx.api.application;

/**
 * Represents a 2 or 3 part version with an optional suffix:
 * Examples 
 * 1.0
 * 1.0.1
 * 1.0.1-draft
 * 
 * The non-suffix versions are deemed later then the suffix (1.0.1 is a later version the 1.0.1-draft)
 */
public interface IVersion extends Comparable<IVersion> {

	/**
	 * @param that to check against
	 * @return true if this version is higher then the 'that' passed in - a suffixed version is a lower version then a non suffixed version
	 * if both versions contain a suffix and have the same version, the suffix is compared one character at a time
	 */
	boolean isHigher(IVersion that);
	
	/**
	 * @return number of version parts, i.e 1.2.3 has 3 parts [1, 2, 3]
	 */
	int getVersionLength();
	
	/**
	 * @param part
	 * @return the version for the given part, 0 indexed, i.e 1.2.3 : part 0=1, part 1=2, part=2=3
	 */
	int getVersion(int part);
	
	/**
	 * @return part 0
	 */
	default int getMajor() {
		return getVersion(0);
	}
	
	/**
	 * @return part 0
	 */
	default int getMinor() {
		return getVersionLength() > 1 ? getVersion(1) : 0;
	}
	
	/**
	 * @return part 0
	 */
	default int getPatch() {
		return getVersionLength() > 2 ? getVersion(2) : 0;
	}
	
	/**
	 * @return nullable suffix to the version i.e. 1.2.3-draft would return draft
	 */
	String getSuffix();
	
	/**
	 * @return string representation of this version, i.e 1.2.3
	 */
	String toString();
	
}
