package io.sdmx.api.application;

import java.util.Collection;


/**
 * API for retrieving classes of the given type, this is to mimic the behaviour of the ApplicationContext from Spring
 * where registered beans can be retrieved by passing in their interface.
 */
public interface IFusionContainer {

	/**
	 * returns all beans of the given type registered with the container
	 * @param <T>
	 * @param type
	 * @return
	 * @throws BeansException
	 */
	<T> Collection<T> getBeansOfType(Class<T> type);

	/**
	 * Return the startup date time as milliseconds since 1970
	 * @return
	 */
	long getStartupTime();

}
