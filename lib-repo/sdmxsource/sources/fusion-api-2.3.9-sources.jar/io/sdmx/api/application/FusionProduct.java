package io.sdmx.api.application;

import java.util.Date;

public interface FusionProduct {
	/**
	 * Returns the release date of the product
	 * @return
	 */
	String getReleaseDate();
	

	/**
	 * Returns the release date of the product
	 * @return
	 */
	Date getReleaseDateAsDate();

	/**
	 * Returns the version of the product
	 * @return
	 */
	String getVersion();
	
	/**
	 * Returns the major version number
	 * @return
	 */
	String getMajorVersion();

	/**
	 * Returns a user assigned product name, such as IMF Registry
	 * @return
	 */
	String getProductName();

	/**
	 * Returns the product
	 * @return
	 */
	String getProduct();
	
}
