package io.sdmx.api.application;

import io.sdmx.api.cache.Cache;

/**
 * A Cache Manager is a Cache which allows for external process to request that the store checks.
 * A Cache Manager is typically (or should be) a class which has direct access to the underlying data source 
 * (a DAO is a typical Cache Manager as it has direct access to the database).
 *
 * @param <T>
 */
public interface CacheManager extends Cache {

	/**
	 * Force a Cache Check against the store.
	 */
	void cacheCheck();
	
	/**
	 * Returns a String identifier of the cache type, for example: 
	 * Structure
	 * Constraints
	 * Metadata
	 * Settings
	 */
	String getCacheType();
	
	/**
	 * Register the application cache manager, to notify on updates
	 * @param applicationCacheManager
	 */
	void registerApplicationCacheManager(ApplicationCacheManager applicationCacheManager);
	
}