package io.sdmx.api.application;

import java.util.List;

/**
 * Contains information about a fusion product
 */
public interface FusionProductInformation  {

	/**
	 * Returns details about he Fusion Product
	 * @return
	 */
	FusionProduct getProductDetails();
	
	/**
	 * 
	 * @return
	 */
	List<FusionProductPlugin> getSupportedPlugins();
	
	/**
	 * Returns the full URL of the web service.
	 * 
	 * The full URL will be to the public API if there is one mapped, otherwise it will be to
	 * the default (internal) API.
	 * @param serivce the web service postfix, for example /ws/public/sdmxapi/rest
	 * 
	 * 
	 * @return
	 */
	String getServiceURL(IApplicationWebService webService);
	
	/**
	 * Returns the URL of the application e.g. http://sandbox.sdmxregistry.org/FusionRegistry
	 * @return
	 */
	String getApplicationURL();
	
	/**
	 * Returns the following JSON 
	 * {
	 *  Product : "FUSION_MATRIX",
	 *  ProductName : "My Product",
	 *  Version : "1.0",
	 *  ReleaseDate : 2138123285
	 *  TimeNow : 2314123145
	 * }
	 * @return
	 */
	String toString();
	
	String publicApiToString();
}
