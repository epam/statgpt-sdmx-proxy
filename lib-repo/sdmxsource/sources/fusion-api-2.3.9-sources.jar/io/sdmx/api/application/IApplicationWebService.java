package io.sdmx.api.application;

/**
 * Defines a web service that is exposed by the application
 * 
 * Comparable by service postfix
 * 
 */
public interface IApplicationWebService extends  Comparable<IApplicationWebService>  {

	/**
	 * @return human readable name for web service, camel case (no white space)
	 */
	String getServiceName();
	
	/**
	 * @return the URL postfix of the web service, everything that comes after the application URL, e.g. /ws/public/sdmxapi/rest
	 */
	String getServicePostFix();
	
	/**
	 * @return A property which can be used to store this service against, lower case, period separated (i.e my.property)
	 */
	String getSystemProperty();
	
}
