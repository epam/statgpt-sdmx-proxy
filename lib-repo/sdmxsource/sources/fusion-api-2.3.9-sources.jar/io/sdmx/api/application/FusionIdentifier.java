package io.sdmx.api.application;

/**
 * Identifies a Fusion Product and returns its name and short-code. E.g "Fusion Registry" and "REG"
 */
public interface FusionIdentifier {
    public String getProductName();

    public String getProductCode();
}
