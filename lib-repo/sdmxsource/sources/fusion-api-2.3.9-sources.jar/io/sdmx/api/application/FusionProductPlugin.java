package io.sdmx.api.application;

public interface FusionProductPlugin {

	/**
	 * Returns the name of the plugin
	 * @return
	 */
	String getPluginName();

	/**
	 * Returns the supported communication version for the plugin
	 * @return
	 */
	Integer[] getPluginCommsVersion();
	
}
