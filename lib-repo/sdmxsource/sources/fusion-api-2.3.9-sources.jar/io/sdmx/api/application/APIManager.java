package io.sdmx.api.application;

/**
 * Provides a single point of entry to store and retrieve the of version that the API is using. 
 * 
 * For example the SearchAPI which outputs JSON could be at version 1 which
 * does not output series count, or version 2, which outputs series count and re-engineers the matched information
 */
public interface APIManager {

	/**
	 * Sets the version of the API to use
	 * @param APIKey the string which identifies the API 
	 * @param version the version to use
	 */
	void setVersion(String APIKey, String version);
	
	/**
	 * Returns true if there is a version for this API Manager, false indicates use latest
	 * @param APIKey
	 * @return
	 */
	boolean hasVersion(String APIKey);

	/**
	 * Returns the version to use, null indicates use latest
	 * @param APIKey
	 * @return
	 */
	IVersion getVersion(String APIKey);
	
}
