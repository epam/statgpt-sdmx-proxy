package io.sdmx.api.application;

public interface ApplicationShutdownAware {

	/**
	 * Informing the class that the server is shutting down
	 */
	void shutdown();
	
}
