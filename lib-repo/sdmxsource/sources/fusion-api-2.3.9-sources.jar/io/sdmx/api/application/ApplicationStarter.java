package io.sdmx.api.application;

public interface ApplicationStarter {

	/**
	 * Returns true if the application has started
	 * @return
	 */
	boolean isStarted();

	/**
	 * @return the startup time of the application. Returns 0L when the time was not properly set at startup.
	 */
	Long getApplicationStartupTime();

	/**
	 * Restart the application, this calls clearCache() on all spring beans which implement Cache and applicationStarted() on all beans implementing ApplicationStartupAware
	 * 
	 * upgradeChecks area also checked using the UpgradeManager
	 * 
	 * @param fusionContainer
	 */
	void startApplication(IFusionContainer fusionContainer);
}
