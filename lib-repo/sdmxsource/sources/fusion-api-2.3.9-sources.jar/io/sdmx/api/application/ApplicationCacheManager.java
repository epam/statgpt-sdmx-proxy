package io.sdmx.api.application;

/**
 * Manages the internal caching of the entire web application
 *
 */
public interface ApplicationCacheManager {

	/**
	 * A Cache Manager notifies when it has updated the underlying data source, this update will be reflected in the 
	 * data store which records internal state
	 * @param cacheManager
	 */
	void notifyUpdate(CacheManager cacheManager);
	
}
