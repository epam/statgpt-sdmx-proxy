package io.sdmx.api.application;

public interface ApplicationCacheInfoManager {

	/**
	 * Returns true if caching is enabled, false if not
	 * @return
	 */
	boolean isNotModifiedEanbled();
	
}
