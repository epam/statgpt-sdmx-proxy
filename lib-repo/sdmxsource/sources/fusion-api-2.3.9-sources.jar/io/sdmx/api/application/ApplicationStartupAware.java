package io.sdmx.api.application;


/**
 * This class needs to be informed when the application dependencies have been wired together so it can perform any post startup processes.
 */
public interface ApplicationStartupAware {
	
	
	/**
	 * Called to inform the class that the application is going to restart and to clear any in memory data. 
	 * A subsequent call will be made to applicationStarted to inform the application that the startup process has completed.
	 */
	void applicationRestarting();
	
	/**
	 * Called to inform the class that the application has started and it should perform its post-startup processes
	 */
	void applicationStarted();
	
	/**
	 * Returns the classes or interfaces that this relies on before starting up
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	Class[] getDependsOn();
	
}
