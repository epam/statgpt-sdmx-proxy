package io.sdmx.api.application;

/**
 * Performs an upgrade between release versions of a product
 * 
 * Implements comparable so they can be sorted by upgrade version
 */
public interface ProductUpgradeEngine extends Comparable<ProductUpgradeEngine> {

	/**
	 * Upgrades to the version of the product given by the upgrade version defined by the getUpgradeVersion() method
	 */
	void upgrade();
	
	/**
	 * Returns the version that this upgrade is to
	 * @return
	 */
	IVersion getUpgradeVersion();
	
}
