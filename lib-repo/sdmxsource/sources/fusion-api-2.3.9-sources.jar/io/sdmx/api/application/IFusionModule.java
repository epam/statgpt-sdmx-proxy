package io.sdmx.api.application;

/**
 * Manages the registration of module specific singleton instances relevant with the application framework
 * 
 * Implementations of this interface should provide a static method to register all instances relevant to the module with the central FusionBeanStore
 */
public interface IFusionModule {

}
