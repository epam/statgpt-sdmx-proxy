package io.sdmx.core.data.engine.info;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.info.ReportedDateEngine;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.sdmx.comparator.TimeFormatComparator;

public class ReportedDateEngineImpl implements ReportedDateEngine {
	public static final ReportedDateEngine INSTANCE = new ReportedDateEngineImpl();
	private ReportedDateEngineImpl() {};

	
	private void registerDate(SdmxDate sdmxDate, Set<String> processedDates, Map<TIME_FORMAT, Map<Date, String>> timeFormatToSortedMap) {
		TIME_FORMAT obsTimeFormat = sdmxDate.getTimeFormatOfDate();
		Map<Date, String> sortedMap;

		//Get the correct sorted map (or create it if it does not yet exist)
		if(timeFormatToSortedMap.containsKey(obsTimeFormat)) {
			sortedMap = timeFormatToSortedMap.get(obsTimeFormat);
		} else {
			sortedMap = new TreeMap<>();
			timeFormatToSortedMap.put(obsTimeFormat, sortedMap);
		}
		sortedMap.put(sdmxDate.getDate(), sdmxDate.getDateInSdmxFormat());
		processedDates.add(sdmxDate.getDateInSdmxFormat());
	}
	
	@Override
	public Map<TIME_FORMAT, List<String>> getAllReportedDates(DataReaderEngine dataReaderEngine) {
		dataReaderEngine.reset();

		Set<String> processedDates = new HashSet<>();
		Map<TIME_FORMAT, Map<Date, String>> timeFormatToSortedMap = new HashMap<>();
		try {
			outer:
			while(dataReaderEngine.moveNextDataset()) {
				Boolean timeAtSeries = null;
				Boolean timeAtObs = null;
				while(dataReaderEngine.moveNextKeyable()) {
					Keyable key = dataReaderEngine.getCurrentKey();
					if(timeAtSeries == null) {
						timeAtSeries = key.getKeyValue(DimensionBean.TIME_DIMENSION_FIXED_ID) != null;
					}
					if(timeAtSeries == Boolean.TRUE) {
						String obsTime = key.getReportedValue(DimensionBean.TIME_DIMENSION_FIXED_ID);
						if(obsTime != null && !processedDates.contains(obsTime)) {
							registerDate(SdmxDateImpl.getSdmxDate(obsTime), processedDates, timeFormatToSortedMap);
						}
					} else {
						while(dataReaderEngine.moveNextObservation()) {
							Observation obs = dataReaderEngine.getCurrentObservation();
							if(timeAtObs == null && !DimensionBean.TIME_DIMENSION_FIXED_ID.equals(obs.getDimensionId())) {
								break outer;
							}
							String obsTime = obs.getDimensionValue();

							//Check we have not already procesed this date
							if(obsTime != null && !processedDates.contains(obsTime)) {
								registerDate(obs.getSdmxObsTime(), processedDates, timeFormatToSortedMap);
							}
						}
					}
				}
			}

			//Create The ResponseMap
			Map<TIME_FORMAT, List<String>> responseMap = new TreeMap<>(TimeFormatComparator.INSTANCE);
			for(TIME_FORMAT currentTimeFormat : timeFormatToSortedMap.keySet()) {
				List<String> sortedDateList = new ArrayList<>();
				responseMap.put(currentTimeFormat, sortedDateList);
				Map<Date, String> sortedMap = timeFormatToSortedMap.get(currentTimeFormat);
				for(Date sortedMapKey : sortedMap.keySet()) {
					sortedDateList.add(sortedMap.get(sortedMapKey));
				}
			}
			return responseMap;
		} finally {
			dataReaderEngine.reset();
		}
	}

}
