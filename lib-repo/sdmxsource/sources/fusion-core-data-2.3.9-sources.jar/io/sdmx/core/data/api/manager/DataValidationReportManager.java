package io.sdmx.core.data.api.manager;

import java.io.OutputStream;

import io.sdmx.core.sdmx.api.error.IDataErrorContainer;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;

/**
 * Responsible for writing validation reports to the output stream
 */
public interface DataValidationReportManager {

	/**
	 * Writes a Validation Report to the Output Stream based on the DatasetDetails
	 * 
	 * The report is in JSON and looks like the following
	 * 
	 * {
	 * 	Meta: {
	 * 		RequestTime: 123456
	 * 		Duration: 12
	 *  }
	 *  ValidData : {
	 *    Dataflow: urn,
	 *    Series: 123
	 *    Observations: 124
	 *    Groups: 12
	 *  },
	 *  InvlaidData : {
	 *  	Dataflow: urn,
	 *  	Series: 12
	 *  	Observations: 10,
	 *  	Groups: 0
	 *  }
	 *  DSD : ""
	 *  Dataflow : ""
	 *  ProvisionAgreement : ""
	 *  Series : 123
	 *  Observations : 1000
	 *  Errors : true
	 *  ValidationReport : [
	 *   	{
	 *        Type : "Structure",
	 *        Errors : [
	 *        	{ Error : "Can not Load Data", "Can not load data due to xyz", "more detail"]} 
	 *        	{ Error : "Can not Load Data", "Can not load data due to xyz", "more detail"]} 
	 *        ]
	 *      }
	 *   ]
	 * }
	 * 
	 * @param details the dataset details to write
	 * @param metrics if provided will write the additional metrics which includes the Meta tag, ValidData tag and InvalidData tag
	 * @param out
	 */
	void writeValidationReport(DataSetDetails details, ValidationTransformationMetrics metrics, OutputStream out);
	
	/**
	 * Writes a report of the errors from the passed in container
	 * Example:
	 * <pre>
	 * [
	 *   	{
	 *        Type : "Structure",
	 *        Errors : [
	 *        	{ Error : "Can not Load Data", "Can not load data due to xyz", "more detail"]} 
	 *        	{ Error : "Can not Load Data", "Can not load data due to xyz", "more detail"]} 
	 *        ]
	 *      }
	 *   ]
	 * </pre>
	 * @param validationResult
	 * @param out
	 */
	void writeValidationReport(IDataErrorContainer errorContainer, OutputStream out);
	
	/**
	 * Writes a Server Error Report to the Output Stream
	 * 
	 * 
	 * 
	 * @param th
	 * @param out
	 */
	void writeValidationReport(Throwable th, OutputStream out);
	
}