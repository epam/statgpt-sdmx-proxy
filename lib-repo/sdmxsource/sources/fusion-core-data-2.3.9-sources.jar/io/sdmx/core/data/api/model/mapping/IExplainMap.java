package io.sdmx.core.data.api.model.mapping;

import java.util.List;

import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Describes the breakdown of a mapping, including the input final output, and mappings for each input component
 */
public interface IExplainMap {
	
	/**
	 * @return mapping rules used
	 */
	MappingRules getMappingRules();

	/**
	 * @return input value to mapping
	 */
	IDataRow getInput();

	/**
	 * @return immutable list of output rows generated from the input row
	 */
	List<IExplainMapOutputRow> getOutputRows();
	
}
