package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.ObservationImpl;

public class ObsSerializer  extends AttributableSerializer<Observation> {
	private Keyable seriesKey;

	public ObsSerializer(Keyable seriesKey) {
		this.seriesKey = seriesKey;
	}
	
	public void setSeriesKey(Keyable seriesKey) {
		this.seriesKey = seriesKey;
	}

	@Override
	public void write(Kryo kryo, Output output, Observation obs) {
		super.write(kryo, output, obs);
		kryo.writeObjectOrNull(output,obs.getDimensionId(), String.class);
		kryo.writeObjectOrNull(output,obs.getDimensionValue(), String.class);

		//Measures
		kryo.writeObject(output, obs.getMeasures(), KeyValueListSerializer.getInstance());
		kryo.writeObject(output, obs.getMultilingualMeasures(), MultilingualKeyValueListSerializer.getInstance());
		
	}

	@Override
	protected AttributableBuilder<Observation> getBuilder(Kryo kryo, Input input) {
		String dimId = kryo.readObjectOrNull(input, String.class);
		String dimValue = kryo.readObjectOrNull(input, String.class);

		final List<KeyValue> measures = kryo.readObject(input, List.class, KeyValueListSerializer.getInstance());
		final List<IMultilingualKeyValue> multilingualMeasures =  kryo.readObject(input, List.class, MultilingualKeyValueListSerializer.getInstance());
		
		return ObservationImpl.builder(seriesKey).dim(dimId, dimValue).measures(measures).measuresMultilingual(multilingualMeasures);
	}
	
}