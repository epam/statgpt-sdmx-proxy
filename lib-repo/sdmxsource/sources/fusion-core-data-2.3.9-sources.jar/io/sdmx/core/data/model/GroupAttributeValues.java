package io.sdmx.core.data.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.utils.core.object.SeriesUtil;

/**
 * Attributes which need to be applied to a group of series which may
 * output additional series attributes or be used to determine a dimension value
 */
public class GroupAttributeValues {
	private Map<String, List<KeyValue>> shortCodeToAttributes = new HashMap<>();
	private List<Integer> dimRefs = new ArrayList<>();  //Dimensions not used in group
	private Set<String> attributeIds;

	public GroupAttributeValues(GroupBean group) {
		DataStructureBean dsd = (DataStructureBean)group.getMaintainableParent();

		for(DimensionBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
			if(!group.getDimensionRefs().contains(dim.getId())) {
				dimRefs.add(dim.getPosition()-1);
			}
		}
		this.attributeIds = dsd.getGroupAttributes(group.getId(), true).stream().map(AttributeBean::getId).collect(Collectors.toSet());
	}

	public void addGroup(Keyable group) {
		List<KeyValue> attributes = new ArrayList<>();
		for(String attrId : attributeIds) {
			KeyValue attr = group.getAttribute(attrId);
			if(attr != null) {
				attributes.add(attr);
			}
		}
		if(attributes.size() > 0) {
			shortCodeToAttributes.put(group.getShortCode(), Collections.unmodifiableList(attributes));
		}
	}

	/**
	 * returns any attributes related to this series
	 * @param series
	 * @return
	 */
	public List<KeyValue> getAttributes(Keyable series) {
		String[] shortCodeSplit = series.getShortCode().split(":");
		for(int i : dimRefs) {
			shortCodeSplit[i] = "";
		}
		String groupKey = SeriesUtil.toSeriesKey(shortCodeSplit);
		return shortCodeToAttributes.get(groupKey);
	}
}
