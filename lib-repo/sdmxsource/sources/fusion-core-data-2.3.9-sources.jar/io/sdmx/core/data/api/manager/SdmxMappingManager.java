package io.sdmx.core.data.api.manager;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.notification.CacheNotifier;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.sdmx.api.model.data.IDataRow;


/**
 * The Sdmx Mapping Manager is responsible for mapping from one structure to another structure based on mapping rules that it is given.
 *
 */
public interface SdmxMappingManager extends CacheNotifier<IStructureEvent> {
	
	/**
	 * Writes a report of which series mapped and which did not map based on the input data and structure map
	 * 
	 * @param rdl
	 * @param structureMap
	 * @param isSource true if the data is the source DSD false if it is the target
	 * @param out the stream to write the report to
	 * @param isValidating whether the mapping should be validated or not
	 */
	void writeMappingReport(ReadableDataLocation rdl, IURNSingle<IStructureMapBean> structureMap, boolean isSource, OutputStream out, boolean isValidating);
	
	/**
	 * Writes the explain plan to the stream
	 * @param sRef reference to the DataStructureMap to use
	 * @param row the row of data to explain the mapping for
	 * @param out
	 */
	void writeExplainPlan(IURNSingle<IStructureMapBean> sRef, IDataRow row, OutputStream out);
	
	/**
	 * Registers a structure set containing mappings to be used, will overwrite any existing mappings if any duplicate or overlaps are found
	 * @param mappingRules
	 */
	MappingRules registerMappingRule(IStructureMapBean mappingRules);

	/**
	 * Returns a set of all the dataflows that can be mapped to the given flow
	 * @param fromFlow
	 * @return
	 */
	Set<DataflowBean> getMappingsForFlow(DataflowBean fromFlow);
	
	/**
	 * Returns a set of all the DSDs that can be mapped to the given DSS
	 * @param fromDsd
	 * @return
	 */
	Set<DataStructureBean> getMappingsForStructure(DataStructureBean fromDsd);
	
	/**
	 * Returns the DataStructureMap for the passed in reference to the Dataflow/DataStructure Map
	 * @param sRef
	 * @return
	 */
	MappingRules getDataStructureMap(IURNSingle<IStructureMapBean> sRef);
	
	/**
	 * Returns a DataStructureMap for the source -> target DataStructure
	 * @param sourceDSD
	 * @param targetDSD
	 * @return
	 */
	MappingRules getDataStructureMap(DataStructureBean sourceDSD, DataStructureBean targetDSD);
	
	/**
	 * Returns a DataStructureMap for the source -> target DataStructure
	 * @param sourceDataflow
	 * @param targetDataflow
	 * @return
	 */
	MappingRules getDataStructureMap(DataflowBean sourceDataflow, DataflowBean targetDataflow);

}
