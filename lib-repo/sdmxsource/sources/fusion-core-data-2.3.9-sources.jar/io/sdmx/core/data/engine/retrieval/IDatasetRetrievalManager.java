package io.sdmx.core.data.engine.retrieval;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.sdmx.model.data.IDataset;

public interface IDatasetRetrievalManager {

	/**
	 * @param restQuery following SDMX rules, the leading data is not required, example IMF,BOP,1.0/F.UK+FR....?detail=seriesKeysOnly
	 * @return a Dataset from the REST query
	 * @throws SdmxNoResultsException if there is no data
	 */
	IDataset getData(String restQuery) throws SdmxNoResultsException;
	
}
