package io.sdmx.core.data.service.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.buider.Builder;
import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.model.format.FlatDataFormatCSV;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.core.data.model.validate.ExternalRequest;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.model.MVDuplicateBehaviour;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.CSVReadableDataLocation;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Builds a ExternalRequest from a HTTP Request from the web service
 */
public class ExternalRequestBuilder implements Builder<ExternalRequest, Request>{
	private static final String HEADER_DATA_FORMAT_IN = "Data-Format";
	private static final String HEADER_FORMAT_OUT = "Accept";
	private static final String HEADER_STRUCTURE = "Structure";
	private static final String HEADER_MAP_STRUCTURE = "Map-Structure";
	private static final String HEADER_UNMAPPED_FORMAT_OUT = "Unmapped-Format";
	private static final String HEADER_SENDER_ID = "Sender-Id";
	private static final String HEADER_RECEIVER_ID = "Receiver-Id";
	private static final String HEADER_DATASET_ACTION = "Dataset-Action";
	private static final String HEADER_DATASET_IDX = "Dataset-Idx";
	private static final String HEADER_DATASET_ID = "Dataset-Id";
	private static final String HEADER_FAIL_ON_ERROR = "Fail-On-Error";
	private static final String HEADER_ZIP_OUTPUT = "Zip";
	private static final String HEADER_METRICS_OUTPUT = "Inc-Metrics";
	private static final String HEADER_UNMAPPED_OUTPUT = "Inc-Unmapped";
	private static final String HEADER_UNMAPPED_REPORT = "Inc-UnmappedReport";
	private static final String HEADER_INCLUDE_INVALID = "Inc-Invalid";
	private static final String HEADER_INCLUDE_VALID = "Inc-Valid";

	private static final String HEADER_REQ_PRIOR_DATA = "Prior-Data-Dependent";
	private static final String HEADER_MERGE_DATASETS = "Merge-Datasets";
	
	private static final String HEADER_DUPLICATE_BEHAVIOUR = "Duplicate-Behaviour";
	
	private static final String HEADER_SKIP_VALIDATION = "Skip-Validation";

	private DataFormatManager dataFormatManager;

	private SdmxBeanRetrievalManager beanRetrievalManager;

	public ExternalRequestBuilder(DataFormat defaultFormat, SdmxBeanRetrievalManager beanRetrievalManager, DataFormatManager dataFormatManager) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.dataFormatManager = dataFormatManager;
	}

	@Override
	public ExternalRequest build(Request buildFrom) throws SdmxException {
		ReadableDataLocation rdl = buildFrom.getReadableDataLocation();

		if(ZipUtil.isAZip(rdl) && ZipUtil.getCountOfFiles(rdl) == 1) {
			ReadableDataLocation unzipped = ZipUtil.unzipFile(rdl);
			rdl.close();
			rdl = unzipped;
		}

		ExternalRequest externalRequest = new ExternalRequest();
		externalRequest.setRdl(rdl);
		
		if(buildFrom.hasHeader(HEADER_SKIP_VALIDATION)) {
			String skipValidation = buildFrom.getHeader(HEADER_SKIP_VALIDATION);
			if (skipValidation.equalsIgnoreCase("true")) {
				externalRequest.setSkipValidation(true);
			}
		}
		
		IURNSingle<? extends IDSDRelatedBean> fromStructure = null;
		if(buildFrom.hasHeader(HEADER_STRUCTURE)) {
			String fromURN = buildFrom.getHeader(HEADER_STRUCTURE);
			if(ObjectUtil.validString(fromURN) && !fromURN.startsWith("urn")) {
				//Generate a URN based on the USerId as this is referencing a CSV template
				String username;
				if (FusionSecurityContext.CTX().hasCurrentUser()) {
					username = FusionSecurityContext.CTX().getSecurityDetails().getUsername();
				} else {
					username = "ANONYMOUS";
				}
				fromURN = SDMX_STRUCTURE_TYPE.DSD.generateUrn(username, fromURN, MaintainableBean.DEFAULT_VERSION);
			}
			//FR-4689
			String[] urns = fromURN.split(",");
			if(urns.length == 1) {
				fromStructure = URN.builder(fromURN).buildSingle(IDSDRelatedBean.class);
				externalRequest.setFromStructure(fromStructure);
			} else {
				List<IURNSingle<? extends IDSDRelatedBean>> refs = new ArrayList<>();
				for(String currentUrn : urns) {
					refs.add(URN.builder(currentUrn).buildSingle(IDSDRelatedBean.class));
				}
				externalRequest.setValidateStructures(refs);
			}
		}

		DataFormat inputFormat = dataFormatManager.getDataFormat(rdl);
		DataFormat outputDataFormat = null;
		// MEDIT #117
		// Obtain the outputDataFormat by analysing the request. Request that any default formats in the manager are not used
		if(buildFrom.hasHeader(HEADER_FORMAT_OUT)) {
			outputDataFormat = dataFormatManager.getFormat(buildFrom, false);
		}
		
		// FMR-115: Add support for "flat csv"
		DataFormat retFormat = determineIfFlatCsvMessage(buildFrom, fromStructure, externalRequest);
		if (outputDataFormat == null && retFormat != null) {
			outputDataFormat = retFormat;
		}
		
		// Set the outputDataFormat from the inputFormat if required
		if(outputDataFormat == null) {
			outputDataFormat = inputFormat;
		}
		
		if(outputDataFormat == null) {
			throw new SdmxException("No output format able to be determined. Input format was " + (inputFormat == null ? "unknown" : inputFormat));
		}
		
		externalRequest.setTranformTo(outputDataFormat);
		
		// Action is transform
		if(buildFrom.hasHeader(HEADER_UNMAPPED_FORMAT_OUT)) {
			DataFormat unmapppedDataFormat = dataFormatManager.getFormat(buildFrom.getHeader(HEADER_UNMAPPED_FORMAT_OUT));
			externalRequest.setUnmappedFormat(unmapppedDataFormat);
		}

		if(buildFrom.hasHeader(HEADER_MAP_STRUCTURE)) {
			externalRequest.setMapStructure(URN.builder(buildFrom.getHeader(HEADER_MAP_STRUCTURE)).buildSingle(IStructureMapRelatedBean.class));
		}
		
		if(buildFrom.hasHeader(HEADER_METRICS_OUTPUT)) {
			externalRequest.setIncludeMetrics(Boolean.parseBoolean(buildFrom.getHeader(HEADER_METRICS_OUTPUT)));
		}
		
		if(buildFrom.hasHeader(HEADER_UNMAPPED_OUTPUT)) {
			externalRequest.setIncludeUnmapped(Boolean.parseBoolean(buildFrom.getHeader(HEADER_UNMAPPED_OUTPUT)));
		}
		
		if(buildFrom.hasHeader(HEADER_UNMAPPED_REPORT)) {
			externalRequest.setIncludeUnmappedReport(Boolean.parseBoolean(buildFrom.getHeader(HEADER_UNMAPPED_REPORT)));
		}
		
		if(buildFrom.hasHeader(HEADER_ZIP_OUTPUT)) {
			externalRequest.setZip(Boolean.parseBoolean(buildFrom.getHeader(HEADER_ZIP_OUTPUT)));
		}

		if(buildFrom.hasHeader(HEADER_INCLUDE_INVALID)) {
			externalRequest.setIncludeInvalid(Boolean.parseBoolean(buildFrom.getHeader(HEADER_INCLUDE_INVALID)));
		}

		if(buildFrom.hasHeader(HEADER_INCLUDE_VALID)) {
			externalRequest.setIncludeValid(Boolean.parseBoolean(buildFrom.getHeader(HEADER_INCLUDE_VALID)));
		}

		if (buildFrom.hasHeader(HEADER_REQ_PRIOR_DATA)) {
			externalRequest.setPriorDataDependent(Boolean.parseBoolean(buildFrom.getHeader(HEADER_REQ_PRIOR_DATA)));
		}

		if (buildFrom.hasHeader(HEADER_MERGE_DATASETS)) {
			externalRequest.setMergeDatasets(Boolean.parseBoolean(buildFrom.getHeader(HEADER_MERGE_DATASETS)));
		}
		
		if (buildFrom.hasHeader(HEADER_DUPLICATE_BEHAVIOUR)) {
			externalRequest.setDuplicateBehaviour( MVDuplicateBehaviour.fromString(buildFrom.getHeader(HEADER_DUPLICATE_BEHAVIOUR)) );
		}

		if(buildFrom.hasHeader(HEADER_SENDER_ID)) {
			String senderId = buildFrom.getHeader(HEADER_SENDER_ID);
			externalRequest.setSenderId(senderId);
		}
		
		if(buildFrom.hasHeader(HEADER_RECEIVER_ID)) {
			String receiverId = buildFrom.getHeader(HEADER_RECEIVER_ID);
			externalRequest.setReceiverId(receiverId);
		}

		if(buildFrom.hasHeader(HEADER_DATASET_ID)) {
			String datasetId = buildFrom.getHeader(HEADER_DATASET_ID);
			externalRequest.setDatasetId(datasetId);
		}

		if(buildFrom.hasHeader(HEADER_DATASET_ACTION)) {
			String ac = buildFrom.getHeader(HEADER_DATASET_ACTION);
			DATASET_ACTION action = DATASET_ACTION.getAction(ac);
			externalRequest.setDatasetAction(action);
		}

		if(buildFrom.hasHeader(HEADER_DATASET_IDX)) {
			String index = buildFrom.getHeader(HEADER_DATASET_IDX);
			try {
				externalRequest.setDatasetIndex(Integer.parseInt(index));
			} catch(NumberFormatException e) {
				throw new SdmxSemmanticException("Illegal Header value '"+index+"' for header '"+HEADER_DATASET_IDX+"' expected to take a value of type int, starting from 0");
			}
		}
		
		if(buildFrom.hasHeader(HEADER_FAIL_ON_ERROR)) {
			String failOnError = buildFrom.getHeader(HEADER_FAIL_ON_ERROR);
			externalRequest.setFailOnError(Boolean.valueOf(failOnError));
		}

		return externalRequest;
	}

	private DataFormat determineIfFlatCsvMessage(Request buildFrom, IURNSingle<? extends IDSDRelatedBean> fromStructure, ExternalRequest externalRequest) {
		if(buildFrom.hasHeader(HEADER_DATA_FORMAT_IN)) {
			String dataFormat = buildFrom.getHeader(HEADER_DATA_FORMAT_IN);
			if (ObjectUtil.validString(dataFormat) && dataFormat.startsWith("csv")) {
				String[] formatSplit = dataFormat.split(";");
				Map<String, String> parameterMap = new HashMap<>();
				for(String currentSplit : formatSplit) {
					String[] vals = currentSplit.split("=");
					if(vals.length == 2) {
						parameterMap.put(vals[0], vals[1]);
					}
				}
				String delimiter = parameterMap.get("delimiter");
				DELIMITER delim = DELIMITER.COMMA;
				if(delimiter != null) {
					delim = DELIMITER.parseDelimiter(delimiter);
				}

				ReadableDataLocation rdl;
				if(fromStructure != null) {
					rdl = new CSVDataReadableDataLocation(externalRequest.getRdl(), delim, 0, new DatasetStructures(fromStructure, beanRetrievalManager));
				} else {
					rdl = new CSVReadableDataLocation(externalRequest.getRdl(), delim, 0);
				}
				externalRequest.setRdl(rdl);
				return new FlatDataFormatCSV(delim);
			}
		}
		return null;
	}
}
