package io.sdmx.core.data.model.dataset;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;

public class DataRow implements IDataRow {
	private IDatasetStructures structures;
	private String shortCode;
	private String rowCode;
	private Map<String, String> row;
	private Map<String, Set<String>> multiValueRow = Collections.emptyMap();
	private Map<String, Set<String>> multilingualValueRow = Collections.emptyMap();
	private Set<String> locales = Collections.emptySet();
	private Boolean partialKey = null;
	

	/**
	 * Builds a DataRow from a map of component id to component value, a copy is taken and made immutable
	 * @param dataflowBean (optional)
	 * @param dsd (required)
	 * @param shortCode (required)
	 * @return
	 */
	public DataRow(IDatasetStructures structures, Map<String, String> row) {
		this(structures, row, null, null, null);
	}
	
	public DataRow(IDatasetStructures structures, Map<String, String> row, Map<String, ? extends Collection<String>> multiValueRow, Map<String, ? extends Collection<String>> multilingualValueRow,
				   Set<String> locales) {
		this(structures);
		
		this.row = row == null ? multiValueRow == null ? new HashMap<>(multilingualValueRow.size()): new HashMap<>(multiValueRow.size()) : new HashMap<>(row);
		this.multiValueRow = multiValueRow == null ? Collections.emptyMap() : getMultivalueRow(multiValueRow, this.row);
		this.multilingualValueRow = getMultilingualvalueRow(multilingualValueRow, this.row);
		this.row = Collections.unmodifiableMap(this.row);
		if(locales != null) {
		    this.locales = Collections.unmodifiableSet(new HashSet<>(locales));
		}
	}
	
	/**
	 * Builds a DataRow from a short code such as A:B:C.  The short code can contain missing entries A::B::X
	 * @param dataflowBean (optional)
	 * @param dsd (required)
	 * @param shortCode (required)
	 * @return
	 */
	public DataRow(IDatasetStructures structures, String shortCode) {
		this(structures);
		if(!ObjectUtil.validString(shortCode)) {
			throw new SdmxException("DataRow - shortCode required");
		}
		row = new HashMap<>();
		String[] split = SeriesUtil.splitKey(shortCode);
		List<DimensionBean> dimensions = structures.getDataStructure().getDimensionList().getDimensions();
		for(int i = 0; i < dimensions.size(); i++) {
			String dimId = dimensions.get(i).getId();
			if(split.length > i && split[i].length() > 0) {
				row.put(dimId, split[i]);
			} else if(!dimId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				partialKey = true;
			}
		}
		this.shortCode= shortCode;
		row = Collections.unmodifiableMap(row);
	}
	
	/**
	 * Common private constructor
	 * @param structures required
	 */
	private DataRow(IDatasetStructures structures) {
		this.structures = structures;
	}
	
	@Override
	/**
	 * Modify the values, keep the short code and partial key if no dimension values
	 * were modified
	 */
	public IDataRow modifyValues(Map<String, String> newData) {
		return this.modifyValues(newData, null, null);
	}
	
	@Override
	/**
	 * Modify a single value
	 */
	public IDataRow modifyValue(String key, String value) {
		DataRow copy = new DataRow(structures);
		Map<String, String> mapCopy = new HashMap<>(getRowData());
		if(value == null) {
			mapCopy.remove(key);
		} else {
			mapCopy.put(key, value);
		}
		
		boolean changeDim = structures.getDataStructure().getDimension(key) != null;
		if(!changeDim) {
			copy.shortCode = this.shortCode;
			copy.partialKey = this.partialKey;
		}
		
		copy.multiValueRow = this.multiValueRow;
		copy.multilingualValueRow = this.multilingualValueRow;
		copy.row = Collections.unmodifiableMap(mapCopy);
		
		return copy;
	}
	
	@Override
	/**
	 * Modify the values, keep the short code and partial key if no dimension values
	 * were modified
	 */
	public IDataRow modifyValues(Map<String, String> newData, Map<String, Set<String>> multiValueData, Map<String, Set<String>> multilingualValueData) {
		DataRow copy = new DataRow(structures);
		Map<String, String> mapCopy = new HashMap<>(getRowData());
		boolean changeDim = false;
		Set<String> dimIds = new HashSet<>(structures.getDataStructure().getDimensionIds());
		for(String newKey : newData.keySet()) {
			if(!changeDim) {
				changeDim = dimIds.contains(newKey);
			}
			String value = newData.get(newKey);
			if(value != null) {
				mapCopy.put(newKey, value);
			} else {
				mapCopy.remove(newKey);
			}
		}
		if(!changeDim) {
			copy.shortCode = this.shortCode;
			copy.partialKey = this.partialKey;
		}
		if(multiValueData == null) {
			multiValueData = Collections.emptyMap();
		} else if(this.multiValueRow == multiValueData) {
			copy.multiValueRow = multiValueData;
		} else {
			copy.multiValueRow = getMultivalueRow(multiValueData, mapCopy);
		}
		if(multilingualValueData == null) {
			multilingualValueData = Collections.emptyMap();
		} else if(this.multilingualValueRow == multilingualValueData) {
			copy.multilingualValueRow = multilingualValueData;
		} else {
			copy.multilingualValueRow = getMultilingualvalueRow(multilingualValueData, mapCopy);
		}
		copy.row = Collections.unmodifiableMap(mapCopy);
		
		return copy;
	}

	private  Map<String, Set<String>>  getMultivalueRow(Map<String, ? extends Collection<String>> multiValueRow, Map<String, String> sinlgeRow) {
		if(ObjectUtil.validMap(multiValueRow)) {
			Map<String, Set<String>> copy = new HashMap<String, Set<String>>(multiValueRow.size());
			for(String key : multiValueRow.keySet()) {
				Collection<String> values = multiValueRow.get(key);
				if(values.size() == 1) {
					sinlgeRow.put(key, (String)values.toArray()[0]);
				} else if(values.size() > 1){
					copy.put(key, Collections.unmodifiableSet(new LinkedHashSet<>(values)));  //Keep the order of items
				}else if(values.size() == 0) {
					sinlgeRow.remove(key);
				}
			}
			if(copy.size() > 0) {
				return Collections.unmodifiableMap(copy);
			}
		}
		return Collections.emptyMap();
	}

	private  Map<String, Set<String>>  getMultilingualvalueRow(Map<String, ? extends Collection<String>> multilingualValueRow, Map<String, String> singleRow) {
		if(ObjectUtil.validMap(multilingualValueRow)) {
			Map<String, Set<String>> copy = new HashMap<String, Set<String>>(multilingualValueRow.size());
			for(String key : multilingualValueRow.keySet()) {
				Collection<String> values = multilingualValueRow.get(key);
				if((values.size() == 1) && !(values.toString().contains(";"))){
					singleRow.put(key, (String)values.toArray()[0]);
				} else if(values.size() >1 || values.toString().contains(";")) {
					copy.put(key, Collections.unmodifiableSet(new LinkedHashSet<>(values)));  //Keep the order of items
				} else if(values.size()==0) {
					singleRow.remove(key);
				}
			}
			if(copy.size() > 0) {
				return Collections.unmodifiableMap(copy);
			}
		}
		return Collections.emptyMap();
	}

	@Override
	public boolean isPartialKey() {
		if(partialKey == null) {
			for(DimensionBean dim : getDatasetStructures().getDataStructure().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
				String dimVal = this.row.get(dim.getId());
				if(dimVal == null) {
					if(!this.multiValueRow.containsKey(dim.getId()) && !this.multilingualValueRow.containsKey(dim.getId())) {
						partialKey = true;
						break;
					}
				}
			}
			if(partialKey == null) {
				partialKey = false;
			}
		}
		return partialKey;
	}

	@Override
	public String getShortCode() {
		if(shortCode == null) {
			partialKey = false;
			List<DimensionBean> dimensions = getDatasetStructures().getDataStructure().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION);
			String[] shortCodeArray = new String[dimensions.size()];
			for(int i = 0; i < dimensions.size(); i++) {
				String dimId = dimensions.get(i).getId();
				String dimVal = this.row.get(dimId);
				shortCodeArray[i] = dimVal;
				if(dimVal == null) {
					partialKey = true;
				}
			}
			this.shortCode= SeriesUtil.toSeriesKey(shortCodeArray);
		}
		return shortCode;
	}
	
	@Override
	public String getRowCode() {
		if(rowCode == null) {
			String timeValue = row.get(DimensionBean.TIME_DIMENSION_FIXED_ID);
			if(timeValue != null) {
				rowCode = getShortCode() + ":"+ timeValue;
			} else {
				rowCode = getShortCode();
			}
		}
		return rowCode;
	}
	
	@Override
	public String getRowCodeAllDimensionsWithWildcard() {
		if(rowCode == null) {
			
			List<DimensionBean> dimensions = getDatasetStructures().getDataStructure().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION);
			String[] shortCodeArray = new String[dimensions.size()];
			for(int i = 0; i < dimensions.size(); i++) {
				String dimId = dimensions.get(i).getId();
				String dimVal = this.row.get(dimId);
				shortCodeArray[i] = dimVal;
				if(dimVal == null) {
					partialKey = true;
				}
			}
			
			this.rowCode = SeriesUtil.toSeriesKey(shortCodeArray, -1, "*", null, ".");
		}
		return rowCode;
	}

	@Override
	public Map<String, String> getRowData() {
		return row;
	}

	@Override
	public Map<String, Set<String>> getMultiValueData() {
		return this.multiValueRow;
	}

	@Override
	public Map<String, Set<String>> getMultilingualValueData(){
		return this.multilingualValueRow;
	}

	@Override
	public Set<String> getLocales(){
		return this.locales;
	}

	@Override
	public IDatasetStructures getDatasetStructures() {
		return structures;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getDatasetStructures().getDataStructure().getShortURN());
		String concat = "";
		for(ComponentBean comp : getDatasetStructures().getDataStructure().getComponents()) {
			String val = this.getRowData().get(comp.getId());
			if(val != null) {
				sb.append(concat+val);
			} else {
				Set<String> values = this.getMultiValueData().get(comp.getId());
				if(values != null && values.size() > 0) {
					sb.append(concat+CollectionUtil.collectionToString(values, ";", ""));
				}
			}
			concat = ".";
		}
		return getDatasetStructures().getDataStructure().getShortURN() + "  " + row.toString()+multiValueRow.toString()+multilingualValueRow.toString();
	}

	private int hashCode = -1;
	
	@Override
	public int hashCode() {
		if(hashCode < 1) {
			hashCode = toString().hashCode();
		}
		return hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DataRow) {
			DataRow that = (DataRow) obj;
			if(!this.getDatasetStructures().equals(that.getDatasetStructures())) {
				return false;
			}
			if(!ObjectUtil.equivalentMap(this.row, that.getRowData())) {
				return false;
			}
			if(this.multiValueRow != null || this.getMultiValueData() != null) {
				if(this.multiValueRow == null) {
					return false;
				}
				if(this.getMultiValueData() == null) {
					return false;
				}
				if(!ObjectUtil.equivalentSet(this.multiValueRow.keySet(), that.getMultiValueData().keySet())) {
					return false;
				}
				for(String multiValueKey : this.multiValueRow.keySet()) {
					if(!ObjectUtil.equivalentSet(this.multiValueRow.get(multiValueKey), that.getMultiValueData().get(multiValueKey))) {
						return false;
					}
				}
			}
			if(this.multilingualValueRow != null || this.getMultilingualValueData() != null){
				if(this.multilingualValueRow == null){
					return false;
				}
				if(this.getMultilingualValueData() == null){
					return false;
				}
				if(!ObjectUtil.equivalentSet(this.multilingualValueRow.keySet(), that.getMultilingualValueData().keySet())){
					return false;
				}
				for(String multilingualValueKey : this.multilingualValueRow.keySet()) {
					if (!ObjectUtil.equivalentSet(this.multilingualValueRow.get(multilingualValueKey), that.getMultilingualValueData().get(multilingualValueKey))) {
						return false;
					}
				}
			}
			return true;
		}
		return false;
	}
	
	
}
