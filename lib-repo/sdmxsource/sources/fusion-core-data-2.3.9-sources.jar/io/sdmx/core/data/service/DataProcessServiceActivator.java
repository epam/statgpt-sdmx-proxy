package io.sdmx.core.data.service;

import java.io.OutputStream;
import java.util.UUID;
import java.util.zip.ZipOutputStream;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.service.data.IDataProcessService;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.manager.IDataProcessManager;
import io.sdmx.core.data.api.manager.IFlatDataWriterManager;
import io.sdmx.core.data.api.model.process.IDataProcess;
import io.sdmx.core.data.model.process.DataProcess;
import io.sdmx.utils.core.collection.FiniteMap;
import io.sdmx.utils.core.file.ZipUtil;
import org.codehaus.jettison.json.JSONObject;


public class DataProcessServiceActivator implements IDataProcessService, Listener<ReadableDataLocation> {
	private IDataProcessManager dataProcessManager;
	private IFlatDataWriterManager dataWriterManager;
	private DataFormatManager dataFormatManager;
	private SdmxBeanRetrievalManager brm;
	
	//2 minutes to do something with the data once it is loaded
	private FiniteMap<String, ReadableDataLocation> loadedDataMap = new FiniteMap<>(1000*120, this);
	
	public DataProcessServiceActivator(IDataProcessManager dataProcessManager, 
									   DataFormatManager dataFormatManager,							
									   IFlatDataWriterManager dataWriterManager, 
									   SdmxBeanRetrievalManager brm) {
		this.dataProcessManager = dataProcessManager;
		this.dataWriterManager = dataWriterManager;
		this.dataFormatManager = dataFormatManager;
		this.brm = brm;
	}
	
	@Override
	/**
	 * Called when the finite map evicts a ReadableDataLocation
	 */
	public void invoke(ReadableDataLocation rdl) {
		rdl.close();
	}

	@Override
	public String loadData(ReadableDataLocation rdl) {
		if(rdl == null) {
			throw new SdmxSemmanticException("loadData missing data file");
		}
		String uid = UUID.randomUUID().toString();
		//Unlikely!
		if(loadedDataMap.containsKey(uid)) {
			return loadData(rdl);  //try again
		}
		loadedDataMap.put(uid, rdl);
		return uid;
	}

	@Override
	public String runProcess(String dataToken, JSONObject processDescription) {
		ReadableDataLocation data = this.loadedDataMap.get(dataToken);
		if(data == null) {
			throw new SdmxSemmanticException("Data file not found with token:"+dataToken);
		}
//		if(data == null) {
//			String dataURL = JsonObjectUtil.getString(processDescription, "DataURL", true);
//			if(dataURL == null) {
//				throw new SdmxSemmanticException("Run Process requires a Dataset or DataURL");
//			}
//			URL url;
//			try {
//				url = new URL(dataURL);
//			} catch (MalformedURLException e) {
//				throw new IllegalArgumentException("The URL specified is not valid: " +dataURL);
//			}
//			data = RestMessageBroker.toReadableDataLocation(url);
//		}
		if(ZipUtil.isAZip(data)) {
			ReadableDataLocation copy = ZipUtil.unzipFile(data);
			//data.close();
			data = copy;
		}
		IDataProcess process = new DataProcess(processDescription);
		return dataProcessManager.processData(process, data).getTokenId();
	}

	@Override
	public void writeProcessStatus(String tokenId, OutputStream out) {
		dataProcessManager.writeProcessStatus(tokenId, out);
	}

	@Override
	public void writeDataset(String tokenId, String processStepId, String saveAs, Request request, IResponse response) {
		DataQuery query = null;//TODO
		DataFormat dataFormat = dataFormatManager.getFormat(request);
		if(dataFormat == null) {
			dataFormat = dataFormatManager.getDefaultFormat();
		}
		if(dataFormat == null) {
			throw new SdmxException("Data format not provided and no default defined");
		}
		response.setContentType(dataFormat.getFormatDetails().getMimeType());
		
		OutputStream out = response.getOutputStream();
		if(saveAs != null) {
			boolean isZip = saveAs.endsWith(".zip");
			String fileExtension = dataFormat.getFormatDetails().getFileExtension();
			if(!isZip && !saveAs.endsWith("."+fileExtension)) {
				saveAs = saveAs+ "." + fileExtension;
			}
			if(isZip) {
				out = new ZipOutputStream(out);
			}
			response.setContentType("application/octet-stream");
			response.setHeader("content-disposition", "attachment; filename = "+ saveAs);
		} else {
			response.setContentType(dataFormat.getFormatDetails().getMimeType());
		}
		IFlatDataWriterEngine dwe = dataWriterManager.getDataWriterEngine(dataFormat, response.getOutputStream(), query);
		dataProcessManager.writeData(query, tokenId, processStepId, dwe);
	}
}
