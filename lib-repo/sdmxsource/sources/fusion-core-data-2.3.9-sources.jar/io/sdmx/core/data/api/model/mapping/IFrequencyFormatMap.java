package io.sdmx.core.data.api.model.mapping;

import io.sdmx.api.date.SdmxDate;

/**
 * Provides the ability to convert the standard SDMX date format into a custom representation
 */
public interface IFrequencyFormatMap {

	/**
	 * Converts the input sdmx date string into a custom representation if rules exist, otherwise this returns
	 * the sdmx date
	 * @param date the SDMX date which includes the format, and point in time
	 * @return the date formatted or input sdmx date if no formatting rules are found for the freqency
	 */
	String formatDate(SdmxDate date);
}
