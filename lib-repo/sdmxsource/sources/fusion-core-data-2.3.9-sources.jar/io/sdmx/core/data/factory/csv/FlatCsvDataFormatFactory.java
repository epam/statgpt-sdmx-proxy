package io.sdmx.core.data.factory.csv;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.model.format.FlatDataFormatCSV;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.StringUtil;

public class FlatCsvDataFormatFactory implements DataFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();

	private static FlatCsvDataFormatFactory INSTANCE;

	//Private constructor - lazy load instance
	public static FlatCsvDataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new FlatCsvDataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static FlatCsvDataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private FlatCsvDataFormatFactory() {
		supportedFormats.put("application/vnd.csv", new FormatDetailsImpl("csv", "csv", "text/csv", true));
		supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}
	
	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public DataFormat getDataFormat(ReadableDataLocation sourceData) {
		if(sourceData.getFormat() == FILE_FORMAT.CSV) {
			// It is CSV if it does NOT start with the word "Dataflow"
			byte[] firstBytes = StreamUtil.getFirstXBytes(sourceData.getInputStream(), 20);
			String firstBit = StringUtil.stripBOM(firstBytes);
			String delimiter = ",";
			String[] splitLine = firstBit.split(delimiter);
			String firstElement = splitLine[0].trim();
			if (!firstElement.equalsIgnoreCase("Dataflow") || firstElement.equalsIgnoreCase("\"Dataflow\"")) {
				return new FlatDataFormatCSV(DELIMITER.COMMA);
			}
		}
		return null;
	}

	@Override
	public Class<DataFormat> getFormatClass() {
		return DataFormat.class;
	}

	@Override
	public DataFormat getFormat(String format, Request request) {
		if(format != null && format.startsWith("csv") && !format.startsWith("csv-sdmx")) {
			return new FlatDataFormatCSV(DELIMITER.COMMA);
		}

		return null;
	}
	
	@Override
	public DataFormat getFormat(Request request, IVNDHeader vndHeader) {
		if(vndHeader.getVnd().startsWith("csv")) {
			return new FlatDataFormatCSV(DELIMITER.COMMA);
		}
		return null;
	}

	@Override
	public int getPriority() {
		return 10;
	}

}
