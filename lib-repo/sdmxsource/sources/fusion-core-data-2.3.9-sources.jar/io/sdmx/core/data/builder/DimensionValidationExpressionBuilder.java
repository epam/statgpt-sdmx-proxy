package io.sdmx.core.data.builder;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.builder.IDimensionValidationExpressionBuilder;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.data.calculation.IDimensionValidationExpression;
import io.sdmx.core.data.model.calcuation.CustomValidationExpression;

public class DimensionValidationExpressionBuilder implements IDimensionValidationExpressionBuilder {

	@Override
	public Set<IDimensionValidationExpression> buildRules(ValidationSchemeBean validationSchemeBean) {
		Set<IDimensionValidationExpression> returnSet = new HashSet<>();
		for(ValidationRuleBean valRule : validationSchemeBean.getItems()) {
			if(valRule.hasExpression()) {
				returnSet.add(new CustomValidationExpression(valRule));
			}
		}
		return returnSet;
	}

}
