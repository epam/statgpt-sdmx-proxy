package io.sdmx.core.data.engine.writer;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.manager.KryoTemporaryDataManager;
import io.sdmx.core.data.util.DataTransformOptions;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.utils.core.application.SingletonStore;

public abstract class FlushingDataWriterProxy<T extends ISeriesObsDataWriterEngine> implements ISeriesObsDataWriterEngine {

    private ITemporaryDataManager tmpDataManager = SingletonStore.getSingleton(ITemporaryDataManager.class);
    private final ITemporaryDataWriterEngine tmpWriter;
    private T infoWriter;

    public FlushingDataWriterProxy(T infoWriter) {

        if(tmpDataManager == null) {
            tmpDataManager = new KryoTemporaryDataManager();
            SingletonStore.registerInstance(tmpDataManager);
        }
        tmpWriter = tmpDataManager.getDataWriterEngine();
        this.infoWriter = infoWriter;
    }


    @Override
    public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
        tmpWriter.startDataset(structures, header, datasetAttributes, annotations);
        infoWriter.startDataset(structures, header, datasetAttributes, annotations);
    }

    @Override
    public void writeKey(Keyable key) {
        tmpWriter.writeKey(key);
        infoWriter.writeKey(key);
    }

    @Override
    public void writeObservation(Observation obs) {
        tmpWriter.writeObservation(obs);
        infoWriter.writeObservation(obs);
    }

    @Override
    public void close(FooterMessage... footer) {
        DataReaderEngine dre = tmpDataManager.getDataReaderEngine(tmpWriter);
        try {
        	tmpWriter.close();
        	infoWriter.close();
        	
        	DataTransformationUtil.copyData(dre, getTargetWriter(infoWriter), DataTransformOptions.getInstance().setCloseWriter(true));
        } finally {
        	tmpDataManager.close(tmpWriter);
        }
    }

    @Override
    public void writeHeader(HeaderBean header) {
    	tmpWriter.writeHeader(header);
    	infoWriter.writeHeader(header);
    }
    
    protected abstract ISeriesObsDataWriterEngine getTargetWriter(T infoWriter);
    
    
}
