package io.sdmx.core.data.constant;

public enum OBS_STATUS_VALUE {
	TIME_SERIES_BREAK(                     "B", true,  true),
	MISSING_VALUE(                         "O", false, true),
	MISSING_VALUE_DATA_CANNOT_EXIST(       "M", false, true),
	MISSING_VALUE_DATA_EXIST_NOT_COLLECTED("L", false, true),
	MISSING_VALUE_HOLIDAY_OR_WEEKEND(      "H", false, true),
	MISSING_VALUE_SUPRESSED(               "Q", false, true),
	DEROGATION(                            "J", true, true),
	STRIKE_AND_OTHER_SPECIAL_EVENTS(       "S", true, true),
	DEFINITION_DIFFERS(                    "D", true, false),
	DATA_INCLUDED_IN_ANOTHER_CATEGORY(     "K", false, true),
	INCLUDES_DATA_FROM_ANOTHER_CATEGORY(   "W", true, false),
	INPUTTED_VALUE(                        "I", true, false),
	FORECAST_VALUE(                        "F", true, false),
	ESTIMATED_VALUE(                       "E", true, false),
	PROVISIONAL_VALUE(                     "P", true, false),
	NOT_SIGNIFICANT(                       "N", true, false),
	LOW_RELIABILITY(                       "U", true, false),
	UNVALIDATED_VALUE(                     "V", true, false),
	EXPERIMENTAL_VALUE(                    "G", true, false),
	NORMAL_VALUE(                          "A", true, false);

	private String representation;
	private boolean allowNumeric;
	private boolean allowMissing;

	OBS_STATUS_VALUE(String representation, boolean allowNumeric, boolean allowMissing) {
		this.representation = representation;
		this.allowNumeric = allowNumeric;
		this.allowMissing = allowMissing;
	}

	public static OBS_STATUS_VALUE getObsStatusValue(String representation) {
		for (OBS_STATUS_VALUE os : OBS_STATUS_VALUE.values()) {
			if (os.representation.equals(representation)) {
				return os;
			}
		}
		// Do not throw exception for performance purposes. Return null
		return null;
	}

	public String getRepresentation() {
		return representation;
	}

	public boolean isAllowNumeric() {
		return allowNumeric;
	}

	public boolean isAllowMissing() {
		return allowMissing;
	}

	@Override
	public String toString() {
		return representation;
	}
}
