package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

public class MaintainableRefBeanSerializer extends Serializer<IMaintainableRef> {
	private static final MaintainableRefBeanSerializer INSTANCE = new MaintainableRefBeanSerializer();
	private MaintainableRefBeanSerializer() {}
	

	public static MaintainableRefBeanSerializer getInstance() {
		return INSTANCE;
	}

	@Override
	public void write(Kryo kryo, Output output, IMaintainableRef object) {
		kryo.writeObject(output, object == null ? -1 : 1);  
		if(object != null) {
			kryo.writeObjectOrNull(output, object.getAgencyId(), String.class);
			kryo.writeObjectOrNull(output, object.getMaintainableId(), String.class);
			kryo.writeObjectOrNull(output, object.getVersion(), String.class);
		}
	}

	@Override
	public IMaintainableRef read(Kryo kryo, Input input, Class<? extends IMaintainableRef> type) {
		boolean isNull = kryo.readObject(input, Integer.class) == -1;
		if(isNull) {
			return null;
		}
		String agency = kryo.readObjectOrNull(input, String.class);
		String id = kryo.readObjectOrNull(input, String.class);
		String version = kryo.readObjectOrNull(input, String.class);
		return MaintainableRef.getInstance(agency, id, version);
	}
}
