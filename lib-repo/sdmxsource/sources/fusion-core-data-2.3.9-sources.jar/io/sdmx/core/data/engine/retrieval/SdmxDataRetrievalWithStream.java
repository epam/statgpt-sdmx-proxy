
package io.sdmx.core.data.engine.retrieval;

import java.io.OutputStream;

import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;


/**
 * The SdmxDataRetrievalWithStream is capable of executing a DataQuery and writing the response to 
 * the OutputStream in the requested response format.
 */
public interface SdmxDataRetrievalWithStream {
	
	void getData(DataQuery dataQuery, DataFormat responseFormat, OutputStream outputStream);	
	
}
