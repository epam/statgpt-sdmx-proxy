package io.sdmx.core.data.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.service.data.IDataValidationService;
import io.sdmx.core.data.api.manager.DataLoadManager;
import io.sdmx.core.data.api.manager.DataValidationReportManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.engine.writer.DatasetInfoWriterEngine;
import io.sdmx.core.data.model.transform.DataTransformationOptionsImpl;
import io.sdmx.core.data.model.validate.ExternalRequest;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;
import io.sdmx.core.data.service.builder.ExternalRequestBuilder;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.MultipartOutputStream;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataValidationService extends AbstractDataService implements IDataValidationService {
	private static final Logger LOG = LoggerFactory.getLogger(DataTransformationService.class);

	public DataValidationService(
			DataLoadManager dataLoadManager,
			ExternalRequestBuilder externalRequestBuilder,
			DataValidationReportManager validationReportManager,
			DataWriterManager dataWriterManager,
			HeaderRetrievalManager headerRetrievalManager,
			WriteableDataLocationFactory wdlFactory) {
		super(dataLoadManager, externalRequestBuilder, validationReportManager, dataWriterManager, headerRetrievalManager, wdlFactory);
	}
	
	@Override
	public void validateData(Request req, IResponse response) {
		ExternalRequest request= null;
		try {
			if(req.getReadableDataLocation() == null) {
				throw new SdmxSemmanticException("Data file not supplied.  If content type is set to multipart/form-data the ContentID name must be 'uploadFile'.  If loading data via a stream, set the content "
						+ "type to application/text, application/xml, or application/json");
			}
			request = externalRequestBuilder.build(req);
			validateData(request, response);
		} catch(Throwable th) {
			handleError(request, response, th);
		}
	}

	private int validateData(ExternalRequest request, IResponse resp) throws IOException {
		LOG.info("External Validate Request Received: " +request);
		ValidationTransformationMetrics metrics = new ValidationTransformationMetrics();

		DataSetDetails details = getDataSetDetails(request);
		WriteableDataLocation tmpWdl = wdlFactory.getTemporaryWriteableDataLocation();
		try {
			if (ObjectUtil.validString( details.getDsdError())) {
				throw new SdmxSemmanticException(details.getDsdError());
			} else {
				//Write the validation report
				if(request.isZip())  {
					resp.setContentType("application/zip");
				} else if(request.isIncludeInvalid() || request.isIncludeValid()) {
					resp.setContentType("multipart/mixed;boundary=fusionboundary");
					resp.setHeader("content-disposition", "form-data");
				} else {
					resp.setContentType("application/json");
				}

				OutputStream out = tmpWdl.getOutputStream();
				DataTransformationOptions options = null;
				if(request.isZip())  {
					options = new DataTransformationOptionsImpl(request.getTranformTo(), new ZipOutputStream(out));
				} else if(request.isIncludeInvalid() || request.isIncludeValid()) {
					options = new DataTransformationOptionsImpl(request.getTranformTo(), new MultipartOutputStream(out, "fusionboundary"));
				} else {
					options = new DataTransformationOptionsImpl(request.getTranformTo(), out);
				}

				if (request.getSenderId() != null) {
                    DataReaderEngine dataReaderEngine = details.getDataReaderEngine(0);
                    if (dataReaderEngine.getHeader() != null) {
                        dataReaderEngine.getHeader().setSender(new PartyBeanImpl(null, request.getSenderId(), null, null));
                    }
                }

				if(request.isIncludeInvalid()) {
					ISeriesObsDataWriterEngine dwe = dataWriterManager.getDataWriterEngine(request.getTranformTo(), options.getOutputStream());
					options.startPart(request.getTranformTo().getFormatDetails(), "InvalidData");

					DatasetInfoWriterEngine dataInfoDataWriterEngine = null;
					if(request.isIncludeMetrics()) {
						dataInfoDataWriterEngine  = new DatasetInfoWriterEngine(dwe);
						dwe = dataInfoDataWriterEngine;
					}
					details.writeInvalidData(dwe);
					if(dataInfoDataWriterEngine != null) {
						metrics.addDataInformation("InvalidData", dataInfoDataWriterEngine.getDataInformation());
					}

				}
				if(request.isIncludeValid()) {
					ISeriesObsDataWriterEngine dwe = dataWriterManager.getDataWriterEngine(request.getTranformTo(), options.getOutputStream());
					options.startPart(request.getTranformTo().getFormatDetails(), "ValidData");
					DatasetInfoWriterEngine dataInfoDataWriterEngine = null;
					if(request.isIncludeMetrics()) {
						dataInfoDataWriterEngine  = new DatasetInfoWriterEngine(dwe);
						dwe = dataInfoDataWriterEngine;
					}
					details.writeValidData(dwe);
					if(dataInfoDataWriterEngine != null) {
						metrics.addDataInformation("ValidData", dataInfoDataWriterEngine.getDataInformation());
					}
				}
				if(request.isIncludeMetrics()) {
					metrics.setEndTime();
				} else {
					metrics = null;
				}
				options.startPart(new FormatDetailsImpl("json", "json", "application/json", false), "report");
				validationReportManager.writeValidationReport(details, metrics, options.getOutputStream());
				options.close();
				StreamUtil.copyStream(tmpWdl.getInputStream(), resp.getOutputStream(), true);
			}
		} finally {
			dataLoadManager.close(details.getUid());
			tmpWdl.close();
			request.getRdl().close();
		}
		LOG.debug("External Request Completed Successfully");
		return 200;
	}
}
