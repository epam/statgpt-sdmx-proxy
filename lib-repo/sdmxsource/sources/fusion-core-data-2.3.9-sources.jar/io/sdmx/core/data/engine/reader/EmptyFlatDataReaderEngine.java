package io.sdmx.core.data.engine.reader;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public class EmptyFlatDataReaderEngine implements IFlatDataReaderEngine {
	public static final EmptyFlatDataReaderEngine INSTANCE = new EmptyFlatDataReaderEngine();
	

	protected EmptyFlatDataReaderEngine() {}

	@Override
	public HeaderBean readHeader() {
		return null;
	}

	@Override
	public DatasetHeaderBean readDatasetHeader() {
		return null;
	}

	@Override
	public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
		return false;
	}

	@Override
	public IDataRow getCurrentRow() {
		return null;
	}

	@Override
	public void reset() {}

	@Override
	public void close() {}

	@Override
	public IFlatDataReaderEngine createCopy() {
		return this;
	}
}
