package io.sdmx.core.data.engine.retrieval;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.query.BaseDataQuery;

public interface IBaseDataQueryWithWriter {
	
	
	/**
	 * Queries for data conforming to the parameters defined by the DataQuery,
	 * the response is written to the DataWriterEngine
	 * 
	 * @param dataQuery
	 * @param dataWriter
	 */
	void getData(BaseDataQuery dataQuery, ISeriesObsDataWriterEngine dataWriter);	
	
}
