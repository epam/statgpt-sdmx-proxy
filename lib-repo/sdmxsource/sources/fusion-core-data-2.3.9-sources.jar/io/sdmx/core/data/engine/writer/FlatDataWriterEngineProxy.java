package io.sdmx.core.data.engine.writer;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Acts as a proxy on another {@link IFlatDataWriterEngine}
 */
public abstract class FlatDataWriterEngineProxy<T extends IFlatDataWriterEngine> implements IFlatDataWriterEngine {
	protected T proxy;
	private boolean isClosed;
	private boolean headerWritten;
	
	protected FlatDataWriterEngineProxy(T proxy) {
		this.proxy = proxy;
	}

	@Override
	public void writeHeader(HeaderBean header) {
		if(headerWritten ) {return ;}
		headerWritten = true;
		proxy.writeHeader(header);
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		proxy.startDataset(header, annotations);
	}

	@Override
	public void writeRow(IDataRow row) {
		proxy.writeRow(row);
	}

	@Override
	public void close() {
		if(isClosed ) {return ;}
		isClosed = true;
		proxy.close();
	}
	
	public void setProxy(T proxy) {
	    this.proxy = proxy;
	}

	public T getProxy() {
		return proxy;
	}
}
