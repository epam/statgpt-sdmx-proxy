package io.sdmx.core.data.manager;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.cache.Cache;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DatasetCreationAware;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.manager.DataValidationManager;
import io.sdmx.core.data.api.manager.DataValidatorLevelRetrievalManager;
import io.sdmx.core.data.engine.validate.ValidatingDataWriterEngine;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.error.DataErrorImpl;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Delegates the validation of Keys and Observations to the registered factories.
 */
public class DataValidationManagerImpl implements DataValidationManager, Cache, ApplicationStartupAware {

	private DataValidatorLevelRetrievalManager dataValidatorManager;
	private Set<DataValidatorFactory> validatorFactories;
	private SdmxSuperBeanRetrievalManager superRetrievalManager;
	private IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager;



	public DataValidationManagerImpl(SdmxSuperBeanRetrievalManager superRetrievalManager, 
			DataValidatorLevelRetrievalManager dataValidatorManager,
			IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager) {
		this.dataValidatorManager = dataValidatorManager;
		this.superRetrievalManager = superRetrievalManager;
		this.constraintPrefixDetailRetreivalManager = constraintPrefixDetailRetreivalManager;
	}

	@Override
	public void applicationRestarting() {}

	@Override
	public void applicationStarted() {
		clearCache();
		for(DataValidatorFactory factory : FusionBeanStore.getBeans(DataValidatorFactory.class)) {
			validatorFactories.add(factory);
		}
	}


	@Override
	public void clearCache() {
		validatorFactories = new HashSet<>();
	}


	@Override
	public Class[] getDependsOn() {
		return null;
	}


	public void addValidatorFactory(DataValidatorFactory fac) {
		if (validatorFactories == null) {
			validatorFactories = new HashSet<>();
		}
		validatorFactories.add(fac);
	}

	private class ErrorCounter implements DataValidationErrorHandler {
		private DataValidationErrorHandler exHandler;
		private Map<String, Integer> exceptionCount = new HashMap<>();
		private int limit;
		private Set<String> limitHit = new HashSet<>();

		public ErrorCounter(DataValidationErrorHandler exHandler, int limit) {
			this.exHandler = exHandler;
			this.limit = limit;
		}


		@Override
		public void handleError(DataError dataError) throws ErrorLimitException {
			this.exHandler.handleError(dataError);
			if(dataError.getErrorCategory() != null) {
				Integer i = exceptionCount.get(dataError.getErrorCategory());
				if(i == null) {
					i = 0;
				}
				i++;
				exceptionCount.put(dataError.getErrorCategory(), i);
				if(i >= limit) {
					limitHit.add(dataError.getErrorCategory());
				}
			}
		}
	}

	@Override
	public Set<DataValidatorFactory> validateData(DataReaderEngine dre, DataValidationErrorHandler exceptionHandler,
			VALIDATION_TYPE validationType, boolean fullValidation) throws SdmxSyntaxException, SdmxSemmanticException {
		return this.validateData(dre, exceptionHandler, validationType, fullValidation, -1);
	}

	@Override
	public Set<DataValidatorFactory> validateData(DataReaderEngine dataReaderEngine, DataValidationErrorHandler exceptionHandler, VALIDATION_TYPE validationType, boolean fullValidation, int errorLimitPerCategory) {
		if (dataReaderEngine == null) {
			throw new IllegalArgumentException("DataReaderEngine can not be null");
		}
		ErrorCounter errorCounter = null;
		if(errorLimitPerCategory > 0) {
			errorCounter = new ErrorCounter(exceptionHandler, errorLimitPerCategory);
			exceptionHandler = errorCounter;
		}

		dataReaderEngine.reset();
		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
		SdmxException.disableExceptionTrace(true);

		//This is just to return to the client so it knows which validators were used
		Set<DataValidatorFactory> returnSet = new HashSet<>();

		Date transactionValidity = null;
		if(dataReaderEngine instanceof DatasetCreationAware) {
			DatasetCreationAware creationAware = (DatasetCreationAware) dataReaderEngine;
			transactionValidity = creationAware.getCreationDate();
		}

		int datasetPos = 0;
		try {
			while (dataReaderEngine.moveNextDataset()) {
				datasetPos = dataReaderEngine.getDatasetPosition();
				DataStructureBean dataStructure = dataReaderEngine.getDataStructure();

				DataflowBean dataFlow = dataReaderEngine.getDataFlow();
				ProvisionAgreementBean provisionAgreement = dataReaderEngine.getProvisionAgreement();
				DatasetHeaderBean currentDatasetHeaderBean = dataReaderEngine.getCurrentDatasetHeaderBean();

				for (DataValidatorFactory aFac : validatorFactories) {
					if (dataValidatorManager != null && dataValidatorManager.getValidationLevel(aFac.getId()).isIgnore()) {
						continue;
					}
					//If this is not a full validation, then only include validators whose validation is related to which provision or flow is linked
					if(!fullValidation && aFac.validationLinkedToFlowOrProvision() == false) {
						continue;
					}
					if(aFac.validationRequiresKnowledgeOfPreviouslyReportedData()) {
						switch(validationType) {
						case IGNORE_FULL_DATA_CONTEXT_VALIDATION:
							continue;
						case FULL_DATA_CONTEXT_PROVIDED:
							//Include the validation engine
							break;
						case RESOLVE_FULL_DATA_CONTEXT:
							//Not yet implemented
							throw new SdmxNotImplementedException("Resolve full data context for validation is not yet implemented");
						}
					}
					returnSet.add(aFac);
				}
				
				ValidatingDataWriterEngine vdwe = new ValidatingDataWriterEngine(superRetrievalManager, constraintPrefixDetailRetreivalManager, returnSet, exceptionHandler, null, null, transactionValidity);
				vdwe.startDataset(new DatasetStructures(dataStructure, dataFlow, provisionAgreement, null), currentDatasetHeaderBean, dataReaderEngine.getDatasetAttributes());

				//No Validation Required!
				if(!vdwe.hasValidators()) {
					return returnSet;
				}
				
				// Analyse the data file asking each DataValidationEngine to perform validation
				while (moveNextKeyable(dataReaderEngine, exceptionHandler)) {
					Keyable key = null;
					try {
						key = dataReaderEngine.getCurrentKey();
					} catch (SdmxException e) {
						exceptionHandler.handleError(new DataErrorImpl(datasetPos, e));
					}
					vdwe.writeKey(key);
					if(checkLimitHit(errorCounter, validatorFactories, vdwe)) {
						return returnSet;
					}
					try {
						while (moveNextObservation(dataReaderEngine, exceptionHandler)) {
							Observation obs = dataReaderEngine.getCurrentObservation();
							vdwe.writeObservation(obs);
							if(checkLimitHit(errorCounter, validatorFactories, vdwe)) {
								return returnSet;
							}
						}
					} catch (SdmxException e) {
						exceptionHandler.handleError(new DataErrorImpl(datasetPos, e));
					}
				}
				vdwe.close();
			}
		} catch (ErrorLimitException ex) {
			throw ex;
		} catch (Throwable th) {
			th.printStackTrace();
			exceptionHandler.handleError(new DataErrorImpl(datasetPos, th));
		} finally {
			SdmxException.disableExceptionTrace(wasDisabled);
		}
		return returnSet;
	}

	/**
	 * Checks if the limit of validation has been hit for any error type, and if so, removes the relevant validator from the set allValidators
	 * @param errorCounter
	 * @param allValidators
	 * @param validationByErrorType
	 * @return true if there are no validators left
	 */
	private boolean checkLimitHit(ErrorCounter errorCounter, Set<DataValidatorFactory> allValidators, ValidatingDataWriterEngine vdwe) {
		if(errorCounter != null && errorCounter.limitHit.size() > 0) {
			for(String errType : errorCounter.limitHit) {
				for(DataValidatorFactory factory : allValidators) {
					if(factory.getId().equals(errType)) {
						vdwe.removeValidator(factory);
						break;
					}
				}
			}
			errorCounter.limitHit = new HashSet<>();
			if(!vdwe.hasValidators()) {
				return true;
			}
		}
		return false;
	}

	private boolean moveNextKeyable(DataReaderEngine dre, DataValidationErrorHandler exceptionHandler) {
		boolean hasNext = false;
		try {
			hasNext = dre.moveNextKeyable();
		} catch (SdmxException e) {
			exceptionHandler.handleError(new DataErrorImpl(dre.getDatasetPosition(), e));
		}
		return hasNext;
	}

	private boolean moveNextObservation(DataReaderEngine dre, DataValidationErrorHandler exceptionHandler) {
		boolean hasNext = false;
		try {
			hasNext = dre.moveNextObservation();
		} catch (SdmxException e) {
			exceptionHandler.handleError(new DataErrorImpl(dre.getDatasetPosition(), e));
		}
		return hasNext;
	}

	@Override
	public Set<DataValidatorFactory> obtainFactoriesToBeUsedInDataValidation(boolean fullValidation) {
		Set<DataValidatorFactory> returnFactorySet = new HashSet<>();
		for (DataValidatorFactory aFac : validatorFactories) {
			if (dataValidatorManager != null && dataValidatorManager.getValidationLevel(aFac.getId()).isIgnore()) {
				continue;
			}
			//If this is not a full validation, then only include validators whose validation is related to which provision or flow is linked
			if(!fullValidation && aFac.validationLinkedToFlowOrProvision() == false) {
				continue;
			}
			returnFactorySet.add(aFac);
		}

		return returnFactorySet;
	}
}