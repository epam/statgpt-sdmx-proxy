package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.ObjectDataType;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_Map;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Serialization for HeaderBean.
 */
public class DT_HeaderBean extends BasicDataType<HeaderBean> {
  private final ObjectDataType objDT;
  private final DT_String strDT;
  private final DT_Map<String, String> strStrMapDT;
  private final DT_DatasetStructureReferenceBean dsrbDT;
  private final DT_List<DatasetStructureReferenceBean, DatasetStructureReferenceBean> dsrbListDT;
  private final DT_List<TextTypeWrapper, Object> ttwListDT;
  private final DT_List<PartyBean, Object> pbListDT;
  private final DT_DATASET_ACTION actionDT;

  public DT_HeaderBean() {
    this.objDT = new ObjectDataType();
    this.strDT = DT_String.getInstance();
    this.strStrMapDT = new DT_Map<>(strDT, strDT);
    this.dsrbDT = new DT_DatasetStructureReferenceBean();
    this.dsrbListDT = new DT_List<>(dsrbDT);
    this.pbListDT = new DT_List<>(objDT);
    this.ttwListDT = new DT_List<>(objDT);
    this.actionDT = new DT_DATASET_ACTION();
  }

  @Override
  public int getMemory(HeaderBean x) {
    int size = 1; // null/object selector

    if (x != null) {
      size += strStrMapDT.getMemory(x.getAdditionalAttributes());
      size += dsrbListDT.getMemory(x.getStructures());
      size += objDT.getMemory(x.getDataProviderReference());
      size += actionDT.getMemory(x.getAction());
      size += strDT.getMemory(x.getId());
      size += strDT.getMemory(x.getDatasetId());
      size += objDT.getMemory(x.getEmbargoDate());
      size += objDT.getMemory(x.getExtracted());
      size += objDT.getMemory(x.getPrepared());
      size += objDT.getMemory(x.getReportingBegin());
      size += objDT.getMemory(x.getReportingEnd());
      size += ttwListDT.getMemory(x.getName());
      size += ttwListDT.getMemory(x.getSource());
      size += pbListDT.getMemory(x.getReceiver());
      size += objDT.getMemory(x.getSender());
      size += 1; // x.isTest()
    }

    return size;
  }

  @Override
  public void write(WriteBuffer buf, HeaderBean x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      strStrMapDT.write(buf, x.getAdditionalAttributes());
      dsrbListDT.write(buf, x.getStructures());
      strDT.write(buf, x.getDataProviderReference() == null ? null : x.getDataProviderReference().getURN());
      actionDT.write(buf, x.getAction());
      strDT.write(buf, x.getId());
      strDT.write(buf, x.getDatasetId());
      objDT.write(buf, x.getEmbargoDate());
      objDT.write(buf, x.getExtracted());
      objDT.write(buf, x.getPrepared());
      objDT.write(buf, x.getReportingBegin());
      objDT.write(buf, x.getReportingEnd());
      ttwListDT.write(buf, x.getName());
      ttwListDT.write(buf, x.getSource());
      pbListDT.write(buf, x.getReceiver());
      objDT.write(buf, x.getSender());
      buf.putVarInt(x.isTest() ? 1 : 0);
    }
  }

  @Override
  public HeaderBean read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    HeaderBean x = null;

    if (!isNull) {
      Map<String, String> additionalAttributes = strStrMapDT.read(buf);
      List<DatasetStructureReferenceBean> structures = dsrbListDT.read(buf);
      String dataProviderReference = strDT.read(buf);
      IURNSingle<DataProviderBean> dpURN = dataProviderReference == null ? null : URN.builder(dataProviderReference).buildSingle(DataProviderBean.class);
      DATASET_ACTION action = actionDT.read(buf);
      String id = strDT.read(buf);
      String datasetId = strDT.read(buf);
      Date embargoDate = (Date)objDT.read(buf);
      Date extracted = (Date)objDT.read(buf);
      Date prepared = (Date)objDT.read(buf);
      Date reportingBegin = (Date)objDT.read(buf);
      Date reportingEnd = (Date)objDT.read(buf);
      List<TextTypeWrapper> name = ttwListDT.read(buf);
      List<TextTypeWrapper> source = ttwListDT.read(buf);
      List<PartyBean> receiver = pbListDT.read(buf);
      PartyBean sender = (PartyBean)objDT.read(buf);
      boolean isTest = (DataUtils.readVarInt(buf) == 1);

      x = new HeaderBeanImpl(additionalAttributes,
                             structures,
                             dpURN,
                             action,
                             id,
                             datasetId,
                             embargoDate,
                             extracted,
                             prepared,
                             reportingBegin,
                             reportingEnd,
                             name,
                             source,
                             receiver,
                             sender,
                             isTest);
    }

    return x;
  }

  @Override
  public HeaderBean[] createStorage(int size) {
    return new HeaderBean[size];
  }
}
