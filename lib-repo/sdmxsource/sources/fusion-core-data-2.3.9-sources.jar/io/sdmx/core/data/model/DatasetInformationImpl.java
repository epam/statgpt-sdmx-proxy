package io.sdmx.core.data.model;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.superbeans.SuperBeansUtil;

public class DatasetInformationImpl implements DatasetInformation {
	private DATASET_ACTION action;
	private Date transactionValidity;
	
	private Map<String, AttributeBean> seriesAttributes = new HashMap<>();
	private Map<String, Map<String, AttributeBean>> groupAttributes = new HashMap<>();
	private Map<String, AttributeBean> obsAttributes = new HashMap<>();
	private Map<String, DimensionBean> dimensionMap = new HashMap<>();

	private boolean isTimeSeries;
	private String dimensionAtObservation;
	
	private DataStructureSuperBean dsdSuperBean;

	private Map<String, AttributeSuperBean> seriesAttributesSB = new HashMap<>();
	private Map<String, Map<String, AttributeSuperBean>> groupAttributesSB = new HashMap<>();  //GROUP ID to Attribute Id to Attribute
	private Map<String, AttributeSuperBean> datasetAttributesSB = new HashMap<>();
	private Map<String, AttributeSuperBean> obsAttributesSB = new HashMap<>();
	private Map<String, DimensionSuperBean> dimensionMapSB = new HashMap<>();
	
	private int dimSize = 0;
	
	private IDatasetStructures datasetStructures;
	
	public DatasetInformationImpl(DatasetHeaderBean headerBean,
			 IDatasetStructures datasetStructures,
			  SdmxSuperBeanRetrievalManager superRetrieval,
			  IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager,
			  DATASET_ACTION datasetAction,
			  Date transactionTime) {
		this.datasetStructures = datasetStructures;
		setProperties(headerBean, superRetrieval, constraintPrefixDetailRetreivalManager, datasetAction, transactionTime);
	}

	public DatasetInformationImpl(DatasetHeaderBean headerBean,
								  DataStructureBean dsd,
								  DataflowBean dataflow,
								  ProvisionAgreementBean pa,
								  SdmxSuperBeanRetrievalManager superRetrieval,
								  IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager,
								  DATASET_ACTION datasetAction,
								  Date transactionTime) {
		Objects.requireNonNull(dsd, "Can not construct DataSetInformation, the DataStructureBean is required");
		Objects.requireNonNull(superRetrieval, "Can not construct DataSetInformation, the SdmxSuperBeanRetrievalManager is required");
		this.datasetStructures = new DatasetStructures(dsd, dataflow, pa, null);
		setProperties(headerBean, superRetrieval, constraintPrefixDetailRetreivalManager, datasetAction, transactionTime);
	}
	
	
	private void setProperties(DatasetHeaderBean headerBean,
			  SdmxSuperBeanRetrievalManager superRetrieval,
			  IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager,
			  DATASET_ACTION datasetAction,
			  Date transactionTime) {
		Objects.requireNonNull(superRetrieval, "Can not construct DataSetInformation, the SdmxSuperBeanRetrievalManager is required");
		
		DataStructureBean dsd = this.datasetStructures.getDataStructure();
		
		if (datasetAction == null) {
			this.action = DATASET_ACTION.INFORMATION;
		} else {
			this.action = datasetAction;
		}
		this.transactionValidity = transactionTime;
		if(this.transactionValidity == null) {
			this.transactionValidity = new Date();
		}
		
		boolean timeAtObs = dsd.getTimeDimension() != null && dsd.getMeasureList() != null;
		
		calculateBeanInformation(headerBean, timeAtObs);
		
		
		Map<String, String> replaceCodelists = constraintPrefixDetailRetreivalManager == null ? null : constraintPrefixDetailRetreivalManager.getRemovePrefixDetails(datasetStructures.getConstrainable());
		if (superRetrieval != null) {
			getSuperBeans(timeAtObs, replaceCodelists, superRetrieval);
		}
		
		seriesAttributes = Collections.unmodifiableMap(seriesAttributes);
		groupAttributes = Collections.unmodifiableMap(groupAttributes);
		obsAttributes = Collections.unmodifiableMap(obsAttributes);
		dimensionMap = Collections.unmodifiableMap(dimensionMap);
		seriesAttributesSB = Collections.unmodifiableMap(seriesAttributesSB);
		groupAttributesSB = Collections.unmodifiableMap(groupAttributesSB);
		obsAttributesSB = Collections.unmodifiableMap(obsAttributesSB);
		datasetAttributesSB = Collections.unmodifiableMap(datasetAttributesSB);
		dimensionMapSB = Collections.unmodifiableMap(dimensionMapSB);
	}
	
	private void calculateBeanInformation(DatasetHeaderBean headerBean, boolean timeAtObs) {
		DataStructureBean dsd = getDatasetStructures().getDataStructure();
		dimSize = 0;
		for(DimensionBean dimension : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			dimensionMap.put(dimension.getId(), dimension);
			dimSize++;
		}
		if(timeAtObs == false && dsd.getTimeDimension() != null) {
			dimensionMap.put(dsd.getTimeDimension().getId(), dsd.getTimeDimension());
		}
		
		if(headerBean == null) {
			//assume time series
			DatasetStructureReferenceBean datasetStructureReferenceBean = new DatasetStructureReferenceBeanImpl(getDatasetStructures().getConstrainable().getURN());
			headerBean = new DatasetHeaderBeanImpl(DimensionBean.TIME_DIMENSION_FIXED_ID, action, datasetStructureReferenceBean);
		}
		isTimeSeries = headerBean.isTimeSeries();
		dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
		if(headerBean.getDataStructureReference() != null) {
			dimensionAtObservation = headerBean.getDataStructureReference().getDimensionAtObservation();
		}
		
		for(AttributeBean att : dsd.getDimensionGroupAttributes()) {
			if(!isTimeSeries && att.getDimensionReferences().contains(dimensionAtObservation)) {
				obsAttributes.put(att.getId(), att);
			} else {
				seriesAttributes.put(att.getId(), att);
			}
		}
		
	
		for(AttributeBean att : dsd.getObservationAttributes()) {
			obsAttributes.put(att.getId(), att);
		}
		
		if(!isTimeSeries && !dimensionAtObservation.equals("AllDimensions")) {
			//Cross sectional is expecting one less dimension at the series key level
			dimSize = dimSize - 1;
		}
		for(GroupBean group : dsd.getGroups()) {
			Map<String, AttributeBean> groupAttributes = new HashMap<>();
			for(AttributeBean attribute : dsd.getGroupAttributes(group.getId(), true)) {
				groupAttributes.put(attribute.getId(), attribute);
			}
			this.groupAttributes.put(group.getId(), groupAttributes);
		}
	}
	
	private void getSuperBeans(boolean timeAtObs, Map<String, String> replaceCodelists, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		DataStructureBean dsd = getDatasetStructures().getDataStructure();
		dsdSuperBean = superBeanRetrievalManager.getDataStructureSuperBean(dsd.getURN());
		dsdSuperBean = SuperBeansUtil.removeCodeIdPrefixes(dsdSuperBean, replaceCodelists);
		
		for(DimensionSuperBean dimension : dsdSuperBean.getDimensions()) {
			if(!dimension.getBuiltFrom().isTimeDimension()) {
				dimensionMapSB.put(dimension.getId(), dimension);
			}
		}
		if(timeAtObs == false && dsd.getTimeDimension() != null) {
			dimensionMapSB.put(dsd.getTimeDimension().getId(), dsdSuperBean.getTimeDimension());
		}
		for(AttributeSuperBean att : dsdSuperBean.getDatasetAttributes()) {
			datasetAttributesSB.put(att.getId(), att);
		}
		for(AttributeSuperBean att : dsdSuperBean.getSeriesAttributes()) {
			if(!isTimeSeries && att.getBuiltFrom().getDimensionReferences().contains(dimensionAtObservation)) {
				obsAttributesSB.put(att.getId(), att);
			} else {
				seriesAttributesSB.put(att.getId(), att);
			}
		}
		for(AttributeSuperBean att : dsdSuperBean.getObservationAttributes()) {
			obsAttributesSB.put(att.getId(), att);
		}
		for(GroupSuperBean group : dsdSuperBean.getGroups()) {
			Map<String, AttributeSuperBean> groupMap = new HashMap<>();
			groupAttributesSB.put(group.getId(), groupMap);
			for(AttributeSuperBean att : dsdSuperBean.getGroupAttributes(group.getId(), true)) {
				groupMap.put(att.getId(), att);
			}
		}
	}
	
	
	
	@Override
	public DATASET_ACTION getAction() {
		return action;
	}

	@Override
	public Date getTransactionValidity() {
		return transactionValidity;
	}

	@Override
	public IDatasetStructures getDatasetStructures() {
		return datasetStructures;
	}

	@Override
	public Map<String, AttributeSuperBean> getSeriesAttributesSuperBeans() {
		return seriesAttributesSB;
	}

	@Override
	public Map<String, Map<String, AttributeSuperBean>> getGroupAttributesSuperBeans() {
		return groupAttributesSB;
	}

	@Override
	public Map<String, AttributeSuperBean> getDatasetAttributesSuperBeans() {
		return datasetAttributesSB;
	}
	
	@Override
	public Map<String, AttributeSuperBean> getObsAttributesSuperBeans() {
		return obsAttributesSB;
	}

	@Override
	public Map<String, DimensionSuperBean> getDimensionMapSuperBeans() {
		return dimensionMapSB;
	}

	@Override
	public Map<String, DimensionBean> getDimensionMap() {
		return dimensionMap;
	}
	@Override
	public int getDimSize() {
		return dimSize;
	}
	@Override
	public boolean isTimeSeries() {
		return isTimeSeries;
	}
	@Override
	public String getDimensionAtObservation() {
		return dimensionAtObservation;
	}
	@Override
	public DataStructureSuperBean getDsdSuperBean() {
		return dsdSuperBean;
	}
}