package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.im.header.PartyBeanImpl;

public class PartyBeanSerializer extends Serializer<PartyBean> {
	private static final PartyBeanSerializer INSTANCE = new PartyBeanSerializer();
	private PartyBeanSerializer() {}

	public static PartyBeanSerializer getInstance() {
		return INSTANCE;
	}

	@Override
	public void write(Kryo kryo, Output output, PartyBean object) {
		kryo.writeObject(output, object == null ? -1 : 1);  
		if(object != null) {
			kryo.writeObjectOrNull(output, object.getId(), String.class);
			kryo.writeObject(output, object.getContacts(), ContactBeanListSerializer.getInstance());
			kryo.writeObject(output, object.getName(), TextTypeWrapperListSerializer.getInstance());
			kryo.writeObjectOrNull(output, object.getTimeZone(), String.class);
		}
	}

	@Override
	public PartyBean read(Kryo kryo, Input input, Class<? extends PartyBean> type) {
		boolean isNull = kryo.readObject(input, Integer.class) == -1;
		if(isNull) {
			return null;
		}
		String id = kryo.readObjectOrNull(input, String.class);
		List<ContactBean> contacts = kryo.readObject(input, List.class, ContactBeanListSerializer.getInstance());
		List<TextTypeWrapper> name = kryo.readObject(input, List.class, TextTypeWrapperListSerializer.getInstance());
		String timezone = kryo.readObjectOrNull(input, String.class);
		return new PartyBeanImpl(name, id, contacts, timezone);
	}
}
