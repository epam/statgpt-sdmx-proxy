package io.sdmx.core.data.api.manager;

import io.sdmx.api.sdmx.engine.DataReaderEngine;


/**
 * Manages the persistence of data obtained from a DataReaderEngine
 * @author Matt Nelson
 *
 */
public interface DataPersistenceManager {

	/**
	 * Persists the data obtainable from the DataReaderEngine
	 * 
	 * @param dataReader - the reader to read the data in
	 */
	void persist(DataReaderEngine dataReader);
	
}
