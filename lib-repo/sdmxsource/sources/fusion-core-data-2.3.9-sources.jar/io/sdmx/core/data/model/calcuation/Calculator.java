// Output created by jacc on Tue Nov 14 13:38:54 GMT 2017
package io.sdmx.core.data.model.calcuation;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.core.data.api.model.calculation.ICalculationFunction;
import io.sdmx.core.data.model.calcuation.functions.PCTOF;
import io.sdmx.utils.core.expression.Exp;

/**
 *  Taken from http://web.cecs.pdx.edu/~mpj/jacc/
 *  
 *  http://web.cecs.pdx.edu/~mpj/jacc/simpleCalc.jacc
 *  
 *  Note this is not thread safe
 *  
 *  The basic structure of a jacc input file is as follows:
	. . . directives section . . .
	%%
	. . . rules section . . .
	%%
	. . . additional code section . . .
 * 
 *  //Built from JACC using this template code
 *  // To compile and run this program using jacc and Sun's JDK:
	//
	//    jacc.jar simpleCalc.jacc
	//    javac Calc.java CalcTokens.java
	//    java  Calc
	//     ... enter arithmetic expressions ... hit EOF to terminate
	//
	
	%package   io.sdmx.core.data.model.calcuation
	%{
	import io.sdmx.api.exception.SdmxSemmanticException;
	%}
	%class     Calculator
	%interface CalculatorTokens
	%semantic  double : yylval
	%get       token
	%next      yylex()
	
	%token '+' '-' '*' '/' '(' ')' ';' NUMBER '.'
	%left  '+' '-'
	%left  '*' '/'
	
	%%
	
	prog : prog ';' expr    { result = $3; }
	     | expr             { result = $1; }
	     ;
	expr : expr '+' expr	   { $$ = $1 + $3; }
	     | expr '-' expr	   { $$ = $1 - $3; }
	     | expr '*' expr	   { $$ = $1 * $3; }
	     | expr '/' expr	   { $$ = $1 / $3; }
	     | '(' expr ')'        { $$ = $2; }
	     | NUMBER             { $$ = $1; }
	     ;
	
	%%

	private void yyerror(String msg) {
		throw new SdmxSemmanticException("Illegal Equation '"+expression+"': "+msg);
	}

	private void nextChar() {
		previousChar = c;
		if(cIdx >= expression.length()) {
			c = -1;
		} else {
			c = expression.charAt(cIdx);
			cIdx++;
		}
	}

	int token;
	double yylval;
	double result;
	int previousChar = Integer.MIN_VALUE;
	int yylex() {
		return yylex(false);
	}
	
	int yylex(boolean negate) {
		for (;;) {
			// Skip whitespace
			while (c==' ' || c=='\n' || c=='\t' || c=='\r') {
				nextChar();
			}
			if (c<0) {
				return (token=ENDINPUT);
			}
			switch (c) {
			case '+' : nextChar();
			return token='+';
			case '-' : 
				int prev = previousChar;
				nextChar();
				//Special case, when the symbol is '-' it may indicate 'subtract' or it could be a negative number
				//If the previous character is ) then it is subtract, if the '-' is followed by a number then it is a negative number
				if(prev != 41) {
					if (Character.isDigit((char)c)) {
						switch(prev) {
						case Integer.MIN_VALUE:
						case '+' :
						case '-' :
						case '*' :
						case '/' :
						case '(' :
						case ')' :
							return yylex(true);
						}
					}
				}
				
			return token='-';
			case '*' : nextChar();
			return token='*';
			case '/' : nextChar();
			return token='/';
			case '(' : nextChar();
			return token='(';
			case ')' : nextChar();
			return token=')';
			case ';' : nextChar();
			return token=';';
			default  : if (Character.isDigit((char)c)) {
				String n = "";
				do {
					if( c == '.') {
						n += "."; 
					} else if( c == 'E') {
						n += "E"; 
					} else {
						n += Character.getNumericValue(c); 
					}
					nextChar();
				} while (Character.isDigit((char)c) || c == '.' || c == 'E');
				try {
					yylval = Double.parseDouble(n);
					if(negate == true) {
						yylval = yylval *-1;
					}
				} catch(Throwable th) {
					throw new SdmxSemmanticException("Illegal Double: "+n);
				}
				return token=NUMBER;
			} else {
				yyerror("Illegal character "+Character.toString((char)c));
				nextChar();
			}
			}
		}
	}

	public synchronized Double execute(String calc) {
		this.expression = calc.trim();
		this.cIdx = 0;
		nextChar(); // prime the character input stream
		yylex();    // prime the token input stream
		parse();    // parse the input
		c = Integer.MIN_VALUE;
		previousChar = Integer.MIN_VALUE;
		return result;
	}
 * @author Matt Nelson
 *
 * Note : some manual modifications to the built code was introduced to support issues where -10 can either mean negative ten or subtract 10 @see yylex(negate) 
 *
 *
 */
public class Calculator  {
	// Setting the Precision for rounding used in the divisor method.
	// 14 was chosen as this appeared to be the value used before BigDecimal was introduced, when a simple divide operation (/) was performed
	private static final int PRECISION = 14;
	
	private static final int ENDINPUT = 0;
	private static final int NUMBER = 1;
	private static final int error = 2;
	    // '(' (code=40)
	    // ')' (code=41)
	    // '*' (code=42)
	    // '+' (code=43)
	    // '-' (code=45)
	    // '.' (code=46)
	    // '/' (code=47)
	    // ';' (code=59)
	    
	private int yyss = 100;
	private int yytok;
	private int yysp = 0;
	private int[] yyst;
	protected int yyerrno = (-1);
	private BigDecimal[] yysv;
	private BigDecimal yyrv;

	private int c = Integer.MIN_VALUE; //The current char being processed in the expression
	private String expression;  //The expresssion to execute
	private int cIdx;  //The index the parser is in the current expression
	
	private BigDecimal result;
	
	private int decimals = -1;
	private RoundingMode roundingMode = RoundingMode.HALF_UP;
	
	
	public Calculator(int decimals, RoundingMode rm) {
		this.decimals = decimals;
		if(rm != null) {
			this.roundingMode = rm;
		}
	}
	
	public Calculator() {}

	private static final Map<String, ICalculationFunction> FUNCTION_MAP;
	public static void registerFunction(ICalculationFunction calFunction) {
		FUNCTION_MAP.put(calFunction.functionName().toUpperCase(), calFunction);
	}
	
	static {
		FUNCTION_MAP = new HashMap<>();
		PCTOF.register();
	}

	public boolean parse() {
		int yyn = 0;
		yysp = 0;
		yyst = new int[yyss];
		yysv = new BigDecimal[yyss];
		yytok = (token
				);
		loop:
			for (;;) {
				switch (yyn) {
				case 0:
					yyst[yysp] = 0;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 17:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 1:
					yyst[yysp] = 1;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 18:
					switch (yytok) {
					case ENDINPUT:
						yyn = 34;
						continue;
					case ';':
						yyn = 5;
						continue;
					}
					yyn = 37;
					continue;

				case 2:
					yyst[yysp] = 2;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 19:
					yyn = yys2();
					continue;

				case 3:
					yyst[yysp] = 3;
					yysv[yysp] = (yylval);
					yytok = (yylex());
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 20:
					switch (yytok) {
					case '.':
					case '(':
					case NUMBER:
					case error:
						yyn = 37;
						continue;
					}
					yyn = yyr8();
					continue;

				case 4:
					yyst[yysp] = 4;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 21:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 5:
					yyst[yysp] = 5;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 22:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 6:
					yyst[yysp] = 6;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 23:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 7:
					yyst[yysp] = 7;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 24:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 8:
					yyst[yysp] = 8;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 25:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 9:
					yyst[yysp] = 9;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 26:
					switch (yytok) {
					case NUMBER:
						yyn = 3;
						continue;
					case '(':
						yyn = 4;
						continue;
					}
					yyn = 37;
					continue;

				case 10:
					yyst[yysp] = 10;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 27:
					switch (yytok) {
					case '*':
						yyn = 6;
						continue;
					case '+':
						yyn = 7;
						continue;
					case '-':
						yyn = 8;
						continue;
					case '/':
						yyn = 9;
						continue;
					case ')':
						yyn = 16;
						continue;
					}
					yyn = 37;
					continue;

				case 11:
					yyst[yysp] = 11;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 28:
					yyn = yys11();
					continue;

				case 12:
					yyst[yysp] = 12;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 29:
					switch (yytok) {
					case '.':
					case '(':
					case NUMBER:
					case error:
						yyn = 37;
						continue;
					}
					yyn = yyr5();
					continue;

				case 13:
					yyst[yysp] = 13;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 30:
					yyn = yys13();
					continue;

				case 14:
					yyst[yysp] = 14;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 31:
					yyn = yys14();
					continue;

				case 15:
					yyst[yysp] = 15;
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 32:
					switch (yytok) {
					case '.':
					case '(':
					case NUMBER:
					case error:
						yyn = 37;
						continue;
					}
					yyn = yyr6();
					continue;

				case 16:
					yyst[yysp] = 16;
					yysv[yysp] = (yylval
							);
					yytok = (yylex()
							);
					if (++yysp>=yyst.length) {
						yyexpand();
					}
				case 33:
					switch (yytok) {
					case '.':
					case '(':
					case NUMBER:
					case error:
						yyn = 37;
						continue;
					}
					yyn = yyr7();
					continue;

				case 34:
					return true;
				case 35:
					yyerror("stack overflow");
				case 36:
					return false;
				case 37:
					yyerror("syntax error");
					return false;
				}
			}
	}

	protected void yyexpand() {
		int[] newyyst = new int[2*yyst.length];
		BigDecimal[] newyysv = new BigDecimal[2*yyst.length];
		for (int i=0; i<yyst.length; i++) {
			newyyst[i] = yyst[i];
			newyysv[i] = yysv[i];
		}
		yyst = newyyst;
		yysv = newyysv;
	}

	private int yys2() {
		switch (yytok) {
		case '*':
			return 6;
		case '+':
			return 7;
		case '-':
			return 8;
		case '/':
			return 9;
		case ENDINPUT:
		case ';':
			return yyr2();
		}
		return 37;
	}

	private int yys11() {
		switch (yytok) {
		case '*':
			return 6;
		case '+':
			return 7;
		case '-':
			return 8;
		case '/':
			return 9;
		case ENDINPUT:
		case ';':
			return yyr1();
		}
		return 37;
	}

	private int yys13() {
		switch (yytok) {
		case '(':
		case '.':
		case NUMBER:
		case error:
			return 37;
		case '*':
			return 6;
		case '/':
			return 9;
		}
		return yyr3();
	}

	private int yys14() {
		switch (yytok) {
		case '(':
		case '.':
		case NUMBER:
		case error:
			return 37;
		case '*':
			return 6;
		case '/':
			return 9;
		}
		return yyr4();
	}

	private int yyr1() { // prog : prog ';' expr
		{ result = (yysv[yysp-1]); }
		yysv[yysp-=3] = yyrv;
		return 1;
	}

	private int yyr2() { // prog : expr
		{ result = yysv[yysp-1]; }
		yysv[yysp-=1] = yyrv;
		return 1;
	}

	private int yyr3() { // expr : expr '+' expr
		{ yyrv = (yysv[yysp-3]).add((yysv[yysp-1]));  }
		yysv[yysp-=3] = yyrv;
		return yypexpr();
	}

	private int yyr4() { // expr : expr '-' expr
		{ yyrv = (yysv[yysp-3]).subtract((yysv[yysp-1]));  } 
		yysv[yysp-=3] = yyrv;
		return yypexpr();
	}

	private int yyr5() { // expr : expr '*' expr
		{ yyrv = (yysv[yysp-3]).multiply((yysv[yysp-1]));  }
		yysv[yysp-=3] = yyrv;
		return yypexpr();
	}

	private int yyr6() { // expr : expr '/' expr
		{ yyrv = (yysv[yysp-3]).divide(yysv[yysp-1], PRECISION, RoundingMode.HALF_UP);  } 
		yysv[yysp-=3] = yyrv;
		return yypexpr();
	}

	private int yyr7() { // expr : '(' expr ')'
		{ yyrv = yysv[yysp-2]; }
		yysv[yysp-=3] = yyrv;
		return yypexpr();
	}

	private int yyr8() { // expr : NUMBER
		{ yyrv = yysv[yysp-1]; }
		yysv[yysp-=1] = yyrv;
		return yypexpr();
	}

	private int yypexpr() {
		switch (yyst[yysp-1]) {
		case 8: return 14;
		case 7: return 13;
		case 6: return 12;
		case 5: return 11;
		case 4: return 10;
		case 0: return 2;
		default: return 15;
		}
	}

	protected String[] yyerrmsgs = {
	};


	private void yyerror(String msg) {
		throw new SdmxSemmanticException("Illegal Equation '"+expression+"': "+msg);
	}

	/** 
	 * Read a single input character from standard input.
	 */
	private void nextChar() {
		previousChar = c;
		if(cIdx >= expression.length()) {
			c = -1;
		} else {
			c = expression.charAt(cIdx);
			cIdx++;
		}
	}

	int token;
	BigDecimal yylval;

	/** Read the next token and return the
	 *  corresponding integer code.
	 */
	int previousChar = Integer.MIN_VALUE;
	int yylex() {
		return yylex(false);
	}
	
	int yylex(boolean negate) {
		for (;;) {
			// Skip whitespace
			while (c==' ' || c=='\n' || c=='\t' || c=='\r') {
				nextChar();
			}
			if (c<0) {
				return (token=ENDINPUT);
			}
			switch (c) {
			case '+' : nextChar();
			return token='+';
			case '-' : 
				int prev = previousChar;
				nextChar();
				//Special case, when the symbol is '-' it may indicate 'subtract' or it could be a negative number
				//If the previous character is ) then it is subtract, if the '-' is followed by a number then it is a negative number
				if(prev != 41) {
					if (Character.isDigit((char)c)) {
						switch(prev) {
						case Integer.MIN_VALUE:
						case '+' :
						case '-' :
						case '*' :
						case '/' :
						case '(' :
						case ')' :
							return yylex(true);
						}
					}
				}
				
			return token='-';
			case '*' : nextChar();
			return token='*';
			case '/' : nextChar();
			return token='/';
			case '(' : nextChar();
			return token='(';
			case ')' : nextChar();
			return token=')';
			case ';' : nextChar();
			return token=';';
			default  : if (Character.isDigit((char)c)) {
				String n = "";
				do {
					if( c == '.') {
						n += "."; 
					} else if( c == 'E') {
						n += "E"; 
					} else {
						n += Character.getNumericValue(c); 
					}
					nextChar();
				} while (Character.isDigit((char)c) || c == '.' || c == 'E');
				try {
					yylval = new BigDecimal(n);
					if(negate == true) {
						yylval =  yylval.negate(); // *-1;
					}
				} catch(Throwable th) {
					throw new SdmxSemmanticException("Illegal Double: "+n);
				}
				return token=NUMBER;
			} else {
				yyerror("Illegal character "+Character.toString((char)c));
				nextChar();
			}
			}
		}
	}
	
	private static final char[] TOKENS  = new char[] {"+".toCharArray()[0], "-".toCharArray()[0], "*".toCharArray()[0], "/".toCharArray()[0]};
	
	public synchronized BigDecimal executeAsBigDecimal(String calc) {
		this.expression = parseFunctions(calc);
		this.cIdx = 0;
		nextChar(); // prime the character input stream
		yylex();    // prime the token input stream
		parse();    // parse the input
		c = Integer.MIN_VALUE;
		previousChar = Integer.MIN_VALUE;
		if(this.decimals >= 0) {
			result = result.setScale(decimals, roundingMode);
		}
		
		return result;
	}

	public synchronized Double execute(String calc) {
		return executeAsBigDecimal(calc).doubleValue();
	}
	
	private String parseFunctions(String calc) {
		Exp exp = Exp.get(TOKENS).blockCopy("(".toCharArray()[0], ")".toCharArray()[0]).trim().parse(calc);
		StringBuilder sb = new StringBuilder();
		
		ICalculationFunction currentFunction = null;
		for(int i=0; i < exp.size(); i++) {
			String block = exp.getBlock(i);
			int level = exp.getLevel(i);
			if(i > 0 && level == 0 && currentFunction != null) {
				Exp argsExp = Exp.get(",".toCharArray()[0]).setSupportLevels(false).parse(block);
				String[] args = new String[(argsExp.size()+1)/2];
				for(int argIdx=0; argIdx < argsExp.size(); argIdx++) {
					if(argIdx % 2 == 0) {
						args[argIdx / 2] = argsExp.getBlock(argIdx);
					}
				}
				if(args.length < currentFunction.minArguments()) {
					throw new SdmxSemmanticException("Argument count "+args.length+" is less then minimum of "+currentFunction.maxArguments()+" for calulation function '"+currentFunction.functionName()+"'");
				}
				if(args.length > currentFunction.maxArguments()) {
					throw new SdmxSemmanticException("Argument count "+args.length+" exceeds maximum of "+currentFunction.maxArguments()+" for calulation function '"+currentFunction.functionName()+"'");
				}
				sb.append(currentFunction.rewrite(args));
			} else {
				currentFunction = FUNCTION_MAP.get(block.toUpperCase());
				if(currentFunction == null) {
					if(level == 0) {
						sb.append("("+parseFunctions(block)+")");
					} else {
						sb.append(block);
					}
				}
			}
		}
		return sb.toString();
	}
	
}
