package io.sdmx.core.data.api.model.calculation;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.sdmx.api.error.IDataErrorContainer;

/**
 * The result of a data validation for a specific dataset
 */
public interface DataValidationResult extends IDataErrorContainer {

	/**
	 * Protects the readable data location, so on close the RDL will not be closed
	 * @param bool
	 */
	void protect(boolean bool);
	
	/**
	 * Full validation
	 */
	void validate();
	
	/**
	 * Re-validates the data based on the new Provision or Dataflow
	 * @param sRef
	 */
	void reValidate(IURNSingle<? extends IDSDRelatedBean> sRef);
	
	/**
	 * Performs a mapping on the underlying dataset based on the provided DataStructureMap.  The data is revalidated based on the 
	 * mapped dataset, DataReaderEngine, Dataflow, Data Structure, and Provision Agreements are updated based on the Mapped dataset
	 * 
	 * @param map the map to use, or null can be passed to unmap.  In the case of unmapping, the original dataset is read to reset the variable
	 */
	void map(MappingRules map);
	
	/**
	 * @param sRef the reference of the DSD or Dataflow or Structure Map to use
	 * @return MappingRules based on the map to DSD or Dataflow defined by the Structure Reference, or if the sRef refers to a StructureMap, uses this to build the rules
	 */
	MappingRules getMappingRules(IURNSingle<? extends IStructureMapRelatedBean> sRef);
	
	/**
	 * Returns the dataset header
	 * @return
	 */
	DatasetHeaderBean getHeader();
	
	/**
	 * Returns the data Reader engine, based on the currently assigned structures
	 * @return
	 */
	DataReaderEngine getDataReaderEngine();
	
	
	/**
	 * Returns the dataset, in SDMX format
	 * @return
	 */
	ReadableDataLocation getReadableDataLocation();
	
	
	/**
	 * @return the datainformation on groups, keys, observations et
	 */
	DataInformation getDataInformation();
	
	/**
	 * Returns a count of the groups in the dataset
	 * @return
	 */
	int getGroups();

	/**
	 * Returns a count of the keys in the dataset
	 * @return
	 */
	int getKeys();

	/**
	 * Returns a count of the observations in the dataset
	 * @return
	 */
	int getObservations();

	/**
	 * Returns a count of the series which could not be mapped
	 * @return
	 */
	int getUnmappedKeysCount();
	
	/**
	 * Returns the report period details, if there were any captured in the validation process
	 * @return
	 */
	Map<TIME_FORMAT, SdmxPeriod> getReportingPeriods();
	
	/**
	 * returns true if the validaiton result includes information on the reported periods for each frequency
	 * @return
	 */
	boolean hasReportedPeriodDetails();
	
	
	/**
	 * returns true if the dataset has any errors
	 * @return
	 */
	boolean hasErrors();
	
	/**
	 * Returns the dataflow referenced by the underlying dataset, this will be what the DataReaderEngine is reading data for if isMapped is false,
	 * @return Dataflow or null if there is no Dataflow assigned
	 */
	DataflowBean getFlow();
	
	/**
	 * Returns the DataStructureBean referenced by the underlying dataset, this will be what the DataReaderEngine is reading data for if isMapped is false
	 * @return DSD this can not be null
	 */
	DataStructureBean getDsd();
	
	/**
	 * Returns true if the data being read has had mapping applied, in which case the mapped Data Structure will be available, and possible the mapped dataflow
	 * @return
	 */
	boolean isMapped();
	
	/**
	 * Returns the dataflow the DataReaderEngine is reading data for if isMapped is true, or null if there is no Dataflow defined in the mapping
	 * @return
	 */
	DataflowBean getMappedFlow();
	
	/**
	 * Returns the DataStructureBean the DataReaderEngine is reading data for if isMapped is true
	 * @return
	 */
	DataStructureBean getMappedDsd();
	
	/**
	 * Returns the ProvisionAgreementBean the DataReaderEngine is reading data for, or null if there is no ProvisionAgreementBean assigned
	 * @return
	 */
	ProvisionAgreementBean getProvision();
	
	/**
	 * Closes off all resources
	 */
	void close();
	
	/**
	 * @return whether the errors in this report prevent Publication
	 */
	boolean preventsPublication();

	/**
     * @return whether the errors in this report prevent Conversion
     */
	boolean preventsConversion();

}
