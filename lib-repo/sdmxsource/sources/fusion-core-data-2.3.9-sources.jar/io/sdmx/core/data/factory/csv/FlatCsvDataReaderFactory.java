package io.sdmx.core.data.factory.csv;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.engine.reader.FlatDataReaderEngine;
import io.sdmx.core.data.model.format.FlatDataFormatCSV;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.core.sdmx.error.DataReadException;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Can create a DataReaderEngine for "Flat CSV" - not an official SDMX standard
 */
public class FlatCsvDataReaderFactory implements DataReaderFactory, IFusionSingleton {

    private List<DataErrorCategory> throwableErrors;
    private static FlatCsvDataReaderFactory INSTANCE;

    //Private constructor - lazy load instance
    public static FlatCsvDataReaderFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FlatCsvDataReaderFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public static FlatCsvDataReaderFactory registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }

    private FlatCsvDataReaderFactory() {
    }

    
    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
            ReadableDataLocation sourceData,
            DataStructureBean dsd,
            DataflowBean dataflowBean,
            ProvisionAgreementBean provisionAgreement,
            DataValidationErrorHandler handler) {

        // FR-5020: BIS stated that this should only cope with CSV where the format is explicitly "Data-Format: csv"
        if (format == null || !(format instanceof FlatDataFormatCSV)) {
            return null;
        }

        CSVDataReadableDataLocation csvData;
        if (sourceData instanceof CSVDataReadableDataLocation) {
            csvData = (CSVDataReadableDataLocation)sourceData;
        } else {
            // Convert the supplied source into a CSVDataReadableDataLocation
            DELIMITER delimiter;
            if (format != null && format instanceof FlatDataFormatCSV) {
                delimiter = ((FlatDataFormatCSV)format).getDelimiter();
            } else {
                delimiter = DELIMITER.COMMA;
            }
            csvData = new CSVDataReadableDataLocation(sourceData, delimiter, 0, null);
        }

        return new FlatDataReaderEngine(csvData, dsd, dataflowBean, provisionAgreement);
    }

    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
            ReadableDataLocation sourceData,
            SdmxBeanRetrievalManager retrievalManager,
            DataValidationErrorHandler handler) {
        // FR-5020: BIS stated that this should only cope with CSV where the format is explicitly "Data-Format: csv"

        // The input must be a CSVDataReadableDataLocation since we need the structures from it. If not it cannot be processed.
        if (!(sourceData instanceof CSVDataReadableDataLocation)) {
            return null;
        }

        if (format != null && !(format instanceof FlatDataFormatCSV)) {
            return null;
        }

        CSVDataReadableDataLocation csvData = (CSVDataReadableDataLocation)sourceData;
        return new FlatDataReaderEngine(csvData, csvData.getStructures());
    }

    @Override
    public String getOverride() {
        return null;
    }

    @Override
    public List<DataErrorCategory> getThrowableErrors() {
        if (throwableErrors == null) {
            List<DataErrorCategory> throwableErrors = new ArrayList<>();
            throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INCONSISTENT_DATASET_ATTR, "Inconsistent Dataset Attributes",
                    "Ensures that the Dataset Attributes reported on each line are consistent with each other. If set to Ignore, no error will be reported if differing lines in the CSV report different values for Dataset Attributes.") );
            this.throwableErrors = throwableErrors;
        }

        return throwableErrors;
    }

    @Override
    public String getId() {
        return "Flat-CSV";
    }

    @Override
    public String getName() {
        return "Flat-CSV";
    }

    @Override
    public int getPriority() {
        return 10;
    }
}
