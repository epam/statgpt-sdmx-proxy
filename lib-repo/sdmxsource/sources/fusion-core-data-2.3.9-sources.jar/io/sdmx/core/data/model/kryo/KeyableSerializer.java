package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.KeyableImpl;

public class KeyableSerializer extends AttributableSerializer<Keyable> {
	private DataflowBean dataflow;
	private DataStructureBean dsd;

	public KeyableSerializer(DataflowBean dataflow, DataStructureBean dsd) {
		this.dataflow = dataflow;
		this.dsd = dsd;
	}

	public void setDataflow(DataflowBean dataflow) {
		this.dataflow = dataflow;
	}

	public void setDsd(DataStructureBean dsd) {
		this.dsd = dsd;
	}

	/**
	 * Writes: [size]|key|[size]|attr|size|annotations
	 */
	public void write(Kryo kryo, Output output, Keyable x) {
		super.write(kryo, output, x);
		kryo.writeObjectOrNull(output, x.getGroupName(), String.class);
		kryo.writeObject(output, x.getKey(), KeyValueListSerializer.getInstance());  
	}
	
	@Override
	protected AttributableBuilder<Keyable> getBuilder(Kryo kryo, Input input) {
		String groupId =  kryo.readObjectOrNull(input, String.class);
		List<KeyValue> key = kryo.readObject(input, List.class, KeyValueListSerializer.getInstance());
		
		return KeyableImpl.builder(dsd).
						dataflow(dataflow).
						group(groupId).
						key(key);
	}

}