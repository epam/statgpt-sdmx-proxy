package io.sdmx.core.data.engine.writer;

import java.util.Collection;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * A proxy on multiple flat data writers - a call to one is a call to all
 */
public class FlatDataWriterEngineMultiProxy implements IFlatDataWriterEngine {
	private Collection<IFlatDataWriterEngine> proxy;
	
	public FlatDataWriterEngineMultiProxy(Collection<IFlatDataWriterEngine> proxy) {
		this.proxy = proxy;
	}

	@Override
	public void writeHeader(HeaderBean header) {
		for(IFlatDataWriterEngine currentProxyWriter : proxy) {
			currentProxyWriter.writeHeader(header);
		}
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		for(IFlatDataWriterEngine currentProxyWriter : proxy) {
			currentProxyWriter.startDataset(header, annotations);
		}
	}

	@Override
	public void writeRow(IDataRow row) {
		for(IFlatDataWriterEngine currentProxyWriter : proxy) {
			currentProxyWriter.writeRow(row);
		}
	}

	@Override
	public void close() {
		for(IFlatDataWriterEngine currentProxyWriter : proxy) {
			currentProxyWriter.close();
		}
	}
}
