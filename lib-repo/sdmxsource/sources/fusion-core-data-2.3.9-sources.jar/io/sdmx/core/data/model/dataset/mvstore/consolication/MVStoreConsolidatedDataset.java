package io.sdmx.core.data.model.dataset.mvstore.consolication;

/**
 * This class represents a dataset stored in a MVStoreDatasetStorage.
 */

/**
 * @deprecated to delete
 */
@Deprecated //see new model
public class MVStoreConsolidatedDataset { //extends MVStoreAbstractDataset {
//	private static final Logger LOG =
//			LoggerFactory.getLogger(MVStoreConsolidatedDataset.class);
//
//	private static final DT_ObsKey obsKeyDT = DT_ObsKey.getInstance();
//	private static final DT_ObsPos obsPosDT = DT_ObsPos.getInstance();
//	private static final DT_String strDT = DT_String.getInstance();
//	private static final DT_Integer intDT = DT_Integer.getInstance(false);
//	private static final DT_List<Integer, Integer> intListDT = new DT_List<>(intDT);
//	private static final DT_List<ObsPos, ObsPos> obsPosListDT = new DT_List<>(obsPosDT);
//
//
//	// map keys to first position in keyables
//	private MVMap<String, Integer> keyableKeyIndex;
//
//	// map first position of a keyable to the positions of its duplicates
//	private MVMap<Integer, List<Integer>> keyableDuplicates;
//
//	//                    --- Observation maps ---
//
//	// map position to observation for sequential access in input order
//	private MVMap<ObsPos, ObservationWrap> observations;
//
//	// map keys to first position in observations
//	private MVMap<ObsKey, ObsPos> observationKeyIndex;
//
//	// map first position of an observation to the positions of its duplicates
//	private MVMap<ObsPos, List<ObsPos>> observationDuplicates;
//
//	// position of the last inserted observation
//	private Integer currentObservationPosition;
//
//	/**
//	 * Create a new instance from scratch.
//	 */
//	public static MVStoreConsolidatedDataset createInstance(MVStore db, int index, IDatasetStructures structures) {
//		return new MVStoreConsolidatedDataset(db, index, structures);
//	}
//
//	/**
//	 * Retrieve an existing instance from the store.
//	 */
//	public static MVStoreConsolidatedDataset retrieveInstance(MVStore db, int index, SdmxBeanRetrievalManager brm) {
//		return new MVStoreConsolidatedDataset(db, index, brm);
//	}
//	
//	/**
//	 * Build a MVStoreDataset instance from scratch.
//	 */
//	private MVStoreConsolidatedDataset(MVStore db, int index, IDatasetStructures structures) {
//		super(db, index, structures);
//		openObservationMaps();
//	}
//
//	/**
//	 * Build a MVStoreDataset instance from the information stored in the
//	 * given MVStore.
//	 */
//	private MVStoreConsolidatedDataset(MVStore db, int index, SdmxBeanRetrievalManager brm) {
//		super(db, index, brm);
//		openObservationMaps();
//	}
//
//	/**
//	 * Open the Keyable maps.
//	 */
//	protected void openKeyableMaps() {
//		super.openKeyableMaps();
//		keyableKeyIndex = MVStoreUtil.openMap("keyableKeyIndex", index, strDT, intDT, db);
//		currentKeyablePosition = keyables.isEmpty() ? -1 : keyables.lastKey();
//		keyableDuplicates = MVStoreUtil.openMap("keyableDuplicates", index, intDT, intListDT, db);
//		LOG.trace("Opened Keyable maps for dataset {}.", index);
//	}
//	
//	private void openObservationMaps() {
//		observations = MVStoreUtil.openMap("observations", index, obsPosDT, observationDT, db);
//		observationKeyIndex = MVStoreUtil.openMap("observationKeyIndex", index, obsKeyDT, obsPosDT, db);
//		observationDuplicates = MVStoreUtil.openMap("observationDuplicates", index, obsPosDT, obsPosListDT, db);
//		LOG.trace("Opened Observation maps for dataset {}.", index);
//	}
//
//	/**
//	 *
//	 */
//	public void writeKey(Keyable keyable) {
//		LOG.trace("writeKey({})", keyable);
//		String kKey = keyable.getShortCode();
//		Integer kBasePosition = keyableKeyIndex.get(kKey);
//
//		// TODO: distinguish between modes, APPEND and MERGE
//
//		currentObservationPosition = -1;
//		Integer kCurrPosition = ++currentKeyablePosition;
//
//		LOG.trace("keyables.put({}, {})", kCurrPosition, keyable);
//		keyables.put(kCurrPosition, keyable);
//
//		if (kBasePosition == null) { // new key
//			LOG.trace("keyableKeyIndex.put({}, {})", kKey, kCurrPosition);
//			keyableKeyIndex.put(kKey, kCurrPosition);
//		} else {
//			List<Integer> tmp = keyableDuplicates.get(kBasePosition);
//
//			tmp = CollectionUtil.extendList(tmp, kCurrPosition);
//			LOG.trace("keyableDuplicates.put({}, {})", kBasePosition, tmp);
//			keyableDuplicates.put(kBasePosition, tmp);
//		}
//	}
//
//
//	/**
//	 * Return an iterator on keyable positions
//	 */
//	public Iterator<Integer> getKeyableIndexIterator() {
//		return keyables.keyIterator(keyables.firstKey());
//	}
//
//	/**
//	 * Get the position of the first occurrence for the given key
//	 */
//	public Integer getKeyBasePosition(String key) {
//		return keyableKeyIndex.get(key);
//	}
//
//	/**
//	 * Return an iterator on positions of first occurrences for keyables
//	 */
//	public Iterator<Integer> getKeyableBasePositionIterator() {
//		return new Iterator<Integer>() {
//			Iterator<Integer> inner = getKeyableIndexIterator();
//			Integer buffer = null;
//
//			@Override
//			public boolean hasNext() {
//				while ((buffer == null) && inner.hasNext()) {
//					buffer = inner.next();
//
//					Keyable keyable = getKeyable(buffer);
//					Integer kBasePosition = keyableKeyIndex.get(keyable.getShortCode());
//
//					if (!buffer.equals(kBasePosition))
//						buffer = null;
//				}
//
//				return (buffer != null);
//			}
//
//			@Override
//			public Integer next() {
//				if (hasNext()) {
//					Integer tmp = buffer;
//
//					buffer = null;
//
//					return tmp;
//				}
//
//				throw new NoSuchElementException();
//			}
//		};
//	}
//
//	/**
//	 * Return an iterator on keyableDuplicates keys
//	 *
//	 * Iterates on the first positions for keyables having further occurrences.
//	 */
//	public Iterator<Integer> getKeyableDuplicatesIterator() {
//		return keyableDuplicates.keyIterator(keyableDuplicates.firstKey());
//	}
//
//	/**
//	 * Return the list of positions for duplicates of the given base position.
//	 */
//	public List<Integer> getKeyableDuplicatePositions(Integer basePosition) {
//		List<Integer> out = keyableDuplicates.get(basePosition);
//
//		return (out == null) ? Collections.emptyList() : new ArrayList<>(out);
//	}
//
//	/**
//	 * Return the list of positions for duplicates of the given base position.
//	 */
//	public List<ObsPos> getObservationDuplicatePositions(ObsPos basePosition) {
//		List<ObsPos> out = observationDuplicates.get(basePosition);
//
//		return (out == null) ? Collections.emptyList() : new ArrayList<>(out);
//	}
//
//	/**
//	 * Return an iterator on observation positions for the given keyable position
//	 */
//	public Iterator<ObsPos> getObservationIndexIterator(Integer kPos) {
//		return new Iterator<ObsPos>() {
//			ObsPos from = getFirstObservationPosition(kPos);
//			Iterator<ObsPos> inner = observations.keyIterator(from);
//			ObsPos buffer = null;
//
//			@Override
//			public boolean hasNext() {
//				if ((buffer == null) && inner.hasNext()) {
//					buffer = inner.next();
//
//					if (!kPos.equals(buffer.getKeyablePosition()))
//						buffer = null;
//				}
//
//				return (buffer != null);
//			}
//
//			@Override
//			public ObsPos next() {
//				if (hasNext()) {
//					ObsPos tmp = buffer;
//
//					buffer = null;
//
//					return tmp;
//				}
//
//				throw new NoSuchElementException();
//			}
//		};
//	}
//
//	/**
//	 * Return an iterator on observation positions for the given keyable position
//	 */
//	public Iterator<ObsKey> getObservationKeyIndexIterator(Integer kPos) {
//		return new Iterator<ObsKey>() {
//			ObsKey from = getFirstObservationKey(kPos);
//			Iterator<ObsKey> inner = observationKeyIndex.keyIterator(from);
//			ObsKey buffer = null;
//
//			@Override
//			public boolean hasNext() {
//				if ((buffer == null) && inner.hasNext()) {
//					buffer = inner.next();
//
//					if (!kPos.equals(buffer.getKeyablePosition()))
//						buffer = null;
//				}
//
//				return (buffer != null);
//			}
//
//			@Override
//			public ObsKey next() {
//				if (hasNext()) {
//					ObsKey tmp = buffer;
//
//					buffer = null;
//
//					return tmp;
//				}
//
//				throw new NoSuchElementException();
//			}
//		};
//	}
//
//	/**
//	 * Get the position of the first (in position order) observation belonging
//	 * to the keyable at the given position.
//	 *
//	 * Note: we check for larger or equal (ceilingKey) because 0 is the smallest
//	 *       valid value for observationPosition
//	 */
//	public ObsPos getFirstObservationPosition(Integer kPos) {
//		ObsPos reference = new ObsPos(kPos, 0);
//		ObsPos pos = observations.ceilingKey(reference);
//
//		// invalidate the position in case it does not belong to the given key
//		if ((pos != null) && !kPos.equals(pos.getKeyablePosition()))
//			pos = null;
//
//		return pos;
//	}
//
//	/**
//	 * Get the position of the last (in position order) observation belonging
//	 * to the keyable at the given position.
//	 *
//	 * Note: we check for smaller or equal (floorKey) because Integer.MAX_VALUE
//	 *       is the largest valid value for observationPosition
//	 */
//	public ObsPos getLastObservationPosition(Integer kPos) {
//		ObsPos reference = new ObsPos(kPos, Integer.MAX_VALUE);
//		ObsPos pos = observations.floorKey(reference);
//
//		// invalidate the position in case it does not belong to the given key
//		if ((pos != null) && !kPos.equals(pos.getKeyablePosition()))
//			pos = null;
//
//		return pos;
//	}
//	
//	@Override
//	public Iterator<Observation> getObs(int keyIdx) {
//		Iterator<ObsPos> obsIt = getObservationPositions(keyIdx).iterator();
//		return new Iterator<Observation>() {
//			
//			@Override
//			public boolean hasNext() {
//				return obsIt.hasNext();
//			}
//
//			@Override
//			public Observation next() {
//				ObsPos obsPos = obsIt.next();
//				if(obsPos != null) {
//					return getObservation(obsPos);
//				}
//				return null;
//			}
//		};
//	}
//
//	/**
//	 * Return the set of positions for observations belonging to the keyable at
//	 * the given position.
//	 */
//	public List<ObsPos> getObservationPositions(Integer kPos) {
//		ObsPos from = getFirstObservationPosition(kPos);
//		List<ObsPos> list;
//
//		if (from != null) {
//			ObsPos to = getLastObservationPosition(kPos);
//			Iterator<ObsPos> iterator = observations.keyIterator(from);
//
//			LOG.trace("getObservationPositions({}) -> ({}..{}).", kPos, from, to);
//
//			list = new ArrayList<>();
//
//			// Collect all the keys k: from <= k <= to
//			while (iterator.hasNext()) {
//				ObsPos next = iterator.next();
//
//				if (obsPosDT.compare(to, next) < 0)
//					break;
//				else
//					list.add(next);
//			}
//		} else {
//			list = Collections.emptyList();
//		}
//
//		LOG.trace("getObservationPositions({}) -> {}.", kPos, list);
//
//		return list;
//	}
//
//	/**
//	 * Get the key of the first (in key order) observation belonging to the
//	 * keyable at the given position.
//	 *
//	 * Note: we check for larger or equal (ceilingKey) because null is a valid
//	 *       value for dimensionValue (flat format)
//	 */
//	public ObsKey getFirstObservationKey(Integer kPos) {
//		ObsKey reference = new ObsKey(kPos, null);
//		ObsKey key = observationKeyIndex.ceilingKey(reference); // larger or equal
//
//		// invalidate the position in case it does not belong to the given key
//		if ((key != null) && !kPos.equals(key.getKeyablePosition()))
//			key = null;
//
//		return key;
//	}
//
//	/**
//	 * Get the key of the last (in key order) observation belonging
//	 * to the keyable at the given position.
//	 *
//	 * Note: we check for strictly smaller (lowerKey) because null is a valid
//	 *       value for dimensionValue (flat format)
//	 */
//	public ObsKey getLastObservationKey(Integer kPos) {
//		ObsKey reference = new ObsKey(kPos + 1, null);
//		ObsKey key = observationKeyIndex.lowerKey(reference); // strictly smaller
//
//		// invalidate the position in case it does not belong to the given key
//		if ((key != null) && !kPos.equals(key.getKeyablePosition()))
//			key = null;
//
//		return key;
//	}
//
//	/**
//	 * Return the set of keys for observations belonging to the keyable at
//	 * the given position.
//	 */
//	public List<ObsKey> getObservationKeys(Integer kPos) {
//		ObsKey from = getFirstObservationKey(kPos);
//		List<ObsKey> list;
//
//		if (from != null) {
//			ObsKey to = getLastObservationKey(kPos);
//			Iterator<ObsKey> iterator = observationKeyIndex.keyIterator(from);
//
//			LOG.trace("getObservationKeys({}) -> ({}..{}).", kPos, from, to);
//
//			list = new ArrayList<>();
//
//			// Collect all the keys k: from <= k <= to
//			while (iterator.hasNext()) {
//				ObsKey next = iterator.next();
//
//				if (obsKeyDT.compare(to, next) < 0)
//					break;
//				else
//					list.add(next);
//			}
//		} else {
//			list = Collections.emptyList();
//		}
//
//		LOG.trace("getObservationKeys({}) -> {}.", kPos, list);
//
//		return list;
//	}
//
//	/**
//	 * Return the observation at the given position
//	 *
//	 * TODO: maybe get the first available >= ?
//	 */
//	public Observation getObservation(ObsPos oPos) {
//		ObservationWrap oWrap = observations.get(oPos);
//		Observation observation = (oWrap == null) ? null : oWrap.getObservation();
//
//		LOG.trace("getObservation({}) => {}", oPos, observation);
//
//		return observation;
//	}
//
//	/**
//	 * Return the first position for observation having the given key
//	 */
//	public ObsPos getObservationBasePosition(ObsKey oKey) {
//		return observationKeyIndex.get(oKey);
//	}
//
//	/**
//	 *
//	 */
//	public void writeObs(Observation observation) {
//		LOG.trace("writeObs({})", observation);
//		Keyable keyable = observation.getSeriesKey();
//		Integer kBasePosition = keyableKeyIndex.get(keyable.getShortCode());
//		ObsKey oKey = new ObsKey(kBasePosition, observation.getDimensionValue());
//		ObsPos oBasePosition = observationKeyIndex.get(oKey);
//
//		// TODO: distinguish between modes, APPEND and MERGE
//
//		ObsPos oCurrPosition = new ObsPos(currentKeyablePosition,
//				++currentObservationPosition);
//		ObservationWrap oWrap = new ObservationWrap(currentKeyablePosition,
//				observation);
//
//		LOG.trace("observations.put({}, {})", oCurrPosition, oWrap);
//		observations.put(oCurrPosition, oWrap);
//
//		if (oBasePosition == null) { // new key
//			LOG.trace("observationKeyIndex.put({}, {}).", oKey, oCurrPosition);
//			observationKeyIndex.put(oKey, oCurrPosition);
//		} else {
//			List<ObsPos> tmp = observationDuplicates.get(oBasePosition);
//
//			tmp = CollectionUtil.extendList(tmp, oCurrPosition);
//			LOG.trace("observationDuplicates.put({}, {}).", oBasePosition, tmp);
//			observationDuplicates.put(oBasePosition, tmp);
//		}
//	}
//
//	/**
//	 *
//	 */
//	public void dump(Logger logger) {
//		if (logger == null || !logger.isDebugEnabled()) {
//			return;
//		}
//		super.dump(logger);
//
//		String kkiFirst = keyableKeyIndex.firstKey();
//		Iterator<String> kkiIter = keyableKeyIndex.keyIterator(kkiFirst);
//
//		logger.debug("      keyableKeyIndex:");
//
//		while (kkiIter.hasNext()) {
//			String k = kkiIter.next();
//			Integer v = keyableKeyIndex.get(k);
//
//			logger.debug("        {} - {}", k, v);
//		}
//
//		Integer kdFirst = keyableDuplicates.firstKey();
//		Iterator<Integer> kdIter = keyableDuplicates.keyIterator(kdFirst);
//
//		logger.debug("      keyableDuplicates:");
//
//		while (kdIter.hasNext()) {
//			Integer k = kdIter.next();
//			List<Integer> v = keyableDuplicates.get(k);
//
//			logger.debug("        {} - {}", k, v);
//		}
//
//		ObsPos oFirst = observations.firstKey();
//		Iterator<ObsPos> oIter = observations.keyIterator(oFirst);
//
//		logger.debug("      observations:");
//
//		while (oIter.hasNext()) {
//			ObsPos k = oIter.next();
//			ObservationWrap v = observations.get(k);
//			String vc = MVStoreUtils.getObservationKey(v.getObservation());
//
//			logger.debug("        {} - {}", k, vc);
//		}
//
//		ObsKey okiFirst = observationKeyIndex.firstKey();
//		Iterator<ObsKey> okiIter = observationKeyIndex.keyIterator(okiFirst);
//
//		logger.debug("      observationKeyIndex:");
//
//		while (okiIter.hasNext()) {
//			ObsKey k = okiIter.next();
//			ObsPos v = observationKeyIndex.get(k);
//
//			logger.debug("        {} - {}", k, v);
//		}
//
//		ObsPos odFirst = observationDuplicates.firstKey();
//		Iterator<ObsPos> odIter = observationDuplicates.keyIterator(odFirst);
//
//		logger.debug("      observationDuplicates:");
//
//		while (odIter.hasNext()) {
//			ObsPos k = odIter.next();
//			List<ObsPos> v = observationDuplicates.get(k);
//
//			logger.debug("        {} - {}", k, v);
//		}
//	}
}
