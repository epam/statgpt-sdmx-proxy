package io.sdmx.core.data.api.model.process;

/**
 * tracking token used to retrieve information about the {@link IDataProcess} status
 */
public interface IProcessToken {

	/**
	 * @return identity of token
	 */
	String getTokenId();
	
	/**
	 * @return the process being executed
	 */
	IDataProcess getProcess();
}
