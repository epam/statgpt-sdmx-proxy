package io.sdmx.core.data.engine.mapping;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.ITimeMapping;
import io.sdmx.core.data.api.model.mapping.ITimePeriodMapping;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

/**
 * A container around the 2 ways time can be mapped
 * <ol>
 *  <li>Using component rules, i.e YEAR from source = TIME_PERIOD in output</li>
 *  <li>Using time mapping rules, i.e Unix Time from source = TIME_PERIOD in output</li>
 * </ol>
 */
public class TimePeriodMapping implements ITimePeriodMapping {
	private IComponentMappingRules timeComponentMap;

	private ITimeMapping timeRulesMapping;
	private IComponentMappingRules freqMapRules;
	
	private String sourceComponent;  //If there is a single source;
	private List<String> sourceComponents;  //If there are multiple single sources;
	

	private String freqSourceComponent;  //If there is a single source;
	private List<String> freqSourceComponents;  //If there are multipe single sources;
	
	private String fixedFrequency;
	private int timeIndex;
	
	/**
	 * Constructor 1 - time mapping rules are contained in the {@link IComponentMappingRules}
	 * @param timeComponentMap
	 */
	public TimePeriodMapping(IComponentMappingRules timeComponentMap) {
		this.timeComponentMap = timeComponentMap;
		if (this.timeComponentMap != null) {
			setSource(this.timeComponentMap.getSourceComponents());
			this.timeIndex = timeComponentMap.getTargetComponents().indexOf(DimensionBean.TIME_DIMENSION_FIXED_ID);
			if(this.timeIndex < 0) {
				throw new RuntimeException("Unable to construct TimePeriodMapping - TIME_PERIOD missing from target component");
			}
		}
	}
	
	/**
	 * Constructor 2 - Time mapping rules, with frequency rules
	 * @param timeRulesMapping
	 * @param freqMapRules
	 */
	public TimePeriodMapping(ITimeMapping timeRulesMapping, IComponentMappingRules freqMapRules) {
		this(timeRulesMapping);
		this.timeRulesMapping = timeRulesMapping;
		this.sourceComponent = this.timeRulesMapping.getSourceComponent();
		this.freqMapRules = freqMapRules;
		if(freqMapRules != null) {
			if(timeRulesMapping.getFrequencyComponent() == null) {
				throw new IllegalArgumentException("TimePeriodMapping expecting frequency Component");
			}
			if(!freqMapRules.getTargetComponents().contains(timeRulesMapping.getFrequencyComponent())) {
				throw new IllegalArgumentException("TimePeriodMapping expecting frequency mapping rules for Dimension:"+timeRulesMapping.getFrequencyComponent());
			}
			if(freqMapRules.getSourceComponents().size() == 1) {
				this.freqSourceComponent = freqMapRules.getSourceComponents().get(0);
			} else {
				this.freqSourceComponents = freqMapRules.getSourceComponents();
			}
		} else if(timeRulesMapping.getFrequencyComponent() != null) {
			throw new IllegalArgumentException("TimePeriodMapping expecting frequency mapping rules for Dimension:"+timeRulesMapping.getFrequencyComponent());
		}
	}
	
	/**
	 * Constructor 3 - Time Mapping rules with a fixed Frequency
	 * @param timeRulesMapping
	 * @param freqMapRules
	 */
	public TimePeriodMapping(ITimeMapping timeRulesMapping, String frequencyId) {
		this(timeRulesMapping);
		this.timeRulesMapping = timeRulesMapping;
		this.sourceComponent = this.timeRulesMapping.getSourceComponent();
		this.fixedFrequency = frequencyId;
	}
	
	/**
	 * Constructor 4 - Time Mapping rules not frequency information required
	 * @param timeRulesMapping
	 * @param freqMapRules
	 */
	public TimePeriodMapping(ITimeMapping timeRulesMapping) {
		this.timeRulesMapping = timeRulesMapping;
		this.sourceComponent = this.timeRulesMapping.getSourceComponent();
	}
	
	@Override
	public List<String> getSourceComponents() {
		return this.timeComponentMap != null ? this.timeComponentMap.getSourceComponents() : this.timeRulesMapping.getSourceComponents();
	}
	@Override
	public List<String> getTargetComponents() {
		return this.timeComponentMap != null ? this.timeComponentMap.getTargetComponents() : this.timeRulesMapping.getTargetComponents();
	}
	@Override
	public boolean outputRequired() {
		return this.timeComponentMap != null ? this.timeComponentMap.outputRequired() : this.timeRulesMapping.outputRequired();
	}
	
	private void setSource(List<String> sourceValues) {
		if(sourceValues.size() == 1) {
			sourceComponent = sourceValues.get(0);
		} else {
			this.sourceComponents = sourceValues;
		}
	}

	@Override
	public IExplainMapComponent explain(Map<String, String> values) {
		if(timeComponentMap != null) {
			if(sourceComponent != null)  {
				String codeValue = values.get(sourceComponent);
				return timeComponentMap.explain(SdmxPeriodImpl.ALL_PERIODS, codeValue);
			}
			return timeComponentMap.explain(SdmxPeriodImpl.ALL_PERIODS, mapToArray(values, sourceComponents));
		}
		String timeValue = values.get(sourceComponent);
		if(timeValue == null) {
			return null;
		}
		String targetFreq = freqMapRules != null ? performFreqMapping(values, timeRulesMapping.getFrequencyComponent()) : this.fixedFrequency;
		return timeRulesMapping.explain(timeValue, targetFreq);
	}

	@Override
	public String performMapping(Map<String, String> values) {
		if(timeComponentMap != null) {
			return performTimeComponentMapping(values);
		}
		String timeValue = values.get(sourceComponent);
		if(timeValue == null) {
			return null;
		}
		String targetFreq = freqMapRules != null ? performFreqMapping(values, timeRulesMapping.getFrequencyComponent()) : this.fixedFrequency;
		return timeRulesMapping.getMappedValue(timeValue, targetFreq);
	}
	
	private String performFreqMapping(Map<String, String> values, String freqComponent) {
		Map<SdmxPeriod, Set<KeyValue>> mappedOutput = null;
		if(freqSourceComponent != null)  {
			String codeValue = values.get(freqSourceComponent);
			mappedOutput = freqMapRules.getMappedCodes(SdmxPeriodImpl.ALL_PERIODS, codeValue);
		} else {
			mappedOutput = freqMapRules.getMappedCodes(SdmxPeriodImpl.ALL_PERIODS, mapToArray(values, freqSourceComponents));
		}
		return unpackMappedOutput(mappedOutput, freqComponent);
	}
	
	private String performTimeComponentMapping(Map<String, String> values) {
		Map<SdmxPeriod, Set<KeyValue>> mappedOutput = null;
		if(sourceComponent != null)  {
			String codeValue = values.get(sourceComponent);
			mappedOutput = timeComponentMap.getMappedCodes(SdmxPeriodImpl.ALL_PERIODS, codeValue);
		} else {
			mappedOutput = timeComponentMap.getMappedCodes(SdmxPeriodImpl.ALL_PERIODS, mapToArray(values, sourceComponents));
		}
		return unpackMappedOutput(mappedOutput, getTargetComponents().get(this.timeIndex));
	}
	
	private String unpackMappedOutput(Map<SdmxPeriod, Set<KeyValue>> mappedOutput, String outputDimension) {
		for(SdmxPeriod period : mappedOutput.keySet()) {
			Set<KeyValue> kvs = mappedOutput.get(period);
			for(KeyValue kv : kvs) {
				if(kv.getConcept().equals(outputDimension)) {
					return kv.getCode();
				}
			}
		}
		return null;
	}
	
	private String[] mapToArray(Map<String, String> values, List<String> arrayValues) {
		String[] returnArray = new String[arrayValues.size()];
		int i =0;
		for(String val : arrayValues) {
			returnArray[i] = values.get(val);
			i++;
		}
		return returnArray;
	}

}
