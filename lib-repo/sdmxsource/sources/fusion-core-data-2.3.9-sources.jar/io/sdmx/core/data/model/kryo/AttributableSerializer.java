package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.core.sdmx.factory.PositionalDataFactory;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;

public abstract class AttributableSerializer<T extends Attributable> extends Serializer<T> {

	@Override
	public void write(Kryo kryo, Output output, T x) {
		kryo.writeObject(output, x.getAttributes(), KeyValueListSerializer.getInstance());
		kryo.writeObject(output, x.getMultilingualAttributes(), MultilingualKeyValueListSerializer.getInstance());
		kryo.writeObject(output, x.getAnnotations(), AnnotationListSerializer.getInstance());
		
		String position = x.getPosition() == null ? null : x.getPosition().toPositionalString();
		kryo.writeObjectOrNull(output, position, String.class);
	}

	@Override
	public T read(Kryo kryo, Input input, Class<? extends T> type) {
		List<KeyValue> attributes = kryo.readObject(input, List.class, KeyValueListSerializer.getInstance());
		List<IMultilingualKeyValue> multilingualAttributes = kryo.readObject(input, List.class, MultilingualKeyValueListSerializer.getInstance());
		List<AnnotationBean> annotations = kryo.readObject(input, List.class, AnnotationListSerializer.getInstance());
		String position = kryo.readObjectOrNull(input, String.class);
		IDataPosition dataPosition = PositionalDataFactory.getInstance().getPosition(position);

		return getBuilder(kryo, input).attributes(attributes).
				attributesMultilingual(multilingualAttributes).
				annotations(annotations).
				position(dataPosition).
				build();
	}
	
	protected abstract AttributableBuilder<T> getBuilder(Kryo kryo, Input input);
	
}
