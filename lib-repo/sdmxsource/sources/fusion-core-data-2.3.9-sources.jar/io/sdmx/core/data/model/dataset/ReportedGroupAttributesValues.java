package io.sdmx.core.data.model.dataset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.core.data.model.GroupAttributeValues;

/**
 * A store of group attribute values, which can be used to look up attributes related to series
 */
public class ReportedGroupAttributesValues {
	private Map<String, GroupAttributeValues> groupAttributes = new HashMap<>();

	public ReportedGroupAttributesValues() {}
	
	public ReportedGroupAttributesValues(DataStructureBean dsd) {
		for(GroupBean groupBean : dsd.getGroups()) {
			addAttributes(groupBean);
		}
	}
	

	private void addAttributes(GroupBean group) {
		groupAttributes.put(group.getId(), new GroupAttributeValues(group));
	}
	
	/**
	 * Returns any group attributes which match the input series
	 * @param key
	 */
	public List<KeyValue> getAttributesForSeries(Keyable key) {
		List<KeyValue> returnList = null;
		for(GroupAttributeValues currentGroupAttribute :  groupAttributes.values()) {
			List<KeyValue> attributes = currentGroupAttribute.getAttributes(key);
			if(attributes != null) {
				if(returnList == null) {
					returnList = new ArrayList<>(attributes);
				} else {
					returnList.addAll(attributes);
				}
			}
		}
		return returnList;
	}
	
	/**
	 * Stores the attributes for this group against the dimension key
	 * @param key
	 */
	public void addGroup(Keyable key) {
		if(key.isSeries()) {
			throw new IllegalArgumentException("GroupAttributes.addGroup can only be called with a group key");
		}
		GroupAttributeValues groupAttributeValues = groupAttributes.get(key.getGroupName());
		if(groupAttributeValues != null) {
			groupAttributeValues.addGroup(key);
		}
	}

}
