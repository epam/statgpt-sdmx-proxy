
package io.sdmx.core.data.model.formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.model.dataset.IObservationValueFormatter;
import io.sdmx.im.data.ObservationMeasureProxy;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Takes multiple IObservationValueFormatter to apply to an observation
 */
public class MultiFormatter implements IObservationValueFormatter {
	private boolean stopOnFirst;
	private List<IObservationValueFormatter> formatters;

	/**
	 * @param stopOnFirst if true then the first formatter to format the observation will be the value used, otherwise all formatters are given the
	 *                    observation to format
	 * @param formatters
	 */
	public MultiFormatter(boolean stopOnFirst, IObservationValueFormatter... formatters) {
		this.stopOnFirst = stopOnFirst;
		if (formatters == null || formatters.length == 0) {
			throw new SdmxSemmanticException("MultiFormatter requires at least 1 IObservationValueFormatter");
		}
		this.formatters = CollectionUtil.toList(formatters);
	}

	@Override
	public String getObservationValue(Observation obs, String measure) {
		//TODO implement support for multiple values
		KeyValue kv = obs.getMeasure(measure);
		for (IObservationValueFormatter formatter : formatters) {
			if (!kv.hasMultipleValues()) {
				String originalValue = kv.getCode();
				String formattedValue = formatter.getObservationValue(obs, measure);
				if (!ObjectUtil.equivalent(originalValue, formattedValue)) {
					if (stopOnFirst) {
						return formattedValue;
					} else {
						List<KeyValue> measures = new ArrayList<>(obs.getMeasures());
						int index = measures.indexOf(kv);
						measures.set(index, KeyValueImpl.getInstance(measure, formattedValue));
						obs = new ObservationMeasureProxy(obs, measures);
					}
				}

			}

		}
		return obs.getMeasure(measure).getCode();
	}
}
