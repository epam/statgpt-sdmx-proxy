package io.sdmx.core.data.factory.writer;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.core.sdmx.format.StructureSchemaFormat;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.factory.ISchemaWriterFactory;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.data.engine.writer.schema.StructureSchemaWriterEngine;

/**
 * Factory for schema queries that want the information back as a structure message, not a .XSD
 */
public class StructureSchemaWriterFactory implements ISchemaWriterFactory {
	private StructureWriterManager swm;
	private SdmxBeanRetrievalManager retrievalManager;

	public StructureSchemaWriterFactory(StructureWriterManager swm, SdmxBeanRetrievalManager retrievalManager) {
		this.swm = swm;
		this.retrievalManager = retrievalManager;
		if(swm == null) {
			throw new SdmxException("StructureSchemaWriterFactory requires a StructureWriterManager");
		}
		if(retrievalManager == null) {
			throw new SdmxException("StructureSchemaWriterFactory requires a SdmxBeanRetrievalManager");
		}
	}
	
	@Override
	public SchemaWriterEngine getSchemaWriterEngine(SchemaFormat format) {
		if(format instanceof StructureSchemaFormat) {
			StructureFormat structureFormat = ((StructureSchemaFormat)format).getStructureFormat();
			return new StructureSchemaWriterEngine(swm, structureFormat, retrievalManager);
		}
		return null;
	}
}

