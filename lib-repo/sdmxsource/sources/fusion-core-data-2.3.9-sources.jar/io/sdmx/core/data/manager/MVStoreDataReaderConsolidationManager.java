package io.sdmx.core.data.manager;

/**
 * @deprecated to delete
 */
@Deprecated //see new model
public class MVStoreDataReaderConsolidationManager {
//                                    implements DataReaderConsolidationManager {
//  private static final Logger LOG =
//          LoggerFactory.getLogger(MVStoreDataReaderConsolidationManager.class);
//
//  private final SdmxBeanRetrievalManager brm;
//  private MVDuplicateBehaviour defaultDuplicateBehaviour =
//                                           MVDuplicateBehaviour.USE_LAST_VALUE;
//
//  public MVStoreDataReaderConsolidationManager(SdmxBeanRetrievalManager brm) {
//    this.brm = brm;
//  }
//
//  @Override
//  public String getId() {
//    return "Duplicate";
//  }
//
//  @Override
//  public String getDescription() {
//    return "Ensures the data file does not contain any duplications which " +
//           "contradict each other. For example, if two observations for the " +
//           "same period, reporting different observation values, will be " +
//           "reported as a duplicate error.";
//  }
//
//  @Override
//  public String getName() {
//    return "Duplicate Observations";
//  }
//
//  @Override
//  public VALIDATION_LEVEL getMinErrorLevel() {
//    return VALIDATION_LEVEL.BLOCK_PUBLICATION;
//  }
//
//  @Override
//  public DataReaderEngine consolidateReader(DataReaderEngine dre,
//                                            DataValidationErrorHandler eh, 
//                                            IConsolidationOptions consolidationOptions) {
//    File file = null;
//
//    try {
//      file = Files.createTempFile("Consolidation", ".mvs").toFile();
//      MVDuplicateBehaviour dupeBehaviour = null;
//      if (consolidationOptions != null) {
//    	  dupeBehaviour = consolidationOptions.getDuplicateBehaviour();
//      }
//      if (dupeBehaviour == null) {
//    	  dupeBehaviour = defaultDuplicateBehaviour;
//      }
//      LOG.debug("Duplicate Behaviour: " + dupeBehaviour);
//      return consolidateReader(dre, eh, file, dupeBehaviour);
//    } catch (IOException e) {
//      throw new RuntimeException("Could not create a temporary file", e);
//    } finally {
//      if (file != null)
//        file.delete();
//    }
//  }
//
//  public DataReaderEngine consolidateReader(DataReaderEngine dre,
//                                            DataValidationErrorHandler eh,
//                                            File file,
//                                            MVDuplicateBehaviour dupeBehaviour) {
//    MVStoreDatasetStorage storage = MVStoreDatasetStorage.createInstance(file);
//    MVStoreDataWriterEngine dwe = new MVStoreDataWriterEngine(storage);
//    MVStoreView view;
//
//    try {
//      HeaderBean header = dre.getHeader();
//
//      dwe.writeHeader(header);
//
//      while (dre.moveNextDataset()) {
//        IDatasetStructures structures = new DatasetStructures(
//                                                   dre.getDataStructure(),
//                                                   dre.getDataFlow(),
//                                                   dre.getProvisionAgreement(),
//                                                   null);
//        DatasetHeaderBean dsHeader = dre.getCurrentDatasetHeaderBean();
//        List<KeyValue> dsAttrs = dre.getDatasetAttributes();
//
//        // Note: here we might want to pass annotations to dwe.
//        dwe.startDataset(structures, dsHeader, dsAttrs);
//
//        while (dre.moveNextKeyable()) {
//          Keyable keyable = dre.getCurrentKey();
//
//          dwe.writeKey(keyable);
//
//          while (dre.moveNextObservation()) {
//            Observation observation = dre.getCurrentObservation();
//
//            dwe.writeObservation(observation);
//          }
//        }
//      }
//    } catch (Throwable t) {
//      LOG.error("Throwable caught:", t);
//      throw t;
//    } finally {
//      dre.close();
//      dwe.close();
//    }
//
//    storage = MVStoreDatasetStorage.reopenInstance(brm, file);
//
//    storage.dump(); // dump content if specific logger is enabled
//
//    // Do a first consolidating read from the storage to collect errors
//    view = new MVStoreConsolidator(getId(), storage, eh, dupeBehaviour);
//    dre = new MVStoreDataReaderEngine(view);
//
//    LOG.trace("Consolidation started.");
//    try {
//      while (dre.moveNextDataset()) {
//        dre.getDatasetAttributes();
//
//        while (dre.moveNextKeyable()) {
//          dre.getCurrentKey();
//
//          while (dre.moveNextObservation())
//            dre.getCurrentObservation();
//        }
//      }
//    } catch (Throwable t) {
//      LOG.error("Throwable caught:", t);
//      throw t;
//    } finally {
//      dre.close();
//    }
//    LOG.trace("Consolidation ended.");
//
////    // Further reading will not collect errors anymore and use a different view
////    // depending on whether duplicates need to be preserved or not.
////    if (MVDuplicateBehaviour.PRESERVE_DUPLICATES.equals(dupeBehaviour))
////      view = new MVStoreRetriever(storage);
////    else
//      view = new MVStoreConsolidator(getId(), storage, null, dupeBehaviour);
//
//    return new MVStoreDataReaderEngine(view);
//  }
//  
//  public MVDuplicateBehaviour getDuplicateValBehaviour() {
//    return defaultDuplicateBehaviour;
//  }
//
//  public void setDuplicateValBehaviour(MVDuplicateBehaviour b) {
//    defaultDuplicateBehaviour = b;
//  }
}
