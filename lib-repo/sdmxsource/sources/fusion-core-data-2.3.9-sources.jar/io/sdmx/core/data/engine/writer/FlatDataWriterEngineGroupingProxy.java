package io.sdmx.core.data.engine.writer;

import java.util.Collections;
import java.util.Set;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;

/**
 * Sorts rows into new datasets, series, and obs
 */
public abstract class FlatDataWriterEngineGroupingProxy<T extends IFlatDataWriterEngine> extends FlatDataWriterEngineProxy<T>  {
	private IDataRow lastKey;
	protected Set<String> measures;	
	protected DatasetHeaderBean dsHeader;

	
	
	public FlatDataWriterEngineGroupingProxy(T proxy) {
		super(proxy);
	}
	
	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		this.dsHeader = header;
		super.startDataset(header, annotations);
	}

	@Override
	public final void writeRow(IDataRow row) {
		boolean newDataset = false;
		boolean newSeries = false;
		
		if(lastKey == null || !lastKey.getDatasetStructures().equals(row.getDatasetStructures())) {
			//New Dataset
			
			IDatasetStructures dsStructures = row.getDatasetStructures();
			DataStructureBean dsd = dsStructures.getDataStructure();
			measures = dsd.hasMeasures() ? SdmxCollectionUtil.identifiablesIds(dsd.getMeasures()) : Collections.emptySet();
			newDataset = true;
			newSeries = true;
		} else if(!lastKey.getShortCode().equals(row.getShortCode())) {
			newSeries = true;
		}
//		for(String measure : this.measures) {
//			if(row.getRowData().containsKey(measure) || row.getMultiValueData().containsKey(measure)) {
//				newObservation(row);
//			}
//		}
		lastKey = row;
		row = processRow(row, newDataset, newSeries);
		if(row != null) {
			super.writeRow(row);
		}
	}

	/**
	 * processes the row, the processes row (modified or unmodified) is returned to be written to the proxy
	 * if null is returned, the proxy is not written to
	 * @param row
	 * @param newDataset
	 * @param newSeries
	 * @return
	 */
	protected abstract IDataRow processRow(IDataRow row, boolean newDataset, boolean newSeries);
	
}
