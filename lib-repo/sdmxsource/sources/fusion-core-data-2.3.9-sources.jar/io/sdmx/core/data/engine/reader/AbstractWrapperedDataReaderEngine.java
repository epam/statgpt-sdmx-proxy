package io.sdmx.core.data.engine.reader;

import java.util.List;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * Acts a a direct wrapper on top of a {@link DataReaderEngine}.  The intention is to override this class if any specific methods are to be overridden.
 */
public abstract class AbstractWrapperedDataReaderEngine implements DataReaderEngine {
	
	protected DataReaderEngine dataReaderEngine;
	
	protected AbstractWrapperedDataReaderEngine() { 
		//Allow a constructor to do internal work to create the DataReaderEngine
	}

	public AbstractWrapperedDataReaderEngine(DataReaderEngine dataReaderEngine) {
		this.dataReaderEngine = dataReaderEngine;
		if(dataReaderEngine == null) {
			throw new IllegalArgumentException("Can not create AbstractWrapperedDataReaderEngine: DataReaderEngine can not be null");
		}
	}
	
	@Override
	public final DataReaderEngine createCopy() {
		return createWrappedCopy(dataReaderEngine.createCopy());
	}
	
	protected abstract DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy);
	
	
	@Override
	public FormatDetails getFormatDetails() {
		if(dataReaderEngine != null) {
			return dataReaderEngine.getFormatDetails();
		}
		return null;
	}

	@Override
	public String getDataFormat() {
		return dataReaderEngine.getDataFormat();
	}

	@Override
	public HeaderBean getHeader() {
		return dataReaderEngine.getHeader();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return dataReaderEngine.getDataStructure();
	}
	
	@Override
	public DataflowBean getDataFlow() {
		return dataReaderEngine.getDataFlow();
	}
	
	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return dataReaderEngine.getProvisionAgreement();
	}

	@Override
	public int getDatasetPosition() {
		return dataReaderEngine.getDatasetPosition();
	}

	@Override
	public int getKeyablePosition() {
		return dataReaderEngine.getKeyablePosition();
	}
	
	@Override
	public int getObsPosition() {
		return dataReaderEngine.getObsPosition();
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return dataReaderEngine.getCurrentDatasetHeaderBean();
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return dataReaderEngine.getDatasetAttributes();
	}

	@Override
	public Keyable getCurrentKey() {
		return dataReaderEngine.getCurrentKey();
	}

	@Override
	public Observation getCurrentObservation() {
		return dataReaderEngine.getCurrentObservation();
	}

	@Override
	public boolean moveNextObservation() {
		return dataReaderEngine.moveNextObservation();
	}

	@Override
	public boolean moveNextKeyable() {
		return dataReaderEngine.moveNextKeyable();
	}

	@Override
	public boolean moveNextDataset() {
		return dataReaderEngine.moveNextDataset();
	}

	@Override
	public void reset() {
		dataReaderEngine.reset();		
	}

	@Override
	public List<FooterMessage> close() {
		dataReaderEngine.close();
		return null;
	}
}
