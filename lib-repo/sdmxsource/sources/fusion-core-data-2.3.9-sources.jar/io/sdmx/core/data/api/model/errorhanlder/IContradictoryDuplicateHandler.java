package io.sdmx.core.data.api.model.errorhanlder;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;

/**
 * Handles duplicate keys or attributes which contradict
 *
 * @param <T>
 */
public interface IContradictoryDuplicateHandler <T extends Attributable> {

	/**
	 * @param keyable the duplicate key or attribute which contradicts a previously reported value
	 * @param kv1 the previously reported key value which kv1 is contradicting
	 * @param kv2 the key value which contradicts
	 */
	void duplicateAttribute(T keyable, KeyValue kv1, KeyValue kv2);

}
