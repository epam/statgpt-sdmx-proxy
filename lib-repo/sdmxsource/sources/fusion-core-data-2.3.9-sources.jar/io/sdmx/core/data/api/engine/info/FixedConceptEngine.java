package io.sdmx.core.data.api.engine.info;

import java.util.Map;

import io.sdmx.api.sdmx.engine.DataReaderEngine;

public interface FixedConceptEngine {
	
	Map<String, String> getFixedConcepts(DataReaderEngine dre, boolean includeDimensions, boolean includeObs, boolean includeAttributes);
	
}
