package io.sdmx.core.data.model.calcuation;

public class ValidationExpressionResult {

	private String resolvedExpression;  //the expression where the placeholders are replaced by the reported values, example UK+FR would be something like 10+20
	private Double actualOutput;  //The reported value
	private Double calculationResult; //The expected value
	private boolean pass; //True if valid
	private Throwable th;
	
	public ValidationExpressionResult(String resolvedExpression, Double actualOutput, Double calculationResult, boolean pass) {
		this.resolvedExpression = resolvedExpression;
		this.actualOutput = actualOutput;
		this.calculationResult = calculationResult;
		this.pass = pass;
	}
	
	public ValidationExpressionResult(String resolvedExpression, Double actualOutput, Throwable th) {
		this.resolvedExpression = resolvedExpression;
		this.actualOutput = actualOutput;
		this.pass = false;
		this.th = th;
	}

	public String getResolvedExpression() {
		return resolvedExpression;
	}

	public Double getActualOutput() {
		return actualOutput;
	}

	public Double getCalculationResult() {
		return calculationResult;
	}

	public boolean isPass() {
		return pass;
	}
	
	public Throwable getThrowable() {
		return th;
	}
}
