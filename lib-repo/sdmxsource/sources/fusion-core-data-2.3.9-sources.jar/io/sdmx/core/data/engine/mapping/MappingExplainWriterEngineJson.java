package io.sdmx.core.data.engine.mapping;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.api.engine.mapping.IMappingExplainWriterEngine;
import io.sdmx.core.data.api.model.mapping.IExplainMap;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch;
import io.sdmx.core.data.api.model.mapping.IExplainMapOutputRow;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.KeyValueUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

/**
 * Writes the {@link IExplainMap} in JSON format
 */
public class MappingExplainWriterEngineJson implements IMappingExplainWriterEngine, IFusionSingleton {

	private static MappingExplainWriterEngineJson INSTANCE;

	public static MappingExplainWriterEngineJson getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MappingExplainWriterEngineJson();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private MappingExplainWriterEngineJson() {}

	@Override
	/**
	 * Writes JSON in the format
	 * <pre>
	 * {
			"StructureMap" : urn
			"SourceDSD"    : urn,
			"TargetDSD"    : urn,
			"Input": {
				see writeStructure
			},
			"Output": {
				see writeOutput
			},
			"Mappings" : [
				see writeMappings
			]
	 * }
	 * </pre>
	 */
	public void writeExplainMap(IExplainMap explainMap, OutputStream out) {
		try(JsonGenerator jsonWriter = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)) {
			jsonWriter.writeStartObject();
			jsonWriter.writeStringField("StructureMap", explainMap.getMappingRules().getStructureMapBean().getUrn());
			jsonWriter.writeStringField("SourceDSD", explainMap.getMappingRules().getFromDataStructure().getUrn());
			jsonWriter.writeStringField("TargetDSD", explainMap.getMappingRules().getToDataStructure().getUrn());

			jsonWriter.writeObjectFieldStart("InputRow");
			writeStructure(jsonWriter, explainMap.getInput());
			jsonWriter.writeEndObject();

			jsonWriter.writeArrayFieldStart("OutputRows");
			for(IExplainMapOutputRow outputRow : explainMap.getOutputRows()) {
				jsonWriter.writeStartObject();
				writeOutput(jsonWriter, outputRow.getOutput());
				writeMappings(jsonWriter, outputRow);
				jsonWriter.writeEndObject();
			}
			jsonWriter.writeEndArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	/**
	 * Writes the outputs, broken down by validity period for output row, with support for multiple rows per period (e.g. split multiple measures into multiple rows)
	 * <pre>
		"AllPeriods" : [
			//see writeStructure
		],
		"2009/2012" : [
			//see writeStructure
		]
	 * </pre>
	 *
	 * @param jsonWriter
	 * @param explainMap
	 * @throws IOException
	 */
	private void writeOutput(JsonGenerator jsonWriter, Map<SdmxPeriod, IDataRow> output) throws IOException {
		jsonWriter.writeObjectFieldStart("Outputs");
		for(SdmxPeriod period : output.keySet()) {
			jsonWriter.writeObjectFieldStart(period.toISOString());
			writeStructure(jsonWriter, output.get(period));
			jsonWriter.writeEndObject();
		}
		jsonWriter.writeEndObject();
	}



	/**
	 * Writes:
	 * <pre>
	 * 	 "PropName" : {
	 * 		"FREQ" : ["A","M"],
	 * 		"REF_AREA" : UK
	 *   }
	 * </pre>
	 * @param jsonWriter
	 * @param row
	 * @throws IOException
	 */
	private void writeStructure(JsonGenerator jsonWriter, IDataRow row) throws IOException {
		for(String compId : row.getRowData().keySet()) {
			jsonWriter.writeStringField(compId, row.getRowData().get(compId));
		}
		for(String compId : row.getMultiValueData().keySet()) {
			JsonWriterUtil.writeStringArray(jsonWriter, compId, row.getMultiValueData().get(compId));
		}
	}

	/**
	 * Writes the array of component maps
	 * <pre>
	 * 	Mappings : [
	 * 		//see writeMapping
	 *  ]
	 * </pre>
	 *
	 *
	 * @param jsonWriter
	 * @param explainMapRow
	 * @throws IOException
	 */
	private void writeMappings(JsonGenerator jsonWriter, IExplainMapOutputRow explainMapRow) throws IOException {
		jsonWriter.writeArrayFieldStart("Mappings");
		for(IExplainMapComponent expComp : explainMapRow.getComponentBreakdown()) {
			writeMapping(jsonWriter, expComp);
		}
		jsonWriter.writeEndArray();
	}

	/**
	 * Writes the explain for how a Component Map was used in the mapping, format:
	 * <pre>
	 * {
		SourceComponents : ["REF_AREA", "CURR_DENOM"]
		TargetComponents : ["CURRENCY"]
		Matches : {
			"AllPeriods" : {
				CURRENCY : //see output for IExplainMapMatch
			},
			"2009/2012" : {
				CURRENCY : //see output for IExplainMapMatch
			}
		},
		Outputs : {
			//see writeOutput
		}
	 * }
	 * </pre>
	 * @param jsonWriter
	 * @param explainMap
	 * @throws IOException
	 */
	private void writeMapping(JsonGenerator jsonWriter, IExplainMapComponent explainMap) throws IOException {
		jsonWriter.writeStartObject();
		JsonWriterUtil.writeStringArray(jsonWriter, "SourceComponents", explainMap.getSourceComponents());
		JsonWriterUtil.writeStringArray(jsonWriter, "TargetComponents", explainMap.getTargetComponents());

		jsonWriter.writeObjectFieldStart("Matches");
		writeMappingForPeriods(jsonWriter, explainMap.getMappings());
		jsonWriter.writeEndObject();

		jsonWriter.writeObjectFieldStart("Outputs");
		writeMatchOutput(jsonWriter, explainMap.getOutputs());
		jsonWriter.writeEndObject();

		jsonWriter.writeEndObject();
	}

	/**
	 * Writes the output for each period in the format:
	 * <pre>
	 * "AllPeriods" : {
			"FREQ" : ["A"],
			"REF_AREA" : ["UK", FR"]

		},
		"2009/2012" : {
			... as above
		}
		</pre>
	 * @param jsonWriter
	 * @param outputs
	 * @throws IOException
	 */
	private void writeMatchOutput(JsonGenerator jsonWriter, Map<SdmxPeriod, List<KeyValue>> outputs) throws IOException {
		for(SdmxPeriod period : outputs.keySet()) {
			jsonWriter.writeObjectFieldStart(period.toISOString());
			Map<String, Set<String>> compId2Values = KeyValueUtil.toMapOfSet(outputs.get(period));
			for(String compId : compId2Values.keySet()) {
				JsonWriterUtil.writeStringArray(jsonWriter, compId, compId2Values.get(compId));
			}
			jsonWriter.writeEndObject();
		}
	}



	/**
	 * <pre>
	 * "AllPeriods" : {
			CURRENCY : //see output for IExplainMapMatch
		},
		"2009/2012" : {
			CURRENCY : //see output for IExplainMapMatch
		}
	</pre>
	 * @param jsonWriter
	 * @param getMappings
	 * @throws IOException
	 */
	private void writeMappingForPeriods(JsonGenerator jsonWriter, Map<SdmxPeriod, List<IExplainMapMatch>> mappings) throws IOException {
		for(SdmxPeriod period : mappings.keySet()) {
			jsonWriter.writeObjectFieldStart(period.toISOString());
			for(IExplainMapMatch match : mappings.get(period)) {
				writeMatch(jsonWriter, match);
			}
			jsonWriter.writeEndObject();
		}
	}


	/**
	 * Writes the match information for a component map in the format:
	 * <pre>
	 *  {
			RuleType 	  : "Regex"
			Input 		  : "A"
			Match		  : ".*"
			CaptureGroups : null
			SubstringStart: 1
			SubstringEnd  : 2
		}
	 * </pre>
	 * @param jsonWriter
	 * @param match
	 * @throws IOException
	 */
	private void writeMatch(JsonGenerator jsonWriter, IExplainMapMatch match) throws IOException {
		jsonWriter.writeObjectFieldStart(match.getComponent());

		String ruleType = null;
		switch(match.getRuleType()) {
		case EQUALS:
			ruleType = "Equals";
			break;
		case IMPLICIT:
			ruleType = "Copy";
			break;
		case REG_EX:
			ruleType = "RegEx";
			break;
		case TIME_EPOCH:
			ruleType = "TimeEpoch";
			break;
		case TIME_PATTERN:
			ruleType = "TimePattern";
			break;
		default:
			break;

		}
		jsonWriter.writeStringField("RuleType", ruleType);

		if(match.getInput() != null) {
			jsonWriter.writeStringField("Input", match.getInput());
		}
		if(match.getMatch() != null) {
			jsonWriter.writeStringField("Match", match.getMatch());
		}
		if(ObjectUtil.validCollection(match.getCaptureGroups())) {
			JsonWriterUtil.writeStringArray(jsonWriter, "CaptureGroups", match.getCaptureGroups());
		}
		if(match.getSubstringStart() > 0) {
			jsonWriter.writeNumberField("SubstringStart", match.getSubstringStart());
		}
		if(match.getSubstringEnd() > 0) {
			jsonWriter.writeNumberField("SubstringEnd", match.getSubstringEnd());
		}
		jsonWriter.writeEndObject();
	}

}
