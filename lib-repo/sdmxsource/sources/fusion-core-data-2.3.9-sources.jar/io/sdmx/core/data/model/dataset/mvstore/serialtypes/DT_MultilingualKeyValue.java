package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.data.MultilingualKeyValue;

public class DT_MultilingualKeyValue extends BasicDataType<IMultilingualKeyValue> {
	private static final DT_MultilingualKeyValue INSTANCE = new DT_MultilingualKeyValue();
	

	private final DT_List<IMultilingualNodeValue, IMultilingualNodeValue> nodeValueListDT;
	private final DT_String strDT = DT_String.getInstance();
	  
	private DT_MultilingualKeyValue() {
		nodeValueListDT = new DT_List<>(DT_MultilingualNodeValue.getInstance());
	}

	public static DT_MultilingualKeyValue getInstance() {
		return INSTANCE;
	}

	@Override
	public int getMemory(IMultilingualKeyValue x) {
		int size = 1; // null/object selector

		if (x != null) {
			size += strDT.getMemory(x.getConcept());
			size += nodeValueListDT.getMemory(x.getMultilingualNodeValues());
		}
		return size;
	}

	@Override
	public void write(WriteBuffer buff, IMultilingualKeyValue x) {
		buff.putVarInt((x == null) ? 0 : 1);

		if (x != null) {
			strDT.write(buff, x.getConcept());
			nodeValueListDT.write(buff, x.getMultilingualNodeValues());
		}

	}

	@Override
	public IMultilingualKeyValue read(ByteBuffer buf) {
		boolean isNull = (DataUtils.readVarInt(buf) == 0);
		IMultilingualKeyValue x = null;

		if (!isNull) {
			String concept = strDT.read(buf);
			List<IMultilingualNodeValue> nodeList = nodeValueListDT.read(buf);
			x = new MultilingualKeyValue(concept, nodeList);
		}
		return x;
	}

	@Override
	public IMultilingualKeyValue[] createStorage(int size) {
		return new IMultilingualKeyValue[size];
	}

}
