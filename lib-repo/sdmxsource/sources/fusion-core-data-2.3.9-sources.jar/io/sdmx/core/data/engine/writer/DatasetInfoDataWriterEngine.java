package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.DATA_POSITION;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.utils.core.collection.KeyValueImpl;
import it.unimi.dsi.fastutil.objects.Object2IntAVLTreeMap;

/**
 * Captures all the information about a dataset's series and series codes as they are being written.
 */
public class DatasetInfoDataWriterEngine implements ISeriesObsDataWriterEngine {

	//A map containing the codes that have been reported against the given dimension
	private Map<String, List<String>> codesForComponentMap;
	
	private Set<String> componentCodes = new HashSet<>(); //Quick lookup
	
	protected List<String> additionalObsAttributes;
	protected List<String> additionalSeriesAttributes;

	//The current data structure that the writer engine is outputting data for
	protected DataStructureSuperBean currentDSDSuperBean;

	//A list of all the dimensions and series level attributes for a DSD
	private List<DimensionSuperBean> allDimensions;
	
	private Object2IntAVLTreeMap<String> indexOfCode = new Object2IntAVLTreeMap<>();

	//The following is relevant for calculating index of series

	//To get the DSD SuperBean
	protected SdmxSuperBeanRetrievalManager superBeanRetrievalManager;

	private IDatasetStructures structures;

	public DatasetInfoDataWriterEngine(SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		if(superBeanRetrievalManager == null) {
			throw new IllegalArgumentException("Can not construct DatasetInfoDataWriterEngine, missing required argument: SdmxSuperBeanRetrievalManager");
		}
		this.superBeanRetrievalManager = superBeanRetrievalManager;
	}
	
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		this.structures = structures;
		DataStructureBean dsd = structures.getDataStructure();
		this.currentDSDSuperBean = superBeanRetrievalManager.getDataStructureSuperBean(dsd.getURN());
		
		if(codesForComponentMap == null) {
			codesForComponentMap = new HashMap<>();
			additionalObsAttributes = new ArrayList<>();
			additionalSeriesAttributes = new ArrayList<>();
			allDimensions = currentDSDSuperBean.getDimensions();
			for(ComponentSuperBean<?> currentComponent : currentDSDSuperBean.getComponents()) {
				codesForComponentMap.put(currentComponent.getId(), new ArrayList<String>());
			}
			
			if (datasetAttributes != null) {
				for(KeyValue kv : datasetAttributes.getAttributes()) {
					storeComponentValue(kv, DATA_POSITION.DATASET_ATTRIBUTE);
				}
			}
			
			codesForComponentMap.put(DimensionBean.TIME_DIMENSION_FIXED_ID, new ArrayList<String>());
		}
	}

	@Override
	public void writeKey(Keyable key) {
		storeComponentValues(key.getKey(), DATA_POSITION.SERIES_KEY);
		storeComponentValues(key.getAttributes(), DATA_POSITION.SERIES_KEY_ATTRIBUTE);
	}

	@Override
	public void writeObservation(Observation obs) {
		if(obs.getDimensionId() != null && obs.getDimensionValue() != null) {
			storeComponentValue(KeyValueImpl.getInstance(obs.getDimensionId(), obs.getDimensionValue()), DATA_POSITION.OBSERVATION);
		}
		storeComponentValues(obs.getAttributes(), DATA_POSITION.OBSERVATION_ATTRIBUTE);
	}

	private void storeComponentValues(List<KeyValue> kvs, DATA_POSITION currentPosition) {
		for(KeyValue kv : kvs) {
			storeComponentValue(kv, currentPosition);
		}
	}
	
	private void storeComponentValue(KeyValue kv, DATA_POSITION currentPosition) {
		if(kv == null) {
			return;
		}
		String componentId = kv.getConcept();
		if(!codesForComponentMap.containsKey(componentId)) {
			switch(currentPosition) {
			case SERIES_KEY_ATTRIBUTE :
				additionalSeriesAttributes.add(componentId);
				break;
			case OBSERVATION_ATTRIBUTE :
				additionalObsAttributes.add(componentId);
				break;
			}
			codesForComponentMap.put(componentId, new ArrayList<String>());
		}

		if (kv.hasMultipleValues()) {
			for(String value : kv.getValues()) {
				KeyValue singleValue = KeyValueImpl.getInstance(kv.getConcept(), value);
				addKeyValue(singleValue);
			}
		} else {
			addKeyValue(kv);
		}
	}
	
	private void addKeyValue(KeyValue kv) {
		if (!componentCodes.contains(kv.getShortCode())) {
			List<String> conceptValues = codesForComponentMap.get(kv.getConcept());
			indexOfCode.put(kv.getShortCode(), conceptValues.size());
			conceptValues.add(kv.getCode());
			componentCodes.add(kv.getShortCode());
		}
	}

	public List<DimensionSuperBean> getAllDimensions() {
		return allDimensions;
	}

	public List<String> getReportedValues(String componentId) {
		List<String> l = codesForComponentMap.get(componentId);
		if(l == null) {
			return new ArrayList<>();
		}
		return l;
	}

	public int getReportedIndex(String concept, String code) {
		return indexOfCode.getInt(concept+":"+code);
	}

	public DataStructureSuperBean getCurrentDSDSuperBean() {
		return currentDSDSuperBean;
	}

	public List<String> getAdditionalObsAttributes() {
		return additionalObsAttributes != null ? Collections.unmodifiableList(additionalObsAttributes) : null;
	}

	public List<String> getAdditionalSeriesAttributes() {
		return additionalSeriesAttributes != null ? Collections.unmodifiableList(additionalSeriesAttributes) : null;
	}

	@Override
	public void writeHeader(HeaderBean header) {

	}

	@Override
	public void close(FooterMessage... footer) {

	}

	public IDatasetStructures getStructures() {
		return structures;
	}
}