package io.sdmx.core.data.model.dataset.mvstore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.util.MVStoreUtil;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * This class represents a dataset stored in a MVStoreDatasetStorage.
 */
public class MVStoreDataset extends MVStoreAbstractDataset {
	private static final Logger LOG = LoggerFactory.getLogger(MVStoreDataset.class);

	private final DT_List<ObservationWrap, ObservationWrap> obsList;
	// map keyable position to list of obs
	private MVMap<Integer, List<ObservationWrap>> observationsForKey; 

	private List<ObservationWrap> obsForKey;  //in memory cache
	
	/**
	 * Create a new instance from scratch.
	 */
	public static MVStoreDataset createInstance(MVStore db, int index, IDatasetStructures structures) {
		return new MVStoreDataset(db, index, structures);
	}

	/**
	 * Retrieve an existing instance from the store.
	 */
	public static MVStoreDataset retrieveInstance(MVStore db, int index, SdmxBeanRetrievalManager brm) {
		return new MVStoreDataset(db, index, brm);
	}

	/**
	 * Build a MVStoreDataset instance from scratch.
	 */
	private MVStoreDataset(MVStore db, int index, IDatasetStructures structures) {
		super(db, index, structures);
		this.obsList = new DT_List<>(this.observationDT);
		openObservationMaps();
	}

	/**
	 * Build a MVStoreDataset instance from the information stored in the
	 * given MVStore.
	 */
	protected MVStoreDataset(MVStore db, int index, SdmxBeanRetrievalManager brm) {
		super(db, index, brm);
		this.obsList = new DT_List<>(this.observationDT);
		openObservationMaps();
	}
	
	/************************************************************************/
	/****************Initialisation				  ***************************/
	/************************************************************************/
	/**
	 * Open the Observation maps.
	 */
	protected void openObservationMaps() {
		observationsForKey = MVStoreUtil.openMap("observations", index, intDT, obsList, db);
		LOG.trace("Opened Observation maps for dataset {}.", index);
	}

	
	/************************************************************************/
	/****************Public API  				  ***************************/
	/************************************************************************/
	public void flush() {
		flushObs();
	}

	@Override
	public void writeKey(Keyable keyable) {
		flushObs();
		super.writeKey(keyable);
	}
	
	
	
	@Override
	public int getObsSize(int keyIdx) {
		final List<ObservationWrap> obsWrap = this.observationsForKey.get(keyIdx);
		return obsWrap == null ? 0 : obsWrap.size();
	}

	@Override
	public Iterator<Observation> getObs(int keyIdx) {
		flushObs();
		final List<ObservationWrap> obsWrap = this.observationsForKey.get(keyIdx);
		if(obsWrap == null) {
			return Collections.emptyIterator();
		}
		final Iterator<ObservationWrap> wrapIt = obsWrap.iterator();
		
		return new Iterator<Observation>() {
			
			@Override
			public boolean hasNext() {
				return wrapIt.hasNext();
			}

			@Override
			public Observation next() {
				ObservationWrap wrapped = wrapIt.next();
				if(wrapped != null) {
					return wrapped;
				}
				return null;
			}
		};
	}

	
	/**
	 * Tg
	 */
	@Override
	public void writeObs(Observation observation) {
		if(obsForKey == null) {
			obsForKey = new ArrayList<>(30);
		}
		ObservationWrap oWrap = new ObservationWrap(currentKeyablePosition, observation);
		obsForKey.add(oWrap);
		if(obsForKey.size() > 300) {
			flushObs();
		}
	}
	
	/**
	 * Update the mv store obs list from the local cache (if required)
	 */
	private void flushObs() {
		if(ObjectUtil.validCollection(obsForKey)) {
			List<ObservationWrap> obsList = this.observationsForKey.get(currentKeyablePosition);
			if(obsList == null) {
				obsList = new ArrayList<>(obsForKey.size());
			} else {
				List<ObservationWrap> newList = new ArrayList<>(obsList.size() + obsForKey.size());
				newList.addAll(obsList);
				obsList = newList;
			}
			obsList.addAll(obsForKey);
			this.observationsForKey.put(currentKeyablePosition, obsList);
			obsForKey = null;
		}
	}

}
