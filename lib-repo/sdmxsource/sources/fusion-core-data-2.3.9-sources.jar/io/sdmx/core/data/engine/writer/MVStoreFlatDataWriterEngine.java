package io.sdmx.core.data.engine.writer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_DataRow;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.util.MVStoreUtil;

public class MVStoreFlatDataWriterEngine implements ITemporaryFlatDataWriterEngine {
    private HeaderBean header;
    private DatasetHeaderBean dsHeader;
    private List<MVStoreFlatDataset> flatDatasets = new ArrayList<>();
    
    private final MVStore db;
    private IMVStore mvStore;
    private boolean closeFileOnClose;
    private boolean isProtected;

    private MVStoreFlatDataset currentMVStoreFlatDataset;
    
    public MVStoreFlatDataWriterEngine() {
        this(null);
    }
    
    public MVStoreFlatDataWriterEngine(File file) {
        this.mvStore = MVStoreUtil.getStore(file);
        this.db = mvStore.getStore();
    }
    
    @Override
    public void writeHeader(HeaderBean header) {
        this.header = header;
    }

    @Override
    public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
        this.dsHeader = header;
        currentMVStoreFlatDataset = null;
    }

    @Override
    public void writeRow(IDataRow row) {
        if(currentMVStoreFlatDataset == null) {
            currentMVStoreFlatDataset = new MVStoreFlatDataset(mvStore, row.getDatasetStructures());
            flatDatasets.add(currentMVStoreFlatDataset);
        }
        currentMVStoreFlatDataset.addRow(row);
    }
    
    public void setProtected(boolean protect) {
        this.isProtected = protect;
    }
    
    @Override
    public void close() {
        db.commit();
        if(closeFileOnClose && !this.isProtected) {
            mvStore.close();
        }
    }

    @Override
    public IFlatDataReaderEngine getDataReaderEngine() {
        return new MVStoreFlatDataReaderEngine(header, this.flatDatasets);
    }

    @Override
    public void removeResources() {
        mvStore.close();
        mvStore.delete();
        flatDatasets.clear();
    }

    private class MVStoreFlatDataset {
        private MVMap<Integer, IDataRow> rows;
        private DatasetHeaderBean header;
        int pos = 0;
        
        private MVStoreFlatDataset(IMVStore mvStore, IDatasetStructures structures) {
            rows = MVStoreUtil.openMap("dataRows", 0, DT_Integer.getInstance(false), new DT_DataRow(structures), mvStore);
            this.header = dsHeader;
        }
        
        private void addRow(IDataRow row) {
            rows.put(pos, row);
            pos++;
        }
    }
    
    private class MVStoreFlatDataReaderEngine implements IFlatDataReaderEngine {
        private HeaderBean header;
        private List<MVStoreFlatDataset> flatDatasets = new ArrayList<>();

        int dsIdx = -1;
        int rowIdx = -1;
        
        private boolean eof;
        
        private IDataRow currentRow;
        private MVStoreFlatDataset currentDataset;
        
        public MVStoreFlatDataReaderEngine(HeaderBean header, List<MVStoreFlatDataset> flatDatasets) {
            this.header = header;
            this.flatDatasets = flatDatasets;
        }

        @Override
        public HeaderBean readHeader() {
            return header;
        }

        @Override
        public DatasetHeaderBean readDatasetHeader() {
            if(eof) {
                return null;
            }
            if(currentDataset == null) {
                if(!moveNextDataSet()) {
                    return null;
                }
            }
            return currentDataset.header;
        }

        @Override
        public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
            if(eof) {
                return false;
            }
            if(currentDataset == null) {
                if(!moveNextDataSet()) {
                    return false;
                }
            }
            rowIdx++;
            if(currentDataset.rows.size() > rowIdx) {
                currentRow = currentDataset.rows.get(rowIdx);
                return true;
            }
            
            if(moveNextDataSet()) {
                return moveNextRow(exHandler);
            }
            
            return false;
        }
        
        private boolean moveNextDataSet() {
            dsIdx++;
            if(flatDatasets.size() > dsIdx) {
                currentDataset = flatDatasets.get(dsIdx);
                rowIdx = -1;
                return true;
            }
            eof = true;
            return false;
        }

        @Override
        public IDataRow getCurrentRow() {
            return currentRow;
        }

        @Override
        public void reset() {
            dsIdx = -1;
            rowIdx = -1;
            currentDataset = null;
            eof = false;
        }

        @Override
        public void close() {
            
        }

        @Override
        public IFlatDataReaderEngine createCopy() {
            return new MVStoreFlatDataReaderEngine(header, flatDatasets);
        }
        
    }

}
