package io.sdmx.core.data.manager;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.im.beans.container.DatasetStructures;

/**
 * Returns the {@link IDatasetStructures} based on the reference (unchanged)
 */
public class BeanRetrievalDatasetStructuresRetrievalManager implements IDatasetStructuresRetrievalManager {
    private SdmxBeanRetrievalManager beanRetrievalManager;

    public BeanRetrievalDatasetStructuresRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
        this.beanRetrievalManager = beanRetrievalManager;
    }

    public BeanRetrievalDatasetStructuresRetrievalManager(SdmxBeans beans) {
    	this.beanRetrievalManager = new InMemoryRetrievalManager(beans);
    }


	@Override
    public IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef) {
        if(sRef == null) {
            throw new SdmxSemmanticException("Unable to read dataset, no DSD reference found");
        }
        return new DatasetStructures(sRef, beanRetrievalManager);
    }
}