package io.sdmx.core.data.engine.retrieval;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.core.data.api.engine.writer.ISimpleDataWriterEngine;

public interface IDataStreamRetrievalManager {

	/**
	 * @param restQuery following SDMX rules, the leading data is not required, example IMF,BOP,1.0/F.UK+FR....?detail=seriesKeysOnly
	 * @param dataWriter the data writer that the result will be streamed to
	 * @throws SdmxNoResultsException if there is no data
	 */
	void getData(String restQuery, ISimpleDataWriterEngine dataWriter) throws SdmxNoResultsException;
	
}
