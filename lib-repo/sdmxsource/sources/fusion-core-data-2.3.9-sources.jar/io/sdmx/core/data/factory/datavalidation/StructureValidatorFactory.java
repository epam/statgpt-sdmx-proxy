package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.StructureDataValidationEngine;

public class StructureValidatorFactory implements DataValidatorFactory {

    @Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
        return new StructureDataValidationEngine(dsi);
    }

    @Override
    public String getId() {
        return "Structure";
    }

    @Override
    public String getName() {
        return "Valid Structure";
    }

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return false;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public String getDescription() {
		return "Ensures the Dataset reports all Dimensions and does not include any additional Dimensions or Attributes."
		        + "For example if a Dimension is missing then it will fail this test.";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.BLOCK_PUBLICATION;
	}
	
	@Override
	public int hashCode() {
		return "StructureValidatorFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof StructureValidatorFactory;
	}
}