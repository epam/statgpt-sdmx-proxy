package io.sdmx.core.data.manager;

import java.util.Collection;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.format.IInformationFormatManager;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.manager.format.AbstractFormatManager;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;


public class DataFormatManagerImpl extends AbstractFormatManager<DataFormat> implements DataFormatManager {
	private Set<DataFormatFactory> factories = null;
	
	public DataFormatManagerImpl(DataFormat defaultFormat, IInformationFormatManager informationFormatManager) {
		super(informationFormatManager, DataFormat.class);
		setDefaultFormat(defaultFormat);
	}

	@Override
	public DataFormat getDataFormat(ReadableDataLocation rdl) {
		if(rdl == null) {
			return null;
		}
		for(DataFormatFactory currentFactory : getDataFormatFactories()) {
			DataFormat df = currentFactory.getDataFormat(rdl);
			if(df != null) {
				return df;
			}
		}
		if(SdmxMessageUtil.getMessageType(rdl) == MESSAGE_TYPE.ERROR) {
			SdmxMessageUtil.parseSdmxErrorMessage(rdl);
		}
		return null;
	}
	
	private Collection<DataFormatFactory> getDataFormatFactories() throws IllegalArgumentException {
		if(factories == null) {
			Set<DataFormatFactory>  factories = new TreeSet<>(new Comparator<DataFormatFactory>() {

				@Override
				public int compare(DataFormatFactory arg0, DataFormatFactory arg1) {
					int compare = arg0.getPriority() - arg1.getPriority();
					if(compare != 0) {
						return compare;
					}
					return arg0.getClass().getName().compareTo(arg1.getClass().getName());
				}
			
			});
			for(DataFormatFactory factory :  FusionBeanStore.getBeans(DataFormatFactory.class)) {
				factories.add(factory);
			}
			this.factories = factories;
		}
		return factories;
	}

}
