package io.sdmx.core.data.engine.validate;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Ensures that Observation Dates match the type reported in the FREQ dimension of the DSD.
 * This Engine validates that the data conforms to the following specification:
 * <ul>
 * <li> The DSD is checked to determine the Frequency dimension.
 * <li> If present, is it a coded Dimension? If so, obtain the SDMX format of this dimension
 * <li> If so, does the Observation dates match to the given frequency code?
 * </ul>
 *
 * For performance a cache of dates is stored, so that we don't repeatedly re-parse the same dates.
 */
public class ObsTimeMatchesFrequencyValidationEngine implements DataValidationEngine {

	private Map<TIME_FORMAT, Set<String>> validDatesPreviouslyEncounteredForFrequency = new HashMap<>();
	private Set<String> ignoreFrequencies = new HashSet<>();

	private String freqDimensionId;
	private TIME_FORMAT seriesTimeFormat;

	public ObsTimeMatchesFrequencyValidationEngine(DimensionBean freqDimension) {
		freqDimensionId = freqDimension.getId();
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {}

	@Override
	public void validateKey(Keyable keyable, DataValidationEngineErrorHandler eh) {
		if (!ObjectUtil.validString(freqDimensionId)) {
			return;
		}

		seriesTimeFormat = null;
		String currentFrequencyCode = keyable.getReportedValue(freqDimensionId);
		if(currentFrequencyCode != null) {
			setSeriesTimeFormat(currentFrequencyCode);
		} else {
			currentFrequencyCode = keyable.getAttributeValue(currentFrequencyCode);
			if(currentFrequencyCode != null) {
				setSeriesTimeFormat(currentFrequencyCode);
			} 
		}
	}
	
	private boolean setSeriesTimeFormat(String freqCodeId) {
		if(!ignoreFrequencies.contains(freqCodeId)) {
			try {
				seriesTimeFormat = TIME_FORMAT.getTimeFormatFromCodeId(freqCodeId);
				return true;
			} catch (IllegalArgumentException iae) {
				ignoreFrequencies.add(freqCodeId);
			}
		}
		return false;
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		String reportedObsTime = obs.getDimensionValue();
		if (obs.hasObsTime()) {
			reportedObsTime = obs.getDimensionValue();
		} else {
			reportedObsTime = obs.getSeriesKey().getReportedValue(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
		if(reportedObsTime == null) {
			return;
		}
		if(seriesTimeFormat == null) {
			if(freqDimensionId.equalsIgnoreCase(obs.getDimensionId())) {
				if(!setSeriesTimeFormat(obs.getDimensionValue())) {
					return;
				}
			} else {
				String reportedAttr = obs.getAttributeValue(freqDimensionId);
				if(reportedAttr != null && !setSeriesTimeFormat(reportedAttr)) {
					return;
				}
			}
		}
		if(seriesTimeFormat == null) {
			return;
		}

		Set<String> validDatesPrevEncountered = validDatesPreviouslyEncounteredForFrequency.get(seriesTimeFormat);
		if (validDatesPrevEncountered == null) {
			validDatesPrevEncountered = new HashSet<>();
			validDatesPreviouslyEncounteredForFrequency.put(seriesTimeFormat, validDatesPrevEncountered);
		}

		if (!validDatesPrevEncountered.contains(reportedObsTime)) {
			if (seriesTimeFormat != null) {
				if(!DateUtil.isSdmxDate(reportedObsTime)) {
					//Reported date is not a valid date.
					//It it outside the remit of this validator to report syntactically invalid dates - this error should be picked up by the valid representation validator
					return;
				}
				// The method 'getObsAsTimeDate' is expensive, so once encountered a good date store it away

				SdmxDate sdmxDate = null;
				try {
					sdmxDate = obs.getSdmxObsTime();
				}  catch (Exception e) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.OBS_INVALID_DATE_FORMAT, reportedObsTime);
					eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID, reportedObsTime));
					return;
				}
				if(sdmxDate != null) {
					TIME_FORMAT timeFormatOfDate = sdmxDate.getTimeFormatOfDate();
					if (!timeFormatOfDate.equals(seriesTimeFormat)) {
						FusionError fe = new FusionErrorImpl(DataErrorCode.OBS_INVALID_DATE_TO_EXPECTED, freqDimensionId, seriesTimeFormat.getReadableCode(), reportedObsTime);
						eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID, reportedObsTime));
					} else {
						validDatesPrevEncountered.add(reportedObsTime);
					}
				}
			}
		}
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		return;
	}

	@Override
	public void close(DataValidationErrorReporter errorHandler) {
		freqDimensionId = null;
		validDatesPreviouslyEncounteredForFrequency = null;
	}
}
