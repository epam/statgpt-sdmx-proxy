package io.sdmx.core.data.model.mapping;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.api.model.mapping.ITimeMapping;
import io.sdmx.core.data.api.model.mapping.ITimePeriodMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.comparator.ComponentMappingComparator;
import io.sdmx.core.data.engine.mapping.ProxyTimePeriodMapping;
import io.sdmx.core.data.engine.mapping.TimePeriodMapping;
import io.sdmx.core.data.model.mapping.time.EpochMapping;
import io.sdmx.core.data.model.mapping.time.TimePatternMapping;
import io.sdmx.core.data.model.mapping.value.ComponentMappingRules;
import io.sdmx.core.data.util.MappingUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

public class MappingRulesImpl implements MappingRules {
	private IStructureMapBean mapBean;
	protected DataStructureBean inputDsd;
	protected DataStructureBean outputDsd;
	protected DataflowBean inputFlow;
	protected DataflowBean outputFlow;

	private Set<IComponentMappingRules> combinationMappingRules = new TreeSet<>(ComponentMappingComparator.INSTANCE);  	//Where more then one component is used to determine output
	private Map<String, Set<IComponentMappingRules>> singleMappingRules = new HashMap<>();	//Where only one component is used on input -> output

	private Map<String, Set<ITimeMapping>> timeMapping = new HashMap<>();
	private Map<String, DateFormat> dataFormatMap = null;  //Only required if the structure map references a timeFormatMapping

	private Set<String> mappedComponents;

	private Map<String, IRepresentationMapBean> representationMap = new HashMap<>();
	private MappingRules reverseMapping;
	private Map<String, String> datasetAttributes;
	private Map<String, String> fixedValues;
	
	private List<Set<String>> splitByMeasure;
	
	private ITimePeriodMapping timePeriodMapping;

	@Override
	public MappingRules getReverseMapping() {
		if(reverseMapping == null) {
			reverseMapping = new MappingRulesImpl(this);
		}
		return reverseMapping;
	}

	/**
	 * Creates a reverse mapping from the source mapping
	 * @param parentMapping - the reverse of the reverse mapping (the source) cached so it can be returned if the reverse mapping is called again
	 */
	private MappingRulesImpl(MappingRulesImpl parentMapping) {
		inputDsd = parentMapping.outputDsd;
		outputDsd = parentMapping.inputDsd;
		outputFlow = parentMapping.inputFlow;
		inputFlow = parentMapping.outputFlow;
		this.reverseMapping = parentMapping;

		//Rewrite the structure map to reverse the component mapping
		mapBean = parentMapping.mapBean.getMutableInstance().reverseMapping().getImmutableInstance();
		for(String repMapUrn : parentMapping.representationMap.keySet()) {
			IRepresentationMapBean repMap = parentMapping.representationMap.get(repMapUrn);
			this.representationMap.put(repMapUrn, repMap.getMutableInstance().reverseMapping(null).getImmutableInstance());
		}
		processComponentMaps(null);
	}
	
	/**
	 * Constructor for the engine,
	 * @param mapBean
	 * @param isSourceMapping if true then the Structure Map's source and target will be honoured, otherwise they will be swapped around as well as the rules
	 */
	public MappingRulesImpl(IStructureMapBean mapBean, SdmxBeanRetrievalManager beanRetrieval) {
		DataflowBean dfIn = null;
		DataflowBean dfOut = null;
		DataStructureBean dsdIn = null;
		DataStructureBean dsdOut = null;
		this.mapBean = mapBean;
		if(mapBean.getSourceRef().getTargetReference() == SDMX_STRUCTURE_TYPE.DATAFLOW) {
			dfIn = beanRetrieval.getBean(mapBean.getSourceRef().getReference().toType(DataflowBean.class));
			if(dfIn == null) {
				throw new CrossReferenceException(mapBean.getSourceRef());
			}

			dfOut = beanRetrieval.getBean(mapBean.getTargetRef().getReference().toType(DataflowBean.class));
			if(dfOut == null) {
				throw new CrossReferenceException(mapBean.getSourceRef());
			}
			dsdIn = beanRetrieval.getBean(dfIn.getDataStructureRef().getReference());
			dsdOut = beanRetrieval.getBean(dfOut.getDataStructureRef().getReference());
		} else if(mapBean.getSourceRef().getTargetReference() == SDMX_STRUCTURE_TYPE.DSD) {
			dsdIn = beanRetrieval.getBean(mapBean.getSourceRef().getReference().toType(DataStructureBean.class));
			dsdOut = beanRetrieval.getBean(mapBean.getTargetRef().getReference().toType(DataStructureBean.class));
		} else {
			throw new SdmxNotImplementedException("MappingEngine must be built from either a StructureMapBean referencing a Data Structure or a Dataflow, not " + mapBean.getSourceRef().getTargetReference().getType());
		}

		if(dsdIn == null) {
			throw new CrossReferenceException(mapBean.getSourceRef());
		}
		if(dsdOut == null) {
			throw new CrossReferenceException(mapBean.getTargetRef());
		}
		this.inputDsd = dsdIn;
		this.outputDsd = dsdOut;
		this.inputFlow = dfIn;
		this.outputFlow = dfOut;
		processComponentMaps(beanRetrieval);
	}
	
	private void processComponentMaps(SdmxBeanRetrievalManager beanRetrieval) {
		//Split by Measure
		splitByMeasure = new ArrayList<>();
		Set<String> inputMeasures = SdmxCollectionUtil.identifiablesIds(inputDsd.getMeasures());
		Set<String> outputMeasures = SdmxCollectionUtil.identifiablesIds(outputDsd.getMeasures());
		
		//Q1 - which output measures have more then one input measure mapping separately to it?
		Map<String, List<Set<String>>> outputMeasureToInputs = new HashMap<>();
		for(IComponentMapBean componentMap : mapBean.getComponentMaps()) {
			for(String targetComponent : componentMap.getTargetComponents()) {
				if(outputMeasures.contains(targetComponent)) {
					Set<String> inputMeasure = new HashSet<>();
					for(String sourceComponent : componentMap.getSourceComponents()) {
						if(inputMeasures.contains(sourceComponent)) {
							inputMeasure.add(sourceComponent);
						}
					}
					if(inputMeasure.size() > 0) {
						CollectionUtil.addToMappedList(outputMeasureToInputs, targetComponent, inputMeasure);
					}
				}
			}
		}
		//Q1 - which output measures have multiple inputs, this is a split
		for(String outputMeasure : outputMeasureToInputs.keySet()) {
			List<Set<String>> mappedFrom = outputMeasureToInputs.get(outputMeasure);
			if(mappedFrom.size() > 1) {
				splitByMeasure.addAll(mappedFrom);
			}
		}
		splitByMeasure = Collections.unmodifiableList(splitByMeasure);
		
		Set<String> dimensionIds = new HashSet<>(outputDsd.getDimensionIds());
		if(outputDsd.getTimeDimension() != null) {
			dimensionIds.add(outputDsd.getTimeDimension().getId());
		}
		
		//Component Maps
		for(IComponentMapBean componentMap : mapBean.getComponentMaps()) {
			boolean outputRequired = MappingUtil.isOutputRequired(componentMap, dimensionIds);
			IRepresentationMapBean repMap = componentMap.getRepresentationMapRef() == null ? null : getRepresentationMap(componentMap.getRepresentationMapRef(), beanRetrieval);
			IComponentMappingRules componentMapping = new ComponentMappingRules(componentMap.getSourceComponents(), componentMap.getTargetComponents(), repMap, outputRequired);
			
			if(componentMapping.getTargetComponents().contains(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				setTimePeriodMapping(new TimePeriodMapping(componentMapping));
				if(componentMapping.getTargetComponents().size() == 1) {
					continue;
				}
			}
			if(componentMapping.getSourceComponents().size() == 1) {
				String componentId = componentMapping.getSourceComponents().get(0);
				Set<IComponentMappingRules> maps = singleMappingRules.get(componentId);
				if(maps == null) {
					maps = new TreeSet<>(ComponentMappingComparator.INSTANCE);
					singleMappingRules.put(componentId, maps);
				}
				maps.add(componentMapping);
			} else {
				combinationMappingRules.add(componentMapping);
			}
		}
		this.singleMappingRules = Collections.unmodifiableMap(singleMappingRules);
		this.combinationMappingRules = Collections.unmodifiableSet(combinationMappingRules);
		
		//Time Maps
		IRepresentationMapBean timeMapping = null;
		if(mapBean.getTimeFormatMapping() != null) {
			timeMapping = getRepresentationMap(mapBean.getTimeFormatMapping(), beanRetrieval);
		}
		
		buildTimeMapping(timeMapping);
		for(ITimePatternMapBean componentMap : mapBean.getTimePatternMaps()) {
			boolean outputRequired = MappingUtil.isOutputRequired(componentMap, dimensionIds);
			ITimeMapping timeMappingRules = new TimePatternMapping(componentMap, this.dataFormatMap, outputRequired);
			if(componentMap.getTargetComponent().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				buildTimePeriodMapping(timeMappingRules);
			} else {
				CollectionUtil.addToMappedSet(this.timeMapping, componentMap.getSourceComponent(), timeMappingRules);
			}
		}
		for(IEpochMapBean componentMap : mapBean.getEpochMap()) {
			boolean outputRequired = MappingUtil.isOutputRequired(componentMap, dimensionIds);
			ITimeMapping timeMappingRules = new EpochMapping(componentMap, this.dataFormatMap, outputRequired);
			if(componentMap.getTargetComponent().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				buildTimePeriodMapping(timeMappingRules);
			} else {
				CollectionUtil.addToMappedSet(this.timeMapping, componentMap.getSourceComponent(), timeMappingRules);
			}
		}
		this.timeMapping = Collections.unmodifiableMap(this.timeMapping);
	}
	
	private void buildTimePeriodMapping(ITimeMapping timeMapping) {
		if(timeMapping.getFrequencyComponent() == null) {
			setTimePeriodMapping(new TimePeriodMapping(timeMapping));
		} else {
			String freqCompId = timeMapping.getFrequencyComponent();
			//Find Frequency Component
			if(getFixedValues().containsKey(freqCompId)) {
				setTimePeriodMapping(new TimePeriodMapping(timeMapping, getFixedValues().get(freqCompId)));
			} else {
				IComponentMappingRules freqComponent = null;
				outer:
				for(String singleMap : singleMappingRules.keySet()) {
					for(IComponentMappingRules rule : singleMappingRules.get(singleMap)) {
						if(rule.getTargetComponents().contains(freqCompId)) {
							freqComponent = rule;
							break outer;
						}
					}
				}
				if(freqComponent == null) {
					for(IComponentMappingRules rule : combinationMappingRules) {
						if(rule.getTargetComponents().contains(freqCompId)) {
							freqComponent = rule;
							break;
						}
					}
				}
				setTimePeriodMapping(new TimePeriodMapping(timeMapping, freqComponent));
			}
		}
	}
	
	private void setTimePeriodMapping(ITimePeriodMapping mapping) {
		if(this.timePeriodMapping != null) {
			if(this.timePeriodMapping instanceof ProxyTimePeriodMapping) {
				((ProxyTimePeriodMapping)this.timePeriodMapping).addMapping(mapping);
			} else {
				this.timePeriodMapping = new ProxyTimePeriodMapping(this.timePeriodMapping, mapping);
			}
		} else {
			this.timePeriodMapping = mapping;
		}
	}
	
	
	@Override
	public List<Set<String>> getSplitByMeasure() {
		return splitByMeasure;
	}


	@Override
	public ITimePeriodMapping getTagetTimePeriodMapping() {
		return timePeriodMapping;
	}


	@Override
	public Map<String, String> getFixedValues() {
		if(fixedValues == null) {
			Map<String, String> fixedOutputs;
			Map<String, String> dsAttributes = getDatasetAttributes();
			if(dsAttributes.isEmpty()) {
				this.fixedValues = mapBean.getFixedOutputs();
			} else {
				fixedOutputs = new HashMap<>();
				for(String key : mapBean.getFixedOutputs().keySet()) {
					if(!dsAttributes.containsKey(key)) {
						fixedOutputs.put(key, mapBean.getFixedOutputs().get(key));
					}
				}
				this.fixedValues = Collections.unmodifiableMap(fixedOutputs);
			}
		}
		return this.fixedValues;
	}

	@Override
	public Map<String, DateFormat> getDateFormatMap() {
		return dataFormatMap;
	}



	@Override
	public Map<String, Set<ITimeMapping>> getTimeMapping() {
		return timeMapping;
	}


	@Override
	public Map<String, String> getDatasetAttributes() {
		if(datasetAttributes == null) {
			Map<String, String> fixedOutputs = mapBean.getFixedOutputs();
			Map<String, String> returnMap = new HashMap<>();
			for(AttributeBean attr : outputDsd.getDatasetAttributes()) {
				String fixedValue = fixedOutputs.get(attr.getId());
				if(ObjectUtil.validString(fixedValue)) {
					returnMap.put(attr.getId(), fixedValue);
				}
			}
			datasetAttributes = Collections.unmodifiableMap(returnMap);
		}
		return datasetAttributes;
	}

	@Override
	public Map<String, Set<IComponentMappingRules>> getSingleMappingRules() {
		return singleMappingRules;
	}

	@Override
	public Set<IComponentMappingRules> getCombinationMappingRules() {
		return combinationMappingRules;
	}

	@Override
	public boolean hasMapping(ComponentBean component) {
		if(component == null) {
			return false;
		}
		return hasMapping(component.getId());
	}
	
	@Override
	public boolean hasMapping(String componentId) {
		if(componentId == null) {
			return false;
		}
		if(mappedComponents == null) {
			Set<String> mappedComponents = new HashSet<>();
			mappedComponents.addAll(singleMappingRules.keySet());
			for(IComponentMappingRules cMap : combinationMappingRules) {
				mappedComponents.addAll(cMap.getSourceComponents());
			}
			this.mappedComponents = mappedComponents;
		}
		return mappedComponents.contains(componentId);
	}
	
	@Override
	public IStructureMapBean getStructureMapBean() {
		return this.mapBean;
	}

	@Override
	public DataflowBean getFromDataflow() {
		return inputFlow;
	}

	@Override
	public DataflowBean getToDataflow() {
		return outputFlow;
	}

	@Override
	public DataStructureBean getFromDataStructure() {
		return inputDsd;
	}

	@Override
	public DataStructureBean getToDataStructure() {
		return outputDsd;
	}

	@Override
	public int hashCode() {
		return mapBean.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof MappingRules) {
			MappingRules that = (MappingRules) obj;
			return this.getStructureMapBean().equals(that.getStructureMapBean());
		}
		return false;
	}

	@Override
	public String toString() {
		return "Structure Map" + this.getStructureMapBean().getShortURN();
	}

	/**
	 * A representation map for time, example
	 * A = yyyy
	 * M = yyyy-Mnn
	 * @param repMap
	 */
	private void buildTimeMapping(IRepresentationMapBean repMap) {
		dataFormatMap = new HashMap<>();
		//Expects single input to single target
		if(repMap != null) {
			for(IMappedRelationshipBean mapping : repMap.getMappedValues()) {
				String input = mapping.getSourceValue().get(0).getValue();

				// FMR-693: If there is no target value, explicitly set the output to "null".
				// The RepresentationMap is stating that this should not be mapped at all.
				SimpleDateFormat sdf;
				List<String> targetValues = mapping.getTargetValue();
				if (targetValues.isEmpty()) {
					sdf = null;
				} else {
					String pattern = mapping.getTargetValue().get(0);
					sdf = DateUtil.getDateFormatter(pattern);
				}
				dataFormatMap.put(input, sdf);
			}
		}
		this.dataFormatMap = Collections.unmodifiableMap(this.dataFormatMap);
	}

	private IRepresentationMapBean getRepresentationMap(ICrossReferenceBean<IRepresentationMapBean> xsRef, SdmxBeanRetrievalManager beanRetrieval) {
		String urn = xsRef.getTargetUrn();
		IRepresentationMapBean repMap = representationMap.get(urn);
		if(repMap == null) {
			repMap = beanRetrieval.getBean(xsRef.getReference());
			if(repMap == null) {
				throw new CrossReferenceException(xsRef);
			}
			representationMap.put(urn, repMap);
		}
		return repMap;
	}

}
