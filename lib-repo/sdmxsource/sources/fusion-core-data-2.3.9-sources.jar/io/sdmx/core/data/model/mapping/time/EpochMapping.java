package io.sdmx.core.data.model.mapping.time;

import java.text.DateFormat;
import java.util.Date;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch.MAP_RULE_TYPE;
import io.sdmx.core.data.model.mapping.explain.ExplainMapComponent;
import io.sdmx.core.data.model.mapping.explain.ExplainMapMatch;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

/**
 * Uses rules from the {@link IEpochMapBean} to map between a source and target time period
 */
public class EpochMapping extends AbstractTimeMapping  {
	private double multiplier; //Needed to convert input dates into milliseconds
	private double offset; //Offset in milliseconds from 1970, needed to move input dates to 1970
	
	/**
	 * @param mappingRules
	 * @param dfMap optional - in the case the output frequency id is non-SDMX, the map contains the formatting rules
	 */
	public EpochMapping(IEpochMapBean mappingRules, Map<String, DateFormat> dfMap, boolean outputRequired) {
		super(mappingRules, dfMap, outputRequired);
		switch(mappingRules.getEpochInterval()) {
		case DAY:
			multiplier = 86400000;
			break;
		case MICROSECOND:
			multiplier = 0.001;
			break;
		case MILLISECOND:
			multiplier = 1;
			break;
		case NANOSECOND:
			multiplier = 0.000001;
			break;
		case SECOND:
			multiplier = 1000;
			break;
		default:
			break;
		}
		offset = mappingRules.getBasePeriod().getDate().getTime();
	}

	@Override
	public IExplainMapComponent explain(String sourceValue, String freq) {
		String output = getMappedValue(sourceValue, freq);
		if(output == null) {
			return null;
		}
		ExplainMapComponent comp = super.getExplainMapComponent();
		ExplainMapMatch match = new ExplainMapMatch();
		match.setRuleType(MAP_RULE_TYPE.TIME_EPOCH);
		match.setInput(sourceValue);
		match.setComponent(getTargetComponent());
		comp.addMatch(SdmxPeriodImpl.ALL_PERIODS, match);
		comp.addOutput(SdmxPeriodImpl.ALL_PERIODS, KeyValueImpl.getInstance(getTargetComponent(), getMappedValue(sourceValue, freq)));
		return comp;
	}

	@Override
	public String getMappedValue(String sourceValue, String freq) {
		//The logic here is to convert the input into milliseconds
		//and then move the base period of the input to 1970 so we can treat this as a Java Date
		try {
			Double asNum = Double.parseDouble(sourceValue);
			asNum = asNum * multiplier;
			
			//Move the period
			asNum = asNum + offset;
			
			long asLong  = asNum.longValue();
			//Convert to the number of milliseconds
			
			//Format the Date into a String
			return formatDate(new Date(asLong), freq);
			
		} catch(NumberFormatException e) {
			return null;
		}
	}
}
