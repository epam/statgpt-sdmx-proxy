package io.sdmx.core.data.api.model.validate;

import java.net.URL;
import java.util.List;
import java.util.Set;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.constant.LOADING_STATUS;
import io.sdmx.core.data.model.DataInformation;

public interface DataSetDetails {

	/**
	 * Returns the DataReaderEngine for the dataset index, or -1 will return a DataReaderEngine which will read all datasets
	 * @return
	 */
	DataReaderEngine getDataReaderEngine(int datasetIndex);

	/**
	 * Writes all the series and observations that failed validation to the output stream
	 * @param out
	 */
	void writeInvalidData(ISeriesObsDataWriterEngine dwe);

	/**
	 * Writes all the series and observations that passed validation to the output stream
	 * @param out
	 */
	void writeValidData(ISeriesObsDataWriterEngine dwe);

	/**
	 * If this dataset details was built from the result of reading data from a URL, then this will return
	 * the URL of the original data location
	 * @return
	 */
	URL getDataURL();

	/**
	 * Returns a Unique identifier for this DatasetDetails
	 * @return
	 */
	String getUid();

	/**
	 * Returns the underlying file format of the dataset
	 * @return
	 */
	String getFileFormat();

	/**
	 * @return the details of the underlying file format, if known
	 */
	FormatDetails getFormatDetails();

	/**
	 * Returns the file name of the dataset, or null if this was created outside of a 'file' concept
	 * @return
	 */
	String getFilename();

	/**
	 * Returns a count of the number of datasets that exist in the loaded data file
	 * @return
	 */
	int getDatasets();

	/**
	 * Returns the data information for all the datasets contained in this data file
	 * @return
	 */
	DataInformation getDataInformation();

	/**
	 * Returns the validation result for the dataset at the given index
	 * @param datasetIndex
	 * @return
	 */
	DataValidationResult getDataValidationResult(int datasetIndex);

	/**
	 * Requests that the DataSetDetails should perform a validation
	 * @param async if true the validation will occur in a separate thread
	 */
    void validateData(boolean async);

    /**
     * Performs a validation of the data, ensuring the Structure defined by the StructureReference is used for the validation.  The Dataset details
     * persists this structure choice against each dataset, so further actions of validation, or transform will use these structures to read the data
     *
     * @param sRefs a structure reference to use per dataset, if any list entries are null or the list size is less then the dataset count, then the existing structure set against the dataset will be used
	 * @param async if true the validation will occur in a separate thread
     */
    void validateData(List<IURNSingle<? extends IDSDRelatedBean>> sRefs, boolean async);

    /**
     * @return the current loading status of the DataSetDetails
     */
    LOADING_STATUS getLoadingStatus();

    /**
     * Sets the Data Structure or Dataflow to Map to
     * @param datasetIndex the index (zero indexed) of the dataset to apply the map to
     * @param sRef the DSD or Dataflow Reference to map the dataset to
     * @param async if true this will be performed in a new thread in the background
     *
     */
	void setMappedStructure(int datasetIndex, IURNSingle<? extends IStructureMapRelatedBean> sRef, boolean async);

	MaintainableBean getMappedStructure();

	Set<? extends MaintainableBean> getMappings();

	IURNSingle<? extends IDSDRelatedBean> getMissingReference();

	String getDsdError();

	String getSenderId();

	boolean getAttributesTested();

	boolean isMergeDatasets();

	/**
	 * @return an immutable list of footer messages read from the loaded dataset, or an empty list if none were read
	 */
	List<FooterMessage> getFooterMessages();

	void close();

}