package io.sdmx.core.data.api.manager;

import io.sdmx.api.sdmx.engine.DataErrorReporter;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;

/**
 * Rolls up all series and observations so there are no duplicates in the data file.
 */
public interface DataReaderConsolidationManager extends DataErrorReporter {
	

	/**
	 * Consolidates the series and observations from a data reader.   
	 * 
	 * @param dre
	 * @param exceptionHandler
	 * @param consolidationOptions may be null
     *
	 * @return either a new DataReaderEngine with the data consolidated, or if consolidation is not required, returns the same DataReaderEngine that was passed in 
	 */
	DataReaderEngine consolidateReader(DataReaderEngine dre, DataValidationErrorHandler exceptionHandler, IConsolidationOptions consolidationOptions);
}