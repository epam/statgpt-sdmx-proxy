package io.sdmx.core.data.model.dataset.mvstore.consolication;

import java.io.File;

import org.h2.mvstore.MVStore;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreAbstractDataset;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreAbstractDatasetStorage;

/**
 *   Stores data for consolidation - it cares about duplicates
 */
public class MVStoreDatasetStorageConsolidation { // {extends MVStoreAbstractDatasetStorage {
//	
//	public static MVStoreDatasetStorageConsolidation createInstance(File file) {
//		return new MVStoreDatasetStorageConsolidation(null, file);
//	}
//
//	public static MVStoreDatasetStorageConsolidation reopenInstance(SdmxBeanRetrievalManager brm, File file) {
//		if (!file.exists())
//			throw new RuntimeException("File " + file + "does not exist.");
//
//		return new MVStoreDatasetStorageConsolidation(brm, file);
//	}
//	
//	private MVStoreDatasetStorageConsolidation(SdmxBeanRetrievalManager brm, File file) {
//		super(brm, file);
//	}
//
//	@Override
//	protected MVStoreAbstractDataset retrieveInstance(MVStore store, int index, SdmxBeanRetrievalManager brm) {
//		return MVStoreConsolidatedDataset.retrieveInstance(store, index, brm);
//	}
//
//	@Override
//	public MVStoreConsolidatedDataset getDataset(int index) {
//		return (MVStoreConsolidatedDataset) super.getDataset(index);
//	}
	
	
}
