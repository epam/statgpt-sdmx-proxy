package io.sdmx.core.data.manager;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.core.data.engine.reader.KryoDataReaderEngine;
import io.sdmx.core.data.engine.writer.KryoDataWriterEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.engine.data.TemporaryDataWriterEngine;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.utils.core.application.FusionSystem;

public class KryoTemporaryDataManager implements ITemporaryDataManager {
	private static final Logger LOG = LoggerFactory.getLogger(KryoTemporaryDataManager.class);

	@Override
	public ITemporaryDataWriterEngine getDataWriterEngine() {
		WriteableDataLocationFactory wdlFactory = FusionSystem.getWdlFactory();
		WriteableDataLocation wdl = wdlFactory.getTemporaryWriteableDataLocation();
		KryoDataWriterEngine kryoDwe;
		try {
			kryoDwe = new KryoDataWriterEngine(wdl);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		ITemporaryDataWriterEngine writer = new TemporaryDataWriterEngine(kryoDwe, wdl);
		LOG.trace("KryoTemporaryDataManager.getDataWriterEngine() => {}",  writer);
		return writer;
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ITemporaryDataWriterEngine writer) {
		writer.close();
		SdmxBeanRetrievalManager brm = new InMemoryRetrievalManager(writer.getWrittenStructures());
		LOG.trace("KryoTemporaryDataManager.getDataReaderEngine({})", writer);
		return new KryoDataReaderEngine(writer.getReadableDataLocation(), brm);
	}

	@Override
	public void close(ITemporaryDataWriterEngine writer) {
		writer.close();
		writer.getReadableDataLocation().close();
	}
}
