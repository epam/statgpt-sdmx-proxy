package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;

public class MultilingualNodeValueSerializer extends Serializer<IMultilingualNodeValue> {
    private static final MultilingualNodeValueSerializer INSTANCE = new MultilingualNodeValueSerializer();

    public static MultilingualNodeValueSerializer getInstance() {
        return INSTANCE;
    }

    private MultilingualNodeValueSerializer() {}

    @Override
    public void write(Kryo kryo, Output output, IMultilingualNodeValue x) {
    	kryo.writeObject(output, x.getTexts(), TextTypeWrapperListSerializer.getInstance());  
    }

    @Override
    public IMultilingualNodeValue read(Kryo kryo, Input input, Class<? extends IMultilingualNodeValue> type) {
        List<TextTypeWrapper> multilingualTexts =  kryo.readObject(input, List.class, TextTypeWrapperListSerializer.getInstance());
        return new MultilingualNodeValue(multilingualTexts);
    }
}


