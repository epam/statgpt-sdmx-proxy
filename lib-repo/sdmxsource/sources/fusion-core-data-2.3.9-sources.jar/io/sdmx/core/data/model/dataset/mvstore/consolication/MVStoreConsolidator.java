package io.sdmx.core.data.model.dataset.mvstore.consolication;

/**
 * @deprecated to delete
 */
@Deprecated //see new model
public class MVStoreConsolidator extends MVStoreAbstractView {
//	private static final Logger LOG =
//			LoggerFactory.getLogger(MVStoreConsolidator.class);
//
//	private static final DataValidationErrorCode DUPLICATE_VALUE_REPORTED =
//			DataValidationErrorCode.DUPLICATE_VALUE_REPORTED;
//	private static final DataValidationErrorCode CONTRADICTORY_VALUE_REPORTED =
//			DataValidationErrorCode.CONTRADICTORY_VALUE_REPORTED;
//
//	private final MVStoreRetriever retriever;
//	private final String errorCategory;
//	private final DataValidationErrorHandler errorHandler;
//
//	private DATA_CONSOLIDATION dupeBehaviour;
//
//	/**
//	 * Pure consolidation, no error capture.
//	 */
//	 public MVStoreConsolidator(String errorCategory,
//			 MVStoreDatasetStorageConsolidation storage) {
//		 this(errorCategory, storage, null, DATA_CONSOLIDATION.USE_LAST_VALUE);
//	 }
//
//	 /**
//	  * Capture duplications as errors if errorHandler != null.
//	  */
//	 public MVStoreConsolidator(String errorCategory,
//			 MVStoreDatasetStorageConsolidation storage,
//			 DataValidationErrorHandler errorHandler,
//			 DATA_CONSOLIDATION dupeBehaviour) {
//		 super(storage);
//		 this.retriever = new MVStoreRetriever(storage);
//		 this.errorCategory = errorCategory;
//		 this.errorHandler = errorHandler;
//		 this.dupeBehaviour = dupeBehaviour;
//	 }
//
//	 /**
//	  * Tell if the dataset with the given index needs consolidation
//	  */
//	 private boolean needsConsolidation(int dsIx) {
//		 DATASET_ACTION action = getDatasetAction(dsIx);
//		 return DataConsolidationUtil.requiresConsolidation(action);
//	 }
//
//	 /**
//	  * Tell, based on dupeBehaviour, if values should be updated from new
//	  * occurrences or the first occurrence value should be kept.
//	  */
//	 private boolean getUpdateValues() {
//		 boolean updateValues = false;
//
//		 switch (dupeBehaviour) {
//		 case PRESERVE_DUPLICATES:
//			 // Do not break - behave like "USE_FIRST_VALUE"
//		 case USE_FIRST_VALUE:
//			 // Do nothing - this will preserve the first encountered value
//			 break;
//		 case USE_LAST_VALUE:
//			 // update values - this will keep the last encountered value
//			 updateValues = true;
//			 break;
//		 default:
//			 throw new IllegalArgumentException("Unexpected argument: " +
//					 dupeBehaviour);
//		 }
//
//		 return updateValues;
//	 }
//
//	 /**
//	  * Consolidate and return attributes for the dataset with the given index
//	  */
//	 @Override
//	 public List<KeyValue> getDatasetAttributes(int dsIx) {
//		 if (!needsConsolidation(dsIx))
//			 return retriever.getDatasetAttributes(dsIx);
//
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Map<String, KeyValue> attrVal = new HashMap<>();
//		 List<String> attrNames = new ArrayList<>();
//		 boolean updateValues = getUpdateValues();
//
//		 for (KeyValue kv2: ds.getDatasetAttributes()) {
//			 String concept = kv2.getConcept();
//			 KeyValue kv1 = attrVal.get(concept);
//
//			 if (kv1 == null) {
//				 attrVal.put(concept, kv2);
//				 attrNames.add(concept);
//			 } else if (!MVStoreUtils.keyValuesEquals(kv1, kv2)) {
//				 if (!kv2.hasMultipleValues() && (kv2.getCode() == null)) {
//					 // ignore null values and keep the current one
//					 //
//					 // FIXME: this is the old, incorrect behaviour, but we need
//					 //        support from data readers to avoid it and properly
//					 //        handle cases like EDI quadruplets
//				 } else {
//					 if (errorHandler != null) {
//						 DataError de = DataConsolidationUtil.duplicateValue(dsIx, kv1, kv2);
//
//						 errorHandler.handleError(de);
//					 }
//
//					 if (updateValues)
//						 attrVal.put(concept, kv2);
//				 }
//			 }
//		 }
//
//		 List<KeyValue> out = new ArrayList<>(attrNames.size());
//
//		 for (String name: attrNames)
//			 out.add(attrVal.get(name));
//
//		 return out;
//	 }
//
//	 /**
//	  * Tell if the occurrence at the given position is a full deletion for the
//	  * related keyable.
//	  * This is true only if both the following conditions are true:
//	  * - the occurrence has no attributes
//	  * - the occurrence has no observations
//	  */
//	 private boolean isFullDeletion(MVStoreConsolidatedDataset ds, Integer pos) {
//		 Keyable keyable = ds.getKeyable(pos);
//		 List<KeyValue> attributes = keyable.getAttributes();
//
//		 if ((attributes != null) && !attributes.isEmpty())
//			 return false;
//
//		 return (ds.getFirstObservationPosition(pos) == null);
//	 }
//
//	 /**
//	  * Tell if the keyable with the given key has a full deletion in the given
//	  * dataset
//	  */
//	 private Integer findFullDeletion(int dsIx, String key) {
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Integer basePosition = ds.getKeyBasePosition(key);
//
//		 if (basePosition != null) {
//			 if (isFullDeletion(ds, basePosition))
//				 return basePosition;
//
//			 for (Integer position: ds.getKeyableDuplicatePositions(basePosition))
//				 if (isFullDeletion(ds, position))
//					 return position;
//		 }
//
//		 return null;
//	 }
//
//
//
//
//
//	 /**
//	  * Tell if the keyable at this position should be ignored for the porpose
//	  * of deletions consolidation
//	  */
//	 private boolean shouldIgnore(int dsIx, Integer position, boolean fromObs) {
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Keyable keyable = ds.getKeyable(position);
//
//		 if (fromObs) {
//			 String key = keyable.getShortCode();
//			 Integer pos = findFullDeletion(dsIx, key);
//
//			 if (pos != null) {
//				 LOG.trace("Ignoring {}:* at {}/{}, full deletion for {} at {}/{}.",
//						 key, dsIx, position, key, dsIx, pos);
//
//				 return true;
//			 }
//		 }
//
//		 for (String key: KeyableUtil.getGroupKeys(keyable)) {
//			 Integer pos = findFullDeletion(dsIx, key);
//
//			 if (pos != null) {
//				 LOG.trace("Ignoring {}{} at {}/{}, full deletion for {} at {}/{}.",
//						 key, fromObs ? ":*" : "", dsIx, position,
//								 key, dsIx, pos);
//
//				 return true;
//			 }
//		 }
//
//		 return false;
//	 }
//
//	 /**
//	  * Return an iterator on the first position for any keyable
//	  */
//	 @Override
//	 public Iterator<Integer> getKeyableIterator(int dsIx) {
//		 if (!needsConsolidation(dsIx))
//			 return retriever.getKeyableIterator(dsIx);
//
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Iterator<Integer> iterator = ds.getKeyableBasePositionIterator();
//		 DATASET_ACTION action = getDatasetAction(dsIx);
//
//		 // In case of DELETE, ignore deletions for keyables which would be
//		 // subsumed by other, more general, deletions.
//		 // e.g.: ignore series for which a group deletion exists
//		 if (action == DATASET_ACTION.DELETE)
//			 return new Iterator<Integer>() {
//			 Iterator<Integer> inner = iterator;
//			 Integer buffer = null;
//
//			 @Override
//			 public boolean hasNext() {
//				 while ((buffer == null) && inner.hasNext()) {
//					 buffer = inner.next();
//
//					 if (shouldIgnore(dsIx, buffer, false))
//						 buffer = null;
//				 }
//
//				 return (buffer != null);
//			 }
//
//			 @Override
//			 public Integer next() {
//				 if (hasNext()) {
//					 Integer tmp = buffer;
//
//					 buffer = null;
//
//					 return tmp;
//				 }
//
//				 throw new NoSuchElementException();
//			 }
//		 };
//
//		 return iterator;
//	 }
//
//	 /**
//	  * Return a consolidated keyable for the given dataset index and position
//	  */
//	 @Override
//	 public Keyable getKeyable(int dsIx, Integer kPos) {
//		 Keyable keyable;
//
//		 if (!needsConsolidation(dsIx))
//			 keyable = retriever.getKeyable(dsIx, kPos);
//		 else {
//			 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//			 List<Integer> duplicates = ds.getKeyableDuplicatePositions(kPos);
//
//			 if (duplicates.isEmpty())
//				 keyable = ds.getKeyable(kPos);
//			 else
//				 keyable = mergeKeyables(dsIx, kPos, duplicates);
//		 }
//
//		 return keyable;
//	 }
//
//	 /**
//	  * Merge the keyable at position kPos1 with the duplicate keyables
//	  * at the given list of positions
//	  */
//	 private Keyable mergeKeyables(int dsIx,
//			 Integer kPos1,
//			 List<Integer> duplicates) {
//		 boolean isDelete = (getDatasetAction(dsIx) == DATASET_ACTION.DELETE);
//		 boolean updateValues = getUpdateValues();
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Keyable k1 = ds.getKeyable(kPos1);
//		 String key = k1.getShortCode();
//
//		 LOG.trace(" -> mergeKeyable({}, {}, {})", dsIx, kPos1, duplicates);
//
//		 // A full keyable deletion subsumes any other
//		 if (isDelete && isFullDeletion(ds, kPos1)) {
//			 LOG.trace("    full deletion for {} at {}/{}",
//					 key, dsIx, kPos1);
//			 return k1;
//		 }
//
//		 // temporary data structures to keep track of attribute values
//		 // and their positions, needed to procude error reports
//		 List<String> attrNames = new ArrayList<>();
//		 Map<String, Integer> attrPos = new HashMap<>();
//		 Map<String, KeyValue> attrVal = new HashMap<>();
//		 List<AnnotationBean> annotations = new ArrayList<>();
//
//		 // keep track of position and current value for each attribute
//		 List<KeyValue> attributes1 = k1.getAttributes();
//
//		 if (attributes1 != null)
//			 for (KeyValue kv1: k1.getAttributes()) {
//				 String concept = kv1.getConcept();
//
//				 attrNames.add(concept);
//				 attrPos.put(concept, kPos1);
//				 attrVal.put(concept, kv1);
//			 }
//
//		 annotations.addAll(k1.getAnnotations());
//
//		 // iterate on subsequent occurrences in order of appearance
//		 for (Integer pos2: duplicates) {
//			 Keyable k2 = ds.getKeyable(pos2);
//
//			 // A full keyable deletion subsumes any other
//			 if (isDelete && isFullDeletion(ds, pos2)) {
//				 LOG.trace("    full deletion for {} at {}/{}",
//						 key, dsIx, pos2);
//				 return k2;
//			 }
//
//			 for (KeyValue kv2: k2.getAttributes()) {
//				 String concept = kv2.getConcept();
//				 KeyValue kv1 = attrVal.get(concept);
//				 LOG.trace("kv1: {} vs kv2: {}", kv1, kv2);
//				 if (kv1 == null) {
//					 attrPos.put(concept, pos2);
//					 attrVal.put(concept, kv2);
//					 attrNames.add(concept);
//				 } else if (!MVStoreUtils.keyValuesEquals(kv1, kv2)) {
//					 if (!kv2.hasMultipleValues() && (kv2.getCode() == null)) {
//						 // ignore null values and keep the current one
//						 //
//						 // FIXME: this is the old, incorrect behaviour, but we need
//						 //        support from data readers to avoid it and properly
//						 //        handle cases like EDI quadruplets
//					 } else {
//						 if (errorHandler != null) {
//							 DataError de = contradictoryValue(dsIx, kv1, kv2, k2);
//
//							 errorHandler.handleError(de);
//						 }
//
//						 if (updateValues) {
//							 attrPos.put(concept, pos2);
//							 attrVal.put(concept, kv2);
//						 }
//					 }
//				 }
//
//				 annotations.addAll(k2.getAnnotations());
//			 }
//		 }
//
//		 List<KeyValue> attributes = new ArrayList<>(attrNames.size());
//
//		 for (String name: attrNames)
//			 attributes.add(attrVal.get(name));
//
//		 return new KeyableImpl(k1.getDataflow(),
//				 k1.getDataStructure(),
//				 k1.getGroupName(),
//				 k1.getKey(),
//				 attributes,
//				 annotations);
//	 }
//
//	 /**
//	  * Return an iterator on observation positions for the given keyable
//	  *
//	  * Please note that ObsPos instances returned by this iterator should be
//	  * considered as opaque tokens.
//	  * The n-th such token returned by this iterator, if passed to the
//	  * getObservation() method, will return the consolidated value for the
//	  * n-th observation for the given keyable.
//	  */
//	 @Override
//	 public Iterator<ObsPos> getObservationIterator(int dsIx, Integer kIndex) {
//		 Iterator<ObsPos> iterator;
//
//		 if (!needsConsolidation(dsIx))
//			 iterator = retriever.getObservationIterator(dsIx, kIndex);
//		 else {
//			 DATASET_ACTION action = getDatasetAction(dsIx);
//
//			 // In case of DELETE, ignore deletions for observations which would be
//			 // subsumed by other, more general, deletions.
//			 // e.g.: ignore observations for which a serie deletion exists
//			 if ((action == DATASET_ACTION.DELETE) &&
//					 shouldIgnore(dsIx, kIndex, true))
//				 iterator = new Iterator<ObsPos>() {
//				 @Override
//				 public boolean hasNext() {
//					 return false;
//				 }
//
//				 @Override
//				 public ObsPos next() {
//					 throw new NoSuchElementException();
//				 }
//			 };
//			 else {
//				 iterator = new Iterator<ObsPos>() {
//					 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//					 Iterator<ObsKey> inner = ds.getObservationKeyIndexIterator(kIndex);
//
//					 @Override
//					 public boolean hasNext() {
//						 return inner.hasNext();
//					 }
//
//					 @Override
//					 public ObsPos next() {
//						 ObsKey obsKey = inner.next();
//
//						 return ds.getObservationBasePosition(obsKey);
//					 }
//				 };
//			 }
//		 }
//
//		 return iterator;
//	 }
//
//	 /**
//	  * Return the observation for the given position
//	  */
//	 @Override
//	 public Observation getObservation(int dsIx, ObsPos oPos) {
//		 Observation observation;
//
//		 if (!needsConsolidation(dsIx))
//			 observation = retriever.getObservation(dsIx, oPos);
//		 else {
//			 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//			 List<ObsPos> duplicates = ds.getObservationDuplicatePositions(oPos);
//
//			 if (duplicates.isEmpty())
//				 observation = ds.getObservation(oPos);
//			 else
//				 observation = mergeObservations(dsIx, oPos, duplicates);
//		 }
//
//		 return observation;
//	 }
//
//	 private boolean isFullObservationDeletion(List<KeyValue> attrs,
//			 Map<String, String> measVals) {
//		 if ((attrs != null) && !attrs.isEmpty())
//			 return false;
//
//		 if ((measVals == null) || measVals.isEmpty())
//			 return true;
//
//		 // FIXME: this part is needed only because (at least) the EDI reader gives
//		 //        back {"OBS_VALUE" => null} for a full observation deletion.
//		 //        It should be removed when readers have been "fixed".
//		 if ((measVals.size() == 1) && measVals.containsKey("OBS_VALUE"))
//			 return true;
//
//		 return false;
//	 }
//
//	 /**
//	  * Merge the observation at position oPos1 with the duplicate observations
//	  * at the given list of positions
//	  */
//	 private Observation mergeObservations(int dsIx,
//			 ObsPos oPos1,
//			 List<ObsPos> duplicates) {
//		 boolean isDelete = (getDatasetAction(dsIx) == DATASET_ACTION.DELETE);
//		 boolean updateValues = getUpdateValues();
//		 MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		 Observation o1 = ds.getObservation(oPos1);
//		 String key = o1.getSeriesKey().getShortCode();
//		 String dimVal = o1.getDimensionValue();
//		 List<KeyValue> attributes1 = o1.getAttributes();
//		 Map<String, String> measureValues1 = o1.getMeasureValues();
//
//		 LOG.trace(" -> mergeObservations({}, {}, {})", dsIx, oPos1, duplicates);
//
//		 // A full observation deletion subsumes any other
//		 if (isDelete && isFullObservationDeletion(attributes1, measureValues1)) {
//			 LOG.trace("    full deletion for {}:{} at {}/{}",
//					 key, dimVal, dsIx, oPos1);
//			 return o1;
//		 }
//
//		 // temporary data structures to keep track of attribute and measure values
//		 // and their positions, needed to procude error reports
//		 List<String> attrNames = new ArrayList<>();
//		 Map<String, ObsPos> attrPos = new HashMap<>();
//		 Map<String, KeyValue> attrVal = new HashMap<>();
//		 Map<String, ObsPos> measPos = new HashMap<>();
//		 Map<String, String> measVal = new HashMap<>();
//		 List<AnnotationBean> annotations = new ArrayList<>();
//
//		 // keep track of position and current value for each attribute and measure
//		 if (attributes1 != null)
//			 for (KeyValue kv1: o1.getAttributes()) {
//				 String concept = kv1.getConcept();
//
//				 attrPos.put(concept, oPos1);
//				 attrVal.put(concept, kv1);
//				 attrNames.add(concept);
//			 }
//
//		 if (measureValues1 != null)
//			 for (Map.Entry<String, String> e: measureValues1.entrySet()) {
//				 String id = e.getKey();
//
//				 measPos.put(id, oPos1);
//				 measVal.put(id, e.getValue());
//			 }
//
//		 annotations.addAll(o1.getAnnotations());
//
//		 for (ObsPos oPos2: duplicates) {
//			 Observation o2 = ds.getObservation(oPos2);
//			 List<KeyValue> attributes2 = o2.getAttributes();
//			 Map<String, String> measureValues2 = o2.getMeasureValues();
//
//			 // A full observation deletion subsumes any other
//			 if (isDelete && isFullObservationDeletion(attributes2, measureValues2)) {
//				 LOG.trace("    full deletion for {}:{} at {}/{}",
//						 key, dimVal, dsIx, oPos2);
//				 return o2;
//			 }
//
//			 LOG.trace(" -> Merge observations Series: {}, oPos1: {}, oPos2: {}",
//					 o1.getSeriesKey().getShortCode(), oPos1, oPos2);
//
//			 if (attributes2 != null)
//				 for (KeyValue kv2: attributes2) {
//					 String concept = kv2.getConcept();
//					 KeyValue kv1 = attrVal.get(concept);
//
//					 if (kv1 == null) {
//						 attrPos.put(concept, oPos2);
//						 attrVal.put(concept, kv2);
//						 attrNames.add(concept);
//					 } else if (!MVStoreUtils.keyValuesEquals(kv1, kv2)) {
//						 if (!kv2.hasMultipleValues() && (kv2.getCode() == null)) {
//							 // ignore null values and keep the current one
//							 //
//							 // FIXME: this is the old, incorrect behaviour, but we need
//							 //        support from data readers to avoid it and properly
//							 //        handle cases like EDI quadruplets
//						 } else {
//							 if (errorHandler != null) {
//								 DataError de = contradictoryValue(dsIx, kv1, kv2, o2);
//
//								 errorHandler.handleError(de);
//							 }
//
//							 if (updateValues) {
//								 attrPos.put(concept, oPos2);
//								 attrVal.put(concept, kv2);
//							 }
//						 }
//					 }
//				 }
//
//			 if (measureValues2 != null)
//				 for (Map.Entry<String, String> e: measureValues2.entrySet()) {
//					 String id = e.getKey();
//					 String v1 = measVal.get(id);
//					 String v2 = e.getValue();
//
//					 if (v1 == null) {
//						 measPos.put(id, oPos2);
//						 measVal.put(id, v2);
//					 } else if (!v1.equals(v2)) {
//						 if (v2 == null) {
//							 // ignore null values and keep the current one
//							 //
//							 // FIXME: this is most likely wrong, but needed for now, as
//							 //        the EDI reader produces an {OBS_VALUE => null} entry
//							 //        in Observation.measuresMap when parsing an observation
//							 //        level attribute (e.g. OBS_COM in BIS_MACRO)
//						 } else {
//							 if (errorHandler != null) {
//								 DataError de = duplicateValue(dsIx, o2, id, v1, v2);
//
//								 errorHandler.handleError(de);
//							 }
//
//							 if (updateValues) {
//								 measPos.put(id, oPos2);
//								 measVal.put(id, v2);
//							 }
//						 }
//					 }
//				 }
//
//			 annotations.addAll(o2.getAnnotations());
//		 }
//
//		 List<KeyValue> attributes = new ArrayList<>(attrNames.size());
//
//		 for (String name: attrNames)
//			 attributes.add(attrVal.get(name));
//
//		 return new ObservationImpl(o1.getSeriesKey(),
//				 o1.getDimensionId(),
//				 o1.getDimensionValue(),
//				 measVal,
//				 attributes,
//				 annotations);
//	 }

//	 /**
//	  * Return a DUPLICATE_VALUE_REPORTED for dataset level attributes, when
//	  * overwriting value prev with value next
//	  */
//	 private DataError duplicateValue(int dsIx,
//			 KeyValue prev,
//			 KeyValue next) {
//		 FusionError fe = new FusionErrorImpl(DUPLICATE_VALUE_REPORTED,
//				 prev.getConcept(),
//				 MVStoreUtils.getValueString(prev),
//				 MVStoreUtils.getValueString(next));
//
//		 return new DataErrorImpl(errorCategory, dsIx, fe, next);
//	 }
//
//	 /**
//	  * Return a DUPLICATE_VALUE_REPORTED for observation measures, when
//	  * overwriting value prev with value next
//	  */
//	 private DataError duplicateValue(int dsIx,
//			 Observation observation,
//			 String measureId,
//			 String prev,
//			 String next) {
//		 KeyValue kvNext = KeyValueImpl.getInstance(measureId, next);
//		 String observationKey = MVStoreUtils.getObservationKey(observation);
//		 FusionError fe = new FusionErrorImpl(DUPLICATE_VALUE_REPORTED,
//				 observationKey,
//				 prev,
//				 next);
//
//		 return new DataErrorImpl(errorCategory, dsIx, fe, kvNext, observation);
//	 }
//
//	 /**
//	  * Return a CONTRADICTORY_VALUE_REPORTED for the given keyable, when
//	  * overwriting value prev with value next
//	  */
//	 private DataError contradictoryValue(int dsIx,
//			 KeyValue prev,
//			 KeyValue next,
//			 Keyable keyable) {
//		 FusionError fe = new FusionErrorImpl(CONTRADICTORY_VALUE_REPORTED,
//				 prev.getConcept(),
//				 MVStoreUtils.getValueString(prev),
//				 MVStoreUtils.getValueString(next),
//				 keyable.getShortCode());
//
//		 return new DataErrorImpl(errorCategory, dsIx, fe, next, keyable);
//	 }
//
//	 /**
//	  * Return a CONTRADICTORY_VALUE_REPORTED for the given observation, when
//	  * overwriting value prev with value next
//	  */
//	 private DataError contradictoryValue(int dsIx,
//			 KeyValue prev,
//			 KeyValue next,
//			 Observation observation) {
//		 Keyable keyable = observation.getSeriesKey();
//		 FusionError fe = new FusionErrorImpl(CONTRADICTORY_VALUE_REPORTED,
//				 prev.getConcept(),
//				 MVStoreUtils.getValueString(prev),
//				 MVStoreUtils.getValueString(next),
//				 keyable.getShortCode());
//
//		 return new DataErrorImpl(errorCategory, dsIx, fe, next, observation);
//	 }
}
