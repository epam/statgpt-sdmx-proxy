package io.sdmx.core.data.model;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.core.data.api.model.dataset.SeriesKey;
import io.sdmx.core.data.api.model.dataset.SeriesKeyValue;


public class SeriesKeyImpl implements SeriesKey, Externalizable {
	private static final long serialVersionUID = 1L;
	
	private Set<SeriesKeyValue> keyValues = new TreeSet<>();
	private Map<String, Set<KeyValue>> conceptValuesMap = new HashMap<>();
	
	private Map<String, String> conceptValueMap = new HashMap<>();
	
	private transient String toString;
	
	
	@Override
	public Set<SeriesKeyValue> getKeyValues() {
		return keyValues;
	}
	
	@Override
	public void setKeyValues(Set<SeriesKeyValue> keyValuesToAdd) {
		Set<SeriesKeyValue> p = new HashSet<>();
		for(SeriesKeyValue keyValue : keyValuesToAdd) {
			if(keyValues.add(keyValue)) {
				p.add(keyValue);
				Set<KeyValue> keyValuesForConcept;
				String concept = keyValue.getConcept();
				conceptValueMap.put(concept, keyValue.getCode());
				
				if(conceptValuesMap.containsKey(concept)) {
					keyValuesForConcept = conceptValuesMap.get(concept);
				} else {
					keyValuesForConcept = new HashSet<>();
					conceptValuesMap.put(concept, keyValuesForConcept);
				}
				keyValuesForConcept.add(keyValue);
			}
		}
		StringBuilder sb = new StringBuilder();
		for(SeriesKeyValue skv : keyValues) {
			sb.append(", " + skv.toString());
		}
		toString = sb.toString();
		for(SeriesKeyValue keyValue : p) {
			keyValue.addSeriesKey(this);	
		}
	}

	@Override
	public void addKeyValue(SeriesKeyValue keyValue) {
		if(keyValues.add(keyValue)) {
			keyValue.addSeriesKey(this);	
			
			Set<KeyValue> keyValuesForConcept;
			String concept = keyValue.getConcept();
			conceptValueMap.put(concept, keyValue.getCode());
			
			if(conceptValuesMap.containsKey(concept)) {
				keyValuesForConcept = conceptValuesMap.get(concept);
			} else {
				keyValuesForConcept = new HashSet<>();
				conceptValuesMap.put(concept, keyValuesForConcept);
			}
			keyValuesForConcept.add(keyValue);
			
			StringBuilder sb = new StringBuilder();
			for(SeriesKeyValue skv : keyValues) {
				sb.append(", " + skv.toString());
			}
			toString = sb.toString();
		}
	}
	
	@Override
	public String getValueForConcept(String concept) {
		return conceptValueMap.get(concept);
	}

	@Override
	public void removeKeyValue(SeriesKeyValue keyValue) {
		keyValues.remove(keyValue);
	}

	
	@Override
	public int hashCode() { 
		if(toString == null) {
			return super.hashCode();
		}
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		return obj.toString().equals(this.toString());
	}

	@Override
	public String toString() {
		if(toString == null) {
			return super.toString();
		}
		return toString;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(keyValues);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		Set<SeriesKeyValue> localkv = (Set<SeriesKeyValue>)in.readObject();
		for(SeriesKeyValue kv : localkv) {
			addKeyValue(kv);
		}
	}
}
