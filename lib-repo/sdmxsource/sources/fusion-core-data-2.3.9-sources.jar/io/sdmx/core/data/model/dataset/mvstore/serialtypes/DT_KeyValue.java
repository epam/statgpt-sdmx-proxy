package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.utils.core.collection.KeyValueImpl;

import java.nio.ByteBuffer;
import java.util.List;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

/**
 * Serialization for KeyValue.
 */
public class DT_KeyValue extends BasicDataType<KeyValue> {
  private static final DT_KeyValue INSTANCE = new DT_KeyValue();
  private static final DT_String strDT = DT_String.getInstance();
  private static final DT_List<String, String> listDT = new DT_List<>(strDT);
  private static final String[] empty = new String[0];

  private DT_KeyValue() {}

  public static DT_KeyValue getInstance() {
    return INSTANCE;
  }

  @Override
  public int getMemory(KeyValue x) {
    int size = 1; // null/code/values selector

    if (x != null) {
      size += strDT.getMemory(x.getConcept());

      if (x.hasMultipleValues())
        size += listDT.getMemory(x.getValues());
      else
        size += strDT.getMemory(x.getCode());
    }

    return size;
  }

  @Override
  public void write(WriteBuffer buf, KeyValue x) {
    if (x == null)
      buf.putVarInt(0);
    else {
      final boolean multiValued = x.hasMultipleValues();

      buf.putVarInt(multiValued ? 2 : 1);
      strDT.write(buf, x.getConcept());

      if (multiValued)
        listDT.write(buf, x.getValues());
      else
        strDT.write(buf, x.getCode());
    }
  }

  @Override
  public KeyValue read(ByteBuffer buf) {
    int selector = DataUtils.readVarInt(buf);
    KeyValue x = null;

    if (selector > 0) {
      String concept = strDT.read(buf);

      if (selector == 2) {
        List<String> values = listDT.read(buf);

        x = KeyValueImpl.getInstance(concept, values.toArray(empty));
      } else {
        String code = strDT.read(buf);

        x = KeyValueImpl.getInstance(concept, code);
      }
    }

    return x;
  }

  @Override
  public KeyValue[] createStorage(int size) {
    return new KeyValue[size];
  }
}
