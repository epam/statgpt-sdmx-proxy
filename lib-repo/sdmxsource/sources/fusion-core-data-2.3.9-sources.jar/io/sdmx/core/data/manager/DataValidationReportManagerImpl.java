package io.sdmx.core.data.manager;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.application.FusionIdentifier;
import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.api.engine.validate.IMetricsWriterEngine;
import io.sdmx.core.data.api.manager.DataValidationReportManager;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.constant.LOADING_STATUS;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.IDataErrorContainer;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public class DataValidationReportManagerImpl implements DataValidationReportManager {
	private static final Logger LOG = LoggerFactory.getLogger(DataValidationReportManagerImpl.class);

	private IMetricsWriterEngine iMetricsWriterEngine;
    private FusionIdentifier fusionIdentifier;

	public DataValidationReportManagerImpl(IMetricsWriterEngine iMetricsWriterEngine, FusionIdentifier fusionIdentifier) {
		this.iMetricsWriterEngine = iMetricsWriterEngine;
		this.fusionIdentifier = fusionIdentifier;
	}
	
	@Override
	public void writeValidationReport(DataSetDetails details, ValidationTransformationMetrics metrics, OutputStream out) {
		JsonGenerator jsonGenerator = getJsonGenerator(out);
		try {
			jsonGenerator.writeStartObject();
			writeMetrics(jsonGenerator, metrics);
			writeReport(jsonGenerator, details);
			jsonGenerator.writeEndObject();
			jsonGenerator.close();
		} catch (IOException e) {
			throw new SdmxException(e, "Could not write Validation Report");
		}
	}

	@Override
	public void writeValidationReport(IDataErrorContainer validationResult, OutputStream out) {
		JsonGenerator jsonGenerator = getJsonGenerator(out);
		try {
			jsonGenerator.writeStartArray();
			writeValidationReport(validationResult, jsonGenerator);
			jsonGenerator.writeEndArray();
			jsonGenerator.close();
		} catch (IOException e) {
			throw new SdmxException(e, "Could not write Validation Report");
		}
	}

	private JsonGenerator getJsonGenerator(OutputStream out) {
		JsonFactory factory = new JsonFactory();
		try {
			return factory.createGenerator(out, JsonEncoding.UTF8);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	@Override
	public void writeValidationReport(Throwable th, OutputStream out) {
		String msg = th.getMessage();
		if(msg == null) {
			msg = "Null Pointer";
		}

		// Fully log the exception to ease debugging.
		LOG.error("Validation error: ", th);

		JsonGenerator jsonGenerator = getJsonGenerator(out);
		try {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("Status", LOADING_STATUS.ERRORED.getStatus());
			jsonGenerator.writeBooleanField("Errors", true);
			jsonGenerator.writeStringField("Error", msg);
			jsonGenerator.writeEndObject();
			jsonGenerator.close();
		} catch (IOException e) {
			throw new SdmxException(e, "Could not write Validation Report");
		}
	}

	private void writeMetrics(JsonGenerator jsonGenerator, ValidationTransformationMetrics metrics) throws IOException {
		if(metrics != null) {
			iMetricsWriterEngine.writeMetrics(jsonGenerator, metrics);
		}
	}


	private void writeReport(JsonGenerator jsonGenerator, DataSetDetails details) throws IOException {
		jsonGenerator.writeStringField("FileFormat", details.getFileFormat());

		if(details.getFormatDetails() != null) {
			jsonGenerator.writeStringField("MimeType", details.getFormatDetails().getMimeType());
		}

		LOADING_STATUS loadingStatus = details.getLoadingStatus();
		if(details.getDataURL() != null) {
			jsonGenerator.writeStringField("DataURL", details.getDataURL().toString());
		}
		if(details.getFilename() != null) {
			jsonGenerator.writeStringField("FileName", details.getFilename());
		}
		if(loadingStatus == LOADING_STATUS.FINISHED) {
			try {
				DataReaderEngine dre = details.getDataReaderEngine(-1);
				if(dre.getHeader() != null) {
					writeDatasetHeaderSummary(dre.getHeader(), jsonGenerator);
				}
			} catch(Throwable th) {
				//Do nothing
			}
		}

		jsonGenerator.writeStringField("Status", loadingStatus.getStatus());

		switch(loadingStatus) {
		case DSD_INVALID:
		case DSD_MISSING:
		case DSD_INCORRECT:
		    jsonGenerator.writeBooleanField("Errors", true);
		    IURNSingle<? extends IDSDRelatedBean> ref = details.getMissingReference();
		    if (ref== null) {
		        jsonGenerator.writeStringField("Error", details.getDsdError());
		    } else {
		        jsonGenerator.writeArrayFieldStart("Datasets");
		        jsonGenerator.writeStartObject();
    		    if (ref.getSdmxStructure() == SDMX_STRUCTURE_TYPE.DATAFLOW) {
    		        jsonGenerator.writeStringField("Dataflow", ref.getURN());
    		    } else {
    		        jsonGenerator.writeStringField("DSD", ref.getURN());
    	        }
    		    jsonGenerator.writeEndObject();
    		    jsonGenerator.writeEndArray();
		    }
//		    jsonGenerator.writeStringField("Error", details.getDsdError());
	        break;
		case ERRORED:
		    jsonGenerator.writeBooleanField("Errors", true);
			jsonGenerator.writeStringField("Error", details.getDsdError());
			break;
		default :
			boolean preventsConversion = false;
			boolean preventsPublication = false;
			boolean hasErrors = false;

			for(int dsIdx=0; dsIdx < details.getDatasets(); dsIdx++) {
				DataValidationResult validationResult = details.getDataValidationResult(dsIdx);
				if(validationResult.hasErrors()) {
					hasErrors = true;
				}
			}
			jsonGenerator.writeBooleanField("Errors", hasErrors);
			jsonGenerator.writeArrayFieldStart("Datasets");
			for(int dsIdx=0; dsIdx < details.getDatasets(); dsIdx++) {
				jsonGenerator.writeStartObject();
				writeValidationReportForDataset(details, loadingStatus, dsIdx, jsonGenerator);

				DataValidationResult validationResult = details.getDataValidationResult(dsIdx);
				if(validationResult != null) {
					preventsConversion = validationResult.preventsConversion();
					preventsPublication = validationResult.preventsPublication();
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();

			if(loadingStatus == LOADING_STATUS.FINISHED) {
				jsonGenerator.writeBooleanField("PreventsConversion", preventsConversion);
				jsonGenerator.writeBooleanField("PreventsPublication", preventsPublication);
			}

			List<FooterMessage> footer = details.getFooterMessages();
			if(ObjectUtil.validCollection(footer)) {
				jsonGenerator.writeArrayFieldStart("FooterMessages");
				for(FooterMessage currentFooter : footer) {
					jsonGenerator.writeStartObject();
					jsonGenerator.writeStringField("Code", currentFooter.getCode());
					if(currentFooter.getSeverity() != null) {
						jsonGenerator.writeStringField("Severity", currentFooter.getSeverity().toString());
					}
					TextTypeWrapper text = TextTypeUtil.getDefaultLocale(currentFooter.getFooterText());
					jsonGenerator.writeStringField("Text", text.getValue());
					jsonGenerator.writeEndObject();
				}
				jsonGenerator.writeEndArray();
			}
		}
	}

	private void writeValidationReportForDataset(DataSetDetails details, LOADING_STATUS loadingStatus, int datasetIndex, JsonGenerator jsonGenerator) throws IOException {
		writeDatasetContent(details, datasetIndex, jsonGenerator);

		if(loadingStatus == LOADING_STATUS.FINISHED) {
			DataValidationResult validationResult = details.getDataValidationResult(datasetIndex);
			jsonGenerator.writeBooleanField("Errors", validationResult.hasErrors());
			if(validationResult.hasErrors()) {
				jsonGenerator.writeArrayFieldStart("ValidationReport");
				if(validationResult.hasErrors()) {
					writeValidationReport(validationResult, jsonGenerator);
				}
				jsonGenerator.writeEndArray();
			}
		}
	}

	private void writeDatasetHeaderSummary(HeaderBean header, JsonGenerator jsonGenerator) throws IOException {
		if(header.getPrepared() != null) {
			jsonGenerator.writeStringField("Prepared", DateUtil.formatDate(header.getPrepared()));
		}
		if(header.getSender() != null) {
			jsonGenerator.writeStringField("SenderId", header.getSender().getId());
		}
		jsonGenerator.writeStringField("DataSetId", header.getDatasetId());
	}

	private void writeDatasetContent(DataSetDetails details, int datasetIndex, JsonGenerator jsonGenerator) throws IOException {
		DataValidationResult validationResult = details.getDataValidationResult(datasetIndex);
		if (validationResult.getDsd() != null) {
			jsonGenerator.writeStringField("DSD", validationResult.getDsd().getUrn());
		}
		if(validationResult.getFlow() != null) {
			jsonGenerator.writeStringField("Dataflow", validationResult.getFlow().getUrn());
		}
		writeProvisionDetails(details, validationResult, jsonGenerator);
		jsonGenerator.writeNumberField("KeysCount", validationResult.getKeys());
		jsonGenerator.writeNumberField("ObsCount", validationResult.getObservations());
		jsonGenerator.writeNumberField("GroupsCount", validationResult.getGroups());
		if(validationResult.hasReportedPeriodDetails()) {
			jsonGenerator.writeObjectFieldStart("ReportedPeriods");
			Map<TIME_FORMAT, SdmxPeriod> reportedPeriods = validationResult.getReportingPeriods();
			for(TIME_FORMAT tf : reportedPeriods.keySet()) {
				jsonGenerator.writeObjectFieldStart(tf.getFrequencyCodeId());
				jsonGenerator.writeStringField("Name", tf.getReadableCode());
				SdmxPeriod period = reportedPeriods.get(tf);
				jsonGenerator.writeStringField("StartPeriod", period.getStartPeriod().getDateInSdmxFormat());
				jsonGenerator.writeStringField("EndPeriod", period.getEndPeriod().getDateInSdmxFormat());
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndObject();
		}

	}

	protected void writeProvisionDetails(DataSetDetails details, DataValidationResult validationResult, JsonGenerator jsonGenerator) throws IOException {
		if(validationResult.getProvision() != null) {
			jsonGenerator.writeStringField("DataProvider", validationResult.getProvision().getDataproviderRef().getTargetUrn());
			jsonGenerator.writeStringField("ProvisionAgreement", validationResult.getProvision().getUrn());
		}
	}

	private void writeValidationReport(IDataErrorContainer validationResult, JsonGenerator jsonGenerator) throws IOException {
		Map<String, List<DataError>> errors = validationResult.getDataErrors();
		for(String errorType : errors.keySet()) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("Type", errorType);
			jsonGenerator.writeArrayFieldStart("Errors");
			writeErrors(errors.get(errorType), jsonGenerator);
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
	}

	private void writeErrors(List<DataError> errors, JsonGenerator jsonGenerator) throws IOException {
		Map<String, DataError> groupedErrors = new TreeMap<>();

		//Group the errors by message and keys
		for(DataError currentError : errors) {
			String key = currentError.getMessage()+currentError.getDataset()+currentError.getComponent()+currentError.getErrorPosition().getName();

			DataError errorWithKey = groupedErrors.get(key);
			if(errorWithKey == null) {
				groupedErrors.put(key, currentError);
			} else {
				if(errorWithKey instanceof DataErrorWrapper) {
					((DataErrorWrapper)errorWithKey).addDataError(currentError);
				} else {
					DataErrorWrapper errorWrapper = new DataErrorWrapper(errorWithKey);
					errorWrapper.addDataError(currentError);
					groupedErrors.put(key, errorWrapper);
				}
			}
		}

		// Query a productInformation object (which may not exist) to obtain the product code (e.g. "REG")
		String productCode = null;
        if (fusionIdentifier != null) {
            productCode = fusionIdentifier.getProductCode();
        }
        if (productCode == null) {
            productCode = "000";
        }

		for(DataError currentError : groupedErrors.values()) {
			String errorType = currentError.getErrorPosition().getName();

			jsonGenerator.writeStartObject();
	        String errorCode = currentError.getErrorCode();
	        if (errorCode == null) {
	            errorCode = "-";
	        } else {
	            errorCode = productCode + "-" + errorCode;
	        }
			jsonGenerator.writeStringField("ErrorCode", errorCode);
			jsonGenerator.writeStringField("Message", currentError.getMessage());

			jsonGenerator.writeNumberField("Dataset", currentError.getDataset());
			if(currentError.getComponent() != null) {
				jsonGenerator.writeStringField("ComponentId", currentError.getComponent().getConcept());
				if(currentError.getComponent().getCode() != null) {
					jsonGenerator.writeStringField("ReportedValue", currentError.getComponent().getCode());
				}
			}
			jsonGenerator.writeStringField("Position", errorType);
			if(ObjectUtil.validCollection(currentError.getShortCode())) {
				jsonGenerator.writeArrayFieldStart("Keys");
				for(String key : currentError.getShortCode()) {
					jsonGenerator.writeString(key);
				}
				jsonGenerator.writeEndArray();
			}
			jsonGenerator.writeEndObject();
		}
	}

	/**
	 * Inner class to support the grouping of data errors
	 */
	private class DataErrorWrapper implements DataError {
		private int dataset;
		private String message;
		private List<String> shortCodes = new ArrayList<>();;
		private ERROR_POSITION errorPosition;
		private String errorCategory;
		private KeyValue component;
        private String errorCode;

		public DataErrorWrapper(DataError dataError) {
			this.dataset = dataError.getDataset();
			this.errorCode = dataError.getErrorCode();
			this.message = dataError.getMessage();
			if(dataError.getShortCode() != null) {
				this.shortCodes.addAll(dataError.getShortCode());
			}
			this.component = dataError.getComponent();
			this.errorCategory = dataError.getErrorCategory();
			this.errorPosition = dataError.getErrorPosition();
		}

		public void addDataError(DataError dataError) {
			if(dataError.getShortCode() != null) {
				this.shortCodes.addAll(dataError.getShortCode());
			}
		}

		@Override
		public int getDataset() {
			return dataset;
		}

		@Override
		public String getMessage() {
			return message;
		}

		@Override
		public KeyValue getComponent() {
			return component;
		}

		@Override
		public List<String> getShortCode() {
			return shortCodes;
		}

		@Override
		public ERROR_POSITION getErrorPosition() {
			return errorPosition;
		}

		@Override
		public String getErrorCategory() {
			return errorCategory;
		}

        @Override
        public String getErrorCode() {
            return errorCode;
        }
	}
}
