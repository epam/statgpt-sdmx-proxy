package io.sdmx.core.data.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.manager.DataReaderConsolidationManager;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.util.DataTransformOptions;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.error.DataErrorImpl;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;


/**
 * Fixes issue
 *
 * FR-2758 "Improve data consolidation performance for highly fragmented files" introduced the AdvancedDataReaderConsolidationManager
 *
 * This consolidation process reads the file and buffers the first 5k duplicate series/obs.
 *
 * A second reader reads the file, and writes it to the output as Compact data, each time a duplicate position is hit
 * the buffered series and obs are merged and output.  When a duplicate is output, the first reader is told to remove
 * the series from its buffer, and the first reader advances again to read more series until the 5k limit is once
 * again hit on the buffer.
 *
 * If the second reader encounters a series which is has read in the past, but knows has already been written, then
 * it knows the file must undergo a second consolidation pass.  This involves passing back in the consolidated dataset
 * for another pass, once again finding and merging the duplicates.
 *
 * If the second reader finds no duplicate series, no duplication is required.
 *
 *
 */
public class AdvancedDataReaderConsolidationManager implements DataReaderConsolidationManager {
	private static final Logger LOG = LoggerFactory.getLogger(AdvancedDataReaderConsolidationManager.class);

	private ITemporaryDataManager temporaryDataManager;

	public AdvancedDataReaderConsolidationManager(ITemporaryDataManager temporaryDataManager) {
		this.temporaryDataManager = temporaryDataManager;
	}

	private static int LIMIT = 5000;

	@Override
	public String getName() {
		return "Duplicate Observations";
	}

	@Override
	public String getDescription() {
		return "Ensures the data file does not contain any duplications which contradict each other. For example, if two observations for the same period, reporting different observation values, will be reported as a duplicate error.";
	}

	@Override
	public String getId() {
		return "Duplicate";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.BLOCK_PUBLICATION;
	}

	@Override
	public DataReaderEngine consolidateReader(DataReaderEngine dre, DataValidationErrorHandler exceptionHandler, IConsolidationOptions consolidationOptions) {
		return consolidateDataset(dre, 0, exceptionHandler);
	}

	private DataReaderEngine consolidateDataset(DataReaderEngine dre, int datasetIndex, DataValidationErrorHandler exceptionHandler) {
		boolean nextDataset = false;
		DuplicateResult result = null;
		int i = 0;

		DataReaderEngine dreCopy = null;
		ITemporaryDataWriterEngine dwe = null;

		do {
			try {
				LOG.info("Consolidate dataset iteration:"+i);
				i++;
				dre.reset();
				nextDataset = false;
				while(dre.moveNextDataset()) {
					if(dre.getDatasetPosition() == datasetIndex) {
						result = checkForDuplicates(dre);
						if(result.duplicates > 0) {
							break;
						}
						datasetIndex++;
					}
				}
				if (result == null || result.duplicates == 0) {
					return dre;
				}
				dreCopy = dre.createCopy();
				dwe = temporaryDataManager.getDataWriterEngine();

				//Copy Header and any preceeding datasets
				while(dreCopy.getDatasetPosition() < dre.getDatasetPosition()) {
					dreCopy.moveNextDataset();
					if(dreCopy.getDatasetPosition() == 0) {
						dwe.writeHeader(dreCopy.getHeader());
					}

					if(dreCopy.getDatasetPosition() < datasetIndex) {
						DataTransformationUtil.copyDataSet(dreCopy, dwe, true, DataTransformOptions.getInstance());
					} else {
						startDataset(dreCopy, dwe);
						break;
					}
				}


				Set<Integer> processedSeries = new HashSet<>();
				while(dreCopy.moveNextKeyable()) {
					if(processedSeries.contains(dreCopy.getKeyablePosition())) {
						continue;
					}
					Keyable key = dreCopy.getCurrentKey();
					String shortCode = key.getShortCode();

					if(result.duplicateSeries.containsKey(shortCode)) {

						List<DuplicateSeries> duplicates = result.duplicateSeries.get(shortCode);

						Map<String, Observation> obsMap = new HashMap<>();
						List<Observation> obsDupes = new ArrayList<>();
						for(DuplicateSeries ser : duplicates) {
							processedSeries.add(ser.idx);
							key = mergeKey(datasetIndex, key, ser.key, exceptionHandler);
							for(Observation obs : ser.obs) {
								String obsKey = obs.getDimensionValue() == null ? "" : obs.getDimensionValue();
								Observation existingObs = obsMap.get(obsKey);

								if (existingObs == null) {
									obsMap.put(obsKey, obs);
									continue;
								}
								Observation mergedObs = mergeObs(dre.getDatasetPosition(), key, obs, existingObs, exceptionHandler);

								if (mergedObs == null) {
									obsDupes.add(obs);
								} else {
									obsMap.put(obsKey, mergedObs);
								}
							}
						}
						dwe.writeKey(key);
						for(Observation obs : getObs(dreCopy, key, obsMap, obsDupes, exceptionHandler)) {
							dwe.writeObservation(obs);
						}
					} else {
						dwe.writeKey(key);
						for(Observation obs : getObs(dreCopy, key, new HashMap<String, Observation>(), new ArrayList<Observation>(), exceptionHandler)) {
							dwe.writeObservation(obs);
						}
					}

					result.removeSeries(shortCode);
				}

				while(dreCopy.moveNextDataset()) {
					nextDataset = true;
					//				DataTransformationUtil.copyData(dreCopy, dwe, DataTransformOptions.getInstance().setCloseWriter(false).setCopyHeader(false).setDatasetLimit(1).setResetReader(false));
					DataTransformationUtil.copyDataSet(dreCopy, dwe, true, DataTransformOptions.getInstance());
				}

				closeEngines(dwe, dre, dreCopy);
				LOG.info("Consolidate complete");

				dre = temporaryDataManager.getDataReaderEngine(dwe);
				if(result.requiresReprocessing == false && nextDataset == true) {
					datasetIndex++;
				}
			} catch (Throwable t) {
				closeEngines(dwe, dre, dreCopy);
				throw t;
			}
		} while(result.requiresReprocessing || nextDataset == true);

		return dre;
	}

	/**
	 * RFS-50: Closes the DataReader and DataWriter engines passed to it, which helps to ensure that the Registry does not hold a lock on a temporary file.
	 * @param dre
	 * @param dwe
	 * @param dreCopy
	 */
	private void closeEngines(ITemporaryDataWriterEngine dwe, DataReaderEngine... dres) {
		if (dwe != null) {
			try {
				dwe.close();
			} catch (Throwable t) {
				LOG.error("Unable to close 'dwe'");
			}
		}
		for (DataReaderEngine dre : dres) {
			if (dre != null) {
				try {
					dre.close();
				} catch (Throwable t) {
					LOG.error("Unable to close 'dre'");
				}
			}
		}
	}

	private List<Observation> getObs(DataReaderEngine dre, Keyable key, Map<String, Observation> obsMap, List<Observation> obsDupes, DataValidationErrorHandler exceptionHandler) {
		while(dre.moveNextObservation()) {
			Observation obs = dre.getCurrentObservation();

			String obsKey = obs.getDimensionValue() == null ? "" : obs.getDimensionValue();
			Observation existingObs = obsMap.get(obsKey);

			if (existingObs == null) {
				obsMap.put(obsKey, obs);
				continue;
			}

			Observation mergedObs = mergeObs(dre.getDatasetPosition(), key, existingObs, obs, exceptionHandler);

			if (mergedObs == null) {
				obsDupes.add(obs);
			} else {
				obsMap.put(obsKey, mergedObs);
			}
		}
		List<Observation> returnList = new ArrayList<>(obsMap.values());
		returnList.addAll(obsDupes);
		Collections.sort(returnList);
		return returnList;
	}

	/**
	 * Checks series and observations for duplicates
	 * @param dre
	 * @return
	 */
	private DuplicateResult checkForDuplicates(DataReaderEngine dre) {
		DuplicateResult duplicateResult = new DuplicateResult(dre);
		duplicateResult.addSeries();
		return duplicateResult;
	}

	private class DuplicateResult {
		// For each unique series create a Set of positions of where the series is located in the dataset.
		Map<String, List<DuplicateSeries>> duplicateSeries = new HashMap<>();
		Set<String> uniqueSeries = new HashSet<>();
		Set<String> allSeries = new HashSet<>();

		private int duplicates = 0;
		private DataReaderEngine dre;
		private boolean requiresReprocessing = false;
		private boolean hasMoreKeys = true;

		public DuplicateResult(DataReaderEngine dre) {
			this.dre = dre;
		}

		public void removeSeries(String duplicate) {
			int num = 0;
			if(duplicateSeries.containsKey(duplicate)) {
				for(DuplicateSeries ser : duplicateSeries.get(duplicate)) {
					num += 1 + ser.obs.size();
				}
				duplicateSeries.remove(duplicate);
				duplicates = duplicates - num;
			}
			uniqueSeries.remove(duplicate);
			addSeries();
		}

		public void addSeries() {
			while(duplicates < LIMIT && hasMoreKeys == true) {
				Keyable key = null;
				try {
					key = dre.getCurrentKey();
				} catch(Throwable th) {
					//just in case the data reader is not protecting against the possibiliy that the current key is requested when the move next obs has not been called yet
				}
				if(key == null) {
					dre.moveNextKeyable();
					key = dre.getCurrentKey();
					if(key == null) {
						return;
					}
				}
				String shortCode = key.getShortCode();
				if(uniqueSeries.contains(shortCode)) {
					List<DuplicateSeries> list = duplicateSeries.get(shortCode);
					if(list == null) {
						list = new ArrayList<>();
						duplicateSeries.put(shortCode, list);
					}
					DuplicateSeries ser = new DuplicateSeries(key, dre);
					list.add(ser);
					duplicates+= 1 + ser.obs.size();
				} else {
					if(allSeries.contains(shortCode)) {
						requiresReprocessing = true;
					}
					allSeries.add(shortCode);
					uniqueSeries.add(shortCode);
					if(duplicates == 0) {
						Set<String> obsKeys = new HashSet<>();
						while(dre.moveNextObservation()) {
							Observation obs = dre.getCurrentObservation();

							String obsKey = obs.getDimensionValue();
							if (obsKey == null) {
								obsKey = ""; //obs.getMeasure();
							}

							if (obsKey != null) {
								if(obsKeys.contains(obsKey)) {
									duplicates++;
									break;
								}
								obsKeys.add(obsKey);
							}
						}
					}
				}
				hasMoreKeys = dre.moveNextKeyable();
			}
		}
	}

	private class DuplicateSeries {
		private Keyable key;
		private List<Observation> obs = new ArrayList<>();
		private int idx;
		public DuplicateSeries(Keyable key, DataReaderEngine dre) {
			this.key = key;
			this.idx = dre.getKeyablePosition();
			while(dre.moveNextObservation()) {
				obs.add(dre.getCurrentObservation());
			}
		}

	}

	private void startDataset(DataReaderEngine dreFrom, ISeriesObsDataWriterEngine dataWriter) {
		IDatasetStructures structures = new DatasetStructures(dreFrom.getDataStructure(), dreFrom.getDataFlow(), dreFrom.getProvisionAgreement(), null);
		dataWriter.startDataset(structures, dreFrom.getCurrentDatasetHeaderBean(), dreFrom.getDatasetAttributes());
	}


	private Keyable mergeKey(int datasetPos, Keyable key1, Keyable key2, DataValidationErrorHandler exceptionHandler) {
		if (!ObjectUtil.validString(key2.getShortCode())) {
			return key1;
		}
		if(!key1.getShortCode().equals(key2.getShortCode())) {
			throw new SdmxException("Merge Key Error.  Can not merge key '"+key1.getShortCode()+"' with '"+key2.getShortCode()+"'");
		}
		if(key1.equals(key2)) {
			return key1;
		}

		List<KeyValue> attributes = mergeKeyValues(datasetPos, key1, null, key1.getAttributes(), key2.getAttributes(), exceptionHandler);
		AnnotationBean[] ann = mergeAnnotations(key1.getAnnotations(), key2.getAnnotations());
		if(!key1.isSeries()) {
			return KeyableImpl.groupKey(key1.getDataflow(), key1.getDataStructure(), key1.getGroupName(), key1.getKey(), attributes, ann);
		} else {
			return KeyableImpl.seriesKey(key1.getDataflow(), key1.getDataStructure(), key1.getKey(), attributes, ann);
		}
	}

	/**
	 * Attempts to merge observations but if anything goes wrong during the process then return null
	 * @param seriesKey
	 * @param obs1
	 * @param obs2
	 * @param eh
	 * @return The merged Observation or null.
	 */
	private Observation mergeObs(int datasetPos, Keyable seriesKey, Observation obs1, Observation obs2, DataValidationErrorHandler eh) {
		List<KeyValue> attributes;
		try {
			attributes = mergeKeyValues(datasetPos, seriesKey, obs1, obs1.getAttributes(), obs2.getAttributes(), eh);
		} catch(SdmxSemmanticException se) {
			return null;
		}
		AnnotationBean[] ann = mergeAnnotations(obs1.getAnnotations(), obs2.getAnnotations());

		List<KeyValue> measures;
		try{
			measures = mergeKeyValues(datasetPos, seriesKey, obs1, obs1.getMeasures(), obs2.getMeasures(), eh);
		} catch(SdmxSemmanticException se){
			return null;
		}
//
//		String obs1Value = obs1.getObservationValue();
//		String obs2Value = obs2.getObservationValue();
//		if(obs1Value != null && obs2Value != null) {
//			if(!ObjectUtil.equivalent(obs1Value, obs2Value)) {
//				String key = seriesKey.getShortCode();
//				if(obs1.getObsTime() != null) {
//					key += ":" +obs1.getObsTime();
//				}
//				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.DUPLICATE_VALUE_REPORTED, key, obs1.getObservationValue(), obs2.getObservationValue());
//				eh.handleError(new DataErrorImpl(this.getId(), datasetPos, fe, KeyValueImpl.getInstance(obs2.getMeasure(), obs2.getObservationValue()), obs1));
//				return null;
//			}
//		}
//		String obsValue = obs1.getObservationValue();
//		if(obsValue == null) {
//			obsValue = obs2.getObservationValue();
//		}

		return ObservationImpl.multipleMeasureCrossSection(seriesKey, obs1.getDimensionId(), obs1.getDimensionValue(), measures, attributes, ann);
//		new ObservationImpl(seriesKey, obs1.getObsTime(), obs1.getMeasure(), obsValue, attributes, ann);
	}

	private List<KeyValue> mergeKeyValues(int datasetPos, Keyable seriesKey, Observation obs1, List<KeyValue> kv1, List<KeyValue> kv2, DataValidationErrorHandler eh) {
		Map<String, String> keyValuesMap = new HashMap<>();
		for(KeyValue kv : kv1) {
			keyValuesMap.put(kv.getConcept(), kv.getCode());
		}
		for(KeyValue kv : kv2) {
			if(keyValuesMap.containsKey(kv.getConcept())) {
				String storedVal = keyValuesMap.get(kv.getConcept());
				if(storedVal == null) {
					keyValuesMap.put(kv.getConcept(), kv.getCode());
				} else if(kv.getCode() == null) {
					//Ignore
				} else if(!storedVal.equals(kv.getCode())) {
					FusionError fe = new FusionErrorImpl(DataValidationErrorCode.CONTRADICTORY_VALUE_REPORTED, kv.getConcept(), storedVal, kv.getCode(), seriesKey.getShortCode());
					// If there was a problem merging, simply add the exception to the handler and return null
					if(obs1 != null) {
						eh.handleError(new DataErrorImpl(this.getId(), datasetPos, fe, kv, obs1));
					} else {
						eh.handleError(new DataErrorImpl(this.getId(), datasetPos, fe, kv, seriesKey));
					}
				}
			} else {
				keyValuesMap.put(kv.getConcept(), kv.getCode());
			}
		}
		List<KeyValue> returnList = new ArrayList<>();
		for(String concept : keyValuesMap.keySet()) {
			returnList.add(KeyValueImpl.getInstance(concept, keyValuesMap.get(concept)));
		}
		return returnList;
	}

	private AnnotationBean[] mergeAnnotations(List<AnnotationBean> ann1, List<AnnotationBean> ann2) {
		int size = 0;
		if(ann1 != null) {
			size += ann1.size();
		}
		if(ann2 != null) {
			size += ann2.size();
		}
		AnnotationBean[] returnArray = new AnnotationBean[size];
		int i=0;
		if(ann1 != null) {
			for(AnnotationBean ann : ann1) {
				returnArray[i] = ann;
				i++;
			}
		}
		if(ann2 != null) {
			for(AnnotationBean ann : ann2) {
				returnArray[i] = ann;
				i++;
			}
		}

		return returnArray;
	}
}