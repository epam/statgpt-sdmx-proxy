package io.sdmx.core.data.model.mapping.explain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapOutputRow;

public class ExplainMapOutputRow implements IExplainMapOutputRow {
	private Map<SdmxPeriod, IDataRow> output = new HashMap<>();
	private List<IExplainMapComponent> componentBreakdown = new ArrayList<>();

	//package protected
	ExplainMapOutputRow() {}

	@Override
	public Map<SdmxPeriod, IDataRow> getOutput() {
		return Collections.unmodifiableMap(output);
	}

	@Override
	public List<IExplainMapComponent> getComponentBreakdown() {
		return Collections.unmodifiableList(componentBreakdown);
	}

	public void addExplainMapComponent(IExplainMapComponent emc) {
		this.componentBreakdown.add(emc);
	}
	
	public void addOutput(SdmxPeriod period, IDataRow row) {
		this.output.put(period, row);
	}
}
