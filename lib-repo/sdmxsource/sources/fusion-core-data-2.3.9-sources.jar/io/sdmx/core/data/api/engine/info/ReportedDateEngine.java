package io.sdmx.core.data.api.engine.info;

import java.util.List;
import java.util.Map;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.engine.DataReaderEngine;

public interface ReportedDateEngine {

	Map<TIME_FORMAT, List<String>> getAllReportedDates(DataReaderEngine dataReaderEngine);
	
}
