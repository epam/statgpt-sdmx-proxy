package io.sdmx.core.data.manager;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.manager.DataValidatorLevelRetrievalManager;

public class DefaultDataValidatorLevelRetrievalManager implements DataValidatorLevelRetrievalManager {

	@Override
	public VALIDATION_LEVEL getValidationLevel(String key) {
		return VALIDATION_LEVEL.REPORT;
	}

	@Override
	public Set<String> getAllIgnoreCategories() {
		return new HashSet<>();
	}

}
