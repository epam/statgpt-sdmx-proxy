package io.sdmx.core.data.manager;

import java.io.OutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.manager.FileQueryManager;
import io.sdmx.core.data.engine.query.FileQueryEngine;
import io.sdmx.core.data.engine.reader.DataReaderQueryFilter;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;

public class FileQueryManagerImpl implements FileQueryManager {

	private DataWriterManager dataWriterManager;
	private DataFormatManager dataFormatManager;
	private DataReaderManager dataReadManager;

	public FileQueryManagerImpl(DataReaderManager dataReadManager, DataWriterManager dataWriterManager, DataFormatManager dataFormatManager) {
		this.dataWriterManager = dataWriterManager;
		this.dataFormatManager = dataFormatManager;
		this.dataReadManager = dataReadManager;
	}


	@Override
	public void runQuery(ReadableDataLocation dataLocation,
			DataQuery dataQuery,
			OutputStream out) {

		DataFormat dataType = dataFormatManager.getDataFormat(dataLocation);
		ISeriesObsDataWriterEngine dataWriterEngine = dataWriterManager.getDataWriterEngine(dataType,  out);

		FileQueryEngine queryEngine = new FileQueryEngine(dataLocation, dataReadManager);
		queryEngine.getData(dataQuery, dataWriterEngine);
	}


	@Override
	public DataReaderEngine runQuery(ReadableDataLocation dataLocation, DataQuery dataQuery) {
		return runQueryInternal(dataLocation, dataQuery, null);
	}

	@Override
	public DataReaderEngine runQuery(ReadableDataLocation dataLocation, DataQuery dataQuery, DataValidationErrorHandler exceptionHandler) {
		return runQueryInternal(dataLocation, dataQuery, exceptionHandler);
	}

	//To get around method ambiguity
	private DataReaderEngine runQueryInternal(ReadableDataLocation dataLocation, DataQuery dataQuery, DataValidationErrorHandler exceptionHandler) {
		DataReaderEngine dataReaderEngine = dataReadManager.getDataReaderEngine(dataLocation,
				dataQuery.getDataStructure(),
				dataQuery.getDataflow(), null, exceptionHandler);

		return new DataReaderQueryFilter(dataReaderEngine, dataQuery);
	}


}