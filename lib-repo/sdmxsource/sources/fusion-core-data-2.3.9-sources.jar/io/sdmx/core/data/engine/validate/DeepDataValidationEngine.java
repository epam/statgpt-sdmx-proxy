package io.sdmx.core.data.engine.validate;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.MeasureSuperBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.util.DataValidationUtil;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Validates the data ensuring that the appropriate Dimensions, Attributes and Observations have valid content.
 * <p>
 * For performance a cache of dates is stored, so that we don't repeatedly re-parse the same dates.
 */
public class DeepDataValidationEngine implements DataValidationEngine {
	private static final Logger LOG = LoggerFactory.getLogger(DeepDataValidationEngine.class);

	protected DatasetInformation dsi;
	private Map<String, Date> previouslyParsedDates = new HashMap<>();
	private Set<String> previouslyErroredDates = new HashSet<>();

	private Keyable currentKey;
	private Map<Date, Observation> observationsForCurrentSeries;
	private List<CodelistBean> codelistsWithValidityPeriod;

	private HashMap<Date, Set<CodelistToCode>> dateToCodeAndFreq;

	private DataStructureSuperBean dsdSuperBean;

	private DATASET_ACTION action;
	private boolean hasTimeDimension;

	/**
	 *
	 * @author Matt Nelson
	 *
	 */
	class CodelistToCode {
		private String codelistUrn;
		private String codeId;

		public CodelistToCode(String codelistUrn, String codeId) {
			this.codelistUrn = codelistUrn;
			this.codeId = codeId;
		}

		@Override
		public boolean equals(Object o) {
			if (o == this) {
				return true;
			}

			if (!(o instanceof CodelistToCode)) {
				return false;
			}
			CodelistToCode that = (CodelistToCode) o;
			return Objects.equals(codelistUrn, that.codelistUrn) &&
					Objects.equals(codeId, that.codeId);
		}

		@Override
		public int hashCode() {
			return Objects.hash(codelistUrn, codeId);
		}
	}

	public DeepDataValidationEngine(DatasetInformation dsi) {
		this.dsi = dsi;

		//		if (dsi.getDataReaderEngine() != null && this.dsi.getDataReaderEngine().getHeader() != null) {
		//		    this.action = dsi.getDataReaderEngine().getHeader().getAction();
		//		}

		// SUPPORT-795
		// Code supplied by Lorenzo (BIS). It copes with his use-case of running the DeepDataValidationEngine
		// against an EDI file where the action is not INFORMATIONAL.
		this.action = dsi.getAction();

		// Determine if there is a measure Dimension
		dsdSuperBean = dsi.getDsdSuperBean();
		List<DimensionSuperBean> dimensions = dsdSuperBean.getDimensions();

		hasTimeDimension = dsdSuperBean.getComponentById(DimensionBean.TIME_DIMENSION_FIXED_ID) != null;

		// Setup the items required for testing Validity Periods of observations
		codelistsWithValidityPeriod = new ArrayList<>();
		for (DimensionSuperBean dsb : dimensions) {
			EnumeratedListBean<? extends EnumeratedItemBean> enumList = dsb.getCodelist(true);
			if (enumList == null || enumList.getStructureType() != SDMX_STRUCTURE_TYPE.CODE_LIST) {
				continue;
			}
			CodelistBean codelist = (CodelistBean) enumList;

			if (codelist.itemsHasValidityPeriod()) {
				codelistsWithValidityPeriod.add(codelist);
				break;
			}
		}

		// Setup cache for Dates to Codes and Freq
		dateToCodeAndFreq = new HashMap<>();
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {
		validateAttributable(dsAttr, dsi.getDatasetAttributesSuperBeans(), eh);
	}


	@Override
	public void validateKey(Keyable keyable, DataValidationEngineErrorHandler eh) {
		currentKey = keyable;
		observationsForCurrentSeries = new HashMap<>();
		Map<String, AttributeSuperBean> attributes = null;

		if(keyable.isSeries()) {
			attributes = dsi.getSeriesAttributesSuperBeans();
		} else {
			GroupSuperBean group = dsi.getDsdSuperBean().getGroupIgnoreCase(keyable.getGroupName());
			if(group == null) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NOT_DEFINE_GROUP_WITH_ID, keyable.getGroupName());
				eh.reportError(fe, (KeyValue) null);
			} else {
				attributes = dsi.getGroupAttributesSuperBeans().get(group.getId());
			}
		}

		for(KeyValue kv : keyable.getKey()) {
			DimensionSuperBean dimension = dsi.getDimensionMapSuperBeans().get(kv.getConcept());

			if(dimension == null) {
				// FR-2141: NPE defence
				DimensionBean dimensionBean = dsi.getDimensionMap().get(kv.getConcept());
				if (dimensionBean == null) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.COMPONENT_NOT_EXIST_IN_DSD, kv.getConcept());
					eh.reportError(fe, kv);
				}
			} else {
				if (ObjectUtil.validString(System.getProperty("IMF"))) {
					if(kv.getConcept().equals("INDICATOR")) {
						if(dsdSuperBean.getId().equals("ECOFIN_DSD")) {
							LOG.debug("Ignore IMF Indicator Dimension");
							continue;
						}
					}
				}
				validateReportedValue(dimension, kv, eh);
			}
		}
		validateAttributable(keyable, attributes, eh);
	}
	
	private void validateAttributable(Attributable attributable, Map<String, AttributeSuperBean> attributes, DataValidationEngineErrorHandler eh) {
		if(attributable == null) {
			return;
		}
		
		for(KeyValue kv : attributable.getAttributes()) {
			if(attributes != null) {
				AttributeSuperBean attribute = attributes.get(kv.getConcept());
				// Only check non-empty values in this ValidationEngine
				if(attribute != null) {
					if (this.action.equals(DATASET_ACTION.DELETE) && !ObjectUtil.validString(kv.getCode())) {
						// Delete messages may supply empty values
						continue;
					}
					validateReportedValue(attribute, kv, eh);
				}
			}
		}
		for(IMultilingualKeyValue kv : attributable.getMultilingualAttributes()){
			if(attributes!=null){
				AttributeSuperBean attribute = attributes.get(kv.getConcept());
				if(attribute != null){
					if (this.action.equals(DATASET_ACTION.DELETE) && !ObjectUtil.validString(kv.getConcept())){
						continue;
					}
					validateReportedMultilingualValue(attribute, kv, eh);
				}
			}
		}
	}

	/**
	 * Validates against the min and max allowed values, and also validates the reported content for each component
	 * @param component
	 * @param kv
	 * @param eh
	 */
	private void validateReportedValue(ComponentSuperBean<? extends ComponentBean> component, KeyValue kv, DataValidationEngineErrorHandler eh) {
		int minOccurs = component.getBuiltFrom().getMinOccurs();
		int size;
		if(kv.hasMultipleValues()) {
			int maxOccurs = component.getBuiltFrom().getMaxOccurs();
			size = kv.getValues().size();
			for(String reportedValue : kv.getValues()) {
				DataValidationUtil.validateComponentValue(component, reportedValue, eh);
			}
			if(size > maxOccurs) {
	            FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUES_EXCEEDS_MAX, Integer.toString(size), kv.getConcept(), Integer.toString(maxOccurs));
				eh.reportError(fe, kv);
			}
		} else {
			size = 1;
			DataValidationUtil.validateComponentValue(component, kv.getCode(), eh);
		}
		if(minOccurs > size) {
			FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUES_LESS_THAN_MIN, Integer.toString(size), kv.getConcept(), Integer.toString(minOccurs));
			eh.reportError(fe, kv);
		}
	}

	private void validateReportedMultilingualValue(ComponentSuperBean<? extends ComponentBean> component, IMultilingualKeyValue multilingualKv, DataValidationEngineErrorHandler eh) {
		int minOccurs = component.getBuiltFrom().getMinOccurs();
		int maxOccurs = component.getBuiltFrom().getMaxOccurs();
		int size = multilingualKv.getMultilingualNodeValues().size();
		for(IMultilingualNodeValue multilingualNodeValue : multilingualKv.getMultilingualNodeValues()) {
			 if (multilingualNodeValue.getTexts() != null){
				DataValidationUtil.validateTextFormat(component, multilingualNodeValue.getTexts(), eh);
			}
		}
		if(size > maxOccurs) {
			FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUES_EXCEEDS_MAX, Integer.toString(size), multilingualKv.getConcept(), Integer.toString(maxOccurs));
			eh.reportError(fe, multilingualKv);
		}
		if(minOccurs > size) {
			FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUES_LESS_THAN_MIN, Integer.toString(size), multilingualKv.getConcept(), Integer.toString(minOccurs));
			eh.reportError(fe, multilingualKv);
		}
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		if(obs.getDimensionId() != null) {
			if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(obs.getDimensionId())) {
				if (!ObjectUtil.validString(obs.getDimensionValue())) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.OBS_NOT_REPORT_TIME_PERIOD);
					eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID));
				} else if(previouslyErroredDates.contains(obs.getDimensionValue())) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.TIME_PERIOD_SYNTAX_ERROR, obs.getDimensionValue());
					eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID));

				} else if(!DateUtil.isSdmxDate(obs.getDimensionValue())) {
					previouslyErroredDates.add(obs.getDimensionValue());
					FusionError fe = new FusionErrorImpl(DataErrorCode.TIME_PERIOD_SYNTAX_ERROR, obs.getDimensionValue());
					eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID));

				} else if (codelistsWithValidityPeriod.size() > 0) {
					Date date = previouslyParsedDates.get(obs.getDimensionValue());
					if(date == null) {
						try {
							date = obs.getSdmxObsTime().getDate();
							previouslyParsedDates.put(obs.getDimensionValue(), date);
						} catch (Throwable t) {
							FusionError fe = new FusionErrorImpl("201-008", t.getMessage());
							eh.reportError(fe, KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID, obs.getDimensionValue()));
						}
					}
					observationsForCurrentSeries.put(date, obs);
				}
			} else {
				KeyValue kv = KeyValueImpl.getInstance(obs.getDimensionId(), obs.getDimensionValue());
				ComponentSuperBean comp = dsdSuperBean.getComponentById(obs.getDimensionId());
				if(comp == null) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.COMPONENT_NOT_EXIST_IN_DSD, obs.getDimensionId());
					eh.reportError(fe, kv);
				}  else {
					validateReportedValue(comp, kv, eh);
				}
			}
		}

		validateReportedValue(dsi.getDsdSuperBean(), obs, eh);
		validateAttributable(obs, dsi.getObsAttributesSuperBeans(), eh);
	}

	private void validateReportedValue(DataStructureSuperBean dsdSuperBean, Observation obs, DataValidationEngineErrorHandler eh) {
		if (this.action.equals(DATASET_ACTION.DELETE)) {
			return;
		}
		for(String measureId : obs.getMeasureMap().keySet()) {
			String obsValue = obs.getMeasureCode(measureId);
			MeasureSuperBean measure = dsdSuperBean.getMeasure(measureId);
			if (measure == null) {
				// This can happen if the measureId is being reported incorrectly.
				// i.e. the Reported Measure dimension is not present within the DSD
				throw new SdmxSemmanticException("The stated measure: '" +measureId + "' is not present in the DSD: " +
						dsdSuperBean.getBuiltFrom().getShortURN());
			}
			validateReportedValue(measure, KeyValueImpl.getInstance(measureId, obsValue), eh);
		}
	}

	@Override
	/**
	 * Validate codes that have been given a validity period to ensure no observations are reported outside of that period
	 */
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {

		if (codelistsWithValidityPeriod.size() == 0) {
			return;
		}
		List<KeyValue> key = currentKey.getKey();
		for (KeyValue keyValue : key) {
			String concept = keyValue.getConcept();
			String value = keyValue.getCode();

			DimensionSuperBean dimensionById = dsdSuperBean.getDimensionById(concept);
			EnumeratedListBean<? extends EnumeratedItemBean> cb = dimensionById.getCodelist(true);

			for (CodelistBean codelist : codelistsWithValidityPeriod) {
				if (cb!=codelist) {
					continue;
				}

				List<CodeBean> allCodes = codelist.getAllItemsById(value);
				if (allCodes.size() == 1) {
					// If there is only 1 element, there might not be validity periods. Can we early out?
					if (allCodes.get(0).getValidityPeriod() == null) {
						continue;
					}
				}

				for (Date obsDate : observationsForCurrentSeries.keySet()) {
					if (dateToCodeAndFreq.containsKey(obsDate)) {
						Set<CodelistToCode> set = dateToCodeAndFreq.get(obsDate);
						CodelistToCode ctc = new CodelistToCode(codelist.getUrn(), value);
						if (set.contains(ctc)) {
							// This obs is known fine.
							break;
						}
					}

					boolean obsValidDate = false;
					for (CodeBean aCode : allCodes) {
						SdmxPeriod validityPeriod = aCode.getValidityPeriod();
						if (validityPeriod.isInPeriod(obsDate)) {
							Set<CodelistToCode> s = dateToCodeAndFreq.get(obsDate);
							if (s == null) {
								s = new HashSet<>();
								dateToCodeAndFreq.put(obsDate, s);
							}
							CodelistToCode ctc = new CodelistToCode(codelist.getUrn(), value);
							s.add(ctc);
							obsValidDate = true;
							break;
						}
					}

					if (!obsValidDate) {
						// Not in date
						String codeId = allCodes.get(0).getId(); // The code ID will be the same on all of the CodeBeans
						Observation obs = observationsForCurrentSeries.get(obsDate);
						FusionError fe = new FusionErrorImpl(DataErrorCode.VALUE_INVALID_FOR_TIME_PERIOD, codeId, concept, obs.getDimensionValue() );
						exceptionHandler.reportError(fe, KeyValueImpl.getInstance(concept, codeId), obs);
					}
				}
			}
		}
	}

	@Override
	public void close(DataValidationErrorReporter exceptionHandler) {
		dsi = null;
		previouslyParsedDates = null;
	}
}
