package io.sdmx.core.data.service;

import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;
import java.util.zip.ZipOutputStream;

import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.service.data.IAsyncDataService;
import io.sdmx.core.data.api.manager.DataLoadManager;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.core.data.manager.DataLoadManagerImpl;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.core.data.model.transform.DataTransformationOptionsImpl;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.core.io.CSVReadableDataLocation;
import io.sdmx.utils.core.io.MultipartOutputStream;
import io.sdmx.utils.core.io.URLUtil.PROTOCOL;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class DataServiceActivator implements IAsyncDataService {
    private static final Logger LOG = LoggerFactory.getLogger(DataLoadManagerImpl.class);

	private DataLoadManager datasetManager;
	private DataFormatManager dataFormatManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;

	public DataServiceActivator(SdmxBeanRetrievalManager beanRetrievalManager,
			DataLoadManager datasetManager,
			DataFormatManager dataFormatManager
			) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.datasetManager = datasetManager;
		this.dataFormatManager = dataFormatManager;
	}

	@Override
	public String performDataLoad(Request req) {
		IURNSingle<? extends IDSDRelatedBean> strRef = null;
		if(req.getParameter("prov") != null) {
			strRef = req.getParameter("prov").startsWith("urn") ? URN.builder(req.getParameter("prov")).buildSingle(ProvisionAgreementBean.class) : null;
		}
		if(strRef == null && req.getParameter("dsd") != null) {
			strRef = req.getParameter("dsd").startsWith("urn") ? URN.builder(req.getParameter("dsd")).buildSingle(DataStructureBean.class) : null;
		}
		String dataFilename =  req.getParameter("dataFileName");
		if(!ObjectUtil.validString(dataFilename)) {
			dataFilename = "Unknown";
		}

		ReadableDataLocation rdl;
		URL url = null;
		boolean isFile = req.getParameter("dataUploadType") == null ? true : req.getParameter("dataUploadType").equals("file");
		if(isFile) {
			rdl = req.getReadableDataLocation();
			if(rdl == null) {
				throw new SdmxException("Data file is empty");
			}
		} else if(req.hasParameter("uploadUrl")) {
			String urlValue = req.getParameter("uploadUrl");
			try {
				url = new URL(urlValue);
			} catch (MalformedURLException e) {
				throw new IllegalArgumentException("The URL specified is not valid: " +urlValue);
			}
			dataFilename = url.getPath();
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			try {
				if(ObjectUtil.validString(username, password)) {
					AuthorizationUtil.storeAuthorizationInThreadLocal(username.trim(), password.trim());
				}
				rdl = RestMessageBroker.toReadableDataLocation(url, PROTOCOL.HTTP, PROTOCOL.HTTPS);
			} finally {
				AuthorizationUtil.clearAuthorizationFromThreadLocal();
			}
		} else {
			throw new IllegalArgumentException("Missing parameter uploadUrl");
		}
		if(ZipUtil.isAZip(rdl)) {
			ReadableDataLocation copy = ZipUtil.unzipFile(rdl);
			rdl.close();
			rdl = copy;
		}
		rdl = postProcessRDL(req, strRef, rdl);
		String uid;
		if (isFile) {
		    uid = datasetManager.getAsyncDatasetDetails(dataFilename, rdl, strRef);
		} else {
		    uid = datasetManager.getAsyncDatasetDetails(url, rdl, strRef);
		}
		if(LOG.isInfoEnabled()) {
		    if(strRef == null) {
		        LOG.info("Dataset loaded, UID={}", strRef, uid);
		    } else {
		        LOG.info("Dataset loaded for structure '{}', UID={}", strRef, uid);
		    }
		}
		return uid;
	}



	@Override
	public void writeLoadStatus(String uid, OutputStream out) {
		datasetManager.writeValidationReport(uid, out);
	}

	@Override
	public void revalidate(JSONObject json, OutputStream out) {
		String uid = JsonObjectUtil.getString(json, "UID", false);
		List<String> sRefs = JsonObjectUtil.unpackStringArray(json, "SRef", false);
		List<IURNSingle<? extends IDSDRelatedBean>> sRefList = new ArrayList<>();
		for(String s : sRefs) {
			sRefList.add(URN.builder(s).buildSingle(IDSDRelatedBean.class));
		}
		try {
			datasetManager.revalidate(uid, sRefList, true, out);
		} catch (TimeoutException e) {
			throw new SdmxException("Dataset not found with UID '"+uid+"' - possible timeout");
		}
	}

	@Override
	public void map(JSONObject json) {
		String uid = JsonObjectUtil.getString(json, "UID", false);
		int index = JsonObjectUtil.getInteger(json, "IDX", false);
		String urn = JsonObjectUtil.getString(json, "Map", true);
		IURNSingle<? extends IStructureMapRelatedBean> sRef = urn == null ? null : URN.builder(urn).buildSingle(IStructureMapRelatedBean.class);
		try {
			datasetManager.setMappedStructure(index, sRef, uid, true);
		} catch (TimeoutException e) {
			throw new SdmxException("Dataset not found with UID '"+uid+"' - possible timeout");
		}
	}


	@Override
	public void getData(String uid, String format, Boolean resolveCodes, String delimiter, String keyDelimiter,
			Boolean xAxis, String senderId, Integer datasetIndex, String map, Boolean isZip,
			Boolean includeUnmappedData, Boolean includeUnmappedReport, Boolean includeMetrics, Request request, IResponse response, Boolean skipValidation) {
	    LOG.info("Get data for uid: {}", uid);
	    DataFormat dataFormat = dataFormatManager.getFormat(request);
		IURNSingle<? extends IStructureMapRelatedBean> mapRef = map == null ? null : URN.builder(map).buildSingle(IStructureMapRelatedBean.class);

		boolean incUnmappedDataBool  = (includeUnmappedData != null && includeUnmappedData == true);
		boolean incUnmappedReportBool = (includeUnmappedReport != null && includeUnmappedReport == true);
		boolean incMetricsBool  = (includeMetrics != null && includeMetrics == true);
		boolean isZipBool  = (isZip != null && isZip == true);
		boolean isSkipValidation = (skipValidation != null && skipValidation == true);


		try {
			if(datasetIndex == null) {
				datasetIndex = -1;
			}
			OutputStream output = response.getOutputStream();
			DataTransformationOptions options;
			if(isZipBool)  {
				options = new DataTransformationOptionsImpl(dataFormat, new ZipOutputStream(output));
			} else if(incUnmappedDataBool) {
				options = new DataTransformationOptionsImpl(dataFormat, new MultipartOutputStream(output, "fusionboundary"));
			} else {
				options = new DataTransformationOptionsImpl(dataFormat, output);
			}
			options.setDatasetIndex(datasetIndex);
			options.setMappedOutputReference(mapRef);
			options.setIncludeUnmappedData(incUnmappedDataBool);
			options.setIncludeUnmappedReport(incUnmappedReportBool);
			options.setSenderId(senderId);
			options.setIncludeMetrics(incMetricsBool);
			if (isSkipValidation) {
				options.setSkipValidation(true);
			}
			
			datasetManager.writeDatasetDetails(uid, options);
			if(isZipBool == false && (incUnmappedDataBool || incMetricsBool)) {
				response.setContentType("multipart/mixed;boundary=fusionboundary");
				response.setHeader("content-disposition", "form-data");

			} else {
				String fileName = isZipBool ? "data" + ".zip" : "data." + dataFormat.getFormatDetails().getFileExtension();
				response.setContentType("application/octet-stream");
				response.setHeader("content-disposition", "attachment; filename = "+ fileName);
			}
		} catch (TimeoutException e) {
			throw new SdmxNoResultsException("Dataset not found, session may have expired");
		}
	}


	protected boolean verifyUploadURL(OutputStream out) {
		return true;
	}

	protected ReadableDataLocation postProcessRDL(Request request,  IURNSingle<? extends IDSDRelatedBean> sRef, ReadableDataLocation rdl) {
		String format = request.getParameter("dataformat");
		if(format != null && format.equals("csv")) {
			String delimiterStr = request.getParameter("csvDelimiter");
			DELIMITER delim = (delimiterStr == null ? DELIMITER.COMMA : DELIMITER.parseDelimiter(delimiterStr) );

			if(sRef != null) {
				return new CSVDataReadableDataLocation(rdl, delim, 0, new DatasetStructures(sRef, beanRetrievalManager));
			}
			return new CSVReadableDataLocation(rdl, delim, 0);
		}
		return rdl;
	}

}
