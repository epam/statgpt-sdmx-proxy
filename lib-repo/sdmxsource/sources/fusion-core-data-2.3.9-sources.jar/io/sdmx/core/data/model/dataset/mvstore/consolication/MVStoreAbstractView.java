package io.sdmx.core.data.model.dataset.mvstore.consolication;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.model.MVStoreView;


/**
 * @deprecated to delete
 */
@Deprecated //see new model
public abstract class MVStoreAbstractView implements MVStoreView {
//	protected static final List<Observation> NO_OBS = Collections.emptyList();
//
//	protected final MVStoreDatasetStorageConsolidation storage;
//
//	protected MVStoreAbstractView(MVStoreDatasetStorageConsolidation storage) {
//		this.storage = storage;
//	}
//
//
//	/**
//	 * Return a copy of this view
//	 */
//	@Override
//	public MVStoreView getCopy() {
//		return this;
//	}
//
//	/**
//	 * Return the dataset count
//	 */
//	@Override
//	public int getDatasetCount() {
//		return storage.getDatasets().size();
//	}
//
//	/**
//	 * Return the global header
//	 */
//	@Override
//	public HeaderBean getHeader() {
//		return storage.getHeader();
//	}
//
//	/**
//	 * Return the header for the dataset with the given index
//	 */
//	@Override
//	public DatasetHeaderBean getDatasetHeader(int dsIx) {
//		MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		return ds.getHeader();
//	}
//
//	/**
//	 * Return the provision agreement bean for the dataset with the given index
//	 */
//	@Override
//	public ProvisionAgreementBean getProvisionAgreement(int dsIx) {
//		MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		return ds.getStructures().getProvisionAgreement();
//	}
//
//	/**
//	 * Return the dataflow bean for the dataset with the given index
//	 */
//	@Override
//	public DataflowBean getDataflow(int dsIx) {
//		MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		return ds.getStructures().getDataflow();
//	}
//
//	/**
//	 * Return the datastructure bean for the dataset with the given index
//	 */
//	@Override
//	public DataStructureBean getDataStructure(int dsIx) {
//		MVStoreConsolidatedDataset ds = storage.getDataset(dsIx);
//		return ds.getStructures().getDataStructure();
//	}
//
//	@Override
//	public abstract List<KeyValue> getDatasetAttributes(int dsIx);
//
//	@Override
//	public abstract Iterator<Integer> getKeyableIterator(int dsIx);
//
//	@Override
//	public abstract Keyable getKeyable(int dsIx, Integer pos1);
}
