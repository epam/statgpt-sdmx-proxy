package io.sdmx.core.data.api.model.mapping;

import java.util.Map;

/**
 * Holds the mapping rules that are used to generates the output time period
 */
public interface ITimePeriodMapping extends IComponentMapping {

	/**
	 * Performs the mapping based on all the row information, and returns the output time period
	 * @param output frequency Id from FREQ Dimension (if known)
	 * @param inputValues example 22, March, 2020
	 * @return 2020-03
	 */
	String performMapping(Map<String, String> values);
	
	
	/**
	 * Explain any mapping that was used to generate the time period output
	 * @param values
	 * @return
	 */
	IExplainMapComponent explain(Map<String, String> values);
	
}
