package io.sdmx.core.data.api.model.dataset;

import java.util.Date;
import java.util.Map;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;

/**
 * Represents information obtained from scanning a Dataset
 * @author Matt Nelson
 *
 */
public interface DatasetInformation {
	
	/**
	 * @return action of the dataset, not null,  defaults to INFORMATION
	 */
	DATASET_ACTION getAction();
	
	/**
	 * @return the date for which the rules should be applied for validation (example constraints), not null, default to the date this was created 
	 */
	Date getTransactionValidity();
	
	/**
	 * @return structures used for the dataset
	 */
	IDatasetStructures getDatasetStructures();

	/**
	 * Returns the DataStructureSuperBean referenced by the dataset
	 * @return
	 */
	DataStructureSuperBean getDsdSuperBean();
	
	Map<String, AttributeSuperBean> getDatasetAttributesSuperBeans();
	
	Map<String, AttributeSuperBean> getSeriesAttributesSuperBeans();
	
	Map<String, Map<String, AttributeSuperBean>> getGroupAttributesSuperBeans();
	
	Map<String, AttributeSuperBean> getObsAttributesSuperBeans();
	
	Map<String, DimensionSuperBean> getDimensionMapSuperBeans();

	Map<String, DimensionBean> getDimensionMap();
	
	/**
	 * Returns the number of dimensions in the DSD
	 * @return
	 */
	int getDimSize();
	
	/**
	 * returns true if the dimension at the observation is TIME_PERIOD
	 * @return
	 */
	boolean isTimeSeries();
	
	/**
	 * @return the dimension at the observation level
	 */
	String getDimensionAtObservation();

}
