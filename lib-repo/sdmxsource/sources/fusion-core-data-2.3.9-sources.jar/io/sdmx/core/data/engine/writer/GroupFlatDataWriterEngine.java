package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.model.dataset.GroupAttributeValues;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Proxies a FlatDataWriterEngine so that Group information is stored away and added back to each row.
 * It reads the data file obtaining the Group attributes and storing them whilst writing each row to a temporary file.
 * This temporary file is then read and each line may be enriched with the group information.
 */
public class GroupFlatDataWriterEngine<T extends IFlatDataWriterEngine> extends FlatDataWriterEngineProxy<T> {

	private ITemporaryFlatDataWriterEngine tmpDwe;
	
	private GroupAttributeStore groupAttributeStore;
	
	private boolean dsdHasGroups;
	private DataStructureBean dsd;
	
	public GroupFlatDataWriterEngine(T proxy) {
	    super(proxy);
		this.dsdHasGroups = false;
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		this.dsd = null;
		closeDataset();
		getProxy().startDataset(header, annotations);
	}

	@Override
	public void writeRow(IDataRow dataRow) {
		if (dsd == null) {
			dsd = dataRow.getDatasetStructures().getDataStructure();
			 
			// Does the DSD have any groups?
			List<GroupBean> groups = dsd.getGroups();
			if (groups.size() > 0) {
				dsdHasGroups = true;
			}

			if (dsdHasGroups) {
				tmpDwe = new MVStoreFlatDataWriterEngine();
				for(GroupBean group : dsd.getGroups()) {
					groupAttributeStore = new GroupAttributeStore();
					for(AttributeBean attr : dsd.getGroupAttributes(group.getId(), false)) {
						groupAttributeStore.registerAttribute(group, attr.getId());
					}
				}
			}
		}
		
		if (!dsdHasGroups) {
			proxy.writeRow(dataRow);
			return;
		}

		// Store the row (enriching if necessary) OR store the GroupAttribute to the store
		if(dataRow.isPartialKey()) {
			// Reporting a Group - save any group attributes in store
			Map<String, String> values = dataRow.getRowData();
			for(String attributeId : groupAttributeStore.getAttributes()) {
				String reportedValue = values.get(attributeId);
				if(reportedValue != null) {
					groupAttributeStore.registerAttributeValue(dataRow.getShortCode(), attributeId, reportedValue);
				}
			}
			return;
		}

		// Persist the row to the temporary store
		tmpDwe.writeRow(dataRow);
	}

	@Override
	public void close() {
		closeDataset();
		proxy.close();
	}
	

    public void closeDataset() {
        if (!dsdHasGroups) {
            return;
        }
        
        // Read data from the temporary store
        IFlatDataReaderEngine dataReaderEngine = tmpDwe.getDataReaderEngine();
        while (dataReaderEngine.moveNextRow()) {
            // Enrich the row with group information and write to the proxy
            IDataRow newRow = dataReaderEngine.getCurrentRow();
            Map<String, String> groupAttributes = groupAttributeStore.getMatchedAttributes(newRow.getShortCode());
            if(groupAttributes != null) {
                // Enrich the row
                newRow = newRow.modifyValues(groupAttributes);
            }
            proxy.writeRow(newRow);
        }
        
        // Close the writers
        try {
            tmpDwe.close();
            tmpDwe.removeResources();
        } catch(Exception e) {
            // Intentionally do nothing
        }
        groupAttributeStore.close();
    }

    /**
     * A store of reported attributes against a subset group of dimension values, which can be looked up by series
     * @author mnelson
     */
    private class GroupAttributeStore {
        private Map<String, GroupAttributeValues> attributeToGroup = new HashMap<>();
        private Map<String, GroupAttributeValues> groupIdToValues = new HashMap<>();
        private List<GroupAttributeValues> groups = new ArrayList<>();
        private Boolean multipleGroups = null;
        
        /**
         * Registers an attribute that a group can report data against
         * @param attributeId
         */
        public void registerAttribute(GroupBean group, String attributeId) {
            GroupAttributeValues groupValues = groupIdToValues.get(group.getId());
            if(groupValues == null) {
                groupValues = new GroupAttributeValues(group);
                groupIdToValues.put(group.getId(), groupValues);
                groups.add(groupValues);
            }
            attributeToGroup.put(attributeId, groupValues);
        }

        protected Set<String> getAttributes() {
            return attributeToGroup.keySet();
        }

        /**
         * @param shortCode
         * @return attributes that have been reported against the series (via a matched group) or null if none have
         */
        public Map<String, String> getMatchedAttributes(String shortCode) {
            Map<String, String> returnMap = null;
            for(GroupAttributeValues reportedValues : groups) {
                Map<String, String> attr = reportedValues.getMatchedAttributes(shortCode);
                if(attr != null) {
                    if(multipleGroups == null) {
                        multipleGroups = groups.size() > 1;
                    }
                    if(returnMap != null) {
                        returnMap.putAll(attr);
                    } else {
                        returnMap = multipleGroups ? new HashMap<>(attr) : attr;
                    }
                }
            }
            return returnMap;
        }

        public void registerAttributeValue(String groupShortCode, String attributeId, String attributeValue) {
            GroupAttributeValues groupValues = attributeToGroup.get(attributeId);
            groupValues.registerAttributeValue(groupShortCode, attributeId, attributeValue);
        }
        
        private void close() {
            groups.forEach(e-> {
                e.close();
            });
        }
    }
}
