package io.sdmx.core.data.engine.writer.enrichment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.core.data.engine.writer.FlatDataWriterEngineProxy;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Adds a new Component value based on some criteria
 */
public class FlatDataWriterEngineDynamicComponent extends FlatDataWriterEngineProxy<IFlatDataWriterEngine> {
	private static final Logger LOG = LoggerFactory.getLogger(FlatDataWriterEngineDynamicComponent.class);
	private static final Pattern ptn = Pattern.compile("\\$\\[(.*?)\\]");

	//ON CONSTRUCTOR
	private SdmxSuperBeanRetrievalManager sbRet;
	private Map<String, String> componentToValueMap = new HashMap<>();  //Map of rules for generation of new values

	//STATE BUILT WHEN DSD KNOWN
	private Map<String, DynamicAttribute> dynamicAttributes = new HashMap<>();
	private DataStructureSuperBean dsdSb;
	private DataStructureBean dsd;

	private enum DECODE {
		ID("id"),
		NAME("name"),
		DESCRITPION("desc");

		private String postFix;
		private DECODE(String postFix) {
			this.postFix = postFix;
		}
	}

	public FlatDataWriterEngineDynamicComponent(IFlatDataWriterEngine proxy, Map<String, String> componentToValueMap, SdmxSuperBeanRetrievalManager sbRet) {
		super(proxy);
		this.sbRet = sbRet;
		this.componentToValueMap = componentToValueMap;
		dynamicAttributes = new HashMap<>();
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		super.startDataset(header, annotations);
		this.dsd = null;
		this.dsdSb = null;
	}

	@Override
	public void writeRow(IDataRow row) {
		if(dsd == null) {
			setUpStructures(row.getDatasetStructures());
		}
		Map<String, String> rowData = row.getRowData();
		Map<String, String> modifyRow = null;

		outer:
			for(String compId : dynamicAttributes.keySet()) {
				DynamicAttribute attr = dynamicAttributes.get(compId);
				for(String dep : attr.dependancies) {
					if(!rowData.containsKey(dep)) {
						continue outer;
					}
				}
				String generatedValue = attr.getDynamicAttribute(rowData);
				if(modifyRow == null) {
					modifyRow = new HashMap<>(dynamicAttributes.size());
				}
				modifyRow.put(compId, generatedValue);
			}
		if(modifyRow != null) {
			row = row.modifyValues(modifyRow);
		}
		super.writeRow(row);
	}

	private void setUpStructures(IDatasetStructures structures) {
		this.dsd = structures.getDataStructure();
		if(this.sbRet != null) {
			this.dsdSb = this.sbRet.getDataStructureSuperBean(dsd.getURN());
		}
		for(String componentId : componentToValueMap.keySet()) {
			String value = componentToValueMap.get(componentId);
			dynamicAttributes.put(componentId, new DynamicAttribute(value));
		}
	}

	private class DynamicAttribute {
		private String dynamictext;
		private Map<String, List<DECODE>> componentIds; //Boolean = decode true/false
		private Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> codelistMap; //comp id to codelist
		private Set<String> dependancies = new HashSet<>(); //dependent on other components being reported

		public DynamicAttribute(String dynamictext) {
			this.dynamictext = dynamictext;
			Matcher m = ptn.matcher(dynamictext);
			componentIds = new HashMap<>();
			codelistMap = new HashMap<>();
			while(m.find()) {
				for(int i = 0 ; i < m.groupCount(); i++) {
					String found = m.group(i);
					String componentId = found.replace("$[", "");
					componentId = componentId.replace("]", "");
					String[] split = componentId.split("\\.");
					componentId = split[0];
					dependancies.add(componentId);
					DECODE decode = DECODE.ID;

					if(split.length > 1 && dsdSb != null) {
							ComponentSuperBean compSb = dsdSb.getComponentById(componentId);
							if(compSb != null) {
								EnumeratedListBean<? extends EnumeratedItemBean> codelist = compSb.getCodelist(true);
								if(codelist != null) {
									if("name".equals(split[1])) {
										decode = DECODE.NAME;
									} else if("desc".equals(split[1])) {
										decode = DECODE.DESCRITPION;
									}
									codelistMap.put(componentId, codelist);
								}
							}
					} else {
						this.dynamictext = this.dynamictext.replace(found, "$["+componentId+".id]");						
					}
					List<DECODE> decodeList = componentIds.get(componentId);
					if(decodeList == null) {
						decodeList = new ArrayList<>();
						componentIds.put(componentId, decodeList);
					}
					decodeList.add(decode);
				}
			}
		}

		private String getDynamicAttribute(Map<String, String> reportedValues) {
			String text = this.dynamictext;
			for(String compId : this.componentIds.keySet()) {
				List<DECODE> decodeList = this.componentIds.get(compId);
				String reportedValue = reportedValues.get(compId);
				if(ObjectUtil.validString(reportedValue)) {
					for(DECODE decode : decodeList) {
						String replaceVal = reportedValue;
						String replaceComp = compId+"."+decode.postFix; 

						if(decode != DECODE.ID) {
							EnumeratedItemBean code = this.codelistMap.get(compId).getItemById(reportedValue);
							if(code != null) {
								replaceVal = decode == DECODE.NAME ? code.getName() : code.getDescription();
							}
						}
						text = text.replace("$["+replaceComp+"]", replaceVal);
					}
				}
			}
			return text;
		}
	}

}
