package io.sdmx.core.data.api.model.mapping;

import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;

/**
 * Explains the mapping between source and target component(s) - directly relates to a single {@link IComponentMappingRules} or {@link ITimePeriodMapping}
 */
public interface IExplainMapComponent {
	
	/**
	 * @return immutable list of components used as input to this mapping
	 */
	List<String> getSourceComponents();

	/**
	 * @return immutable list of components output from this mapping
	 */
	List<String> getTargetComponents();
	
	/**
	 * @return an immutable map of describing each mapping rule used, broken down by the period for which the rule is applicable
	 */
	Map<SdmxPeriod, List<IExplainMapMatch>> getMappings(); 
	

	/**
	 * @return outputs for each period, the mapped list contains a value for each of the target components, in the same order
	 */
	Map<SdmxPeriod, List<KeyValue>> getOutputs(); 
}
