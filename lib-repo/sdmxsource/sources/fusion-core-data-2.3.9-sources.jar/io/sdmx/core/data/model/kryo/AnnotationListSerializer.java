package io.sdmx.core.data.model.kryo;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;

public class AnnotationListSerializer extends ListSerializer<AnnotationBean> {
	private static final AnnotationListSerializer INSTANCE = new AnnotationListSerializer();
	
	public static AnnotationListSerializer getInstance() {
		return INSTANCE;
	}
	
	private AnnotationListSerializer() {
		super(AnnotationSerializer.getInstance());
	}
	
}
