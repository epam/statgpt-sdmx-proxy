package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StructureReferenceSerializer extends Serializer<StructureReferenceBean> {
	private static final StructureReferenceSerializer INSTANCE = new StructureReferenceSerializer();
	private StructureReferenceSerializer() {}

	public static StructureReferenceSerializer getInstance() {
		return INSTANCE;
	}
	
	@Override
	public void write(Kryo kryo, Output output, StructureReferenceBean object) {
		String targetUrn = object == null ? null : object.getTargetUrn(true);
		kryo.writeObjectOrNull(output, targetUrn, String.class);
	}

	@Override
	public StructureReferenceBean read(Kryo kryo, Input input, Class<? extends StructureReferenceBean> type) {
		String targetUrn = kryo.readObjectOrNull(input, String.class);
		return targetUrn == null ? null : StructureReferenceBeanImpl.buildAndVerify(targetUrn);
	}
}
