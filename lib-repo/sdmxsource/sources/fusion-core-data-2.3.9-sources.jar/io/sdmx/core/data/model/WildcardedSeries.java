package io.sdmx.core.data.model;

import java.util.regex.Pattern;

import io.sdmx.utils.core.object.SeriesUtil;

/**
 * Creates a pattern based on the wildcarded series, and can be used to check if the wildcarded series matches 
 * the input series.
 * <p/>
 * A wildcarded series can be either be denoted by the abscence of the series key code, or a star as shown in the examples below:
 * <p/>
 * A:B::D or A:B:*:D
 */
public class WildcardedSeries {
	private Pattern pattern;
	
	public WildcardedSeries(String wildcardSeries) {
		pattern = SeriesUtil.wildcardSeriesToPattern(wildcardSeries);
	}

	public boolean isMatch(String series) {
		return pattern.matcher(series).matches();
	}
}
