package io.sdmx.core.data.api.model.consolidation;

import io.sdmx.core.sdmx.model.MVDuplicateBehaviour;
import io.sdmx.utils.core.object.SORT_ORDER;

/**
 * Defines the options to use when consolidating data
 */
public interface IConsolidationOptions {

	MVDuplicateBehaviour getDuplicateBehaviour();

	SORT_ORDER getSortOrder();

}
