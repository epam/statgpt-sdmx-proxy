package io.sdmx.core.data.model.dataset.mvstore;

import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.im.data.ObservationProxy;

/**
 * This class wraps an observation together with its keyable position.
 *
 * This is needed so that they can be serialized together, reliably storing the
 * keyable position instead of the keyable referenced by the observation.
 */
public class ObservationWrap extends ObservationProxy {
	private final Integer keyablePosition;

	public ObservationWrap(Integer keyablePosition, Observation observation) {
		super(observation);
		this.keyablePosition = keyablePosition;
	}

	public Integer getKeyablePosition() {
		return keyablePosition;
	}

	public String toString() {
		return "(" + keyablePosition +  ", " + super.getProxy() + ")";
	}
}
