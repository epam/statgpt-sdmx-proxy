package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.DefaultSerializers.StringSerializer;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.im.beans.base.ContactBeanImpl;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;

public class ContactBeanSerializer  extends Serializer<ContactBean> {
	private static final ContactBeanSerializer INSTANCE = new ContactBeanSerializer();
	private ListSerializer stringList = new ListSerializer<>(new StringSerializer());
	private ContactBeanSerializer() {}
	

	public static ContactBeanSerializer getInstance() {
		return INSTANCE;
	}

	@Override
	public void write(Kryo kryo, Output output, ContactBean object) {
		kryo.writeObjectOrNull(output, object.getId(), String.class);
		kryo.writeObject(output, object.getDepartments(), TextTypeWrapperListSerializer.getInstance());
		kryo.writeObject(output, object.getEmail(), stringList);
		kryo.writeObject(output, object.getFax(), stringList);
		kryo.writeObject(output, object.getName(), TextTypeWrapperListSerializer.getInstance());
		kryo.writeObject(output, object.getRole(), TextTypeWrapperListSerializer.getInstance());
		kryo.writeObject(output, object.getTelephone(), stringList);
		kryo.writeObject(output, object.getUri(), stringList);
		kryo.writeObject(output, object.getX400(), stringList);
	}

	@Override
	public ContactBean read(Kryo kryo, Input input, Class<? extends ContactBean> type) {
		ContactMutableBean contact = new ContactMutableBeanImpl();
		
		contact.setId(kryo.readObjectOrNull(input, String.class));
		List<TextTypeWrapper> text = kryo.readObject(input, List.class, TextTypeWrapperListSerializer.getInstance());
		contact.setDepartments(TextTypeWrapperListSerializer.toMutable(text));
		contact.setEmail((List<String>)kryo.readObject(input, List.class, stringList));
		contact.setFax((List<String>)kryo.readObject(input, List.class, stringList));
		text = kryo.readObject(input, List.class, TextTypeWrapperListSerializer.getInstance());
		contact.setNames(TextTypeWrapperListSerializer.toMutable(text));
		text = kryo.readObject(input, List.class, TextTypeWrapperListSerializer.getInstance());
		contact.setRoles(TextTypeWrapperListSerializer.toMutable(text));
		contact.setTelephone((List<String>)kryo.readObject(input, List.class, stringList));
		contact.setUri((List<String>)kryo.readObject(input, List.class, stringList));
		contact.setX400((List<String>)kryo.readObject(input, List.class, stringList));
		
		return new ContactBeanImpl(contact);
	}
}