package io.sdmx.core.data.api.model.consolidation;

import io.sdmx.core.sdmx.model.MVDuplicateBehaviour;
import io.sdmx.utils.core.object.SORT_ORDER;

public class ConsolidationOptions implements IConsolidationOptions {

	private MVDuplicateBehaviour duplicateBehaviour;
	private SORT_ORDER sortOrder;

	public ConsolidationOptions(MVDuplicateBehaviour dupeBehaviour) {
		this(dupeBehaviour, SORT_ORDER.NATURAL);
	}
	
	public ConsolidationOptions(MVDuplicateBehaviour dupeBehaviour, SORT_ORDER sortOrder) {
		this.duplicateBehaviour = dupeBehaviour;
		this.sortOrder = sortOrder;
	}
	
	@Override
	public MVDuplicateBehaviour getDuplicateBehaviour() {
		return duplicateBehaviour;
	}

	@Override
	public SORT_ORDER getSortOrder() {
		return sortOrder;
	}

}
