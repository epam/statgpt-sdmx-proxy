package io.sdmx.core.data.api.manager;

import java.util.Date;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Supports data transformation
 */
public interface DataReaderWriterTransform {

	/**
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated 
	void copyToWriter(DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			boolean includeObs,
			boolean includeattributes,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean copyHeader,
			boolean closeWriter,
			boolean mergeDatasets);

	/**
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated 
	void copyDatasetToWriter(DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			String pivotDimension,
			boolean includeObs,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean includeHeader,
			boolean closeOnCompletion,
			boolean mergeDatasets);

	/**
	 * Copies the data held in the data reader engine to the data writer engine verbatim.
	 * <p/>
	 * This will make an initial call on the reader engine to reset the position back to the start to ensure a full copy
	 * <p/>
	 * The writer engine may be closed on completion, the reader engine will NOT be closed
	 *
	 * @param dataReaderEngine the reader engine to read the data from
	 * @param dataWriterEngine the writer engine to write the data to
	 * @param copyHeader Whether to copy the  the writer on completion
	 * @param closeWriter Whether to close the writer on completion
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated 
	void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, boolean copyHeader, boolean closeWriter);

	/**
	 * Copies the data held in the data reader engine to the data writer engine verbatim.
	 * <p/>
	 * This will make an initial call on the reader engine to reset the position back to the start to ensure a full copy
	 * <p/>
	 * The writer engine may be closed on completion, the reader engine will NOT be closed
	 *
	 * @param dataReaderEngine the reader engine to read the data from
	 * @param dataWriterEngine the writer engine to write the data to
	 * @param copyHeader Whether to copy the  the writer on completion
	 * @param closeWriter Whether to close the writer on completion
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated 
	void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, boolean copyHeader, boolean closeWriter, boolean mergeDatasets);

	/**
	 * Copies the data held in the data reader engine to the data writer engine - pivoting the data on the dimension supplied.
	 * <p/>
	 * This will make an initial call on the reader engine to reset the position back to the start to ensure a full copy
	 * <p/>
	 * The writer engine may be closed on completion, the reader engine will NOT be closed
	 *
	 * @param dataReaderEngine the reader engine to read the data from
	 * @param dataWriterEngine the writer engine to write the data to
	 * @param pivotDimension The dimension to pivot around
	 * @param closeWriter Whether to close the writer on completion
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated
	void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, String pivotDimension, boolean closeWriter, boolean mergeDatasets);

	/**
	 * Writes the keyable to the writer engine, if the key is a series then it will also write any observations under the series
	 * @param dataReaderEngine
	 * @param dataWriterEngine
	 * @param keyable
	 * @param maxObs if 0 or null then do not output observations, if less then 0 then there is no limit, if greater then 0 then limit the max obs to this number
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated
	void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs);

	/**
	 * Writes the keyable to the writer engine, if the key is a series then it will also write any observations under the series.
	 * <p/>
	 * Only writes the observations that fall between the two date parameters
	 * @param dataReaderEngine
	 * @param dataWriterEngine
	 * @param keyable
	 * @param maxObs if 0 then do not output observations, if null or less then 0 then there is no limit, if greater then 0 then limit the max obs to this number
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated
	void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs, Date dateFrom, Date dateTo,
			boolean includeattributes);

	/**
	 * Writes the keyable to the writer engine, if the key is a series then it will also write any observations under the series.
	 * <p/>
	 * Only writes the observations that fall between the two date parameters
	 * @param dataReaderEngine
	 * @param dataWriterEngine
	 * @param keyable
	 * @param maxObs if 0 then do not output observations, if null or less then 0 then there is no limit, if greater then 0 then limit the max obs to this number
	 * @deprecated use {@link DataTransformationUtil}
	 */
	@Deprecated
	void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs, Date dateFrom, Date dateTo);

	/**
	 * Writes the observation to the writer engine
	 * @param dataWriterEngine
	 * @param keyable
	 * @param obs
     * @deprecated use {@link DataTransformationUtil}
     * */
	@Deprecated
	void writeObsToWriter(DataWriterEngine dataWriterEngine, Keyable keyable, Observation obs,  boolean includeattributes);

	/**
	 * Writes the observation to the writer engine
	 * @param dataWriterEngine
	 * @param keyable
	 * @param obs
     * @deprecated use {@link DataTransformationUtil}
    */
	@Deprecated
	void writeObsToWriter(DataWriterEngine dataWriterEngine, Keyable keyable, Observation obs);
}
