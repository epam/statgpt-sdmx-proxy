package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;

import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.ObjectDataType;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.core.sdmx.factory.PositionalDataFactory;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;

/**
 *
 * @param <K> typically K and V
 * @param <V>
 */
public abstract class DT_Attributable<K extends Attributable, V extends Attributable> extends BasicDataType<K> {
	private static final DT_String strDT = DT_String.getInstance();
	private final DT_Integer intDT;
	private final DT_List<KeyValue, KeyValue> kvListDT;
	private final DT_List<IMultilingualKeyValue, IMultilingualKeyValue> mlAttrListDT;
	private final DT_List<AnnotationBean, Object> annListDT;

	public DT_Attributable() {
		final ObjectDataType objDT = new ObjectDataType();
		
		this.intDT = DT_Integer.getInstance(false);
		this.mlAttrListDT = new DT_List<>(DT_MultilingualKeyValue.getInstance());
		this.kvListDT = new DT_List<>(DT_KeyValue.getInstance());
		this.annListDT = new DT_List<>(objDT);
	}

	@Override
	public int getMemory(K attributable) {
		int size = 1; // null/string selector

		if (attributable != null) {
			size += kvListDT.getMemory(attributable.getAttributes());
			size += mlAttrListDT.getMemory(attributable.getMultilingualAttributes());
			size += annListDT.getMemory(attributable.getAnnotations());
			size += strDT.getMemory(attributable.getPosition() == null ? null : attributable.getPosition().toPositionalString());
		}

		return size;
	}

	@Override
	public void write(WriteBuffer buf, K attributable) {
		intDT.write(buf, (attributable == null) ? 0 : 1);
		if (attributable != null) {
			kvListDT.write(buf, attributable.getAttributes());
			mlAttrListDT.write(buf, attributable.getMultilingualAttributes());
			strDT.write(buf, attributable.getPosition() == null ? null : attributable.getPosition().toPositionalString());
			annListDT.write(buf, attributable.getAnnotations());
		}
	}

	@Override
	public K read(ByteBuffer byteBuffer) {
		Integer isNull = intDT.read(byteBuffer);
		if(isNull == 0) {
			return null;
		}
		List<KeyValue> attributes = kvListDT.read(byteBuffer);
		List<IMultilingualKeyValue> multilingualAttributes = mlAttrListDT.read(byteBuffer);
		String position = strDT.read(byteBuffer);
		List<AnnotationBean> annotations = annListDT.read(byteBuffer);

		IDataPosition dataPosition = PositionalDataFactory.getInstance().getPosition(position);

		return build(getBuilder(byteBuffer).attributes(attributes).
				attributesMultilingual(multilingualAttributes).
				annotations(annotations).
				position(dataPosition).
				build());
	}
	
	/**
	 * In the case K is the same as V the implementation should just return built,
	 * 
	 * @param built
	 * @return
	 */
	protected abstract K build(V built);

	protected abstract AttributableBuilder<V> getBuilder(ByteBuffer byteBuffer);
}
