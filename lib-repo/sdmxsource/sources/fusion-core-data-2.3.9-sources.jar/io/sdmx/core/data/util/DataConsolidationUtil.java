package io.sdmx.core.data.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.DataErrorReporter;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.model.errorhanlder.IContradictoryDuplicateHandler;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.error.DataErrorImpl;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.collection.KeyValueUtil;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Contains the business logic for dataset consolidation
 */
public class DataConsolidationUtil {
	private static final DataValidationErrorCode DUPLICATE_VALUE_REPORTED = DataValidationErrorCode.DUPLICATE_VALUE_REPORTED;
	private static final DataValidationErrorCode CONTRADICTORY_VALUE_REPORTED = DataValidationErrorCode.CONTRADICTORY_VALUE_REPORTED;

	
	 /**
	  * Tell if the dataset with the given index needs consolidation
	  */
	 public static boolean requiresConsolidation(DATASET_ACTION action) {
		 return ((action == DATASET_ACTION.APPEND) ||
				 (action == DATASET_ACTION.REPLACE) ||
				 (action == DATASET_ACTION.DELETE) ||
				 (action == DATASET_ACTION.INFORMATION));
	 }
	
	/**
	 * Consolidate (merge) a list of keys (series or group) which have the same short code.
	 * The merge works on a first reported value wins basis, where a null reported value is taken as a reported value.
	 * If a last reported value wins is required, the list must be reversed
	 * 
	 * 
	 * @param dsIdx
	 * @param keyDuplicates list of keys whose short code is the same
	 * @param reverseOrder if true the last not null values 'win' otherwise the first not null values 'win'
	 * @param contraditionHandler optional, if provided any contradictions will be reported to this error handler
	 * @return
	 */
	public static Keyable consolidateKeys(int dsIdx,
			List<Keyable> keyDuplicates,
			boolean reverseOrder,
			IContradictoryDuplicateHandler<Keyable> contraditionHandler) {
		
		if(keyDuplicates.size() == 1) {
			return keyDuplicates.get(0);
		}
		
		
		List<KeyValue> attributes = mergeAttributes(keyDuplicates, reverseOrder, contraditionHandler);
		
		Keyable firstKey = keyDuplicates.get(0);
		
		if(firstKey.getGroupName() != null) {
			return KeyableImpl.groupKey(firstKey.getDataflow(), firstKey.getDataStructure(), firstKey.getGroupName(), firstKey.getKey(), attributes);
		}
		//TODO annotations - can the short code be reused?
		return KeyableImpl.seriesKey(firstKey.getDataflow(), firstKey.getDataStructure(), firstKey.getKey(), attributes);
	}

	/**
	 * Consolidate a set of observations who have the same ObsKey
	 * @param obsDuplicates to be merged
	 * @param reverseOrder if true the last not null values 'win' otherwise the first not null values 'win'
	 * @return
	 */
	public static Observation consolidateObs(int dsIdx,
			Keyable key,
			List<Observation> obsDuplicates,
			boolean reverseOrder,
			IContradictoryDuplicateHandler<Observation> errorHandler) {
		if(obsDuplicates == null || obsDuplicates.size() == 0) {
			return null;
		}
		if(obsDuplicates.size() == 1) {
			return obsDuplicates.get(0);
		}
		Map<String, KeyValue> reportedMeasures = new HashMap<>();
		String dimId = null;
		String dimVal = null;
		int i = reverseOrder ? obsDuplicates.size()-1 : 0;
		while(i >= 0 && i < obsDuplicates.size()) {
			Observation obs = obsDuplicates.get(i);
			dimId = obs.getDimensionId();
			dimVal = obs.getDimensionValue();
			List <KeyValue> measures = obs.getMeasures();
			if(measures != null) {
				for(KeyValue reportedMeasure : measures) {
					//KeyValue reportedValue = measures.get(measure);
					//TODO do we want to ignore nulls?
					if(reportedMeasure.hasMultipleValues() || reportedMeasure.getCode()!=null){
						if(!reportedMeasures.containsKey(reportedMeasure.getConcept())) {
							reportedMeasures.put(reportedMeasure.getConcept(), reportedMeasure);
						}else if(errorHandler != null){
							//int index = reportedMeasures.get(reportedMeasure.getConcept());
							KeyValue previousMeasure = reportedMeasures.get(reportedMeasure.getConcept());
							if(!ObjectUtil.equivalent(previousMeasure, reportedMeasure)){
								if(reverseOrder){
									errorHandler.duplicateAttribute(obs,reportedMeasure, previousMeasure);
								}else{
									errorHandler.duplicateAttribute(obs,previousMeasure,reportedMeasure);
								}
							}
						}
					}
				}
			}
			i = reverseOrder ? i-1 : i+1;
		}
		List<KeyValue> attributes = mergeAttributes(obsDuplicates, reverseOrder, errorHandler);

		//TODO Annotations
		List<KeyValue> reportedMeasuresList = new ArrayList<KeyValue>(reportedMeasures.values());
		return ObservationImpl.multipleMeasureCrossSection(key, dimId, dimVal, reportedMeasuresList, attributes, null);  //TODO Annotations
	}

	/**
	 * Merges attributes, first reported attribute wins, a null reported key value considered a reported value
	 * 
	 * @param attributeable
	 * @param errorHandler if provided will verify duplicates are not contradictory, if they are an error will be reported
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<KeyValue> mergeAttributes(List<? extends Attributable> attributeable,
												 boolean reverseOrder,
												 @SuppressWarnings("rawtypes") IContradictoryDuplicateHandler onDuplicate)  {
		Map<String, KeyValue> reportedAttributes = new HashMap<>();
		
		int i = reverseOrder ? attributeable.size()-1 : 0;
		while(i >= 0 && i < attributeable.size()) {
			Attributable attr = attributeable.get(i);
			List<KeyValue> kvs = attr.getAttributes();
			int j = reverseOrder ? kvs.size() -1 : 0;
			while(j >= 0 && j < kvs.size()) {
				KeyValue kv = kvs.get(j);
				if(!reportedAttributes.containsKey(kv.getConcept())) {
					reportedAttributes.put(kv.getConcept(), kv);
				} else if(onDuplicate != null) {
					//check there is no contradiction in reported value
					KeyValue previouslyReported = reportedAttributes.get(kv.getConcept());
					if (!previouslyReported.equals(kv)) {
						if (!kv.hasMultipleValues() && (kv.getCode() == null)) {
							// ignore null values and keep the current one
							//
							// FIXME: this is the old, incorrect behaviour, but we need
							//        support from data readers to avoid it and properly
							//        handle cases like EDI quadruplets
						} else {
							//							 DataError de = contradictoryValue(dsIdx, previouslyReported, kv, obs);
							onDuplicate.duplicateAttribute(attr, previouslyReported, kv);
						}
					}
				}
				j = reverseOrder ? j-1 : j+1;
			}
			i = reverseOrder ? i-1 : i+1;
		}
		return new ArrayList<>(reportedAttributes.values());
	}

	/**
	 * Return a DUPLICATE_VALUE_REPORTED for observation measures.
	 * When overwriting value prev with value next
	 */
	public static DataError duplicateMeasureValue(
			DataErrorReporter errorReporter,
			int dsIx,
			Observation observation,
			String measureId,
			String prev,
			String next) {
		FusionError fe = new FusionErrorImpl(DUPLICATE_VALUE_REPORTED,
				observation.getShortCode(),
				prev,
				next);

		KeyValue kvNext = KeyValueImpl.getInstance(measureId, next);
		return new DataErrorImpl(errorReporter.getId(), dsIx, fe, kvNext, observation);
	}

	/**
	 * Return a CONTRADICTORY_VALUE_REPORTED for the given dataset attribute.
	 * When overwriting value prev with value next
	 */
	public static DataError contradictoryDatasetAttribute(
			DataErrorReporter errorReporter,
			int dsIx,
			KeyValue prev,
			KeyValue next) {
		FusionError fe = new FusionErrorImpl(CONTRADICTORY_VALUE_REPORTED,
				prev.getConcept(),
				KeyValueUtil.getValueString(prev),
				KeyValueUtil.getValueString(next));

		return new DataErrorImpl(errorReporter.getId(), dsIx, fe, next);
	}
	
	/**
	 * Return a CONTRADICTORY_VALUE_REPORTED for the given keyable.
	 * When overwriting value prev with value next
	 */
	public static DataError contradictorySeriesAttribute(
			DataErrorReporter errorReporter,
			int dsIx,
			KeyValue prev,
			KeyValue next,
			Keyable keyable) {
		FusionError fe = new FusionErrorImpl(CONTRADICTORY_VALUE_REPORTED,
				prev.getConcept(),
				KeyValueUtil.getValueString(prev),
				KeyValueUtil.getValueString(next),
				keyable.getShortCode());

		return new DataErrorImpl(errorReporter.getId(), dsIx, fe, next, keyable);
	}

	/**
	 * Return a CONTRADICTORY_VALUE_REPORTED for the given observation, when
	 * overwriting value prev with value next
	 */
	public static DataError contradictoryObsAttribute(
			DataErrorReporter errorReporter,
			int dsIx,
			KeyValue prev,
			KeyValue next,
			Observation observation) {
		FusionError fe = new FusionErrorImpl(CONTRADICTORY_VALUE_REPORTED,
				prev.getConcept(),
				KeyValueUtil.getValueString(prev),
				KeyValueUtil.getValueString(next),
				observation.getSeriesKey().getShortCode());

		return new DataErrorImpl(errorReporter.getId(), dsIx, fe, next, observation);
	}

}
