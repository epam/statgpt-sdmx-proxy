package io.sdmx.core.data.manager;

import java.io.OutputStream;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.manager.retrieval.rest.RestDataQueryManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.query.RESTDataQuery;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.im.data.query.DataQueryImpl;

/**
 * This class obtains a DataWriterEngine for a DataFormat, builds a DataQuery from a RESTDataQuery
 * and passes this information on to a SdmxDataRetrievalWithWriter to fulfil the query
 */
public class RestDataQueryManagerImpl implements RestDataQueryManager {
	
	private DataWriterManager dataWriterManager;
	
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;
	
	public RestDataQueryManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager, SdmxDataRetrievalWithWriter dataRetrievalWithWriter, DataWriterManager dataWriterManager) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
	}
	
	@Override
	/**
	 * Execute the rest query, write the response out to the output stream based on the data format
	 * @param dataQuery the REST dataQuery
	 * @param dataFormat the required output format
	 * @param out the output stream to write the output to
	 */
	public void executeQuery(RESTDataQuery restDataQuery, DataFormat dataFormat, OutputStream out) {
		DataQuery dataQuery = new DataQueryImpl(restDataQuery, beanRetrievalManager);
		ISeriesObsDataWriterEngine dataWriterEngine = dataWriterManager.getDataWriterEngine(dataFormat, out, dataQuery);
		dataRetrievalWithWriter.getData(dataQuery, dataWriterEngine);
	}

}
