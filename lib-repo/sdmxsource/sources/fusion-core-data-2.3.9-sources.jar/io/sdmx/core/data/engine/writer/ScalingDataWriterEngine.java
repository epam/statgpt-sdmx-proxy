package io.sdmx.core.data.engine.writer;

import java.util.*;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.model.formatting.SeriesKeyPattern;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.im.data.AbstractAttributable;
import io.sdmx.im.data.KeyableProxy;
import io.sdmx.im.data.ObservationMeasureProxy;
import io.sdmx.im.data.ObservationProxy;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.NumberUtils;

/**
 * Modifies observations by applying a scaling factor
 */
public class ScalingDataWriterEngine extends DataWriterEngineProxy {
	private static final String UNIT_MULT = "UNIT_MULT";
	
	
	private Map<SeriesKeyPattern, Integer> scalingBySeries = new HashMap<>();
	private Integer globalScale;

	private Integer globalUnitMultiplier;   //UNIT_MULT reported on the dataset
	private Integer seriesUnitMultiplier;   //UNIT_MULT reported on the series (if applicable)
	private Integer requiredUnitMultiplier; //Unit multiplier that should be applied to the observations in the series
	
	private Map<Integer, KeyValue> kvMap;
	
	private DataStructureBean currentDSD;
	
	/**
	 * @param dwe
	 * @param globalScale unit multiplier (*10^[scale])
	 * @param scalingBySeries unit multiplier by series
	 */
	public ScalingDataWriterEngine(ISeriesObsDataWriterEngine dwe, Integer globalScale, Map<SeriesKeyPattern, Integer> scalingBySeries) {
		super(dwe);
		this.globalScale = globalScale;
		if(scalingBySeries != null) {
			this.scalingBySeries.putAll(scalingBySeries);
		}
		this.scalingBySeries = Collections.unmodifiableMap(this.scalingBySeries);
		kvMap = new HashMap<>(scalingBySeries.size() + 1);
	}
	

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		super.startDataset(structures, header, datasetAttributes, annotations);
		this.currentDSD = structures.getDataStructure();
		if(datasetAttributes != null) {
			for(KeyValue dsAttr : datasetAttributes.getAttributes()) {
				if(dsAttr.getConcept().equals(UNIT_MULT)) {
					String unitMult = dsAttr.getCode();
					globalUnitMultiplier = getUnitMultipler(unitMult);
				}
			}
		}
	}

	@Override
	public void writeKey(Keyable key) {
		String unitMult = key.getAttributeValue(UNIT_MULT);
		
		requiredUnitMultiplier = null;
		for(SeriesKeyPattern pattern : scalingBySeries.keySet()) {
			if(pattern.getDsd() != null && !pattern.getDsd().equals(currentDSD)) {
				continue;
			}
			if(pattern.isMatch(key)) {
				requiredUnitMultiplier = scalingBySeries.get(pattern);
				break;
			}
		}
		if(requiredUnitMultiplier == null) {
			requiredUnitMultiplier = globalScale;
		}
		if(globalUnitMultiplier == null && requiredUnitMultiplier != null) {
			seriesUnitMultiplier = getUnitMultipler(unitMult);
			if(seriesUnitMultiplier != null) {
				//modify the series key unit multiplier
				key = new KeyableProxy(key, rebuildAttributes(key, requiredUnitMultiplier));
			}
		}
		super.writeKey(key);
	}

	@Override
	public void writeObservation(Observation obs) {
		if(requiredUnitMultiplier != null) {
			//Current unit multiplier comes from either the global level, the series level or the obs level
			Integer currentUnitMult = globalUnitMultiplier != null ? globalUnitMultiplier : this.seriesUnitMultiplier != null ? seriesUnitMultiplier : getUnitMultipler(obs);
			
			if(currentUnitMult == null) {
				currentUnitMult = 0;  //set to units
			}
			//Adjust scaling factor
			//If the reported unit multiplier is 3 (thousands) and the desired is (6) millions, the number must be multiplied by 10^-3
			//e.g. 300 (representing 300 thousand) becomes 0.3 (0.3 of a million)
			//If the reported unit multiplier is 3 (thousands) and the desired is (0) units, the number must be multiplied by 10^3
			//e.g. 300 (representing 300 thousand) becomes 300,000 (300 thousand)
			int scalingFactor = currentUnitMult - requiredUnitMultiplier;
			
			List<KeyValue> measureValues = new ArrayList<>();
			for(KeyValue currentMeasure : obs.getMeasures()) {
				if(currentMeasure.hasMultipleValues()){
					List<String> formattedValues = new ArrayList<>();
					for(String value: currentMeasure.getValues()){
						formattedValues.add(NumberUtils.scaleNumber(value, scalingFactor));
					}
					measureValues.add(KeyValueImpl.getInstance(currentMeasure.getConcept(), String.valueOf(formattedValues)));
				}
				else{
					String measureValue = currentMeasure.getCode();
					String formatted = NumberUtils.scaleNumber(measureValue, scalingFactor);
					measureValues.add(KeyValueImpl.getInstance(currentMeasure.getConcept(), formatted));
				}
			}
			obs = new ObservationMeasureProxy(obs, measureValues);
			
			//If the unit mult is at the obs level
			Attributable attProxy = this.globalUnitMultiplier == null && this.seriesUnitMultiplier == null ? rebuildAttributes(obs, requiredUnitMultiplier) : obs;
			obs = new ObservationProxy(obs, attProxy, getLastKey());
		}
		super.writeObservation(obs);
	}

	/**
	 * Overrides the UNIT_MULT in the attributes with the new scale factor
	 * @param attributable
	 * @param newScale
	 * @return
	 */
	private Attributable rebuildAttributes(Attributable attributable, Integer newScale) {
		KeyValue newKv = kvMap.get(newScale);
		if(newKv == null) {
			newKv = KeyValueImpl.getInstance(UNIT_MULT, newScale.toString());
			kvMap.put(newScale, newKv);
		}
		
		List<KeyValue> currentAttributes = attributable.getAttributes();
		List<KeyValue> newAttributes = new ArrayList<>(currentAttributes.size());
		for(KeyValue kv : currentAttributes) {
			if(kv.getConcept().equals(UNIT_MULT)) {
				newAttributes.add(newKv);
			} else {
				newAttributes.add(kv);
			}
 		}
		return new AbstractAttributable(newAttributes, attributable.getAnnotations());
	}
	
	/**
	 * @return the unit multiplier on the observation, 0 to indicate no multipler to be applied
	 */
	private Integer getUnitMultipler(Observation obs) {
		String unitMult = obs.getAttributeValue(UNIT_MULT);
		return getUnitMultipler(unitMult);
	}

	/**
	 * @return the unit multiplier on the observation, null to indicate no multipler to be applied
	 */
	private Integer getUnitMultipler(String reportedValue) {
		if(reportedValue != null && NumberUtils.isInteger(reportedValue, true)) {
			return Integer.parseInt(reportedValue);
		}
		return null;
	}
}
