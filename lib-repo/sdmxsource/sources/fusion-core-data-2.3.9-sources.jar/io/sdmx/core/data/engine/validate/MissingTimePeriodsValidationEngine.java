package io.sdmx.core.data.engine.validate;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.error.FusionErrorImpl;

public class MissingTimePeriodsValidationEngine implements DataValidationEngine {

	private TreeSet<String> obsTimes = new TreeSet<>();  //An ordered set of time periods
	private List<String> expectedTimePeriods = new ArrayList<>();

	private Keyable currentKey;

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler errorHandler) {}

	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler errorHandler) {
		if(key.isSeries()) {
			currentKey = key;
			obsTimes = new TreeSet<>();
		} else {
			currentKey = null;
		}
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler errorHandler) {
		obsTimes.add(obs.getDimensionValue());
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		if(obsTimes.size() == 0 || currentKey == null) {
			return;
		}
		//ensure the full run of time series is present
		String seriesStartPeriod = obsTimes.first();
		String seriesEndPeriod = obsTimes.last();
		if(seriesStartPeriod.equals(seriesEndPeriod)) {
			return;
		}


		TIME_FORMAT tf;
		Date reportingDateStart;
        Date reportingDateEnd;
		try {
		    tf =  DateUtil.getTimeFormatOfDate(seriesStartPeriod);
		    reportingDateStart = DateUtil.formatDate(seriesStartPeriod, true);
		    reportingDateEnd = DateUtil.formatDate(seriesEndPeriod, false);
		} catch (Exception e) {
		    // Any number format exceptions will be caught by a different validator, so return
		    return;
		}
		double millisPerPeriod = tf.getMillisInPeriod();
		long expectedNumberOfPeriods = Math.round((reportingDateEnd.getTime() - reportingDateStart.getTime()) / millisPerPeriod);
		if(expectedNumberOfPeriods == obsTimes.size()) {
			//The number of periods matches the expected size, don't both to check them all
			return;
		}
		if(expectedNumberOfPeriods > 300) {
			//Do we really want to create loads of time periods???
			if(expectedNumberOfPeriods - obsTimes.size() > 20) {
				//the value of 20 is because if there is a high number of possible periods, with a load missing, it is easier to state there are a load missing
				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.MULTIPLE_OBS_VALUES_MISSING, seriesStartPeriod, seriesEndPeriod);
                exceptionHandler.reportError(fe, (KeyValue) null, currentKey);
				return;
			}
		}


		String cachedStartPeriod = expectedTimePeriods.size() == 0 ? null : expectedTimePeriods.get(0);
		String cachedEndPeriod = expectedTimePeriods.size() == 0 ? null : expectedTimePeriods.get(expectedTimePeriods.size()-1);

		//The following code adds any new date ranges into the expectedTimePeriods list in the order in which they are expected
		String iterateStart = null;
		String iterateEnd = null;

		boolean addToStart = false;
		if(!expectedTimePeriods.contains(seriesStartPeriod)) {
			addToStart = true; // Add the time periods to the start
			iterateStart = seriesStartPeriod;
			if(expectedTimePeriods.contains(seriesEndPeriod)) {
				//The end period is present, so iterate up to the first value in the list
				iterateEnd = cachedStartPeriod;
			} else {
				iterateEnd = seriesEndPeriod;
			}
		} else if(!expectedTimePeriods.contains(seriesEndPeriod)) {
			iterateStart = cachedEndPeriod;
			iterateEnd = seriesEndPeriod;
		}
		if(iterateStart != null && iterateEnd != null) {
			Date dateStart = DateUtil.formatDate(iterateStart, true);
			Date dateEnd = DateUtil.formatDate(iterateEnd, true);
			List<String> timeValues = DateUtil.createTimeValues(dateStart, dateEnd, tf);
			int startIdx = 0;
			boolean exists = false;
			for(String newValue : timeValues) {
				if(exists) {
					if(newValue.equals(cachedEndPeriod)) {
						//We have iterated onto the last period in the list, all subsequent periods
						//are to be added to the end of the list
						exists = false;
						addToStart = false;
						continue;
					}
				} else if(newValue.equals(cachedStartPeriod)) {
					//The value we have iterated onto was the first period in the list, so skip this
					//and any subsequent periods that are not the last period that was in the list
					exists = true;
					continue;
				}
				if(addToStart) {
					expectedTimePeriods.add(startIdx, newValue);
					startIdx++;
				} else {
					expectedTimePeriods.add(newValue);
				}
			}
		}
		//End of expectedTimePeriods list update

		//Check if the reported periods contain any gaps!
		int idxStart = expectedTimePeriods.indexOf(seriesStartPeriod);
		int idxEnd = expectedTimePeriods.indexOf(seriesEndPeriod);
		int range = idxEnd - idxStart;
		if(obsTimes.size() == (range+1)) {
			//The number of reported periods matches our expectations, we know they must all exist
			return;
		}
		Set<String> expectedPeriods = new HashSet<>();
		while(idxStart <= idxEnd) {
			expectedPeriods.add(expectedTimePeriods.get(idxStart));
			idxStart++;
		}

		for(String obsTime : expectedPeriods) {
			if(!obsTimes.contains(obsTime)) {
				//TODO Should this be a time range where possible?
				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.MISSING_OBS_FOR_TIME_PERIOD, obsTime);
                exceptionHandler.reportObsError(fe, null, currentKey.getShortCode()+":"+obsTime);
			}
		}
	}

	@Override
	public void close(DataValidationErrorReporter exceptionHandler) {}


}
