package io.sdmx.core.data.model.mapping;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.core.data.api.model.mapping.IFrequencyFormatMap;
import io.sdmx.utils.core.date.DateUtil;

public class FrequencyFormatMap implements IFrequencyFormatMap {
	private Map<TIME_FORMAT, DateFormat> dataFormatMap = new HashMap<>(); 
	
	/**
	 * A representation map for time, example
	 * A = yyyy
	 * M = yyyy-Mnn
	 * @param repMap
	 */
	public FrequencyFormatMap(IRepresentationMapBean repMap) {
		//Expects single input to single target
		if(repMap != null) {
			for(IMappedRelationshipBean mapping : repMap.getMappedValues()) {
				String input = mapping.getSourceValue().get(0).getValue();
				try {
					TIME_FORMAT tf  = TIME_FORMAT.getTimeFormatFromCodeId(input);

					// FMR-693: If there is no target value, explicitly set the output to "null".
					// The RepresentationMap is stating that this should not be mapped at all.
					SimpleDateFormat sdf;
					List<String> targetValues = mapping.getTargetValue();
					if (targetValues.isEmpty()) {
						sdf = null;
					} else {
						String pattern = mapping.getTargetValue().get(0);
						sdf = DateUtil.getDateFormatter(pattern);
					}
					dataFormatMap.put(tf, sdf);
				} catch(Throwable th) {
					continue;
				}
			}
		}
		this.dataFormatMap = Collections.unmodifiableMap(this.dataFormatMap);
	}
	
	@Override
	public String formatDate(SdmxDate date) {
		DateFormat formatter = this.dataFormatMap.get(date.getTimeFormatOfDate());
		String dateStr = date.getDateInSdmxFormat();
		if(formatter != null) {
			dateStr = formatter.format(date.getDate());
		}
		return dateStr;
	}
	
}
