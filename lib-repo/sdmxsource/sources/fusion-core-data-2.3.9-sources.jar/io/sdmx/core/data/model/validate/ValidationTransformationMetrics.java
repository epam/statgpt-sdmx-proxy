package io.sdmx.core.data.model.validate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.model.DataInformation;

public class ValidationTransformationMetrics {
	private Date startTime = new Date(); 
	private Date endTime; 
	private MappingRules mapping; 
	private Map<String, DataInformation> dataInformation = new HashMap<>();
	

	public void addDataInformation(String key, DataInformation dataInformation) {
		this.dataInformation.put(key, dataInformation);
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		if(endTime == null) {
			setEndTime();
		}
		return endTime;
	}

	public MappingRules getMappingRules() {
		return mapping;
	}

	public void setMapping(MappingRules mapping) {
		this.mapping = mapping;
	}

	public Map<String, DataInformation> getDataInformation() {
		return dataInformation;
	}
	
	public void setEndTime() {
		this.endTime = new Date();
	}
}
