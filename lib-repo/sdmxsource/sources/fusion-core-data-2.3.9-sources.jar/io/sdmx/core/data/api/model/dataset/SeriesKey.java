package io.sdmx.core.data.api.model.dataset;

import java.io.Serializable;
import java.util.Set;


/**
 * A data key is a unique identifier to a set of data over time
 */
public interface SeriesKey extends Serializable  {
	
	/**
	 * Returns the dimension points for this data item
	 * @return
	 */
	Set<SeriesKeyValue> getKeyValues();
	
	 void setKeyValues(Set<SeriesKeyValue> keyValues);
	
	/**
	 * Adds a key value to this series key - if it already exists in this SeriesKey then there will be no effect
	 * @param keyValue
	 */
	void addKeyValue(SeriesKeyValue keyValue);
	
	/**
	 * Removes a key value from this series key
	 * @param keyValue
	 */
	void removeKeyValue(SeriesKeyValue keyValue);
	
	/**
	 * Returns the code value for the given concept
	 * @param concept
	 * @return
	 */
	String getValueForConcept(String concept);
}
