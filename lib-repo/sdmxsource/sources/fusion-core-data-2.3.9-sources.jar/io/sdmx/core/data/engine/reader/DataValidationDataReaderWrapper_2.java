package io.sdmx.core.data.engine.reader;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.data.model.DataInformation;

/**
 * Came from FusionCOre - the other from FusionRegistryCommunity
 */
@Deprecated  //not used
public class DataValidationDataReaderWrapper_2 extends AbstractWrapperedDataReaderEngine implements DataReaderEngine {
	private Map<Integer, DataStructureBean> dsds = new HashMap<>();
	private Map<Integer, DataflowBean> flows = new HashMap<>();
	private Map<Integer, ProvisionAgreementBean> provs = new HashMap<>();
	private Map<Integer, DataProviderBean> providers = new HashMap<>();
	
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public DataValidationDataReaderWrapper_2(DataReaderEngine dre, SdmxBeanRetrievalManager beanRetrievalManager) {
		super(dre);
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		throw new SdmxNotImplementedException("Not implemented");
	}

	public void setDataInformation(DataInformation dataInformation) {
		for(int i =0; i < dataInformation.getDatasets(); i++) {
			setDataStructure(i, dataInformation.getDsd(i));
			setDataflow(i, dataInformation.getFlow(i));
			setProvision(i, dataInformation.getProvision(i));
		}
	}
	
	public void setDataStructure(int dsNum, DataStructureBean dsd) {
		if(dsd == null) {
			dsds.remove(dsNum);
		} else {
			dsds.put(dsNum, dsd);
			flows.remove(dsNum);
			providers.remove(dsNum);
			provs.remove(dsNum);
		}
	}
	
	public void setDataflow(int dsNum, DataflowBean flow) {
		if(flow == null) {
			flows.remove(dsNum);
		} else {
			flows.put(dsNum, flow);
		}
	}
	
	public void setProvision(int dsNum, ProvisionAgreementBean prov) {
		if(prov == null) {
			provs.remove(dsNum);
			providers.remove(dsNum);
		} else {
			provs.put(dsNum, prov);
			DataProviderBean provider = beanRetrievalManager.getBean(prov.getDataproviderRef().getReference());
			providers.put(dsNum, provider);
		}
	}

	@Override
	public DataStructureBean getDataStructure() {
		return getDataStructure(getDatasetPosition());
	}

	@Override
	public DataflowBean getDataFlow() {
		return getDataFlow(getDatasetPosition());
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return getProvisionAgreement(getDatasetPosition());
	}
	
	
	public DataProviderBean getDataProvider(int idx) {
		if(providers.containsKey(idx)) {
			return providers.get(idx);
		}
		if(getProvisionAgreement(idx) != null) {
			DataProviderBean provider = beanRetrievalManager.getBean(getProvisionAgreement().getDataproviderRef().getReference());
			providers.put(idx, provider);
			return provider;
		}
		return null;
	}
	
	public DataStructureBean getDataStructure(int idx) {
		if(dsds.containsKey(idx)) {
			return dsds.get(idx);
		}
		return null;
	}

	public DataflowBean getDataFlow(int idx) {
		if(flows.containsKey(idx)) {
			return flows.get(idx);
		}
		return null;
	}

	public ProvisionAgreementBean getProvisionAgreement(int idx) {
		if(provs.containsKey(idx)) {
			return provs.get(idx);
		}
		return null;
	}

}
