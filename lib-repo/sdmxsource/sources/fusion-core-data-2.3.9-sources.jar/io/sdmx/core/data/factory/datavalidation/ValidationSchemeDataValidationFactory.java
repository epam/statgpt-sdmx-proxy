package io.sdmx.core.data.factory.datavalidation;

import java.util.Set;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.ValidationSchemeDataValidationEngine;
import io.sdmx.utils.core.object.ObjectUtil;

public class ValidationSchemeDataValidationFactory implements DataValidatorFactory {

    private CrossReferencingRetrievalManager crossReferencingRetrievalManager;
    private SdmxBeanRetrievalManager beanRetrievalManager;

    public ValidationSchemeDataValidationFactory(SdmxBeanRetrievalManager beanRetrievalManager,
			CrossReferencingRetrievalManager crossReferencingRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
	}

	@Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
        DataflowBean dataflow = dsi.getDatasetStructures().getDataflow();
        if(dataflow == null) {
            return null;
        }
        Set<ValidationSchemeBean> validationSchemes = crossReferencingRetrievalManager.getCrossReferencingStructures(dataflow, false, ValidationSchemeBean.class);
        if(ObjectUtil.validCollection(validationSchemes)) {
            return new ValidationSchemeDataValidationEngine(validationSchemes, dsi.getDsdSuperBean(), beanRetrievalManager);
        }
        return null;
    }

    @Override
    public String getId() {
        return "Calculation";
    }

    @Override
    public String getName() {
        return "Valid Calculations";
    }

    @Override
	public boolean validationLinkedToFlowOrProvision() {
		return true;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return true;
	}

	@Override
	public String getDescription() {
		return "Performs any mathematical calculations, defined in Validation Schemes, to ensure compliance";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.IGNORE;
	}
}
