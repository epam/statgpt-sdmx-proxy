package io.sdmx.core.data.model.mapping.explain;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch;
import io.sdmx.utils.core.collection.CollectionUtil;

public class ExplainMapComponent implements IExplainMapComponent {
	private List<String> sourceComponents;
	private List<String> targetComponents;
	private Map<SdmxPeriod, List<IExplainMapMatch>> mappings = new HashMap<>(); 
	private Map<SdmxPeriod, List<KeyValue>> outputs = new HashMap<>(); 
	public ExplainMapComponent(List<String> sourceComponents, List<String> targetComponents) {
		this.sourceComponents = Collections.unmodifiableList(sourceComponents);
		this.targetComponents = Collections.unmodifiableList(targetComponents);
	}

	@Override
	public List<String> getSourceComponents() {
		return sourceComponents;
	}

	@Override
	public List<String> getTargetComponents() {
		return targetComponents;
	}

	@Override
	public Map<SdmxPeriod, List<KeyValue>> getOutputs() {
		return Collections.unmodifiableMap(outputs);
	}

	@Override
	public Map<SdmxPeriod, List<IExplainMapMatch>> getMappings() {
		return Collections.unmodifiableMap(mappings);
	}
	
	public void addMatch(SdmxPeriod period, IExplainMapMatch match) {
		CollectionUtil.addToMappedList(mappings, period, match);
	}


	public void addOutput(SdmxPeriod period, KeyValue kv) {
		CollectionUtil.addToMappedList(outputs, period, kv);
	}
}
