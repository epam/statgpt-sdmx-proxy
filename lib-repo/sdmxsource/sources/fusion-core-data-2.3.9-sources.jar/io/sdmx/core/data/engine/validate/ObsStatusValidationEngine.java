package io.sdmx.core.data.engine.validate;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.constants.SDMX_EDI_ATTRIBUTES;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.constant.OBS_STATUS_VALUE;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Ensure all reported values are correct for the Observation Status.
 * These requirements come from the document supplied by Hubert:
 *
 *   Statistical Working Group / Technical Working Group
 *
 *   POSSIBLE WAYS OF IMPLEMENTING THE OBSERVATION STATUS CONCEPT  /  MAY 2019  /  VERSION 2.0
 */
public class ObsStatusValidationEngine implements DataValidationEngine {

	public ObsStatusValidationEngine(DataStructureBean dsd) {
		// Do nothing
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {
		// Do nothing
	}

	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler eh) {
		// Do nothing
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		KeyValue attribute = obs.getAttribute("OBS_STATUS");
		if (attribute == null) {
			return;
		}

		OBS_STATUS_VALUE obsStatusValue = OBS_STATUS_VALUE.getObsStatusValue(attribute.getCode());
		if (obsStatusValue == null) {
			// not a code mentioned in the document, do not check anything further and do not throw exception
			return;
		}

		// MEDIT: FMR #65: OBS_PRE_BREAK rule: if TIME_SERIES_BREAK (B), the OBS_PRE_BREAK or PRE_BREAK_VALUE attribute must exist
		KeyValue obsPreBreakAttr = obs.getAttribute(SDMX_EDI_ATTRIBUTES.OBS_PRE_BREAK_V1.getId());
		KeyValue preBreakAttr = obs.getAttribute(SDMX_EDI_ATTRIBUTES.OBS_PRE_BREAK_V2.getId());

		// DEV-1498
		// If PRE_BREAK present, throw a Validation Error is if the OBS_STATUS is not B
		// If PRE_BREAK not present, error if the OBS_STATUS is B (but "-" is allowed")
		if (obsPreBreakAttr != null || preBreakAttr != null) {
			if (!obsStatusValue.toString().equals("B")) {
				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_PRE_BREAK_VALUE_PRESENT, obsStatusValue.toString());
				eh.reportError(fe, (KeyValue) null);
			}
		} else {
			if (obsStatusValue.toString().equals("B") && !obsStatusValue.equals("-")) {
				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_PRE_BREAK_VALUE_MISSING);
				eh.reportError(fe, (KeyValue) null);
			}
		}

		if (obsStatusValue.isAllowNumeric() && obsStatusValue.isAllowMissing()) {
			// OBS_STATUS permits anything, so early out
			return;
		}

		if (obsStatusValue.isAllowMissing()) {
			// Report error if a real value has been specified
			for(KeyValue kv : obs.getMeasures()){
				if(kv.hasMultipleValues()){
					for(String value: kv.getValues()){
						if(ObjectUtil.validString(value) && !value.equals("-") && !value.equals("NaN")){
							FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_STATUS_OBS_VALUE_ILLEGAL, obsStatusValue.getRepresentation());
							eh.reportError(fe, kv);
						}
					}
				}
				else{
					String value = kv.getCode();
					if (ObjectUtil.validString(value) && !value.equals("-") && !value.equals("NaN")) {
						FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_STATUS_OBS_VALUE_ILLEGAL, obsStatusValue.getRepresentation());
						eh.reportError(fe, kv);
						// MEDIT#330. It is possible that this is a multi-measure DSD. Only report a single error for the Observation.
						break;
					}
				}
			}
		}
		// Report error if value is missing
		if (obsStatusValue.isAllowNumeric()) {
			if (obs.getMeasures().isEmpty()) {
				FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_STATUS_OBS_VALUE_MISSING, obsStatusValue.getRepresentation());
				eh.reportError(fe, (KeyValue) null);
				// MEDIT#330. It is possible that this is a multi-measure DSD. Only report a single error for the Observation.
			} else {
				for(KeyValue kv : obs.getMeasures()){
					if(kv.hasMultipleValues()){
						for(String value: kv.getValues()){
							if(!ObjectUtil.validString(value) || value.equals("-") || value.equals("NaN")){
								FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_STATUS_OBS_VALUE_MISSING, obsStatusValue.getRepresentation());
								eh.reportError(fe, kv);
							}
						}
					}
					else{
						String value = kv.getCode();
						if (!ObjectUtil.validString(value) || value.equals("-") || value.equals("NaN")) {
							FusionError fe = new FusionErrorImpl(DataValidationErrorCode.OBS_STATUS_OBS_VALUE_MISSING, obsStatusValue.getRepresentation());
							eh.reportError(fe, (KeyValue) null);
							// MEDIT#330. It is possible that this is a multi-measure DSD. Only report a single error for the Observation.
							break;
						}
					}
				}
			}
		}
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		// Do nothing
	}

	@Override
	public void close(DataValidationErrorReporter errorHandler) {
		// Do nothing
	}

}
