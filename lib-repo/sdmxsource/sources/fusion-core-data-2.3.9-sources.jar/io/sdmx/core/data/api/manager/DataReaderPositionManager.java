package io.sdmx.core.data.api.manager;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Moves the data reader position backwards or forwards
 */
public interface DataReaderPositionManager {

	/**
	 * Moves the data reader engine to the position at the given index
	 * @param dataReaderEngine
	 * @param datasetIndex the dataset to read the key for
	 * @param keyPosition the key index in the dataset
	 * @return
	 */
	Keyable moveToPosition(DataReaderEngine dataReaderEngine, int datasetIndex, int keyPosition);
	
	/**
	 * Moves the data reader engine to the observation at the given index, from the key otained by the given index
	 * @param dataReaderEngine
	 * @param datasetIndex the dataset to read the key for
	 * @param keyPosition the key index that the observation belongs to
	 * @param obsNum the observation index in the key
	 * @return
	 */
	Observation moveToObs(DataReaderEngine dataReaderEngine, int datasetIndex, int keyPosition, int obsNum);
}
