package io.sdmx.core.data.engine.retrieval;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.sdmx.model.data.query.AvailabilityQuery;
import io.sdmx.api.sdmx.model.format.StructureFormat;

/**
 * To satisfy the 'availabilty' SDMX GET resource
 * https://github.com/sdmx-twg/sdmx-rest/blob/master/doc/availability.md
 */
public interface IAvailabililtyManager {

	
	/**
	 * Writes the Available Constraints for each query and, if requested in the query, the related structures, in the given 
	 * format to the output stream
	 * 
	 * @param query one or more queries to write the availability information for
	 * @param format response format
	 * @param out to write the response to
	 */
	void writeAvailableConstraint(Set<AvailabilityQuery> queries, StructureFormat format, OutputStream out);
}
