package io.sdmx.core.data.model.format;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;

public class FlatDataFormatCSV implements DataFormat {
	private static final long serialVersionUID = 1L;
	private FormatDetails formatDetails = new FormatDetailsImpl("csv", MIME_TYPE.APPLICATION_CSV, false, "text/csv");
	private DELIMITER delimiter;


	public FlatDataFormatCSV(DELIMITER delimiter) {
		if(delimiter == null) {
			throw new SdmxException("Delimiter required for FlatDataFormatCSV");
		}
		this.delimiter = delimiter;
	}

	public DELIMITER getDelimiter() {
		return delimiter;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof FlatDataFormatCSV) {
			FlatDataFormatCSV that = (FlatDataFormatCSV) obj;
			return that.getDelimiter() == this.getDelimiter();
		}
		return false;
	}

	@Override
	public String toString() {
		return "CSV["+delimiter.getDelimiterAsString()+"]";
	}
}
