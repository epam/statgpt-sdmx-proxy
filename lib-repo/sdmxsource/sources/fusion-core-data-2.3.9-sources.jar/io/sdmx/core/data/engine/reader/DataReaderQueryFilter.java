package io.sdmx.core.data.engine.reader;

import java.util.Set;

import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.utils.core.object.AssertUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataReaderQueryFilter extends AbstractWrapperedDataReaderEngine implements DataReaderEngine {
	private static final Logger LOG = LoggerFactory.getLogger(DataReaderQueryFilter.class);

	private DataQuery dataQuery;
	private int keyPos = -1;

	private Observation obs;
	private boolean seriesKeysOnly = false;
	
	private Long dateFrom;
	private Long dateTo;

	public DataReaderQueryFilter(DataReaderEngine dataReaderEngine, DataQuery dataQuery) {
		super(dataReaderEngine);
		AssertUtil.notNull(dataQuery, "dataQuery");
		LOG.info("Create DataReaderQuery Filter with query: "+dataQuery);
		this.dataQuery = dataQuery;
		seriesKeysOnly = dataQuery.getDataQueryDetail() == DATA_QUERY_DETAIL.SERIES_KEYS_ONLY;
		
		if (dataQuery.getQueryPeriod() != null) {
			if(dataQuery.getQueryPeriod().getStartPeriod() != null) {
				dateFrom = dataQuery.getQueryPeriod().getStartPeriod().getDate().getTime();
			}
			if(dataQuery.getQueryPeriod().getEndPeriod() != null) {
				dateTo = dataQuery.getQueryPeriod().getEndPeriod().getDate().getTime();
			}
		}
		
	}
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		return new DataReaderQueryFilter(proxyCopy, dataQuery);
	}
	
	@Override
	public Keyable getCurrentKey() {
		return super.getCurrentKey();
	}

	@Override
	public int getKeyablePosition() {
		return keyPos;
	}

	@Override
	//TODO Other filters such as LastNObservations
	public boolean moveNextObservation() {
		boolean nextObs = true;
		obs = null;
		while(nextObs) {
			if(seriesKeysOnly) {
				return false;
			}
			nextObs = super.moveNextObservation();
			if(nextObs == false) {
				return false;
			}
			if(dateFrom == null && dateTo == null) {
				return nextObs;
			}
			
			obs = super.getCurrentObservation();
			if(dateFrom != null) {
				if(obs.getSdmxObsTime().getDate().getTime() < dateFrom) {
					continue;
				}
			}
			if(dateTo != null) {
				if(obs.getSdmxObsTime().getDate().getTime() > dateTo) {
					continue;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public Observation getCurrentObservation() {
		if(dateFrom == null || dateTo == null) {
			return super.getCurrentObservation();
		}
		return obs;
	}

	@Override
	public boolean moveNextDataset() {
		keyPos = -1;
		return super.moveNextDataset();
	}

	@Override
	public void reset() {
		keyPos = -1;
		super.reset();
	}

	@Override
	public boolean moveNextKeyable() {
		while(super.moveNextKeyable()) {
			Keyable key = super.getCurrentKey();
			boolean seriesMatch = seriesMatch(dataQuery, key);
			LOG.debug("Series Match '"+key+"'=" +seriesMatch);
			if(seriesMatch) {
				keyPos++;
				return true;
			}
		}
		return false;
	}

	private boolean seriesMatch(DataQuery dataQuery, Keyable key) {
		if (dataQuery.hasSelections()) {
			for(DataQuerySelection selection : dataQuery.getSelections()) {
				Set<String> selectionValues = selection.getValues();
				String val = key.getReportedValue(selection.getComponentId());
	    		if(val == null) {
	    			return false;  //NOT IN THE SERIES , ROLLED UP CONCEPTS DOES NOT CONTAIN THIS CONCEPT
	    		}
	    		if(selection.isExcluded()) {
	    			if(selectionValues.contains(val)) {
		    			return false;
		    		}	
	    		} else if(!selectionValues.contains(val)) {
	    			return false;
	    		}
	    	}
		}
		return true;
	}
}
