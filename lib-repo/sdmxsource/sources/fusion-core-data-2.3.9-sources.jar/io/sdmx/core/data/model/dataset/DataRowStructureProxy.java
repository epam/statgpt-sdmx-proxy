package io.sdmx.core.data.model.dataset;

import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;

/**
 * Changes the structures for a row of data
 */
public class DataRowStructureProxy extends ProxyDataRow {
	private IDatasetStructures structures; 
	
	public DataRowStructureProxy(IDataRow proxy, IDatasetStructures structures) {
		super(proxy);
		this.structures = structures;
	}

	@Override
	public IDatasetStructures getDatasetStructures() {
		return structures;
	}
}
