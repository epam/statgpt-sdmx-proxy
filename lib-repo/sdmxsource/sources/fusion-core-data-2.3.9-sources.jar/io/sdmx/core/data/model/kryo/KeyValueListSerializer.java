package io.sdmx.core.data.model.kryo;

import io.sdmx.api.collection.KeyValue;

public class KeyValueListSerializer extends ListSerializer<KeyValue> {
	private static final KeyValueListSerializer INSTANCE = new KeyValueListSerializer();
	
	public static KeyValueListSerializer getInstance() {
		return INSTANCE;
	}
	
	private KeyValueListSerializer() {
		super(KeyValueSerializer.getInstance());
	}

}