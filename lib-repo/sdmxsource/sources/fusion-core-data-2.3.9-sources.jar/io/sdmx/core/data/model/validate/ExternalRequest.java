package io.sdmx.core.data.model.validate;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.model.MVDuplicateBehaviour;

/**
 * Represents a request from a command line client to the service
 */
public class ExternalRequest {
	private ReadableDataLocation rdl;
	private DataFormat tranformTo;
	private DataFormat unmappedFormat;
	private List<IURNSingle<? extends IDSDRelatedBean>> validateStructures = Collections.emptyList();
	private IURNSingle<? extends IDSDRelatedBean> fromStructure;
	private IURNSingle<? extends IStructureMapRelatedBean> mapStructure;
	private String senderId;
	private String receiverId;
	private String datasetId;
	private DATASET_ACTION datasetAction;
	private int datasetIndex = -1;
	private boolean failOnError;
	private boolean includeUnmappedData;
	private boolean includeUnmappedReport;
	private boolean includeMetrics;

	private boolean includeValid;     //Optional - for Data validation, this will output the validation result AND the dataset containing only the valid data
	private boolean includeInValid;   //Optional - for Data validation, this will output the validation result AND the dataset containing only the invalid data

    private boolean skipValidation;

	private boolean isZip;
    private boolean priorDataDependent;

    private boolean mergeDatasets;

    private MVDuplicateBehaviour duplicateBehaviour;
    
	public DataFormat getUnmappedFormat() {
		return unmappedFormat;
	}

	public void setUnmappedFormat(DataFormat unmappedFormat) {
		this.unmappedFormat = unmappedFormat;
	}

	public boolean isZip() {
		return isZip;
	}

	public void setZip(boolean isZip) {
		this.isZip = isZip;
	}

	public boolean isIncludeValid() {
		return includeValid;
	}

	public void setIncludeValid(boolean includeValid) {
		this.includeValid = includeValid;
	}

	public boolean isIncludeInvalid() {
		return includeInValid;
	}

	public void setIncludeInvalid(boolean includeInValid) {
		this.includeInValid = includeInValid;
	}

	public boolean isIncludeUnmapped() {
		return includeUnmappedData;
	}

	public void setIncludeUnmapped(boolean includeUnmapped) {
		this.includeUnmappedData = includeUnmapped;
	}

	public boolean isIncludeUnmappedReport() {
		return includeUnmappedReport;
	}

	public void setIncludeUnmappedReport(boolean includeUnmappedReport) {
		this.includeUnmappedReport = includeUnmappedReport;
	}
	
	public boolean isIncludeMetrics() {
		return includeMetrics;
	}

	public void setIncludeMetrics(boolean includeMetrics) {
		this.includeMetrics = includeMetrics;
	}

	public MVDuplicateBehaviour getDuplicateBehaviour() {
		return duplicateBehaviour;
	}
	
	public void setDuplicateBehaviour(MVDuplicateBehaviour b) {
		this.duplicateBehaviour = b;
	}

	public boolean isFailOnError() {
		return failOnError;
	}

	public void setFailOnError(boolean failOnError) {
		this.failOnError = failOnError;
	}

	public int getDatasetIndex() {
		return datasetIndex;
	}

	public void setDatasetIndex(int datasetIndex) {
		this.datasetIndex = datasetIndex;
	}

	/**
	 * @return an RDL containing an input stream to the dataset
	 */
	public ReadableDataLocation getRdl() {
		return rdl;
	}

	public void setRdl(ReadableDataLocation rdl) {
		this.rdl = rdl;
	}

	public void setTranformTo(DataFormat tranformTo) {
		this.tranformTo = tranformTo;
	}
	
	/**
	 * A list of Dataflow or Provision References to apply to each dataset for futher validation
	 */
	public List<IURNSingle<? extends IDSDRelatedBean>> getValidateStructures() {
		return validateStructures;
	}

	public void setValidateStructures(List<IURNSingle<? extends IDSDRelatedBean>> validateStructures) {
		this.validateStructures = validateStructures;
	}

	public void setFromStructure(IURNSingle<? extends IDSDRelatedBean> fromStructure) {
		this.fromStructure = fromStructure;
	}

	public void setMapStructure(IURNSingle<? extends IStructureMapRelatedBean> mapStructure) {
		this.mapStructure = mapStructure;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	public String getReceiverId() {
		return receiverId;
	}

	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}

	public String getDatasetId() {
		return datasetId;
	}

	public void setDatasetAction(DATASET_ACTION datasetAction) {
		this.datasetAction = datasetAction;
	}

	public DATASET_ACTION getDatasetAction() {
		return datasetAction;
	}

	/**
	 * @return the data format to output the dataset it
	 */
	public DataFormat getTranformTo() {
		return tranformTo;
	}

	/**
	 * @return a Structure Reference of the structure that the incoming dataset references
	 */
	public IURNSingle<? extends IDSDRelatedBean> getFromStructure() {
		return fromStructure;
	}

	/**
     * @return a Structure Reference of the structure to map the data to when validating/writing output
     */
	public IURNSingle<? extends IStructureMapRelatedBean> getMapStructure() {
		return mapStructure;
	}

	/**
	 * Sets whether this request is "prior data dependent"
	 * @param val
	 */
    public void setPriorDataDependent(boolean val) {
        this.priorDataDependent = val;
    }

    /**
     * @return whether this is "prior data dependent"
     */
    public boolean isPriorDataDependent() {
        return this.priorDataDependent;
    }

    /**
     * Sets whether this request should merge Datasets
     * @param val
     */
    public void setMergeDatasets(boolean val) {
        this.mergeDatasets = val;
    }

    /**
     * @return whether this request should merge datasets
     */
    public boolean isMergeDatasets() {
        return this.mergeDatasets;
    }

	public boolean isSkipValidation() {
		return skipValidation;
	}

	public void setSkipValidation(boolean skipValidation) {
		this.skipValidation = skipValidation;
	}
}