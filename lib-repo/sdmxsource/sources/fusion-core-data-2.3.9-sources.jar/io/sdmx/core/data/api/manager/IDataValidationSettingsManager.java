package io.sdmx.core.data.api.manager;

public interface IDataValidationSettingsManager {

	/**
     * @return the maximum number of errors that can be thrown before validation is aborted
     */
    int getMaxNumberOfErrors();

    /**
     * Set the maximum number of errors
     * @param maxErrors
     */
    void setMaxNumberOfErrors(int maxErrors);
}
