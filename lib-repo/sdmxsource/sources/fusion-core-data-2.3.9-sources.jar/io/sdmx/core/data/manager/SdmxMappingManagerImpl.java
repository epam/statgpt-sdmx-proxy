package io.sdmx.core.data.manager;

import java.io.OutputStream;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.core.data.api.manager.DataValidationManager;
import io.sdmx.core.data.api.manager.IFlatDataReaderManager;
import io.sdmx.core.data.api.manager.SdmxMappingManager;
import io.sdmx.core.data.api.model.mapping.IExplainMap;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.engine.mapping.MappingDataReportWriterJson;
import io.sdmx.core.data.engine.mapping.MappingEngineImpl;
import io.sdmx.core.data.engine.mapping.MappingExplainWriterEngineJson;
import io.sdmx.core.data.engine.reader.FlatDataReaderEngine2SeriesObs;
import io.sdmx.core.data.engine.writer.MappingDataWriterEngine;
import io.sdmx.core.data.model.mapping.DataMappingConfig;
import io.sdmx.core.data.model.mapping.MappingRulesImpl;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.data.util.MappingUtil;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxMappingManagerImpl implements SdmxMappingManager, IStructureEventListener  {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMappingManagerImpl.class);

	protected SdmxBeanRetrievalManager sdmxBeanRetrievalManager;
	protected SdmxSuperBeanRetrievalManager superBeanRetrievalManager;

	private CrossReferencingRetrievalManager crossReferencingRetrievalManager;
	private DataValidationManager dataValidationManager;
	private IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager;
	
	//Cache
	protected Map<String, MappingRules> mapping = new ConcurrentHashMap<>();  //source urn+target urn = Map

	//Structure Map URN to DataStructureMap
	private Map<IURNAbsolute<IStructureMapBean>, MappingRules> sMapToDsMap = new ConcurrentHashMap<>();


	private Map<IStructureMapBean, MappingRules> mapsForStructureMap = new ConcurrentHashMap<>();

	private Set<Listener<IStructureEvent>> listeners = new HashSet<>();

	private boolean outputRequired;
	
	public SdmxMappingManagerImpl(SdmxBeanRetrievalManager sdmxBeanRetrievalManager,
								  SdmxSuperBeanRetrievalManager sbRetMan,
								  CrossReferencingRetrievalManager crossReferencingRetrievalManager,
								  DataValidationManager dataValidationManager,
								  IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager) {
		if(sdmxBeanRetrievalManager == null) {
			throw new IllegalArgumentException("SdmxMappingManagerImpl -> SdmxBeanRetrievalManager Required");
		}
		if(sbRetMan == null) {
			throw new IllegalArgumentException("SdmxMappingManagerImpl -> SdmxSuperBeanRetrievalManager Required");
		}
		if(crossReferencingRetrievalManager == null) {
			throw new IllegalArgumentException("SdmxMappingManagerImpl -> CrossReferencingRetrievalManager Required");
		}
		this.dataValidationManager = dataValidationManager;
		this.sdmxBeanRetrievalManager = sdmxBeanRetrievalManager;
		this.superBeanRetrievalManager = sbRetMan;
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
		this.constraintPrefixDetailRetreivalManager = constraintPrefixDetailRetreivalManager;
		this.outputRequired = MappingUtil.isOutputRequired();
	}
	
	
	/**
	 * Ensure the cache is not stale corresponding to configuration
	 */
	private void checkCache() {
		if(MappingUtil.isOutputRequired() != this.outputRequired) {
			this.outputRequired = MappingUtil.isOutputRequired();
			clearCache();
		}
		if(mapping.isEmpty()) {
			rebuildCache();
		}
	}
	
	private void rebuildCache() {
		for(IStructureMapBean currentMap : this.sdmxBeanRetrievalManager.getMaintainableBeans(URN.build(IStructureMapBean.class))) {
			try {
				registerMappingRule(currentMap);
			} catch(Throwable th) {
				th.printStackTrace();
			}
		}
	}
	
	

	@Override
	public void notifyStructureEvent(IStructureEvent event) {
		//Additions
		SdmxBeans additions = event.getAdditions();
		//Structure Set Mapping
		for(IStructureMapBean structureMap : additions.getStructureMaps()) {
			try {
				registerMappingRule(structureMap);
			} catch(Throwable th) {
				th.printStackTrace();
			}
		}
		//Modifications
		SdmxBeans modifications = event.getModification();
		for(DataStructureBean dsd : modifications.getDataStructures()) {
			for(IStructureMapBean maint : crossReferencingRetrievalManager.getAllAncestors(dsd.getURN(), IStructureMapBean.class)) {
				//THIS SHOULD ALWAYS BE TRUE
				if(maint.getStructureType() == SDMX_STRUCTURE_TYPE.STRUCTURE_MAP) {
					try {
						deregisterMappingRule((IStructureMapBean)maint);
						registerMappingRule((IStructureMapBean)maint);
					} catch(Throwable th) {
						th.printStackTrace();
					}
				}
			}
		}
		for(IStructureMapBean structureMap : modifications.getStructureMaps()) {
			try {
				deregisterMappingRule(structureMap);
				registerMappingRule(structureMap);
			} catch(Throwable th) {
				th.printStackTrace();
			}
		}
		for(IRepresentationMapBean repMap : modifications.getRepresentationMaps()) {
			for(IStructureMapBean maint : crossReferencingRetrievalManager.getAllAncestors(repMap.getURN(), IStructureMapBean.class)) {
				try {
					deregisterMappingRule(maint);
					registerMappingRule(maint);
				} catch(Throwable th) {
					th.printStackTrace();
				}
			}
		}
		//DELETIONS
		SdmxBeans deletions = event.getDeletions();
		for(IStructureMapBean structureMap : deletions.getStructureMaps()) {
			deregisterMappingRule(structureMap);
		}
		notifyListeners(event);
	}

	@Override
	public void clearCache() {
		mapping = new ConcurrentHashMap<>();  //source urn+target urn = Map
		sMapToDsMap = new ConcurrentHashMap<>();
		mapsForStructureMap = new ConcurrentHashMap<>();
	}


	@Override
	public void addListener(Listener<IStructureEvent> listener) {
		listeners.add(listener);
	}

	@Override
	public void removeListener(Listener<IStructureEvent> listener) {
		listeners.remove(listener);
	}

	private void notifyListeners(IStructureEvent event) {
		LOG.info("Beans Event processed. Notify all listeners");

		for(Listener<IStructureEvent> currentListener : listeners) {
			//Ensure the notification is just the beans that changed, not all of them
			LOG.debug("Notify Listener: " + currentListener);
			currentListener.invoke(event);
		}
	}

	@Override
	public Set<DataflowBean> getMappingsForFlow(DataflowBean fromFlow) {
		checkCache();
		Set<DataflowBean> returnSet = new HashSet<>();
		for(MappingRules currentMap : mapping.values()) {
			if(currentMap.getFromDataflow() != null && currentMap.getFromDataflow().equals(fromFlow)) {
				returnSet.add(currentMap.getToDataflow());
			} else if(currentMap.getToDataflow() != null && currentMap.getToDataflow().equals(fromFlow)) {
				returnSet.add(currentMap.getFromDataflow());
			}
		}
		return returnSet;
	}



	@Override
	public Set<DataStructureBean> getMappingsForStructure(DataStructureBean fromDsd) {
		checkCache();
		Set<DataStructureBean> returnSet = new HashSet<>();
		for(MappingRules currentMap : mapping.values()) {
			if(currentMap.getFromDataStructure() != null && currentMap.getFromDataStructure().equals(fromDsd)) {
				returnSet.add(currentMap.getToDataStructure());
			} else if(currentMap.getToDataStructure() != null && currentMap.getToDataStructure().equals(fromDsd)) {
				returnSet.add(currentMap.getFromDataStructure());
			}
		}
		return returnSet;
	}

	@Override
	public MappingRules getDataStructureMap(DataStructureBean sourceDSD, DataStructureBean targetDSD) {
		checkCache();
		MappingRules map = mapping.get(getMapKey(sourceDSD, targetDSD));
		if(map == null) {
			map = mapping.get(getMapKey(targetDSD, sourceDSD));
		}
		return map;
	}



	@Override
	/**
	 * First check for maps for dataflow, then DSD
	 */
	public MappingRules getDataStructureMap(DataflowBean sourceDataflow, DataflowBean targetDataflow) {
		checkCache();
		if(sourceDataflow == null) {
			throw new SdmxException("Can not perform mapping, source dataflow was not provided");
		}
		if(targetDataflow == null) {
			throw new SdmxException("Can not perform mapping, target dataflow was not provided");
		}
		MappingRules map = mapping.get(getMapKey(sourceDataflow, targetDataflow));
		if(map == null) {
			map = mapping.get(getMapKey(targetDataflow, sourceDataflow));
		}
		if(map == null) {
			map = mapping.get(getMapKey(sourceDataflow.getDataStructureRef().getReference(), targetDataflow.getDataStructureRef().getReference()));
		}
		if(map == null) {
			map = mapping.get(getMapKey(targetDataflow.getDataStructureRef().getReference(), sourceDataflow.getDataStructureRef().getReference()));
		}
		return map;
	}

	@Override
	public void writeExplainPlan(IURNSingle<IStructureMapBean> mapRef, IDataRow row, OutputStream out) {
		MappingRules rules = getDataStructureMap(mapRef);
		IExplainMap explain = MappingEngineImpl.getInstance().explainMapping(rules, row);
		MappingExplainWriterEngineJson.getInstance().writeExplainMap(explain, out);
	}

	@Override
	public void writeMappingReport(ReadableDataLocation rdl, IURNSingle<IStructureMapBean> mapRef, boolean isSource, OutputStream out, boolean isValidating) {
		MappingRules rules = getDataStructureMap(mapRef);
		DataStructureBean dsd = isSource ? rules.getFromDataStructure() : rules.getToDataStructure();
		DataflowBean flow = isSource ? rules.getFromDataflow() : rules.getToDataflow();
		
		//This is a bit hacky as it moves from flat to non flat - try to remove once the non-flat can take a IDatasetStructuresRetrievalManager instead of a SdmxBeanRetreivalManager
		IFlatDataReaderEngine dre = SingletonStore.getSingleton(IFlatDataReaderManager.class).getDataReaderEngine(rdl, new IDatasetStructuresRetrievalManager() {
			
			@Override
			public IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef) {
				if(!sRef.isMatch(dsd)) {
					return new DatasetStructures(sRef, sdmxBeanRetrievalManager);
				}
				return new DatasetStructures(dsd, flow, null, null);
			}
		});
		MappingDataReportWriterJson mappingReportWriter = new MappingDataReportWriterJson(out);
		DataMappingConfig mappingConfig = DataMappingConfig.getInstance(rules).setReportDataWriterEngine(mappingReportWriter);
		mappingConfig.setForceFlat(true);  //for the report, treat everything as an obs
		if(dataValidationManager != null && isValidating) {
			mappingConfig.setValidation(dataValidationManager.obtainFactoriesToBeUsedInDataValidation(true), superBeanRetrievalManager, constraintPrefixDetailRetreivalManager);
		}
		
		MappingDataWriterEngine mappingDwe = new MappingDataWriterEngine(mappingConfig);
		
		DataReaderEngine dre2 = new FlatDataReaderEngine2SeriesObs(dre);
		DataTransformationUtil.copyData(dre2, mappingDwe, true, true);
	}

	
	/**
	 * Returns a structure map from a reference to the structure map
	 * @param sRef
	 * @return
	 */
	@Override
	public MappingRules getDataStructureMap(IURNSingle<IStructureMapBean> sRef) {
		checkCache();
		MappingRules dsMap = sMapToDsMap.get(sRef);
		if(dsMap == null) {
			IStructureMapBean sMap = sdmxBeanRetrievalManager.getBean(sRef);
			if(sMap == null) {
				throw new SdmxReferenceException(sRef);
			}
			dsMap = registerMappingRule(sMap);
		}
		return dsMap;
	}

	private void deregisterMappingRule(IStructureMapBean structureSet) {
		LOG.info("Deregister Mapping Rule " + structureSet.getUrn());
		MappingRules dsMap = this.mapsForStructureMap.get(structureSet);
		if(dsMap != null) {
			deregisterMappingRule(dsMap);
		}
	}

	private void deregisterMappingRule(MappingRules dsMap) {
		if(dsMap != null) {
			String[] keys = getMapKeys(dsMap);
			this.mapping.remove(keys[0], dsMap);
			if(keys[1] != null) {
				this.mapping.remove(keys[1], dsMap);
			}
			this.sMapToDsMap.remove(dsMap.getStructureMapBean().getURN());
		}
	}

	@Override
	public MappingRules registerMappingRule(IStructureMapBean map) {
		LOG.info("Register Mapping Rule " + map.getUrn());
		MappingRules m1 = new MappingRulesImpl(map, this.sdmxBeanRetrievalManager);
		storeMap(m1);
		mapsForStructureMap.put(map, m1);
		return m1;
	}


	private void storeMap(MappingRules dsMap) {
		String[] keys = getMapKeys(dsMap);
		this.mapping.put(keys[0], dsMap);
		if(keys[1] != null) {
			this.mapping.put(keys[1], dsMap);
		}
		this.sMapToDsMap.put(dsMap.getStructureMapBean().getURN(), dsMap);
	}

	private String[] getMapKeys(MappingRules map) {
		String[] returnKeys = new String[2];
		returnKeys[0] = getMapKey(map.getFromDataStructure(), map.getToDataStructure());
		if(map.getFromDataflow() != null) {
			returnKeys[1] = getMapKey(map.getFromDataflow(), map.getToDataflow());
		}
		return returnKeys;
	}

	private String getMapKey(MaintainableBean source, MaintainableBean target) {
		return source.getUrn() + target.getUrn();
	}

	private String getMapKey(IURNSingle<? extends IDSDRelatedBean> source, IURNSingle<? extends IDSDRelatedBean> target) {
		return source.getURN() + target.getURN();
	}
}
