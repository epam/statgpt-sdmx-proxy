package io.sdmx.core.data.manager;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.im.beans.container.DatasetStructures;

/**
 * Returns the same {@link IDatasetStructures} regardless of what the request was
 */
public class FixedDatasetStructuresRetrievalManager implements IDatasetStructuresRetrievalManager {
	private IDatasetStructures structures;
	
	public FixedDatasetStructuresRetrievalManager(IURNSingle<? extends IDSDRelatedBean> sRef, SdmxBeanRetrievalManager retMan) {
		this.structures = new DatasetStructures(sRef, retMan);
	}
	
	public FixedDatasetStructuresRetrievalManager(DataStructureBean dsd, DataflowBean flow, ProvisionAgreementBean prov) {
		this.structures = new DatasetStructures(dsd, flow, prov, null);
	}

	@Override
	public IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef) {
		return structures;
	}
}
