package io.sdmx.core.data.engine.mapping;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.data.api.engine.mapping.IMappingDataReportWriter;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * A data writer engine for mapped data, where the output is a report on
 * which rows map and which do not.
 * 
 * Example Report:
 * <pre>
 * {
 * 	 StructureMap : urn,
 *   SourceData : {
 *    	DSD : urn,
 *    	Dataflow : urn,
 *    	Components : ["DIM1", "Dx", "att1", "a..n"]
 *   },
 *   TargetData : {
 *    	DSD : urn,
 *    	Dataflow : urn,
 *    	Components : ["DIM1", "Dx", "att1", "a..n"]
 *   },
 *   Result : [  //a result of all the mapped rows
 * 	  {
 *      Input : ["A","B","C"]  				//input row
 *      Output : ["OUT1", ["a, x"], "OUT3"]	//output row (dim 2 has more then one mapped value)
 *    },
 *    {
 *      Input : ["A","B","C"]  				//input row
 *      Unmapped : [
 *        {
 *     	    PeriodStart : null //no start
 *     	    PeriodEnd : "2008"
 *          Output : ["OUT1", ["a, x"], "OUT3"]	//output row (dim 2 has more then one mapped value)
 *        }
 *      ]
 *    }
 *   ]
 * }
 * </pre>
 */
public class MappingDataReportWriterJson implements IMappingDataReportWriter {
	protected JsonGenerator jsonGenerator;
	protected String[] sourceComponents;
	protected String[] targetComponents;
	private boolean isClosed;

	public MappingDataReportWriterJson(OutputStream out) {
		this(JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON));
	}
	
	public MappingDataReportWriterJson(JsonGenerator jg) {
		this.jsonGenerator = jg;
	}
	
	@Override
	public void writeMappingRules(MappingRules mappingRules) {
		try {
			this.jsonGenerator.writeStartObject();
			writeMaintainable("StructureMap", mappingRules.getStructureMapBean());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void writeMappedStructures(IDatasetStructures inputStructures, IDatasetStructures outputStructures) {
		sourceComponents = SdmxCollectionUtil.identifiablesIdArray(inputStructures.getDataStructure().getComponents());
		targetComponents = SdmxCollectionUtil.identifiablesIdArray(outputStructures.getDataStructure().getComponents());
		
		try {
			//Start the results array
			writeStructure("SourceStructure", inputStructures, sourceComponents);
			writeStructure("TargetStructure", outputStructures, targetComponents);
			jsonGenerator.writeArrayFieldStart("Result");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	private void writeStructure(String label, IDatasetStructures structures, String[] structure) throws IOException {
		jsonGenerator.writeObjectFieldStart(label);
		writeMaintainable("DSD", structures.getDataStructure());
		writeMaintainable("Dataflow", structures.getDataflow());
		JsonWriterUtil.writeStringArray(jsonGenerator, "Components", structure);
		jsonGenerator.writeEndObject();
	}
	
	private void writeMaintainable(String label, MaintainableBean maint) throws IOException {
		if(maint != null) {
			jsonGenerator.writeStringField(label, maint.getUrn());
		}
	}

	@Override
	public void writeMappedRow(IDataRow inputRow, IDataRow outputRow, SdmxPeriod validityPeriod,  Map<FusionError, KeyValue> validationErrors) {
		try {
			this.jsonGenerator.writeStartObject();
			writeValueArray("Input", sourceComponents, inputRow.getRowData(), inputRow.getMultiValueData());
			writeValueArray("Output", targetComponents, outputRow.getRowData(), outputRow.getMultiValueData());
			if(ObjectUtil.validMap(validationErrors) ) {
				this.jsonGenerator.writeArrayFieldStart("ValidationErrors");
				for(FusionError currentError : validationErrors.keySet()) {
					this.jsonGenerator.writeString(currentError.getErrorMessage());
				}
				this.jsonGenerator.writeEndArray();
			}
			this.jsonGenerator.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void writeUnMappedRow(IDataRow inputRow, IDataRow outputRow, SdmxPeriod validityPeriod, Set<IComponentMapping> unmappedComponents) {
		try {
			this.jsonGenerator.writeStartObject();
			writeValueArray("Input", sourceComponents, inputRow.getRowData(), inputRow.getMultiValueData());
			this.jsonGenerator.writeArrayFieldStart("Unmapped");
			writeUnmappedElements(validityPeriod, outputRow, unmappedComponents);
			this.jsonGenerator.writeEndArray();  //end unmapped
			this.jsonGenerator.writeEndObject();  //end object
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected void writeUnmappedElements(SdmxPeriod period, IDataRow row, Set<IComponentMapping> unmappedComponents) throws IOException {
		this.jsonGenerator.writeStartObject();
		
		writePeriods(period);
		writeValueArray("Output", targetComponents, row.getRowData(), row.getMultiValueData());
		
		this.jsonGenerator.writeArrayFieldStart("MissingComponents");
		for (IComponentMapping componentMapping : unmappedComponents) {
			for(String sourceComponentId : componentMapping.getSourceComponents()) {
				this.jsonGenerator.writeString(sourceComponentId);
			}
		}
		this.jsonGenerator.writeEndArray();
		
		this.jsonGenerator.writeEndObject();
	}
	
	protected void writePeriods(SdmxPeriod period) throws IOException {
		if(period != SdmxPeriodImpl.ALL_PERIODS) {
			if(period.hasStartPeriod()) {
				this.jsonGenerator.writeStringField("PeriodStart", period.getStartPeriod().getDateInSdmxFormat());
			}
			if(period.hasEndPeriod()) {
				this.jsonGenerator.writeStringField("PeriodEnd", period.getEndPeriod().getDateInSdmxFormat());
			}
		}
	}

	protected void writeValueArray(String arrayName, String[] components, Map<String, String> singleValue, Map<String, Set<String>> multiValue) throws IOException {
		if(singleValue == null) {
			singleValue = Collections.emptyMap();
		}
		if(multiValue == null) {
			multiValue = Collections.emptyMap();
		}
		this.jsonGenerator.writeArrayFieldStart(arrayName);
		for(int i=0; i < components.length; i++) {
			String componentId = components[i];
			String reportedData = singleValue.get(componentId);
			if(reportedData == null) {
				//Could be multivalue
				Set<String> values = multiValue.get(componentId);
				if(values != null) {
					if(values.size() == 1) {
						this.jsonGenerator.writeString((String)values.toArray()[0]);
					} else {
						JsonWriterUtil.writeStringArray(jsonGenerator, null, values);
					}
				} else {
					this.jsonGenerator.writeNull();
				}
			} else {
				this.jsonGenerator.writeString(reportedData);
			}
		}
		this.jsonGenerator.writeEndArray();
	}

	@Override
	public void close() {
		if(isClosed) {
			return;
		}
		isClosed = true;
		try {
			this.jsonGenerator.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
