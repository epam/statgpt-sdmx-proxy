package io.sdmx.core.data.api.model.calculation;

import io.sdmx.core.data.model.calcuation.Calculator;

/**
 * A funciton which can be registered with the {@link Calculator}
 */
public interface ICalculationFunction {

	/**
	 * @return the function name, for example PCTOF
	 */
	String functionName();
	
	/**
	 * @return minimum number of expected arguments, where arguments are comma separated, for example FUNCION(A,B,C)
	 */
	int minArguments();
	
	/**
	 * @return maximum number of expected arguments, where arguments are comma separated, for example FUNCION(A,B,C)
	 */
	int maxArguments();
	
	/**
	 * @param args array of arguments, for example PCT(3,2) would supply the args 3 and 2
	 * @return  the string as a calculation expression, for example rewrites PCTOF(3, 2) would return the string ((100/3) * 2)
	 */
	String rewrite(String... args);
}
