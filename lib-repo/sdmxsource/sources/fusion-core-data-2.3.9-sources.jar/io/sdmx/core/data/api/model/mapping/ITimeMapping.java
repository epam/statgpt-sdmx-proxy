package io.sdmx.core.data.api.model.mapping;

import java.util.List;

import io.sdmx.utils.core.collection.CollectionUtil;

public interface ITimeMapping extends IComponentMapping {

	/**
	 * The source components, whose combined values are used to derive the output value(s) for the target components
	 * @return A list of Component IDs from the source DSD
	 */
	String getSourceComponent();

	/**
	 * The target components the source components map to
	 * @return A list of Component IDs to the target DSD
	 */
	String getTargetComponent();
	
	/**
	 * @return optional - Id of the Component in the output DSD which holds the value for output frequency, if this is not null then the mapping
	 * expects the frequency value to be passed into this mapping in order to derive the output format for time
	 */
	String getFrequencyComponent();
	

	/**
	 * @param sourceValue source time value, for example Mar-2007
	 * @param freq required only if getFrequencyComponent returns a not null value.  In the case it is required, this is the value of the frequency component 
	 * for the series that is being mapped
	 * @return
	 */
	String getMappedValue(String sourceValue, String freq);
	
	/**
	 * Returns all the source components used as input to this mapping (unmodifiable list). All values for each component must be concatenated together
	 * to create a sourceValue used to call getMappedCodes, for example if this method returns FREQ and REF_AREA then a source value would be A:UK
	 * @return
	 */
	default List<String> getSourceComponents() {
		return CollectionUtil.toList(getSourceComponent());
	}
	
	/**
	 * Returns all the target components of this mapping (unmodifiable list)
	 * @return
	 */
	default List<String> getTargetComponents() {
		 return CollectionUtil.toList(getTargetComponent());
	}
	
	IExplainMapComponent explain(String sourceValue, String freq);
}
