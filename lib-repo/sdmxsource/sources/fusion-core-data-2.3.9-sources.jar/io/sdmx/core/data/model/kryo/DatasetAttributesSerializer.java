package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;

import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;

public class DatasetAttributesSerializer extends AttributableSerializer<IDatasetAttributes> {
	private static final DatasetAttributesSerializer INSTANCE = new DatasetAttributesSerializer();
	
	public static DatasetAttributesSerializer getInstance() {
		return INSTANCE;
	}
	
	private DatasetAttributesSerializer() { }

	@Override
	protected AttributableBuilder<IDatasetAttributes> getBuilder(Kryo kryo, Input input) {
		return DatasetAttributes.builder();
	}

}