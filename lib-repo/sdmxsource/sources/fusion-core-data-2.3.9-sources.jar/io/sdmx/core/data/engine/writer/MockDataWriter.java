package io.sdmx.core.data.engine.writer;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;

// Does not actually write as such, simply interrogates and stores the structures that are referenced.
public class MockDataWriter extends DatasetInfoDataWriterEngine {
	private SdmxBeans beans;

	public MockDataWriter(SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		super(superBeanRetrievalManager);
	}
	
	@Override
	public void writeHeader(HeaderBean header) {}

	@Override
	public void close(FooterMessage... footer) {
		if(currentDSDSuperBean == null) {
			return;
		}
		beans = new SdmxBeansImpl();
		for(ComponentSuperBean sb : currentDSDSuperBean.getComponents()) {
			beans.addIdentifiable(sb.getConcept().getBuiltFrom());

			EnumeratedListBean<? extends EnumeratedItemBean> cl = sb.getCodelist(true);

			if(cl != null) {
				Set<String> reportedValues = new HashSet<>(super.getReportedValues(sb.getId()));
				beans.addIdentifiable(cl.filterItems(reportedValues, true));
			}
		}

	}

	public SdmxBeans getAllStructures() {
		return beans;
	}
}
