package io.sdmx.core.data.manager;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.api.manager.DataParseManager;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.logging.LoggingUtil;

public class DataParseManagerImpl implements DataParseManager {
	private final Logger log = LoggerFactory.getLogger(DataParseManagerImpl.class);

	private DataReaderManager dataReaderManager;
	private DataWriterManager dataWriterManager;
	private StructureReaderManager structureParsingManager;
	
	public DataParseManagerImpl(DataReaderManager dataReaderManager, DataWriterManager dataWriterManager, StructureReaderManager structureParsingManager) {
		this.dataReaderManager = dataReaderManager;
		this.dataWriterManager = dataWriterManager;
		this.structureParsingManager = structureParsingManager;
	}

	@Override
	public void performTransform(ReadableDataLocation sourceData, ReadableDataLocation dsdLocation, OutputStream out, DataFormat dataFormat) {
		SdmxBeans beans = structureParsingManager.parseStructures(dsdLocation);
		performTransform(sourceData, out, dataFormat, new InMemoryRetrievalManager(beans));
	}

	@Override
	public void performTransform(ReadableDataLocation sourceData, OutputStream out, DataFormat dataFormat, DataStructureBean dsd, DataflowBean flow) {
		LoggingUtil.debug(log, "Perform transform request");
		try {
			DataReaderEngine dre = dataReaderManager.getDataReaderEngine(sourceData, dsd, flow, null, null);
			ISeriesObsDataWriterEngine dwe = dataWriterManager.getDataWriterEngine(dataFormat, out);
			DataTransformationUtil.copyData(dre, dwe, true, true);
		} finally {
			StreamUtil.closeStream(out);
		}
	}

	@Override
	public List<ReadableDataLocation> performTransformAndSplit(ReadableDataLocation sourceData, ReadableDataLocation dsdLocation, DataFormat dataFormat) {
		SdmxBeans beans = structureParsingManager.parseStructures(dsdLocation);
		SdmxBeanRetrievalManager retrievalManager = new InMemoryRetrievalManager(beans);
		return performTransformAndSplit(sourceData, dataFormat, retrievalManager);
	}

	@Override
	public List<ReadableDataLocation> performTransformAndSplit(ReadableDataLocation sourceData, DataFormat dataFormat, SdmxBeanRetrievalManager retrievalManager) {
		DataReaderEngine dre = dataReaderManager.getDataReaderEngine(sourceData, retrievalManager, null);

		List<ReadableDataLocation> returnList = new ArrayList<>();
		WriteableDataLocation tmpDataLocation;
		while(dre.moveNextDataset()) {
			tmpDataLocation = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation();
			ISeriesObsDataWriterEngine dwe = dataWriterManager.getDataWriterEngine(dataFormat, tmpDataLocation.getOutputStream());
			DataTransformationUtil.copyData(dre, dwe, true, true);
			returnList.add(tmpDataLocation);
		}
		return returnList;
	}

	@Override
	public void performTransform(ReadableDataLocation sourceData, OutputStream out, DataFormat dataFormat, SdmxBeanRetrievalManager beanRetrievalManager) {
		LoggingUtil.debug(log, "Perform transform request");

		DataReaderEngine dre = null;
		ISeriesObsDataWriterEngine dwe = null;
		try {
			dre = dataReaderManager.getDataReaderEngine(sourceData, beanRetrievalManager, null);
			dwe = dataWriterManager.getDataWriterEngine(dataFormat, out);
			DataTransformationUtil.copyData(dre, dwe, true, true);
		} finally {
			StreamUtil.closeStream(out);
			if (dre != null) {
				dre.close();
			}
			if (dwe != null) {
				dwe.close();
			}
		}
	}

	@Override
	public ReadableDataLocation performTransform(ReadableDataLocation sourceData, DataFormat dataFormat, SdmxBeanRetrievalManager beanRetrievalManager) {
		WriteableDataLocation tmpDataLocation = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation();
		try {
			LoggingUtil.debug(log, "URI generated to write transformed dataset to :" + tmpDataLocation.toString());
			performTransform(sourceData, tmpDataLocation.getOutputStream(), dataFormat, beanRetrievalManager);
			return tmpDataLocation;
		} catch(RuntimeException rtEx) {
			tmpDataLocation.close();
			throw rtEx;
		} finally {
			if(tmpDataLocation != null) {
				StreamUtil.closeStream(tmpDataLocation.getOutputStream());
			}
		}
	}

	@Override
	public ReadableDataLocation performTransform(ReadableDataLocation sourceData, DataFormat dataFormat,DataStructureBean dsd, DataflowBean flow) {
		WriteableDataLocation tmpBuffer = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation();
		try (OutputStream outputstream = tmpBuffer.getOutputStream()) {
			LoggingUtil.debug(log, "URI generated to write transformed dataset to :" + tmpBuffer.toString());
			performTransform(sourceData, outputstream, dataFormat, dsd, flow);
			return tmpBuffer;
		} catch(RuntimeException rtx) {
			tmpBuffer.close();
			throw rtx;
        } catch(IOException ioe) {
            tmpBuffer.close();
            throw new RuntimeException(ioe);
        }
	}
}
