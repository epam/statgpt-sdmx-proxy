package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;


/**
 * Serialization for DATASET_ACTION.
 */
public class DT_DATASET_ACTION extends BasicDataType<DATASET_ACTION> {
  @Override
  public int getMemory(DATASET_ACTION action) {
    return 1;
  }

  @Override
  public void write(WriteBuffer buf, DATASET_ACTION action) {
    int i = 0; // for null

    if (action != null)
      switch (action) {
        case APPEND :       i = 1; break;
        case REPLACE :      i = 2; break;
        case FULL_REPLACE : i = 3; break;
        case DELETE :       i = 4; break;
        case INFORMATION :  i = 5; break;
        case MERGE :        i = 6; break;
        case UPDATE :       i = 7; break;
        default:
          throw new IllegalArgumentException("Invalid value: " + action);
      }

    buf.putVarInt(i);
  }

  @Override
  public DATASET_ACTION read(ByteBuffer buf) {
    int i = DataUtils.readVarInt(buf);
    DATASET_ACTION action = null;

    if (i != 0)
      switch (i) {
        case 1 : action = DATASET_ACTION.APPEND;       break;
        case 2 : action = DATASET_ACTION.REPLACE;      break;
        case 3 : action = DATASET_ACTION.FULL_REPLACE; break;
        case 4 : action = DATASET_ACTION.DELETE;       break;
        case 5 : action = DATASET_ACTION.INFORMATION;  break;
        case 6 : action = DATASET_ACTION.MERGE;        break;
        case 7 : action = DATASET_ACTION.UPDATE;       break;
        default:
          throw new IllegalArgumentException("Invalid value: " + i);
      }

    return action;
  }

  @Override
  public DATASET_ACTION[] createStorage(int size) {
    return new DATASET_ACTION[size];
  }
}
