package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.ObjectDataType;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;

public class DT_MultilingualNodeValue extends BasicDataType<IMultilingualNodeValue> {
	private static final DT_MultilingualNodeValue INSTANCE = new DT_MultilingualNodeValue();

	private final DT_List<TextTypeWrapper, Object> ttwListDT;
	private final ObjectDataType objDT;

	public static DT_MultilingualNodeValue getInstance() {
		return INSTANCE;
	}

	private DT_MultilingualNodeValue() {
		this.objDT = new ObjectDataType();
		this.ttwListDT = new DT_List<>(objDT);
	}

	@Override
	public int getMemory(IMultilingualNodeValue obj) {
		int size = 1; // null/object selector

		if (obj != null) {
			size += ttwListDT.getMemory(obj.getTexts());
		}
		return size;
	}

	@Override
	public void write(WriteBuffer buff, IMultilingualNodeValue x) {
		buff.putVarInt((x == null) ? 0 : 1);

		if (x != null) {
			objDT.write(buff, x.getTexts());
		}

	}

	@Override
	public IMultilingualNodeValue read(ByteBuffer buf) {
		boolean isNull = (DataUtils.readVarInt(buf) == 0);
		IMultilingualNodeValue x = null;

		if (!isNull) {
			List<TextTypeWrapper> tt = ttwListDT.read(buf);
			x = new MultilingualNodeValue(tt);
		}
		return x;
	}

	@Override
	public IMultilingualNodeValue[] createStorage(int size) {
		return new IMultilingualNodeValue[size];
	}

}
