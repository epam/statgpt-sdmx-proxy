package io.sdmx.core.data.model.dataset.mvstore;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_Object;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;
import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;
import io.sdmx.core.sdmx.util.MVStoreUtil;

/**
 * This class represents a dataset collection stored in a MVStore file.
 */
public abstract class MVStoreAbstractDatasetStorage implements IDatasetStoreContainer {
	private static final Logger LOG = LoggerFactory.getLogger(MVStoreAbstractDatasetStorage.class);

	private static final String DUMP_LOGNAME = MVStoreAbstractDatasetStorage.class.getName() + ".DUMP";
	private static final Logger DUMP_LOG = LoggerFactory.getLogger(DUMP_LOGNAME);

	private static final Integer COLLINFO_header = 1;


	private final IMVStore store;
	private final MVStore db;

	private final List<MVStoreAbstractDataset> datasets;
	private MVStoreAbstractDataset currentDataset = null;

	private final DT_Object objectDT;

	private final Map<Integer, Object> collection_info;
	private boolean isProtected;


	protected MVStoreAbstractDatasetStorage(SdmxBeanRetrievalManager brm, File file) {
		store = MVStoreUtil.getStore(file);
		this.db = store.getStore();
		TreeSet<String> mapNames = new TreeSet<>(db.getMapNames());
		LOG.trace("Maps:");
		for (String mapName: mapNames)
			LOG.trace("  {}", mapName);

		// Add collection_info
		this.objectDT = new DT_Object(null); // FIXME
		this.collection_info = openCollectionInfo("collection_info");

		datasets = new ArrayList<>();

		int index = 0;
		for (String mapName: mapNames)
			if (mapName.matches("dataset_info_\\d{6}"))
				datasets.add(retrieveInstance(db, index, brm));
	}
	
	protected abstract MVStoreAbstractDataset retrieveInstance(MVStore store, int index, SdmxBeanRetrievalManager brm);
	

	/**
	 * Open a global map<Integer, Object> with the given identifier.
	 */
	private Map<Integer, Object> openCollectionInfo(String itemId) {
		MVMap.Builder<Integer, Object> builder = new MVMap.Builder<>();

		builder.valueType(objectDT);

		LOG.trace("Opening map {}", itemId);

		return db.openMap(itemId, builder);
	}

	@Override
	public int getDatasetSize() {
		return this.datasets.size();
	}

	@Override
	public void close(boolean removeResources) {
		if(!this.isProtected) {
			close();
			if(removeResources == true) {
				this.store.delete();
			}
		}
	}

	public void setHeader(HeaderBean header) {
		collection_info.put(COLLINFO_header, MVStoreUtil.nullOrObject(header));
	}

	@Override
	public HeaderBean getHeader() {
		return MVStoreUtil.nullOrCast(collection_info.get(COLLINFO_header));
	}


	public List<IDatasetStore> getDatasets() {
		return new ArrayList<>(datasets);
	}

	// Data writing interface

	/**
	 * Add a new dataset to the storage
	 */
	public void startDataset(IDatasetStructures structures,
			DatasetHeaderBean header,
			IDatasetAttributes attributes,
			AnnotationBean... annotations) {
		int index = datasets.size();
		List<AnnotationBean> annotationList =
				(annotations == null) ? null : Arrays.asList(annotations);

		currentDataset = MVStoreDataset.createInstance(db, index, structures);

		currentDataset.setHeader(header);
		currentDataset.writeDatasetAttributes(attributes);
		currentDataset.writeDatasetAnnotations(annotationList);

		this.datasets.add(currentDataset);
	}

	public void writeKey(Keyable key) {
		currentDataset.writeKey(key);
	}

	public void writeObs(Observation obs) {
		currentDataset.writeObs(obs);
	}

	// Data reading interface

	@Override
	public MVStoreAbstractDataset getDataset(int index) {
		return datasets.get(index);
	}

	public void commit() {
		for(MVStoreAbstractDataset ds : this.datasets) {
			ds.flush();
		}
		db.commit();
	}

	public void close() {
		db.close();
	}

	public IMVStore getStore() {
		return this.store;
	}
	
	public void setProtected(boolean protect) {
		this.isProtected = protect;
	}

	/**
	 *
	 */
	public void dump() {
		if (DUMP_LOG.isDebugEnabled()) {
			int dsCnt = datasets.size();

			DUMP_LOG.debug("----------------------------------------");
			DUMP_LOG.debug("--- Dataset Storage Dump ---");
			DUMP_LOG.debug("  Datasets:");

			for (int dsIx = 0; dsIx < dsCnt; dsIx++) {
				DUMP_LOG.debug("    Dataset {}:", dsIx);

				IDatasetStore ds = datasets.get(dsIx);

				//TDODO DUMP
				//ds.dump(DUMP_LOG);
			}

			DUMP_LOG.debug("----------------------------------------");
		}
	}
}
