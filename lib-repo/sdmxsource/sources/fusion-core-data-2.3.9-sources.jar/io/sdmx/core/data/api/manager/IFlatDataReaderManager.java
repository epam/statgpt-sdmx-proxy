package io.sdmx.core.data.api.manager;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;

/**
 * Obtains an {@link IFlatDataReaderEngine} to read the source data
 */
public interface IFlatDataReaderManager {
	
	/**
	 * @param sourceData the data to read
	 * @param retrievalManager used to obtain the structures required by the data reader
	 * @return {@link IFlatDataReaderEngine} to read the dataset 
	 * @throws SdmxNotImplementedException if ReadableDataLocation or DataStructureBean is null
	 */

	IFlatDataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData, IDatasetStructuresRetrievalManager retrievalManager) throws SdmxNotImplementedException;
}
