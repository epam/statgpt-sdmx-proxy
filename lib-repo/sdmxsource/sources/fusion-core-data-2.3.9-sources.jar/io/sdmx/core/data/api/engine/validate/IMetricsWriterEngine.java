package io.sdmx.core.data.api.engine.validate;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;

public interface IMetricsWriterEngine {

	/**
	 * Writes Metrics as
	 * <pre>
	 * {
	 * 	Meta: {
	 * 		RequestTime: 123456
	 * 		Duration: 12
	 *  }
	 *  SourceData : {
	 *    Dataflow: urn,
	 *    Series: 123
	 *    Observations: 124
	 *    Groups: 12
	 *  },
	 *  OutputData : {
	 *  	Dataflow: urn,
	 *  	Series: 12
	 *  	Observations: 10,
	 *  	Groups: 0
	 *  }
	 *  UnMappedData : {
	 *  	Datasets: [
	 *  		{
	 *  			Structure: urn,
	 *  			Series: 12
	 *  			Observations: 10,
	 *  			Groups: 0
	 *  		}
	 *  	]
	 *  }
	 *  </pre>
	 * 
	 * @param out stream to write to - this is not closed on completion
	 * @param startTime start time of the validation/transformation process
	 * @param endTime end time of the validation/transformation process
	 * @param mapping if any mapping was used
	 * @param dataInformation a map of JSON Key to the Dataset Information
	 */
	void writeMetrics(OutputStream out, ValidationTransformationMetrics transformationMetrics);
	
	/**
	 * Writes metrics as documented above, when there is already a JsonGenerator. The outere object is NOT written, only the inner properties
	 * starting with Meta
	 * @param jsonGenerator
	 * @param transformationMetrics
	 * @throws IOException
	 */
	void writeMetrics(JsonGenerator jsonGenerator, ValidationTransformationMetrics transformationMetrics) throws IOException;

	/**
	 * Writes a metrics report to the standard as specified by the BIS in MEDIT#262
	 * @param jsonGenerator
	 * @param transformationMetrics
	 * @param unmappedMappings
	 * @throws IOException
	 */
	void writeSpecificMetricsReport(JsonGenerator jsonGenerator, ValidationTransformationMetrics transformationMetrics, Map<IComponentMapping, List<String>> unmappedMappings) throws IOException;
}
