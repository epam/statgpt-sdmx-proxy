package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;

import org.h2.mvstore.WriteBuffer;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.KeyableImpl;

/**
 * Serialization for Keyable.
 */
public class DT_Keyable extends DT_Attributable<Keyable, Keyable> {
	private final DT_String strDT;
	private final DT_List<KeyValue, KeyValue> kvListDT;

	private final DataflowBean dfBean;
	private final DataStructureBean dsBean;

	public DT_Keyable(IDatasetStructures structures) {
		this.dfBean = structures.getDataflow();
		this.dsBean = structures.getDataStructure();

		final DT_KeyValue kvDT = DT_KeyValue.getInstance();

		this.strDT = DT_String.getInstance();
		this.kvListDT = new DT_List<>(kvDT);
	}

	@Override
	public int getMemory(Keyable key) {
		int size = 1; // null/string selector

		if (key != null) {
			size += 2; // keyablePosition
			size += strDT.getMemory(key.getGroupName());
			size += kvListDT.getMemory(key.getKey());
		}

		return size + super.getMemory(key);
	}

	@Override
	public void write(WriteBuffer buf, Keyable key) {
		super.write(buf, key);
		if (key != null) {
			strDT.write(buf, key.getGroupName());
			kvListDT.write(buf, key.getKey());
		}
	}

	@Override
	protected AttributableBuilder<Keyable> getBuilder(ByteBuffer byteBuffer) {
		String groupId = strDT.read(byteBuffer);
		List<KeyValue> key = kvListDT.read(byteBuffer);
		
		return KeyableImpl.builder(dsBean).
						   dataflow(dfBean).
						   key(key).
						   group(groupId);
	}
	
	@Override
	protected Keyable build(Keyable built) {
		return built;
	}

	@Override
	public Keyable[] createStorage(int size) {
		return new Keyable[size];
	}
}
