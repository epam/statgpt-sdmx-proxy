package io.sdmx.core.data.engine.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.ITimePeriodMapping;

/**
 * If there are multiple rules against 1 Dimension, use the rule which outputs something
 */
public class ProxyTimePeriodMapping implements ITimePeriodMapping {
	private List<ITimePeriodMapping> mappings = new ArrayList<>();

	public ProxyTimePeriodMapping(ITimePeriodMapping... inputMappings) {
		if(inputMappings != null) {
			for(ITimePeriodMapping mapping : inputMappings) {
				this.mappings.add(mapping);
			}
		}
	}

	public void addMapping(ITimePeriodMapping mapping) {
		this.mappings.add(mapping);
	}



	@Override
	public List<String> getSourceComponents() {
		for(ITimePeriodMapping currentMapping : this.mappings) {
			return currentMapping.getSourceComponents();
		}
		return Collections.emptyList();
	}

	@Override
	public List<String> getTargetComponents() {
		for(ITimePeriodMapping currentMapping : this.mappings) {
			return currentMapping.getTargetComponents();
		}
		return Collections.emptyList();
	}

	@Override
	public boolean outputRequired() {
		for(ITimePeriodMapping currentMapping : this.mappings) {
			if( currentMapping.outputRequired()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String performMapping(Map<String, String> values) {
		for(ITimePeriodMapping currentMapping : this.mappings) {
			String mapped = currentMapping.performMapping(values);
			if(mapped != null) {
				return mapped;
			}
		}
		return null;
	}

	@Override
	public IExplainMapComponent explain(Map<String, String> values) {
		for(ITimePeriodMapping currentMapping : this.mappings) {
			String mapped = currentMapping.performMapping(values);
			if(mapped != null) {
				return currentMapping.explain(values);
			}
		}
		return null;
	}

	@Override
	public String getId() {
		// Return the first ID
		for(ITimePeriodMapping currentMapping : this.mappings) {
			return currentMapping.getId();
		}
		return null;
	}
}
