package io.sdmx.core.data.engine.writer.schema;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.container.SdmxBeansSorted;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;
import io.sdmx.utils.sdmx.structure.AgencyUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class StructureSchemaWriterEngine implements SchemaWriterEngine {
	private StructureWriterManager swm;
	private StructureFormat outputFormat;
	private SdmxBeanRetrievalManager retrievalManager;
	
	public StructureSchemaWriterEngine(StructureWriterManager swm, StructureFormat outputFormat, SdmxBeanRetrievalManager retrievalManager) {
		this.swm = swm;
		this.outputFormat = outputFormat;
		this.retrievalManager = retrievalManager;
	}

	@Override
	public void writeSchema(ConstrainedCodes validCodes, String dimensionAtObservation, boolean prettyPrint, OutputStream out) {
		SdmxBeans beans = new SdmxBeansImpl();
		
		Set<String> writtenLinks = new HashSet<>();
		addLink(beans, writtenLinks, validCodes.getDatasetStructures().getProvisionAgreement());
		addLink(beans, writtenLinks, validCodes.getDatasetStructures().getDataflow());
		addLink(beans, writtenLinks, validCodes.getDatasetStructures().getDataStructure());
		addLink(beans, writtenLinks, validCodes.getDatasetStructures().getDataProvider());
		
		//ensure the URNs are output in a consistent order for reliable tests
		Set<ContentConstraintBean> sortedConstraints = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
		sortedConstraints.addAll(validCodes.getConstraintsUsed());
		for(ContentConstraintBean cc : sortedConstraints) {
			addLink(beans, writtenLinks, cc);
		}

		//Add high level info to beans container (DSD, Flow, Provision)
		beans.addIdentifiable(validCodes.getDsd().getBuiltFrom());

		//Maps
		Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> componentId2Enumeration = new HashMap<>();
		Map<ConceptSchemeBean, Set<String>> validConcepts = new HashMap<>();
		Map<EnumeratedListBean<? extends EnumeratedItemBean>, Set<String>> validCodeIds = new HashMap<>();
		
		Map<EnumeratedListBean<? extends EnumeratedItemBean>, Set<String>> enumList2Comps = new HashMap<>();  //2 components that share the same codelist

		//Build Maps
		for(ComponentSuperBean<ComponentBean> compSb : validCodes.getDsd().getComponents()) {
			ConceptBean concept = compSb.getConcept().getBuiltFrom();
			CollectionUtil.addToMappedSet(validConcepts, concept.getMaintainableParent(), concept.getId());

			EnumeratedListBean<? extends EnumeratedItemBean> enumeration = compSb.getCodelist(true);
			if(enumeration != null) {
				componentId2Enumeration.put(compSb.getId(), enumeration);
				CollectionUtil.addToMappedSet(enumList2Comps, enumeration, compSb.getId());
			}
		}

		//Partial Concept Schemes
		for(ConceptSchemeBean cs : validConcepts.keySet()) {
			cs = cs.filterItems(validConcepts.get(cs), true);
			beans.addIdentifiable(cs);
		}

		//Partial Codelists
		Map<String, Set<String>> validCodeIdsByComponentId = validCodes.getValidCodes();
		for(String compId : componentId2Enumeration.keySet()) {
			EnumeratedListBean<? extends EnumeratedItemBean> enumeration = componentId2Enumeration.get(compId);
			if(enumeration != null) {
				Set<String> existingValid = validCodeIdsByComponentId.get(compId);
				if(existingValid != null) {
					CollectionUtil.addToMappedSet(validCodeIds, enumeration, existingValid);
				} else {
					validCodeIds.put(enumeration, enumeration.getItems().stream().map(e->e.getId()).collect(Collectors.toSet()));
				}
			}
		}
		//Add to Container
		for(EnumeratedListBean<? extends EnumeratedItemBean> enumeration : validCodeIds.keySet()) {
			enumeration = enumeration.filterItems(validCodeIds.get(enumeration), true);
			beans.addIdentifiable(enumeration);
		}
		
		//Partial Agency Schemes
		Map<String, Set<String>> agencyIdMap = new HashMap<>();
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			String[] agencySplit = AgencyUtil.splitAgencyId(maint.getAgencyId());
			CollectionUtil.addToMappedSet(agencyIdMap, agencySplit[0], agencySplit[1]);
		}
		for(String agencySchemeAgencyId : agencyIdMap.keySet()) {
			AgencySchemeBean acySch = retrievalManager.getBean(URN.builder().agencyId(agencySchemeAgencyId).buildSingle(AgencySchemeBean.class));
			if(acySch != null) {
				beans.addIdentifiable(acySch.filterItems(agencyIdMap.get(agencySchemeAgencyId), true));
			}
		}
		
		//Constraints
		ContentConstraintMutableBean constraint = null;
		for(EnumeratedListBean<? extends EnumeratedItemBean> enumeration : enumList2Comps.keySet()) {
			Set<String> compIds = enumList2Comps.get(enumeration);
			if(compIds.size() > 1) {
				Set<String> fullCodelist = validCodeIds.get(enumeration);
				for(String compId : compIds) {
					Set<String> validCompCodes = validCodes.getValidCodes().get(compId);
					if(!validCompCodes.containsAll(fullCodelist)) {
						if(constraint == null) {
							constraint = new ContentConstraintMutableBeanImpl();
							constraint.setAgencyId(validCodes.getDsd().getAgencyId());
							ConstraintAttachmentMutableBean constraintAttachment = new ContentConstraintAttachmentMutableBeanImpl();
							constraintAttachment.addStructureReference(validCodes.getConstrainable().asReference());
							constraint.setConstraintAttachment(constraintAttachment);
							constraint.setId(validCodes.getDsd().getId());
							constraint.setVersion("1.0");
							constraint.addName("en", "Restrictions for Components");
							CubeRegionMutableBean cr = new CubeRegionMutableBeanImpl();
							constraint.setIncludedCubeRegion(cr);
						}
						KeyValuesMutable kvs = new KeyValuesMutableImpl();
						kvs.setId(compId);
						kvs.setKeyValues(new ArrayList<>(validCompCodes));
						constraint.getIncludedCubeRegion().addKeyValues(kvs);
					}
				}
			}
		}
		if(constraint != null) {
			beans.addIdentifiable(constraint.getImmutableInstance());
		}
		for(ContentConstraintBean c : validCodes.getConstraintsUsed()) {
		    if(!c.isCubeRegion()) {
		        beans.addIdentifiable(c);
		    }
		}
		
		beans = SdmxBeansSorted.getInstance(beans);
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			addLink(beans, writtenLinks, maint);
		}
		swm.writeStructures(beans, outputFormat, out);
	}
	
	private void addLink(SdmxBeans beans, Set<String> allLinks, IdentifiableBean identifiable) {
		if(identifiable != null) {
			if(allLinks.add(identifiable.getUrn())) {
				beans.addLink(LinkBean.urnLink(identifiable));
			}
		}
	}
}
