package io.sdmx.core.data.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.sdmx.empty.EmptyAttributable;
import io.sdmx.core.sdmx.engine.data.RolldownDataWriterEngine;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.data.KeyableProxy;
import io.sdmx.im.data.ObservationProxy;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Copies data from a reader to a writer
 */
public class DataTransformationUtil {
    private static final Logger LOG = LoggerFactory.getLogger(DataTransformationUtil.class);


    public static void copyData(DataReaderEngine reader, ISeriesObsDataWriterEngine writer,  boolean copyHeader, boolean closeWriter) {
        copyData(reader, writer, DataTransformOptions.getInstance().setCopyHeader(copyHeader).setCloseWriter(closeWriter));
    }

    public static void copyData(DataReaderEngine reader, DataWriterEngine writer,  DataTransformOptions options) {
        copyData(reader, new RolldownDataWriterEngine(writer), options);
    }

    public static void copyData(DataReaderEngine reader, ISeriesObsDataWriterEngine writer,  DataTransformOptions options) {
        LOG.debug("copy dataset to writer");
        if(options.isResetReader()) {
            LOG.debug("reset data reader");
            reader.reset();
        }
        if(options.isCopyHeader()) {
            if(reader.getHeader() != null) {
                LOG.debug("copy dataset header");
                writer.writeHeader(reader.getHeader());
            }
        }

        DatasetStructures lastStructures = null;
        int dsIdx = 0;
        while(reader.moveNextDataset()) {
            dsIdx++;
            if(options.getDatasetLimit() > 0 && dsIdx > options.getDatasetLimit()) {
                break;
            }
            DatasetHeaderBean newDatasetHeaderBean = reader.getCurrentDatasetHeaderBean();
            DatasetStructures structures = new DatasetStructures(reader.getDataStructure(), reader.getDataFlow(), reader.getProvisionAgreement(), null);
            if(lastStructures == null || !options.isMergeDataset() || !lastStructures.equals(structures)) {
                LOG.debug("start dataset {} ", structures);
                writer.startDataset(structures, newDatasetHeaderBean, reader.getDatasetAttributes());
                lastStructures = structures;
            }
            LOG.debug("copy dataset {} ", dsIdx);
            copyDataSet(reader, writer, false, options);
        }
        if(options.isCloseWriter()) {
            LOG.debug("close data writer");
            writer.close();
        }
        LOG.debug("copy dataset complete");
    }

    /**
     * Copies the information in the current dataset to the output - this only copies one dataset, and expects the reader
     * to already have been advanced to the dataset to copy
     * @param reader
     * @param writer
     * @param options
     */
    public static void copyDataSet(DataReaderEngine reader, ISeriesObsDataWriterEngine writer, boolean startDataset, DataTransformOptions options) {
        if(options == null) {
            options = DataTransformOptions.getInstance();
        }
        if(startDataset) {
            DatasetHeaderBean newDatasetHeaderBean = reader.getCurrentDatasetHeaderBean();
            DatasetStructures structures = new DatasetStructures(reader.getDataStructure(), reader.getDataFlow(), reader.getProvisionAgreement(), null);
            LOG.debug("start dataset {}", structures.toString());
            writer.startDataset(structures, newDatasetHeaderBean, reader.getDatasetAttributes());
        }

        while(reader.moveNextKeyable()) {
            Keyable key = reader.getCurrentKey();
            if(!options.isIncludeAttributes()) {
                key = new KeyableProxy(key, EmptyAttributable.INSTANCE);
            }
            if(LOG.isDebugEnabled()) {
                LOG.debug("write key {}", key.toString());
            }
            writer.writeKey(key);
            if(options.isIncludeObs()) {
                while(reader.moveNextObservation()) {
                    Observation obs = reader.getCurrentObservation();
                    if(!options.isIncludeAttributes()) {
                        obs = new ObservationProxy(obs, EmptyAttributable.INSTANCE, key);
                    }
                    if(LOG.isDebugEnabled()) {
                        LOG.debug("write obs {}", obs.toString());
                    }
                    writer.writeObservation(obs);
                }
            }
        }
    }

    public static void copyData(IFlatDataReaderEngine reader, IFlatDataWriterEngine writer,  boolean copyHeader, boolean closeWriter) {
        reader.reset();
        if(copyHeader) {
            writer.writeHeader(reader.readHeader());
        }

        boolean startedDataset = false;
        while(reader.moveNextRow()) {
            IDataRow row = reader.getCurrentRow();
            if(!startedDataset) {
                writer.startDataset(reader.readDatasetHeader());
                startedDataset = true;
            }
            writer.writeRow(row);
        }
        if(closeWriter) {
            writer.close();
        }
    }

    /**
     * Copies Series/Obs data to a flat writer
     * @param reader
     * @param writer
     * @param copyHeader
     * @param closeWriter
     */
    public static void copyData(DataReaderEngine reader, IFlatDataWriterEngine writer,  boolean copyHeader, boolean closeWriter, boolean mergeDatasets) {
        reader.reset();
        if(copyHeader) {
            writer.writeHeader(reader.getHeader());
        }
        Map<String, String> lastDatasetAttributes = null;
        DatasetHeaderBean lastDatasetHeaderBean = null;
        IDatasetStructures structures = null;

        while(reader.moveNextDataset()) {
            DatasetHeaderBean newDatasetHeaderBean = reader.getCurrentDatasetHeaderBean();
            Map<String, String> dsAttributes = CollectionUtil.keyValuesToFlatMap(reader.getDatasetAttributes().getAttributes());
            if(mergeDatasets == false  || !ObjectUtil.equivalentMap(lastDatasetAttributes, dsAttributes) || DataHeaderUtil.isHeaderEqual(lastDatasetHeaderBean, newDatasetHeaderBean)) {
                writer.startDataset(newDatasetHeaderBean);
                lastDatasetHeaderBean = newDatasetHeaderBean;
                structures = new DatasetStructures(reader.getDataStructure(), reader.getDataFlow(), reader.getProvisionAgreement(), null);
            }

            // Records where a row was ever written for this Dataset
            boolean wasRowEverWrittern = false;
            while(reader.moveNextKeyable()) {
                Keyable series = reader.getCurrentKey();
                Map<String, String> seriesData = CollectionUtil.keyValuesToFlatMap(series.getKey());
                seriesData.putAll(CollectionUtil.keyValuesToFlatMap(series.getAttributes()));
                seriesData.putAll(dsAttributes);
                boolean hasObs = false;
                while(reader.moveNextObservation()) {
                    hasObs = true;
                    Observation obs = reader.getCurrentObservation();
                    Map<String, String> rowData = new HashMap<>(seriesData);
                    rowData.putAll(CollectionUtil.keyValuesToFlatMap(obs.getAttributes()));
                    if(obs.getDimensionId() != null) {
                        rowData.put(obs.getDimensionId(), obs.getDimensionValue());
                    }
                    Map<String, Set<String>> multivalueMeasures = new HashMap<>();
                    for(KeyValue measure : obs.getMeasures()){
                        if (measure.hasMultipleValues()) {
                            multivalueMeasures.put(measure.getCode(), new HashSet<>(measure.getValues()));
                        }else{
                            rowData.put(measure.getCode(), measure.getConcept());
                        }

                    }
                    flushRow(rowData, multivalueMeasures, structures, writer);
                    wasRowEverWrittern = true;
                }
                if(!hasObs) {
                    flushRow(seriesData, null, structures, writer);
                    wasRowEverWrittern = true;
                }
            }

            if (!wasRowEverWrittern && dsAttributes.size() > 0) {
                // No rows were ever written but there are Dataset Attributes, so write these out
                flushRow(dsAttributes, null, structures, writer);
            }

        }
        if(closeWriter) {
            writer.close();
        }
    }

    private static void flushRow(Map<String, String> rowData, Map<String, ? extends Collection<String>> multiValueRow, IDatasetStructures structures, IFlatDataWriterEngine writer) {
        writer.writeRow(new DataRow(structures, rowData, multiValueRow, null, null));
    }

}
