package io.sdmx.core.data.comparator;

import java.util.Comparator;

import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.utils.core.comparator.StringListComparator;

public class ComponentMappingComparator implements Comparator<IComponentMapping> {
	public static final ComponentMappingComparator INSTANCE = new ComponentMappingComparator();
	
	private ComponentMappingComparator() { }

	@Override
	public int compare(IComponentMapping a, IComponentMapping b) {
		int sourceCompare = StringListComparator.INSTANCE.compare(a.getSourceComponents(), b.getSourceComponents());
		if(sourceCompare != 0) {
			return sourceCompare;
		}
		return StringListComparator.INSTANCE.compare(a.getTargetComponents(), b.getTargetComponents());
	}
	
}
