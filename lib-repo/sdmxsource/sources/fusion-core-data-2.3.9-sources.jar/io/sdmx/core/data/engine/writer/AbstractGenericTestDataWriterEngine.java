package io.sdmx.core.data.engine.writer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.im.util.model.TestDSDUtil;
import io.sdmx.im.util.model.testinstances.TestDSDInstances;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * A generic class for writing datasets, to be subclassesed by unit tests classes for testing the capability of data writers
 *
 * DSD Component Values;
 * FREQ:      A, S, T, Q, M, W, D, H, I
 * REF_AREA:  EUR, EUR.UK, EUR.FR, EUR.DE, EUR.ES, ASIA, ASIA.TH  									(hierarchcial)
 * INDICATOR: P1_IND_0, P2_IND_1, P3_IND_2, P1_IND_4, P2_IND_5....and so on							(100 codes, P[1-3]_IND_[0-33]
 * COMPANY:   GOO=Google, QUO=Quora, Inc., IBM=IBM, MANN=Mann and Son's, JAJ=Johnson & Johnson		(code names with special characters)
 *
 * 
 * All Other Coded Dimensions
 * AA, AB, AC, AD, AE, AF, AG, AH, AI
 * 
 * 
 * 
 * @param dsd
 * @param beans
 * @param includeDSD
 */
public abstract class AbstractGenericTestDataWriterEngine {

	/**
	 * Interface allowing arrow function
	 */
	protected interface TestMethodRunner {
		
		SdmxBeans runTestMethod(IFlatDataWriterEngine dwe, SdmxBeans beans);

	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeSeriesKeysOnlyCoded(IFlatDataWriterEngine dwe, SdmxBeans container) {
		return writeSeriesKeysOnlyCoded(dwe, "A", container);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeSeriesKeysOnlyCoded(IFlatDataWriterEngine dwe, String frequencyId, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0:GOO"));
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0:QUO"));
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0:MANN"));
		dwe.close();
		return container;
	}
	
	/**
	 * Creates coded and non coded series attributes
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeSeriesWithAttributesNoObs(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		dsd = TestDSDUtil.createAttribute(dsd, "TITLE:STRING", ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
		dsd = TestDSDUtil.createAttribute(dsd, "UPDATED:STRING", ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TITLE a series title", "UPDATED 1990-01-01T13:46.11Z")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("TITLE a series title")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:MANN").modifyValues(CollectionUtil.buildMapValues("UPDATED 1991-01-01T13:46.11Z")));
		dwe.close();
		return container;
		
	}

	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeTimeSeriesDataNoAttributes(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 12.3")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 12.4")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 12.5")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 22.1")));
		dwe.writeRow(new DataRow(structures, "M:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008-01-01", "OBS_VALUE 1.2")));
		dwe.writeRow(new DataRow(structures, "A:UK:P3_IND_1:MAN").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 12.31")));
		dwe.writeRow(new DataRow(structures, "A:FR:P3_IND_2:MAN").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 12.41")));
		dwe.writeRow(new DataRow(structures, "A:DE:P3_IND_3:MAN").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 12.51")));
		dwe.writeRow(new DataRow(structures, "A:ES:P3_IND_4:IBM").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 12.61")));
		dwe.writeRow(new DataRow(structures, "A:CH:P3_IND_5:IBM").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 12.71")));
		dwe.close();
		return container;
	}
	
	
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeTimeSeriesDatasetAttributes(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		dsd = TestDSDUtil.createAttribute(dsd, "CONTACT", ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("CONTACT MN", "TIME_PERIOD 2008", "OBS_VALUE 12.3")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("CONTACT MN","TIME_PERIOD 2009", "OBS_VALUE 12.4")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("CONTACT MN","TIME_PERIOD 2010", "OBS_VALUE 12.5")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("CONTACT MN","TIME_PERIOD 2008", "OBS_VALUE 22.1")));
		dwe.writeRow(new DataRow(structures, "M:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("CONTACT MN","TIME_PERIOD 2008-01-01", "OBS_VALUE 1.2")));
		dwe.close();
		return container;
	}
	
	/**
	 * Writes data where the last dimension is a valuelist
	 * 
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeTimeSeriesWithValueListDimension(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "SYMBOL:VL");
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:ASIA:$").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 12.4")));
		dwe.writeRow(new DataRow(structures, "A:CH:$").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 12.5")));
		dwe.writeRow(new DataRow(structures, "A:FR:&").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 22.1")));
		dwe.writeRow(new DataRow(structures, "A:DE:%").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2011", "OBS_VALUE 1.2")));
		dwe.close();
		return container;
	}
	
	/**
	 * Writes data where one of the dimensions contains a comma
	 * 
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeTimeSeriesWithUncodedDimensionContainingComma(IFlatDataWriterEngine dwe, String frequencyId, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:");
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2000", "OBS_VALUE 1.1")));
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2001", "OBS_VALUE 2.2")));
		dwe.writeRow(new DataRow(structures, frequencyId+":EUR:P1_IND_0,FOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2000", "OBS_VALUE 3.3")));
		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeMultipleMeasuresTimeSeries(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, false, "FREQ:CL", "REF_AREA:CL");
		dsd = TestDSDUtil.createMeasure(dsd, "BIRTHS");
		dsd = TestDSDUtil.createMeasure(dsd, "DEATHS");
		dsd = TestDSDUtil.createMeasure(dsd, "MARRIAGES");
		
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "BIRTHS 10", "DEATHS 20", "MARRIAGES 30")));
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "BIRTHS 10.1", "DEATHS 20.1", "MARRIAGES 30.1")));
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2012", "BIRTHS 10.2", "DEATHS 20.2", "MARRIAGES 30.2")));
		dwe.writeRow(new DataRow(structures, "A:CH").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "BIRTHS 11", "DEATHS 21", "MARRIAGES 31")));;
		dwe.writeRow(new DataRow(structures, "A:CH").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2019", "BIRTHS 11.1", "DEATHS 21.1", "MARRIAGES 31.1")));;
		dwe.writeRow(new DataRow(structures, "A:FR").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "BIRTHS 12", "DEATHS 22", "MARRIAGES 32")));
		dwe.writeRow(new DataRow(structures, "A:FR").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "BIRTHS 12.1", "DEATHS 22.1", "MARRIAGES 32.1")));
		dwe.close();
		return container;
	}
	
	/**
	 * The times are reported in an attribute, not a TIME_PERIOD column
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeMultipleMeasuresNoTime(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(false, false, "FREQ:CL", "REF_AREA:CL");
		dsd = TestDSDUtil.createMeasure(dsd, "BIRTHS");
		dsd = TestDSDUtil.createMeasure(dsd, "DEATHS");
		dsd = TestDSDUtil.createMeasure(dsd, "MARRIAGES");
		dsd = TestDSDUtil.createAttribute(dsd, "DOB", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
		dsd = TestDSDUtil.createAttribute(dsd, "REPORTED_DATE", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
			
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("DOB 2009-01-01T11:22:12Z", "REPORTED_DATE 2009", "BIRTHS 10", "DEATHS 20", "MARRIAGES 30")));
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2010", "BIRTHS 10.1", "DEATHS 20.1", "MARRIAGES 30.1")));
		dwe.writeRow(new DataRow(structures, "A:ASIA").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2012", "BIRTHS 10.2", "DEATHS 20.2", "MARRIAGES 30.2")));
		dwe.writeRow(new DataRow(structures, "A:CH").modifyValues(CollectionUtil.buildMapValues("DOB 2009-01-01T12:23:12Z",  "REPORTED_DATE 2009", "BIRTHS 11", "DEATHS 21", "MARRIAGES 31")));;
		dwe.writeRow(new DataRow(structures, "A:CH").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2019", "BIRTHS 11.1", "DEATHS 21.1", "MARRIAGES 31.1")));;
		dwe.writeRow(new DataRow(structures, "A:FR").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2009", "BIRTHS 12", "DEATHS 22", "MARRIAGES 32")));
		dwe.writeRow(new DataRow(structures, "A:FR").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2008", "BIRTHS 12.1", "DEATHS 22.1", "MARRIAGES 32.1")));
		dwe.close();
		return container;
	}
	
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeNoMeasures(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(false, false, "FREQ:CL", "REF_AREA:CL");
		dsd = TestDSDUtil.createAttribute(dsd, "REPORTED_DATE", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
			
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:ASIA"));
		dwe.writeRow(new DataRow(structures, "M:ASIA").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2010")));
		dwe.writeRow(new DataRow(structures, "D:ASIA").modifyValues(CollectionUtil.buildMapValues("REPORTED_DATE 2012")));
		dwe.writeRow(new DataRow(structures, "A:CH"));
		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeMultivalueAttribute(IFlatDataWriterEngine dwe, SdmxBeans container, boolean codedAttribute) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(false, false, "FREQ:CL", "REF_AREA:CL");
		String attId = "DATA_PROVIDER";
		if(codedAttribute) {
			attId = attId + ":CL";
		}
		DataStructureMutableBean mutable = dsd.getMutableInstance();
		TestDSDUtil.createAttribute(mutable, attId, ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION).setMaxOccurs(3);
		dsd = mutable.getImmutableInstance();
		
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		Map<String, String> row = CollectionUtil.buildMapValues("FREQ A", "REF_AREA UK");
		Map<String, List<String>> multiValueRow = new HashMap<>();
		CollectionUtil.addToMappedList(multiValueRow, "DATA_PROVIDER", "ONS");
		CollectionUtil.addToMappedList(multiValueRow, "DATA_PROVIDER", "BOE");
				
		dwe.writeRow(new DataRow(structures, row, multiValueRow, null, null));
		
		row = CollectionUtil.buildMapValues("FREQ A", "REF_AREA FR");
		multiValueRow = new HashMap<>();
		CollectionUtil.addToMappedList(multiValueRow, "DATA_PROVIDER", "INSEE");
		dwe.writeRow(new DataRow(structures, row, multiValueRow, null, null));
		
		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeMultilingualAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDInstances.getDSDWithComplexContent();
		TextFormatMutableBean multilingualString = new TextFormatMutableBeanImpl();
		multilingualString.setMultiLingual(TERTIARY_BOOL.TRUE);

		String attId = "TITLE";
		DataStructureMutableBean mutable = dsd.getMutableInstance();
		TestDSDUtil.createAttribute(mutable, attId, ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION).setMaxOccurs(3).setTextFormat(multilingualString);
		dsd = mutable.getImmutableInstance();
		container = startDataset(dsd, container, dwe);

		IDatasetStructures structures = new DatasetStructures(dsd);
		Map<String, String> row = CollectionUtil.buildMapValues("FREQ A", "REF_AREA UK");
		Map<String, List<String>> multilingualRow = new HashMap<>();
		CollectionUtil.addToMappedList(multilingualRow, "TITLE", "en: Some english text;fr:Quelques textes en anglais");

		dwe.writeRow(new DataRow(structures, row, null, multilingualRow, null));

		row = CollectionUtil.buildMapValues("FREQ A", "REF_AREA FR");
		multilingualRow = new HashMap<>();
		CollectionUtil.addToMappedList(multilingualRow, "TITLE", "de: Ein englischer Text");
		dwe.writeRow(new DataRow(structures, row, null, multilingualRow, null));

		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeHTMLAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeDatasetAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeSeriesAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeGroupAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeTimeSeriesObsAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		dsd = TestDSDUtil.createAttribute(dsd, "UNIT:CL", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
		dsd = TestDSDUtil.createAttribute(dsd, "OBS_CONF", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("UNIT AA", "OBS_CONF A",  "TIME_PERIOD 2008", "OBS_VALUE 12.3")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("OBS_CONF A", "TIME_PERIOD 2009", "OBS_VALUE 12.4")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 12.5")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 22.1")));
		dwe.writeRow(new DataRow(structures, "M:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("UNIT AB", "OBS_CONF -", "TIME_PERIOD 2008-01-01", "OBS_VALUE 1.2")));
		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writePartialKeyAttribute(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		dsd = TestDSDUtil.createAttribute(dsd, "FOOTNOTES", ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
		container = startDataset(dsd, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd);

		dwe.writeRow(new DataRow(structures, ":EUR::GOO").modifyValues(CollectionUtil.buildMapValues("FOOTNOTES c'est la vie")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("UNIT AA", "OBS_CONF A",  "TIME_PERIOD 2008", "OBS_VALUE 12.3")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("OBS_CONF A", "TIME_PERIOD 2009", "OBS_VALUE 12.4")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 12.5")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 22.1")));
		dwe.writeRow(new DataRow(structures, ":EUR::QUO").modifyValues(CollectionUtil.buildMapValues("FOOTNOTES Table 1A, a table we can all relate to")));
		dwe.writeRow(new DataRow(structures, "M:EUR:P1_IND_0:QUO").modifyValues(CollectionUtil.buildMapValues("UNIT AB", "OBS_CONF -", "TIME_PERIOD 2008-01-01", "OBS_VALUE 1.2")));
		dwe.close();
		return container;
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeDatasetLevel(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributePartialKeyLevel(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeObsLevel(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeSimple(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeHierarchy(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeHierarchyCardinality(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected void writeMSDAttributeHierarchyCardinalityComplexContent(IFlatDataWriterEngine dwe, SdmxBeans container) {
		TestDSDInstances.generateMixedBag(false, false);
	}
	
	/**
	 * @param dwe to write the data to
	 * @param container to add the DSD and related structures to that are being written
	 */
	protected SdmxBeans writeMultipleDatasets(IFlatDataWriterEngine dwe, SdmxBeans container) {
		DataStructureBean dsd1 = TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL", "COMPANY:CL");
		DataStructureBean dsd2 = (DataStructureBean)TestDSDUtil.generateDSD(true, true, "FREQ:CL", "REF_AREA:CL", "INDICATOR:CL").getMutableInstance().setAgencyId("ACY2").getImmutableInstance();

		container = startDataset(dsd1, container, dwe);
		
		IDatasetStructures structures = new DatasetStructures(dsd1);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 8")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 9")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 10")));
		dwe.writeRow(new DataRow(structures, "M:EUR:P1_IND_0:GOO").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010-01", "OBS_VALUE 10")));
		
		container.merge(startDataset(dsd2, null, dwe));
		
		structures = new DatasetStructures(dsd2);
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_1").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2008", "OBS_VALUE 8")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_1").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2009", "OBS_VALUE 9")));
		dwe.writeRow(new DataRow(structures, "A:EUR:P1_IND_1").modifyValues(CollectionUtil.buildMapValues("TIME_PERIOD 2010", "OBS_VALUE 10")));

		dwe.close();
		return container;
	}
	
	protected SdmxBeans startDataset(DataStructureBean dsd, SdmxBeans container, IFlatDataWriterEngine dwe) {
		if(container == null) {
			container = new SdmxBeansImpl();
		}
		TestDSDInstances.generateReferences(dsd, container, true);
		DatasetHeaderBean header = new DatasetHeaderBeanImpl("DSID", DATASET_ACTION.APPEND, new DatasetStructureReferenceBeanImpl(dsd.getURN()));
		dwe.startDataset(header);
		return container;
	}
}
