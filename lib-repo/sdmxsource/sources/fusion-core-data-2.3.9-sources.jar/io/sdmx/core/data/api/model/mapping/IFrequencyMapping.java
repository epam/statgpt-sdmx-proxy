package io.sdmx.core.data.api.model.mapping;

import java.util.List;

/**
 * Specific mapping rules for FREQ Dimension
 */
public interface IFrequencyMapping {

	/**
	 * @return an immutable list of input components required to perform the mapping
	 */
	List<String> getInputComponents();
	
	/**
	 * Performs the mapping and returns the output frequency
	 * @param inputValues example A
	 * @return output frequency
	 */
	String performMapping(String...inputValues);
}
