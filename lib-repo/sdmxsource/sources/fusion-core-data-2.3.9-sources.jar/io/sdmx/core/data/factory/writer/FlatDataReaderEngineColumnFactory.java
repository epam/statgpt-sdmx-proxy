package io.sdmx.core.data.factory.writer;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.engine.reader.FlatDataReaderEngineColumn;
import io.sdmx.core.data.model.format.FlatDataFormatCSV;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.factory.data.IFlatDataReaderFactory;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.utils.core.csv.CSVColumnReaderEngineImpl;

public class FlatDataReaderEngineColumnFactory implements IFlatDataReaderFactory {
    private HeaderRetrievalManager headerRetrievalManager;


    public FlatDataReaderEngineColumnFactory(HeaderRetrievalManager headerRetrievalManager) {
        this.headerRetrievalManager = headerRetrievalManager;
    }

    @Override
    public IFlatDataReaderEngine getDataReaderEngine(DataFormat format, ReadableDataLocation sourceData, 
                                                     IDatasetStructuresRetrievalManager retrievalManager) {
    	//If the format is passed in and not a supported format, return null
        if (format != null &&  !(format instanceof FlatDataFormatCSV)) {
            return null;
        }

        DELIMITER delimiter = null;
        IDatasetStructures structures = null;
        int startRow = 0;
        if(sourceData instanceof CSVDataReadableDataLocation) {
            CSVDataReadableDataLocation csvRdl = (CSVDataReadableDataLocation)sourceData;
            delimiter = csvRdl.getDelimiter();
            structures = csvRdl.getStructures();
            startRow = csvRdl.getStartRow();
        } else
        if(format instanceof FlatDataFormatCSV) {
            FlatDataFormatCSV csvFormat = (FlatDataFormatCSV)format;
            delimiter = csvFormat.getDelimiter();
            structures = retrievalManager == null ? structures : retrievalManager.getDatasetStructures(null);
        }
        if(sourceData.getFormat() == FILE_FORMAT.CSV) {
            //Assume delimiter comma, and structures from retrieval manager;
            delimiter = DELIMITER.COMMA;
            try {
                structures = retrievalManager == null ? structures :retrievalManager.getDatasetStructures(null);  //Check if structures is 'fixed' in the retrieval manager
            } catch(Throwable th) {}
            if(structures == null) {
                return null;
            }
        }
        if(delimiter != null) {
            if(structures == null) {
                try {
                    structures = retrievalManager == null ? null : retrievalManager.getDatasetStructures(null);  //Check if structures is 'fixed' in the retrieval manager
                } catch(Throwable th) {}

                throw new SdmxSemmanticException("CSV Data requires reference to the structures used to read the data");
            }
            ColumnReaderEngine colReader = new CSVColumnReaderEngineImpl(sourceData, delimiter, null, startRow);
            return new FlatDataReaderEngineColumn(colReader, structures, headerRetrievalManager);
        }
        return null;
    }
}
