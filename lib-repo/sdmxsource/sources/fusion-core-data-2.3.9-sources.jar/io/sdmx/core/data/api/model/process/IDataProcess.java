package io.sdmx.core.data.api.model.process;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;

/**
 * A container for one or more defined processes to apply to a dataset
 */
public interface IDataProcess {
	
	/**
	 * @return optional reference to a structure with which to read the data
	 */
	IURNSingle<? extends IDSDRelatedBean> getStructure();
	
	/**
	 * @return immutable list of process steps, not null
	 */
	List<IProcessStep> getProcessSteps();
	
}
