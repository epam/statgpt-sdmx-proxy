package io.sdmx.core.data.engine.validate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.SdmxInternalServerException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CalculationErrorHandler;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleHierarchyBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.data.calculation.ValidationExpression;
import io.sdmx.api.sdmx.model.error.ICaculationError;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.model.calcuation.CustomValidationExpression;
import io.sdmx.core.data.model.calcuation.HierarchicalValidationExpression;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;

/**
*
* DimensionExpression contains one or more ValidationExpression  (e.g REF_AREA = 5 Validation Expressions)
* Each ValidationExpression is built on construction, and is built from a ValidationRule from the ValidationSchemeBean
* <p/>
* Each time a new series is reported, each validation expression is checked to see if the series is reporting
* a dimension value which is either an input or output to the expression.  For example the expression:

* <b><u>Sex</u></b>
* <p>T = M + F</p>

* The series A:UK:T would be an input to this expression and A:UK:M would be an output.
* <p/>
* The expression is then fed observation values for inputs and outputs against a short code, which is the series key, minus the dimension that is being calculated,
* plus the observation time. For example:
* addOutput("A:UK::2008", 10)  - the value of 10 against short code A:UK  for time period 2008
* addInput("A:UK::2008", 0, 7) - the value of 7 reported against short code A:UK for time period 2008 for index 0 of the expression (M)
* addInput("A:UK::2008", 1, 3) - the value of 7 reported against short code A:UK for time period 2008 for index 0 of the expression (F)
* <p/>
* When the full dataset has been read, each expression may contain multiple inputs and outputs for different series.
* Each expression is run to determine if the output matches the expected output as described by the calculation
*
*/
public class ValidationSchemeDataValidationEngine implements DataValidationEngine {
	private static final Logger LOG = LoggerFactory.getLogger(ValidationSchemeDataValidationEngine.class);

	private Map<String, Set<ValidationExpression>> dimensionExpresssions = new HashMap<>();
	private Set<ValidationExpressionMatch> validationExpressions = new HashSet<>();

	public ValidationSchemeDataValidationEngine(Set<ValidationSchemeBean> valScheme, DataStructureSuperBean dsd, SdmxBeanRetrievalManager beanRetrievalManager) {
		if(valScheme == null) {
			return;
		}
		for(ValidationSchemeBean validationSchemeBean : valScheme) {
			LOG.debug("Process Validation Scheme: "+validationSchemeBean.getUrn());
			for(ValidationRuleBean validationRule : validationSchemeBean.getItems()) {
				LOG.debug("Process Validation Rule: "+validationRule.getUrn());
				if(validationRule.hasExpression()) {
					LOG.debug("Process Validation Expression: "+validationRule.getExpression());
					CustomValidationExpression vEx = new CustomValidationExpression(validationRule);
					DimensionSuperBean dim;
					try {
						dim = dsd.getDimensions().get(vEx.getDimensionIndex());
					} catch(IndexOutOfBoundsException ex) {
						throw new SdmxInternalServerException("Validation Expression '"+validationRule.getExpression()+
								"' references dimension at index '"+vEx.getDimensionIndex()+
								"' which does not exist in data structure '"+dsd.getUrn()+"'");
					}
					addValidationExpression(dim.getId(), vEx);
				} else {
					ValidationRuleHierarchyBean vHierarchy = validationRule.getValidationHierarchy();
					HierarchyBean hierarchy = beanRetrievalManager.getBean(vHierarchy.getHierarchyReference().getReference());
					//From hierarchy work out expressions, one expression per parent/child realationship
					String dimId = vHierarchy.getDimensionReference().getReference().getIdentifiableId();
					DimensionSuperBean dim = dsd.getDimensionById(dimId);
					if(dim == null) {
						throw new SdmxInternalServerException("Validation Rule '"+validationRule.getUrn()+
								"' references dimension '"+vHierarchy.getDimensionReference().getReference().getFullIdentifiableId()+
								"' which does not exist in data structure '"+dsd.getUrn()+"'");
					}
					EnumeratedListBean<?> cl = dim.getCodelist(true);
					if(cl != null && cl.getStructureType() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
						addValidationExpression(hierarchy.getHierarchicalCodeBeans(), dimId, cl.getUrn());
					}
				}
			}
		}
	}

	private void addValidationExpression(List<HierarchicalCodeBean> hCodes, String dimensionId, String codelistURN) {
		for(HierarchicalCodeBean hCode : hCodes) {
			boolean hasChildren = hCode.getCodeRefs().size() > 0;
			if(!hasChildren) {
				//If there are no child codes, then there is no point in keeping it as an expression
				continue;
			}
			if(hCode.getCodeReference().getReference().getMaintainableURN().getURN().equals(codelistURN)) {
				addValidationExpression(dimensionId, new HierarchicalValidationExpression(hCode));
			} else {
				//As there are child codes, try those as some may be for this codelist
				addValidationExpression(hCode.getCodeRefs(), dimensionId, codelistURN);
			}
		}
	}

	private void addValidationExpression(String dimensionId, ValidationExpression expression) {
		LOG.debug("Add Validation Expression '"+expression+"' for Dimension '"+dimensionId+"'");
		Set<ValidationExpression> expressions = dimensionExpresssions.get(dimensionId);
		if(expressions == null) {
			expressions = new HashSet<>();
			dimensionExpresssions.put(dimensionId, expressions);
		}
		expressions.add(expression);
	}

	private class ValidationExpressionMatch {
		private String shortCode = null;
		private boolean isOutput = false;
		private int inputIndex = -1;
		private ValidationExpression exp;

		public ValidationExpressionMatch(String shortCode, ValidationExpression exp) {
			LOG.debug("Validation Expression '"+exp+"' Output Match '"+shortCode+"'");
			this.shortCode = shortCode;
			this.isOutput = true;
			this.exp = exp;
		}

		public ValidationExpressionMatch(String shortCode, int index, ValidationExpression exp) {
			LOG.debug("Validation Expression '"+exp+"' Input #"+index+" Match '"+shortCode+"'");
			this.shortCode = shortCode;
			this.inputIndex = index;
			this.exp = exp;
		}

		public void addReportedValue(Observation obs) {
			List<BigDecimal> bd = obs.getNumericalMeasureValues().get(PrimaryMeasureBean.FIXED_ID);
			//Do not use obs.getShortCode() as our short code includes a wildcard for the dimension that is operted on
			String obsShortCode = shortCode+":"+obs.getDimensionValue();
			
			if(bd != null) {
				for(BigDecimal value : bd){
					Double dbl = value.doubleValue();
					if(isOutput){
						exp.addOutput(obsShortCode, dbl);
					}else{
						exp.addInput(obsShortCode, inputIndex, dbl);
					}
				}
			}
		}
	}


	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler errorHandler) {}

	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler errorHandler) {
		if(!key.isSeries()) {
			return;
		}
		//Reset all defaults
		validationExpressions = new HashSet<>();
		for(String dimension : dimensionExpresssions.keySet()) {
			for(ValidationExpression exp : dimensionExpresssions.get(dimension)) {
				String dimVal = key.getReportedValue(dimension);
				if(exp.getOutputCode().equals(dimVal)) {
					//This is the output to this expression
					validationExpressions.add(new ValidationExpressionMatch(key.createShortCode(dimension), exp));
				} else {
					int inputIndex = exp.getInputCodes().indexOf(dimVal);
					if(inputIndex >= 0) {
						validationExpressions.add(new ValidationExpressionMatch(key.createShortCode(dimension), inputIndex, exp));
					}
				}
			}
		}
	}


	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler errorHandler) {
		for(ValidationExpressionMatch exp : validationExpressions) {
			exp.addReportedValue(obs);
		}
	}


	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		//Do nothing
	}

	@Override
	public void close(DataValidationErrorReporter errorHandler) {
		for(String dimensionId : dimensionExpresssions.keySet()) {
			for(ValidationExpression valExp : dimensionExpresssions.get(dimensionId)) {
				ErrorHandler localErrorHandler = new ErrorHandler(valExp, dimensionId, errorHandler);
				valExp.validate(localErrorHandler);
			}
		}
	}

	private class ErrorHandler implements CalculationErrorHandler {
		private DataValidationErrorReporter dataValidationReporter;
		private ValidationExpression validationExpression;
		private String dimensionId;

		public ErrorHandler(ValidationExpression expression, String dimensionId, DataValidationErrorReporter errorHandler) {
			this.dataValidationReporter = errorHandler;
			this.validationExpression = expression;
			this.dimensionId = dimensionId;
		}

		@Override
		public void reportError(ICaculationError error) {
			//There is not reported value, indicating the that expression had a constant to check against for the output, for example 10 > UK +FR
		    List<String> args = new ArrayList<>();
		    args.add(error.getExpression());
		    args.add(dimensionId);

			FusionError fe;
			if(error.getExpectedValue() == null) {
				if(error.getException() != null) {
					fe = DataValidationErrorCode.FAILED_CALCULATION_NO_OUTPUT_DUE_TO_ERROR;
					args.add(error.getException().getMessage());
				} else {
                   fe = DataValidationErrorCode.FAILED_CALCULATION_NO_OUTPUT;
				}
			} else {
			    String errorMess;
				if(error.getReportedValue() == null) {
				    errorMess = "Calculation result ";
				    errorMess = "";
					fe = DataValidationErrorCode.FAILED_CALCULATION_WITH_CALCULATION_RESULT;
				} else {
					//There is a reported value, indicating that the expression had a code for the output, example EUR > FR + DE
				    errorMess = "Reported Value '"+error.getReportedValue()+"' ";
				    errorMess = "'" + error.getReportedValue()+"' ";
					fe = DataValidationErrorCode.FAILED_CALCULATION_WITH_REPORTED_VALUE;
				}
				String failType;
				switch(error.getEquality()) {
				case "<" : failType = "is greater than or equal to"; break;
				case "<=" : failType = "is greater than"; break;
				case ">" : failType = "is less than or equal to"; break;
				case ">=" : failType = "is less than"; break;
				case "<>" : failType = "is equal to"; break;
				default :
					failType = "does not match expected output of";
				}
				errorMess += failType + " '"+error.getExpectedValue()+"'";
				args.add(errorMess);
			}
			args.add(error.getResolvedValues());

			FusionError fusionError = new FusionErrorImpl(fe, args.toArray(new String[args.size()]));
			reportError(error, fusionError);
		}

		//private void reportError(ICaculationError error, String message) {
		private void reportError(ICaculationError error, FusionError fe) {
			String value = error.getReportedValue() != null ? error.getReportedValue().toString() : null;
			dataValidationReporter.reportObsError(fe, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, value),  getObservationShortCodes(error));
		}

		/**
		 * returns the short codes of all the observations used as an input to the calculation
		 *
		 * @param shortCode - with wildcarded dimension that is used for the calculation, for example A::M:2008
		 * @return list of expanded short codes, for example A:EUR:M:2008, A:UK:M:2008, A:FR:M:2008,
		 */
		private String[] getObservationShortCodes(ICaculationError error) {
			List<String> obsInError = new ArrayList<>();


			if(!validationExpression.isOutputNumerical()) {
				String obsShortCode = error.getShortCode().replace("*", validationExpression.getOutputCode());  // Changes A::M:2008 to A:EUR:M:2008
				obsInError.add(obsShortCode);
			}
			for(String inputCode : error.getInputCodeIds()) {
				String obsShortCode = error.getShortCode().replace("*", inputCode);  // Changes A::M:2008 to A:UK:M:2008
				obsInError.add(obsShortCode);
			}

			return obsInError.stream().toArray(String[]::new);
		}
	}
}
