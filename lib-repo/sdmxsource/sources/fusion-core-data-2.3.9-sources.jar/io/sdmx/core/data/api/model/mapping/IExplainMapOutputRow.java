package io.sdmx.core.data.api.model.mapping;

import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * An output row for an input mapping
 */
public interface IExplainMapOutputRow {

	/**
	 * @return immutable map of output rows resulting from mapping against the period for whih the data are applicable 
	 */
	Map<SdmxPeriod, IDataRow> getOutput();
	
	/**
	 * @return an immutable list, explaining how each component or group of components were used to map the input
	 */
	List<IExplainMapComponent> getComponentBreakdown();
	
}
