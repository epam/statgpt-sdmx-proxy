package io.sdmx.core.data.model.mapping.explain;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.core.data.api.model.mapping.IExplainMapMatch;

public class ExplainMapMatch implements IExplainMapMatch {
	private MAP_RULE_TYPE ruleType;
	private String component;
	private String input;
	private String match;
	private List<String> captureGroups;
	private int substringStart = -1; 
	private int substringEnd = -1; 
	
	@Override
	public MAP_RULE_TYPE getRuleType() {
		return ruleType;
	}
	@Override
	public String getComponent() {
		return component;
	}

	@Override
	public String getInput() {
		return input;
	}

	@Override
	public String getMatch() {
		return match;
	}

	@Override
	public List<String> getCaptureGroups() {
		return captureGroups;
	}

	@Override
	public int getSubstringStart() {
		return substringStart;
	}

	@Override
	public int getSubstringEnd() {
		return substringEnd;
	}

	public void setRuleType(MAP_RULE_TYPE ruleType) {
		this.ruleType = ruleType;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public void setMatch(String match) {
		this.match = match;
	}

	public void setCaptureGroups(List<String> captureGroups) {
		this.captureGroups = captureGroups;
	}
	public void setSubstringStart(int substringStart) {
		this.substringStart = substringStart;
	}

	public void setSubstringEnd(int substringEnd) {
		this.substringEnd = substringEnd;
	}
}
