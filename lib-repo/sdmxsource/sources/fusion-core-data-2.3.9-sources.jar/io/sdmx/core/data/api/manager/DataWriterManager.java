package io.sdmx.core.data.api.manager;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

public interface DataWriterManager {

	/**
	 * Returns a {@link DataWriterEngine} that can write the given {@link DATA_TYPE}.
	 * @param dataFormat defines the data format to write the output in - if null is passed the default format form the {@link DataFormatManager} will be used
	 * @param out the {@link OutputStream} to write the data to
	 * @return
	 * @throws SdmxNotImplementedException if no {@link DataWriterEngine} could be found to write the requested data
	 */
	ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out);
	
	/**
	 * Returns a {@link DataWriterEngine} that can write the given {@link DATA_TYPE}.
	 * @param dataFormat defines the data format to write the output in - if null is passed the default format form the {@link DataFormatManager} will be used
	 * @param out the {@link OutputStream} to write the data to
	 * @param dataQuery (optional)defines the data query that was used to obtain the data 
	 * @return
	 * @throws SdmxNotImplementedException if no {@link DataWriterEngine} could be found to write the requested data
	 */
	ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery);
}
