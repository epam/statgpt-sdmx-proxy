package io.sdmx.core.data.manager;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.api.manager.IFlatDataReaderManager;
import io.sdmx.core.data.engine.reader.SeriesObs2FlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataFormatError;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.api.factory.data.IFlatDataReaderFactory;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.proxy.SdmxBeanRetrievalManagerProxy;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.error.FusionErrorImpl;

public class FlatDataReaderManager implements IFlatDataReaderManager {

	private Set<IFlatDataReaderFactory> factories;
	
	private DataFormatManager dataFormatManager;
	private DataReaderManager dataReaderManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private BeanRetrievalDatasetStructuresRetrievalManager brmRm;
	
	public FlatDataReaderManager(DataFormatManager dataFormatManager, DataReaderManager dataReaderManager, SdmxBeanRetrievalManager beanRetrievalManager) {
		this.dataFormatManager = dataFormatManager;
		this.dataReaderManager = dataReaderManager;
		this.beanRetrievalManager = beanRetrievalManager;
		this.brmRm = new BeanRetrievalDatasetStructuresRetrievalManager(beanRetrievalManager);
		SingletonStore.registerInstance(this);
	}
	
	@Override
	public IFlatDataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData, IDatasetStructuresRetrievalManager retrievalManager) throws SdmxNotImplementedException {
		retrievalManager = retrievalManager == null ? brmRm : retrievalManager;
		DataFormat df = dataFormatManager.getDataFormat(sourceData);
		for(IFlatDataReaderFactory currentFactory : getDataReaderFactories()) {
			IFlatDataReaderEngine dre = currentFactory.getDataReaderEngine(df, sourceData, retrievalManager);
			if(dre != null) {
				return dre;
			}
		}
		
		//Check 'old world' readers and wrap them
		//Convert the retrieval manager and exception handler
		//note - underlying DataReaderEngine dre may think it is reading from DSD 'x' but in reality it is DSD 'y' which was modified
		//in order to make it comply with the data header, this is because the 'old world' behaviour was to force the DSD to match the header
		//in the 'new world' the header is just advisory, the DSD used to read the data does not need to match.
		//As such the grouped to flat reader needs to report the 'real' DSD whereas the DRE may report that it is using a different DSD because the agency/id/version
		//parameters were changed
		ValidatingDataReaderManager dre = new ValidatingDataReaderManager(sourceData, new DataSetStructuresToBeanRetrievalManager(retrievalManager));
		if(dre.hasReader()) {
			return dre;
		}
		throw new UnrecognisedFormatException(sourceData.getInputStream());
	}

	/**
	 * extends group writer by handling all errors
	 */
	private class ValidatingDataReaderManager extends SeriesObs2FlatDataReaderEngine implements DataValidationErrorHandler { 
		private DataReaderExceptionHandler exHandler;
		
		public ValidatingDataReaderManager(ReadableDataLocation sourceData, SdmxBeanRetrievalManager beanRetrievalManager) {
			super(null);
			super.dre = dataReaderManager.getDataReaderEngine(sourceData, beanRetrievalManager, this);
		}
		
		public boolean hasReader() {
			return super.dre != null;
		}

		@Override
		public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
			this.exHandler = exHandler;
			try {
				return super.moveNextRow(exHandler);
			} finally {
				this.exHandler = null;
			}
		}

		@Override
		public void handleError(DataError err) throws ErrorLimitException {
			if(this.exHandler != null) {
				this.exHandler.handleException(new DataFormatError() {
					
					@Override
					public String getMessage() {
						return err.getMessage();
					}
					
					@Override
					public FusionError getFusionError() {
						return new FusionErrorImpl(err.getErrorCode(), err.getMessage());
					}
					
					@Override
					public Enum getErrorType() {
						return null;
					}
					
					@Override
					public ERROR_POSITION getErrorPosition() {
						return err.getErrorPosition();
					}
				});
			}
		}
	}
	
	/**
	 * Used if the data is to be read with a specific structure, it converts the parameters of the structure to the one used to read it with
	 */
	private class DataSetStructuresToBeanRetrievalManager extends SdmxBeanRetrievalManagerProxy {
		private IDatasetStructuresRetrievalManager retrievalManager;
		
		
		public DataSetStructuresToBeanRetrievalManager(IDatasetStructuresRetrievalManager retrievalManager) {
			super(beanRetrievalManager);
			this.retrievalManager = retrievalManager;
		}
		
		@Override
		public <T extends IdentifiableBean> T getBean(IURNSingle<T> urn) {
			if(urn.isType(IDSDRelatedBean.class)) {
				IDatasetStructures structures = retrievalManager.getDatasetStructures(urn.toType(IDSDRelatedBean.class));
				switch(urn.getSdmxStructure()) {
				case DATAFLOW : if(structures.getDataflow() != null) return  (T)structures.getDataflow();
				case DSD : if(structures.getDataStructure() != null) return (T)structures.getDataStructure();
				case PROVISION_AGREEMENT : if(structures.getProvisionAgreement() != null) return (T)structures.getProvisionAgreement();
				}
			}
			return super.getBean(urn);
		}
	}
	
	private Collection<IFlatDataReaderFactory> getDataReaderFactories() {
		if(factories == null) {
			synchronized(this) {
				factories = new HashSet<>();
				factories.addAll(FusionBeanStore.getBeans(IFlatDataReaderFactory.class));
			}
		}
		return factories;
	}
}
