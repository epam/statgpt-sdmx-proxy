package io.sdmx.core.data.engine.writer;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.api.model.dataset.IDataWriterMetrics;

/**
 * Capture metrics on data written to the writer
 */
public class FlatDataWriterEngineMetrics extends FlatDataWriterEngineProxy<IFlatDataWriterEngine> {
	private long timeStart = System.currentTimeMillis();
	private long timeEnd = -1;
	private int seriesCount = -1;
	private int rowsCount = 0;
	private boolean captureSeriesCount;
	private String lastSeries = "";
	
	public FlatDataWriterEngineMetrics(IFlatDataWriterEngine proxy, boolean captureSeriesCount) {
		super(proxy);
		this.captureSeriesCount = captureSeriesCount;
		if(captureSeriesCount) {
			seriesCount = 0;
		}
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		super.startDataset(header, annotations);
	}

	@Override
	public void writeRow(IDataRow row) {
		this.rowsCount++;
		if(captureSeriesCount) {
			if(!lastSeries.equals(row.getShortCode())) {
				this.seriesCount++;
			}
			lastSeries = row.getShortCode();
		}
		super.writeRow(row);
	}
	
	/**
	 * @return metrics of data processed so far
	 */
	public IDataWriterMetrics getDataWriterMetrics() {
		return new IDataWriterMetrics() {
			
			@Override
			public long getStartTime() {
				return timeStart;
			}
			
			@Override
			public int getSeries() {
				return seriesCount;
			}
			
			@Override
			public int getRows() {
				return rowsCount;
			}
			
			@Override
			public long getEndTime() {
				return timeEnd;
			}
		};
	}

	@Override
	public void close() {
		super.close();
		timeEnd = System.currentTimeMillis();
	}
}
