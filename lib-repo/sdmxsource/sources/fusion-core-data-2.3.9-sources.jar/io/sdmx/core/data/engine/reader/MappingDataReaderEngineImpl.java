package io.sdmx.core.data.engine.reader;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.engine.writer.MappingDataWriterEngine;
import io.sdmx.core.data.manager.KryoTemporaryDataManager;
import io.sdmx.core.data.model.mapping.DataMappingConfig;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * This class reads data according to one dataset, but maps it to another based on the DataStructureMap
 * @author Matt Nelson
 *
 */
public class MappingDataReaderEngineImpl extends AbstractWrapperedDataReaderEngine implements DataReaderEngine {
	private ITemporaryDataManager tmpDataManager = SingletonStore.getSingleton(ITemporaryDataManager.class, true);
	private ITemporaryDataWriterEngine tmpDwe;
	private MappingRules map;

	/**
	 * 
	 * @param mapToRef a reference to the DSD which is being mapped TO
	 * @param dre the DataReaderEngine of the underlying dataset
	 * @param map the DataStructureMap to use for mapping the data
	 */
	public MappingDataReaderEngineImpl(DataReaderEngine dre, MappingRules map) {
		if(tmpDataManager == null) {
			tmpDataManager = new KryoTemporaryDataManager();
			SingletonStore.registerInstance(tmpDataManager);
		}
		tmpDwe = tmpDataManager.getDataWriterEngine();
		ISeriesObsDataWriterEngine dwe = new MappingDataWriterEngine(DataMappingConfig.getInstance(map).setMappedDataWriterEngine(tmpDwe));
		DataTransformationUtil.copyData(dre, dwe, true, true);
		this.map = map;
		super.dataReaderEngine = tmpDataManager.getDataReaderEngine(tmpDwe);
	}
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		return new MappingDataReaderEngineImpl(proxyCopy, map);
	}

	@Override
	public List<FooterMessage> close() {
		try {
			super.close();
		} finally {
			if(tmpDwe != null) {
				tmpDataManager.close(tmpDwe);
			}
		}
		return Collections.emptyList();
	}
}
