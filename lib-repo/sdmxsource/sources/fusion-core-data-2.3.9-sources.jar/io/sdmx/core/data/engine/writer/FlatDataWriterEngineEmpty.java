package io.sdmx.core.data.engine.writer;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * Does nothing with the written data
 */
public class FlatDataWriterEngineEmpty implements IFlatDataWriterEngine {
	public static final FlatDataWriterEngineEmpty INSTANCE = new FlatDataWriterEngineEmpty();
	
	/**
	 * For subclassing only
	 */
	protected FlatDataWriterEngineEmpty() {}

	@Override
	public void writeHeader(HeaderBean header) {}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {}

	@Override
	public void writeRow(IDataRow row) {}

	@Override
	public void close() {}

	
}
