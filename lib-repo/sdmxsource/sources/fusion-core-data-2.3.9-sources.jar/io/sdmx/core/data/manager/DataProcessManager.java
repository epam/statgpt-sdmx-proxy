package io.sdmx.core.data.manager;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.factory.IDataProcessFactory;
import io.sdmx.core.data.api.manager.IDataProcessManager;
import io.sdmx.core.data.api.manager.IFlatDataReaderManager;
import io.sdmx.core.data.api.manager.IProcessStepRetrievalManager;
import io.sdmx.core.data.api.model.dataset.IDataWriterMetrics;
import io.sdmx.core.data.api.model.process.IDataProcess;
import io.sdmx.core.data.api.model.process.IProcessStep;
import io.sdmx.core.data.api.model.process.IProcessToken;
import io.sdmx.core.data.engine.writer.FlatDataWriterEngineMetrics;
import io.sdmx.core.data.engine.writer.FlatDataWriterEngineMultiProxy;
import io.sdmx.core.data.engine.writer.FlatDataWriterEngineTmpStore;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.FiniteMap;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

/**
 *  Processes the input data by performing the following tasks:
 *  <ol>
 *    <li>Obtaining a {@link IFlatDataReaderEngine} for the input data</li>
 *    <li>Building a chain or {@link IFlatDataWriterEngine} based on the process steps</li>
 *    <li>Copying the data from the reader to writer(s)</li>
 *  </ol>
 */
public class DataProcessManager implements IDataProcessManager, Listener<DataProcessManager.ProcessExecutionManager> {
	private Map<String, IDataProcessFactory> processStepFactories;

	private IFlatDataReaderManager dataReaderManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;

	private Map<String, ProcessExecutionManager> processingMap = Collections.synchronizedMap(new HashMap<>());  						//A map of processes that are not complete
	private Map<String, ProcessExecutionManager> processedMap =  Collections.synchronizedMap(new FiniteMap<>(1000*60*10, this));  //10 minute store of completed processes
	
	public DataProcessManager(IFlatDataReaderManager dataReaderManager, SdmxBeanRetrievalManager beanRetrievalManager) {
		this.dataReaderManager = dataReaderManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	/**
	 * The finite map has evicted the process manager - close the resources
	 */
	public void invoke(ProcessExecutionManager evicted) {
		for(ITemporaryFlatDataWriterEngine currentTmpStore : evicted.getTemporaryDataStores()) {
			currentTmpStore.removeResources();
		}
	}

	@Override
	public IProcessToken processData(final IDataProcess process, ReadableDataLocation data) {
		//1. Obtain a IFlatDataReaderEngine, obtain the structures from either the reference passed in, or if none was passed, the reference from the dataset
		IFlatDataReaderEngine dre = dataReaderManager.getDataReaderEngine(data, new IDatasetStructuresRetrievalManager() {
			@Override
			public IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef) {
				if(process.getStructure() != null) {
					return new DatasetStructures(process.getStructure(), beanRetrievalManager);
				}
				if(sRef == null) {
					throw new SdmxSemmanticException("Can not read data, no DSD reference found");
				}
				return new DatasetStructures(sRef, beanRetrievalManager);
			}
		});

		//2. Build the Hierarchy of IFlatDataWriterEngine based on the Process Steps
		final ProcessExecutionManager manager = new ProcessExecutionManager(process, dre);
		return manager.executeProcess();
	}

	@Override
	public boolean isComplete(String tokenId) throws SdmxNoResultsException {
		ProcessExecutionManager process = processingMap.get(tokenId);
		if(process == null) {
			process = processedMap.get(tokenId);
			if(process == null) {
				throw new SdmxNoResultsException("Process not found");
			}
			return true;
		}
		return false;
	}

	@Override
	public void writeProcessStatus(String tokenId, OutputStream out) {
		ProcessExecutionManager process = processingMap.get(tokenId);
		if(process == null) {
			process = processedMap.get(tokenId);
		}
		if(process == null) {
			throw new SdmxNoResultsException("Process not found");
		}
		JSONObject response = new JSONObject();
		try {
			response.put("ProcessToken", tokenId);
			response.put("StartTime", process.processStart);
			int status = process.procesEnd < 0 ? 0 : 1;
			response.put("EndTime", process.procesEnd);
			if(process.error != null) {
				status = 2;
			}
			response.put("Status", status);
			if(process.processStepMetricsWriter.keySet().size() > 0) {
				JSONObject metrics = new JSONObject();

				response.put("Steps", metrics);
				for(String processStepId : process.processStepMetricsWriter.keySet()) {
					JSONObject stepMetrics = new JSONObject();
					metrics.put(processStepId, stepMetrics);
					IDataWriterMetrics writerMetrics = process.processStepMetricsWriter.get(processStepId).getDataWriterMetrics();
					stepMetrics.put("StartTime", writerMetrics.getStartTime());
					stepMetrics.put("EndTime", writerMetrics.getEndTime());
					stepMetrics.put("Series", writerMetrics.getRows());
					stepMetrics.put("Rows", writerMetrics.getSeries());
				}
			}
			out.write(response.toString().getBytes());
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void writeData(DataQuery query, String tokenId, String processId, IFlatDataWriterEngine writer) throws SdmxNoResultsException {
		ProcessExecutionManager processManager = processedMap.get(tokenId);
		if(processManager == null) {
			boolean exists = processingMap.containsKey(tokenId);
			if(!exists) {
				throw new SdmxNoResultsException("Process not found");
			} else {
				throw new SdmxNoResultsException("Process not complete, please check process status is complete before performing operations on the process");
			}
		}
		ITemporaryFlatDataWriterEngine processWriter = processManager.getTemporaryDataStore(processId);
		if(processWriter == null) {
			throw new SdmxNoResultsException("Process step not found");
		}
		IFlatDataReaderEngine dre = processWriter.getDataReaderEngine();
		//TODO if DataQuery is not null, create a proxy IFlatDataWriterEngine to filter results which do not conform to the query
		DataTransformationUtil.copyData(dre, writer, true, true);
	}



	public class ProcessExecutionManager implements IProcessStepRetrievalManager, Runnable {
		private final String id = UUID.randomUUID().toString();
		private long processStart = System.currentTimeMillis();
		private long procesEnd = -1;
		private Map<String, IProcessStep> procesSteps = new HashMap<>();
		private Map<String, Integer> processStepCount = new HashMap<>(); //Keep a record of how often the step was requested
		private Map<String, IFlatDataWriterEngine> processStepWriter = new HashMap<>();
		private Map<String, FlatDataWriterEngineMetrics> processStepMetricsWriter = new HashMap<>();
		private Map<String, FlatDataWriterEngineTmpStore> processStepWriterTmpStore = new HashMap<>();
		private Throwable error;
		
		private Set<String> processDependancies = new HashSet<>();
		
		private IFlatDataReaderEngine dre;
		private final IDataProcess process;
		public ProcessExecutionManager(IDataProcess process, IFlatDataReaderEngine dre) {
			this.dre = dre;
			this.process = process;
			for(IProcessStep processStep : process.getProcessSteps()) {
				this.procesSteps.put(processStep.getStepId(), processStep);
				this.processStepCount.put(processStep.getStepId(), 0);
			}
			//Loop all steps and generate, this ensures the step count for all processes is at least 1
			//Any process which is not used by the output of another process is taken to be a high level process
			//to which the data is written
			for(IProcessStep currentStep : process.getProcessSteps()) {
				processDependancies = new HashSet<>();
				getProcessStep(currentStep.getStepId());
			}
		}
		
		public IProcessToken executeProcess() {
			Thread t = new Thread(this, this.id);
			t.setDaemon(true);
			t.start();
			return new IProcessToken() {

				@Override
				public IDataProcess getProcess() {
					return process;
				}

				@Override
				public String getTokenId() {
					return id;
				}
			};
		}
		
		@Override
		public void run() {
			try {
				processingMap.put(this.id, this);
				List<IFlatDataWriterEngine> writers = getHighLevelWriters();

				if(writers.size() == 0) {
					throw new SdmxSemmanticException("Unable to run process, no process step entry point found");
				}
				//3. Create a final writer, which is either the only high level writer found or a proxy on top of multiple writers
				IFlatDataWriterEngine finalOutputWriter = writers.size() > 1 ? new FlatDataWriterEngineMultiProxy(writers) : writers.get(0);
				
				//4. Run the process by reading the dataset and writing the data to the process writers
				DataTransformationUtil.copyData(dre, finalOutputWriter, true, true);
			} finally {
				processedMap.put(this.id, this);
				this.procesEnd = System.currentTimeMillis();
				processingMap.remove(this.id);
			}
		}

		/**
		 * Writes the current status of the process to the output stream, in the format
		 * {
		 * 		"Id"    		: string
		 * 		"ProcessStart"  : long
		 * 		"ProcessEnd"    : long
		 *      "Steps"         : {
		 *        "StepId" : {
		 *          "ProcessStart"  : long
		 * 		    "ProcessEnd"    : long
		 *          "Rows"          : int
		 *          "Series"		: int
		 *        },
		 *       }
		 * }
		 * @param out
		 * @throws IOException
		 */
		public void writeProcessStatus(OutputStream out) throws IOException {
			try(JsonGenerator jsonWriter = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)) {
				jsonWriter.writeStartObject();
				jsonWriter.writeStringField("Id", this.id);
				jsonWriter.writeNumberField("ProcessStart", this.processStart);
				jsonWriter.writeNumberField("ProcessEnd", this.procesEnd);
				jsonWriter.writeStartArray("Steps");
				for(String stepId : this.procesSteps.keySet()) {
					FlatDataWriterEngineMetrics stepMetricsWriter = this.processStepMetricsWriter.get(stepId);
					if(stepMetricsWriter != null) {
						IDataWriterMetrics metrics = stepMetricsWriter.getDataWriterMetrics();
						if(metrics != null) {
							//Write Step Metrics Object
							jsonWriter.writeObjectFieldStart(stepId);
							jsonWriter.writeNumberField("ProcessStart", metrics.getStartTime());
							jsonWriter.writeNumberField("ProcessEnd", metrics.getEndTime());
							jsonWriter.writeNumberField("Rows", metrics.getRows());
							jsonWriter.writeNumberField("Series", metrics.getSeries());
							jsonWriter.writeEndObject(); //End Step Object
						}
					}
				}
				jsonWriter.writeEndArray();
				jsonWriter.writeEndObject();
			}
		}

		/**
		 * @return list of all writers that are of type {@link ITemporaryFlatDataWriterEngine}
		 */
		public List<ITemporaryFlatDataWriterEngine> getTemporaryDataStores() {
			List<ITemporaryFlatDataWriterEngine> writers = new ArrayList<>();
			for(String processId : processStepWriterTmpStore.keySet()) {
				writers.add(processStepWriterTmpStore.get(processId));
			}
			return writers;
		}

		/**
		 * @param processId
		 * @return temporary store if the process represents a temporary store - otherwise null
		 */
		public ITemporaryFlatDataWriterEngine getTemporaryDataStore(String processId) {
			return processStepWriterTmpStore.get(processId);
		}

		/**
		 * @return list of all writers that are not used as the output of any other writer, deemed to be a writer which consumes the source data
		 */
		public List<IFlatDataWriterEngine> getHighLevelWriters() {
			List<IFlatDataWriterEngine> writers = new ArrayList<>();
			for(String processId : processStepCount.keySet()) {
				if(processStepCount.get(processId) == 1) {
					writers.add(processStepWriter.get(processId));
				}
			}
			return writers;
		}

		@Override
		public IFlatDataWriterEngine getProcessStep(String processStepId) {
			if(!this.processStepCount.containsKey(processStepId)) {
				throw new SdmxSemmanticException("Process Step '"+processStepId+"' not defined for process");
			}
			if(processDependancies.contains(processStepId)) {
				throw new SdmxSemmanticException("Recursive Process Step loop to process:"+processStepId);
			}
			processDependancies.add(processStepId);
			int stepCount = this.processStepCount.get(processStepId) +1;
			this.processStepCount.put(processStepId, stepCount);

			IFlatDataWriterEngine writer = processStepWriter.get(processStepId);
			if(writer == null) {
				IProcessStep processStep = procesSteps.get(processStepId);
				if(processStep == null) {
					throw new SdmxSemmanticException("Process Step with ID '"+processStepId+"' not found");
				}
				IDataProcessFactory factory = getProcessStepFactory(processStep.getProcessId());
				writer = factory.getDataWriterEngine(processStep.getProcessProperties(), this);
				if(writer instanceof FlatDataWriterEngineTmpStore) {
					this.processStepWriterTmpStore.put(processStepId, (FlatDataWriterEngineTmpStore)writer);
				}
				if(processStep.captureMetrics()) {
					writer = new FlatDataWriterEngineMetrics(writer, true);
				}
				processStepWriter.put(processStepId, writer);
			}
			if(writer == null) {
				throw new SdmxException("Process Step '"+processStepId+"' did not produce an IFlatDataWriterEngine");
			}
			return writer;
		}
	}

	private IDataProcessFactory getProcessStepFactory(String factoryId) {
		if(processStepFactories == null) {
			Map<String, IDataProcessFactory> factories = new HashMap<>();
			for(IDataProcessFactory factory : FusionBeanStore.getBeans(IDataProcessFactory.class)) {
				factories.put(factory.getProcessId(), factory);
			}
			this.processStepFactories = factories;
		}
		IDataProcessFactory factory = processStepFactories.get(factoryId);
		if(factory == null) {
			throw new SdmxSemmanticException("Process Step factory with ID '"+factoryId+"' not found");
		}
		return factory;
	}
}
