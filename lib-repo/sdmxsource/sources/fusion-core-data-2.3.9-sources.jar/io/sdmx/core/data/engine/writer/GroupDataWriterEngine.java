package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.manager.KryoTemporaryDataManager;
import io.sdmx.core.data.model.dataset.ReportedGroupAttributesValues;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.im.data.KeyableProxy;
import io.sdmx.im.data.ObservationProxy;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Proxies a DataWriterEngine and stores Group information.
 * 
 * It converts all Group Attributes to Series Attributes so that the DataWriter will output Group Attributes just as if they are Series Attributes.
 */
public class GroupDataWriterEngine extends DataWriterEngineProxy {
	private boolean dsdHasGroups;
    private ReportedGroupAttributesValues groupAttributes;
    private DataStructureBean dataStructureBean;
    private ITemporaryDataManager tmpDataManager = SingletonStore.getSingleton(ITemporaryDataManager.class, true);
    private ITemporaryDataWriterEngine tmpWriter;
    private ISeriesObsDataWriterEngine targetWriter;
    private HeaderBean header;
	private boolean hasWrittenGroups;
    
	public GroupDataWriterEngine(ISeriesObsDataWriterEngine dwe) {
		super(dwe);
		if(tmpDataManager == null) {
			tmpDataManager = new KryoTemporaryDataManager();
			SingletonStore.registerInstance(tmpDataManager);
		}
	}
	
    @Override
	public void writeHeader(HeaderBean header) {
		this.header = header;
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
        this.dataStructureBean = structures.getDataStructure();
		List<GroupBean> groups = dataStructureBean.getGroups();
		dsdHasGroups = !groups.isEmpty();
		
		if (tmpWriter != null) {
			// Cater for multiple datasets
			super.close();
			flushSeriesAndAddGroups(false);
			// DEV-2278: Lorenzo noted that unless the tmpDataManager is closed, temporary files are not deleted
			tmpDataManager.close(tmpWriter);
			super.setProxy(targetWriter);
		}
		
		//If the DSD has groups, write all data to a temporary store, and only capture the group information
		if (dsdHasGroups) {
		    this.targetWriter = super.getProxy();  //store the target writer and replace with the tmp writer
			this.groupAttributes = new ReportedGroupAttributesValues(dataStructureBean);
			tmpWriter = tmpDataManager.getDataWriterEngine();
			super.setProxy(tmpWriter);
			
		}
		super.writeHeader(this.header);
        // Reset the groupAttributes object
		super.startDataset(structures, datasetHeader, datasetAttributes, annotations);
	}

	@Override
	public void writeKey(Keyable key) {
		if(key.isSeries()) {
	        super.writeKey(key);
		} else {
			groupAttributes.addGroup(key);
			hasWrittenGroups = true;
		}
	}
	
    public boolean hasWrittenGroups() {
    	return hasWrittenGroups;
    }

	@Override
    public void close(FooterMessage... footer) {
		try {
			super.close(footer);
			flushSeriesAndAddGroups(true);
		} finally {
			if(tmpWriter != null) {
				tmpDataManager.close(tmpWriter);
			}
		}
    }

	private void flushSeriesAndAddGroups(boolean closeWriter) {
		if(!dsdHasGroups) {
			return;
		}
		//Flush the temp data writer proxy to the flusing proxy
		FlusingProxyDataWriterEngine flusingProxy = new FlusingProxyDataWriterEngine(targetWriter);
		DataReaderEngine dre = tmpDataManager.getDataReaderEngine(tmpWriter);

		//Re-read all series written in, and enrich with the group information
		DataTransformationUtil.copyData(dre, flusingProxy, true, closeWriter);
	}
	
	public class FlusingProxyDataWriterEngine extends DataWriterEngineProxy {
	    private Keyable proxyKey = null;
	    
		public FlusingProxyDataWriterEngine(ISeriesObsDataWriterEngine dwe) {
			super(dwe);
		}

		@Override
		public void writeKey(Keyable key) {
			proxyKey = null;
			if(key.isSeries()) {
		        final List<KeyValue> attributesForSeries = groupAttributes.getAttributesForSeries(key);
		        if (ObjectUtil.validCollection(attributesForSeries)) {
		        	//Modify Key
		            final List<KeyValue> combinedAttributes = new ArrayList<>(key.getAttributes().size()+attributesForSeries.size());
		            combinedAttributes.addAll(key.getAttributes());
		            combinedAttributes.addAll(attributesForSeries);
		            proxyKey = new KeyableProxy(key) {

						@Override
						public List<KeyValue> getAttributes() {
							return combinedAttributes;
						}

						@Override
						public KeyValue getAttribute(String concept) {
							KeyValue kv = super.getAttribute(concept);
							if(kv != null) {
								return kv;
							}
							for(KeyValue currentKv : attributesForSeries) {
								if(currentKv.getConcept().equals(concept)) {
									return currentKv;
								}
							}
							return null;
						}

						@Override
						public String getAttributeValue(String concept) {
							KeyValue kv = getAttribute(concept);
							if(kv != null) {
								return kv.getCode();
							}
							return null;
						}
					};
					key = proxyKey;
		        }
		        super.writeKey(key);
			}
		}

	    @Override
		public void writeObservation(Observation obs) {
			if(proxyKey != null) {
				obs = new ObservationProxy(obs, obs, proxyKey);
			}
			super.writeObservation(obs);
		}
	}
}
