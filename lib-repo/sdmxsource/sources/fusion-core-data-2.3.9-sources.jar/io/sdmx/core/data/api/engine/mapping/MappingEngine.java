package io.sdmx.core.data.api.engine.mapping;

import io.sdmx.core.data.api.model.mapping.IExplainMap;
import io.sdmx.core.data.api.model.mapping.IMappedRow;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Performs atomic mapping operations such as MapKey, MapObs, and Explain Plan
 */
public interface MappingEngine {
	
	/**
	 * Performs a mapping on the input values, as if mapValues was called, the difference
	 * is the response contains both the mapped rows, with the reasons why the mapping output came to be
	 * 
	 * @param rules contains the mapping rules, source DSD to target
	 * @param inputValues the values conforming to the source DSD for the {@link MappingRules}
	 * @return the mapped values along with the breakdown of mapping rules used to arrive at this output
	 */
	IExplainMap explainMapping(MappingRules rules,  IDataRow inputValues);

	/**
	 * Maps the input values to return 0->many mapped rows
	 * @param rules contains the mapping rules, source DSD to target
	 * @param inputValues the values conforming to the source DSD for the {@link MappingRules}
	 * @return {@link IMappedRow}
	 */
	IMappedRow mapValues(MappingRules rules, IDataRow inputValues);

}