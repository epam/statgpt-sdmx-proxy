package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.im.data.MultilingualKeyValue;

public class MultilingualKeyValueSerializer extends Serializer<IMultilingualKeyValue> {
	private static final MultilingualKeyValueSerializer INSTANCE = new MultilingualKeyValueSerializer();

	public static MultilingualKeyValueSerializer getInstance() {
		return INSTANCE;
	}

	private MultilingualKeyValueSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, IMultilingualKeyValue x) {
		kryo.writeObject(output, x.getConcept());
		kryo.writeObject(output, x.getMultilingualNodeValues(), MultilingualNodeValueListSerializer.getInstance());
	}

	@Override
	public IMultilingualKeyValue read(Kryo kryo, Input input, Class<? extends IMultilingualKeyValue> type) {
		String concept = kryo.readObject(input, String.class);
		List<IMultilingualNodeValue> multilingualNodes = kryo.readObject(input, List.class, MultilingualNodeValueListSerializer.getInstance());
		return MultilingualKeyValue.getInstance(concept, multilingualNodes);
	}
}

