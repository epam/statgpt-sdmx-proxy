package io.sdmx.core.data.factory.datavalidation;

import java.util.Date;
import java.util.Set;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.api.sdmx.manager.structure.IConstraintModelRetreivalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.ConstraintValidationEngine;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConstraintValidatorFactory implements DataValidatorFactory {

	private IConstraintModelRetreivalManager constraintModelRetrievalManager;
	
	public ConstraintValidatorFactory(IConstraintModelRetreivalManager constraintModelRetrievalManager) {
		this.constraintModelRetrievalManager = constraintModelRetrievalManager;
	}

	@Override
	public DataValidationEngine createInstance(DatasetInformation dsi) {
		ConstrainableBean constrainable = dsi.getDatasetStructures().getConstrainable();
		Date creationDate = dsi.getTransactionValidity();
		Set<ContentConstraintModel> constraintRules = constraintModelRetrievalManager.getContentConstraintModels(constrainable, creationDate);
		if (ObjectUtil.validCollection(constraintRules)) {
			return new ConstraintValidationEngine(constraintRules);
		}
		// If there are no constraints simply return a null instead of a DataValidationEngine
		return null;
	}

	@Override
	public String getId() {
		return "Constraint";
	}

	@Override
    public String getName() {
        return "Valid Constraint";
    }

	@Override
	public String getDescription() {
		return "These  are additional checks performed when a Dataflow and/or Provision Agreement are selected. "
				+ "A Dimension or Attribute in the dataset may report a value which is valid with regards to the DSD, but has been restricted for the reporting entity in the Reporting Constraints.  "
				+ "For example the Reporting Country UK is valid in the country codelist, but the data provider FR will not be allowed to report this data. ";
	}

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return true;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.BLOCK_PUBLICATION;
	}
}