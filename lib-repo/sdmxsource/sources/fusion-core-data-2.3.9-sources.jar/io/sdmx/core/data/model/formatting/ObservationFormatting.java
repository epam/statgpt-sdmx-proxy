package io.sdmx.core.data.model.formatting;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class ObservationFormatting implements IObservationFormatting {
	private static final long serialVersionUID = 1L;
	private int precision;
	private boolean precisionDP;
	private boolean normalise;
	private boolean sci;
	private List<String> key = Collections.emptyList();
	private RoundingMode roundingMode;
	private Locale locale;
	private Integer scalingFactor;
	
	public ObservationFormatting(IObservationFormatting obsFormatting) {
		this.precision = obsFormatting.getPrecision();
		this.precisionDP = obsFormatting.isPrecisionDP();
		this.roundingMode = obsFormatting.getRoundingMode();
		this.normalise = obsFormatting.isNormalise();
		this.locale =  obsFormatting.getLocale();
		this.sci = obsFormatting.isScientificNotation();
		this.scalingFactor = obsFormatting.getScalingFactor();
		if(ObjectUtil.validCollection(obsFormatting.getKeyMatch())) {
			this.key = Collections.unmodifiableList(new ArrayList<>(obsFormatting.getKeyMatch()));
		}
	}
	
	/**
	 * @return an empty observation formatting
	 */
	public static ObservationFormatting get() {
		return new ObservationFormatting(null, null, -1, null, false, false, false, null);
	}

	/**
	 * @param precision
	 * @return a copy of this instance with the precision set
	 */
	public ObservationFormatting precision(int precision) {
		return new ObservationFormatting(this).setPrecision(precision);
	}

	public ObservationFormatting precisionDP() {
		return new ObservationFormatting(this).setPrecisionDP(true);
	}

	public ObservationFormatting normalise() {
		return new ObservationFormatting(this).setNormalise(true);
	}

	public ObservationFormatting sci() {
		return new ObservationFormatting(this).setSci(true);
	}

	public ObservationFormatting key(List<String> key) {
		return new ObservationFormatting(this).setKey(key);
	}

	public ObservationFormatting roundingMode(RoundingMode roundingMode) {
		return new ObservationFormatting(this).setRoundingMode(roundingMode);
	}

	public ObservationFormatting locale(Locale locale) {
		return new ObservationFormatting(this).setLocale(locale);
	}

	public ObservationFormatting scalingFactor(Integer scalingFactor) {
		return new ObservationFormatting(this).setScalingFactor(scalingFactor);
	}
	
	

	/**
	 * @param key the series key or partial key to which this formatting applies - null to indicate a global rule.  
	 *        Syntax is either: 
	 *        a) COMPONENT_ID1=VAL1+VAL2,COMPONENT_ID2=VAL_3
	 *        b) =FLOW_ALIAS.A:B+C:D:E
	 *        For syntax (a) the plus operator is treated as an OR, and the comma separator is treated as an AND
	 *        For syntax (b) the flow alias is optional, the key parts are optional, the plus operator is treated as an OR
	 *        For both (a & b) if the string starts with a '!' symbol to indicate a not command
	 *        Each entry in the list is treated as an OR
	 *        
	 * @param locale the output locale for the formatted number
	 * @param precision the number of decimal places or significant figures (determined by precisionDP)
	 * @param scalingFactor the multiplier to apply to the number, 10^scaling factor for example if the observation value is 1.1 and the scaling factor is 3 the scaled number is 1100
	 * @param precisionDP if true the precision is decimal places, false it is significant figures
	 * @param scientific true to format the output as scientific notation (i.e. 1.1*10^3)
	 * @param normalise normalise will ensure there are always 'x' number of decimal places/significant figures even if it is longer then the * original number, i.e. 1.1 to 3 decimal places would be 1.100 normalised and 1.1 not normalised
	 * @param roundingMode if rounding is required
	 */
	public ObservationFormatting(List<String> key, 
								 Locale locale, 
								 int precision, 
								 Integer scalingFactor,
								 boolean precisionDP,  
								 boolean scientific, 
								 boolean normalise, 
								 RoundingMode roundingMode) {
		this.precision = precision;
		this.precisionDP = precisionDP;
		if(roundingMode == null) {
			roundingMode = RoundingMode.HALF_UP;
		}
		this.roundingMode = roundingMode;
		this.normalise = normalise;
		this.sci = scientific;
		this.locale = locale;
		this.scalingFactor = scalingFactor;
		if(key != null) {
			this.key = Collections.unmodifiableList(new ArrayList<>(key));
		}
	}
	
	private ObservationFormatting setPrecision(int precision) {
		this.precision = precision;
		return this;
	}

	private ObservationFormatting setPrecisionDP(boolean precisionDP) {
		this.precisionDP = precisionDP;
		return this;
	}

	private ObservationFormatting setNormalise(boolean normalise) {
		this.normalise = normalise;
		return this;
	}

	private ObservationFormatting setSci(boolean sci) {
		this.sci = sci;
		return this;
	}

	private ObservationFormatting setKey(List<String> key) {
		this.key = key;
		return this;
	}

	private ObservationFormatting setRoundingMode(RoundingMode roundingMode) {
		if(roundingMode != null) {
			this.roundingMode = roundingMode;
		}
		return this;
	}

	private ObservationFormatting setLocale(Locale locale) {
		this.locale = locale;
		return this;
	}

	private ObservationFormatting setScalingFactor(Integer scalingFactor) {
		this.scalingFactor = scalingFactor;
		return this;
	}

	@Override
	/**
	 * @return null to indicate not applicable,  the multiplier to apply to the number, 10^scaling factor for example if the observation value is 1.1 and the scaling factor is 3 the scaled number is 1100
	 */
	public Integer getScalingFactor() {
		return scalingFactor;
	}

	@Override
	/**
	 * @return null to indicate not applicable, the output locale for the formatted number (what symbols to use for the thousand separator and decimal place)
	 */
	public Locale getLocale() {
		return locale;
	}

	@Override
	/**
	 * @return normalise will ensure there are always 'x' number of decimal places/significant figures even if it is longer then the * original number, i.e. 1.1 to 3 decimal places would be 1.100 normalised and 1.1 not normalised
	 */
	public boolean isNormalise() {
		return normalise;
	}

	@Override
	/**
	 * @return the number of decimal places or significant figures (determined by precisionDP)
	 */
	public int getPrecision() {
		return precision;
	}

	@Override
	/**
	 * @return if true the precision is decimal places, false it is significant figures
	 */
	public boolean isPrecisionDP() {
		return precisionDP;
	}

	@Override
	/**
	 * @return  if rounding is required
	 * @see BigDecimal
	 */
	public RoundingMode getRoundingMode() {
		return roundingMode;
	}

	@Override
	/**
	 * @return true to format the output as scientific notation (i.e. 1.1*10^3)
	 */
	public boolean isScientificNotation() {
		return sci;
	}

	@Override
	/**
	 * @return the series key or partial key to which this formatting applies - null to indicate a global rule
	 */
	public List<String> getKeyMatch() {
		return key;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof IObservationFormatting) {
			IObservationFormatting that = (IObservationFormatting) obj;
			return  this.isPrecisionDP() == that.isPrecisionDP() && 
					this.isScientificNotation() == that.isScientificNotation() && 
					this.isNormalise() == that.isNormalise() && 
					this.getPrecision() == that.getPrecision() && 
					this.getRoundingMode() == that.getRoundingMode() &&
					ObjectUtil.equivalent(this.getLocale(), that.getLocale()) &&
					ObjectUtil.equivalent(this.getScalingFactor(), that.getScalingFactor()) &&
					ObjectUtil.equivalent(this.key, that.getKeyMatch());
		}
		return false;
	}

	@Override
	public String toString() {
		String keysString = CollectionUtil.collectionToString(key, ",", "");
		String locale = this.getLocale() == null ? "" : this.getLocale().toString();
		String scale = this.getScalingFactor() == null ? "" : "*10^"+this.getScalingFactor().toString();
		return precision + (precisionDP ? "dp" : "sf") + scale + " " + locale + " " +(normalise ? " fixed " : " max ") + roundingMode + " "+keysString;
	}
}
