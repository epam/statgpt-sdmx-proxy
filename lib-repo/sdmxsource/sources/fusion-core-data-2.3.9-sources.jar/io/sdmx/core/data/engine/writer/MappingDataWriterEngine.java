package io.sdmx.core.data.engine.writer;

import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean.COMPONENT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.api.engine.mapping.MappingEngine;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.api.model.mapping.IMappedRow;
import io.sdmx.core.data.api.model.mapping.ITimeMapping;
import io.sdmx.core.data.api.model.mapping.ITimePeriodMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.engine.mapping.MappingEngineImpl;
import io.sdmx.core.data.model.DatasetInformationImpl;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.data.model.mapping.DataMappingConfig;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.core.sdmx.error.InMemoryErrorHandler;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.data.AbstractAttributable;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.KeyableProxy;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.data.ObservationMeasureProxy;
import io.sdmx.im.data.ObservationProxy;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.collection.KeyValueUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.NumberUtils.Format;
import io.sdmx.utils.core.object.NumberUtils.NotationStyle;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

public class MappingDataWriterEngine extends DataWriterEngineProxy implements ISeriesObsDataWriterEngine {
	private MappingEngine mappingEngine = MappingEngineImpl.getInstance();
	private GroupDataWriterEngine groupDwe;

	/**
	 * @param mappingConfig containing the mapping configuration
	 */
	public MappingDataWriterEngine(DataMappingConfig mappingConfig) {
		this.groupDwe = new GroupDataWriterEngine(new MappingProxyDataWriterEngine(mappingConfig));
		ISeriesObsDataWriterEngine roundingProxy = new RoundingProxyDataWriterEngine(this.groupDwe, mappingConfig);
		super.setProxy(roundingProxy);
	}
	
	/**
	 * This class rounds a number to fit within a set length. For example a value of 123456 which needs to
	 * fit inside a String of length 5, would be converted to 1.2E5.
	 */
	public class RoundingProxyDataWriterEngine implements ISeriesObsDataWriterEngine {

		private ISeriesObsDataWriterEngine proxy;
		private DataMappingConfig mappingConfig;
		private Map<String, Integer> serAttrToModify;
		private Map<String, Integer> obsAttrToModify;
		private Map<String, Integer> measuresToModify;

		RoundingProxyDataWriterEngine(ISeriesObsDataWriterEngine proxy, DataMappingConfig mappingConfig) {
			this.proxy = proxy;
			this.mappingConfig = mappingConfig;
			this.serAttrToModify = new HashMap<>();
			this.obsAttrToModify = new HashMap<>();
			this.measuresToModify = new HashMap<>();
		}
		
		@Override
		public void writeHeader(HeaderBean header) {
			proxy.writeHeader(header);
		}

		@Override
		public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
			MappingRules mappingRules = this.mappingConfig.getMappingRules();
			DataStructureBean tgtDsd = mappingRules.getToDataStructure();
			
			// Analyse all Attributes and Measures in the TargetDSD looking for uncoded dimensions with
			// a Text Type of String with a max length
			List<AttributeBean> allAttributes = tgtDsd.getAttributes();
			for (AttributeBean attributeBean : allAttributes) {
				if (!attributeBean.hasCodedRepresentation() && attributeBean.getRepresentation() != null) {
					TextFormatBean tgtTf = attributeBean.getRepresentation().getTextFormat();
					if (TEXT_TYPE.STRING.equals(tgtTf.getTextType())) {
						BigInteger maxLength = tgtTf.getMaxLength();
						if (maxLength != null) {
							// This component may be modified
							if (attributeBean.getAttachmentLevel().equals(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION)) {
								obsAttrToModify.put(attributeBean.getId(), maxLength.intValue());
							} else {
								serAttrToModify.put(attributeBean.getId(), maxLength.intValue());
							}
						}
					}
				}
			}
			
			List<MeasureDimensionBean> allMeasures = tgtDsd.getMeasures();
			for (MeasureDimensionBean measureBean : allMeasures) {
				if (!measureBean.hasCodedRepresentation() && measureBean.getRepresentation() != null) {
					TextFormatBean tgtTf = measureBean.getRepresentation().getTextFormat();
					if (TEXT_TYPE.STRING.equals(tgtTf.getTextType())) {
						BigInteger maxLength = tgtTf.getMaxLength();
						if (maxLength != null) {
							// This component may be modified
							measuresToModify.put(measureBean.getId(), maxLength.intValue());
						}
					}
				}
			}
			
			proxy.startDataset(structures,header,datasetAttributes,annotations);
		}

		@Override
		public void writeKey(Keyable key) {
			if (serAttrToModify.isEmpty()) {
				proxy.writeKey(key);
				return;
			}
			
			List<KeyValue> newAttributes;
			if (serAttrToModify.isEmpty() ) {
				newAttributes = key.getAttributes();
			} else {
				newAttributes = new ArrayList<>();
				for (KeyValue kv : key.getAttributes()) {
					Integer maxLength = serAttrToModify.get(kv.getConcept());
					if (maxLength == null) {
						newAttributes.add(kv);
					} else {
						String newVal;
						if(NumberUtils.isParsable(kv.getCode())) {
							newVal = modifyItem(kv.getCode(), maxLength);
						} else {
							newVal = kv.getCode();
						}
						newAttributes.add(KeyValueImpl.getInstance(kv.getConcept(), newVal));
					}
				}
			}
			
			// Wrap the existing Key in an AttributableProxy
			Keyable newKey = new KeyableProxy(key, new AbstractAttributable(newAttributes));
			proxy.writeKey(newKey);
		}
		
		@Override
		public void writeObservation(Observation obs) {
			if (obsAttrToModify.isEmpty() && measuresToModify.isEmpty()) {
				proxy.writeObservation(obs);
				return;
			}
			
			List<KeyValue> newAttributes;
			if (obsAttrToModify.isEmpty() ) {
				newAttributes = obs.getAttributes();
			} else {
				newAttributes = new ArrayList<>();
				for (KeyValue kv : obs.getAttributes()) {
					Integer maxLength = obsAttrToModify.get(kv.getConcept());
					if (maxLength == null) {
						newAttributes.add(kv);
					} else {
						String newVal;
						if(NumberUtils.isParsable(kv.getCode())) {
							newVal = modifyItem(kv.getCode(), maxLength);
						} else {
							newVal = kv.getCode();
						}
						newAttributes.add(KeyValueImpl.getInstance(kv.getConcept(), newVal));
					}
				}
			}
			
			List<KeyValue> newMeasures;
			if (measuresToModify.isEmpty() ) {
				newMeasures = obs.getMeasures();
			} else {
				newMeasures = new ArrayList<>();
				for (KeyValue kv : obs.getMeasures()) {
					Integer maxLength = measuresToModify.get(kv.getConcept());
					if (maxLength == null) {
						newMeasures.add(kv);
					} else {
						String newVal;
						// Check the current value is a number
						if(NumberUtils.isParsable(kv.getCode())) {
							newVal = modifyItem(kv.getCode(), maxLength);
						} else {
							newVal = kv.getCode();
						}
						newMeasures.add(KeyValueImpl.getInstance(kv.getConcept(), newVal));
					}
				}
			}
		
			// Proxy the Observation with the Attributes and new Measures
			Observation measureProxy = new ObservationMeasureProxy(obs, newMeasures);
			AbstractAttributable attrProxy = new AbstractAttributable(newAttributes);
			proxy.writeObservation( new ObservationProxy(measureProxy, attrProxy) );
		}
		
		/**
		 * Potentially returns a new representation of the supplied value that will fit within the specified length
		 * @param originalValue
		 * @param maxLength
		 * @return
		 */
		private String modifyItem(String originalValue, int maxLength) {
			int length = originalValue.length();
			if (length <= maxLength) {
				return originalValue;
			}
			
			boolean isInteger = NumberUtils.isInteger(originalValue, true);
			// We know that the length is too long. If this is an Integer 3 characters will be added E+X to make
			// this value fit. If it's a Double, then a minimum of 1 character (the dot) MIGHT be needed to be added, although there may be
			// extra for E+X
			// Note that because Scientific Notation represents it as E+X, we are going to return it as EX. So for the
			// significant figures, we are using the value of 2 not 3
			int signifcantFigures = isInteger ?  length-2 : length-1;
			
			// May need to modify the length with a +1.
			// An Integer may end up with an E+X in it (remember the '+' will be dropped) so we need 1 more character for the 'E'
			// This is also the case where the the "Integer part" of a decimal is greater than the maxLength
			int maxLengthModifier = (isInteger || originalValue.indexOf('.') > maxLength) ? 1 : 0;
			
			String newValue = modifyToLength(originalValue, maxLength, maxLengthModifier, signifcantFigures);
	        // If the new value contains an E and a + remove the plus.
			if (newValue.indexOf('+') > -1) {
        		return newValue.replace("+", "");
        	}
			return newValue;
		}
		
		/**
		 * Returns a rounded value of the supplied value which must fit into the number of characters specified by 'maxLength'.
		 * The modifier is passed in, rather than added to 'maxLength' to give the error messages clarity.
		 * @param originalValue
		 * @param maxOriginalLength
		 * @param maxLengthModifier
		 * @param signifcantFigures
		 * @return
		 */
		public String modifyToLength(String originalValue, int maxOriginalLength, int maxLengthModifier, int signifcantFigures) {
			String newValue;
			int loopLimit = 0;
			int maxLengthModded = maxOriginalLength + maxLengthModifier;
		    while (true) {
		        NumberUtils.Format formatter = Format.get().sf(signifcantFigures).normalise(false).outputNotation(NotationStyle.SCIENTIFIC_NOTATION).roundMode(RoundingMode.HALF_UP);
		        newValue = NumberUtils.formatNumber(originalValue, formatter);
		        
		        // If the newValue will fit into the original maximum length (NOT the modded length) return it
		        if (newValue.length() <= maxOriginalLength) {
	        		return newValue;
		        }
		        
		        // If the newValue will fit into the modified length, if is scientific notation or a decimal, return it
		        // This check is to deal with the corner-case of where an Integer is too long to fit into the 'maxOriginalLength'
		        // so needs to become scientific notation
		        if (newValue.length() <= maxLengthModded && (newValue.contains("E") || newValue.contains("."))) {
	        		return newValue;
	        	}
		        
		        if (newValue.length() < maxLengthModded) {
	        		return newValue;
		        }
		        
		        if (signifcantFigures < 0 && newValue.equals(originalValue)) {
		        	// The supplied value can not be rounded into the specified length.
		        	throw new RuntimeException("Unable to round the value of " + originalValue + " using the max length of: " + maxOriginalLength);
		        }
		        
		        if (++loopLimit > 100) {
		        	// Something has gone seriously wrong. Abort this loop
		        	throw new RuntimeException("Unable to determine a rounded value for " + originalValue + " with max length of: " + maxOriginalLength +
		        			"  and significant figures of: " + signifcantFigures);
		        }
		        signifcantFigures--;
		    }
		}

		@Override
		public void close(FooterMessage... footer) {
			proxy.close(footer);
		}
	}

	/**
	 * Stores information about a row of data, regarding whether the row refers to data which states that
	 * there are Series or Observation Attributes, or if the data contains Observation information.
	 */
	public class DataRowProperties {
		boolean hasSeriesAttr;
		boolean hasObs;
		boolean hasObsAttr;
	}

	public class MappingProxyDataWriterEngine implements ISeriesObsDataWriterEngine {
		//Constructed State
		private DataMappingConfig mappingRequest;
		private MappingRules mappingRules; //Could have been flipped

		//Runtime State
		private IDatasetStructures sourceStructures;
		private IDatasetStructures mappedStructures;

		private DataStructureBean fromDSD;
		private DataStructureBean toDSD;
		private DataflowBean toDataflow;
		private DataflowBean fromDataflow;

		private Collection<DataValidationEngine> dataValidationEngines = Collections.emptyList();

		private Collection<String> sourceMeasureIds = Collections.emptyList();
		private Collection<String> sourceSeriesAttributeIds = Collections.emptyList();
		private Collection<String> sourceObsAttributeIds = Collections.emptyList();

		private boolean toTimeSeries;
		private Collection<String> targetDimensionIds = Collections.emptyList();
		private Collection<String> targetSeriesAttributeIds = Collections.emptyList();
		private Collection<String> targetObsAttributeIds = Collections.emptyList();
		private Collection<String> targetMeasureIds = Collections.emptyList();

		//Group
		private Set<String> groupOnlyAttributesTarget = Collections.emptySet();  //A set of attributes which can only be reported against a group (not a Dimension Group)
		private Map<String, String> groupAttributeIdToGroupName = Collections.emptyMap();
		private Map<String, List<String>> groupDimensions = Collections.emptyMap();
		private Map<String, List<String>> groupAttributeMap = Collections.emptyMap();
		private Map<String, List<String>> attributesForGroup = new HashMap<>(); //Group Id to list of attributes (for output datasets only)
		private Map<String, boolean[]> writtenGroups = new HashMap<>();  //Group Short Code to a true/false for each attribute to say if it has already been written FR-3439

		//Mapping Detail
		private boolean dsInfluencesSeries;  	//If true, one or more of the dataset attributes influences some part of the obs, in which case each obs that is mapped requires series information as well
		private boolean dsInfluencesObs;  		//If true, one or more of the dataset attributesinfluences some part of the obs, in which case each obs that is mapped requires series information as well
		private boolean seriesInfluencesObs;  	//If true, one or more of the series influences some part of the obs, in which case each obs that is mapped requires series information as well
		private boolean obsInfluencesSeries;  	//If true, one or more of the observations influences the target series

		//Mapped State
		private Map<String, String> lastSeriesRow;	//The last row that generated the last written series
		private boolean writtenKey; 				//True if observations were written for the last unmapped Series
		private Keyable lastWrittenKey;				//Keep a record of the last wriiten key so we don't double write the same key twice if 2 mappings map to the same key

		private Map<String, String> dsAttrBaseMap = new HashMap<>();  //The Dataset Attributes reported against the source dataset
		private Map<String, String> keyBaseMap = new HashMap<>(); 	  //The last Series Key and Series/Group attributes written (remember group attributes have been flattened into the Series)
		private Map<String, String> row = null;						  //The row to write


		private Map<SdmxPeriod, Keyable> keyByPeriod = new HashMap<>(); //Any other last mapped series keys which are only valid for a subset of periods
		private Keyable allPeriodsSeriesKey;  //the last mapped series key which is valid for all periods

		private InMemoryErrorHandler errorHandler = new InMemoryErrorHandler();
		private Map<SdmxPeriod, IDataRow> mappedSeriesObsMappings = new HashMap<>(); //A mapped series may contain output mappings which need to be applied to observations.

		private boolean startedTargetDataset;
		private boolean startedUnmappedDataset;
		private boolean startedUnmappedKey;
		private boolean writtenUnmappedObs;
		private boolean needToWriteTargetDataset;      // For subsequent Datasets after the first
		private boolean needToWriteUnmappedDataset;    // For subsequent Datasets after the first
		private HeaderBean header;
		private DatasetHeaderBean sourceDatasetHeader;
		private Keyable sourceKey;
		private Observation sourceObs;
		private DatasetHeaderBean mappedDatasetHeader;
		private AnnotationBean[] annotations;

		private IMappedRow seriesRow;
		private boolean hasGroupError = false;
		private boolean hasSeriesError = false;
		private List<String> createdGroups = new ArrayList<>();
		
		private boolean isDeleteMapping = false;

		public MappingProxyDataWriterEngine(DataMappingConfig mappingRequest) {
			this.mappingRequest = mappingRequest;
		}

		@Override
		public void writeHeader(HeaderBean header) {
			this.header = header;
		}

		@Override
		public void startDataset(IDatasetStructures sourceStructures, DatasetHeaderBean datasetHeader, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
			this.sourceStructures = sourceStructures;
			this.sourceDatasetHeader = datasetHeader;
			DataStructureBean dsd = sourceStructures.getDataStructure();
			mappingRules = mappingRequest.getMappingRules();
			boolean isMappingFrom = mappingRules.getFromDataStructure().equals(dsd);
			if(!isMappingFrom) {
				mappingRules = mappingRules.getReverseMapping();
			}
			
			this.dsAttrBaseMap = new HashMap<>();
			this.keyBaseMap = new HashMap<>();

			this.fromDSD = mappingRules.getFromDataStructure();
			this.toDSD = mappingRules.getToDataStructure();
			this.fromDataflow = mappingRules.getFromDataflow();
			if(fromDataflow != null) {
				toDataflow = isMappingFrom ? mappingRules.getToDataflow() : mappingRules.getFromDataflow();
			}
			this.toTimeSeries = toDSD.getTimeDimension() != null;
			this.mappedDatasetHeader = datasetHeader;
			if(datasetHeader != null && datasetHeader.getDataStructureReference() != null) {
				if(toTimeSeries) {
					//Output will be time series
					IURNSingle<? extends IDSDRelatedBean> toRef = toDataflow != null ? toDataflow.getURN() :toDSD.getURN();
					DatasetStructureReferenceBean dsStructtRef = new DatasetStructureReferenceBeanImpl(toRef);
					this.mappedDatasetHeader = datasetHeader.modifyDataStructureReference(dsStructtRef);
				}
				//TODO non time series output
			}
			
			this.isDeleteMapping = (datasetHeader != null && datasetHeader.getAction() == DATASET_ACTION.DELETE);

			mappedStructures = new DatasetStructures(toDSD, toDataflow, null, null);
			initValidators();
			initLists();
			initGroups();
			this.annotations = annotations;

			//Output Report
			if(this.mappingRequest.getReportDataWriterEngine() != null) {
				this.mappingRequest.getReportDataWriterEngine().writeMappingRules(mappingRules);
				this.mappingRequest.getReportDataWriterEngine().writeMappedStructures(sourceStructures, mappedStructures);
			}

			// Put any fixed Dataset Attribute values into the map
			if(datasetAttributes != null) {
				for(KeyValue kv : datasetAttributes.getAttributes()) {
					this.dsAttrBaseMap.put(kv.getConcept(), kv.getCode());
				}
			}

			// Set the flags to start a new dataset ONLY if a dataset has not been already written
			if (startedTargetDataset) {
				needToWriteTargetDataset = true;
			}
			if (startedUnmappedDataset) {
				needToWriteUnmappedDataset = true;
			}

			determineMappingInfluences(mappingRules);
			//Do not start the dataset until the first key is mapped as there may be dataset attributes derived from series attributes
		}

		@Override
		public void writeKey(Keyable key) {
			seriesRow = null;
			hasSeriesError = false;
			hasGroupError = false;
			flushKey();
			this.sourceKey = key;
			int mapSize = key.getKey().size() + key.getAttributes().size();
			if(this.dsInfluencesSeries) {
				mapSize += this.dsAttrBaseMap.size();
			}
			this.keyBaseMap = new HashMap<>(mapSize);
			this.row = keyBaseMap;

			addToMap(keyBaseMap, key.getKey());
			for(String seriesAttr : this.sourceSeriesAttributeIds) {
				String val = key.getAttributeValue(seriesAttr);
				val = val == null ? "" : val;
				keyBaseMap.put(seriesAttr, val);
			}

			if(this.dsInfluencesSeries || needToWriteTargetDataset || !startedTargetDataset) {
				keyBaseMap.putAll(this.dsAttrBaseMap);
			}
		}

		@Override
		public void writeObservation(Observation obs) {
			if(!seriesInfluencesObs && !obsInfluencesSeries && !writtenKey) {
				this.row = keyBaseMap;
				flushRow(true, false);
				writtenKey = true;
			}

			this.sourceObs = obs;
			writtenUnmappedObs = false;
			if(hasSeriesError) {
				writeToUnmappedDataWriterEngine();
				this.sourceObs = null;
				return;
			}
			this.row = seriesInfluencesObs || obsInfluencesSeries ? new HashMap<>(keyBaseMap) : new HashMap<>();
			if(this.dsInfluencesObs) {
				row.putAll(this.dsAttrBaseMap);
			}
			addToMap(row, obs.getAttributes());
			for(String seriesAttr : this.sourceObsAttributeIds) {
				String val = obs.getAttributeValue(seriesAttr);
				val = val == null ? "" : val;
				row.put(seriesAttr, val);
			}
			for(String measureId : sourceMeasureIds) {
				String measureValue = obs.getMeasureValues(measureId) != null ? obs.getMeasureCode(measureId) : "";
				measureValue = measureValue == null ? "" : measureValue;
				row.put(measureId, measureValue);
			}

			if(obs.getDimensionId() != null) {
				row.put(obs.getDimensionId(), obs.getDimensionValue());
			}

			flushRow(false, true);
			this.sourceObs = null;
		}

		@Override
		public void close(FooterMessage... footer) {
			flushKey();
			writeStartDataset(null);
			this.mappingRequest.close();
		}

		/**
		 * Initalise the validators
		 */
		private void initValidators() {
			DATASET_ACTION action = this.mappedDatasetHeader != null ? this.mappedDatasetHeader.getAction() : null;
			Set<DataValidatorFactory> dataValidators = mappingRequest.getDataValidatorFactories();
			if(!ObjectUtil.validCollection(dataValidators)) {
				return;
			}
			SdmxSuperBeanRetrievalManager superRetrieval = mappingRequest.getSuperbeanRetrievalManager();
			IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager = mappingRequest.getConstraintPrefixDetailRetreivalManager();
			DatasetInformation dsi = new DatasetInformationImpl(this.mappedDatasetHeader, mappedStructures, superRetrieval, constraintPrefixDetailRetreivalManager, action, null);

			if(ObjectUtil.validCollection(dataValidators)) {
				dataValidationEngines = new ArrayList<>(dataValidators.size());
				for(DataValidatorFactory factory : dataValidators) {
					// This Data Writer Engine should only validate with the DataValidationEngines:
					// ConstraintValidationEngine and DeepDataValidationEngine
					if (factory.getId().equals("Constraint") || factory.getId().equals("Representation") || factory.getId().equals("TimePeriodFormat")) {
						DataValidationEngine validationEngine = factory.createInstance(dsi);
						if(validationEngine != null) {
							dataValidationEngines.add(validationEngine);
						}
					}
				}
			}
		}

		/**
		 * Initialise the lists that help when constructing the mapped keys
		 */
		private void initLists() {
			this.targetDimensionIds = toDSD.getDimensionIds();
			this.targetSeriesAttributeIds = new ArrayList<>();
			this.targetObsAttributeIds = new ArrayList<>();
			this.targetMeasureIds = SdmxCollectionUtil.identifiablesIdList(toDSD.getMeasures());
			for(AttributeBean attribute : toDSD.getAttributes()) {
				switch(attribute.getAttachmentLevel()) {
					case DIMENSION_GROUP:
						targetSeriesAttributeIds.add(attribute.getId());
						break;
					case OBSERVATION:
						targetObsAttributeIds.add(attribute.getId());
						break;
				}
			}

			sourceSeriesAttributeIds = new ArrayList<>();
			sourceObsAttributeIds = new ArrayList<>();
			sourceMeasureIds = fromDSD.getMeasures().stream().map(e->e.getId()).collect(Collectors.toList());
			for(AttributeBean attribute : fromDSD.getAttributes()) {
				switch(attribute.getAttachmentLevel()) {
					case DIMENSION_GROUP:
					case GROUP:  //Group attributes have been collapsed into the series
						sourceSeriesAttributeIds.add(attribute.getId());
						break;

					case OBSERVATION:
						sourceObsAttributeIds.add(attribute.getId());
						break;
				}
			}

		}
		
		/**
		 * When the dataset changes, we need to know if information at a higher level (i.e. Series) influences the outputs at a lower level (i.e Observation)
		 * If this is true then we need to ensure that the mapping engine is passed higher level key values when it maps lower level information (i.e. pass all source Series values when mapping an source Observation)
		 */
		private void determineMappingInfluences(MappingRules mappingRules) {
			if(mappingRequest.isForceFlat()) {
				this.dsInfluencesSeries = true;
				this.dsInfluencesObs = true;
				this.seriesInfluencesObs = true;
				return;
			}
			this.dsInfluencesSeries = false;
			this.dsInfluencesObs = false;
			this.seriesInfluencesObs = false;

			if(fromDSD.getTimeDimension() == null) {
				this.seriesInfluencesObs = true;  //map everything as a row
			}
			
			Map<String, ATTRIBUTE_ATTACHMENT_LEVEL> sourceComponent2Level = getComponentLevels(fromDSD);
			Map<String, ATTRIBUTE_ATTACHMENT_LEVEL> targetComponent2Level = getComponentLevels(toDSD);

			Map<String, Set<IComponentMappingRules>> sourceToComp = mappingRules.getSingleMappingRules();
			for(String currentSourceComponent : sourceToComp.keySet()) {
				ATTRIBUTE_ATTACHMENT_LEVEL sourceLevel = sourceComponent2Level.get(currentSourceComponent);
				for(IComponentMappingRules rule : sourceToComp.get(currentSourceComponent)) {
					for(String targetComp : rule.getTargetComponents()) {
						ATTRIBUTE_ATTACHMENT_LEVEL targetLevel = rule.isTimeDependant() ? ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION :targetComponent2Level.get(targetComp);
						processSourceLevel2TargetLevel(sourceLevel, targetLevel);
					}
				}
			}
			for(IComponentMappingRules rule : mappingRules.getCombinationMappingRules()) {
				for(String currentSourceComponent : rule.getSourceComponents()) {
					ATTRIBUTE_ATTACHMENT_LEVEL sourceLevel = sourceComponent2Level.get(currentSourceComponent);
					for(String targetComp : rule.getTargetComponents()) {
						ATTRIBUTE_ATTACHMENT_LEVEL targetLevel = rule.isTimeDependant() ? ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION : targetComponent2Level.get(targetComp);
						processSourceLevel2TargetLevel(sourceLevel, targetLevel);
					}
				}
			}
			Map<String, Set<ITimeMapping>> timeMappingMap = mappingRules.getTimeMapping();
			for(String mapId : timeMappingMap.keySet()) {
				for(ITimeMapping timeMapping : timeMappingMap.get(mapId)) {
					ATTRIBUTE_ATTACHMENT_LEVEL sourceLevel = sourceComponent2Level.get(timeMapping.getSourceComponent());
					ATTRIBUTE_ATTACHMENT_LEVEL targetLevel = targetComponent2Level.get(timeMapping.getTargetComponent());
					processSourceLevel2TargetLevel(sourceLevel, targetLevel);
				}
			}

			ITimePeriodMapping timePeriodMappingMap = mappingRules.getTagetTimePeriodMapping();
			if (timePeriodMappingMap != null) {
				for(String aComp : timePeriodMappingMap.getSourceComponents()) {
					// DEV-2711: It's a TIME_PERIOD so source is against the OBSERVATION
					ATTRIBUTE_ATTACHMENT_LEVEL sourceLevel = ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION;//sourceComponent2Level.get(aComp);
					for (String tgtComp : timePeriodMappingMap.getTargetComponents()) {
						ATTRIBUTE_ATTACHMENT_LEVEL targetLevel = targetComponent2Level.get(tgtComp);
						processSourceLevel2TargetLevel(sourceLevel, targetLevel);
					}

				}
			}
		}

		/**
		 * @param source
		 * @param target
		 */
		private void processSourceLevel2TargetLevel(ATTRIBUTE_ATTACHMENT_LEVEL sourceLevel, ATTRIBUTE_ATTACHMENT_LEVEL targetLevel) {
			if(sourceLevel == null || targetLevel == null) {
				return;
			}
			switch(sourceLevel) {
				case DATA_SET:
					switch(targetLevel) {
						case DIMENSION_GROUP:
							dsInfluencesSeries = true;
							break;
						case OBSERVATION:
							dsInfluencesObs = true;
							break;
					}
				case DIMENSION_GROUP:
					switch(targetLevel) {
						case OBSERVATION:
							seriesInfluencesObs = true;
							break;
					}
					break;
				case OBSERVATION:
					if(targetLevel == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
						obsInfluencesSeries = true;
					}
					break;
			}
		}

		/**
		 * @param dsd
		 * @return map of DSD Component ID to the position in the DSD: OBSERVATION, DIMENISON_GROUP or DATASET
		 */
		private Map<String, ATTRIBUTE_ATTACHMENT_LEVEL> getComponentLevels(DataStructureBean dsd) {
			Map<String, ATTRIBUTE_ATTACHMENT_LEVEL> component2Level = new HashMap<>();
			addLevelToMap(dsd.getDimensionIds(), ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP, component2Level);
			// DEV-2711: Add the Time Dimension to the Map of "components to level"
			if (dsd.getTimeDimension() != null) {
				component2Level.put(dsd.getTimeDimension().getId(), ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
			}

			addLevelToMap(SdmxCollectionUtil.identifiablesIdList(dsd.getMeasures()), ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION, component2Level);
			for(AttributeBean attribute : dsd.getAttributes()) {
				switch(attribute.getAttachmentLevel()) {
					case DIMENSION_GROUP:
					case GROUP:
						component2Level.put(attribute.getId(), ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
						break;
					default:
						component2Level.put(attribute.getId(), attribute.getAttachmentLevel());
						break;
				}
			}
			return component2Level;
		}

		private void addLevelToMap(Collection<String> ids, ATTRIBUTE_ATTACHMENT_LEVEL level, Map<String, ATTRIBUTE_ATTACHMENT_LEVEL> component2Level) {
			for(String id : ids) {
				component2Level.put(id, level);
			}
		}

		private void addToMap(Map<String, String> kvMap, List<KeyValue> kvs) {
			for(KeyValue kv : kvs) {
				kvMap.put(kv.getConcept(), kv.getCode());
			}
		}

		/**
		 * Flushes the series key if there are no observations written for the series
		 *
		 * Flush key is called if there is a new series key to map, or this writer is being closed
		 */
		private void flushKey() {
			/**
			 * If there is row data, and the series key was never written, flush the row
			 */
			if(this.row != null && !writtenKey) {
				if (!seriesInfluencesObs && !obsInfluencesSeries) {
					flushRow(true, true);
				} else {
					// This will be called only when a writeKey is called after another
					// writeKey and no writeObs has been called between the writeKeys
					// Sets all the observation attributes and measures to empty strings
					// and updates the row with that information.
					this.row = new HashMap<>(keyBaseMap);
					if(this.dsInfluencesObs) {
						row.putAll(this.dsAttrBaseMap);
					}
					for(String obsAttrId : this.sourceObsAttributeIds) {
						row.put(obsAttrId, "");
					}
					for(String measureId : sourceMeasureIds) {
						row.put(measureId, "");
					}
					flushRow(false, true);
				}
			}
			
			if(!this.keyByPeriod.isEmpty()) {
				this.keyByPeriod = new HashMap<>();
			}
			if(!this.mappedSeriesObsMappings.isEmpty()) {
				this.mappedSeriesObsMappings = new HashMap<>();
			}
			this.startedUnmappedKey = false;
			this.writtenKey = false;
			this.allPeriodsSeriesKey = null;
			this.lastSeriesRow = new HashMap<>();
		}

		/**
		 * Builds the full row for reporting purposes, recombines the series, dataset attributes, and obs information
		 * @return
		 */
		private IDataRow getFullRow() {
			if(this.mappingRequest.getReportDataWriterEngine() != null) {
				//Build full row for reporting purposes
				Map<String, String> inputRow = new HashMap<>(this.row);
				if(!this.seriesInfluencesObs) {
					inputRow.putAll(this.keyBaseMap);
				}
				if(!this.dsInfluencesSeries && !this.dsInfluencesObs) {
					inputRow.putAll(this.dsAttrBaseMap);
				}
				return new DataRow(sourceStructures, inputRow);
			}
			return null;
		}


		/**
		 * @param isSeries if this is mapping only a series key and not any observation information,
		 * this method will need to capture any observation level outputs that will need to be augmented with
		 * subsequent observation level mappings for this series
		 * @param writeReport true if this is a series with no obs, or an obs
		 */
		private void flushRow(boolean isSeries, boolean writeReport) {
			if(this.row == null) {
				return;
			}
			
			//Flushes the row for mapping
			IMappedRow mappedRow = mappingEngine.mapValues(this.mappingRules, new DataRow(mappedStructures, this.row));
			if(isSeries) {
				seriesRow = mappedRow;
			}
			IDataRow inputRowForReporting = getFullRow();

			if(mappedRow.getMappedPeriods().isEmpty()) {
				writeToUnmappedDataWriterEngine();
				if(writeReport) {
					writeUnmapped(inputRowForReporting, new DataRow(mappedStructures, Collections.emptyMap()), SdmxPeriodImpl.ALL_PERIODS, mappedRow.getUnmappedComponents());
				}
			} else if(ObjectUtil.validCollection(mappedRow.getUnmappedComponents())) {
				if(isSeries) {
					this.hasSeriesError = true;
				}
				writeToUnmappedDataWriterEngine();
				//Always write the report, if it is a series no obs will be written
				//if it is an obs the write report would be true anyway
				for(SdmxPeriod period : mappedRow.getMappedPeriods()) {
					for(IDataRow outputRow : mappedRow.getMappedValues(period)) {
						writeUnmapped(inputRowForReporting, outputRow, period, mappedRow.getUnmappedComponents());
					}
				}

			} else {
				for(SdmxPeriod period : mappedRow.getMappedPeriods()) {
					for(IDataRow outputRow : mappedRow.getMappedValues(period)) {
						Map<String, String> mappedRowMap = outputRow.getRowData();
						
						if (isDeleteMapping) {
							// This is a delete mapping so determine which values should be excluded, based on the input row.
							DataRowProperties inputRowProps = createDataRowProperties(this.row, this.fromDSD);
							Set<String> exclusionValues = determineExclusionItems(inputRowProps);

							if (!exclusionValues.isEmpty()) {
								// Remove the excluded values from the current mapping
								Map<String, String> mapCopy = new HashMap<>();
								for (Map.Entry<String, String> entry : mappedRowMap.entrySet()) {
									String key = entry.getKey();
									if (!exclusionValues.contains(key)) {
										mapCopy.put(key, entry.getValue());
									}
								}
								mappedRowMap = mapCopy;
							}
							
							// Obtain the properties of the mapped row and ensure that these match those of the input row.
							// i.e. if series attr were on the input, then there must be series attr in the mapped output
							// If there is not, the row is considered unmapped
							DataRowProperties outputRowProps = createDataRowProperties(mappedRowMap, this.toDSD);
							if (inputRowProps.hasSeriesAttr != outputRowProps.hasSeriesAttr ||
								inputRowProps.hasObs != outputRowProps.hasObs ||
								inputRowProps.hasObsAttr != outputRowProps.hasObsAttr) {
								 writeToUnmappedDataWriterEngine();
								 continue;
							}
						}
						
						if(isSeries) {
							Map<String, String> mappedObsValues = null;
							// This only needs to be done if source series can generate obs attributes/measures
							if (this.seriesInfluencesObs) {
								for(String obsAttr : this.targetObsAttributeIds) {
									String obsVal = mappedRowMap.get(obsAttr);
									if(obsVal != null) {
										if(mappedObsValues == null) {
											mappedObsValues = new HashMap<>();
										}
										mappedObsValues.put(obsAttr, obsVal);
									}
								}
							}
							//TODO What about the Time Dimension?
							for(String obsAttr : this.targetMeasureIds) {
								String obsVal = mappedRowMap.get(obsAttr);
								if(obsVal != null) {
									if(mappedObsValues == null) {
										mappedObsValues = new HashMap<>();
									}
									mappedObsValues.put(obsAttr, obsVal);
								}
							}
							if(mappedObsValues != null) {
								this.mappedSeriesObsMappings.put(period, new DataRow(null, mappedObsValues));
							}
						}
						boolean hasSeriesKey = verifyKey(outputRow);

						List<String> outputGroupAttributes = getGroupAttributes(mappedRowMap, isSeries);
						List<String> outputGroups = Collections.emptyList();

						if(!outputGroupAttributes.isEmpty()) {
							mappedRowMap = new HashMap<>(mappedRowMap);
							outputGroups = getMatchedGroups(mappedRowMap, outputGroupAttributes);
						}

						//If the output mapping contains a partial series key, then it shows the mapping of the values failed

						if(!writtenKey &&  !ObjectUtil.validCollection(outputGroups) && !hasSeriesKey) {
							//There are no groups, and there is no series key, this is an unmapped row
							writeToUnmappedDataWriterEngine();
							if(writeReport) {
								writeUnmapped(inputRowForReporting, outputRow, period, mappedRow.getUnmappedComponents());
							}
						} else {
							boolean wasMapped = false;
							boolean hasObsError = false;


							//The row needs to be split into a Group Key, Series Key and Observation
							for(String groupId : outputGroups) {
								List<String> groupDimensions = this.groupDimensions.get(groupId);
								List<String> groupAttributes = this.groupAttributeMap.get(groupId);
								List<KeyValue> key = KeyValueUtil.toKeyValues(mappedRowMap, groupDimensions, false);
								List<KeyValue> attributes = KeyValueUtil.toKeyValues(mappedRowMap, groupAttributes, false);
								if(!attributes.isEmpty()) {  //No point in writing a group if it is not reporting any attributes
									Keyable groupKey = new KeyableImpl(toDataflow, toDSD, groupId, key, attributes);
									hasGroupError = !writeMappedKey(groupKey, mappedRowMap);
									wasMapped = true;
									if(!hasGroupError) {
										mappedRowMap = new HashMap<>(mappedRowMap);
										for(KeyValue currentGA : attributes) {
											//Remove the group attributes so it does not output it for the series as well
											//TestMappingDataSets.testImplicitUnlessOtherwiseSpecified
											mappedRowMap.remove(currentGA.getConcept());
										}
									}
								}
							}
							if(hasSeriesKey) {
								if(isNewSeries(mappedRowMap)) {
									//Has the series key changed?
									List<KeyValue> key = KeyValueUtil.toKeyValues(mappedRowMap, this.targetDimensionIds, false);
									List<KeyValue> attributes = KeyValueUtil.toKeyValues(mappedRowMap, this.targetSeriesAttributeIds, false);
									Keyable seriesKey = new KeyableImpl(toDataflow, toDSD, null, key, attributes);
									hasSeriesError = !writeMappedKey(seriesKey, mappedRowMap);
									wasMapped = true;
									lastSeriesRow = mappedRowMap;
								}
								//The series may not be new, but the validity period might be
								if(!hasSeriesError) {
									if(period.isAllPeriods()) {
										this.allPeriodsSeriesKey = lastWrittenKey;
									} else {
										this.keyByPeriod.put(period, lastWrittenKey);
									}
								}
							}

							Observation mappedObs = getMappedObservation(mappedRowMap);
							if(mappedObs != null) {
								//An Observation with no series - indication that the series failed
								if(!hasError(mappedObs)) {
									mappingRequest.getMappedDataWriterEngine().writeObservation(mappedObs);
								} else {
									hasObsError = true;
								}
								wasMapped = true;  //TODO Should this write to the unmapped data writer - the original observation presumably (what is there was no obs?)
							}
							boolean hasError = hasGroupError || hasSeriesError || hasObsError;
							/**
							 * Key/Obs was not written due to either a validation error, or because the mapping failed
							 */
							if(hasError || !wasMapped) {
								writeToUnmappedDataWriterEngine();
							}

							if(mappingRequest.getReportDataWriterEngine() != null && (writeReport || hasSeriesError || hasGroupError)) {
								outputRow = mergeWithSeriesRows(outputRow, period);
								if(wasMapped) {
									mappingRequest.getReportDataWriterEngine().writeMappedRow(inputRowForReporting, outputRow, period, errorHandler.getErrors());
								} else {
									mappingRequest.getReportDataWriterEngine().writeUnMappedRow(inputRowForReporting, outputRow, period, mappedRow.getUnmappedComponents());
								}
							}
						}
					}
				}
			}
			this.row = null;
		}
		
		/**
		 * Analyse a row and evaluate it against the supplied DSD, to create a properties object that states
		 * whether the row has Series Attr, Obs Attr or Observation
		 * @param rowData the row to analyse
		 * @param dsd the Data Structure the row should be analysed against
		 * @return a DataRowProperties
		 */
		private DataRowProperties createDataRowProperties(Map<String, String> rowData, DataStructureBean dsd) {
			DataRowProperties rowProps = new DataRowProperties();
			
			for (String id : rowData.keySet()) {
				if (rowData.get(id) == null || rowData.get(id).equals("")) {
					continue;
				}
				
				ComponentBean component = dsd.getComponent(id);
				switch (component.getType()) {
				case DIMENSION:
					break;
				case MEASURE:
					rowProps.hasObs = true;
					break;
				case ATTRIBUTE:
					AttributeBean attr = dsd.getAttribute(id);
					if (attr != null) {
						if (attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION ) {
							rowProps.hasObsAttr = true;
						} else if (attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
							rowProps.hasSeriesAttr = true;
						}
					}
					break;
				}
			}
			
			return rowProps;
		}
		
		/**
		 * Creates a Set of "component id"s that should be excluded from the output based on the input. This is required for "delete mappings".
		 * A data row will have been analysed and a DataRowProperties object is supplied as a parameter which represents that row.
		 * This properties object states if the row (and this will have been the input row) has series, series attr and obs attr.
		 * The target DSD is queried for its series and obs attr and if the input row had the equivalent, then the components will be included in the list of values to exclude.
		 * Also any fixed value mappings that refer to attributes, the component in the target DSD, will be added to the exclusion set.
		 * @param rowProps
		 * @return a Set of Strings, where each value is a component ID in the target DSD. This may be an empty Set and will not be null.
		 */
		private Set<String> determineExclusionItems(DataRowProperties rowProps) {
			Set<String> exclusionValues = new HashSet<>();
			
			DataStructureBean tgtDsd = this.toDSD;
			if (!rowProps.hasObsAttr) {
				// All Obs Attributes should be excluded
				exclusionValues.addAll(tgtDsd.getObservationAttributes().stream() .map(AttributeBean::getId).collect(Collectors.toList()));
			}
			if (!rowProps.hasObs) {
				// All Measures should be excluded
				exclusionValues.addAll(tgtDsd.getMeasures().stream() .map(MeasureDimensionBean::getId).collect(Collectors.toList()));
			}
			if (!rowProps.hasSeriesAttr) {
				// Exclude all series attributes
				exclusionValues.addAll(tgtDsd.getSeriesAttributes(null).stream() .map(AttributeBean::getId).collect(Collectors.toList()));
			}
			
			// Add to the exclusion list, any Fixed Values but only those against an attribute
			Map<String, String> fixedValues = mappingRules.getFixedValues();
			for (String id : fixedValues.keySet()) {
				ComponentBean component = this.toDSD.getComponent(id);
				if (component.getType().equals(COMPONENT_TYPE.ATTRIBUTE)) {
					exclusionValues.add(id);
				}
			}
			
			return exclusionValues;
		}

		/**
		 * Writes the source Key and Observation as unmapped
		 */
		private void writeToUnmappedDataWriterEngine() {
			if(this.sourceObs != null) {
				writeUnMappedObs();
			} else {
				writeUnMappedKey();
			}
		}

		private void startUnmappedDataset() {
			mappingRequest.getUnmappedDataWriterEngine().writeHeader(this.header);
			mappingRequest.getUnmappedDataWriterEngine().startDataset(sourceStructures, sourceDatasetHeader, null, annotations);
			startedUnmappedDataset = true;
		}

		private IDataRow mergeWithSeriesRows(IDataRow outputRow, SdmxPeriod period) {
			if(seriesRow == null) {
				return outputRow;
			}
			for(SdmxPeriod seriesPeriod : seriesRow.getMappedPeriods()) {
				if(period.isInPeriod(seriesPeriod)) {
					List<IDataRow> rows = seriesRow.getMappedValues(seriesPeriod);
					Map<String, String> newRow = new HashMap<>(outputRow.getRowData());
					Map<String, Set<String>> multiValues = new HashMap<>(outputRow.getMultiValueData());
					for(IDataRow row : rows) {
						if(row == outputRow) {
							return row;
						}
						newRow.putAll(row.getRowData());
						Map<String, Set<String>> seriesMultiValues = outputRow.getMultiValueData();
						for(String seriesComp : seriesMultiValues.keySet()) {
							Set<String> values = seriesMultiValues.get(seriesComp);
							Set<String> existing = multiValues.get(seriesComp);
							if(existing == null) {
								existing = values;
							} else {
								existing = new HashSet<>(existing);
								existing.addAll(values);
							}
							multiValues.put(seriesComp, values);
						}
					}
					return new DataRow(outputRow.getDatasetStructures(), newRow, multiValues, null, null);
				}
			}
			return outputRow;
		}

		private void writeUnMappedKey() {
			if(mappingRequest.getUnmappedDataWriterEngine() == null) {
				return;
			}

			if(!startedUnmappedDataset) {
				startUnmappedDataset();
				needToWriteUnmappedDataset = false;
			} else {
				if (needToWriteUnmappedDataset) {
					if (mappedStructures != null) {
						mappingRequest.getUnmappedDataWriterEngine().startDataset(sourceStructures, sourceDatasetHeader, null, annotations);
					}
					needToWriteUnmappedDataset = false;
				}
			}

			// Check to see if this.sourceKey contains group attributes
			// If it does , extract the Group information
			if (groupDwe.hasWrittenGroups()) {
				extractGroupsFromKey();
			}

			mappingRequest.getUnmappedDataWriterEngine().writeKey(this.sourceKey);
			this.startedUnmappedKey = true;
		}

		/**
		 * Check the current sourceKey to see if it contains group information
		 */
		private void extractGroupsFromKey() {
			List<AttributeBean> groupAttributes = fromDSD.getGroupAttributes();

			List<KeyValue> serAttributes = new ArrayList<>(this.sourceKey.getAttributes());
			Map <String, List<KeyValue>> grpIdToAttr = new HashMap<>();

			for (AttributeBean groupAttr : groupAttributes) {
				KeyValue anAttr = this.sourceKey.getAttribute(groupAttr.getId());
				if (anAttr != null) {
					String groupId = groupAttr.getAttachmentGroup();
					CollectionUtil.addToMappedList(grpIdToAttr, groupId, anAttr);
					serAttributes.remove(anAttr);
				}
			}

			if (grpIdToAttr.keySet().isEmpty()) {
				return;
			}

			for(String groupId: grpIdToAttr.keySet()) {
				List<KeyValue> grpAttributes = grpIdToAttr.get(groupId);

				List<KeyValue> gKeys = new ArrayList<>();
				GroupBean aGrp = fromDSD.getGroup(groupId);
				List<String> dimensionRefs = aGrp.getDimensionRefs();
				for (String aDim : dimensionRefs) {
					gKeys.add( 	this.sourceKey.getKeyValue(aDim) );
				}

				Keyable groupKey = KeyableImpl.groupKey(this.sourceKey.getDataflow(), this.sourceKey.getDataStructure(), groupId, gKeys, grpAttributes);
				String grpShortKey = groupKey.getShortCode();
				if (!createdGroups.contains(grpShortKey)) {
					// Group has not been previously written
					createdGroups.add(grpShortKey);
					mappingRequest.getUnmappedDataWriterEngine().writeKey(groupKey);
				}

			}
			// Update the sourceKey so it doesn't have the group information
			this.sourceKey = KeyableImpl.seriesKey(this.sourceKey.getDataflow(), this.sourceKey.getDataStructure(), this.sourceKey.getKey(), serAttributes, this.sourceKey.getAnnotations());
		}

		private void writeUnMappedObs() {
			if(mappingRequest.getUnmappedDataWriterEngine() != null && !writtenUnmappedObs) {
				if(!this.startedUnmappedKey) {
					writeUnMappedKey();
				}
				mappingRequest.getUnmappedDataWriterEngine().writeObservation(this.sourceObs);
				writtenUnmappedObs = true;
			}
		}

		private boolean writeMappedKey(Keyable key, Map<String, String> mappedRowMap) {
			if(hasError(key)) {
				return false;  //TODO Should this write to the unmapped data writer - the original series key presumably
			}
			if(mappingRequest.getMappedDataWriterEngine() != null) {
				writeStartDataset(mappedRowMap);
				if(lastWrittenKey != null) {
					if(lastWrittenKey.equals(key)) {
						return true;
					}
				}
				mappingRequest.getMappedDataWriterEngine().writeKey(key);
				lastWrittenKey = key;
			}
			return true;

		}

		/**
		 * Calls startDataset (and also writes the header) only if they have not been written already.
		 * DEV-2261: Required so that on closing the mapped dataset, if nothing mapped, then a dataset is created rather than a blank file.
		 */
		private void writeStartDataset(Map<String, String> mappedRowMap) {
			if (startedTargetDataset && !needToWriteTargetDataset) {
				return;
			}
			if(mappingRules == null) {
				return;
			}

			// Reset the lastWrittenKey
			lastWrittenKey = null;

			List<KeyValue> datasetAttributes = KeyValueUtil.toKeyValues(mappingRules.getDatasetAttributes());
			mapDatasetAttributes(mappedRowMap, datasetAttributes);
			
			IDatasetAttributes dsAttrs = new DatasetAttributes(datasetAttributes, annotations);
			if (startedTargetDataset && needToWriteTargetDataset) {
				
				if (mappedStructures != null) {
					mappingRequest.getMappedDataWriterEngine().startDataset(mappedStructures, mappedDatasetHeader, dsAttrs);
				}
				needToWriteTargetDataset = false;
				return;
			}
			
			if (header != null) {
				mappingRequest.getMappedDataWriterEngine().writeHeader(header);
			}
			if (mappedStructures != null) {
				mappingRequest.getMappedDataWriterEngine().startDataset(mappedStructures, mappedDatasetHeader, dsAttrs);
			}
			startedTargetDataset = true;
		}

		/**
		 * For each of the mappedRows, add to the List of datasetAttributes any mapped values
		 * @param mappedRowMap a map of Component IDs to a value
		 * @param datasetAttributes a KeyValue List of Dataset Attributes
		 */
		private void mapDatasetAttributes(Map<String, String> mappedRowMap, List<KeyValue> datasetAttributes) {
			if (mappedRowMap == null) {
				return;
			}
			
			// For each of the target Dataset Attributes, add any mapped values
			for(AttributeBean dsAttr : toDSD.getDatasetAttributes()) {
				String mappedValue = mappedRowMap.get(dsAttr.getId());
				if(mappedValue != null) {
					datasetAttributes.add(KeyValueImpl.getInstance(dsAttr.getId(), mappedValue));
				}
			}
		}

		private boolean hasError(Keyable key) {
			errorHandler.resetState();
			for(DataValidationEngine dve : dataValidationEngines) {
				dve.validateKey(key, errorHandler);
			}
			return errorHandler.hasError();
		}

		private boolean hasError(Observation key) {
			errorHandler.resetState();
			for(DataValidationEngine dve : dataValidationEngines) {
				dve.validateObs(key, errorHandler);
				dve.finishedObs(errorHandler);
			}
			return errorHandler.hasError();
		}

		private Observation getMappedObservation(Map<String, String> mappedRow) {
			String dimensionId = toTimeSeries ? DimensionBean.TIME_DIMENSION_FIXED_ID : null;
			String dimensionValue = toTimeSeries ? mappedRow.get(DimensionBean.TIME_DIMENSION_FIXED_ID) : null;

			if(toTimeSeries && dimensionValue == null) {
				return null;
			}

			Keyable key = getLastMappedKey(dimensionValue);
			if(key == null) {
				return null;  //No point in checking the mapped values as this observation has no corresponding series key
			}

			List<KeyValue> attributes = KeyValueUtil.toKeyValues(mappedRow, this.targetObsAttributeIds, false);
			List<KeyValue> measures = KeyValueUtil.toKeyValues(mappedRow, this.targetMeasureIds, false);
			//Map<String, String> measures = populateMeasureMap(mappedRow, null);
			
			// If the Mapped Series has mappings that need to be applied to the Output, add them here
			if(ObjectUtil.validMap(this.mappedSeriesObsMappings)) {
				Date obsTime = dimensionValue != null ? SdmxDateImpl.getSdmxDate(dimensionValue).getDate() : null;
				for(SdmxPeriod period : this.mappedSeriesObsMappings.keySet()) {
					if(dimensionValue == null || period.isInPeriod(obsTime)) {
						IDataRow row = this.mappedSeriesObsMappings.get(period);

						mappedRow = row.getRowData();
						
						// Update the List of attributes with any attr values stated in the mappedRow
						// Under certain conditions this can result in KeyValues with the same ID,
						// so it is important not to add duplicate Attributes
						List<KeyValue> keyValuesToAdd = KeyValueUtil.toKeyValues(mappedRow, this.targetObsAttributeIds, false);
						Set<String> uniqueAttributeIds = attributes.stream().map(KeyValue::getConcept).collect(Collectors.toSet());
						for (KeyValue aKeyValue : keyValuesToAdd) {
							// Only add to the List of attributes, if the ID is not already present
							if (!uniqueAttributeIds.contains(aKeyValue.getConcept())) {
								attributes.add(aKeyValue);
							} else {
								// NOTE: Could attributes with different values be merged into a single entry, with the values for both?
								// E.g. CONF_STATUS has values of both 'A' and 'B'
							}
						}
						
						measures.addAll(KeyValueUtil.toKeyValues(mappedRow, this.targetMeasureIds, false));
						//measures = populateMeasureMap(mappedRow, measures);
						break;
					}
				}
			}
			
			if(measures != null || ObjectUtil.validCollection(attributes) || dimensionValue != null) {
				return new ObservationImpl(getLastMappedKey(dimensionValue), dimensionId, dimensionValue, measures, attributes, null);
			}
			return null;
		}

		private Keyable getLastMappedKey(String timeValue) {
			if(this.allPeriodsSeriesKey != null) {
				return this.allPeriodsSeriesKey;
			}
			Date obsTime = timeValue != null ? SdmxDateImpl.getSdmxDate(timeValue).getDate() : null;
			for(SdmxPeriod period : this.keyByPeriod.keySet()) {
				if(timeValue == null || period.isInPeriod(obsTime)) {
					return this.keyByPeriod.get(period);
				}
			}
			return null;
		}

		private Map<String, String> populateMeasureMap(Map<String, String> mappedRow, Map<String, String> measures) {
			for(String measureId : this.targetMeasureIds) {
				String mappedValue = mappedRow.get(measureId);
				if(mappedValue != null) {
					if(measures == null) {
						measures = new HashMap<>(this.targetMeasureIds.size());
					}
					measures.put(measureId, mappedValue);
				}
			}
			return measures;
		}

		/**
		 * @param rowMap
		 * @return true if the new rowMap contains a new series key, or new series attributes
		 */
		private boolean isNewSeries(Map<String, String> rowMap) {
			if(lastSeriesRow == null) {
				return true;
			}
			if(hasMapDiffs(rowMap, this.targetDimensionIds)) {
				return true;
			}
			if(hasMapDiffs(rowMap, this.targetSeriesAttributeIds)) {
				return true;
			}
			return false;
		}

		/**
		 * @param rowMap
		 * @return true if the new rowMap contains a new series key, or new series attributes
		 */
		private boolean hasMapDiffs(Map<String, String> rowMap, Collection<String> ids) {
			for(String currentId : ids) {
				if(isNewMapValue(lastSeriesRow, rowMap, currentId)) {
					return true;
				}
			}
			return false;
		}

		private boolean isNewMapValue(Map<String, String> map1, Map<String, String> map2, String component) {
			return !ObjectUtil.equivalent(map1.get(component), map2.get(component));
		}

		/**
		 * @param values
		 * @return true if the values map contains a value for each dimension of the DSD
		 */
		private boolean verifyKey(IDataRow row) {
			return verifyKey(row.getRowData(), this.targetDimensionIds);
		}

		/**
		 * @param values
		 * @return true if the values map contains a value for each of the specified dimensions
		 */
		private boolean verifyKey(Map<String, String> values, Collection<String> dimensionCollection) {
			for(String dimId : dimensionCollection) {
				if(values.get(dimId) == null) {
					return false;
				}
			}
			return true;
		}

		/**
		 * Writes the input data key that does not have a corresponding output key
		 * @param inputRow
		 * @param mappedValues the actual values that were mapped (and did not result in a full key)
		 */
		private void writeUnmapped(IDataRow inputRow, IDataRow outputRow, SdmxPeriod validityPeriod, Set<IComponentMapping> unmappedComponents) {
			if(mappingRequest.getReportDataWriterEngine() != null) {
				outputRow = mergeWithSeriesRows(outputRow, validityPeriod);
				mappingRequest.getReportDataWriterEngine().writeUnMappedRow(inputRow, outputRow, validityPeriod, unmappedComponents);
			}
		}

		private void initGroups() {
			writtenGroups = new HashMap<>();
			if(ObjectUtil.validCollection(toDSD.getGroups())) {
				groupDimensions = new HashMap<>();
				groupAttributeIdToGroupName = new HashMap<>();
				groupAttributeMap = new HashMap<>();

				for(GroupBean group : toDSD.getGroups()) {
				    List<AttributeBean> groupAttributes = toDSD.getGroupAttributes(group.getId(), true);
				    List<String> groupAttributeIds = new ArrayList<>();
				    for(AttributeBean attr : groupAttributes) {
				        if(attr.getAttachmentGroup() == null) {
				            continue;
				        }
				        groupAttributeIds.add(attr.getId());
				    }
				    if(groupAttributeIds.isEmpty()) {
				        continue;
				    }
					String groupId = group.getId();
					groupDimensions.put(groupId, group.getDimensionRefs());

					for(String attrId : groupAttributeIds) {
						groupAttributeIdToGroupName.put(attrId, groupId);
					}
					groupAttributeMap.put(groupId, groupAttributeIds);
					attributesForGroup.put(groupId, groupAttributeIds);
				}
				this.groupOnlyAttributesTarget = new HashSet<>();
				for(AttributeBean attributeBean : toDSD.getGroupAttributes()) {
					this.groupOnlyAttributesTarget.add(attributeBean.getId());
				}
			}
		}

		/**
		 * Checks for group attributes in the mapped output - if a group attributes are present and the group key is complete
		 * then the group ID is added to the return list.  If a group attribute is present but it does not contain a full group key
		 * OR the all the group attributes have already been reported then it will not be written.  If group Attributes have already been reported
		 * they will be added to the remove components set
		 *
		 * @param singleRowValues
		 * @param excludeDimensionGroups if true, it will not include group attributes if they are also in a dimension group
		 * @return list of groups that this row contains information for
		 */
		private List<String> getMatchedGroups(Map<String, String> singleRowValues, List<String> groupAttributes) {
			List<String> returnList = null;
			//If the output mapping contains group attributes but no group dimensions, remove the group attribute
			Set<String> processedGroups = null;
			Set<String> removeComponents = new HashSet<>();
			for(String groupAttrId : groupAttributes) {
				String groupId = groupAttributeIdToGroupName.get(groupAttrId);
				if(processedGroups != null && processedGroups.contains(groupId)) {
					continue;
				}
				if(processedGroups == null) {
					processedGroups = new HashSet<>();
				}
				processedGroups.add(groupId);
				if(verifyGroup(groupId, singleRowValues, removeComponents)) {
					if(returnList == null) {
						returnList = new ArrayList<>();
					}
					returnList.add(groupId);
				} else {
					for(String removeGroupAttr : groupAttributeMap.get(groupId)) {
						removeComponents.add(removeGroupAttr);
					}
				}
			}
			for(String removeComponent : removeComponents) {
				singleRowValues.remove(removeComponent);
			}
			return returnList == null ? Collections.emptyList() : returnList;
		}

		/**
		 *
		 * @param rowMap
		 * @param excludeDimensionGroups if true, it will not include group attributes if they are also in a dimension group
		 * @return list of group attributes which have reported values in the row
		 */
		private List<String> getGroupAttributes(Map<String, String> rowMap, boolean excludeDimensionGroups) {
			Set<String> toCheckSet = excludeDimensionGroups ? groupOnlyAttributesTarget : groupAttributeIdToGroupName.keySet();
			List<String> returnList = null;
			for(String groupAttrId : toCheckSet) {
				if(rowMap.containsKey(groupAttrId)) {
					if(returnList == null) {
						returnList = new ArrayList<>(toCheckSet.size());
					}
					returnList.add(groupAttrId);
				}
			}
			return returnList == null ? Collections.emptyList() : returnList;
		}

		/**
		 * Verifies all the group dimensions exist for the group, and the group attributes have not already been reported,
		 * if the group attribute has been reported, they are removed from the mapped values, if no group attributes are left, false is returned
		 * @param groupId
		 * @param values
		 * @param removeComponents Component IDs are added to this set if they have already been written for the Group Key
		 * @return true if all the group dimensions exist and there is at least 1 unreported group attribute for the group key
		 */
		private boolean verifyGroup(String groupId, Map<String, String> values, Set<String> removeComponents) {
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(String groupDim : this.groupDimensions.get(groupId)) {
				String groupVal = values.get(groupDim);
				if(groupVal == null) {
					return false;
				}
				sb.append(concat+groupVal);
				concat = ":";
			}
			String shortCode = sb.toString();
			boolean[] writtenAttributes = this.writtenGroups.get(shortCode);
			List<String> groupAttrIds = attributesForGroup.get(groupId);

			//Skip group if the group has been written - this can be undone in the next loop
			boolean hasAttributes = false;
			if(writtenAttributes == null) {
				hasAttributes = true;
				writtenAttributes = new boolean[groupAttrIds.size()];
				writtenGroups.put(shortCode, writtenAttributes);
			}
			int i=0;
			for(String attrId : groupAttrIds) {
				if(writtenAttributes[i]) {
					removeComponents.add(attrId);
				} else {
					writtenAttributes[i] = values.containsKey(attrId);
					hasAttributes = true;
				}
				i++;
			}
			return hasAttributes;
		}
	}
}
