package io.sdmx.core.data.api.model.dataset;

import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Formats an observation's measure value based on formatting rules
 */
public interface IObservationValueFormatter {

	/**
	 * @param obs
	 * @param measure the measure to format
	 * @return the formatted measure value
	 */
	String getObservationValue(Observation obs, String measure);
	
}
