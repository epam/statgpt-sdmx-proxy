package io.sdmx.core.data.manager;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.RemovalCause;

import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.api.engine.validate.IMetricsWriterEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.manager.DataLoadManager;
import io.sdmx.core.data.api.manager.DataValidationManager;
import io.sdmx.core.data.api.manager.DataValidationReportManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.constant.LOADING_STATUS;
import io.sdmx.core.data.engine.mapping.UnmappedDataReportWriter;
import io.sdmx.core.data.engine.validate.DataReaderForValidation;
import io.sdmx.core.data.engine.writer.DatasetInfoWriterEngine;
import io.sdmx.core.data.engine.writer.MappingDataWriterEngine;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.mapping.DataMappingConfig;
import io.sdmx.core.data.model.validate.DatasetDetailsImpl;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;
import io.sdmx.core.data.util.DataTransformOptions;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.empty.EmptySeriesObsDataWriterEngine;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public class DataLoadManagerImpl implements DataLoadManager {
	private static final Logger LOG = LoggerFactory.getLogger(DataLoadManagerImpl.class);

	private DataWriterManager dataWriterManager;
	private DataValidationReportManager validationReportManager;
	private FusionProductInformationRetrievalManager fpInformationRetrievalManager;
	private IMetricsWriterEngine metricsWriterEngine;

	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private DataValidationManager dataValidationManager;
	private IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager;
	
	private Set<String> loading = new HashSet<>();
	
	private Cache<String, DataSetDetails> map = Caffeine.newBuilder()
            .expireAfterAccess(10, TimeUnit.MINUTES)
            .maximumSize(10000)
            .removalListener((String key, DataSetDetails value, RemovalCause cause) -> {
                if(value != null) {
                    publishDataLoadMessage(value);
                    LOG.info("Evict from cache: "+value.getUid());
                    value.close();
                }
            })
            .build();

	public DataLoadManagerImpl(SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
							   IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager,
							   DataWriterManager dataWriterManager,
							   DataValidationReportManager validationReportManager,
							   FusionProductInformationRetrievalManager fpInformationRetrievalManager,
							   IMetricsWriterEngine metricsWriterEngine,
							   DataValidationManager dataValidationManager) {
		this.dataWriterManager = dataWriterManager;
		this.validationReportManager = validationReportManager;
		this.fpInformationRetrievalManager = fpInformationRetrievalManager;
		this.metricsWriterEngine = metricsWriterEngine;
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.dataValidationManager = dataValidationManager;
		this.constraintPrefixDetailRetreivalManager = constraintPrefixDetailRetreivalManager;
	}

	@Override
	public void revalidate(String uid, List<IURNSingle<? extends IDSDRelatedBean>> sRefs, boolean asyncronous, OutputStream out) throws SdmxUnauthorisedException, TimeoutException {
		final DataSetDetails datasetDetails = getDatasetDetails(uid);
		datasetDetails.validateData(sRefs, asyncronous);
	}

	@Override
	public void writeValidationReport(String uid, OutputStream out) {
		if(loading.contains(uid)) {
			JSONObject response = new JSONObject();
			try {
				response.append("Status", LOADING_STATUS.INITIALISING.getStatus());
				out.write(response.toString().getBytes());
			} catch (JSONException e) {
				throw new SdmxException("Error writing JSON status");
			} catch (IOException e) {
				throw new SdmxException("Error writing status to output stream");
			}
		} else {
			DataSetDetails details = map.getIfPresent(uid);
			if(details == null) {
				throw new SdmxException("No Dataset details found for UID: "+uid);
			}
			validationReportManager.writeValidationReport(details, null, out);
		}
	}

	@Override
	public void close(String uid) {
	    LOG.debug("Close uid: {}", uid);

		DataSetDetails details;
		try {
			details = getDatasetDetails(uid);
		} catch (SdmxUnauthorisedException e) {
			return;
		} catch (TimeoutException e) {
			return;
		}
		publishDataLoadMessage(details);
		map.invalidate(uid);
		details.close();
	}

	@Override
	public void setMappedStructure(int datasetIdx, IURNSingle<? extends IStructureMapRelatedBean> mapTo, String uid, boolean async) throws TimeoutException {
		DataSetDetails datasetDetails = getDatasetDetails(uid);
		datasetDetails.setMappedStructure(datasetIdx, mapTo, async);
	}

	@Override
	public DataSetDetails getDatasetDetails(String filename, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets, IConsolidationOptions consolidationOptions, boolean skipValidation) {
		DataSetDetails details = new DatasetDetailsImpl(filename, rdl, sRef, priorDataDependent, mergeDatasets, consolidationOptions, skipValidation);
		if (!skipValidation) {
			details.validateData(false);
		}
		map.put(details.getUid(), details);
		return details;
	}
	
	@Override
	public DataSetDetails getDatasetDetails(String filename, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets) {
		return getDatasetDetails(filename, rdl, sRef, priorDataDependent, mergeDatasets, null, false);
	}

	@Override
	public DataSetDetails getDatasetDetails(String uid) throws TimeoutException, SdmxUnauthorisedException {
		DataSetDetails returnDetails = map.getIfPresent(uid);
		if(returnDetails == null) {
		    LOG.debug("Dataset details not found for uid: {}", uid);

			throw new TimeoutException();
		}
		return returnDetails;
	}

	@Override
	public void writeDatasetDetails(String uid, DataTransformationOptions transformOptions)  throws TimeoutException, SdmxUnauthorisedException {
		try {
			DataSetDetails details = getDatasetDetails(uid);
			LOADING_STATUS status = details.getLoadingStatus();
			if(status != LOADING_STATUS.FINISHED) {
			     throw new IllegalArgumentException("Can not download dataset '"+(uid)+"'.  Dataset status must be Complete. Status is currently: "+status.getStatus());
			}
			Integer datasetIndex = transformOptions.getDatasetIndex();
			if(datasetIndex == null) {
				datasetIndex = -1;
			}
			if(details.getDatasets() < datasetIndex+1) {
				throw new IllegalArgumentException("Can not perform transformation on dataset '"+(datasetIndex+1)+"'.  The loaded data only contains '"+details.getDatasets()+"' datasets");
			}
			DataReaderEngine dre = null;

			boolean includeMetrics = transformOptions.isIncludeMetrics();
			ValidationTransformationMetrics metrics = new ValidationTransformationMetrics();

			OutputStream out = transformOptions.getOutputStream();
			if (transformOptions.getOutputDataFormat() == null) {
			    throw new SdmxException("Unable to transform dataset - output Data format not specified");
			}
			transformOptions.startPart(transformOptions.getOutputDataFormat().getFormatDetails(), "out");
			ISeriesObsDataWriterEngine targetDwe = this.dataWriterManager.getDataWriterEngine(transformOptions.getOutputDataFormat(), out);
			targetDwe = modifyDataWriterEngine(targetDwe);

			DatasetInfoWriterEngine outputDataWriter = null;
			if(includeMetrics) {
				outputDataWriter  = new DatasetInfoWriterEngine(targetDwe);
				targetDwe = outputDataWriter;
			}

			dre = details.getDataReaderEngine(datasetIndex);

			WriteableDataLocation unmapped = null;

			DatasetInfoWriterEngine unmappedDataWriter = null;
			UnmappedDataReportWriter unmappedReportWriter = null;
			
			if(transformOptions.getMappedOutputReference() != null) {
				if(datasetIndex < 0) {
					if(details.getDatasets() == 1) {
						datasetIndex = 0;
					} else {
					    String currentDSDUrn = null;
					    for (int i=0; i < details.getDatasets(); i++) {
					        DataValidationResult dataValidationResult = details.getDataValidationResult(i);
					        DataStructureBean dsd = dataValidationResult.getDsd();
					        if (currentDSDUrn == null) {
					            currentDSDUrn = dsd.getUrn();
					        } else {
					            if (!dsd.getUrn().equals(currentDSDUrn)) {
					                throw new SdmxNotImplementedException("Mapping can not be performed on multiple datasets with different Data Structures");
					            }
					        }
					    }
					    datasetIndex = 0;
					}
				}
				MappingRules mappingRules = details.getDataValidationResult(datasetIndex).getMappingRules(transformOptions.getMappedOutputReference());
				DataMappingConfig mappingConfig = DataMappingConfig.getInstance(mappingRules);
				if(dataValidationManager != null) {
					Set<DataValidatorFactory> dataValidatorFactories = transformOptions.isSkipValidation() ? Collections.emptySet() :dataValidationManager.obtainFactoriesToBeUsedInDataValidation(true);
					mappingConfig.setValidation(dataValidatorFactories, superBeanRetrievalManager, constraintPrefixDetailRetreivalManager);
				}
				mappingConfig.setMappedDataWriterEngine(targetDwe);
				
				if(transformOptions.isIncludeUnmappedData()) {
					unmapped = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation();
					ISeriesObsDataWriterEngine uFdwe = this.dataWriterManager.getDataWriterEngine(transformOptions.getIncludeUnmappedFormat(), unmapped.getOutputStream());
					uFdwe.writeHeader(dre.getHeader());
					unmappedDataWriter = new DatasetInfoWriterEngine(uFdwe);
				}
				
				// MEDIT#262 - write an unmapped report
				if(transformOptions.isIncludeUnmappedReport()) {
					unmappedReportWriter = new UnmappedDataReportWriter(mappingRules);
					mappingConfig.setReportDataWriterEngine(unmappedReportWriter);
					if(unmappedDataWriter == null) {
						unmappedDataWriter = new DatasetInfoWriterEngine(EmptySeriesObsDataWriterEngine.INSTANCE);
					}
				}
				
				mappingConfig.setUnmappedDataWriterEngine(unmappedDataWriter);
				targetDwe = new MappingDataWriterEngine(mappingConfig);
				metrics.setMapping(mappingRules);
			}

			DataReaderForValidation drv;
			if(dre instanceof DataReaderForValidation) {
				drv = ((DataReaderForValidation)dre);
			} else {
				drv = new DataReaderForValidation(null, dre, null, null, null);
				dre = drv;
			}
			drv.setHighestAttachment(transformOptions.getHighestAttachment());
			if(ObjectUtil.validString(transformOptions.getSenderId())) {
				drv.setSenderId(transformOptions.getSenderId());
			}
			if(ObjectUtil.validString(transformOptions.getReceiverId())) {
				drv.setReceiverId(transformOptions.getReceiverId());
			}
			if(ObjectUtil.validString(transformOptions.getDatasetId())) {
				drv.setDatasetId(transformOptions.getDatasetId());
			}
			if(transformOptions.getDatasetAction() != null) {
				drv.setAction(transformOptions.getDatasetAction());
				ThreadLocalUtil.storeOnThread("ENFORCE_DATASET_ACTION", transformOptions.getDatasetAction());
			}
			String productName = fpInformationRetrievalManager != null &&
					fpInformationRetrievalManager.getFusionProductInformation() != null &&
							fpInformationRetrievalManager.getFusionProductInformation().getProductDetails() != null ?
								fpInformationRetrievalManager.getFusionProductInformation().getProductDetails().getProductName() : null;

			drv.setCreatedBy(productName);

			boolean mergeDatasets = details.isMergeDatasets();
			DataTransformationUtil.copyData(dre, targetDwe, DataTransformOptions.getInstance().setCloseWriter(true).setCopyHeader(true).setMergeDataset(mergeDatasets));
			if(transformOptions.isIncludeUnmappedData() && unmappedDataWriter != null) {
			    DataInformation dataInformation = unmappedDataWriter.getDataInformation();
			    boolean hasSeries = false;
			    for (int i=0; i < dataInformation.getDatasets(); i++) {
			        if (dataInformation.getDatasetInfo(i).getKeys() > 0) {
			            hasSeries = true;
			            break;
			        }
			    }
			    if (hasSeries) {
					try {
						DataFormat unmappedFormat = transformOptions.getIncludeUnmappedFormat() != null ? transformOptions.getIncludeUnmappedFormat() : transformOptions.getOutputDataFormat();
						transformOptions.startPart(unmappedFormat.getFormatDetails(), "unmapped");
						StreamUtil.copyStream(unmapped.getInputStream(), out);
					} finally {
						unmapped.close();
					}
			    }
			}
			
			if(includeMetrics) {
				transformOptions.startPart(MIME_TYPE.APPLICATION_JSON.getMimeType(),"metrics", MIME_TYPE.APPLICATION_JSON.getFileExtension());
				DataInformation sourceData;
				if(datasetIndex < 0) {
					sourceData = details.getDataInformation();
				} else {
					DataValidationResult dataValidationResult = details.getDataValidationResult(datasetIndex);
					sourceData = dataValidationResult.getDataInformation();
				}
				DataInformation outputData = outputDataWriter.getDataInformation();
				DataInformation unmappedData = null;
				if(unmappedDataWriter != null) {
					unmappedData = unmappedDataWriter.getDataInformation();
				}
				metrics.addDataInformation("SourceData", sourceData);
				metrics.addDataInformation("OutputData", outputData);
				if(unmappedData != null) {
					metrics.addDataInformation("UnMappedData", unmappedData);
				}

				//mappingRules
				metrics.setEndTime();
				
				try {
					// MEDIT#262 - Write the metrics.json file.
					JsonFactory factory = new JsonFactory();
					JsonGenerator jg = factory.createGenerator(out, JsonEncoding.UTF8);
					jg.writeStartObject();
					Map<IComponentMapping, List<String>> unmappedMappings = null;
					
					if (unmappedReportWriter != null) {
						unmappedMappings = unmappedReportWriter.getUnmappedElements();
					}
					
					metricsWriterEngine.writeSpecificMetricsReport(jg, metrics, unmappedMappings);
					jg.writeEndObject();
					jg.close();
				} catch (Exception e) {
					throw new SdmxException(e, "Error writing JSON metrics file");
				}
			}
			
			publishDataQueryMessage(details, transformOptions.getOutputDataFormat());
		} finally {
			transformOptions.close();
			ThreadLocalUtil.clearFromThread("ENFORCE_DATASET_ACTION");
		}
	}

	/**
     * This method allows sub-classes to modify the DataWriterEngine, adding proxies as required
     * @param dwe the original DataWriterEngine
     * @return
     */
    protected ISeriesObsDataWriterEngine modifyDataWriterEngine(ISeriesObsDataWriterEngine dwe) {
        // This implementation returns the original DataWriterEngine unchanged
        return dwe;
    }

	private void publishDataQueryMessage(DataSetDetails details, DataFormat dataFormat) {
		//TODO Fix this
//		try {
//			DataflowBean flow = getFlowFromDetails(details);
//			StringBuilder sb = new StringBuilder();
//			sb.append("/data/"+flow.getAgencyId() + "," + flow.getId() + "," + flow.getVersion()+"/");
//			RESTDataQuery query = new RESTDataQueryImpl(sb.toString());
//			dataQueryPublisher.publishMessage(new AuditDataQueryEventImpl(query, PrimaryMeasureBean.FIXED_ID, dataFormat, ThreadLocalUtil.getUID()));
//		} catch(Throwable th) {
//			LOG.error("Could not audit data download request", th);
//		}
	}

	private void publishDataLoadMessage(DataSetDetails details) {
		try {
			//TODO FIx this
//			DataflowBean flow = getFlowFromDetails(details);
//			if(flow == null) {
//				return;
//			}
//			//TODO multiple datasets
//			DataValidationResult validationResult = details.getDataValidationResult(0);
//			dataSubmissionPublisher.publishMessage(new AuditDataSubmitEventImpl(flow.getUrn(), null, validationResult.getKeys(), validationResult.getObservations(), details.getUid()));
		} catch(Throwable th) {
			LOG.error("Error while trying to publish message to Fusion Audit", th);
		}
	}

	@Override
	public String getAsyncDatasetDetails(final String dataFilename, final ReadableDataLocation rdl, final IURNSingle<? extends IDSDRelatedBean> strRef) {
		final DataSetDetails datasetDetails  = new DatasetDetailsImpl(dataFilename, rdl, strRef);
		final String uid = datasetDetails.getUid();
		map.put(uid, datasetDetails);
		datasetDetails.validateData(true);
		return uid;
	}

    @Override
    public String getAsyncDatasetDetails(URL url, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> strRef) {
        final DataSetDetails datasetDetails  = new DatasetDetailsImpl(url.toString(), rdl, strRef);
        final String uid = datasetDetails.getUid();
        map.put(uid, datasetDetails);
        datasetDetails.validateData(true);
        return uid;
    }

}
