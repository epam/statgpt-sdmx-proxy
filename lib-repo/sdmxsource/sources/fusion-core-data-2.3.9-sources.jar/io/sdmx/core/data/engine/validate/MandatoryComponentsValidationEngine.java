package io.sdmx.core.data.engine.validate;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;

/**
 * Ensure all mandatory components (attributes and measures) are present.
 * This Validation Engine expects the dataset to have been consolidated.
 */
public class MandatoryComponentsValidationEngine implements DataValidationEngine {
	private Set<String> mandatoryObsAttributesStr;
	private Set<String> mandatorySeriesAttributesStr;
	private Set<String> mandatoryDataSetAttributesStr;
	private Set<String> mandatoryObservationsStr;
	private String dimensionAtObservation;
	private Map<String, Set<String>> mandatoryGroupAttributes;

	private DataStructureBean dsd;
    private DATASET_ACTION action;

	public MandatoryComponentsValidationEngine(DatasetInformation dsi) {
		this.dsd = dsi.getDatasetStructures().getDataStructure();
	    this.action = dsi.getAction();

		mandatoryDataSetAttributesStr = new HashSet<>();
		mandatoryGroupAttributes = new HashMap<>();
		mandatoryObsAttributesStr = new HashSet<>();
		mandatorySeriesAttributesStr = new HashSet<>();
		mandatoryObservationsStr = new HashSet<>();

		if (action.equals(DATASET_ACTION.DELETE)) {
            // Delete messages do not need Mandatory attributes checked
		    return;
        }

		for(GroupBean group : dsd.getGroups()) {
			Set<String> mandatoryAttribtues = new HashSet<>();
			mandatoryGroupAttributes.put(group.getId(), mandatoryAttribtues);
			for(AttributeBean attr : dsd.getGroupAttributes(group.getId(), false)) {
				if (attr.isMandatory()) {
					mandatoryAttribtues.add(attr.getId());
				}
			}
		}
		List<AttributeBean> attributes = dsd.getAttributes();
		for (AttributeBean attrBean : attributes) {
			if (attrBean.getAttachmentLevel().equals(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET)) {
				if (attrBean.isMandatory()) {
					mandatoryDataSetAttributesStr.add(attrBean.getId());
				}
			}
		}
		
		this.dimensionAtObservation = dsi.getDimensionAtObservation();
		
		for(AttributeBean attr : dsd.getSeriesAttributes(dimensionAtObservation)) {
			if (attr.isMandatory()) {
				mandatorySeriesAttributesStr.add(attr.getId());
			}
		}

		for (AttributeBean attr: dsd.getObservationAttributes(dimensionAtObservation)) {
			if (attr.isMandatory()) {
				mandatoryObsAttributesStr.add(attr.getId());
			}
		}
		
		for (MeasureDimensionBean ameasure : dsd.getMeasures()) {
			if (ameasure.isMandatory()) {
				mandatoryObservationsStr.add(ameasure.getId());
			}
		}
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {
		if(dsAttr != null) {
			checkAttributes(dsAttr.getAttributes(), mandatoryDataSetAttributesStr, eh);
		}
	}

	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler eh) {
		List<KeyValue> attributes = key.getAttributes();
		if(key.isSeries()) {
			checkAttributes(attributes, mandatorySeriesAttributesStr, eh);
		} else {
			checkAttributes(attributes, mandatoryGroupAttributes.get(key.getGroupName()), eh);
		}
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		List<KeyValue> attributes = obs.getAttributes();
		checkAttributes(attributes, mandatoryObsAttributesStr, eh);
		checkMandatoryMeasures(obs, eh);
	}
	
	private void checkMandatoryMeasures(Observation obs, DataValidationEngineErrorHandler eh) {
		if (mandatoryObservationsStr.isEmpty()) {
			return;
		}

		// Determine all of the reported measures
		Set<String> reportedMeasures = new HashSet<>();
		for (KeyValue keyValue : obs.getMeasures()) {
			reportedMeasures.add(keyValue.getConcept());
		}
		// Subtract the reported measures from a set of expected mandatory measures
		Set<String> mandatoryMeasuresCopy = new HashSet<>(mandatoryObservationsStr);
		mandatoryMeasuresCopy.removeAll(reportedMeasures);
		if (mandatoryMeasuresCopy.size() > 0 ) {
			// Some mandatory measures were not present
			for (String missingMeasure : mandatoryMeasuresCopy) {
			    FusionError fe = new FusionErrorImpl(DataValidationErrorCode.MISSING_MANDATORY_MEASURE, missingMeasure);
				eh.reportError(fe, KeyValueImpl.getInstance(missingMeasure, null));
			}
		}
	}

	private void checkAttributes(List<KeyValue> attributes, Set<String> mandatoryAttrs, DataValidationEngineErrorHandler eh) {
		if(mandatoryAttrs == null || mandatoryAttrs.isEmpty()) {
			return;
		}
		Set<String> attrs = new HashSet<>();
		for (KeyValue keyValue : attributes) {
			attrs.add(keyValue.getConcept());
		}

		// To find which mandatory attributes were missing, subtract the attributes that were present from
		// the set of mandatory attributes that were passed in
		Set<String> mandatoryAttributesCopy = new HashSet<>(mandatoryAttrs);
		mandatoryAttributesCopy.removeAll(attrs);

		// FR-4043 - TIME_FORMAT is explicitly never a mandatory attribute
		mandatoryAttributesCopy.remove("TIME_FORMAT");
		if (mandatoryAttributesCopy.size() > 0 ) {
			// Some Mandatory Attributes were not present - make a more presentable list of the missing Mandatory Attributes
			for (String missingAttr : mandatoryAttributesCopy) {
			    FusionError fe = new FusionErrorImpl(DataValidationErrorCode.MISSING_MANDATORY_ATTR, missingAttr);
				eh.reportError(fe, KeyValueImpl.getInstance(missingAttr, null));
			}
		}
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		// Do nothing
	}

	@Override
	public void close(DataValidationErrorReporter errorHandler) {
		mandatoryObsAttributesStr = null;
		mandatorySeriesAttributesStr = null;
		mandatoryDataSetAttributesStr = null;
		dimensionAtObservation = null;
		mandatoryGroupAttributes = null;
		dsd = null;
	}

//	@Override
//    public Set<DATASET_ACTION> excludeForDatasetActions() {
//	    return Collections.singleton(DATASET_ACTION.DELETE);
//    }

}