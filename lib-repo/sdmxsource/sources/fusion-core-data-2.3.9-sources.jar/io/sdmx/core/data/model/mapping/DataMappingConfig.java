package io.sdmx.core.data.model.mapping;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.core.data.api.engine.mapping.IMappingDataReportWriter;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.sdmx.empty.EmptySeriesObsDataWriterEngine;

public class DataMappingConfig {
	private ISeriesObsDataWriterEngine mappedDataWriterEngine = EmptySeriesObsDataWriterEngine.INSTANCE;
	private IMappingDataReportWriter reportDataWriterEngine;
	private ISeriesObsDataWriterEngine unmappedDataWriterEngine = EmptySeriesObsDataWriterEngine.INSTANCE;
	private MappingRules mappingRules;
	private boolean forceFlat;

	//Validation
	private Set<DataValidatorFactory> dataValidatorFactories = Collections.emptySet();
	private SdmxSuperBeanRetrievalManager superbeanRetrievalManager;
	private IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager;
	
	
	public DataMappingConfig(MappingRules mappingRules) {
		this.mappingRules = mappingRules;
		Objects.requireNonNull(mappingRules, "DataMappingConfig: MappingRules are required");
	}

	public static DataMappingConfig getInstance(MappingRules mappingRules) {
		return new DataMappingConfig(mappingRules);
	}
	
	public ISeriesObsDataWriterEngine getMappedDataWriterEngine() {
		return mappedDataWriterEngine;
	}
	
	public DataMappingConfig setMappedDataWriterEngine(ISeriesObsDataWriterEngine mappedDataWriterEngine) {
		if(mappedDataWriterEngine == null) {
			mappedDataWriterEngine = EmptySeriesObsDataWriterEngine.INSTANCE;
		}
		this.mappedDataWriterEngine = mappedDataWriterEngine;
		return this;
	}

	/**
	 * @return if true, the mapping always maps the series with the observation information
	 */
	public boolean isForceFlat() {
		return forceFlat;
	}

	public void setForceFlat(boolean forceFlat) {
		this.forceFlat = forceFlat;
	}

	public IMappingDataReportWriter getReportDataWriterEngine() {
		return reportDataWriterEngine;
	}
	
	public DataMappingConfig setReportDataWriterEngine(IMappingDataReportWriter reportDataWriterEngine) {
		this.reportDataWriterEngine = reportDataWriterEngine;
		return this;
	}
	
	public ISeriesObsDataWriterEngine getUnmappedDataWriterEngine() {
		return unmappedDataWriterEngine;
	}
	
	public DataMappingConfig setUnmappedDataWriterEngine(ISeriesObsDataWriterEngine unmappedDataWriterEngine) {
		if(unmappedDataWriterEngine == null) {
			unmappedDataWriterEngine = EmptySeriesObsDataWriterEngine.INSTANCE;
		}
		this.unmappedDataWriterEngine = unmappedDataWriterEngine;
		return this;
	}
	
	public MappingRules getMappingRules() {
		return mappingRules;
	}
	
	public DataMappingConfig setMappingRules(MappingRules mappingRules) {
		this.mappingRules = mappingRules;
		return this;
	}
	
	public Set<DataValidatorFactory> getDataValidatorFactories() {
		return dataValidatorFactories;
	}
	
	public SdmxSuperBeanRetrievalManager getSuperbeanRetrievalManager() {
		return superbeanRetrievalManager;
	}

	public IConstraintPrefixDetailRetreivalManager getConstraintPrefixDetailRetreivalManager() {
		return constraintPrefixDetailRetreivalManager;
	}

	/**
	 * 
	 * @param dataValidatorFactories set of factories to use in validating the mapped data
	 * @param superRetrieval required if data validator factories is a non empty set
	 * @param constraintPrefixDetailRetreivalManager optional - used for constraint validaiton where the constrained codes have prefix details from codelist inheritence
	 * @return
	 */
	public DataMappingConfig setValidation(Set<DataValidatorFactory> dataValidatorFactories, SdmxSuperBeanRetrievalManager superRetrieval, IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager) {
		if(dataValidatorFactories == null || dataValidatorFactories.size() == 0) {
			this.dataValidatorFactories = Collections.emptySet();
		} else {
			this.dataValidatorFactories = Collections.unmodifiableSet(new HashSet<>(dataValidatorFactories));
			Objects.requireNonNull(superRetrieval, "DataMappingConfig: SdmxSuperBeanRetrievalManager is required if data validaiton factories are provided");
			this.superbeanRetrievalManager = superRetrieval;
			this.constraintPrefixDetailRetreivalManager = constraintPrefixDetailRetreivalManager;
		}
		return this;
	}
	
	/**
	 * Closes off any resources
	 */
	public void close() {
		if(mappedDataWriterEngine != null) {
			mappedDataWriterEngine.close();
		}
		if(reportDataWriterEngine != null) {
			reportDataWriterEngine.close();
		}
		if(unmappedDataWriterEngine != null) {
			unmappedDataWriterEngine.close();
		}
	}
}
