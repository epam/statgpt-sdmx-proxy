package io.sdmx.core.data.model.kryo;

import java.util.Date;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class DatasetHeaderSerializer extends Serializer<DatasetHeaderBean> {
	private static final DatasetHeaderSerializer INSTANCE = new DatasetHeaderSerializer();
	
	public static DatasetHeaderSerializer getInstance() {
		return INSTANCE;
	}
	
	private DatasetHeaderSerializer() { }
	
	@Override
	public void write(Kryo kryo, Output output, DatasetHeaderBean object) {
		kryo.writeObject(output, object == null ? -1 : 1);
		if(object != null) {
			kryo.writeObjectOrNull(output, object.getAction() == null ? null : object.getAction().toString(), String.class);
			kryo.writeObjectOrNull(output, object.getDataProviderReference() == null ? null : object.getDataProviderReference().getURN(), String.class);
			kryo.writeObjectOrNull(output, object.getDatasetId(), String.class);
			kryo.writeObjectOrNull(output, object.getDataStructureReference(), DatasetStructureReferenceSerializer.getInstance());
			kryo.writeObjectOrNull(output, object.getPublicationPeriod(), String.class);
			kryo.writeObjectOrNull(output, object.getPublicationYear(), Integer.class);
			kryo.writeObjectOrNull(output, object.getReportingBeginDate(), Date.class);
			kryo.writeObjectOrNull(output, object.getReportingEndDate(), Date.class);
			kryo.writeObjectOrNull(output, object.getValidFrom(), Date.class);
			kryo.writeObjectOrNull(output, object.getValidTo(), Date.class);
		}
		
	}

	@Override
	public DatasetHeaderBean read(Kryo kryo, Input input, Class<? extends DatasetHeaderBean> type) {
		boolean isNull = kryo.readObject(input, Integer.class) == -1;
		if(isNull) {
			return null;
		}
		String action = kryo.readObjectOrNull(input, String.class);
		DATASET_ACTION dsAction = action == null ? null : DATASET_ACTION.getAction(action);
		String dpRef = kryo.readObjectOrNull(input, String.class);
		String dsId = kryo.readObjectOrNull(input, String.class);
		DatasetStructureReferenceBean dsStructRef = kryo.readObjectOrNull(input, DatasetStructureReferenceBean.class, DatasetStructureReferenceSerializer.getInstance());
		String publicationPeriod = kryo.readObjectOrNull(input, String.class);
		int publicationYear = kryo.readObjectOrNull(input, Integer.class);
		Date rBeginDate = kryo.readObjectOrNull(input, Date.class);
		Date rEndDate = kryo.readObjectOrNull(input, Date.class);
		Date validFrom = kryo.readObjectOrNull(input, Date.class);
		Date validTo = kryo.readObjectOrNull(input, Date.class);
		return new DatasetHeaderBeanImpl(dsId, dsAction, dsStructRef, URN.buildOrNull(dpRef, DataProviderBean.class), rBeginDate, rEndDate, validFrom, validTo, publicationYear, publicationPeriod, publicationPeriod);
	}
}
