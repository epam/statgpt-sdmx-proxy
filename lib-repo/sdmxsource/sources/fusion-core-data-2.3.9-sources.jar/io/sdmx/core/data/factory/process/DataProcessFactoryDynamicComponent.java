package io.sdmx.core.data.factory.process;

import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.core.data.api.manager.IProcessStepRetrievalManager;
import io.sdmx.core.data.engine.writer.enrichment.FlatDataWriterEngineDynamicComponent;
import org.codehaus.jettison.json.JSONObject;

/**
 * Enriches a dataset by adding one or more components whose values are based on values of other reported values for the same row
 * for example the creation of a Series Title based on the reported Indicator, Reference Area, and Frequency
 */
public class DataProcessFactoryDynamicComponent extends AbstractProxyMappingProcess {

	private SdmxSuperBeanRetrievalManager sbRetMan;
	
	public DataProcessFactoryDynamicComponent(SdmxSuperBeanRetrievalManager sbRetMan) {
		this.sbRetMan = sbRetMan;
	}

	@Override
	public String getProcessId() {
		return "DYNAMIC_COMPONENT";
	}

	@Override
	/**
	 * Returns data validation writer, properties include
	 * {
	 *    "DynamicComponents"       : {
	 *       "SERIES_TITLE" : "$[INDICATOR.name] for $[REF_AREA.name]"
	 *    	 "OBS_STATUS"   : "A"
	 *    }
	 */
	protected IFlatDataWriterEngine getDataWriterEngine(JSONObject properties, IFlatDataWriterEngine proxy, IProcessStepRetrievalManager stepRetrievalManager) {
		Map<String, String> dynamicComponents = JsonObjectUtil.unpackMap(properties, "DynamicComponents", false);
		if(dynamicComponents.size() == 0) {
			throw new SdmxSemmanticException("Dynamic Components requires at least one Component value");
		}
		return new FlatDataWriterEngineDynamicComponent(proxy, dynamicComponents, sbRetMan);
	}
}
