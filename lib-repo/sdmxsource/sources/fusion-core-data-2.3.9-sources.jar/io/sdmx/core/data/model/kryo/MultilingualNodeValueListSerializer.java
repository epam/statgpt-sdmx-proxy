package io.sdmx.core.data.model.kryo;

import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;

public class MultilingualNodeValueListSerializer  extends ListSerializer<IMultilingualNodeValue> {
	private static final MultilingualNodeValueListSerializer INSTANCE = new MultilingualNodeValueListSerializer();
	
	public static MultilingualNodeValueListSerializer getInstance() {
		return INSTANCE;
	}
	
	private MultilingualNodeValueListSerializer() {
		super(MultilingualNodeValueSerializer.getInstance());
	}
}
