package io.sdmx.core.data.api.model.mapping;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;

/**
 * Defines a mapping between components, this may be one to one, one to many, or many to many
 */
public interface IComponentMappingRules extends IComponentMapping {
	
	/**
	 * Explains the mapping rules used to arrive at the output
	 * @param requestedPeriod
	 * @param sourceValue
	 * @return
	 */
	IExplainMapComponent explain(SdmxPeriod requestedPeriod, String... sourceValue);
	
	/**
	 * Returns a map of output component, to time period set of mapped values
	 * @param sourceValue this is the reported source value, or colon concatenated values if more then one source component is mapped
	 * @return
	 */
	Map<SdmxPeriod, Set<KeyValue>> getMappedCodes(SdmxPeriod requestedPeriod, String... sourceValue);

	/**
	 * @return the short URN of the IRepresentationMapBean that created this ComponentMappingRule, example: METATECH:OECD_AGRIC_OUTLOOK(1.0)
	 */
	String getId();
	
	/**
	 * @return true if this mapping contains rules which are for a subset of time (i.e. they have a validity period which is not equal to AllPeriods)
	 */
	boolean isTimeDependant();
	
}
