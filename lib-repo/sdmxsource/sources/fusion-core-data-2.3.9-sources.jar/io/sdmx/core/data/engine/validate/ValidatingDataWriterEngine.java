package io.sdmx.core.data.engine.validate;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.model.DatasetInformationImpl;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.core.sdmx.empty.EmptySeriesObsDataWriterEngine;
import io.sdmx.core.sdmx.error.DataErrorImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;

/**
 * Splits data down the valid/invalid path based on whether it is valid or not
 *
 * Note: This first implementation does split data which fails validation AFTER the key/obs has been validated via the
 * validator's validateKey and validateObs obs method. This means any validation errors reported on finishedObs or on close will
 * still be reported to the exceptionHandler but will not split the data to the valid/invalid writer as it has already been written
 * For an example of a validator that is impacted by this design, see the ValidationSchemeDataValidationEngine which validates all data on close
 */
public class ValidatingDataWriterEngine implements ISeriesObsDataWriterEngine {
	private SdmxSuperBeanRetrievalManager sdmxSuperBeanRetrievalManager;
	private IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager;

	private DataValidationErrorHandler exceptionHandler;
	private ISeriesObsDataWriterEngine validProxy;
	private ISeriesObsDataWriterEngine invalidProxy;
	private Set<DataValidatorFactory> datavalidationFactories = Collections.emptySet();
	private Map<DataValidatorFactory, DataValidationEngine> validators = Collections.emptyMap();
	private Date transactionTime;


	//STATEFUL
	private Map<DataValidationEngine, ErrorTranslator> errorTranslators = Collections.emptyMap();
	private int datasetPos = -1;
	boolean lastCheckIsError = false;
	private boolean invalidStartedDataset = false;
	private boolean validStartedDataset = false;
	private boolean invalidWrittenKey = false;
	private Keyable lastKey;
	private IDatasetStructures structures;
	private DatasetHeaderBean header;
	private IDatasetAttributes datasetAttributes;
	private AnnotationBean[] dsAnnotations;

	private boolean writtenObs;


	public ValidatingDataWriterEngine(SdmxSuperBeanRetrievalManager sdmxSuperBeanRetrievalManager,
									  IConstraintPrefixDetailRetreivalManager constraintPrefixDetailRetreivalManager,
									  Set<DataValidatorFactory> datavalidationFactories,
									  final DataValidationErrorHandler exceptionHandler,
									  ISeriesObsDataWriterEngine validProxy,
									  ISeriesObsDataWriterEngine invalidProxy,
									  Date transactionTime) {
		this.sdmxSuperBeanRetrievalManager = sdmxSuperBeanRetrievalManager;
		this.constraintPrefixDetailRetreivalManager = constraintPrefixDetailRetreivalManager;
		this.datavalidationFactories =datavalidationFactories == null ? Collections.emptySet() : datavalidationFactories;
		this.validProxy = validProxy != null ? validProxy : EmptySeriesObsDataWriterEngine.INSTANCE;
		this.invalidProxy = invalidProxy != null ? invalidProxy : EmptySeriesObsDataWriterEngine.INSTANCE;
		if(transactionTime == null) {
			transactionTime = new Date();
		}
		this.transactionTime = transactionTime;
		this.exceptionHandler = new DataValidationErrorHandler() {

			@Override
			public void handleError(DataError err) throws ErrorLimitException {
				lastCheckIsError = true;
				exceptionHandler.handleError(err);
			}
		};
	}

	@Override
	public void writeHeader(HeaderBean header) {
		validProxy.writeHeader(header);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		this.structures = structures;
		this.header = header;
		this.datasetAttributes = datasetAttributes;
		this.dsAnnotations = annotations;

		DATASET_ACTION action = header == null ? null : header.getAction();

		DatasetInformation dsi = new DatasetInformationImpl(header,
				structures.getDataStructure(),
				structures.getDataflow(),
				structures.getProvisionAgreement(),
				sdmxSuperBeanRetrievalManager,
				constraintPrefixDetailRetreivalManager,
				action, transactionTime);
		datasetPos++;

		validators = new HashMap<>(datavalidationFactories.size());
		errorTranslators = new HashMap<>(datavalidationFactories.size());
		for(DataValidatorFactory factory : datavalidationFactories) {
			DataValidationEngine engine = factory.createInstance(dsi);
			if(engine != null) {
				validators.put(factory, engine);
				errorTranslators.put(engine, new ErrorTranslator(exceptionHandler, factory, datasetPos));
			}
		}
		validateDatasetAttributes(datasetAttributes);
	}

	/**
	 * @return true if there are validators to validate the data.  Validators are created after the startDataset method has been called.
	 */
	public boolean hasValidators() {
		return validators.size() > 0;
	}

	private void startDataset(ISeriesObsDataWriterEngine proxy) {
		proxy.startDataset(structures, header, datasetAttributes, dsAnnotations);
		validStartedDataset = false;
		invalidStartedDataset = false;
	}

	private void validateDatasetAttributes(IDatasetAttributes datasetAttributes) {
		for (DataValidationEngine validator : validators.values()) {
			ErrorTranslator errorTranslator = errorTranslators.get(validator);
			errorTranslator.inDatasetAttributes = true;
			try {
				validator.validateDatasetAttributes(datasetAttributes, errorTranslator);
			} catch (SdmxException e) {
				errorTranslator.reportError(e);
			} finally {
				errorTranslator.inDatasetAttributes = false;
			}
		}
	}

	@Override
	public void writeKey(Keyable key) {
		flushObs();
		writtenObs = false;
		lastCheckIsError = false;
		invalidWrittenKey = false;
		if (key != null) {
			for (DataValidationEngine validator : validators.values()) {
				ErrorTranslator errorTranslator = errorTranslators.get(validator);
				errorTranslator.setCurrentKey(key);
				try {
					validator.validateKey(key, errorTranslator);
				} catch(Throwable th) {
					errorTranslator.reportError(th);
				}
			}
			if(lastCheckIsError) {
				invalidWrittenKey = true;
				if(!invalidStartedDataset) {
					startDataset(invalidProxy);
					invalidStartedDataset = true;
				}
				invalidProxy.writeKey(key);
			} else {
				if(!validStartedDataset) {
					startDataset(validProxy);
					validStartedDataset = true;
				}
				validProxy.writeKey(key);
			}
			lastKey = key;
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		writtenObs = true;
		lastCheckIsError = false;
		for(DataValidationEngine validator : validators.values()) {
			ErrorTranslator errorTranslator = errorTranslators.get(validator);
			errorTranslator.setCurrentObs(obs);
			try {
				validator.validateObs(obs, errorTranslator);
			} catch(Throwable th) {
				errorTranslator.reportError(th);
			}
		}
		if(lastCheckIsError || invalidWrittenKey) {
			if(!invalidStartedDataset) {
				startDataset(invalidProxy);
				invalidStartedDataset = true;
			}
			if(!invalidWrittenKey) {
				invalidProxy.writeKey(lastKey);
			}
			invalidProxy.writeObservation(obs);
		} else {
			//dataset and key must have been written
			validProxy.writeObservation(obs);
		}
	}

	/**
	 * Removes validation for the given factory
	 * @param factory
	 */
	public void removeValidator(DataValidatorFactory factory) {
		validators.remove(factory);
	}


	private void flushObs() {
		if(writtenObs) {
			for (DataValidationEngine validator : validators.values()) {
				validator.finishedObs(errorTranslators.get(validator));
			}
		}
	}

	@Override
	public void close(FooterMessage... footer) {
		flushObs();
		for (DataValidationEngine validator : validators.values()) {
			try {
				validator.close(errorTranslators.get(validator));
			} catch (Throwable th) {
				// If this end-validation failed, simply return. The calling code will catch the ExceptionHandler for errors.
				// If we were to throw this Throwable OR if we were to not perform a return here, the lower catch block
				// would catch the exceptions and duplicate the errors.
			}
		}
	}


	private class ErrorTranslator implements DataValidationErrorReporter, DataValidationEngineErrorHandler {
		private DataValidationErrorHandler dataValidationErrorHandler;
		private String validationId;
		private int datasetPosition;

		private boolean inDatasetAttributes = false;
		private Keyable currentKey;
		private Observation currentObs;

		public ErrorTranslator(DataValidationErrorHandler dataValidationErrorHandler, DataValidatorFactory validationFactory, int datasetPosition) {
			this.dataValidationErrorHandler = dataValidationErrorHandler;
			this.validationId = validationFactory.getId();
			this.datasetPosition = datasetPosition;
		}

		public void reportError(Throwable th) {
			String val = ErrorUtil.getErrorMessage(th);
			FusionError fe = new FusionErrorImpl(val, null);
			reportError(fe, (KeyValue) null);
		}

		@Override
		public void reportError(FusionError fe, KeyValue component) {
			if(currentKey != null) {
				reportError(fe, component, currentKey);
			} else if(currentObs != null) {
				reportError(fe, component, currentObs);
			} else if(inDatasetAttributes){
				reportDatasetAttributeError(fe, component);
			}  else {
				dataValidationErrorHandler.handleError(new DataErrorImpl(validationId, datasetPosition, fe, null));
			}
		}

		@Override
		public void reportError(FusionError fe, IMultilingualKeyValue component) {
			if(currentKey !=null){
				reportError(fe, component, currentKey);
			}
		}

		@Override
		public void reportError(FusionError fe, KeyValue component, Observation obs) {
			dataValidationErrorHandler.handleError(new DataErrorImpl(validationId, datasetPosition, fe, component, obs));
		}

		@Override
		public void reportObsError(FusionError fe, KeyValue component, String... obsShortCode) {
			dataValidationErrorHandler.handleError(DataErrorImpl.fromObsShortCode(validationId, datasetPosition, fe, component, obsShortCode));
		}

		@Override
		public void reportError(FusionError fe, KeyValue component, Keyable key) {
			dataValidationErrorHandler.handleError(new DataErrorImpl(validationId, datasetPosition, fe, component, key));
		}

		@Override
		public void reportError(FusionError fe, IMultilingualKeyValue component, Keyable key){
			dataValidationErrorHandler.handleError(new DataErrorImpl(validationId, datasetPosition, fe, component, key));
		}

		@Override
		public void reportDatasetAttributeError(FusionError fe, KeyValue component) {
			dataValidationErrorHandler.handleError(new DataErrorImpl(validationId, datasetPosition, fe, component));
		}

		public void setCurrentKey(Keyable currentKey) {
			this.currentKey = currentKey;
			this.currentObs = null;
		}

		public void setCurrentObs(Observation currentObs) {
			this.currentObs = currentObs;
			this.currentKey = null;
		}
	}
}