package io.sdmx.core.data.constant;

public enum LOADING_STATUS {
	INITIALISING("Initialising", false),  //Initial status
    ANALYSING("Analysing", false),     //The dataset is being analysed for series and obs count, and which dsd's it references
    VALIDATING_1("Validating", false),  // 
    CONSOLIDATING("Consolidating", false), //The dataset is being consolidated, duplicate series and observations are being merged into one final dataset
    VALIDATING_2("Validating", false),  //
    FINISHED("Complete", false),      //The dataset validation process has finished, there may/man not be errors
    DSD_INCORRECT("IncorrectDSD", true), //The dataset references a DSD that can not be used to validate the data
    DSD_INVALID("InvalidRef", true), //The dataset references a DSD/Dataflow/Provision that does not exist in the Registry
    DSD_MISSING("MissingDSD", true), //The dataset does not not reference any structure so the system can not read the dataset
    ERRORED("Error", true);        //The dataset can not be read at all, 

	private String status;
	private boolean isError;

	private LOADING_STATUS(String name, boolean isError) {
		this.status = name;
		this.isError = isError;
	}

	public boolean isError() {
		return isError;
	}

	public String getStatus() {
		return status;
	}
}
