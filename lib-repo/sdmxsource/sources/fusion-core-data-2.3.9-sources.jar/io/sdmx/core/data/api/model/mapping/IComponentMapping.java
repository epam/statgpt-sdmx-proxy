package io.sdmx.core.data.api.model.mapping;

import java.util.List;

import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * Describes a mapping between one ore move source Components to one or more target Components
 */
public interface IComponentMapping {
	/**
	 * Returns all the source components used as input to this mapping (unmodifiable list). All values for each component must be concatenated together
	 * to create a sourceValue used to call getMappedCodes, for example if this method returns FREQ and REF_AREA then a source value would be A:UK
	 * @return
	 */
	List<String> getSourceComponents();
	
	/**
	 * Returns all the target components of this mapping (unmodifiable list)
	 * @return
	 */
	List<String> getTargetComponents();
	
	
	default String getId() {
		return CollectionUtil.join(",", "", getSourceComponents())+"->"+CollectionUtil.join(",", "", getTargetComponents());
	}

	/**
	 * @return true if an output is required for this mapping to be determined a success
	 */
	boolean outputRequired();
}
