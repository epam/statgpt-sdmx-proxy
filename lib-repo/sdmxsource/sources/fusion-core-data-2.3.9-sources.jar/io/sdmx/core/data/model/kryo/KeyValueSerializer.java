package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.utils.core.collection.KeyValueImpl;

public class KeyValueSerializer extends Serializer<KeyValue> {
	private static final KeyValueSerializer INSTANCE = new KeyValueSerializer();
	
	public static KeyValueSerializer getInstance() {
		return INSTANCE;
	}
	
	private KeyValueSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, KeyValue object) {
		int count = object.hasMultipleValues() ? object.getValues().size() : 1;
		kryo.writeObject(output, count);
		kryo.writeObject(output, object.getConcept());
		if(object.hasMultipleValues()) {
			for(String value : object.getValues()) {
				kryo.writeObject(output, value);
			}
		} else {
			// Kryo will not write null values, so write a blank value if the object code is null
			String val = object.getCode();
			if (val == null) {
				val = "";
			}
			kryo.writeObject(output, val);
		}
	}

	@Override
	public KeyValue read(Kryo kryo, Input input, Class<? extends KeyValue> type) {
		int count = kryo.readObject(input, Integer.class);
		String concept = kryo.readObject(input, String.class);
		if(count > 1) {
			String[] arr = new String[count];
			for(int i=0; i < count; i++)  {
				arr[i] =  kryo.readObject(input, String.class);
			}
			return KeyValueImpl.getInstance(concept, arr);
		}
		return KeyValueImpl.getInstance(concept, kryo.readObject(input, String.class));
	}
}