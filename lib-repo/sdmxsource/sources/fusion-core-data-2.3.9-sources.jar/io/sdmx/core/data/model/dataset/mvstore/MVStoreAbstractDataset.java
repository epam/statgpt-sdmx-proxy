package io.sdmx.core.data.model.dataset.mvstore;

import java.util.Iterator;
import java.util.List;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_DatasetAttributes;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_IDatasetStructures;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_Keyable;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_Object;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_ObservationWrap;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.util.MVStoreUtil;
import io.sdmx.im.beans.container.SdmxBeansImpl;

/**
 * This class represents a dataset stored in a MVStoreDatasetStorage.
 */
public abstract class MVStoreAbstractDataset implements IDatasetStore {
	private static final Logger LOG =
			LoggerFactory.getLogger(MVStoreAbstractDataset.class);

	private static final Integer DSINFO_header = 1;
	private static final Integer DSINFO_attributes = 2;
	private static final Integer DSINFO_annotations = 3;
	private static final Integer DSINFO_structures = 4;

	protected static final DT_Integer intDT = DT_Integer.getInstance(false);

	protected final MVStore db;
	protected final int index;

	private final DT_Object objectDT;
	private final DT_DatasetAttributes datasetAttributeDT;
	private final DT_Keyable keyableDT;
	private final DT_IDatasetStructures structuresDT;
	protected final DT_ObservationWrap observationDT;

	private MVMap<Integer, Object> dataset_info;  //A map of dataset info numbers (see statics) and the object it is storing


	protected MVMap<Integer, IDatasetAttributes> datasetAttributes;
	
	// map position to keyable for sequential access in input order
	protected MVMap<Integer, Keyable> keyables;

	private IDatasetStructures structures;

	// position of the last inserted keyable
	protected Integer currentKeyablePosition;



	/**
	 * Build a MVStoreDataset instance from scratch.
	 */
	protected MVStoreAbstractDataset(MVStore db, int index, IDatasetStructures structures) {
		this.db = db;
		this.index = index;

		SdmxBeanRetrievalManager brm = createBeanRetrievalManager(structures);
		this.structuresDT = new DT_IDatasetStructures(brm);
		this.datasetAttributeDT = new DT_DatasetAttributes();
		this.objectDT = new DT_Object(structuresDT);
		openDatasetInfo();

		this.observationDT = new DT_ObservationWrap(this);
		storeStructures(structures);
		this.structures = structures;
		
		this.keyableDT = new DT_Keyable(this.structures);

		openKeyableMaps();
	}

	/**
	 * Build a MVStoreDataset instance from the information stored in the
	 * given MVStore.
	 */
	protected MVStoreAbstractDataset(MVStore db, int index, SdmxBeanRetrievalManager brm) {
		this.db = db;
		this.index = index;

		this.structuresDT = new DT_IDatasetStructures(brm);
		this.datasetAttributeDT = new DT_DatasetAttributes();
		this.objectDT = new DT_Object(structuresDT);
		openDatasetInfo();
		this.observationDT = new DT_ObservationWrap(this);
		this.structures = retrieveStructures();
		
		this.keyableDT = new DT_Keyable(this.structures);

		openKeyableMaps();
	}
	
	
	/************************************************************************/
	/****************Initialisation				  ***************************/
	/************************************************************************/

	/**
	 * Returns a BeanRetrievalManager populated with the contents of the structures object
	 * @param structures
	 * @return
	 */
	private SdmxBeanRetrievalManager createBeanRetrievalManager(IDatasetStructures structures) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(structures.getConstrainable());
		beans.addIdentifiable(structures.getDataflow());
		beans.addIdentifiable(structures.getDataProvider());
		beans.addIdentifiable(structures.getDataStructure());
		beans.addIdentifiable(structures.getProvisionAgreement());
		
		return new InMemoryRetrievalManager(beans);
	}
	
	/**
	 * Open a per dataset MVMap<Integer, Object> with the given identifier.
	 */
	private void openDatasetInfo() {
		datasetAttributes = MVStoreUtil.openMap("dataset_attr", index, intDT, datasetAttributeDT, db);
		dataset_info = MVStoreUtil.openMap("dataset_info", index, intDT, objectDT, db);
		LOG.trace("Opened Dataset map for dataset {}.", index);
	}

	/**
	 * Open the Keyable maps.
	 */
	protected void openKeyableMaps() {
		keyables = MVStoreUtil.openMap("keyables", index, intDT, keyableDT, db);
		currentKeyablePosition = keyables.isEmpty() ? -1 : keyables.lastKey();
		LOG.trace("Opened Keyable maps for dataset {}.", index);
	}


	private void storeStructures(IDatasetStructures structures) {
		dataset_info.put(DSINFO_structures, MVStoreUtil.nullOrObject(structures));
	}
	

	private IDatasetStructures retrieveStructures() {
		return MVStoreUtil.nullOrCast(dataset_info.get(DSINFO_structures));
	}
	
	/************************************************************************/
	/****************Public API  				  ***************************/
	/************************************************************************/
	public void flush() {}
	
	
	@Override
	public IDatasetStructures getStructures() {
		return structures;
	}

	//TODO put on API?
	/**
	 * 
	 */
	public void setHeader(DatasetHeaderBean header) {
		dataset_info.put(DSINFO_header, MVStoreUtil.nullOrObject(header));
	}

	@Override
	public DatasetHeaderBean getHeader() {
		Object val = dataset_info.get(DSINFO_header);
		return MVStoreUtil.nullOrCast(val);
	}
	
	
	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return MVStoreUtil.nullOrCast(datasetAttributes.get(DSINFO_attributes));
	}

	@Override
	public List<AnnotationBean> getDatasetAnnotations() {
		return MVStoreUtil.nullOrCast(dataset_info.get(DSINFO_annotations));
	}

	@Override
	public int getKeySize() {
		return this.keyables.size();
	}

	@Override
	public void writeDatasetAttributes(IDatasetAttributes attributes) {
		datasetAttributes.put(DSINFO_attributes, attributes);
	}

	@Override
	public void writeDatasetAnnotations(List<AnnotationBean> annotations) {
		dataset_info.put(DSINFO_annotations, MVStoreUtil.nullOrObject(annotations));
	}

	/**
	 *
	 */
	@Override
	public void writeKey(Keyable keyable) {
		LOG.trace("writeKey({})", keyable);
		Integer kCurrPosition = ++currentKeyablePosition;
		if(LOG.isTraceEnabled()) {
			LOG.trace("keyables.put({}, {})", kCurrPosition, keyable);
		}
		keyables.put(kCurrPosition, keyable);
	}

	/**
	 * Return the keyable at the given position
	 *
	 * TODO: maybe get the first available >= ?
	 */
	@Override
	public Keyable getKeyable(Integer kPos) {
		Keyable keyable = keyables.get(kPos);
		LOG.trace("getKeyable({}) => {}", kPos, keyable);
		return keyable;
	}

	/**
	 *
	 */
	public void dump(Logger logger) {
		if (logger == null || !logger.isDebugEnabled()) {
			return;
		}
		Integer kFirst = keyables.firstKey();
		Iterator<Integer> kIter = keyables.keyIterator(kFirst);

		logger.debug("      keyables:");

		while (kIter.hasNext()) {
			Integer k = kIter.next();
			Keyable v = keyables.get(k);
			String vc = (v == null) ? null : v.getShortCode();

			logger.debug("        {} - {}", k, vc);
		}
	}

}
