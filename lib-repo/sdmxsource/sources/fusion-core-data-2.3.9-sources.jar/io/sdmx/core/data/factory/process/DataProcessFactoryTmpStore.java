package io.sdmx.core.data.factory.process;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.data.api.factory.IDataProcessFactory;
import io.sdmx.core.data.api.manager.IProcessStepRetrievalManager;
import io.sdmx.core.data.engine.writer.FlatDataWriterEngineTmpStore;
import org.codehaus.jettison.json.JSONObject;

/**
 * Stores the data in a temporary location
 */
public class DataProcessFactoryTmpStore implements IDataProcessFactory {

	@Override
	public String getProcessId() {
		return "STORE_TMP";
	}

	@Override
	public IFlatDataWriterEngine getDataWriterEngine(JSONObject properties, IProcessStepRetrievalManager stepRetrievalManager) {
		return new FlatDataWriterEngineTmpStore();
	}
}
