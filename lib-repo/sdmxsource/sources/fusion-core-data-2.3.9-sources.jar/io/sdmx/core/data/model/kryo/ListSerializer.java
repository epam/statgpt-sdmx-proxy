package io.sdmx.core.data.model.kryo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class ListSerializer<T> extends Serializer<List<T>> {
	private Serializer<T> serializer;

	public ListSerializer(Serializer<T> serializer) {
		this.serializer = serializer;
	}

	@Override
	public void write(Kryo kryo, Output output, List<T> keyValueList) {
		kryo.writeObject(output, keyValueList.size());  
		for(T key : keyValueList) {
			kryo.writeObject(output, key, serializer);
		}
	}

	@Override
	public List<T>  read(Kryo kryo, Input input, Class<? extends List<T>> type) {
		int listSize = kryo.readObject(input, Integer.class);
		List<T> returnList =  listSize > 0 ? new ArrayList<>(listSize) : Collections.emptyList();
		for(int i=0; i < listSize; i++) {
			returnList.add((T)kryo.readObject(input, Object.class, serializer));
		}
		return returnList;
	}
}