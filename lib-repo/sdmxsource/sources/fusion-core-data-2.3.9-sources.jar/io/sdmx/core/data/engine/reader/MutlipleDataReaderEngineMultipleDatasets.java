package io.sdmx.core.data.engine.reader;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Wraps many data reader engines and walks through the datasets and series of each
 * The Header and DataSetHeader is taken from the first datareader engine
 */
public class MutlipleDataReaderEngineMultipleDatasets implements DataReaderEngine {
	private List<DataReaderEngine> dataReaderEngines = new ArrayList<>();
	private DataReaderEngine currentDataReaderEngine;
	private int dataReaderIndex = 0;
	private int datasetPosition = 0;
	private HeaderRetrievalManager headerRetrievalManager;
	
	public MutlipleDataReaderEngineMultipleDatasets(List<DataReaderEngine> dataReaderEngines, HeaderRetrievalManager headerRetrievalManager) {
		if(!ObjectUtil.validCollection(dataReaderEngines)) {
			throw new IllegalArgumentException("Can not construct MultipleDataReaderEngine with null or empty list");
		}
		this.dataReaderEngines.addAll(dataReaderEngines);
		this.currentDataReaderEngine = dataReaderEngines.get(0);
		this.headerRetrievalManager = headerRetrievalManager;
	}

	@Override
	public String getDataFormat() {
		return currentDataReaderEngine.getDataFormat();
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		for(DataReaderEngine dre : dataReaderEngines) {
			if(dre.getFormatDetails() != null) {
				return dre.getFormatDetails();
			}
		}
		return null;
	}


	@Override
	public HeaderBean getHeader() {
		HeaderBean header = currentDataReaderEngine.getHeader();
		if (header != null) {
			return header;
		}
		if(headerRetrievalManager != null){
			header = new HeaderBeanImpl(headerRetrievalManager.getHeader().getSender().getId());
		} else {
			header = new HeaderBeanImpl("ZZZ");
		}
		return header;
	}

	@Override
	public DataReaderEngine createCopy() {
		List<DataReaderEngine> dataReaderEngineCopy = new ArrayList<>();
		for(DataReaderEngine dre : dataReaderEngines) {
			dataReaderEngineCopy.add(dre.createCopy());
		}
		return new MutlipleDataReaderEngineMultipleDatasets(dataReaderEngineCopy, headerRetrievalManager);
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return currentDataReaderEngine.getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return currentDataReaderEngine.getDataFlow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return currentDataReaderEngine.getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return datasetPosition;
	}

	@Override
	public int getKeyablePosition() {
		return currentDataReaderEngine.getKeyablePosition();
	}

	@Override
	public int getObsPosition() {
		return currentDataReaderEngine.getObsPosition();
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return currentDataReaderEngine.getCurrentDatasetHeaderBean();
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return currentDataReaderEngine.getDatasetAttributes();
	}

	@Override
	public Keyable getCurrentKey() {
		return currentDataReaderEngine.getCurrentKey();
	}

	@Override
	public Observation getCurrentObservation() {
		return currentDataReaderEngine.getCurrentObservation();
	}

	@Override
	public boolean moveNextObservation() {
		return currentDataReaderEngine.moveNextObservation();
	}

	@Override
	public boolean moveNextKeyable() {
		return currentDataReaderEngine.moveNextKeyable();
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		if(currentDataReaderEngine.moveNextDataset()) {
			datasetPosition ++;
			return true;
		}
		if(dataReaderEngines.size() > (dataReaderIndex+1)) {
			dataReaderIndex++;
			currentDataReaderEngine = dataReaderEngines.get(dataReaderIndex);
			return moveNextDataset();
		}
		return false;
	}

	@Override
	public void reset() {
		for(DataReaderEngine dre : dataReaderEngines) {
			dre.reset();
		}
	}

	@Override
	public List<FooterMessage> close() {
		List<FooterMessage> returnList = new ArrayList<>();
		for(DataReaderEngine dre : dataReaderEngines) {
			List<FooterMessage> footers = dre.close();
			if(footers != null) {
				returnList.addAll(footers);
			}
		}
		return returnList;
	}
	
	
	
}
