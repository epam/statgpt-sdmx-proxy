package io.sdmx.core.data.model.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;

public class FusionXLDataFormat implements DataFormat {
	private static final long serialVersionUID = 1L;
	private FormatDetails formatDetails = new FormatDetailsImpl("FusionXL", "csv", "text/csv", true, "application/vnd.fusionxl");
	
	private ConstrainedCodes cds;
	public static final FusionXLDataFormat INSTANCE = new FusionXLDataFormat();
	
	private FusionXLDataFormat() {}

	/**
	 * Constructor is used when the data written should include more metadata at the end of the message
	 * for other code values /labels which may not appear in the dataset, this is used when 
	 * the user has loaded a dataset up for future data authoring.  The user wants the metadata that 
	 * provides labels for the data they have loaded, but also more metadata for data they may wish to author
	 * @param cds
	 */
	public FusionXLDataFormat(ConstrainedCodes cds) {
		this.cds = cds;
	}


	public ConstrainedCodes getConstrainedDataStructure() {
		return cds;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
	

	@Override
	public int hashCode() {
		return getFormatDetails().getAcceptHeaders()[0].hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof FusionXLDataFormat) {
			InformationFormat that = (InformationFormat)obj;
			return that.getFormatDetails().getAcceptHeaders()[0].equals(this.getFormatDetails().getAcceptHeaders()[0]);
		}
		return false;
	}

	@Override
	public String toString() {
		return getFormatDetails().getAcceptHeaders()[0];
	}

}
