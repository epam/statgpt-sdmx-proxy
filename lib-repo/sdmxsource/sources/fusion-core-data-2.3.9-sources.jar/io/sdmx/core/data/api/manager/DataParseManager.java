package io.sdmx.core.data.api.manager;

import java.io.OutputStream;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.DataFormat;


/**
 * The data Manager is responsible for transforming data to adhere to one SMDX schema type to another.
 */
public interface DataParseManager {
	/**
	 * Performs a transform from one data format to another data format.  
	 * 	  
	 * @param sourceData the location of the the input stream which reads the data to transform
	 * @param out OutputStream to write the transform results to
	 * @param dataFormat the format to transform to
	 * @param retrievalManager used to get any data structures needed to interpret the data
	 */
	void performTransform(ReadableDataLocation sourceData, 
						  OutputStream out, 
						  DataFormat dataFormat, 
						  SdmxBeanRetrievalManager retrievalManager);
	
	/**
	 * 
	 * Performs a transform from one data format to another data format. 
	 * @param sourceData the location of the the input stream which reads the data to transform
	 * @param out OutputStream to write the transform results to
	 * @param dataFormat the format to transform to
	 * @param dsd the Structure bean that specifies the data format 
	 * @param dataflowBean (optional) provides extra information about the data
	 */
	void performTransform(ReadableDataLocation sourceData, 
						  OutputStream out, 
						  DataFormat dataFormat, 
						  DataStructureBean dsd,
						  DataflowBean dataflowBean);
	
	/**
	 * Performs a transform from one data format to another data format.  
	 * 	  
	 * @param sourceData the location of the the input stream which reads the data to transform
	 * @param dsdLocation the location of the structure used to transform the data
	 * @param out OutputStream to write the transform results to
	 * @param dataFormat the format to transform to
	 */
	void performTransform(ReadableDataLocation sourceData, 
						  ReadableDataLocation dsdLocation,
						  OutputStream out, 
						  DataFormat dataFormat);	
	/**
	 * 
	 * @param sourceData
	 * @param dsdLocation
	 * @param dataFormat
	 * @return
	 */
	List<ReadableDataLocation> performTransformAndSplit(ReadableDataLocation sourceData, 
														ReadableDataLocation dsdLocation,
														DataFormat dataFormat);
	
	/**
	 * 
	 * @param sourceData
	 * @param dsdLocation
	 * @param dataFormat
	 * @return
	 */
	List<ReadableDataLocation> performTransformAndSplit(ReadableDataLocation sourceData, 
			  											DataFormat dataFormat,
			  											SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Performs a transform from one data format to another data format. 
	 * 	  
	 * @param sourceData giving access to the input stream which reads the data to transform
	 * @param outputFormat The format to transform to
	 * @param beanRetrievalManager 
	 * @return
	 */
	ReadableDataLocation performTransform(ReadableDataLocation sourceData, 
						  				  DataFormat dataFormat, 
						  				  SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Performs a transform from one data format to another data format.
	 * 
	 * @param sourceData
	 * @param dataFormat
	 * @param dsd
	 * @param dataflowBean (optional) provides extra information about the data
	 * @return
	 */
	ReadableDataLocation performTransform(ReadableDataLocation sourceData, 
			  							  DataFormat dataFormat, 
			  							  DataStructureBean dsd,
			  							  DataflowBean dataflowBean);
}
