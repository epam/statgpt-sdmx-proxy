package io.sdmx.core.data.engine.validate;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;

/**
 * Validates that extra Dimensions and Attributes have not been defined and ensures that
 * Dimensions and Attributes have a value (but NOT whether the value is correct).
 */
public class StructureDataValidationEngine implements DataValidationEngine {
	protected DatasetInformation dsi;

	public StructureDataValidationEngine(DatasetInformation dsi) {
		this.dsi = dsi;
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {
		if(dsAttr == null) return;
		
		for(KeyValue kv : dsAttr.getAttributes()) {
			ComponentSuperBean attribute = dsi.getDsdSuperBean().getComponentById(kv.getConcept());
			if(attribute == null) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NO_ATTRIBUTE, kv.getConcept());
				eh.reportError(fe, kv);

			} else {
				if(attribute.getBuiltFrom().getStructureType() != SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_COMPONENT_NOT_ATTRIBUTE, kv.getConcept(), attribute.getBuiltFrom().getStructureType().getType().toString());
	                eh.reportError(fe, kv);
				}
				AttributeSuperBean attr = (AttributeSuperBean) attribute;
				if(attr.getBuiltFrom().getAttachmentLevel() !=  ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_ATTRIBUTE_NOT_ON_DATASET, kv.getConcept(), attr.getBuiltFrom().getAttachmentLevel().toString());
	                eh.reportError(fe, kv);
				}
			}
		}
	}


	@Override
	public void validateKey(Keyable keyable, DataValidationEngineErrorHandler eh) {

		Map<String, AttributeSuperBean> attributes = null;
		if(!keyable.isSeries()) {
			GroupSuperBean group = dsi.getDsdSuperBean().getGroupIgnoreCase(keyable.getGroupName());
			if(group == null) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NO_GROUP_WITH_ID, keyable.getGroupName() );
                eh.reportError(fe, (KeyValue) null);
			} else {
				attributes = dsi.getGroupAttributesSuperBeans().get(group.getId());
				for(KeyValue kv : keyable.getKey()) {
					if(group.getDimensionById(kv.getConcept()) == null) {
						FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NO_COMPONENT_IN_GROUP, kv.getConcept(), group.getId());
	                    eh.reportError(fe, kv);
					}
				}
			}
		} else {
			if(keyable.getKey().size() != dsi.getDimSize()) {
				Map<String, KeyValue> reportedKeys = new HashMap<>();
				for(KeyValue kv : keyable.getKey()) {
					reportedKeys.put(kv.getConcept(), kv);
				}

				// Ensure that missing dimension(s) are not simply the Dimension at Observation
				boolean stillMissingDimension = true;
				String dimAtObs = dsi.getDimensionAtObservation();
				if (! (dimAtObs.equals(DimensionBean.TIME_DIMENSION_FIXED_ID) || dimAtObs.equals(DatasetStructureReferenceBean.ALL_DIMENSIONS)) ) {
					if (!reportedKeys.keySet().contains(dimAtObs)) {
						if (reportedKeys.size() + 1 == dsi.getDimSize()) {
							// The missing dimension was the Dim at Observation
							stillMissingDimension = false;
						}
					}
				}

				if (stillMissingDimension) {
					Set<String> actualKeys = dsi.getDimensionMap().keySet();
					for(String dsdKeyId : actualKeys) {
						if(!reportedKeys.keySet().contains(dsdKeyId)) {
							FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_MISSING_VALUE_FOR_DIMENSION, dsdKeyId);
	                        eh.reportError(fe, KeyValueImpl.getInstance(dsdKeyId, null));
						}
					}

					if (reportedKeys.size() > 0) {
						for(String reportedKey : reportedKeys.keySet()) {
							if(!actualKeys.contains(reportedKey)) {
								FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NO_COMPONENT, reportedKey);
	                            eh.reportError(fe, reportedKeys.get(reportedKey));
							}
						}
					}
				}
			}
			attributes = dsi.getSeriesAttributesSuperBeans();
		}
		for(KeyValue kv : keyable.getKey()) {
			DimensionSuperBean dimension = dsi.getDimensionMapSuperBeans().get(kv.getConcept());

			if(dimension == null) {
				// FR-2141: NPE defence
				DimensionBean dimensionBean = dsi.getDimensionMap().get(kv.getConcept());
				if (dimensionBean == null) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_NO_COMPONENT, kv.getConcept());
                    eh.reportError(fe, kv);
				}
			}
		}

		for(KeyValue kv : keyable.getAttributes()) {
			if(attributes != null) {
			    // FR-4043 - TIME_FORMAT is explicitly not a mandatory attribute so ignore it
			    if (kv.getConcept().equals("TIME_FORMAT")) {
                    continue;
                }
				AttributeSuperBean attribute = attributes.get(kv.getConcept());
				// Only check for the existence of values in this ValidationEngine - DeepDataValidationEngine will check the values
				if(attribute == null) {
				    FusionError fe;
				    if (keyable.isSeries()) {
				        fe = new FusionErrorImpl(DataErrorCode.DSD_SERIES_ATTR_NOT_EXIST, kv.getConcept(), keyable.getDataStructure().getUrn().split("=")[1]);
				    } else {
				        fe = new FusionErrorImpl(DataErrorCode.DSD_GROUP_ATTR_NOT_EXIST, keyable.getGroupName(), kv.getConcept(), keyable.getDataStructure().getUrn().split("=")[1]);
				    }
                    eh.reportError(fe, kv);
				}
			}
		}
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		for(KeyValue kv : obs.getAttributes()) {
			AttributeSuperBean attribute = dsi.getObsAttributesSuperBeans().get(kv.getConcept());
			if(attribute == null) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.DSD_OBS_ATTR_NOT_EXIST, kv.getConcept(), obs.getSeriesKey().getDataStructure().getUrn().split("=")[1]);
                eh.reportError(fe, kv);
			}
		}
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
	    // Do nothing
	}

	@Override
	public void close(DataValidationErrorReporter exceptionHandler) {
		dsi = null;
	}
}