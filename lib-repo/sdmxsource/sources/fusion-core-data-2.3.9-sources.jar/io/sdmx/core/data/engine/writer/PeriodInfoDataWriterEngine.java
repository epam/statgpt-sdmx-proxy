package io.sdmx.core.data.engine.writer;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

/**
 * Capture the start and end period details for the dataset
 *
 */
public class PeriodInfoDataWriterEngine extends DataWriterEngineProxy {
	private SdmxDate startPeriod;
	private SdmxDate endPeriod;
	

	@Override
	public void writeObservation(Observation obs) {
		SdmxDate thisPeriod = obs.getSdmxObsTime();
		if(thisPeriod != null) {
			if(this.startPeriod == null || thisPeriod.isEarlier(startPeriod)) {
				this.startPeriod = thisPeriod;
			}
			if(this.endPeriod == null || thisPeriod.isLater(endPeriod)) {
				this.endPeriod = thisPeriod;
			}
		}
	}
	
	public SdmxPeriod getPeriod() {
		if(startPeriod != null) {
			return new SdmxPeriodImpl(startPeriod, endPeriod);
		}
		return null;
	}

	public SdmxDate getStartPeriod() {
		return startPeriod;
	}

	public SdmxDate getEndPeriod() {
		return endPeriod;
	}
}
