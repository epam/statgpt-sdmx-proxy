package io.sdmx.core.data.api.model.process;

import io.sdmx.core.data.api.factory.IDataProcessFactory;
import org.codehaus.jettison.json.JSONObject;

/**
 * Represents one step in a process
 */
public interface IProcessStep {

	/**
	 * @return identifier of the process to apply, this must match the identity of a {@link IDataProcessFactory}
	 */
	String getProcessId();
	
	/**
	 * @return identification for this {@link IProcessStep} which can be used as outputs for other {@link IProcessStep}
	 */
	String getStepId();
	
	/**
	 * @return true to capture step metrics, false if not
	 */
	boolean captureMetrics();
	
	/**
	 * @return an object of properties to configure the process step
	 */
	JSONObject getProcessProperties();
}
