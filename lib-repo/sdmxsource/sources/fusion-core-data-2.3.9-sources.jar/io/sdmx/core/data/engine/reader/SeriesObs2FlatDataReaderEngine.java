package io.sdmx.core.data.engine.reader;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * Reads data conforming to the {@link DataReaderEngine} Interface, and converts it to flat data
 */
public class SeriesObs2FlatDataReaderEngine implements IFlatDataReaderEngine {
	private DATASET_POSITION datasetPosition = DATASET_POSITION.DATASET;
	protected DataReaderEngine dre;
	private HeaderBean header;
	private DatasetHeaderBean datasetHeader;
	
	//FIxed Dataset State
	private Map<String, String> datasetAttributes = new HashMap<>();
	private Set<String> observationConcepts = new HashSet<>();
	
	//Changing Row State
	private Map<String, String> currentSeriesData;
	private Map<String, String> currentRowData;

	private IDatasetStructures structures = null;
	private IDataRow currentRow = null;

	
	public SeriesObs2FlatDataReaderEngine(DataReaderEngine dre) {
		this.dre = dre;
	}
	
	@Override
	public IFlatDataReaderEngine createCopy() {
		return new SeriesObs2FlatDataReaderEngine(dre.createCopy());
	}

	@Override
	public HeaderBean readHeader() {
		if(this.header == null) {
			this.header = dre.getHeader();
		}
		return this.header;
	}

	@Override
	public DatasetHeaderBean readDatasetHeader() {
		if(this.datasetHeader == null) {
			this.datasetHeader = dre.getCurrentDatasetHeaderBean();
		}
		return this.datasetHeader;
	}

	@Override
	public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
		switch(datasetPosition) {
		case DATASET:
			if(!dre.moveNextDataset()) {
				return false;
			}
			this.datasetHeader = dre.getCurrentDatasetHeaderBean();
			if(dre.getDatasetAttributes() != null) {
				populateMap(dre.getDatasetAttributes().getAttributes(), datasetAttributes);
			}
			this.structures = new DatasetStructures(dre.getDataStructure(), dre.getDataFlow(), dre.getProvisionAgreement(), null);
			setObservationConcepts();
			if(!moveNextKey()) {
				return moveNextRow(exHandler);  //move to the next dataset
			}
			return true;
		case OBSERVATION:
			if(moveNextObs()) {
				return true;
			}
			datasetPosition = DATASET_POSITION.SERIES;
			return moveNextRow(exHandler);
		case SERIES:
			if(moveNextKey()) {
				return true;
			}
			datasetPosition = DATASET_POSITION.DATASET;
			return moveNextRow(exHandler);
		default:
			break;
		}
		return false;
	}
	
	private void setObservationConcepts() {
		DataStructureBean dsd = structures.getDataStructure();
		observationConcepts = new HashSet<>();
		observationConcepts.addAll(SdmxCollectionUtil.identifiablesIds(dsd.getObservationAttributes()));
		observationConcepts.addAll(SdmxCollectionUtil.identifiablesIds(dsd.getMeasures()));
		if(dsd.getTimeDimension() != null) {
			observationConcepts.add(dsd.getTimeDimension().getId());
		}
	}

	private boolean moveNextKey() {
		currentRow = null;
		currentSeriesData = null;
		if(dre.moveNextKeyable()) {
			this.datasetPosition = DATASET_POSITION.SERIES;
			Keyable currentKey = dre.getCurrentKey();
			currentSeriesData = new HashMap<>(datasetAttributes);
			populateMap(currentKey.getKey(), currentSeriesData);		
			populateMap(currentKey.getAttributes(), currentSeriesData);		
			if(!moveNextObs()) {
				currentRowData = currentSeriesData;
			}
			return true;
		}
		return false;
	}

	private boolean moveNextObs() {
		currentRowData = null;
		if(dre.moveNextObservation()) {
			boolean isSameKey = this.datasetPosition == DATASET_POSITION.OBSERVATION;
			this.datasetPosition = DATASET_POSITION.OBSERVATION;
			Observation currentObs = dre.getCurrentObservation();
			currentRowData = isSameKey ? new HashMap<>(datasetAttributes) : new HashMap<>(currentSeriesData);
			
			populateMap(currentObs.getAttributes(), currentRowData);
			if(currentObs.getDimensionId() != null) {
				currentRowData.put(currentObs.getDimensionId(), currentObs.getDimensionValue());
			}
			for(String measure : currentObs.getMeasureMap().keySet()) {
				currentRowData.put(measure, currentObs.getMeasureCode(measure));
			}
			if(isSameKey) {
				for(String obsConcept :observationConcepts) {
					if(!currentRowData.containsKey(obsConcept)) {
						currentRowData.put(obsConcept, null);
					}
				}
				currentRow = currentRow.modifyValues(currentRowData);
			} else {
				currentRow = null; //Lazy load
			}
			return true;
		}
		return false;
	}

	private void populateMap(List<KeyValue> keyValues, Map<String, String> toPopulate) {
		if(keyValues == null) {
			return;
		}
		for(KeyValue kv : keyValues) {
			toPopulate.put(kv.getConcept(), kv.getCode());
		}
	}

	@Override
	public IDataRow getCurrentRow() {
		if(currentRow == null) {
			currentRow = new DataRow(structures, currentRowData);
		}
		return currentRow;
	}

	@Override
	public void reset() {
		dre.reset();
		datasetPosition = DATASET_POSITION.DATASET;

		//FIxed Dataset State
		datasetAttributes = new HashMap<>();
		structures = null;
		observationConcepts = new HashSet<>();
		
		//Changing Row State
		currentSeriesData = null;
		currentRowData = null;

		currentRow = null;
	}

	@Override
	public void close() {
		dre.close();
	}

}
