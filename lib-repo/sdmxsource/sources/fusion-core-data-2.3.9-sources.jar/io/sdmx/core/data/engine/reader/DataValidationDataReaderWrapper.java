package io.sdmx.core.data.engine.reader;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

@Deprecated  //not used
public class DataValidationDataReaderWrapper extends AbstractWrapperedDataReaderEngine implements DataReaderEngine {
	private Map<Integer, DataStructureBean> dsds = new HashMap<>();
	private Map<Integer, DataflowBean> flows = new HashMap<>();
	private Map<Integer, ProvisionAgreementBean> provs = new HashMap<>();
	private Map<Integer, DataProviderBean> providers = new HashMap<>();
	private String senderId;
	
	private DATASET_ACTION action;
	private Date embargoDate;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private HeaderRetrievalManager headerRetrievalManager;
	private boolean modifyDatasetHeader = false;
	private ReadableDataLocation rdl;
	private DataValidationErrorHandler exceptionHandler;
	private DataStructureBean defaultDSD;

	private DataReaderManager drm;
	
	public DataValidationDataReaderWrapper(DataReaderEngine dre,
											ReadableDataLocation rdl,
											SdmxBeanRetrievalManager beanRetrievalManager,
											HeaderRetrievalManager headerRetrievalManager,
											DataValidationErrorHandler exceptionHandler,
											DataReaderManager drm) {
		super(dre);
		
		this.rdl = rdl;
		this.beanRetrievalManager = beanRetrievalManager;
		this.headerRetrievalManager = headerRetrievalManager;
		this.exceptionHandler = exceptionHandler;
		this.drm = drm;
	}
	

	@Override
	public HeaderBean getHeader() {
		HeaderBean header = super.getHeader();
		boolean hasSender = ObjectUtil.validString(senderId);
		
		if (header == null) {
			if(hasSender) {
				header = new HeaderBeanImpl(senderId);
			} else if(headerRetrievalManager != null){
				header = new HeaderBeanImpl(headerRetrievalManager.getHeader().getSender().getId());
			} else {
				header = new HeaderBeanImpl("ZZZ");
			}
		} else {
			PartyBean modifiedSender;
			PartyBean party = header.getSender();
			
			if(hasSender) {
				//User override
				if (party != null) {
					modifiedSender = new PartyBeanImpl(party.getName(), senderId, party.getContacts(), party.getTimeZone());
				} else {
					modifiedSender = new PartyBeanImpl(null, senderId, null, null);
				}
				header.setSender(modifiedSender);
			}
		}
		if (action != null) {
			header.setAction(action);
		}
		if (embargoDate != null) {
			header.setEmbargoDate(embargoDate);
		}
		
		return header;
	}
	
	public void setModifyDatasetHeader(boolean modifyDatasetHeader) {
		this.modifyDatasetHeader = modifyDatasetHeader;
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		DatasetHeaderBean currentHeader = super.getCurrentDatasetHeaderBean();
		if(!modifyDatasetHeader) {
			return currentHeader;
		}
		IDSDRelatedBean maint = getProvisionAgreement();
		if(maint == null) {
			maint = getDataFlow();
		}
		if(maint == null) {
			maint = getDataStructure();
		}
		DatasetStructureReferenceBean dssDatasetStructureReferenceBean = new DatasetStructureReferenceBeanImpl(maint.getURN());
		if(currentHeader != null) {
			return currentHeader.modifyDataStructureReference(dssDatasetStructureReferenceBean);
		}
		
		HeaderBean header = getHeader();
		if(header != null) {
			return new DatasetHeaderBeanImpl(header.getId(), header.getAction(), dssDatasetStructureReferenceBean);
		}
		return new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.INFORMATION, dssDatasetStructureReferenceBean);
	}

	public void setDefaultDSD(DataStructureBean dsd) {
		this.defaultDSD = dsd;
	}
	
	public void setDataStructure(int dsNum, DataStructureBean dsd) {
		if(dsd == null) {
			dsds.remove(dsNum);
		} else {
			dsds.put(dsNum, dsd);
			flows.remove(dsNum);
			providers.remove(dsNum);
			provs.remove(dsNum);
		}
	}
	
	public void setDataflow(int dsNum, DataflowBean flow) {
		if(flow == null) {
			flows.remove(dsNum);
		} else {
			flows.put(dsNum, flow);
		}
	}
	
	public void setProvider(int dsNum, DataProviderBean provider) {
		if(provider == null) {
			provs.remove(dsNum);
			providers.remove(dsNum);
		} else {
			providers.put(dsNum, provider);
		}
	}
	
	public void setProvision(int dsNum, ProvisionAgreementBean prov) {
		if(prov == null) {
			provs.remove(dsNum);
			providers.remove(dsNum);
		} else {
			provs.put(dsNum, prov);
			DataProviderBean provider = beanRetrievalManager.getBean(prov.getDataproviderRef().getReference());
			providers.put(dsNum, provider);
			
			DataflowBean flow = beanRetrievalManager.getBean(prov.getStructureUseage().getReference());
			flows.put(dsNum, flow);
		}
	}

	@Override
	public DataStructureBean getDataStructure() {
		return getDataStructure(getDatasetPosition());
	}

	@Override
	public DataflowBean getDataFlow() {
		return getDataFlow(getDatasetPosition());
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return getProvisionAgreement(getDatasetPosition());
	}
	
	@Override
	public boolean moveNextDataset() {
		return super.moveNextDataset();
	}
	
	public DataProviderBean getDataProvider(int idx) {
		if(providers.containsKey(idx)) {
			return providers.get(idx);
		}
		if(getProvisionAgreement(idx) != null) {
			DataProviderBean provider = beanRetrievalManager.getBean(getProvisionAgreement().getDataproviderRef().getReference());
			providers.put(idx, provider);
			return provider;
		}
		return null;
	}
	
	public DataStructureBean getDataStructure(int idx) {
		if(dsds.containsKey(idx)) {
			return dsds.get(idx);
		}
		return null;
	}

	public DataflowBean getDataFlow(int idx) {
		if(flows.containsKey(idx)) {
			return flows.get(idx);
		}
		return null;
	}

	public ProvisionAgreementBean getProvisionAgreement(int idx) {
		if(provs.containsKey(idx)) {
			return provs.get(idx);
		}
		return null;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
	
	public void setAction(DATASET_ACTION action) {
		this.action = action;
	}
	
	public void setEmbargoDate(Date aDate) {
		this.embargoDate = aDate;
	}
	
	@Override
	public void reset() {
		super.close();
		if(defaultDSD != null) {
			super.dataReaderEngine = drm.getDataReaderEngine(rdl, defaultDSD, null, null, exceptionHandler);
		} else {
			super.dataReaderEngine = drm.getDataReaderEngine(rdl, beanRetrievalManager, exceptionHandler);
		}
	}
	
	public void closeUnderlyingReader() {
		super.close();
	}

	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		throw new SdmxNotImplementedException("Not implemented");
	}
}
