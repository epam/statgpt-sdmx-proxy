package io.sdmx.core.data.engine.reader;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.zip.InflaterInputStream;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.engine.writer.KryoDataWriterEngine;
import io.sdmx.core.data.model.kryo.AnnotationListSerializer;
import io.sdmx.core.data.model.kryo.DatasetAttributesSerializer;
import io.sdmx.core.data.model.kryo.DatasetHeaderSerializer;
import io.sdmx.core.data.model.kryo.DatasetStructuresSerializer;
import io.sdmx.core.data.model.kryo.HeaderSerializer;
import io.sdmx.core.data.model.kryo.KeyableSerializer;
import io.sdmx.core.data.model.kryo.ObsSerializer;
import io.sdmx.core.data.util.KryoUtil;

public class KryoDataReaderEngine implements DataReaderEngine {
	private Kryo kryo = KryoUtil.createInstance();
	
	private Input input;
	private KeyableSerializer kser;
	private ObsSerializer obsser = new ObsSerializer(null);

	//STATE
	private HeaderBean header;
	private DatasetHeaderBean dsHeader;
	private IDatasetStructures dsStructures;
	private IDatasetAttributes dsAttributes;
	private int dsPos = 0;
	private int keyPos = 0;
	private int obsPos = 0;
	private Keyable currentKey;
	private Keyable nextKey;
	private Observation currentObs;
	private Integer currentType;
	
	private ReadableDataLocation rdl;
	private SdmxBeanRetrievalManager brm;
	
	public KryoDataReaderEngine(ReadableDataLocation rdl, SdmxBeanRetrievalManager brm) {
		this.brm = brm;
		this.rdl = rdl;
		reset();
	}

	@Override
	public FormatDetails getFormatDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return dsStructures.getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return dsStructures.getDataflow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return dsStructures.getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return dsPos;
	}

	@Override
	public int getKeyablePosition() {
		return keyPos;
	}

	@Override
	public int getObsPosition() {
		return obsPos;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		return moveType(KryoDataWriterEngine.DATASET_START);
	}

	@Override
	public void reset() {
		InputStream in = new InflaterInputStream(rdl.getInputStream());
		this.input = new Input(in);
		this.dsPos = 0;
		this.keyPos = 0;
		this.obsPos = 0;
		this.header = null;
		this.dsStructures = null;
		this.dsAttributes = null;
		this.currentKey = null;
		this.currentObs = null;
		this.nextKey = null;
	}

	@Override
	public HeaderBean getHeader() {
		return header;
	}

	@Override
	public DataReaderEngine createCopy() {
		return new KryoDataReaderEngine(rdl.copy(), brm);
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return dsHeader; 
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return dsAttributes; 
	}

	@Override
	public Keyable getCurrentKey() {
		return currentKey;
	}

	@Override
	public Observation getCurrentObservation() {
		return currentObs;
	}

	@Override
	public boolean moveNextObservation() {
		this.currentObs = null;
		return moveType(KryoDataWriterEngine.OBS_START);
	}

	@Override
	public boolean moveNextKeyable() {
		this.currentKey = null;
		if(nextKey != null) {
			currentKey = nextKey;
			nextKey = null;
			return true;
		}
		return moveType(KryoDataWriterEngine.KEY_START);
	}
	
	
	private boolean moveType(int moveToType) {
		if(currentType != null && currentType == KryoDataWriterEngine.END) {
			return false;
		}
		nextKey = null;
		currentType = Integer.MIN_VALUE;
		while(currentType != moveToType) {
			currentType = kryo.readObject(input, Integer.class);
			switch(currentType) {
			case KryoDataWriterEngine.HEADER_START :
				this.header =  kryo.readObjectOrNull(input, HeaderBean.class, HeaderSerializer.getInstance());
				break;
			case KryoDataWriterEngine.DATASET_START :
				dsPos++;
				dsHeader = kryo.readObjectOrNull(input, DatasetHeaderBean.class, DatasetHeaderSerializer.getInstance());
				dsStructures = kryo.readObjectOrNull(input, IDatasetStructures.class, DatasetStructuresSerializer.getReadInstance(brm));
				dsAttributes = kryo.readObjectOrNull(input, IDatasetAttributes.class, DatasetAttributesSerializer.getInstance());
				this.kser = new KeyableSerializer(dsStructures.getDataflow(), dsStructures.getDataStructure());
				break;
			case KryoDataWriterEngine.KEY_START :
				keyPos++;
				currentKey = kryo.readObject(input, Keyable.class, this.kser);
				this.obsser.setSeriesKey(currentKey);
				if(moveToType == KryoDataWriterEngine.OBS_START) {
					nextKey = currentKey;
					return false;
				}
				break;
			case KryoDataWriterEngine.OBS_START :
				obsPos++;
				this.currentObs = kryo.readObject(input, Observation.class, this.obsser);
				break;
			case KryoDataWriterEngine.END :
				return false;
			}
		}
		return true;
	}

	@Override
	public List<FooterMessage> close() {
		this.input.close();
		this.rdl.close();
		return Collections.emptyList();
	}
	
}