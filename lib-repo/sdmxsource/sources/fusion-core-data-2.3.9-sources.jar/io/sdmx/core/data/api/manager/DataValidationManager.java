package io.sdmx.core.data.api.manager;

import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;

/**
 * The DataValidationManager is responsible for validating data read from a DataReaderEngine
 */
public interface DataValidationManager {

	/**
	 * For DataValidatorFactory who require the full data context to accurately report an error there are two levels of validation,
	 * 1. Do not include these validators
	 * 2. Include the validator, use the input data reader as the full context
	 * 3. Include the validator, and ensure the full context is resolved
	 */
	enum VALIDATION_TYPE {
		IGNORE_FULL_DATA_CONTEXT_VALIDATION,
		RESOLVE_FULL_DATA_CONTEXT,
		FULL_DATA_CONTEXT_PROVIDED
	}

	/**
	 * Validates the data read from the DataReaderEngine
	 * @param dre the reader engine used to read the dataset.  The DataValidationManager will reset the DataReaderEngine
	 * @param exceptionHandler
	 * @param validationType
	 * @param fullValidation if true, all registered DataValidatorFactories will be used, if false, then only those which vary with respect to Dataflow or Provision will be used
	 * @param errorLimitPerValidator - 0 or less to indicate unlimited
	 * @return a set of DataValidatorFactory that have been validated against
	 * @throws SdmxSyntaxException if the data is not syntactically valid
     * @throws SdmxSemmanticException if the data is syntactically valid, however it contains invalid content
	 */
	Set<DataValidatorFactory> validateData(DataReaderEngine dre,
										   DataValidationErrorHandler exceptionHandler,
										   VALIDATION_TYPE validationType,
										   boolean fullValidation,
										   int errorLimitPerValidator) throws SdmxSyntaxException, SdmxSemmanticException;

	/**
	 * Validates the data read from the DataReaderEngine
	 * @param dre the reader engine used to read the dataset.  The DataValidationManager will reset the DataReaderEngine
	 * @param exceptionHandler
	 * @param fullValidation if true, all registered DataValidatorFactories will be used, if false, then only those which vary with respect to Dataflow or Provision will be used
	 *
	 * @return a set of DataValidatorFactory that have been validated against
	 *
	 * @throws SdmxSyntaxException if the data is not syntactically valid
	 * @throws SdmxSemmanticException if the data is syntactically valid, however it contains invalid content
	 */
	Set<DataValidatorFactory> validateData(DataReaderEngine dre,
										   DataValidationErrorHandler exceptionHandler,
										   VALIDATION_TYPE validationType,
										   boolean fullValidation) throws SdmxSyntaxException, SdmxSemmanticException;

	/**
	 * Returns a Set of factories that will be used for this data validation.
	 * This is useful when you need to reset any existing errors for a particular factory type.
	 * @param fullValidation if true, all registered DataValidatorFactories will be used, if false, then only those which vary with respect to Dataflow or Provision will be used
	 * @return
	 */
	Set<DataValidatorFactory> obtainFactoriesToBeUsedInDataValidation(boolean fullValidation);
}
