package io.sdmx.core.data.api.manager;

import java.util.Collection;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;

/**
 * Used to Obtain a DataReaderEngine capable of reading the information contained in a ReadableDataLocation
 */
public interface DataReaderManager {

	/**
	 * Obtains a DataReaderEngine that is capable of reading the data which is exposed via the ReadableDataLocation
	 *
	 * @param sourceData - giving access to an InputStream of the data
	 * @param dsd - describes the data in terms of the dimensionality
	 * @param dataflowBean (optional) provides further information about the data
	 * @param provison (optional)  provides further information about who is reporting the data
	 * @param exceptionHandler - the DataReaderEngine will use this to report {@link SdmxSemmanticException} in the dataset, which make the dataset
	 * invalid with regards to the specification, but do not prevent the dataset from being read.  If no errorHandler is provided, then the error will simply
	 * be thrown by the DataReaderEngine on data read.
	 * @param optional dataRead notifier
	 * @return
	 * @throws SdmxNotImplementedException if ReadableDataLocation or DataStructureBean is null
	 */
	DataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData,
										 DataStructureBean dsd,
										 DataflowBean dataflowBean,
										 ProvisionAgreementBean provison,
										 DataValidationErrorHandler exceptionHandler);
	


	/**
	 * Obtains a DataReaderEngine that is capable of reading the data which is exposed via the ReadableDataLocation
	 *
	 * @param sourceData - giving access to an InputStream of the data
	 * @param retrievalManager - used to obtain the DataStructure(s) that describe the data
	 * @param exceptionHandler - the DataReaderEngine will use this to report {@link SdmxSemmanticException} in the dataset, which make the dataset
	 * invalid with regards to the specification, but do not prevent the dataset from being read.  If no errorHandler is provided, then the error will simply
	 * be thrown by the DataReaderEngine on data read.
	 * @param optional dataRead notifier
	 * @return
	 * @throws SdmxNotImplementedException if ReadableDataLocation or DataStructureBean is null
	 */
	DataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData,
										 SdmxBeanRetrievalManager retrievalManager,
										 DataValidationErrorHandler exceptionHandler);
	
	
	

	/**
	 * @return all of the Data Reader Factories that this Manager manages
	 */
	Collection<DataReaderFactory> getDataReaderFactories();
}