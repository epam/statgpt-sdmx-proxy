package io.sdmx.core.data.model;

import java.util.Date;

/**
 * Describes options for data transformation
 */
public class TransformOptions {
	private boolean includeObs;  
	private boolean includeAttributes; 
	private boolean includeHeader; 
	private String pivotDimension;
	private Integer maxObs; 
	private Date dateFrom; 
	private Date dateTo;
	private boolean copyHeader;
	private boolean closeWriter;
	
	
	public String getPivotDimension() {
		return pivotDimension;
	}
	public void setPivotDimension(String pivotDimension) {
		this.pivotDimension = pivotDimension;
	}
	public boolean isIncludeObs() {
		return includeObs;
	}
	public void setIncludeObs(boolean includeObs) {
		this.includeObs = includeObs;
	}

	public boolean isIncludeAttributes() {
		return includeAttributes;
	}
	public void setIncludeAttributes(boolean includeAttributes) {
		this.includeAttributes = includeAttributes;
	}
	public boolean isIncludeHeader() {
		return includeHeader;
	}
	public void setIncludeHeader(boolean includeHeader) {
		this.includeHeader = includeHeader;
	}
	public Integer getMaxObs() {
		return maxObs;
	}
	public void setMaxObs(Integer maxObs) {
		this.maxObs = maxObs;
	}
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public boolean isCopyHeader() {
		return copyHeader;
	}
	public void setCopyHeader(boolean copyHeader) {
		this.copyHeader = copyHeader;
	}
	public boolean isCloseWriter() {
		return closeWriter;
	}
	public void setCloseWriter(boolean closeWriter) {
		this.closeWriter = closeWriter;
	}
}
