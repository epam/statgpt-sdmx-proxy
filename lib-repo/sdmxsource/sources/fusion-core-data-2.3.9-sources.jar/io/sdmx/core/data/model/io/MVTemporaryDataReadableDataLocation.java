package io.sdmx.core.data.model.io;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.List;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.core.data.engine.writer.MVStoreDataWriterEngine;
import io.sdmx.utils.core.collection.CollectionUtil;

public class MVTemporaryDataReadableDataLocation implements ReadableDataLocation {
	private static final long serialVersionUID = 1L;
	private MVStoreDataWriterEngine writerEngine;
	private boolean isClosed;
	private boolean isProtected;

	public MVTemporaryDataReadableDataLocation(MVStoreDataWriterEngine writerEngine) {
		this.writerEngine = writerEngine;
	}
	
	@Override
	public FILE_FORMAT getFormat() {
		return FILE_FORMAT.BINARY;
	}

	@Override
	public InputStream getInputStream() {
		 return new ByteArrayInputStream(this.getClass().getName().getBytes());
	}

	@Override
	public String getName() {
		return "MVStore Temp";
	}

	@Override
	public void close() {
		if(!isClosed && !isProtected()) {
			writerEngine.close();
			isClosed = true;
		}
	}

	@Override
	public boolean isClosed() {
		return isClosed;
	}

	public MVStoreDataWriterEngine getWriterEngine() {
		return writerEngine;
	}

	@Override
	public ReadableDataLocation copy() {
		return new MVTemporaryDataReadableDataLocation(writerEngine);
	}

	@Override
	public boolean isProtected() {
		return isProtected;
	}

	@Override
	public void setProtected(boolean protect) {
		this.isProtected = protect;
		this.writerEngine.setProtected(protect);
	}
	
	@Override
	public boolean splitable() {
		return false;
	}

	@Override
	public List<ReadableDataLocation> split(boolean closeSource) {
		return CollectionUtil.getImmutableList(this);
	}

	@Override
    public ReadableDataLocation move(Path moveTo) {
        throw new SdmxNotImplementedException("Move not implemented for MVTemporaryDataReadableDataLocation");
    }

    @Override
    public long getSize() {
        throw new SdmxNotImplementedException("Get Size not implemented for MVTemporaryDataReadableDataLocation");
    }
}
