package io.sdmx.core.data.model;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;

public class DatasetInfo {
	private int groups;
	private int keys;
	private int observations;

	//Array mapping to dataset index
	private DatasetHeaderBean headers;
	private IDatasetStructures structures;
	
	private boolean isFinal;

	private Map<TIME_FORMAT, SdmxPeriod> reportingPeriods = new HashMap<>();  //period for frequency per dataset

	public DatasetInfo(DatasetHeaderBean headers, IDatasetStructures structures) {
		this.headers = headers;
		this.structures = structures;
	}
	
	/**
	 * DatasetInfo becomes immutable
	 */
	public void makeFinal() {
		if(reportingPeriods != null) {
			reportingPeriods = Collections.unmodifiableMap(reportingPeriods);
		}
		this.isFinal = true;
	}
	
	public void addGroup() {
		if(isFinal) {
			throw new IllegalArgumentException("Can not add group count to final DatasetInfo");
		}
		groups++;
	}
	
	public void setGroups(int groups) {
		if(isFinal) {
			throw new IllegalArgumentException("Can not set groups count to final DatasetInfo");
		}
		this.groups = groups;
	}

	public int getGroups() {
		return groups;
	}

	public void addKey() {
		if(isFinal) {
			throw new IllegalArgumentException("Can not add key count to final DatasetInfo");
		}
		keys++;
	}
	
	public void setKeys(int keys) {
		if(isFinal) {
			throw new IllegalArgumentException("Can not set key count to final DatasetInfo");
		}
		this.keys = keys;
	}

	public int getKeys() {
		return keys;
	}

	public void addObservation() {
		if(isFinal) {
			throw new IllegalArgumentException("Can not add observation count to final DatasetInfo");
		}
		observations++;
	}
	public int getObservations() {
		return observations;
	}

	public DatasetHeaderBean getHeaders() {
		return headers;
	}

	public ProvisionAgreementBean getProvision() {
		return structures.getProvisionAgreement();
	}

	public DataflowBean getFlow() {
		return structures.getDataflow();
	}

	public DataStructureBean getDsd() {
		return structures.getDataStructure();
	}

	public Map<TIME_FORMAT, SdmxPeriod> getReportingPeriods() {
		return reportingPeriods;
	}

	public void setReportingPeriods(Map<TIME_FORMAT, SdmxPeriod> reportingPeriods) {
		if(isFinal) {
			throw new IllegalArgumentException("Can not set reporting periods to final DatasetInfo");
		}
		this.reportingPeriods = reportingPeriods;
	}
}
