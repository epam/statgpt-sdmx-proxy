package io.sdmx.core.data.model.mapping.value;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch.MAP_RULE_TYPE;
import io.sdmx.core.data.model.mapping.explain.ExplainMapMatch;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.regex.RegexUtil;

/**
 * A pattern match rule, which can also contain child rules (if rule 1 match, then go to next part of array and check)
 * 
 * A fuzzy matching rule may be made up of reg-ex and capture groups for each value, an example of how this would be applied:
 * 
 * Input
 * FREQ :  (A|M|Q)(0-9)
 * INDICATOR : EMP_(A-Z)
 * 
 * Output
 * FREQ : \1         - capture group 1 - A, M, or Q
 * DOMAIN : EMP
 * INDICATOR: \1_\2  - capture group 2, the Freq number, capture group 3 (the indicator letter)
 * 
 * Example Input:  A4,EMP_B
 * Example Output: A, EMP, 4_B
 */
public class FuzzyMappingRule {
	private Pattern pattern; //Mutually exclusive with value
	private String value;    //Mutually exclusive with pattern
	
	
	private int startIndex;  //optional - defaults to 0 if not set
	private int endIndex;    //optional

	private FuzzyMappingRule childRule; //optional
	
	boolean hasCaptureGroups = false;
	
	private String[] outputValue; //Mapped output - note, this may contain capture groups
	
	private String captureGroupValue;    //A source string which contains a capture group, mutually exclusive with value & pattern
	private boolean captureGroupValueRegEx; //If the source string contains a capture group and is regex then the resulting string needs to be compiled
	
	public FuzzyMappingRule(IMappedRelationshipBean mappedRelationship) {
		this(mappedRelationship.getSourceValue(), 0);
		this.outputValue = new String[mappedRelationship.getTargetValue().size()];
		this.hasCaptureGroups = hasCaptureGroups();
		for(int i=0;i < mappedRelationship.getTargetValue().size(); i++) {
			String targetValue = mappedRelationship.getTargetValue().get(i);
			if(!hasCaptureGroups && RegexUtil.hasCaptureGroup(targetValue)) {
				hasCaptureGroups = true;
			}
			this.outputValue[i] = targetValue;
		}
	}
	
	private FuzzyMappingRule(List<IMappedValueBean> values, int idx) {
		IMappedValueBean mappedVale = values.get(idx);
		if(values.size() > idx+1) {
			this.childRule = new FuzzyMappingRule(values, (idx+1));
		}
		if(mappedVale.isRegEx()) {
			if(RegexUtil.hasCaptureGroup(mappedVale.getValue())) {
				this.captureGroupValue = mappedVale.getValue();
				this.captureGroupValueRegEx = true;
				hasCaptureGroups = true;
			} else {
				this.pattern = mappedVale.getPattern();
			}
		} else {
			if(RegexUtil.hasCaptureGroup(mappedVale.getValue())) {
				this.captureGroupValue = mappedVale.getValue();
				hasCaptureGroups = true;
			} else {
				this.value = mappedVale.getValue();
			}
		}
		this.startIndex = mappedVale.getStartIndex();
		this.endIndex = mappedVale.getEndIndex();
		if(this.startIndex < 0) {
			this.startIndex = 0;
		}
	}
	
	private boolean hasCaptureGroups( ) {
		if(childRule != null && childRule.hasCaptureGroups()) {
			return true;
		}
		return hasCaptureGroups;
	}
	
	/**
	 * Attempts to map the input string, returns null if no mapping found
	 * @param input input values to match the mapping rules
	 * @return mapped values
	 */
	public String[] map(String... input) {
		return map(null, input);
	}
	
	/**
	 * Explains the mapping result by breaking down the components and rules used
	 * @param input input values to match the mapping rules
	 * @return an {@link ExplainMapMatch} for each target component
	 */
	public List<ExplainMapMatch> explain(String... input) {
		List<ExplainMapMatch> explainMatch = new ArrayList<>();
		map(explainMatch, input);
		return explainMatch;
	}
	
	private String[] map(List<ExplainMapMatch> explain, String... input) {
		List<String> captureGroup = hasCaptureGroups ? new ArrayList<>() : null;
		if(map(input, 0, captureGroup, explain)) {
			if(ObjectUtil.validCollection(captureGroup)) {
				//Replace output value with captured group
				String[] returnValue = new String[outputValue.length];
				for(int i=0;i < outputValue.length; i++) {
					String val = outputValue[i];
					returnValue[i] = RegexUtil.replaceCaptureGroups(val, CollectionUtil.toArray(captureGroup));
				}
				if(explain != null) {
					for(ExplainMapMatch explainMatch : explain) {
						explainMatch.setCaptureGroups(captureGroup);
					}
				}
				return returnValue;
			} else {
				return outputValue;
			}
		}
		return null;
	}
	
	private boolean map(String[] input, int i, List<String> captureGroup, List<ExplainMapMatch> explain) {
		if(map(input[i], captureGroup, explain)) {
			if(childRule != null) {
				return childRule.map(input, i+1, captureGroup, explain);
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Attempts to map the string based on this rule alone, returns the mapped value if there is one, null if not
	 * @param map
	 * @param captureGroup - if this rule has capture groups in the output the list is passed in to be populated with the group if the mapping was a match
	 * @return
	 */
	private boolean map(String map, List<String> captureGroup, List<ExplainMapMatch> explain) {
		if(map == null) {
			return false;
		}
		boolean isMatch = false;
		//1. Substring if required
		if(startIndex > 0 || endIndex > 0) {
			if(endIndex > 0) {
				//Remember start index is either set, or defaulted to 0
				int end = map.length() < endIndex ? map.length() : endIndex;
				map = map.substring(startIndex, end);
			} else {
				//we know start index is greater then 0, but end index is not
				map = map.substring(startIndex);
			}
		}
		try {
			//2. Match on value or pattern
			if(value != null) {
				isMatch = value.equals(map);
			} else if(captureGroupValue != null) {
				String matchVal = RegexUtil.replaceCaptureGroups(captureGroupValue, CollectionUtil.toArray(captureGroup));
				if(captureGroupValueRegEx) {
					isMatch = runPatternMatch(map, Pattern.compile(matchVal), captureGroup);
				} else {
					isMatch = matchVal.equals(map);
				}
			} else {
				isMatch = runPatternMatch(map, pattern, captureGroup);
			}
		} finally {
			if(isMatch && explain != null) {
				ExplainMapMatch match = new ExplainMapMatch();
				if(startIndex > 0) {
					match.setSubstringStart(startIndex);
				}
				if(endIndex > 0) {
					match.setSubstringEnd(endIndex);
				}
				match.setRuleType(value != null ? MAP_RULE_TYPE.EQUALS : MAP_RULE_TYPE.REG_EX);
				if(pattern != null) {
					match.setMatch(pattern.pattern());
				}
				if(captureGroupValue != null) {
					match.setMatch(captureGroupValue);
				}
				match.setInput(map);
				explain.add(match);
			}
		}
		return isMatch;
	}
	
	private boolean runPatternMatch(String map, Pattern pattern, List<String> captureGroup) {
		Matcher matcher = pattern.matcher(map);
		if(matcher.matches()) {
			if (captureGroup != null && matcher.groupCount() > 0 ) {
				// Note group 0 is the whole element, so start from 1
				for (int i=1; i <= matcher.groupCount(); i++) {
					captureGroup.add(matcher.group(i));
				}
			}
			return true;
		}
		return false;
	}
}

