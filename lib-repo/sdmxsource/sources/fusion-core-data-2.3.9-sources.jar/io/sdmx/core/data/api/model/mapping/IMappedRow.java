package io.sdmx.core.data.api.model.mapping;

import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

public interface IMappedRow {

	/**
	 * @return list of mapped periods
	 */
	Set<SdmxPeriod> getMappedPeriods();
	
	/**
	 * @param period one of the periods in the getMappedPeriods method
	 * @return mapped rows for period, typically returns only 1 row, however if the mapping collapses multiple measures into a single Measure split by Dimension ID the return
	 * from the mapping can contain multiple output rows for only 1 input row
	 */
	List<IDataRow> getMappedValues(SdmxPeriod period);
	
	/**
	 * @return immutable map of IComponentMapping rules that are were used, did not output anything, and have output required
	 */
	Set<IComponentMapping> getUnmappedComponents();
}
