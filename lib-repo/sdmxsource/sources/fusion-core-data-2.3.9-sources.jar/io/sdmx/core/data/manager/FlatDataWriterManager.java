package io.sdmx.core.data.manager;

import java.io.OutputStream;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.manager.IFlatDataWriterManager;

public class FlatDataWriterManager extends AbstractDataWriterManager implements IFlatDataWriterManager {
	
	public FlatDataWriterManager(DataFormatManager dataFormatManager, DataWriterManager dataWriterManager) {
		super(dataFormatManager);
	}
	
	@Override
	public IFlatDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		return super.getFlatDataWriterEngine(dataFormat, out, dataQuery);
	}
}
