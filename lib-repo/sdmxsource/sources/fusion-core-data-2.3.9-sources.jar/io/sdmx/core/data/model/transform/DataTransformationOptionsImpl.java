package io.sdmx.core.data.model.transform;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.utils.core.io.MultipartOutputStream;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.io.UncloseableOutputStream;

public class DataTransformationOptionsImpl implements DataTransformationOptions {
    private static final Logger LOG = LoggerFactory.getLogger(DataTransformationOptionsImpl.class);

	private SDMX_STRUCTURE_TYPE highestAttachment;
	private DataFormat outputDataFormat;
	private DataFormat unmappedDataFormat;
	private Integer datasetIndex;
	private IURNSingle<? extends IStructureMapRelatedBean> mappedOutputReference;
	private String senderId;
	private String receiverId;
	private String datasetId;
	private DATASET_ACTION datasetAction;
	private boolean includeUnmappedData;
	private boolean includeUnmappedReport;
	private boolean includeMetrics;

	private ZipOutputStream zOut;
	private MultipartOutputStream mOut;
	private UncloseableOutputStream out;
	private boolean skipValidation;

	public DataTransformationOptionsImpl(DataFormat outputDataFormat, ZipOutputStream out) {
		this.outputDataFormat = outputDataFormat;
		this.zOut = out;
		this.out = new UncloseableOutputStream(out);
	}

	public DataTransformationOptionsImpl(DataFormat outputDataFormat, MultipartOutputStream out) {
		this.outputDataFormat = outputDataFormat;
		this.mOut = out;
		this.out = new UncloseableOutputStream(out);
	}

	public DataTransformationOptionsImpl(DataFormat outputDataFormat, OutputStream out) {
		this.outputDataFormat = outputDataFormat;
		this.out = new UncloseableOutputStream(out);
	}
	
	@Override
	public SDMX_STRUCTURE_TYPE getHighestAttachment() {
		return highestAttachment;
	}

	@Override
	public void setHighestAttachment(SDMX_STRUCTURE_TYPE highestAttachment) {
		this.highestAttachment = highestAttachment;
	}

	@Override
	public void startPart(FormatDetails formatDetails, String fileName) {
		startPart(formatDetails.getMimeType(), fileName, formatDetails.getFileExtension());
	}

	@Override
	public void startPart(String mimeType, String fileName, String fileExtension) {
		try {
			String fullFileName = fileName+"."+fileExtension;
			if(zOut != null) {
				ZipEntry entry = new ZipEntry(fullFileName);
				zOut.putNextEntry(entry);
			} else if(mOut != null) {
				mOut.startPart(mimeType, fileName, fullFileName);
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void close() {
	    LOG.debug("close output stream");
		if(zOut != null) {
			StreamUtil.closeStream(zOut);
		} else if(mOut != null) {
			StreamUtil.closeStream(mOut);
		}
		out.forceClose();
	}

	@Override
	public OutputStream getOutputStream() {
		return out;
	}

	@Override
	public DataFormat getOutputDataFormat() {
		return outputDataFormat;
	}

	@Override
	public Integer getDatasetIndex() {
		return datasetIndex;
	}

	@Override
	public IURNSingle<? extends IStructureMapRelatedBean> getMappedOutputReference() {
		return mappedOutputReference;
	}

	@Override
	public String getSenderId() {
		return senderId;
	}
	
	@Override
	public DataFormat getIncludeUnmappedFormat() {
		if(this.unmappedDataFormat == null) {
			return this.getOutputDataFormat();
		}
		return this.unmappedDataFormat;
	}

	@Override
	public void setIncludeUnmappedFormat(DataFormat format) {
		this.unmappedDataFormat = format;
	}

	@Override
	public String getReceiverId() {
		return receiverId;
	}

	@Override
	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	@Override
	public void setDatasetIndex(Integer datasetIndex) {
		this.datasetIndex = datasetIndex;
	}

	@Override
	public void setMappedOutputReference(IURNSingle<? extends IStructureMapRelatedBean> mappedOutputReference) {
		this.mappedOutputReference = mappedOutputReference;
	}

	@Override
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	@Override
	public boolean isIncludeUnmappedData() {
		return includeUnmappedData;
	}

	@Override
	public void setIncludeUnmappedData(boolean bool) {
		this.includeUnmappedData = bool;
	}

	@Override
	public boolean isIncludeUnmappedReport() {
		return includeUnmappedReport;
	}

	@Override
	public void setIncludeUnmappedReport(boolean bool) {
		this.includeUnmappedReport = bool;
	}
	
	@Override
	public boolean isIncludeMetrics() {
		return includeMetrics;
	}

	@Override
	public void setIncludeMetrics(boolean bool) {
		this.includeMetrics = bool;
	}

	@Override
	public String getDatasetId() {
		return datasetId;
	}

	@Override
	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}

	@Override
	public DATASET_ACTION getDatasetAction() {
		return datasetAction;
	}

	@Override
	public void setDatasetAction(DATASET_ACTION datasetAction) {
		this.datasetAction = datasetAction;
	}

	@Override
	public void setSkipValidation(boolean bool) {
		this.skipValidation = bool;
	}
	
	@Override
	public boolean isSkipValidation() {
		return this.skipValidation;
	}
}