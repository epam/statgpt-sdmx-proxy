package io.sdmx.core.data.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.core.data.factory.csv.FlatCsvDataReaderFactory;
import io.sdmx.core.data.factory.csv.FlatCsvDataFormatFactory;

/**
 * Register all factories with the fusion framework
 */
public class FusionCoreDataModule implements IFusionModule {

	public static void register() {
	    FlatCsvDataFormatFactory.registerInstance();
	    FlatCsvDataReaderFactory.registerInstance();
	}
}
