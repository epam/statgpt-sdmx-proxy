package io.sdmx.core.data.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.engine.reader.FlatDataReaderEngine2SeriesObs;
import io.sdmx.core.data.engine.reader.MutlipleDataReaderEngineMultipleDatasets;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.api.factory.data.IFlatDataReaderFactory;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

public class DataReaderManagerImpl implements DataReaderManager {

	private SortedSet<DataReaderFactory> factories;
	private DataFormatManager dataFormatManager;

	public DataReaderManagerImpl(DataFormatManager dataFormatManager) {
		this.dataFormatManager = dataFormatManager;
		SingletonStore.registerInstance(this);
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData,
			DataStructureBean dsd,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreement,
			DataValidationErrorHandler exceptionHandler) {
		if (StreamUtil.isEmpty(sourceData)) {
			throw new UnrecognisedFormatException("Unable to create a DataReaderEngine as InputFile has no content");
		}
		if (ZipUtil.isAZip(sourceData)) {
	        List<ReadableDataLocation> items = ZipUtil.unzipFiles(sourceData);
	        List<DataReaderEngine> dres = new ArrayList<>();
	        for (ReadableDataLocation anRdl : items) {
	        	DataReaderEngine dre = getDataReaderEngine(anRdl, dsd, dataflowBean, provisionAgreement, exceptionHandler);
	        	dres.add(dre);
            }
	        if(dres.size() == 1) {
	        	return dres.get(0);
	        } else {
	        	return new MutlipleDataReaderEngineMultipleDatasets(dres, null);
	        }
	    }

		DataFormat df = dataFormatManager.getDataFormat(sourceData);
		for(DataReaderFactory currentFactory : getDataReaderFactories()) {
			DataReaderEngine dre = currentFactory.getDataReaderEngine(df, sourceData, dsd, dataflowBean, provisionAgreement, exceptionHandler);
			if(dre != null) {
				return dre;
			}
		}
		//Check the flat readers
		for(IFlatDataReaderFactory currentFactory : FusionBeanStore.getBeans(IFlatDataReaderFactory.class)) {
			IFlatDataReaderEngine dre = currentFactory.getDataReaderEngine(df, sourceData, new IDatasetStructuresRetrievalManager() {

				@Override
				public IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef) {
					return new DatasetStructures(dsd, dataflowBean, provisionAgreement, null);
				}
			});
			if(dre != null) {
				return new FlatDataReaderEngine2SeriesObs(dre);
			}
		}
		throw new UnrecognisedFormatException(sourceData.getInputStream());
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ReadableDataLocation sourceData,
			SdmxBeanRetrievalManager retrievalManager,
			DataValidationErrorHandler exceptionHandler) {
		if (StreamUtil.isEmpty(sourceData)) {
			throw new UnrecognisedFormatException("Unable to create a DataReaderEngine as InputFile has no content");
		}
		if (ZipUtil.isAZip(sourceData)) {
	        List<ReadableDataLocation> items = ZipUtil.unzipFiles(sourceData);
	        List<DataReaderEngine> dres = new ArrayList<>();
	        for (ReadableDataLocation anRdl : items) {
	        	DataReaderEngine dre = getDataReaderEngine(anRdl, retrievalManager, exceptionHandler);
	        	dres.add(dre);
            }
	        if(dres.size() == 1) {
	        	return dres.get(0);
	        } else {
	        	return new MutlipleDataReaderEngineMultipleDatasets(dres, null);
	        }
	    }

		DataFormat df = dataFormatManager.getDataFormat(sourceData);
		if(df == null) {
			throw new UnrecognisedFormatException(sourceData.getInputStream());
		}
		for(DataReaderFactory currentFactory : getDataReaderFactories()) {
			DataReaderEngine dre = currentFactory.getDataReaderEngine(df, sourceData, retrievalManager, exceptionHandler);
			if(dre != null) {
				return dre;
			}
		}

		IDatasetStructuresRetrievalManager retMan = new BeanRetrievalDatasetStructuresRetrievalManager(retrievalManager);

		//Check the flat readers
		for(IFlatDataReaderFactory currentFactory : FusionBeanStore.getBeans(IFlatDataReaderFactory.class)) {
			IFlatDataReaderEngine dre = currentFactory.getDataReaderEngine(df, sourceData, retMan);
			if(dre != null) {
				return new FlatDataReaderEngine2SeriesObs(dre);
			}
		}
		try {
			MESSAGE_TYPE message = SdmxMessageUtil.getMessageType(sourceData);
			if(message == MESSAGE_TYPE.ERROR) {
				SdmxMessageUtil.parseSdmxErrorMessage(sourceData);
			}
		} catch(Throwable th) {}
		throw new UnrecognisedFormatException(sourceData.getInputStream());
	}



	@Override
	public Collection<DataReaderFactory> getDataReaderFactories() {
		if(factories == null) {
			synchronized(this) {
				factories = new TreeSet<>(new FactoryComparator());
				factories.addAll(FusionBeanStore.getBeans(DataReaderFactory.class));
			}
		}
		return factories;
	}




	private class FactoryComparator implements Comparator<DataReaderFactory> {

		@Override
		public int compare(DataReaderFactory o1, DataReaderFactory o2) {
		    // The DataReaderFactories are ordered by:
		    // * priority - the lower the number the higher the priority
		    // * override - should a factory be placed lower down the list
		    // * name - alphabetical ascending order
		    int priority1 = o1.getPriority();
		    int priority2 = o2.getPriority();
		    if (priority1 != priority2) {
		        if (priority1 < priority2) return -1;
		        return 1;
		    }
		    // Priorities are equivalent so compare by override and then by name
	        String claz1 = o1.getClass().getName();
            String claz2 = o2.getClass().getName();
            if(ObjectUtil.equivalent(o1.getOverride(), claz2)) {
                return -1;
            }
            if(ObjectUtil.equivalent(o2.getOverride(), claz1)) {
                return 1;
            }
            return claz1.compareTo(claz2);


		}
	}
}