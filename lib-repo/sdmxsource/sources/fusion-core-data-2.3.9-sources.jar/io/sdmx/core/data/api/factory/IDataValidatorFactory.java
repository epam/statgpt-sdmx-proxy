package io.sdmx.core.data.api.factory;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;

public interface IDataValidatorFactory {
	
	/**
	 * @return a unique identifier for the factory
	 */
	String getFactoryId();
	
	/**
	 * Returns a Data Validation Engine proxied on top of the {@link IFlatDataWriterEngine}
	 */
	IFlatDataWriterEngine getDataValidationEngine(IFlatDataWriterEngine proxy);
}
