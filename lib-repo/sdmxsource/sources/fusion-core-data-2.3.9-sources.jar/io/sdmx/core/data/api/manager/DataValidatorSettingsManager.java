package io.sdmx.core.data.api.manager;

import java.io.OutputStream;

/**
 * Used to obtain category levels, set category levels and write category levels
 */
public interface DataValidatorSettingsManager {

    /**
     * Saves the level against the id
     * @param id
     * @param level
     * @returns whether the save was successful or not
     */
    boolean saveLevel(String id, Integer level);


    /**
     * Writes the categories as:
     *
     *  {
            "FormatAgnostic": [{
                "Id": "FACTORY_ID",
                "Name": "Mandatory Attributes",
                "Description": "Ensures Mandatory Attributes are reported",
                "MinLevel" : 0,
                "Level": 1
            }]
            "FormatSpecific": [{
                "DataFormat": "ExcelValidation",
                "errors": [{
                    "Id": "DATES_OUT_OF_SEQUENCE",
                    "Name": "Sequential Dates",
                    "Description": "description for: Sequential Dates",
                    "MinLevel" : 0,
                    "Level": 0
                }]
            }, {
                "facId": "SDMXValidation",
                "errors": [{
                    "Id": "HEADER_ELEMENT_DUPLICATE",
                    "Name": "Duplicate Header Element",
                    "Description": "description for: Duplicate Header Element",
                    "MinLevel" : 0,
                    "Level": 0
                }...
             ]
            }],
        }
     *
     *
     * @param out
     */
    void writeCategories(OutputStream out);

}