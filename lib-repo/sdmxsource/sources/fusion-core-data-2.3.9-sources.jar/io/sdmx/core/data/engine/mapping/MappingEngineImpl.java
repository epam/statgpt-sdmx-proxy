package io.sdmx.core.data.engine.mapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.PeriodContents;
import io.sdmx.api.date.PeriodsContainer;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.api.engine.mapping.MappingEngine;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.api.model.mapping.IExplainMap;
import io.sdmx.core.data.api.model.mapping.IMappedRow;
import io.sdmx.core.data.api.model.mapping.ITimeMapping;
import io.sdmx.core.data.api.model.mapping.ITimePeriodMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.data.model.mapping.MappedRow;
import io.sdmx.core.data.model.mapping.explain.ExplainMap;
import io.sdmx.core.data.model.mapping.explain.ExplainMapOutputRow;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.PeriodSetContents;
import io.sdmx.utils.core.date.PeriodsContainerImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class MappingEngineImpl implements MappingEngine, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(MappingEngineImpl.class);

	private static MappingEngineImpl INSTANCE;

	public static MappingEngineImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MappingEngineImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private MappingEngineImpl() {}

	@Override
	public IExplainMap explainMapping(MappingRules rules, IDataRow inputValues) {
		boolean isMappingFrom = rules.getFromDataStructure().equals(inputValues.getDatasetStructures().getDataStructure());
		if(!isMappingFrom) {
			rules = rules.getReverseMapping();
		}
		ExplainMap explain = new ExplainMap(rules, inputValues);

		//Convert null or missing values to empty string so they can map
		Map<String, String> emptyRowValues = new HashMap<>();
		for(ComponentBean comp : rules.getFromDataStructure().getComponents()) {
			String value = inputValues.getReportedValue(comp.getId());
			if(value == null) {
				emptyRowValues.put(comp.getId(), "");
			}
		}
		if(emptyRowValues.size() > 0) {
			emptyRowValues.putAll(inputValues.getRowData());
			inputValues = new DataRow(inputValues.getDatasetStructures(), emptyRowValues);
		}
		
		
		mapValues(rules, inputValues, explain);
		return explain;
	}

	@Override
	public IMappedRow mapValues(MappingRules rules, IDataRow sourceData) {
		return mapValues(rules, sourceData, null);
	}

	private IMappedRow mapValues(MappingRules rules, IDataRow sourceData, ExplainMap explainMap) {
		Set<IComponentMapping> unmappedComponents = new HashSet<>();
		Map<String, String> inputValues = sourceData.getRowData();
		//Is a split of measures required
		Map<SdmxPeriod, List<IDataRow>> returnRows = new HashMap<>();
		if(rules.getSplitByMeasure().size() > 0) {
			List<Set<String>> loopMeasures = new ArrayList<>();
			for(Set<String> keepMeasures : rules.getSplitByMeasure()) {
				for(String keepMeasure : keepMeasures) {
					if(inputValues.get(keepMeasure) != null) {
						loopMeasures.add(keepMeasures);
						break;
					}
				}
			}
			//Rule - if there are no measures, then map once, if there is at least one on the row, then map only the rows that have
			//measure values against them
			if(loopMeasures.size() == 0) {
				ExplainMapOutputRow explainRow = explainMap == null ? null : explainMap.addOutputRow();
				addMappedRows(rules, returnRows, getMappedValues(rules, inputValues, explainRow, unmappedComponents), explainRow);
			} else {
				for(Set<String> currentMeasureLoop : loopMeasures) {
					Map<String, String> inputValuesCopy = new HashMap<>(inputValues);
					//remove any measures not in this loop
					for(MeasureDimensionBean measure : rules.getFromDataStructure().getMeasures()) {
						if(!currentMeasureLoop .contains(measure.getId())) {
							inputValuesCopy.remove(measure.getId());
						}
					}
					ExplainMapOutputRow explainRow = explainMap == null ? null : explainMap.addOutputRow();
					addMappedRows(rules, returnRows, getMappedValues(rules, inputValuesCopy, explainRow, unmappedComponents), explainRow);
				}

			}
		} else {
			ExplainMapOutputRow explainRow = explainMap == null ? null : explainMap.addOutputRow();
			addMappedRows(rules, returnRows, getMappedValues(rules, inputValues, explainRow, unmappedComponents), explainRow);
		}
		return new MappedRow(returnRows, unmappedComponents);
	}

	/**
	 * adds the mapped values for each period into a MappedRow and adds to the list
	 *
	 * @param mappedRows this list has the MappedRows added to it
	 * @param mappedIdValuesForPeriod to unpack
	 */
	private void addMappedRows(MappingRules rules, Map<SdmxPeriod, List<IDataRow>> mappedRows, Map<SdmxPeriod, Map<String, Set<String>>> mappedIdValuesForPeriod, ExplainMapOutputRow explainMap) {
		IDatasetStructures outputStructures = new DatasetStructures(rules.getToDataStructure(), rules.getToDataflow(), null, null);
		for(SdmxPeriod currentPeriod : mappedIdValuesForPeriod.keySet()) {
			Map<String, Set<String>> mappedIdValues = mappedIdValuesForPeriod.get(currentPeriod);
			
			IDataRow outputRow = new DataRow(outputStructures, null, mappedIdValues, null, null);
			if(explainMap != null) {
				explainMap.addOutput(currentPeriod, outputRow);
			}
			CollectionUtil.addToMappedList(mappedRows, currentPeriod, outputRow);
		}
	}

	/**
	 * For an input DSD, and a key, returns what the mapped component values are.
	 *
	 * For example, this could return a Map of the following:
	 *
	 * SdmxPeriod.AllPeriods
	 * {FREQ=[H], DER_TYPE=[A], DER_RATING=[B], DER_SECTOR_UDL=[F]...}
	 *
	 * @param dsd - the input DSD that the values conform to
	 * @param values - the reported values for dimensions or attributes for the input key
	 * @param explainMap - optional explain plan to describe the mapping
	 * @param requestedPeriod - the period that the mapping is being applied to
	 * @return PeriodsContainer containing a map for each period.  Each map is a mapping of dimension/attribute id to a set of mapped code values
	 */
	protected Map<SdmxPeriod, Map<String, Set<String>>> getMappedValues(MappingRules rules, Map<String, String> values, ExplainMapOutputRow explainMap, Set<IComponentMapping> unmappedComponents) {
		//1. CREATE PERIOD CONTAINER AND DEFAULT CONTAINER
		//Create a container for periods
		PeriodsContainer<Map<String, Set<String>>> periodsContainer = PeriodsContainerImpl.getMapContainer(false);

		// For each of the dimensions...
		//validComponents(values.keySet(), rules.getFromDataStructure());
		Map<String, Set<IComponentMappingRules>> singleMappingRules  = rules.getSingleMappingRules();
		Set<IComponentMappingRules> combinationMappingRules = rules.getCombinationMappingRules();

		Set<String> inputKeys = new HashSet<>(values.keySet());  //All the dimensions and attributes used as inputs for this mapping
		Set<String> mappedComponents= new HashSet<>();    //Of the above, all the ones that were mapped
		Set<String> removeUnmapped = new HashSet<>();

		//1. Is there an output TIME_PERIOD?
		ITimePeriodMapping timePeriodMapping = rules.getTagetTimePeriodMapping();
		SdmxPeriod requestedPeriod = null;
		if(timePeriodMapping != null) {
			String outputTimePeriod = timePeriodMapping.performMapping(values);
			// Added this defence. Somehow the outputTImePeriod is the word "null" !
			if(outputTimePeriod != null && !outputTimePeriod.equals("null")) {
				Map<String, Set<String>> fixedValues = new HashMap<>();
				Set<String> fixedValue = new HashSet<>();
				fixedValue.add(outputTimePeriod);
				fixedValues.put(DimensionBean.TIME_DIMENSION_FIXED_ID, fixedValue);
				try {
					if(explainMap != null) {
						explainMap.addExplainMapComponent(timePeriodMapping.explain(values));
					}
					requestedPeriod = new SdmxPeriodImpl(outputTimePeriod, outputTimePeriod);
					periodsContainer.addContents(fixedValues, SdmxPeriodImpl.ALL_PERIODS);
				} catch(SdmxSemmanticException e) {
					if(LOG.isDebugEnabled()) {
						LOG.debug("Unable to convert Time Period into SdmxPeriod: {} ",outputTimePeriod);
					}
				}
			} else if (values.containsKey(DimensionBean.TIME_DIMENSION_FIXED_ID) &&  timePeriodMapping.outputRequired()) {
				String timeValue = values.get(DimensionBean.TIME_DIMENSION_FIXED_ID);
				if(timeValue != null && timeValue.length() > 0) {
					// No Time based mapping occurred. Report an error if the source has a TIME_PERIOD field
					unmappedComponents.add(timePeriodMapping);
				}
			}
		}

		for(String fixedComponentId : rules.getFixedValues().keySet()) {
			Map<String, Set<String>> fixedValues = new HashMap<>();
			Set<String> fixedValue = new HashSet<>();
			fixedValue.add(rules.getFixedValues().get(fixedComponentId));
			fixedValues.put(fixedComponentId, fixedValue);
			periodsContainer.addContents(fixedValues, SdmxPeriodImpl.ALL_PERIODS);
		}

		for(String componentId : values.keySet()) {
			String componentValue = values.get(componentId);
			if(componentValue == null) {
				continue;
			}
			
			PeriodContents<Set<KeyValue>> contents = new PeriodSetContents<>();
			PeriodsContainer<Set<KeyValue>> keyValuesForPeriod = new PeriodsContainerImpl<>(contents);

			//Map Time
			Set<ITimeMapping> timeMappings = rules.getTimeMapping().get(componentId);
			if(timeMappings != null) {
				for(ITimeMapping timeMapping : timeMappings) {
					String freqComp = timeMapping.getFrequencyComponent();
					String freq = null;
					if(freqComp != null) {
						//TODO THIS IS WRONG - IT SHOULD BE LOOKING AT THE OUTPUT FREQ, NOT INPUT
						freq = values.get(freqComp);
					}
					String mappedTimePeriod = timeMapping.getMappedValue(componentValue, freq);
					if(mappedTimePeriod != null) {
						if(explainMap != null) {
							explainMap.addExplainMapComponent(timeMapping.explain(componentValue, freq));
						}
						String outputComponent = timeMapping.getTargetComponent();
						Set<String> mappedTimeKvSet = new HashSet<>();
						mappedTimeKvSet.add(mappedTimePeriod);
						Map<String, Set<String>> keyValueMapForPeriod = periodsContainer.getContents(SdmxPeriodImpl.ALL_PERIODS);
						if(keyValueMapForPeriod == null) {
							keyValueMapForPeriod = new HashMap<>();
						}
						keyValueMapForPeriod.put(outputComponent, mappedTimeKvSet);
						periodsContainer.addContents(keyValueMapForPeriod, SdmxPeriodImpl.ALL_PERIODS);
					} else if(!componentValue.equals("") && timeMapping.outputRequired()){
						unmappedComponents.add(timeMapping);
					}
				}
			}

			if(requestedPeriod == null) {
				requestedPeriod = new SdmxPeriodImpl(new Date(), new Date(), TIME_FORMAT.DATE);
			}
			Set<IComponentMappingRules> mapping = singleMappingRules.get(componentId);
			if(mapping != null) {
				// There is a mapping for this component
				for(IComponentMappingRules currentMapping : mapping) {
					Map<SdmxPeriod, Set<KeyValue>> mappedCodes = currentMapping.getMappedCodes(requestedPeriod, componentValue);
					boolean hasMapping = false;
					for(SdmxPeriod period : mappedCodes.keySet()) {
						if(mappedCodes.get(period).size() > 0) {
							hasMapping = true;
							if(explainMap != null) {
								explainMap.addExplainMapComponent(currentMapping.explain(requestedPeriod, componentValue));
							}
							break;
						}
					}
					if(!hasMapping) {
						// No mapping, so determine and report the rule(s) that was not used
						if(currentMapping.outputRequired()) {
							// If the original componentValue was blank do not report as unmapped
							if (!componentValue.equals("")) {
							    unmappedComponents.add(currentMapping);
							}
						}
						
						//FR-3133 If there is not a mapping, still store the empty value so that the intersection can be determined (no intersection)
						//Remove the empty value before returning
						//No mapping for component
						Set<KeyValue> valuesForPeriod = new HashSet<>();

						for(String target : currentMapping.getTargetComponents()) {
							ComponentBean comp = rules.getToDataStructure().getComponent(target);
							if(comp == null) {
								continue;
							}
							if(comp.getStructureType() == SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
								AttributeBean attr = (AttributeBean) comp;
								if(attr.getAttachmentLevel() != ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
									continue;
								}
							}
							if(comp.getStructureType() == SDMX_STRUCTURE_TYPE.PRIMARY_MEASURE) {
								continue;
							}
							removeUnmapped.add(comp.getId());
							valuesForPeriod.add(KeyValueImpl.getInstance(comp.getId(), ""));
						}
						keyValuesForPeriod.addContents(valuesForPeriod, SdmxPeriodImpl.ALL_PERIODS);
						continue;
					}
					mappedComponents.add(componentId);
					for(SdmxPeriod currentPeriod : mappedCodes.keySet()) {
						Set<KeyValue> valuesForPeriod = mappedCodes.get(currentPeriod);
						if(valuesForPeriod.size() > 0) {
							keyValuesForPeriod.addContents(valuesForPeriod, currentPeriod);
						}
					}
				}
				for(SdmxPeriod currentPeriod : keyValuesForPeriod.getPeriods()) {
					Set<KeyValue> keyValuesForCurrentPeriod = keyValuesForPeriod.getContents(currentPeriod);
					if(ObjectUtil.validCollection(keyValuesForCurrentPeriod)) {
						Map<String, Set<String>> keyValueMapForPeriod = CollectionUtil.keyValuesToMap(keyValuesForCurrentPeriod);
						periodsContainer.addContents(keyValueMapForPeriod, currentPeriod);
					}
				}
			}
		}
		
		for(IComponentMappingRules currentMapping : combinationMappingRules) {
			if(inputKeys.containsAll(currentMapping.getSourceComponents())) {
				List<String> sourceComponents = currentMapping.getSourceComponents();
				String[] sourceValues = new String[sourceComponents.size()];
				Map<SdmxPeriod, Set<KeyValue>> mappedCodes = new HashMap<>();
				int i = 0;
				boolean hasInputValue = false;
				for(String compId : sourceComponents) {
					String codeId = values.get(compId);
					sourceValues[i] = codeId;
					if(!hasInputValue) {
						hasInputValue = codeId != null && codeId.length() > 0;
					}
					i++;
				}
				mappedCodes.putAll(currentMapping.getMappedCodes(requestedPeriod, sourceValues));
				if(mappedCodes.size() > 0) {
					mappedComponents.addAll(sourceComponents);
					if(explainMap != null) {
						explainMap.addExplainMapComponent(currentMapping.explain(requestedPeriod, sourceValues));
					}
				} else {
					// Report that this is unmapped
					if(hasInputValue && currentMapping.outputRequired()) {
						unmappedComponents.add(currentMapping);
					}
				}

				for(SdmxPeriod currentPeriod : mappedCodes.keySet()) {
					Set<KeyValue> keyValuesForCurrentPeriod = mappedCodes.get(currentPeriod);
					if(ObjectUtil.validCollection(keyValuesForCurrentPeriod)) {
						Map<String, Set<String>> keyValueMapForPeriod = CollectionUtil.keyValuesToMap(keyValuesForCurrentPeriod);
						periodsContainer.addContents(keyValueMapForPeriod, currentPeriod);
					}
				}
			}
		}
		inputKeys.removeAll(mappedComponents);

		Map<SdmxPeriod, Map<String, Set<String>>> allPeriods = periodsContainer.getContents();
		Map<SdmxPeriod, Map<String, Set<String>>> returnPeriods;
		if(requestedPeriod != null) {
			returnPeriods = new HashMap<>();
			for(SdmxPeriod currentPeriod : allPeriods.keySet()) {
				if(currentPeriod.isInPeriod(requestedPeriod)) {
					returnPeriods.put(currentPeriod, allPeriods.get(currentPeriod));
				}
			}
		} else {
			returnPeriods = allPeriods;
		}

		//Remove and whitespace values - which were required to fix FR-3133
		if(removeUnmapped.size() > 0) {
			for(SdmxPeriod currentPeriod : returnPeriods.keySet()) {
				Map<String, Set<String>> mappedValues = returnPeriods.get(currentPeriod);
				for(String toRemove : removeUnmapped) {
					mappedValues.remove(toRemove);
				}
			}
		}
		//Ensure no other whitespace values exist
		//This can happen now that any missing values in the source attributes/measures are reported as empty strings in order to support the ability to
		//map an empty string to something - the issue is that in the case the mapping is implicit (copy source to target) it can output empty strings
		//which need to be removed before reporting the mapped output
		for(SdmxPeriod currentPeriod : returnPeriods.keySet()) {
			Map<String, Set<String>> mappedValues = returnPeriods.get(currentPeriod);
			removeUnmapped = null;
			for(String compId : mappedValues.keySet()) {
				if(mappedValues.get(compId).remove("")) {
					if(removeUnmapped == null) {
						removeUnmapped = new HashSet<>();
					}
					removeUnmapped.add(compId);
				}
			}
			if(removeUnmapped != null) {
				for(String toRemove : removeUnmapped) {
					mappedValues.remove(toRemove);
				}
			}
		}
		return returnPeriods;
	}
}
