package io.sdmx.core.data.api.manager;

import java.util.concurrent.TimeoutException;

import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.model.validate.DatasetDetailsImpl;

public interface FusionValidationManager {

	/**
	 * Builds and returns a {@link DatasetDetailsImpl} object from the {@link ReadableDataLocation}.  The {@link DatasetDetailsImpl} is
	 * also stored by the manager for future retrieval by UID.
	 * The filename passed in will be used as the filename for the file uploaded.
	 *
	 * @param filename may be null
	 * @param rdl
	 * @param sRef
	 * @param priorDataDependent
	 * @param mergeDatasets
	 * @param consolidationOptions
	 * @return
	 */
	DataSetDetails getDatasetDetails(String filename, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets, IConsolidationOptions consolidationOptions, boolean skipValidation);

	/**
	 * Builds and returns a {@link DatasetDetailsImpl} object from the {@link ReadableDataLocation}.  The {@link DatasetDetailsImpl} is
	 * also stored by the manager for future retrieval by UID.
	 * The filename passed in will be used as the filename for the file uploaded.
	 *
	 * @param filename may be null
	 * @param rdl
	 * @param sRef
	 * @param priorDataDependent
	 * @param mergeDatasets
	 * @return
	 */
	DataSetDetails getDatasetDetails(String filename, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets);

	/**
	 * Returns a {@link DatasetDetailsImpl} from a UID
	 * @param uid
	 * @return
	 * @throws TimeoutException if a {@link DatasetDetailsImpl} could not be found with the UID
	 * @throws SdmxUnauthorisedException if the {@link DatasetDetailsImpl} requested belong to a different user
	 */
	DataSetDetails getDatasetDetails(String uid) throws TimeoutException, SdmxUnauthorisedException;

	/**
	 * Writes the data, with optional mapping
	 * @param uid
	 * @param transformOptions
	 * @throws TimeoutException
	 * @throws SdmxUnauthorisedException
	 */
	void writeDatasetDetails(String uid, DataTransformationOptions transformOptions)  throws TimeoutException, SdmxUnauthorisedException;
}