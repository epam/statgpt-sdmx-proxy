package io.sdmx.core.data.api.engine.mapping;

import java.io.OutputStream;

import io.sdmx.core.data.api.model.mapping.IExplainMap;

/**
 * Writes the {@link IExplainMap} to the output stream, format depends on implementation
 */
public interface IMappingExplainWriterEngine {

	/**
	 * Writes the explain map to the output stream
	 * @param explainMap
	 * @param out
	 */
	void writeExplainMap(IExplainMap explainMap, OutputStream out);
}
