package io.sdmx.core.data.engine.reader;

import java.util.List;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public class SeriesRollUpDataReaderEngine implements DataReaderEngine {
	private DataReaderEngine proxy;
	
	private int key;
	private int obs;
	private Keyable currentKey = null;
	private Keyable nextKey = null;
	
	public SeriesRollUpDataReaderEngine(DataReaderEngine proxy) {
		this.proxy = proxy;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return proxy.getFormatDetails();
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return proxy.getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return proxy.getDataFlow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return proxy.getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return proxy.getDatasetPosition();
	}

	@Override
	public int getKeyablePosition() {
		return key;
	}

	@Override
	public int getObsPosition() {
		return obs;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		key = 0;
		obs = 0;
		currentKey = null;
		return proxy.moveNextDataset();
	}

	@Override
	public void reset() {
		key = 0;
		obs = 0;
		proxy.reset();
	}

	@Override
	public HeaderBean getHeader() {
		return proxy.getHeader();
	}

	@Override
	public DataReaderEngine createCopy() {
		return new SeriesRollUpDataReaderEngine(proxy.createCopy());
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return proxy.getCurrentDatasetHeaderBean();
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return proxy.getDatasetAttributes();
	}

	@Override
	public Keyable getCurrentKey() {
		return currentKey;
	}

	@Override
	public Observation getCurrentObservation() {
		return proxy.getCurrentObservation();
	}

	@Override
	public boolean moveNextObservation() {
		if(proxy.moveNextObservation()) {
			return true;
		}
		while(proxy.moveNextKeyable()) {
			nextKey = proxy.getCurrentKey();
			if(nextKey.equals(currentKey)) {
				if(proxy.moveNextObservation()) {
					return true;
				}
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
	public boolean moveNextKeyable() {
		try {
			if(nextKey != null) {
				currentKey = nextKey;
				return true;
			}
			while(proxy.moveNextKeyable()) {
				nextKey = proxy.getCurrentKey();
				if(currentKey == null || currentKey.getShortCode().equals(nextKey.getShortCode())) {
					currentKey = nextKey;
					return true;
				}
			}
		} finally {
			nextKey = null;
		}
		return false;
	}

	@Override
	public List<FooterMessage> close() {
		return proxy.close();
	}
}
