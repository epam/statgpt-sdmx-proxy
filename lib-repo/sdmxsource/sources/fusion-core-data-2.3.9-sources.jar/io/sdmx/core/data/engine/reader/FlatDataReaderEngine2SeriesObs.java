package io.sdmx.core.data.engine.reader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.MultilingualKeyValue;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

public class FlatDataReaderEngine2SeriesObs implements DataReaderEngine {
	private IFlatDataReaderEngine flatDre;

	private DatasetHeaderBean dsHeader;
	private int datasetPosition = -1;
	private int keyablePosition = -1;
	private int obsPosition = -1;

	private IDataRow currentRow;
	private IDataRow nextRow;

	private IDatasetStructures structures;

	private List<KeyValue> datasetAttributes;
	private List<IMultilingualKeyValue> multilingualAttributes;
	private Keyable currentKey;
	private Observation currentObs;

	private boolean hasNextSeries = false;
	private boolean hasNextObs = false;
	private boolean hasNextGroup = false;

	private List<String> observationAttributes;
	private Set<String> observationConcepts;
	private List<String> dimensions;
	private List<String> seriesAttributes;
	private Map<String, List<String>> groupAttributes;

	private Map<String, String> groupAttributeToGroupIdNoDimGroup;
	private Map<String, String> groupAttributeToGroupId;


	private List<String> measures;  //Each flat row may consist of 1 or more measures (if the row contains an observation)


	private List<String> rowGroups;  //Each flat row may consist of 1 or more measures (if the row contains an observation)
	private int rowGroupIdx = -1;
	private int dsdGroupCount = 0;    //Number of groups that the DSD has

	private boolean readObs;

	public FlatDataReaderEngine2SeriesObs(IFlatDataReaderEngine flatDre) {
		this.flatDre = flatDre;
		reset();
	}

	@Override
	public DataReaderEngine createCopy() {
		return new FlatDataReaderEngine2SeriesObs(flatDre.createCopy());
	}

	@Override
	public FormatDetails getFormatDetails() {
		return flatDre.getDataFormat();
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return structures.getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return structures.getDataflow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return structures.getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return datasetPosition;
	}

	@Override
	public int getKeyablePosition() {
		return keyablePosition;
	}

	@Override
	public int getObsPosition() {
		return obsPosition;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		try {
			dsHeader = null;
			return datasetPosition == -1;
		} finally {
			datasetPosition = 0;
		}
	}

	@Override
	public void reset() {
		flatDre.reset();
		dsHeader = null;
		datasetPosition = -1;
		keyablePosition = -1;
		obsPosition = -1;
		dsdGroupCount = 0;
		hasNextGroup = false;
		hasNextObs = false;
		hasNextSeries = false;
		nextRow = null;
		readObs = false;
		currentRow = null;

		//Get DSD,Flow,Prov and Process Dataset Attributes
		if(flatDre.moveNextRow()) {
			hasNextSeries = true;
			nextRow = flatDre.getCurrentRow();
			structures = nextRow.getDatasetStructures();
			processDSD(structures.getDataStructure());
			this.nextRow = null;
			flatDre.reset();
		} else {
			// DEV-1924: Defend against being unable to read a row which would mean that
			// the required field "structures" is null which causes an issue across the code
			throw new RuntimeException("The file does not contain readable information to determine the structures");
		}
	}

	private void processDSD(DataStructureBean dsd) {
		processDatasetAttributes(dsd);
		processObservationConcepts(dsd);
		processMeasures(dsd);
		processGroupConcepts(dsd);
	}

	private void processDatasetAttributes(DataStructureBean dsd) {
		//Process Dataset Attributes
		datasetAttributes = new ArrayList<>();
		multilingualAttributes = new ArrayList<>();
		for(AttributeBean attr : dsd.getDatasetAttributes()) {
			KeyValue kv = getKeyValue(nextRow, attr.getId());
			if(kv != null) {
				datasetAttributes.add(kv);
			}
			IMultilingualKeyValue multilingualKv = getMultilingualKeyValue(nextRow, attr.getId());
			if(multilingualKv != null) {
				multilingualAttributes.add(multilingualKv);
			}
		}
		datasetAttributes = Collections.unmodifiableList(datasetAttributes);
		multilingualAttributes = Collections.unmodifiableList(multilingualAttributes);
	}

	private KeyValue getKeyValue(IDataRow row, String componentId) {
		String attrVal = row.getRowData().get(componentId);
		if(attrVal != null) {
			return KeyValueImpl.getInstance(componentId, attrVal);
		}
		Set<String> attrVals = row.getReportedValues(componentId);
		if(attrVals != null) {
			return KeyValueImpl.getInstance(componentId, CollectionUtil.toArray(attrVals));
		}
		return null;
	}

	private IMultilingualKeyValue getMultilingualKeyValue(IDataRow row, String componentId){
		Set<String> multilingualAttrVals = row.getReportedMultilingualValues(componentId);
		if(multilingualAttrVals != null) {
			List<IMultilingualNodeValue> multilingualNodeValues = new ArrayList<>();
			for (String attr:multilingualAttrVals) {
				String[] nodeValues = attr.split(";");
				List<TextTypeWrapper> wrapperList = new ArrayList<>();
				for (String value : nodeValues) {
					String[] splitString = value.split(":");
					TextTypeWrapper textTypeWrapper = new TextTypeWrapperImpl(splitString[0], splitString[1], null);
					wrapperList.add(textTypeWrapper);
				}
				MultilingualNodeValue multilingualNodeValue = new MultilingualNodeValue(wrapperList);
				multilingualNodeValues.add(multilingualNodeValue);
			}
			return MultilingualKeyValue.getInstance(componentId, multilingualNodeValues);
		}
		return null;
	}

	private void processObservationConcepts(DataStructureBean dsd) {
		//Process Observation Concepts
		this.observationConcepts = SdmxCollectionUtil.identifiablesIds(dsd.getObservationAttributes());
		this.observationConcepts.addAll(SdmxCollectionUtil.identifiablesIds(dsd.getMeasures()));
		if(dsd.getTimeDimension()!= null) {
			this.observationConcepts.add(dsd.getTimeDimension().getId());
		}
		this.observationAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getObservationAttributes());
		dimensions = SdmxCollectionUtil.identifiablesIdList(dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION));
		seriesAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getDimensionGroupAttributes());
	}

	private void processGroupConcepts(DataStructureBean dsd) {
		this.dsdGroupCount = dsd.getGroups().size();
		this.groupAttributes = new HashMap<>();
		this.groupAttributeToGroupId = new HashMap<>();
		this.groupAttributeToGroupIdNoDimGroup = new HashMap<>();
		for(GroupBean currentGroup : dsd.getGroups()) {
			String groupId = currentGroup.getId();
			//Group Dimensions referes to which dimensions are NOT a member of the group
			Set<String> groupDimensions = new HashSet<>();
			for(String dimId : dimensions) {
				if(currentGroup.getDimensionRefs().indexOf(dimId) < 0) {
					groupDimensions.add(dimId);
				}
			}
			List<String> groupAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getGroupAttributes(groupId, true));
			this.groupAttributes.put(groupId, groupAttributes);
			for(String attrId : groupAttributes) {
				groupAttributeToGroupId.put(attrId, groupId);
			}
			for(AttributeBean attrId : dsd.getGroupAttributes(groupId, false)) {
				groupAttributeToGroupIdNoDimGroup.put(attrId.getId(), groupId);
			}
		}
	}




	private void processMeasures(DataStructureBean dsd) {
		this.measures = SdmxCollectionUtil.identifiablesIdList(dsd.getMeasures());
	}

	@Override
	public HeaderBean getHeader() {
		return flatDre.readHeader();
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		if(dsHeader == null) {
			dsHeader = flatDre.readDatasetHeader();
			if(dsHeader == null) {
				IDSDRelatedBean maint = getProvisionAgreement();
				if(maint == null) {
					maint = getDataFlow();
				}
				if(maint == null) {
					maint = getDataStructure();
				}
				String dimAtObs = getDataStructure().getTimeDimension() != null ? DimensionBean.TIME_DIMENSION_FIXED_ID : DatasetStructureReferenceBean.ALL_DIMENSIONS;
				DatasetStructureReferenceBean sRef = new DatasetStructureReferenceBeanImpl(null, maint.getURN(), null, null, dimAtObs);
				dsHeader = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.INFORMATION, sRef);
			}
		}
		return dsHeader;
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return new DatasetAttributes(datasetAttributes);  //TODO Poisiton Information
	}

	@Override
	public Keyable getCurrentKey() {
		if(currentRow != null && currentKey == null && hasNextSeries) {
			Map<String, String> map = currentRow.getRowData();
			List<KeyValue> dimensionsKVs  = new ArrayList<>();
			if(this.rowGroupIdx >=0) {
				String groupId = this.rowGroups.get(rowGroupIdx);
				for(String dimId : this.getDataStructure().getGroup(groupId).getDimensionRefs()) {
					String dimVal = map.get(dimId);
					if(dimVal != null) {
						dimensionsKVs.add(KeyValueImpl.getInstance(dimId, dimVal));
					}
				}
				List<KeyValue> attributes = getAttributesFromRow(this.groupAttributes.get(groupId));
				List<IMultilingualKeyValue> multilingualAttributes = getMultilingualAttributesFromRow(this.groupAttributes.get(groupId));
				currentKey =KeyableImpl.groupKey(getDataFlow(), getDataStructure(), groupId, dimensionsKVs, attributes, multilingualAttributes);
			} else {
				for(String dimId : dimensions) {
					String dimVal = map.get(dimId);
					if(dimVal != null) {
						dimensionsKVs.add(KeyValueImpl.getInstance(dimId, dimVal));
					}
				}
				List<KeyValue> attributes = getAttributesFromRow(seriesAttributes);
				List<IMultilingualKeyValue> multilingualAttributes = getMultilingualAttributesFromRow(seriesAttributes);
				currentKey = KeyableImpl.seriesKey(getDataFlow(), getDataStructure(), dimensionsKVs, attributes, multilingualAttributes);
			}
		}
		return currentKey;
	}

	@Override
	public Observation getCurrentObservation() {
		if(currentObs == null && hasNextObs) {
			Map<String, String> rowData = currentRow.getRowData();
			List<KeyValue> measureValues = getMeasuresFromRow(measures);
			List<KeyValue> attributes = getAttributesFromRow(observationAttributes);
			List<IMultilingualKeyValue> multilingualAttributes = getMultilingualAttributesFromRow(observationAttributes);
			List<IMultilingualKeyValue> multilingualMeasures = getMultilingualAttributesFromRow(measures);
			String obsTime = rowData.get(DimensionBean.TIME_DIMENSION_FIXED_ID);
			String measureDim = obsTime != null ? DimensionBean.TIME_DIMENSION_FIXED_ID : null;
			currentObs = ObservationImpl.multipleMeasureCrossSection(getCurrentKey(), measureDim, obsTime, measureValues, attributes, multilingualAttributes, multilingualMeasures, null);
		}
		return currentObs;
	}

	private List<KeyValue> getAttributesFromRow(Collection<String> attributeIds) {
		List<KeyValue> attributes = new ArrayList<>();
		for(String attrId : attributeIds) {
			KeyValue kv = getKeyValue(currentRow, attrId);
			if(kv != null) {
				attributes.add(kv);
			}
		}
		return attributes;
	}

	private List<KeyValue> getMeasuresFromRow(Collection<String> measureIds) {
		List<KeyValue> measures = new ArrayList<>();
		for(String id : measureIds) {
			KeyValue kv = getKeyValue(currentRow, id);
			if(kv != null) {
				measures.add(kv);
			}
		}
		return measures;
	}

	private List<IMultilingualKeyValue> getMultilingualAttributesFromRow(Collection<String> attributeIds){
		List<IMultilingualKeyValue> multilingualAttributes = new ArrayList<>();
		for(String attrId : attributeIds){
			IMultilingualKeyValue multilingualKeyValue = getMultilingualKeyValue(currentRow, attrId);
			if (multilingualKeyValue != null) {
				multilingualAttributes.add(multilingualKeyValue);
			}
		}
		return multilingualAttributes;
	}


	@Override
	public boolean moveNextObservation() {
		if(this.currentKey != null && !this.currentKey.isSeries()) {
			return false;
		}
		this.currentObs = null;
		if(!hasNextObs) {
			return false;
		}

		//If the observation on this row has already been read, advance to the next  row
		if(readObs) {
			if(!flatDre.moveNextRow()) {
				this.currentRow = null;
				this.hasNextSeries = false;
				this.hasNextObs = false;
				return false;
			}
		}
		readObs = true; // This row has now been fully read
		//Check the next row for the observation
		nextRow = flatDre.getCurrentRow();
		if(nextRow != null) {
			if (isSeriesTheSame(nextRow)) {
				//Same series, so there is a new observations
				this.currentRow = nextRow;
				nextRow = null;
				//Ensure there is at least one observation concept on this row
				for(String obsConceptId : this.observationConcepts) {
					if(currentRow.getRowData().keySet().contains(obsConceptId)) {
						obsPosition++;
						return true;
					}
				}
				//If this row has no reported values for any observation concept, it may be possible that the next row
				//Has exactly the same dimension and attribute values reported, but with some observation values as well
				//This is why we recurse again, to move to the next row and perform the same checks - the recursion loop stops when either
				//There are no more rows
				//The next row is not the same series as this row (series key or series attributes change)
				//The next row is the same series/attributes AND there is at least 1 reported Measure value
				return moveNextObservation();
			}
			//Series are not the same
			hasNextObs = false;
		}
		return false;
	}

	@Override
	public boolean moveNextKeyable() {
		obsPosition= -1;
		hasNextObs = true;
		readObs = false;
		//important note - each row of data can describe information for a series, multiple measures, and group attributes
		//in order to read conforming to the key/obs data model, a single row may be multiple keys (one for the series, and one for the groups)
		//as such groups should be read first before series
		this.currentKey = null;
		if(!hasNextSeries) {
			return false;
		}
		if(hasNextGroup) {
			//This is either going to be a group
			rowGroupIdx++;
			if(rowGroups.size() > rowGroupIdx) {
				//Still in a group, reutrn true
				return true;
			}
			hasNextGroup = false;
			rowGroupIdx = -1;
			if(!this.currentRow.isPartialKey()) {
				//return true if this row also contains series data, otherwise move to the next row
				return true;
			}
		}
		//		hasNextObs = false;
		rowGroupIdx = -1;
		try {
			//If the iterator is already on the next row, then move it to the current row
			//and return true
			if(nextRow != null) {
				this.currentRow = nextRow;
				nextRow = null;
				this.currentObs = null;
				this.currentKey = null;
				keyablePosition++;
				return true;
			}
			//move the iterator to the next row and check for the next series
			while(flatDre.moveNextRow()) {
				IDataRow nextRow = flatDre.getCurrentRow();
				if(nextRow != null) {
					boolean rowContainsADimension = false;
					// Check if the row contains at least one dimension
					for(String dimId : this.dimensions)  {
						if(nextRow.getRowData().containsKey(dimId)) {
							rowContainsADimension = true;
							if(this.currentRow == null) {
								this.currentRow = nextRow;
								this.currentObs = null;
								keyablePosition++;
								return true;
							}
							//There is another series IF the series attributes or dimensions differ from the current row
							if(!isSeriesTheSame(nextRow)) {
								this.currentKey = null;
								this.currentObs = null;
								this.currentRow = nextRow;
								keyablePosition++;
								return true;
							}
						}
					}
					
					if (!rowContainsADimension) {
						// BIS MED-IT: #349
						// No dimensions present on this row.
						// If there are NO attributes at all or dataset attributes ONLY, then ignore this line
						// If there was any series or observation attributes, or measures process this line
						if (rowContainsElement(nextRow, this.seriesAttributes)) {
							setCurrentRow(nextRow);
							return true;
						}
						if (rowContainsElement(nextRow, this.observationAttributes)) {
							setCurrentRow(nextRow);
							return true;
						}
						if (rowContainsElement(nextRow, this.measures)) {
							setCurrentRow(nextRow);
							return true;
						}
					}
				}

			}
		} finally {
			hasNextGroup = false;
			//Set the value of hasNextObs if the current row is not null and contains observation concepts
			if(currentRow != null) {
				Map<String, String> rowData = currentRow.getRowData();
				//If the row has a full series key:
				if(!this.currentRow.isPartialKey()) {
					//then check if it also contains observations
					//					for(String obsConceptId : this.observationConcepts) {
					//						if(rowData.keySet().contains(obsConceptId)) {
					//							hasNextObs = true;
					//							break;
					//						}
					//					}
					//Check to see if this row also contains group attributes which are not mirrored by a Dimension Group
					processRowGroups(groupAttributeToGroupIdNoDimGroup);
				} else {
					//Check to see if this row contains group attributes which may be mirrored by a Dimension Group
					processRowGroups(groupAttributeToGroupId);
				}
			}
		}
		hasNextSeries = false;
		return false;
	}
	
	/**
	 * Does the row contain any of the items in the List of Ids
	 * @param row
	 * @param items
	 * @return
	 */
	private boolean rowContainsElement(IDataRow row, List<String> items) {
		for(String id : items)  {
			if(row.getRowData().containsKey(id)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * "Reset" the currentRow field and set it to the specified row
	 * @param row
	 */
	private void setCurrentRow(IDataRow row) {
		this.currentRow = row;
		this.currentObs = null;
		this.keyablePosition++;
	}
	
	private boolean isSeriesTheSame(IDataRow nextRow) {
		if(currentRow == null) {
			return false;
		}
		if(!nextRow.getShortCode().equals(currentRow.getShortCode())) {
			return false;
		}

		for (String serAttr : seriesAttributes) {
			String newSeriesAttr = nextRow.getReportedValue(serAttr);
			String currSeriesAttr = currentRow.getReportedValue(serAttr);
			if (!ObjectUtil.equivalent(newSeriesAttr, currSeriesAttr)) {
				return false;
			}
		}

		return true;
	}

	private void processRowGroups(Map<String, String> attrId2GroupId) {
		this.rowGroups = null;
		Map<String, String> rowData = currentRow.getRowData();
		for(String attrId : attrId2GroupId.keySet()) {
			if(rowData.containsKey(attrId)) {
				String groupId = attrId2GroupId.get(attrId);
				if(this.rowGroups == null) {
					hasNextGroup = true;
					this.rowGroupIdx = 0;  //Set it to the first group
					this.rowGroups = new ArrayList<>(dsdGroupCount);
				}
				if(!this.rowGroups.contains(groupId)) {
					this.rowGroups.add(groupId);
				}
				if(this.rowGroups.size() == dsdGroupCount) {
					break;
				}
			}
		}
	}

	@Override
	public List<FooterMessage> close() {
		flatDre.close();
		return Collections.emptyList();
	}
}
