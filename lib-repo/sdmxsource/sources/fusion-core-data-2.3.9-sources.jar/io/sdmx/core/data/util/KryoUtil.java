package io.sdmx.core.data.util;

import com.esotericsoftware.kryo.Kryo;

public class KryoUtil {
	
	/**
	 * @return a new instance of the Kryo object serialization class
	 */
    public static Kryo createInstance() {
    	Kryo kryo = new Kryo();
		// Kryo v5 requires all types to be registered or we can setRegistrationRequired to false
    	kryo.setRegistrationRequired(false);
    	return kryo;
    }
}
