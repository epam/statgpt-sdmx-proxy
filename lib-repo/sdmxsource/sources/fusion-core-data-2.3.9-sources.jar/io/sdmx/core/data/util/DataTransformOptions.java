package io.sdmx.core.data.util;

public class DataTransformOptions {
	private boolean mergeDataset;
	private boolean copyHeader;
	private boolean closeWriter;
	private boolean resetReader = true;
	private int datasetLimit = -1;
	private boolean includeObs = true;
	private boolean includeAttributes = true;
	
	
	private DataTransformOptions() {}
	
	public static DataTransformOptions getInstance() {
		return new DataTransformOptions();
	}

	public boolean isMergeDataset() {
		return mergeDataset;
	}

	public DataTransformOptions setMergeDataset(boolean mergeDataset) {
		this.mergeDataset = mergeDataset;
		return this;
	}

	public boolean isCopyHeader() {
		return copyHeader;
	}

	public DataTransformOptions setCopyHeader(boolean copyHeader) {
		this.copyHeader = copyHeader;
		return this;
	}

	public boolean isCloseWriter() {
		return closeWriter;
	}

	public DataTransformOptions setCloseWriter(boolean closeWriter) {
		this.closeWriter = closeWriter;
		return this;
	}

	public int getDatasetLimit() {
		return datasetLimit;
	}

	public DataTransformOptions setDatasetLimit(int datasetLimit) {
		this.datasetLimit = datasetLimit;
		return this;
	}

	public boolean isResetReader() {
		return resetReader;
	}

	public DataTransformOptions setResetReader(boolean resetReader) {
		this.resetReader = resetReader;
		return this;
	}

	public boolean isIncludeObs() {
		return includeObs;
	}

	public DataTransformOptions setIncludeObs(boolean includeObs) {
		this.includeObs = includeObs;
		return this;
	}

	public boolean isIncludeAttributes() {
		return includeAttributes;
	}

	public DataTransformOptions setIncludeAttributes(boolean includeAttributes) {
		this.includeAttributes = includeAttributes;
		return this;
	}
}
