package io.sdmx.core.data.manager;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.manager.DataReaderConsolidationManager;

public abstract class AbstractConsolidationManager implements DataReaderConsolidationManager {
	
	@Override
	public String getName() {
		return "Duplicate Observations";
	}

	@Override
	public String getDescription() {
		return "Ensures the data file does not contain any duplications which contradict each other. For example, if two observations for the same period, reporting different observation values, will be reported as a duplicate error.";
	}

	@Override
	public String getId() {
		return "Duplicate";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.BLOCK_PUBLICATION;
	}

}
