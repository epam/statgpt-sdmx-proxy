package io.sdmx.core.data.engine.writer;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.core.data.api.engine.validate.IMetricsWriterEngine;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.DatasetInfo;
import io.sdmx.core.data.model.validate.ValidationTransformationMetrics;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;

public class MetricsWriterEngine implements IMetricsWriterEngine {

	/**
	 * Writes Metrics as
	 * <pre>
	 * {
	 * 	Meta: {
	 * 		RequestTime: 123456
	 * 		Duration: 12
	 *  }
	 *  SourceData : {
	 *    Dataflow: urn,
	 *    Series: 123
	 *    Observations: 124
	 *    Groups: 12
	 *  },
	 *  OutputData : {
	 *  	Dataflow: urn,
	 *  	Series: 12
	 *  	Observations: 10,
	 *  	Groups: 0
	 *  }
	 *  UnMappedData : {
	 *  	Datasets: [
	 *  		{
	 *  			Structure: urn,
	 *  			Series: 12
	 *  			Observations: 10,
	 *  			Groups: 0
	 *  		}
	 *  	]
	 *  }
	 *  </pre>
	 * 
	 * @param out stream to write to - this is not closed on completion
	 * @param startTime start time of the validation/transformation process
	 * @param endTime end time of the validation/transformation process
	 * @param mapping if any mapping was used
	 * @param dataInformation a map of JSON Key to the Dataset Information
	 */
	@Override
	public void writeMetrics(OutputStream out, ValidationTransformationMetrics transformationMetrics) {
		JsonGenerator jsonGenerator = getJsonGenerator(out);
		try {
			jsonGenerator.writeStartObject();
			writeMetrics(jsonGenerator, transformationMetrics);
			jsonGenerator.writeEndObject();
			jsonGenerator.close();
		} catch (IOException e) {
			throw new SdmxException(e, "Could not write Validation Report");
		}
	}
	
	@Override
	public void writeMetrics(JsonGenerator jsonGenerator, ValidationTransformationMetrics transformationMetrics) throws IOException {
		jsonGenerator.writeObjectFieldStart("Meta");
		jsonGenerator.writeNumberField("RequestTime",transformationMetrics.getStartTime().getTime());
		jsonGenerator.writeNumberField("Duration", transformationMetrics.getEndTime().getTime() - transformationMetrics.getStartTime().getTime());
		jsonGenerator.writeEndObject();
		for(String key : transformationMetrics.getDataInformation().keySet()) {
			jsonGenerator.writeObjectFieldStart(key);
			writeDataInformation(jsonGenerator, transformationMetrics.getDataInformation().get(key), transformationMetrics.getMappingRules());
			jsonGenerator.writeEndObject();
		}
	}
	
//	@Override
//	public void writeSpecificMetricsReport(JsonGenerator jsonGenerator, ValidationTransformationMetrics transformationMetrics, JSONObject jsonUnmappedData) throws IOException {
//		jsonGenerator.writeObjectFieldStart("Meta");
//		jsonGenerator.writeNumberField("RequestTime",transformationMetrics.getStartTime().getTime());
//		jsonGenerator.writeNumberField("Duration", transformationMetrics.getEndTime().getTime() - transformationMetrics.getStartTime().getTime());
//		jsonGenerator.writeEndObject();
//
//		String[] itemOrder= new String[] {"SourceData", "OutputData"};
//		for (String key : itemOrder) {
//			DataInformation dataInformation = transformationMetrics.getDataInformation().get(key);
//			if (dataInformation == null) {
//				continue;
//			}
//			jsonGenerator.writeObjectFieldStart(key);
//			writeDataInformation(jsonGenerator, dataInformation, transformationMetrics.getMappingRules());
//			jsonGenerator.writeEndObject();
//		}
//
//		DataInformation dataInformation = transformationMetrics.getDataInformation().get("UnMappedData");
//		if (dataInformation != null) {
//			jsonGenerator.writeObjectFieldStart("UnMappedData");
//			writeUnmappedData(jsonGenerator, dataInformation, transformationMetrics.getMappingRules(), jsonUnmappedData);
//			jsonGenerator.writeEndObject();
//		}
//	}
	
	private JsonGenerator getJsonGenerator(OutputStream out) {
		JsonFactory factory = new JsonFactory();
		try {
			return factory.createGenerator(out, JsonEncoding.UTF8);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private void writeDataInformation(JsonGenerator jsonGenerator, DataInformation dataInformation, MappingRules mapping) throws IOException {
		jsonGenerator.writeArrayFieldStart("Datasets");
		for(int i=0; i < dataInformation.getDatasets(); i++) {
			DatasetInfo info = dataInformation.getDatasetInfo(i);
			
			//Use the provision, if null then Flow, if null then DSD
			MaintainableBean sourceMaint = info.getProvision() == null ? info.getFlow() == null ? info.getDsd() : info.getFlow() : info.getProvision();
			if(sourceMaint.getStructureType() == SDMX_STRUCTURE_TYPE.DSD && mapping != null) {
				if(mapping.getFromDataflow() != null) {
					sourceMaint = mapping.getFromDataStructure().equals(sourceMaint) ? mapping.getFromDataflow() : mapping.getToDataflow();
				}
			}
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("Structure", sourceMaint.getUrn());
			jsonGenerator.writeNumberField("Series", info.getKeys());
			jsonGenerator.writeNumberField("Observations", info.getObservations());
			jsonGenerator.writeNumberField("Groups", info.getGroups());
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}
	
//	private void writeUnmappedData(JsonGenerator jsonGenerator, DataInformation dataInformation, MappingRules mapping, JSONObject jsonUnmappedData) throws IOException {
//		jsonGenerator.writeArrayFieldStart("Datasets");
//		for(int i=0; i < dataInformation.getDatasets(); i++) {
//			DatasetInfo info = dataInformation.getDatasetInfo(i);
//
//			//Use the provision, if null then Flow, if null then DSD
//			MaintainableBean sourceMaint = info.getProvision() == null ? info.getFlow() == null ? info.getDsd() : info.getFlow() : info.getProvision();
//			if(sourceMaint.getStructureType() == SDMX_STRUCTURE_TYPE.DSD && mapping != null) {
//				if(mapping.getFromDataflow() != null) {
//					sourceMaint = mapping.getFromDataStructure().equals(sourceMaint) ? mapping.getFromDataflow() : mapping.getToDataflow();
//				}
//			}
//			jsonGenerator.writeStartObject();
//			jsonGenerator.writeStringField("Structure", sourceMaint.getUrn());
//			jsonGenerator.writeNumberField("Series", info.getKeys());
//			jsonGenerator.writeNumberField("Observations", info.getObservations());
//			jsonGenerator.writeNumberField("Groups", info.getGroups());
//
//			if (jsonUnmappedData != null) {
//				writeResultArray(jsonGenerator, jsonUnmappedData);
//			}
//
//			jsonGenerator.writeEndObject();
//		}
//		jsonGenerator.writeEndArray();
//	}
//
//	private void writeResultArray(JsonGenerator jsonGenerator, JSONObject jsonUnmappedData) throws IOException {
//		try {
//			JSONArray resultArray = jsonUnmappedData.getJSONArray("Result");
//			JsonWriterUtil.writeJsonArray(jsonGenerator, "Result", resultArray);
//		} catch (JSONException e) {
//			throw new SdmxException(e, "Unable to obtain 'Result'. Unable to write report.");
//		}
//	}

	@Override
	public void writeSpecificMetricsReport(JsonGenerator jsonGenerator, ValidationTransformationMetrics transformationMetrics, Map<IComponentMapping, List<String>> unmappedMappings) throws IOException {
		jsonGenerator.writeObjectFieldStart("Meta");
		jsonGenerator.writeNumberField("RequestTime",transformationMetrics.getStartTime().getTime());
		jsonGenerator.writeNumberField("Duration", transformationMetrics.getEndTime().getTime() - transformationMetrics.getStartTime().getTime());
		jsonGenerator.writeEndObject();
		
		String[] itemOrder= new String[] {"SourceData", "OutputData"};
		for (String key : itemOrder) {
			DataInformation dataInformation = transformationMetrics.getDataInformation().get(key);
			if (dataInformation == null) {
				continue;
			}
			jsonGenerator.writeObjectFieldStart(key);
			writeDataInformation(jsonGenerator, dataInformation, transformationMetrics.getMappingRules());
			jsonGenerator.writeEndObject();
		}
		
		DataInformation dataInformation = transformationMetrics.getDataInformation().get("UnMappedData");
		if (dataInformation != null) {
			jsonGenerator.writeObjectFieldStart("UnMappedData");
			writeUnmappedData(jsonGenerator, dataInformation, transformationMetrics.getMappingRules(), unmappedMappings);
			jsonGenerator.writeEndObject();
		}
	}
	
	private void writeUnmappedData(JsonGenerator jsonGenerator, DataInformation dataInformation, MappingRules mapping, Map<IComponentMapping, List<String>> unmappedMappings) throws IOException {
		jsonGenerator.writeArrayFieldStart("Datasets");
		for(int i=0; i < dataInformation.getDatasets(); i++) {
			DatasetInfo info = dataInformation.getDatasetInfo(i);
			
			//Use the provision, if null then Flow, if null then DSD
			MaintainableBean sourceMaint = info.getProvision() == null ? info.getFlow() == null ? info.getDsd() : info.getFlow() : info.getProvision();
			if(sourceMaint.getStructureType() == SDMX_STRUCTURE_TYPE.DSD && mapping != null) {
				if(mapping.getFromDataflow() != null) {
					sourceMaint = mapping.getFromDataStructure().equals(sourceMaint) ? mapping.getFromDataflow() : mapping.getToDataflow();
				}
			}
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("Structure", sourceMaint.getUrn());
			jsonGenerator.writeNumberField("Series", info.getKeys());
			jsonGenerator.writeNumberField("Observations", info.getObservations());
			jsonGenerator.writeNumberField("Groups", info.getGroups());
			
			if (unmappedMappings != null) {
				writeResultArray(jsonGenerator, mapping, unmappedMappings);
			}
			
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	/**
	 * Writes an array of JSONObjects which have structure like the following:
	 * <pre>
	 * {
     *    "Component":"FUTURE_OR_OPTION",
     *    "Mapping":"BIS.XTD:FIA_INSTR_MAP(1.0)",
     *    "UnmappedSource": ["ADEX3.010106", "ADEX3.010206"]
     * }
     * </pre>
	 * 
	 * @param jsonGenerator
	 * @param extraBit
	 */
	private void writeResultArray(JsonGenerator jsonGenerator, MappingRules rules, Map<IComponentMapping, List<String>> unmappedMappings) {
		if(!ObjectUtil.validMap(unmappedMappings)) {
			return;
		}
		
		IStructureMapBean map = rules.getStructureMapBean();
		try {
			jsonGenerator.writeArrayFieldStart("Result");
			
			for (Entry<IComponentMapping, List<String>> entry : unmappedMappings.entrySet()) {
				List<String> unmappedRows = entry.getValue();
				IComponentMapping componentMap = entry.getKey();
				
				//Write JSON { "Component" : ["COMP1, "COMP2"]
				jsonGenerator.writeStartObject();
				List<String> source = componentMap.getSourceComponents();
				JsonWriterUtil.writeStringArray(jsonGenerator, "Component", source);
				String mapping = getComponentMapType(map, componentMap);
				jsonGenerator.writeStringField("Mapping", mapping);
				jsonGenerator.writeArrayFieldStart("UnmappedSource");
				for (String aVal : unmappedRows) {
					jsonGenerator.writeString(aVal);
				}
				jsonGenerator.writeEndArray();
				
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		} catch (Exception e) {
			throw new SdmxException(e, "Unable to construct 'Result' element. Unable to write report.");
		}
	}
	
	
	/**
	 * @param map the strucutre map that the component mapping was built from
	 * @param compMapping the mapping which contains the source and target components
	 * @return the component map type (representation map, epoch map, time pattern)
	 */
	private String getComponentMapType(IStructureMapBean map, IComponentMapping compMapping) {
		List<String> source = compMapping.getSourceComponents();
		List<String> target = compMapping.getTargetComponents();
		
		for(IComponentMapBean compMapBean : map.getComponentMaps()) {
			if(ObjectUtil.equivalentCollection(compMapBean.getSourceComponents(), source) && ObjectUtil.equivalentCollection(compMapBean.getTargetComponents(), target)) {
				return compMapBean.getRepresentationMapRef() == null ? "Implicit" : "RepresentationMap="+compMapBean.getRepresentationMapRef().getTargetUrn().split("=")[1];
			}
		}
		if(source.size() != 1 || target.size() != 1) {
			return null;
		}
		for(IEpochMapBean epochMapBean : map.getEpochMap()) {
			if(epochMapBean.getSourceComponent().equals(source.get(0)) && epochMapBean.getTargetComponent().equals(target.get(0))) {
				return "EpochMap="+epochMapBean.getEpochInterval()+":"+epochMapBean.getBasePeriod().getDateInSdmxFormat();
			}
 		}
		for(ITimePatternMapBean timePatternMapBean : map.getTimePatternMaps()) {
			if(timePatternMapBean.getSourceComponent().equals(source.get(0)) && timePatternMapBean.getTargetComponent().equals(target.get(0))) {
				return "TimePatternMap="+timePatternMapBean.getPattern();
			}
		}
		return null;
		
	}

}
