package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.DeepDataValidationEngine;

public class RepresentationValidatorFactory implements DataValidatorFactory {

    @Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
        return new DeepDataValidationEngine(dsi);
    }

    @Override
    public String getId() {
        return "Representation";
    }

    @Override
    public String getName() {
        return "Valid Representation";
    }

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return false;
	}
	
	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public String getDescription() {
		return "Ensures the reported values for Dimensions, Attributes, and Observation values comply with the DSD.  "
				+ "For example if a Dimension provides a list of valid code Ids, and the reported value is not contained in this list then it will fail this test.";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.BLOCK_PUBLICATION;
	}
	
	@Override
	public int hashCode() {
		return "RepresentationValidatorFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof RepresentationValidatorFactory;
	}
}