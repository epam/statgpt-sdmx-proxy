package io.sdmx.core.data.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.TimeoutException;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.service.data.IDataTransformationService;
import io.sdmx.core.data.api.manager.DataLoadManager;
import io.sdmx.core.data.api.manager.DataValidationReportManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.api.model.transform.DataTransformationOptions;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.model.transform.DataTransformationOptionsImpl;
import io.sdmx.core.data.model.validate.ExternalRequest;
import io.sdmx.core.data.service.builder.ExternalRequestBuilder;
import io.sdmx.utils.core.io.MultipartOutputStream;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataTransformationService extends AbstractDataService implements IDataTransformationService {
	private static final Logger LOG = LoggerFactory.getLogger(DataTransformationService.class);

	public DataTransformationService(
					DataLoadManager dataLoadManager,
					ExternalRequestBuilder externalRequestBuilder,
					DataValidationReportManager validationReportManager,
					DataWriterManager dataWriterManager,
					HeaderRetrievalManager headerRetrievalManager,
					WriteableDataLocationFactory wdlFactory
					) {
		super(dataLoadManager, externalRequestBuilder, validationReportManager, dataWriterManager, headerRetrievalManager, wdlFactory);
	}
	
	@Override
	public void transformData(Request req, IResponse response) {
		ExternalRequest request= null;
		try {
			if(req.getReadableDataLocation() == null) {
				throw new SdmxSemmanticException("Data file not supplied.  If content type is set to multipart/form-data the ContentID name must be 'uploadFile'.  If loading data via a stream, set the content "
						+ "type to application/text, application/xml, or application/json");
			}
			request = externalRequestBuilder.build(req);
			transformData(request, response);
		} catch(Throwable th) {
			handleError(request, response, th);
		}
	}
	
	private int transformData(ExternalRequest request, IResponse resp) throws IOException {
		LOG.info("External Transform Request Received : " +request);
		
		WriteableDataLocation tmpWdl = null;
		DataSetDetails details = null;
		try {
			details = getDataSetDetails(request);
			if(ObjectUtil.validString(details.getDsdError())) {
				throw new SdmxSemmanticException(details.getDsdError());
			}
			for(int i=0; i < details.getDatasets(); i++) {
				DataValidationResult validationResult = details.getDataValidationResult(i);
				if(request.isFailOnError()) {
					if(validationResult.hasErrors()) {
						throw new SdmxSemmanticException("Dataset could not be transformed, fail-on-error is set to true, and errors were found in the dataset.  Peform a data validation to view the errors");
					}
				}
				if(validationResult.preventsConversion()) {
					throw new SdmxSemmanticException("Dataset could not be converted due to errors");
				}
			}
	
			tmpWdl = wdlFactory.getTemporaryWriteableDataLocation();
			DataTransformationOptions options = getDataTransformationOptions(request, details, tmpWdl.getOutputStream());
			
			LOG.info("Perform Transformation");
			dataLoadManager.writeDatasetDetails(details.getUid(), options);

			//Everything worked, copy stream
			if(request.isZip())  {
				resp.setContentType("application/zip");
			} else if(request.isIncludeUnmapped() || request.isIncludeMetrics()) {
				resp.setContentType("multipart/mixed;boundary=fusionboundary");
				resp.setHeader("content-disposition", "form-data");
			} else {
				resp.setContentType(request.getTranformTo().getFormatDetails().getMimeType());
			}
			StreamUtil.copyStream(tmpWdl.getInputStream(), resp.getOutputStream(), true);
		} catch (TimeoutException e) {
			throw new SdmxException(e, "Time out");
		} finally {
			if (tmpWdl != null) {
				tmpWdl.close();
			}
			if (details != null) {
				dataLoadManager.close(details.getUid());
			}
			request.getRdl().setProtected(false);
			request.getRdl().close();
		}

		LOG.debug("External Request Completed Successfully");
		return 200;
	}

	private DataTransformationOptions getDataTransformationOptions(ExternalRequest request, DataSetDetails details, OutputStream out) throws IOException {
		if(request.getTranformTo() != null) {
			LOG.info("Transform Data");
			String senderId = request.getSenderId();
			if(senderId == null) {
				senderId = details.getSenderId();
				if(senderId == null) {
					if(headerRetrievalManager != null) {
						senderId = headerRetrievalManager.getHeader().getSender().getId();
					} else {
						senderId = "FUSION";
					}
				}
			}
			DataTransformationOptions options = null;
			if(request.isZip())  {
				options = new DataTransformationOptionsImpl(request.getTranformTo(), new ZipOutputStream(out));
			} else if(request.isIncludeUnmapped() || request.isIncludeMetrics()) {
				options = new DataTransformationOptionsImpl(request.getTranformTo(), new MultipartOutputStream(out, "fusionboundary"));
			} else {
				options = new DataTransformationOptionsImpl(request.getTranformTo(), out);
			}
			options.setIncludeUnmappedFormat(request.getUnmappedFormat());
			options.setIncludeUnmappedData(request.isIncludeUnmapped());
			options.setIncludeUnmappedReport(request.isIncludeUnmappedReport());
			options.setIncludeMetrics(request.isIncludeMetrics());
			options.setDatasetIndex(request.getDatasetIndex());
			options.setMappedOutputReference(request.getMapStructure());
			options.setSenderId(senderId);
			String receiverId = request.getReceiverId();
			if (ObjectUtil.validString(receiverId)) {
				options.setReceiverId(receiverId);
			}

			String datasetId = request.getDatasetId();
			options.setDatasetId(datasetId);

			DATASET_ACTION action = request.getDatasetAction();
			options.setDatasetAction(action);

			if (request.isSkipValidation()) {
				options.setSkipValidation(true);
			}
			
			return options;
		}
		throw new SdmxSemmanticException("Can not transform data, missing Accept header defining output format");
	}

}
