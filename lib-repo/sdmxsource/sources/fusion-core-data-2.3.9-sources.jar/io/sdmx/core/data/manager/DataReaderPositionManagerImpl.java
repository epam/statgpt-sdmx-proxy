package io.sdmx.core.data.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.manager.DataReaderPositionManager;

public class DataReaderPositionManagerImpl implements DataReaderPositionManager {
	private static final Logger LOG = LoggerFactory.getLogger(DataReaderPositionManagerImpl.class);

	@Override
	public Keyable moveToPosition(DataReaderEngine dataReaderEngine, int datasetPos, int i) {
		moveToDataset(dataReaderEngine, datasetPos);
		int keyableIndex = dataReaderEngine.getKeyablePosition();
		if(LOG.isDebugEnabled()) {
			LOG.debug("Move to position '"+i+"' current position '"+keyableIndex+"'");
		}
		int stepsToGo;
		if (i == keyableIndex) {
			return dataReaderEngine.getCurrentKey();
		}
		if (i > keyableIndex) {
			stepsToGo = i-(keyableIndex+1);
		}
		else {
			stepsToGo = i; // starts at zero, which is one step
			dataReaderEngine.reset();
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("'"+stepsToGo+"' steps to go");
		}
		for(int j = 0; j <= stepsToGo; j++) {
			if(!dataReaderEngine.moveNextKeyable()) {
				return null;
			}
			if(LOG.isDebugEnabled()) {
				LOG.debug("Pos "+dataReaderEngine.getKeyablePosition()+":" +dataReaderEngine.getCurrentKey().getShortCode());
			}
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("0 steps to go");
		}
		return dataReaderEngine.getCurrentKey();
	}

	@Override
	public Observation moveToObs(DataReaderEngine dataReaderEngine, int datasetPos, int keyPosition, int obsNum) {
		moveToPosition(dataReaderEngine, datasetPos, keyPosition);
		for(int j = 0; j <= keyPosition; j++) {
			if(!dataReaderEngine.moveNextObservation()) {
				return null;
			}
		}
		return dataReaderEngine.getCurrentObservation();
	}
	
	private void moveToDataset(DataReaderEngine dataReaderEngine, int i) {
		int currentDatasetIndex = dataReaderEngine.getDatasetPosition();
		if(currentDatasetIndex > i) {
			dataReaderEngine.reset();
			currentDatasetIndex = -1;
		}
		while(currentDatasetIndex < i) {
			boolean moveNextDatasetSucceed = dataReaderEngine.moveNextDataset();
			if (!moveNextDatasetSucceed) {
				throw new SdmxSemmanticException("Unable to move to next dataset");
			}
			currentDatasetIndex = dataReaderEngine.getDatasetPosition();
		}
	}
}
