package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.model.type.DT_List;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.DataType;
import org.h2.mvstore.type.ObjectDataType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Serialization for (a specific subset of) generic Object
 */
public class DT_Object extends BasicDataType<Object> {
  private static final Logger LOG = LoggerFactory.getLogger(DT_Object.class);

  private final DT_IDatasetStructures dsStrDT;
  private final DT_HeaderBean hdrDT;
  private final DT_DatasetHeaderBean dsHdrDT;
  private final ObjectDataType objectDataType;
  private final DT_List<Object, Object> objListDT;

  public DT_Object(DT_IDatasetStructures dsStrDT) {
    this.dsStrDT = dsStrDT;
    this.hdrDT = new DT_HeaderBean();
    this.dsHdrDT = new DT_DatasetHeaderBean();
    this.objectDataType = new ObjectDataType();
    this.objListDT = new DT_List<>(objectDataType);
  }

  @SuppressWarnings("rawtypes")
  private BasicDataType getDataTypeFromObject(Object obj) {
    BasicDataType dt = objectDataType; // default data type

    if (obj instanceof HeaderBean)
      dt = hdrDT;
    else if (obj instanceof DatasetHeaderBean)
      dt = dsHdrDT;
    else if (obj instanceof IDatasetStructures)
      dt = dsStrDT;
    else if (obj instanceof List<?>)
      dt = objListDT;

    if (LOG.isDebugEnabled())
      LOG.debug("getDataTypeFromObject - obj: {}, class: {}, dt: {}",
                obj, obj == null ? "null" : obj.getClass(), dt);

    return dt;
  }

  @SuppressWarnings("rawtypes")
  private Integer getIdFromDataType(BasicDataType dt) {
    Integer id = null;

    if (dt == hdrDT)
      id = 0;
    else if (dt == dsHdrDT)
      id = 1;
    else if (dt == dsStrDT)
      id = 2;
    else if (dt == objListDT)
      id = 3;
    else if (dt == objectDataType)
      id = 4;

    if (LOG.isDebugEnabled())
      LOG.debug("getIdFromDataType - dt: {}, id: {}", dt, id);

    return id;
  }

  @SuppressWarnings("rawtypes")
  private BasicDataType getDataTypeFromId(Integer id) {
    BasicDataType dt = null;

    switch (id) {
      case 0 : dt = hdrDT; break;
      case 1 : dt = dsHdrDT; break;
      case 2 : dt = dsStrDT; break;
      case 3 : dt = objListDT; break;
      case 4 : dt = objectDataType; break;
    }

    return dt;
  }

  @Override
  public int getMemory(Object obj) {
    @SuppressWarnings("unchecked")
    BasicDataType<Object> dt = getDataTypeFromObject(obj);

    return 1 + dt.getMemory(obj);
  }

  @Override
  public void write(WriteBuffer buf, Object obj) {
    @SuppressWarnings("unchecked")
    BasicDataType<Object> dt = getDataTypeFromObject(obj);

    buf.putVarInt(getIdFromDataType(dt));
    dt.write(buf, obj);
  }

  @Override
  public Object read(ByteBuffer buf) {
    @SuppressWarnings("unchecked")
    BasicDataType<Object> dt = getDataTypeFromId(DataUtils.readVarInt(buf));

    return dt.read(buf);
  }

  @Override
  public Object[] createStorage(int size) {
    return new Object[size];
  }
}
