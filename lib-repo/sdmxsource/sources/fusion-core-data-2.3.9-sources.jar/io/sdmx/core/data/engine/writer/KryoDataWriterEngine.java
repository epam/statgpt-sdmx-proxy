package io.sdmx.core.data.engine.writer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;
import java.util.zip.DeflaterOutputStream;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.kryo.AnnotationListSerializer;
import io.sdmx.core.data.model.kryo.DatasetAttributesSerializer;
import io.sdmx.core.data.model.kryo.DatasetHeaderSerializer;
import io.sdmx.core.data.model.kryo.DatasetStructuresSerializer;
import io.sdmx.core.data.model.kryo.HeaderSerializer;
import io.sdmx.core.data.model.kryo.KeyableSerializer;
import io.sdmx.core.data.model.kryo.ObsSerializer;
import io.sdmx.core.data.util.KryoUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.io.FileUtil;

public class KryoDataWriterEngine implements ISeriesObsDataWriterEngine {
	public static final int HEADER_START = 0;
	public static final int DATASET_START = 1;
	public static final int KEY_START = 2;
	public static final int OBS_START = 3;
	public static final int END = 9;
	
	private Kryo kryo = KryoUtil.createInstance();
	private Output out;
	private KeyableSerializer kser;
	private ObsSerializer obsser = new ObsSerializer(null);
	
	private boolean isClosed;
	

	public KryoDataWriterEngine(WriteableDataLocation wdl) throws IOException {
		OutputStream outputStream = new DeflaterOutputStream(wdl.getOutputStream());
		out = new Output(outputStream);
	}
	
	public KryoDataWriterEngine(File f) throws FileNotFoundException {
		OutputStream outputStream = new DeflaterOutputStream(FileUtil.getOutputStream(f));
		out = new Output(outputStream);
	}

	@Override
	public void writeHeader(HeaderBean header) {
		kryo.writeObject(out, HEADER_START);
		kryo.writeObjectOrNull(out, header, HeaderSerializer.getInstance());
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		kryo.writeObject(out, DATASET_START);
		kryo.writeObjectOrNull(out, header, DatasetHeaderSerializer.getInstance());
		kryo.writeObjectOrNull(out, structures, DatasetStructuresSerializer.getWriteInstance());
		kryo.writeObjectOrNull(out, datasetAttributes, DatasetAttributesSerializer.getInstance());
		kser  = new KeyableSerializer(structures.getDataflow(), structures.getDataStructure());
	}

	@Override
	public void writeKey(Keyable key) {
		kryo.writeObject(out, KEY_START);
		obsser.setSeriesKey(key);
		kryo.writeObject(out, key, kser);
	}

	@Override
	public void writeObservation(Observation obs) {
		kryo.writeObject(out, OBS_START);
		kryo.writeObject(out, obs, obsser);
	}

	@Override
	public void close(FooterMessage... footer) {
		if(isClosed) {
			return;
		}
		isClosed = true;
		kryo.writeObject(out, END);
		out.close();
	}

}
