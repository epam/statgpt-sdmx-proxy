package io.sdmx.core.data.factory.format;

import io.sdmx.core.sdmx.api.factory.data.ISeriesDataWriterFactory;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.utils.core.application.SingletonStore;

public abstract class MetadataAwareDataWriterFactory implements ISeriesDataWriterFactory {
	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	protected SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager() {
		if(superBeanRetrievalManager == null) {
			ISdmxBeanRetreivalContainer brmContainer = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class, false);
			if(brmContainer != null) {
				superBeanRetrievalManager = brmContainer.getSuperBeanRetrievalManager(true);
			}
		}
		return superBeanRetrievalManager;
	}
	
	protected SdmxBeanRetrievalManager getBeanRetrievalManager() {
		if(beanRetrievalManager == null) {
			ISdmxBeanRetreivalContainer brmContainer = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class, false);
			if(brmContainer != null) {
				beanRetrievalManager = brmContainer.getBeanRetrievalManager(true);
			}
		}
		return beanRetrievalManager;
	}

	public void setSuperBeanRetrievalManager(SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		this.superBeanRetrievalManager = superBeanRetrievalManager;
	}
	
	public void setBeanRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
}
