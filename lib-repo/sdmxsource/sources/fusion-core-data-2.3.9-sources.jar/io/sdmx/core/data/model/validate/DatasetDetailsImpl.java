package io.sdmx.core.data.model.validate;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DatasetCreationAware;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.security.ISecureThread;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.api.manager.DataValidatorLevelRetrievalManager;
import io.sdmx.core.data.api.manager.SdmxMappingManager;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.constant.LOADING_STATUS;
import io.sdmx.core.data.engine.reader.DataValidationDataReaderWrapper;
import io.sdmx.core.data.engine.reader.DataValidationResultDataReaderEngine;
import io.sdmx.core.data.engine.reader.MutlipleDataReaderEngineMultipleDatasets;
import io.sdmx.core.data.engine.validate.DataReaderForValidation;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.DatasetInfo;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.error.DataValidationErrorHandlerImpl;
import io.sdmx.core.structure.util.StructureUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.WriteableDataLocationTmp;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.http.broker.RestMessageBroker;

public class DatasetDetailsImpl implements DataSetDetails {
	private static final Logger LOG = LoggerFactory.getLogger(DatasetDetailsImpl.class);

	private ITemporaryDataManager temporaryDataManager = SingletonStore.getSingleton(ITemporaryDataManager.class);
	private DataValidatorLevelRetrievalManager dataValidatorManager = SingletonStore.getSingleton(DataValidatorLevelRetrievalManager.class);
	private SdmxMappingManager sdmxMappingManager = SingletonStore.getSingleton(SdmxMappingManager.class);
	private HeaderRetrievalManager headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);
	private DataReaderManager dataReaderManager = SingletonStore.getSingleton(DataReaderManager.class);

	//A Data Validation Result per Dataset
	private List<DataValidationResult> dataValidationResult = new ArrayList<>();

	//Retrieval Managers
	private SdmxBeanRetrievalManager beanRetrievalManager;

	//Identifier and File Information
	private String uid;

	private ReadableDataLocation rdl;

	private FormatDetails formatDetails;
	private String fileFormat = "Unknown";

	private IURNSingle<? extends IDSDRelatedBean> missingReference;  //If the dataset if referencing a DSD/Flow/Provision that could not be resolved.

	//Variable State (DSD Specific)
	protected String dsdError;


	protected LOADING_STATUS loadingStatus = LOADING_STATUS.INITIALISING;
	private DataInformation dataInformation;
	private boolean attributesTested;

	//Mapped Structure
	private MaintainableBean mappedStructure;
	private String filename;

	private String senderId;
	private URL url;

	private List<FooterMessage> footerMessages;

	private IURNSingle<? extends IDSDRelatedBean> forceToReadUsing;

	private boolean priorDataDependent;
	private boolean mergeDatasets;

	private IConsolidationOptions consolidateOptions;

	public DatasetDetailsImpl(URL url, IURNSingle<? extends IDSDRelatedBean> sRef) {
		this(url.getPath(), convertURLToRDL(url), sRef);
		this.url = url;
		this.forceToReadUsing = sRef;
	}

	public DatasetDetailsImpl(String filename, ReadableDataLocation anRDL, IURNSingle<? extends IDSDRelatedBean> sRef) {
		this(filename, anRDL, sRef, false, false, null);
	}

	public DatasetDetailsImpl(String filename, ReadableDataLocation anRDL, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets, IConsolidationOptions consolidateOptions) {
		this(filename, anRDL, sRef, priorDataDependent, mergeDatasets, consolidateOptions, false);
	}

	public DatasetDetailsImpl(String filename, ReadableDataLocation anRDL, IURNSingle<? extends IDSDRelatedBean> sRef, boolean priorDataDependent, boolean mergeDatasets, IConsolidationOptions consolidateOptions, boolean skipValidation) {
		this.consolidateOptions = consolidateOptions;
		ISdmxBeanRetreivalContainer beanRetrievalContainer = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class);
		if(beanRetrievalContainer != null) {
			beanRetrievalManager = beanRetrievalContainer.getBeanRetrievalManager(true);
		}
		this.uid = UUID.randomUUID().toString();
		LOG.info("Create Dataset Details");

		this.filename = filename;

		if(anRDL == null) {
			throw new SdmxSemmanticException("Can not read date - missing data stream");
		}
		anRDL.setProtected(true);
		this.rdl = anRDL;
		this.forceToReadUsing = sRef;
		this.priorDataDependent = priorDataDependent;
		this.mergeDatasets = mergeDatasets;

		if (skipValidation) {
			init(false);
			if(!this.loadingStatus.isError()) {
				setLoadingStatus(LOADING_STATUS.FINISHED);
			}
		}
	}

	/**
	 * Initialises the data reader.  This occurs on first data load, or if the user changes the Data Structure Definition used to read the data.
	 *
	 * If it is the latter, and the underlying dataset already references data structures, then the DSD will be modified to 'pretend' it is the DSD to match it.
	 *
	 */
	private void init(boolean performValidation) {
		this.loadingStatus = LOADING_STATUS.ANALYSING;
		DataReaderEngine dre = null;

		DataValidationErrorHandlerImpl dataReadFailureHandler = new DataValidationErrorHandlerImpl(dataValidatorManager.getAllIgnoreCategories());
		try {
			if(forceToReadUsing != null) {
				ProvisionAgreementBean provisionAgreementBean = null;
				DataflowBean dataflowBean = null;
				DataStructureBean dsd = null;
				IURNSingle<? extends IDSDRelatedBean> sRef = forceToReadUsing;
				switch(forceToReadUsing.getSdmxStructure()) {
				case PROVISION_AGREEMENT :
					provisionAgreementBean = beanRetrievalManager.getBean(sRef.toType(ProvisionAgreementBean.class));
					if(provisionAgreementBean == null) {
						break;
					}
					sRef = provisionAgreementBean.getStructureUseage().getReference();
				case DATAFLOW :
					dataflowBean = beanRetrievalManager.getBean(sRef.toType(DataflowBean.class));
					if (dataflowBean == null) {
						break;
					}
					sRef = dataflowBean.getDataStructureRef().getReference();
				case DSD :
					dsd = beanRetrievalManager.getBean(sRef.toType(DataStructureBean.class));
					break;
				default : throw new SdmxSemmanticException("Can not read dataset with reference provided:" +sRef.getURN());
				}
				if (dsd == null) {
					this.loadingStatus = LOADING_STATUS.DSD_INVALID;
					this.dsdError = "Specified structure could not be obtained: " + forceToReadUsing.getURN();
					rdl.setProtected(false);
					rdl.close();
					return;
				} else {
					dre = dataReaderManager.getDataReaderEngine(rdl, beanRetrievalManager, dataReadFailureHandler);
					IURNSingle<? extends IDSDRelatedBean> mutateTo;
					try {
						dre.moveNextDataset();
						if (dre.getDataStructure() != null) {
							mutateTo = dre.getDataStructure().getURN();
						} else {
							mutateTo = null;
						}
					} catch (DataSetStructureReferenceException e) {
						mutateTo = e.getReferenceTo();
					}
					DataStructureBean mutatedDSD = null;
					if (mutateTo == null) {
						mutatedDSD = dsd;
					} else {
						if(!mutateTo.getURN().equals(dsd.getUrn())) {
							//mutate it
							mutatedDSD = (DataStructureBean)StructureUtil.changeValues(dsd, mutateTo);
							dataflowBean = null;  //clear the dataflow
						} else {
							mutatedDSD = dsd;
						}
					}
					dre.close();
					dre = dataReaderManager.getDataReaderEngine(rdl, mutatedDSD, dataflowBean, provisionAgreementBean, dataReadFailureHandler);
					if(mutatedDSD != dsd) {
						DataReaderForValidation dreWrapped = new DataReaderForValidation(headerRetrievalManager, dre, dsd, dataflowBean, provisionAgreementBean);
						dreWrapped.setDefaultIfNotProvided(false);
						dre = dreWrapped;
					}
				}
			} else {
				dre = dataReaderManager.getDataReaderEngine(rdl, beanRetrievalManager, dataReadFailureHandler);
			}
		} catch(DataSetStructureReferenceException e) {
			this.missingReference = e.getReferenceTo();
			if(missingReference == null) {
				this.loadingStatus = LOADING_STATUS.DSD_MISSING;
			} else {
				this.loadingStatus = LOADING_STATUS.DSD_INVALID;
			}
			rdl.setProtected(false);
			rdl.close();
			// Do not throw the Exception from here. Simply return
			return;
		} catch(RuntimeException e) {
			this.loadingStatus = LOADING_STATUS.ERRORED;
			this.dsdError = e.getMessage();
			rdl.setProtected(false);
			rdl.close();
			throw e;
		}
		try {
			setFileFormat(dre.getDataFormat());
			this.formatDetails = dre.getFormatDetails();
			if (dre.getHeader() != null && dre.getHeader().getSender() != null) {
				this.senderId = (dre.getHeader().getSender().getId());
			}

			clearState();
			//It is important to create the dataInformation off the underlying data reader otherwise the DSD will be null
			//Create a validation result per dataset
			dataValidationResult = new ArrayList<>();
			setLoadingStatus(LOADING_STATUS.CONSOLIDATING);
			Date creationDate = null;
			if(dre instanceof DatasetCreationAware) {
				DatasetCreationAware creationAware = (DatasetCreationAware) dre;
				creationDate = creationAware.getCreationDate();
			}
			int dsIdx = 0;

			dre.reset();
			//Split into single files

			while(dre.moveNextDataset()) {
				ITemporaryDataWriterEngine dwe = temporaryDataManager.getDataWriterEngine();
				dwe.writeHeader(dre.getHeader());
				DataTransformationUtil.copyDataSet(dre, dwe, true, null);
				dwe.close();

				List<DataError> errorsForDataset = new ArrayList<>();
				List<DataError> errors = dataReadFailureHandler.getErrors();
				for(DataError error : errors) {
					if(error.getDataset() == dsIdx) {
						errorsForDataset.add(error);
					}
				}

				// If not reporting errors, set the DataValidationErrorHandler to be a non-reporting error handler
				DataValidationErrorHandler errorHandler = performValidation ? null : new NonReportingErrorHandler();

				DataValidationResultImpl res = null;
				try {
					res = new DataValidationResultImpl(beanRetrievalManager, creationDate,
							dwe.getReadableDataLocation(),
							temporaryDataManager.getDataReaderEngine(dwe),
							errorsForDataset, priorDataDependent, consolidateOptions, errorHandler);
					dataValidationResult.add(res);
				} catch (Throwable t) {
					// RFS-50: Something went wrong in the creation of the DataValidationResultImpl
					// close the WriteableDataLocation and re-throw the exception

					// The dwe cannot be null. Unprotect its readableDataLocation and delete it
					dwe.getReadableDataLocation().setProtected(false);
					try {
						dwe.close();
					} catch (Throwable t2) {
						LOG.error("Unable to close DataWriterEngine: {} ", dwe);
					}

					try {
						dre.close();
					} catch (Throwable t2) {
						LOG.error("Unable to close DataReaderEngine: {}", dre);
					}
					throw t;
				}
				dsIdx++;
			}

			if(dataValidationResult.isEmpty()) {
				throw new SdmxException("No datasets were present in submitted data file");
			}
			setLoadingStatus(LOADING_STATUS.VALIDATING_1);
			for(DataValidationResult dvr : dataValidationResult) {
				if (performValidation) {
					try {
						if (applyEdiLenientRules(formatDetails)) {
							ThreadLocalUtil.storeOnThread(ThreadLocalUtil.APPLY_EDI_LENIENCE, true);
						}
						dvr.validate();
					} finally {
						ThreadLocalUtil.clearFromThread(ThreadLocalUtil.APPLY_EDI_LENIENCE);
					}
				}
			}
			footerMessages = dre.close();
			if(footerMessages == null) {
				footerMessages = new ArrayList<>();
			}
			footerMessages = Collections.unmodifiableList(footerMessages);
		} catch(DataSetStructureReferenceException e) {
			this.missingReference = e.getReferenceTo();
			if(missingReference == null) {
				this.dsdError = "Can not read dataset as it does not reference a Data Structure. Please provide Data Structure information in order for this dataset to be read";
				this.loadingStatus = LOADING_STATUS.DSD_MISSING;
			} else {
				this.dsdError = "Invalid DSD referenced. Reference is: " + this.missingReference.getURN();
				this.loadingStatus = LOADING_STATUS.DSD_INVALID;
			}
			return;
		} catch(Throwable e) {
			try {
				LOG.error("Error reading dataset", e);
				DataStructureBean dsd = dre.getDataStructure();
				if(dre instanceof DataValidationDataReaderWrapper) {
					DataValidationDataReaderWrapper dvw = (DataValidationDataReaderWrapper)dre;
					dsd = dvw.getDataStructure(0);
				}
				if(dsd != null) {
					this.dsdError = "The data file can not be read with Data Structure '"+dsd.getUrn()+"' Message is :"+e.getMessage();
					this.loadingStatus = LOADING_STATUS.DSD_INCORRECT;
 				} else {
					this.dsdError = e.getMessage() != null ? e.getMessage() : "The data file does not reference a Data Structure";
					this.loadingStatus = LOADING_STATUS.DSD_MISSING;
				}
			} catch(Throwable th) {
				this.dsdError = th.getMessage();
			}
			//this.loadingStatus = LOADING_STATUS.ERRORED;
			return;
		} finally {
			if(!loadingStatus.isError()) {
				setLoadingStatus(LOADING_STATUS.FINISHED);
			}
		}
	}

	// An ErrorHandler that does not report any errors
	private class NonReportingErrorHandler implements DataValidationErrorHandler {

		@Override
		public void handleError(DataError err) throws ErrorLimitException {
			// Intentionally do nothing
		}

	}

	@Override
	public DataReaderEngine getDataReaderEngine(int datasetIndex) {
		if(this.loadingStatus != LOADING_STATUS.FINISHED) {
			throw new IllegalArgumentException("Can not get DataReaderEngine while current state is '"+loadingStatus.getStatus()+"'");
		}
		if(datasetIndex == -1 && this.dataValidationResult.size() == 1) {
			datasetIndex = 0;
		}

		if(datasetIndex == -1) {
			List<DataReaderEngine> dataReaderEngines = new ArrayList<>();
			for(DataValidationResult dvr : this.dataValidationResult) {
				dataReaderEngines.add(dvr.getDataReaderEngine());
			}
			return new MutlipleDataReaderEngineMultipleDatasets(dataReaderEngines, headerRetrievalManager);
		}
		if(datasetIndex >= this.getDatasets()) {
			throw new IllegalArgumentException("Can not get DataReaderEngine for dataset at index '"+datasetIndex+"'");
		}
		return getDataValidationResult(datasetIndex).getDataReaderEngine();
	}

	@Override
	public void writeInvalidData(ISeriesObsDataWriterEngine dwe) {
		writeData(dwe, true);
	}

	@Override
	public void writeValidData(ISeriesObsDataWriterEngine dwe) {
		writeData(dwe, false);
	}

	/**
	 * Writes all the data in errors (only) or valid data (only) depending on the boolean passed in
	 * @param readErrors true to return a reader that reads only the errors, false to read only the valid data
	 */
	private void writeData(ISeriesObsDataWriterEngine dwe, boolean readErrors) {
		List<DataError> allErrors = new ArrayList<>();
		for(DataValidationResult dvr : dataValidationResult) {
			for(List<DataError> dataErrors : dvr.getDataErrors().values()) {
				allErrors.addAll(dataErrors);
			}
		}
		DataValidationResultDataReaderEngine dre = new DataValidationResultDataReaderEngine(getDataReaderEngine(-1), allErrors, readErrors);
		DataTransformationUtil.copyData(dre, dwe, true, true);
	}

	@Override
	public void validateData(boolean async) {
		validateData(null, async);
	}

	@Override
	public void validateData(final List<IURNSingle<? extends IDSDRelatedBean>> sRefs, boolean async) {
		if(this.loadingStatus != null && this.loadingStatus.isError() && ObjectUtil.validCollection(sRefs)) {
			this.forceToReadUsing = sRefs.get(0);
			this.loadingStatus = LOADING_STATUS.INITIALISING;
			this.dsdError = null;
			this.missingReference = null;
		}
		if(this.loadingStatus != LOADING_STATUS.ERRORED) {
			if(async) {
				ISecureThread thread = FusionSecurityContext.CTX().createSecureThread(true);
				thread.runProcess(() -> {
					performValidation(sRefs);
				});
			} else {
				performValidation(sRefs);
			}
		}
	}

	private void performValidation(List<IURNSingle<? extends IDSDRelatedBean>> sRefs) {
		setLoadingStatus(LOADING_STATUS.VALIDATING_1);

		//If this is the first call, then initalise the reader
		if(!ObjectUtil.validCollection(dataValidationResult)) {
			init(true);
		}
		if(this.loadingStatus.isError()) {
			return;
		}
		//Set the references to override the data reads with - if any of these result in the underlying DSD changing, this
		//will automatically invoke a rebuild of the data reader engine, and re-consolidation process (init() will be invoked)
		setLoadingStatus(LOADING_STATUS.VALIDATING_1);
		try {
			if(ObjectUtil.validCollection(sRefs)) {
				int i = 0;
				for(IURNSingle<? extends IDSDRelatedBean> sRef : sRefs) {
					try {
						if (applyEdiLenientRules(formatDetails)) {
							ThreadLocalUtil.storeOnThread(ThreadLocalUtil.APPLY_EDI_LENIENCE, true);
						}
						this.dataValidationResult.get(i).reValidate(sRef);
					} finally {
						ThreadLocalUtil.clearFromThread(ThreadLocalUtil.APPLY_EDI_LENIENCE);
					}
					i++;
				}
			}
		} finally {
			if(!this.loadingStatus.isError()) {
				setLoadingStatus(LOADING_STATUS.FINISHED);
			}
		}
	}
	
	/**
	 * Determines whether "EDI Lenient" rules should be applied.
	 * This is determined by the format being EDI and the System property 'edi.lenient.enabled' being set to true.
	 */
	private boolean applyEdiLenientRules(FormatDetails formatDetails) {
		if (formatDetails != null && formatDetails.getFormatAsString().equals("SDMX-EDI")) {
			if (System.getProperty("edi.lenient.enabled") != null && System.getProperty("edi.lenient.enabled").equalsIgnoreCase("true")) {
				return true;
			}
		}
		return false;
	}

	private static ReadableDataLocation convertURLToRDL(URL url) {
		WriteableDataLocation wdl = new WriteableDataLocationTmp();
		RestMessageBroker.sendMessage(wdl.getOutputStream(), url.toString());

		ReadableDataLocation rdl = wdl;
		if(ZipUtil.isAZip(rdl) && !url.getPath().endsWith("xlsx")) {
			try {
				rdl = ZipUtil.unzipFile(wdl);
			} finally {
				wdl.close();
			}
		}
		return rdl;
	}


	@Override
	public URL getDataURL() {
		return url;
	}

	@Override
	public String getFilename() {
		return filename;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	/**
	 * Removes all stateful information about this dataset with regards to validation
	 */
	private void clearState() {
		dsdError = null;
		dataInformation = null;
		dataValidationResult = null;
	}

	/**
	 * Sets the Ddataflow or Data Structure Ref to Map the Dataset to
	 * @param datasetIndex
	 * @param sRef
	 * @param async
	 */
	@Override
	public void setMappedStructure(final int datasetIndex, final IURNSingle<? extends IStructureMapRelatedBean> sRef, boolean async) {
		if(async) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					setMappedStructure(datasetIndex, sRef);
				}
			}).start();
		} else {
			setMappedStructure(datasetIndex, sRef);
		}
	}

	/**
	 * Sets the Dataflow or Data Structure Ref to Map the Dataset to
	 * @param datasetIndex
	 * @param sRef
	 */
	private void setMappedStructure(int datasetIndex, IURNSingle<? extends IStructureMapRelatedBean> sRef) {
		this.loadingStatus = LOADING_STATUS.VALIDATING_2;
		try {
			MappingRules map;
			DataValidationResult dvr = dataValidationResult.get(datasetIndex);
			if(sRef == null) {
				dvr.map(null);
			} else {
				switch(sRef.getSdmxStructure()) {
				case DSD :
					mappedStructure = beanRetrievalManager.getBean(sRef.toType(DataStructureBean.class));
					if(mappedStructure == null) {
						throw new SdmxReferenceException(sRef);
					}
					map = sdmxMappingManager.getDataStructureMap(dvr.getDsd(), (DataStructureBean)mappedStructure);
					break;
				case DATAFLOW :
					mappedStructure = beanRetrievalManager.getBean(sRef.toType(DataflowBean.class));
					if(mappedStructure == null) {
						throw new SdmxReferenceException(sRef);
					}
					map = sdmxMappingManager.getDataStructureMap(dvr.getFlow(), (DataflowBean)mappedStructure);
					break;
				default : throw new SdmxException("URN expected to be to dsd, or dataflow, but was to :" +sRef.getSdmxStructure().getType());
				}
				dvr.map(map);
			}
			this.loadingStatus = LOADING_STATUS.FINISHED;
		} catch(Throwable th) {
			this.dsdError = th.getMessage();
			this.loadingStatus = LOADING_STATUS.ERRORED;
		}
	}

	@Override
	public boolean isMergeDatasets() {
		return mergeDatasets;
	}

	@Override
	public MaintainableBean getMappedStructure() {
		return mappedStructure;
	}


	@Override
	public DataValidationResult getDataValidationResult(int datasetIndex) {
		if(dataValidationResult == null || dataValidationResult.size() < (datasetIndex+1)) {
			return null;
		}
		return dataValidationResult.get(datasetIndex);
	}

	@Override
	public List<FooterMessage> getFooterMessages() {
		return footerMessages;
	}

	@Override
	public String getDsdError() {
		return dsdError;
	}

	@Override
	public LOADING_STATUS getLoadingStatus() {
		return loadingStatus;
	}

	private void setLoadingStatus(LOADING_STATUS loadingStatus) {
		this.loadingStatus = loadingStatus;
	}

	@Override
	public boolean getAttributesTested() {
		return attributesTested;
	}

	/**
	 * Returns all the available datastructures/dataflows that map to the data file
	 * @return
	 */
	@Override
	public Set<? extends MaintainableBean> getMappings() {
		//		if(getFlow() != null) {
		//			return this.mappingRetrievalManager.getMappingsForFlow(getFlow());
		//		}
		//		return this.mappingRetrievalManager.getMappingsForStructure(getDsd());
		return null;
	}

	@Override
	public DataInformation getDataInformation() {
		if(dataInformation == null) {
			List<DatasetInfo> allInfo = new ArrayList<>();
			for(DataValidationResult dvr : dataValidationResult) {
				DatasetInfo datasetInfo = dvr.getDataInformation().getDatasetInfo(0);
				allInfo.add(datasetInfo);
			}
			dataInformation = new DataInformation(allInfo);
		}
		return dataInformation;
	}
	@Override
	public String getFileFormat() {
		return fileFormat;
	}
	@Override
	public String getUid() {
		return uid;
	}

	private void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	@Override
	public IURNSingle<? extends IDSDRelatedBean> getMissingReference() {
		return missingReference;
	}

	@Override
	public int getDatasets() {
		if (dataValidationResult == null) {
			return -1;
		}
		return dataValidationResult.size();
	}

	@Override
	public void close() {
		if(rdl != null) {
			rdl.setProtected(false);
			rdl.close();
		}
		if(ObjectUtil.validCollection(dataValidationResult)) {
			for(DataValidationResult r : dataValidationResult) {
				r.close();
			}
		}
	}

	@Override
	public String getSenderId() {
		return senderId;
	}
}
