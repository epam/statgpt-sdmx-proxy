package io.sdmx.core.data.model.kryo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;

public class TextTypeWrapperListSerializer  extends Serializer<List<TextTypeWrapper>> {
	private static final TextTypeWrapperListSerializer INSTANCE = new TextTypeWrapperListSerializer();
	
	public static TextTypeWrapperListSerializer getInstance() {
		return INSTANCE;
	}
	
	private TextTypeWrapperListSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, List<TextTypeWrapper> toSer) {
		kryo.writeObject(output, toSer == null ? 0 : toSer.size());  
		for(TextTypeWrapper key : toSer) {
			kryo.writeObject(output, key, TextTypeWrapperSerializer.getInstance());
		}
	}

	@Override
	public List<TextTypeWrapper>  read(Kryo kryo, Input input, Class<? extends List<TextTypeWrapper>> type) {
		int attrSize = kryo.readObject(input, Integer.class);
		List<TextTypeWrapper> keyValueList =  attrSize > 0 ? new ArrayList<>(attrSize) : Collections.emptyList();
		for(int i=0; i < attrSize; i++) {
			keyValueList.add(kryo.readObject(input, TextTypeWrapper.class, TextTypeWrapperSerializer.getInstance()));
		}
		return keyValueList;
	}
	
	public static List<TextTypeWrapperMutableBean> toMutable(List<TextTypeWrapper> text) {
		List<TextTypeWrapperMutableBean> textMutable = text.size() == 0 ? Collections.emptyList() : new ArrayList<>(text.size());
		for(TextTypeWrapper tt : text) {
			textMutable.add(new TextTypeWrapperMutableBeanImpl(tt, null));
		}
		return textMutable;
	}
}