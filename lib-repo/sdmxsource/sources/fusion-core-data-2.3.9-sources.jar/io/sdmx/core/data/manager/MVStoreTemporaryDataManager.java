package io.sdmx.core.data.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.data.engine.writer.MVStoreDataWriterEngine;
import io.sdmx.core.data.model.io.MVTemporaryDataReadableDataLocation;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;
import io.sdmx.core.sdmx.engine.data.DatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.engine.data.TemporaryDataWriterEngine;

public class MVStoreTemporaryDataManager implements ITemporaryDataManager {
	private static final Logger LOG = LoggerFactory.getLogger(MVStoreTemporaryDataManager.class);

	@Override
	public ITemporaryDataWriterEngine getDataWriterEngine() {
		MVStoreDataWriterEngine mvStoreDwe = new MVStoreDataWriterEngine();
		ReadableDataLocation rdl = new MVTemporaryDataReadableDataLocation(mvStoreDwe);
		ITemporaryDataWriterEngine writer = new TemporaryDataWriterEngine(mvStoreDwe, rdl);
		LOG.trace("MVStoreTemporaryDataManager.getDataWriterEngine() => {}",  writer);
		return writer;
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ITemporaryDataWriterEngine writer) {
		LOG.trace("MVStoreTemporaryDataManager.getDataReaderEngine({})", writer);
		return new DatasetStoreDataReaderEngine(getMVStoreDataWriterEngine(writer));
	}

	@Override
	public void close(ITemporaryDataWriterEngine writer) {
		getMVStoreDataWriterEngine(writer).close(true);
	}

	private IDatasetStoreContainer getMVStoreDataWriterEngine(ITemporaryDataWriterEngine writer) {
		if (!(writer instanceof TemporaryDataWriterEngine)) {
			throw new IllegalArgumentException("Argument writer must be a TemporaryDataWriterEngine");
		}

		TemporaryDataWriterEngine tmpWriter = (TemporaryDataWriterEngine) writer;
		if(!(tmpWriter.getDataWriter() instanceof MVStoreDataWriterEngine)) {
			throw new IllegalArgumentException("TemporaryDataWriterEngine writer must be a MVStoreDataWriterEngine");
		}
		
		MVStoreDataWriterEngine mvStoreDwe = (MVStoreDataWriterEngine) tmpWriter.getDataWriter();
		return mvStoreDwe.getStorage();
	}
}
