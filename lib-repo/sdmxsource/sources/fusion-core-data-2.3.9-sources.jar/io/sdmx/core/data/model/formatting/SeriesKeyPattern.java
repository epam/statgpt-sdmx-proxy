package io.sdmx.core.data.model.formatting;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.SeriesUtil;

public class SeriesKeyPattern {
	private boolean notRule = false;
	private Map<String, Set<String>> keyValuesMap = new HashMap<>();
	private String seriesKey;
	private DataStructureBean dsd;

	/**
	 * Creates a pattern with the given key so that it can be matched against Keyable read from the dataset
	 * 
	 * @param key to match on, the syntax is either:
	 * =A:UK:EMP (full key)
	 * =A+M:UK+FR+DE:EMP (key with multiple matches per dimension)
	 * =A::EMP (key with wildcard dimension)
	 * FREQ=A,REF_AREA=UK (component values)
	 * 
	 * The rules can be negated by postfixing with a '!' character - a not rule returns true for any Key that does not match
	 * !REF_AREA=UK 
	 * !=A::EMP 
	 * 
	 * @param dsd
	 */
	public SeriesKeyPattern(String key, DataStructureBean dsd) {
		this.dsd = dsd;
		if(key.startsWith("!")) {
			notRule = true;
			key = key.substring(1);
		}
		if(key.startsWith("=")) {
			//Series Key Match
			key = key.substring(1);
			if(SeriesUtil.isFullKey(key, dsd.getDimensionIds().size())) {
				seriesKey = key;
			} else {
				keyValuesMap = SeriesUtil.toDimensionSelections(key, dsd.getDimensionIds(), CHARS.PLUS.getChar());
			}
		} else {
			//Key value pair match
			String[] kv = key.split(",");
			for(String currentKv : kv) {
				String[] kvSplit = currentKv.split("=");
				if(kvSplit.length == 1) {
					throw new SdmxSemmanticException("Syntax error on observation formatting key '"+key+"'. Expecting key value pairs in syntax 'FREQ=A+M,CURRENCY=USD' or as a series key match using syntax '=A+M:USD:DIM3'");
				}
				keyValuesMap.put(kvSplit[0], CollectionUtil.arrayToSet(kvSplit[1].split("\\+")));
			}
		}
	}
	
	/**
	 * @return the DSD this rule is for - null if the rule is generic and can be applied to multiple DSDs
	 */
	public DataStructureBean getDsd() {
		return dsd;
	}

	/**
	 * @param key
	 * @return true if the key matches one of the patterns, false if no patterns matched, or if this is a not rule the logic is reversed
	 */
	public boolean isMatch(Keyable key) {
		boolean match = false;
		if(seriesKey != null) {
			match = seriesKey.equals(key.getShortCode());
		} else {
			if(key.getDataStructure() == null) {
				return false;  //DSD unknown
			}
			match = true;
			for(String dimId : keyValuesMap.keySet()) {
				ComponentBean comp = key.getDataStructure().getComponent(dimId);
				if(comp  != null) {
					String reportedValue = key.getReportedValue(dimId);
					if(reportedValue == null || !keyValuesMap.get(dimId).contains(reportedValue)) {
						match = false;
						break;
					}
				} else {
					match = false;
				}
			}
		}
		
		return notRule ? !match : match;
	}
}
