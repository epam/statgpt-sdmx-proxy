package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.engine.reader.EmptyFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Writes data to a temporary location, optionally partitioned
 */
public class FlatDataWriterEngineTmpStore implements ITemporaryFlatDataWriterEngine {
	private HeaderBean header;
	private DatasetHeaderBean dsHeader;
	private List<IDataRow> rows = new ArrayList<>();
	
	@Override
	public void writeHeader(HeaderBean header) {
		this.header = header;
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		this.dsHeader = header;
	}

	@Override
	public void writeRow(IDataRow row) {
		rows.add(row);
	}

	@Override
	public void close() {}

	@Override
	public IFlatDataReaderEngine getDataReaderEngine() {
		if(rows == null) {
			return EmptyFlatDataReaderEngine.INSTANCE;
		}
		return new IFlatDataReaderEngine() {
			private int idx = -1;
			
			@Override
			public void reset() {
				idx = -1;
			}
			
			
			@Override
			public IFlatDataReaderEngine createCopy() {
				return getDataReaderEngine();
			}

			@Override
			public HeaderBean readHeader() {
				return header;
			}
			
			@Override
			public DatasetHeaderBean readDatasetHeader() {
				return dsHeader;
			}
			
			@Override
			public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
				idx++;
				return rows != null && rows.size() > idx;
			}
			
			@Override
			public IDataRow getCurrentRow() {
				if(idx < 0) {
					return null;
				}
				if(rows != null && rows.size() > idx) {
					return rows.get(idx);
				}
				return null;
			}
			
			@Override
			public void close() {
				idx = -1;
			}
		};
	}

	@Override
	public void removeResources() {
		header = null;
		dsHeader = null;
		rows = null;
	}
}
