package io.sdmx.core.data.model.kryo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;

public class ContactBeanListSerializer  extends Serializer<List<ContactBean>> {
	private static final ContactBeanListSerializer INSTANCE = new ContactBeanListSerializer();
	
	public static ContactBeanListSerializer getInstance() {
		return INSTANCE;
	}
	
	private ContactBeanListSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, List<ContactBean> keyValueList) {
		kryo.writeObject(output, keyValueList.size());  
		for(ContactBean key : keyValueList) {
			kryo.writeObject(output, key, ContactBeanSerializer.getInstance());
		}
	}

	@Override
	public List<ContactBean> read(Kryo kryo, Input input, Class<? extends List<ContactBean>> type) {
		int attrSize = kryo.readObject(input, Integer.class);
		List<ContactBean> returnList =  attrSize > 0 ? new ArrayList<>(attrSize) : Collections.emptyList();
		for(int i=0; i < attrSize; i++) {
			returnList.add(kryo.readObject(input, ContactBean.class, ContactBeanSerializer.getInstance()));
		}
		return returnList;
	}
}