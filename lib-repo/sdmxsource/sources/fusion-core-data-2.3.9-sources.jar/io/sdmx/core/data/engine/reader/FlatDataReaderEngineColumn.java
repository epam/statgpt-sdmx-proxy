package io.sdmx.core.data.engine.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.header.HeaderBeanImpl;

@Deprecated
public class FlatDataReaderEngineColumn implements IFlatDataReaderEngine {
	private ColumnReaderEngine columnDataReaderEngine;
	private HeaderRetrievalManager headerRetrievalManager;

	private IDatasetStructures structures;
	private HeaderBean header;
	private DatasetHeaderBean datasetHeaderBean;
	
	private List<String> columnComponents; //List of components in the same order as the columns, null indicates column that does not correspond to DSD

	private boolean isClosed = false;
	
	public FlatDataReaderEngineColumn(ColumnReaderEngine columnDataReaderEngine, IDatasetStructures structures, HeaderRetrievalManager headerRetrievalManager) {
		this.columnDataReaderEngine = columnDataReaderEngine;
		this.headerRetrievalManager = headerRetrievalManager;
		this.structures =structures;
		
		IDSDRelatedBean masterMaint = structures.getProvisionAgreement();
		if(masterMaint == null) {
			masterMaint = structures.getDataflow();
		}
		DataStructureBean dsd = structures.getDataStructure();
		if(masterMaint == null) {
			masterMaint = dsd;
		}
		String dimenisonAtObservation =  dsd.getTimeDimension() != null ? DimensionBean.TIME_DIMENSION_FIXED_ID :  DatasetStructureReferenceBean.ALL_DIMENSIONS;
		DatasetStructureReferenceBean dStrucRef = new DatasetStructureReferenceBeanImpl(null, masterMaint.getURN(), null, null, dimenisonAtObservation);
		datasetHeaderBean = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.INFORMATION, dStrucRef);
		
		List<String> headerRow = columnDataReaderEngine.readHeader();
		columnComponents = new ArrayList<>(headerRow.size());
		for(int i=0; i < headerRow.size(); i++) {
			String rowText = headerRow.get(i);
			boolean isComponent = dsd.getComponent(rowText) != null;
			rowText = isComponent ? rowText : null;
			columnComponents.add(rowText);
		}
		for(String dimId : structures.getDataStructure().getDimensionIds()) {
			if(columnComponents.indexOf(dimId) < 0) {
				throw new SdmxSemmanticException("Can not read CSV data, missing column for Dimension: "+dimId);
			}
		}
	}

	@Override
	public IFlatDataReaderEngine createCopy() {
		return new FlatDataReaderEngineColumn(columnDataReaderEngine.copy(), structures, headerRetrievalManager);
	}

	@Override
	public HeaderBean readHeader() {
		// Construct a Message Header Bean
		if(headerRetrievalManager != null) {
			header = (HeaderBeanImpl)headerRetrievalManager.getHeader();
		} else {
			String senderId = "unknown";
			header = new HeaderBeanImpl(senderId);
		}
		return header;
	}

	@Override
	public DatasetHeaderBean readDatasetHeader() {
		return datasetHeaderBean;
	}

	@Override
	public boolean moveNextRow(DataReaderExceptionHandler exHandler) {
		if(isClosed) {
			return false;
		}
		return columnDataReaderEngine.moveNextRow();
	}

	@Override
	public IDataRow getCurrentRow() {
		if(isClosed) {
			return null;
		}
		List<String> rowData = columnDataReaderEngine.readRow();
		if(rowData == null) {
			return null;
		}
		Map<String, String> newRow = new HashMap<>();
		int max = Math.min(rowData.size(), this.columnComponents.size());
		for(int i=0; i < max; i++) {
			String rowConcept = this.columnComponents.get(i);
			if(rowConcept != null) {
				String rowVaue = rowData.get(i);
				if(rowVaue != null && rowVaue.length() > 0) {
					newRow.put(rowConcept, rowVaue);
				}
			}
		}
		return new DataRow(structures, newRow);
	}

	@Override
	public void reset() {
		if(!isClosed) {
			columnDataReaderEngine.reset();
		}
	}

	@Override
	public void close() {
		if(!isClosed) {
			isClosed = true;
			columnDataReaderEngine.close();
		}
	}
}
