package io.sdmx.core.data.engine.reader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Is able to read data filtering out the data is error, or the data in success
 * thereby enabling the valid or invalid data to be written
 *
 */
public class DataValidationResultDataReaderEngine extends AbstractWrapperedDataReaderEngine {

	private Set<String> badKeys = new HashSet<>();
	private Set<String> keysWithObs = new HashSet<>();
	private Set<String> badObs = new HashSet<>();
	
	private int keyPosition;
	private int obsPosition;
	
	private boolean inBadKey = false; //True if the whole series is bad
	private Keyable currentKey;
	private Observation currentObs;
	
	private boolean readErrors;

	private List<Observation> tempStack;
	private boolean currentKeyHasNoObs;
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		return new DataValidationResultDataReaderEngine(proxyCopy, badKeys, keysWithObs, badObs, readErrors);
	}
	
	/**
	 * Copy constructor
	 */
	private DataValidationResultDataReaderEngine(DataReaderEngine dataReaderEngine, 
			Set<String> badKeys, 
			Set<String> keysWithObs,
			Set<String> badObs,
			boolean readErrors) {
		super(dataReaderEngine);
		this.readErrors = readErrors;
		this.badKeys = badKeys;
		this.keysWithObs = keysWithObs;
		this.badObs = badObs;
	}
	
	/**
	 * 
	 * @param dataReaderEngine
	 * @param dataErrors
	 * @param readErrors if true then this will filter out the good data and read only the errors, if false then it will filter out the errors
	 */
	public DataValidationResultDataReaderEngine(DataReaderEngine dataReaderEngine, Collection<DataError> dataErrors, boolean readErrors) {
		super(dataReaderEngine);
		
		dataReaderEngine.reset();
		this.readErrors = readErrors;
		for(DataError currentError : dataErrors) {
			List<String> shortCodes = currentError.getShortCode();
			if(!ObjectUtil.validCollection(shortCodes)) {
				continue;
			}
			switch(currentError.getErrorPosition()) {
			case GROUP :
			case SERIES :
				 badKeys.addAll(shortCodes);
				break;
			case OBSERVATION :
				badObs.addAll(shortCodes);
				break;
			}
		}
		if(badObs.size() > 0) {
			//Derive the series key from the DSD - note, we could split on ':' but if the obs time contains a ':' then this will
			//fail, so best to use the DSD to know how many dimensions we should expect in the short code
			if(dataReaderEngine.moveNextDataset()) {
				DataStructureBean dsd = dataReaderEngine.getDataStructure();
				
				int numberOfDimensions = dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).size();
				for(String obsShortCode : badObs) {
					int indexOf = 0;
					for(int i=0; i < numberOfDimensions; i++) {
						indexOf = obsShortCode.indexOf(":", indexOf+1);
					}
					// The code above assumes that a ":<obs_time>" suffix always exists, but this is not the case.
					// Some DSDs might not even have a definition for a TIME_DIMENSION (e.g.: BIS.XTD:FOW_SPEC(1.0)).
					// In this case there will be no ":" separator after the last dimension, indexOf will be -1 and
					// seriesShortCode should be the same as obsShortCode.
					String seriesShortCode = (indexOf == -1) ? obsShortCode : obsShortCode.substring(0, indexOf);
					keysWithObs.add(seriesShortCode);
				}
			}
			dataReaderEngine.reset();
		}
	}
	
	

	@Override
	public int getKeyablePosition() {
		return keyPosition;
	}

	@Override
	public int getObsPosition() {
		return obsPosition;
	}

	@Override
	public Keyable getCurrentKey() {
		return currentKey;
	}

	@Override
	public Observation getCurrentObservation() {
		return currentObs;
	}

	@Override
	public boolean moveNextObservation() {
		currentObs = null;

		if (currentKeyHasNoObs) {
			// The current key has no observations so return false. Do not invoke super.moveNextObservation()
			return false;
		}
		
		// Check for any entries in the observation stack and process these
		while (!tempStack.isEmpty()) {
			Observation obs = tempStack.remove(0);
			if (processObs(obs)) {
				return true;
			}
		}
		while(super.moveNextObservation()) {
			Observation obs = super.getCurrentObservation();
			if (processObs(obs)) {
				return true;
			}
		}
		return false;
	}

	private boolean processObs(Observation obs) {
		if(readErrors) {
			if(inBadKey || badObs.contains(obs.getShortCode())) {
				obsPosition++;
				currentObs = obs;
				return true;
			}
		} else if(!badObs.contains(obs.getShortCode())) {
			obsPosition++;
			currentObs = obs;
			return true;
		}
		return false;
	}

	@Override
	public boolean moveNextKeyable() {
		currentObs = null;
		currentKey = null;
		obsPosition = 0;
		currentKeyHasNoObs = false;
		
		while(super.moveNextKeyable()) {
			Keyable key = super.getCurrentKey();
			
			boolean isBadKey = badKeys.contains(key.getShortCode());
			inBadKey = isBadKey;
			
			tempStack = new ArrayList<>();
			// Do not want to write out an empty series key as a valid value
			if (!readErrors) {
				boolean shouldSkipKey = shouldSkipThisKey(key);
				if (shouldSkipKey) {
					continue;
				}
			}
			
			if(readErrors) {
				if(isBadKey || keysWithObs.contains(key.getShortCode())) {
					currentKey = key;
					keyPosition++;
					return true;
				}
			} else if(!isBadKey) {
				currentKey = key;
				keyPosition++;
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns true if this key has Observations and all are contained in the 'badObs' variable
	 */
	private boolean shouldSkipThisKey(Keyable key) {
		boolean hasAnObservation = false;
		while(super.moveNextObservation()) {
			hasAnObservation = true;
			currentKeyHasNoObs = false;
			Observation obs = super.getCurrentObservation();
			tempStack.add(obs);
			String obsShortCode = obs.getShortCode();
			if (!badObs.contains(obsShortCode)) {
				return false;
			}
		}
		
		if (!hasAnObservation) {
			currentKeyHasNoObs = true;
			return false;
		}
		
		return true;
	}
	
	@Override
	public boolean moveNextDataset() {
		return super.moveNextDataset();
	}

	@Override
	public void reset() {
		currentObs = null;
		currentKey = null;
		obsPosition = 0;
		keyPosition = 0;
		super.reset();
	}
}
