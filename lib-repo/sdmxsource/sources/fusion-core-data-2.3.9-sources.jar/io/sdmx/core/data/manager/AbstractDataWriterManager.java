package io.sdmx.core.data.manager;

import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.writer.FlatToTimeSeriesDataWriterEngine;
import io.sdmx.core.data.engine.writer.TimeSeriesToFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.api.factory.data.DataWriterFactory;
import io.sdmx.core.sdmx.api.factory.data.IFlatDataWriterFactory;
import io.sdmx.core.sdmx.api.factory.data.ISeriesDataWriterFactory;
import io.sdmx.core.sdmx.engine.data.RolldownDataWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class AbstractDataWriterManager {
	private Set<IFlatDataWriterFactory> flatFactories;
	private Set<ISeriesDataWriterFactory> seriesFactories;
	private Set<DataWriterFactory> skFactories;
	private DataFormatManager dataFormatManager;

	public AbstractDataWriterManager(DataFormatManager dataFormatManager) {
		this.dataFormatManager = dataFormatManager;
		SingletonStore.registerInstance(this);
	}

	public IFlatDataWriterEngine getFlatDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		IFlatDataWriterEngine engine = findFlatDataWriterEngine(dataFormat, out, dataQuery);
		if(engine != null) {
			return engine;
		}
		DataWriterEngine dwe = findSkDataWriterEngine(dataFormat, out, dataQuery);
		if(dwe != null) {
			return new FlatToTimeSeriesDataWriterEngine(dwe);
		}
		throw new SdmxNotImplementedException("Could not write data out in type: " +dataFormat);
	}

	public ISeriesObsDataWriterEngine getTimeSeriesDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat == null) {
			dataFormat = dataFormatManager.getDefaultFormat();
		}
		if(dataFormat == null){
			throw new IllegalArgumentException("Can not create DataWriterEngine - DataFormat is null ");
		}
		ISeriesObsDataWriterEngine sdwe = findSeriesDataWriterEngine(dataFormat, out, dataQuery);
		if(sdwe != null) {
			return sdwe;
		}

		DataWriterEngine dwe = findSkDataWriterEngine(dataFormat, out, dataQuery);
		if(dwe != null) {
			return new RolldownDataWriterEngine(dwe);
		}

		IFlatDataWriterEngine engine = findFlatDataWriterEngine(dataFormat, out, dataQuery);
		if(engine != null) {
			return new TimeSeriesToFlatDataWriterEngine(engine);
		}

		throw new SdmxNotImplementedException("Could not write data out in type: " +dataFormat);
	}

	private ISeriesObsDataWriterEngine findSeriesDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		for(ISeriesDataWriterFactory dwf : getSeriesDataWriterFactories()) {
			ISeriesObsDataWriterEngine dwe = dwf.getDataWriterEngine(dataFormat, out, dataQuery);
			if(dwe != null) {
				return dwe;
			}
		}
		return null;
	}

	private DataWriterEngine findSkDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		for(DataWriterFactory dwf : getDataWriterFactories()) {
			DataWriterEngine dwe = dwf.getDataWriterEngine(dataFormat, out, dataQuery);
			if(dwe != null) {
				return dwe;
			}
		}
		return null;
	}

	private IFlatDataWriterEngine findFlatDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat == null) {
			dataFormat = dataFormatManager.getDefaultFormat();
		}
		if(dataFormat == null){
			throw new IllegalArgumentException("Can not create DataWriterEngine - DataFormat is null ");
		}
		for(IFlatDataWriterFactory dwf : getFlatDataWriterFactories()) {
			IFlatDataWriterEngine dwe = dwf.getDataWriterEngine(dataFormat, out, dataQuery);
			if(dwe != null) {
				return dwe;
			}
		}
		return null;
	}

	private Collection<ISeriesDataWriterFactory> getSeriesDataWriterFactories() {
		if(seriesFactories == null) {
			Set<ISeriesDataWriterFactory> seriesFac = new HashSet<>();
			seriesFac.addAll(FusionBeanStore.getBeans(ISeriesDataWriterFactory.class));
			seriesFactories = seriesFac;
		}
		return seriesFactories;
	}

	private Collection<IFlatDataWriterFactory> getFlatDataWriterFactories() {
		if(flatFactories == null) {
			Set<IFlatDataWriterFactory> flatFac = new HashSet<>();
			flatFac.addAll(FusionBeanStore.getBeans(IFlatDataWriterFactory.class));
			flatFactories = flatFac;
		}
		return flatFactories;
	}

	private Collection<DataWriterFactory> getDataWriterFactories() {
		if(skFactories == null) {
			Set<DataWriterFactory> sf = new HashSet<>();
			sf.addAll(FusionBeanStore.getBeans(DataWriterFactory.class));
			skFactories = sf;
		}
		return skFactories;
	}

}
