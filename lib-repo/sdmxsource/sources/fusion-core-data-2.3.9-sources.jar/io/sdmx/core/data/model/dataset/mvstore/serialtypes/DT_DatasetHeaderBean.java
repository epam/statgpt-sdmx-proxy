package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.Date;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.ObjectDataType;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Serialization for DatasetHeaderBean.
 */
public class DT_DatasetHeaderBean extends BasicDataType<DatasetHeaderBean> {
  private final ObjectDataType objDT;
  private final DT_String strDT;
  private final DT_Integer intDT;
  private final DT_DatasetStructureReferenceBean dsrbDT;
  private final DT_DATASET_ACTION actionDT;
  private final String reportingYearStartDate_placeholder = null;

  public DT_DatasetHeaderBean() {
    this.objDT = new ObjectDataType();
    this.strDT = DT_String.getInstance();
    this.intDT = DT_Integer.getInstance(true);
    this.dsrbDT = new DT_DatasetStructureReferenceBean();
    this.actionDT = new DT_DATASET_ACTION();
  }

  @Override
  public int getMemory(DatasetHeaderBean x) {
    int size = 1; // null/object selector

    if (x != null) {
      size += strDT.getMemory(x.getDatasetId());
      size += actionDT.getMemory(x.getAction());
      size += dsrbDT.getMemory(x.getDataStructureReference());
      size += objDT.getMemory(x.getDataProviderReference());
      size += objDT.getMemory(x.getReportingBeginDate());
      size += objDT.getMemory(x.getReportingEndDate());
      size += objDT.getMemory(x.getValidFrom());
      size += objDT.getMemory(x.getValidTo());
      size += intDT.getMemory(x.getPublicationYear());
      size += strDT.getMemory(x.getPublicationPeriod());
      size += strDT.getMemory(reportingYearStartDate_placeholder);
    }

    return size;
  }

  @Override
  public void write(WriteBuffer buf, DatasetHeaderBean x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      strDT.write(buf, x.getDatasetId());
      actionDT.write(buf, x.getAction());
      dsrbDT.write(buf, x.getDataStructureReference());
      strDT.write(buf, x.getDataProviderReference() == null ? null : x.getDataProviderReference().getURN());
      objDT.write(buf, x.getReportingBeginDate());
      objDT.write(buf, x.getReportingEndDate());
      objDT.write(buf, x.getValidFrom());
      objDT.write(buf, x.getValidTo());
      intDT.write(buf, x.getPublicationYear());
      strDT.write(buf, x.getPublicationPeriod());
      strDT.write(buf, reportingYearStartDate_placeholder);
    }
  }

  @Override
  public DatasetHeaderBean read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    DatasetHeaderBean x = null;

    if (!isNull) {
      String datasetId = strDT.read(buf);
      DATASET_ACTION action = actionDT.read(buf);
      DatasetStructureReferenceBean dataStructureReference = dsrbDT.read(buf);
      String dataProviderURN = strDT.read(buf);
      Date reportingBeginDate = (Date)objDT.read(buf);
      Date reportingEndDate = (Date)objDT.read(buf);
      Date validFrom = (Date)objDT.read(buf);
      Date validTo = (Date)objDT.read(buf);
      Integer publicationYear = intDT.read(buf);
      String publicationPeriod = strDT.read(buf);
      String reportingYearStartDate = strDT.read(buf);

      x = new DatasetHeaderBeanImpl(datasetId,
                                    action,
                                    dataStructureReference,
                                    URN.buildOrNull(dataProviderURN, DataProviderBean.class),
                                    reportingBeginDate,
                                    reportingEndDate,
                                    validFrom,
                                    validTo,
                                    publicationYear,
                                    publicationPeriod,
                                    reportingYearStartDate);
    }

    return x;
  }

  @Override
  public DatasetHeaderBean[] createStorage(int size) {
    return new DatasetHeaderBean[size];
  }
}
