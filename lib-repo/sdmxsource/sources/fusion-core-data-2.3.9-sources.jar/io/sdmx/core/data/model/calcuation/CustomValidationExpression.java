package io.sdmx.core.data.model.calcuation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.core.sdmx.error.CaculationError;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.exception.CalculationErrorHandler;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.data.calculation.IDimensionValidationExpression;
import io.sdmx.api.sdmx.model.error.ICaculationError;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A ValidationExpression operates on a ValidationRuleBean which is operating on a single dimension
 */
public class CustomValidationExpression implements IDimensionValidationExpression {
	private static final Logger LOG = LoggerFactory.getLogger(CustomValidationExpression.class);
	
	private ValidationRuleBean rule;
	private final Pattern PATTERN = Pattern.compile("\\[([^]]+)\\]", Pattern.DOTALL);
	private String outputCode;
	private Double output;
	private List<String> inputCodes = new ArrayList<>();

	private String equationRHS;  //[FR]+[DE]
	private String equality;
	private Calculator calculator;

	//Short Code - Including Time Period to Group of values
	private Map<String, Group> groups = new HashMap<>();

	private int dimensionIndex; //The index of the dimension that this rule is operating on

	private Double lastCalculatedResult;

	/**
	 * @param dimensionId example REFERENCE_AREA
	 * @param equation - example [::UK]=[::FR]+[::DE]
	 */
	public CustomValidationExpression(ValidationRuleBean rule) {
		this(rule.getResultant(), rule.getEqualityOperator().toString(), rule.getExpression());
		this.rule = rule;
	}

	public CustomValidationExpression(String result, String equality, String equation) {
		if(!ObjectUtil.validString(result)) {
			throw new SdmxSemmanticException("Can not construct CustomValidationExpression - missing 'result' parameter");
		}
		if(!ObjectUtil.validString(equality)) {
			throw new SdmxSemmanticException("Can not construct CustomValidationExpression - missing 'equality' parameter");
		}
		if(!ObjectUtil.validString(equation)) {
			throw new SdmxSemmanticException("Can not construct CustomValidationExpression - missing 'equation' parameter");
		}
		calculator = new Calculator();
		if(LOG.isDebugEnabled()) {
			LOG.debug("result: "+ result);
			LOG.debug("equality: "+ equality);
			LOG.debug("equation: "+ equation);
		}
		try {
			output = Double.parseDouble(result);
		} catch(NumberFormatException e) {}

		Matcher m = PATTERN.matcher(equation);
		while(m.find()) {
			for(int i = 0 ; i < m.groupCount(); i++) {
				String found = m.group(i);
				String replaced = found.replace("[", "");
				replaced = replaced.replace("]", "");
				LOG.debug("Process Rule Placeholder: "+replaced);
				String[] split = replaced.split(":");
				for(int idx=0; idx < split.length; idx++) {
					String str = split[idx];
					if(ObjectUtil.validString(str)) {
						replaced = str;
						this.dimensionIndex = idx;
						LOG.debug("Dimension Code: "+replaced);
						LOG.debug("Dimension Index: "+dimensionIndex);
						break;
					}
				}
				inputCodes.add(replaced);
				LOG.debug("inputCodes: "+ replaced);
				equation = equation.replace(found, "["+replaced+"]");
				LOG.debug("Updated Equation: "+equation);
			}
		}
		outputCode = result.replaceAll("\\[", "");
		outputCode = outputCode.replaceAll("\\]", "");
		outputCode = outputCode.replaceAll(":", "");

		this.equationRHS = equation;
		this.equality = equality;
		//test the equality operator is valid
		EQUALITY.fromString(equality);
		if(LOG.isDebugEnabled()) {
			LOG.debug("output code: "+ outputCode);
			LOG.debug("equation modified: "+ equation);
		}
	}

	public ValidationRuleBean getRule() {
		return rule;
	}

	@Override
	public EQUALITY getEquality() {
		return EQUALITY.fromString(equality);
	}

	@Override
	public boolean isOutputNumerical() {
		return output != null;
	}

	public int getDimensionIndex() {
		return dimensionIndex;
	}

	@Override
	public String getOutputCode() {
		return outputCode;
	}

	@Override
	public List<String> getInputCodes() {
		return Collections.unmodifiableList(inputCodes);
	}

	@Override
	/**
	 * Short code is the observation short code (A:B:C:2008)
	 */
	public void addOutput(String shortCode, Double value) {
		LOG.debug("addOutput value for '"+shortCode+"'='"+value+"'");
		getGroup(shortCode).output = value;
	}

	@Override
	/**
	 * Short code is the observation short code (A:B:C:2008)
	 */
	public void addInput(String shortCode, int index, Double value) {
		LOG.debug("addInput  value for '"+shortCode+"'='"+value+"'");
		getGroup(shortCode).inputs[index] = value;
	}



	@Override
	public void validate(CalculationErrorHandler errorHandler) {
		//Short code is the observation short code
		for(String shortCode : groups.keySet()) {
			Group group = groups.get(shortCode);
			if(output != null) {
				group.output = output;
			}
			if(!group.validGroup()) {
				LOG.debug("Group for short code '"+shortCode+"' does not have enough information to perform a cacluation - missing output or inputs");
				continue;
			}
			ValidationExpressionResult result = execute(group.output, group.inputs);
			if(!result.isPass()) {
				String expression = outputCode+equality+equationRHS;
				ICaculationError error = new CaculationError(shortCode, expression, this.equality, inputCodes, result.getResolvedExpression(), result.getCalculationResult(), group.output, result.getThrowable());
				errorHandler.reportError(error);
			}
		}
	}

	private Group getGroup(String shortCode) {
		Group group = groups.get(shortCode);
		if(group == null) {
			group = new Group();
			groups.put(shortCode, group);
		}
		return group;
	}

	private class Group {
		private Double output;
		private Double[] inputs;

		public Group() {
			inputs = new Double[inputCodes.size()];
		}

		/**
		 * Returns true if there is an output, and at least one input
		 * @return
		 */
		private boolean validGroup() {
			if(output == null) {
				return false;
			}
			for(int i=0; i < inputs.length; i++) {
				if(inputs[i] != null) {
					return true;
				}
			}
			return false;
		}
	}

	/**
	 * Re-writes the expression, replacing the series key placeholders with the input values.
	 * Example, expression: [::A:] + [::B:] with inputs a0 a1 would be re-written to a0 + a1
	 * if null is passed, or any aspects of the inputs are null, the relevant placeholder will be rewritten as a[x], 
	 * where [x] = zero indexed position, i.e a0, a1
	 *  
	 * @param inputs
	 * @return
	 */
	public String rewriteExpression(String... inputs) {
		String newExpression = equationRHS;
		Matcher m = PATTERN.matcher(newExpression);

		int i=0;
		while(m.find()) {
			String input = inputs != null && inputs.length > i ? inputs[i] : null;
			if(input == null) {
				input = "a"+i;
			}
			newExpression = m.replaceFirst(input.toString());
			m = PATTERN.matcher(newExpression);
			i++;
		}
		return newExpression;
	}

	/**
	 * Execute the expression, returning true for pass false for fail
	 * @param actualOutput
	 * @param inputs
	 * @return
	 */
	public ValidationExpressionResult execute(Double actualOutput, Double...inputs) {
		String[] asString = new String[inputs.length];
		int i=0;
		for(Double d : inputs) {
			asString[i] = d == null ? "0" : d.toString();
			i++;
		}

		String newExpression = rewriteExpression(asString);
		try {
			lastCalculatedResult = calculator.execute(newExpression); 
		} catch(Throwable th) {
			return new ValidationExpressionResult(newExpression, actualOutput, th);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("evaluate in:"+actualOutput + equality + newExpression);
			LOG.debug("evaluate out:"+actualOutput + equality + lastCalculatedResult);
		}
		boolean pass = false;
		switch(equality) {
		case "=" : pass = lastCalculatedResult - actualOutput == 0; break;
		case "<" : pass = actualOutput < lastCalculatedResult; break;
		case "<=" : pass = actualOutput <= lastCalculatedResult; break;
		case ">" : pass = actualOutput > lastCalculatedResult; break;
		case ">=" : pass = actualOutput >= lastCalculatedResult; break;
		case "<>" : pass = lastCalculatedResult - actualOutput != 0; break;
		default : throw new UnsupportedOperationException("Unsupported equality operator: " +equality);
		}
		return new ValidationExpressionResult(newExpression, actualOutput, lastCalculatedResult, pass);
	}

	@Override
	public String toString() {
		return outputCode+equality+equationRHS;
	}
}
