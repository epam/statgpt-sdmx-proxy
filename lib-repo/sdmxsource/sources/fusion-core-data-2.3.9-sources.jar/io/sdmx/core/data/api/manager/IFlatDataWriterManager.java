package io.sdmx.core.data.api.manager;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * Obtains an {@link IFlatDataWriterEngine} based on required output format
 */
public interface IFlatDataWriterManager {
	/**
	 * Returns a {@link DataWriterEngine} that can write the given {@link DATA_TYPE}.
	 * @param dataFormat defines the data format to write the output in - if null is passed the default format form the {@link DataFormatManager} will be used
	 * @param out the {@link OutputStream} to write the data to
	 * @return
	 * @throws SdmxNotImplementedException if no {@link IFlatDataWriterEngine} could be found to write the requested data
	 */
	default IFlatDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out) {
		return getDataWriterEngine(dataFormat, out, null);
	}
	
	/**
	 * Returns a {@link DataWriterEngine} that can write the given {@link DATA_TYPE}.
	 * @param dataFormat defines the data format to write the output in - if null is passed the default format form the {@link DataFormatManager} will be used
	 * @param out the {@link OutputStream} to write the data to
	 * @param dataQuery (optional)defines the data query that was used to obtain the data 
	 * @return
	 * @throws SdmxNotImplementedException if no {@link IFlatDataWriterEngine} could be found to write the requested data
	 */
	IFlatDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery);
}
