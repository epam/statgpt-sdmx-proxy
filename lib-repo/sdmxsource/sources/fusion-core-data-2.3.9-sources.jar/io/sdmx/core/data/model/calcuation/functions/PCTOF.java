package io.sdmx.core.data.model.calcuation.functions;

import io.sdmx.core.data.api.model.calculation.ICalculationFunction;
import io.sdmx.core.data.model.calcuation.Calculator;

/**
 * Percentage Of (arg1, arg2) converted to (100/arg2) * arg1
 * @author Matthew Nelson
 *
 */
public class PCTOF implements ICalculationFunction {
	
	private PCTOF() {}

	public static void register() {
		Calculator.registerFunction(new PCTOF());
	}

	@Override
	public String functionName() {
		return "PCTOF";
	}

	@Override
	public int minArguments() {
		return 2;
	}

	@Override
	public int maxArguments() {
		return 2;
	}

	@Override
	public String rewrite(String... args) {
		return "((100/"+args[1]+")*"+args[0]+")";
	}
	
}
