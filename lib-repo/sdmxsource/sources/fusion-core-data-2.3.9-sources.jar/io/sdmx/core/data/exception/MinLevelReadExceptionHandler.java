package io.sdmx.core.data.exception;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.core.data.api.manager.DataValidatorLevelRetrievalManager;
import io.sdmx.core.data.manager.DefaultDataValidatorLevelRetrievalManager;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * Ignores all errors unless they hit the minimum level or greater
 */
public class MinLevelReadExceptionHandler implements DataValidationErrorHandler {

    private DataValidatorLevelRetrievalManager dataValidatorManager;

	private VALIDATION_LEVEL level;
	private int maxErrors;
	private int errorCount = 0;

	private List<DataError> dataErrors = new ArrayList<>();

	/**
	 * First failure when an error is reported which hits the minimum level
	 * @param minLevel
	 */
	public MinLevelReadExceptionHandler(VALIDATION_LEVEL minLevel) {
		this(minLevel, 1);
	}

	/**
	 * Stores the errors until the limit is hit
	 * @param minLevel
	 * @param maxErrors if 0 or less then no limit is imposed
	 */
    public MinLevelReadExceptionHandler(VALIDATION_LEVEL minLevel, int maxErrors) {
        dataValidatorManager = SingletonStore.getSingleton(DataValidatorLevelRetrievalManager.class);
        if(dataValidatorManager == null) {
        	dataValidatorManager = new DefaultDataValidatorLevelRetrievalManager();
        }
        this.level = minLevel;
        this.maxErrors = maxErrors;
	}

	@Override
	public void handleError(DataError err) throws ErrorLimitException {
		if(err == null) {
			return;
		}
		if(dataValidatorManager.getValidationLevel(err.getErrorCategory()).isGreaterThanOrEqualTo(level)) {
			dataErrors.add(err);
			errorCount++;
			if(maxErrors > 0 & errorCount > maxErrors) {
				throw new ErrorLimitException(maxErrors, getErrorMessages());
			}
		}
	}

	public boolean hasErrors() {
		return dataErrors.size() > 0;
	}

	public List<DataError> getErrors() {
		return Collections.unmodifiableList(dataErrors);
	}

	public List<String> getErrorMessages() {
		return dataErrors.stream().map(DataError::getMessage).collect(Collectors.toList());
	}

}
