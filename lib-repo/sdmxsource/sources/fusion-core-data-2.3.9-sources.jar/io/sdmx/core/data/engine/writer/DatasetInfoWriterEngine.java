package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.DatasetInfo;
import io.sdmx.core.sdmx.engine.data.DataWriterEngineProxy;

/**
 * Builds up a picture of the number of series, groups, and obs written for each dataset as it is written
 */
public class DatasetInfoWriterEngine extends DataWriterEngineProxy {
	private List<DatasetInfo> datasetInfo = new ArrayList<>();
	private DatasetInfo currentInfo;
	private DataInformation finalInformation;
	
	public DatasetInfoWriterEngine(ISeriesObsDataWriterEngine dwe) {
		super(dwe);
	}

	/**
	 * Returns the built dataset information
	 * @return
	 */
	public DataInformation getDataInformation() {
		if(finalInformation != null) {
			return finalInformation;
		}
		//On the fly details, still not closed writer
		return new DataInformation(datasetInfo);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		super.startDataset(structures, header, datasetAttributes, annotations);
		if(currentInfo != null) {
			currentInfo.makeFinal();
		}
		currentInfo = new DatasetInfo(header, structures);
		datasetInfo.add(currentInfo);
	}

	@Override
	public void writeKey(Keyable key) {
		super.writeKey(key);
		if(key.isSeries()) {
			currentInfo.addKey();
		} else {
			currentInfo.addGroup();
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		super.writeObservation(obs);
		currentInfo.addObservation();
	}

	@Override
	public void close(FooterMessage... footer) {
		super.close(footer);
		if(currentInfo != null) {
			currentInfo.makeFinal();
		}
		finalInformation = new DataInformation(datasetInfo);
		datasetInfo = null; 
		currentInfo = null;
	}
}
