package io.sdmx.core.data.api.manager;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;

/**
 * A stateful manager which knows about a process, and is able to return a specific step in that process on demand
 */
public interface IProcessStepRetrievalManager {

	/**
	 * @param processId
	 * @return the process step for the identifier
	 */
	IFlatDataWriterEngine getProcessStep(String processId);
}
