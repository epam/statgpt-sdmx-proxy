package io.sdmx.core.data.engine.writer;

import java.util.Map;

import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;

/**
 * A Flat to TimeSeries DataWriterEngine that does not output groups
 */
public class FlatToTimeSeriesDataWriterEngineNoGroups extends FlatToTimeSeriesDataWriterEngine {

    public FlatToTimeSeriesDataWriterEngineNoGroups(DataWriterEngine dataWriterEngine) {
        super(dataWriterEngine);
	}

	public FlatToTimeSeriesDataWriterEngineNoGroups(ISeriesObsDataWriterEngine dataWriterEngine) {
		super(dataWriterEngine);
	}
	
	@Override
    protected boolean isNewGroup(String groupId, Map<String, String> values) {
	    return false;
	}

}
