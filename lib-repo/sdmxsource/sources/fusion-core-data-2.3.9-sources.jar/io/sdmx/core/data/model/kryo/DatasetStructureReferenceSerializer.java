package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class DatasetStructureReferenceSerializer  extends Serializer<DatasetStructureReferenceBean> {
	private static final DatasetStructureReferenceSerializer INSTANCE = new DatasetStructureReferenceSerializer();
	
	public static DatasetStructureReferenceSerializer getInstance() {
		return INSTANCE;
	}
	
	private DatasetStructureReferenceSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, DatasetStructureReferenceBean object) {
		kryo.writeObject(output, object == null ? -1 : 1);
		if(object != null) {
			kryo.writeObjectOrNull(output, object.getDimensionAtObservation(), String.class);
			kryo.writeObjectOrNull(output, object.getId(), String.class);
			kryo.writeObjectOrNull(output, object.getServiceURL(), String.class);
			kryo.writeObjectOrNull(output, object.getStructureReference().getURN(), String.class);
			kryo.writeObjectOrNull(output, object.getStructureURL(), String.class);
		}
	}

	@Override
	public DatasetStructureReferenceBean read(Kryo kryo, Input input, Class<? extends DatasetStructureReferenceBean> type) {
		boolean isNull = kryo.readObject(input, Integer.class) == -1;
		if(isNull) {
			return null;
		}
		String dimAtObs = kryo.readObjectOrNull(input, String.class);
		String id = kryo.readObjectOrNull(input, String.class);
		String serviceUrl = kryo.readObjectOrNull(input, String.class);
		String sRef = kryo.readObjectOrNull(input, String.class);
		String structureUrl = kryo.readObjectOrNull(input, String.class);
		
		return new DatasetStructureReferenceBeanImpl(id, URN.builder(sRef).buildSingle(IDSDRelatedBean.class), serviceUrl, structureUrl, dimAtObs);
	}
}