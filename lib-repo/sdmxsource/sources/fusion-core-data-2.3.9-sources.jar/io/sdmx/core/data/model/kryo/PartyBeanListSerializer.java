package io.sdmx.core.data.model.kryo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.header.PartyBean;

public class PartyBeanListSerializer  extends Serializer<List<PartyBean>> {
	private static final PartyBeanListSerializer INSTANCE = new PartyBeanListSerializer();
	
	public static PartyBeanListSerializer getInstance() {
		return INSTANCE;
	}
	
	private PartyBeanListSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, List<PartyBean> keyValueList) {
		kryo.writeObject(output, keyValueList.size());  
		for(PartyBean key : keyValueList) {
			kryo.writeObject(output, key, PartyBeanSerializer.getInstance());
		}
	}

	@Override
	public List<PartyBean>  read(Kryo kryo, Input input, Class<? extends List<PartyBean>> type) {
		int attrSize = kryo.readObject(input, Integer.class);
		List<PartyBean> keyValueList =  attrSize > 0 ? new ArrayList<>(attrSize) : Collections.emptyList();
		for(int i=0; i < attrSize; i++) {
			keyValueList.add(kryo.readObject(input, PartyBean.class, PartyBeanSerializer.getInstance()));
		}
		return keyValueList;
	}
}