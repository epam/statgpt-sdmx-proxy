package io.sdmx.core.data.api.model.mapping;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;

/**
 * Contains MappingRules built from a {@link IStructureMapBean}
 */
public interface MappingRules {
	
	/**
	 * Reverses the mapping rules by changing the source DSD to the target and target to source (and all the rules in-between)
	 * Note - this is only possible if the source does not contain regex expressions or substring mappings
	 * @return
	 */
	MappingRules getReverseMapping();
	
	/**
	 * @return Source Dataflow or null if this is only mapping DSDs
	 */ 
	DataflowBean getFromDataflow();

	/**
	 * @return Target Dataflow or null if this is only mapping DSDs
	 */
	DataflowBean getToDataflow();

	/**
	 * 
	 * @return source DSD this will not be null
	 */
	DataStructureBean getFromDataStructure();
	
	/**
	 * Target DSD this will not be null
	 * @return
	 */
	DataStructureBean getToDataStructure();
	
	/**
	 * Returns the structure map that was used to construct this engine
	 * @return
	 */
	IStructureMapBean getStructureMapBean();
	
	/**
	 * @return rules to generate the output time period, or null if there are no rules or output time period
	 */
	ITimePeriodMapping getTagetTimePeriodMapping();
	
	/**
	 * When multiple source measures map to the same output measure, it creates a split - forcing two mapping requests for the same row, for example:
	 * <br/>
	 * M1, M2, M3 -> OBS_VALUE 
	 * <br/>
	 * Translates into this method returning a List containing one item each, M1, M2, M3 
	 * <br/>
	 * This information is then translated into a row of data being split into three rows for mapping, for example
	 * FREQ,REF_AREA,M1,M2,M3 will be split into the following mapping requests:
	 * <ol>
	 *   <li>FREQ, REF_AREA, M1</li>
	 *   <li>FREQ, REF_AREA, M2</li>
	 *   <li>FREQ, REF_AREA, M3</li>
	 * </ol>
	 * <br/>
	 * In a more complex example where the combination of measures is required to generate an outupt:
	 * <br/>
	 * M1a or M2a -> M1x  & M1a and M3a -> M4x
	 * <br/>
	 * The above is translated into a List of two items, each with 2 items: 
	 * <ol>
	 *  <li>M1a (output is M1 and M4)</li>
	 *  <li>M2a, M3a (output is M1 and M4)</li>
	 * </ol> 
	 * <br/>
	 * In the case that there is no measure in or out, or there is a simple mapping which does not require any splits, this method will return an empty list
	 * 
	 * @return immutable list, not null
	 */
	List<Set<String>> getSplitByMeasure();
	
	/**
	 * @return fix ouptut values at the dataset level
	 */
	Map<String, String> getDatasetAttributes();
	
	/**
	 * @return an immutable map of fixed values (Component Id to Fixed value), excluding dataset attributes, or an empty man if no fixed values defined
	 */
	Map<String, String> getFixedValues();
	
	/**
	 * @return if defined, a map of code id to date formatter used to parse a {@link Date} into an output, if not defined returns null
	 */
	Map<String, DateFormat> getDateFormatMap();
	
	/**
	 * @return immutable map, source component id to the mapping rules for that component
	 */
	Map<String, Set<IComponentMappingRules>> getSingleMappingRules();
	
	/**
	 * @return immutable map of component id, to the time mapping used for that component
	 */
	Map<String, Set<ITimeMapping>> getTimeMapping();
	
	/**
	 * @return immutable map, where multiple source dimensions are used to derive the output value
	 */
	Set<IComponentMappingRules> getCombinationMappingRules();
	
	/**
	 * @param component
	 * @return true if the Component is mapped in either a single key or combination key mapping
	 */
	boolean hasMapping(ComponentBean component);
	/**
	 * @param componentId
	 * @return true if the Component with the given ID is mapped in either a single key or combination key mapping
	 */
	boolean hasMapping(String componentId);
}
