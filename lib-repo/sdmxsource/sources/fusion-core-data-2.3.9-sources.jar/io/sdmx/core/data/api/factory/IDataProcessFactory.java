package io.sdmx.core.data.api.factory;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.data.api.manager.IProcessStepRetrievalManager;
import org.codehaus.jettison.json.JSONObject;

/** 
 * A factory used to generate a {@link IFlatDataWriterEngine} which performs the process task, for example a validation process
 * would validate the data when written to the generated {@link IFlatDataWriterEngine}, whereas a split process may split the 
 */
public interface IDataProcessFactory {
	
	/**
	 * @return unique identification for this process
	 */
	String getProcessId();
	
	/**
	 * @param properties - optional, any additional properties used to configure the process
	 * @param stepRetrievalManager - required to retrieve any sub process steps for this process
	 * @return {@link IFlatDataWriterEngine} encapsulating the logic of the process, wrapping the proxy if provided (and supported)
	 */
	IFlatDataWriterEngine getDataWriterEngine(JSONObject properties, IProcessStepRetrievalManager stepRetrievalManager);

}
