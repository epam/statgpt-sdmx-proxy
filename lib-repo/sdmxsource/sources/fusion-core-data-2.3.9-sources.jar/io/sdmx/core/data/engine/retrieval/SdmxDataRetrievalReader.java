
package io.sdmx.core.data.engine.retrieval;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * The SdmxDataRetrievalWithStream is capable of executing a data query, returning a DataReaderEngine with the result
 *
 */
public interface SdmxDataRetrievalReader {

	/**
	 * Queries for data and returns a DataReaderEngine to read the data
	 * @param dataQuery
	 * @param dataWriterEngine
	 */
	DataReaderEngine getData(DataQuery dataQuery);
	
}
