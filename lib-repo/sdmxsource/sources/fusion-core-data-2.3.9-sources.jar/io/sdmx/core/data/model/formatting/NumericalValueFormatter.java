package io.sdmx.core.data.model.formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.model.dataset.IObservationValueFormatter;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.NumberUtils.Format;
import io.sdmx.utils.core.object.NumberUtils.NotationStyle;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public class NumericalValueFormatter implements IObservationValueFormatter {
	private NumberUtils.Format globalFormat;
	private List<PatternRule> patternRules;
	private static final String UNIT_MULT = "UNIT_MULT";
	
	/**
	 * @param formattingRules series key (wildcard allowed) to formatting rules, empty string key to indicate global rule if none else match
	 */
	public NumericalValueFormatter(List<IObservationFormatting> formattingRules, Map<String, DataStructureBean> dsdMap) {
		for(IObservationFormatting rule : formattingRules) {
			NumberUtils.Format format = buildFormat(rule);
			
			if(!ObjectUtil.validCollection(rule.getKeyMatch())) {
				globalFormat = format;
			} else {
				for(String key : rule.getKeyMatch()) {
					boolean notRule = false;
					Map<String, Set<String>> componentValues = new HashMap<>();
					if(key.startsWith("!")) {
						notRule = true;
						key = key.substring(1);
					}
					DataStructureBean dsd = null;
					if(key.startsWith("=")) {
						//Series Key Match
						key = key.substring(1);
						String alias = "";
						if(key.contains(".")) {
							//DSD Alias to key
							String[] aliasSplit = key.split("\\.", 2);
							alias = aliasSplit[0];
							key = aliasSplit[1];
						}
						dsd = dsdMap != null ? dsdMap.get(alias) : null;
						if(dsd == null) {
							if(alias.length() == 0) {
								alias = "(default)";
							}
							throw new SdmxSemmanticException("Unable to process formatting rule '"+rule.getKeyMatch()+"' DSD not found for alias '"+alias+"'");
						}
						componentValues = SeriesUtil.toDimensionSelections(key, dsd.getDimensionIds(), CHARS.PLUS.getChar());
					} else {
						//Key value pair match
						String[] kv = key.split(",");
						for(String currentKv : kv) {
							String[] kvSplit = currentKv.split("=");
							if(kvSplit.length == 1) {
								throw new SdmxSemmanticException("Syntax error on observation formatting key '"+key+"'. Expecting key value pairs in syntax 'FREQ=A+M,CURRENCY=USD' or as a series key match using syntax '=A+M:USD:DIM3'");
							}
							Set<String> valueSet = new HashSet<>();
							for(String value : CollectionUtil.arrayToSet(kvSplit[1].split("\\+"))) {
								valueSet.add(value.trim());
							}
							componentValues.put(kvSplit[0].trim(), valueSet);
						}
					}
					if(patternRules == null) {
						patternRules = new ArrayList<>();
					}
					patternRules.add(new PatternRule(dsd, notRule, componentValues, format));
				}
			}
		}
	}

	@Override
	public String getObservationValue(Observation obs, String measure) {
		//TODO add support for multiple values
		KeyValue kv = obs.getMeasure(measure);
		if(kv != null) {
			if (!kv.hasMultipleValues()) {
				if (!NumberUtils.isParsable(kv.getCode())) {
					return kv.getCode();
				}
				Format format = getFormat(obs);
				if (format != null) {
					if (format.scalingFactor() != null) {
						//Compare the scaling factor with the UNIT_MULT on the observation ( if there is one) and take the diff
						int scalingFactor = format.scalingFactor();
						int unitMultScalingFactor = getUnitMultipler(obs);
						if (unitMultScalingFactor != 0) {
							//adjust scaling factor
							scalingFactor = unitMultScalingFactor - scalingFactor;
							format = Format.get(format);
							format.scalingFactor(scalingFactor);
						}
					}
					return NumberUtils.formatNumber(kv.getCode(), format);
				}

			}
			return kv.getCode();
		}
		return null;
	}
	
	/**
	 * @return the unit multiplier on the observation, 0 to indicate no multipler to be applied
	 */
	private int getUnitMultipler(Observation obs) {
		String unitMult = obs.getAttributeValue(UNIT_MULT);
		if(unitMult == null) {
			Keyable key = obs.getSeriesKey();
			if(key != null) {
				unitMult = key.getAttributeValue(UNIT_MULT);
				if(unitMult == null) {
					KeyValue kv = key.getKeyValue(UNIT_MULT);
					unitMult = kv == null ? null : kv.getCode();
				}
			}
		}
		if(unitMult != null && NumberUtils.isInteger(unitMult, true)) {
			return Integer.parseInt(unitMult);
		}
		return 0;
	}
	
	private Format getFormat(Observation obs) {
		if(patternRules != null &&
				obs.getSeriesKey() != null &&
				obs.getSeriesKey().getDataStructure() != null) {
			for(PatternRule p : patternRules) {
				if(p.ruleMatch(obs)) {
					return p.format;
				}
			}
		}
		return globalFormat;
	}

	private NumberUtils.Format buildFormat(IObservationFormatting formatting) {
		NotationStyle notationStyle = formatting.isScientificNotation() ? NotationStyle.ENGINGEERING_NOTATION : NotationStyle.PLAIN;
		NumberUtils.Format format = Format.get().roundMode(formatting.getRoundingMode()).outputNotation(notationStyle);
		if(formatting.isPrecisionDP()) {
			format.dp(formatting.getPrecision());
		} else {
			format.sf(formatting.getPrecision());
		}
		format.normalise(formatting.isNormalise());
		if(formatting.getLocale() != null) {
			Locale locale = formatting.getLocale();
			if(locale == Locale.ROOT) {
				ClientRequest request = ThreadLocalUtil.getClientRequest();
				locale = request.getLocale();
				if(locale == null) {
					locale = Locale.ENGLISH;
				}
			}
			format.locale(locale);
		}
		format.scalingFactor(formatting.getScalingFactor());
		return format;
	}
	
	private class PatternRule {
		private boolean notRule = false;
		private Map<String, Set<String>> keyValuesMap;
		private NumberUtils.Format format;
		private DataStructureBean dsd;
		
		/**
		 * @param dsd nullable - if provided, the series key must be for the DSD provided in order to match
		 * @param notRule - if true then the key values indicate what the key must NOT contain in order for the pattern to match
		 * @param keyValuesMap - component ids to values
		 * @param format - the formatting rules to apply to the observation value
		 */
		public PatternRule(DataStructureBean dsd, boolean notRule, Map<String, Set<String>> keyValuesMap, Format format) {
			this.dsd = dsd;
			this.notRule = notRule;
			this.keyValuesMap = keyValuesMap;
			this.format = format;
		}



		private boolean ruleMatch(Observation obs) {
			DataStructureBean obsDSD = obs.getSeriesKey().getDataStructure();
			if(obsDSD == null) {
				return false;
			}
			if(dsd != null && !dsd.equals(obsDSD)) {
				return false;
			}
			for(String dimId : keyValuesMap.keySet()) {
				ComponentBean comp = obs.getSeriesKey().getDataStructure().getComponent(dimId);
				if(comp  != null) {
					String reportedValue = obs.getSeriesKey().getReportedValue(dimId);
					if(reportedValue == null || !keyValuesMap.get(dimId).contains(reportedValue)) {
						return notRule ? true  : false;
					}
				} else {
					return notRule ? true  : false;
				}
			}
			return notRule ? false  : true;
		}
	}
}
