package io.sdmx.core.data.model.io;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.utils.core.io.CSVReadableDataLocation;

public class CSVDataReadableDataLocation extends CSVReadableDataLocation {
	private static final long serialVersionUID = 1L;
	private IDatasetStructures structures;

	public CSVDataReadableDataLocation(ReadableDataLocation proxy, DELIMITER delimiter, int startRow, IDatasetStructures structures) {
		super(proxy, delimiter, startRow);
		this.structures = structures;
	}

	public IDatasetStructures getStructures() {
		return structures;
	}
}
