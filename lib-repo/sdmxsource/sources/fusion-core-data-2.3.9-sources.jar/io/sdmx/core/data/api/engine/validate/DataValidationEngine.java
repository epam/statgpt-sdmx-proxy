package io.sdmx.core.data.api.engine.validate;

import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;

/**
  * A DataValidationEngine validates the data that it is supplied with.
 */
public interface DataValidationEngine {
	
	/**
	 * Validates the supplied attribute values reporting an error if key is not valid
	 * @param key
	 */
	void validateDatasetAttributes(IDatasetAttributes datasetAttributes, DataValidationEngineErrorHandler errorHandler);

	/**
	 * Validates the supplied key reporting an error if the key is not valid
	 * @param key
	 * @return map of Component Id to list of errors for that component
	 */
	void validateKey(Keyable key, DataValidationEngineErrorHandler errorHandler);
	
	/**
	 * Validates the supplied observation reporting an error if observation is not valid
	 * @param obs
	 */
	void validateObs(Observation obs, DataValidationEngineErrorHandler errorHandler);

	/**
	 * A method that may be used to perform any handling once all the observations have been processed for a series
	 * 
	 * @param exceptionHandler
	 */
	void finishedObs(DataValidationErrorReporter exceptionHandler);
	
	/**
	 * Indicates the full dataset has been validated, close off any resources and write any final errors to the handler
	 * @param errorHandler
	 */
	void close(DataValidationErrorReporter exceptionHandler);

}
