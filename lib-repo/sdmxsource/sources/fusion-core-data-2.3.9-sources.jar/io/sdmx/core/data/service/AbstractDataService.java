package io.sdmx.core.data.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.core.data.api.manager.DataLoadManager;
import io.sdmx.core.data.api.manager.DataValidationReportManager;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.data.api.model.consolidation.ConsolidationOptions;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.validate.DataSetDetails;
import io.sdmx.core.data.model.validate.ExternalRequest;
import io.sdmx.core.data.service.builder.ExternalRequestBuilder;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SORT_ORDER;

public abstract class AbstractDataService {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractDataService.class);
	
	protected DataLoadManager dataLoadManager;
	protected ExternalRequestBuilder externalRequestBuilder;
	protected DataValidationReportManager validationReportManager;
	protected DataWriterManager dataWriterManager;
	protected HeaderRetrievalManager headerRetrievalManager;
	protected WriteableDataLocationFactory wdlFactory;
	
	public AbstractDataService(
			DataLoadManager dataLoadManager,
			ExternalRequestBuilder externalRequestBuilder,
			DataValidationReportManager validationReportManager,
			DataWriterManager dataWriterManager,
			HeaderRetrievalManager headerRetrievalManager,
			WriteableDataLocationFactory wdlFactory
			) {
		this.dataLoadManager = dataLoadManager;
		this.externalRequestBuilder = externalRequestBuilder;
		this.validationReportManager = validationReportManager;
		this.dataWriterManager = dataWriterManager;
		this.headerRetrievalManager = headerRetrievalManager;
		this.wdlFactory = wdlFactory;
	}

	protected void handleError(ExternalRequest request, IResponse response, Throwable th) {
		if(request != null) {
			if(request.getRdl() != null) {
				request.getRdl().close();
			}
		}
		int status = 400;
		if(th instanceof SdmxException) {
			status = ((SdmxException)th).getHttpRestErrorCode();
		}
		response.setStatus(status);
		response.setContentType("application/json");
		validationReportManager.writeValidationReport(th, response.getOutputStream());
	}
	
	protected DataSetDetails getDataSetDetails(ExternalRequest request) {
		LOG.info("External Request Received: " +request);
		IConsolidationOptions consolidationOptions = new ConsolidationOptions(request.getDuplicateBehaviour(), SORT_ORDER.NATURAL);
		DataSetDetails details = dataLoadManager.getDatasetDetails(null, request.getRdl(), request.getFromStructure(), request.isPriorDataDependent(), request.isMergeDatasets(), consolidationOptions, request.isSkipValidation());

		if (request.isSkipValidation()) {
			LOG.info("Skipping Validation");
		} else if(ObjectUtil.validCollection(request.getValidateStructures())) {
			LOG.info("Validating");
			details.validateData(request.getValidateStructures(), false);
		}
		return details;
	}
	
}
