package io.sdmx.core.data.api.manager;

import java.io.OutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

public interface FileQueryManager {

	/**
	 * Loads the file in at the given fileLocation and writes out the data that matches
	 * the query parameters - the output format is the same format as the file is in
	 * @param dataLocation
	 * @param dataQuery
	 * @param out
	 */
	void runQuery(ReadableDataLocation dataLocation, DataQuery dataQuery, OutputStream out);

	/**
	 * Loads the file in at the given fileLocation and returns a DataReaderEngine that
	 * when queried will return results determined by the query parameters.
	 * @param dataLocation
	 * @param dataQuery
	 * @return
	 */
	DataReaderEngine runQuery(ReadableDataLocation dataLocation, DataQuery dataQuery);
	
	/**
	 * Loads the file in at the given fileLocation and returns a DataReaderEngine that
	 * when queried will return results determined by the query parameters.
	 * @param dataLocation
	 * @param dataQuery
	 * @return
	 */
	DataReaderEngine runQuery(ReadableDataLocation dataLocation, DataQuery dataQuery, DataValidationErrorHandler exceptionHandler);
}
