package io.sdmx.core.data.factory.reader;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.data.engine.writer.MVStoreDataWriterEngine;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreAbstractDatasetStorage;
import io.sdmx.core.data.model.io.MVTemporaryDataReadableDataLocation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.engine.data.DatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.error.DataErrorCategory;

public class MVStoreDataReaderFactory implements DataReaderFactory {

	@Override
	public DataReaderEngine getDataReaderEngine(DataFormat format, 
			ReadableDataLocation sourceData, 
			DataStructureBean dsd, 
			DataflowBean dataflowBean, 
			ProvisionAgreementBean provisionAgreement,
			DataValidationErrorHandler exceptionHandler) {
		return getDataReaderEngine(sourceData);
	}

	@Override
	public DataReaderEngine getDataReaderEngine(DataFormat format, ReadableDataLocation sourceData, SdmxBeanRetrievalManager retrievalManager, 
			DataValidationErrorHandler exceptionHandler) {
		return getDataReaderEngine(sourceData);
	}


	private DataReaderEngine getDataReaderEngine(ReadableDataLocation rdl) {
		if(rdl instanceof MVTemporaryDataReadableDataLocation) {
			MVTemporaryDataReadableDataLocation tRdl = (MVTemporaryDataReadableDataLocation) rdl;
			MVStoreDataWriterEngine mvStoreDataWriterEngine = tRdl.getWriterEngine();
			MVStoreAbstractDatasetStorage storage = mvStoreDataWriterEngine.getStorage();
			return new DatasetStoreDataReaderEngine(storage);
		}
		return null;
	}

	@Override
	public String getOverride() {
		return null;
	}

	@Override
	public List<DataErrorCategory> getThrowableErrors() {
		return Collections.emptyList();
	}

	@Override
	public String getId() {
		return "MVStoreDataReaderFactory";
	}

	@Override
	public String getName() {
		return "MVStoreDataReaderFactory";
	}

}
