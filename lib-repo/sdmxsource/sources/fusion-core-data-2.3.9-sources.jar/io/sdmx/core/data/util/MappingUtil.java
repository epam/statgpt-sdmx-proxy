package io.sdmx.core.data.util;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.utils.core.collection.CollectionUtil;

public class MappingUtil {
	private  static final String REQUIRED = "REQUIRED";
	private static boolean outputRequired = false;
	
	public static void setOutputRequired(boolean outputRequired) {
		MappingUtil.outputRequired = outputRequired;
	}
	
	public static boolean isOutputRequired() {
		return MappingUtil.outputRequired;
	}
	
	/**
	 * A required mapping is one which fails if the mapping was used but there was no content output (a null).
	 * 
	 * A mapping to a Dimension is always required because with no Dimension value there can be no mapped output, however a mapping to
	 * an Attribute is open to interpretation.
	 * 
	 * @param componentMap to check if required
	 * @param targetDimensionIds - dimensions ID (including the Time Dimensions) of the target DSD
	 * @return true if the mapping is to a Dimension, or if the global 'output required' is true or if the StructureMap has an annotation with ID of REQUIRED
	 */
	public static boolean isOutputRequired(ITimeComponentMapBean componentMap, Set<String> targetDimensionIds) {
		if(isOutputRequired(componentMap)) {
			return true;
		}
		if (componentMap == null) {
			return false;
		}
		String targetComponent = componentMap.getTargetComponent();
		return targetDimensionIds.contains(targetComponent);
	}
	

	/**
	 * A required mapping is one which fails if the mapping was used but there was no content output (a null).
	 * 
	 * A mapping to a Dimension is always required because with no Dimension value there can be no mapped output, however a mapping to
	 * an Attribute is open to interpretation.
	 * 
	 * @param componentMap to check if required
	 * @param targetDimensionIds - dimensions ID (including the Time Dimensions) of the target DSD
	 * @return true if the mapping is to a Dimension, or if the global 'output required' is true or if the StructureMap has an annotation with ID of REQUIRED
	 */
	public static boolean isOutputRequired(IComponentMapBean componentMap, Set<String> targetDimensionIds) {
		if(isOutputRequired(componentMap)) {
			return true;
		}
		if (componentMap == null) {
			return false;
		}
		List<String> targetComponentIds = componentMap.getTargetComponents();
		return CollectionUtil.containsAny(targetDimensionIds, targetComponentIds);
	}

	
	private static boolean isOutputRequired(SDMXBean componentMap) {
		if(outputRequired) {
			return true;
		}
		if(componentMap != null) {
			IStructureMapBean parentMap = componentMap.getParent(IStructureMapBean.class, true);
			return isOutputRequired(parentMap.getAnnotations());
		}
		return false;
	}
	
	private static boolean isOutputRequired(List<AnnotationBean> annotations) {
		for(AnnotationBean annotation : annotations) {
			if(annotation.getId() != null &&  annotation.getId().equals(MappingUtil.REQUIRED)) {
				return true;
			}
		}
		return false;
	}
}
