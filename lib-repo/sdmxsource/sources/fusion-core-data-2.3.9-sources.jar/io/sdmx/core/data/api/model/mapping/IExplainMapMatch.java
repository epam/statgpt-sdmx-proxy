package io.sdmx.core.data.api.model.mapping;

import java.util.List;

/**
 * Explains a mapping match in terms of input, mapped output, and the mapping rule that was fired
 */
public interface IExplainMapMatch {

	/**
	 * Describes the ways a mapping can be derived from an input
	 * <ol>
	 *  <li>implicit: the source value is carried over to target with no mapping involved</li>
	 *  <li>equals: the source value matches a mapping value</li>
	 *  <li>regex: the source value matches a regular expression</li>
	 *  <li>time pattern: the source value matches a time pattern</li>
	 *  <li>time epoch: the source value is a numerical representation of time</li>
	 * </ol>
	 * 
	 * Note, the equals and regex are applied after any substring rules
	 */
	enum MAP_RULE_TYPE {
		IMPLICIT,
		EQUALS,
		REG_EX,
		TIME_PATTERN,
		TIME_EPOCH
	}
	
	/**
	 * @return the map rule type used for this match
	 */
	MAP_RULE_TYPE getRuleType();
	
	/**
	 * @return the component that matched
	 */
	String getComponent();
	
	/**
	 * @return the input to the rule, after the application of substring rules (if any)
	 */
	String getInput();
	
	/**
	 * @return if the rule is RegEx this returns the regex, if it is time pattern, this will return the pattern used, otherwise null will be returned
	 */
	String getMatch();
	
	/**
	 * @return the values used for capture groups, if any capture groups were defined in the rule
	 */
	List<String> getCaptureGroups();
	
	/**
	 * @return the start index of the input string to use (-1 to indicate no substring start rule was used)
	 */
	int getSubstringStart(); 
	
	/**
	 * @return the end index of the input string to use (-1 to indicate no substring start rule was used)
	 */
	int getSubstringEnd(); 
	
}
