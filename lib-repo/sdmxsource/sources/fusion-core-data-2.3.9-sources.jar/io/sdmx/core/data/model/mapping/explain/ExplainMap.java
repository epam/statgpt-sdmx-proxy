package io.sdmx.core.data.model.mapping.explain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.data.api.model.mapping.IExplainMap;
import io.sdmx.core.data.api.model.mapping.IExplainMapOutputRow;
import io.sdmx.core.data.api.model.mapping.MappingRules;

/**
 */
public class ExplainMap implements IExplainMap {
	private IDataRow input;
	private MappingRules mappingRules;
	private List<IExplainMapOutputRow> outputRow = new ArrayList<>();
	
	public ExplainMap(MappingRules rules, IDataRow inputValues) {
		this.input = inputValues;
		this.mappingRules = rules;
	}

	@Override
	public MappingRules getMappingRules() {
		return mappingRules;
	}

	@Override
	public IDataRow getInput() {
		return input;
	}

	@Override
	public List<IExplainMapOutputRow> getOutputRows() {
		return Collections.unmodifiableList(outputRow);
	}
	
	public ExplainMapOutputRow addOutputRow() {
		ExplainMapOutputRow row = new ExplainMapOutputRow();
		outputRow.add(row);
		return row;
	}
}
