package io.sdmx.core.data.api.model.transform;

import java.io.OutputStream;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.data.DataFormat;

public interface DataTransformationOptions {

	/**
	 * @return the output format
	 */
	DataFormat getOutputDataFormat();

	/**
	 * If this is a multipart or zip output stream, starts the next section
	 * @param formatDetails defining the mime type and file extension
	 * @param fileName - without the extension
	 */
	void startPart(FormatDetails formatDetails, String fileName);
	
	/**
	 * If this is a multipart or zip output stream, starts the next section
	 * 
	 * @param contentType the format to output
	 * @param mimeType for the HTTP Header
	 * @param fileExtension file extension without the period prefix, i.e xml
	 * @param fileName file name without the file extension
	 */
	void startPart(String mimeType, String fileName, String fileExtension);

	/**
	 * @return the output stream
	 */
	OutputStream getOutputStream();

	/**
	 * Closes the stream
	 */
	void close();

	/**
	 * @return returns the dataset to transform, null indicates all datasets, zero indexed
	 */
	Integer getDatasetIndex();
	void setDatasetIndex(Integer datasetIndex);

	/**
	 * @return a reference
	 */
	IURNSingle<? extends IStructureMapRelatedBean> getMappedOutputReference();
	void setMappedOutputReference(IURNSingle<? extends IStructureMapRelatedBean> mappedOutputReference);

	/**
	 * Include a file for unmapped data
	 * @return
	 */
	boolean isIncludeUnmappedData();
	void setIncludeUnmappedData(boolean bool);

	/**
	 * Include a file of the report of the unmapped data
	 * @return
	 */
	boolean isIncludeUnmappedReport();
	void setIncludeUnmappedReport(boolean bool);
	
	/**
	 * @return optional format for unmapped data, if null the returned format is the same as the output data format
	 */
	DataFormat getIncludeUnmappedFormat();
	void setIncludeUnmappedFormat(DataFormat format);
	
	/**
	 * Include Metrics on the transformation, file format of output is as follows
	 * <pre>
	 * {
	 * 	Meta: {
	 * 		RequestTime: 123456
	 * 		Duration: 12
	 *  }
	 *  SourceData : {
	 *    Format : SDMX,
	 *    Dataflow: urn,
	 *    Series: 123
	 *    Observations: 124
	 *    Groups: 12
	 *  },
	 *  OutputData : {
	 *  	Format: CSV,
	 *  	Dataflow: urn,
	 *  	Series: 12
	 *  	Observations: 10,
	 *  	Groups: 0
	 *  }
	 *  </pre>
	 */
	boolean isIncludeMetrics();
	void setIncludeMetrics(boolean bool);

	/**
	 * Returns the output sender id,
	 * @return
	 */
	String getSenderId();
	void setSenderId(String senderId);

	/**
	 * Returns the output receiver id,
	 * @return
	 */
	String getReceiverId();
	void setReceiverId(String receiverId);

	String getDatasetId();
	void setDatasetId(String datasetId);

	DATASET_ACTION getDatasetAction();
	void setDatasetAction(DATASET_ACTION datasetAction);

	/**
	 * Specifies the highest attachment level to output, i.e. if the datasaet has a Provision Attachment but the highest attachment is seet to DSD, then only the
	 * get DSD method will return a value, getDataflow and getProvision will return null
	 * @param highestAttachment
	 */
	void setHighestAttachment(SDMX_STRUCTURE_TYPE highestAttachment);
	SDMX_STRUCTURE_TYPE getHighestAttachment();

	/**
	 * @return whether validation after a mapping should be performed
	 */
	boolean isSkipValidation();

	/**
	 * Sets whether validation should be performed after a mapping
	 */
	void setSkipValidation(boolean bool);
}
