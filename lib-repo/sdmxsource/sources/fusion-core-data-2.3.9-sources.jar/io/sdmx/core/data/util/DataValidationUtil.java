package io.sdmx.core.data.util;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorTranslatorToList;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.core.data.constant.OBS_STATUS_VALUE;
import io.sdmx.core.sdmx.error.DataValidationErrorCode;
import io.sdmx.core.sdmx.error.ErrorTranslatorToExceptionHandler;
import io.sdmx.core.sdmx.error.FirstFailureErrorHandler;
import io.sdmx.core.sdmx.util.TextFormatValidationUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.UrnUtil;

public class DataValidationUtil {
	private static final Pattern xsdID = Pattern.compile("([A-Z]|[a-z]|_)+([A-Z]|[a-z]|\\\\|[0-9]|_|\\-|\\.)*");
	private static final Pattern idWithInt = Pattern.compile("([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*");
	private static final Pattern idWithNoInt = Pattern.compile("([A-Z]|[a-z])+([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*");

	/**
	 * @param obsStatus observation status, example M
	 * @param obsValue the reported obs value, can be null
	 * @return
	 */
	public static DataValidationErrorCode isValidObsStatus(String obsStatus, String obsValue) {
		OBS_STATUS_VALUE obsStatusValue = OBS_STATUS_VALUE.getObsStatusValue(obsStatus);

		if (obsStatusValue == null) {
			// not a code mentioned in the document, do not check anything further and do not report as error
			return null;
		}

		if (obsStatusValue.isAllowNumeric() && obsStatusValue.isAllowMissing()) {
			// OBS_STATUS permits anything, so early out
			return null;
		}

		boolean isObsMissing = !ObjectUtil.validString(obsValue) || obsValue.equals("-") || obsValue.equals("NaN");
		
		if (obsStatusValue.isAllowMissing()) {
			// Report error if a real value has been specified
			if (!isObsMissing) {
				return DataValidationErrorCode.OBS_STATUS_OBS_VALUE_ILLEGAL;
			}
		}

		if (obsStatusValue.isAllowNumeric()) {
			// Report error if value is missing
			if (isObsMissing) {
				return DataValidationErrorCode.OBS_STATUS_OBS_VALUE_MISSING;
			}
		}
		return null;
	}
	
	/**
	 * Validates a reported value for a component, for example FREQ=A, OBS_VALUE=12.3
	 * @param component
	 * @param value
	 * @param errorMessages, if there are errors, it will be added to this list of error messages
	 */
	public static void validateComponentValue(ComponentSuperBean<? extends ComponentBean> component, String value, List<String> errorMessages) {
		validateComponentValue(component, value, new ErrorTranslatorToList(errorMessages));
	}

	/**
	 * When validating a component, the restriction used is that a local Codelist is used for validation over other elements.
	 * If there is no local Codelist, then the local TextFormat is used.
     * If the Local TextFormat is not present, then the Codelist from the Concept Scheme is used.
     * If that is not present, the TextFormat from the Concept is used (if present).
	 */
	public static void validateComponentValue(ComponentSuperBean<? extends ComponentBean> component, String value, DataValidationEngineErrorHandler eh) {
		EnumeratedListBean<EnumeratedItemBean> aCodelist = component.getCodelist(true);
		if (aCodelist != null) {
			validateCodeValue(aCodelist, component.getBuiltFrom(), value, eh);
		} else {
			validateTextFormat(component, value, eh);
		}
	}

	public static void validateTextFormat(ComponentSuperBean<? extends ComponentBean> componentSb, List<TextTypeWrapper> texts, DataValidationEngineErrorHandler eh) {
		for(TextTypeWrapper text: texts){
			validateTextFormat(componentSb, text.getValue(), eh);
		}
	}

	public static void validateTextFormat(ComponentSuperBean<? extends ComponentBean> componentSb, String value, List<String> errorMessages) {
		validateTextFormat(componentSb, value, new ErrorTranslatorToList(errorMessages));
	}

	public static void validateTextFormat(ComponentSuperBean<? extends ComponentBean> componentSb, String value, DataValidationEngineErrorHandler eh) {
		if(componentSb.getTextFormat() == null) {
			return;
		}
		TextFormatValidationUtil.validateTextFormat(componentSb.getTextFormat(), componentSb.getBuiltFrom(), value, eh);
	}

	public static void validateTextFormat(TextFormatBean textFormat, ComponentBean component, String value, List<String> errorMessages) {
		TextFormatValidationUtil.validateTextFormat(textFormat, component, value, new ErrorTranslatorToList(errorMessages));
	}

	private static void validateValue(ComponentSuperBean<? extends ComponentBean> component, String reportedValue,  DataValidationEngineErrorHandler eh) {
		validateComponentValue(reportedValue, component, eh);
	}

	private static void validateComponentValue(String value, ComponentSuperBean component, DataValidationEngineErrorHandler eh) {
		EnumeratedListBean<EnumeratedItemBean> codelist = component.getCodelist(true);
		if(codelist != null) {
			validateCodeValue(codelist, (ComponentBean)component.getBuiltFrom(), value, eh);
		}
	}

	public static void validateCodeValue(EnumeratedListBean<? extends EnumeratedItemBean> codelist, ComponentBean component, String value, DataValidationEngineErrorHandler eh) {
		if(!ObjectUtil.validString(value)) {
		    String componentIdentifier = component.getStructureType().getType() + " '" + component.getId() + "'";
			FusionError fe = new FusionErrorImpl(DataErrorCode.INVALID_REPRESENTATION_IN_REFERENCE, componentIdentifier, "", codelist.getStructureType().getType(), UrnUtil.getUrnPostfix(codelist.getUrn()) );
            eh.reportError(fe, getKv(value, component.getId()) );
		} else {
			if(codelist.getItemById(value) == null) {
			    String componentIdentifier = component.getStructureType().getType() + " '" + component.getId() + "'";
	            FusionError fe = new FusionErrorImpl(DataErrorCode.INVALID_REPRESENTATION_IN_REFERENCE, componentIdentifier, value, codelist.getStructureType().getType(), UrnUtil.getUrnPostfix(codelist.getUrn()) );
	            eh.reportError(fe, getKv(value, component.getId()) );
			}
		}
	}




	public static void validateTextType(List<TextTypeWrapper> textTypes, String validPatternStr) throws SdmxSemmanticException {
		validateTextType(null, textTypes, validPatternStr, new ErrorTranslatorToExceptionHandler(new FirstFailureErrorHandler()));
	}

	/**
	 * Validates that the locale in the text type is unique
	 * @param textTypes
	 * @throws SdmxSemmanticException
	 */
	public static void validateTextType(String componentId, List<TextTypeWrapper> textTypes, String validPatternStr, DataValidationEngineErrorHandler eh) throws SdmxSemmanticException {
		Pattern validPattern = null;
		if(ObjectUtil.validString(validPatternStr)) {
			validPattern = Pattern.compile(validPatternStr);
		}
		Set<String> languages = new HashSet<>();
		if(textTypes != null) {
			for(TextTypeWrapper currentTextType : textTypes) {
				if(validPattern != null) {
					if(!validPattern.matcher(currentTextType.getValue()).matches()) {
						FusionError fe = new FusionErrorImpl(DataErrorCode.VALUE_INVALUD_WITH_RESPECT_TO_PATTERN, currentTextType.getValue(), validPattern.toString());
			            eh.reportError(fe, getKv(currentTextType.getValue(), componentId));
					}
				}
				if(languages.contains(currentTextType.getLocale())) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_DUPLICATE_LANGUAGE, currentTextType.getLocale());
		            eh.reportError(fe, getKv(currentTextType.getValue(), componentId));
				}
				languages.add(currentTextType.getLocale());
			}
		}
	}

	/**
	 * Is this a valid xsd:Id type.
	 * An xsd:ID value must be an NCName. This means that it must start with a letter or underscore, and can only contain letters, digits,
	 * underscores, hyphens, and periods.
	 *
	 * @param id
	 * @return
	 */
	public static boolean isValidXsdId(String id) {
		if(!ObjectUtil.validString(id)) {
			return false;
		}
		return xsdID.matcher(id).matches();
	}


	/**
	 * Trims the leading and trailing whitespace from the specified id
	 * <p>
	 * Validates that the id starts with an alpha character (or alpha numeric if startWithIntAllowed is true).
	 *
	 * The id may that also contains one or more of the following:
	 * <ul>
	 *   <li>alphabetics in either case</li>
	 *   <li>a 'star' symbol (*)</li>
	 *   <li>an 'at' symbol (@)</li>
	 *   <li>integers (0-9)<li>
	 *   <li>an underscore (_)</li>
	 *   <li>a dollar ($)</li>
	 *   <li>a dash (-)</li>
	 * </ul>
	 * @param id The string to
	 * @param startWithIntAllowed Determines whether an integer is allowed to be the first character of the string
	 * @throws SdmxSemmanticException if the string id not valid - empty strings or null strings are not validated
	 */
	public static String cleanAndValidateId(String id, boolean startWithIntAllowed) throws SdmxSemmanticException {
		if (!ObjectUtil.validString(id)) {
			return null;
		}

		String trimedId = id.trim();
		if(!isValidId(trimedId, startWithIntAllowed)) {
			if(startWithIntAllowed) {
				throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_INVALID_ID, trimedId);
			}
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_INVALID_ID_START_ALPHA, trimedId);
		}
		return trimedId;
	}

	public static boolean isValidId(String id, boolean startWithIntAllowed) {
		if (!ObjectUtil.validString(id)) {
			return false;
		}

		String trimedId = id.trim();
		Pattern idPattern;

		if(startWithIntAllowed) {
			idPattern = idWithInt;
		} else {
			idPattern = idWithNoInt;
		}
		if(!idPattern.matcher(trimedId).matches()) {
			return false;
		}
		return true;
	}
	
	private static KeyValue getKv(String code, String concept) {
		return KeyValueImpl.getInstance(concept, code);
	}

}
