package io.sdmx.core.data.model.mapping.value;

import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Explicit rule used when all values are explicit (no substrings, no patterns)
 */
public class ExplicitMappingRule {
	private String[] value;

	public ExplicitMappingRule(String[] value) {
		this.value = value;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ExplicitMappingRule) {
			return ObjectUtil.equivalentArray(value, ((ExplicitMappingRule) obj).value);
		} 
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(String currentValue : value) {
			sb.append(currentValue+"-");
		}
		return sb.toString();
	}
}