package io.sdmx.core.data.api.model.dataset;

import java.util.Set;

import io.sdmx.api.collection.KeyValue;

public interface SeriesKeyValue extends KeyValue {
	/**
	 * Adds a series key that this KeyValue Belongs to
	 * @param dataKey
	 */
	void addSeriesKey(SeriesKey dataKey);
	
	
	/**
	 * Returns the series key's that this key values belongs to
	 * @return
	 */
	Set<SeriesKey> getSeriesKeys();
	
	/**
	 * Returns a copy
	 * @return
	 */
	SeriesKeyValue createCopy();
}
