package io.sdmx.core.data.util;

import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataHeaderUtil {

	/**
	 * Compares two headers, with the exception of the ID of the DatasetStructureReferenceBean
	 * @param one
	 * @param two
	 * @return
	 */
	public static boolean isHeaderEqual(DatasetHeaderBean one, DatasetHeaderBean two) {
		if(one == null && two == null) {
			return true;
		}
		if(one == null && two != null) {
			return false;
		}
		if(two== null && one != null) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getAction(), two.getAction())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getDataProviderReference(), two.getDataProviderReference())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getDatasetId(), two.getDatasetId())) {
			return false;
		}
		if(!isHeaderEqual(one.getDataStructureReference(), two.getDataStructureReference())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getPublicationPeriod(), two.getPublicationPeriod())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getPublicationYear(), two.getPublicationYear())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getReportingBeginDate(), two.getReportingBeginDate())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getReportingEndDate(), two.getReportingEndDate())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getValidFrom(), two.getValidFrom())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getValidTo(), two.getValidTo())) {
			return false;
		}
		return true;
	}

	/**
	 * Checks everything but the id
	 * @return
	 */
	public static boolean isHeaderEqual(DatasetStructureReferenceBean one, DatasetStructureReferenceBean two) {
		if(one == null && two == null) {
			return true;
		}
		if(one == null && two != null) {
			return false;
		}
		if(two== null && one != null) {
			return false;
		}
		if(one.isTimeSeries() != two.isTimeSeries()) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getStructureReference(), two.getStructureReference())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getServiceURL(), two.getServiceURL())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getStructureURL(), two.getStructureURL())) {
			return false;
		}
		if(!ObjectUtil.equivalent(one.getDimensionAtObservation(), two.getDimensionAtObservation())) {
			return false;
		}
		return true;
	}
}
