package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;
import org.h2.mvstore.type.ObjectDataType;

import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Serialization for DatasetStructureReferenceBean.
 */
public class DT_DatasetStructureReferenceBean
                         extends BasicDataType<DatasetStructureReferenceBean> {
  private final DT_String strDT = DT_String.getInstance();

  @Override
  public int getMemory(DatasetStructureReferenceBean x) {
    int size = 1; // null/object selector

    if (x != null) {
      size += strDT.getMemory(x.getId());
      size += strDT.getMemory(x.getStructureReference().getURN()); 
      size += strDT.getMemory(x.getServiceURL());
      size += strDT.getMemory(x.getStructureURL());
      size += strDT.getMemory(x.getDimensionAtObservation());
    }

    return size;
  }

  @Override
  public void write(WriteBuffer buf, DatasetStructureReferenceBean x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      strDT.write(buf, x.getId());
      strDT.write(buf, x.getStructureReference().getURN());
      strDT.write(buf, x.getServiceURL());
      strDT.write(buf, x.getStructureURL());
      strDT.write(buf, x.getDimensionAtObservation());
    }
  }

  @Override
  public DatasetStructureReferenceBean read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    DatasetStructureReferenceBean x = null;

    if (!isNull) {
      String id = strDT.read(buf);
      String structureReference = strDT.read(buf);
      String serviceURL = strDT.read(buf);
      String structureURL = strDT.read(buf);
      String dimensionAtObservation = strDT.read(buf);

      x = new DatasetStructureReferenceBeanImpl(id,
                                                URN.builder(structureReference).buildSingle(IDSDRelatedBean.class),
                                                serviceURL,
                                                structureURL,
                                                dimensionAtObservation);
    }

    return x;
  }

  @Override
  public DatasetStructureReferenceBean[] createStorage(int size) {
    return new DatasetStructureReferenceBean[size];
  }
}
