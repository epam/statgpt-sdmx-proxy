package io.sdmx.core.data.api.manager;

import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeoutException;

import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;

/**
 * Responsible for managing data loaded for validation, and transformation purposes
 */
public interface DataLoadManager extends FusionValidationManager {

	/**
	 * Maps the DatasetDetails with the given UID to the structuremap or removes the mapping if the structuremap is null
	 * @param datasetIdx the index of the dataset to apply the map to
	 * @param mapTo the DSD or Dataflow to map to
	 * @param uid the unique identifier of the dataset
	 * @param async if true then the mapping will take place in a new Thread
	 */
	void setMappedStructure(int datasetIdx, IURNSingle<? extends IStructureMapRelatedBean> mapTo, String uid, boolean async) throws TimeoutException, SdmxUnauthorisedException;


	/**
	 * Writes a validation report for the dataset obtained from the given UID
	 * @param uid the unique identifier of the dataset
	 * @param out
	 */
	void writeValidationReport(String uid, OutputStream out);

	/**
	 * Re-validates all the datasets in the dataset obtained from the UID
	 *
	 * @param uid the UID of the dataset to apply the
	 * @param sRef a list of structure references to use, the list is in order of dataset, so if the Dataset details has 3 datasets, the list should be of size 3
	 * @param out
	 */
	void revalidate(String uid, List<IURNSingle<? extends IDSDRelatedBean>> sRefs, boolean asyncronous, OutputStream out) throws SdmxUnauthorisedException, TimeoutException;

	/**
	 * Obtains the DatasetDetails in an asynchronous manner.
	 * @param dataFilename
	 * @param rdl
	 * @param strRef
	 * @return The UID of the dataset details
	 */
	String getAsyncDatasetDetails(String dataFilename, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> strRef);

	/**
     * Obtains the DatasetDetails from a URL in an asynchronous manner.
	 * @param url
	 * @param rdl
	 * @param strRef
	 * @return The UID of the dataset details
	 */
	String getAsyncDatasetDetails(URL url, ReadableDataLocation rdl, IURNSingle<? extends IDSDRelatedBean> strRef);

	/**
	 * Close a dataset and tidy up resources
	 * @param uid
	 */
	void close(String uid);
}
