package io.sdmx.core.data.api.manager;

import java.util.List;
import java.util.Map;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.data.model.DataInformation;

/**
 * The purpose of the data information manager is to get metadata off the dataset.
 */
public interface DataInformationManager {

	/**
	 * Returns DataInformation about the data, this processes the entire dataset to give an overview of what is in the dataset.
	 * <p/>
	 * @return
	 */
	DataInformation getDataInformation(DataReaderEngine dre);
	
	/**
	 * Returns an ordered list of all the unique dates for each time format in the dataset.  
	 * <p/>
	 * This list is ordered with the earliest date first.
	 * <p/>
	 * This method will call <code>reset()</code> on the dataReaderEngine before and after the 
	 * information has been gathered 
	 * 
	 * @return a map of time format to the list of dates that are contained for the time format
	 */
	Map<TIME_FORMAT, List<String>> getAllReportedDates(DataReaderEngine dataReaderEngine);
	
	/**
	 * Returns a list of dimension - value pairs where there is only a single value in the data for the dimension.  For example if the entire
	 * dataset had FREQ=A then one of the returned KeyValue pairs would be FREQ,A.  If FREQ=A and Q this would not be returned.
	 * <p/>
	 * <strong>Note : an initial call to DataReaderEngine.reset will be made</strong>
	 * @param dre
	 * @param includeAttributes if true will also report the attributes that have only one value in the entire dataset
	 * @return
	 */
	Map<String, String> getFixedConcepts(DataReaderEngine dre, boolean includeDimensions, boolean includeObs, boolean includeSeriesAttributes);
}
