package io.sdmx.core.data.model.dataset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.h2.mvstore.MVMap;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;
import io.sdmx.core.sdmx.model.type.DT_Map;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.core.sdmx.util.MVStoreUtil;
import io.sdmx.utils.core.object.SeriesUtil;

public class GroupAttributeValues implements AutoCloseable {
  //an array of key index to eliminate in order to build the group short code
    //For example A:UK:EMP could be re-written as :UK:EMP if the A (Frequency) is not part of the group
    private List<Integer> eliminateValues = new ArrayList<>();  //Dimensions not used in group

    //A map of group short code to attributes
    private MVMap<String, Map<String, String>> shortCodeToAttributes;

    private IMVStore mvStore = MVStoreUtil.getStore();
    
    public GroupAttributeValues(GroupBean group) {
        DT_String strDt = DT_String.getInstance();
        shortCodeToAttributes =  MVStoreUtil.openMap("shortCodeToAttributes", 0, strDt, new DT_Map<String, String>(strDt, strDt), mvStore);
        DataStructureBean dsd = (DataStructureBean)group.getMaintainableParent();

        for(DimensionBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
            if(!group.getDimensionRefs().contains(dim.getId())) {
                eliminateValues.add(dim.getPosition()-1);
            }
        }
    }

    /**
     * @param shortCode
     * @return attributes that have been reported against the series (via a matched group) or null if none have
     */
    public Map<String, String> getMatchedAttributes(String shortCode) {
        String[] shortCodeSplit = SeriesUtil.splitKey(shortCode);
        for(Integer i : eliminateValues) {
            shortCodeSplit[i] = "";
        }
        String groupKey = SeriesUtil.toSeriesKey(shortCodeSplit);
        return shortCodeToAttributes.get(groupKey);
    }

    public void registerAttributeValue(String groupShortCode, String attributeId, String attributeValue) {
        Map<String, String> mapped = shortCodeToAttributes.get(groupShortCode);
        if(mapped == null) {
            mapped = new HashMap<>();
            shortCodeToAttributes.put(groupShortCode, mapped);
        }
        mapped.put(attributeId, attributeValue);
    }
    
    @Override
    public void close() {
        mvStore.close();
    }
}
