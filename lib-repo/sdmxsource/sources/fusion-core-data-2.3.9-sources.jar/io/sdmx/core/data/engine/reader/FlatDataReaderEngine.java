package io.sdmx.core.data.engine.reader;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.csv.CSVColumnReaderEngineImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

/**
 * Converts a 'flat' view of data, read in using a ColumnReaderEngine into a series / obs grouping which conforms to the DataReaderEngine.
 * <p/>
 * The grouping is derived using the information from the DataStructureDefinition.
 * <p/>
 * Multiple measures are supported as multiple observations in the same series, each measure can have its own attributes associated with it based on the attribute attachment from the DSD
 * <p/>
 * Each Observation will have a time period related to it if the DSD has a Time Dimension
 */
public class FlatDataReaderEngine implements DataReaderEngine {

	private HeaderRetrievalManager headerRetrievalManager;

	private HeaderBeanImpl header;

	//GLOBAL UNCHANGED DETAILS
	private ColumnReaderEngine columnReaderEngine;
	private DataStructureBean dsd;
	private DataflowBean dataflow;
	private ProvisionAgreementBean provision;

	//DSD STATE - GLOBAL UNCHANGED
	private int[] dimensionPositions; //A list of pointers to the row array of where the dimensions are
	private String[] dimensions;

	private String[] seriesAttr;
	private int[] seriesAttrPositions;

	private String[] measures;
	private int[] measuresPositions;

	private String[] measureAttr;
	private int[] measureAttrPositions;

	private int timePosition = -1;

	
	private boolean movedDataset;
	private boolean hasMeasures;

	//CURRENT DATA STATE
	private List<KeyValue> datasetAttributes = null;
	private String currentSeriesShortCode = null; //Example A:UK:EMP
	private Keyable currentKey;
	private Observation currentObs;
	private boolean endOfDataset = false;
	private boolean readObsRow = false;

	//META STATE
	private int keyPosition = -1;
	private int obsPosition = -1;
	private int dsPosition = -1;

	//RAW STATE FROM COLUMN READER
	private List<String> currentRow;
	private int currentRowSize;

	private DatasetHeaderBean datasetHeaderBean;

	public FlatDataReaderEngine(CSVDataReadableDataLocation csvData, IDatasetStructures structures) {
	    this.dsd = structures.getDataStructure();
        this.dataflow = structures.getDataflow();
        this.provision = structures.getProvisionAgreement();
        columnReaderEngine = createColumnReaderEngine(csvData);
        build(columnReaderEngine);
	}

	public FlatDataReaderEngine(CSVDataReadableDataLocation csvData, DataStructureBean dsd, DataflowBean dataflow, ProvisionAgreementBean provision) {
		this.dsd = dsd;
		this.dataflow = dataflow;
		this.provision = provision;
		columnReaderEngine = createColumnReaderEngine(csvData);
		build(columnReaderEngine);
	}

	public FlatDataReaderEngine(ColumnReaderEngine colReaderEngine, DataStructureBean dsd, DataflowBean dataflow, ProvisionAgreementBean provision) {
	    this.dsd = dsd;
        this.dataflow = dataflow;
        this.provision = provision;
        build(colReaderEngine);
	}

	private ColumnReaderEngine createColumnReaderEngine(CSVDataReadableDataLocation csvData) {
	    // If the source file has a header use it, otherwise use the default order
	    String firstBit = obtainFirstPartOfFile(csvData.getInputStream());
	    String[] splitLine = firstBit.split(""+csvData.getDelimiter().getDelimiter());

	    List<String> compPositions = analyseFirstLine(splitLine);
	    int startRow = 0;
	    if (compPositions == null) {
	        compPositions = useDefaultOrder(dsd);
	    } else {
	        // Skip the header
	        startRow++;
	    }

        ColumnReaderEngine colReader = new CSVColumnReaderEngineImpl(csvData, csvData.getDelimiter(), compPositions, startRow);
        return colReader;
	}

	// Analyse the first row to determine if it is a header row
	private List<String> analyseFirstLine(String[] splitLine) {
        Set<String> allElementsInHeader = new HashSet<>(Arrays.asList(splitLine));
        Set<String> dimensionIds = dsd.getDimensions().stream().map(e -> e.getId()).collect(Collectors.toSet());
        Set<String> measureIds = dsd.getMeasures().stream().map(e -> e.getId()).collect(Collectors.toSet());
        dimensionIds.addAll(measureIds);

        if (!allElementsInHeader.containsAll(dimensionIds)) {
            return null;
        }

        // The header line contains all of the dimensions and the measure(s) - it may also contain attributes and potentially junk.  Analyse the line to identify the parts we need

        // Add the attributes to the Set of "dimensions"
        Set<String> attributeIds = dsd.getAttributes().stream().map(e -> e.getId()).collect(Collectors.toSet());
        dimensionIds.addAll(attributeIds);

        List<String> compPositions = new ArrayList<>();
        for (int i=0; i < splitLine.length; i++) {
            String val = splitLine[i];
            if (dimensionIds.contains(val)) {
                compPositions.add(val);
            } else {
                compPositions.add(null);
            }
        }

        return compPositions;
    }

    private void build(ColumnReaderEngine colReader) {
	    if (colReader == null) {
	        throw new IllegalArgumentException("Unable to construct a FlatDataReaderEngine since the colReader supplied was null");
        }
	    headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);
        this.columnReaderEngine = colReader;

		IDSDRelatedBean masterMaint = provision != null ? provision : dataflow != null ? dataflow : dsd;

		//If there is at least ONE measure and a Time Dimension, then Time is at the observation level
		String dimenisonAtObservation = dsd.getTimeDimension() != null && dsd.getMeasureList() != null ? DimensionBean.TIME_DIMENSION_FIXED_ID : DatasetStructureReferenceBean.ALL_DIMENSIONS;
		DatasetStructureReferenceBean dStrucRef = new DatasetStructureReferenceBeanImpl(null, masterMaint.getURN(), null, null, dimenisonAtObservation);
		datasetHeaderBean = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.INFORMATION, dStrucRef);


		List<String> rowHeaders = columnReaderEngine.readHeader();
		SDMX_STRUCTURE_TYPE[] seriesDimensions = dsd.getMeasureList() == null ? new SDMX_STRUCTURE_TYPE[2] : new SDMX_STRUCTURE_TYPE[1];
		seriesDimensions[0] = SDMX_STRUCTURE_TYPE.DIMENSION;
		if(seriesDimensions.length > 1) {
			seriesDimensions[1] = SDMX_STRUCTURE_TYPE.TIME_DIMENSION;
		}
		ArrayHolder arr = new ArrayHolder(dsd.getDimensions(seriesDimensions), rowHeaders);
		this.dimensions = arr.strArr;
		this.dimensionPositions = arr.intArr;

		arr = new ArrayHolder(dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID), rowHeaders);
		this.seriesAttr = arr.strArr;
		this.seriesAttrPositions = arr.intArr;

		hasMeasures = dsd.getMeasureList() != null && ObjectUtil.validCollection(dsd.getMeasureList().getMeasures());
		if(hasMeasures) {
			arr = new ArrayHolder(dsd.getMeasureList().getMeasures(), rowHeaders);
			this.measures = arr.strArr;
			this.measuresPositions = arr.intArr;
			this.hasMeasures = this.measures.length > 0;
			
			arr = new ArrayHolder(dsd.getObservationAttributes(), rowHeaders);
			this.measureAttr = arr.strArr;
			this.measureAttrPositions = arr.intArr;
			
			timePosition = rowHeaders.indexOf(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
		if(this.dimensions.length == 0) {
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(DimensionBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
				sb.append(concat + dim.getId());
				concat = ", ";
			}
			throw new SdmxSemmanticException("Can not read CSV Data - Header Row does not contain any Columns names that match DSD Dimensions: " + sb.toString());
		}
		// Construct a Message Header Bean
		if(headerRetrievalManager != null) {
			header = (HeaderBeanImpl)headerRetrievalManager.getHeader();
		} else {
			String senderId = "unknown";
			header = new HeaderBeanImpl(senderId);
		}
	}

    private String obtainFirstPartOfFile(InputStream inputStream) {
        // FR-4770 Note: this is a temporary fix - the first 'X' characters needs to be obtained in a more comprehensive manner
        byte[] firstBytes = StreamUtil.getFirstXBytesUpToCRLF(inputStream, 2000);
        return StringUtil.stripBOM(firstBytes);
    }

	private List<String> useDefaultOrder(DataStructureBean dsd) {
        List<String> components = new ArrayList<>();

        for(DimensionBean dimension : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
            components.add(dimension.getId());
        }
        for(AttributeBean attribute : dsd.getDatasetAttributes()) {
            components.add(attribute.getId());
        }
        for(AttributeBean attribute : dsd.getSeriesAttributes(null)) {
            components.add(attribute.getId());
        }
        for(AttributeBean attribute : dsd.getObservationAttributes(null)) {
            components.add(attribute.getId());
        }
        for(MeasureDimensionBean measure : dsd.getMeasures()) {
            components.add(measure.getId());
        }
        return components;
    }

	/**
	 * Holds the array of components by Id, and the position of where they are in the columnar data
	 */
	private class ArrayHolder {
		private String[] strArr;
		private int[] intArr;

		public ArrayHolder(List<? extends ComponentBean> components, List<String> rowHeaders) {
			this.strArr = new String[components.size()];
			this.intArr= new int[components.size()];
			int i = 0;
			int negCount = 0;
			for(ComponentBean dim : components) {
				int idx = rowHeaders.indexOf(dim.getId());
				this.strArr[i] = dim.getId();
				this.intArr[i] = idx;
				if(idx < 0) {
					negCount++;
				}
				i++;
			}
			//Remove any array items if the component was not described in the header
			if(negCount > 0) {
				int newCount = strArr.length - negCount;
				String[] strArr = new String[newCount];
				int[] intArr= new int[newCount];
				i = 0;
				int j =0;
				for(String str : this.strArr) {
					int pos = this.intArr[j];
					j++;
					if(pos < 0) {
						continue;
					}
					strArr[i] = str;
					intArr[i] = pos;
					i++;
				}
				this.strArr = strArr;
				this.intArr = intArr;
			}
		}
	}

	@Override
	public FormatDetails getFormatDetails() {
		return columnReaderEngine.getFormatDetails();
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return provision;
	}

	@Override
	public DataflowBean getDataFlow() {
		return dataflow;
	}

	@Override
	public DataStructureBean getDataStructure() {
		return dsd;
	}

	@Override
	public int getDatasetPosition() {
		return dsPosition;
	}

	@Override
	public int getKeyablePosition() {
		return keyPosition;
	}

	@Override
	public int getObsPosition() {
		return obsPosition;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		if(!movedDataset) {
			dsPosition++;
			movedDataset = true;
			return true;
		}
		return false;
	}

	@Override
	public HeaderBean getHeader() {
		return header;
	}

	@Override
	public DataReaderEngine createCopy() {
		return new FlatDataReaderEngine(columnReaderEngine.copy(), dsd, dataflow, provision);
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return datasetHeaderBean;
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		if(datasetAttributes == null) {
			datasetAttributes = new ArrayList<>();
			if(ObjectUtil.validCollection(dsd.getDatasetAttributes())) {
				if(currentRow == null) {
					moveNextRow();
				}
				if(currentRow != null) {
					for(AttributeBean attr : this.dsd.getDatasetAttributes()) {
						List<String> rowHeaders = columnReaderEngine.readHeader();
						int idx = rowHeaders.indexOf(attr.getId());
						if(idx >=0) {
							String value = getRowValue(idx);
							if(value != null) {
								datasetAttributes.add(KeyValueImpl.getInstance(attr.getId(), value));
							}
						}
					}
				}
			}
			datasetAttributes = Collections.unmodifiableList(datasetAttributes);
		}
		return new DatasetAttributes(datasetAttributes);
	}


	@Override
	public Keyable getCurrentKey() {
		if(currentRow == null) {
			return null;
		}
		if(currentKey == null) {
			List<KeyValue> key = new ArrayList<>();
			List<KeyValue> attributes = new ArrayList<>();
			for(int i=0; i < dimensions.length; i++) {
				String reportedValue = getRowValue(dimensionPositions[i]);
				if(reportedValue != null) {
					key.add(KeyValueImpl.getInstance(dimensions[i], reportedValue));
				}
			}
			for(int i=0; i < seriesAttr.length; i++) {
				String reportedValue = getRowValue(seriesAttrPositions[i]);
				if(ObjectUtil.validString(reportedValue)) {
					attributes.add(KeyValueImpl.getInstance(seriesAttr[i], reportedValue));
				}
			}
			this.currentKey = KeyableImpl.seriesKey(dataflow, dsd, key, attributes);
		}
		return currentKey;
	}

	@Override
	/**
	 * If the reader has not read any rows yet, or if there are no measures defined by the DSD, returns null.
	 * <p/>
	 * If the observation has already been built, returns it, otherwise lazy load
	 * <p/>
	 * Gets the measure dimension and value from the measure that the moveNextObservation moved to, gets the associated observation attributes, and time value
	 * and builds the observation before returning it
	 */
	public Observation getCurrentObservation() {
		if(!hasMeasures || currentRow == null) {
			return null;
		}
		if(currentObs == null) {
			List<KeyValue> measureValues = new ArrayList<>();

			for(int i=0; i < measures.length; i++) {
				String measureDimension = this.measures[i];
				String measureValue = getRowValue(this.measuresPositions[i]);
				if(measureValue != null && !measureValue.isEmpty()) {
					measureValues.add(KeyValueImpl.getInstance(measureDimension, measureValue));
				}
			}
			List<KeyValue> attributes = (measureAttr == null || measureAttr.length == 0) ? Collections.emptyList() : new ArrayList<>(measureAttr.length);
			if(measureAttr != null) {
				for(int i=0; i < measureAttr.length; i++) {
					String measureAttr = this.measureAttr[i];
					String measureAttrValue = getRowValue(this.measureAttrPositions[i]);
					if(measureAttrValue != null && measureAttrValue.length() > 0) {
						attributes.add(KeyValueImpl.getInstance(measureAttr, measureAttrValue));
					}
				}
			}
			//Lazy load observation
			String obsDim = timePosition >=0 ? DimensionBean.TIME_DIMENSION_FIXED_ID : null;
			String obsTime = timePosition >=0 ? getRowValue(timePosition) : null;
			this.currentObs = ObservationImpl.multipleMeasureCrossSection(currentKey, obsDim, obsTime, measureValues, attributes);
		}
		return currentObs;
	}

	@Override
	/**
	 * If there are no measures in the DSD, returns false.
	 * <p/>
	 * Sets the current observation to null, so that it is lazy loaded if requested.
	 * <p/>
	 * If there are multiple measures, moves to the next measure and returns it
	 * <p/>
	 * If all the measures have been checked, moves to the next row - if the next row has the same series key as the current row, it will return the value for the first measure
	 */
	public boolean moveNextObservation() {
		if(!hasMeasures || currentRow == null) {
			return false;
		}
		this.currentObs = null;
		if(readObsRow) {
			if(!moveNextRow()) {
				endOfDataset = true;
				return false;
			}
			String sk = readSeriesKey(currentRow);
			if(sk == null || !sk.equals(this.currentSeriesShortCode)) {
				//series key has changed, so this row's observation is for a different series
				return false;
			}
		}
		readObsRow = true;
		//		if((measureIndex+1) >= this.measures.length) {
//		this.measureIndex = -1;
//		if(!moveNextRow()) {
//			endOfDataset = true;
//			return false;
//		}
//		String sk = readSeriesKey(currentRow);
//		if(sk == null || !sk.equals(this.currentSeriesShortCode)) {
//			//series key has changed, so this row's observation is for a different series
//			return false;
//		}
//	}
//	this.measureIndex++;

		
		//Check there is at least one measure value
		for(int i=0; i < measures.length; i++) {
			String measureValue = getRowValue(this.measuresPositions[i]);
			if(measureValue != null) {
				this.obsPosition++;
				return true;
			}
		}
		//No measure values, check measure attributes
		if(measureAttr != null) {
			for(int i=0; i < measureAttr.length; i++) {
				String measureAttrValue = getRowValue(this.measureAttrPositions[i]);
				if(measureAttrValue != null) {
					this.obsPosition++;
					return true;
				}
			}
		}
		return moveNextObservation();  //move to the next row/series
		
//		if((measureIndex+1) >= this.measures.length) {
//			this.measureIndex = -1;
//			if(!moveNextRow()) {
//				endOfDataset = true;
//				return false;
//			}
//			String sk = readSeriesKey(currentRow);
//			if(sk == null || !sk.equals(this.currentSeriesShortCode)) {
//				//series key has changed, so this row's observation is for a different series
//				return false;
//			}
//		}
//		this.measureIndex++;
//		if(!ObjectUtil.validString(getRowValue(this.measuresPositions[measureIndex]))) {
//			//NO Obs Value, return true if there is at least one Observation Attribute
//			ArrayHolder ah = this.measureAttributes == null ? null : this.measureAttributes.get(this.measures[measureIndex]);
//			if(ah != null) {
//				for(int idx : ah.intArr) {
//					if(ObjectUtil.validString(getRowValue(idx))) {
//						this.obsPosition++;
//						return true;
//					}
//				}
//			}
//			return moveNextObservation();
//		}
//		this.obsPosition++;
//		return true;
	}


	@Override
	/**
	 * Checks a series short code built from the current row - against the current series short code - if the two match, it moves to the next row and
	 * performs the same check, until either there are no more rows, or the serie short code changes.  If it is the latter, the new series short code is
	 * updated with that from the new row
	 * <p/>
	 * Current Key and Current Obs are set to null on this method call, forcing new ones to be lazy loaded on request.
	 * </p>
	 * Measure Index is set back to -1 so that on the call to moveNextObservation, the current row is not changed
	 */
	public boolean moveNextKeyable() {
		if(endOfDataset) {
			return false;
		}
		if(!movedDataset) {
			moveNextDataset();
		}
		this.readObsRow = false;
		this.obsPosition = -1;
		this.currentKey = null;
		this.currentObs = null;
		String newSeriesKey = currentRow == null ? null : readSeriesKey(currentRow);
		while(ObjectUtil.equivalent(newSeriesKey, currentSeriesShortCode)) {
			if(!moveNextRow()) {
				return false;
			}
			newSeriesKey = readSeriesKey(currentRow);
		}
		this.currentSeriesShortCode = newSeriesKey;
		this.keyPosition++;
		return true;
	}

	private boolean moveNextRow() {
		if(endOfDataset) {
			return false;
		}
		if(!columnReaderEngine.moveNextRow()) {
			endOfDataset = true;
			currentRow = null;
			return false;
		}
		currentRow = columnReaderEngine.readRow();
		currentRowSize = currentRow.size();
		return true;
	}

	/**
	 * Read the value from the current row with protection against ArrayIndexOutOfBoundsException
	 * @param pos
	 * @return
	 */
	private String getRowValue(int pos) {
		if(currentRowSize <= pos) {
			return null;
		}
		String str = currentRow.get(pos);
		if(str != null && str.length() == 0) {
			return null;
		}
		return str;
	}

	/**
	 * Generates a colon separated series key from a row of data, example response A:UK:EMP
	 * @param columns
	 * @return
	 */
	private String readSeriesKey(List<String> columns) {
		if(columns == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(Integer pos : this.dimensionPositions) {
			String value = columns.size() <= pos ? "" : columns.get(pos);
			sb.append(concat + value);
			concat = ":";
		}
		return sb.toString();
	}

	@Override
	/**
	 * Closes the underlying column reader engine
	 */
	public List<FooterMessage> close() {
		columnReaderEngine.close();
		return Collections.emptyList();
	}

	@Override
	public void reset() {
		this.columnReaderEngine.reset();
		this.endOfDataset = false;
		this.currentSeriesShortCode = null;
		this.currentRow = null;
		this.keyPosition = -1;
		this.obsPosition = -1;
		this.dsPosition = -1;
		this.currentKey = null;
		this.currentObs = null;
		movedDataset = false;
	}

}
