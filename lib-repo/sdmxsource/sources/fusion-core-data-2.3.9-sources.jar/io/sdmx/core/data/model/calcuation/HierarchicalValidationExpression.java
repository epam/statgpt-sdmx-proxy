package io.sdmx.core.data.model.calcuation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.core.sdmx.error.CaculationError;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.exception.CalculationErrorHandler;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.data.calculation.ValidationExpression;
import io.sdmx.api.sdmx.model.error.ICaculationError;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Expression built from a Hierarchy
 */
public class HierarchicalValidationExpression implements ValidationExpression {

	private String outputCode;
	private List<String> inputCodes = new ArrayList<>();
	private List<ChildNode> childNodes = new ArrayList<>();

	//The same code may appear multiple times in the same hierarchy
	private Map<String, Set<ChildNode>> reportedCodeToNodeMap = new HashMap<>();

	//A map of output values
	private Map<String, Double> shortCodeToReportedValueMap = new HashMap<>();

	private Set<String> reportedShortCodes = new HashSet<>();

	/**
	 * Builds a hierarchical expression based on the root node, which is the expected output and child nodes, any child node which does not share the
	 * same codelist reference as the root node is not included in the calculation
	 * @param hierarchicalCode
	 */
	public HierarchicalValidationExpression(HierarchicalCodeBean hierarchicalCode) {
		String codelistUrn = hierarchicalCode.getCodeReference().getReference().getMaintainableURN().getURN();
		outputCode = hierarchicalCode.getCodeId();
		buildHierarchy(hierarchicalCode.getCodeRefs(), codelistUrn);
	}

	@Override
	public boolean isOutputNumerical() {
		return false;
	}

	@Override
	public EQUALITY getEquality() {
		return EQUALITY.EQUAL;
	}

	@Override
	public String getOutputCode() {
		return outputCode;
	}

	@Override
	public List<String> getInputCodes() {
		return inputCodes;
	}

	@Override
	public void addOutput(String shortCode, Double value) {
		shortCodeToReportedValueMap.put(shortCode, value);
	}

	@Override
	public void addInput(String shortCode, int index, Double value) {
		String codeId = inputCodes.get(index);
		reportedShortCodes.add(shortCode);
		for(ChildNode node : reportedCodeToNodeMap.get(codeId)) {
			node.shortCodeToReportedValueMap.put(shortCode, value);
		}
	}

	@Override
	/**
	 * Validates each part of the hierarchy
	 */
	public void validate(CalculationErrorHandler errorHandler) {
		for(String shortCode : reportedShortCodes) {
			Double reportedValue = shortCodeToReportedValueMap.get(shortCode);
			validateCodeValue(shortCode, this.outputCode, reportedValue, childNodes, errorHandler);
		}
	}

	private void buildHierarchy(List<HierarchicalCodeBean> hCodes, String codelistUrn) {
		for(HierarchicalCodeBean hCode : hCodes) {
			childNodes.add(new ChildNode(hCode, codelistUrn));
		}
	}

	private class ChildNode {
		private boolean isInCodelist;
		private String codeId;
		private List<ChildNode> childNodes = new ArrayList<>();

		private Map<String, Double> shortCodeToReportedValueMap = new HashMap<>();

		public ChildNode(HierarchicalCodeBean hCode, String codelistUrn) {
			this.codeId = hCode.getCodeId();
			isInCodelist = hCode.getCodeReference().getReference().getMaintainableURN().getURN().equals(codelistUrn);
			Set<ChildNode> nodeMap = reportedCodeToNodeMap.get(codeId);
			if(nodeMap == null) {
				nodeMap = new HashSet<>();
				reportedCodeToNodeMap.put(codeId, nodeMap);
			}
			nodeMap.add(this);

			if(isInCodelist) {
				inputCodes.add(hCode.getCodeId());
			}
			for(HierarchicalCodeBean childCode : hCode.getCodeRefs()) {
				childNodes.add(new ChildNode(childCode, codelistUrn));
			}
		}

		/**
		 * Validates each part of the hierarchy
		 */
		public void validate(String shortCode, CalculationErrorHandler errorHandler) {
			Double outputValue = shortCodeToReportedValueMap.get(shortCode);
			validateCodeValue(shortCode, codeId, outputValue, childNodes, errorHandler);
		}

		public Double getValue(String shortCode) {
			Double reportedValue = isInCodelist ? shortCodeToReportedValueMap.get(shortCode) : null;
			if(reportedValue == null) {
				reportedValue = getSumChildNodes(shortCode, childNodes);
			}
			return reportedValue;
		}


		/**
		 * Returns the values used, for example 12 + 13.2
		 * @param shortCode
		 * @return
		 */
		public String getCalulcationValues(String shortCode) {
			Double reportedValue = isInCodelist ? shortCodeToReportedValueMap.get(shortCode) : null;
			if(reportedValue != null) {
				return reportedValue.toString();
			}
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(ChildNode cn : childNodes) {
				String value = cn.getCalulcationValues(shortCode);
				if(ObjectUtil.validString(value)) {
					sb.append(concat + value);
					concat = "+";
				}
			}
			return sb.toString();
		}

		/**
		 * Returns the codes used in the expression, example UK + FR
		 * @param shortCode
		 * @return
		 */
		public String getCodeCalulcationWithValue(String shortCode) {
			Double reportedValue = isInCodelist ? shortCodeToReportedValueMap.get(shortCode) : null;
			if(reportedValue != null) {
				return codeId;
			}
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(ChildNode cn : childNodes) {
				String codeId = cn.getCodeCalulcationWithValue(shortCode);
				if(ObjectUtil.validString(codeId)) {
					sb.append(concat + codeId);
					concat = "+";
				}
			}
			return sb.toString();
		}
	}

	private void validateCodeValue(String shortCode, String outputCode, Double reportedValue, List<ChildNode> childNodes, CalculationErrorHandler errorHandler) {
		if(reportedValue != null) {
			Double childValue = getSumChildNodes(shortCode, childNodes);
			if(childValue != null && !reportedValue.equals(childValue)) {
				//VALIDATION ERROR
				StringBuilder expression = new StringBuilder();
				expression.append(this.outputCode+" = ");
				String concat = "";
				
				List<ChildNode> codesUsed = new ArrayList<>();
				List<String> codesIdsUsed = new ArrayList<>();
				for(ChildNode node : childNodes) {
					String codeId = node.getCodeCalulcationWithValue(shortCode);
					if(ObjectUtil.validString(codeId)) {
						codesUsed.add(node);
						
						for(String id : codeId.split("\\+")) {
							codesIdsUsed.add(id);
						}
						expression.append(concat+codeId);
						concat = "+";
					}
				}
				String calculation = getCalculationValues(shortCode, codesUsed);
				
				ICaculationError error = new CaculationError(shortCode, expression.toString(), "+", codesIdsUsed, calculation, childValue, reportedValue, null);

				errorHandler.reportError(error);
			}
		} 
		for(ChildNode cn : childNodes) {
			cn.validate(shortCode, errorHandler);
		}
	}

	/**
	 * Returns the sum of the child nodes, or null if there are no reported values
	 * @param childNodes
	 * @return
	 */
	private Double getSumChildNodes(String shortCode, List<ChildNode> childNodes) {
		Double reportedValue = null;
		for(ChildNode cn : childNodes) {
			Double childValue = cn.getValue(shortCode);
			if(childValue != null) {
				if(reportedValue == null) {
					reportedValue = childValue;
				} else {
					reportedValue += childValue;
				}
			}
		}
		return reportedValue;
	}

	/**
	 * Returns the calculation values used for the child nodes 
	 * example 12+13+14 
	 * @param childNodes
	 * @return
	 */
	private String getCalculationValues(String shortCode, List<ChildNode> childNodes) {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(ChildNode cn : childNodes) {
			String value = cn.getCalulcationValues(shortCode);
			if(ObjectUtil.validString(value)) {
				sb.append(concat + value);
				concat = "+";
			}
		}
		return sb.toString();
	}

	/**
	 * Returns the calculation used for the child nodes 
	 * example 1E+3P+5Z 
	 * @param childNodes
	 * @return
	 */
	private String getCalculationChildNodes(String shortCode, List<ChildNode> childNodes) {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(ChildNode cn : childNodes) {
			String codeId = cn.getCodeCalulcationWithValue(shortCode);
			if(ObjectUtil.validString(codeId)) {
				sb.append(concat + cn.getCodeCalulcationWithValue(shortCode));
				concat = "+";
			}
		}
		return sb.toString();
	}
}
