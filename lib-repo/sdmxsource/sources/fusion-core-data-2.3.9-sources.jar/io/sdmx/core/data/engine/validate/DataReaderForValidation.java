package io.sdmx.core.data.engine.validate;

import java.util.Date;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DatasetCreationAware;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.core.data.engine.reader.AbstractWrapperedDataReaderEngine;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.data.KeyableProxy;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;

/**
 * Wraps a DataReaderEngine allowing the override of the DataStructure, Dataflow, and ProvisionAgreement reported by the DataReaderEngine
 *
 * In addition this class extends DatasetCreationAware which allows a timestamp to be set on when this dataset was created, which then flows through to the constraint
 * validation, as only the constraints that have a validity
 */
public class DataReaderForValidation extends AbstractWrapperedDataReaderEngine implements DataReaderEngine, DatasetCreationAware {
	private HeaderRetrievalManager headerRetrievalManager;
	private DataStructureBean dsd;
	private DataflowBean dataflow;
	private ProvisionAgreementBean prov;
	private String senderId;
	private String receiverId;
	private String datasetId;
	private String createdBy;
	private DATASET_ACTION action;
	private Date creationDate;
	boolean defaultIfNotProvided = true;  //The user may want to unlink a provision or dataflow, in which case if it is null do NOT use the underlying one (default is true)
	private HeaderBean header;
	private SDMX_STRUCTURE_TYPE highestAttachment; //nullable - DSD, Dataflow, or Provision
	
	public DataReaderForValidation(HeaderRetrievalManager headerRetrievalManager, DataReaderEngine dataReaderEngine, DataStructureBean dsd, DataflowBean flow, ProvisionAgreementBean prov) {
		super(dataReaderEngine);
		this.dsd = dsd;
		this.dataflow = flow;
		this.prov = prov;
		this.headerRetrievalManager = headerRetrievalManager;
	}
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		return new DataReaderForValidation(headerRetrievalManager, proxyCopy, dsd, dataflow, prov);
	}

	@Override
	public HeaderBean getHeader() {
		if(this.header != null) {
			//Ensure the header is not double modified on each time this method is called
			return this.header;
		}
		HeaderBean header = super.getHeader();
		boolean hasSender = ObjectUtil.validString(senderId);

		if (header == null) {
			if(hasSender) {
				header = new HeaderBeanImpl(senderId);
			}  else if(headerRetrievalManager != null){
				header = new HeaderBeanImpl(headerRetrievalManager.getHeader().getSender().getId());
			} else {
				header = new HeaderBeanImpl("ZZZ");
			}
		} else {
			PartyBean modifiedSender;
			PartyBean party = header.getSender();

			if(hasSender) {
				//User override
				if (party != null) {
					modifiedSender = new PartyBeanImpl(party.getName(), senderId, party.getContacts(), party.getTimeZone());
				} else {
					modifiedSender = new PartyBeanImpl(null, senderId, null, null);
				}
				header.setSender(modifiedSender);
			}
		}
		if(createdBy != null) {
			header.addSource(new TextTypeWrapperImpl("en", createdBy));
		}
		if (action != null) {
			header.setAction(action);
		}

		if (receiverId != null) {
			PartyBean pb = new PartyBeanImpl(null, receiverId, null, null);
			header.setReceiver(pb);
		}

		if (datasetId != null) {
			updateDatasetId(header);
		}
		this.header = header;
		return header;
	}

	private void updateDatasetId(HeaderBean header) {

		if (datasetId.contains("${DATAFLOW_") || datasetId.contains("${DSD_")) {
			try {
				if (!this.moveNextDataset()) {
					throw new RuntimeException("No datasets were present in submitted data file");
				}

				if (datasetId.contains("${DATAFLOW_ID}")) {
					if (getDataFlow() == null) {
						throw new RuntimeException("The datasetID contains a reference to the dataflow, but this data is not for a dataflow!");
					}
					datasetId = datasetId.replaceAll("\\$\\{DATAFLOW_ID\\}", getDataFlow().getId());
				}

				if (datasetId.contains("${DATAFLOW_ACY}")) {
					if (getDataFlow() == null) {
						throw new RuntimeException("The datasetID contains a reference to the dataflow, but this data is not for a dataflow!");
					}
					datasetId = datasetId.replaceAll("\\$\\{DATAFLOW_ACY\\}", getDataFlow().getAgencyId());
				}

				if (datasetId.contains("${DATAFLOW_VER}")) {
					if (getDataFlow() == null) {
						throw new RuntimeException("The datasetID contains a reference to the dataflow, but this data is not for a dataflow!");
					}
					String version = getDataFlow().getVersion().toString().replaceAll("\\.", "_");
					datasetId = datasetId.replaceAll("\\$\\{DATAFLOW_VER\\}", version);
				}

				if (datasetId.contains("${DSD_ID}")) {
					if (getDataStructure() == null) {
						throw new RuntimeException("No data structure specified!");
					}
					datasetId = datasetId.replaceAll("\\$\\{DSD_ID\\}", getDataStructure().getId());
				}

				if (datasetId.contains("${DSD_ACY}")) {
					if (getDataFlow() == null) {
						throw new RuntimeException("No data structure specified!");
					}
					datasetId = datasetId.replaceAll("\\$\\{DSD_ACY\\}", getDataStructure().getAgencyId());
				}

				if (datasetId.contains("${DSD_VER}")) {
					if (getDataFlow() == null) {
						throw new RuntimeException("No data structure specified!");
					}
					String version = getDataFlow().getVersion().toString().replaceAll("\\.", "_");
					datasetId = datasetId.replaceAll("\\$\\{DSD_VER\\}", version);
				}

			} finally {
				this.reset();
			}
		}

		if (!ValidationUtil.isValidId(datasetId, true)) {
			throw new RuntimeException("The Dataset ID is not valid!  Value is: '" + datasetId +"'");
		}

		header.setDatasetId(datasetId);
	}
	@Override
	public DataStructureBean getDataStructure() {
		if(dsd != null) {
			return dsd;
		}
		return super.getDataStructure();
	}
	/**
	 * Specifies the highest attachment level to ouptut, i.e. if the datasaet has a Provisin Attachment but the highest attachment is seet to DSD, then only the 
	 * get DSD method will return a value, getDataflow and getProvision will return null
	 * @param highestAttachment
	 */
	public void setHighestAttachment(SDMX_STRUCTURE_TYPE highestAttachment) {
		this.highestAttachment = highestAttachment;
	}

	@Override
	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public DataflowBean getDataFlow() {
		if(highestAttachment != null && highestAttachment == SDMX_STRUCTURE_TYPE.DSD) {
			return null;
		}
		if(dataflow != null || defaultIfNotProvided == false) {
			return dataflow;
		}
		return super.getDataFlow();
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		if(highestAttachment != null && highestAttachment != SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT) {
			return null;
		}
		if(prov != null || defaultIfNotProvided == false) {
			return prov;
		}
		return super.getProvisionAgreement();
	}

	/**
	 * Tells this instance to use or not use the default DSD/flow or provision agreement obtained from the underlying data reader engine, if this corresponding structure has not
	 * been explicitly set on this class.
	 *
	 * @param defaultIfNotProvided
	 */
	public void setDefaultIfNotProvided(boolean defaultIfNotProvided) {
		this.defaultIfNotProvided = defaultIfNotProvided;
	}

	@Override
	public Keyable getCurrentKey() {
		Keyable returnKey = super.getCurrentKey();
		if(returnKey == null) {
			return null;
		}
		return new KeyableWrapper(returnKey, getDataStructure(), getDataFlow());
	}

	public void setAction(DATASET_ACTION action) {
		this.action = action;
	}

	/**
	 * Override the DSD and Dataflow
	 */
	private class KeyableWrapper extends KeyableProxy implements Keyable {
		private DataStructureBean dsd;
		private DataflowBean dataflow;


		public KeyableWrapper(Keyable keyable, DataStructureBean dsd, DataflowBean dataflow) {
			super(keyable);
			this.dsd = dsd;
			this.dataflow = dataflow;
		}


		@Override
		public DataStructureBean getDataStructure() {
			return dsd;
		}

		@Override
		public DataflowBean getDataflow() {
			return dataflow;
		}

	}

}
