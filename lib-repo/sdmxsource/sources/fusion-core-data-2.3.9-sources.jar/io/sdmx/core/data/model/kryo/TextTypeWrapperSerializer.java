package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;

public class TextTypeWrapperSerializer  extends Serializer<TextTypeWrapper> {
	private static final TextTypeWrapperSerializer INSTANCE = new TextTypeWrapperSerializer();
	
	public static TextTypeWrapperSerializer getInstance() {
		return INSTANCE;
	}
	
	private TextTypeWrapperSerializer() { }

	@Override
	public void write(Kryo kryo, Output output, TextTypeWrapper object) {
		kryo.writeObject(output, object.getLocale());
		kryo.writeObjectOrNull(output, object.getValue(), String.class);
	}

	@Override
	public TextTypeWrapper read(Kryo kryo, Input input, Class<? extends TextTypeWrapper> type) {
		String locale = kryo.readObject(input, String.class);
		String value = kryo.readObjectOrNull(input, String.class);
		return new TextTypeWrapperImpl(locale, value, null);
	}
}