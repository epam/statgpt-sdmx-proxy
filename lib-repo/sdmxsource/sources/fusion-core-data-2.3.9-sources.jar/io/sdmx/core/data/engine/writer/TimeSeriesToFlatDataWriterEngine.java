package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;

/**
 * Converts data from time series to flat
 */
public class TimeSeriesToFlatDataWriterEngine implements ISeriesObsDataWriterEngine {
	private IFlatDataWriterEngine flatDataWriterEngine;
	private Map<String, String> seriesValues = null;
	private Map<String, List<String>> seriesMultiValues = null;
	private Map<String, List<String>> seriesMultilingualValues = null;
	private boolean writtenSeries = false;
	private Map<String, String> datasetAttributes = new HashMap<>();
	private Set<String> locales = new HashSet<>();

	private IDatasetStructures structures;

	public TimeSeriesToFlatDataWriterEngine(IFlatDataWriterEngine flatDataWriterEngine) {
		this.flatDataWriterEngine = flatDataWriterEngine;
		if(this.flatDataWriterEngine == null) {
			throw new IllegalArgumentException("TimeSeriesToFlatDataWriterEngine -> IFlatDataWriterEngine Required");
		}
	}

	@Override
	public void writeHeader(HeaderBean header) {
		flatDataWriterEngine.writeHeader(header);
	}
	private int seriesSize = 0;

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if(seriesValues != null && !writtenSeries) {
			flushMap(seriesValues, seriesMultiValues, seriesMultilingualValues, locales);
			writtenSeries = false;
			seriesValues = new HashMap<>(seriesSize);
		}
	    this.structures = structures;
	    this.datasetAttributes = new HashMap<>();
	    if(datasetAttributes != null) {
	    	for(KeyValue kv : datasetAttributes.getAttributes()) {
	    		this.datasetAttributes.put(kv.getConcept(), kv.getCode());
	    	}
	    }
	    DataStructureBean dsd = structures.getDataStructure();

	    seriesSize = dsd.getDimensionIds().size() + dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID).size() + dsd.getGroupAttributes().size();
	    flatDataWriterEngine.startDataset(header, annotations);
	}

	@Override
	public void writeKey(Keyable key) {
		if(seriesValues != null && !writtenSeries) {
			flushMap(seriesValues, seriesMultiValues, seriesMultilingualValues, locales);
		}
		seriesMultiValues = null;
		seriesMultilingualValues = null;
		writtenSeries = false;
		seriesValues = new HashMap<>(seriesSize);
		for(KeyValue kv : key.getKey()) {
			seriesValues.put(kv.getConcept(), kv.getCode());
		}
		for(KeyValue kv : key.getAttributes()) {
			if(kv.getValues() != null) {
				if(seriesMultiValues == null) {
					seriesMultiValues = new HashMap<>();
				}
				seriesMultiValues.put(kv.getConcept(), kv.getValues());
			} else {
				seriesValues.put(kv.getConcept(), kv.getCode());
			}
		}
		for(IMultilingualKeyValue multilingualKeyValue : key.getMultilingualAttributes()){
			if(multilingualKeyValue.getMultilingualNodeValues() != null){
				if(seriesMultilingualValues == null){
					seriesMultilingualValues = new HashMap<>();
				}
				List<String> values = new ArrayList<>();
				for(IMultilingualNodeValue compNode : multilingualKeyValue.getMultilingualNodeValues()){
					List<String> texts = new ArrayList<>();
					for(TextTypeWrapper text : compNode.getTexts()){
						texts.add(text.getLocale()+":"+text.getValue());
						locales.add(text.getLocale());
					}
					values.add(String.join(";", texts));
				}
				seriesMultilingualValues.put(multilingualKeyValue.getConcept(), values);
			}
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		Map<String, List<String>> obsMultiValues = null;
		Map<String, List<String>> obsMultilingualValues = null;
		Map<String, String> currentValues = new HashMap<>(seriesValues);
		for(KeyValue kv : obs.getAttributes()) {
			if(kv.getValues() != null) {
				if(obsMultiValues == null) {
					obsMultiValues = new HashMap<>();
				}
				obsMultiValues.put(kv.getConcept(), kv.getValues());
			} else {
				currentValues.put(kv.getConcept(), kv.getCode());
			}
		}
		for(IMultilingualKeyValue multilingualKeyValue : obs.getMultilingualAttributes()){
			if(multilingualKeyValue.getMultilingualNodeValues() != null){
				if(obsMultilingualValues == null){
					obsMultilingualValues = new HashMap<>();
				}
				List<String> values = new ArrayList<>();
				for(IMultilingualNodeValue compNode : multilingualKeyValue.getMultilingualNodeValues()){
					List<String> texts = new ArrayList<>();
					for(TextTypeWrapper text : compNode.getTexts()){
						texts.add(text.getLocale()+":"+text.getValue());
						locales.add(text.getLocale());
					}
					values.add(String.join(";", texts));
				}
				obsMultilingualValues.put(multilingualKeyValue.getConcept(), values);

			}
		}
		if(obs.getDimensionId() != null) {
			currentValues.put(obs.getDimensionId(), obs.getDimensionValue());
		}
		//for(String measureId : obs.getMeasureMap().keySet()) {
		//	currentValues.put(measureId, obs.getMeasureValues().get(measureId));
		//}
		for(KeyValue kv : obs.getMeasures()) {
			if(kv.getValues() != null) {
				if(obsMultiValues == null) {
					obsMultiValues = new HashMap<>();
				}
				obsMultiValues.put(kv.getConcept(), kv.getValues());
			} else {
				currentValues.put(kv.getConcept(), kv.getCode());
			}
		}
		
		if(obsMultiValues == null) {
			if(seriesMultiValues != null) {
				obsMultiValues=seriesMultiValues;
			}
		} else 	if(seriesMultiValues != null) {
			obsMultiValues.putAll(seriesMultiValues);
		}

		if(obsMultilingualValues == null) {
			if(seriesMultilingualValues != null) {
				obsMultilingualValues=seriesMultilingualValues;
			}
		} else 	if(seriesMultilingualValues != null) {
			obsMultilingualValues.putAll(seriesMultilingualValues);
		}


		flushMap(currentValues, obsMultiValues, obsMultilingualValues, locales);
		writtenSeries = true;
	}


	@Override
	public void close(FooterMessage... footer) {
		if(!writtenSeries) {
			if(seriesValues == null && datasetAttributes.size() > 0) {
				//no series written, only datset attributes
				flatDataWriterEngine.writeRow(new DataRow(structures, datasetAttributes));
			} else if(seriesValues != null){
				flushMap(seriesValues, seriesMultiValues, seriesMultilingualValues, locales);
			}
		}
		flatDataWriterEngine.close();
	}

	/**
	 * Flush map required under the following conditions:
	 * <ol>
	 *  <li>Series Written followed by another series</li>
	 *  <li>Observation Written but not flushed</li>
	 * </ol>
	 */
	private void flushMap(Map<String, String> map,  Map<String, ? extends Collection<String>> multiValueRow, Map<String, ? extends Collection<String>> multilingualValueRow, Set<String> locales) {
		map.putAll(datasetAttributes);
		flatDataWriterEngine.writeRow(new DataRow(structures, map, multiValueRow, multilingualValueRow, locales));
	}
}
