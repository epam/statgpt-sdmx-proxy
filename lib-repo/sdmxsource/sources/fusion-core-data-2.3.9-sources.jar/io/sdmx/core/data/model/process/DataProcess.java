package io.sdmx.core.data.model.process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.core.data.api.model.process.IDataProcess;
import io.sdmx.core.data.api.model.process.IProcessStep;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class DataProcess implements IDataProcess {
	private IURNSingle<? extends IDSDRelatedBean> sRef;
	private List<IProcessStep> processSteps;

	public DataProcess(IURNSingle<? extends IDSDRelatedBean> sRef, List<IProcessStep> processSteps) {
		this.sRef = sRef;
		this.processSteps = Collections.unmodifiableList(new ArrayList<>(processSteps));
		validate();
	}

	/**
	 * Build from JSON, format:
	 * <pre>
	 *  {
	 *    "Structure" : "urn"     //metadata to read the data, only required if overriding the structure reference from the dataset
	 *    "ProcessSteps" : [
	 *      {
	 *      	"ProcessId"  : "VALIDATE"  //Id of a registered process
	 *      	"StepId"     : "STEP1"     //Unique Id for the step
	 *      	"Metrics"    : true        //true to capture metrics for the process
	 *      	"Properties" : {}  		   //optional map of properties specific to the process
	 *      }
	 *    ]
	 *  }
	 * </pre>
	 * @param json
	 */
	public DataProcess(JSONObject json) {
		String urn = JsonObjectUtil.getString(json, "Structure", true);
		this.sRef = urn == null ? null :  URN.builder(urn).buildSingle(IDSDRelatedBean.class);
		this.processSteps = new ArrayList<>();
		for(JSONObject stepJson : JsonObjectUtil.getArrayOfObjects(json, "ProcessSteps", false)) {
			this.processSteps.add(new ProcessStep(stepJson));
		}
		this.processSteps = Collections.unmodifiableList(this.processSteps);
		validate();
	}

	private void validate() {
		if(this.processSteps.size() == 0) {
			throw new SdmxSemmanticException("A DataProcess must contain at least one step");
		}
	}

	@Override
	public IURNSingle<? extends IDSDRelatedBean> getStructure() {
		return sRef;
	}

	@Override
	public List<IProcessStep> getProcessSteps() {
		return processSteps;
	}

}
