package io.sdmx.core.data.api.manager;

import io.sdmx.core.data.model.DataParseMetadata;

public interface DataTransform {
	
	void transform(DataParseMetadata dataParseMetadata);
	
}
