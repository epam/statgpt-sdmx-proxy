package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.core.sdmx.model.data.ObsKey;
import io.sdmx.core.sdmx.model.type.DT_String;

/**
 * Serialization for ObsKey.
 */
public class DT_ObsKey extends BasicDataType<ObsKey> {
  private static final DT_ObsKey INSTANCE = new DT_ObsKey();
  private static final DT_String strDT = DT_String.getInstance();

  private DT_ObsKey() {
  }

  public static DT_ObsKey getInstance() {
    return INSTANCE;
  }

  @Override
  public int compare(ObsKey a, ObsKey b) {
    int cmp = a.getKeyablePosition().compareTo(b.getKeyablePosition());

    if (cmp == 0) {
      String va = a.getDimensionValue();
      String vb = b.getDimensionValue();

      cmp = (va == vb) ? 0 :
            (va == null) ? -1 :
            (vb == null) ? 1 : va.compareTo(vb);
    }

    return cmp;
  }

  @Override
  public int getMemory(ObsKey x) {
    int size = 1; // null/string selector

    if (x != null)
      size += 2 + strDT.getMemory(x.getDimensionValue());

    return size;
  }

  @Override
  public void write(WriteBuffer buf, ObsKey x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      buf.putVarInt(x.getKeyablePosition());
      strDT.write(buf, x.getDimensionValue());
    }
  }

  @Override
  public ObsKey read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    ObsKey x = null;

    if (!isNull) {
      Integer keyablePosition = DataUtils.readVarInt(buf);
      String dimensionValue = strDT.read(buf);

      x = new ObsKey(keyablePosition, dimensionValue);
    }

    return x;
  }

  @Override
  public ObsKey[] createStorage(int size) {
    return new ObsKey[size];
  }
}
