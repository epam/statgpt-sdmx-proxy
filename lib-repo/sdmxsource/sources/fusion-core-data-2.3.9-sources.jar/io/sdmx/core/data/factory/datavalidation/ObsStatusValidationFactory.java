package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.ObsStatusValidationEngine;

public class ObsStatusValidationFactory implements DataValidatorFactory {

    @Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
        return new ObsStatusValidationEngine(dsi.getDatasetStructures().getDataStructure());
    }

    @Override
    public String getName() {
        return "Obs Status";
    }

	@Override
	public String getId() {
		return "ObsStatusValidator";
	}

	@Override
	public String getDescription() {
	    return "Ensures the values reported are correct with regards to the Observation Status. " +
                "If the OBS_STATUS value is B, D, W, I, F, E, P, N, U, V, G or A then numerics are permitted in the observation. " +
                "All other OBS_STATUS values prevent a numeric value being reported for the observation. " +
                "If the OBS_STATUS is D, W, I, F, E, P, N, U, V, G or A then the observation may not be null. " +
                "All other OBS_STATUS values permit the reporting of empty observations.";
	}

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return true;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.IGNORE;
	}
	
	@Override
	public int hashCode() {
		return "ObsStatusValidationFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ObsStatusValidationFactory;
	}
}