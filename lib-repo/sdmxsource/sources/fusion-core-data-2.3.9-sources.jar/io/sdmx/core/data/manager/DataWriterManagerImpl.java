package io.sdmx.core.data.manager;

import java.io.OutputStream;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;

public class DataWriterManagerImpl extends AbstractDataWriterManager implements DataWriterManager {

	public DataWriterManagerImpl(DataFormatManager dataFormatManager) {
		super(dataFormatManager);
	}

	@Override
	public ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out) {
		return getDataWriterEngine(dataFormat, out, null);
	}

	@Override
	public ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		return super.getTimeSeriesDataWriterEngine(dataFormat, out, dataQuery);
	}
	
}
