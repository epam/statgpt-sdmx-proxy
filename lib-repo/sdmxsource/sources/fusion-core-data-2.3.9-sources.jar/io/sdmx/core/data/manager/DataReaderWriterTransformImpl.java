package io.sdmx.core.data.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.api.manager.DataReaderWriterTransform;
import io.sdmx.core.data.model.TransformOptions;
import io.sdmx.core.data.util.DataHeaderUtil;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataReaderWriterTransformImpl implements DataReaderWriterTransform {
	public static final DataReaderWriterTransform INSTANCE = new DataReaderWriterTransformImpl();
	private DataReaderWriterTransformImpl() {}

	private void pivot(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, TransformOptions options) {
		String pivotDimension = options.getPivotDimension();

		DatasetHeaderBean datasetHeader = dataReaderEngine.getCurrentDatasetHeaderBean();

		String currentCrossSectionConcept = datasetHeader.getDataStructureReference().getDimensionAtObservation();
		boolean pivotIsTime = (pivotDimension.equals(DimensionBean.TIME_DIMENSION_FIXED_ID));
		boolean fromIsTimeSeries = datasetHeader.isTimeSeries();

		//Determine the series and observation attributes based on the new cross section, this is only possible if the data reader engine contains the keyFamily
		DataStructureBean keyFamily = dataReaderEngine.getDataStructure();
		List<String> seriesAttributeConcepts = null;
		List<String> obsAttributeConcepts = null;

		if(keyFamily != null) {
			//TODO what if there is no Key Family???
			seriesAttributeConcepts = getSeriesAttributes(pivotDimension, keyFamily);
			obsAttributeConcepts = getObsAttributes(pivotDimension, keyFamily);
		}

		Set<String> shortCodes = new HashSet<>();

		Map<String, Keyable> keyMap = new HashMap<>();
		Map<String, Set<Observation>> obsMap = new HashMap<>();

		while(dataReaderEngine.moveNextKeyable()) {
			Keyable key = dataReaderEngine.getCurrentKey();
			if(!key.isSeries()) {
				// Copy the Group verbatim and continue loop. There is no more useful information that can be obtained from the group
				writeKeyableToWriter(dataReaderEngine, dataWriterEngine, key, 0);
				continue;
			}
			String codeForPivot = pivotIsTime ? key.getReportedValue(DimensionBean.TIME_DIMENSION_FIXED_ID) : key.getReportedValue(pivotDimension);

			while(dataReaderEngine.moveNextObservation()) {
				Observation obs = dataReaderEngine.getCurrentObservation();

				String currentObsCode = obs.getDimensionValue();
				String newKeyShortCode = getKeyShortCode(key, currentObsCode, pivotDimension);
				Set<Observation> observations = obsMap.get(newKeyShortCode);
				if(!shortCodes.contains(newKeyShortCode)) {
					shortCodes.add(newKeyShortCode);
					keyMap.put(newKeyShortCode, createNewKey(key, pivotDimension, currentCrossSectionConcept, currentObsCode, pivotIsTime, fromIsTimeSeries, seriesAttributeConcepts));
					observations = new HashSet<>();
					obsMap.put(newKeyShortCode, observations);
				}
				String obsValue = obs.getPrimaryMeasure().getValues().get(0);
				//TODO Obs Attributes
				observations.add(ObservationImpl.crossSection(key, pivotDimension, codeForPivot, obsValue, null));
			}
		}
		for(String currentKey : keyMap.keySet()) {
			Keyable key = keyMap.get(currentKey);
			writeKeyableToWriter(dataWriterEngine, keyMap.get(currentKey), options.isIncludeAttributes());
			for(Observation obs : obsMap.get(currentKey)) {
				writeObsToWriter(dataWriterEngine, key, obs, options.isIncludeAttributes());
			}
		}
	}

	private String getKeyShortCode(Keyable currentKey, String promoteCode, String ignoreConcept) {
		String returnString = "";
		for(KeyValue kv : currentKey.getKey()) {
			if(kv.getConcept().equals(ignoreConcept)) {
				continue;
			}
			returnString += kv.getCode() + ":";
		}
		returnString += promoteCode;
		return returnString;
	}


	@Override
	public void copyToWriter(DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			boolean includeObs,
			boolean includeAttributes,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean copyHeader,
			boolean closeWriter,
			boolean mergeDatasets) {
		copyToWriter(dataReaderEngine, dataWriterEngine, null, includeObs, includeAttributes, -1, null, null, copyHeader, closeWriter, mergeDatasets);
	}

	@Override
    public void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, String pivotDimension,  boolean closeOnCompletion, boolean mergeDatasets) {
        copyToWriter(dataReaderEngine, dataWriterEngine, pivotDimension, true, true, -1, null, null, true, closeOnCompletion, mergeDatasets);
    }

	@Override
    public void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, boolean copyHeader, boolean closeWriter) {
        copyToWriter(dataReaderEngine, dataWriterEngine, null, true, true, -1, null, null, copyHeader, closeWriter, false);
    }

    @Override
    public void copyToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, boolean copyHeader, boolean closeWriter, boolean mergeDatasets) {
        copyToWriter(dataReaderEngine, dataWriterEngine, null, true, true, -1, null, null, copyHeader, closeWriter, mergeDatasets);
    }

	private void copyToWriter(DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			String pivotDimension,
			boolean includeObs,
			boolean includeAttributes,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean includeHeader,
			boolean closeOnCompletion,
			boolean forceStartNewDataset) {
		dataReaderEngine.reset();
		HeaderBean header = dataReaderEngine.getHeader();
		if(includeHeader && header != null) {
			dataWriterEngine.writeHeader(header);
		}

		try {
			DatasetHeaderBean dsHeader = null;
			List<KeyValue> attributeValues = null;
			while(dataReaderEngine.moveNextDataset()) {
				boolean startNewDataset = dataReaderEngine.getDatasetPosition() == 0;
				if (forceStartNewDataset) {
				    startNewDataset = true;
				} else if (dataReaderEngine.getDatasetPosition() > 0) {
					//CHECK PREVIOUS ATTS Vs CURRENT ATTS
					startNewDataset = !ObjectUtil.containsAll(attributeValues, dataReaderEngine.getDatasetAttributes().getAttributes());
				}
				
				attributeValues = dataReaderEngine.getDatasetAttributes().getAttributes();
				dsHeader = copyDatasetToWriter(dsHeader, dataReaderEngine, dataWriterEngine, pivotDimension, includeObs, includeAttributes, maxObs,
						dateFrom, dateTo, false, false, startNewDataset);
			}
		} finally {
			if(closeOnCompletion) {
				dataWriterEngine.close();
			}
		}
	}

	private DatasetHeaderBean copyDatasetToWriter(
			DatasetHeaderBean previousDatasetHeader,
			DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			String pivotDimension,
			boolean includeObs,
			boolean includeAttributes,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean includeHeader,
			boolean closeOnCompletion,
			boolean forceStartNewDataset) {
		TransformOptions options = new TransformOptions();
		options.setPivotDimension(pivotDimension);
		options.setIncludeObs(includeObs);
		options.setMaxObs(maxObs);
		options.setDateFrom(dateFrom);
		options.setDateTo(dateTo);
		options.setIncludeHeader(includeHeader);
		options.setCloseWriter(closeOnCompletion);
		options.setIncludeAttributes(includeAttributes);
		return copyDatasetToWriter(previousDatasetHeader, dataReaderEngine, dataWriterEngine, options, forceStartNewDataset);
	}

	private DatasetHeaderBean copyDatasetToWriter(
			DatasetHeaderBean previousDatasetHeader,
			DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			TransformOptions transformOptions,
			boolean forceStartNewDataset) {
		try {
			if(transformOptions.isIncludeHeader() && dataReaderEngine.getHeader() != null) {
				dataWriterEngine.writeHeader(dataReaderEngine.getHeader());
			}
			DatasetHeaderBean datasetHeader = dataReaderEngine.getCurrentDatasetHeaderBean();
			boolean fromIsTimeSeries = datasetHeader != null && datasetHeader.isTimeSeries();
			String dimensionAtObs = datasetHeader == null ? null : datasetHeader.getDataStructureReference().getDimensionAtObservation();
			if(transformOptions.getPivotDimension() == null || (fromIsTimeSeries && transformOptions.getPivotDimension().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) || transformOptions.getPivotDimension().equals(dimensionAtObs)) {
				if(forceStartNewDataset || (previousDatasetHeader == null || !DataHeaderUtil.isHeaderEqual(datasetHeader, previousDatasetHeader))) {
					dataWriterEngine.startDataset(dataReaderEngine.getProvisionAgreement(), dataReaderEngine.getDataFlow(), dataReaderEngine.getDataStructure(), datasetHeader);
				}
				if(dataReaderEngine.getDatasetAttributes() != null) {
					if(transformOptions.isIncludeAttributes()) {
						writeAttributable(dataWriterEngine, dataReaderEngine.getDatasetAttributes());
					}
				}
				
				Keyable previousKey = null;
				Keyable currentKey = null;
				boolean writeKey = true;
				while(true) {
					try {
						if(!dataReaderEngine.moveNextKeyable()) {
							break;
						}
						writeKey = true;
						currentKey = dataReaderEngine.getCurrentKey();
						if(previousKey != null) {
							if(previousKey.equals(currentKey)) {
								writeKey = false;
							}
						}
						previousKey = currentKey;
					} catch(Throwable th) {
						if(currentKey == null) {
							throw new SdmxException(th, "Error while trying to read first series key: "+th.getMessage());
						}
						throw new SdmxException(th, "Error while trying to read next series/group in the DataSet.  The last successfully processed key was: " + currentKey);
					}

					try {
						if(writeKey == false) {
							if(transformOptions.isIncludeObs()) {
								writeKeyableToWriter(dataReaderEngine, dataWriterEngine, currentKey, transformOptions.getMaxObs(), transformOptions.getDateFrom(), transformOptions.getDateTo(), transformOptions.isIncludeAttributes(), true);
							}
						} else if(transformOptions.isIncludeObs()) {
							writeKeyableToWriter(dataReaderEngine, dataWriterEngine, currentKey, transformOptions.getMaxObs(), transformOptions.getDateFrom(), transformOptions.getDateTo(), transformOptions.isIncludeAttributes());
						} else {
							writeKeyableToWriter(dataWriterEngine, currentKey, transformOptions.isIncludeAttributes());
						}
					} catch(Throwable th) {
						throw new SdmxException(th, "Error occurred while processing " + currentKey);
					}
				}
				return datasetHeader;
			} else {
				//Modify the header to change the dimension at observation
				String dsId = null;
				IURNSingle<? extends IDSDRelatedBean> structureRef = null;
				String serviceURL = null;
				String structureURL = null;

				if(datasetHeader.getDataStructureReference() != null) {
					dsId = datasetHeader.getDataStructureReference().getId();
					structureRef = datasetHeader.getDataStructureReference().getStructureReference();
					serviceURL = datasetHeader.getDataStructureReference().getServiceURL();
					structureURL = datasetHeader.getDataStructureReference().getStructureURL();
				} else {
					structureRef = dataReaderEngine.getDataStructure().getURN();
				}

				DatasetStructureReferenceBean dsStructureRef = new DatasetStructureReferenceBeanImpl(dsId, structureRef, serviceURL, structureURL, transformOptions.getPivotDimension());
				DatasetHeaderBean modifiedDatasetHeader = datasetHeader.modifyDataStructureReference(dsStructureRef);

				if(previousDatasetHeader == null || !DataHeaderUtil.isHeaderEqual(datasetHeader, previousDatasetHeader)) {
					dataWriterEngine.startDataset(dataReaderEngine.getProvisionAgreement(), dataReaderEngine.getDataFlow(), dataReaderEngine.getDataStructure(), modifiedDatasetHeader);
				}
				//The data reader is pivoting on a different dimension then the one we want to pivot on - start algorithm
				//We are pivoting on a different dimension to the current pivot
				pivot(dataReaderEngine, dataWriterEngine, transformOptions);
				return modifiedDatasetHeader;
			}
		} finally {
			if(transformOptions.isCloseWriter()) {
				dataWriterEngine.close();
			}
		}
	}




	@Override
	public void copyDatasetToWriter(DataReaderEngine dataReaderEngine,
			DataWriterEngine dataWriterEngine,
			String pivotDimension,
			boolean includeObs,
			Integer maxObs,
			Date dateFrom,
			Date dateTo,
			boolean includeHeader,
			boolean closeOnCompletion,
			boolean forceStartNewDataset) {
		copyDatasetToWriter(null, dataReaderEngine, dataWriterEngine, pivotDimension, includeObs, true, maxObs, dateFrom, dateTo,
				includeHeader, closeOnCompletion, forceStartNewDataset);
	}

	private List<String> getSeriesAttributes(String pivotDimension, DataStructureBean keyFamily) {
		List<String> returnList = new ArrayList<>();
		for(AttributeBean currentAttribute : keyFamily.getSeriesAttributes(pivotDimension)) {
			returnList.add(currentAttribute.getId());
		}
		return returnList;
	}

	private List<String> getObsAttributes(String pivotDimension, DataStructureBean keyFamily) {
		List<String> returnList = new ArrayList<>();
		for(AttributeBean currentAttribute : keyFamily.getObservationAttributes(pivotDimension)) {
			returnList.add(currentAttribute.getId());
		}
		return returnList;
	}

	private Keyable createNewKey(
			Keyable keyable,
			String ignoreConcept,
			String includeNewConcept,
			String newConceptValue,
			boolean movingToTimeSeries,
			boolean movingFromTimeSeries,
			List<String> seriesAttributeConcepts) {
		List<KeyValue> newKeyList = keyable.getKey();
		KeyValue removeKv = null;
		for(KeyValue kv : keyable.getKey()) {
			if(kv.getConcept().equals(ignoreConcept)) {
				removeKv = kv;
				break;
			}
		}
		List<KeyValue> newAttList = new ArrayList<>();
		for(KeyValue currentAttr : keyable.getAttributes()) {
			if(seriesAttributeConcepts.contains(currentAttr.getConcept())) {
				newAttList.add(currentAttr);
			}
		}
		newKeyList.remove(removeKv);
		if(movingToTimeSeries) {
			newKeyList.add(KeyValueImpl.getInstance(DimensionBean.TIME_DIMENSION_FIXED_ID, keyable.getReportedValue(DimensionBean.TIME_DIMENSION_FIXED_ID)));
		} else {
			newKeyList.add(KeyValueImpl.getInstance(includeNewConcept, newConceptValue));
		}
		return KeyableImpl.seriesKey(keyable.getDataflow(), keyable.getDataStructure(), newKeyList, newAttList);
	}


	/**
	 * Writes the keyable to the data writer engine, if includeObs is true and date from and to filter out all observation values for a key, then the key will not be written.
	 */
	@Override
	public void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs, Date dateFrom, Date dateTo, boolean includeAttributes) {
		writeKeyableToWriter(dataReaderEngine, dataWriterEngine, keyable, maxObs, dateFrom, dateTo, includeAttributes, false);
	}
	/**
	 * Writes the keyable to the data writer engine, if includeObs is true and date from and to filter out all observation values for a key, then the key will not be written.
	 */
	private void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs, Date dateFrom, Date dateTo, boolean includeAttributes, boolean writtenKey) {
		boolean filteredObs = false;
		String fromDateFormatted = null;
		String toDateFormatted = null;

		boolean seriesKeysOnly = maxObs != null && maxObs == 0;
		if(keyable.isSeries() && !seriesKeysOnly) {
			//Filter out the observations from the series
			boolean hasMax = maxObs != null && maxObs > 0;
			List<Observation> obsList = new ArrayList<>();
			Observation obs = null;
			while(true) {
				try {
					if(!dataReaderEngine.moveNextObservation()) {
						break;
					}
				} catch(Throwable th) {
					if(obs == null) {
						throw new SdmxException(th, "Error occurred whilst trying to read first observation in key");
					}
					throw new SdmxException(th, "Error occurred whilst trying to determine if series key had another observation, last successfully processed observation: " + obs);
				}
				obs = dataReaderEngine.getCurrentObservation();
				if(dateFrom != null) {
					if(fromDateFormatted == null) {
						TIME_FORMAT format = obs.getSdmxObsTime().getTimeFormatOfDate();
						fromDateFormatted = DateUtil.formatDate(dateFrom, format);
					}
					if(obs.getDimensionValue().compareTo(fromDateFormatted) < 0) {
						filteredObs = true;
						continue;
					}
				}
				if(dateTo != null) {
					if(toDateFormatted == null) {
						TIME_FORMAT format = obs.getSdmxObsTime().getTimeFormatOfDate();
						toDateFormatted = DateUtil.formatDate(dateTo, format);
					}
					if(obs.getDimensionValue().compareTo(toDateFormatted) > 0) {
						filteredObs = true;
						continue;
					}
				}
				if(!writtenKey) {
					writeKeyableToWriter(dataWriterEngine, keyable, includeAttributes);
					writtenKey = true;
				}
				if(!hasMax) {
					writeObsToWriter(dataWriterEngine, keyable, obs, includeAttributes);
				} else {
					obsList.add(obs);
				}
			}
			//There was a limit on the number of obs, so now only write out the to 'x' results
			if(obsList.size() > 0) {
				Collections.sort(obsList);
				Collections.reverse(obsList);
				int loopCount = obsList.size() > maxObs ? maxObs : obsList.size();
				for(int i = 0; i < loopCount; i++) {
					writeObsToWriter(dataWriterEngine, keyable, obsList.get(i), includeAttributes);
				}
			}
			if(!filteredObs && !writtenKey) {
				//If no observations were filtered and the key was not written, write the key out
				writeKeyableToWriter(dataWriterEngine, keyable, includeAttributes);
			}
		} else {
			//Either it is not a series, or observations are not to be included, either way the key needs to be written out
			writeKeyableToWriter(dataWriterEngine, keyable, includeAttributes);
		}
	}

	@Override
	public void writeObsToWriter(DataWriterEngine dataWriterEngine, Keyable keyable, Observation obs, boolean includeAttributes) {
		dataWriterEngine.writeObservation(obs.getDimensionId(), obs.getDimensionValue(), obs.getMeasures(), getAnnotations(obs.getAnnotations()));
		if(includeAttributes) {
			this.writeAttributable(dataWriterEngine, obs);
		}
		writeMultivaluedMeasures(dataWriterEngine, obs.getMeasures());
	}



	@Override
	public void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs, Date dateFrom, Date dateTo) {
		writeKeyableToWriter(dataReaderEngine, dataWriterEngine, keyable, maxObs, dateFrom, dateTo, true);
	}

	@Override
	public void writeObsToWriter(DataWriterEngine dataWriterEngine, Keyable keyable, Observation obs) {
		writeObsToWriter(dataWriterEngine, keyable, obs, true);
	}

	@Override
	public void writeKeyableToWriter(DataReaderEngine dataReaderEngine, DataWriterEngine dataWriterEngine, Keyable keyable, Integer maxObs) {
		writeKeyableToWriter(dataReaderEngine, dataWriterEngine, keyable, maxObs, null, null, true);
	}

	/**
	 * Writes the keyable to the datawriter engine
	 * @param dataWriterEngine
	 * @param keyable
	 */
	private void writeKeyableToWriter(DataWriterEngine dataWriterEngine, Keyable keyable, boolean includeAttributes) {
		if(keyable.isSeries()) {
			dataWriterEngine.startSeries(getAnnotations(keyable.getAnnotations()));
			for(KeyValue kv : keyable.getKey()) {
				dataWriterEngine.writeSeriesKeyValue(kv.getConcept(), kv.getCode());
			}
//			if(!keyable.isTimeSeries()) {
//				if (keyable.getCrossSectionConcept() != null) {
//					if(keyable.getObsTime() == null) {
//						throw new SdmxSemmanticException("Dataset is cross sectional, cross section is missing a time");
//					}
//					dataWriterEngine.writeSeriesKeyValue(DimensionBean.TIME_DIMENSION_FIXED_ID, keyable.getObsTime());
//				} else {
//				}
//			}
		} else {
			dataWriterEngine.startGroup(keyable.getGroupName());
			for(KeyValue kv : keyable.getKey()) {
				dataWriterEngine.writeGroupKeyValue(kv.getConcept(), kv.getCode());
			}
		}

		if(includeAttributes) {
			writeAttributable(dataWriterEngine, keyable);
		}
	}
	
	private void writeAttributable(DataWriterEngine dataWriterEngine,Attributable attributable) {
		writeAttributes(dataWriterEngine, attributable.getAttributes());
		writeMultilingualAttributes(dataWriterEngine, attributable.getMultilingualAttributes());
	}

	/**
	 * writes attributes and multivalued attributes to the data writer engine
	 * @param dataWriterEngine
	 * @param attributes
	 */
	private void writeAttributes(DataWriterEngine dataWriterEngine, List<KeyValue> attributes) {
		List<KeyValue> multivalueAttributes = new ArrayList<>();
		if(attributes != null) {
			for(KeyValue attr : attributes) {
				if(attr.getValues() != null){
					multivalueAttributes.add(attr);
					continue;
				}
				String codeVal = attr.getCode() == null ? "" : attr.getCode();
				dataWriterEngine.writeAttributeValue(attr.getConcept(), codeVal);
			}
			for(KeyValue multiValueAttr : multivalueAttributes){
				dataWriterEngine.writeAttributeValue(multiValueAttr.getConcept(), multiValueAttr.getValues().toArray(new String[0]));
			}
		}
	}

	/**
	 * writes multivalued measures to the datawriter engine. Iterates over the list of measures, extracts measures which
	 * have multiple values and only writes those.
	 * @param dataWriterEngine
	 * @param measures
	 */
	private void writeMultivaluedMeasures(DataWriterEngine dataWriterEngine, List<KeyValue> measures){
		List<KeyValue> multivalueMeasures = new ArrayList<>();
		if(measures !=null){
			for(KeyValue measure: measures){
				if(measure.getValues() != null && !(measure.getConcept().equals(PrimaryMeasureBean.FIXED_ID))){
					multivalueMeasures.add(measure);
				}
			}
			for(KeyValue multiValueMeasure : multivalueMeasures){
				dataWriterEngine.writeAttributeValue(multiValueMeasure.getConcept(), multiValueMeasure.getValues().toArray(new String[0]));
			}
		}
	}

	/**
	 * writes multilingual attributes to the data writer engine.
	 * @param dataWriterEngine
	 * @param complexAttributes
	 */
	private void writeMultilingualAttributes(DataWriterEngine dataWriterEngine, List<IMultilingualKeyValue> complexAttributes) {
		if(complexAttributes != null) {
			for(IMultilingualKeyValue complexAttribute : complexAttributes) {
				dataWriterEngine.writeMultilingualAttributeValue(complexAttribute);
			}
		}
	}
	private AnnotationBean[] getAnnotations(List<AnnotationBean> annotationList) {
		if(annotationList.size() == 0) {
			return null;
		}
		AnnotationBean[] annotationArr = new AnnotationBean[annotationList.size()];
		for(int i =0; i < annotationList.size(); i++) {
			annotationArr[i] = annotationList.get(i);
		}
		return annotationArr;
	}
}
