package io.sdmx.core.data.engine.query;

import java.util.Set;
import java.util.UUID;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;

public class FileQueryEngine implements SdmxDataRetrievalWithWriter {
	private ReadableDataLocation dataLocation;
	private DataReaderManager dataReadManager;
	
	
	public FileQueryEngine(ReadableDataLocation dataLocation, DataReaderManager dataReadManager) {
		if(dataLocation == null) {
			throw new IllegalArgumentException("dataLocation can not be null");
		}
		if(dataReadManager == null) {
			throw new IllegalArgumentException("dataReadManager can not be null");
		}
		this.dataLocation = dataLocation;
		this.dataReadManager = dataReadManager;
	}
	
	@Override
	public void getData(DataQuery dataQuery, ISeriesObsDataWriterEngine dataWriterEngine) {
		try {
			DataStructureBean dataStructureBean = dataQuery.getDataStructure();
			
			DataReaderEngine dataReaderEngine = dataReadManager.getDataReaderEngine(dataLocation, dataStructureBean, dataQuery.getDataflow(), null, null);
			DATASET_ACTION action = DATASET_ACTION.INFORMATION;
			if(dataReaderEngine.getHeader() != null && dataReaderEngine.getHeader().getAction() != null) {
				action = dataReaderEngine.getHeader().getAction();
			}
			DatasetStructureReferenceBean dsRef;
			if(dataQuery.getDataflow() != null) {
				dsRef = new DatasetStructureReferenceBeanImpl(dataQuery.getDataflow().getURN());
			} else {
				dsRef = new DatasetStructureReferenceBeanImpl(dataStructureBean.getURN());
			}
			
			
			
			DatasetHeaderBean dsHeader = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), action, dsRef);
			dataWriterEngine.startDataset(new DatasetStructures(dataStructureBean, dataQuery.getDataflow(), null, null), dsHeader, null);
			
			//FUNC not been updated to new query
			SdmxDate queryFrom = null;
			SdmxDate queryTo = null;
			if(dataQuery.hasSelections()) {
				if (dataQuery.hasSelections()) {
					if(dataQuery.getStartPeriod() != null) {
						queryFrom = dataQuery.getStartPeriod();
					}
					if(dataQuery.getEndPeriod() != null) {
						queryTo = dataQuery.getEndPeriod();
					}
				}
			}
			boolean includeObs = dataQuery.getDataQueryDetail() != DATA_QUERY_DETAIL.SERIES_KEYS_ONLY;
			Integer maxObs = null;
			if(!includeObs) {
				maxObs = 0;
			} else {
				//TODO this should change, and so should the reader writer transform API
				maxObs = dataQuery.getLastNObservations();
				if(maxObs == null) {
					maxObs = dataQuery.getFirstNObservations();
				}
			}
			while(dataReaderEngine.moveNextDataset()) {
				while(dataReaderEngine.moveNextKeyable()) {
					Keyable key = dataReaderEngine.getCurrentKey();
					if(dataQuery.hasSelections() && !seriesMatch(dataQuery, key)) {
						continue;
					}
					dataWriterEngine.writeKey(key);
					int obsWritten = 0;
					while(dataReaderEngine.moveNextObservation()) {
						if(maxObs != null && maxObs == obsWritten) {
							break;
						}
						Observation obs = dataReaderEngine.getCurrentObservation();
						if(queryFrom != null) {
							SdmxDate date = obs.getSdmxObsTime();
							if(date != null && date.isEarlier(queryFrom)) {
								continue;
							}
						}
						if(queryTo != null) {
							SdmxDate date = obs.getSdmxObsTime();
							if(date != null && date.isLater(queryTo)) {
								continue;
							}
						}
						dataWriterEngine.writeObservation(obs);
						obsWritten++;
					}
				}
			}
		} finally {
			dataWriterEngine.close();
		}
	}
	
	//FUNC not been updated to new query
	private boolean seriesMatch(DataQuery dataQuery, Keyable key) {
		if (dataQuery.hasSelections()) {
			for(DataQuerySelection selection : dataQuery.getSelections()) {
				Set<String> selectionValues = selection.getValues();
				String val = key.getReportedValue(selection.getComponentId());
	    		if(val == null) {
	    			return false;  //NOT IN THE SERIES , ROLLED UP CONCEPTS DOES NOT CONTAIN THIS CONCEPT
	    		}
	    		if(selection.isExcluded()) {
	    			if(selectionValues.contains(val)) {
		    			return false;
		    		}	
	    		} else if(!selectionValues.contains(val)) {
	    			return false;
	    		}
	    	}
		}
		return true;
	}
}
