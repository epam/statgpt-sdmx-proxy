package io.sdmx.core.data.model.kryo;

import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;

public class MultilingualKeyValueListSerializer extends ListSerializer<IMultilingualKeyValue> {
	private static final MultilingualKeyValueListSerializer INSTANCE = new MultilingualKeyValueListSerializer();
	
	public static MultilingualKeyValueListSerializer getInstance() {
		return INSTANCE;
	}
	
	private MultilingualKeyValueListSerializer() {
		super(MultilingualKeyValueSerializer.getInstance());
	}
}
