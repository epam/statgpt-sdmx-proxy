package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Set;

import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.sdmx.model.type.DT_Map;
import io.sdmx.core.sdmx.model.type.DT_Set;
import io.sdmx.core.sdmx.model.type.DT_String;

public class DT_DataRow extends BasicDataType<IDataRow> {
    private IDatasetStructures structures;
    private DT_Map<String, String> row;
    private DT_Map<String, Set<String>> multiValueData;
    private DT_Map<String, Set<String>> multilingualValueData;
    private DT_Set<String> locales;
    
    public DT_DataRow(IDatasetStructures structures) {
        this.structures = structures;
        DT_String strDt = DT_String.getInstance();
        this.row = new DT_Map<>(strDt, strDt);
        this.multiValueData = new DT_Map<>(strDt, new DT_Set<>(strDt));
        this.multilingualValueData = new DT_Map<>(strDt, new DT_Set<>(strDt));
        this.locales = new DT_Set<>(strDt);
    }

    @Override
    public IDataRow[] createStorage(int size) {
        return new IDataRow[size];
    }

    @Override
    public int getMemory(IDataRow obj) {
        int size = row.getMemory(obj.getRowData());
        size += multiValueData.getMemory(obj.getMultiValueData());
        size += multilingualValueData.getMemory(obj.getMultilingualValueData());
        size += locales.getMemory(obj.getLocales());
        return size;
    }

    @Override
    public void write(WriteBuffer buff, IDataRow obj) {
        row.write(buff, obj.getRowData());
        multiValueData.write(buff, obj.getMultiValueData());
        multilingualValueData.write(buff, obj.getMultilingualValueData());
        locales.write(buff, obj.getLocales());
    }

    @Override
    public IDataRow read(ByteBuffer buff) {
        Map<String, String> rowData = row.read(buff);
        Map<String, Set<String>> multiValueData = this.multiValueData.read(buff);
        Map<String, Set<String>> multilingualValueData = this.multilingualValueData.read(buff);
        Set<String> locales = this.locales.read(buff);
        
        return new DataRow(structures, rowData, multiValueData, multilingualValueData, locales);
    }

}
