package io.sdmx.core.data.model.dataset.mvstore.consolication;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreDataset;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreDatasetStorage;
import io.sdmx.core.sdmx.model.data.ObsPos;

/**
 * @deprecated to delete
 */
@Deprecated //see new model
public class MVStoreRetriever extends MVStoreAbstractView {
//	private static final Logger LOG = LoggerFactory.getLogger(MVStoreRetriever.class);
//
//	public MVStoreRetriever(MVStoreDatasetStorageConsolidation storage) {
//		super(storage);
//	}
//
//	/**
//	 * Return attributes for the given dataset
//	 */
//	@Override
//	public List<KeyValue> getDatasetAttributes(int dsIx) {
//		MVStoreDataset ds = storage.getDataset(dsIx);
//
//		return ds.getDatasetAttributes();
//	}
//
//	/**
//	 * Return an iterator on keyable positions for the given dataset
//	 */
//	@Override
//	public Iterator<Integer> getKeyableIterator(int dsIx) {
//		MVStoreDataset ds = storage.getDataset(dsIx);
//
//		return ds.getKeyableIndexIterator();
//	}
//
//	/**
//	 * Return the keyable at the given position
//	 */
//	@Override
//	public Keyable getKeyable(int dsIx, Integer kPos) {
//		MVStoreDataset ds = storage.getDataset(dsIx);
//
//		return ds.getKeyable(kPos);
//	}
//
//	/**
//	 * Return an iterator on observation positions for the given keyable
//	 */
//	@Override
//	public Iterator<ObsPos> getObservationIterator(int dsIx, Integer kIndex) {
//		MVStoreDataset ds = storage.getDataset(dsIx);
//
//		return new Iterator<ObsPos>() {
//			Iterator<ObsPos> inner = ds.getObservationIndexIterator(kIndex);
//
//			@Override
//			public boolean hasNext() {
//				return inner.hasNext();
//			}
//
//			@Override
//			public ObsPos next() {
//				return inner.next();
//			}
//		};
//	}
//
//	/**
//	 * Return the observation for the given index
//	 */
//	@Override
//	public Observation getObservation(int dsIx, ObsPos obsPos) {
//		MVStoreDataset ds = storage.getDataset(dsIx);
//
//		return ds.getObservation(obsPos);
//	}
}
