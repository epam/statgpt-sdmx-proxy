package io.sdmx.core.data.engine.writer;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.object.SeriesUtil;

/**
 * <p>A strange little animal designed to support publication tables, the concept is this
 *
 * <p>A user has a basket of wildcarded series and they want to know which codes are valid for the wildcarded
 * dimensions.
 *
 * <p>The user may want to pick a code in one dimension, and then know which codes remain valid in the other dimension
 *
 * <p>They may also be interested in the start / end period.
 *
 * <p>This Data Writer Engine captures the information about which values are valid for the dimensions that the user is interested in,
 * and then acts as a engine which can be asked questions about what remains valid based on code choices
 *
 */
public class SubConstraintDataWriterEngine implements ISeriesObsDataWriterEngine {

	private int variableSize;
	private Map<String, Integer> dimPos = new HashMap<>();
	private Map<String, Set<String>> validValues = new HashMap<>();
	private String[] currentSeries;
	private Set<String> series = new HashSet<>();

	private boolean hasTimeDimension;
	private String periodTo;
	private String periodFrom;
	
	private boolean storeObsTime;
	
	private int seriesCount;
	
	
	public SubConstraintDataWriterEngine(Collection<String> variableDimensions, boolean storeObsTime) {
		this.storeObsTime = storeObsTime;
		if(variableDimensions != null) {
			int i=0;
			for(String dimId : variableDimensions) {
				if(!dimId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
					dimPos.put(dimId, i);
					i++;
				}
			}
			variableSize = i;
		}
	}

	@Override
	public void writeHeader(HeaderBean header) {}


	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		this.hasTimeDimension = structures.getDataStructure().getTimeDimension() != null;		
	}



	@Override
	public void writeKey(Keyable key) {
		seriesCount++;
		currentSeries = new String[variableSize];
		for(KeyValue kv : key.getKey()) {
			writeSeriesKeyValue(kv.getConcept(), kv.getCode());
		}
		String asStr = SeriesUtil.toSeriesKey(currentSeries);
		series.add(asStr);
	}

	public int getSeriesCount() {
		return seriesCount;
	}

	private void writeSeriesKeyValue(String id, String value) {
		Integer pos = dimPos.get(id);
		if(pos != null) {
			currentSeries[pos] = value;
			Set<String> values = validValues.get(id);
			if(values == null) {
				values = new HashSet<>();
				validValues.put(id, values);
			}
			values.add(value);
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		if(storeObsTime) {
			processObsTime(obs.getDimensionValue());
			if(hasTimeDimension && obs.getSdmxObsTime() != null) {
				processObsTime(obs.getSdmxObsTime().getDateInSdmxFormat());
			}
		}
	}

	private void processObsTime(String timePeriod) {
		if(periodFrom == null) {
			periodFrom = timePeriod;
			periodTo = timePeriod;
		} else {
			//The new time period is before the earliest we have recorded
			if(periodFrom.compareTo(timePeriod) > 0) {
				this.periodFrom = timePeriod;
			}
			//The new time period is later then the latest time period we have recoded
			//Reset the series set, as any previous series are for an older set of data
			int compare = periodTo.compareTo(timePeriod);
			if(compare < 0) {
				periodTo = timePeriod;
				series = new HashSet<>();
			} else if(compare > 0) {
				return;
			}
		}
	}

	public String[] getDimensions() {
		String[] returnArray = new String[variableSize];
		for(String dimId : dimPos.keySet()) {
			returnArray[dimPos.get(dimId)] = dimId;
		}
		return returnArray;
	}

	public Set<String> getSeries() {
		return series;
	}

	public Set<String> getValidValues(String dimId) {
		return validValues.get(dimId);
	}

	public String getPeriodTo() {
		return periodTo;
	}

	public String getPeriodFrom() {
		return periodFrom;
	}

	@Override
	public void close(FooterMessage... footer) {
		//Makes collections immutable
		for(String dimId : validValues.keySet()) {
			Set<String> values = validValues.get(dimId);
			if(values != null) {
				validValues.put(dimId, Collections.unmodifiableSet(values));
			}
		}
		validValues = Collections.unmodifiableMap(validValues);
		series = Collections.unmodifiableSet(series);
	}


}
