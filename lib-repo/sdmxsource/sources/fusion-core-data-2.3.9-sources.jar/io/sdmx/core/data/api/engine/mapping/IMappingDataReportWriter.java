package io.sdmx.core.data.api.engine.mapping;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Processes mapped and unmapped rows
 */
public interface IMappingDataReportWriter {
	
	/**
	 * The mapping rules which are being used for this mapping report
	 * @param mappingRules
	 */
	void writeMappingRules(MappingRules mappingRules);
	
	
	/**
	 * Writes the mapped structures
	 * @param inputStructures
	 * @param outputStructures
	 */
	void writeMappedStructures(IDatasetStructures inputStructures, IDatasetStructures outputStructures);
	
	/**
	 * 
	 * @param inputRow 
	 * @param outputRow
	 * @param validityPeriod the validity period of the outputRow
	 * @param validationErrors if any validaiton errors were reported on the the Obs/Key
	 */
	void writeMappedRow(IDataRow inputRow, IDataRow outputRow, SdmxPeriod validityPeriod,  Map<FusionError, KeyValue> validationErrors);

	/**
	 * 
	 * @param inputRow
	 * @param outputRow
	 * @param validityPeriod
	 * @param unmappedComponents
	 */
	void writeUnMappedRow(IDataRow inputRow, IDataRow outputRow, SdmxPeriod validityPeriod, Set<IComponentMapping> unmappedComponents);
	
	/**
	 * Closes the report writer
	 */
	void close();
	
}
