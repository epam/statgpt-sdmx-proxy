package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.MandatoryComponentsValidationEngine;

public class MandatoryComponentsValidationFactory implements DataValidatorFactory {

    @Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
        return new MandatoryComponentsValidationEngine(dsi);
    }

    @Override
    public String getName() {
        return "Mandatory Components";
    }

	@Override
	public String getId() {
		return "MandatoryComponents";
	}

	@Override
	public String getDescription() {
		return "Ensures all Measures and Attributes, as defined in the Data Structure Definition (DSD), are reported if they are marked as Mandatory.";
	}

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return false;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return true;
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.IGNORE;
	}

	@Override
	public int hashCode() {
		return "MandatoryComponentsValidationFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof MandatoryComponentsValidationFactory;
	}
}