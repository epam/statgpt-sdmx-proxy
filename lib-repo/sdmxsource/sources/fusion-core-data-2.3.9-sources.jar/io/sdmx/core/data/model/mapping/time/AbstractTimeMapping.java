package io.sdmx.core.data.model.mapping.time;

import java.text.DateFormat;
import java.util.Date;
import java.util.Map;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.core.data.api.model.mapping.ITimeMapping;
import io.sdmx.core.data.model.mapping.explain.ExplainMapComponent;
import io.sdmx.core.data.util.MappingUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.DateUtil;


public abstract class AbstractTimeMapping implements ITimeMapping  {
	private TIME_FORMAT outputFrequency;
	private DateFormat outputDateFormat;
	private Map<String, DateFormat> dfMap;
	private boolean outputRequired;
	
	private ITimeComponentMapBean mappingRules;

	/**
	 * 
	 * @param mappingRules
	 * @param dfMap optional - in the case the output frequency id is non-SDMX, the map contains the formatting rules
	 */
	public AbstractTimeMapping(ITimeComponentMapBean mappingRules, Map<String, DateFormat> dfMap, boolean outputRequired) {
		this.mappingRules = mappingRules;
		this.dfMap = dfMap;
		if(mappingRules.getOutputFrequencyId() != null) {
			if(TIME_FORMAT.isValidCodeId(mappingRules.getOutputFrequencyId())) {
				this.outputFrequency = TIME_FORMAT.getTimeFormatFromCodeId(mappingRules.getOutputFrequencyId());
			} else {
				this.outputDateFormat = dfMap.get(mappingRules.getOutputFrequencyId());
			}
		}
		this.outputRequired = outputRequired;
	}
	
	/**
	 * @return ExplainMapComponent with source and target
	 */
	protected ExplainMapComponent getExplainMapComponent() {
		return new ExplainMapComponent(CollectionUtil.toList(getSourceComponent()), CollectionUtil.toList(getTargetComponent()));
	}

	@Override
	public boolean outputRequired() {
		return outputRequired;
	}

	@Override
	public String getSourceComponent() {
		return mappingRules.getSourceComponent();
	}
	
	@Override
	public String getTargetComponent() {
		return mappingRules.getTargetComponent();
	}

	@Override
	public String getFrequencyComponent() {
		return mappingRules.getOutputFrequencyDimId();
	}
	
	//TODO move to start, end, mid period!, also year start
	String formatDate(Date date, String freqId) {
		//If an explict frequency is passed in, use it
		if(freqId != null) {
			return mapFromFreqId(date, freqId);
		}
		//If the output frequency is known, use it
		if(outputFrequency != null) {
			return DateUtil.formatDate(date, outputFrequency);
		}
		//If the date format is known, use it
		if(outputDateFormat != null) {
			return outputDateFormat.format(date);
		}
		return null;  //not enough information to format the date
	}
	
	private String mapFromFreqId(Date date, String freqId) {
		if(dfMap != null && dfMap.containsKey(freqId)) {
			DateFormat df = dfMap.get(freqId);
			return df.format(date);
		}
		if(TIME_FORMAT.isValidCodeId(freqId)) {
			return DateUtil.formatDate(date, TIME_FORMAT.getTimeFormatFromCodeId(freqId));
		}
		return null;
	}
}
