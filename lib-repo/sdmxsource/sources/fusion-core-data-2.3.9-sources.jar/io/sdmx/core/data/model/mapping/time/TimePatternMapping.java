package io.sdmx.core.data.model.mapping.time;

import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch.MAP_RULE_TYPE;
import io.sdmx.core.data.model.mapping.explain.ExplainMapComponent;
import io.sdmx.core.data.model.mapping.explain.ExplainMapMatch;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class TimePatternMapping extends AbstractTimeMapping  {
	private SimpleDateFormat pattern;

	public TimePatternMapping(ITimePatternMapBean mappingRules, Map<String, DateFormat> dfMap, boolean outputRequired) {
		super(mappingRules, dfMap, outputRequired);
		this.pattern = DateUtil.getDateFormatter(mappingRules.getPattern());
	}

	@Override
	public IExplainMapComponent explain(String sourceValue, String freq) {
		ExplainMapComponent comp = super.getExplainMapComponent();
		ExplainMapMatch match = new ExplainMapMatch();
		match.setRuleType(MAP_RULE_TYPE.TIME_PATTERN);
		match.setInput(sourceValue);
		match.setComponent(getTargetComponent());
		comp.addMatch(SdmxPeriodImpl.ALL_PERIODS, match);
		comp.addOutput(SdmxPeriodImpl.ALL_PERIODS, KeyValueImpl.getInstance(getTargetComponent(), getMappedValue(sourceValue, freq)));
		getMappedValue(sourceValue, match, freq);
		return comp;
	}

	@Override
	public String getMappedValue(String sourceValue, String freq) {
		return getMappedValue(sourceValue, null, freq);
	}

	private String getMappedValue(String sourceValue, ExplainMapMatch match, String freq) {
		ParsePosition p = new ParsePosition(0);
		Date outputDate = pattern.parse(sourceValue, p);
		if(outputDate != null) {
			if(match != null) {
				match.setMatch(pattern.toPattern());
			}
		}
		if(outputDate != null) {
			return formatDate(outputDate, freq);
		}
		return null;
	}
}
