package io.sdmx.core.data.model.kryo;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class HeaderSerializer extends Serializer<HeaderBean> {
	private static final HeaderSerializer INSTANCE = new HeaderSerializer();
	private static final ListSerializer<DatasetStructureReferenceBean> datasetStructureSerializer = new ListSerializer<DatasetStructureReferenceBean>(DatasetStructureReferenceSerializer.getInstance());
	private HeaderSerializer() {}

	public static HeaderSerializer getInstance() {
		return INSTANCE;
	}
	
	@Override
	public void write(Kryo kryo, Output output, HeaderBean object) {
		kryo.writeObject(output, object == null ? -1 : 1);  
		if(object != null) {
			kryo.writeObjectOrNull(output, object.getAction() == null ? null : object.getAction().toString(), String.class);
			kryo.writeObject(output, new HashMap<>(object.getAdditionalAttributes())); 
			kryo.writeObjectOrNull(output, object.getDataProviderReference() == null ? null : object.getDataProviderReference().getURN(), String.class);
			kryo.writeObjectOrNull(output, object.getDatasetId(), String.class);
			kryo.writeObjectOrNull(output, object.getEmbargoDate(), Date.class);
			kryo.writeObjectOrNull(output, object.getExtracted(), Date.class);
			kryo.writeObjectOrNull(output, object.getId(), String.class);
			kryo.writeObjectOrNull(output, object.getName(), TextTypeWrapperListSerializer.getInstance());
			kryo.writeObjectOrNull(output, object.getPrepared(), Date.class);
			kryo.writeObjectOrNull(output, object.getReceiver(), PartyBeanListSerializer.getInstance());  
			kryo.writeObjectOrNull(output, object.getReportingBegin(), Date.class);  
			kryo.writeObjectOrNull(output, object.getReportingEnd(), Date.class);  
			kryo.writeObjectOrNull(output, object.getSender(),  PartyBeanSerializer.getInstance());   
			kryo.writeObjectOrNull(output, object.getSource(), TextTypeWrapperListSerializer.getInstance());
			kryo.writeObjectOrNull(output, object.getStructures(), datasetStructureSerializer);
			kryo.writeObject(output, object.isTest());
		}
	}

	@Override
	public HeaderBean read(Kryo kryo, Input input, Class<? extends HeaderBean> type) {
		boolean isNull = kryo.readObject(input, Integer.class) == -1;
		if(isNull) {
			return null;
		}
		String actionString = kryo.readObjectOrNull(input, String.class);
		HashMap<String, String> additionalAttributes = kryo.readObject(input, HashMap.class);
		String dataProvider = kryo.readObjectOrNull(input, String.class);
		String datasetId = kryo.readObjectOrNull(input, String.class);
		Date embargoDate = kryo.readObjectOrNull(input, Date.class);
		Date extractedDate = kryo.readObjectOrNull(input, Date.class);
		String id = kryo.readObjectOrNull(input, String.class);
		List<TextTypeWrapper> name = kryo.readObjectOrNull(input, List.class, TextTypeWrapperListSerializer.getInstance());
		Date prepared = kryo.readObjectOrNull(input, Date.class);
		List<PartyBean> receiver = kryo.readObjectOrNull(input, List.class, PartyBeanListSerializer.getInstance());
		Date reportingBeing = kryo.readObjectOrNull(input, Date.class);
		Date reportingEnd = kryo.readObjectOrNull(input, Date.class);
		PartyBean sender = kryo.readObjectOrNull(input, PartyBean.class, PartyBeanSerializer.getInstance());
		List<TextTypeWrapper> source = kryo.readObjectOrNull(input,  List.class, TextTypeWrapperListSerializer.getInstance());
		List<DatasetStructureReferenceBean> structures = kryo.readObjectOrNull(input, List.class, datasetStructureSerializer);
		boolean isTest = kryo.readObject(input, Boolean.class);
		
		return new HeaderBeanImpl(additionalAttributes, 
									structures, 
									dataProvider == null ? null : URN.builder(dataProvider).buildSingle(DataProviderBean.class), 
									actionString == null ? null : DATASET_ACTION.getAction(actionString), 
									id, 
									datasetId, 
									embargoDate, 
									extractedDate, 
									prepared, 
									reportingBeing, 
									reportingEnd, 
									name, 
									source, 
									receiver, 
									sender, 
									isTest);
	}
}
