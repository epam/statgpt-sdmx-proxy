package io.sdmx.core.data.model.dataset.mvstore;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

public class MVStoreFlatDataset {
    private static final Logger LOG = LoggerFactory.getLogger(MVStoreFlatDataset.class);
    
 // map position to keyable for sequential access in input order
    private MVMap<Integer, IDataRow> rows;
    
    /**
     * Build a MVStoreDataset instance from scratch.
     */
    public MVStoreFlatDataset(MVStore db, int index, IDatasetStructures structures) {
        
    }
}
