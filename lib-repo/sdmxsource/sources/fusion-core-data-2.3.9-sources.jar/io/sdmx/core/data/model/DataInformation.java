package io.sdmx.core.data.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.comparator.SdmxYearWeekComparator;

public class DataInformation implements Serializable {
	private static final long serialVersionUID = 4279234605066137963L;

	private boolean hasReportPeriodInfo;
	private List<DatasetInfo> info = new ArrayList<>();

	public DataInformation(List<DatasetInfo> info) {
		this.info = info;
	}

	public DataInformation(DataReaderEngine dre) {
		this(dre, false);
	}

	public DataInformation(IFlatDataReaderEngine dre, boolean includeReportingPeriods) {
		if (dre == null) {
			throw new IllegalArgumentException("No DataReaderEngine provided");
		}
		this.hasReportPeriodInfo = includeReportingPeriods;
		boolean isTimeSeries = false;
		IDataRow lastRow = null;
		CurrentInfo currentInfo = null;
		List<String> measures = null;
		while(dre.moveNextRow()) {
			IDataRow row = dre.getCurrentRow();
			boolean newDataset = lastRow == null ? true : lastRow.getDatasetStructures() != row.getDatasetStructures();
			boolean newSeries  = lastRow == null ? true : lastRow.seriesMatch(row);
			if(newDataset) {
				IDatasetStructures structures = row.getDatasetStructures();
				DataStructureBean dsd = structures.getDataStructure();
				isTimeSeries = dsd.getTimeDimension() != null;
				if(currentInfo != null) {
					currentInfo.close();
				}
				currentInfo = new CurrentInfo(dre.readDatasetHeader(), structures);
				measures = SdmxCollectionUtil.identifiablesIdList(dsd.getMeasures());
			}
			if(newSeries) {
				if(row.isPartialKey()) {
					currentInfo.addGroup(row.getShortCode());
				} else {
					currentInfo.addKey(row.getShortCode());
				}
			}
			if(isTimeSeries && hasReportPeriodInfo) {
				String timePeriod = row.getRowData().get(DimensionBean.TIME_DIMENSION_FIXED_ID);
				currentInfo.addTimePeriod(timePeriod);
			}
			for(String measure : measures) {
				// DEV-1732 If any measure has a value, it counts as 1 observation
				if(row.getRowData().containsKey(measure)) {
					currentInfo.addObservation();
					break;
				}
			}
		}
		if(currentInfo != null) {
			currentInfo.close();
		}
	}

	public DataInformation(DataReaderEngine dre, boolean includeReportingPeriods) {
		if (dre == null) {
			throw new IllegalArgumentException("No DataReaderEngine provided");
		}
		this.hasReportPeriodInfo = includeReportingPeriods;
		dre.reset();
		while(dre.moveNextDataset()) {
			IDatasetStructures structures = new DatasetStructures(dre.getDataStructure(), dre.getDataFlow(), dre.getProvisionAgreement(), null);
			CurrentInfo currentInfo = new CurrentInfo(dre.getCurrentDatasetHeaderBean(), structures);
			boolean isTimeSeries = dre.getDataStructure().getTimeDimension() != null;

			while(dre.moveNextKeyable()) {
				Keyable currentKey = dre.getCurrentKey();
				if(currentKey.isSeries()) {
					currentInfo.addKey(currentKey.getShortCode());
				} else {
					currentInfo.addGroup(currentKey.getShortCode());
				}
				while(dre.moveNextObservation()) {
					currentInfo.addObservation();
					if(includeReportingPeriods == true && isTimeSeries) {
						Observation obs = dre.getCurrentObservation();
						currentInfo.addTimePeriod(obs.getDimensionValue());
					}
				}
			}
			currentInfo.close();
		}
	}
	
	
	private class CurrentInfo {
		Set<String> keySet = new HashSet<>();
		Set<String> groupSet = new HashSet<>();
		private Set<String> processedDates = null;
		private Set<String> unparseableDates = null;
		private Map<TIME_FORMAT, Set<String>> frequencyToPeriods = null; //Map of frequency to reported periods
		private DatasetInfo currentInfo;
		
		public CurrentInfo(DatasetHeaderBean headers, IDatasetStructures structures) {
			this.currentInfo = new DatasetInfo(headers, structures);
			info.add(currentInfo);
			if(hasReportPeriodInfo == true) {
				processedDates = new HashSet<>();
				unparseableDates = new HashSet<>();
				frequencyToPeriods = new HashMap<>();
			}
		}
		
		public void addKey(String key) {
			this.keySet.add(key);
		}
		
		public void addGroup(String key) {
			this.groupSet.add(key);
		}
		
		public void addObservation() {
			this.currentInfo.addObservation();
		}

		public void addTimePeriod(String timePeriod) {
			if(!hasReportPeriodInfo || timePeriod == null) {
				return;
			}
			if(!processedDates.contains(timePeriod)) {
			    if (unparseableDates.contains(timePeriod)) {
			        return;
			    }
			    if(!DateUtil.isSdmxDate(timePeriod)) {
			    	unparseableDates.add(timePeriod);
			    } else {
			    	SdmxDate date;
			    	try {
			    		date = SdmxDateImpl.getSdmxDate(timePeriod);
			    	} catch (Exception e) {
			    		// If unable to parse this date, add to the set of unparseableDates so it is not (expensively) re-evaluated
			    		unparseableDates.add(timePeriod);
			    		return;
			    	}
			    	TIME_FORMAT frequency = date.getTimeFormatOfDate();
			    	if (frequency != null && frequency.equals(TIME_FORMAT.MONTH)) {
			    		// Month values can be with or without an 'M' (e.g. 2000-12 or 2000-M12).
			    		// To aid comparison of dates, in the case where a dataset has reported data using both
			    		// formats, remove any 'M' values from 'timePeriod'.
			    		if (timePeriod.substring(5,6).equals("M") ) {
			    			timePeriod = timePeriod.substring(0,5) + timePeriod.substring(6);
			    		}
			    	}
			    	
			    	Set<String> reportedDates = frequencyToPeriods.get(frequency);
			    	if(reportedDates == null) {
			    	    if (frequency == TIME_FORMAT.WEEK) {
			    	        reportedDates = new TreeSet<>(new SdmxYearWeekComparator());
			    	    } else {
			    	        reportedDates = new TreeSet<>();
			    	    }
			    		frequencyToPeriods.put(frequency, reportedDates);
			    	}
			    	reportedDates.add(timePeriod);
			    }
			}
		}
		
		public void close() {
			currentInfo.setGroups(groupSet.size());
			currentInfo.setKeys(keySet.size());
			Map<TIME_FORMAT, SdmxPeriod> reportingPeriods = new HashMap<>();
			if(hasReportPeriodInfo) {
				for(TIME_FORMAT freq : frequencyToPeriods.keySet()) {
					Set<String> sortedDates = frequencyToPeriods.get(freq);
					List<String> asList = sortedDates.stream().collect(Collectors.toList());
					String dateFrom = asList.get(0);
					String dateTo = asList.get(asList.size()-1);
					SdmxPeriod period = new SdmxPeriodImpl(dateFrom, dateTo);
					reportingPeriods.put(freq, period);
				}
			}
			currentInfo.setReportingPeriods(reportingPeriods);
		}
	}

	public DatasetInfo getDatasetInfo(int idx) {
		try {
			return info.get(idx);
		} catch(ArrayIndexOutOfBoundsException e) {
			throw new SdmxException("Could not return information for dataset at index '"+idx+"' max index="+(info.size()-1));
		}
	}


	public int getDatasets() {
		return info.size();
	}

	public boolean hasReportPeriodInfo() {
		return hasReportPeriodInfo;
	}

	/**
	 * Returns an immutable map of reported periods for each frequency
	 * @return
	 */
	public Map<TIME_FORMAT, SdmxPeriod> getReportingPeriods(int idx) {
		return getDatasetInfo(idx).getReportingPeriods();
	}

	/**
	 * Returns the number of series keys for the dataset at the given index
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public int getNumberOfSeriesKeys(int idx) {
		return getDatasetInfo(idx).getKeys();
	}

	/**
	 * Returns the number of groups for the dataset at the given index
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public int getGroups(int idx) {
		return getDatasetInfo(idx).getGroups();
	}

	/**
	 * Returns the number of observations for the dataset at the given index
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public int getNumberOfObservations(int idx) {
		return getDatasetInfo(idx).getObservations();
	}

	/**
	 * Returns the  dataset header for the dataset at the given index
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public DatasetHeaderBean getHeader(int idx) {
		return getDatasetInfo(idx).getHeaders();
	}

	/**
	 * Returns the provision agreement for the dataset at the given index.  This may be null if the dataset did not
	 * reference a provision agreement.
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public ProvisionAgreementBean getProvision(int idx) {
		return getDatasetInfo(idx).getProvision();
	}

	/**
	 * Returns the dataflow for the dataset at the given index.  This may be null if the dataset did not
	 * reference a dataflow.
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public DataflowBean getFlow(int idx) {
		return getDatasetInfo(idx).getFlow();
	}

	/**
	 * Returns the dsd for the dataset at the given index. This will not be null.
	 * @param idx the dataset index (zero indexed)
	 * @return
	 */
	public DataStructureBean getDsd(int idx) {
		return getDatasetInfo(idx).getDsd();
	}



}