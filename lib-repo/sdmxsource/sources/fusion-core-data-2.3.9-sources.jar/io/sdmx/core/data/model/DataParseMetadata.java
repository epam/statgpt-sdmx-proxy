package io.sdmx.core.data.model;

import java.io.OutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;

/**
 * Contains information required for data parsing.
 */
public class DataParseMetadata {
	private ReadableDataLocation sourceData; 
	private OutputStream out; 
	private DataStructureBean dataStructure;
	private SDMX_SCHEMA outputSchemaVersion;
	
	public DataParseMetadata(ReadableDataLocation sourceData, 
							 OutputStream out,
							 SDMX_SCHEMA outputSchemaVersion,
							 DataStructureBean keyFamily) {
		this.sourceData = sourceData;
		this.out = out;
		this.dataStructure = keyFamily;
		this.outputSchemaVersion = outputSchemaVersion;
	}

	public ReadableDataLocation getSourceData() {
		return sourceData;
	}

	public OutputStream getOut() {
		return out;
	}
	
	public DataStructureBean getDataStructure() {
		return dataStructure;
	}

	public SDMX_SCHEMA getOutputSchemaVersion() {
		return outputSchemaVersion;
	}
}
