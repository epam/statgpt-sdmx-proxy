package io.sdmx.core.data.model.mapping.time;

import java.text.DateFormat;

import io.sdmx.api.date.TIME_FORMAT;

/**
 * <p>Maps the number of SDMX Periods after a given time period, where the time period is expressed as a pattern, the 
 * SDMX Period to increment is expressed using the SDMX {@link TIME_FORMAT} id followed by the number of Periods.</p>
 * 
 * <p>Example: 2007-M01 would be expressed using the pattern yyyy-Mnn</p>
 * <p>Example: M01 2007 would be expressed using the pattern Mnn yyyy</p>
 * <p>Example: M01 D01 2007 would be expressed using the pattern Mnn Dnn yyyy</p>
 */
public class SdmxEpochMapping {
	private DateFormat df; 
	private String pattern;
	
	private TIME_FORMAT[] periods;
	
	
	public SdmxEpochMapping(String pattern) {
		//1. Remove the 
	}


	
}
