package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;

/**
 * Serialization for {@link IDatasetAttributes}
 */
public class DT_DatasetAttributes extends DT_Attributable<IDatasetAttributes, IDatasetAttributes> {
	
	@Override
	/**
	 * Generics K is the same as V
	 */
	protected IDatasetAttributes build(IDatasetAttributes built) {
		return built;
	}

	@Override
	/**
	 * No additional information required over and above Attributable
	 */
	protected AttributableBuilder<IDatasetAttributes> getBuilder(ByteBuffer byteBuffer) {
		return DatasetAttributes.builder();
	}

	@Override
	/**
	 * No additional information required over and above Attributable
	 */
	public int getMemory(IDatasetAttributes x) {
		return super.getMemory(x);
	}

	@Override
	public IDatasetAttributes[] createStorage(int size) {
		return new IDatasetAttributes[size];
	}
	
}
