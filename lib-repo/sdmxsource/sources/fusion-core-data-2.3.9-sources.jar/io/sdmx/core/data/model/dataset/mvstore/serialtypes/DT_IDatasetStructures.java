package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Serialization for IDatasetStructures.
 */
public class DT_IDatasetStructures extends BasicDataType<IDatasetStructures> {
  private final SdmxBeanRetrievalManager brm;
  private final DT_String strDT;
  

  public DT_IDatasetStructures(SdmxBeanRetrievalManager brm) {
    this.brm = brm;
    this.strDT = DT_String.getInstance();
  }

  @Override
  public int getMemory(IDatasetStructures x) {
    int size = 1; // null/object selector

    if (x != null) {
      final DataStructureBean dsBean = x.getDataStructure();
      final DataflowBean dfBean = x.getDataflow();
      final ProvisionAgreementBean paBean = x.getProvisionAgreement();
      final DataProviderBean dpBean = x.getDataProvider();

      size += strDT.getMemory((dsBean == null) ? null : dsBean.getUrn());
      size += strDT.getMemory((dfBean == null) ? null : dfBean.getUrn());
      size += strDT.getMemory((paBean == null) ? null : paBean.getUrn());
      size += strDT.getMemory((dpBean == null) ? null : dpBean.getUrn());
    }

    return size;
  }

  @Override
  public void write(WriteBuffer buf, IDatasetStructures x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      final DataStructureBean dsBean = x.getDataStructure();
      final DataflowBean dfBean = x.getDataflow();
      final ProvisionAgreementBean paBean = x.getProvisionAgreement();
      final DataProviderBean dpBean = x.getDataProvider();

      strDT.write(buf, (dsBean == null) ? null : dsBean.getUrn());
      strDT.write(buf, (dfBean == null) ? null : dfBean.getUrn());
      strDT.write(buf, (paBean == null) ? null : paBean.getUrn());
      strDT.write(buf, (dpBean == null) ? null : dpBean.getUrn());
    }
  }

  @Override
  public IDatasetStructures read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    IDatasetStructures x = null;

    if (!isNull) {
      IURNAbsolute<DataStructureBean> dsRef = URN.buildOrNull(strDT.read(buf), DataStructureBean.class);
      IURNAbsolute<DataflowBean> dfRef = URN.buildOrNull(strDT.read(buf), DataflowBean.class);
      IURNAbsolute<ProvisionAgreementBean> paRef = URN.buildOrNull(strDT.read(buf), ProvisionAgreementBean.class);
      IURNAbsolute<DataProviderBean> dpRef = URN.buildOrNull(strDT.read(buf), DataProviderBean.class);
      
      DataStructureBean dsBean = brm.getBean(dsRef);
      DataflowBean dfBean = (dfRef == null) ? null : brm.getBean(dfRef);
      ProvisionAgreementBean paBean = (paRef == null) ? null : brm.getBean(paRef);
      DataProviderBean dpBean = (dpRef == null) ? null : brm.getBean(dpRef);

      x = new DatasetStructures(dsBean, dfBean, paBean, dpBean);
    }
    return x;
  }
  
  @Override
  public IDatasetStructures[] createStorage(int size) {
    return new IDatasetStructures[size];
  }
}
