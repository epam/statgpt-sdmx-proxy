package io.sdmx.core.data.model.dataset.mvstore;

import java.io.File;

import org.h2.mvstore.MVStore;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;

/**
 * This class represents a dataset collection stored in a MVStore file.
 */
public class MVStoreDatasetStorage extends MVStoreAbstractDatasetStorage {


	public static MVStoreDatasetStorage createInstance(File file) {
		return new MVStoreDatasetStorage(null, file);
	}

	public static MVStoreDatasetStorage reopenInstance(SdmxBeanRetrievalManager brm, File file) {
		if (!file.exists())
			throw new RuntimeException("File " + file + "does not exist.");

		return new MVStoreDatasetStorage(brm, file);
	}
	
	private MVStoreDatasetStorage(SdmxBeanRetrievalManager brm, File file) {
		super(brm, file);
	}
	
	@Override
	protected MVStoreAbstractDataset retrieveInstance(MVStore store, int index, SdmxBeanRetrievalManager brm) {
		return new MVStoreDataset(store, index, brm);
	}

	
}
