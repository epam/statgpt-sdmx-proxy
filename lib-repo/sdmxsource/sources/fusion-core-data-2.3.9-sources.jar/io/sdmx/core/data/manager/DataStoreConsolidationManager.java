package io.sdmx.core.data.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.model.consolidation.ConsolidationOptions;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.errorhanlder.IContradictoryDuplicateHandler;
import io.sdmx.core.data.engine.reader.DatasetAttributeOverrideDataReaderEngine;
import io.sdmx.core.data.engine.writer.MVStoreDataWriterEngine;
import io.sdmx.core.data.model.dataset.mvstore.ObservationWrap;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_Keyable;
import io.sdmx.core.data.model.dataset.mvstore.serialtypes.DT_ObservationWrap;
import io.sdmx.core.data.util.DataConsolidationUtil;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.engine.data.IDatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;
import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;
import io.sdmx.core.sdmx.engine.data.DatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.model.MVDuplicateBehaviour;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.core.sdmx.util.MVStoreUtil;
import io.sdmx.im.data.AbstractAttributable;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SORT_ORDER;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.object.StringUtil;

public class DataStoreConsolidationManager extends AbstractConsolidationManager {
	private static final DT_String strDT = DT_String.getInstance();
	private static final DT_Integer intDT = DT_Integer.getInstance(false);
	
	private MVDuplicateBehaviour defaultDuplicateBehaviour = MVDuplicateBehaviour.USE_LAST_VALUE;
	
	@Override
	public DataReaderEngine consolidateReader(DataReaderEngine dre, DataValidationErrorHandler errorHandler, IConsolidationOptions consolidationOptions) {
		List<DuplicateDetails> duplicatedDetails = getDuplicateDetails(dre);
		
		if (consolidationOptions == null) {
			// To avoid repeated null checks later, default to a defined behaviour
			consolidationOptions = new ConsolidationOptions(defaultDuplicateBehaviour, SORT_ORDER.NATURAL);
		}
		
		try {
			boolean duplicates = false;
			boolean duplicateAttributes = false;
			for(DuplicateDetails details : duplicatedDetails) {
				if(details.hasDuplicates) {
					duplicates = true;
				}
				if(details.duplicateAttributes) {
					duplicateAttributes = true;
				}
			}
			if(!duplicates) {
				dre.reset();
				if(duplicateAttributes) {
					//Just need to consolidate the dataset attributes, can be done via a proxy reader
					int dsIdx = -1;
					Map<Integer, List<KeyValue>> dsAttributes = new HashMap<>(duplicatedDetails.size());
					for(DuplicateDetails details : duplicatedDetails) {
						dsIdx++;
						
						List<KeyValue> dsAttr = details.dsAttributes.getAttributes();
						if(details.duplicateAttributes) {
							dsAttr = consolidateDatasetAttributes(dsAttr, dsIdx, errorHandler, consolidationOptions);
							
						}
						dsAttributes.put(dsIdx, dsAttr);
					}
					return new DatasetAttributeOverrideDataReaderEngine(dsAttributes, dre);
				}
				return dre;  //no consolidation required
			}
			return consolidate(duplicatedDetails, dre, errorHandler, consolidationOptions);
		} finally {
			for(DuplicateDetails details : duplicatedDetails) {
				details.close();
			}
		}
	}
	
	/**
	 * Iterates the dataset to discover if there are duplicate keys/obs, and records where the duplicates are
	 * @return duplicate details per dataset
	 */
	private List<DuplicateDetails> getDuplicateDetails(DataReaderEngine dre)  {
		List<DuplicateDetails> returnList = new ArrayList<>();
		dre.reset();
		while(dre.moveNextDataset()) {
			DuplicateDetails returnDetails = new DuplicateDetails(dre.getDatasetAttributes());
			returnList.add(returnDetails);
			if(dre.getCurrentDatasetHeaderBean() != null) {
				if(!DataConsolidationUtil.requiresConsolidation(dre.getCurrentDatasetHeaderBean().getAction())) {
					continue;  //continue to the next dataset
				}
			}
			//A map of short code to the number of duplicate keys
			while(dre.moveNextKeyable()) {
				Keyable key = dre.getCurrentKey();
				returnDetails.registerKey(key);
				if(!returnDetails.hasDuplicates) {
					//If there are no duplicates found yet, check the obs just to make sure
					Set<String> obsKeys = new HashSet<>();
					while(dre.moveNextObservation()) {
						Observation obs = dre.getCurrentObservation();
						if(obsKeys.contains(obs.getDimensionValue())) {
							returnDetails.hasDuplicates = true;
							break;
						} else {
							obsKeys.add(obs.getDimensionValue());
						}
					}
				}
			}
		}
		return returnList;
	}
	
	private class DuplicateDetails {
		private final IMVStore db;
		private MVMap<String, Integer> keyCountMap; //A map of keys to the number of duplicates, used to create a list of the correct size later
		private boolean hasDuplicates = false;
		private boolean duplicateAttributes = false;
		private IDatasetAttributes dsAttributes;
		
		public DuplicateDetails(IDatasetAttributes dsAttributes) {
			this.dsAttributes = dsAttributes;
			this.db = MVStoreUtil.getStore();  //TODO need a way to delete the file
			this.keyCountMap = MVStoreUtil.openMap("keyableDuplicates", 0, strDT, intDT, db);
			
			if(dsAttributes != null) {
				//TODO This ignores complex content
				if(ObjectUtil.validCollection(dsAttributes.getAttributes())) {
					//Check for duplicates
					Set<String> attrId = new HashSet<>(dsAttributes.getAttributes().size());
					for(KeyValue kv : dsAttributes.getAttributes()) {
						if(attrId.contains(kv.getConcept())) {
							duplicateAttributes = true;
							break;
						}
						attrId.add(kv.getConcept());
					}
				}
			}
		}
		
		private void registerKey(Keyable key) {
			Integer keyCount = keyCountMap.get(key.getShortCode());
			if(keyCount != null) {
				this.hasDuplicates = true;
				keyCount++;
			} else {
				keyCount = 1;
			}
			keyCountMap.put(key.getShortCode(), keyCount);
		}
		
		/**
		 * Closes all resources, deletes the file backing the mv store
		 */
		private void close() {
			db.delete();
		}
	}
	
	private IDatasetStoreContainer getDatasetStoreContainer(DataReaderEngine dre) {
		if(dre instanceof IDatasetStoreDataReaderEngine) {
			return ((IDatasetStoreDataReaderEngine)dre).getDatasetContainer();
		}
		//Copy the dataset to an in-memory store
		dre.reset();
		MVStoreDataWriterEngine dwe = new MVStoreDataWriterEngine(false);
		DataTransformationUtil.copyData(dre, dwe, true, true);
		return dwe.getStorage();
	}
	
	private DataReaderEngine consolidate(List<DuplicateDetails> detailList,
										 DataReaderEngine dre,
										 DataValidationErrorHandler errorHandler,
										 IConsolidationOptions consolidationOptions) {
		//Build an in-memory model for the datasets
		
		IDatasetStoreContainer storeContainer = getDatasetStoreContainer(dre);
		MVStoreDataWriterEngine tmpDataWriter = new MVStoreDataWriterEngine();
		try {
			tmpDataWriter.writeHeader(dre.getHeader());
			for(int dsIdx =0; dsIdx < storeContainer.getDatasetSize(); dsIdx++) {
				DuplicateDetails details = detailList.get(dsIdx);
				IDatasetStore dataset = storeContainer.getDataset(dsIdx);

				
				List<KeyValue> dsAttr = dataset.getDatasetAttributes().getAttributes();  //TODO Ignores Complex content
				if(details.duplicateAttributes) {
					dsAttr = consolidateDatasetAttributes(dsAttr, dsIdx, errorHandler, consolidationOptions);
				}
				IDatasetAttributes datasetAttributes = DatasetAttributes.builder().attributes(dsAttr).build();  //TODO Complex content
				tmpDataWriter.startDataset(dataset.getStructures(), dataset.getHeader(), datasetAttributes); 
				IMVStore db = MVStoreUtil.getStore();
				try {
					consolidateDataset(dataset, details, db.getStore(), dsIdx, tmpDataWriter, errorHandler, consolidationOptions);
				} finally {
					db.delete();
				}
			}
			tmpDataWriter.close();
			return new DatasetStoreDataReaderEngine(tmpDataWriter.getStorage());
		} finally {
			storeContainer.close(true);
		}
	}
	
	private List<KeyValue> consolidateDatasetAttributes(List<KeyValue> attributes,
														int dsIdx,
														DataValidationErrorHandler errorHandler,
														IConsolidationOptions consolidationOptions) {
		AbstractAttributable dsAttributes = new AbstractAttributable(attributes);
		final MVDuplicateBehaviour rule;
		rule = consolidationOptions.getDuplicateBehaviour() != null ? consolidationOptions.getDuplicateBehaviour() : defaultDuplicateBehaviour;
		
		List<KeyValue> returnList = new ArrayList<>();
		IContradictoryDuplicateHandler<AbstractAttributable> duplicateProcess = (errorHandler == null && rule != MVDuplicateBehaviour.PRESERVE_DUPLICATES) ? null : (key, kv1, kv2)-> {
			if(errorHandler != null) {
				DataError de = DataConsolidationUtil.contradictoryDatasetAttribute(this, dsIdx, kv1, kv2);
				errorHandler.handleError(de);
			}
			if(rule == MVDuplicateBehaviour.PRESERVE_DUPLICATES) {
				returnList.add(kv2);
			}
		};
		boolean reverseOrder = rule == MVDuplicateBehaviour.USE_LAST_VALUE;
		List<KeyValue> mergedList = DataConsolidationUtil.mergeAttributes(CollectionUtil.toList(dsAttributes), reverseOrder, duplicateProcess);
		
		if(returnList.size() > 0) {
			mergedList.addAll(returnList);
		}
		return mergedList;
	}
	
	private void consolidateDataset(IDatasetStore dataset,
									DuplicateDetails details,
									MVStore db,
									int dsIdx,
									MVStoreDataWriterEngine tmpDataWriter,
									DataValidationErrorHandler errorHandler,
									IConsolidationOptions consolidationOptions) {
		boolean isDelete = dataset.getHeader() != null ? dataset.getHeader().getAction() == DATASET_ACTION.DELETE : false;
		MVMap<String, Integer> keyCountMap = details.keyCountMap;
		
		DT_Keyable keyDT = new DT_Keyable(dataset.getStructures());
		DT_ObservationWrap obsDT = new DT_ObservationWrap(dataset);
		
		DT_List<ObservationWrap, ObservationWrap> obsListDT = new DT_List<>(obsDT);
		DT_List<Keyable, Keyable> keyListDT = new DT_List<>(keyDT);
		
		Set<String> fullyDeleteKeys = new HashSet<>();
		
		List<String> seriesOrder = new ArrayList<>();
		MVMap<String, List<Keyable>> keyMap = MVStoreUtil.openMap("key", 0, strDT, keyListDT, db);
		MVMap<String, List<ObservationWrap>> obsMap = MVStoreUtil.openMap("obs", 0, strDT, obsListDT, db);  //all the obs for the key
		//TODO how to handle nulls (if keep first, does it merge all values where not null)
		for(int keyIdx=0; keyIdx < dataset.getKeySize(); keyIdx++) {
			Keyable key = dataset.getKeyable(keyIdx);
			String shortCode = key.getShortCode();
			if (fullyDeleteKeys.contains(shortCode)) {
				// Ignore this entry as a full delete for this series was previously encountered
				continue;
			}
			
			Integer duplicateKeyCount = keyCountMap.get(shortCode);
			Iterator<Observation> obsIt = dataset.getObs(keyIdx);
			
			//if(duplicateKeyCount == 1) {
			//	seriesOrder.add(shortCode);
				//No duplicates, write the key
				//tmpDataWriter.writeKey(key);
				//writeObs(tmpDataWriter, obsIt, dsIdx, key, errorHandler, rule);
			//} else {
				//Consolidate all the keys, and store all the obs for each key in a map
				int obsSize = dataset.getObsSize(keyIdx);
				List<Keyable> keys = keyMap.get(shortCode);
				if(keys == null) {
					seriesOrder.add(shortCode);
					keys = new ArrayList<>(duplicateKeyCount);  //create a list of the correct size
					//TODO will this work (i.e. does the mv store care if we create a list of the correct size?)
				}
				keys.add(key);
				keyMap.put(shortCode, keys);  //re-add to mv store

				//Merge new obs into MV mapped list of obs
				List<ObservationWrap> obsList = obsMap.get(shortCode);
				if(obsList == null) {
					obsList = new ArrayList<>(obsSize);
				} else {
					List<ObservationWrap> obsCopy = new ArrayList<>(obsSize+obsList.size());
					obsCopy.addAll(obsList);
					obsList = obsCopy;
				}
				//copy all the obs into the list
				int obsCount = 0;
				while(obsIt.hasNext()) {
					Observation obs = obsIt.next();
					obsCount++;
					if(obs instanceof ObservationWrap) {
						obsList.add((ObservationWrap)obs);
					} else {
						obsList.add(new ObservationWrap(keyIdx, obs));
					}
				}
				obsMap.put(shortCode, obsList);
			//}
			
			if (isDelete && isFullDeletion(key, obsCount)) {
				// Remove any other entries
				keyMap.put(shortCode, Collections.singletonList(key));
				obsMap.remove(shortCode);
				fullyDeleteKeys.add(shortCode);
			}
		}
		
		// Sort keys
		SeriesUtil.sort(seriesOrder, consolidationOptions.getSortOrder());
		
		//Merge duplicates
		for(String shortCode : seriesOrder) {
			List<Keyable> keys = keyMap.get(shortCode);
			
			//Handle preserve duplicates
			//Null if no error handler, otherwise execute the function
			final MVDuplicateBehaviour rule;
			rule = consolidationOptions.getDuplicateBehaviour() != null ? consolidationOptions.getDuplicateBehaviour() : defaultDuplicateBehaviour;
			IContradictoryDuplicateHandler<Keyable> duplicateProcess = (errorHandler == null && rule != MVDuplicateBehaviour.PRESERVE_DUPLICATES) ? null : (key, kv1, kv2)-> {
				if(errorHandler != null) {
					DataError de = DataConsolidationUtil.contradictorySeriesAttribute(this, dsIdx, kv1, kv2,  key);
					errorHandler.handleError(de);
				}
				if(rule == MVDuplicateBehaviour.PRESERVE_DUPLICATES) {
					tmpDataWriter.writeKey(key);
				}
			};
			boolean reverseOrder = rule == MVDuplicateBehaviour.USE_LAST_VALUE;
			Keyable key = DataConsolidationUtil.consolidateKeys(dsIdx, keys, reverseOrder, duplicateProcess);
			tmpDataWriter.writeKey(key);
			List<ObservationWrap> obsList = obsMap.get(key.getShortCode());
			if(ObjectUtil.validCollection(obsList)) {
				writeObs(tmpDataWriter, obsList.iterator(), dsIdx, key, errorHandler, rule, consolidationOptions.getSortOrder());
			}
		}
	}
	
	/**
	 * Writes the observations merges duplicates
	 * @param dwe
	 * @param obsIt
	 */
	private void writeObs(ISeriesObsDataWriterEngine dwe,
						 Iterator<? extends Observation> obsIt,
						 int dsIdx,
						 Keyable key,
						 DataValidationErrorHandler errorHandler,
						 MVDuplicateBehaviour consolidationRule,
						 SORT_ORDER sortOrder) {
		obsIt = consolidateObs(obsIt, dsIdx, key, errorHandler, consolidationRule, sortOrder);
		while(obsIt.hasNext()) {
			dwe.writeObservation(obsIt.next());
		}
	}
	
	/**
	 * Returns a new observation iterator from an observation iterator passed in
	 * @param obsList the obs iterator
	 * @param dsIdx the dataset index
	 * @param key key for the obs
	 * @param errorHandler optional
	 * @param rule
	 * @return
	 */
	private Iterator<Observation> consolidateObs(Iterator<? extends Observation> obsList,
												 int dsIdx,
												 Keyable key,
												 DataValidationErrorHandler errorHandler,
												 MVDuplicateBehaviour rule,
												 SORT_ORDER sortOrder) {
		//Create a map of obs key to list of obs
		Map<String, List<Observation>> obsMap = new LinkedHashMap<>();  //all the obs for the key
		
		List<Observation> returnList = new ArrayList<>();
		
		while(obsList.hasNext()) {
			Observation obs = obsList.next();
			String mapKey = obs.getDimensionValue();
			mapKey = mapKey != null ? mapKey : StringUtil.EMPTY;  //For non time series data, the map key is an empty string
			CollectionUtil.addToMappedList(obsMap, mapKey, obs);
		}

		List<String> obsKeys = new ArrayList<String>(obsMap.keySet());
		if (sortOrder.equals(SORT_ORDER.ASCENDING) || sortOrder.equals(SORT_ORDER.DESCENDING)) {
			Collections.sort(obsKeys);
		}
		if (sortOrder.equals(SORT_ORDER.DESCENDING)) {
			Collections.reverse(obsKeys);
		}
		
		//for each list, consolidate
		for(String obsKey : obsKeys) {
			List<Observation> obsForKey = obsMap.get(obsKey);
			Observation toReturn;
			Set<Observation> addedFromDupeHandler = new HashSet<>();
			if(obsForKey.size() == 1) {
				toReturn = obsForKey.get(0);
			} else {
				IContradictoryDuplicateHandler<Observation> duplicateProcess = (errorHandler == null && rule != MVDuplicateBehaviour.PRESERVE_DUPLICATES) ? null : (obs, kv1, kv2)-> {
					if(errorHandler != null) {
						DataError de;
						if(key.getDataStructure().getMeasure(kv1.getConcept()) ==null) {
							de = DataConsolidationUtil.contradictoryObsAttribute(this, dsIdx, kv1, kv2,  obs);
						} else {
							de = DataConsolidationUtil.duplicateMeasureValue(this, dsIdx, obs, kv1.getConcept(), kv1.getCode(), kv2.getCode());
						}
						errorHandler.handleError(de);
					}
					if(rule == MVDuplicateBehaviour.PRESERVE_DUPLICATES) {
						// Store this item away rather than adding it to "returnList" now
						addedFromDupeHandler.add(obs);
					}
				};
				boolean reverseOrder = rule == MVDuplicateBehaviour.USE_LAST_VALUE;
				toReturn = DataConsolidationUtil.consolidateObs(0, key, obsForKey, reverseOrder, duplicateProcess);
			}
			returnList.add(toReturn);
			// If there are any items that the duplicate handler encountered, add them after
			// added the item in "toReturn"
			if (addedFromDupeHandler.size() > 0) {
				returnList.addAll(addedFromDupeHandler);
			}
		}
		return returnList.iterator();
	}
	
	/**
	 * Determine if this Key represents a "full deletion". This is true only if both the following conditions are met:
	 * - the Key has no attributes
	 * - the Key has no observations
	 */
	private boolean isFullDeletion(Keyable key, int obsCount) {
		List<KeyValue> attributes = key.getAttributes();
		if ((attributes != null) && !attributes.isEmpty()) {
			return false;
		}

		return obsCount < 1;
	}
	
	public MVDuplicateBehaviour getDuplicateValBehaviour() {
		return defaultDuplicateBehaviour;
	}

	public void setDuplicateValBehaviour(MVDuplicateBehaviour b) {
		defaultDuplicateBehaviour = b;
	}
}
