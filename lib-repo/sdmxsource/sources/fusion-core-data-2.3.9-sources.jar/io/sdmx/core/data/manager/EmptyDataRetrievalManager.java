package io.sdmx.core.data.manager;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.retrieval.SdmxDataRetrievalReader;

public class EmptyDataRetrievalManager implements SdmxDataRetrievalReader {

	@Override
	public DataReaderEngine getData(DataQuery dataQuery) {
		throw new SdmxNoResultsException("No data for query");
	}
	
}
