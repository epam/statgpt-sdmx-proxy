package io.sdmx.core.data.model.mapping;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.core.data.api.model.mapping.IComponentMapping;
import io.sdmx.core.data.api.model.mapping.IMappedRow;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

public class MappedRow implements IMappedRow {
	private Map<SdmxPeriod, List<IDataRow>> mappedRows;
	private Set<IComponentMapping> unmapped;
	
	public MappedRow(Map<SdmxPeriod, List<IDataRow>> mappedRows, Set<IComponentMapping> unmapped) {
		this.mappedRows = mappedRows;
		this.unmapped = unmapped;
	}

	@Override
	public Set<SdmxPeriod> getMappedPeriods() {
		return mappedRows.keySet();
	}

	@Override
	public List<IDataRow> getMappedValues(SdmxPeriod period) {
		return mappedRows.get(period);
	}

	@Override
	public Set<IComponentMapping> getUnmappedComponents() {
		return unmapped;
	}

}
