package io.sdmx.core.data.api.factory;

import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.engine.DataErrorReporter;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;

public interface DataValidatorFactory extends DataErrorReporter, IPluggable {
	
    /**
     * Creates a new instance of a DataValidationEngine, however it may return null
     * (see the ConstraintValidatorFactory).
     * @param dsi
     * @return a new instance or null
     */
    DataValidationEngine createInstance(DatasetInformation dsi);

    /**
     * Returns true if the output of this data validation can change depending on whether the dataset is linked to a DSD, Dataflow or Provision Agreement
     * For example Constraints validation may pass if the validation is against the DSD but fail if it is against the dataflow, in which case this would return true
     * @return
     */
    boolean validationLinkedToFlowOrProvision();
    
    /**
     * If the validation requires knowledge of what data was previously reported in order to accurately state this fails validation, then this should return true.
     * 
     * An example is Mandatory Attributes which may be missing from a reported dataset, but present in a database, so if the dataset being validated is simply updating
     * a value in the database then the mandatory attribute is not required.
     * @return
     */
    boolean validationRequiresKnowledgeOfPreviouslyReportedData();
    
 
}
