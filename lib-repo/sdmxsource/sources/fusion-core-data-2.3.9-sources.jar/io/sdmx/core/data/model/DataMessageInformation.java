package io.sdmx.core.data.model;

import java.util.List;

import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;


public class DataMessageInformation {
	private DATA_TYPE dataType;
	private HeaderBean header;
	private List<DatasetHeaderBean> datasetHeaders;
	
	public DataMessageInformation(DATA_TYPE dataType, HeaderBean header,List<DatasetHeaderBean> datasetHeaders) {
		this.dataType = dataType;
		this.header = header;
		this.datasetHeaders = datasetHeaders;
	}

	public DATA_TYPE getDataType() {
		return dataType;
	}

	public HeaderBean getHeader() {
		return header;
	}

	public List<DatasetHeaderBean> getDatasetHeaders() {
		return datasetHeaders;
	}
}
