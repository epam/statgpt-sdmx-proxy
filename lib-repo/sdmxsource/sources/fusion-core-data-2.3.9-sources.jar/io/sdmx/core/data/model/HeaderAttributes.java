package io.sdmx.core.data.model;

import java.util.Date;
import java.util.Set;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.utils.core.object.ObjectUtil;


public class HeaderAttributes {
	private String id;
	private String test;
	private String truncated;
	private Set<TextTypeWrapper> name;
	private Date prepard;
	private String dataStructureRef;
	private String dataStructureAgency;
	private String datasetAgency;
	private String datasetId;
	private DATASET_ACTION datasetAction;
	private Date extracted;
	private Date reportingBegin;
	private Date reportingEnd;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTest() {
		return test;
	}
	public void setTest(String test) {
		this.test = test;
	}
	public String getTruncated() {
		return truncated;
	}
	public void setTruncated(String truncated) {
		this.truncated = truncated;
	}
	public Set<TextTypeWrapper> getName() {
		return name;
	}
	public void setName(Set<TextTypeWrapper> name) {
		this.name = name;
	}
	public Date getPrepard() {
		return prepard;
	}
	public void setPrepard(Date prepard) {
		this.prepard = prepard;
	}
	public String getDataStructureRef() {
		return dataStructureRef;
	}
	public void setDataStructureRef(String dataStructureRef) {
		this.dataStructureRef = dataStructureRef;
	}
	public String getDataStructureAgency() {
		return dataStructureAgency;
	}
	public void setDataStructureAgency(String dataStructureAgency) {
		this.dataStructureAgency = dataStructureAgency;
	}
	public String getDatasetAgency() {
		return datasetAgency;
	}
	public void setDatasetAgency(String datasetAgency) {
		this.datasetAgency = datasetAgency;
	}
	public String getDatasetId() {
		return datasetId;
	}
	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}
	public DATASET_ACTION getDatasetAction() {
		return datasetAction;		
	}
	
	public void setDatasetAction(String datasetAction) {
		if(!ObjectUtil.validString(datasetAction)) {
			this.datasetAction = DATASET_ACTION.INFORMATION;
		} 
		if(datasetAction.equals("Append") || datasetAction.equals("Update")) {
			this.datasetAction = DATASET_ACTION.APPEND;
		}
		if(datasetAction.equals("Replace")) {
			this.datasetAction = DATASET_ACTION.REPLACE;
		}
		if(datasetAction.equals("Delete")) {
			this.datasetAction = DATASET_ACTION.DELETE;
		}
	}
	public Date getExtracted() {
		return extracted;
	}
	public void setExtracted(Date extracted) {
		this.extracted = extracted;
	}
	public Date getReportingBegin() {
		return reportingBegin;
	}
	public void setReportingBegin(Date reportingBegin) {
		this.reportingBegin = reportingBegin;
	}
	public Date getReportingEnd() {
		return reportingEnd;
	}
	public void setReportingEnd(Date reportingEnd) {
		this.reportingEnd = reportingEnd;
	}
}
