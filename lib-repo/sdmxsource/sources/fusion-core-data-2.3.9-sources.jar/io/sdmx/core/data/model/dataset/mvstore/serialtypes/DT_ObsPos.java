package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.core.sdmx.model.data.ObsPos;

/**
 * Serialization for ObsPos.
 */
public class DT_ObsPos extends BasicDataType<ObsPos> {
  private static final DT_ObsPos INSTANCE = new DT_ObsPos();

  private DT_ObsPos() {
  }

  public static DT_ObsPos getInstance() {
    return INSTANCE;
  }

  @Override
  public int compare(ObsPos a, ObsPos b) {
    int cmp = a.getKeyablePosition().compareTo(b.getKeyablePosition());

    if (cmp == 0)
      cmp = a.getObservationPosition().compareTo(b.getObservationPosition());

    return cmp;
  }

  @Override
  public int getMemory(ObsPos x) {
    return (x == null) ? 1 : 5;
  }

  @Override
  public void write(WriteBuffer buf, ObsPos x) {
    buf.putVarInt((x == null) ? 0 : 1);

    if (x != null) {
      buf.putVarInt(x.getKeyablePosition());
      buf.putVarInt(x.getObservationPosition());
    }
  }

  @Override
  public ObsPos read(ByteBuffer buf) {
    boolean isNull = (DataUtils.readVarInt(buf) == 0);
    ObsPos x = null;

    if (!isNull) {
      Integer keyablePosition = DataUtils.readVarInt(buf);
      Integer observationPosition = DataUtils.readVarInt(buf);

      x = new ObsPos(keyablePosition, observationPosition);
    }

    return x;
  }

  @Override
  public ObsPos[] createStorage(int size) {
    return new ObsPos[size];
  }
}
