package io.sdmx.core.data.model.dataset;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Abstract proxy on top of data row
 */
public abstract class ProxyDataRow implements IDataRow {
	private IDataRow proxy;

	public ProxyDataRow(IDataRow proxy) {
		this.proxy = proxy;
	}

	@Override
	public IDataRow modifyValue(String key, String value) {
		return proxy.modifyValue(key, value);
	}

	@Override
	public IDataRow modifyValues(Map<String, String> newData) {
		return proxy.modifyValues(newData);
	}

	@Override
	public IDataRow modifyValues(Map<String, String> newData, Map<String, Set<String>> multiValueData, Map<String, Set<String>> multilingualValueData) {
		return proxy.modifyValues(newData, multiValueData, multilingualValueData);
	}

	@Override
	public boolean isPartialKey() {
		return proxy.isPartialKey();
	}

	@Override
	public String getShortCode() {
		return proxy.getShortCode();
	}

	@Override
	public String getRowCode() {
		return proxy.getRowCode();
	}
	
	@Override
	public String getRowCodeAllDimensionsWithWildcard() {
		return proxy.getRowCodeAllDimensionsWithWildcard();
	}

	@Override
	public Map<String, String> getRowData() {
		return proxy.getRowData();
	}

	@Override
	public Map<String, Set<String>> getMultiValueData() {
		return proxy.getMultiValueData();
	}

	@Override
	public Map<String, Set<String>> getMultilingualValueData(){
		return proxy.getMultilingualValueData();
	}

	@Override
	public Set<String> getLocales(){
		return proxy.getLocales();
	}

	@Override
	public IDatasetStructures getDatasetStructures() {
		return proxy.getDatasetStructures();
	}

}
