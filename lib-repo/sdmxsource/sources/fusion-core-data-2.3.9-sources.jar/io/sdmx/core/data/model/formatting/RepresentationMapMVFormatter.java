package io.sdmx.core.data.model.formatting;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.model.dataset.IObservationValueFormatter;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.model.mapping.value.ComponentMappingRules;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;


/**
 * Formats an observation value based on a representation map, and knowledge of the Observation's Component that is used for the format input
 */
public class RepresentationMapMVFormatter implements IObservationValueFormatter {
	private String componentId;
	private IComponentMappingRules map;
	
	/**
	 * @param componentId to obtain additional information from i.e. OBS_STATUS
	 * @param repMap used to map the reported value against the component i.e. OBS_STATUS to get the MV value
	 */
	public RepresentationMapMVFormatter(String componentId, IRepresentationMapBean repMap) {
		super();
		this.componentId = componentId;
		List<String> sourcetarget = CollectionUtil.toList(this.componentId);
		this.map = new ComponentMappingRules(sourcetarget, sourcetarget, repMap, false);
	}

	@Override
	/**
	 * @return the original value if not missing, or a mapped value if a mapping exists, otherwise returns the original value (null or empty string)
	 */
	public String getObservationValue(Observation obs, String measure) {
		String measureValue = null;
		if (obs.getMeasure(measure) != null){
			measureValue = obs.getMeasureCode(measure);
		}
		if(!ObjectUtil.validString(measureValue) || SdmxConstants.MISSING_DATA_VALUE.equals(measureValue)) {
			String compVal = obs.getAttributeValue(componentId);
			if(compVal == null) {
				Keyable sk = obs.getSeriesKey();
				if(sk != null) {
					compVal = sk.getAttributeValue(componentId);
					if(compVal == null) {
						compVal = sk.getReportedValue(componentId);
					}
				}
			}
			if(compVal == null) {
				compVal = "";
			}
			SdmxPeriod period = obs.getSdmxObsTime() == null ? null : new SdmxPeriodImpl(obs.getSdmxObsTime(), obs.getSdmxObsTime());
			Map<SdmxPeriod, Set<KeyValue>> mapped = map.getMappedCodes(period, compVal);
			for(SdmxPeriod mapKey : mapped.keySet()) {
				Set<KeyValue> values = mapped.get(mapKey);
				for(KeyValue kv : values) {
					return kv.getCode();
				}
			}
		}
		return measureValue;
	}
	
}
