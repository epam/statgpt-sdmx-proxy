package io.sdmx.core.data.model.dataset.mvstore.serialtypes;

import java.nio.ByteBuffer;
import java.util.List;
import org.h2.mvstore.WriteBuffer;
import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.model.dataset.mvstore.ObservationWrap;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.model.type.DT_Integer;
import io.sdmx.core.sdmx.model.type.DT_List;
import io.sdmx.core.sdmx.model.type.DT_String;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.ObservationImpl;

/**
 * Serialization for ObservationWrap.
 */
public class DT_ObservationWrap extends DT_Attributable<ObservationWrap, Observation> {
	private final DT_String strDT;
	private final DT_Integer intDT;
	private final DT_List<KeyValue, KeyValue> kvListDT;

	private final IDatasetStore dataset;

	public DT_ObservationWrap(IDatasetStore dataset) {
		this.dataset = dataset;

		final DT_KeyValue measureDT = DT_KeyValue.getInstance();

		this.strDT = DT_String.getInstance();
		this.intDT = DT_Integer.getInstance(false);
		this.kvListDT = new DT_List<>(measureDT);
	}

	@Override
	public int getMemory(ObservationWrap ow) {
		int size = intDT.getMemory(1); // null/string selector

		if (ow != null) {
			size += intDT.getMemory(ow.getKeyablePosition());
			size += strDT.getMemory(ow.getDimensionId());
			size += strDT.getMemory(ow.getDimensionValue());
			size += kvListDT.getMemory(ow.getMeasures());
			size += super.getMemory(ow);
		}

		return size;
	}

	@Override
	public void write(WriteBuffer buf, ObservationWrap ow) {
		super.write(buf, ow);
		if (ow != null) {
			intDT.write(buf, ow.getKeyablePosition());
			strDT.write(buf, ow.getDimensionId());
			strDT.write(buf, ow.getDimensionValue());
			kvListDT.write(buf, ow.getMeasures());
		}
	}

	@Override
	protected ObservationWrap build(Observation built) {
		//the position is ignored on the read, but the datatype read has to be the same as the write so just use 0 for position
		return new ObservationWrap(0, built);  
	}

	@Override
	protected AttributableBuilder<Observation> getBuilder(ByteBuffer byteBuffer) {
		Integer keyablePosition = intDT.read(byteBuffer);
		String dimId = strDT.read(byteBuffer);
		String dimValue = strDT.read(byteBuffer);
		List <KeyValue> measures = kvListDT.read(byteBuffer);
		Keyable keyable = dataset.getKeyable(keyablePosition);
		
		return ObservationImpl.builder(keyable).dim(dimId, dimValue).measures(measures);
	}

	@Override
	public ObservationWrap[] createStorage(int size) {
		return new ObservationWrap[size];
	}

}
