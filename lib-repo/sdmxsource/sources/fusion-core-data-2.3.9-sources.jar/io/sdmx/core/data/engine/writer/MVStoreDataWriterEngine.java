package io.sdmx.core.data.engine.writer;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreAbstractDatasetStorage;
import io.sdmx.core.data.model.dataset.mvstore.MVStoreDatasetStorage;

public class MVStoreDataWriterEngine implements ISeriesObsDataWriterEngine {
	private MVStoreAbstractDatasetStorage storage;
	private boolean closeFileOnClose;
	private boolean isProtected;
	
	public MVStoreDataWriterEngine() {
		this(false);
	}
	
	public MVStoreDataWriterEngine(boolean closeFileOnClose) {
		this.closeFileOnClose = closeFileOnClose;
		this.storage = MVStoreDatasetStorage.createInstance(null);
	}
	
	public MVStoreDataWriterEngine(MVStoreAbstractDatasetStorage store) {
		this.storage = store;
	}

	public MVStoreAbstractDatasetStorage getStorage() {
		return storage;
	}
	
	@Override
	public void writeHeader(HeaderBean header) {
		this.storage.setHeader(header);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		this.storage.startDataset(structures, header, datasetAttributes, annotations);
	}

	@Override
	public void writeKey(Keyable key) {
		this.storage.writeKey(key);
	}

	@Override
	public void writeObservation(Observation obs) {
		this.storage.writeObs(obs);
	}

	public void removeResources() {
		storage.getStore().delete();
	}
	
	public void setProtected(boolean protect) {
		this.isProtected = protect;
		this.storage.setProtected(protect);
	}
	
	@Override
	public void close(FooterMessage... footer) {
	    storage.commit();  
	    if(closeFileOnClose && !this.isProtected) {
	    	storage.close();
	    }
	}

}
