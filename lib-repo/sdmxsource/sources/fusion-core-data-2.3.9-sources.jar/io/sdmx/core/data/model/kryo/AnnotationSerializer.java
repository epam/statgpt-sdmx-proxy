package io.sdmx.core.data.model.kryo;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.beans.base.AnnotationBeanImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;

public class AnnotationSerializer extends Serializer<AnnotationBean> {
	private static final AnnotationSerializer INSTANCE = new AnnotationSerializer();
	
	public static AnnotationSerializer getInstance() {
		return INSTANCE;
	}
	
	private AnnotationSerializer() { }
	

	@Override
	public void write(Kryo kryo, Output output, AnnotationBean object) {
		kryo.writeObjectOrNull(output, object.getId(), String.class);
		kryo.writeObjectOrNull(output, object.getTitle(), String.class);
		kryo.writeObjectOrNull(output, object.getType(), String.class);
		
		String uri = object.getUri() == null ? null : object.getUri().toString();
		kryo.writeObjectOrNull(output, uri, String.class);
		kryo.writeObjectOrNull(output, object.getText(), TextTypeWrapperListSerializer.getInstance());
	}

	@Override
	public AnnotationBean read(Kryo kryo, Input input, Class<? extends AnnotationBean> claz) {
		String id = kryo.readObjectOrNull(input, String.class);
		String title = kryo.readObjectOrNull(input, String.class);
		String type = kryo.readObjectOrNull(input, String.class);
		String uri = kryo.readObjectOrNull(input, String.class);
		List<TextTypeWrapper> text = kryo.readObjectOrNull(input, List.class, TextTypeWrapperListSerializer.getInstance());
		List<TextTypeWrapperMutableBean> textMutable = TextTypeWrapperListSerializer.toMutable(text);
		
		AnnotationMutableBean annotationMutable = new AnnotationMutableBeanImpl();
		annotationMutable.setId(id);
		annotationMutable.setTitle(title);
		annotationMutable.setType(type);
		annotationMutable.setUri(uri);
		annotationMutable.setText(textMutable);
		return new AnnotationBeanImpl(annotationMutable, null);
	}

	
}
