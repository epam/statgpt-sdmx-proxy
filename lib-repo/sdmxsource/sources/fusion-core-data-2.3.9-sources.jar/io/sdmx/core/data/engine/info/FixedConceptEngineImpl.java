package io.sdmx.core.data.engine.info;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.info.FixedConceptEngine;

public class FixedConceptEngineImpl implements FixedConceptEngine {
	public static final FixedConceptEngine INSTANCE = new FixedConceptEngineImpl();
	private FixedConceptEngineImpl() {};

	@Override
	public Map<String, String> getFixedConcepts(DataReaderEngine dre, boolean includeDims, boolean includeObsAttr, boolean includeSeriesAttributes) {
		dre.reset();

		Map<String, String> conceptMap = new HashMap<>();
		Set<String> skipConcepts = new HashSet<>();

		while(dre.moveNextKeyable()) {
			Keyable key = dre.getCurrentKey();
			if(includeSeriesAttributes) {
				processKeyValues(key.getAttributes(), conceptMap, skipConcepts);
			}
			if(includeDims) {
				processKeyValues(key.getKey(), conceptMap, skipConcepts);
			}
			if(includeObsAttr) {
				while(dre.moveNextObservation()) {
					Observation obs = dre.getCurrentObservation();
					processKeyValues(obs.getAttributes(), conceptMap, skipConcepts);
					if(obs.getDimensionValue() != null) {
						processKeyValue(obs.getDimensionId(), obs.getDimensionValue(), conceptMap, skipConcepts);
					}
				}
			}
		}
		Map<String, String> fixedKeyValues = new HashMap<>();
		for(String fixedConcept : conceptMap.keySet()) {
			fixedKeyValues.put(fixedConcept, conceptMap.get(fixedConcept));
		}
		return fixedKeyValues;
	}

	private void processKeyValues(List<KeyValue> kvs, Map<String, String> conceptMap, Set<String> skipConcepts) {
		for(KeyValue kv : kvs) {
			processKeyValue(kv.getConcept(), kv.getCode(), conceptMap, skipConcepts);
		}
	}

	
	private void processKeyValue(String  compId, String value, Map<String, String> conceptMap, Set<String> skipConcepts) {
		if(skipConcepts.contains(compId)) {
			return;
		}
		if(!conceptMap.containsKey(compId)) {
			conceptMap.put(compId, value);
			return;
		} 
		if(!conceptMap.get(compId).equals(value)) {
			conceptMap.remove(compId);
			skipConcepts.add(compId);
		}
	}
}
