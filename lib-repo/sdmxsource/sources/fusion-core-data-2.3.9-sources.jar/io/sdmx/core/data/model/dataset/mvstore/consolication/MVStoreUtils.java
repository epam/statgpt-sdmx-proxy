package io.sdmx.core.data.model.dataset.mvstore.consolication;

import java.util.List;
import java.util.Objects;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

public class MVStoreUtils {
  /**
   * Format an observation key as the keyable short code plus, if present,
   * the (observation-) dimension value, separated by a colon.
   */
	@Deprecated // use observation.getShortCode()
  public static String getObservationKey(Observation observation) {
    Keyable keyable = observation.getSeriesKey();
    String dimVal = observation.getDimensionValue();

    return keyable.getShortCode() + ((dimVal == null) ? "" : ":" + dimVal);
  }

  // compare two non-null KeyValue instances having the same concept
  // FIXME: this function can be replaced by KeyValue::equals() once fixed.
  @Deprecated //should now be fixed
  public static boolean keyValuesEquals(KeyValue a, KeyValue b) {
    boolean equal = false;

    if (a.hasMultipleValues() == b.hasMultipleValues()) {
      if (a.hasMultipleValues())
        // FIXME: should these be sets, instead?
        equal = a.getValues().equals(b.getValues());
      else
        equal = Objects.equals(a.getCode(), b.getCode());
    }

    return equal;
  }

  @Deprecated //use KeyValueUtil
  public static String getValueString(KeyValue kv) {
    String val;

    if (kv.hasMultipleValues()) {
      List<String> values = kv.getValues();

      if (values.isEmpty())
        val = "[]";
      else
        val = "['" + String.join("', '", values) + "']";
    } else
      val = kv.getCode();

    return val;
  }
}
