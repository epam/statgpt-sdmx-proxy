package io.sdmx.core.data.manager;

import java.util.List;
import java.util.Map;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.data.api.engine.info.FixedConceptEngine;
import io.sdmx.core.data.api.engine.info.ReportedDateEngine;
import io.sdmx.core.data.api.manager.DataInformationManager;
import io.sdmx.core.data.engine.info.FixedConceptEngineImpl;
import io.sdmx.core.data.engine.info.ReportedDateEngineImpl;
import io.sdmx.core.data.model.DataInformation;


public class DataInformationManagerImpl implements DataInformationManager {
	public static final DataInformationManager INSTANCE = new DataInformationManagerImpl();
	private DataInformationManagerImpl() {};
	private ReportedDateEngine reportedDateEngine = ReportedDateEngineImpl.INSTANCE;
	private FixedConceptEngine fixedConceptEngine = FixedConceptEngineImpl.INSTANCE;

	@Override
	public Map<TIME_FORMAT, List<String>> getAllReportedDates(DataReaderEngine dataReaderEngine) {
		return reportedDateEngine.getAllReportedDates(dataReaderEngine);
	}

	@Override
	public Map<String, String> getFixedConcepts(DataReaderEngine dre, boolean includeDimensions, boolean includeObs, boolean includeSeriesAttributes) {
		return fixedConceptEngine.getFixedConcepts(dre, includeDimensions, includeObs, includeSeriesAttributes);
	}

	@Override
	public DataInformation getDataInformation(DataReaderEngine dre) {
		return new DataInformation(dre);
	}
}
