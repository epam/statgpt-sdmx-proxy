package io.sdmx.core.data.engine.validate;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConstraintValidationEngine implements DataValidationEngine {

	private Set<ContentConstraintModel> timeRestrictedConstraints = new HashSet<>();

	private Keyable seriesToValidate = null;
	private Set<ContentConstraintModel> timeDependantConstraintsToUse;

	private Set<ContentConstraintModel> unRestrictedConstraints = new HashSet<>(); //In the case where there are no observations, and there are time series constraints
	private Date reportingBeginDate;
	private Date reportingEndDate;
	private List<KeyValue> datasetAttributes;
	
	private boolean hasTimeDependantConstraints = false;

	public ConstraintValidationEngine(Set<ContentConstraintModel> constraintModels) {
		if (constraintModels == null) {
			throw new IllegalArgumentException("ContentConstraintModel set may not be null!");
		}
		unRestrictedConstraints = new HashSet<>();
		for(ContentConstraintModel model : constraintModels) {
			if(model.hasValidityPeriod()) {
				this.timeRestrictedConstraints.add(model);
			} else {
				this.unRestrictedConstraints.add(model);
			}
		}
		hasTimeDependantConstraints = this.timeRestrictedConstraints.size() > 0;
	}

	@Override
	public void validateDatasetAttributes(IDatasetAttributes dsAttr, DataValidationEngineErrorHandler eh) {
		datasetAttributes = dsAttr == null ? Collections.emptyList() : dsAttr.getAttributes();
	}


	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler eh) {
		try {
			seriesToValidate = key;
			validateSeries(eh);
		} finally {
			if(hasTimeDependantConstraints) {
				timeDependantConstraintsToUse = new HashSet<>(this.timeRestrictedConstraints.size());
			}
		}
	}

	private class ErrorTranslator implements DataValidationEngineErrorHandler {
		private DataValidationErrorReporter errorReporter;
		private Keyable series;

		public ErrorTranslator(DataValidationErrorReporter errorReporter, Keyable series) {
			this.errorReporter = errorReporter;
			this.series = series;
		}

		@Override
		public void reportError(FusionError fe, KeyValue component) {

			errorReporter.reportError(fe, component, series);
		}

		@Override
		public void reportError(FusionError fe, IMultilingualKeyValue component) {
			errorReporter.reportError(fe, component, series);
		}
	}

	private void validateSeries(DataValidationEngineErrorHandler eh) {
		if(seriesToValidate != null) {
			for(ContentConstraintModel constraint : unRestrictedConstraints) {
				constraint.validateKey(seriesToValidate, eh);
			}
		}
	}

	@Override
	public void validateObs(Observation obs, DataValidationEngineErrorHandler eh) {
		for(ContentConstraintModel constraint : timeRestrictedConstraints) {
			SdmxDate sdmxDate = obs.getSdmxObsTime();
			if(sdmxDate != null) {
				Date dte = sdmxDate.getDate();
				if(reportingBeginDate == null || reportingBeginDate.after(dte)) {
					reportingBeginDate = dte;
				}
				if(reportingEndDate == null || reportingEndDate.before(dte)) {
					reportingEndDate = dte;
				}
				if(constraint.getValidityPeriod().isInPeriod(dte) == false) {
					continue;
				}
			}
			timeDependantConstraintsToUse.add(constraint);
			constraint.validateObservation(obs, eh);
		}
		for(ContentConstraintModel constraint : unRestrictedConstraints) {
			constraint.validateObservation(obs, eh);
		}
	}

	@Override
	public void finishedObs(DataValidationErrorReporter exceptionHandler) {
		Keyable series = seriesToValidate;
		ErrorTranslator translator = new ErrorTranslator(exceptionHandler, series);
		try {
			if(timeDependantConstraintsToUse != null) {
				for(ContentConstraintModel constraint : timeDependantConstraintsToUse) {
					constraint.validateKey(seriesToValidate, translator);
				}
			}
		} catch(Throwable th) {
			exceptionHandler.reportError(new FusionErrorImpl(ErrorUtil.getErrorMessage(th)), (KeyValue) null, series);
		}

		if(ObjectUtil.validCollection(datasetAttributes)) {
			for(ContentConstraintModel constraintModel : timeRestrictedConstraints) {
				if(ObjectUtil.validOneObject(reportingBeginDate, reportingEndDate)) {
					if(constraintModel.getValidityPeriod().isInPeriod(reportingBeginDate, reportingEndDate) == false) {
						continue;
					}
				}
				timeDependantConstraintsToUse.add(constraintModel);
				validateDatasetAttrs(constraintModel, exceptionHandler);
			}
			for(ContentConstraintModel constraintModel : unRestrictedConstraints) {
				validateDatasetAttrs(constraintModel, exceptionHandler);
			}
		}
	}

	private void validateDatasetAttrs(ContentConstraintModel constraintModel, DataValidationErrorReporter exceptionHandler) {
		for(KeyValue currentDsAttr : datasetAttributes) {
			if(constraintModel.isConstrainedKeyValue(currentDsAttr)) {
				exceptionHandler.reportDatasetAttributeError(new FusionErrorImpl("Dataset Attribute is restricted: " + currentDsAttr), currentDsAttr);
			}
		}
	}


	@Override
	public void close(DataValidationErrorReporter errorHandler) {
		timeRestrictedConstraints = null;
		seriesToValidate = null;
		timeDependantConstraintsToUse = null;
		reportingBeginDate = null;
		reportingEndDate = null;
		datasetAttributes = null;
	}
}