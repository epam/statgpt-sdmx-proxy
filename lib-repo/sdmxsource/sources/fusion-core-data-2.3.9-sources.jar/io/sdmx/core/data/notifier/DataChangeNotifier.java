package io.sdmx.core.data.notifier;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.utils.core.notifier.AbstractNotifier;

public class DataChangeNotifier extends AbstractNotifier<DataflowBean> {

}
