package io.sdmx.core.data.api.model.dataset;

public interface IDataWriterMetrics {

	/**
	 * @return the time the dataset writer started writing data
	 */
	long getStartTime();
	
	/**
	 * @return the time the datset writer finished writing data, or -1 if no completed
	 */
	long getEndTime();
	
	/**
	 * @return number of unique series, -1 if this information was not captured
	 */
	int getSeries();
	
	/**
	 * @return number of rows in the data
	 */
	int getRows();
	
}
