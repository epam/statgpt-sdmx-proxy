package io.sdmx.core.data.engine.retrieval;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.availability.IAvailabilityInfo;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Converts availability information about data into SdmxBeans, including the Content Constraint to describe what data exists
 * and descendants if requested
 */
public interface IAvailabilityBeansRetreivalEngine {

	/**
	 * Obtains all of the SdmxBeans used to describe the available data.  The SDMX ContentConstraint describes which dimension values
	 * are valid, related structures (Concepts, Codelists, DSDs) are optionally resolved
	 * 
	 * @param availabililty set of available data information
	 * @param componentIds optional - if provided only the components passed in will be included in the output content constraint
	 * @param referenceDetails details on which structures to resolve (related to the Constraint)
	 * @param speicifcStructure optional reference to speific structures to resolve
	 * @return
	 */
	SdmxBeans getBeans(
			  Set<IAvailabilityInfo> validValues, 
			  Set<String> componentIds,
			  STRUCTURE_REFERENCE_DETAIL referenceDetails, 
			  SDMX_STRUCTURE_TYPE speicifcStructure);
}
