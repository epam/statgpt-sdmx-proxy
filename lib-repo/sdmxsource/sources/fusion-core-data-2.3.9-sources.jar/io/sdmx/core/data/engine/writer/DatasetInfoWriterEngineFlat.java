package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.DatasetInfo;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Builds up a picture of the number of series, groups, and obs written for each dataset as it is written
 */
public class DatasetInfoWriterEngineFlat<T extends IFlatDataWriterEngine> extends FlatDataWriterEngineGroupingProxy<T> {
	private List<DatasetInfo> datasetInfo = new ArrayList<>();
	private DatasetInfo currentInfo;
	private DataInformation finalInformation;
	
	public DatasetInfoWriterEngineFlat(T dwe) {
		super(dwe);
	}
	/**
	 * Returns the built dataset information
	 * @return
	 */
	public DataInformation getDataInformation() {
		if(finalInformation != null) {
			return finalInformation;
		}
		//On the fly details, still not closed writer
		return new DataInformation(datasetInfo);
	}
	
	@Override
	protected IDataRow processRow(IDataRow row, boolean newDataset, boolean newSeries) {
		if(newDataset) {
			//New Dataset
			if(currentInfo != null) {
				currentInfo.makeFinal();
			}
			IDatasetStructures dsStructures = row.getDatasetStructures();
			currentInfo = new DatasetInfo(dsHeader, dsStructures);
			datasetInfo.add(currentInfo);
			currentInfo.addKey();
		} else if(newSeries) {
			currentInfo.addKey();
		}
		for(String measure : this.measures) {
			if(row.getRowData().containsKey(measure) || row.getMultiValueData().containsKey(measure)) {
				// DEV-1732 If any measure has a value, it counts as 1 observation
				currentInfo.addObservation();
				break;
			}
		}
		return row;
	}
	
	

	@Override
	public void close() {
		super.close();
		if(currentInfo != null) {
			currentInfo.makeFinal();
		}
		finalInformation = new DataInformation(datasetInfo);
		datasetInfo = null;
		currentInfo = null;
	}
}
