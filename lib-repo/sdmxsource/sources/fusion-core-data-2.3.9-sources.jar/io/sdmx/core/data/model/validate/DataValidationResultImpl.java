package io.sdmx.core.data.model.validate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.manager.DataReaderConsolidationManager;
import io.sdmx.core.data.api.manager.DataReaderManager;
import io.sdmx.core.data.api.manager.DataValidationManager;
import io.sdmx.core.data.api.manager.DataValidationManager.VALIDATION_TYPE;
import io.sdmx.core.data.api.manager.DataValidatorLevelRetrievalManager;
import io.sdmx.core.data.api.manager.IDataValidationSettingsManager;
import io.sdmx.core.data.api.manager.SdmxMappingManager;
import io.sdmx.core.data.api.model.calculation.DataValidationResult;
import io.sdmx.core.data.api.model.consolidation.IConsolidationOptions;
import io.sdmx.core.data.api.model.mapping.MappingRules;
import io.sdmx.core.data.engine.reader.MappingDataReaderEngineImpl;
import io.sdmx.core.data.engine.validate.DataReaderForValidation;
import io.sdmx.core.data.engine.writer.MVStoreDataWriterEngine;
import io.sdmx.core.data.manager.AdvancedDataReaderConsolidationManager;
import io.sdmx.core.data.model.DataInformation;
import io.sdmx.core.data.model.io.MVTemporaryDataReadableDataLocation;
import io.sdmx.core.data.util.DataTransformationUtil;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.error.CategorisingErrorHandler;
import io.sdmx.core.sdmx.error.ReportedErrors;
import io.sdmx.core.sdmx.util.BeanRetreivalUtil;
import io.sdmx.core.structure.manager.retrieval.HeaderRetrievalManagerImpl;
import io.sdmx.core.structure.util.StructureUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class DataValidationResultImpl implements DataValidationResult {
	private static final Logger LOG = LoggerFactory.getLogger(DataValidationResultImpl.class);

	private DataValidationManager dataValidationManager;  //Data validation for Flow/Provision specific
	public IDataValidationSettingsManager generalSettingsManager;
	private DataValidatorLevelRetrievalManager dataValidatorManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private HeaderRetrievalManager headerRetrievalManager;
	private DataReaderConsolidationManager dataReaderConsolidationManager;
	private DataReaderManager dataReaderManager;
	private SdmxMappingManager mappingRetrievalManager;

	//Stateful
	private ProvisionAgreementBean provisionAgreementBean;
	private DataflowBean dataflowBean;
	private DataStructureBean dsd;
	private DataStructureBean lastDsd;  //This is the DSD that the datareader was last built using
	private DatasetHeaderBean header;
	private Map<String, List<DataError>> errorMap = new HashMap<>();
	private Map<String, List<DataError>> errorMapMapped = new HashMap<>();

	private List<DataError> consolidationErrors = new ArrayList<>();
	private List<DataError> formatSpecificErrors = new ArrayList<>();

	private DataInformation dataInformation;
	private ReadableDataLocation rdl;  //The dataset in StructureSpecific 2.1 format
	private DataReaderEngine dre;
	private Date creationDate;
	private DataReaderForValidation dreWrapped;
	private boolean priorDataDependent;

	//Mapping
	private DataInformation mappedDataInformation;
	private DataflowBean mappedDataflow;
	private DataStructureBean mappedDSD;

	private boolean isProtected = false;

	private IConsolidationOptions consolidateOptions;

	/**
	 * Constructor expect a RDL containing a readable dataset from a bean retrieval manager,
	 * Consolidates the data and performs a full validation
	 *
	 * @param beanRetrievalManager
	 * @param creationDate
	 * @param rdl
	 * @param formatSpecificErrors
	 * @param consolidateOptions
	 * @param errorHandler - the errorHandler to use, but if not supplied this class will create a ConsolidationErrorHandler
	 */
	public DataValidationResultImpl(SdmxBeanRetrievalManager beanRetrievalManager, Date creationDate, ReadableDataLocation rdl, DataReaderEngine tdre, List<DataError> formatSpecificErrors, boolean priorDataDependent, IConsolidationOptions consolidateOptions, DataValidationErrorHandler errorHandler) {
		dataValidationManager = SingletonStore.getSingleton(DataValidationManager.class);
		generalSettingsManager = SingletonStore.getSingleton(IDataValidationSettingsManager.class, false);
		dataValidatorManager = SingletonStore.getSingleton(DataValidatorLevelRetrievalManager.class);
		headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);
		dataReaderConsolidationManager = SingletonStore.getSingleton(DataReaderConsolidationManager.class, false);
		dataReaderManager = SingletonStore.getSingleton(DataReaderManager.class);
		mappingRetrievalManager = SingletonStore.getSingleton(SdmxMappingManager.class);
		this.consolidateOptions = consolidateOptions;

		if(headerRetrievalManager == null) {
			headerRetrievalManager = new HeaderRetrievalManagerImpl();
			SingletonStore.registerInstance(headerRetrievalManager);
		}
		if(dataReaderConsolidationManager == null) {
			ITemporaryDataManager tmpDataManager = SingletonStore.getSingleton(ITemporaryDataManager.class);
			dataReaderConsolidationManager = new AdvancedDataReaderConsolidationManager(tmpDataManager);
			SingletonStore.registerInstance(dataReaderConsolidationManager);
		}

		this.rdl = rdl;
		this.dre = tdre;
		this.beanRetrievalManager = beanRetrievalManager;
		this.creationDate = creationDate;
		this.rdl.setProtected(true);
		//TODO Errors in the underlying format would have only been captured on first read before the transformation took place
		//Perform up front consolidation and validation of DSD specific things
		initialiseDataReaderEngine(this.consolidateOptions, errorHandler);
		if(ObjectUtil.validCollection(formatSpecificErrors)) {
			this.formatSpecificErrors = formatSpecificErrors;
		}
		dataInformation = new DataInformation(dre, true);
		this.provisionAgreementBean = dataInformation.getProvision(0);
		this.dataflowBean = dataInformation.getFlow(0);
		this.dsd = dataInformation.getDsd(0);
		this.lastDsd = dsd;
		this.priorDataDependent = priorDataDependent;
	}

	/**
	 * Obtains a consolidated DataReaderEngine based on the underlying dataset
	 */
	private void initialiseDataReaderEngine(IConsolidationOptions consolidateOptions, DataValidationErrorHandler errorHandler) {
		DataReaderEngine localDre;
		if (this.dre == null) {
			localDre = dataReaderManager.getDataReaderEngine(rdl, beanRetrievalManager, null);
			dre = localDre;
		} else {
			localDre = dre;
		}
		try {
			if (errorHandler == null) {
				errorHandler = new ConsolidationErrorHandler();
			}
			dre = dataReaderConsolidationManager.consolidateReader(localDre, errorHandler, consolidateOptions);
		} catch(Throwable th) {
			LOG.error("Error consolidating dataset");
		}
		if(dre != localDre) {
			// Unprotect, close and nullify the original RDL
			this.rdl.setProtected(false);
			localDre.close();
			this.rdl.close();
			this.rdl = null;
		}
		dre.reset();
		consolidationErrors = Collections.unmodifiableList(consolidationErrors);
	}
	
	// An ErrorHandler that consolidates errors into a List
	private class ConsolidationErrorHandler implements DataValidationErrorHandler {

		@Override
		public void handleError(DataError err) throws ErrorLimitException {
			consolidationErrors.add(err);
		}

	}

	/**
	 * Full validation
	 */
	@Override
	public void validate() {
		DataReaderEngine dreToUse = dre;
		if(creationDate != null) {
			if(dre instanceof DataReaderForValidation) {
				((DataReaderForValidation)dre).setCreationDate(creationDate);
			} else {
				dreToUse = new DataReaderForValidation(headerRetrievalManager, dre, null, null, null);
				((DataReaderForValidation)dreToUse).setCreationDate(creationDate);
			}
		}
		validateData(dreToUse, dataValidationManager, true);
	}

	@Override
	public DataReaderEngine getDataReaderEngine() {
		DataReaderEngine returnDre = dreWrapped != null ? dreWrapped : dre;
		return returnDre.createCopy();
	}

	@Override
	public ReadableDataLocation getReadableDataLocation() {
		if (rdl == null) {
			MVStoreDataWriterEngine mvStoreDwe = new MVStoreDataWriterEngine();
			ReadableDataLocation rdl = new MVTemporaryDataReadableDataLocation(mvStoreDwe);
			DataTransformationUtil.copyData(dre, mvStoreDwe, true, true);
			this.rdl = rdl;
		}
		return rdl;
	}

	@Override
	public DataInformation getDataInformation() {
		return dataInformation;
	}

	/**
	 * Re-validates the data based on the new Provision or Dataflow
	 * @param sRef
	 */
	@Override
	public void reValidate(IURNSingle<? extends IDSDRelatedBean> sRef) {
		if(sRef != null) {
			ProvisionAgreementBean newProvisionAgreementBean = null;
			DataflowBean newDataflowBean = null;
			this.dsd = null;

			switch(sRef.getSdmxStructure()) {
			case PROVISION_AGREEMENT :
				newProvisionAgreementBean = BeanRetreivalUtil.getMaintainableBean(beanRetrievalManager, ProvisionAgreementBean.class, sRef);
				if (newProvisionAgreementBean == null) {
				    throw new SdmxException("Unable to obtain provision Agreement: " + sRef.getURN());
				}
				sRef = newProvisionAgreementBean.getStructureUseage().getReference();
			case DATAFLOW :
				newDataflowBean = BeanRetreivalUtil.getMaintainableBean(beanRetrievalManager, DataflowBean.class, sRef);
				if (newDataflowBean == null) {
                    throw new SdmxException("Unable to obtain Dataflow: " + sRef.getURN());
                }
				sRef = newDataflowBean.getDataStructureRef().getReference();
			case DSD :
				dsd = BeanRetreivalUtil.getMaintainableBean(beanRetrievalManager, DataStructureBean.class, sRef);
				break;
			default : throw new SdmxNotImplementedException("Validation of dataset requires either a Provision, Dataflow, or DSD reference.  Illegal reference provided:" +sRef.getURN());
			}

			if(!dsd.equals(lastDsd)) {
				LOG.debug("Revalidation Data Structure change made from '"+lastDsd+"' to '"+dsd+"'. Build new DataReaderEngine");
				//Full validation required
				DataStructureBean dsdMutated = (DataStructureBean)StructureUtil.changeValues(dsd, dataInformation.getDsd(0).getURN());
				dre = dataReaderManager.getDataReaderEngine(getReadableDataLocation(), dsdMutated, dataInformation.getFlow(0), dataInformation.getProvision(0), null);
				dreWrapped = new DataReaderForValidation(headerRetrievalManager, dre, dsd, dataflowBean, provisionAgreementBean);
				dreWrapped.setDefaultIfNotProvided(false);
				validateData(dreWrapped, dataValidationManager, true);
				lastDsd = dsd;
			} else if(!ObjectUtil.equivalent(newProvisionAgreementBean, provisionAgreementBean) || !ObjectUtil.equivalent(newDataflowBean, dataflowBean)) {
				LOG.debug("Revalidation Provision or Dataflow change made. Perform validation based on constraints and validation scheme");
				dataflowBean = newDataflowBean;
				provisionAgreementBean = newProvisionAgreementBean;
				dreWrapped = new DataReaderForValidation(headerRetrievalManager, dre, dsd, dataflowBean, provisionAgreementBean);
				dreWrapped.setDefaultIfNotProvided(false);
				validateData(dreWrapped, dataValidationManager, false);
			} else {
				LOG.debug("Revalidaiton not required, no changes to Provision, Dataflow, or DSD made");
			}
		}
	}

	@Override
	public MappingRules getMappingRules(IURNSingle<? extends IStructureMapRelatedBean> sRef) {
		MappingRules map;
		MaintainableBean sourceStructure = null;
		MaintainableBean mappedStructure = null;

		switch(sRef.getSdmxStructure()) {
		case DSD :
			mappedStructure = BeanRetreivalUtil.getMaintainableBean(beanRetrievalManager, DataStructureBean.class, sRef);
			if(mappedStructure == null) {
				throw new SdmxReferenceException(sRef);
			}
			sourceStructure = getDsd();
			map = mappingRetrievalManager.getDataStructureMap(getDsd(), (DataStructureBean)mappedStructure);
			break;
		case DATAFLOW :
			DataflowBean flow = BeanRetreivalUtil.getMaintainableBean(beanRetrievalManager, DataflowBean.class, sRef);
			if(flow == null) {
				throw new SdmxReferenceException(sRef);
			}
			mappedStructure = flow;

			sourceStructure = getFlow();
			if(sourceStructure == null) {
				throw new SdmxException("Can not perform dataflow mapping, dataset has not been linked to a dataflow");
			}
			map = mappingRetrievalManager.getDataStructureMap(getFlow(), (DataflowBean)mappedStructure);
			break;
		case STRUCTURE_MAP :
			map = mappingRetrievalManager.getDataStructureMap(URN.builder().urn(sRef).buildSingle(IStructureMapBean.class));
			if(map == null) {
				throw new SdmxNoResultsException("No Structure Map could be found with URN '"+sRef.getURN());
			}
			sourceStructure = getDsd();
			break;
		default : throw new SdmxSemmanticException("URN expected to be to dsd, or dataflow, but was to :" +sRef.getSdmxStructure().getType());
		}

		if(map == null) {
			throw new SdmxNoResultsException("No Structure Map could be found to map '"+sourceStructure.getUrn()+"' to '"+mappedStructure.getUrn()+"' ");
		}
		return map;
	}

	@Override
	public void map(MappingRules map) {
		errorMapMapped = new HashMap<>();
		if(map == null) {
			mappedDataInformation = null;
			this.mappedDataflow = null;
			this.mappedDSD = null;
			initialiseDataReaderEngine(this.consolidateOptions, new ConsolidationErrorHandler());
			this.provisionAgreementBean = dataInformation.getProvision(0);
			this.dataflowBean = dataInformation.getFlow(0);
			this.dsd = dataInformation.getDsd(0);
		} else {
			//Map
			dreWrapped = null;
			DataReaderEngine mappedDataReader = null;
			try {
				LOG.debug("Revalidaiton Data Structure change made from '"+lastDsd+"' to use map '"+map+"'. Build new DataReaderEngine");
				mappedDataReader = new MappingDataReaderEngineImpl(this.dre, map);
				this.dre = mappedDataReader;
				validateData(mappedDataReader, dataValidationManager, true);
				lastDsd = mappedDataReader.getDataStructure();

				mappedDataInformation = new DataInformation(dre);
				this.mappedDataflow = mappedDataInformation.getFlow(0);
				this.mappedDSD = mappedDataInformation.getDsd(0);
			} finally {
				if (mappedDataReader != null) {
					mappedDataReader.close();
				}
			}
		}
	}

	private void validateData(DataReaderEngine dre, DataValidationManager dvm, boolean fullValidation) {
		LOG.debug("Validate Data using Data Validation Manager: "+dvm.getClass().getName());

		CategorisingErrorHandler exceptionHandler = new CategorisingErrorHandler();

		// Reset the stored errors as appropriate
		if (ObjectUtil.validMap(errorMap)) {
			Set<DataValidatorFactory> factorySet = dvm.obtainFactoriesToBeUsedInDataValidation(fullValidation);
			for (DataValidatorFactory aFactory : factorySet) {
				LOG.debug("Resetting errors for: " + aFactory.getId());
				setErrors(aFactory.getId(), null);
			}
		}

		VALIDATION_TYPE validationType = priorDataDependent ? VALIDATION_TYPE.IGNORE_FULL_DATA_CONTEXT_VALIDATION : VALIDATION_TYPE.FULL_DATA_CONTEXT_PROVIDED;
		int maxErrors = generalSettingsManager != null ? generalSettingsManager.getMaxNumberOfErrors() : Integer.MAX_VALUE;
		for(DataValidatorFactory errorType : dvm.validateData(dre, exceptionHandler, validationType, fullValidation, maxErrors)) {
			ReportedErrors datasetErrors = exceptionHandler.getErrors(0);
			if(datasetErrors != null) {
				setErrors(errorType.getId(), datasetErrors.getCategorisedErrors(errorType.getId()));
			}
		}
	}



	private void setErrors(String type, List<DataError> errors) {
		if(ObjectUtil.validCollection(errors)) {
			if(dre instanceof MappingDataReaderEngineImpl) {
				errorMapMapped.put(type, Collections.unmodifiableList(errors));
			} else {
				errorMap.put(type, Collections.unmodifiableList(errors));
			}
		} else {
			if(dre instanceof MappingDataReaderEngineImpl) {
				errorMapMapped.remove(type);
			} else {
				errorMap.remove(type);
			}
		}
	}


	@Override
	public Map<String, List<DataError>> getDataErrors() {
		Map<String, List<DataError>> copy;
		if(dre instanceof MappingDataReaderEngineImpl) {
			copy = new HashMap<>(errorMapMapped);
		} else {
			copy = new HashMap<>(errorMap);
		}

		if(ObjectUtil.validCollection(consolidationErrors)) {
			copy.put(consolidationErrors.get(0).getErrorCategory(), consolidationErrors);
		}
		if(formatSpecificErrors != null) {
			for(DataError error : formatSpecificErrors) {
				List<DataError> errors = copy.get("FormatSpecific");
				if(errors == null) {
					errors = new ArrayList<>();
					copy.put("FormatSpecific", errors);
				}
				errors.add(error);
			}
		}
		return Collections.unmodifiableMap(copy);
	}

	@Override
	public DatasetHeaderBean getHeader() {
		return header;
	}

	@Override
	public boolean hasReportedPeriodDetails() {
		return dataInformation.hasReportPeriodInfo();
	}

	@Override
	public Map<TIME_FORMAT, SdmxPeriod> getReportingPeriods() {
		if(mappedDataInformation != null) {
			return mappedDataInformation.getReportingPeriods(0);
		}
		return dataInformation.getReportingPeriods(0);
	}

	@Override
	public int getGroups() {
		if(mappedDataInformation != null) {
			return mappedDataInformation.getGroups(0);
		}
		return dataInformation.getGroups(0);
	}

	@Override
	public int getKeys() {
		if(mappedDataInformation != null) {
			return mappedDataInformation.getNumberOfSeriesKeys(0);
		}
		return dataInformation.getNumberOfSeriesKeys(0);
	}

	@Override
	public int getObservations() {
		if(mappedDataInformation != null) {
			return mappedDataInformation.getNumberOfObservations(0);
		}
		return dataInformation.getNumberOfObservations(0);
	}

	@Override
	public int getUnmappedKeysCount() {
		int allKeys = dataInformation.getNumberOfSeriesKeys(0);
		if(mappedDataInformation == null) {
			return allKeys;
		}
		int mappedKeys = mappedDataInformation.getNumberOfSeriesKeys(0);
		return allKeys - mappedKeys;
	}

	@Override
	public DataflowBean getFlow() {
		return dataflowBean;
	}

	@Override
	public DataStructureBean getDsd() {
		return dsd;
	}

	@Override
	public boolean isMapped() {
		return mappedDSD != null;
	}

	@Override
	public DataflowBean getMappedFlow() {
		return mappedDataflow;
	}

	@Override
	public DataStructureBean getMappedDsd() {
		return mappedDSD;
	}

	@Override
	public ProvisionAgreementBean getProvision() {
		return provisionAgreementBean;
	}

	@Override
	public boolean hasErrors() {
		Map<String, List<DataError>> errors = getDataErrors();
		for(String errorType : errors.keySet()) {
			if(errors.get(errorType).size() > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean preventsPublication() {
		//The key to the map is the high level category - in the case of format specific errors, there is the sub category that the error category will
		//report, for example the key to the map might be SDMX-ML but an Error Category is SDMX-ML.InvalidHeader
		for(List<DataError> dataErrors : getDataErrors().values()) {
			for(String errorCatgeory : dataErrors.stream().map(DataError::getErrorCategory).collect(Collectors.toSet())) {
				boolean blocksPub = dataValidatorManager.getValidationLevel(errorCatgeory).blocksPublication();
				if (blocksPub) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public boolean preventsConversion() {
		//The key to the map is the high level category - in the case of format specific errors, there is the sub category that the error category will
		//report, for example the key to the map might be SDMX-ML but an Error Category is SDMX-ML.InvalidHeader
		for(List<DataError> dataErrors : getDataErrors().values()) {
			for(String errorCategory : dataErrors.stream().map(DataError::getErrorCategory).collect(Collectors.toSet())) {
				boolean blocksCon = dataValidatorManager.getValidationLevel(errorCategory).blocksConversion();
				if (blocksCon) {
					return true;
				}
			}
		}
		return false;
	}


	
	@Override
	public void protect(boolean bool) {
		this.isProtected = bool;
	}

	@Override
	public void close() {
		if(this.isProtected == false && this.rdl != null) {
			this.rdl.setProtected(false);
			this.rdl.close();
		}
		if(this.dre != null) {
			this.dre.close();
		}
		this.provisionAgreementBean = null;
		this.dataflowBean = null;
		this.dsd = null;
		this.header = null;
		this.errorMap = null;
		this.dataInformation = null;
		this.dre = null;
	}
}