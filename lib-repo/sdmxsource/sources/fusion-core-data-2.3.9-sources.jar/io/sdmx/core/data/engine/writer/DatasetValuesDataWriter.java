package io.sdmx.core.data.engine.writer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class DatasetValuesDataWriter implements ISeriesObsDataWriterEngine {

	private Map<String, Set<String>> reportedValuesMap = new HashMap<>();

	public DatasetValuesDataWriter() {

	}
	
	public Map<String, Set<String>> getReportedValuesMap() {
		return this.reportedValuesMap;
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		// store dataset attribute name and values
		if(datasetAttributes != null) {
			addKeyValues(datasetAttributes.getAttributes());
		}
			
	}

	@Override
	public void writeKey(Keyable key) {
		// store series key name and values
		addKeyValues(key.getKey());
		// store series attribute name and values
		addKeyValues(key.getAttributes());
	}

	@Override
	public void writeObservation(Observation obs) {
		// store observation dimension id and value (time period)
		if (obs.getDimensionId() != null && ObjectUtil.validString(obs.getDimensionValue())) {
			CollectionUtil.addToMappedSet(reportedValuesMap, obs.getDimensionId(), obs.getDimensionValue());
		}
		// store observation attribute name and values
		addKeyValues(obs.getAttributes());
	}

	private void addKeyValues(List<KeyValue> kvs) {
		// NPE defence
		if (kvs == null) {
			return;
		}
		for (KeyValue attribute : kvs) {
			if (ObjectUtil.validString(attribute.getCode())) {
				CollectionUtil.addToMappedSet(reportedValuesMap, attribute.getConcept(), attribute.getCode());
			} else if (attribute.hasMultipleValues()) {
				CollectionUtil.addToMappedSet(reportedValuesMap, attribute.getConcept(), attribute.getValues());
			}
		}
	}

	@Override
	public void close(FooterMessage... footer) {
		this.reportedValuesMap = CollectionUtil.getImmutableMapOfSets(reportedValuesMap);
	}

	@Override
	public void writeHeader(HeaderBean header) {

	}

	public void clearResources() {
		this.reportedValuesMap = null;
	}
}
