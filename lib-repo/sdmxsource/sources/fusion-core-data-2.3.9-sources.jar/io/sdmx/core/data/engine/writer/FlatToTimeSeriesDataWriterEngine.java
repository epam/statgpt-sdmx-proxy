package io.sdmx.core.data.engine.writer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.core.sdmx.engine.data.RollupDataWriterEngine;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;
import io.sdmx.im.data.MultilingualKeyValue;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * Converts flat data SDMX Time Series view (Single measure)
 */
public class FlatToTimeSeriesDataWriterEngine implements IFlatDataWriterEngine {
	private DataWriterEngine dataWriterEngine;
	private DatasetHeaderBean header;
	private AnnotationBean[] annotations;

	private Map<String, String> currentKey = Collections.emptyMap();  //current series key value
	private Map<String, String> currentGroup = Collections.emptyMap();  //current series key value

	private DataStructureBean dsd;
	private List<String> groupIds = Collections.emptyList();
	private List<String> measureIds = Collections.emptyList();
	private Map<String, List<String>> groupDimensions = Collections.emptyMap();
	private Map<String, List<String>> groupAttributeMap = Collections.emptyMap();
	private List<String> dimensionIds = Collections.emptyList();
	private List<String> seriesAttributeIds = Collections.emptyList();
	private List<String> obsAttributeIds = Collections.emptyList();
	private String dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;

	private Map<String, String> groupAttributeIdToGroupName = Collections.emptyMap();

	private boolean firstRowWritten;  //This is useful to know as the dataset attributes are pulled from the first row
	
	private IDataRow lastRow;

	/**
	 * @param dataWriterEngine to write the data to
	 * @param dimenisonAtObservation the dimension to iterate observations over, i.e TIME_PERIOD
	 */
	public FlatToTimeSeriesDataWriterEngine(DataWriterEngine dataWriterEngine) {
		this.dataWriterEngine = dataWriterEngine;
	}

	public FlatToTimeSeriesDataWriterEngine(ISeriesObsDataWriterEngine dataWriterEngine) {
		this.dataWriterEngine = new RollupDataWriterEngine(dataWriterEngine);
	}
	
	@Override
	public void writeHeader(HeaderBean header) {
		dataWriterEngine.writeHeader(header);
	}

	@Override
	public void startDataset(DatasetHeaderBean header, AnnotationBean... annotations) {
		this.header = header;
		this.annotations = annotations;
		this.dsd = null;
		currentGroup = new HashMap<>();
	}

	private void setStructures(IDatasetStructures structures) {
		this.dsd = structures.getDataStructure();
		if(dsd.getTimeDimension() != null && header != null) {
			DatasetStructureReferenceBean dsStructRef = header.getDataStructureReference();
			if(!dsStructRef.getDimensionAtObservation().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				DatasetStructureReferenceBean modified = new DatasetStructureReferenceBeanImpl(dsStructRef.getId(), dsStructRef.getStructureReference(), dsStructRef.getServiceURL(), dsStructRef.getServiceURL(), DimensionBean.TIME_DIMENSION_FIXED_ID);
				header = header.modifyDataStructureReference(modified);
			}
		}

		dataWriterEngine.startDataset(structures.getProvisionAgreement(), structures.getDataflow(), dsd, header, annotations);


		dimensionIds = SdmxCollectionUtil.identifiablesIdList(dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION));
		seriesAttributeIds = SdmxCollectionUtil.identifiablesIdList(dsd.getSeriesAttributes(dimensionAtObservation));
		obsAttributeIds = SdmxCollectionUtil.identifiablesIdList(dsd.getObservationAttributes());
		groupIds = SdmxCollectionUtil.identifiablesIdList(dsd.getGroups());
		measureIds = SdmxCollectionUtil.identifiablesIdList(dsd.getMeasures());
		
		if(dsd.getTimeDimension() == null) {
			dimensionAtObservation = null;
		}
		
		if(groupIds.size() > 0) {
			groupDimensions = new HashMap<>();
			groupAttributeMap = new HashMap<>();
			groupAttributeIdToGroupName = new HashMap<>();
			for(String groupId : groupIds) {
				groupDimensions.put(groupId, dsd.getGroup(groupId).getDimensionRefs());
				List<String> groupAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getGroupAttributes(groupId, false));
				for(String attrId : groupAttributes) {
					groupAttributeIdToGroupName.put(attrId, groupId);
				}
				this.groupAttributeMap.put(groupId, groupAttributes);
			}
		}
	}
	
	private void writeAttributes(IDataRow dataRow, List<String> attributeIds) {
		Map<String, String> values                = dataRow.getRowData();
		Map<String, Set<String>> multiValueData   = dataRow.getMultiValueData();
		Map<String, Set<String>> multiLingualValueData = dataRow.getMultilingualValueData();
		for(String attrId : attributeIds) {
			String value = values.get(attrId);
			Set<String> multiValueAttribute = multiValueData.get(attrId);
			if(value != null) {
				this.dataWriterEngine.writeAttributeValue(attrId, value);
			} else if(ObjectUtil.validCollection(multiValueAttribute)) {
				this.dataWriterEngine.writeAttributeValue(attrId, CollectionUtil.toArray(multiValueAttribute));
			}
			Set<String> multiLingualAttributes = multiLingualValueData.get(attrId);
			if(ObjectUtil.validCollection(multiLingualAttributes)) {
				List<IMultilingualNodeValue> nodeValues = new ArrayList<>();
				for(String mlingualAttr : multiLingualAttributes) {
					String[] split = mlingualAttr.split(";",2);
					List<TextTypeWrapper> ttList = new ArrayList<>(split.length);
					for(String currentSplit : split) {
						String[] localeValueSplit = currentSplit.split(":" , 2); 
						ttList.add(new TextTypeWrapperImpl(localeValueSplit[0], localeValueSplit[1]));
					}
					nodeValues.add(new MultilingualNodeValue(ttList));
				}
				IMultilingualKeyValue mkv = new MultilingualKeyValue(attrId, nodeValues);
				this.dataWriterEngine.writeMultilingualAttributeValue(mkv);
			}
		}
	}
	private boolean attributesUpdated(IDataRow dataRow, List<String> attributeIds) {
		if(lastRow == null) return true;
		Map<String, String> values                = dataRow.getRowData();
		Map<String, Set<String>> multiValueData   = dataRow.getMultiValueData();
		Map<String, Set<String>> multiLingualValueData = dataRow.getMultilingualValueData();
		for(String attrId : attributeIds) {
			String value = values.get(attrId);
			Set<String> multiValueAttribute = multiValueData.get(attrId);
			if(value != null) {
				if(!value.equals(lastRow.getReportedValue(attrId))) {
					return true;
				}
			}  else if(lastRow.getReportedValue(attrId) != null) {
				return true;
			}
			
			Set<String> lastMVData = lastRow.getReportedValues(value);
			if(!ObjectUtil.equivalentCollection(lastMVData, multiValueAttribute)) {
				return true;
			}
			Set<String> lastMLData = lastRow.getReportedMultilingualValues(value);
			if(!ObjectUtil.equivalentCollection(lastMLData, multiLingualValueData.get(attrId))) {
				return true;
			}
		}
		return false;
	}
	
	

	@Override
	public void writeRow(IDataRow dataRow) {
		if(this.dsd == null) {
			setStructures(dataRow.getDatasetStructures());
		}
		Map<String, String> values                = dataRow.getRowData();
		
		if(!firstRowWritten) {
			writeAttributes(dataRow,  SdmxCollectionUtil.identifiablesIdList(dsd.getDatasetAttributes()));
			firstRowWritten = true;
		}
		boolean isGroup = false;
		Set<String> processedGroups = null;
		for(String groupAttr : groupAttributeIdToGroupName.keySet()) {
			if(values.containsKey(groupAttr)) {
				isGroup = true;
				String groupId = groupAttributeIdToGroupName.get(groupAttr);
				if(processedGroups == null) {
					processedGroups = new HashSet<>();
				}
				if(processedGroups.contains(groupId)) {
					continue;
				}
				processedGroups.add(groupId);
				if (isNewGroup(groupId, values)) {
				    writeGroup(groupId, dataRow);
				}
			}
		}
		if(isGroup) {
			//only continue if all the dimensions are present as it could also be reporting a series
			for(String dimId : dimensionIds) {
				String dimValue = values.get(dimId);
				if(dimValue == null) {
					return;
				}
			}
		}

		if(isNewSeries(dataRow)) {
			writeSeries(dataRow);
		}
		//Write Obs
		String obConceptValue = values.get(this.dimensionAtObservation);
		List<KeyValue> measures = new ArrayList<>(measureIds.size());
		for(String measureId : measureIds) {
			String measureValue = values.get(measureId);
			if(measureValue != null) {
				measures.add(KeyValueImpl.getInstance(measureId, measureValue));
			}
		}
		boolean hasObs = obConceptValue != null || measures.size() > 0;
		if(!hasObs) {
			for(String attrId : obsAttributeIds) {
				if(dataRow.getReportedValue(attrId) != null ||
						ObjectUtil.validCollection(dataRow.getReportedValues(attrId)) || 
						ObjectUtil.validCollection(dataRow.getReportedMultilingualValues(attrId))) {
					hasObs = true;
					break;
				}
			}
		}
		if(hasObs) {
			String dimAtObs = obConceptValue == null ? null : dimensionAtObservation;
			dataWriterEngine.writeObservation(dimAtObs, obConceptValue, measures);
			writeAttributes(dataRow, obsAttributeIds);
		}
		this.lastRow = dataRow;
	}

	private boolean isNewSeries(IDataRow dataRow) {
		for(String dimId : dimensionIds) {
			String dimValue = dataRow.getReportedValue(dimId);
			if(!ObjectUtil.equivalent(dimValue, currentKey.get(dimId))) {
				return true;
			}
		}
		return attributesUpdated(dataRow, seriesAttributeIds);
	}

	private void writeSeries(IDataRow dataRow) {
		currentKey = new HashMap<>();

		this.dataWriterEngine.startSeries();
		for(String dimId : dimensionIds) {
			String dimValue = dataRow.getReportedValue(dimId);
			currentKey.put(dimId, dimValue);
			if(dimValue != null) {
				this.dataWriterEngine.writeSeriesKeyValue(dimId, dimValue);
			}
		}
		// Write the series to the DWE and store them away for future checking
		writeAttributes(dataRow, seriesAttributeIds);
		
		//, values, currentSeriesAttr);
	}

	protected boolean isNewGroup(String groupId, Map<String, String> values) {
        if (currentGroup.isEmpty()) {
            setCurrentGroup(values, dsd.getGroup(groupId));
    	    return true;
        }

	    for (String elementId : currentGroup.keySet()) {
            String dimValue = values.get(elementId);

            if (dimValue == null && currentGroup.get(elementId) != null) {
                setCurrentGroup(values, dsd.getGroup(groupId));
                return true;
            }

            if (dimValue != null && !dimValue.equals(currentGroup.get(elementId))) {
                // The element is different so this is a new group
                setCurrentGroup(values, dsd.getGroup(groupId));
                return true;
            }
        }

	    // Not a new group
	    return false;
	}

    private void setCurrentGroup(Map<String, String> values, GroupBean group) {
        // Obtain the Dimensions and Attributes for the current group
        Set<String> groupElements = group.getDimensionRefs().stream().collect(Collectors.toSet());
        Set<String> groupAttr = dsd.getGroupAttributes().stream().map(attr -> attr.getId()).collect(Collectors.toSet());
        groupElements.addAll(groupAttr);

        currentGroup = new HashMap<>();
        // Walk the supplied values adding any group elements to the currentGroup field
        for (Map.Entry<String,String> entry : values.entrySet()) {
            if (groupElements.contains(entry.getKey())) {
                currentGroup.put(entry.getKey(), entry.getValue());
            }
        }
    }

	private void writeGroup(String groupId, IDataRow dataRow) {
		dataWriterEngine.startGroup(groupId);
		for(String dimId : groupDimensions.get(groupId)) {
			String dimValue = dataRow.getReportedValue(dimId);
			if (dimValue != null) {
				this.dataWriterEngine.writeGroupKeyValue(dimId, dimValue);
			}
		}
		writeAttributes(dataRow, groupAttributeMap.get(groupId));
	}
	

	@Override
	public void close() {
		dataWriterEngine.close();
	}
}
