package io.sdmx.core.data.factory.process;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.data.api.factory.IDataProcessFactory;
import io.sdmx.core.data.api.manager.IProcessStepRetrievalManager;
import org.codehaus.jettison.json.JSONObject;

/**
 * Represents a process which is a proxy on another process
 */
public abstract class AbstractProxyMappingProcess implements IDataProcessFactory {

	@Override
	/**
	 * Properties must include an Output property which has only 1 value
	 */
	public final IFlatDataWriterEngine getDataWriterEngine(JSONObject properties, IProcessStepRetrievalManager stepRetrievalManager) {
		if(!properties.has("Output")) {
			throw new SdmxSemmanticException("Process Step '"+getProcessId()+"' requires an Output step");
		}
		if(stepRetrievalManager == null) {
			throw new SdmxException("AbstractProxyMappingProcess.getDataWriterEngine requires a IProcessStepRetrievalManager");
		}
		String outputStepId = JsonObjectUtil.getString(properties, "Output", false);
		IFlatDataWriterEngine proxy = getProxy(outputStepId, stepRetrievalManager);
		return getDataWriterEngine(properties, proxy, stepRetrievalManager);
	}
	
	protected IFlatDataWriterEngine getProxy(String outputId, IProcessStepRetrievalManager stepRetrievalManager) {
		IFlatDataWriterEngine proxy = stepRetrievalManager.getProcessStep(outputId);
		if(proxy == null) {
			throw new SdmxSemmanticException("Output Process Step '"+outputId+"' not found");
		}
		return proxy;
	}
	
	protected abstract IFlatDataWriterEngine getDataWriterEngine(JSONObject properties, IFlatDataWriterEngine proxy, IProcessStepRetrievalManager stepRetrievalManager);
}
