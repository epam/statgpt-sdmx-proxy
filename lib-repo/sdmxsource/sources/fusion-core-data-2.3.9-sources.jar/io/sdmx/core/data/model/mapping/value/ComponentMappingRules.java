package io.sdmx.core.data.model.mapping.value;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.core.data.api.model.mapping.IComponentMappingRules;
import io.sdmx.core.data.api.model.mapping.IExplainMapComponent;
import io.sdmx.core.data.api.model.mapping.IExplainMapMatch.MAP_RULE_TYPE;
import io.sdmx.core.data.model.mapping.explain.ExplainMapComponent;
import io.sdmx.core.data.model.mapping.explain.ExplainMapMatch;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;

/**
 * Represents a Component mapping to a Component, OR multiple input Components whose concatenation of values map to an output, or a single source component which maps to a concatenated output
 * <p/>
 * Rules are applied in the following order:
 * 1. Explicit rule matches (no wildcarding or sub-string)
 * 2. Wildcard/substring applied - first match wins, as ordered in the {@link IComponentMapBean}
 * 
 * Note, rules are stored in baskets of periods - a single period can contain a combination of explicit rules and combination rules
 * 
 * 
 * If the {@link IRepresentationMapBean} is referenced then implicit mapping is used (same value out as the value in)
 */
public class ComponentMappingRules implements IComponentMappingRules {
	private List<String> sourceComponents;
	private List<String> targetComponents;

	//1. Explicit Mapping Rules - single source and target
	private Map<SdmxPeriod, Map<String, Set<String>>> simpleRules  = new HashMap<>();

	//1. Explicit Mapping Rules - multiple source or target
	private Map<SdmxPeriod, Map<ExplicitMappingRule, Set<String[]>>> multiSimpleRules = new HashMap<>();

	//2. Fuzzy rules that rely on pattern matching
	private Map<SdmxPeriod, List<FuzzyMappingRule>> fuzzyRules = new HashMap<>();

	private boolean verbatimCopy = false;  //Implicit Mapping (no rules)
	private boolean isSimple = false;
	private boolean isTimeBound = false;
	private boolean outputRequired = false;
	private String id;
	
	private int[] ignoreCase;  //ignore case by source component index
	
	/**
	 * @param source - source component ids
	 * @param target - target component ids
	 * @param repMap - the mapping rules, null to indicate implicit mapping (i.e just copy the source value to the target)
	 */
	public ComponentMappingRules(List<String> source, List<String> target, IRepresentationMapBean repMap, boolean outputRequired) {
		this.outputRequired = outputRequired;
		sourceComponents = Collections.unmodifiableList(new ArrayList<>(source));
		targetComponents = Collections.unmodifiableList(new ArrayList<>(target));;

		if(repMap == null) {
			//this is a verbatim copy of values
			verbatimCopy = true;
			return;
		} else {
			this.id = repMap.getShortURN();
		}
		//IF the source is of type BOOLEAN then the case should not matter
		
		
		
		isSimple = sourceComponents.size() == 1 && targetComponents.size() == 1;
		List<Integer> ignoreByIndex = new ArrayList<>();
		for(int i=0; i < repMap.getSourceRef().size(); i++) {
			boolean ignoreCase = repMap.getSourceRef().get(i).getTextType() == TEXT_TYPE.BOOLEAN;
			if(ignoreCase) {
				ignoreByIndex.add(i);
			}
		}
		if(ignoreByIndex.size() > 0) {
			this.ignoreCase = new int[ignoreByIndex.size()];
			for(int i=0; i < ignoreByIndex.size(); i++) {
				this.ignoreCase[i] = ignoreByIndex.get(i);
			}
		}
		
		for(IMappedRelationshipBean mappedRelationship : repMap.getMappedValues()) {
			SdmxPeriod validityPeriod = mappedRelationship.getValidityPeriod();
			if(validityPeriod == null) {
				validityPeriod = SdmxPeriodImpl.ALL_PERIODS;
			}
			boolean isExplicitRule = true;
			for(IMappedValueBean sourceValue : mappedRelationship.getSourceValue()) {
				if(sourceValue.isRegEx() || sourceValue.getStartIndex() > 0 || sourceValue.getEndIndex() > 0) {
					isExplicitRule = false;
					break;
				}
			}
			if(isExplicitRule) {
				if(isSimple) {
					IMappedValueBean mappedValue = mappedRelationship.getSourceValue().get(0);
					String input = mappedValue.getValue();

					// FMR-693: If there is no target value, explicitly set the output to "null".
					// The RepresentationMap is stating that this should not be mapped at all.
					List<String> targetValues = mappedRelationship.getTargetValue();
					String output = targetValues.isEmpty() ? null : targetValues.get(0);

					Map<String, Set<String>> mappedValues = simpleRules.get(validityPeriod);
					if(mappedValues != null && this.ignoreCase != null) {
						Map<String, Set<String>> mappedValuesCopy = new HashMap<>(mappedValues.size());
						for(String sourceValue : mappedValues.keySet()) {
							mappedValuesCopy.put(sourceValue.toLowerCase(), mappedValues.get(sourceValue));
						}
						mappedValues = mappedValuesCopy;
					}
					if(mappedValues == null) {
						mappedValues = new HashMap<>();
						simpleRules.put(validityPeriod, mappedValues);
					}
					CollectionUtil.addToMappedSet(mappedValues, input, output);
				} else {
					Map<ExplicitMappingRule, Set<String[]>> explicitMappings = multiSimpleRules.get(validityPeriod);
					if(explicitMappings == null) {
						explicitMappings = new HashMap<>();
						multiSimpleRules.put(validityPeriod, explicitMappings);
					}
					String[] outputValue = CollectionUtil.toArray(mappedRelationship.getTargetValue());
					String[] sourceValue = new String[mappedRelationship.getSourceValue().size()];
					for(int i=0;i < mappedRelationship.getSourceValue().size(); i++) {
						sourceValue[i] = mappedRelationship.getSourceValue().get(i).getValue();
					}
					if(ignoreCase != null) {
						for(int i =0; i < ignoreCase.length; i++) {
							int idx = ignoreCase[i];
							sourceValue[idx] = sourceValue[idx].toLowerCase();
						}
					}
					CollectionUtil.addToMappedSet(explicitMappings, new ExplicitMappingRule(sourceValue), outputValue);
				}
			} else {
				//Fuzzy Rule
				List<FuzzyMappingRule> rules = fuzzyRules.get(validityPeriod);
				if(rules == null) {
					rules = new ArrayList<>();
					fuzzyRules.put(validityPeriod, rules);
				}
				rules.add(new FuzzyMappingRule(mappedRelationship));
			}
		}

		fuzzyRules = Collections.unmodifiableMap(fuzzyRules);
		//patternSourceToTargetCodeMappingsByDate = Collections.unmodifiableMap(patternSourceToTargetCodeMappingsByDate);
		multiSimpleRules = Collections.unmodifiableMap(multiSimpleRules);

		processTimeBound(simpleRules.keySet());
		processTimeBound(fuzzyRules.keySet());
		processTimeBound(multiSimpleRules.keySet());
	}
	
	private void processTimeBound(Set<SdmxPeriod> periods) {
		if(isTimeBound) {
			return;
		}
		for(SdmxPeriod period : periods) {
			if(!period.isAllPeriods()) {
				isTimeBound = true;
				return;
			}
		}
	}
	
	@Override
	public boolean outputRequired() {
		return outputRequired;
	}

	@Override
	public boolean isTimeDependant() {
		return isTimeBound;
	}

	@Override
	public List<String> getSourceComponents() {
		return sourceComponents;
	}

	@Override
	public List<String> getTargetComponents() {
		return targetComponents;
	}
	
	@Override
	public String getId() {
		return id;
	}
	
	@Override
	/**
	 * Returns a map of output component, to time period set of mapped values
	 * @param requestedPeriod optional, period to apply mapping rules for
	 * @param explain - optional, provided to capture the breakdown of mapping
	 * @param sourceValues this is the reported source value(s), expects a value per mapped source
	 * @return
	 */
	public IExplainMapComponent explain(SdmxPeriod requestedPeriod, String... sourceValue) {
		ExplainMapComponent explain = new ExplainMapComponent(sourceComponents, targetComponents);
		getMappedCodes(requestedPeriod, explain, sourceValue);
		return explain;
	}

	@Override
	/**
	 * Returns a map of output component, to time period set of mapped values
	 * @param requestedPeriod optional, period to apply mapping rules for
	 * @param explain - optional, provided to capture the breakdown of mapping
	 * @param sourceValues this is the reported source value(s), expects a value per mapped source
	 * @return
	 */
	public Map<SdmxPeriod, Set<KeyValue>> getMappedCodes(SdmxPeriod requestedPeriod, String... sourceValue) {
		return getMappedCodes(requestedPeriod, null, sourceValue);
	}

	/**
	 * Returns a map of output component, to time period set of mapped values
	 * @param requestedPeriod optional, period to apply mapping rules for
	 * @param explain - optional, provided to capture the breakdown of mapping
	 * @param sourceValues this is the reported source value(s), expects a value per mapped source
	 * @return
	 */
	public Map<SdmxPeriod, Set<KeyValue>> getMappedCodes(SdmxPeriod requestedPeriod, ExplainMapComponent explain, String...sourceValues) {
		if(sourceValues == null) {
			return Collections.emptyMap();
		}
		for(String sv : sourceValues) {
			if(sv == null) {
				return Collections.emptyMap();
			}
		}
		if(ignoreCase != null) {
			for(int i =0; i < ignoreCase.length; i++) {
				int idx = ignoreCase[i];
				sourceValues[idx] = sourceValues[idx].toLowerCase();
			}
		}
		
		Map<SdmxPeriod, Set<KeyValue>> returnMap = new HashMap<>();
		if(verbatimCopy) {
			String mappedValue = sourceValues[0];
			if(sourceValues.length > 1)  {
				StringBuilder sb = new StringBuilder();
				for(String mappedVal : sourceValues) {
					if(mappedVal != null) {
						sb.append(mappedVal);
					}
				}
				mappedValue  = sb.toString();
			}
			if(ObjectUtil.validString(mappedValue)) {
				//We only want to copy if there is an input which is not empty
				//TODO a verbatim copy should only be allowed if there is one input value - this needs to be policed
				Set<KeyValue> returnSet = new HashSet<>();
				for(String target : targetComponents) {
					returnSet.add(KeyValueImpl.getInstance(target, mappedValue));
				}
				returnMap.put(SdmxPeriodImpl.ALL_PERIODS, returnSet);
				if(explain != null) {
					for(String target : targetComponents) {
						ExplainMapMatch match = new ExplainMapMatch();
						match.setRuleType(MAP_RULE_TYPE.IMPLICIT);
						match.setComponent(target);
						match.setInput(mappedValue);
						explain.addMatch(SdmxPeriodImpl.ALL_PERIODS, match);
						explain.addOutput(SdmxPeriodImpl.ALL_PERIODS, KeyValueImpl.getInstance(target, mappedValue));
					}
				}
			}
			return returnMap;
		}

		//1. Try to find explicit mapping
		if(isSimple) {
			for(SdmxPeriod period : simpleRules.keySet()) {
				if(requestedPeriod != null && !period.isInPeriod(requestedPeriod)) {
					continue;
				}
				Set<KeyValue> kvForPeriod =  getFromSimpleMap(simpleRules.get(period), sourceValues[0]);
				if(ObjectUtil.validCollection(kvForPeriod)) {
					returnMap.put(period, kvForPeriod);
					explainEquals(sourceValues[0], kvForPeriod, period, explain);
				}
			}
		} else {
			for(SdmxPeriod period : multiSimpleRules.keySet()) {
				if(requestedPeriod != null && !period.isInPeriod(requestedPeriod)) {
					continue;
				}
				Map<ExplicitMappingRule, Set<String[]>> sourceToTargetCodeMappings = multiSimpleRules.get(period);
				Set<KeyValue> kvForPeriod = getFromExplicitMap(sourceToTargetCodeMappings, sourceValues);
				if(ObjectUtil.validCollection(kvForPeriod)) {
					returnMap.put(period, kvForPeriod);
					explainEquals(SeriesUtil.toSeriesKey(sourceValues), kvForPeriod, period, explain);
				}
			}
		}

		Set<SdmxPeriod> processedPeriods = new HashSet<>(returnMap.keySet());
		//If no matches were found for 'all periods' check the fuzzyRules set
		if(!returnMap.containsKey(SdmxPeriodImpl.ALL_PERIODS)) {
			outer:
				for(SdmxPeriod period : fuzzyRules.keySet()) {
					//If the requested period is not in the current period, OR the current period has already had an explicit match found, then skip
					if((requestedPeriod != null && !period.isInPeriod(requestedPeriod)) || processedPeriods.contains(period)) {
						continue;
					}
					//Check each fuzzy rule - first one wins!
					for(FuzzyMappingRule rule : fuzzyRules.get(period)) {
						String[] mapped = rule.map(sourceValues);
						if(mapped != null) {
							if(explain != null) {
								//There is an ExplainMapMatch for each source value that maps
								List<ExplainMapMatch> explainMatch = rule.explain(sourceValues);
								int explainMatchIndex = -1;
								for(int i=0; i < this.targetComponents.size(); i++) {
									String target = this.targetComponents.get(i);
									//There may be less explainMatch if only some of the source values mapped
									if (explainMatch.size() > i) {
										explainMatchIndex = i;
									}
									//set the source component that matched
									ExplainMapMatch emMatch = explainMatch.get(explainMatchIndex);
									emMatch.setComponent(target);
									//add the match
									explain.addMatch(period, emMatch);
									//explain the output
									explain.addOutput(period, KeyValueImpl.getInstance(target, mapped[i]));
								}
							}
							returnMap.put(period, codeArrayToKeyValue(mapped));
							continue outer;
						}
					}
				}
		}
		return returnMap;
	}
	
	private void explainEquals(String input, Set<KeyValue> kvForPeriod, SdmxPeriod period, ExplainMapComponent explain) {
		if(explain != null) {
			for(String component : this.sourceComponents) {
				ExplainMapMatch match = new ExplainMapMatch();
				match.setRuleType(MAP_RULE_TYPE.EQUALS);
				match.setComponent(component);
				match.setInput(input);
				explain.addMatch(period, match);
			}
			for(KeyValue kv : kvForPeriod) {
				explain.addOutput(period, kv);
			}
		}
	}

	/**
	 * @param inputMap
	 * @param codeId
	 * @return mapped keys for input code id
	 */
	private Set<KeyValue> getFromExplicitMap(Map<ExplicitMappingRule, Set<String[]>> inputMap, String[] values) {
		ExplicitMappingRule codeAsRule = new ExplicitMappingRule(values);
		Set<String[]> set1 = inputMap.get(codeAsRule);
		if(set1 != null) {
			return codeArrayToKeyValue(set1);
		}
		return null;
	}

	/**
	 * @param inputMap
	 * @param codeId
	 * @return mapped keys for input code id
	 */
	private Set<KeyValue> getFromSimpleMap(Map<String, Set<String>> inputMap, String key) {
		Set<String> set1 = inputMap.get(key);
		if(set1 != null) {
			return codesKeyValue(set1);
		}
		return null;
	}

	/**
	 * Converts a set of output CodeIds to a set of Key Values
	 * @param codes
	 * @return
	 */
	private Set<KeyValue> codesKeyValue(Set<String> codes) {
		Set<KeyValue> kvForPeriod = new HashSet<>();
		for(String codeId : codes) {
			kvForPeriod.add(KeyValueImpl.getInstance(targetComponents.get(0), codeId));
		}
		return kvForPeriod;
	}

	/**
	 * Converts a set of output CodeIds to a set of Key Values
	 * @param codes
	 * @return
	 */
	private Set<KeyValue> codeArrayToKeyValue(Set<String[]> codes) {
		Set<KeyValue> kvForPeriod = new HashSet<>();
		for(String[] codeIds : codes) {
			codeArrayToKeyValue(codeIds, kvForPeriod);
		}
		return kvForPeriod;
	}
	
	/**
	 * Converts a set of output CodeIds to a set of Key Values
	 * @param codes
	 * @return
	 */
	private Set<KeyValue> codeArrayToKeyValue(String[] codeIds) {
		Set<KeyValue> kvForPeriod = new HashSet<>();
		codeArrayToKeyValue(codeIds, kvForPeriod);
		return kvForPeriod;
	}

	/**
	 * Converts a set of output CodeIds to a set of Key Values
	 * @param codes
	 * @return
	 */
	private void codeArrayToKeyValue(String[] codeIds, Set<KeyValue> kvForPeriod) {
		int i = 0;
		for(String currentCodeId : codeIds) {
			kvForPeriod.add(KeyValueImpl.getInstance(targetComponents.get(i), currentCodeId));
			i++;
		}
	}
}
