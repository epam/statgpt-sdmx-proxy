package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.ObsTimeMatchesFrequencyValidationEngine;

public class ObsTimeMatchFreqValidatorFactory implements DataValidatorFactory {

    @Override
    public DataValidationEngine createInstance(DatasetInformation dsi) {
    	DimensionBean dimension = dsi.getDatasetStructures().getDataStructure().getFrequencyDimension();
    	if(dimension == null) {
    		return null;
    	}
        return new ObsTimeMatchesFrequencyValidationEngine(dimension);
    }

    @Override
    public String getId() {
        return "TimePeriodFormat";
    }

    @Override
    public String getName() {
        return "Time Period Format";
    }

	@Override
	public String getDescription() {
		return "Ensure the reported Frequency code matches the reported time period, for example FREQ=A will expect time periods in format YYYY."
				+ " This test only applies when the DSD has a Frequency Dimension.";
	}
	
	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return false;
	}
	
	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.IGNORE;
	}

	@Override
	public int hashCode() {
		return "ObsTimeMatchFreqValidatorFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ObsTimeMatchFreqValidatorFactory;
	}
}