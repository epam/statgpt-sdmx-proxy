package io.sdmx.core.data.model.process;

import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.core.data.api.model.process.IProcessStep;
import org.codehaus.jettison.json.JSONObject;

public class ProcessStep implements IProcessStep {
	private String processId;
	private String stepId;
	private boolean captureMetrics;
	private JSONObject processProperties;

	public ProcessStep(String processId, String stepId, boolean captureMetrics, JSONObject processProperties) {
		this.processId = processId;
		this.stepId = stepId;
		this.captureMetrics = captureMetrics;
		this.processProperties = processProperties;
	}

	/**
	 * Build from JSON, format:
	 * <pre>
	 *  {
	 *  	"ProcessId"  : "VALIDATE"  //Id of a registered process
	 *      "StepId"     : "STEP1"     //Unique Id for the step
	 *      "Metrics"    : true        //true to capture metrics for the process
	 *      "Properties" : {}  		   //optional map of properties specific to the process
	 *  }
	 * </pre>
	 * @param json
	 */
	public ProcessStep(JSONObject json) {
		this.processId = JsonObjectUtil.getString(json, "ProcessId", false);
		this.stepId = JsonObjectUtil.getString(json, "StepId", false);
		this.captureMetrics = JsonObjectUtil.getBoolean(json, "Metrics", true);
		this.processProperties = JsonObjectUtil.getJsonObject(json, "Properties", true);
		if(this.processProperties == null) {
			processProperties = new JSONObject();
		}
	}



	@Override
	public String getProcessId() {
		return processId;
	}

	@Override
	public String getStepId() {
		return stepId;
	}

	@Override
	public boolean captureMetrics() {
		return captureMetrics;
	}

	@Override
	public JSONObject getProcessProperties() {
		return processProperties;
	}
}
