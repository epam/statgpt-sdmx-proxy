package io.sdmx.core.data.service;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.service.data.IDataMappingService;
import io.sdmx.core.data.api.manager.SdmxMappingManager;
import io.sdmx.core.data.model.dataset.DataRow;
import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.core.application.SingletonStore;

public class DataMappingService implements IDataMappingService {
	
	private SdmxMappingManager mappingManager;

	public DataMappingService(SdmxMappingManager mappingManager) {
		this.mappingManager = mappingManager;
	}
	
	@Override
	public void explainMap(ReadableDataLocation rdl, IURNSingle<IStructureMapBean> mapRef, boolean isSource, OutputStream out, boolean isValidating) {
		mappingManager.writeMappingReport(rdl, mapRef, isSource, out, isValidating);
	}

	@Override
	public void explainMap(IURNSingle<IStructureMapBean> mapRef, boolean isSource, String[] key, Map<String, String> componentValues, OutputStream out) {
		DataStructureBean dsd = getMapDSD(mapRef, isSource);
		if(key != null) {
			int i =0;
			
			List<DimensionBean> dims = dsd.getDimensionList().getDimensions();
			for(String keyValue : key) {
				if(dims.size() > i) {
					componentValues.put(dims.get(i).getId(), keyValue);
				}
				i++;
			}
		}
		IDataRow dataRow = new DataRow(new DatasetStructures(dsd), componentValues);
		mappingManager.writeExplainPlan(mapRef, dataRow, out);
	}
	
	private DataStructureBean getMapDSD(IURNSingle<IStructureMapBean> mapRef, boolean isSource) {
		SdmxBeanRetrievalManager brm = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class).getBeanRetrievalManager(true);
		IStructureMapBean map = brm.getBean(mapRef);
		if (map == null) {
			throw new SdmxReferenceException(mapRef);
		}
		ICrossReferenceBean<?> strRef = isSource ? map.getSourceRef() : map.getTargetRef();
		ICrossReferenceBean<?> dsdRef = strRef.getTargetReference() == SDMX_STRUCTURE_TYPE.DSD ? strRef : null;
		
		if(dsdRef == null) {
			DataflowBean flow = brm.getBean(strRef.getReference().toType(DataflowBean.class));
			if(flow == null) {
				throw new CrossReferenceException(strRef);
			}
			dsdRef = flow.getDataStructureRef();
		}
		DataStructureBean dsd = brm.getBean(dsdRef.getReference().toType(DataStructureBean.class));
		if(dsd == null) {
			throw new CrossReferenceException(dsdRef);
		}
		return dsd;
	}
 
}
