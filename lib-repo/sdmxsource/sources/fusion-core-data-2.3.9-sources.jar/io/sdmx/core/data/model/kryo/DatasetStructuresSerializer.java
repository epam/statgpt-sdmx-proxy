package io.sdmx.core.data.model.kryo;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.utils.sdmx.xs.URN;

public class DatasetStructuresSerializer extends Serializer<IDatasetStructures> {
	private static final DatasetStructuresSerializer WRITE_INSTANCE = new DatasetStructuresSerializer(null);
	private SdmxBeanRetrievalManager brm;
	
	public static DatasetStructuresSerializer getWriteInstance() {
		return WRITE_INSTANCE;
	}
	
	public static DatasetStructuresSerializer getReadInstance(SdmxBeanRetrievalManager brm) {
		return new DatasetStructuresSerializer(brm);
	}
	
	public DatasetStructuresSerializer(SdmxBeanRetrievalManager brm) {
		this.brm = brm;
	}

	@Override
	public void write(Kryo kryo, Output output, IDatasetStructures object) {
		writeUrn(kryo, output, object.getConstrainable());
		
	}

	private void writeUrn(Kryo kryo, Output output, IdentifiableBean constrainable) {
		kryo.writeObjectOrNull(output,  constrainable == null ? null : constrainable.getUrn(), String.class);
	}
	
	@Override
	public IDatasetStructures read(Kryo kryo, Input input, Class<? extends IDatasetStructures> type) {
		String urn = kryo.readObject(input, String.class);
		return new DatasetStructures(URN.getInstanceSingle(ConstrainableBean.class, urn), brm);
	}
	
}
