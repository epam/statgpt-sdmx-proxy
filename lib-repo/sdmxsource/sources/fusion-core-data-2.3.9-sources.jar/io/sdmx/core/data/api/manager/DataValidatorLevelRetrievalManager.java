package io.sdmx.core.data.api.manager;

import java.util.Set;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;

/**
 *Provides an API to check the level of a validation result
 */
public interface DataValidatorLevelRetrievalManager {

    /**
     * @return whether to ignore this error
     */
	VALIDATION_LEVEL getValidationLevel(String key);
	
	
	/**
	 * Returns a set of keys which represent all the error categories with VALIDATION_LEVEL.IGNORE
	 * @return
	 */
	Set<String> getAllIgnoreCategories();

}