package io.sdmx.core.data.engine.reader;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.im.data.DatasetAttributes;

/**
 * override the dataset attributes in the underlying reader
 */
public class DatasetAttributeOverrideDataReaderEngine extends AbstractWrapperedDataReaderEngine {
	private Map<Integer, List<KeyValue>> dsAttributes;  //dataset attribute by index

	public DatasetAttributeOverrideDataReaderEngine(Map<Integer, List<KeyValue>> dsAttributes, DataReaderEngine dataReaderEngine) {
		super(dataReaderEngine);
		if(dsAttributes == null) {
			dsAttributes = Collections.emptyMap();
		} else {
			Map<Integer, List<KeyValue>> immutableCopy = new HashMap<>();
			for(Integer key : dsAttributes.keySet()) {
				List<KeyValue> values = dsAttributes.get(key);
				if(values == null) {
					values = Collections.emptyList();
				} else {
					values = Collections.unmodifiableList(values);
				}
				immutableCopy.put(key, values);
			}
			dsAttributes = Collections.unmodifiableMap(immutableCopy);
			
		}
		this.dsAttributes = dsAttributes;
	}
	
	@Override
	protected DataReaderEngine createWrappedCopy(DataReaderEngine proxyCopy) {
		return new DatasetAttributeOverrideDataReaderEngine(dsAttributes, proxyCopy);
	}
	
	@Override
	public IDatasetAttributes getDatasetAttributes() {
		List<KeyValue> kvs = dsAttributes.get(super.dataReaderEngine.getDatasetPosition());
		if(kvs == null) {
			kvs = Collections.emptyList();
		}
		return new DatasetAttributes(kvs);
	}
	
}
