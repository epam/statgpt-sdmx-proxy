package io.sdmx.core.data.factory.datavalidation;

import io.sdmx.api.sdmx.constants.VALIDATION_LEVEL;
import io.sdmx.core.data.api.engine.validate.DataValidationEngine;
import io.sdmx.core.data.api.factory.DataValidatorFactory;
import io.sdmx.core.data.api.model.dataset.DatasetInformation;
import io.sdmx.core.data.engine.validate.MissingTimePeriodsValidationEngine;

public class MissingTimePeriodsValidationFactory implements DataValidatorFactory {

	@Override
	public String getName() {
		return "Missing Observations";
	}

	@Override
	public String getDescription() {
		return "Ensures that the Series reports an observation value for the time period that lies within the time range that the series is reporting data for.  "
				+ "For example if the first Observation value for a series is reported for 2001 and the last is reported for 2004, then this test that observations were reported for 2001, 2002, 2003, and 2004";
	}

	@Override
	public String getId() {
		return "MISSING_TIME_PERIODS";
	}

	@Override
	public VALIDATION_LEVEL getMinErrorLevel() {
		return VALIDATION_LEVEL.IGNORE;
	}

	@Override
	public DataValidationEngine createInstance(DatasetInformation dsi) {
		if(dsi.getDatasetStructures().getDataStructure().getTimeDimension() != null) {
			return new MissingTimePeriodsValidationEngine();
		}
		return null;
	}

	@Override
	public boolean validationLinkedToFlowOrProvision() {
		return false;
	}

	@Override
	public boolean validationRequiresKnowledgeOfPreviouslyReportedData() {
		return false;
	}

	@Override
	public int hashCode() {
		return "MissingTimePeriodsValidationFactory".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof MissingTimePeriodsValidationFactory;
	}
	
}
