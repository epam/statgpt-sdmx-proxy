package io.sdmx.format.csv.constant;

import io.sdmx.utils.core.object.ObjectUtil;

// Specifies what is output when outputting a CSV
public enum CSV_LABEL {
    ID("ID"),
    NAME("NAME"),
    ID_AND_NAME ("ID_AND_NAME"),
    ALL_LANG ("ALL_LANG");

    private String propertyName;

	private CSV_LABEL(String prop) {
		this.propertyName = prop;
	}

	public String getPropertyName() {
		return propertyName;
	}
	
	/**
	 * From REST query parameter
	 * @param labels
	 * @return
	 */
	public static CSV_LABEL fromParam(String labels) {
		 // Check the parameterValues
        if(ObjectUtil.validString(labels)) {
            if (labels.equals("both")) {
                return CSV_LABEL.ID_AND_NAME;
            } else if (labels.equals("name")) {
            	return CSV_LABEL.NAME;
            } else if (labels.equals("all-lang")) {
            	return CSV_LABEL.ALL_LANG;
            }
        }
        return CSV_LABEL.ID;
	}

	public static CSV_LABEL resolvePropertyName(String prop) {
		for(CSV_LABEL currentProp : CSV_LABEL.values()) {
			if(currentProp.getPropertyName().equals(prop)) {
				return currentProp;
			}
		}
		throw new IllegalArgumentException("Could not resolve property '"+prop+"' to a CSV Label type");
	}
}
