package io.sdmx.format.csv.format;

import java.util.Locale;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.core.data.api.manager.DataWriterManager;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.format.csv.constant.CSV_LABEL;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Represents the properties used to describe the desired contents of a SDXM CSV Dataset
 * @see DataWriterManager
 */
public class SdmxCsvDataFormat extends SdmxDataFormat {
	public static final SdmxCsvDataFormat BASIC_V2 = new SdmxCsvDataFormat(DATA_TYPE.SDMX_CSV_2_0_0, null, false, false, null, DELIMITER.COMMA);
	
	public static final String DEFAULT_KEYS_PARAM_HEADER = "KEY";
	
	private static final long serialVersionUID = 1L;
	private FormatDetails formatDetails;
	private String asVNDString; //LAZY LOADED
	private boolean includeNames;
	private boolean normalizedTime = false;
	private boolean includeBom = false;
	private Locale locale;
    private boolean includeSeriesKey;
    private boolean includeObsKey;
    private String rowHeaderValue;
    private boolean includeAction;
    private CSV_LABEL csvLabel;
	private DELIMITER delimiter;
    
	public SdmxCsvDataFormat(DATA_TYPE dt, String labelsParam, boolean normalizedTime, boolean includeBom, Locale locale) {
		this(dt, labelsParam, normalizedTime, includeBom, locale, false, false, null, false, DELIMITER.COMMA);
	}
	
	public SdmxCsvDataFormat(DATA_TYPE dt, String labelsParam, boolean normalizedTime, boolean includeBom, Locale locale, DELIMITER delimiter) {
		this(dt, labelsParam, normalizedTime, includeBom, locale, false, false, null, false, delimiter);
	}

	public SdmxCsvDataFormat(DATA_TYPE dt, String labelsParam, boolean normalizedTime, boolean includeBom, Locale locale, boolean includeSeriesKey, boolean includeObsKey, String rowHeaderValue, boolean includeAction) {
		this(dt, labelsParam, normalizedTime, includeBom, locale, includeSeriesKey, includeObsKey, rowHeaderValue, includeAction, DELIMITER.COMMA);
	}
	
    public SdmxCsvDataFormat(DATA_TYPE dt, String labelsParam, boolean normalizedTime, boolean includeBom, Locale locale, boolean includeSeriesKey, boolean includeObsKey, String rowHeaderValue, boolean includeAction, DELIMITER delimiter) {
        super(dt);
        this.includeNames = analyseLabelsParam(labelsParam);
        this.normalizedTime = normalizedTime;
        this.includeBom = includeBom;
        this.locale = locale;
        this.includeSeriesKey = includeSeriesKey;
        this.includeObsKey = includeObsKey;
        this.rowHeaderValue = rowHeaderValue;
        this.includeAction = includeAction;
        this.delimiter = delimiter;
        if(dt != DATA_TYPE.SDMX_CSV_1_0 && dt != DATA_TYPE.SDMX_CSV_2_0_0) {
        	throw new IllegalArgumentException("SdmxCsvDataFormat can only take formats DATA_TYPE.SDMX_CSV_1_0 or DATA_TYPE.SDMX_CSV_2_0_0");
        }
    }

    // In this format only the value "both" will output the labels
    private boolean analyseLabelsParam(String labelsParam) {
    	this.csvLabel = CSV_LABEL.fromParam(labelsParam);
    	
    	if (labelsParam == null) {
            return false;
        }
        return labelsParam.equals("both");
    }

	@Override
	public FormatDetails getFormatDetails() {
		if(formatDetails == null) {
			String version = this.getSdmxDataFormat() == DATA_TYPE.SDMX_CSV_1_0 ? "1.0.0" : "2.0.0";
			String vnd = "application/vnd.sdmx.data+csv;version="+version;
			if(normalizedTime) {
				vnd+=";timeFormat=normalized";
			}
			if(includeNames) {
				vnd+=";labels=both";
			}
			if(includeBom) {
				vnd+=";bom=include";
			}
			// Output the "keys" value
			if (includeSeriesKey) {
			    if (includeObsKey) {
			        vnd+=";keys=both";
			    } else {
			        vnd+=";keys=series";
			    }
			} else if (includeObsKey) {
			    vnd+=";keys=obs";
			} else if (ObjectUtil.validString(this.rowHeaderValue)) {
				String suffix = this.rowHeaderValue.equals(SdmxCsvDataFormat.DEFAULT_KEYS_PARAM_HEADER) ? "" : ":" + this.rowHeaderValue;
				vnd += ";keys=row" + suffix;
			}
			
			if (includeAction) {
			    vnd+=";action=true";
			}

			formatDetails = new FormatDetailsImpl("csv", MIME_TYPE.APPLICATION_CSV, true, vnd);
		}
		return formatDetails;
	}

	public CSV_LABEL getLabelType() {
		return csvLabel;
	}
	
	/**
	 * If the parameter value is true then the concatenated id and localised name of the Artefacts
	 * separated by ": " are displayed. Note that the character combination ": "
	 * could also be part of the Artefact name and could therefore occur several times within the concatenated string.
	 * @return
	 */
	public boolean isIncludeNames() {
		return includeNames;
	}

	/**
	 * If true, then a ByteOrderMark will be included at a non displayable first character in the dataset, required when the output
	 * contains non Latin characters and the intension is to open the dataset in Microsoft Excel
	 * @return
	 */
	public boolean isIncludeBom() {
		return includeBom;
	}

	/**
	 * If the parameter value is normalized then the TIME_PERIOD values are converted to the most granular
	 * ISO 8601 representation taking into account the highest frequency of the data in the message and the
	 * moment in time when the lower-frequency values were collected (which, e.g. at the ECB, is typically
	 * either at the beginning, middle or end of the reporting period). This eases comparisons and business
	 * analysis of multi-frequency values, e.g. in pivot tables. As an example, if annual and daily data are
	 * available in the message and the annual data were collected at the end of the reporting period, the
	 * formatted value for the annual period 2014 becomes 2014-12-31.
	 * @return
	 */
	public boolean isNormalizedTime() {
		return normalizedTime;
	}

	/**
     * Returns whether the output should include the series key.
     * This is a colon separated value of the dimensions. E.g. A1A:FR:A
     * @return
     */
    public boolean isIncludeSeriesKey() {
        return includeSeriesKey;
    }

    /**
     * Returns whether the output should include the observation key.
     * This is the combination of all dimensions, including the dimension set at the observation level. E.g. A1A:FR:A:2001
     * @return
     */
    public boolean isIncludeObsKey() {
        return includeObsKey;
    }
    
    public String getKeysParamRowValue() {
    	return this.rowHeaderValue;
    }

    /**
     * Returns whether the output should include the action.
     * @return
     */
    public boolean isIncludeAction() {
        return includeAction;
    }

	/**
	 *
	 * The first best language match according to the user's preferred language choices in the http Accept-Language header
	 * (or if that is not available than according to the system's default language order) is to be used for each localisable name element.
	 * The message does however not indicate the returned language per localisable name element.
	 * In case that there is no such language match for a particular localisable name element, it is optional to return the element
	 * in a system-default language or alternatively to not return the element. It is recommended to indicate all languages
	 * used anywhere in the message for localised name elements through
	 * http Content-Language response header (languages of the intended audience).
	 *
	 * @return locale to output CSV labels in, this can be null
	 */
	public Locale getLocale() {
		return locale;
	}
	
	/**
	 * Returns the delimiter used by this CSV Data Format
	 */
	public DELIMITER getDelimiter() {
		return delimiter;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxCsvDataFormat) {
			return this.toString().equals(obj.toString());
		}
		return false;
	}

	@Override
	public String toString() {
		if(asVNDString == null) {
			String vnd = getFormatDetails().getAcceptHeaders()[0];
			if(locale != null) {
				vnd+=";locale="+locale.getLanguage();
			}

			asVNDString = vnd;
		}
		return asVNDString;
	}
}
