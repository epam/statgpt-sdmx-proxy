package io.sdmx.format.csv.engine.v2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.format.csv.engine.AbstractSdmxCsvDataReaderEngine;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.MultilingualKeyValue;
import io.sdmx.im.data.ObservationImpl.ObsBuilder;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.UrnUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxCsvDataReaderEngineV2 extends AbstractSdmxCsvDataReaderEngine {
	private static final long serialVersionUID = 1L;
	private static final FormatDetails formatDetails = new FormatDetailsImpl("SDMX CSV v2.0", MIME_TYPE.APPLICATION_CSV, true, "application/vnd.sdmx.data+csv;version=2.0.0");
	
	private static final Pattern VARIABLE_PATTERN= Pattern.compile(".*\\[(.+)\\]");    //Match any characters that end in [something] where 'something' is in capture group 1

//	//CONFIG
	private String multiValueDelimiter = ";";
	private Integer structureIdColumn;
	private Integer actionColumn;

	private IURNSingle<IDSDRelatedBean> lastUrn;
	private DATASET_ACTION datasetAction = null;
	private String currentRowStructureType;
	private String currentRowStructureId;
	private String currentRowStructureAction;



	private Set<String> multiValueColumnIds = null;
	private Map<String, List<String>> multilingualColumnIds = null;

	public SdmxCsvDataReaderEngineV2(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, retrievalManager, headerRetrievalManager, null, exceptionHandler);
	}

	public SdmxCsvDataReaderEngineV2(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, retrievalManager, headerRetrievalManager, delimiter, exceptionHandler);
	}

	public SdmxCsvDataReaderEngineV2(ReadableDataLocation rdl, DataStructureBean dsd, DataflowBean dataflow, ProvisionAgreementBean prov, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, dsd, dataflow, prov, headerRetrievalManager, delimiter, exceptionHandler);
	}

	@Override
	public void reset() {
		super.reset();
		this.currentRowStructureAction = null;
		this.currentRowStructureId = null;
		this.currentRowStructureType = null;
		this.datasetAction = null;
		this.lastUrn = null;
	}

	@Override
	public DataReaderEngine createCopy() {
		if(this.beanRetrieval != null) {
			return new SdmxCsvDataReaderEngineV2(dataLocation.copy(), beanRetrieval, headerRetrievalManager, exceptionHandler);
		}
		return new SdmxCsvDataReaderEngineV2(dataLocation.copy(), defaultDsd, defaultDataflow, defaultProvisionAgreement, headerRetrievalManager, delimiter, exceptionHandler);
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	/**
	 * The column ID may contain [] or a pattern to extract before finding the 'component id'  for example REF_AREA[] would
	 * record REF_AREA as having multiple values, and the reutrn the Component REF_AREA from the DSD.
	 * @param columnId
	 * @param columnPosition
	 * @return
	 */
	@Override
	protected ComponentBean getHeaderColumnComponent(String columnId) {
		String headerId = columnId;  //ID and Label are the same, may change later
		int arrayIndex = columnId.indexOf("[");
		if(arrayIndex > 0) {
			headerId = columnId.substring(0, arrayIndex);  //ID is a substring of label
			if(columnId.charAt(arrayIndex+1) == "]".charAt(0)) {
				if(this.multiValueColumnIds == null) {
					this.multiValueColumnIds = new HashSet<>();
				}
				multiValueColumnIds.add(headerId);
			} else {
				Matcher m = VARIABLE_PATTERN.matcher(columnId);
				if(m.matches()) {
					//Multilingual
					String variableValue = m.group(1);
					List<String> langs = CollectionUtil.getImmutableList(variableValue.split(multiValueDelimiter));
					if(this.multilingualColumnIds == null) {
						this.multilingualColumnIds = new HashMap<>();
					}
					this.multilingualColumnIds.put(headerId, langs);
				}
			}
		}
		return super.getHeaderColumnComponent(headerId);
	}


	@Override
	protected void validateFirstRow(List<String> headerRow) {
		int headerPos = 0;
		// Ensure element 1 is "STRUCTURE" or "STRUCTURE[;]" (where ; is the optional multi-value delimiter and can be any character)
		//TODO BOM

		String structureMarker = headerRow.get(headerPos).toUpperCase();
		if (!structureMarker.startsWith("STRUCTURE")) {
			throw new SdmxSemmanticException("The input file is not a valid SDMX CSV (version 2.0.0) file");
		}

		// Ensure length is correct
		if (structureMarker.length() == 9) {
			// Nothing to do with analysing the "multi-value delimiter"
			// TODO: set the multi-value delimiter to the default value

		} else if (structureMarker.length() == 12) {
			// The analysis of the "multi-value delimiter"
			if (structureMarker.charAt(9) != '[' || structureMarker.charAt(11) != ']') {
				throw new SdmxSemmanticException("The input file is not a valid SDMX CSV (version 2.0.0) file");
			}
			multiValueDelimiter = String.valueOf(structureMarker.charAt(10));
		} else {
			throw new SdmxSemmanticException("The input file is not a valid SDMX CSV (version 2.0.0) file");
		}

		// Ensure Element 2 is STRUCTRUE_ID
		String structureId = headerRow.get(++headerPos).toUpperCase();
		if (!structureId.equalsIgnoreCase("STRUCTURE_ID")) {
			throw new SdmxSemmanticException("Second element of header does not contain 'STRUCTURE_ID'");
		} else {
			structureIdColumn = headerPos;
		}
		actionColumn = headerRow.indexOf("ACTION");
	}

	@Override
	protected void validateDSDCompatible(DataStructureBean dsd) {}

	@Override
	protected IURNSingle<IDSDRelatedBean> getStructureRef() {
		String structureType = getCellValue(0);
		String structureId = getCellValue(structureIdColumn);
		if(structureType == null) {
		    throw new SdmxSemmanticException("Error with row '"+getCurrentRow().asString()+"' missing value for STRUCTURE");
		}
		if(structureId == null) {
            throw new SdmxSemmanticException("Error with row '"+getCurrentRow().asString()+"' missing value for "+structureIdColumn);
        }
		//NPE protection as the possible null value is passed into the equals
		if(!structureType.equals(currentRowStructureType) || !structureId.equals(currentRowStructureId)) {
			//New Structure
			SDMX_STRUCTURE_TYPE strTypeEnum = getStructureType(structureType);
			if(strTypeEnum == null) {
				strTypeEnum = getStructureType(structureType.toLowerCase());
				if(strTypeEnum == null) {
					throw new SdmxSemmanticException("Unexpected value for structure type. Expected either dataprovision, dataflow or datastructure . Value was '" + structureType +"'");
				}
			}
			String[] split = structureId.split(": ");  //A id and name column contains urn: name (colon+whitespace)
			String maintUrn = UrnUtil.createURN(strTypeEnum, split[0]);
			lastUrn = URN.builder(maintUrn).buildSingle(IDSDRelatedBean.class);
		}
		return lastUrn;
	}



	private SDMX_STRUCTURE_TYPE getStructureType(String structureType) {
		switch(structureType) {
		case "dataprovision" : return SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT;
		case "dataflow" : return SDMX_STRUCTURE_TYPE.DATAFLOW;
		case "datastructure" : return SDMX_STRUCTURE_TYPE.DSD;
		default : return null;
		}
	}
	
	@Override
	protected DATASET_ACTION getAction() {
		String actionString = super.getCellValue(this.actionColumn);
		if(actionString == null) {
			return DATASET_ACTION.INFORMATION;
		}
		if(!actionString.equals(currentRowStructureAction)) {
			switch(actionString) {
			case "A":
				datasetAction = DATASET_ACTION.APPEND;
				break;
			case "I":
				datasetAction = DATASET_ACTION.INFORMATION;
				break;
			case "D":
				datasetAction = DATASET_ACTION.DELETE;
				break;
			case "R":
				datasetAction = DATASET_ACTION.REPLACE;
				break;
			default:
				throw new SdmxSemmanticException("Unexpected value for dataset action. Expected either 'I', 'D' or 'R' but was was '" + actionString +"'");
			}
		}
		return datasetAction;
	}

	@Override
	/**
	 * Adds either a key value, key with multiple values, or key with multilingual values to the attribute builder
	 * depending on the column definition and the cell content
	 * 
	 * @param compId attribute ID
	 * @param compValue the cell value
	 * @param populateAttributes the builder
	 */
	protected void addMeasure(String measureId, String cellValue, ObsBuilder obsBuilder) {
		processCellValue(measureId, cellValue, (mkv)-> {
			obsBuilder.addAttributeMultilingual(mkv);
		}, (kv) -> {
			obsBuilder.measure(kv);
		});
	}

	/**
	 * Adds either a key value, key with multiple values, or key with multilingual values to the attribute builder
	 * depending on the column definition and the cell content
	 * 
	 * @param compId attribute ID
	 * @param compValue the cell value
	 * @param populateAttributes the builder
	 */
	@Override
	protected void addAttribute(String compId, String compValue, AttributableBuilder<?> populateAttributes) {
		processCellValue(compId, compValue, (mkv)-> {
			populateAttributes.addAttributeMultilingual(mkv);
		}, (kv) -> {
			populateAttributes.addAttribute(kv);
		});
	}

	/**
	 * Used in processCellValue to act as a callback for IMultilingualKeyValue
	 */
	private interface IMultilingualKeyValueCallback {

		void addKv(IMultilingualKeyValue kv);

	}

	/**
	 * Used in processCellValue to act as a callback for KeyValues
	 */
	private interface KeyValueCallback {

		void addKv(KeyValue kv);

	}
	
	/**
	 * @param compId
	 * @param compValue
	 * @param mkvCallback called if a IMultilingualKeyValueCallback is built from the CompValue
	 * @return either KeyValue or null
	 */
	protected void processCellValue(String compId, String compValue, IMultilingualKeyValueCallback mkvCallback, KeyValueCallback kvCallback) {
		if(compValue == null) {
			return;
		}
		KeyValue kv = null;
		if(multiValueColumnIds != null && multiValueColumnIds.contains(compId)) {
			String[] values = compValue.split(multiValueDelimiter);
			kv = KeyValueImpl.getInstance(compId, values);
		} else if (multilingualColumnIds != null && multilingualColumnIds.containsKey(compId)){
			Set<String> newMultilingualRowValues = new HashSet<>();
			if(compValue.contains(";")){
				newMultilingualRowValues = CollectionUtil.arrayToSet(compValue.split("\";\""));
			}else {
				newMultilingualRowValues = compValue == null ? Collections.emptySet() : CollectionUtil.arrayToSet(compValue.split(multiValueDelimiter));
			}
			IMultilingualKeyValue mlKv = getMultilingualKeyValue(compId, newMultilingualRowValues);
			mkvCallback.addKv(mlKv);
		} else {
			kv = KeyValueImpl.getInstance(compId, compValue);
		}
		if(kv != null) {
			kvCallback.addKv(kv);
		}
	}

	private IMultilingualKeyValue getMultilingualKeyValue(String componentId, Set<String> multilingualAttrVals){
		if(ObjectUtil.validCollection(multilingualAttrVals)) {
			List<IMultilingualNodeValue> multilingualNodeValues = new ArrayList<>();
			for (String attr:multilingualAttrVals) {
				String[] nodeValues = attr.split(";");
				List<TextTypeWrapper> wrapperList = new ArrayList<>();
				for (String value : nodeValues) {
					String[] splitString = value.split(":");
					TextTypeWrapper textTypeWrapper = new TextTypeWrapperImpl(splitString[0], splitString[1], null);
					wrapperList.add(textTypeWrapper);
				}
				MultilingualNodeValue multilingualNodeValue = new MultilingualNodeValue(wrapperList);
				multilingualNodeValues.add(multilingualNodeValue);
			}
			return MultilingualKeyValue.getInstance(componentId, multilingualNodeValues);
		}
		return null;
	}
}