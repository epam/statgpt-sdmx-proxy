package io.sdmx.format.csv.engine.v1;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.format.csv.engine.AbstractSdmxCsvDataReaderEngine;
import io.sdmx.format.csv.util.SdmxCSVUtil;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxCsvDataReaderEngineV1 extends AbstractSdmxCsvDataReaderEngine implements DataReaderEngine {
	private static Logger LOG = LoggerFactory.getLogger(SdmxCsvDataReaderEngineV1.class);
	private static final long serialVersionUID = 1L;
	private static final FormatDetails formatDetails = new FormatDetailsImpl("csv", "csv", "application/vnd.sdmx.data+csv;version=1.0.0", true);

	/**
	 * @param rdl readable data location with the content to be read
	 * @param retrievalManager allows the retrieval of structures
	 * @param exceptionHandler specific to data reading (optional and can be null)
	 * @param dataReadNotifier sends csv-specific notifications on the position of a dataset,
	 *                         key or observation (optional and can be null)
	 */
	public SdmxCsvDataReaderEngineV1(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, retrievalManager, headerRetrievalManager, null, exceptionHandler);
	}

	public SdmxCsvDataReaderEngineV1(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, retrievalManager, headerRetrievalManager, delimiter, exceptionHandler);
	}

	public SdmxCsvDataReaderEngineV1(ReadableDataLocation rdl, DataStructureBean dsd, DataflowBean dataflow, ProvisionAgreementBean prov, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(rdl, dsd, dataflow, prov, headerRetrievalManager, delimiter, exceptionHandler);
	}
	
	@Override
	protected void validateFirstRow(List<String> headerRow) {
		if (!SdmxCSVUtil.isValidFirstCellV1(headerRow.get(0))) {
			throw new SdmxSemmanticException("SDMX-CSV v1.0 must have 'Dataflow' as the first column with all rows reporting the Dataflow's short URN, example 'ECB:EXR(1.0)'");
		}
	}
	
	@Override
	protected void validateDSDCompatible(DataStructureBean dsd) {
		if(currentDsd.getPrimaryMeasure() == null) {
			throw new SdmxSemmanticException("SDMX-CSV v1.0  only supports a Data Structure with a Primary Measure (OBS_VALUE)");
		}
		if(currentDsd.getMeasures().size() > 1) {
			throw new SdmxSemmanticException("SDMX-CSV v1.0 can not read against a Data Structure which contains multiple Measure Dimensions");
		}
	}
	
	@Override
	protected DATASET_ACTION getAction() {
		return DATASET_ACTION.INFORMATION;  //TODO What was this before?
	}

	@Override
	protected IURNSingle<IDSDRelatedBean> getStructureRef() {
		if(getHeaderRow() == null) {
			return null;
		}
		String urnPostfix = getCellValue(0);
		return URN.builder(SDMX_STRUCTURE_TYPE.DATAFLOW.getUrnPrefix()+urnPostfix).buildSingle(IDSDRelatedBean.class);
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	@Override
	public String getDataFormat() {
		return "SDMX-CSV";
	}

	@Override
	public DataReaderEngine createCopy() {
		if(this.beanRetrieval != null) {
			return new SdmxCsvDataReaderEngineV1(dataLocation.copy(), beanRetrieval, headerRetrievalManager, exceptionHandler);
		}
		return new SdmxCsvDataReaderEngineV1(dataLocation.copy(), defaultDsd, defaultDataflow, defaultProvisionAgreement, headerRetrievalManager, delimiter, exceptionHandler);
	}

}
