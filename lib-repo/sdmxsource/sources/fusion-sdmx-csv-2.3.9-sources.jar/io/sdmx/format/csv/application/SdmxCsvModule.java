package io.sdmx.format.csv.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.format.csv.factory.SdmxCsvDataFormatFactory;
import io.sdmx.format.csv.factory.v1.SdmxCsvDataReaderFactoryV1;
import io.sdmx.format.csv.factory.v1.SdmxCsvDataWriterFactoryV1;
import io.sdmx.format.csv.factory.v2.SdmxCsvDataReaderFactoryV2;
import io.sdmx.format.csv.factory.v2.SdmxCsvDataWriterFactoryV2;

/**
 * Register all factories with the fusion framework
 */
public class SdmxCsvModule implements IFusionModule {

	public static void register() {
	    SdmxCsvDataFormatFactory.registerInstance();
	    SdmxCsvDataWriterFactoryV1.registerInstance();
	    SdmxCsvDataReaderFactoryV1.registerInstance();
	    
	    SdmxCsvDataReaderFactoryV2.registerInstance();
	    SdmxCsvDataWriterFactoryV2.registerInstance();
	}
}
