package io.sdmx.format.csv.factory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.dao.settings.DataFormattingSettingsManager;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.format.csv.api.manager.CSVDataFormatDefaultsManager;
import io.sdmx.format.csv.constant.CSV_LABEL;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.structure.LocaleUtil;

public class SdmxCsvDataFormatFactory implements DataFormatFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxCsvDataFormatFactory.class);
	
	private Map<String, FormatDetails> suppoprtedFormats = new HashMap<>();
    private DataFormattingSettingsManager dataFormattingSettingsManager;
    private CSVDataFormatDefaultsManager csvManager;

    private static SdmxCsvDataFormatFactory INSTANCE;

    //Private constructor - lazy load instance
    public static SdmxCsvDataFormatFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxCsvDataFormatFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public static SdmxCsvDataFormatFactory registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }

    private SdmxCsvDataFormatFactory() {
        suppoprtedFormats.put("application/vnd.sdmx.data+csv;version=1.0.0", new FormatDetailsImpl("sdmx-csv", "csv", "text/csv", true));
        suppoprtedFormats.put("application/vnd.sdmx.data+csv;version=2.0.0", new FormatDetailsImpl("sdmx-csv", "csv", "text/csv", true));
        suppoprtedFormats = Collections.unmodifiableMap(suppoprtedFormats);
    }
    
    @Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return suppoprtedFormats;
	}

	@Override
	public Class<DataFormat> getFormatClass() {
		return DataFormat.class;
	}

	@Override
    public DataFormat getDataFormat(ReadableDataLocation sourceData) {
    	if(sourceData.getFormat() == FILE_FORMAT.CSV) {
    		byte[] firstBytes = StreamUtil.getFirstXBytes(sourceData.getInputStream(), 20);
            String firstPart = StringUtil.stripBOM(firstBytes);
            if (firstPart == null) {
            	return null;
            }
            
            // Remove any possible leading quote marks
            if (firstPart.startsWith("\"")) {
            	firstPart.substring(1);
            }
            firstPart = firstPart.toUpperCase();
            
            // The technical documentation for SDMX CSV states that the delimiter can be determined from the characters in the input file.
            // For SDMX V1:  "... by the ninth character of the message, which is just after the fixed first column header term DATAFLOW."
            // For SDMX V2:  "... Note that the separator used in a message can be determined by retrieving the character
            //                that follows the fixed first column header term STRUCTURE (which may be extended by a squared bracket term)."
            // See:  https://github.com/sdmx-twg/sdmx-csv/blob/v1.0/data-message/docs/sdmx-csv-field-guide.md
            // and   https://github.com/sdmx-twg/sdmx-csv/blob/master/data-message/docs/sdmx-csv-field-guide.md#design-principles-for-sdmx-csv-21-data-messages-aligned-with-sdmx-31
            DELIMITER delimiter;
            DATA_TYPE dt = null;
            
            if (firstPart.startsWith("DATAFLOW") && (firstPart.length() > 8)) {
            	// This is likely SDMX CSV V1. Whatever character follows 'dataflow' is the delimiter character
            	try {
            		delimiter = DELIMITER.parseDelimiter(firstPart.charAt(8));
            		dt = DATA_TYPE.SDMX_CSV_1_0;
            	} catch (SdmxException e) {
            		LOG.error("Character following 'DATAFLOW' is not a valid delimiter. Character is: " + firstPart.charAt(8));
            		return null;
            	}
            } else if (firstPart.startsWith("STRUCTURE")) {
            	// This is likely SDMX CSV V2.
            	int posAfterStructure = 9;  // The index after the word 'STRUCTURE'
            	
            	// Is 'STRUCTURE' followed by ' [ ... ] '
                if (posAfterStructure < firstPart.length() && firstPart.charAt(posAfterStructure) == '[') {
                	// Testing for the sub-field separation character
                    int closingBracketPos = firstPart.indexOf(']', posAfterStructure);
                    if (closingBracketPos > -1  && (firstPart.length() > closingBracketPos + 1)) {
                    	try {
                    		delimiter = DELIMITER.parseDelimiter(firstPart.charAt(closingBracketPos+1));
                    		dt = DATA_TYPE.SDMX_CSV_2_0_0;
                    	} catch (SdmxException e) {
                    		LOG.error("Character following 'STRUCTURE' is not a valid delimiter. Character is: " + firstPart.charAt(closingBracketPos+1));
                    		return null;
                    	}
                    } else {
                    	// No closing bracket, this is not valid SDMX CSV2
                    	return null;
                    }
                } else if (posAfterStructure < firstPart.length()) {
                	// Is 'STRUCTURE' followed directly by a delimiter
                	try {
                		delimiter = DELIMITER.parseDelimiter(firstPart.charAt(posAfterStructure));
                		dt = DATA_TYPE.SDMX_CSV_2_0_0;
                	} catch (SdmxException e) {
                		LOG.error("Character following 'STRUCTURE' is not a valid delimiter. Character is: " + firstPart.charAt(posAfterStructure));
                		return null;
                	}
                } else {
                	return null;
                }
            } else {
            	return null;
            }
            String labelsValue = getDefaultIncludeNames() ? "both" : "id";
            boolean includeBom = getDefaultIncludeBom();
            return new SdmxCsvDataFormat(dt, labelsValue, false, includeBom, null, delimiter);
    	}
        return null;
    }

    @Override
    public DataFormat getFormat(String format, Request request) {
        if (format == null) {
            return null;
        }

        // FR-4144: Support both formats of csv-sdmx and sdmx-csv
        if (format.startsWith("sdmx-csv") || format.startsWith("csv-sdmx")) {
        	DATA_TYPE dataType = "sdmx-csv-1.0.0".equals(format) ? DATA_TYPE.SDMX_CSV_1_0 : DATA_TYPE.SDMX_CSV_2_0_0;
        	 
            boolean includeBom = getDefaultIncludeBom();

            String labelsValue = getDefaultIncludeNames() ? "both" : "id";
            if(request.hasParameter("labels")) {
                labelsValue = request.getParameter("labels");
            }

            if(request.hasParameter("bom")) {
                includeBom = "include".equals(request.getParameter("bom"));
            }

            KeysOutput keysOutput;
            if(request.hasParameter("keys")) {
                keysOutput = KeysOutput.obtainInstance( request.getParameter("keys") );
            } else {
                keysOutput = KeysOutput.NONE;
            }

            boolean includeAction = false;
            if(request.hasParameter("action")) {
                includeAction = "true".equalsIgnoreCase(request.getParameter("action"));
            }

            boolean normalizedTime = "normalized".equals(request.getParameter("timeFormat"));
            return new SdmxCsvDataFormat(dataType, labelsValue, normalizedTime, includeBom, getLocale(request), keysOutput.outputSeries(), keysOutput.outputObs(), keysOutput.getRowValue(), includeAction);
        }
        return null;
    }

    @Override
    public DataFormat getFormat(Request request, IVNDHeader vndHeader) {
        if(vndHeader.getVnd().startsWith("sdmx.data+csv")) {
            String version = vndHeader.getParameterValue("version");
            DATA_TYPE dataType = "1.0.0".equals(version) ? DATA_TYPE.SDMX_CSV_1_0 : DATA_TYPE.SDMX_CSV_2_0_0;
            if (version != null && !(version.equals("1.0.0") || version.equals("2.0.0"))) {
                throw new SdmxNotAcceptableException("Unsupported Accept format: " + vndHeader.getOriginalVND());
            }

            String labelsValue = getDefaultIncludeNames() ? "both" : "id";
            if(vndHeader.hasParameter("labels")) {
                labelsValue = vndHeader.getParameterValue("labels");
            } else if(request.hasParameter("labels")) {
                labelsValue= request.getParameter("labels");
            }

            boolean normalizedTime = false;
            if(vndHeader.hasParameter("timeFormat")) {
                normalizedTime = "normalized".equals(vndHeader.getParameterValue("timeFormat"));
            } else if(request.hasParameter("timeFormat")) {
                normalizedTime = "normalized".equals(request.getParameter("timeFormat"));
            }

            boolean includeBom = getDefaultIncludeBom();
            if(vndHeader.hasParameter("bom")) {
                includeBom = "include".equals(vndHeader.getParameterValue("bom"));
            } else if(request.hasParameter("bom")) {
                includeBom = "include".equals(request.getParameter("bom"));
            }

            KeysOutput keysOutput;
            if(vndHeader.hasParameter("keys")) {
                keysOutput = KeysOutput.obtainInstance( vndHeader.getParameterValue("keys") );
            } else if(request.hasParameter("keys")) {
                keysOutput = KeysOutput.obtainInstance( request.getParameter("keys") );
            } else {
                keysOutput = KeysOutput.NONE;
            }

            boolean includeAction = false;
            if(vndHeader.hasParameter("action")) {
                includeAction = "true".equalsIgnoreCase(vndHeader.getParameterValue("action"));
            }
            return new SdmxCsvDataFormat(dataType, labelsValue, normalizedTime, includeBom, getLocale(request), keysOutput.outputSeries(), keysOutput.outputObs(), keysOutput.getRowValue(), includeAction);
        }
        return null;
    }

    /**
     * Represents the values that can be specified by the "keys" parameter in the VND header.
     * This can take the values of: "none, "obs", "series", "both" and "rows"
     * see MEDIT#382
     */
    private static class KeysOutput {
        public static final KeysOutput NONE = new KeysOutput(false, false, null);
		private boolean outputSeries;
        private boolean outputObs;
        private String headerVal;

        private KeysOutput (boolean outputSeries, boolean outputObs, String headerVal) {
            this.outputSeries = outputSeries;
            this.outputObs = outputObs;
            this.headerVal = headerVal;
        }

        public static KeysOutput obtainInstance(String val) {
        	if (val == null) {
        		return NONE;
        	}
        	
            if (val.equalsIgnoreCase("both")) {
                return new KeysOutput(true, true, null);
            }
            if (val.equalsIgnoreCase("series")) {
                return new KeysOutput(true, false, null);
            }
            if (val.equalsIgnoreCase("obs")) {
                return new KeysOutput(false, true, null);
            }
            if (val.startsWith("row")) {
            	if (val.length() == 3) {
            		return new KeysOutput(false, false, "KEY");
            	}
            	if (val.length() > 4 && val.charAt(3) == ':') {
                    String subStr = val.substring(4);
                    return new KeysOutput(false, false, subStr);
                }
            }
            return NONE;
        }

        public boolean outputSeries() {
            return this.outputSeries;
        }

        public boolean outputObs() {
            return this.outputObs;
        }

        public String getRowValue() {
        	return this.headerVal;
        }
    }

    private boolean getDefaultIncludeNames() {
        if(csvManager != null) {
            CSV_LABEL defaultLabel = csvManager.getOutputLabelsType();
            return defaultLabel != null && defaultLabel != CSV_LABEL.ID;
        }
        return false;
    }

    private boolean getDefaultIncludeBom() {
        if(csvManager != null) {
            return csvManager.includeBom();
        }
        return false;
    }

    private Locale getLocale(Request request) {
        String localeStr = request.getParameter("locale");
        if (ObjectUtil.validString(localeStr)) {
            return LocaleUtil.obtainLocale(localeStr);
        }

        if (dataFormattingSettingsManager == null) {
            return null;
        }
        if (dataFormattingSettingsManager.useLocaleFromMessageHeader()) {
            String headerStr = request.getHeader("Accept-Language");
            if (ObjectUtil.validString(headerStr)) {
                return LocaleUtil.obtainLocale(headerStr);
            }
        }
        return dataFormattingSettingsManager.getDefaultLocale();
    }

    public void setDataFormattingSettingsManager(DataFormattingSettingsManager dataFormattingSettingsManager) {
        this.dataFormattingSettingsManager = dataFormattingSettingsManager;
    }

    public void setCsvManager(CSVDataFormatDefaultsManager csvManager) {
        this.csvManager = csvManager;
    }
}
