package io.sdmx.format.csv.factory.v1;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.core.sdmx.error.DataReadException;
import io.sdmx.format.csv.engine.v1.SdmxCsvDataReaderEngineV1;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SdmxCsvDataReaderFactoryV1 implements DataReaderFactory, IFusionSingleton {
    private static Logger LOG = LoggerFactory.getLogger(SdmxCsvDataReaderFactoryV1.class);
    private static SdmxCsvDataReaderFactoryV1 INSTANCE;

    private HeaderRetrievalManager headerRetrievalManager;
    private List<DataErrorCategory> throwableErrors;

    public static SdmxCsvDataReaderFactoryV1 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxCsvDataReaderFactoryV1();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public static SdmxCsvDataReaderFactoryV1 registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }
    
    public SdmxCsvDataReaderFactoryV1() {
    	SingletonStore.registerInterest(HeaderRetrievalManager.class, (instance) -> {
    		this.headerRetrievalManager = instance;
    	});
    }

    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
    		ReadableDataLocation sourceData,
    		DataStructureBean dsd, DataflowBean dataflowBean,
    		ProvisionAgreementBean provisionAgreement,
    		DataValidationErrorHandler exceptionHandler) {
    	if (dsd.getMeasures().size() == 1 && tryFormat(format)) {  //only 1 measure supported in SDMX v1.0
    		if(dsd.getMeasures().size() == 1 || dsd.getPrimaryMeasure() == null && isSdmxCSV1(format)) {
    			if(dsd.getPrimaryMeasure() == null) {
    				throw new SdmxSemmanticException("SDMX-CSV v1.0  only supports a Data Structure with a Primary Measure (OBS_VALUE)");
    			}
    			if(dsd.getMeasures().size() > 1) {
    				throw new SdmxSemmanticException("SDMX-CSV v1.0 can not read against a Data Structure which contains multiple Measure Dimensions");
    			}
    		}
    		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
    		try {
                // Disable the exception trace since it is possible this isn't SDMX CSV format
                SdmxException.disableExceptionTrace(true);
                DELIMITER delim = obtainDelimiter(format);
                SdmxCsvDataReaderEngineV1 reader = new SdmxCsvDataReaderEngineV1(sourceData, dsd, dataflowBean, provisionAgreement, headerRetrievalManager, delim, getDataReaderExceptionHandler(exceptionHandler));
                LOG.info("Using SDMX-CSV Data Reader");
                return reader;
            } catch (Exception e) {
                return null;
            } finally {
                SdmxException.disableExceptionTrace(wasDisabled);
            }
        }
        return null;
    }

    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
    		ReadableDataLocation sourceData,
    		SdmxBeanRetrievalManager retrievalManager,
    		DataValidationErrorHandler exceptionHandler) {
        if (tryFormat(format)) {
        	boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
            try {
                // Disable the exception trace since it is possible this isn't SDMX CSV format
                SdmxException.disableExceptionTrace(true);
                DELIMITER delim = obtainDelimiter(format);
                SdmxCsvDataReaderEngineV1 reader = new SdmxCsvDataReaderEngineV1(sourceData, retrievalManager, headerRetrievalManager, delim, getDataReaderExceptionHandler(exceptionHandler));
				LOG.info("Using SDMX-CSV Data Reader");
                return reader;
            } catch (Exception e) {
                return null;
            } finally {
                SdmxException.disableExceptionTrace(wasDisabled);
            }
        }
        return null;
    }
    
    /**
     * Returns the delimiter as specified by this format. If the format has no delimiter,
     * then a Comma is used.
     */
    private DELIMITER obtainDelimiter(DataFormat format) {
    	if (format != null && format instanceof SdmxCsvDataFormat) {
        	return ((SdmxCsvDataFormat)format).getDelimiter();
        }
    	return DELIMITER.COMMA;  // Default to Comma
	}

	private boolean tryFormat(DataFormat format) {
    	if(format == null) {
    		return true;
    	}
    	return isSdmxCSV1(format);
    }
    
    private boolean isSdmxCSV1(DataFormat format) {
      	if(format instanceof SdmxCsvDataFormat) {
    		SdmxCsvDataFormat csvFormat = (SdmxCsvDataFormat)format;
    		return csvFormat.getSdmxDataFormat() == DATA_TYPE.SDMX_CSV_1_0;
    	}
    	return false;
    }

    @Override
    public String getOverride() {
        return null;
    }

    @Override
    public List<DataErrorCategory> getThrowableErrors() {
        if (throwableErrors == null) {
            List<DataErrorCategory> throwableErrors = new ArrayList<>();
            throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INCONSISTENT_DATASET_ATTR, "Inconsistent Dataset Attributes",
                    "Ensures that the Dataset Attributes reported on each line are consistent with each other. If set to Ignore, no error will be reported if differing lines in the CSV report different values for Dataset Attributes.") );
            this.throwableErrors = throwableErrors;
        }

        return throwableErrors;
    }

    @Override
    public String getId() {
        return "SDMX-CSV";
    }

    @Override
    public String getName() {
        return "SDMX-CSV";
    }
}