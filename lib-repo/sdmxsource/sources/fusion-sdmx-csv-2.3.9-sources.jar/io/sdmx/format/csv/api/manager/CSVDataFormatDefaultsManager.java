package io.sdmx.format.csv.api.manager;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.format.csv.constant.CSV_LABEL;

/**
 * Returns default values for the SDMX CSV data format
 */
public interface CSVDataFormatDefaultsManager {

	/**
	 * @return the delimiter
	 */
	DELIMITER getDelimiter();

	/**
	 * @return the key separator
	 */
	String getKeySeparator();

	/**
	 * Returns the CSV label type (id and name, etc.)
	 */
	CSV_LABEL getOutputLabelsType();

	/**
	 * @return whether the Series Key should be output
	 */
	boolean getOutputSeriesKey();

	/**
	 * @return default for inclusion of BOM
	 */
	boolean includeBom();
}
