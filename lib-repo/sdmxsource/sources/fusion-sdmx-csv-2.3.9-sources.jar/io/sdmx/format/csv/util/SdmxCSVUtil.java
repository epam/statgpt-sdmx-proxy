package io.sdmx.format.csv.util;

import java.util.regex.Pattern;

import io.sdmx.utils.core.object.StringUtil;

public class SdmxCSVUtil {
	private static final Pattern CSV_V3_PATTERN= Pattern.compile(".*\\[(.+)\\]");    //Match any characters that end in [something] where 'something' is in capture group 1

	public static boolean isValidFirstCellV2(String cellContents) {
        cellContents = cleanCell(cellContents);
		return cellContents.equals("STRUCTURE") || CSV_V3_PATTERN.matcher(cellContents).matches();
	}
	
	public static boolean isValidFirstCellV1(String cellContents) {
        String cleanedString = cleanCell(cellContents);
        return cleanedString.equalsIgnoreCase("Dataflow") || cleanedString.equalsIgnoreCase("\"Dataflow\"");
	}
	
	private static String cleanCell(String cell) {
		return StringUtil.stripBOM(cell).trim();
	}
	 
}

