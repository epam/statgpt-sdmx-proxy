package io.sdmx.format.csv.factory.v2;

import java.io.OutputStream;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.factory.data.IFlatDataWriterFactory;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.format.csv.engine.v2.SdmxCsvDataWriterEngineV2;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SdmxCsvDataWriterFactoryV2 implements IFlatDataWriterFactory, IFusionSingleton {

	private static SdmxCsvDataWriterFactoryV2 INSTANCE;

	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;

	//Private constructor - lazy load instance
	private SdmxCsvDataWriterFactoryV2() {}

	public static SdmxCsvDataWriterFactoryV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxCsvDataWriterFactoryV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxCsvDataWriterFactoryV2 registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}


	@Override
	public IFlatDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat instanceof SdmxCsvDataFormat) {
			SdmxCsvDataFormat csvFormat = (SdmxCsvDataFormat)dataFormat;
			if(csvFormat.getSdmxDataFormat() == DATA_TYPE.SDMX_CSV_2_0_0) {
				return new SdmxCsvDataWriterEngineV2(csvFormat, getSuperBeanRetrievalManager(),  out);
			}
		}
		return null;
	}

	private SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager() {
		if (superBeanRetrievalManager == null) {
			ISdmxBeanRetreivalContainer brmContainer = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class, false);
			if (brmContainer != null) {
				superBeanRetrievalManager = brmContainer.getSuperBeanRetrievalManager(true);
			}
		}
		return superBeanRetrievalManager;
	}
}
