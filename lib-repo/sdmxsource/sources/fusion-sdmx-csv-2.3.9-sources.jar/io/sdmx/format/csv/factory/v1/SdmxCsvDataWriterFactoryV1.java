package io.sdmx.format.csv.factory.v1;

import java.io.OutputStream;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.data.DataWriterFactory;
import io.sdmx.core.sdmx.api.factory.data.ISeriesDataWriterFactory;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.format.csv.engine.v1.SdmxCsvDataWriterEngineV1;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.core.data.engine.writer.GroupDataWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SdmxCsvDataWriterFactoryV1 implements ISeriesDataWriterFactory, IFusionSingleton {

    private static SdmxCsvDataWriterFactoryV1 INSTANCE;

	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;

	//Private constructor - lazy load instance
    private SdmxCsvDataWriterFactoryV1() {}

    public static SdmxCsvDataWriterFactoryV1 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxCsvDataWriterFactoryV1();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public static SdmxCsvDataWriterFactoryV1 registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }


	@Override
	public ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat instanceof SdmxCsvDataFormat) {
		    SdmxCsvDataFormat csvFormat = (SdmxCsvDataFormat)dataFormat;
		    if(csvFormat.getSdmxDataFormat() == DATA_TYPE.SDMX_CSV_1_0) {
		    	return new GroupDataWriterEngine( new SdmxCsvDataWriterEngineV1(csvFormat, getSuperBeanRetrievalManager(),  out) );
		    }
		}
		return null;
	}

    private SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager() {
        if (superBeanRetrievalManager == null) {
            ISdmxBeanRetreivalContainer brmContainer = SingletonStore.getSingleton(ISdmxBeanRetreivalContainer.class, false);
            if (brmContainer != null) {
                superBeanRetrievalManager = brmContainer.getSuperBeanRetrievalManager(true);
            }
        }
        return superBeanRetrievalManager;
    }
}
