package io.sdmx.format.csv.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.engine.data.AbstractDataReaderEngine;
import io.sdmx.core.sdmx.error.DataFormatErrorImpl;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.core.sdmx.model.data.CsvFilePosition;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.DatasetAttributes.DatasetAttributesBuilder;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.KeyableImpl.KeyBuilder;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.data.ObservationImpl.ObsBuilder;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.csv.CSVColumnReaderEngineImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class AbstractSdmxCsvDataReaderEngine extends AbstractDataReaderEngine {
	private static final long serialVersionUID = 1L;
	private ColumnReaderEngine columnReaderEngine;
	private RowDetails rowDetails;  				//Details of the change from the last row to the current row
	private CSVColumnPosition columnPositions;		//Details of the column to component positions

	private List<String> headerRow;					//First row is the CSV Header

	private List<Keyable> groupAndSeriesStack = new ArrayList<>();;  //One row can result in multiple keys, if so stack them here
	
	private Boolean readDataset = null;         //On moving to a new key or obs, the row has moved to a new dataset
	private boolean readRowKey = false;  		//have we read the key yet
	private boolean readRowObs = false;  		//have we read the obs yet

	protected DELIMITER delimiter = DELIMITER.COMMA;
	private boolean endOfFile;
	
	protected ReadableDataLocation dataLocation;
	protected HeaderRetrievalManager headerRetrievalManager;
	
	public AbstractSdmxCsvDataReaderEngine(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DataReaderExceptionHandler exceptionHandler) {
		this(rdl, retrievalManager, headerRetrievalManager, null, exceptionHandler);
	}
	
	public AbstractSdmxCsvDataReaderEngine(ReadableDataLocation rdl, SdmxBeanRetrievalManager retrievalManager, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(retrievalManager, null, null, null, exceptionHandler);
		startReader(rdl, delimiter);
		this.headerRetrievalManager = headerRetrievalManager;
	}
	
	public AbstractSdmxCsvDataReaderEngine(ReadableDataLocation rdl, DataStructureBean dsd, DataflowBean dataflow, ProvisionAgreementBean prov, HeaderRetrievalManager headerRetrievalManager, DELIMITER delimiter, DataReaderExceptionHandler exceptionHandler) {
		super(null, dsd, dataflow, prov, exceptionHandler);
		startReader(rdl, delimiter);
		this.headerRetrievalManager = headerRetrievalManager;
	}
	
	@Override
	public void reset() {
		super.reset();
		if(this.columnReaderEngine != null) {
			columnReaderEngine.reset();
		}
		if(rowDetails != null) {
			rowDetails = new RowDetails(headerRow);
		}
		readDataset = null;
		endOfFile = false;
		readRowKey = false;
		readRowObs = false;
		groupAndSeriesStack = null;
		groupAndSeriesStack = new ArrayList<>();
		columnPositions = null;
	}


	/**
	 * Read the first metadata line to determine the column indexes
	 */
	private void startReader(ReadableDataLocation rdl, DELIMITER delimiter) {
		try {
			this.dataLocation = rdl;
			if(rdl.getFormat() == FILE_FORMAT.EMPTY) {
				throw new SdmxSemmanticException("The input file may not be empty. At least a header row with column identifiers must be present.");
			}
			if(delimiter != null) {
				this.delimiter = delimiter;
			}
			columnReaderEngine = new CSVColumnReaderEngineImpl(rdl, this.delimiter, null, 0, true);
			headerRow = columnReaderEngine.readHeader();
			
			validateFirstRow(headerRow);
			this.rowDetails = new RowDetails(headerRow);
		} catch(RuntimeException e) {
			if(columnReaderEngine != null) {
				columnReaderEngine.close();
			}
			throw e;
		} catch (Throwable th) {
			throw new SdmxException(th, "Error reading CSV");
		}
	}

	/**
	 * Ensure the header row is valid in accordance to the specification
	 * @param headerRow
	 * @throws SdmxSemmanticException if the row is not valid
	 */
	protected abstract void validateFirstRow(List<String> headerRow);

	/**
	 * Ensure the DSD is compatible with this version of CSV reader
	 */
	protected abstract void validateDSDCompatible(DataStructureBean dsd);
	 
	/**
	 * @param columnId
	 * @param columnPosition
	 * @return component from the column ID or null if component does not exist in the DSD
	 */
	protected ComponentBean getHeaderColumnComponent(String columnId) {
		return currentDsd.getComponent(columnId);
	}
	
	@Override
	public HeaderBean getHeader() {
		if (headerRetrievalManager == null) {
			String senderId = "unknown";
			headerBean = new HeaderBeanImpl(senderId);
		} else {
			headerBean = headerRetrievalManager.getHeader();
		}
		return headerBean;
	}

	@Override
	/**
	 * Move to the next dataset
	 */
	protected boolean moveNextDatasetInternal() {
		readRowKey  = false;
		readRowObs  = false;
		this.currentDatasetAttributes = null;
		
		// Reset the dataset position
		datasetPosition = DATASET_POSITION.DATASET;
		
		if(readDataset != null && readDataset == false) {
			readDataset = true;
			return true;
		}
		readDataset = true;
		while(rowDetails.moveNextRow()) {
			if(rowDetails.datasetChange) {
				break;
			}
		}
		if(endOfFile) {
			readRowKey  = true;
			readRowObs  = true;
			return false;
		}
		

		// Note: MEDIT #111 - the BIS have questioned why the behaviour of this class is that the DatasetID is set to the Dataflow reference.
		// For consistency with all other ReaderEngines, this has been changed.
		// The original request came from the ECB in FR-4978.
		/*
		// FR-4978: Construct a header bean with the ID of the Dataflow
        headerBean = new HeaderBeanImpl(sRef.getMaintainableId(), null, null, null, null, null, false);
		 */
		headerBean = new HeaderBeanImpl(null);
		this.groupAndSeriesStack = new ArrayList<>();

		//Call this to set the value with position
		lazyLoadDatasetAttributes();

		return true;
	}

	@Override
	protected IDatasetAttributes lazyLoadDatasetAttributes() {
		if(this.currentDatasetAttributes == null) {
			DatasetAttributesBuilder attrBuilder = DatasetAttributes.builder();
			attrBuilder.position(rowDetails.getPosition(columnPositions.notifyDatasetIndexes));
			this.currentDatasetAttributes = populateDatasetAttributes(attrBuilder).build();
		}
		return this.currentDatasetAttributes;
	}

	/**
	 * Builds the key which has been populated with dimenisons, attributes, and position information
	 * no SDMX v3.0 items added (multivalue)
	 * @param dsAttrBuilder
	 * @return
	 */
	private DatasetAttributesBuilder populateDatasetAttributes(DatasetAttributesBuilder dsAttrBuilder) {
		for(AttributeBean attr : currentDsd.getDatasetAttributes()) {
			for(int i=0; i < getHeaderRow().size(); i++) {
				if(attr.getId().equals(getHeaderRow().get(i))) {
					addAttribute(attr.getId(), rowDetails.getValue(i), dsAttrBuilder);
				}
			}
		}
		return dsAttrBuilder;
	}

	@Override
	/**
	 * User may have progressed the reader moving to the next dataset, or checking if there is another obs
	 * If so, then there is already a key to read
	 */
	protected boolean moveNextKeyableInternal() {
		try {
			if (!readDataset) {
				// If moving datasets do not move to the next key
				return false;
			}
			if(!readRowKey) {
				return true;
			}
			if (!groupAndSeriesStack.isEmpty())  {
				return true;
			}
			while(rowDetails.moveNextRow()) {
				if(rowDetails.datasetChange) {
					readDataset = false;
					return false;
				}
				if(rowDetails.keyChange) {
					return true;
				}
			}
		} finally {
			readRowKey = true;
			readRowObs = false;
		}
		readRowObs = true;  //no obs to read
		return false;
	}

	@Override
	protected Keyable lazyLoadKey() {
		if(endOfFile) {
			return null;
		}

		if (!groupAndSeriesStack.isEmpty()) {
			// Pop the first empty from the stack
			return groupAndSeriesStack.remove(0);
		}


		KeyBuilder keyBuilder = KeyableImpl.builder(currentDsd).dataflow(currentDataflow);
		addDimensionValuesToKey(keyBuilder);
		addSeriesAttributeValuesToKey(keyBuilder);
		keyBuilder.position(rowDetails.getPosition(this.columnPositions.notifyKeyIndexes));


		Keyable seriesKey = keyBuilder.build();  //Row always contains a series key (does it?)//TODO check what if there are not a full compliment
		//of dimensions
		if (columnPositions.groupAttrIds.length < 1) {
			// No groups, so return a Keyable for the series
			return seriesKey;
		}

		outer:
			for (Map.Entry<String, Set<String>> entry : columnPositions.groupMap.entrySet()) {
				keyBuilder.clearKey().attributes(null).attributesMultilingual(null); //Clear Attribute State

				String groupId = entry.getKey();
				Set<String> currentGroupAttrIds = entry.getValue();
				Set<String> mandatoryGroupAttrIds = columnPositions.groupMapMandatoryElements.get(groupId);

				// Check to see if there are any Group Attributes at all or there are missing Mandatory Group Attributes
				boolean atLeastOneGroupAttrPresent = false;
				for(String groupAttributeId : currentGroupAttrIds) {
					String attrVal = rowDetails.getValue(groupAttributeId);
					if(attrVal == null && mandatoryGroupAttrIds.contains(attrVal)) {
						//missing mandatory value, skip group
						continue outer;
					}
					if (attrVal != null) {
						atLeastOneGroupAttrPresent = true;
					}
					addAttribute(groupAttributeId, attrVal, keyBuilder);
				}
				if (!atLeastOneGroupAttrPresent) {
					continue outer;
				}
				
				List<String> thisGroupDimRefs = this.currentDsd.getGroup(groupId).getDimensionRefs();
				for (String currentDimId : thisGroupDimRefs) {
					String attrVal = rowDetails.getValue(currentDimId);
					KeyValue kv = getKeyValue(currentDimId, attrVal);
					if(kv == null) {
						//missing group dimension value, skip group
						continue outer;
					}
					keyBuilder.key(kv);
				}
				Keyable groupKey = keyBuilder.group(groupId).position(rowDetails.getPosition(columnPositions.notifyKeyIndexes)).build();
				groupAndSeriesStack.add(groupKey);
			}

		// Add the series to the stack if there is either:
		//a. no group keys in the row i.e. the row has something but it is not a group
		//b. the key size matches the dimension size, i.e. the row has a group but possibly not the series
		if(groupAndSeriesStack.size() == 0 || (seriesKey.getKey().size() == currentDsd.getDimensionIds().size())) {
			groupAndSeriesStack.add(seriesKey);
		}
		return groupAndSeriesStack.size() > 0 ? groupAndSeriesStack.remove(0) : null;
	}

	@Override
	protected boolean moveNextObservationInternal() {
		try {
			if (!groupAndSeriesStack.isEmpty())  {  //If it is not empty, we are still in a group stack
				return false;
			}
			if(readRowObs == false && rowDetails.hasObsValues) {
				return true;
			}
			readRowObs = true;
			while(rowDetails.moveNextRow()) {
				if(rowDetails.datasetChange) {
					readDataset = false;
					return false;
				}
				if(rowDetails.keyChange) {
					readRowKey = false;
					return false;
				}
				if(rowDetails.hasObsValues) {
					return true;
				}
			}
			return false;
		} finally {
			readRowObs = true;
		}
	}


	@Override
	protected Observation lazyLoadObservation() {
		if(endOfFile) {
			return null;
		}
		ObsBuilder obsBuilder = ObservationImpl.builder(currentKey);
		getCellValues(columnPositions.obsAttrIds, columnPositions.obsAttrIndexes, (attrId, attrVal) -> {
			addAttribute(attrId, attrVal, obsBuilder);
		});
		getCellValues(columnPositions.measureIds, columnPositions.measureIndexes, (measureId, measureVal) -> {
			addMeasure(measureId, measureVal, obsBuilder);
		});
		String obsTime = rowDetails.getValue(columnPositions.timeIndex);
		if (obsTime != null) {
			obsBuilder.time(obsTime);
			validateTime(obsTime);
		}
		obsBuilder.position(rowDetails.getPosition(columnPositions.notifyObsIndexes));
		return obsBuilder.build();
	}
	
	protected void validateTime(String obsTime) {
		int obsTimeLength = obsTime.length();
		if (obsTimeLength > 4 && obsTime.charAt(5) == 'W' && obsTimeLength != 8) {
			handleException("Weekly data for SDMX CSV is of the format YYYY-Www. Reported value is: " + obsTime, true, SEVERITY.HIGH, TYPE.INVALID_DATE, ERROR_POSITION.OBSERVATION);
		}
	}

	
	protected void addDimensionValuesToKey(KeyBuilder keyBuilder) {
		List<KeyValue> dimensions = generateKeyValues(columnPositions.dimensionIds, columnPositions.dimensionIndexes);
		keyBuilder.key(dimensions);
	}

	protected void addSeriesAttributeValuesToKey(KeyBuilder keyBuilder) {
		getCellValues(columnPositions.seriesAttrIds, columnPositions.seriesAttrIndexes, (attrId, attrVal) -> {
			addAttribute(attrId, attrVal, keyBuilder);
		});
	}

	private interface CellValueNotifier {

		void cellValue(String cellId, String cellValue);

	}
	
	/**
	 * Adds a Measure to the Observation
	 * 
	 * @param attributeId
	 * @param cellValue
	 * @param populateAttributes
	 */
	protected void addMeasure(String measureId, String cellValue, ObsBuilder obsBuilder) {
		obsBuilder.measure(getKeyValue(measureId, cellValue));
	}


	/**
	 * Adds an Attribute to the Attributable
	 * 
	 * @param attributeId
	 * @param cellValue
	 * @param populateAttributes
	 */
	protected void addAttribute(String attributeId, String cellValue, AttributableBuilder<?> populateAttributes) {
		populateAttributes.addAttribute(getKeyValue(attributeId, cellValue));
	}

	/**
	 * Generates single key value pairs based on an array of IDs and an array of ID to column position
	 * @param ids
	 * @param positions
	 * @return
	 */
	private List<KeyValue> generateKeyValues(String[] ids, int[] positions) {
		List<KeyValue> returnList = new ArrayList<>();
		for (int i=0; i < positions.length; i++) {
			int position = positions[i];
			KeyValue kv = getKeyValue(ids[i], position);
			if(kv != null) {
				returnList.add(kv);
			}
		}
		return returnList;
	}

	private void getCellValues(String[] ids, int[] positions, CellValueNotifier notifier) {
		for (int i=0; i < positions.length; i++) {
			int position = positions[i];
			String value = rowDetails.getValue(position);
			if(value != null) {
				notifier.cellValue(ids[i], value);
			}
		}
	}

	/**
	 * @return DSD, Provision or Dataflow reference on current line
	 */
	protected abstract IURNSingle<IDSDRelatedBean> getStructureRef();

	/**
	 * @return dataset action for the current row
	 */
	protected abstract DATASET_ACTION getAction();


	protected List<String> getHeaderRow() {
		return headerRow;
	}

	/**
	 * @param conceptId for the key value
	 * @param colPos to identify the cell in the current row
	 * @return key value with the concept and value from the cell in the given column - or null if the value in the cell is empty
	 */
	protected String getCellValue(Integer colPos) {
		String value = rowDetails.getValue(colPos);
		if(ObjectUtil.validString(value)) {
			return value;
		}
		return null;
	}
	
	protected RowDetails getCurrentRow() {
        return rowDetails;
    }


	/**
	 * @param conceptId for the key value
	 * @param colPos to identify the cell in the current row
	 * @return key value with the concept and value from the cell in the given column - or null if the value in the cell is empty
	 */
	protected KeyValue getKeyValue(String conceptId, Integer colPos) {
		String value = rowDetails.getValue(colPos);
		if(ObjectUtil.validString(value)) {
			return KeyValueImpl.getInstance(conceptId, value);
		}
		return null;
	}

	/**
	 * @param conceptId for the key value
	 * @param colPos to identify the cell in the current row
	 * @return key value with the concept and value from the cell in the given column - or null if the value in the cell is empty
	 */
	protected KeyValue getKeyValue(String conceptId, String cellValue) {
		if(ObjectUtil.validString(cellValue)) {
			return KeyValueImpl.getInstance(conceptId, cellValue);
		}
		return null;
	}

	private void handleDatasetAttributeError(String errMsg) {
		if (exceptionHandler != null) {
			boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
			SdmxException.disableExceptionTrace(true);
			try {
				exceptionHandler.handleException(new DataFormatErrorImpl(errMsg, TYPE.INCONSISTENT_DATASET_ATTR));
			} finally {
				SdmxException.disableExceptionTrace(wasDisabled);
			}
		}
	}
	
	private void datasetChanged(IURNSingle<? extends IDSDRelatedBean> datastructure) {
		setCurrentStructure(datastructure);
		// Set the action on the header
		if (datasetHeaderBean != null) {
			// Reset the dataset header bean with a new ID
			datasetHeaderBean = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), getAction(), datasetHeaderBean.getDataStructureReference());
		}
		//FR-4466 Unable to load SDMX-CSV via UI when explicit DSD is selected
		//Revert to default DSD IF it has been specified and there is no BeanRetreivalManager and no Dataflow/DSD set
		if(this.currentDataflow == null && this.currentDsd == null) {
			if(this.beanRetrieval == null && defaultDsd != null) {
				setCurrentDsd(this.defaultDsd);
			} else {
				throw new DataSetStructureReferenceException(datastructure);
			}
		}
		validateDSDCompatible(currentDsd);

		this.columnPositions = new CSVColumnPosition(currentDsd);
	}
	
	/**
	 * Contains current row, previous, row, start and end index, details on the changes and content
	 * Changes from the previous row
	 */
	protected class RowDetails {
		private int expectedRowSize;
		private int rowIdx = -1;
		private long currentRowStartByteIndex;
		private long currentRowEndByteIndex;

		private IURNSingle<? extends IDSDRelatedBean> datastructure;
		private DATASET_ACTION datasetAction;

		private List<String> previousRow;
		private List<String> currentRow;

		private boolean datasetChange; //true if the data structure reference has changed
		private boolean keyChange;     //true if the series key or series attributes have changed

		private boolean hasObsValues;  //true if the current row has observation values, time, or attributes

		public RowDetails(List<String> rowHeader) {
			expectedRowSize = rowHeader.size();
		}

		private boolean moveNextRow () {
			if(endOfFile) {
				return false;
			}
			currentRowStartByteIndex = columnReaderEngine.getCurrentByteCount();

			this.previousRow = currentRow;
			this.currentRow = null;
			int i =0;
			//The next row must be a non zero length row, after 100 empty rows return false
			while(!ObjectUtil.validCollection(currentRow) && columnReaderEngine.moveNextRow() && i < 100) {
				this.currentRow = columnReaderEngine.readRow();
				this.rowIdx++;
				i++;
			}
			if(!ObjectUtil.validCollection(currentRow)) {
				endOfFile = true;
				return false;
			}
			validateRowSize();

			//Analyse the change(s) from the previous row
			this.datasetChange = isDatasetChange();
			if(datasetChange) {
				readRowKey = false;
				readRowObs = false;
				datasetChanged(datastructure);
			} else {
				validateDatasetAttributesNoChange();  //Dataset attributes should be the same as the previous row
			}
			this.keyChange = this.datasetChange || isKeyChange();
			if(keyChange) {
				readRowKey = false;
			}
			readRowObs = false;
			this.hasObsValues = hasObsElement();
			return true;
		}

		/**
		 * @return true if the structure reference changes or the dataset action changes
		 */
		private boolean isDatasetChange() {
			boolean changed = false;
			IURNSingle<? extends IDSDRelatedBean> datastructure = getStructureRef();
			if(!ObjectUtil.equivalent(this.datastructure, datastructure)) {
				this.datastructure = datastructure;
				changed = true;
			}
			DATASET_ACTION action = getAction();
			if(!ObjectUtil.equivalent(datasetAction, action)) {
				this.datasetAction = action;
				changed = true;
			}
			return changed;
		}
		/**
		 * @return true if the any series key or group key changes
		 */
		private boolean isKeyChange() {
			if(hasChanges(columnPositions.dimensionIndexes)) {
				return true;
			}
			if(hasChanges(columnPositions.seriesAttrIndexes)) {
				return true;
			}
			if(hasChanges(columnPositions.groupAttrIndexes)) {
				return true;
			}

			return false;
		}

		/**
		 */
		private void validateDatasetAttributesNoChange() {
			if(previousRow == null) {
				return;
			}
			for(int cellIdx : columnPositions.datasetAttrIndexes) {
				String previousVal = this.previousRow.size() > cellIdx ? this.previousRow.get(cellIdx) : null;
				String currentVal =  this.currentRow.size() > cellIdx ? this.currentRow.get(cellIdx) : null;
				if(!ObjectUtil.equivalent(currentVal, previousVal)) {
					String headerId = getHeaderRow().get(cellIdx);
					String errMsg = "Dataset Attribute " + headerId + " has been previously reported as '" + previousVal + "' but was reported as '" + currentVal + "'";
					handleDatasetAttributeError(errMsg);
				}
			}
		}

		/**
		 * @return true if there are changes to the content of the column positions
		 */
		private boolean hasChanges(int[] colPositions) {
			if(previousRow == null) {
				return true;
			}
			for(int cellIdx : colPositions) {
				String previousVal = this.previousRow.size() > cellIdx ? this.previousRow.get(cellIdx) : null;
				String currentVal =  this.currentRow.size() > cellIdx ? this.currentRow.get(cellIdx) : null;
				if(!ObjectUtil.equivalent(currentVal, previousVal)) {
					return true;
				}
			}
			return false;
		}

		private void validateRowSize() {
			// Ensure line is of the correct length
			if (this.currentRow.size() != expectedRowSize) {
				CSV_ERRORS errorType;
				String modifier;
				if (currentRow.size() > expectedRowSize) {
					modifier = "more";
					errorType = CSV_ERRORS.CSV_TOO_MANY_ELEMENTS;
				} else {
					modifier = "less";
					errorType = CSV_ERRORS.CSV_TOO_FEW_ELEMENTS;
				}
				DataFormatErrorImpl dfe = new DataFormatErrorImpl("Line " + (rowIdx+2) + " has " + modifier + " elements than expected. Expected " + expectedRowSize + " elements but line contained " + this.currentRow.size()+ " elements", errorType);

				if (exceptionHandler == null) {
					throw new SdmxException(dfe.getMessage());
				} else {
					exceptionHandler.handleException(dfe);
				}
			}
			currentRowEndByteIndex = columnReaderEngine.getCurrentByteCount();
		}

		/**
		 * If any part of an Observation has been reported on the current line, return true.
		 * A "part" could be the Observation Value, Time_Period or any Observation Attribute
		 */
		private boolean hasObsElement() {
			if (hasValue(columnPositions.timeIndex)) {
				return true;
			}
			if (hasValue(columnPositions.measureIndexes)) {
				return true;
			}
			if (hasValue(columnPositions.obsAttrIndexes)) {
				return true;
			}
			return false;
		}

		/**
		 * @param cols
		 * @return true if at least one cell has a not null non-empty value for the current row
		 */
		protected boolean hasValue(int[] cols) {
			if(cols != null) {
				for(Integer col : cols) {
					if(hasValue(col)) {
						return true;
					}
				}
			}
			return false;
		}

		/**
		 * @param colPos cell in the given column for the current row
		 * @return true if the cell has a not null non-empty value for the current row
		 */

		protected boolean hasValue(Integer colPos) {
			return getValue(colPos) != null;
		}

		protected String getValue(String compId) {
			Integer cellPosition = columnPositions.getColumnPosition(compId);
			if(cellPosition == null) {
				return null;
			}
			return getValue(cellPosition);
		}

		/**
		 * @param colPos
		 * @return the value from the row if it is a non zero length string, otherwise null
		 */
		protected String getValue(Integer colPos) {
			if(colPos == null || colPos < 0) {
				return null;
			}
			if(currentRow.size() <= colPos) {
				return null;
			}
			String value = currentRow.get(colPos);
			if(value.length() == 0) {
				return null;
			}
			return value;
		}

		private IDataPosition getPosition(List<Integer> colPositions) {
			long start = currentRowStartByteIndex + 1;
			long end = currentRowEndByteIndex - start;
			return new CsvFilePosition(start, end, delimiter, colPositions);
		}
		
		/**
		 * @return row represented as a string, comma seperated
		 */
		public String asString() {
		    return CollectionUtil.join(",", "", currentRow);
		}
	}

	/**
	 * Holds the Mapping from the DSD Component to the CSV Column Position
	 */
	protected class CSVColumnPosition {
		private String[] dimensionIds;
		private String[] datasetAttrIds;
		private String[] seriesAttrIds;
		private String[] measureIds;
		private String[] obsAttrIds;
		private String[] groupAttrIds;

		private int[] dimensionIndexes;
		private int[] datasetAttrIndexes;
		private int[] seriesAttrIndexes;
		private int[] obsAttrIndexes;
		private int[] groupAttrIndexes;
		private int[] measureIndexes;
		private int timeIndex = -1;
		//		private int obsIndex = -1;

		//TODO INDEX PER GROUP
		private List<Integer> notifyKeyIndexes; // column indexes for notifications
		private List<Integer> notifyDatasetIndexes;
		private List<Integer> notifyObsIndexes;


		private Map<String, Set<String>> groupMap;  				 // A Map of Group IDs to a Set of Attribute IDs
		private Map<String, Set<String>> groupMapMandatoryElements;  // A Map of Group IDs to a Set of their Mandatory items
		private Map<String, Integer> compId2ColumnPos = new HashMap<>();

		public CSVColumnPosition(DataStructureBean currentDsd) {
			List<String> measureIds = new ArrayList<>();
			List<String> dimensionIds = new ArrayList<>();
			List<String> datasetAttrIds = new ArrayList<>();
			List<String> seriesAttrIds = new ArrayList<>();
			List<String> obsAttrIds = new ArrayList<>();
			List<String> groupAttrIds = new ArrayList<>();

			List<Integer> dimensionIndexes = new ArrayList<>();
			List<Integer> datasetAttrIndexes = new ArrayList<>();
			List<Integer> seriesAttrIndexes = new ArrayList<>();
			List<Integer> obsAttrIndexes = new ArrayList<>();
			List<Integer> groupAttrIndexes = new ArrayList<>();
			List<Integer> measureIndexes = new ArrayList<>();


			for(int i=0; i < getHeaderRow().size(); i++) {
				String str = getHeaderRow().get(i);
				ComponentBean comp = getHeaderColumnComponent(str);
				if(comp == null) {
					continue;
				}
				compId2ColumnPos.put(comp.getId(), i);

				if(comp.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
					this.timeIndex = i;
				} else {
					switch(comp.getStructureType()) {
					case DIMENSION :
						dimensionIds.add(comp.getId());
						dimensionIndexes.add(i);
						break;
					case MEASURE_DIMENSION :
						measureIds.add(comp.getId());
						measureIndexes.add(i);
						break;
					case DATA_ATTRIBUTE :
						AttributeBean attr = (AttributeBean)comp;
						switch(attr.getAttachmentLevel()) {
						case DIMENSION_GROUP :
							seriesAttrIds.add(comp.getId());
							seriesAttrIndexes.add(i);
							break;
						case OBSERVATION :
							obsAttrIds.add(comp.getId());
							obsAttrIndexes.add(i);
							break;
						case DATA_SET :
							datasetAttrIds.add(comp.getId());
							datasetAttrIndexes.add(i);
							break;
						case GROUP :
							groupAttrIds.add(comp.getId());
							groupAttrIndexes.add(i);
						}
						break;
					}

				}
			}
			this.dimensionIds = dimensionIds.stream().toArray(String[]::new);
			this.datasetAttrIds = datasetAttrIds.stream().toArray(String[]::new);
			this.seriesAttrIds = seriesAttrIds.stream().toArray(String[]::new);
			this.obsAttrIds = obsAttrIds.stream().toArray(String[]::new);
			this.groupAttrIds = groupAttrIds.stream().toArray(String[]::new);
			this.measureIds = measureIds.stream().toArray(String[]::new);

			this.dimensionIndexes = dimensionIndexes.stream().mapToInt(i->i).toArray();
			this.datasetAttrIndexes = datasetAttrIndexes.stream().mapToInt(i->i).toArray();
			this.seriesAttrIndexes = seriesAttrIndexes.stream().mapToInt(i->i).toArray();
			this.obsAttrIndexes = obsAttrIndexes.stream().mapToInt(i->i).toArray();
			this.groupAttrIndexes = groupAttrIndexes.stream().mapToInt(i->i).toArray();
			this.measureIndexes = measureIndexes.stream().mapToInt(i->i).toArray();
			
			notifyDatasetIndexes = Collections.unmodifiableList(new ArrayList<>(datasetAttrIndexes));
			notifyKeyIndexes = new ArrayList<>(dimensionIndexes);
			notifyKeyIndexes.addAll(seriesAttrIndexes);
			Collections.unmodifiableList(notifyKeyIndexes);

			notifyObsIndexes = new ArrayList<>();
			if(timeIndex >=0) {
				notifyObsIndexes.add(timeIndex);
			}
			notifyObsIndexes.addAll(measureIndexes);
			notifyObsIndexes.addAll(obsAttrIndexes);
			Collections.unmodifiableList(notifyObsIndexes);

			setupGroupMapping(currentDsd);
		}

		private void setupGroupMapping(DataStructureBean currentDsd) {
			// Create a Map of group name to elements in the Group (a Set of their IDs)
			groupMap = new HashMap<>();
			groupMapMandatoryElements = new HashMap<>();
			for (AttributeBean attributeBean : currentDsd.getGroupAttributes()) {
				Set<String> set = groupMap.get(attributeBean.getAttachmentGroup());
				if (set == null) {
					set = new HashSet<>();
					groupMap.put(attributeBean.getAttachmentGroup(), set);
				}
				set.add(attributeBean.getId());

				if (attributeBean.isMandatory()) {
					Set<String> setMandatory = groupMapMandatoryElements.get(attributeBean.getAttachmentGroup());
					if (setMandatory == null) {
						setMandatory = new HashSet<>();
						groupMapMandatoryElements.put(attributeBean.getAttachmentGroup(), setMandatory);
					}
					setMandatory.add(attributeBean.getId());
				}
			}
		}

		private Integer getColumnPosition(String componentId) {
			if(componentId == null) {
				return null;
			}
			return columnPositions.compId2ColumnPos.get(componentId);
		}
	}
	

	@Override
	public List<FooterMessage> close() {
		dataLocation.close();
		columnReaderEngine.close();
		return Collections.emptyList();
	}
	
	private static enum CSV_ERRORS {
		CSV_TOO_MANY_ELEMENTS,
		CSV_TOO_FEW_ELEMENTS;
	}
}
