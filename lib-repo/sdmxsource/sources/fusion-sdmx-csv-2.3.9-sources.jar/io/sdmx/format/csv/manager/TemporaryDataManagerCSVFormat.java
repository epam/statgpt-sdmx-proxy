package io.sdmx.format.csv.manager;

import java.util.List;

import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.data.engine.writer.TimeSeriesToFlatDataWriterEngine;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.engine.data.EmptyDataReaderEngine;
import io.sdmx.core.sdmx.engine.data.TemporaryDataWriterEngine;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.format.csv.engine.v2.SdmxCsvDataReaderEngineV2;
import io.sdmx.format.csv.engine.v2.SdmxCsvDataWriterEngineV2;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.utils.core.application.FusionSystem;

/**
 * Writes the data in compact format so that it can be stored temporarily and read at a a later date
 */
public class TemporaryDataManagerCSVFormat implements ITemporaryDataManager {
	private SdmxBeanRetrievalManager brm;

	public TemporaryDataManagerCSVFormat(SdmxBeanRetrievalManager brm) {
		this.brm = brm;
	}

	@Override
	public ITemporaryDataWriterEngine getDataWriterEngine() {
		WriteableDataLocation wdl = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation(null);
		SdmxCsvDataWriterEngineV2 dwe = new SdmxCsvDataWriterEngineV2(SdmxCsvDataFormat.BASIC_V2, null, wdl.getOutputStream());
		return new TemporaryDataWriterEngine(new TimeSeriesToFlatDataWriterEngine(dwe), wdl, brm);
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ITemporaryDataWriterEngine writer) {
		InMemoryRetrievalManager brm = new InMemoryRetrievalManager(writer.getWrittenStructures());

		if(!writer.dataWritten()) {
			return new DREProxy(writer);
		}

		SdmxCsvDataReaderEngineV2 csvReader = new SdmxCsvDataReaderEngineV2(writer.getReadableDataLocation(), brm, null, null);
		
		return csvReader;
	}

	private class DREProxy extends EmptyDataReaderEngine {
		private int datasetPosition = -1;
		private HeaderBean headerBean;
		private List<DatasetHeaderBean> datasetHeaders;
		private List<IDatasetStructures> structures;

		public DREProxy(ITemporaryDataWriterEngine dwe) {
			this.structures = dwe.getStructures();
			this.datasetHeaders = dwe.getDatasetHeaders();
			this.headerBean = dwe.getHeader();
		}

		@Override
		public HeaderBean getHeader() {
			return headerBean;
		}

		@Override
		public ProvisionAgreementBean getProvisionAgreement() {
			return structures.get(datasetPosition).getProvisionAgreement();
		}

		@Override
		public DataflowBean getDataFlow() {
			return structures.get(datasetPosition).getDataflow();
		}


		@Override
		public DataStructureBean getDataStructure() {
			return structures.get(datasetPosition).getDataStructure();
		}

		@Override
		public int getDatasetPosition() {
			return datasetPosition;
		}

		@Override
		public void reset() {
			datasetPosition = -1;
		}

		@Override
		public boolean moveNextDataset() throws DataSetStructureReferenceException {
			int next = datasetPosition + 1;
			if(datasetHeaders.size() > next) {
				datasetPosition++;
				return true;
			}
			return false;
		}

	}

	

	@Override
	public void close(ITemporaryDataWriterEngine writer) {
		writer.getReadableDataLocation().close();
	}
}
