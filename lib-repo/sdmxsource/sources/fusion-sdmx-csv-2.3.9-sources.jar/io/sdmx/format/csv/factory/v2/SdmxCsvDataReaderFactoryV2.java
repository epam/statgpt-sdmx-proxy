package io.sdmx.format.csv.factory.v2;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.model.io.CSVDataReadableDataLocation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.core.sdmx.error.DataReadException;
import io.sdmx.format.csv.engine.v2.SdmxCsvDataReaderEngineV2;
import io.sdmx.format.csv.factory.v1.SdmxCsvDataReaderFactoryV1;
import io.sdmx.format.csv.format.SdmxCsvDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SdmxCsvDataReaderFactoryV2 implements DataReaderFactory, IFusionSingleton {
    private static Logger LOG = LoggerFactory.getLogger(SdmxCsvDataReaderFactoryV1.class);
    private static SdmxCsvDataReaderFactoryV2 INSTANCE;

    private HeaderRetrievalManager headerRetrievalManager;
    private List<DataErrorCategory> throwableErrors;
    
    public static SdmxCsvDataReaderFactoryV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxCsvDataReaderFactoryV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public static SdmxCsvDataReaderFactoryV2 registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }


    public SdmxCsvDataReaderFactoryV2() {
    	SingletonStore.registerInterest(HeaderRetrievalManager.class, (instance) -> {
    		this.headerRetrievalManager = instance;
    	});
    }
    

    @Override
    public String getId() {
        return "SDMX-CSV-V2";
    }

    @Override
    public String getName() {
        return "SDMX-CSV-V2";
    }
    
    @Override
    public String getOverride() {
        return null;
    }
    
	 @Override
	    public List<DataErrorCategory> getThrowableErrors() {
	        if (throwableErrors == null) {
	            List<DataErrorCategory> throwableErrors = new ArrayList<>();
	            throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INCONSISTENT_DATASET_ATTR, "Inconsistent Dataset Attributes",
	                    "Ensures that the Dataset Attributes reported on each line are consistent with each other. If set to Ignore, no error will be reported if differing lines in the CSV report different values for Dataset Attributes.") );
	            this.throwableErrors = throwableErrors;
	        }

	        return throwableErrors;
	    }

    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
    		ReadableDataLocation sourceData,
    		DataStructureBean dsd, DataflowBean dataflowBean,
    		ProvisionAgreementBean provisionAgreement,
    		DataValidationErrorHandler exceptionHandler) {
        if (tryFormat(format)) {
            DELIMITER delimiter = null;
            if(sourceData instanceof CSVDataReadableDataLocation) {
                CSVDataReadableDataLocation csvRdl = (CSVDataReadableDataLocation)sourceData;
                delimiter = csvRdl.getDelimiter();
            }
            if(sourceData.getFormat() == FILE_FORMAT.CSV) {
            	delimiter = obtainDelimiterFromFormat(delimiter, format);
            	boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
            	try {
                    // Disable the exception trace since it is possible this isn't SDMX CSV format
                    SdmxException.disableExceptionTrace(true);
                    SdmxCsvDataReaderEngineV2 reader = new SdmxCsvDataReaderEngineV2(sourceData, dsd, dataflowBean, provisionAgreement, this.headerRetrievalManager, delimiter, getDataReaderExceptionHandler(exceptionHandler));
                    LOG.info("Using SDMX-CSV Data Reader");
                    return reader;
                } catch (Exception e) {
                    return null;
                } finally {
                    SdmxException.disableExceptionTrace(wasDisabled);
                }
            }
        }
        return null;
    }
    
    @Override
    public DataReaderEngine getDataReaderEngine(DataFormat format,
    		ReadableDataLocation sourceData,
    		SdmxBeanRetrievalManager retrievalManager,
    		DataValidationErrorHandler exceptionHandler) {
    	if (tryFormat(format)) {
            DELIMITER delimiter = null;
            if(sourceData instanceof CSVDataReadableDataLocation) {
                CSVDataReadableDataLocation csvRdl = (CSVDataReadableDataLocation)sourceData;
                delimiter = csvRdl.getDelimiter();
            }
            if(sourceData.getFormat() == FILE_FORMAT.CSV) {
            	delimiter = obtainDelimiterFromFormat(delimiter, format);
            	boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
            	try {
                    // Disable the exception trace since it is possible this isn't SDMX CSV format
                    SdmxException.disableExceptionTrace(true);
                    SdmxCsvDataReaderEngineV2 reader = new SdmxCsvDataReaderEngineV2(sourceData, retrievalManager, this.headerRetrievalManager, delimiter, getDataReaderExceptionHandler(exceptionHandler));
                    LOG.info("Using SDMX-CSV Data Reader");
                    return reader;
                } catch (Exception e) {
                    return null;
                } finally {
                    SdmxException.disableExceptionTrace(wasDisabled);
                }
            }
        }
        return null;
    }
    
//    private boolean confirmHeader(List<String> header, DataFormat format) {
//    	if(header.size() < 3) {
//    		return false;
//    	}
//    	if(!header.get(0).startsWith("STRUCTURE")) {
//			return false;
//		}
//		if(!header.get(1).equals("STRUCTURE_ID")) {
//			return false;
//		}
//		return true;
//    }
    
    private boolean tryFormat(DataFormat format) {
    	if(format == null) {
    		return true;
    	}
    	return isSdmxCSV2(format);
    }
    
    private boolean isSdmxCSV2(DataFormat format) {
      	if(format instanceof SdmxCsvDataFormat) {
    		SdmxCsvDataFormat csvFormat = (SdmxCsvDataFormat)format;
    		return csvFormat.getSdmxDataFormat() == DATA_TYPE.SDMX_CSV_2_0_0;
    	}
    	return false;
    }

    /**
     * Given the current delimiter, if this is a COMMA (the default) and the format is a SdmxCsvDataFormat,
     * then obtained the delimiter from the format.
     * @param currentDelimiter
     * @param format
     * @return
     */
    private DELIMITER obtainDelimiterFromFormat(DELIMITER currentDelimiter, DataFormat format) {
    	// If an explicit format has already been set, don't use the value from the format
		if ((currentDelimiter == null || currentDelimiter == DELIMITER.COMMA) && format instanceof SdmxCsvDataFormat) {
			return ((SdmxCsvDataFormat) format).getDelimiter();
		}
		return currentDelimiter;
    }
}
