
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;


public interface KeyValuesMutable extends MutableBean  {

	String getId();
	KeyValuesMutable setId(String id);
	
	List<String> getKeyValues();
	void setKeyValues(List<String> values);
	KeyValuesMutable addValue(String value);
	
	boolean isCascadeValue(String value);

	List<String> getCascade();
//	List<String> getCascadeExcludeRoot();
	void setCascade(List<String> cascadeValues);
//	void setCascadeExcludeRoot(List<String> cascadeValues);
	
	void addCascade(String value);
	

	KeyValuesMutable setValidity(String value, String validFrom, String validTo);
	String getValidFrom(String value);
	String getValidTo(String value);
	
	
	TimeRangeMutableBean getTimeRange();
	void setTimeRange(TimeRangeMutableBean timeRange);
	
	
	/**
	 * @return true if the code prefix is to be removed before validation
	 */
	boolean isRemovePrefix();
	void setRemovePrefix(boolean removePrefix);
	
	
}
