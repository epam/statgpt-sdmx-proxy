package io.sdmx.api.sdmx.model.beans.base;

/**
 *  Links back to a DSD, Dataflow, or Structure Map and can therefore be used in a mapping.
 */
public interface IStructureMapRelatedBean extends MaintainableBean {

}
