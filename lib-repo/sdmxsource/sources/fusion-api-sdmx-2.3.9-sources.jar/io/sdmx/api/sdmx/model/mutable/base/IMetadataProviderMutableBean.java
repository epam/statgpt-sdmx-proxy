 	
package io.sdmx.api.sdmx.model.mutable.base;



public interface IMetadataProviderMutableBean extends OrganisationMutableBean {

}
