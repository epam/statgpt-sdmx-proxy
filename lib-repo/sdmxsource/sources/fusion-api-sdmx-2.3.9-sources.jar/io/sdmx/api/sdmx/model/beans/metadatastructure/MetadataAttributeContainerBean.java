package io.sdmx.api.sdmx.model.beans.metadatastructure;

import java.util.List;

/**
 * a container of metadata attributes
 */
public interface MetadataAttributeContainerBean {

	/**
	 * @return an immutable list of metadata attributes, or an empty list if none exist
	 */
	List<MetadataAttributeBean> getMetadataAttributes();
	
}
