
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.datastructure.CrossSectionalDataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;


public interface CrossSectionalDataStructureMutableBean extends DataStructureMutableBean {

	List<CrossSectionalMeasureMutableBean> getCrossSectionalMeasures();
	
	/**
	 * Gets a map of attribute id, mapping to the cross sectional measure ids it is attached to.
	 */
	Map<String, List<String>> getAttributeToMeasureMap();
	
	/**
	 * Set a map of attribute id, mapping to the cross sectional measure ids it is attached to.
	 * @param attributeToMeasure
	 */
	void setAttributeToMeasureMap(Map<String, List<String>>  attributeToMeasure);

	void setMeasureDimensionCodelistMapping(Map<String, StructureReferenceBean> mapping);
	
	Map<String, StructureReferenceBean> getMeasureDimensionCodelistMapping();
	
	List<String> getCrossSectionalAttachDataSet();
	
	List<String> getCrossSectionalAttachGroup();
	
	List<String> getCrossSectionalAttachSection();
	
	List<String> getCrossSectionalAttachObservation();
	
	void setCrossSectionalMeasures(List<CrossSectionalMeasureMutableBean> crossSectionalMeasure);
	
	void setCrossSectionalAttachDataSet(List<String> dimensionReferences);
	
	void setCrossSectionalAttachGroup(List<String> dimensionReferences);
	
	void setCrossSectionalAttachSection(List<String> dimensionReferences);
	
	void setCrossSectionalAttachObservation(List<String> dimensionReferences);
	
	void addCrossSectionalMeasures(CrossSectionalMeasureMutableBean crossSectionalMeasure);
	
	void addCrossSectionalAttachDataSet(String dimensionReference);
	
	void addCrossSectionalAttachGroup(String dimensionReference);
	
	void addCrossSectionalAttachSection(String dimensionReference);
	
	void addCrossSectionalAttachObservation(String dimensionReference);
	
	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	CrossSectionalDataStructureBean getImmutableInstance();
}
