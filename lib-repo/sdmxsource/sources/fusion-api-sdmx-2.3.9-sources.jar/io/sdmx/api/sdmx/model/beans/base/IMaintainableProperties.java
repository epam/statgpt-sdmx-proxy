package io.sdmx.api.sdmx.model.beans.base;

import java.io.Serializable;

public interface IMaintainableProperties extends Serializable {

	/**
	 * @return the agency id that is responsible for maintaining this maintainable artifact
	 */
	String getAgencyId();
	
	/**
	 * @return id of the maintainable
	 */
	String getId();
	
	/**
	 * @return no null, the version of the maintainable
	 */
	ISdmxVersion getVersion();
}
