
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;


public interface DataProviderSchemeMutableBean extends OrganisationSchemeMutableBean<DataProviderMutableBean>{

	
	@Override
	DataProviderSchemeBean getImmutableInstance();
	
}
