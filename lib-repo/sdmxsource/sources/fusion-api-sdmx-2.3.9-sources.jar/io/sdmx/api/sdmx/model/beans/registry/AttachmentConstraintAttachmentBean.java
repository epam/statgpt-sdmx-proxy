
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.DataAndMetadataSetReference;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;


public interface AttachmentConstraintAttachmentBean extends SdmxStructureBean {
	
	/**
	 * Returns the target structure for this constraint attachment
	 * @return
	 */
	Class<? extends IdentifiableBean> getTargetStructureType();
	
	/**
	 * Returns the structure references that this constraint is referencing
	 * @return
	 */
	List<ICrossReferenceBean<?>> getStructureReferences();
	
	/**
	 * If the target structure is a dataset or metadata set, then this will return the id of that set
	 * @return
	 */
	List<DataAndMetadataSetReference> getDataOrMetadataSetReference();
	

	List<DataSourceBean> getDatasources();
}
