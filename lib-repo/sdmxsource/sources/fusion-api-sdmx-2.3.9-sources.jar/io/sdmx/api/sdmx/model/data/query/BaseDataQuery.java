package io.sdmx.api.sdmx.model.data.query;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;

/**
 * Base interface for both standard and complex data queries
 */
public interface BaseDataQuery extends Serializable  {
	
	default boolean isSecure() {
		return false;
	}
	
	/**
	 * Returns a hash of this query which can be used for caching, if a new query contains the same query parameters it will return the same hash
	 * @return
	 */
	String getHash();
	
	/**
	 * Returns a set of all the additional parameter names, values the can be retrieved from the getParameter method
	 * @return
	 */
	Set<String> getParameters();
	
	/**
	 * Returns the value of any extended parameter
	 * @param parameter
	 * @return
	 */
	String getParameter(String parameter);
	
	/**
	 * Adds a query parameter
	 * @param paramName
	 * @param paramValue
	 * @return
	 */
	String addParameter(String paramName, String paramValue);
	
	/**
	 * Returns true if this query has one or more selection groups on it, false means the query is a query for all.
	 * @return
	 */
	boolean hasSelections();
	
	/**
	 * Returns the Key Family (Data Structure Definition) that this query is returning data for.
	 * @return
	 */
	DataStructureBean getDataStructure();
	
	/**
	 * Returns the Dataflow that the query is returning data for.
	 * @return
	 */
	DataflowBean getDataflow();
	
	/**
	 * Returns true if there are any restrictions on observations by date (lastUpdated, from, to) or by index (lastN, firstN)
	 * @return
	 */
	boolean hasObservationRestrictions();
	
	/**
	 * Returns true if there are any restrictions on observations by date (lastUpdated, from, to) 
	 * @return
	 */
	boolean hasDateRestrictions();
	
	/**
	 * Returns the maximum number of observations accepted, if the result exceeds this limit, an exception should be thrown
	 *  @return max obs or null if not defined
	 */
	Integer getMaxObservations();
	void setMaxObservations(Integer max);
	
	/**
	 * Returns the maximum number of series accepted, if the result exceeds this limit, an exception should be thrown
	 * @return max series or null if not defined
	 */
	Integer getMaxSeries();
	void setMaxSeries(Integer max);
	 
	/**
	 * Returns the last 'n' observations, for each series key, to return as a result of a data query.  
	 * @return last 'n' observations or null if unspecified
	 */
	Integer getLastNObservations();
	
	/**
	 * Returns the first 'n' observations, for each series key,  to return as a result of a data query.
	 * @return first 'n' observations or null if unspecified
	 */
	Integer getFirstNObservations();
	
	/**
	 * Returns the detail of the query.  The detail specifies whether to return just the series keys, just the data or everything.  
	 * <p/>
	 * Defaults to FULL (everything)
	 * 
	 * @return
	 */
	DATA_QUERY_DETAIL getDataQueryDetail();
	
	/**
	 * adds a provision agreement to this data query
	 * @param provision
	 */
	void addProvisionAgreement(ProvisionAgreementBean provision);

	/**
	 * Removes all provision agreement selections from this data query
	 */
	void clearProvisionAgreements();

	
	/**
	 * @return set of Provision Agreements to query, or an empty set to indicate all
	 */
	Set<ProvisionAgreementBean> getProvisionAgreements();
	
	/**
	 * Returns the data provider(s) that the query is for, an empty list represents ALL.
	 * @return
	 */
	Set<DataProviderBean> getDataProvider();
	
	/**
	 * @return set of attributes to exclude from the output
	 */
	Set<String> getExcludeAttributes();
	
	/**
	 * Adds an attribute to exclude from the output
	 */
	void addExcludeAttribute(String attrId);
	
	
	void setDataProvider(DataProviderBean dataProvider);
	
	/**
	 * Returns the period if specified, for which the returned observations my lie within
	 * @return period or null if not specified
	 */
	SdmxPeriod getQueryPeriod();
	
	/**
	 * Returns the start of the period, or null if there is no start specified
	 * @return
	 */
	SdmxDate getStartPeriod();

	/**
	 * Returns the end of the period, or null if there is no start specified
	 * @return
	 */
	SdmxDate getEndPeriod();
	
	
	/**
	 * The last updated date is a filter on the data meaning 'only return data that was updated after this time'.
	 * <p/>
	 * If this attribute is used, the returned message should only
	 * include the latest version of what has changed in the database since that point in time (updates and revisions).
	 * <p/>
	 * This should include: 
	 * <ul>
	 *  <li>Observations that have been added since the last time the query was performed (INSERT)</li>
	 *  <li>Observations that have been revised since the last time the query was performed (UPDATE)</li>
	 *  <li>Observations that have been deleted since the last time the query was performed (DELETE)</li>
	 * </ul>
	 * If no offset is specified, default to local.
	 * <p/>
	 * Returns null if unspecified
	 * @return
	 */
	SdmxDate getLastUpdatedDate();
	
	void setFirstNObs(Integer firstNObs);
	
	void setLastNObs(Integer lastNObs);

	void setLastUpdated(SdmxDate lastUpdated);
	
	void setDataQueryDetail(DATA_QUERY_DETAIL dataQueryDetail);
	
	/**
	 * Remove the date from query filter
	 */
	void clearDateFrom();
	
	/**
	 * Remove the date to query filter
	 */
	void clearDateTo();
	
	/**
	 * Removes date from and date to query filters
	 */
	default void clearPeriods() {
		clearDateFrom();
		clearDateTo();
	}
	
	
	
	/**
	 * Sets the from date of the data query as an ISO compliant String
	 * @param date
	 */
	void setDateFrom(String date);
	
	/**
	 * Sets the from date of the data query
	 * @param date
	 */
	void setDateFrom(Date date);
	
	/**
	 * Sets the date from as an SdmxDate
	 * @param date
	 */
	void setDateFrom(SdmxDate date);
	
	/**
	 * Sets the to date of the data query
	 * @param date
	 */
	void setDateTo(Date date);
	
	/**
	 * Sets the to date of the data query as an ISO compliant String
	 * @param date
	 */
	void setDateTo(String date);
	
	/**
	 * Sets the date to as an SdmxDate
	 * @param date
	 */
	void setDateTo(SdmxDate date);
}