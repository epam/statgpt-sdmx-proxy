
package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface ISchemeMapMutableBean extends MaintainableMutableBean {

	StructureReferenceBean getSourceRef();
	
	StructureReferenceBean getTargetRef();
	
	 void setSourceRef(StructureReferenceBean sourceRef);
	 
	 void setTargetRef(StructureReferenceBean targetRef);
	 
	
}
