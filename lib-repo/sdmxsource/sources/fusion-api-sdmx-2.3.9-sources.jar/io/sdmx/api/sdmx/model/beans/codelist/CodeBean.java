
package io.sdmx.api.sdmx.model.beans.codelist;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;

/**
 * Represents an SDMX Code
 * @author Matt Nelson
 *
 */
public interface CodeBean extends HierarchicalItemBean<CodeBean>, EnumeratedItemBean, ValidityPeriodBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<CodeBean> getURN();
	
	/**
	 * Returns the Id of the parent Code
	 * @return
	 */
	String getParentCode();
	
	/**
	 * Returns true if this code is inherited from another codelist
	 * @return
	 */
	boolean isInherited();
	

}
