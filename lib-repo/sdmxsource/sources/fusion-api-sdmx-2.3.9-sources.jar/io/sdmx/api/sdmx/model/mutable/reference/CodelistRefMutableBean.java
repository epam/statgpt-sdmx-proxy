package io.sdmx.api.sdmx.model.mutable.reference;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

@Deprecated
public interface CodelistRefMutableBean {
    String getAlias();

    void setAlias(String alias);

    StructureReferenceBean getCodelistReference();

    void setCodelistReference(StructureReferenceBean sRef);
}