package io.sdmx.api.sdmx.model.modify;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

/**
 * An interface to inform listeners that a Maintainable Structure has changed some part of its identity (Agency, ID or Version)
 */
public interface IIdentityChanger {

    /**
     * A Structure has changed. All implementors of this Interface should see if they should veto the requested change.
     * If null or a blank string is returned the change may go ahead. If any other String is returned this IdentityChanger implementation
     * is vetoing the structural change and the returned string is the error message.
     *
     * @param oldRef
     * @param newRef
     * @returns null or a blank string if subsequent changes should go ahead. Any other string states that changes are not permitted and the returned string is the error message
     */
    public String vetoChange(StructureReferenceBean oldRef, StructureReferenceBean newRef);

    /**
     * A Structure has changed. All implementors of this Interface should see if they need to perform any work and return false if
     *
     * @param oldRef
     * @param newRef
     */
    public void changed(StructureReferenceBean oldRef, StructureReferenceBean newRef);
}
