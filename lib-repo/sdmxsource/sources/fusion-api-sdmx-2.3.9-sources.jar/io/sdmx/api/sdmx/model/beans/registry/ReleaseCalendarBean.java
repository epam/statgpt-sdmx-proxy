
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;

public interface ReleaseCalendarBean extends SdmxStructureBean, INoCrossReferencesBean {
		
	String getPeriodicity();
	
	String getOffset();
	
	String getTolerance();
	
	ReleaseCalendarMutableBean createMutableBean();
}
