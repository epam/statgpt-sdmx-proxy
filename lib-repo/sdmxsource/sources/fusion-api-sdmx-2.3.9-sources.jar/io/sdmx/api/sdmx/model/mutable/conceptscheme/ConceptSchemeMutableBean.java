package io.sdmx.api.sdmx.model.mutable.conceptscheme;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface ConceptSchemeMutableBean extends ItemSchemeMutableBean<ConceptMutableBean> {

	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	ConceptSchemeBean getImmutableInstance();

	/**
	 * Returns the Validity Type
	 * @return
	 */
	MAINT_VALIDITY_TYPE getValidityType();

	/**
	 * Sets the Validity Type
	 * @param validityType
	 */
	void setValidityType(MAINT_VALIDITY_TYPE validityType);
}