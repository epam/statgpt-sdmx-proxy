package io.sdmx.api.sdmx.model;

import java.io.Serializable;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Defines the properties for a Maintainable or Identifiable structure type in the system
 */
public interface ISDMXStructureType<K extends MaintainableBean, V extends IdentifiableBean> extends Serializable {

	/**
	 * @return true if this refers to any structure type
	 */
	boolean isAny();
	
	/**
	 * @return not null, the class which describes the Maintainable type of this structure (or the parent structure to which the structure belongs)
	 */
	default Class<K> getMaintainableType() {
		return getMaintainableStructureType().getMaintainableType();
	}
	
	/**
	 * @return not null, the class which describes the this structure type, this is the same as the getMaintainableType if this class is a maintainable structure definition
	 */
	Class<V> getClassType();
	
	/**
	 * @return not null, the maintainable structure which owns this structure, returns this if this is already an {@link IMaintainableStructureType}
	 */
	IMaintainableStructureType<K> getMaintainableStructureType();
	
	/**
	 * @return not null, the URN namespace example: urn:sdmx:org.sdmx.infomodel 
	 */
	String getUrnNamespace();

	/**
	 * Some structures such as AgencyScheme have a fixed ID, if this is the case this method will return the fixed ID for that
	 * structure type, or null if the ID of the structure is not fixed
	 * @return fixed ID or null
	 */
	String getFixedId();
	
	/**
	 * Some structures such as AgencyScheme have a fixed version, if this is the case this method will return the fixed version for that
	 * structure type, or null if the version of the structure is not fixed
	 * @return fixed version or null
	 */
	String getFixedVersion();

	/**
	 * Returns the URN Class example Metadataflow
	 * @return
	 */
	String getUrnClass();

	/**
	 * Returns the URN package (example 'mapping').
	 * @return
	 */
	String getUrnPackage();
	
	default boolean isAbstract() {
		return getUrnPackage().equals("abstract");
	}

	/**
	 * @return human readable type example 'Concept Map'
	 */
	String toString();
	
	/**
	 * @return fully qualified class name, for example: urn:sdmx:org.sdmx.infomodel.codelist.Code
	 */
	default String getFullyQualifiedClass() {
		return getUrnNamespace() + getUrnPackage() + "." + getUrnClass();
	}

	default String generateURN(String agencyId, String id, String version, String...identifiableIds) {
		id = id != null ? id.toUpperCase() : id;  //Maintainable IDs are set to upper case on the MaintainableBeanImpl
		String urn = getFullyQualifiedClass() + "=" +agencyId + ":" +id  + "("+version+")";
		if(identifiableIds != null && identifiableIds.length > 0 && identifiableIds[0] != null) {
			urn += "."+String.join(".", identifiableIds);
		}
		return urn;
	}
	
	default boolean matchesType(IURN<?> urn) {
		if(isAny() || urn.getStructureType().isAny()) {
			return true;
		}
		boolean isAbstract = urn.getStructureType().isAbstract() || this.isAbstract();
		return urn.getStructureType().equals(this) || (isAbstract && matchesType(urn.getStructureType().getClassType()));
	}
	
	/**
	 * Example usage - if this StructureType is for an SDXM CategorySchemeBean then the following will return true
	 * matchesType(CategorySchemeBean.class);
	 * matchesType(ItemSchemeBean.class);
	 * matchesType(MaintainableBean.class);
	 * matchesType(IdentifiableBean.class);
	 * matchesType(null);
	 * 
	 * And false
	 * matchesType(CodeBean.class);
	 * 
	 * 
	 * @param identifiableType to check against
	 * @return true if the class this type defines either directly matchs the class passed in, or is a sub interface 
	 */
	default boolean matchesType(Class<? extends IdentifiableBean> identifiableType) {
		if(isAny() || identifiableType == null) {
			return true;
		}
		return identifiableType.isAssignableFrom(getClassType()) || getClassType().isAssignableFrom(identifiableType);
	}
	
	/**
	 * @return true if this is representing a maintainable artifact if false
	 */
	default boolean isMaintainable() {
		return getMaintainableStructureType() != this;
	}
	
	/**
	 * @return true if the structure has a fixed Version
	 */
	default boolean hasFixedVersion() {
		return getFixedVersion() != null;
	}
	
	/**
	 * @return true if the structure has a fixed ID
	 */
	default boolean hasFixedId() {
		return getFixedId() != null;
	}
	
}
