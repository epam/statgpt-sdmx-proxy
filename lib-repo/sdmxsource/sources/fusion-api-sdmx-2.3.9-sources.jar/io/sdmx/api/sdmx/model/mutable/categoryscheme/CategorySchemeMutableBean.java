package io.sdmx.api.sdmx.model.mutable.categoryscheme;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface CategorySchemeMutableBean extends ItemSchemeMutableBean<CategoryMutableBean> {

	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	CategorySchemeBean getImmutableInstance();

	/**
	 * Returns the Validity Type
	 * @return
	 */
	MAINT_VALIDITY_TYPE getValidityType();

	/**
	 * Sets the Validity Type
	 * @param validityType
	 */
	void setValidityType(MAINT_VALIDITY_TYPE validityType);
}