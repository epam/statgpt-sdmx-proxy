package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;

public interface ContentConstraintMutableBean extends ConstraintMutableBean {

	boolean getIsDefiningActualDataPresent();
	
	void setIsDefiningActualDataPresent(boolean present);
	
	/**
	 * Returns the metadata target region, or null if this is undefined.
	 * @return
	 */
	MetadataTargetRegionMutableBean getMetadataTargetRegion();
	
	void setMetadataTargetRegion(MetadataTargetRegionMutableBean mtr);
	
	/**
	 * Returns a CubeRegion where the Keys and Attributes are defining data that is present or allowed (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	CubeRegionMutableBean getIncludedCubeRegion();

	void setExcludedCubeRegion(CubeRegionMutableBean cubeRegionMutable);
	
	void setIncludedCubeRegion(CubeRegionMutableBean cubeRegionMutable);
	
	/**
	 * Returns a CubeRegion where the Keys and Attributes are defining data is is not present or disallowed (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	CubeRegionMutableBean getExcludedCubeRegion();
	
		
	ReferencePeriodMutableBean getReferencePeriod();

	void setReferencePeriod(ReferencePeriodMutableBean bean);
	
	ReleaseCalendarMutableBean getReleaseCalendar();

	void setReleaseCalendar(ReleaseCalendarMutableBean bean);
	
	@Override
	ContentConstraintBean getImmutableInstance();
}
