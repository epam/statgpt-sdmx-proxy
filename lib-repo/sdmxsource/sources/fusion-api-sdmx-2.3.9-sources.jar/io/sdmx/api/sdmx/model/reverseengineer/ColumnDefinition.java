package io.sdmx.api.sdmx.model.reverseengineer;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean.COMPONENT_TYPE;

/**
 * Abstract definition for column, subclassed by coded or text definitions
 */
public interface ColumnDefinition {

	/**
	 * Concept Id to use, or null to take the Id from the column header (mandatory)
	 */
	String getConceptId();

	/**
	 * Concept name to use, or null to use inheritance rules
	 * <br/>
	 * Inheritance rules:
	 * <ol>
	 *  <li>Check Existing Beans for Existing Concept</li>
	 *  <li>Use Concept Id</li>
	 * </ol>
	 */
	String getConceptName();

	/**
	 * @return the type of component
	 */
	COMPONENT_TYPE getComponentType();	 

}
