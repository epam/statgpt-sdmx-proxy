package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;

public interface ICustomTypeSchemeMutableBean extends IVtlSchemeMutableBean<ICustomTypeMutableBean> {

	@Override
	ICustomTypeSchemeBean getImmutableInstance();
	
	/**
	 * Adds a new custom type
	 * @param vtlScalerType
	 * @param dataType
	 * @param outputFormat
	 * @param nullValue
	 * @param vtlLiteralFormat
	 * @return
	 */
	ICustomTypeMutableBean addCustomType(String id, String name, String vtlScalerType, String dataType, String outputFormat, String nullValue, String vtlLiteralFormat);
	
}
