package io.sdmx.api.sdmx.model.beans.mapping;

public interface ConceptMapBean extends ItemMapBean {

}
