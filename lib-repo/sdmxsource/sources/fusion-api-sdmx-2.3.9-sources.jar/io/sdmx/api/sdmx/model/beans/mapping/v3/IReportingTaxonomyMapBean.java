package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;

/**
 * Represents an SDMX Reporting Taxonomy Map
 *
 * @author Matt Nelson
 */
public interface IReportingTaxonomyMapBean extends IItemSchemeMapBean<IReportingCategoryMapBean> {

	@Override
	IReportingTaxonomyMapMutableBean getMutableInstance();
}
