package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

public interface IUserDefinedOperatorBean extends ItemBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IUserDefinedOperatorBean> getURN();
	
	/**
	 * A VTL statement for the definition of a new operator; it specifies the operator name,
	 * its parameters and the data types, the VTL expression that defines its behaviour
	 * @return not null. 
	 */
	String getOperatorDefinition();
	
}
