package io.sdmx.api.sdmx.model.reverseengineer;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;

public interface UncodedColumnDefinition extends ColumnDefinition {

	/**
	 * @return the format of the column
	 */
	TEXT_TYPE getTextType();
	
	/**
	 * @return the zero indexed column 
	 */
	Integer getColumn();
	
	/**
	 * @return if a string format optionally returns the min/max length
	 */
	Integer minLength();
	Integer maxLength();
}
