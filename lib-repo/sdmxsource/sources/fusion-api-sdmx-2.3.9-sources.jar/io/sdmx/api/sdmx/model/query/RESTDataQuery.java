package io.sdmx.api.sdmx.model.query;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;

public interface RESTDataQuery extends Serializable {
	public static final String ALL_DIMENSIONS = "AllDimensions";
	
	/**
	 * Returns a String representation of this query, in SDMX REST format starting from Data/.
	 * <p/>
	 * Example Data/ACY,FLOW,1.0/M.Q+P....L/ALL?detail=seriesKeysOnly
	 * @return
	 */
	String getRestQuery();

	String getExpression();

	/**
	 * If true then the response message will contain previous versions of the data as they were disseminated in the past
	 * past ("history" or "timeline" functionality)
	 * @return
	 */
	boolean includeHistory();

	/**
	 * @return required, the Dataflow reference - this may contain missing parts to the URN (i.e no Agency ID, no Version). If parts are 
	 * missing these are expected to filled in by only one possible value (i.e. unambiguous)
	 */
	IURN<DataflowBean> getFlowRef();

	/**
	 * Returns the data provider reference, or null if ALL
	 */
	IURNSingle<DataProviderBean> getProviderRef();

	/**
	 * Returns the provision agreement reference, or null if ALL.
	 * <p/>
	 * <strong>NOTE: </strong> This is not part of the SDMX Specification but required to index data where there may be multiple provision agreements for a single data provider
	 * and dataflow pair
	 */
	IURNSingle<ProvisionAgreementBean> getProvisionRef();

	/**
	 * Returns the start date to get the data from, or null if undefined
	 * @return
	 */
	SdmxDate getStartPeriod();

	/**
	 * Returns the end date to get the data from, or null if undefined
	 * @return
	 */
	SdmxDate getEndPeriod();

	/**
	 * Returns the updated after date to get the data from, or null if undefined
	 * @return
	 */
	SdmxDate getUpdatedAfter();

	/**
	 *
	 * Returns the first 'n' observations, for each series key, to return as a result of a data query.
	 * @return last 'n' observations or null if unspecified
	 */
	Integer getLastNObservations();


	/**
	 * Returns the first 'n' observations, for each series key,  to return as a result of a data query
	 * @return first 'n' observations or null if unspecified
	 */
	Integer getFirstNObservations();
	
	/**
	 * To support paginiation of data queries.  An Offset is the series index to start from, zero indexed
	 * 
	 * @return offset to use or null if not defined
	 */
	Integer getOffset();
	
	/**
	 * To support paginiation of data queries.
	 * 
	 * @return maximum number of series to output, -1 indicates no limit
	 */
	Integer getMax();

	/**
	 * Returns the level of detail for the return data, or null if undefined
	 * @return
	 */
	DATA_QUERY_DETAIL getQueryDetail();

	/**
	 * Returns the dimension to , or null if undefined
	 * @return
	 */
	String getDimensionAtObservation();

	/**
	 * Returns the list of dimension codeid filters, in the same order as the dimensions are defined by the DataStructure
	 * @return
	 */
	List<Set<String>> getQueryList();

	/**
	 * Returns the dataset id that is being queried, or null if undefined
	 * @return
	 */
	String getDatasetId();

	/**
	 * Returns an immutable map of additional query parameters that were passed, an empty map is returned if no additional query parameters were passed
	 * @return
	 */
	Map<String, String> getAdditionalQueryParmeters();

	/**
	 * Returns a parameter value for any additional parameters not defined by the REST specification, this can be used for extension of the SDMX functionality
	 * @return
	 */
	String getParamValue(String param);

}
