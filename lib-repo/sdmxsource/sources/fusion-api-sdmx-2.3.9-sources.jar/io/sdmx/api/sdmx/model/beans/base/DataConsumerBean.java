
package io.sdmx.api.sdmx.model.beans.base;



/**
 * Represents an SDMX DataConsumer
 * @author Matt Nelson
 *
 */
public interface DataConsumerBean extends OrganisationBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<DataConsumerBean> getURN();
	
	@Override
	DataConsumerSchemeBean getMaintainableParent();
}
