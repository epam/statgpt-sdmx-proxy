
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

@Deprecated
public interface RelatedStructuresMutableBean extends MutableBean {

	 void addRelatedStructure(StructureReferenceBean sRef);
	 
	 List<StructureReferenceBean> getDataStructureRef();
	 
	 List<StructureReferenceBean> getMetadataStructureRef();
	 
	 List<StructureReferenceBean> getConceptSchemeRef();
	 
	 List<StructureReferenceBean> getCategorySchemeRef();
	 
	 List<StructureReferenceBean> getOrgSchemeRef();
	 
	 List<StructureReferenceBean> getHierCodelistRef();
	 
	 void setDataStructureRef(List<StructureReferenceBean> keyFamilyRef);
	 
	 void setMetadataStructureRef(List<StructureReferenceBean> metadataStructureRef);
	 
	 void setConceptSchemeRef(List<StructureReferenceBean> conceptSchemeRef);
	 
	 void setCategorySchemeRef(List<StructureReferenceBean> categorySchemeRef);
	 
	 void setOrgSchemeRef(List<StructureReferenceBean> orgSchemeRef);
	 
	 void setHierCodelistRef(List<StructureReferenceBean> hierCodelistRef);
	 
}
