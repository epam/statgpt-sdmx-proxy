package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;

/**
 * A single text entry that can have representation in multiple languages
 */
public interface TextTypeBean extends SDMXBean, INoCrossReferencesBean {

	/**
	 * The text for each language
	 * @return
	 */
	List<TextTypeWrapper> getText();
	
	/**
	 * Returns the text in the current language as defined by ClientRequest.getLocale() - if this is null, 
	 * returns text for language 'en', if this is null then returns the first text entry in the list of TextTypeWrapper
	 * @return
	 */
	String getTextForCurrentLanguage();
	
}
