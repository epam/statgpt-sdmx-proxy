
package io.sdmx.api.sdmx.model.mutable.mapping;



@Deprecated
public interface OrganisationSchemeMapMutableBean extends ItemSchemeMapMutableBean<ItemMapMutableBean> {

}
