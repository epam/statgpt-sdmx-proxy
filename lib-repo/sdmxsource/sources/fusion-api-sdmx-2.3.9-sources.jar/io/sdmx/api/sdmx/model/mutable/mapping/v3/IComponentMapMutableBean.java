package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;

/**
 * Maps one or more source components to one or more target components between two DSDs referenced by the {@link IStructureMapMutableBean}
 */
public interface IComponentMapMutableBean extends AnnotableMutableBean {

	/**
	 * Reverses the source and target components
	 */
	void reverseMapping();
	/**
	 * The source components, whose combined values are used to derive the output value(s) for the target components
	 * @return A list of Component IDs from the source DSD
	 */
	List<String> getSourceComponents();
	IComponentMapMutableBean setSourceComponents(List<String> compId);
	IComponentMapMutableBean addSourceComponent(String compId);

	/**
	 * The target components the source components map to
	 * @return A list of Component IDs to the target DSD
	 */
	List<String> getTargetComponents();
	IComponentMapMutableBean setTargetComponents(List<String> compId);
	IComponentMapMutableBean addTargetComponent(String compId);
	
	/**
	 * @return a reference to the representation map which is used to describe the relationship between the reported values
	 * of the source to target component. A null response indicates the values are copied from source to target unmapped, in this 
	 * case there should only be 1 source component and 1 target component
	 */
	StructureReferenceBean getRepresentationMapRef();
	IComponentMapMutableBean setRepresentationMapRef(StructureReferenceBean ref);
}
