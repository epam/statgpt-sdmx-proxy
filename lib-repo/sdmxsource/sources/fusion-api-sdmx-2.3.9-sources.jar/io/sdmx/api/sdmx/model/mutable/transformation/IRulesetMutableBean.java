package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface IRulesetMutableBean extends ItemMutableBean {

	String getRulesetDefinition();
	void setRulesetDefinition(String rulesetDefinition);
	
	String getRulesetType();
	void setRulesetType(String rulesetType);
	
	String getRulesetScope();
	void setRulesetScope(String rulesetScope);
}
