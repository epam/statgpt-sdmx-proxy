
package io.sdmx.api.sdmx.model.beans.base;

/**
 * Nameable beans carry a mandatory name and an optional description, Nameable beans are also Identifiable
 */
public interface NameableBean extends INamedBean, IdentifiableBean {

}
