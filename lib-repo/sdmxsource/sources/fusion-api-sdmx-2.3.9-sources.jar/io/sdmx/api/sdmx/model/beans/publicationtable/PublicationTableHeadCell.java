package io.sdmx.api.sdmx.model.beans.publicationtable;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * This cell is used as a header (either column header or row header)
 */
public interface PublicationTableHeadCell extends SDMXBean, INoCrossReferencesBean {

	/**
	 * @return the text for the label, variables can be used, for example $(SECTOR.A.NAME)
	 */
	String getLabel();
	
	/**
	 * Returns the row span
	 * @return
	 */
	int getRowSpan();
	
	/**
	 * Returns the column span
	 * @return
	 */
	int getColSpan();
	
	/**
	 * @return the {@link PublicationTableHeadCell} label parsed into a {@link IHeadLabel}
	 */
	IHeadLabel getRowLabel();
	
}
