package io.sdmx.api.sdmx.model.data;

import java.util.List;

import io.sdmx.api.csv.DELIMITER;

/**
 * A position notifier for csv files. Stores the location of a dataset, key or observation 
 * in a file. This consists of a line start byte offset and relevant data column indexes.
 * 
 * getOffset returns the offset of the start of the CSV line
 * getBytes returns the length of the CSV line
 */
public interface ICsvFilePosition extends IFilePosition {

	/**
	 * @return Delimiter that the CSV is using
	 */
	DELIMITER getDelimiter();

	/**
	 * @return relevant data column indexes (zero-based)
	 */
	List<Integer> getColumns();
	
	/**
	 * Overridden to provide additional JavaDoc to describe response
	 * 
	 * csv:[offset]:[bytes]:[delimiter]:[column 1]:[column 2]:[column n]
	 * 
	 * example
	 * 
	 * csv:200:23:,:1:3:4:7
	 * 
	 */
	@Override
	String toPositionalString();
}
