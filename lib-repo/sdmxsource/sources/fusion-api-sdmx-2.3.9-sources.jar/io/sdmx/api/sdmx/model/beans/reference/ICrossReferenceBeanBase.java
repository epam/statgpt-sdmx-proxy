
package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * A Base Cross Reference is a reference that could reference one or more structure types using either a semantic, absolute or wildcard URN
 * 
 * The cross reference has an owner (getReferencedFrom) and a target (getURN) and can be subclassed by more specific types of reference, i.e. semantic and absolute
 */
public interface ICrossReferenceBeanBase extends Serializable {  
	
	/**
	 * @return not null, the reference to the given structure (or structures if this is a {@link ICrossReferenceBeanFuzzy})
	 */
	IURN<?> getReference();
		
	/**
	 * @return not null - the structure that owns this Cross Reference 
	 */
	IdentifiableBean getReferencedFrom();
	
	/**
	 * @return not null - the structure that owns this Cross Reference 
	 */
	default IURNAbsolute<?> getReferencedFromURN() {
		return getReferencedFrom().getURN();
	}
	
	/**
	 * @return not null, the URN parameters of the reference which may include wildcards, absolue, or semantic versioning
	 */
	default String getTargetUrn() {
		return getReference().getURN();
	}
	
	/**
	 * @return the target identifiable structure being referenced
	 */
	default SDMX_STRUCTURE_TYPE getTargetReference() {
		return getReference().getSdmxStructure();
	}
	
	/**
	 * @return the maintainable structure type being referenced
	 */
	default SDMX_STRUCTURE_TYPE getMaintainableStructureType() {
		return getTargetReference().getMaintainableStructureType();
	}
	
	/**
	 * @return true if the reference contains wildcard values (fuzzy reference)
	 */
	default boolean isWildcardReference() {
		return getReference().isWildcard();
	}
	

	/**
	 * @param identifiableBean to test the match against
	 * @return true if this cross reference matches the attributes of the {@link IdentifiableBean}
	 */
	default boolean isMatch(IdentifiableBean identifiableBean) {
		return getReference().isMatch(identifiableBean.getURN());
	}
	
	/**
	 * @return the mutable reference type
	 */
	StructureReferenceBean asMutable();
	
}
