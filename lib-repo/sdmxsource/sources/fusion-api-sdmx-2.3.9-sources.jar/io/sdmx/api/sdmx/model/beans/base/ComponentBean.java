package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * A component is a bean which contains reference to a codelist and a concept
 * </p>
 * The concept reference is mandatory and the codelist reference is optional 
 *  
 * @author Matt Nelson
 *
 */
public interface ComponentBean extends IdentifiableBean, IRepresentedBean {
	
	enum COMPONENT_TYPE {
		DIMENSION,
		ATTRIBUTE,
		MEASURE,
		METADATA_ATTRIBUE
	}
	
	@Override
	/**
	 * @return overridden to reutrn a more specific type
	 */
	IURNAbsolute<? extends ComponentBean> getURN();
	
	/**
	 * @return the concept reference, this method will not return null as concept reference is mandatory
	 */
	ICrossReferenceBean<ConceptBean> getConceptRef();
	
	/**
	 * The type of component
	 * @return
	 */
	COMPONENT_TYPE getType();
	
	/**
	 * Returns true if this bean is Mandatory
	 * @return
	 */
	boolean isMandatory();

}
