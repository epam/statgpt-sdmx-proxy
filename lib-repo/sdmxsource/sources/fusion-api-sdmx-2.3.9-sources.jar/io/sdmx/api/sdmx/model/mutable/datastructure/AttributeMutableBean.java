package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;

public interface AttributeMutableBean extends ComponentMutableBean {

	List<StructureReferenceBean> getConceptRoles();
	
	/**
	 * Adds a concept Role to the existing list of concept roles
	 * @param sRef
	 */
	void addConceptRole(StructureReferenceBean sRef);
	
	void setConceptRoles(List<StructureReferenceBean> conceptRoles);
	
	List<String> getDimensionReferences();
	
	/**
	 * @return the list of measures that this attribute references, if this is an empty list, then the attribute is relevant to all measures
	 */
	List<String> getMeasureReferences();
	AttributeMutableBean addMeasureReference(String dimensionRef);
	AttributeMutableBean setMeasureReferences(List<String> dimensionRef);
	
	
	AttributeMutableBean addDimensionReferences(String dimensionRef);
	AttributeMutableBean setDimensionReferences(List<String> dimensionRef);
	
	String getAttachmentGroup();
	
	AttributeMutableBean setAttachmentGroup(String attachmentGroup);
	
	/**
	 * Returns the ATTRIBUTE_ATTACHMENT_LEVEL attribute indicating the level to which the attribute is attached in time-series formats 
	 * (generic, compact, utility data formats). 
	 * Attributes with an attachment level of Group are only available if the data is organised in groups, 
	 * and should be used appropriately, as the values may not be communicated if the data is not grouped.
	 * @return
	 */
	ATTRIBUTE_ATTACHMENT_LEVEL getAttachmentLevel();
	

	AttributeMutableBean setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel);

}
