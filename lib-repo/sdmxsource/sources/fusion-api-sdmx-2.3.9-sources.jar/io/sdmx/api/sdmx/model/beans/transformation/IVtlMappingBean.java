package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public interface IVtlMappingBean<T extends IdentifiableBean> extends ItemBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<? extends IVtlMappingBean> getURN();
	
	/**
	 * @return not null. The reference used to refer to the reference SDMX artefact in the transformations. 
	 * This must be unique within th emappping scheme in which it is defined.
	 */
	String getAlias();
	
	/**
	 * @return not null. The reference to the mapped structure that the mapping is defined for.
	 */
	ICrossReferenceBean<T> getMapped();
}
