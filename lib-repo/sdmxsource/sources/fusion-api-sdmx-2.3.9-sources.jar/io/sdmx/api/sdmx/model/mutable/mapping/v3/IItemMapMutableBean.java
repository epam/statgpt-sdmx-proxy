package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;


public interface IItemMapMutableBean<T extends IItemMapMutableBean<T>> extends AnnotableMutableBean {
	
	/**
	 * @param idx nullable
	 * @return the index to substring the source ID
	 */
	T setSourceStartIdx(Integer idx);
	Integer getSourceStartIdx();
	
	/**
	 * @param idx nullable
	 * @return the index to substring the source ID
	 */
	T setSourceEndIdx(Integer idx);
	Integer getSourceEndIdx();
	
	/**
	 * if the source value is a regular expression
	 */
	T setSourceRegEx(boolean regEx);
	boolean isSourceRegEx();
	
	T setSourceId(String srcId);
	String getSourceId();

	T setTargetId(String targetId);
	String getTargetId();
	
	/**
	 * @return when this mapping is valid from or null if not defined
	 */
	T setValidFrom(String period);
	String getValidFrom();
	
	/**
	 * @return when this mapping is valid to or null if not defined
	 */
	T setValidTo(String period);
	String getValidTo();
}
