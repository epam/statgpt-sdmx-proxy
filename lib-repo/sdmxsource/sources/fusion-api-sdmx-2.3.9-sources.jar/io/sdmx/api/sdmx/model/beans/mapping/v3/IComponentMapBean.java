package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Maps one or more source components to one or more target components between two DSDs referenced by the {@link IStructureMapBean}
 */
public interface IComponentMapBean extends AnnotableBean {

	/**
	 * Properties as reported in the Diff
	 */
	enum Properties {
		SOURCE_COMPONENTS("Source Components"),
		TARGET_COMPONENTS("Target Components");
		
		private String property;
		
		private Properties(String property) {
			this.property = property;
		}

		public String getProperty() {
			return property;
		}
	}
	
	
	/**
	 * The source components, whose combined values are used to derive the output value(s) for the target components
	 * @return A list of Component IDs from the source DSD
	 */
	List<String> getSourceComponents();

	/**
	 * The target components the source components map to
	 * @return A list of Component IDs to the target DSD
	 */
	List<String> getTargetComponents();
	
	/**
	 * @return a reference to the representation map which is used to describe the relationship between the reported values
	 * of the source to target component. A null response indicates the values are copied from source to target unmapped, in this 
	 * case there should only be 1 source component and 1 target component
	 */
	ICrossReferenceBean<IRepresentationMapBean> getRepresentationMapRef();
}
