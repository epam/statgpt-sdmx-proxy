package io.sdmx.api.sdmx.model.beans.valuelist;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;

/**
 * Represents simple text or multilingual text (can be HTML) linked to an identifier
 *
 */
public interface VariableBean extends INoCrossReferencesBean {
	
	/**
	 * Returns the Id
	 * @return
	 */
	String getId();
	
	/**
	 * Returns the text type
	 * @return
	 */
	TextTypeBean getTextType();
	
	/**
	 * For simple value maps, returns a single value
	 * @return
	 */
	String getValue();
}
