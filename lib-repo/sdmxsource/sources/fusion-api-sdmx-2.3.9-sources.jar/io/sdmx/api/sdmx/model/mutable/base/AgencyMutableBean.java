
package io.sdmx.api.sdmx.model.mutable.base;



public interface AgencyMutableBean extends OrganisationMutableBean {

}
