
package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface ConstraintMutableBean extends MaintainableMutableBean {

	ConstraintAttachmentMutableBean getConstraintAttachment();

	void setConstraintAttachment(ConstraintAttachmentMutableBean bean);


	/**
	 * Returns the series keys that this constraint defines at ones that either have data, or are allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetMutableBean getIncludedSeriesKeys();


	/**
	 * Returns the series keys that this constraint defines at ones that either do not have data, or are not allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetMutableBean getExcludedSeriesKeys();

	void setExcludedSeriesKeys(ConstraintDataKeySetMutableBean excludedSeriesKeys);


	void setIncludedSeriesKeys(ConstraintDataKeySetMutableBean includedSeriesKeys);

	

	/**
	 * Returns the metadata keys that this constraint defines at ones that either have data, or are allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetMutableBean getIncludedMetadataKeys();


	/**
	 * Returns the metadata keys that this constraint defines at ones that either do not have data, or are not allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetMutableBean getExcludedMetadataKeys();

	void setExcludedMetadataKeys(ConstraintDataKeySetMutableBean excludedSeriesKeys);


	void setIncludedMetadataKeys(ConstraintDataKeySetMutableBean includedSeriesKeys);

}
