
package io.sdmx.api.sdmx.model.header;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;

/**
 * A party represents a individual or group and can have additional contact information
 */
public interface PartyBean {


	List<TextTypeWrapper> getName();
	
	String getId();
	
	List<ContactBean> getContacts();
	
	String getTimeZone();
	
	
}
