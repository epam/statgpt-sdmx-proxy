package io.sdmx.api.sdmx.model;

import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * Provides the means to retrieve structures and cross references from 
 * the environment that it is attached to
 */
public interface IStructureEnvironment {

	/**
	 * @return not null, the {@link SdmxBeanRetrievalManager} to get {@link IdentifiableBean} by URN
	 */
	SdmxBeanRetrievalManager getBeanRetrievalManager();
	
	/**
	 * @return not null, the {@link IURNRetrievalManager} to find URNs that match a full or partial URN
	 */
	IURNRetrievalManager getURNRetrievalManager();
	
	/**
	 * @return not null, the {@link IURNReferenceRetreivalManager} to get URNs which reference other URNs
	 */
	IURNReferenceRetreivalManager getURNReferenceRetreivalManager();
	
	/**
	 * @return not null, the {@link ISdmxBeanRestRetrievalManager} to get structures by URN
	 */
	ISdmxBeanRestRetrievalManager getRestBeanRetrievalManager();
	
	/**
	 * @return not null, the {@link ConstraintRetrievalManager} to get structures by URN
	 */
	ConstraintRetrievalManager getConstraintRetrievalManager();
	
	/**
	 * @return not null, the {@link SdmxSuperBeanRetrievalManager} for the environment
	 */
	SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager();

	/**
	 * @return not null, the {@link CrossReferencingRetrievalManager} which finds parent and ancestor structures
	 */
	CrossReferencingRetrievalManager getAncestorRetrievalManager();

	/**
	 * @return not null, the {@link CrossReferencedRetrievalManager} which finds child and descendant structures
	 */
	CrossReferencedRetrievalManager getDescendantRetrievalManager();
	
}
