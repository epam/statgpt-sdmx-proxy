package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;

/**
 * Represents an SDMX Organisation Scheme Map
 *
 * @author Matt Nelson
 */
public interface IOrganisationSchemeMapBean extends IItemSchemeMapBean<IOrganisationMapBean> {

	@Override
	IOrganisationSchemeMapMutableBean getMutableInstance();
}
