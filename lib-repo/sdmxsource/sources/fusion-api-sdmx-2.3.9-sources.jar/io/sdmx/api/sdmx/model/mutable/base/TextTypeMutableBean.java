package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;

public interface TextTypeMutableBean extends MutableBean {
	
	/**
	 * The text for each language
	 * @return
	 */
	List<TextTypeWrapperMutableBean> getText();
	void setText(List<TextTypeWrapperMutableBean> text);
	void addText(TextTypeWrapperMutableBean text);

}
