
package io.sdmx.api.sdmx.model.mutable.codelist;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;


public interface CodeMutableBean extends ItemMutableBean, ValidityPeriodMutableBean {

	String getParentCode();
	
	void setParentCode(String parentCode);
	
	/**
	 * Returns true if this code is inherited from another codelist
	 * @return
	 */
	boolean isInherited();
	
	/**
	 * Sets inherited to true
	 */
	void setInherited(boolean inherited);
}
