
package io.sdmx.api.sdmx.model.data;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;


/**
 * Represents a Series or Group Key in a Dataset.  Series have zero to may associated Observations  
 */
public interface Keyable extends Attributable {
	
	/**
	 * Returns the data structure to which this key belongs, this will not be null
	 * @return
	 */
	DataStructureBean getDataStructure();
	
	/**
	 * Returns the dataflow to which this key belongs.  This may be null
	 * if the dataflow is unknown or not applicable.
	 * @return
	 */
	DataflowBean getDataflow();
	
	/**
	 * Returns a colon delimited string representing this key.  
	 * <p/>
	 * Example - if the Key Values are:
	 * 1. FREQ = A
	 * 2. COUNTRY = UK
	 * 3. SEX = M
	 * <p/>
	 * The Short code would be A:UK:M
	 * 
	 * For a Group, the short code includes a concatenation of all Group Key values, and leaves blanks where the dimension 
	 * is not part of the group key, for example a sibling group of the previous example is:
	 * ':UK:M' (nothing reported for frequency)
	 * @return
	 */
	String getShortCode();
	
	/**
	 * Creates a short code for the key but missing out the dimension which matched the ignoreDimension id
	 * @param key series key
	 * @param ignoreDimension do not include the value for this dimension in the short code
	 * @return
	 */
	String createShortCode(String ignoreDimension);
	
	/**
	 * @return an immutable list of key values for this key
	 */
	List<KeyValue> getKey();
	
	/**
	 * Returns the key value for the dimension Id - returns null if the dimension id is not part of the key
	 * @return
	 */
	KeyValue getKeyValue(String dimensionId);
	
	/**
	 * Returns the key value for the dimension Id - returns null if the dimension id is not part of the key
	 * @return
	 */
	String getReportedValue(String dimensionId);
	
	/**
	 * Returns true if this key belongs to a series key, if false then it belongs to a group
	 * @return
	 */
	boolean isSeries();
	
	/**
	 * @return the name (or id) of this group, if this is a group (i.e. isSeries() returns null)
	 */
	String getGroupName();

	
	
}
