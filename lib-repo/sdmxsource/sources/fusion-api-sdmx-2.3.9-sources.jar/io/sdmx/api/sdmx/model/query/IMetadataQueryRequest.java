package io.sdmx.api.sdmx.model.query;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;

public interface IMetadataQueryRequest {
	/**
	 * @return true if the structure format was defaulted (i.e. not explicitly requested by the user) in which case
	 * the API has more flexibilty to choose a different format if not supported
	 */
	boolean wasFormatDefaulted();
	
	/**
	 * @return the metadata query
	 */
	IRESTMetadataQuery getMetadataQueryRequest();
	
	/**
	 * @return access to the HTTP request
	 */
	Request getRequest();
	
	/**
	 * @return access to the response stream and status
	 */
	IResponse getResponse();
	
	/**
	 * @return desired response format
	 */
	IMetadataFormat getFormat();
}
