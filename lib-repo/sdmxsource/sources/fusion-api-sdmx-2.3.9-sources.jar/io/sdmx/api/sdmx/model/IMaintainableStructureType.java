package io.sdmx.api.sdmx.model;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * This specialised for of ISDMXStructureStructure is the maintainable type
 */
public interface IMaintainableStructureType<K extends MaintainableBean> extends ISDMXStructureType<K, K> {

	/**
	 * @return true if this STRUCTURE_TYPE is representing a maintainable artifact.
	 */
	default boolean isMaintainable() {
		return true;
	}
	
	/**
	 * @return true if this STRUCTURE_TYPE is representing a maintainable artifact.
	 */
	default boolean isIdentifiable() {
		return true;
	}
}
