package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;


public interface ConstrainedDataKeyMutableBean extends MutableBean {

	List<IConstrainedKeyValue> getKeyValues();
	/**
	 * Sets the key values with remove prefix to false
	 * @param keyvalues
	 */
	void setSimpleKeyValues(List<KeyValue> keyvalues);
	void setKeyValues(List<IConstrainedKeyValue> keyvalues);
	void addKeyValue(IConstrainedKeyValue keyvalue);
	void addKeyValue(KeyValue keyvalue);

	/**
	 * Returns the list of key values
	 * @return
	 */
	List<IConstrainedKeyValue> getComponentValues();
	void setComponentValues(List<IConstrainedKeyValue> keyvalues);
	void addComponentValues(IConstrainedKeyValue keyvalue);


	String getValidFrom();
	ConstrainedDataKeyMutableBean setValidFrom(String validFrom);

	String getValidTo();
	ConstrainedDataKeyMutableBean setValidTo(String validTo);
}
