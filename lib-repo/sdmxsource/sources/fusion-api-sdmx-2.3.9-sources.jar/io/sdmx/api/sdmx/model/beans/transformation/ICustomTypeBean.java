package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

/**
 * Details a custom type within a {@link ICustomTypeSchemeBean}
 */
public interface ICustomTypeBean extends ItemBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<ICustomTypeBean> getURN();
	
	/**
	 * Identifies the VTL scaler type that is to be converted to a resulting output data type
	 * @return not null
	 */
	String getVtlScalarType();
	
	/**
	 * identifies the resulting output data type of the VTL scaler type that is to be converted to.  If this is an SDMX data type, it must use the proper SimpleDatATyep enumeration value.
	 * For all other data types, a string value can be used to identify the type
	 * @return not null
	 */
	String getDataType();
	
	
	/**
	 * The format the VTL scaler type has to  assumer (e.g. YYYY_MM-DD; see VTL specifications), both for the literals in the VTL expressions
	 * and for the conversion to the output
	 * @return optional
	 */
	String getOutputFormat();
	
	/**
	 * The value to be produced in the output of the conversion when a component has a null value
	 * @return optional
	 */
	String getNullValue();
	
	/**
	 * The format in which the literals of the VTL scaler type are expressed in the the transformations.  This is only
	 * needed if the format is different than the output format expressed by means of the VTL type
	 * @return optional
	 */
	String getVtlLiteralFormat();
	
}
