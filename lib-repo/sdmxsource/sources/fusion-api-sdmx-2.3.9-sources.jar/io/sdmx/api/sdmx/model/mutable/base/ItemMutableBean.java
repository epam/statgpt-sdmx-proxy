
package io.sdmx.api.sdmx.model.mutable.base;



public interface ItemMutableBean extends NameableMutableBean {

}
