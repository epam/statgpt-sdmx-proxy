package io.sdmx.api.sdmx.model.mutable.valuelist;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public interface ValueItemMutableBean extends AnnotableMutableBean {
	
	/**
	 * Returns the Id
	 * @return
	 */
	String getId();
	void setId(String id);
	
	/**
	 * Returns the text type
	 * @return
	 */
	List<TextTypeWrapperMutableBean> getNames();
	void setName(List<TextTypeWrapperMutableBean> names);
	void addName(String locale, String value);
	

	/**
	 * Returns the text type
	 * @return
	 */
	List<TextTypeWrapperMutableBean> getDescriptions();
	void setDescription(List<TextTypeWrapperMutableBean> descriptions);
	void addDescription(String locale, String value);
	
}
