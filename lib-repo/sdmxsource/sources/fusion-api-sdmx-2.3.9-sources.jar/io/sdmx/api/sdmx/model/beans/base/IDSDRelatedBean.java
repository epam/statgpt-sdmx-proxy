package io.sdmx.api.sdmx.model.beans.base;

/**
 *  Ultimately links back to a DSD, and can therefore be used to process data.
 *  
 *  This will be either a Registration, Provision Agreement, Dataflow, or DSD
 */
public interface IDSDRelatedBean extends MaintainableBean, ConstrainableBean {
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<? extends IDSDRelatedBean> getURN();
	
}
