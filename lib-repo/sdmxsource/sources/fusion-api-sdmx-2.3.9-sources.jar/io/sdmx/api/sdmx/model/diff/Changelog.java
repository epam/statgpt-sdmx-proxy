package io.sdmx.api.sdmx.model.diff;

import java.io.OutputStream;
import java.util.SortedSet;

/**
 * Represents a set of changes for a maintainable artifact, for each version of the artifact
 */
public interface Changelog {
	
	/**
	 * the type of change that this changelog represents
	 * structure difference is 
	 * @author Accelerator
	 *
	 */
	enum CHANGELOG_TYPE{
		/**
		 * A change between a structure and its version
		 */
		VERSION_CHANGE,
		/**
		 * a change between 2 different structures of the same type
		 */
		STRUCTURE_DIFFERENCE
	}

	/**
	 * Returns a set of changes latest version first
	 * @return
	 */
	SortedSet<BeanDiff> getChanges();
	
	/**
	 * Writes itself as JSON to the output stream in the format
	 * 
	 * 3.0": {
		"ADDITION": [],
		"REMOVAL": [],
		"EDIT": [
			{
			"urn": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=METATECH:DF_EUR(2.0)",
			"property": "Data Structure Definition Reference",
			"sourcevalue": "METATECH:DEMO_TIMESERIES(2.0)",
			"targetvalue": "METATECH:DEMO_TIMESERIES(3.0)"
			},
			{
			"urn": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=METATECH:DF_EUR(2.0)",
			"property": "Name",
			"sourcevalue": "DemoTimeSeries2",
			"targetvalue": "DemoTimeSeries3"
			}
			]
		},
		"2.0" : {...},
		"1.0" : {...}
	 * @param out
	 */
	void writeJSON(OutputStream out);
}
