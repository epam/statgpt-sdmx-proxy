
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;

public interface AgencySchemeMutableBean extends OrganisationSchemeMutableBean<AgencyMutableBean> {

	@Override
	AgencySchemeBean getImmutableInstance();
	
}
