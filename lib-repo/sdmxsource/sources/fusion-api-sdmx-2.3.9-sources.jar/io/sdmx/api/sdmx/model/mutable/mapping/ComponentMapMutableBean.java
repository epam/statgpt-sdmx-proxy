
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;


@Deprecated
public interface ComponentMapMutableBean extends AnnotableMutableBean {

	List<String> getMapConceptRef();
	
	List<String> getMapTargetConceptRef();
	
	RepresentationMapRefMutableBean getRepMapRef();
	
	void addMapConceptRef(String sourceRef);
	
	void addMapTargetConceptRef(String targetRef);
	
	void setMapConceptRef(List<String> sourceRef);
	
	void setMapTargetConceptRef(List<String> targetRef);
	
	void setRepMapRef(RepresentationMapRefMutableBean representationRef);
	
	
	
}
