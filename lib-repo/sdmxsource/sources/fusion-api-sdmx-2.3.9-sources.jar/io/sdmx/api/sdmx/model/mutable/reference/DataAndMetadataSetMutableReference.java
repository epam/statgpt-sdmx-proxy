
package io.sdmx.api.sdmx.model.mutable.reference;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface DataAndMetadataSetMutableReference extends MutableBean {

	/**
	 * Returns the dataset referenced by data flow/provider/provision
	 * @return
	 */
	StructureReferenceBean getDataSetReference();
	void setDataSetReference(StructureReferenceBean bean);
	
	/**
	 * Returns the id of the data or metadata set
	 * @return
	 */
	String getSetId();
	void setSetId(String id);
	
	/**
	 * Returns true if this is a dataset reference, false if it is a metadata set reference
	 * @return
	 */
	boolean isDataSetReference();
	void setIsDataSetReference(boolean isRef);
}
