
package io.sdmx.api.sdmx.model.mutable.base;


public interface OrganisationUnitMutableBean extends OrganisationMutableBean {

	/**
	 * Returns the id of the parent organisation unit, or null if there is none
	 * @return
	 */
	String getParentUnit();
	
	/**
	 * 
	 * Sets a parent unit to the value specified.
	 * @param parentUnit
	 */
	void setParentUnit(String parentUnit);
}
