package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

import java.util.List;

/**
 * Describes the details of a single transformation in a {@link ITransformationSchemeBean}
 */
public interface ITransformationBean extends ItemBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<ITransformationBean> getURN();
	
	/**
	 * @return true if the result is permanently stored. A persistent result can be used by transformation defines in
	 * other transformation schemes, but a non-persistent result can only be used by transformations within the same transformation scheme
	 */
	boolean isPersistent();

	/**
	 * @return not null - the left hand side of the VTL statement.  This identifies the result artefact which may be used in subsequent transformations
	 * If the result is an SDMX Artefact this is expressed using the alias; see Section 6 SDMX Standards ("Abbreviation of the URN").
	 */
	String getResult();
	
	/**
	 * The right hand side of the VTL statement. This is the expression that is executed for this transformation. It includes references to operands and other
	 * artefacts.  The expression may contain references to SDMX artefacts using the reduced URN format; see Section 6 SDMX Standards ("Abbreviation of the URN").
	 * 
	 * @return not null 
	 */
	String getExpression();

	/**
	 * returns an immutable list of full and/or partial references from within the VTL statement. As VTL can reference a structure by
	 * only its ID a IURN contains a minimum of a maintainable ID and a Structure type. As it is not possible at construction
	 * time to determine if the VTL statement is referencing an SDMX structure or another VTL variable, a IURN which contains only an ID
	 * is only an indication that it may be a SDMX structure reference. If the IURN contains an AgencyID or Version then this should
	 * be interpreted as an unambiguous reference to an SDMX structure.
	 *
	 * @return List<IURN> of referenced artifacts
	 */
	List<IURN<?>> getReferencedArtifacts();

}
