package io.sdmx.api.sdmx.model.tx;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;

/**
 * Filter on the Transactions by URN, Transaction Id, and/or Action
 */
public interface ITXURNQuery {

	/**
	 * @return nullable, transaction ID to filter by
	 */
	String getTxId();
	
	/**
	 * @return nullable, the URN to filter by
	 */
	IURNMaintainable<?> getUrn();
	
	/**
	 * @return nullable, the action (1=insert,2=update, 3=delete) 
	 */
	Integer getAction();
	
}
