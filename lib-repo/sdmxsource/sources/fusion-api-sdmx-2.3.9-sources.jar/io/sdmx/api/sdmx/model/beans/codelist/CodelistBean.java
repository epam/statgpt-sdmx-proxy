package io.sdmx.api.sdmx.model.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesMaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;

/**
 *
 *
 * Represents an SDMX Code List
 * <pre>
 *               __
 *              / _)
 *     _/\/\/\_/ /
 *   _|         /
 *  _|  (  | (  |
 * /__.-'|_|--|_|     Raaar
 * </pre>
 *
 *
 * @author Matt Nelson
 */
public interface CodelistBean extends ValidatableBean<CodeBean>, EnumeratedListBean<CodeBean>, INoCrossReferencesMaintainableBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<CodelistBean> getURN();
	
	/**
	 * @param prefix
	 * @return a copy with the Codelist, keeping only the codes with the given prefix, but with the prefixes removed (to satsify Discriminated Union use case)
	 */
	CodelistBean removePrefix(String prefix);

	/**
	 * Returns true if the codelist is only reporting a subset of the codes.
	 * <p/>
	 * Partial codelists are used for dissemination purposes only not for reporting updates.
	 * @return
	 */
	@Override
	boolean isPartial();


	/**
	 * @return true if this codelist contains geographical information
	 * @see IGeoGridCodelistBean, {@link IGeographicCodelistBean}
	 */
	boolean isGeoCodelist();

	@Override
	CodelistBean cloneForDate(Date date);


	/**
	 * @return codes that have no parent codes
	 */
	List<CodeBean> getRootCodes();

	/**
	 * @param id
	 * @return the child codes for the codelist
	 */
	@Override
	List<CodeBean> getChildren(String id);


	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	CodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);


	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	CodelistMutableBean getMutableInstance();

	/**
	 * Returns whether this instance was created by a request for a specific point in time.
	 * For example, if the instance was constructed via new() then this should returned false.
	 * However if the instance was constructed via a cloneForDate() method then this should return true.
	 */
	@Override
	boolean createdFromTimeRequest();


	/**
	 * Returns a new item scheme based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @return
	 */
	@Override
	CodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet);

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////INHERITANCE  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * @return true if this codelist is the material representation of a Codelist inherited from other codelists
	 */
	boolean isInherited();

	/**
	 * 
	 * @return true if this Codelist defines inheritance rules (it may be in its raw form, in which case isInherited=false and this Codelist only contains its own codes, not those that it inherits from)
	 */
	boolean hasInherited();
	
	/**
	 * @return not null immutable list of inheritence rules, empty list if there are none
	 */
	List<ICodelistInheritanceRuleBean> getInheritedCodelists();

	/**
	 * @return if isInherited is true, this returns the raw Codelist where isInherited=false but hasInherited=true - if isInherited = false, returns null
	 */
	CodelistBean getRootCodelist();

	
}