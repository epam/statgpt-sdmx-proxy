package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;

public interface INamePersonalisationSchemeMutableBean extends IVtlSchemeMutableBean<INamePersonalisationMutableBean> {

	@Override
	INamePersonalisationSchemeBean getImmutableInstance();

	INamePersonalisationMutableBean addINamePersonalisation(String id, String vtlArtefact, String defaultName, String personalisedName);
	
}
