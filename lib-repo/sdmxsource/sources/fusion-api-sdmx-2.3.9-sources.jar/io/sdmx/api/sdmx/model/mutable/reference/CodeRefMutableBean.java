
package io.sdmx.api.sdmx.model.mutable.reference;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;


public interface CodeRefMutableBean extends IdentifiableMutableBean, ValidityPeriodMutableBean {
	
	StructureReferenceBean getCodeReference();
	void setCodeReference(StructureReferenceBean structureReference);

	List<CodeRefMutableBean> getCodeRefs();
	void setCodeRefs(List<CodeRefMutableBean> codeRefs);
	void addCodeRef(CodeRefMutableBean codeRef);
	
	Date getValidFrom();
	
	void setValidFrom(Date validFrom);

	Date getValidTo();

	void setValidTo(Date validTo);
	
	String getLevelReference();
	
	
	void setLevelReference(String levelRef);
	

	CodeRefMutableBean setVersion(String version);
	String getVersion();
	
	/**
	 * This has the same Effect as getValidFrom
	 */
	@Override
	default Date getStartDate() {
		return this.getValidFrom();
	}
	
	/**
	 * This has the same Effect as getValidTo
	 */
	@Override
	default Date getEndDate() {
		return this.getValidTo();
	}
	
	/**
	 * This has the same Effect as setValidFrom
	 */
	@Override
	default ValidityPeriodMutableBean setStartDate(Date startDate) {
		this.setValidFrom(startDate);
		return this;
	}
	
	/**
	 * This has the same Effect as setValidTo
	 */
	@Override
	default ValidityPeriodMutableBean setEndDate(Date endDate) {
		this.setValidTo(endDate);
		return this;
	}
}
