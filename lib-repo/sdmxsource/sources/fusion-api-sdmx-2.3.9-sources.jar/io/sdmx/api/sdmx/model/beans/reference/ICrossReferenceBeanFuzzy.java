package io.sdmx.api.sdmx.model.beans.reference;

/**
 * Represents a cross reference which can match multiple structures as it 
 * can omit information in the URN such as a wildcard agency, id, version, and structure type
 */
public interface ICrossReferenceBeanFuzzy extends ICrossReferenceBeanBase {

	
	/**
	 * @return true if the reference contains wildcard values
	 */
	default boolean isWildcardReference() {
		return true;
	}
	
}
