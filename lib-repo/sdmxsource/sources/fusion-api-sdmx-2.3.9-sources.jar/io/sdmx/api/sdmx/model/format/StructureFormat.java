package io.sdmx.api.sdmx.model.format;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;

/**
 * StructureFormat is an Interface which wrappers a strongly typed and non-extensible {@link STRUCTURE_OUTPUT_FORMAT} enumeration.  The purpose of the wrapper is to
 * allow for additional implementations to be provided which may describe non-sdmx formats which are not supported by the {@link STRUCTURE_OUTPUT_FORMAT} enum.
 */
public interface StructureFormat extends InformationFormat {
	/**
	 * Returns the SDMX Structure Output Type that this interface is describing.
	 * <p/>
	 * If this is not describing an SDMX message then this will return null and the implementation class will be expected to expose additional methods
	 * to describe the output format
	 * @return SDMX output format, or null if this is not describing an SDMX output
	 */
	STRUCTURE_OUTPUT_FORMAT getSdmxOutputFormat();

	/**
	 * Returns the string value of how this format should be represented in a Web Service query. For example in a standard structure query in SMDX 2.1 format,
	 * the Web Service would expect ?format=sdmx-2.1.  So an implementor of this interface which wanted to be an SMDX 2.1 format would return "sdmx-2.1"
	 * @return the format
	 */
	String getWebServiceFormat();
}
