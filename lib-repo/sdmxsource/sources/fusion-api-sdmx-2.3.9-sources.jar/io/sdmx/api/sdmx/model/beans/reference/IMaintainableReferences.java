package io.sdmx.api.sdmx.model.beans.reference;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Describes the references from a MaintainableBean
 */
public interface IMaintainableReferences<T extends MaintainableBean> {

	/**
	 * @return from maintainable URN
	 */
	IURNMaintainable<T> getMaintURN();


	/**
	 * @return Immutable map of references, from identifiable URN, to collection of identifiable URNs.  
	 * The From URN may be the maintainable URN or an Identifiable URN which is contained in the IURNMaintainable 
	 * 
	 * e.g. if the IURNMaintainable for this type is a DataStructureDefinition, the IURNAbsolute key in this map would be a Dimenison, Attribute, or Meausre URN
	 * with the Mapped set being to a Concept URN and possibly a Codelist / Valuelist URN
	 */
	Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> getReferences();
	
}
