package io.sdmx.api.sdmx.model.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * Container for metadata (structure, reference metadata)
 */
public interface IMetadataContainer  extends Serializable {
	
	/**
	 * @return not null, list of links which are relevant to the container (informational only)
	 */
	List<ILinkBean> getLinks();
	
	/**
	 * Adds a link to the list of link
	 * @param link
	 */
	void addLink(ILinkBean link);
	
	/**
	 * Returns a new, read-only identifier for this beans container
	 * @return
	 */
	String getId();
	
	/**
	 * Returns the action for this container
	 * @return
	 */
	DATASET_ACTION getAction();
	
	/**
	 * Sets the action for this container
	 * @param action
	 */
	void setAction(DATASET_ACTION action);
	
	/**
	 * Returns the header for this beans container. Returns null if there is no header associated with this container.
	 * @return
	 */
	HeaderBean getHeader();

	/**
	 * Sets the header on this set of beans
	 * @return
	 */
	void setHeader(HeaderBean header);
	
	/**
	 * @return set of unique locales in the container
	 */
	Set<String> getAllLocales();
}
