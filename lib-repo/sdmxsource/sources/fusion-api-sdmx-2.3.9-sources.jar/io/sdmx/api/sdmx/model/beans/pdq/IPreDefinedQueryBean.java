package io.sdmx.api.sdmx.model.beans.pdq;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;

public interface IPreDefinedQueryBean extends MaintainableBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IPreDefinedQueryBean> getURN();
	
	
	/**
	 * @return true to indicate this is a virtual dataflow, false to indicate it is a filter on an existing dataflow
	 */
	boolean isVirtualFlow();
	
	@Override
	IPreDefinedQueryMutableBean getMutableInstance();
	
    /**
	 * @return the Dataflows the query is for
	 */
	Set<IDirectCrossReferenceBean<DataflowBean>> getDataflow();
	
	/**
	 * @return the set of selections selections are implicitly ANDED together.
	 */
	List<IPreDefinedQueryComponentFilterBean> getSelections();
	
	/**
	 * <p>Returns an immutable list set containing the basket of series which are expected to be returned as a result of this query.</p>
	 * <p>The syntax is colon separated A:B:C:D</p>
	 * <p>Series can be wildcarded, and may contain + operators to indicate multiple selections, example: A:::D</p>
	 * @return
	 */
	Set<String> getSeries();

	/**
	 * @return immutable map of additional query parameters
	 */
	Map<String, String> getParameters();
}
