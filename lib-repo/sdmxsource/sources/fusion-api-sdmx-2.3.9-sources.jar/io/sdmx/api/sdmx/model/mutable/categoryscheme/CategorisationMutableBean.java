
package io.sdmx.api.sdmx.model.mutable.categoryscheme;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface CategorisationMutableBean extends MaintainableMutableBean {

	/**
	 * Returns a reference to the structure that this is categorising
	 * @return
	 */
	StructureReferenceBean getStructureReference();

	/**
	 * Returns a reference to the category that this giving the semantic
	 * @return
	 */
	StructureReferenceBean getCategoryReference();

	/**
	 * Sets the reference to the structure that this is categorising
	 * @return
	 */
	void setStructureReference(StructureReferenceBean structureReference);

	/**
	 * Sets the reference to the category that this giving the semantic
	 * @return
	 */
	void setCategoryReference(StructureReferenceBean categoryRef);

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	CategorisationBean getImmutableInstance();
}
