
package io.sdmx.api.sdmx.model.beans.process;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;


/**
 * Represents an SDMX Process Step
 * @author Matt Nelson
 */
public interface ProcessStepBean extends NameableBean, INoCrossReferencesBean {
	
	/**
	 * Returns the inputs of this Process Step as a copy of the underlying list.
	 * <p/>
	 * Returns an empty list if no inputs exist
	 * @return
	 */
	List<InputOutputBean> getInput();
	
	/**
	 * Returns the outputs of this process step as a copy of the underlying list.
	 * <p/>
	 * Returns an empty list if no outputs exist
	 * @return
	 */
	List<InputOutputBean> getOutput();
	
	
	ComputationBean getComputation();
	
	/**
	 * Returns TransitionBeans as a copy of the underlying list.
	 * <p/>
	 * Returns an empty list if no TransitionBean exist
	 * @return
	 */
	List<TransitionBean> getTransitions();
	
	/**
	 * Returns the child Process Steps as a copy of the underlying list.
	 * <p/>
	 * Returns an empty list if no child process steps exist
	 * @return
	 */
	List<ProcessStepBean> getProcessSteps();

}
