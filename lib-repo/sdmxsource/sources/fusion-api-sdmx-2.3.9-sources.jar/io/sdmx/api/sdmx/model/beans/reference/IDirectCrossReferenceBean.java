package io.sdmx.api.sdmx.model.beans.reference;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * A direct cross reference is one which is fully described in a Maintainable structure or it's child structure
 * and does not require any external information, for example a Dataflow directly references a DSD by its URN
 * whereas a Data Constraint indirectly references a Concept because the Data Constraint only provides the
 * DSD Component ID, the URN can only be resolved by first resolving the DSD to find Component by its ID and using
 * this to detemine the Concept Scheme to then derive the Concept URN
 * 
 * TL;DR - a IDirectCrossReferenceBean is part of a MaintainableBean
 * 
 * @param <T>
 */
public interface IDirectCrossReferenceBean<T extends IdentifiableBean> extends ICrossReferenceBean<T> {

    /**
     * @return not null, the property of the owning structures reference, i.e. a representation map may have two IDirectCrossReferenceBean one for the source
     * codelist and one for the target, the source would take the property 'source' and the target 'target', enabling a system to determine how the reference is used
     * by its owning structure.
     */
    String getProperty();
    
}
