package io.sdmx.api.sdmx.model.beans.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;

/**
 * Defines an Excel Reporting Template
 */
public interface ReportingTemplateBean extends MaintainableBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ReportingTemplateBean> getURN();
	
	/**
	 * @return an optional instruction sheet
	 */
	ReportTemplateInstructionSheetBean getInstructionSheet();
	
	/**
	 * Returns all the worksheets for this template
	 * @return
	 */
	List<ReportingTemplateWorksheetBean> getWorksheets();
	
	/**
	 * If true will include a worksheet which includes a summary of the checking tables for each worksheet.  
	 * @return
	 */
	boolean includeFormulaCheckingSummary();

	@Override
	ReportingTemplateMutableBean getMutableInstance();
}
