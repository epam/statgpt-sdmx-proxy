package io.sdmx.api.sdmx.model.beans.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

public interface ReportTemplateInstructionSheetBean extends INoCrossReferencesBean {
	
	/**
	 * @return name of worksheet
	 */
	String getName();
	
	/**
	 * @return optional title
	 */
	String getTitle();
	
	/**
	 * @return immutable list of instructions
	 */
	List<ReportTemplateInstructionTextBean> getInstructions();
}
