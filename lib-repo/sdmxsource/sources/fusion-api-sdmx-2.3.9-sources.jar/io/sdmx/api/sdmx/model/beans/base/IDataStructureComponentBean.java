package io.sdmx.api.sdmx.model.beans.base;


public interface IDataStructureComponentBean extends ComponentBean {

}
