package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * Defines one row of the table header
 */
public interface PublicationTableHeadRow extends SDMXBean, INoCrossReferencesBean {
	
	/**
	 * Returns the list of table header cells for this row
	 * @return
	 */
	List<PublicationTableHeadCell> getHeaderCells();
	
}
