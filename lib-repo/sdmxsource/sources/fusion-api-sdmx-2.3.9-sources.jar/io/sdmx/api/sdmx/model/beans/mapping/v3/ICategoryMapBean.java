package io.sdmx.api.sdmx.model.beans.mapping.v3;

/**
 * Represents an SDMX Category Map
 */
public interface ICategoryMapBean extends IItemMapBean {

}
