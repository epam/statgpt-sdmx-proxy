package io.sdmx.api.sdmx.model.superbeans.hierarchy;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;

public interface HierarchySuperBean extends MaintainableSuperBean<HierarchyBean> {

	/**
	 * @return underlying hierarchy
	 */
	List<HierarchicalCodeSuperBean> getCodeRefs();
}
