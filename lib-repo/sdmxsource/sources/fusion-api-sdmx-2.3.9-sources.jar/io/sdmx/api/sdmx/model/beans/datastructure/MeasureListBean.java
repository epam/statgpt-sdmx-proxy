
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * Represents an SDMX Measure List
 * @author Matt Nelson
 *
 */
public interface MeasureListBean extends IdentifiableBean, INoCrossReferencesBean {
	static final String FIXED_ID = "MeasureDescriptor";
	
	/**
	 * Returns the primary measure, this can be null
	 * @return
	 */
	PrimaryMeasureBean getPrimaryMeasure();
	
	/**
	 * @return additional measures
	 */
	List<MeasureDimensionBean> getMeasures();
}
