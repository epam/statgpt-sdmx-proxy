package io.sdmx.api.sdmx.model.query;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

/**
 * Query for a Publication Table
 * @author Metadata Technology
 *
 */
public interface RESTTableQuery {

	/**
	 * Returns a reference to the Table which is to be built
	 * @return
	 */
	IMaintainableRef getTableReference();
	
	/**
	 * Returns the period for which to build the table, or null if not defined
	 * @return
	 */
	SdmxPeriod getTablePeriod();
	
	/**
	 * Returns the table query parameters, or an empty map if no parameters were passed
	 * @return
	 */
	Map<String, String> getQueryParameters();
	
}
