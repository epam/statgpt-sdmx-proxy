
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;


/**
 * Represents an SDMX Dimension in a Data Structure.
 * <p/>
 * A dimension defines the semantic using a <code>ConceptBean</code>, and the representation using either <code>CodelistBean</code>
 * a <code>TextFormatBean</code> or just plain text.
 * @author Matt Nelson
 *
 */
public interface DimensionBean extends IDataStructureComponentBean, Comparable<DimensionBean> {
	String TIME_DIMENSION_FIXED_ID = "TIME_PERIOD";

	/**
	 * @return overridden to return the absolute type
	 */
	@Override
	IURNAbsolute<DimensionBean> getURN();

	
	@Override
	default int getMinOccurs() {
		return 1;
	}
	
	@Override
	default int getMaxOccurs() {
		return 1;
	}
	
	/**
	 * This method is here for backwards compatibility with SDMX v2.1 and v2.0 where there was no
	 * concept of multiple measures.  Multiple Measures were provided through a Dimension which played
	 * the role of a Measure Dimension and each reported Measure was backed by a Concept. i.e the reported
	 * data was against a Concept such as Births, Deaths, Marriages which would be present in the Concept Scheme
	 * that this URN references
	 * 
	 * @return nullable, reference to Concept Scheme used in v2.0 SDMX
	 */
	IURNSingle<ConceptSchemeBean> getConceptScheme();
	
	/**
	 * Returns true if this dimension is the measure dimension.
	 * <p/>
	 * <strong>NOTE: </strong> This is mutually exclusive with isFrequencyDimension() and isTimeDimension().
	 * @return
	 */
	boolean isMeasureDimension();
	
	/**
	 * Returns true if this dimension is the frequency dimension.
	 * <p/>
	 * <strong>NOTE: </strong> This is mutually exclusive with isMeasureDimension() and isTimeDimension().
	 * @return
	 */
	boolean isFrequencyDimension();
	
	/**
	 * Returns true if this dimension is the time dimension.
	 * <p/>
	 * <strong>NOTE: </strong> This is mutually exclusive with isFrequencyDimension() and isMeasureDimension().
	 * @return
	 */
	boolean isTimeDimension();
	
	/**
	 * Returns the index of this dimension in the dimension list. 1 indexed.
	 * @return
	 */
	int getPosition();
	
	/**
	 * Returns cross references to the concept(s) that are defining the role of this dimension.
	 * The returned list is a copy of the underlying list.
	 * <p/>
	 * Returns an empty list if there are no concept roles defined.
	 * @return
	 */
	List<IDirectCrossReferenceBean<ConceptBean>> getConceptRole();
	
	@Override
	DataStructureBean getMaintainableParent();
	
}
