package io.sdmx.api.sdmx.model.data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;

/**
 * A container for Measure values, with optional attributes and dimension at observation level
 */
public interface Observation extends Attributable, Comparable<Observation> {
	
	/**
	 * Returns the parent series key for this observation.  The returned object can not be null.
	 * @return
	 */
	Keyable getSeriesKey();
	
	/**
	 * Returns a colon delimited string representing this key.
	 * <p/>
	 * Example - if the Key Values are:
	 * 1. FREQ = A
	 * 2. COUNTRY = UK
	 * 3. SEX = M
	 * 4. TIME_PERIOD = 2008
	 * <p/>
	 * The Short code would be A:UK:M:2008
	 * @return
	 */
	String getShortCode();
	
	/**
	 * @return the reported value for the primary measure, or null if there is not one
	 */
	default KeyValue getPrimaryMeasure() {
		return getMeasure(PrimaryMeasureBean.FIXED_ID);
	}
	
	/**
	 * @param measure- the ID of the measure
	 * @return the value for the given measure or null if there is no value
	 */
	KeyValue getMeasure(String measure);

	String getMeasureCode(String conceptId);
	
	/**
	 * @return not null, immutable list of measure values
	 */
	List<KeyValue> getMeasures();

	/**
	 * @return immutable map of measure ID to measure values, not null
	 */
	Map<String, KeyValue> getMeasureMap();
	
	/**
	 * @param measure - the ID of the measure
	 * @return immutable list of measure values for the measure with the given ID - not null
	 */
	List<String> getMeasureValues(String measure);
	
	/**
	 * @return immutable map of measures expressed as a number, null values are measures which could not be expressed numerically
	 * @see getMeasureValues for the inputs to this map
	 */
	Map<String, List<BigDecimal>> getNumericalMeasureValues();
	
	/**
	 * @return optional - the ID of the Dimension on the Observation.  For time series date, this will be DimensionBean.TIME_DIMENSION_FIXED_ID
	 */
	String getDimensionId();
	
	/**
	 * @return optional the value for the Dimension at the Observation - for Time Series data this will be the time value
	 */
	String getDimensionValue();

	/**
	 * @return optional observation time as SdmxDate, this is not null if getDimensionId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID) && getDimensionValue() != null
	 */
	SdmxDate getSdmxObsTime();

	/**
	 * @param concept
	 * @return the value(s) for the given complex measure
	 */
	IMultilingualKeyValue getMultilingualMeasure(String concept);

	/**
	 * @return List of all complex measures for an observation
	 */
	List<IMultilingualKeyValue> getMultilingualMeasures();
	
	/**
	 * @return true if the observation time is not null
	 */
	default boolean hasObsTime() {
		return DimensionBean.TIME_DIMENSION_FIXED_ID.equals(getDimensionId()) && getDimensionValue() != null;
	}
}
