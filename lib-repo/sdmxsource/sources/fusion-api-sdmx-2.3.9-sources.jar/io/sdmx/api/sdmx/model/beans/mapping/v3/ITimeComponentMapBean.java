package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;

/**
 * Defines the rules for mapping a Component whose value defines a point in time, but where the syntax of time does not match the SDMX specification, 
 * the exact rules for how the source value is formatted are defined in sub interfaces, which include {@link IEpochMapBean} and {@link ITimePatternMapBean} 
 */
public interface ITimeComponentMapBean extends AnnotableBean {

	/**
	 * The component id in the source DSD for the mapping, this defines which component will contain the time period that needs mapping
	 * @return Component ID from the source DSD. Not Null.
	 */
	String getSourceComponent();

	/**
	 * The component id in the target DSD for the mapping, this defines which component will contain the time period that needs to take the mapped value
	 * @return Component ID from the target DSD. Not Null.
	 */
	String getTargetComponent();

	/**
	 * <p>Mutually exclusive with getOutputFrequencyDimId</p>
	 * <br/>
	 * <p>Returns the Frequency ID used to format the output time period, for example A would format the output time in YYYY format</p>
	 * <br/>
	 * <p>The output frequency is expected to align with the frequencies found in {@link TIME_FORMAT}, however in situations where the output 
	 * frequency is not in this enumeration, the getRepresentationMapRef() method should return not null, and the linked map should contain the formatting
	 * rules for the identifier, e.g. A2 = YY</p>
	 * 
	 * @return the output frequency - or if null the output frequency is derived from another Dimension
	 */
	String getOutputFrequencyId();
	
	/**
	 * <p>Mutually exclusive with getOutputFrequencyId</p>
	 * <br/>
	 * <p>Returns the Id of the Component whose value (for the series) defines how the output time period is formatted, for example a value of FREQ would
	 * cause a lookup to the value of the FREQ Dimension (in the mapped output) which may result in the value A which is then used to format time using the YYYY format</p>
	 * <br/>
	 * <p>The output frequency is expected to align with the frequencies found in {@link TIME_FORMAT}, however in situations where the output 
	 * frequency is not in this enumeration, the getRepresentationMapRef() method should return not null, and the linked map should contain the formatting
	 * rules for the identifier, e.g. A2 = YY</p>
	 * 
	 * @return the output frequency - or if null the output frequency is derived from another Dimension
	 */
	String getOutputFrequencyDimId();
	
	/**
	 * In case the input frequency is lower then the output frequency, the mapping defaults to end of period, 
	 * but can be explicitly told to resolve to start, end, or mid period
	 * @return period position, if null, default end of period
	 */
	PERIOD_POSITION getPeriodResolution();
	
}
