package io.sdmx.api.sdmx.model.beans.publicationtable;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Maps a variable identifier (getId()) to a Codelist
 */
public interface PublicationVariableBean extends IdentifiableBean {

	/**
	 * @return reference to the Codelist or Valuelist which contains the variable values (codes)
	 */
	ICrossReferenceBean<? extends EnumeratedListBean> getCodelistReference();

}
