package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface INamePersonalisationMutableBean extends ItemMutableBean {

	/**
	 * Identifies the type of VTL model artefact that is being personalised.  In VTL 2.0, this is valuedomain or variable
	 * @return not null
	 */
	String getVtlArtefact();
	void setVtlArtefact(String vtlArtefact);
	
	/**
	 * Provides the VTL standard name that is being personalised
	 * @return not null
	 */
	String getVtlDefaultName();
	void setVtlDefaultName(String VtlDefaultName);
	
	/**
	 * Provides the personalised name that is used in place of the VTL standard name in the transformation expression
	 * @return not null
	 */
	String getPersonalisedName();
	void setPersonalisedName(String PersonalisedName);
	
}
