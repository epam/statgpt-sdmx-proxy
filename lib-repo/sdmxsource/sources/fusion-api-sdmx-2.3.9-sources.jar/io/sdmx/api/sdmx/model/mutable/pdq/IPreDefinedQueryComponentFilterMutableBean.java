package io.sdmx.api.sdmx.model.mutable.pdq;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * A filter on a component in the DSD for a {@link IPreDefinedQueryBean}
 */
public interface IPreDefinedQueryComponentFilterMutableBean extends MutableBean {
 
	/**
	 * @return the component that is being filtered
	 */
	String getComponentId();
	void setComponentId(String id);
	
	void addFilter(MATCH_FUNCTION function, Collection<String> values);
	Map<MATCH_FUNCTION, Set<String>> getFilters();
}
