package io.sdmx.api.sdmx.model;

import java.util.Map;



/**
 * The SdmxReader is a technology independent definition of a reader for SDMX-ML files
 *
 */
public interface SdmxReader {
	
	/**
	 * Reads the next element enforcing it is one of the following elements
	 * @param expectedElement this can not be null
	 * @return will return a value that matches one of the expected values, response can never be null
	 * @throws ValidationException if the next element does not match the expected element
	 */
	//String readNextElement(String...expectedElement) throws ValidationException;
	
	
	
	/**
	 * Takes a peek at the next element without moving the parser forward
	 * @return
	 */
//	String peek();
	
	/**
	 * Reads the next element returning the value.  The response is null if there is no more elements to read
	 * @return
	 */
	boolean moveNextElement();
	
	
	/**
	 * Returns the name of the currentElement
	 * @return
	 */
	String getCurrentElement();
	/**
	 * Returns the value in the current element - returns null if there is no value
	 * @return
	 */
	String getCurrentElementValue();
	
	/**
	 * Moves the parser back to the element with the given name. 
	 */
//	boolean moveBackToElement(String element);

	/**
	 * Moves to the position in the file with the element name, returns true if the move was successful, false if no element was found 
	 * @param element
	 * @return
	 */
	boolean moveToElement(String element);
	
	boolean moveToElement(String element, String doNoMovePast);
	
	/**
	 * Returns a map of all the attributes present on the current node
	 * @return
	 */
	Map<String, String> getAttributes();
	
	
	/**
	 * Returns an attribute value with the given name, if mandatory is true then will enforce the response is not null
	 * @param attributeName
	 * @param mandatory
	 * @return
	 * @throws ValidationException if mandatory is true and the attribute is not present
	 */
	String getAttributeValue(String attributeName, boolean mandatory);
	
	
	/**
	 * Closes any underlying resource
	 */
	void close();
	
}
