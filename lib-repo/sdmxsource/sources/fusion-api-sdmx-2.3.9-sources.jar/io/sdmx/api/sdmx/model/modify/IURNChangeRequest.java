package io.sdmx.api.sdmx.model.modify;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface IURNChangeRequest {

	/**
	 * Unique identifier for this change request
	 */
	String getUid();

	Map<MaintainableBean, MaintainableBean> getUrnChanges();
	
	Map<String, IReferencesUpdatedRequest> getReferenceUpdates();
	
}
