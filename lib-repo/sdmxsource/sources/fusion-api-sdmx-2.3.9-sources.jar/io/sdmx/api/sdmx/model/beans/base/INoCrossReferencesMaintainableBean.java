package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;

/**
 * A maintainable bean which does not cross reference any other {@link IdentifiableBean} and contains
 * no composites which can cross reference any other {@link IdentifiableBean}, for example a {@link CodelistBean}
 */
public interface INoCrossReferencesMaintainableBean extends INoCrossReferencesBean, MaintainableBean {


}