package io.sdmx.api.sdmx.model.beans.valuelist;

import java.net.URL;
import java.util.Collection;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesMaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;

/**
 * This is similar to the SDMX Codelist, but each item in an item list does not have to have a SDMX Compliant Identifier
 */
public interface ValueListBean extends EnumeratedListBean<ValueItemBean>, INoCrossReferencesMaintainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ValueListBean> getURN();
	
	/**
	 * @return an immutable list of items, or an empty list if none exist
	 */
	@Override
    List<ValueItemBean> getItems();
	
	/**
	 * @return true if this is a partial list
	 */
	@Override
    boolean isPartial();
	
	/**
	 * @param id
	 * @return the item by id, or null if it does not exist
	 */
	@Override
    ValueItemBean getItemById(String id);
	
	/**
	 * override from MaintainableBean
	 */
	@Override
    ValueListMutableBean getMutableInstance();
	
	/**
	 * override from MaintainableBean
	 */
	@Override
    ValueListBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Creates a partial list by either removing all or keeping only the set of items passed in, sets the is partial flag to true
	 * @param items set of item ids
	 * @param keep if true then the set of items which match the passed in ids will be kept, otherwise the set will be used as the set to remove
	 * @return the modified ValueListBean
	 */
	@Override
    ValueListBean filterItems(Collection<String> items, boolean keep);
	
	
}
