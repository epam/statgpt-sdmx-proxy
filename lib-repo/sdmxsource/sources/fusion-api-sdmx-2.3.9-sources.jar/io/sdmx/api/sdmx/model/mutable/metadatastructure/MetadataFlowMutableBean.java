
package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface MetadataFlowMutableBean extends IMetadataTargetIdentifiableMutable {
	
	StructureReferenceBean getMetadataStructureRef();
	
	void setMetadataStructureRef(StructureReferenceBean metadataStructureRef);
	
	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	MetadataFlowBean getImmutableInstance();
	
}
