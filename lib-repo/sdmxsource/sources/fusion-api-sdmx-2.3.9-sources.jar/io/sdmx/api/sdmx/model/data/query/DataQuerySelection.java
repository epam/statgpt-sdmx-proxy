
package io.sdmx.api.sdmx.model.data.query;

import java.io.Serializable;
import java.util.Set;

import io.sdmx.api.sdmx.constants.COMPOMNENT_TYPE;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;

/**
 * A DataQuerySelection represents a single component (dimension or attribute), with one or more code selections for it.
 */
public interface DataQuerySelection extends Serializable {
	
	/**
	 * Returns the component Id that the code selection(s) are for.  The component Id is either a reference to a dimension
	 * or an attribute
	 * @return
	 */
	String getComponentId();
	
	/**
	 * Returns the value of the code that has been selected for the component. 
	 * <p/>
	 * If more then one value exists then calling this method will result in a exception.  
	 * Check that hasMultipleValues() returns false before calling this method
	 * @return
	 */
	String getValue();
	
	/**
	 * Returns all the code values that have been selected for this component
	 * @return
	 */
	Set<String> getValues();
	
	/**
	 * Adds a selection value to this 
	 * @param value
	 */
	void addSelectionValue(String... value);
	
	/**
	 * Returns true if more then one value exists for this component
	 * @return
	 */
	boolean hasMultipleValues();
	
	/**
	 * Returns true if this rule is defining values to be EXCLUDED from the result set, as oppose to inclusion
	 * @return
	 */
	boolean isExcluded();
	
	/**
	 * @return the function to match by
	 */
	public MATCH_FUNCTION getMatchFunction();
	
	/**
	 * Returns what this component in with respect to the DSD (Dimension, Series Attribute etc)
	 * @return
	 */
	COMPOMNENT_TYPE getComponentType();
}
