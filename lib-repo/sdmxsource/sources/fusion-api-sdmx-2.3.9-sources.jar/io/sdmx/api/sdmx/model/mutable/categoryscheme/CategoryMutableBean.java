
package io.sdmx.api.sdmx.model.mutable.categoryscheme;

import io.sdmx.api.sdmx.model.mutable.base.HierarchicalItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;


public interface CategoryMutableBean extends HierarchicalItemMutableBean<CategoryMutableBean>, ValidityPeriodMutableBean {


	
}
