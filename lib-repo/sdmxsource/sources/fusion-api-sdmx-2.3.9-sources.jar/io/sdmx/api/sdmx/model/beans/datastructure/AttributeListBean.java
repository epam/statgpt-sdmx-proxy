
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_URN;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;


/**
 * Represents an SDMX Attribute List
 */
public interface AttributeListBean extends IdentifiableBean, INoCrossReferencesBean {
	static final String URN_CLASS = "AttributeDescriptor";
	static final String URN_PACKAGE = SDMX_URN.PACKAGE_DATASTRUCTURE;

	static final String FIXED_ID = "AttributeDescriptor";
	

	/**
	 * Returns the list of attributes that this attribute list is holding.
	 * <p/>
	 * The returned list will be a copy of the underlying list, and is expected to have at least one AttributeBean
	 * @return
	 */
	List<AttributeBean> getAttributes();
}
