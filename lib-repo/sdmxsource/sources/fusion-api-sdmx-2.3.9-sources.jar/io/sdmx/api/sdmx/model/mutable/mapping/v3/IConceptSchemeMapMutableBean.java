package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;

public interface IConceptSchemeMapMutableBean extends IItemSchemeMapMutableBean<IConceptMapMutableBean> {

	IConceptSchemeMapBean getImmutableInstance();
}
