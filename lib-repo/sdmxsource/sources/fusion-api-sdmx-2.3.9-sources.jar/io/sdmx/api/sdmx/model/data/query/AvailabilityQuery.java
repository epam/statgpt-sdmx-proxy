package io.sdmx.api.sdmx.model.data.query;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.AVAILABILITY_MODE;
import io.sdmx.api.sdmx.constants.METRICS;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;

/**
 * A query used to return the available code selections based on the current query state
 */
public interface AvailabilityQuery {
	
	/**
	 * Returns the reference detail for this structure query, can not be null
	 * @return
	 */
	STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail();

	/**
	 * If STRUCTURE_REFERENCE_DETAIL == SPECIFIC, this method will return the specific structure reference, returns null otherwise
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getSpecificStructureReference();
	
	/**
	 * returns the mode which defines how to generate the list of valid value
	 * @return
	 */
	AVAILABILITY_MODE getMode();
	
	/**
	 * @return If availability is only required for a subset of Components, then this will return the Ids of that component
	 * null will be returned if availability is required for all Compoentns
	 */
	Set<String> getComponentIds();
	
	/**
	 * @return Series Query or Data Query
	 */
	BaseDataQuery getDataQuery();
	
	/**
	 * Include metrics in the response - does not return null, default NONE
	 * @return
	 */
	METRICS includeMetrics();
	
	/**
	 * @return list of structures to explicitly return metrics for
	 */
	List<SDMX_STRUCTURE_TYPE> getSpecificMetrics();
}
