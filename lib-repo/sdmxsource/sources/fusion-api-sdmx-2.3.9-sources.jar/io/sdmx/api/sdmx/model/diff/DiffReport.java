package io.sdmx.api.sdmx.model.diff;

import java.util.Set;
import java.util.SortedSet;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * Provides the ability to both build a Difference report, and obtain the diff information
 */
public interface DiffReport {


	/**
	 * Returns the source maintainable that is being compared
	 * @return
	 */
	MaintainableBean getSource();

	/**
	 * Returns the target maintainable that is being compared
	 * @return
	 */
	MaintainableBean getTarget();


	/**
	 * Adds a difference between two object properties - the source or target values can be null, but they can not both be null
	 * all other properties are required
	 * @param reference - a reference to the object, for example a URN
	 * @param property - the object property
	 * @param sourceVal - source value if null then a Diff.MODIFCATION.REMOVAL operation is assumed - if not null toString will be called on this when creating the Diff
	 * @param targetVal - source value if null then a Diff.MODIFCATION.ADDITION operation is assumed - if not null toString will be called on this when creating the Diff
	 */
	void addDiff(SDMXBean source, String property, Object sourceVal, Object targetVal);

	/**
	 * Returns a list of all the differences in the order in which they were found
	 * @param modificationType the type of difference, if null is provided all the differences will be returned
	 * @return
	 */
	SortedSet<Diff> getdifferences(ModificationAction modificationType);
	
	/**
	 * @return a list of all the differences in the order in which they were found
	 */
	Set<Diff> getDifferences();

}
