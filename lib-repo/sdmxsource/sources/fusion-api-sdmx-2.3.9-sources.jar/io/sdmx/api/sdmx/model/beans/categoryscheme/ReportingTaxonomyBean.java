
package io.sdmx.api.sdmx.model.beans.categoryscheme;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;


/**
 * Represents an SDMX Reporting Taxonomy
 * @author Matt Nelson
 *
 */
public interface ReportingTaxonomyBean extends ItemSchemeBean<ReportingCategoryBean>, INoCrossReferencesBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ReportingTaxonomyBean> getURN();
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are 
	 * contained within the Maintainable
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	ReportingTaxonomyBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ReportingTaxonomyMutableBean getMutableInstance();
	
}
