package io.sdmx.api.sdmx.model.mutable.base;

import java.util.Date;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;

public interface ItemSchemeMutableBean<T extends ItemMutableBean> extends MaintainableMutableBean {

	/**
	 * Returns the list of items, this can be null
	 * @return
	 */
	List<T> getItems();

	/**
	 * Returns the item with the given id, returns null if there is no item with the id provided
	 * @param id
	 * @return
	 */
	T getItemById(String id);

	/**
	 * sets the list of items, overwriting any existing list.  Will set the list to null if the passed in argument is null
	 * @param list
	 */
	void setItems(List<T> list);

	/**
	 * Creates a partial list by either removing all or keeping only the set of items passed in, sets the is partial flag to true
	 * @param items set of item ids
	 * @param keep if true then the set of items which match the passed in ids will be kept, otherwise the set will be used as the set to remove
	 * @param filterAction if an item is excluded should items which reference this parent have their parent code set to null?
	 * @return the partial MutableBean
	 */
	MaintainableMutableBean createPartialList(Set<String>  items, boolean keep, ITEM_FILTER_ACTION filterAction);

	/**
	 * Creates a partial list by either removing all or keeping only the set of items passed in, sets the is partial flag to true
	 * @param urns set of item urns
	 * @param keep if true then the set of items which match the passed in urns will be kept, otherwise the set will be used as the set to remove
	 * @param filterAction if an item is excluded should items which reference this parent have their parent code set to null?
	 * @return the partial MutableBean
	 */
	MaintainableMutableBean createPartialByUrn(Set<String> urns, boolean keep, ITEM_FILTER_ACTION filterAction);

	/**
	 * removes the item with the given id, if it exists
	 * @param id
	 * @return true if the item was successfully removed, false otherwise
	 */
	boolean removeItem(String id);

	/**
	 * Adds an item to the list of items, creates a list if it does not already exist
	 * @param item
	 */
	void addItem(T item);

	/**
	 * Adds an item to the list of items, at a specified position, creates a list if it does not already exist
	 * @param item
	 * @param pos
	 */
	void addItemAtPosition(T item, int pos);

	/**
	 * Creates an item and adds it to the scheme
	 * @param id, the id to set
	 * @param name, the name to set in the 'en' lang
	 * @return the created item
	 */
	T createItem(String id, String name);

	boolean isPartial();

	void setPartial(boolean isPartial);

	/**
	 * Removes items in this item scheme that are not valid for the specified Date.
	 * @param aDate
	 */
	ItemSchemeMutableBean<T> stripItems(Date aDate);

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ItemSchemeBean<?> getImmutableInstance();

	/**
	 * Returns whether this instance was created by a request for a specific point in time.
	 * For example, if the instance was constructed via new() then this should returned false.
	 * However if the instance was constructed via a cloneForDate() method then this should return true.
	 */
	default boolean createdFromTimeRequest() {
		return false;
	}
}