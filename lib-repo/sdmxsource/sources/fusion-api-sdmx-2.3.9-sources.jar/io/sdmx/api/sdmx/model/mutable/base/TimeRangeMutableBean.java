package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;

public interface TimeRangeMutableBean extends MutableBean {

	/**
	 * If true then start date and end date both have a value, and the range is between the start and end dates.
	 * <p/>
	 * If false, then only the start date or end date will be populated, if the start date is populated then it this period refers
	 * to dates before the start date. If the end date is populated then it refers to dates after the end date.
	 * @return
	 */
	boolean isRange();
	void setIsRange(boolean isRange);
	
	/**
	 * Returns the Start Date - if range is true, or the Before date if range is false
	 * @return
	 */
	SdmxDate getStartDate();
	void setStartDate(SdmxDate start);
	
	/**
	 * Returns the End Date - if range is true, or the After date if range is false
	 * @return
	 */
	SdmxDate getEndDate();
	void setEndDate(SdmxDate end);
	
	/**
	 * Returns true if the start date is included in the range
	 * @return
	 */
	boolean isStartInclusive();
	void setIsStartInclusive(boolean includeStart);
	
	/**
	 * Returns true if the end date is included in the range
	 * @return
	 */
	boolean isEndInclusive();
	void setIsEndInclusive(boolean includeEnd);

	/**
	 * @return the beginning of the validity period for the Time Range, can be null
	 */
	SdmxDate getValidFrom();
	void setValidFrom(SdmxDate validFrom);

	/**
	 * @return the end of the validity period for the Time Range, can be null
	 */
	SdmxDate getValidTo();
	void setValidTo(SdmxDate validTo);

	/**
	 * @return an immutable instance of itself
	 */
	TimeRangeBean createImmutableInstance(SdmxStructureBean parent);
}
