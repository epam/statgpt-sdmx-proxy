package io.sdmx.api.sdmx.model.beans.codelist;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public interface ICodelistInheritanceRuleBean extends SDMXBean {
	
	/**
	 * @return the reference to the Codelist to inherit from
	 */
	ICrossReferenceBean<CodelistBean> getCodelistRef();
	
	/**
	 * @return the prefix to include on the inherited Codelist
	 */
	String getPrefix();

	/**
	 * @return not null, immutable list of ids to include from inheritance, the presence of a % indicates a wildcard
	 */
	List<String> getInclusiveInheritenceIds();
	
	/**
	 * @return not null, immutable set of Code Ids to cascade down from in the inheritance inclusion rule
	 */
	Set<String> getInclusiveInheritenceCascades();
	
	/**
	 * @return not null, immutable list of ids to exclude from inheritance, the presence of a % indicates a wildcard
	 */
	List<String> getExclusiveInheritenceIds();
	
	/**
	 * @return not null, immutable set of Code Ids to cascade down from in the inheritance exclusion rule
	 */
	Set<String> getExclusiveInheritenceCascades();
}
