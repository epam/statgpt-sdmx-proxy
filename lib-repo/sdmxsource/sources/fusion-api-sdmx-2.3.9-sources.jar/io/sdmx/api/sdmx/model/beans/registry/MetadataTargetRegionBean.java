
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;

public interface MetadataTargetRegionBean extends SdmxStructureBean, INoCrossReferencesBean {

	/**
	 * Returns true if the information reported is to be included or excluded 
	 * @return
	 */
	boolean isInclude();
	
	String getReport();
	
	String getMetadataTarget();
	
	
	/**
	 * Returns the key values restrictions for the metadata target region
	 * @return
	 */
	List<MetadataTargetKeyValuesBean> getTargetKeyValues();
	
	/**
	 * Returns the attributes restrictions for the metadata target region
	 * @return
	 */
	List<KeyValues> getAttributes();
	
}
