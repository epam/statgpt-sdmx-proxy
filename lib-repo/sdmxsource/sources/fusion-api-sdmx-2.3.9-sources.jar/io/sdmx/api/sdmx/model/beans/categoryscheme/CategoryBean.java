
package io.sdmx.api.sdmx.model.beans.categoryscheme;

import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MetricsBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;

/**
 * Represents an SDMX Category
 * 
 * This bean may include metrics if it has been enriched and is linked to data, this bean will inherit the metrics of all sub-categories
 */
public interface CategoryBean extends HierarchicalItemBean<CategoryBean>, MetricsBean, ValidityPeriodBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<CategoryBean> getURN();
}
