package io.sdmx.api.sdmx.model.diff;

public enum ModificationAction {
    ADDITION,
    EDIT,
    REMOVAL;
}
