
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface RepresentationMutableBean extends MutableBean {

	/**
	 * Returns the text format, which is typically present for an uncoded component (one which does not reference a codelist).
	 * </p>
	 * Returns null if there is no text format present
	 * @return
	 */
	TextFormatMutableBean getTextFormat();

	void setTextFormat(TextFormatMutableBean textFormat);
	
	/**
	 * Returns the codelist reference, returns null if there is no reference
	 * @return
	 */
	StructureReferenceBean getRepresentation();
	

	/**
	 * @return minimum number of values that can be reported against this attribute. Greater then 0  indicates mandatory
	 */
	Integer getMinOccurs();
	RepresentationMutableBean setMinOccurs(Integer num);
	/**
	 * @return maximum number of values that can be reported against this attribute, default 1
	 */
	Integer getMaxOccurs();
	RepresentationMutableBean setMaxOccurs(Integer num);

	void setRepresentation(StructureReferenceBean representationRef);
	
}
