package io.sdmx.api.sdmx.model.mutable.transformation;

public interface IVtlConceptSchemeMappingMutableBean extends IVtlMappingMutableBean {

}
