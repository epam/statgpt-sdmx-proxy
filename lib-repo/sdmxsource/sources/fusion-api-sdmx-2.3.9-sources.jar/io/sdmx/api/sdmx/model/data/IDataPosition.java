package io.sdmx.api.sdmx.model.data;

/**
 * Marker interface to be subclasses with concrete positional interfaces.  The {@link IDataPosition} is used
 * to indicate the position in a dataset of the information in a dataset for example an Observation Measure may be a byte
 * offset in a file (if the dataset is read from a file) or a cell reference in an excel workbook, or a series offset from an in memory store
 */
public interface IDataPosition {

	/**
	 * Common position types
	 */
	enum POSITION_TYPE {
		FILE("fip"),      //IFilePosition
		CSV("csv"),       //ICsvFilePosition
		EXCEL("exl"),
		RELATIVE("rel"),  //IRelativePosition
		CUSTOM("cus"),    //Could be anything, getId() will provide more detail
		UNAVAILABLE("unv");
		
		private String positionalPrefix;

		private POSITION_TYPE(String positionalPrefix) {
			this.positionalPrefix = positionalPrefix;
		}

		/**
		 * @return the prefix at the start of the toPositionalString
		 */
		public String getPositionalPrefix() {
			return positionalPrefix;
		}
	}
	
	/**
	 * @return the type of positional information this represents to assist in downcasting
	 */
	POSITION_TYPE getPositionType();
	
	/**
	 * Default implementation returns POSITION_TYPE as a string, for CUSTOM position types this can be overridden to provide
	 * some more details on the custom type
	 * 
	 * @return not null - unique ID for this position type which can be used in switch statements for downcasting.
	 */
	default String getId() {
		return getPositionType().toString();
	}
	
	/**
	 * @return not null - a string to represent the position formatted according to the position type, the string has the following parts
	 * [position type]:[positional parameter 1]:[positional parameter 2]:[positional parameter n]
	 * 
	 * For example for a {@link IFilePosition} it may be
	 * fip:100:23
	 * 
	 * 
	 */
	String toPositionalString();
	
}
