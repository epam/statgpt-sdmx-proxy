package io.sdmx.api.sdmx.model.data;

public interface ICellPositions {

	
	
}
