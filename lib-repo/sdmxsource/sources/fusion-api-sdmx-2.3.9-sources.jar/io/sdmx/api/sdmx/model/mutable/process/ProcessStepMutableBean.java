
package io.sdmx.api.sdmx.model.mutable.process;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;


public interface ProcessStepMutableBean extends NameableMutableBean {
	
	List<InputOutputMutableBean> getInput();
	
	List<InputOutputMutableBean> getOutput();
	
	ComputationMutableBean getComputation();
	
	List<TransitionMutableBean> getTransitions();
	
	List<ProcessStepMutableBean> getProcessSteps();
	
	void addInput(InputOutputMutableBean input);
	
	void setInput(List<InputOutputMutableBean> input);
	
	void addOutput(InputOutputMutableBean output);
	
	void setOutput(List<InputOutputMutableBean> output);
	
	void setComputation(ComputationMutableBean computation);
	
	void setTransitions(List<TransitionMutableBean> transitions);
	
	void addTransition(TransitionMutableBean transition);
	
	void setProcessSteps(List<ProcessStepMutableBean> processSteps);
	
	void addProcessStep(ProcessStepMutableBean processStep);
	
}
