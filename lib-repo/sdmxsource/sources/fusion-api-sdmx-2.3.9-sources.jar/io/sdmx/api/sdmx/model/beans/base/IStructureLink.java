package io.sdmx.api.sdmx.model.beans.base;

/**
 * Describe a link between two structures
 */
@Deprecated //use PersistableCrossReference 
public interface IStructureLink {

	/**
	 * @return not null - the source maintainable
	 */
	IURN<?> getMaintainable();
	
	/**
	 * @return not null - the source structure (either the maintainable or an identifiable within the maintainable)
	 */
	IURN<?> getSource();
	
	/**
	 * @return not null - the target structure 
	 */
	IURN<?> getTarget();
}
