package io.sdmx.api.sdmx.model.beans.mapping.v3;

/**
 * Represents an SDMX Reporting Category Map
 */
public interface IReportingCategoryMapBean extends IItemMapBean {

}
