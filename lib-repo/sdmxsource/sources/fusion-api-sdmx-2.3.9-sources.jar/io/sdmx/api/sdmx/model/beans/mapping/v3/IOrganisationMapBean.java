package io.sdmx.api.sdmx.model.beans.mapping.v3;

/**
 * Represents an SDMX Organisation Map
 */
public interface IOrganisationMapBean extends IItemMapBean {

}
