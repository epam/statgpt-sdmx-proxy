
package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


public interface MetadataStructureDefinitionMutableBean extends MaintainableMutableBean, IMetadataAttributeContainerMutableBean {

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	MetadataStructureDefinitionBean getImmutableInstance();
	
}
