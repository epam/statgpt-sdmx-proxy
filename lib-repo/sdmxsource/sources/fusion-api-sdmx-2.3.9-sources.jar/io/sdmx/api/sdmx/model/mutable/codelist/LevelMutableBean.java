
package io.sdmx.api.sdmx.model.mutable.codelist;

import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;


public interface LevelMutableBean extends NameableMutableBean {

	TextFormatMutableBean getCodingFormat();
	
	void setCodingFormat(TextFormatMutableBean textFormat);
	
	LevelMutableBean getChildLevel();
	
	void setChildLevel(LevelMutableBean level);
	
	
}
