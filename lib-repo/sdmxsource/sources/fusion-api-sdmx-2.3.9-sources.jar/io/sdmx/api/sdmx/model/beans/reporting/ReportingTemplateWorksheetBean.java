package io.sdmx.api.sdmx.model.beans.reporting;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;

/**
 * Describes a report template worksheet
 *
 */
public interface ReportingTemplateWorksheetBean extends IdentifiableBean {
	
	@Override
	/**
	 * @return a more specific generics type
	 */
	IURNAbsolute<ReportingTemplateWorksheetBean> getURN();
	
	/**
	 * The Dataflow that this worksheet is for
	 * @return
	 */
	ICrossReferenceBean<DataflowBean> getDataflow();
	
	/**
	 * Max width, measured in characters which roughly relates to excels number system (not pixels, the one with no name when resizing a column)
	 * @return max width of the columns, or null if not specified.
	 */
	Integer getColMaxWidth();
	
	/**
	 * @return an optional Dimension Id, if present this worksheet will be used as a template for all unique dimension values of the slice, i.e if SliceBy is FREQ then there will be a worksheet for each Frequency based on this template
	 */
	String getSliceBy();
	
	/**
	 * The dimensions to be used in the table columns
	 * @return
	 */
	List<String> getTableCols();

	/**
	 * The dimensions to be used in the table rows
	 * @return
	 */
	List<String> getTableRows();
	
	/**
	 * The attributes that have fixed values
	 * @return
	 */
	Set<String> getFixedAttributes();
	
	/**
	 * The fixed value for the attribute with the given id
	 * @param dimId
	 * @return
	 */
	String getFixedAttributeValue(String dimId);
	

	Map<String, String> getFixedAttributesMap();
	
	/**
	 * Returns the attributes that have variable values and are included in the report alongside the observation cells
	 * @return
	 */
	Set<String> getVariableAttributes();
	
	/**
	 * Returns the dimensions that can be reported by the user as a single value on the worksheet, separately from the main table
	 * @return
	 */
	Set<String> getVariableDimensions();
	
	/**
	 * Returns the attributes that have variable values and are included in a separate worksheet
	 * @return
	 */
	Set<String> getWorksheetAttributes();
	
	/**
	 * Returns the attributes that have variable values and are to be built into a separate table below the main observation table
	 * @return
	 */
	Set<String> getSeparateAttributes();
	
	/**
	 * Returns the conditional attributes or an empty list if there are none
	 * @param attributeId
	 * @return
	 */
	List<ReportingTemplateConditionalAttributeBean> getConditionalAttributes();
	
	/**
	 * @return  a set of Dimensions ids to exclude from the output excel report if the dimension has a fixed value
	 */
	Set<String> getExcludeDimensions();
	
	/**
	 * @return the id of the attribute to be used as colour on the observation, or null if none is defined
	 */
	ReportingTemplateColourBean getColourAttribute();
	
	/**
	 * @param componentId
	 * @return true if this component should display the values by id, or false if display is by label
	 */
	TEXT_DISPLAY getTextDisplay(String componentId);
	
	/**
	 * @return nullable, specifies the number of decimal places to round any numerical data to
	 */
	Integer getRoundDecimals();
	
	/**
	 * @return immutable map of component id to display default is by label if unspecified
	 */
	Map<String, TEXT_DISPLAY> getTextDisplay();
	
	/**
	 * @return not null, immutable map of Dimension IDs to Hierarchy
	 */
	Map<String, IDirectCrossReferenceBean<HierarchyBean>> getHierarhcyReferences();

	/**
	 * @return not null, immutable set of dimension ids that have an implicit hierarchy
	 */
	Set<String> getImplicitHierarchices();
	
}
