
package io.sdmx.api.sdmx.model.mutable.process;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;

public interface InputOutputMutableBean extends AnnotableMutableBean {

	String getLocalId();

	void setLocalId(String localId);

	StructureReferenceBean getStructureReference();

	void setStructureReference(StructureReferenceBean structureReference);
}
