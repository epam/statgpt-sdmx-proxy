package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * Content constraint defining allowed data
 */
public interface AllowedContentConstraintBean extends ContentConstraintBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<AllowedContentConstraintBean> getURN();
}
