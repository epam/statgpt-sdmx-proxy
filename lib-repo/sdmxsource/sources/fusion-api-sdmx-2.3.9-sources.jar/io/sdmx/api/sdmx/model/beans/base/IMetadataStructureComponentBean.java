package io.sdmx.api.sdmx.model.beans.base;

public interface IMetadataStructureComponentBean  extends ComponentBean {

}
