package io.sdmx.api.sdmx.model.beans.transformation;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;

/**
 * Provides the details of a custom type scheme, in which user defined operators are described
 */
public interface ICustomTypeSchemeBean extends IVtlSchemeBean<ICustomTypeBean>, INoCrossReferencesBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ICustomTypeSchemeBean> getURN();
	
	@Override
	ICustomTypeSchemeMutableBean getMutableInstance();
	
	@Override
	ICustomTypeSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

}
