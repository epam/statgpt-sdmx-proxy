
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;


public interface IMetadataProviderSchemeMutableBean extends OrganisationSchemeMutableBean<IMetadataProviderMutableBean>{

	
	@Override
	IMetadataProviderSchemeBean getImmutableInstance();
	
}
