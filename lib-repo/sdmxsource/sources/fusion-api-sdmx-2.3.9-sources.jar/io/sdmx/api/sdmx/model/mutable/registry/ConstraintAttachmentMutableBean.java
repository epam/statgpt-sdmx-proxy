
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.DataAndMetadataSetMutableReference;


public interface ConstraintAttachmentMutableBean extends MutableBean {

	
	DataAndMetadataSetMutableReference getDataOrMetadataSetReference();
	void setDataOrMetadataSetReference(DataAndMetadataSetMutableReference ref);
	
	Set<StructureReferenceBean> getStructureReference();
	void setStructureReference(Set<StructureReferenceBean> bean);
	void addStructureReference(StructureReferenceBean bean);

	List<DataSourceMutableBean> getDataSources();
	
	void setDataSources(List<DataSourceMutableBean> beans);
	
	void addDataSources(String url);
	
	void addDataSource(DataSourceMutableBean dsBean);

}
