
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.Date;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;


public interface ReferencePeriodMutableBean extends MutableBean {

	/**
	 * Returns an inclusive start time for the reference period
	 * @return
	 */
	Date getStartTime();

	void setStartTime(Date start);
	
	/**
	 * Returns an inclusive end time for the reference period
	 * @return
	 */
	Date getEndTime();

	void setEndTime(Date end);

}
