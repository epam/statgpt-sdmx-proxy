package io.sdmx.api.sdmx.model.beans.codelist;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;

/**
 * This Codelist and all the codes in it are the result of the combination of one or more Codelists
 *
 * This Codelist has an Agency, Id, and Version as the unique identifiers, this will match the Id, Agency, and Version of ONE of the
 * underlying Codelists in this container, this Codelist is the maintained artifact from which this Combined Codelist is built.  The
 * additional Codelists are those that this Codelist is
 */
public interface CombinedCodelistBean extends CodelistBean {

	/**
	 * @return an immutable list of Codelists that the root Codelist extends.  The order is important, and codes which are redefined
	 * in either a lower level Codelist (later in the list) or the root Codelist, take precedence.  It
	 *
	 * Codelist ONE:
	 * A = Alpha
	 * B = Beta
	 * G = Gamma
	 * Codelist TWO:
	 * A = Angola
	 * B = Brazil
	 * Root Codelist:
	 * A = Apple
	 *
	 * The outcome is A=Apple, B=Brazil, G=Gamma
	 */
	List<CodelistBean> getExtendedCodelists();

	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	CodelistMutableBean getMutableInstance();

}
