
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;

public interface RegistrationBean extends MaintainableBean, ConstrainableBean, IDSDRelatedBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<RegistrationBean> getURN();
	
	/**
	 * Returns true if one of the index getters is set to true
	 * @return
	 */
	boolean isIndexed();
	
	/**
	 * The indexTimeSeries, if true, indicates that the registry must index all time series for the registered data. 
	 * <p/> 
	 * The index will create a Keyset Constraint
	 * <p/>
	 * The default value is false, and the attribute will always be assumed false when the provision agreement references a metadata flow.
	 * @return
	 */
	TERTIARY_BOOL getIndexTimeSeries();
	
	/**
	 * The indexDataSet, if true, indicates that the registry must index the range of actual (present) 
	 * values for each dimension of the data set or identifier component of the metadata set (as indicated in the set's structure definition). 
	 * <p/>
	 * The index will create a Cube Region Constraint
	 * <p/>
	 * The default value is false.
	 * @return
	 */
	TERTIARY_BOOL getIndexDataset();
	
	/**
	 * The indexAttributes, if true, indicates that the registry must index the range of actual (present) values 
	 * for each attribute of the data set or the presence of the metadata attributes of the metadata set (as indicated in the set's structure definition). 
	 * <p/>
	 * The default value is false.
	 * @return
	 */
	TERTIARY_BOOL getIndexAttributes();
	
	/**
	 * The indexReportingPeriod, if true, indicates that the registry must index the time period ranges for which data is present for the data source. 
	 * <p/>
	 * The default value is false, and the attribute will always be assumed false when the provision agreement references a metadata flow.
	 * @return
	 */
	TERTIARY_BOOL getIndexReportingPeriod();
	
	/**
	 * Returns when the registration was last updated
	 * @return
	 */
	SdmxDate getLastUpdated();
	
	SdmxDate getValidFrom();
	
	SdmxDate getValidTo();
	
	DataSourceBean getDataSource();
	
	/**
	 * @return not null, a reference to the provision agreement this registration is for
	 */
	ICrossReferenceBean<ProvisionAgreementBean> getProvisionAgreementRef();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the RegistrationMutableBean.
	 * @return
	 */
	@Override
	RegistrationMutableBean getMutableInstance();
	
}
