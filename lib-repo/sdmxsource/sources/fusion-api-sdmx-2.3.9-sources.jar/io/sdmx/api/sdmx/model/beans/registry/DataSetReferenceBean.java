
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public interface DataSetReferenceBean extends SdmxStructureBean {

	String getDatasetId();
	
	ICrossReferenceBean<DataProviderBean> getDataProviderReference();
}
