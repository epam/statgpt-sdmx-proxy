package io.sdmx.api.sdmx.model.beans.base;

import java.util.Collection;
import java.util.List;

/**
 * Represents an enumerated list of enumeration items, where a Codelist is an example of a list where the list items are Identifiable (they have a URN)
 * and a ValueList is an example of an enumeration where the list items are not Identifiable (they do not have a URN as the Id of the item can be anything)
 */
public interface EnumeratedListBean<T extends EnumeratedItemBean> extends MaintainableBean {

	/**
	 * @return an immutable list of items, or an empty list if none exist
	 */
	List<T> getItems();
	
	/**
	 * @return true if this is a partial list
	 */
	boolean isPartial();
	
	/**
	 * @param id
	 * @return the item by id, or null if it does not exist
	 */
	T getItemById(String id);
	
	/**
	 * @param id id of an idtem for which to return the child items for
	 * @return the child items for the enumeration or an empty list if there are none
	 */
	List<T> getChildren(String id);
	
	/**
	 * Creates a partial list by either removing all or keeping only the set of items passed in, sets the is partial flag to true
	 * @param items set of item ids
	 * @param keep if true then the set of items which match the passed in ids will be kept, otherwise the set will be used as the set to remove
	 * @return the modified ValueListBean
	 */
	EnumeratedListBean<T> filterItems(Collection<String> items, boolean keep);
	
	/**
	 * Returns the value of the shortest length code in the codelist, or -1 if this codelist contains no codes.
	 * @return A positive integer or -1
	 */
	int getCodeMinLength();

	/**
	 * Returns the value of the longest length code in the codelist, or -1 if this codelist contains no codes.
	 * @return A positive integer or -1
	 */
	int getCodeMaxLength();
	
}
