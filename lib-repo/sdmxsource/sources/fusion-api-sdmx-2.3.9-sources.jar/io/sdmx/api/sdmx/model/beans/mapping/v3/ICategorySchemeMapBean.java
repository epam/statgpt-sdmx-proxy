package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;

/**
 * Represents an SDMX Category Scheme Map
 *
 * @author Matt Nelson
 */
public interface ICategorySchemeMapBean extends IItemSchemeMapBean<ICategoryMapBean> {

	@Override
	ICategorySchemeMapMutableBean getMutableInstance();
}
