package io.sdmx.api.sdmx.model.beans.transformation;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;

/**
 * Container for {@link INamePersonalisationBean}
 */
public interface INamePersonalisationSchemeBean extends IVtlSchemeBean<INamePersonalisationBean>, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<INamePersonalisationSchemeBean> getURN();
	
	@Override
	INamePersonalisationSchemeMutableBean getMutableInstance();
	
	@Override
	INamePersonalisationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
}
