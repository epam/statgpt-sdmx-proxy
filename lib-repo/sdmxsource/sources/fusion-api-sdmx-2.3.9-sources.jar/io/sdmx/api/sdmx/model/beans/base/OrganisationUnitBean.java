
package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents an SDMX OrganisationUnit
 * @author Matt Nelson
 *
 */
public interface OrganisationUnitBean extends OrganisationBean {
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<OrganisationUnitBean> getURN();
	
	/**
	 * Returns the parent organisation unit
	 * @return parent, or null if there is no parent
	 */
	String getParentUnit();
	
	/**
	 * Returns true if getParentUnit returns a not null object
	 * @return
	 */
	boolean hasParentUnit();
	
}
