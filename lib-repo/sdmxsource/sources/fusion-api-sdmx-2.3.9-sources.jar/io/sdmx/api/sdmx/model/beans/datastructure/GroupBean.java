
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;


/**
 * A Group is responsible for grouping a subset of the Dimensions in a Data Structure and giving the group an id.
 * <p/>
 * A group then contains its own unique id, which can then be referenced when reporting metadata attributes.
 * @author Matt Nelson
 */
public interface GroupBean extends IdentifiableBean, INoCrossReferencesBean {

	/**
	 * Returns the list of dimensions that this group is referencing - the list is in the order that the dimensions appear in the <code>KeyFamilyBean</code>.  
	 * The list is mutually exclusive with <code>getAttachmentConstraintRef()</code>, and will have a size of 1 or more only if <code>getAttachmentConstraintRef()</code>
	 * is null. If <code>getAttachmentConstraintRef()</code> is not null then this method will return an empty list.
	 * <p/>
	 * <strong>NOTE: </strong>The list is a copy so modifying the returned set will not be reflected in the GroupBean instance.
	 * 
	 * @return
	 */
	List<String> getDimensionRefs();
}
