
package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;


/**
 * Represents a SDMX OrganisationScheme
 * @author Matt Nelson
 *
 * @param <T>
 */
public interface OrganisationSchemeBean<T extends OrganisationBean> extends ItemSchemeBean<T>, INoCrossReferencesMaintainableBean {

	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@Override
	OrganisationSchemeMutableBean getMutableInstance();
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<? extends OrganisationSchemeBean<T>> getURN();
}
