
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;


@Deprecated
public interface CategoryMapMutableBean extends MutableBean {

	String getAlias();
	
	List<String> getSourceId();
	
	List<String> getTargetId();
	
	void setAlias(String catAlias);
	
	void setSourceId(List<String> sourceId);
	
	void setTargetId(List<String> targetId);
}
