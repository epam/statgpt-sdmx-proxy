package io.sdmx.api.sdmx.model.error;

import java.util.List;

import io.sdmx.api.sdmx.exception.CalculationErrorHandler;
import io.sdmx.api.sdmx.model.data.calculation.ValidationExpression;

/**
 * Represents an error resulting from a mathmatical calcualtion
 * 
 * @see CalculationErrorHandler
 * @see ValidationExpression
 */
public interface ICaculationError {

	/**
	 * Returns a sorted, immutable list of code ids that were used in the calculation 
	 * @return
	 */
	List<String> getInputCodeIds();

	/**
	 * Returns the short code to the observation that was used in the calculation, this will contain a wildcard (*) on the dimension that was
	 * used in the calcualtion, for example A:*:M:2008
	 * 
	 * Combining this with the input codes, we can see that A:UK:M:2008 and A:FR:M:2008 were the two input observations into this calculation
	 * 
	 * @return
	 */
	String getShortCode();
	
	/**
	 * Returns the equality operator, 
	 * +
	 * -
	 * <>
	 * >
	 * <
	 * <=
	 * >=
	 * 
	 * @return
	 */
	String getEquality();
	
	/**
	 * Returns the expression used, EUR=FR+DE+UK
	 * @return
	 */
	String getExpression();
	
	/**
	 * Returns the resolved values, 10=3+3+3
	 * @return
	 */
	String getResolvedValues();
	
	/**
	 * Returns the expected value which has been calculated based on the inputs, for example 9
	 * 
	 * If this is null, then there was most likley an exception thrown during the calulation and getException will reutrn the Throwable
	 * 
	 * @return
	 */
	Double getExpectedValue();
	
	/**
	 * Returns the reported value, 10
	 * @return
	 */
	Double getReportedValue();
	
	/**
	 * If there was an exception thrown during the calculation, then there will be no expectedvalue calcualted, the error is reported here
	 * 
	 * An example error is division by zero, which is uncalculable.  Typically this will be null.
	 * 
	 * @return {@link Throwable} can be null
	 */
	Throwable getException();
}
