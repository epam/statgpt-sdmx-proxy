
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean.SUBSCRIPTION_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


public interface SubscriptionMutableBean extends MaintainableMutableBean {

	StructureReferenceBean getOwner();

	void setOwner(StructureReferenceBean owner);

	List<String> getMailTo();

	void setMailTo(List<String> mailTo);

	List<String> getHTTPPostTo();

	void setHTTPPostTo(List<String> hTTPPostTo);

	List<StructureReferenceBean> getReferences();

	void addReference(StructureReferenceBean reference);
	
	void setReferences(List<StructureReferenceBean> references);

	SUBSCRIPTION_TYPE getSubscriptionType();

	void setSubscriptionType(SUBSCRIPTION_TYPE subscriptionType);
	
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	SubscriptionBean getImmutableInstance();
	
}
