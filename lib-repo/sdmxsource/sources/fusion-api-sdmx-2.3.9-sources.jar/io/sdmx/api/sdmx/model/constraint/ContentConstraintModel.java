package io.sdmx.api.sdmx.model.constraint;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Provides a model on top of a Content Constraint
 */
public interface ContentConstraintModel {
	
	/**
	 * @return not null, the {@link ContentConstraintBean} that this model was built from
	 */
	ContentConstraintBean getBuiltFrom();
	
	/**
	 * @return not null, unmodifiable map of component id to prefix removed from codelist for component due to the underlying constraint rule specifiying the component not include the prefix used by the extended codelist
	 */
	Map<String, String> getRemovePrefixes();

	/**
	 * Returns true if the constraint is defining restrictions based on the reported observation date, as oppose to the date of the submission (which is transaction validity).
	 * 
	 * E.g If this constraint has a Valid From data of 2007 and valid to of 2009, and an observation is reported for 2008 then this constraint would be applied.  However if this method returns false
	 * and it is operating on transaction validity, then the observation date of 2008 is ignored, and the actual date the data file was submitted is taken, 2018 for example, in which case this constraint is not
	 * applied
	 * @return
	 */
	boolean isBusinessValidity();

	/**
	 * Checks the validity of the Observation - note, this will not check the date of the Observation with the valid from/to date of this model, this check is
	 * expected to be performed independently 
	 * 
	 * @param key
	 * @return true if the observation is valid
	 */
	boolean isValidObservation(Observation obs);
	
	/**
	 *returns a list of components in errors, or an empty list if there are no validation errors
	 * @param obs
	 * @return
	 */
	List<String> validateObservation(Observation obs);
	void validateObservation(Observation obs, DataValidationEngineErrorHandler eh);
	
	
	/**
	 * Checks the validity of the key
	 * @param key
	 */
	boolean isValidKey(Keyable key);
	
	/**
	 * Validates the key and returns a list of errors, or an empty list if there are no validation errors
	 * @param key
	 * @return
	 */
	List<String> validateKey(Keyable key);
	void validateKey(Keyable key, DataValidationEngineErrorHandler eh);

	
	
	/**
	 * Returns true if the Key Value has been restricted due to a constraint
	 * @param kv
	 * @return
	 */
	boolean isConstrainedKeyValue(KeyValue kv);
	
	/**
	 * Returns true if the code has been constrained with respect to the dimension
	 * @param dimenisonId
	 * @param code
	 * @return
	 */
	boolean isConstrainedCode(String dimenisonId, String code);

	/**
	 * Returns true if the series short code is valid due to both included and excluded series constraints (not cube region)
	 * @param shortCode in format A:B:C, or wildcarded series 
	 * @see SeriesUtil.isWildCardSeries
	 * @return
	 */
	boolean isValidShortCode(String shortCode);
	
	/**
	 * Returns true if the series short code has been disallowed due to exclude series constraints  (not cube region)
	 * @param shortCode in format A:B:C, or wildcarded series 
	 * @see SeriesUtil.isWildCardSeries
	 * @return
	 */
	boolean isExplicitlyExcludedShortCode(String shortCode);
	
	SdmxPeriod getValidityPeriod();

	boolean hasValidityPeriod();
	
	/**
	 * Returns a new array of series restrictions, where each array represents a series key in the order defined by the DSD dimensions.  Wildcards are 
	 * denoted by null values.  Example  ["A",null,"UK"] would represent one wildcared series restriction.
	 * @return
	 */
	String[][] getAllowableSeries();

	/**
	 * Returns true if this model is restricting the values for the given dimension
	 * @param dimId
	 * @return
	 */
	@Deprecated //not used
	boolean isConstrainingDimensionValues(String dimId);

	/**
	 * Creates a partial Codelist based on the constraint information
	 * @param dimId the dimension the Codelist is for
	 * @param codelist the Codelist
	 * @return
	 */
	@Deprecated //not used
	EnumeratedListBean createPartialCodelist(String dimId, EnumeratedListBean<? extends EnumeratedItemBean> codelist);
	
	/**
	 * Filters all the dimension values based on the constrained codes
	 * @param dimId
	 * @param dimensionValues
	 */
	@Deprecated //not used
	void filterDimensionValues(String dimId, Set<String> dimensionValues);
	
	/**
	 * Returns a copy of the valid values for the given Component,  Valid values include values from coded and non-coded Component
	 * where this can be determined from both included cube regions, included series restrictions.
	 * <p/>
	 * If there are no valid values specified for the Component then null is returned, if there are no 
	 * valid values for the Component then an empty set is returned
	 * 
	 * <p>
	 * Modifications to the set will not modify the underlying valid values of the constraint model.
	 * 
	 * @param compId
	 * @return 
	 */
	Set<String> getValidValues(String compId);
	
	/**
	 * Returns a copy of the excluded values Set for the given dimension, modifications to the set will not modify
	 * the underlying valid values of the constraint model. Valid values include values from coded and non-coded dimensions
	 * where this can be determined, if there are no valid values specified for the dimension then null is returned, if there are no 
	 * excluded values for the dimension then an empty set is returned
	 * 
	 * @param compId
	 * @return
	 */
	Set<String> getExcludedValues(String compId);

}
