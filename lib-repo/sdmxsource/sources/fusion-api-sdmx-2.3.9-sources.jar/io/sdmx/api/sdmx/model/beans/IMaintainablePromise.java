package io.sdmx.api.sdmx.model.beans;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * A Promise to return a maintainable on request
 * @param <T>
 */
public interface IMaintainablePromise<T extends MaintainableBean> {

	/**
	 * @return not null, the URN to a maintainable structure
	 */
	IURNMaintainable<T> getURN();
	
	/**
	 * @return not null, the maintainable structure resolved
	 */
	T getMaintainable();
	
}
