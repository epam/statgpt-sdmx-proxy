
package io.sdmx.api.sdmx.model.mutable.process;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


public interface ProcessMutableBean extends MaintainableMutableBean {
	
	List<ProcessStepMutableBean> getProcessSteps();
	
	void setProcessSteps(List<ProcessStepMutableBean> processSteps);
	
	void addProcessStep(ProcessStepMutableBean processStep);
	
	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	ProcessBean getImmutableInstance();
	
}
