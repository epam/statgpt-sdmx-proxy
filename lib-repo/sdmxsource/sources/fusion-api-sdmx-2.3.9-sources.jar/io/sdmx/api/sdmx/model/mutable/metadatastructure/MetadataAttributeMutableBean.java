
package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;


public interface MetadataAttributeMutableBean extends ComponentMutableBean, IMetadataAttributeContainerMutableBean {

	TERTIARY_BOOL getPresentational(); 
	
	MetadataAttributeMutableBean setPresentational(TERTIARY_BOOL bool); 

}
