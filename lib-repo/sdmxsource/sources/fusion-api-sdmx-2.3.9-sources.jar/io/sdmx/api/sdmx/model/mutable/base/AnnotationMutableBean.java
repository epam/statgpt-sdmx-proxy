
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;


public interface AnnotationMutableBean extends MutableBean {

	String getId();

	void setId(String value);

	String getTitle();

	void setTitle(String title);

	String getType();

	void setType(String type);

	List<TextTypeWrapperMutableBean> getText();

	void addText(TextTypeWrapperMutableBean text);

	void addText(String locale, String text);

	void setText(List<TextTypeWrapperMutableBean> list);

	String getUri();

	void setUri(String url);

	boolean isDynamic();

	void setDynamic(boolean dynamic);
}
