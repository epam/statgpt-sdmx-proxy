
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;


public interface HierarchyMutableBean extends MaintainableMutableBean {
	
	HierarchyMutableBean stripItems(Date aDate);

	List<CodeRefMutableBean> getHierarchicalCodeBeans();
	
	void setHierarchicalCodeBeans(List<CodeRefMutableBean> codeRefs);
	
	void addHierarchicalCodeBean(CodeRefMutableBean codeRef);
	
	LevelMutableBean getChildLevel();
	
	void setChildLevel(LevelMutableBean level);
	
	/**
	 * If true this indicates that the hierarchy has formal levels. In this case, every code should have a level associated with it.
	 * 
	 * If false this does not have formal levels.  This hierarchy may still have levels, getLevel() may still return a value, the levels are not formal and the call to a code for its level may return null.
	 * 
	 */
	boolean isFormalLevels();
	
	
	void setFormalLevels(boolean bool);
	
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	HierarchyBean getImmutableInstance();
	
}
