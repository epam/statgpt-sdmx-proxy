package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;

/**
 * Represents an SDMX Concept Scheme Map
 *
 * @author Matt Nelson
 */
public interface IConceptSchemeMapBean extends IItemSchemeMapBean<IConceptMapBean> {

	@Override
	IConceptSchemeMapMutableBean getMutableInstance();
}
