package io.sdmx.api.sdmx.model.reverseengineer;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

/**
 * Defines column(s) in columnar data which can be used to define a coded dimension,
 * either Id or Name (or both) are required, if Id is missing it can be generated based on the ID_GENERATION_STRATEGY, but the name column is required
 * 
 * If the Ids do not conform to a valid SDMX code ID, then a Value List must be created
 */
public interface CodedDimensionCoumnDefinition extends ColumnDefinition {
	
	/**
	 * @return the coelist identifiers to use when generating the codelist
	 */
	IMaintainableRef getCodelistIdentifiers();
	
	/**
	 * @return zero indexed column to be used for the Id or null if not provided
	 */
	Integer getIdColumn();
	
	/**
	 * @return zero indexed column to be used for the name or null if not provided
	 */
	Map<Integer, String> getNameColumn();
	
	/**
	 * @return zero indexed column to be used for the description or null if not provided
	 */
	Map<Integer, String> getDescriptionColumn();
	
	/**
	 * @return the id generation strategey, mutually exclusive with the Id Column
	 */
	ID_GENERATION_STRATEGY getIdGenerationStrategy();
	
	
	enum ID_GENERATION_STRATEGY {
		AUTO_INCREMENT_NUMERICAL,
		AUTO_INCREMENT_ALPHA,
		FIRST_LETTER_ONLY,
		FIRST_TWO_LETTERS,
		FIRST_THREE_LETTERS,
		FIRST_OF_EACH_WORD
	}

}
