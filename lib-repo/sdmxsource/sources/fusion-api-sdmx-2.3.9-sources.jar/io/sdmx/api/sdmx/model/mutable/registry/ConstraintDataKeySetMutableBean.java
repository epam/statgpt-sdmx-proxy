
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;


public interface ConstraintDataKeySetMutableBean extends MutableBean {

	List<ConstrainedDataKeyMutableBean> getConstrainedDataKeys();
	
	void setConstrainedDataKeys(List<ConstrainedDataKeyMutableBean> keys);
	
	void addConstrainedDataKey(ConstrainedDataKeyMutableBean key);

}
