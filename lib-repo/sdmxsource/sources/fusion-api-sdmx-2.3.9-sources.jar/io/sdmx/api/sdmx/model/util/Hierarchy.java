package io.sdmx.api.sdmx.model.util;



public interface Hierarchy<T> extends HierarchyNode<T> {

	
}
