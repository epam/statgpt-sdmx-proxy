package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

import java.util.List;

public interface IRulesetBean extends ItemBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IRulesetBean> getURN();
	
	/**
	 * A VTL statement for the definition of a reulset.  This must conform to the syntax
	 * of the VTL definition language 
	 * @return not null
	 */
	String getRulesetDefinition();
	
	/**
	 * The VTL type of the ruleset.  In VTL 2.0 this is datapoint or hierarchical
	 * @return not null
	 */
	String getRulesetType();
	
	/**
	 * This model artefact on which the the ruleset is defined. In VTL 2.0 this is the value domain or
	 * variable
	 * @return not null
	 */
	String getRulesetScope();

	/**
	 * returns an immutable list of full and/or partial references from within the VTL statement. As VTL can reference a structure by
	 * only its ID a IURN contains a minimum of a maintainable ID and a Structure type. As it is not possible at construction
	 * time to determine if the VTL statement is referencing an SDMX structure or another VTL variable, a IURN which contains only an ID
	 * is only an indication that it may be a SDMX structure reference. If the IURN contains an AgencyID or Version then this should
	 * be interpreted as an unambiguous reference to an SDMX structure.
	 *
	 * @return List<IURN> of referenced artifacts
	 */
	List<IURN<?>> getReferencedArtifacts();
}
