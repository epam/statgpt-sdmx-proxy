
package io.sdmx.api.sdmx.model.format;

/**
 * Marker interface, used to describe a structure query format, the implementation is expected to offer more information describing the format
 */
public interface StructureQueryFormat<T> {

}
