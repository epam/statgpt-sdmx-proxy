package io.sdmx.api.sdmx.model.mutable.mapping.v3;

/**
 *  <p>A specialisation of {@link ITimeComponentMapMutableBean} used to describe a string representation of time, and how this maps to SDMX Time Periods.</p>
 *  <br/>  
 *  <p>Describes the patterns for each supported time representation e.g. 2002 31 12 could be expressed as YYYY DD MM<p/>
 */
public interface ITimePatternMapMutableBean extends ITimeComponentMapMutableBean {

	/**
	 * 
	 * @return immutable map of patterns to output frequency Id, or pattern to null if the output frequency is obtained from the output frequency in the 
	 * {@link ITimeComponentMapMutableBean}
	 */
	String getPattern();
	ITimePatternMapMutableBean setPattern(String patterns);
	
	
	String getLocale();
	ITimePatternMapMutableBean setLocale(String str);
	
}
