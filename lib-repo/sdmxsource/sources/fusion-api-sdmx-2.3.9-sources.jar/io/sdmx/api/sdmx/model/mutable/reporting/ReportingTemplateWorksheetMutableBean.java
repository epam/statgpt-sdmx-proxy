package io.sdmx.api.sdmx.model.mutable.reporting;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;

/**
 * Describes a report template worksheet
 */
public interface ReportingTemplateWorksheetMutableBean extends IdentifiableMutableBean {
	
	
	/**
	 * @return an optional Dimension Id, if present this worksheet will be used as a template for all unique dimension values of the slice, i.e if SliceBy is FREQ then there will be a worksheet for each Frequency based on this template
	 */
	String getSliceBy();
	void setSliceBy(String sliceBy);
	
	/**
	 * The constraint that this worksheet is for
	 * @return
	 */
	StructureReferenceBean getDataflow();
	void setDataflow(StructureReferenceBean sRef);
	

	Integer getColMaxWidth();
	void setColMaxWidth(Integer width);
	
	/**
	 * The dimensions to be used in the table columns
	 * @return
	 */
	List<String> getTableCols();
	void setTableCols(List<String> cols);

	/**
	 * The dimensions to be used in the table rows
	 * @return
	 */
	List<String> getTableRows();
	void setTableRows(List<String> cols);
	
	/**
	 * The fixed value for each attribute
	 * @param dimId
	 * @return
	 */
	Map<String, String> getFixedAttributeValues();
	void setFixedAttributeValues(Map<String, String> map);
	
	/**
	 * Returns the attributes that have variable values and are included in the report alongside the observation cells
	 * @return
	 */
	Set<String> getVariableAttributes();
	void setVariableAttributes(Set<String> attributes);
	
	/**
	 * Returns the dimensions that can be reported by the user as a single value on the worksheet, separately from the main table
	 * @return
	 */
	Set<String> getVariableDimensions();
	void setVariableDimensions(Set<String> dimensions);
	
	/**
	 * @return  a set of Dimensions ids to exclude from the output excel report if the dimension has a fixed value
	 */
	Set<String> getExcludeDimensions();
	void setExcludeDimensions(Set<String> dimensions);
	
	/**
	 * Returns the attributes that have variable values and are included in a separate worksheet
	 * @return
	 */
	Set<String> getWorksheetAttributes();
	void setWorksheetAttributes(Set<String> attributes);
	
	/**
	 * Returns the attributes that have variable values and are to be built into a separate table below the main observation table
	 * @return
	 */
	Set<String> getSeparateAttributes();
	void setSeparateAttributes(Set<String> attributes);

	/**
	 * The id of the attribute to be used as colour on the observation, or null if none is defined
	 * @return
	 */
	ReportingTemplateColourMutableBean getColourAttribute();
	void setColourAttribute(ReportingTemplateColourMutableBean attribute);
	
	/**
	 * sets the link of dimension to how to display - default is by name if unspecfed 
	 * @return
	 */
	Map<String, TEXT_DISPLAY> getTextDisplay();
	void setTextDisplay(Map<String, TEXT_DISPLAY>  display);
	void addTextDisplay(String componentId, TEXT_DISPLAY display);
	
	Set<ReportingTemplateConditionalAttributeMutableBean> getConditionalAttributes();
	void setConditionalAttributes(Set<ReportingTemplateConditionalAttributeMutableBean> attrs);
	
	
	/**
	 * Returns a map of dimension ids to hierarchical codelist
	 * @return
	 */
	Map<String, StructureReferenceBean> getHierarhcyReferences();
	void setHierarhcyReferences(Map<String, StructureReferenceBean> hRefs);

	/**
	 * Returns a set of dimension ids that have an implicit hierarchy
	 * @return
	 */
	Set<String> getImplicitHierarchices();
	void setImplicitHierarchices(Set<String> hierarchies);
	
	/**
	 * If not null, specifies the number of decimal places to round any numerical data to
	 * @return
	 */
	Integer getRoundDecimals();
	void setRoundDecimals(Integer decimals);
	
}
