package io.sdmx.api.sdmx.model.beans.transformation;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;

/**
 * A container of {@link IRulesetBean}
 */
public interface IRulesetSchemeBean extends IVtlSchemeBean<IRulesetBean> {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IRulesetSchemeBean> getURN();
	
	/**
	 * @return optional reference to a VTL mapping scheme which defines aliases for given SDMX artefacts that are used in the rulesets.  Rulesets 
	 * defined on the value domains reference Codelists or Concept Schemes (the latter in VTL are considered as the Value Domains of the variables corresponding to the 
	 * SDMX Measure Dimensions). The rulesets defined on varaibles reference Concepts (for which a definite representation is assumed).  There fore
	 * a ruleset should only refer to Codelists, Concept Schemes, an Concepts
	 */
	ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef();
	
	@Override
	IRulesetSchemeMutableBean getMutableInstance();
	
	@Override
	IRulesetSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
}
