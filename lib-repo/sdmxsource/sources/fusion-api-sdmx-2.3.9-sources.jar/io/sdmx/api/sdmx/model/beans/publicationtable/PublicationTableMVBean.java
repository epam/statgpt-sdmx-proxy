package io.sdmx.api.sdmx.model.beans.publicationtable;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * <p>When an observation contains an empty value, it can be replaced with a missing value text, e.g. NaN, mv, nap.  The value
 * used for a missing value may be based on the value of another component of the Observation, for example the reported OBS_STATUS value
 * may indicate what missing value text to display, with M=mv, and L=nap.  If there is such a mapping, it is maintained in a Representation Map
 * which provides the rules</p>
 */
public interface PublicationTableMVBean extends SDMXBean {
	
	/**
	 * @return the component whose reported value will be used to determine the missing value
	 */
	String getComponentId();
	
	/**
	 * @return the default missing value to use if no observation exists for the cell at all (nothing to map)
	 */
	String getDefaultMissingValue();
	
	/**
	 * @return optional reference to a mapping relationship for missing values
	 */
	ICrossReferenceBean<IRepresentationMapBean> getMissingValueMapping();
	
}
