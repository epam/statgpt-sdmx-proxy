package io.sdmx.api.sdmx.model.beans.mapping;


/**
 * Represents an SDMX Organisation Scheme Map
 * @author Matt Nelson
 * @deprecated use mapping.v3
 */
@Deprecated
public interface OrganisationSchemeMapBean extends ItemSchemeMapBean<ItemMapBean> {

}
