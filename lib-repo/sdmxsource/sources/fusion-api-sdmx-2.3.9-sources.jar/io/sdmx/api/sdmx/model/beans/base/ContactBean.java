package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;

/**
 * Represents a contact (individual or organisation)
 */
public interface ContactBean extends INoCrossReferencesBean {
	
	/**
	 * Returns the id of the contact
	 * @return the id, or null if there is no id
	 */
	String getId();
	
	/**
	 * Returns the names of the contact
	 * @return list of names, or an empty list if none exist
	 */
	List<TextTypeWrapper> getName();

	/**
	 * Returns the roles of the contact
	 * @return list of roles, or an empty list if none exist
	 */
	List<TextTypeWrapper> getRole();

	/**
	 * Returns the departments of the contact
	 * @return list of departments, or an empty list if none exist
	 */
	List<TextTypeWrapper> getDepartments();
	
	/**
	 * Returns the email of the contact
	 * @return list of email, or an empty list if none exist
	 */
	List<String> getEmail();

	/**
	 * Returns the fax of the contact
	 * @return list of fax, or an empty list if none exist
	 */
	List<String> getFax();

	/**
	 * Returns the telephone of the contact
	 * @return list of telephone, or an empty list if none exist
	 */
	List<String> getTelephone();
	/**
	 * Returns the uris of the contact
	 * @return list of uris, or an empty list if none exist
	 */
	List<String> getUri();

	/**
	 * Returns the x400 of the contact
	 * @return list of emails, or an empty list if none exist
	 */
	List<String> getX400();
}
