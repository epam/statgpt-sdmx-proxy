package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.constants.CONDITION;

/**
 * Defines which value an attribute should take when the conditions defined in this object are met
 */
public interface ConditionalAttributeMappingBeanMutableBean extends MutableBean {
	
	/**
	 * The value the attribute should take
	 * @return
	 */
	String getAttributeValue();
	void setAttributeValue(String attVal);
	
	/**
	 * The condition that must be met
	 * @return
	 */
	CONDITION getCondition();
	void setCondition(CONDITION condition);
	
	/**
	 * Additional condition rules, only applicable for certain conditions 
	 * @return
	 */
	String getConditionDetail();
	void setConditionDetail(String detail);
	
}
