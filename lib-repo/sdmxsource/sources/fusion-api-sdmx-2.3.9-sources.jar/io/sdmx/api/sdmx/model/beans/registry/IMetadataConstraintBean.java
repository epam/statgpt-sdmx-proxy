package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;

/**
 * MetadataConstraint defines the structure of a metadata constraint.
 * A metadata constraint can specify allowed attribute values for metadata
 * described by the constrained artefact.
 */
public interface IMetadataConstraintBean extends MaintainableBean {

	@Override
	IMetadataConstraintMutableBean getMutableInstance();

	List<IDirectCrossReferenceBean<?>> getAttachments();

	List<KeyValues> getIncludedTarget();

	List<KeyValues> getExcludedTarget();

	ReleaseCalendarBean getReleaseCalendar();
}
