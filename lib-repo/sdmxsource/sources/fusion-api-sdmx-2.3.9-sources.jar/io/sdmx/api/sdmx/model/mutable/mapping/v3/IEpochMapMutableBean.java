package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.EPOCH;

/**
 * <p>A specialisation of {@link ITimeComponentMapMutableBean} used to describe a numerical representation of time, and how this maps to SDMX Time Periods.</p>
 * <br/>
 * <p>For example 1605719750 is 2020-11-18 if the Epoch is milliseconds and the base period is 1970 with output frequency as daily </p>
 */
public interface IEpochMapMutableBean extends ITimeComponentMapMutableBean {
	
	/**
	 * @return non null property, the start period where the first interval starts, for example UNIX Time would return 1970
	 */
	String getBasePeriod();
	IEpochMapMutableBean setBasePeriod(String period);
	
	/**
	 * @return non null property, the duration of each interval, for example UNIX time would return MILLISECONDS
	 */
	EPOCH getEpochInterval();
	IEpochMapMutableBean setEpochInterval(EPOCH interval);
	
}
