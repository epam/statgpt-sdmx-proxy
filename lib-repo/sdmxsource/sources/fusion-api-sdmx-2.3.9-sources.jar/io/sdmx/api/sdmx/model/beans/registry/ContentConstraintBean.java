
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;

public interface ContentConstraintBean extends ConstraintBean, INoCrossReferencesBean {
	public static String WILDCARD_CODE = "*";
	
	/**
	 * Returns true if the constraint is defining restrictions based on the reported observation date, as oppose to the date of the submission (which is transaction validity).
	 * 
	 * E.g If this constraint has a Valid From data of 2007 and valid to of 2009, and an observation is reported for 2008 then this constraint would be applied.  However if this method returns false
	 * and it is operating on transaction validity, then the observation date of 2008 is ignored, and the actual date the data file was submitted is taken, 2018 for example, in which case this constraint is not
	 * applied
	 * @return
	 */
	boolean isBusinessValidity();
	
	/**
	 * Returns true if this constraint is defining the actual data present for this constraint, false if it is defining the
	 * allowed data
	 * @return
	 */
	boolean isDefiningActualDataPresent();
	
	/**
	 * Returns true if this is a Cube Region Constraint - false if it is a Series Constraint
	 * @return
	 */
	boolean isCubeRegion();
	
	/**
	 * Returns true if the given component is being constrained by this constraint
	 * @param componentId
	 * @return
	 */
	boolean isConstrainingComponent(String componentId);
	
	/**
	 * Returns the metadata target region, or null if this is undefined.
	 * @return
	 */
	MetadataTargetRegionBean getMetadataTargetRegion();
	
	@Override
	ConstraintAttachmentBean getConstraintAttachment();
	
	/**
	 * Returns the series keys that this constraint defines at ones that either have data, or are allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	@Override
	ConstraintDataKeySetBean getIncludedSeriesKeys();
	
	
	/**
	 * Returns the series keys that this constraint defines at ones that either do not have data, or are not allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	@Override
	ConstraintDataKeySetBean getExcludedSeriesKeys();
	
	
	/**
	 * Returns a CubeRegion where the Keys and Attributes are defining data that is present or allowed (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	CubeRegionBean getIncludedCubeRegion();
	
	/**
	 * Returns a CubeRegion where the Keys and Attributes are defining data is is not present or disallowed (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	CubeRegionBean getExcludedCubeRegion();
	
	/**
	 * Returns true if there is an included series
	 * @return
	 */
	boolean hasIncludedSeries();
	
	/**
	 * Returns true if there is an excluded series
	 * @return
	 */
	boolean hasExcludedSeries();
	
	/**
	 * Returns true if there is an excluded cube region
	 * @return
	 */
	boolean hasExcludedCubeRegion();
	
	/**
	 * Returns true if there is an included cube region
	 * @return
	 */
	boolean hasIncludedCubeRegion();
	
	
	/**
	 * Returns the set of key values, taken from both the included cube region and excluded cube region
	 * @return
	 */
	Set<KeyValues> getRestrictedComponents();
	
	@Deprecated //Not used in SDMX 3.0
	ReferencePeriodBean getReferencePeriod();
	
	ReleaseCalendarBean getReleaseCalendar();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ContentConstraintMutableBean getMutableInstance();
	
}
