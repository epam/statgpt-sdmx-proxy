
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;


public interface MeasureListMutableBean extends IdentifiableMutableBean {

	/**
	 * Supports measures in addition to the primary measure
	 * @return
	 */
	List<MeasureMutableBean> getMeasures();
	void setMeasures(List<MeasureMutableBean> measures);
	void addMeasures(MeasureMutableBean measure);
	
	
}
