package io.sdmx.api.sdmx.model.beans.publicationtable;

/** 
 *  Represents the Head cell of a table column or row, the head cell has a syntax that can be parsed into properties such as 
 *  level, anchor, and loop
 */
public interface IHeadLabel {

	/**
	 * Anchor a row so it is always shown even if all values are null
	 */
	public enum ANCHOR {
		NO_ANCHOR,  //do not show row if null
		ANCHOR_ROW,  //show row if null
		ANCHOR_FOLLLOWING,  //show all child and sibling rows if null
		ANCHOR_CHILDREN  //show this and child rows if null
	}

	/**
	 * @return not null - the anchor to apply to the row
	 */
	ANCHOR getAnchor();

	/**
	 * @return nullable - if the row is set up to be a loop over a dimension this will return the loop details
	 */
	ILoop getLoop();

	/**
	 * @return null if getLoop is no null, otherwise will return the label for the heading
	 */
	String getLabel();

	/**
	 * @return the level of the row starting at 1 (higher numbers indicate it is a child row as it is an extra level deep in the hierarchy)
	 */
	int getLevel();
}
