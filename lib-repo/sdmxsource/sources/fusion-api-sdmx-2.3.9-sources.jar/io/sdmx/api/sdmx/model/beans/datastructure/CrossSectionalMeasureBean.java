
package io.sdmx.api.sdmx.model.beans.datastructure;

import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;

/**
 * Represents a SDMX Cross Sectional Measure
 */
public interface CrossSectionalMeasureBean extends IDataStructureComponentBean {

	String getMeasureDimension();
	
	String getCode();
	
}
