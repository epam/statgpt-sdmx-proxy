package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;

/**
 * Represents a SDMX v3.0 representation map, where source and target can be one of the following:
 * <ul>
 *  <li>Codelist</li>
 *  <li>Valuelist</li>
 *  <li>Free Text</li>
 * </ul>
 * <p/>
 * The source and target can be mixed types allowing for Codelists to map to free text for example.
 * <p/>
 * SDMX v2.1 and lower only supports Codelist to Codelist mapping (via a structure called the CodelistMap)
 */
public interface IRepresentationMapBean extends MaintainableBean {

	public static final String FR_MAPPING_NOTE = "FR_MAPPING_NOTE";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IRepresentationMapBean> getURN();

	/**
	 * Properties as reported in the Diff
	 */
	enum Properties {
		SOURCE_REFERENCES("Source References"),
		TARGET_REFERENCES("Target References"),
		MAPPED_VALUES("Mapped Values");
		
		private String property;
		
		private Properties(String property) {
			this.property = property;
		}

		public String getProperty() {
			return property;
		}
	}
	
	/**
	 * @return a list of Cross References to either a Codelist or Valuelist, a null response indicates that the source is free text
	 */
	List<IRepresentationMapRefBean> getSourceRef();
	
	/**
	 * @return a list of Cross References to either a Codelist or Valuelist, a null response indicates that the target is free text
	 */
	List<IRepresentationMapRefBean> getTargetRef();
	
	/**
	 * @return immutable list of mapped values, or an empty list if no mapped values exist
	 */
	List<IMappedRelationshipBean> getMappedValues();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	IRepresentationMapMutableBean getMutableInstance();
	
}
