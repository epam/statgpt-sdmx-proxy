
package io.sdmx.api.sdmx.model.beans.conceptscheme;

import io.sdmx.api.sdmx.model.beans.base.ConceptBaseBean;
import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.IRepresentedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;

/**
 * Represents an SDMX Concept.
 * @author Matt Nelson
 *
 */
public interface ConceptBean extends HierarchicalItemBean<ConceptBean>, ConceptBaseBean, ValidityPeriodBean, IRepresentedBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<ConceptBean> getURN();
	
	/**
	 * Returns the parent concept Id.
	 * @return null if no parent concept is defined
	 */
	String getParentConcept();
	
	/**
	 * Returns the parent concept agency. 
	 * @return null if no parent agency is defined
	 */
	String getParentAgency();
	
	/**
	 * Returns the ISO concept reference for this concept.
	 * @return null if no ISO concept reference is defined
	 */
	ICrossReferenceBean<ConceptBean> getIsoConceptReference();
	
	/**
	 * Recurses up the parent tree to find the maintainable parent.  If this is a maintainable then 
	 * it will return a reference to itself
	 * @return
	 */
	@Override
	ConceptSchemeBean getMaintainableParent();
	
}
