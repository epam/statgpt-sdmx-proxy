
package io.sdmx.api.sdmx.model.beans.base;

import java.net.URI;
import java.util.List;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;


/**
 * An Identifiable Bean describes a Bean which contains a unique identifier (urn) and can therefore
 * be identified uniquely.  
 * 
 * @author Matt Nelson
 *
 */
public interface IdentifiableBean extends AnnotableBean, SdmxStructureBean {

	/**
	 * Returns the id for this component, this is a mandatory field and will never be null.
	 * @return
	 */
	String getId();
	
	/**
	 * Returns a period separated id of this identifiable, starting from the non-maintainable top-level ancestor to this identifiable.
	 * <p/>
	 * For example, if this is "Category A" as a child of "Category AA", then this method will return AA.A (note the category scheme id is not present in this identifier).
	 * <p/>
	 * Returns null if this is a maintainable bean.
	 * @param includeDifferentTypes if true will recurse all the way back up the tree regardless of ancestor types, up to the maintainable level.
	 * If false, will stop at the first occurrence of an ancestor who's getStructureType() is not equal to this.getStructureType().
	 * @return
	 */
	String getFullIdPath(boolean includeDifferentTypes);
	
	/**
	 * The URN is unique and is a computable generated value based on the properties of this structure such as structure type, agency, ID, version 
	 * 
	 * @return not null absolute URN of this structure
	 */
	IURNAbsolute<?> getURN();
	
	/**
	 * @return not null the URN for this structure as a string
	 */
	String getUrn();
	
	/**
	 * Returns a shortened form of the URN (everything after the =)
	 * example: METATECH:OECD_AGRIC_OUTLOOK(1.0)
	 * @return
	 */
	default String getShortURN() {
		return getURN().getShortURN();
	}
	
	/**
	 * @return the 'class' of structure this is
	 */
	default ISDMXStructureType<?, ?> getStructureClass() {
		return getURN().getStructureType();
	}
	
	/**
	 * Returns the URI for this component, returns null if there is no URI.
	 * <p/>
	 * URI describes where additional information can be found for this component. This is guaranteed to return
	 * a value if the structure is a <code>MaintainableBean</code> and <code>isExternalReference</code> is true.
	 * @return
	 */
	URI getUri();
	
	/**
	 * @return not null, a mutable copy of the URN
	 */
	default StructureReferenceBean asReference() {
		return getURN().asMutable();
	}
	
	/**
	 * Returns a list of all the underlying text types for this identifiable (does not recurse down to children).
	 * <p/>
	 * Returns an empty list if there are no text types for this identifiable.
	 * @return
	 */
	List<TextTypeWrapper> getAllTextTypes();
	
	/**
	 * @return not null, optional list of links to other objects
	 */
	List<ILinkBean> getLinks();
	
}
