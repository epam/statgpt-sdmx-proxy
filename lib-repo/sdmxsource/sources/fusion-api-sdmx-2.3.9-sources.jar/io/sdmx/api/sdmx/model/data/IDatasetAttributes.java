package io.sdmx.api.sdmx.model.data;


/**
 * A container for all Attributes reported at the Dataset level
 */
public interface IDatasetAttributes extends Attributable {
	
}
