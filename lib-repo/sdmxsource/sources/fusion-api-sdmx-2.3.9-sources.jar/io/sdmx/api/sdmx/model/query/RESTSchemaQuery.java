
package io.sdmx.api.sdmx.model.query;

import java.io.Serializable;
import java.util.Date;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;

/**
 * Defines a schema query that contains information defined by the RESTful API
 */
public interface RESTSchemaQuery extends Serializable {

	/**
	 * Returns the reference to the structure the query is for, this can be:
	 * <ul>
	 *  <li>Data Structure</li>
	 *  <li>Dataflow</li>
	 *  <li>Provision Agreement</li>
	 * @return
	 */
	IURNSingle<? extends IDSDRelatedBean> getReference();

	/**
	 * Returns the dimension at observation
	 * @return
	 */
	String getDimAtObs();

	/**
	 * Returns the valid to date of the query - this can be null if omitted from the query
	 * @return
	 */
	Date getValidFrom();
	
	/**
	 * Returns the valid to date of the query - this can be null if omitted from the query
	 * @return
	 */
	Date getValidTo();
	
	/**
	 * @return nullable, if not null the metadata must be returned as it was for this timestamp
	 */
	SdmxDate getAsOf();
	
	/**
	 * @return true if the response is to be 'pretty printed'
	 */
	boolean prettyPrint();
}
