
package io.sdmx.api.sdmx.model.superbeans.datastructure;

import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;

/**
 * A dimension is one component of a key that together with other dimensions of the key
 * uniquely identify the observation.
 * @author Matt Nelson
 */
public interface DimensionSuperBean extends ComponentSuperBean<DimensionBean> {


	/**
	 * Replace, add, or remove the codelist in this component
	 * @param cl the codelist to replace with, null to remove the codelist
	 * @return
	 */
	DimensionSuperBean replaceCodelist(CodelistBean cl);
}