
package io.sdmx.api.sdmx.model.beans.base;

import java.net.URL;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import io.sdmx.api.io.IDeferrable;
import io.sdmx.api.io.IDeferred;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanFuzzy;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


/**
 * A MaintainableBean is a top level bean (contains no parents), it has a reference to an Agency <code>getAgencyId()</code>
 * and has a <strong>mandatory id</strong> and a <strong>mandatory version</strong>, defaulting to 1.0.
 * <p/>
 * The unique identifier of a maintainable artefact is the AgencyId, Id and Version.
 * <p/>
 * Each maintainable artifact can create a mutable representation of itself (<code>getMutableInstance()</code>)
 * and can also return a stub representation of itself <code>getStub()</code>.
 * @author Matt Nelson
 */
public interface MaintainableBean extends VersionableBean, IDeferrable<MaintainableBean> {
    
    /**
     * @return checksum calculated from the content of the bean
     */
    String getChecksum();
    
    /**
     * @return not null, the properties for this bean
     */
    IMaintainableProperties getMaintainableProperties();
    
    /**
     * @return the core properties that are required to build a {@link IDeferred} bean of this type
     */
    @Override
    IDeferredBeanDefinition getDeferredDefinition();
    
    /**
     * @return a deferred implementation of itself, storing the contents of itself in serialised form on the disk
     */
    IMaintainableBeanDeferred<?> toDeferred();
    
    /**
     * @return a deferred implementation of itself, constructed using the loader, which must return the full version on demand
     * @param loader - required, this must return the full maintainable on demand
     */
    IMaintainableBeanDeferred<?> toDeferred(IDeferredLoader<MaintainableBean> loader);
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<?> getURN();
	
	/**
	 * @return not null, immutable. A set of both wildcard and absolute cross references that this MaintainableBean (or any child SdmxBean) have
	 */
	Set<IDirectCrossReferenceBean<?>> getCrossReferences();
	
	/**
	 * @return not null, immutable. A set of fuzzy cross references that this MaintainableBean (or any child SdmxBean) have
	 */
	Set<ICrossReferenceBeanFuzzy> getCrossReferencesFuzzy();
	
	default IdentifiableBean getIdentifiableComposite(IURNSingle<?> urn) {
		if(urn == null) {
			return null;
		}
		if(urn.isMaintainableReference()) {
			return this;
		}
		for(IdentifiableBean ident :getIdentifiableComposites()) {
			if(urn.isMatch(ident)) {
				return ident;
			}
		}
		return null;
	}
	
	/**
	 * Filters the composites by URN
	 * @param urn
	 * @return all matches, not null, mutable
	 */
	default Set<IdentifiableBean> filter(IURN<?> urn) {
		Set<IdentifiableBean> returnSet = new HashSet<>();
		for(IdentifiableBean ident : getIdentifiableComposites()) {
			if(urn.isMatch(ident)) {
				returnSet.add(ident);
			}
		}
		return returnSet;
	}
	
	/**
	 * @return the 'class' of structure this is
	 */
	default IMaintainableStructureType<?> getMaintainableClass() {
		return getURN().getStructureType();
	}
	
	
	/**
	 * @param schemaVersion
	 * @return false if this maintainable is not compatible with the given schema version
	 */
	default boolean isCompatible(SDMX_SCHEMA schemaVersion) {
		return true;
	}
	
	/**
	 * Returns the default standard that this maintainable conforms to i.e SDMX
	 * @return
	 */
	IMetadataStandard getDefaultStandard();
	
	/**
	 * Returns an Id unique to this specific instance.  This is a GUID generated on construction, so no two MaintainableBean wil share the same internalId.
	 * 
	 * @return
	 */
	String getInternalId();
	
	/**
	 * Returns the agency id that is responsible for maintaining this maintainable artifact
	 * @return
	 */
    String getAgencyId();
	
	/**
	 * @return true if the version for this structure type is fixed to 1.0
	 */
	default boolean isFixedVersion() {
		return getStructureClass().hasFixedVersion();
	}
	
	/**
	 * Returns whether this structure is marked as final, meaning the structure can not be modified
	 * @return
	 */
	boolean isFinal();
	
	/**
	 * Returns whether this maintainable artifact is externally referenced
	 * @return
	 */
	boolean isExternalReference();
	
	/**
	 * Returns true if this is a stub
	 * @return
	 */
	boolean isStub();
	
	/**
	 * Reserved for item schemes, but exposed on the {@link MaintainableBean} API to save from downcasting, a partial
	 * ItemScheme has had 1 or more Items removed - typically due to a structure query which only requests specific items in the response
	 */
	default boolean isPartial() {
		return false;
	}
	
	/**
	 * Performs a diffReport
	 * @param maint
	 * @return
	 */
	DiffReport diff(MaintainableBean maint);
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Adds a annotations to a copy of this bean, and returns the copy
	 * @param ref a map of structure references to a set of annotations to add
	 * @return
	 */
	MaintainableBean addAnnotations(Map<IURNAbsolute<?>, Set<AnnotationMutableBean>> annotations);
	
	/**
	 * Copies all dynamic Annotations from the passed in maintainble and sub identifiables to this maintainable and its identifiable composites
	 * @param maint the maintinable to copy from
	 * @return {@link MaintainableBean} this will be either a new maintainable if a change was made, or the same instance if no dynamic attributes required copying
	 */
	MaintainableBean copyDynamicAnnotations(MaintainableBean maint);
	
	/**
	 * @return identifiable composite by fully qualified id, i.e. if looking for a specific Category in a Category Scheme include the full path where '.' is used to
	 * separare the ids of parent to child (do not include the maintainable id).  Example CATA.CHILD_CATB
	 */
	<T extends IdentifiableBean> T getCompositeById(Class<T> type, String qualifiedId);
	
	/**
	 * Lazy loaded property that is loaded when addAnnotations method is called.
	 * @return true if any of the annotations on this maintainable are dynamic
	 */
	boolean hasDynamicAnnotations();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	MaintainableMutableBean getMutableInstance();
	
	/**
	 * The serviceURL attribute indicates the URL of an SDMX SOAP web service from which the details of the object can be retrieved.
	 * Note that this can be a registry or and SDMX structural metadata repository,
	 * as they both implement that same web service interface.
	 * Optional.
	 * @return
	 * @since v2.1 SDMX Schema
	 */
	URL getServiceURL();
	
	/**
	 * The structureURL attribute indicates the URL of a SDMX-ML structure message
	 * (in the same version as the source document) in which the externally referenced object is contained.
	 * Note that this my be a URL of an SDMX RESTful web service which will return the referenced object.
	 * Optional.
	 * @return
	 * @since v2.1 SDMX Schema
	 */
	URL getStructureURL();
	
	/**
	 * Returns a sorted set of available locales for this maintainable bean
	 * @return
	 */
	SortedSet<String> getLocales();
	
}
