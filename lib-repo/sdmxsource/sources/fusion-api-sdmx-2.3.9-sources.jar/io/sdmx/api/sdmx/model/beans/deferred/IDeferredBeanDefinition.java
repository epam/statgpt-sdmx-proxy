package io.sdmx.api.sdmx.model.beans.deferred;

import java.net.URL;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.io.IDeferredDefinition;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Contains the details of a {@link MaintainableBean} that can be used to reload the bean
 * @param <T>
 */
public interface IDeferredBeanDefinition extends IDeferredDefinition<MaintainableBean> {
    
    /**
     * @return URN of the deferred bean
     */
    IURNMaintainable<?> getUrn();
    
    /**
     * @return not null, checksum of the original bean
     */
    String getChecksum();
    
    /**
     * @return not null, unmodifiable list of annotations
     */
    List<AnnotationBean> getAnnotations();
    
    /**
     * @return optional, structure URL for the maintainable
     */
    URL getStructureURL();
    
    /**
     * @return optional, service URL for the maintainable
     */
    URL getServiceURL();
    
    /**
     * @return optional, validity period for the maintainable
     */
    SdmxPeriod getValidityPeriod();
    
    /**
     * @return not null, optional list of links to other objects
     */
    List<ILinkBean> getLinks();
    
    /**
     * @return not null, unmodifiable map of names (lang to value)
     */
    Map<String, String> getNames();
    
    /**
     * @return not null, unmodifiable map of descriptions (lang to value)
     */
    Map<String, String> getDescriptions();
    
    /**
     * @return not null, unmodifiable map of properties
     */
    Map<String, String> getProperties();
    
    default Boolean getBooleanProperty(String prop) {
        if(!getProperties().containsKey(prop)) {
            return null;
        }
        return Boolean.valueOf(getProperties().get(prop));
    }
    
}
