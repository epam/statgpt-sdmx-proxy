package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;

/**
 * @deprecated use  {@link IStructureMapMutableBean} {@link IRepresentationMapMutableBean} 
 */
public interface StructureSetMutableBean extends MaintainableMutableBean {

	RelatedStructuresMutableBean getRelatedStructures();

	void addRelatedStructure(StructureReferenceBean sRef);

	List<StructureMapMutableBean> getStructureMapList();

	List<CodelistMapMutableBean> getCodelistMapList() ;

	List<CategorySchemeMapMutableBean> getCategorySchemeMapList();

	List<ConceptSchemeMapMutableBean> getConceptSchemeMapList();

	List<OrganisationSchemeMapMutableBean> getOrganisationSchemeMapList();

	void setRelatedStructures(RelatedStructuresMutableBean relatedStructures);

	void setStructureMapList(List<StructureMapMutableBean> structureMapList);

	void setCodelistMapList(List<CodelistMapMutableBean> codelistMapList);

	void setCategorySchemeMapList(List<CategorySchemeMapMutableBean> categorySchemeMapList);

	void setConceptSchemeMapList(List<ConceptSchemeMapMutableBean> conceptSchemeMapList);

	void setOrganisationSchemeMapList(List<OrganisationSchemeMapMutableBean> organisationSchemeMapList);


	void addStructureMap(StructureMapMutableBean structureMap);

	void addCodelistMap(CodelistMapMutableBean codelistMap);

	void addCategorySchemeMap(CategorySchemeMapMutableBean categorySchemeMap);

	void addConceptSchemeMap(ConceptSchemeMapMutableBean conceptSchemeMap);

	void addOrganisationSchemeMap(OrganisationSchemeMapMutableBean organisationSchemeMap);

	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	StructureSetBean getImmutableInstance();

	/**
	 * Removes items from the Structure Set that are not valid for the specified Date.
	 * @param aDate
	 * @return
	 */
	StructureSetMutableBean stripItems(Date aDate);
}