package io.sdmx.api.sdmx.model.mutable.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Defines an Excel Reporting Template
 */
public interface ReportingTemplateMutableBean extends MaintainableMutableBean {
	
	/**
	 * Returns all the worksheets for this template
	 * @return
	 */
	List<ReportingTemplateWorksheetMutableBean> getWorksheets();
	void setWorksheets(List<ReportingTemplateWorksheetMutableBean> worksheets);
	
	/**
	 * set and get instruction sheet
	 * @param instructionSheet
	 */
	void setInstructionSheet(ReportTemplateInstructionSheetMutableBean instructionSheet);
	ReportTemplateInstructionSheetMutableBean getInstructionSheet();
	
	boolean includeFormulaCheckingSummary();
	void setIncludeFormulaCheckingSummary(boolean bool);
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ReportingTemplateBean getImmutableInstance();
}
