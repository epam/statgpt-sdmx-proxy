package io.sdmx.api.sdmx.model.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface HierarchyAssociationMutableBean extends MaintainableMutableBean {

	/**
	 * @return reference to the Hierarchy with which this is linking
	 */
	StructureReferenceBean getHierarchyRef();
	HierarchyAssociationMutableBean setHierarchyRef(StructureReferenceBean ref);


	/**
	 * @return reference to the maintainable which the hierarchy is being linked to
	 */
	StructureReferenceBean getLinkedStructure();
	HierarchyAssociationMutableBean setLinkedStructure(StructureReferenceBean ref);
	
	
	/**
	 * @return optional reference to a structure to give the link context, e.g. if the Link is to Dimension the Context could be a Dataflow (i.e. only link to this in the context of that)
	 */
	StructureReferenceBean getContextStructure();
	HierarchyAssociationMutableBean setContextStructure(StructureReferenceBean ref);

	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	HierarchyAssociationBean getImmutableInstance();
}
