
package io.sdmx.api.sdmx.model.submissionresponse;

/**
 * Response from a SDMX Registry for a Subscription submission
 */
public interface SubmitSubscriptionResponse extends SubmitStructureResponse {

	/**
	 * Returns the id that the subscriber assigned to the subscription
	 * @return
	 */
	String getSubscriberAssignedId();
	
}
