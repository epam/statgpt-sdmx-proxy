
package io.sdmx.api.sdmx.model.beans.base;

import java.util.Collection;

import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;


/**
 * Represents an SDMX MetadataProviderSchemeBean
 *
 */
public interface IMetadataProviderSchemeBean extends OrganisationSchemeBean<IMetadataProviderBean> {

	static final String FIXED_ID = "METADATA_PROVIDERS";
	static final String FIXED_VERSION = "1.0";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IMetadataProviderSchemeBean> getURN();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	IMetadataProviderSchemeMutableBean getMutableInstance();
	
	@Override
	IMetadataProviderSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet);
	
}
