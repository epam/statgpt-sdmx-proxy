package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.VersionableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;

public interface VersionableMutableBean extends NameableMutableBean, ValidityPeriodMutableBean{

	/**
	 * Sets all the properties on this bean from the bean passed in
	 * @param bean - to copy from
	 * @param includeInheritedProperties - if true, all properties will be set on the inherited interfaces
	 */
	void copyVersionableProperties(VersionableBean bean, boolean includeInheritedProperties);
	void copyVersionableProperties(VersionableMutableBean bean, boolean includeInheritedProperties);
	
	/**
	 * Sets the version if it is an absolute version and not a reference using semantic versioning
	 * @param vRef
	 * @return
	 */
	default VersionableMutableBean setVersion(IVersionRef vRef) {
		if(!vRef.isAbsolute()) {
			throw new IllegalArgumentException("Can not set version on versioable mutable as the version '"+vRef.toString()+"' is not absolute");
		}
		return setVersion(vRef.getMaxVersion());
	}
	
	VersionableMutableBean setVersion(ISdmxVersion version);
	VersionableMutableBean setVersion(String version);

	String getVersion();
	
}
