package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.Collection;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Contains the full definition of a publication table, 
 * 
 * Table title is the Name of this bean, and subtitle is the description, both of which can contain variables such as $(TIME_PERIOD) or $(MEASURE.ID)
 */
public interface PublicationTableBean extends MaintainableBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<PublicationTableBean> getURN();
	
	/**
	 * Returns a list of 1 or more dataflows that this publication table references
	 * @return
	 */
	Collection<PublicationTableDataflow> getDataflowReferences();
	
	/**
	 * Returns the dataflow reference with the given alias, or null if no such reference exists for the alias
	 * @param alias to match PublicationTableDataflow.getAlias
	 * @return
	 */
	ICrossReferenceBean<DataflowBean> getDataflowReference(String alias);
	
	/**
	 * <p>The output frequency of the period determines the output date format, using the default SDMX rules</p> 
	 * <p>The default can be overridden, for example A=YY.  To override the default rules, reference a Representation Map
	 * which maps the source Frequency i.e. A to a Java SimpleTime Format i.e. YY</p>
	 * 
	 * @return optional reference to a representation map mapping relationships for time 
	 */
	ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping();
	
	/**
	 * For use cases where a dimension value is conditional on the value of a dimension whose value is passed in as a variable.
	 * 
	 * For example if REF_ARA=JP then CURRENCY=JPY - the first variable REF_AREA determines the value of the second variable CURRENCY
	 * 
	 * @return mapping rules, empty list if no rules are defined
	 */
	List<PublicationTableVariableMappingBean> getVariableMapping();
	
	/**
	 * @return optional missing value rules
	 */
	PublicationTableMVBean getMissingValueRules();
	
	/**
	 * Returns a reference to all the codelists used as variables 
	 * @return
	 */
	List<PublicationVariableBean> getVariables();
	
	/**
	 * Returns the list of table header rows 
	 * @return
	 */
	List<PublicationTableHeadRow> getHeaderRows();
	
	/**
	 * Returns the list of table body rows 
	 * @return
	 */
	List<PublicationTableBodyRow> getBodyRows();
	
	/**
	 * Returns a list of the conditional variables used for this table
	 * @return
	 */
	List<ConditionalVariable> getConditionalVariables();
	
	/**
	 * Returns the table footer text for example
	 * 
	 * <sup>1</sup> Data are incomplete. See Table A2 for a list of countries that report non-bank subsectors.
	 * 
	 * @return
	 */
	List<TextTypeBean> getFootnotes();
	
	/**
	 * Options to format the key:
	 * <ol>
	 *  <li>=A:UK:EMP - series key</li>
	 *  <li>=FLOW.A:UK:EMP - Series key for Dataflow alias FLOW</li>
	 *  <li>CURRENCY=GBP,FREQ=A - Component Values</li>
	 *</ol>
	 * 
	 * 
	 * @return formatting to use for the observation values - empty string mapping represents a global rule, other strings are mapped on a series key
	 * or partial key in the format A:B:C
	 */
	List<IObservationFormatting> getObservationFormatting();
	
}
