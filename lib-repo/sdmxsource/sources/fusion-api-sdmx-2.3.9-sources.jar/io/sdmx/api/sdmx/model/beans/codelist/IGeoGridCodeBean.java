package io.sdmx.api.sdmx.model.beans.codelist;

public interface IGeoGridCodeBean extends CodeBean {

	/**
	 * @return the value used to align the code to one cell in the grid
	 */
	String getGeoCell();
	
}
