
package io.sdmx.api.sdmx.model.mutable.reference;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Defines a tree structure of Identifiable along with a set of all the structures that cross reference the Identifiable
 */
public interface MutableCrossReferencingTree {

	/**
	 * Returns the maintainable for which the structures are referencing 
	 * @return
	 */
	MaintainableMutableBean getMaintainable();
	
	/**
	 * Returns a set of maintainables that reference the given identifiable
	 * @return
	 */
	List<MutableCrossReferencingTree> getReferencingStructures();
}
