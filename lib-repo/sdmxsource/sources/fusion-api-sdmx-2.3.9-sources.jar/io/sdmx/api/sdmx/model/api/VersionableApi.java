package io.sdmx.api.sdmx.model.api;

import java.util.List;

import io.sdmx.api.sdmx.constants.VERSIONABLE_API;

/**
 * A Versionable is an item that can exist at different versions against an enumerated type.
 * E.g. versions 1.1, 1.2 for the type of "STRUCTURE_API"
 */
public interface VersionableApi {

	/**
	 * @return a list of Strings of all the versions that exist for this Versionable  
	 */
	List<String> getApiVersion();

	/**
	 * @return the API type
	 */
	VERSIONABLE_API getAPIType();
}
