package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * For use cases where a dimension value is conditional on the value of a dimension whose value is passed in as a variable.
 * For example if REF_ARA=JP then CURRENCY=JPY - the first variable REF_AREA determines the value of the second variable CURRENCY
 *
 */
public interface PublicationTableVariableMappingBean extends SDMXBean {

	/**
	 * @return the dimension id whose value is used as an input to this mapping
	 */
	String getInputDimensionId();
	
	/**
	 * @return list of output dimension ids - at least one is required
	 */
	List<String> getOutputDimensionId();
	
	/**
	 * @return a reference to the representation map which must have as many mapped output as there are output dimension ids
	 */
	ICrossReferenceBean<IRepresentationMapBean> getMappingRules();
}
