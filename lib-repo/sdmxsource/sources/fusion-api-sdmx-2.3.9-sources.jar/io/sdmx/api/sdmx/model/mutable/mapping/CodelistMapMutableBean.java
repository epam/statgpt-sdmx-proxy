
package io.sdmx.api.sdmx.model.mutable.mapping;

import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;

/**
 * @deprecated use {@link IRepresentationMapMutableBean} 
 */
public interface CodelistMapMutableBean extends ItemSchemeMapMutableBean<CodeMapMutableBean> {

	
}
