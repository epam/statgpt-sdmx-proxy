package io.sdmx.api.sdmx.model.mutable.mapping.v3;

/**
 * Represents an SDMX Reporting Category Map
 */
public interface IReportingCategoryMapMutableBean extends IItemMapMutableBean<IReportingCategoryMapMutableBean> {

}
