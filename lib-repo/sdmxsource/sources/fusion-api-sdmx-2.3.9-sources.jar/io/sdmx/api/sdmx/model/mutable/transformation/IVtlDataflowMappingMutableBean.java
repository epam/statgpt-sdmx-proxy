package io.sdmx.api.sdmx.model.mutable.transformation;

import java.util.List;

public interface IVtlDataflowMappingMutableBean extends IVtlMappingMutableBean {
	/**
	 * @return optional.  The mapping method used when mapping from SDMX to VTL.  This is typically a standandardToVtlMappingMethodType, 
	 * but can be any other value to allow for non-standard methods.  The implied default is basic
	 */
	String getFromMethod();
	void setFromMethod(String fromMethod);
	
	/**
	 * @return optional.  The mapping method used when mapping from SDMX to VTL.  This is typically a standandardToVtlMappingMethodType, 
	 * but can be any other value to allow for non-standard methods.  The implied default is basic for single measure VTL data structures and Unpivot for
	 * multi-measure VTL data structures
	 */
	String getToMethod();
	void setToMethod(String toMethod);
	
	
	/**
	 * @return immutable list, not null.  Identifies a sub space of the mapped dataflow that the mapping applies to. This is  a collection of references to the dimensions 
	 * that make up the space
	 */
	List<String> getFromSubSpace();
	void setFromSubSpace(List<String> fromSubspace);
	
	/**
	 * @return immutable list, not null.  Identifies a sub space of the mapped dataflow that the mapping applies to. This is  a collection of references to the dimensions 
	 * that make up the space
	 */
	List<String> getToSubSpace();
	void setToSubSpace(List<String> toSubspace);
}
