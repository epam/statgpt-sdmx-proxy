
package io.sdmx.api.sdmx.model.beans.reference.complex;

import java.util.List;

import io.sdmx.api.sdmx.constants.COMPLEX_MAINTAINABLE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.COMPLEX_STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;

/**
 * Contains information about a Complex Structure Query.  The information includes the response detail, 
 * and which referenced artefacts should be referenced in the response
 */
@Deprecated //unused
public interface ComplexStructureQueryMetadata {

	/**
	 * true if the matched artefact should be returned in the query result besides the referenced artefacts. 
	 * @return
	 */
	boolean isReturnedMatchedArtefact();
	
	/**
	 * Returns the query detail for this structure query, can not be null
	 * @return
	 */
	COMPLEX_STRUCTURE_QUERY_DETAIL getStructureQueryDetail();
	
	/**
	 * Returns the query details for the resolved references, can not be null
	 * @return
	 */
	COMPLEX_MAINTAINABLE_QUERY_DETAIL getReferencesQueryDetail();
	
	/**
	 * Returns the reference detail for this structure query, can not be null
	 * @return
	 */
	STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail();
	
	/**
	 * If STRUCTURE_REFERENCE_DETAIL == SPECIFIC, this method will return the specific structures for getting references, returns null otherwise
	 * @return
	 */
	List<SDMX_STRUCTURE_TYPE> getReferenceSpecificStructures();
}
