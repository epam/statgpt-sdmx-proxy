
package io.sdmx.api.sdmx.model.beans.mapping;

/**
 * Represents an SDMX Concept Scheme Map
 * @author Matt Nelson
 * @deprecated use mapping.v3
 */
@Deprecated
public interface ConceptSchemeMapBean extends ItemSchemeMapBean<ItemMapBean>  {

}
