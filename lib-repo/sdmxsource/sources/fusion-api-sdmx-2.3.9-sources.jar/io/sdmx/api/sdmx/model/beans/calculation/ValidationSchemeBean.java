package io.sdmx.api.sdmx.model.beans.calculation;

import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;

/**
 * Contains data validation rules for datasets collected against a Dataflow or Provision Agreement
 */
public interface ValidationSchemeBean extends ItemSchemeBean<ValidationRuleBean> {

	/**
	 * Returns a reference to either the Dataflow or Provision Agreement that this scheme is defining rules for
	 * @return
	 */
	ICrossReferenceBean<DataflowBean> getAttachment();
	
	@Override
	ValidationSchemeMutableBean getMutableInstance();
}
