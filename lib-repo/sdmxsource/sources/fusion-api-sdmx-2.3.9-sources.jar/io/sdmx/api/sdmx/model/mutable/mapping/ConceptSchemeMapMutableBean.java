
package io.sdmx.api.sdmx.model.mutable.mapping;



@Deprecated
public interface ConceptSchemeMapMutableBean extends ItemSchemeMapMutableBean<ItemMapMutableBean>  {

}
