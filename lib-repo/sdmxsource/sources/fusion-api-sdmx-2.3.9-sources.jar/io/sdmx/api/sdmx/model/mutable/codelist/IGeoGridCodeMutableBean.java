package io.sdmx.api.sdmx.model.mutable.codelist;

public interface IGeoGridCodeMutableBean extends CodeMutableBean {

	/**
	 * @return the value used to align the code to one cell in the grid
	 */
	String getGeoCell();
	void setGeoCell(String cell);
	
}
