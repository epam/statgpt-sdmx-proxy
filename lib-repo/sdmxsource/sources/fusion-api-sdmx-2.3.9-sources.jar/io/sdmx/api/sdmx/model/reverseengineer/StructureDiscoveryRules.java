package io.sdmx.api.sdmx.model.reverseengineer;

import java.util.List;

/**
 * Defines the rules on how to derive a DSD and related Concepts and Codelists from Columnar Dataset
 */
public interface StructureDiscoveryRules {

	/**
	 * @return the agency that will own the generated structures
	 */
	String getAgencyId();
	
	/**
	 * @return the concept scheme that will contain the generated concepts
	 */
	String getConceptSchemeId();
	
	/**
	 * @return the name of the data structure to create
	 */
	String getDataStructureId();
	
	/**
	 * @return the name of the data structure to create
	 */
	String getDataStructureName();

	/**
	 * Returns a list of columns to discover rules from, based on the column process order
	 * @return
	 */
	List<? extends ColumnDefinition> getColumnDefinitions();
	
	
}
