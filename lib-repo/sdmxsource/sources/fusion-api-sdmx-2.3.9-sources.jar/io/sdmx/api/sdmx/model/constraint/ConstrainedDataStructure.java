package io.sdmx.api.sdmx.model.constraint;

import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;

/**
 * Defines a Data Structure, optionally in the context of another structure, along with any constrained (partial) codelists and allowable series
 */
public interface ConstrainedDataStructure {

	/**
	 * Returns the Constrainable structure that the data structure has been constrained by
	 * @return
	 */
	ConstrainableBean getConstrainable();
	
	
	/**
	 * Returns the Data Structure that this ConstrainedDataStructure is defining
	 * @return
	 */
	DataStructureSuperBean getDataStructure();
	
	/**
	 * Returns the codelist (it may be partial) that the DSD component is referencing.  This will return null if the component id resolves to a component that
	 * is not codeed.  
	 * @param componentId the Id of the DSD component
	 * @return
	 * @throws SdmxException if the component id does not resolve to a component for the DSD
	 */
	EnumeratedListBean<EnumeratedItemBean> getCodelistForComponent(String componentId);
	
	/**
	 * Returns a set of allowable series, where each series is represented as a String made up of component ids spearated with a ':' for exmaple
	 * A:B:C:D 
	 * @return
	 */
	Set<String> getAllowableSeries();
	
	
}
