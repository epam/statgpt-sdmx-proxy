package io.sdmx.api.sdmx.model.beans.metadatastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IMSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;

/**
 * Extended by Metadataflow and Metadata Provision - both of which can identify metadata targets
 */
public interface IMetadataTargetIdentifier extends MaintainableBean, IMSDRelatedBean {

	/**
	 * @return list of 1 or more targets, which may be full or partial references
	 */
	List<ICrossReferenceBeanBase> getTargets();
	
}
