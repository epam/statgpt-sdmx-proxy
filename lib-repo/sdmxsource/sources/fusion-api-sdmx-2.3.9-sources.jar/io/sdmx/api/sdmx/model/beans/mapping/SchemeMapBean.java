
package io.sdmx.api.sdmx.model.beans.mapping;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

/**
 * Represents an SDMX Scheme Map
 * @author Matt Nelson
 * @deprecated use mapping.v3
 */
@Deprecated
public interface SchemeMapBean extends NameableBean {

	/**
	 * Source and target refs are structure references not cross references as they are 
	 * referencing a deprecated unregistered type
	 * 
	 * @return
	 */
	StructureReferenceBean getSourceRef();
	
	/**
	 * Source and target refs are structure references not cross references as they are 
	 * referencing a deprecated unregistered type
	 * 
	 * @return
	 */
	StructureReferenceBean getTargetRef();
	
}
