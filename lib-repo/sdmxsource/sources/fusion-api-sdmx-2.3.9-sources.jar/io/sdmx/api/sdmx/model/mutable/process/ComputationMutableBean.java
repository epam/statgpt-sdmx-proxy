
package io.sdmx.api.sdmx.model.mutable.process;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;


public interface ComputationMutableBean extends AnnotableMutableBean {

	public String getLocalId();

	public void setLocalId(String localId);

	public String getSoftwarePackage();

	public void setSoftwarePackage(String softwarePackage);

	public String getSoftwareLanguage();
	
	public void setSoftwareLanguage(String softwareLanguage);
	
	public String getSoftwareVersion();

	public void setSoftwareVersion(String softwareVersion);

	public List<TextTypeWrapperMutableBean> getDescriptions();

	public void addDescriptions(TextTypeWrapperMutableBean description);
	
	public void setDescriptions(List<TextTypeWrapperMutableBean> descriptions);
}
