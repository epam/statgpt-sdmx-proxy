package io.sdmx.api.sdmx.model.mutable.datastructure;

import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;

public interface MeasureMutableBean extends ComponentMutableBean {

}
