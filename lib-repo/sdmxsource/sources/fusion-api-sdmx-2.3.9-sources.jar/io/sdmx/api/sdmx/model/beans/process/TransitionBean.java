
package io.sdmx.api.sdmx.model.beans.process;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;


/**
 * Represented a transition between process steps
 * @author Matt Nelson
 *
 */
public interface TransitionBean extends IdentifiableBean, INoCrossReferencesBean {
	
	ProcessStepBean getTargetStep();
	
	List<TextTypeWrapper> getCondition();
	
	String getLocalId();
}
