
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;


public interface AnnotableMutableBean extends MutableBean {
	
	/**
	 * Sets all the properties on this bean from the bean passed in
	 * @param bean - to copy from
	 */
	void copyAnnotableProperties(AnnotableBean bean);
	void addAnnotation(AnnotationBean annotationBean);
	void copyAnnotableProperties(AnnotableMutableBean bean);

	List<AnnotationMutableBean> getAnnotations();

	void setAnnotations(List<AnnotationMutableBean> annotations);

	void addAnnotation(AnnotationMutableBean annotation);

	void removeAnnotationsByType(String annotationType);

	void removeAnnotationsByTitle(String annotationTitle);

	/**
	 * Adds an annotation and returns it
	 * @param title
	 * @param type
	 * @param url
	 * @return
	 */
	AnnotationMutableBean addAnnotation(String title, String type, String url);
	AnnotationMutableBean addAnnotation(String id, String title, String type, String url);

	Set<AnnotationMutableBean> getAnnotationsByType(String type);

	Set<AnnotationMutableBean> getAnnotationsByTitle(String type);
}
