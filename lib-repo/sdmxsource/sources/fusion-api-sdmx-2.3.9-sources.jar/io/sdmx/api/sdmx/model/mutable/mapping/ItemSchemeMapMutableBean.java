
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;


@Deprecated
public interface ItemSchemeMapMutableBean<T extends ItemMapMutableBean> extends SchemeMapMutableBean {

	List<T> getItems();

	void setItems(List<T> items);

	void addItem(T item);


}
