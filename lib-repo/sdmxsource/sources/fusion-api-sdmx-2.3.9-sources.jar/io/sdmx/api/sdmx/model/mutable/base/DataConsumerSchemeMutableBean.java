
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;


public interface DataConsumerSchemeMutableBean extends OrganisationSchemeMutableBean<DataConsumerMutableBean> {

	@Override
	DataConsumerSchemeBean getImmutableInstance();
	
}
