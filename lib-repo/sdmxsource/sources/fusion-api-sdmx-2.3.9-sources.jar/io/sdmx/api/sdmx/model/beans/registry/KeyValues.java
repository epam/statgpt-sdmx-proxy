
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;


/**
 * Represents an SDMX KeyValues as defined in a SDMX ContentConstraint
 * @author Matt Nelson
 *
 */
public interface KeyValues extends SdmxStructureBean {

	/**
	 * Returns the identifier of the component that the values are for
	 * @return
	 */
	String getId();
	
	/**
	 * @return true if the code prefix is to be removed before validation
	 */
	boolean isRemovePrefix();
	
	/**
	 * Returns true if the KeyValues are defining included keys, or false if excluded keys
	 * @return
	 */
	boolean isIncluded();
	
	/**
	 * This is mutually exclusive with the getTimeRange() method, and will return an empty list if getTimeRange() returns a non-null value
	 * @return the allowed / disallowed values in the constraint, this will not include values which are in the getCascadeExcludeRoot() set 
	 */
	Set<String> getValues();
	
	/**
	 * @return values which are cascade values with the root code included
	 */
	Set<String> getCascadeValues();
	
	/**
	 * @return values which are cascade values but not included in the getValues set (subset of getCascadeValues)
	 */
	Set<String> getCascadeExcludeRoot();
	
	/**
	 * Where the values are coded, and the codes have child codes, if a value if to be cascaded, then include all the child
	 * codes in the constraint for inclusion / exclusion
	 * @param value - the code id to check if it is to be cascaded (must exist in the getValues() list)
	 * @return true if the value is set to be cascaded
	 */
	boolean isCascadeValue(String value);
	
	/**
	 * @param value
	 * @return the time range for which the value is constrained
	 */
	SdmxPeriod getValidityPeriod(String value);
	
	/**
	 * Returns the time range that is being constrained, this is mutually exclusive with the getValues()
	 * @return
	 */
	TimeRangeBean getTimeRange();
}
