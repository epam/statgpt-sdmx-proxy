package io.sdmx.api.sdmx.model.error;

import java.util.List;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.http.HTTP_STATUS;

/**
 * represents an error that can be read / written as SDMX-ML
 */
public interface ISdmxError {

	HTTP_STATUS getHttpCode();
	
	int getSDMXCode();
	
	SDMX_ERROR_CODE getSdmxErrorCode();
	
	List<String> getErrorMessage();
	
}
