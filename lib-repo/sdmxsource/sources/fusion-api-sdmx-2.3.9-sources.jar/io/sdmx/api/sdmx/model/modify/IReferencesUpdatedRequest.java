package io.sdmx.api.sdmx.model.modify;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface IReferencesUpdatedRequest {


	MaintainableBean getSourceMaintainable();

	MaintainableBean getModifiedMaintainable();

	Map<StructureReferenceBean, StructureReferenceBean> getModifiedReferences();
	
}
