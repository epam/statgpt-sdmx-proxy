
package io.sdmx.api.sdmx.model.format;

import io.sdmx.api.format.InformationFormat;

/**
 * Defines a Schema format
 */
public interface SchemaFormat extends InformationFormat {


}
