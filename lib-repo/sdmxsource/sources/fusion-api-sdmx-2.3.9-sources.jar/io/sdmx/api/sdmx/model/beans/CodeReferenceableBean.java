package io.sdmx.api.sdmx.model.beans;

import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;

/**
 * 
 * A CodeReferenceableBean defines an object that has an implicit or explicit code reference.
 * <p>For example an Structure Set has StructureMap's that contain value mappings, and the value mappings might be explicit in mapping codes, as might the Codelist maps
 * <p>Or an HCL references a code in a codelist
 */
public interface CodeReferenceableBean { // should extend Maintainable?
	
	/**
	 * This will return a copy of the item with these codes Removed from ALL references in the object
	 * @param codeUrnsToRemove
	 * @param beanRet - this is used to make sure that the Structure maps and codelist maps are coded
	 * @return
	 */
	CodeReferenceableBean cloneItemWithCodeFilter(Set<String> urns, SdmxBeanRetrievalManager beanRet);
}