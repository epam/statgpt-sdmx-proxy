package io.sdmx.api.sdmx.model.constraint;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;

/**
 * Contains a Map of dimension Id to a set of valid codes for the dimension.
 * Contains the Data Structure that the dimensions are for
 */
public interface ConstrainedCodes {
	
	/**
	 * @return a non null immutable set of all the constraints that were used as an input to this subset of codes
	 */
	Set<ContentConstraintBean> getConstraintsUsed();
	
	/**
	 * @return the dataset structures that this was built from
	 */
	IDatasetStructures getDatasetStructures();
	
	/**
	 * @return the Constrainable structure that was used to build these constrained Codelists
	 */
	default ConstrainableBean getConstrainable() {
		return getDatasetStructures().getConstrainable();
	}
	
	/**
	 * @return not null - the underlying Data Structure Definition that the valid codes are for
	 */
	DataStructureSuperBean getDsd();
	
	/**
	 * @param componentId
	 * @return the codelist for the component, this may be a partial codelist if it is constrained
	 */
	 EnumeratedListBean<? extends EnumeratedItemBean> getCodelist(String componentId);
	
	/**
	 * Returns the set of valid codes for each Component of the Data Structure
	 * @return
	 */
	Map<String, Set<String>> getValidCodes();
	
}
