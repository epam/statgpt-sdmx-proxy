package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface IMetadataTargetIdentifiableMutable extends MaintainableMutableBean  {

	/**
	 * @return list of 1 or more targets, which may be full or partial references
	 */
	List<StructureReferenceBean> getTargets();
	void setTargets(List<StructureReferenceBean> targets);
	void addTarget(StructureReferenceBean sRef);
}
