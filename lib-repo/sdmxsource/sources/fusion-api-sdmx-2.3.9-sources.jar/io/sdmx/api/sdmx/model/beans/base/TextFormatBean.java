
package io.sdmx.api.sdmx.model.beans.base;

import java.math.BigDecimal;
import java.math.BigInteger;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;


/**
 * TextFormatBean gives information about the restrictions on a text value 
 * 
 * @author Matt Nelson
 *
 */
public interface TextFormatBean extends SDMXBean, INoCrossReferencesBean {
	
	/**
	 * Returns the type the values the text value can take 
	 * @return null if not defined
	 */
	TEXT_TYPE getTextType();
	
	/**
	 * Returns the earliest start time the value can take -  
	 * @return null if not defined
	 */
	SdmxDate getStartTime();

	/**
	 * Returns the latest end time the value can take -  
	 * @return null if not defined
	 */
	SdmxDate getEndTime();
	
	/**
	 * Indicates whether the values are intended to be ordered, and it may work in combination with the interval attribute
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	TERTIARY_BOOL getSequence();
	
	/**
	 * Returns the minimum length of text field that the value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigInteger getMinLength();
	
	/**
	 * Returns the maximum length of text field that the value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigInteger getMaxLength();
	
	/**
	 * Returns the start value of text field that the value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigDecimal getStartValue();
	
	/**
	 * Returns the end value of text field that the value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigDecimal getEndValue();
	
	/**
	 * Returns the maximum value that the numerical value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigDecimal getMaxValue();
	
	/**
	 * Returns the maximum value that the numerical value must take
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigDecimal getMinValue();
	
	/**
	 * Returns the interval of for the text values, this is typically given if isInterval() is true
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigDecimal getInterval();
	
	/**
	 * Returns the interval of for the text values, this is typically given if isInterval() is true
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	String getTimeInterval();
	
	/**
	 * Returns the number of decimal places, if the type is number
	 * <p/>
	 * If null, then interpret as N/A
	 * @return
	 */
	BigInteger getDecimals();
	
	/**
	 * Returns the pattern that the reported value must adhere to
	 * @return
	 */
	String getPattern();
	
	
	TERTIARY_BOOL getMultiLingual();
	
	/**
	 * Returns whether this TextFormat enforces restrictions.
	 */
	boolean hasRestrictions();
}
