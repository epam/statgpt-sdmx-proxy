package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.regex.Pattern;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * Defines the rule for a mapping from a single source value for example 
 * to map a value GBP, the value should simply be GBP.  However complex rules such as value must
 * start with GBP can be applied using value as GBP and an end index of 2 (0 indexed) which is interpreted as
 * the first three letters should be GBP.  The value may also be a regular expression used to pattern match.
 */
public interface IMappedValueBean extends SDMXBean, INoCrossReferencesBean {
	/**
	 * Properties as reported in the Diff
	 */
	enum Properties {
		REG_EX("Is RegEx"),
		SUBSTRING_START_IDX("Substring Start Index"),
		SUBSTRING_END_IDX("Substring End Index"),
		SOURCE_VALUE("Source Value"),
		MAPPED_VALUE("Mapped Value");
		
		private String property;
		
		private Properties(String property) {
			this.property = property;
		}

		public String getProperty() {
			return property;
		}
	}
	
	/**
	 * @return isRegEx() is true, returns the compiled pattern, otherwise returns null
	 */
	Pattern getPattern();

	/**
	 * @return the value to match
	 */
	String getValue();
	
	/**
	 * @return true if the value should be processed as a regular expression
	 */
	boolean isRegEx();
	
	/**
	 * @return the start index of the string to match, zero indexed, -1 to indicate N/A
	 */
	int getStartIndex();

	/**
	 * @return the end index of the string to match, zero indexed, -1 to indicate N/A
	 */
	int getEndIndex();
	
}
