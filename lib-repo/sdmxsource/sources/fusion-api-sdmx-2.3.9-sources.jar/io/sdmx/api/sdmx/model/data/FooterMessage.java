package io.sdmx.api.sdmx.model.data;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;

/**
 *	Provides extra detail on close, used to inform users of things such as truncated messages, or errors while processing.
 */
public interface FooterMessage {
	enum SEVERITY {
		ERROR("Error"),
		INFORMATION("Information"),
		WARNING("Warning");
		
		private String stringValue;
		
		private SEVERITY(String stringValue) {
			this.stringValue = stringValue;
		}

		@Override
		public String toString() {
			return stringValue;
		}
	}
	/**
	 * Mandatory Field - use to describe the error/warning
	 * @return
	 */
	String getCode();
	/**
	 * Optional - describes severity of problem
	 * @return
	 */
	SEVERITY getSeverity();
	
	/**
	 * Any text associated with the footer, there must be at least one text message
	 * @return
	 */
	List<TextTypeWrapper> getFooterText();
}
