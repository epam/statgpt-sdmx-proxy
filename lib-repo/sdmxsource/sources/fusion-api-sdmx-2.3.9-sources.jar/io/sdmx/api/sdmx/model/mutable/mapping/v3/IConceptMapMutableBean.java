package io.sdmx.api.sdmx.model.mutable.mapping.v3;

/**
 * Represents an SDMX Concept Map
 */
public interface IConceptMapMutableBean extends IItemMapMutableBean<IConceptMapMutableBean> {

}
