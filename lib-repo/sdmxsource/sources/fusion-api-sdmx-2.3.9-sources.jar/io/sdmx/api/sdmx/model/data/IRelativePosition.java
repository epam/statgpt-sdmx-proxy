package io.sdmx.api.sdmx.model.data;

/**
 * A position notifier which records the occurrence of the dataset, key, observation rather then the location in a file, 
 * i.e the first dataset is position 0, the next is position 1.  The key is relative to the dataset, first key is position 0, the next position 1, and the 
 * observation is relative to the key, the first obs for any key is position 0, and the next is position 1
 */
public interface IRelativePosition extends IDataPosition {

	/**
	 * @return zero indexed position, relative to the container
	 */
	int getPosition();
	
}
