
package io.sdmx.api.sdmx.model.mutable.conceptscheme;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ConceptBaseMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;


public interface ConceptMutableBean extends ItemMutableBean, ConceptBaseMutableBean, ValidityPeriodMutableBean {

	String getParentConcept();
	
	String getParentAgency();
	
	RepresentationMutableBean getCoreRepresentation();
		
	void setParentConcept(String parent);
	 
	void setParentAgency(String parentAgency);
	
	void setCoreRepresentation(RepresentationMutableBean coreRepresentation);
	
	StructureReferenceBean getIsoConceptReference();

	void setIsoConceptReference(StructureReferenceBean isoConceptReference);
}
