
package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface ProvisionAgreementMutableBean extends MaintainableMutableBean {
	
	StructureReferenceBean getStructureUsage();

	StructureReferenceBean getDataproviderRef();
	
	void setStructureUsage(StructureReferenceBean structureUseage);
	
	void setDataproviderRef(StructureReferenceBean dataproviderRef);
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ProvisionAgreementBean getImmutableInstance();
}
