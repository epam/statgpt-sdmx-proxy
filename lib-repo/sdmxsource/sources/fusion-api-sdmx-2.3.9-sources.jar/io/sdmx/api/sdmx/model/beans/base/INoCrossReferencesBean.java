package io.sdmx.api.sdmx.model.beans.base;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;

/**
 * A bean which does not cross reference any other {@link IdentifiableBean},
 * it's composites might i.e. a Constraint does not directly reference anything, but it has a constraint attachment which does
 */
public interface INoCrossReferencesBean extends SDMXBean {

	@Override
	default void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		//Do Nothing
	}
}