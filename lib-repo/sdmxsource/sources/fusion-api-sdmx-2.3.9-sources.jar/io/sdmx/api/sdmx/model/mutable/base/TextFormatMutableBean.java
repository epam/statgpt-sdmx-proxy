
package io.sdmx.api.sdmx.model.mutable.base;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;


public interface TextFormatMutableBean extends MutableBean {

	TERTIARY_BOOL getMultiLingual();

	void setMultiLingual(TERTIARY_BOOL isMultiLingual);
	
	TEXT_TYPE getTextType();
	
	TERTIARY_BOOL getSequence();
	
	BigDecimal getMaxValue();
	
	BigDecimal getMinValue();
	
	BigInteger getMinLength();
	
	BigInteger getMaxLength();
	
	BigDecimal getStartValue();
	
	BigDecimal getEndValue();
	
	BigDecimal getInterval();
	
	String getTimeInterval();
	
	BigInteger getDecimals();
	
	Date getStartTime();
	
	void setStartTime(Date startTime);

	Date getEndTime();
	
	void setEndTime(Date endTime);
	
	String getPattern();
	
	void setTextType(TEXT_TYPE textType);
	
	void setSequence(TERTIARY_BOOL isSequence);
	
	void setMinLength(BigInteger minLength);
	
	void setMaxLength(BigInteger maxLength);
	
	void setStartValue(BigDecimal startValue);
	
	void setEndValue(BigDecimal endValue);
	
	void setInterval(BigDecimal interval);

	void setMaxValue(BigDecimal maxValue);
	
	void setMinValue(BigDecimal minValue);
	
	void setTimeInterval(String timeInterval);
	
	void setDecimals(BigInteger decimals);
	
	void setPattern(String pattern);
	
}
