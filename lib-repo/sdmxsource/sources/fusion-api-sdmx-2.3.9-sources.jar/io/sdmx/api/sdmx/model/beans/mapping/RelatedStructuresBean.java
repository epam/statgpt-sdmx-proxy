package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;

/**
 * Represents an SDMX Related Structures Map
  * @deprecated use mapping.v3
 */
@Deprecated
public interface RelatedStructuresBean extends SdmxStructureBean {

	 List<IDirectCrossReferenceBean<DataStructureBean>> getDataStructureRef();
	 
	 List<IDirectCrossReferenceBean<MetadataStructureDefinitionBean>> getMetadataStructureRef();
	 
	 List<IDirectCrossReferenceBean<ConceptSchemeBean>> getConceptSchemeRef();
	 
	 List<IDirectCrossReferenceBean<CategorySchemeBean>> getCategorySchemeRef();
	 
	 List<IDirectCrossReferenceBean<OrganisationSchemeBean>> getOrgSchemeRef();
	 
	 List<IDirectCrossReferenceBean<HierarchyBean>> getHierCodelistRef();
}
