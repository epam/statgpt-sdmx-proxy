
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;


@Deprecated
public interface RepresentationMapRefMutableBean extends MutableBean {
	
	
	String getCodelistMapRef();

	TextFormatMutableBean getToTextFormat();

	TO_VALUE getToValueType();

	Map<String, Set<String>> getValueMappings();
	
	void setCodelistMapRef(String codelistRef);

	void setToTextFormat(TextFormatMutableBean toTextFormat);

	void setToValueType(TO_VALUE toValue);

	void setValueMappings(Map<String, Set<String>> mapping);
	
	/**
	 * Maps the component id to the component with the given value
	 * @param componentId
	 * @param componentValue
	 */
	void addMapping(String componentId, String componentValue);
	
	/**
	 * Get the value mappings associated with the componentId.
	 * This will never return null
	 * @param componentId
	 * @return
	 */
	Set<String> getMappingsFromComponentId(String componentId);
	
}
