
package io.sdmx.api.sdmx.model.beans.base;


/**
 * Represents an SDMX Data Provider
 * @author Matt Nelson
 *
 */
public interface DataProviderBean extends OrganisationBean, ConstrainableBean, MetricsBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<DataProviderBean> getURN();
	
	
	@Override
	DataProviderSchemeBean getMaintainableParent();
}
