package io.sdmx.api.sdmx.model.query;

import io.sdmx.api.sdmx.constants.AVAILABILITY_MODE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;

/**
 * An extension of the data query used to query for the availability of data, rather then the data itself
 * @see https://github.com/sdmx-twg/sdmx-rest/wiki/Data-Availability
 */
public interface RESTAvailabilityQuery extends RESTDataQuery {

	/**
	 * Returns the reference detail for this structure query, can not be null
	 * @return
	 */
	STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail();

	/**
	 * If STRUCTURE_REFERENCE_DETAIL == SPECIFIC, this method will return the specific structure reference, returns null otherwise
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getSpecificStructureReference();
	
	/**
	 * returns the mode which defines how to generate the list of valid value
	 * @return
	 */
	AVAILABILITY_MODE getMode();
	
	/**
	 * @return If availability is only required for one Component, then this will return the Id of that component
	 * null will be returned if availability is required for all Compoentns
	 */
	String[] getComponentIds();
	
}
