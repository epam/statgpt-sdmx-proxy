package io.sdmx.api.sdmx.model.beans.registry;

public interface AdvancedReleaseCalendarBean  extends ContentConstraintBean {

}
