package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.List;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * Defines a relationship between one or more source values (in combination) which are the equivalent to one or more
 * target values (in combination)
 */
public interface IMappedRelationshipBean extends AnnotableBean, INoCrossReferencesBean {
	
	/**
	 * Properties as reported in the Diff
	 */
	enum Properties {
		SOURCE_VALUE("Source Value"),
		VALIDITY_PERIOD("Validity Period"),
		TARGET_VALUE("Target Value");
		
		private String property;
		
		private Properties(String property) {
			this.property = property;
		}

		public String getProperty() {
			return property;
		}
	}
	
	/**
	 * Returns the validity period (valid from and to dates) for this mapping, not null (SdmxPeriod for AllPeriods (no start or end date) returned to indicate all periods)
	 * @return
	 */
	SdmxPeriod getValidityPeriod();
	
	/**
	 * @return position in the list of mapped relationships
	 */
	int getPosition();

	/**
	 * Returns true if there is a the validity period 
	 * @return
	 */
	default boolean hasValidityPeriod() {
		return getValidityPeriod() != null;
	}
	
	/**
	 * @return one or more source values which map to the target, as a matched value can contain rules these are captured in the {@link IMappedValueBean}
	 */
	List<IMappedValueBean> getSourceValue();
	
	/**
	 * @return one or more output target values mapped from the source, target values are absolute values
	 */
	List<String> getTargetValue();

}
