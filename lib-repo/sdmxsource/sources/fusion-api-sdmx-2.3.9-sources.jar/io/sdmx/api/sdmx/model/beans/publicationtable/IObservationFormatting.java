package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.io.Serializable;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;

public interface IObservationFormatting extends Serializable {

	/**
	 * @return if 0 or greater this represents the number of decimal places or number of significant figures
	 */
	int getPrecision();
	
	/**
	 * @return true to indicate the precision is the number of decimal places, false to indicate it represents significant figures
	 */
	boolean isPrecisionDP();
	
	/**
	 * @return true to indicate the final number must always contain the precision digets (pads with trailing zeros if necessary, i.e. 1.2 formats to 1.20)
	 */
	boolean isNormalise();
	
	/**
	 * @return true to use scientific notation on output i.e. 123000000 becomes 123E6
	 */
	boolean isScientificNotation();
	
	/**
	 * if provided the string will be formatted with thousand and decimal separators as used by the given locale,
	 * if the locale is Locale.ROOT this indicates that the locale is variable and the system should pick the local from the user's request (i,e
	 * if the request if via HTTP the Accpet-Language header would be used) - default to 'en' if not found
	 * @return the locale to use to format 
	 */
	Locale getLocale();
	
	/**
	 * @return the technique to use when rounding
	 */
	RoundingMode getRoundingMode();
	
	/**
	 * The scaling factor is applied to numerical observation values - i.e. a scaling factor or 2 will multiply numerical observation values by 100 (1.2 becomes 120).  
	 * 
	 * The system will check the Observation to determine if there is already a scaling factor applied (if there is an Attribute or Dimension for UNIT_MULT which uses the common CL_UNIT_MULT codelist) if there is
	 * then the system will find the difference between the unit multiplier already applied to the observation, and the desired unit multiplier and us this as the scaling factor - for example if an Observation 
	 * of 1.2 is reported with a unit multiplier of 6 (millions) and the scaling factor is 9 (Billions) then the system will multiple the value of 1.2 by 0.001 (6-9 = -3, 10^-3=0.001). The value of 1.2 million is
	 * 0.0012 billion. 
	 * 
	 * @return null to indicate no scaling factor. Zero to indicate Units, positive or negative to indicate 10 to the power of (i.e. 1 is tens, 2 is hundreds, 3 is thousands, -1 is tenths)
	 */
	Integer getScalingFactor();
	
	/**
	 * Defines which observations this rule applies to, matched the rule on an observation key - a null key match indicates a global rule
	 * 
	 * Options to format the key:
	 * <ol>
	 *  <li>=A:UK:EMP - series key</li>
	 *  <li>=A:UK:EMP:P:MEASURE1 - series key for a specific measure</li>
	 *  <li>=FLOW.A:UK:EMP - Series key for Dataflow alias FLOW</li>
	 *  <li>CURRENCY=GBP,FREQ=A - Component Values</li>
	 *</ol>
	 * 
	 * @return formatting to use for the observation values - empty or null string mapping represents a global rule, other strings are mapped on a series key
	 * or partial key in the format A:B:C
	 */
	List<String> getKeyMatch();
	
}
