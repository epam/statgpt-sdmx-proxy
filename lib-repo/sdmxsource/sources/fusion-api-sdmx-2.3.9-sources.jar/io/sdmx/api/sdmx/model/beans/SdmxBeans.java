package io.sdmx.api.sdmx.model.beans;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.registry.ActualContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.AdvancedReleaseCalendarBean;
import io.sdmx.api.sdmx.model.beans.registry.AllowedContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueMapBean;
import io.sdmx.api.sdmx.model.util.Hierarchy;

/**
 * Container for Structure Sdmx Beans, contains methods to add, remove, merge, and retrieve beans.  Also contains the means to
 * retrieve a mutable instance of the same container (<code>getMutableBeans</code>)
 */
public interface SdmxBeans extends IMetadataContainer, SdmxBeanRetrievalManager {
	
	/**
	 * Returns all the structure types held in this container
	 * @return
	 */
	Set<IMaintainableStructureType<?>> getDistinctTypes();
	
	/**
	 * Returns a read only copy of this beans container, or returns itself if it is already a read only copy
	 * @return
	 */
	SdmxBeans getReadOnlyCopy();

	/**
	 * Adds all the Beans in the supplied beans to this set of beans,
	 * any duplicates found in this set will be overwritten by the provided beans.  If the beans argument has a header this will overwrite
	 * and header set on this beans.
	 * <p/>
	 * The id of this SdmxBeans container will not be overwritten
	 * @param beans
	 */
	void merge(SdmxBeans beans);
	
	/**
	 * Merges but if overwrite is set to false, it will keep the original copy, not the updated copy
	 * @param beans
	 * @param overwrite
	 */
	void merge(SdmxBeans beans, boolean overwrite);
	
	/**
	 * Empties all the Beans in this container
	 */
	void clear();
	
	//ADD
	
	/**
	 * Adds many identifiables to the SdmxBeans container.
	 * <p/>
	 * If the identifiable belongs to an already stored maintainable, then the stored maintainable will be overwritten
	 * @see addIdentifiable(IdentifiableBean)
	 * @param beans
	 */
	void addIdentifiables(Collection<? extends IdentifiableBean> beans);
	
	/**
	 * Adds an identifiable to the SdmxBeans container.
	 * If the bean is a maintainable then it will be added directly into the container.
	 * If the bean is an identifiable that has a maintainable ancestor, then the maintainable ancestor will be added to the container,
	 * and will be retrievable through the respective getter method.
	 * <p/>
	 * If the identifiable belongs to an already stored maintainable, then the stored maintainable will be overwritten.
	 * @param bean
	 * @return true if the structure was added which overwrote an existing structure, false otherwise
	 */
	boolean addIdentifiable(IdentifiableBean bean);

	/**
	 * Removes the maintainable from the container, if it exists
	 */
	void removeMaintainable(MaintainableBean bean);
	
	/*****************************************************************************************************************/
	
	/**
	 * @param type maintainable type
	 * @return true if this container has one or more structures of the given type
	 */
	boolean hasStructuresOfType(SDMX_STRUCTURE_TYPE type);
	
	/*****************************************************************************************************************/
		
	/**
	 * Obtains a set of MaintainableBeans of type T that match the reference parameters in the MaintainableRef argument.
	 * 
	 * @param structureType identifies the structure type - null or MaintainableBean will return all structure types that match the reference
	 * @return
	 */
	<T extends MaintainableBean> Set<T> getMaintainableBeans(Class<T> structureType);
	
	/**
	 * Returns all the agencies that exist in the beans collection
	 */
	
	/**
	 * Returns the agencies in this beans container as a Hierarchy.  Note the Hierarchy starts with the default
	 * agency scheme, so this must be present for the returned Hierarchy to contain any Agencies
	 * 
	 * @return
	 */
	Hierarchy<AgencyBean> getAgencyHierarchy();
	
	/**
	 * Returns all the agencies that exist in the beans collection
	 */
	Set<AgencyBean> getAgencies();

	/**
	 * Returns all the AdvancedReleaseBean that exist in the beans collection
	 */
	default Set<AdvancedReleaseCalendarBean> getAdvancedReleaseCalendars() {
		return getMaintainableBeans(AdvancedReleaseCalendarBean.class);
	}
	
	/**
	 * Returns all the agency schemes in this container, returns an empty set if no agencies exist
	 */
	default Set<AgencySchemeBean> getAgenciesSchemes() {
		return getMaintainableBeans(AgencySchemeBean.class);
	}
		
	default Set<ContentConstraintBean> getContentConstraintBeans() {
		return getMaintainableBeans(ContentConstraintBean.class);
	}

	/**
	 * Returns all the content constraints that exist in the beans collection
	 */
	default Set<AllowedContentConstraintBean> getAllowedContentConstraintBeans() {
		return getMaintainableBeans(AllowedContentConstraintBean.class);
	}
	
	/**
	 * Returns all the content constraints that exist in the beans collection
	 */
	default Set<ActualContentConstraintBean> getActualContentConstraintBeans() {
		return getMaintainableBeans(ActualContentConstraintBean.class);
	}
	
	/**
	 * Returns all the organisation unit schemes in this container, returns an empty set if no organisation schemes exist
	 */
	default Set<OrganisationUnitSchemeBean> getOrganisationUnitSchemes() {
		return getMaintainableBeans(OrganisationUnitSchemeBean.class);
	}
	
	/**
	 * Returns all the data consumers in this container, returns an empty set if no data consumers exist
	 */
	default Set<DataConsumerSchemeBean> getDataConsumerSchemes() {
		return getMaintainableBeans(DataConsumerSchemeBean.class);
	}
	
	/**
	 * Returns all the dataflows in this container, returns an empty set if no dataflows exist
	 */
	default Set<DataflowBean> getDataflows() {
		return getMaintainableBeans(DataflowBean.class);
	}
	
	/**
	 * Returns all the data provider in this container, returns an empty set if no data providers exist
	 */
	default Set<DataProviderSchemeBean> getDataProviderSchemes() {
		return getMaintainableBeans(DataProviderSchemeBean.class);
	}
	
	/**
	 * Returns all the metadataflows in this container, returns an empty set if no metadata provider schemes exist
	 */
	default Set<IMetadataProviderSchemeBean> getMetadataProviderSchemeBean() {
		return getMaintainableBeans(IMetadataProviderSchemeBean.class);
	}
	
	/**
	 * Returns all the metadataflows in this container, returns an empty set if no metadataflows exist
	 */
	default Set<MetadataFlowBean> getMetadataflows() {
		return getMaintainableBeans(MetadataFlowBean.class);
	}
	
	/**
	 * Returns all the metadataflows in this container, returns an empty set if no metadataflows exist
	 */
	default Set<MetadataProvisionAgreementBean> getMetadataProvisions() {
		return getMaintainableBeans(MetadataProvisionAgreementBean.class);
	}
	
	/**
	 * Returns all the category schemes in this container, returns an empty set if no category schemes exist
	 */
	default Set<CategorySchemeBean> getCategorySchemes() {
		return getMaintainableBeans(CategorySchemeBean.class);
	}
	
	/**
	 * Returns all the codelists in this container, returns an empty set if no codelists exist
	 */
	default Set<CodelistBean> getCodelists() {
		return getMaintainableBeans(CodelistBean.class);
	}
	
	/**
	 * Returns all the Hierarchy Associations in this container, returns an empty set if none exist
	 */
	default Set<HierarchyAssociationBean> getHierarchyAssociations() {
		return getMaintainableBeans(HierarchyAssociationBean.class);
	}
	
	/**
	 * Returns all the hierarchical codelists in this container, returns an empty set if no hierarchical codelists exist
	 */
	default Set<HierarchyBean> getHierarchies() {
		return getMaintainableBeans(HierarchyBean.class);
	}
	
	/**
	 * Returns all the categorisations in this container, returns an empty set if no categorisations exist
	 */
	default Set<CategorisationBean> getCategorisations() {
		return getMaintainableBeans(CategorisationBean.class);
	}
	
	/**
	 * Returns all the concept schemes in this container, returns an empty set if no concept schemes exist
	 */
	default Set<ConceptSchemeBean> getConceptSchemes() {
		return getMaintainableBeans(ConceptSchemeBean.class);
	}
	
	/**
	 * Returns all the metadata structures in this container, returns an empty set if no metadata structures exist
	 */
	default Set<MetadataStructureDefinitionBean> getMetadataStructures() {
		return getMaintainableBeans(MetadataStructureDefinitionBean.class);
	}

	/**
	 * Returns all the metadata constraints in this container, returns an empty set if no metadata constraints exist
	 */
	default Set<IMetadataConstraintBean> getMetadataConstraints() {
		return getMaintainableBeans(IMetadataConstraintBean.class);
	}
	
	/**
	 * Returns all the key families in this container, returns an empty set if no key families exist
	 */
	default Set<DataStructureBean> getDataStructures() {
		return getMaintainableBeans(DataStructureBean.class);
	}
	
	/**
	 * Returns all the reporting taxonomies in this container, returns an empty set if no reporting taxonomies exist
	 */
	default Set<ReportingTaxonomyBean> getReportingTaxonomys() {
		return getMaintainableBeans(ReportingTaxonomyBean.class);
	}
	
	/**
	 * Returns all the reporting taxonomies in this container, returns an empty set if no reporting taxonomies exist
	 */
	default Set<ReportingTemplateBean> getReportingTemplates() {
		return getMaintainableBeans(ReportingTemplateBean.class);
	}
	
	/**
	 * Returns all the representation maps in this container, returns an empty set if none exist
	 */
	default Set<IRepresentationMapBean> getRepresentationMaps() {
		return getMaintainableBeans(IRepresentationMapBean.class);
	}
	
	/**
	 * Returns all the category scheme maps in this container, returns an empty set if none exist
	 */
	default Set<ICategorySchemeMapBean> getCategorySchemeMaps() {
		return getMaintainableBeans(ICategorySchemeMapBean.class);
	}

	/**
	 * Returns all the concept scheme maps in this container, returns an empty set if none exist
	 */
	default Set<IConceptSchemeMapBean> getConceptSchemeMaps() {
		return getMaintainableBeans(IConceptSchemeMapBean.class);
	}

	/**
	 * Returns all the organisation scheme maps in this container, returns an empty set if none exist
	 */
	default Set<IOrganisationSchemeMapBean> getOrganisationSchemeMaps() {
		return getMaintainableBeans(IOrganisationSchemeMapBean.class);
	}

	/**
	 * Returns all the reporting taxonomy maps in this container, returns an empty set if none exist
	 */
	default Set<IReportingTaxonomyMapBean> getReportingTaxonomyMaps() {
		return getMaintainableBeans(IReportingTaxonomyMapBean.class);
	}

	/**
	 * Returns all the structure sets in this container, returns an empty set if no structure sets exist
	 */
	default Set<IStructureMapBean> getStructureMaps() {
		return getMaintainableBeans(IStructureMapBean.class);
	}
	
	/**
	 * Returns all the processes in this container, returns an empty set if no processes exist
	 */
	default Set<ProcessBean> getProcesses() {
		return getMaintainableBeans(ProcessBean.class);
	}
	
	/**
	 * Returns all the provision agreements in this container, returns an empty set if no provision agreements exist
	 */
	default Set<ProvisionAgreementBean> getProvisionAgreements() {
		return getMaintainableBeans(ProvisionAgreementBean.class);
	}
	
	/**
	 * Returns all the Publication Tables in this container, returns an empty set if no Publication Tables exist
	 */
	default Set<PublicationTableBean> getPublicationTables() {
		return getMaintainableBeans(PublicationTableBean.class);
	}
	
	/**
	 * Returns all the PreDefinedQueries Bean in this container, returns an empty set if no IPreDefinedQueryBean exist
	 */
	default Set<IPreDefinedQueryBean> getPredefinedQueries() {
		return getMaintainableBeans(IPreDefinedQueryBean.class);
	}
	
	/**
	 * Returns all the registrations in this container, returns an empty set if no registrations exist
	 */
	default Set<RegistrationBean> getRegistrations() {
		return getMaintainableBeans(RegistrationBean.class);
	}
	
	/**
	 * Returns all the subscriptions in this container, returns an empty set if no subscriptions exist
	 */
	default Set<SubscriptionBean> getSubscriptions() {
		return getMaintainableBeans(SubscriptionBean.class);
	}
	
	/**
	 * Returns all the validation schemes in this container, returns an empty set if no validation schemes exist
	 */
	default Set<ValidationSchemeBean> getValidationSchemes() {
		return getMaintainableBeans(ValidationSchemeBean.class);
	}
	
	/**
	 * Returns all the value lists in this container, returns an empty set if no validation schemes exist
	 */
	default Set<ValueListBean> getValueLists() {
		return getMaintainableBeans(ValueListBean.class);
	}
	
	/**
	 * Returns all the value maps in this container, returns an empty set if no validation schemes exist
	 */
	default Set<ValueMapBean> getValueMaps() {
		return getMaintainableBeans(ValueMapBean.class);
	}
	
	default Set<ICustomTypeSchemeBean> getVtlCustomTypeBean() {
		return getMaintainableBeans(ICustomTypeSchemeBean.class);
	}
	
	default Set<INamePersonalisationSchemeBean> getVtlNamePersonalisationBean() {
		return getMaintainableBeans(INamePersonalisationSchemeBean.class);
	}
	
	default Set<IRulesetSchemeBean> getVtlRulesetSchemeBean() {
		return getMaintainableBeans(IRulesetSchemeBean.class);
	}

	default Set<ITransformationSchemeBean> getVtlTransformationSchemeBean() {
		return getMaintainableBeans(ITransformationSchemeBean.class);
	}
	
	default Set<IUserDefinedOperatorSchemeBean> getVtlUserDefinedOperatorSchemeBean() {
		return getMaintainableBeans(IUserDefinedOperatorSchemeBean.class);
	}
	
	default Set<IVtlMappingSchemeBean> getVtlMappingSchemeBean() {
		return getMaintainableBeans(IVtlMappingSchemeBean.class);
	}
	
	/*****************************************************************************************************************/
	
	/**
	 * Returns all the maintainables in this container, returns an empty set if no maintainables exist in this container.
	 * @return set of all maintainables, minus any which match the optional exclude parameters
	 * @param exclude do not return the maintainables which match the optional exclude parameters
	 */
	Set<MaintainableBean> getAllMaintainables(SDMX_STRUCTURE_TYPE...exclude);

	/**
	 * Returns all the maintainables of a given type.
	 * @param structureType filter on this type for returned maintainables
	 * @return set of all maintainables of given type
	 */
	Set<MaintainableBean> getMaintainables(SDMX_STRUCTURE_TYPE structureType);

	/**
	 * Return a copy of this container consisting of the maintainables of this container that match the given predicate.
	 * @param predicate
	 * @return SdmxBeans
	 */
	SdmxBeans filterMaintainables(Predicate<? super MaintainableBean> predicate);
	
	/**
	 * Returns true if this container does not hold any structures
	 * @return
	 */
	default boolean isEmpty() {
		return this.getAllMaintainables().isEmpty();
	}
	
	/**
	 * Calls Deep Equals on each maintainable in the beans container and returns true if both are contained, this ignores order
	 * @param beansToEqual
	 * @return
	 */
	default boolean deepEquals(SdmxBeans beansToEqual) {
		Set<MaintainableBean> thisMaints = this.getAllMaintainables();
		Set<MaintainableBean> thatMaints = beansToEqual.getAllMaintainables();
		if(thisMaints.size() != thatMaints.size()) {
			return false;
		}
		Map<String, MaintainableBean> urnMap = new HashMap<>();
		
		for(MaintainableBean thisMaint: thisMaints) {
			urnMap.put(thisMaint.getUrn(), thisMaint);
		}
		
		for(MaintainableBean thatMaint: thatMaints) {
			MaintainableBean thisMaint = urnMap.get(thatMaint.getUrn());
			if(thisMaint == null) {
				return false;
			}
			if(!thisMaint.deepEquals(thatMaint, true)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Get the maintainable bean based off the URN, this will return null if the bean does not exist
	 * @param urn
	 * @return
	 */
	default MaintainableBean getMaintainable(String urn) {
		Stream<MaintainableBean> filter = this.getAllMaintainables().stream().filter(m -> m.getUrn().equals(urn));
		Set<MaintainableBean> maintSet = filter.collect(Collectors.toSet());
		if(maintSet.isEmpty()) {
			return null;
		}
		return maintSet.iterator().next();
	}
}
