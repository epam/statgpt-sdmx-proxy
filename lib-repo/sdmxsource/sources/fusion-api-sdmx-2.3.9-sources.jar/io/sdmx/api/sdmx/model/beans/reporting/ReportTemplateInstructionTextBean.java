package io.sdmx.api.sdmx.model.beans.reporting;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

public interface ReportTemplateInstructionTextBean extends INoCrossReferencesBean {

	/**
	 * @return text content for the sheet, simple markdown supported
	 */
	String getContent();
	
	/**
	 * @return number of columns to merge to fit the content, text wrap is enabled
	 */
	int getColWidth();
	
	/**
	 * @return number of rows to merge to fit the content, text wrap is enabled
	 */
	int getColHeight();
	
}
