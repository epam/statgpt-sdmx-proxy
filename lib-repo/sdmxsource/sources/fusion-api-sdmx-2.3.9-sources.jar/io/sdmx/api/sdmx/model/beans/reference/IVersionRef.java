package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;

/**
 * References one or more versions, the version syntax is two or three parts:
 * 
 * 1.0
 * 1.0.0 
 * 
 * If a suffix exists, the version is deemed unstable
 * 1.0.0-draft
 * 
 * If a part contains a * it indicates all versions that match
 * 1.0.* will match 1.0.0 and 1.0.1
 * 1.* will match 1.0.0 and 1.0.1 and 1.1.0
 * 
 * 
 * If a part contains a ~ it will match all latest versions which are stable
 * 1.0.~ will match 1.0.5 only if assessing the following versions: 1.0.3, 1.0.4, 1.0.5, and 1.0.6-draft
 * 
 * If a part contains a + it will match all latest versions which are stable or unstable
 * 1.0.~ will match 1.0.6-draft only if assessing the following versions: 1.0.3, 1.0.4, 1.0.5, and 1.0.6-draft
 * 
 */
public interface IVersionRef extends Serializable {
	
	/**
	 * @return true if this is referencing a non semantically versioned structure, i.e one with only two parts
	 */
	default boolean isTwoPart() {
		return isAbsolute() && this.getMinVersion().getPatch() < 0;
	}

	/**
	 * @return true if the latest version in the min/max range is being referenced if false then all versions are matched
	 */
	boolean isLatest();
	
	/**
	 * @return true if this is referencing an absolute version, with no latest/range logic (min version == max version, islatest==false)
	 */
	boolean isAbsolute();
	
	/**
	 * @return true if this will match on any version, does not take into account drafts i.e. if All may return true but then return false
	 * on a draft because it has a null version suffix.  Check with version suffix to ensure it is all drafts as well
	 */
	boolean isAll();
	
	/**
	 * optional, used to reference versions that include a suffix, if null no suffix should be present, if * any suffix (of lack of) is matched
	 * @return
	 */
	String getVersionSuffix();
	
	/**
	 * @return minimum version being referenced
	 */
	ISdmxVersion getMinVersion();
	
	/**
	 * @return maximum version being referenced
	 */
	ISdmxVersion getMaxVersion();
	
	/**
	 * @return true if this reference can match on draft structures with a suffix three part
	 */
	default boolean matchDraft() {
        String suffix = getVersionSuffix();
        return suffix != null;
    }
	
	default boolean hasSuffix() {
		String suffix = getVersionSuffix();
		return suffix != null && !suffix.equals("*");
	}
	
	/**
	 * A patch restriction is greater then or equal to zero, this is required because a 2 part
	 * version number has a patch version of -1, so a three part version number ending in .0 must not include
	 * two part version numbers
	 * @return
	 */
	default boolean hasMinPatchRestrictions() {
		return getMinVersion().getPatch() >= 0;
	}
	
	default boolean hasMaxPatchRestrictions() {
		return getMaxVersion().getPatch() < Integer.MAX_VALUE;
	}
	
	default boolean hasMinMinorRestrictions() {
		return getMinVersion().getMinor() > 0;
	}

	default boolean hasMaxMinorRestrictions() {
		return getMaxVersion().getMinor() < Integer.MAX_VALUE;
	}
	
	default boolean hasMinMajorRestrictions() {
		return getMinVersion().getMajor() > 0;
	}
	
	default boolean hasMaxMajorRestrictions() {
		return getMaxVersion().getMajor() < Integer.MAX_VALUE;
	}
	/**
	 * @param version
	 * @return true if the version passed in matches the rules of this reference
	 */
	boolean isMatch(ISdmxVersion version);
	
	/**
	 * @param version
	 * @return true if the version passed in matches the rules of this reference
	 */
	boolean isMatch(IVersionRef vRef);
	
	/**
	 * @return string representation of the reference, e.g.e 1+2.0
	 */
	@Override
    String toString();
}
