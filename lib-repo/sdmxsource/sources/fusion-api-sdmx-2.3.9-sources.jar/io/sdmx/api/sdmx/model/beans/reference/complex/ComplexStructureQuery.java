
package io.sdmx.api.sdmx.model.beans.reference.complex;


/**
 * A ComplexStructureQuery defines very complex search rules for finding structures
 */
@Deprecated //unused
public interface ComplexStructureQuery {


	/**
	 * Returns information about the response detail, and which referenced artefacts should be referenced in the response
	 * @return
	 */
	ComplexStructureQueryMetadata getStructureQueryMetadata();
	
	/**
	 * Returns the query parameters used to identify the structure(s) begin queried for - this can not be null
	 * @return
	 */
	ComplexStructureReferenceBean getStructureReference();
}
