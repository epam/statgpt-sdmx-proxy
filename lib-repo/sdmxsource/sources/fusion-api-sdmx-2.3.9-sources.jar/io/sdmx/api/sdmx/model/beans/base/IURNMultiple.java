package io.sdmx.api.sdmx.model.beans.base;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;

/**
 * Represents URN which contains multiple agencies, Ids or versions
 * 
 * An {@link IURNMultiple} 
 * 
 * A URN with multiple references would look like the following
 * 
 * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_FREQ(1.0,2.0)                  - multiple versions
 * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_REF_AREA,CL_FREQ(1.0)          - multiple Codelist IDs
 * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_REF_AREA,CL_FREQ(*)            - multiple Codelist IDs any version
 * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX,BIS:CL_FREQ(1.0)                  - multiple agency IDs any version
 * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX,BIS:CL_REF_AREA,CL_FREQ(1.0,2.0)  - multiple agency IDs, and Codelist IDs, and versions
 * urn:sdmx:org.sdmx.infomodel.codelist.Code=SDMX:CL_FREQ(2.0).A,M,Q                    - multiple Code IDs 
 * 
 * @param <K>
 */
public interface IURNMultiple<K extends IdentifiableBean> extends IURN<K> {

	/**
	 * @return contains a reference to multiple structures - this overrides the information in IMaintainableRef
	 */
	IMultiMaintainableRef getMutltiReference();
	
	/**
	 * @return not null, immutable, zero to many identifiable IDs
	 */
	Set<String> getIdentifiableIds();
	
	/**
	 * @return fixed MULTIPLE
	 */
	@Override
	default REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.MULTIPLE;
	}
	
	/**
	 * @param identifiableBean to test the match against
	 * @return true if this cross reference matches the attributes of the {@link IdentifiableBean}
	 */
	default boolean isMatch(IdentifiableBean identifiableBean) {
		return isMatch(identifiableBean.getURN());
	}
	
	/**
	 * Overrides the IURN implementation by testing the multiple agencies, ids, and versions
	 */
	@Override
	default boolean isMatch(IURN<?> that) {
		//Compare structure type, return false if both are a specific type that do not match
		if(!this.getStructureType().isAny() && 
				!that.getStructureType().isAny() && 
				this.getStructureType() != that.getStructureType()) {  //TODO what  about abstract types?  i.e OrganisationScheme 
			return false;
		}
		
		IMultiMaintainableRef multiRef = getMutltiReference();
		
		//Only perform checks if both this URN and that URN have at least 1 filter on the property
		boolean agencyIdCheck = that.hasAgencyId() && this.hasAgencyId();
		boolean maintIdCheck = that.hasMaintainableId() && this.hasMaintainableId();
		boolean identIdCheck = that.hasIdentifiableId() && this.hasIdentifiableId();
		
		if(that.getReferenceType() == REFERENCE_TYPE.MULTIPLE) {
			//The URN passed in is also of type multiple
			IURNMultiple<?> thatMult = that.asMultiple();
			IMultiMaintainableRef thatMultiRef = thatMult.getMutltiReference();
			if(agencyIdCheck && !multiRef.getAgencyId().contains(that.getAgencyId())) {
				return false;
			}
			if(maintIdCheck && !multiRef.getId().contains(that.getMaintainableId())) {
				return false;
			}
			if(identIdCheck && !getIdentifiableIds().contains(thatMult.getIdentifiableIds())) {
				return false;
			}
		} else {
			//The URN passed in only has single values for agency, id, version
			if(agencyIdCheck && !multiRef.getAgencyId().contains(that.getAgencyId())) {
				return false;
			}
			if(maintIdCheck && !multiRef.getId().contains(that.getMaintainableId())) {
				return false;
			}
			if(identIdCheck && !getIdentifiableIds().contains(that.getIdentifiableId())) {
				return false;
			}
		}
		if(!that.getVersion().isMatch(this.getVersion())) {
			return false;
		}
		return true;
	}
}
