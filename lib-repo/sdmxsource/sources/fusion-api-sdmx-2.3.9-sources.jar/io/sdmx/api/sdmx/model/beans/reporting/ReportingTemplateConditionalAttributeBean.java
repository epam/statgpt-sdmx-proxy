package io.sdmx.api.sdmx.model.beans.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * Contains a set of conditional rules for an attribute
 *
 */
public interface ReportingTemplateConditionalAttributeBean extends INoCrossReferencesBean {

	/**
	 * Returns the attribute id
	 * @return
	 */
	String getAttributeId();
	
	/**
	 * Returns the set of output attribute values for the given conditions 
	 * @return
	 */
	List<ConditionalAttributeMappingBean> getConditions();
	
}
