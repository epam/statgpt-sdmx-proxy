package io.sdmx.api.sdmx.model.mutable.pdq;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface IPreDefinedQueryMutableBean extends MaintainableMutableBean {
	
	@Override
	IPreDefinedQueryBean getImmutableInstance();
	
	/**
	 * @return true to indicate this is a virtual dataflow, false to indicate it is a filter on an existing dataflow
	 */
	boolean isVirtualFlow();
	void setVirtualFlow(boolean virtual);
	/**
	 * @return the Dataflows the query is for
	 */
	Set<StructureReferenceBean> getDataflow();
	void setDataflow(Set<StructureReferenceBean> dataflows);
	void addDataflow(StructureReferenceBean dataflow);
	
	/**
	 * @return the set of selections selections are implicitly ANDED together. 
	 */
	List<IPreDefinedQueryComponentFilterMutableBean> getSelections();
	void setSelections(List<IPreDefinedQueryComponentFilterMutableBean> selections);
	void addSelection(IPreDefinedQueryComponentFilterMutableBean selection);
	
	/**
	 * <p>Returns an immutable list set containing the basket of series which are expected to be returned as a result of this query.</p>
	 * <p>The syntax is colon separated A:B:C:D</p>
	 * <p>Series can be wildcarded, and may contain + operators to indicate multiple selections, example: A:::D</p>
	 * @return
	 */
	Set<String> getSeries();
	void setSeries(Set<String> series);
	void addSeries(String series);

	/**
	 * @return mutable map of additional query parameters
	 */
	Map<String, String> getParameters();
	void setParameters(Map<String, String> map);
	void addParameter(String key, String value);
}
