package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents a URN which uses semantic versioning to target the identifiable structures
 */
public interface IURNSemantic<K extends IdentifiableBean> extends IURNSingle<K> {

	default REFERENCE_TYPE getType() {
		return REFERENCE_TYPE.SEMANTIC;
	}
}
