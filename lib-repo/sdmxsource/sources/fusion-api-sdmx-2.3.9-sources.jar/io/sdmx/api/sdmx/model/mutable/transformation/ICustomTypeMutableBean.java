package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface ICustomTypeMutableBean extends ItemMutableBean {

	String getVtlScalarType();
	void setVtlScalarType(String vtlScalarType);
	
	String getDataType();
	void setDataType(String dataType);
	
	String getOutputFormat();
	void setOutputFormat(String outputFormat);
	
	String getNullValue();
	void setNullValue(String nullValue);
	
	String getVtlLiteralFormat();
	void setVtlLiteralFormat(String vtlLiteralFormat);
}
