
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface MetadataTargetRegionMutableBean extends MutableBean {
	/**
	 * Returns true if the information reported is to be included or excluded 
	 * @return
	 */
	boolean isInclude();
	void setIsInclude(boolean include);
	
	String getReport();
	void setReport(String report);
	
	String getMetadataTarget();
	void setMetadataTarget(String metadatatarget);
	
	/**
	 * Returns the key values restrictions for the metadata target region
	 * @return
	 */
	List<MetadataTargetKeyValuesMutable> getKey();
	
	void setKey(List<MetadataTargetKeyValuesMutable> key);
	
	void addKey(MetadataTargetKeyValuesMutable key);
	
	/**
	 * Returns the attributes restrictions for the metadata target region
	 * @return
	 */
	List<KeyValuesMutable> getAttributes();
	
	
	void setAttributes(List<KeyValuesMutable>  attributes);
	
	void addAttribute(KeyValuesMutable attribute);
	
}
