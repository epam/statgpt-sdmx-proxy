package io.sdmx.api.sdmx.model.mutable.transformation;

public interface IVtlCodelistMappingMutableBean extends IVtlMappingMutableBean {

}
