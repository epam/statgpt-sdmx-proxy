package io.sdmx.api.sdmx.model.diff;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;

/**
 * A difference between two properties of an object
 */
public interface Diff {

	/**
	 * Returns a reference to the source identifiable structure where the difference occurred (or the parent of the SDMXBean if the difference occurred
	 * in a non-identifiable structure type)
	 * @return
	 */
	IURNAbsolute<?> getURN();
	
	/**
	 * Returns the object property that is different
	 * @return
	 */
	String getProperty();

	/**
	 * Returns the source value
	 * @return
	 */
	String getSourceValue();

	/**
	 * Returns the target value
	 * @return
	 */
	String getTargetValue();

	/**
	 * Returns the modification, addition is where there is a source value and
	 * no target value, removal is the opposite, and modification is where the two
	 * values are different
	 * @return
	 */
	ModificationAction getModification();

}
