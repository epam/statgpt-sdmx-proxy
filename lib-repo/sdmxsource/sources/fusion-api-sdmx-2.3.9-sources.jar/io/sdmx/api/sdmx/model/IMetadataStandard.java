package io.sdmx.api.sdmx.model;

/**
 * Represents a metadata standards (e.g SDMX v3.0 or DDI) - used by objects
 * to indicate which standards they are compatible with
 *
 */
public interface IMetadataStandard {
	
	/**
	 * @return unique Id for the standard, i.e SDMX
	 */
	String getId();
	
}
