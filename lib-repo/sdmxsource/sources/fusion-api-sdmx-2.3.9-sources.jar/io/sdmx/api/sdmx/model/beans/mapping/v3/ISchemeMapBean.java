
package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Represents an SDMX Scheme Map
 * @author Matt Nelson
 *
 */
public interface ISchemeMapBean extends MaintainableBean {

	ICrossReferenceBean<? extends ItemSchemeBean> getSourceRef();
	
	ICrossReferenceBean<? extends ItemSchemeBean> getTargetRef();
	
}
