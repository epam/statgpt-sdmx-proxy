
package io.sdmx.api.sdmx.model.beans.base;

import java.io.Serializable;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.diff.DiffReport;


/**
 * An SDMXBean represents any SDMX structural artifact or metadata structure artifact.
 * <p/>
 * All classes which inherit from SDMXBean are immutable, meaning they can not have any of their contents modified.
 * Any collections returned as a result of a method call will be copies of collections ensuring the immutability of the 
 * SDMXBean is preserved.  This 'copy paradigm' is also true of composite objects returned, which are mutable, for example any object
 * of type 'java.util.Date' will be a copy of the underlying Date object contained in the SDXMBean.
 *  
 * @author Matt Nelson
 */
public interface SDMXBean extends Serializable {

	/**
	 * Returns the structure type of this component.
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getStructureType();
	
	/**
	 * returns a readable type for this structure
	 */
	String getStructureName();
	
	/**
	 * Returns the parent that this SDMXBean belongs to 
	 * <p/>
	 * If this is a MaintainableBean, then there will be no parent to return, so will return a value of null
	 * @return
	 */
	SDMXBean getParent();
	
	/**
	 * Returns the first identifiable parent of this SDMXBean
	 * <p/>
	 * If this is a MaintainableBean, then there will be no parent to return, so will return a value of null
	 * @return
	 */
	IdentifiableBean getIdentifiableParent();
	
	/**
	 * Adds cross references for this bean to the set
	 * @param references adds the cross references to the set
	 */
	void getCrossReferences(Set<ICrossReferenceBeanBase> references);

	
	/**
	 * A SDMXBean has an optional key, this can be used for sorting and comparing.  For example a key for an Identifiable structure will be the URN
	 * the key for a TextType will be the locale, the key allows Beans to be compared without having to know their underlying type.
	 * 
	 * This method may return null 
	 * 
	 * @return
	 */
	String getKey();
	
	/**
	 * Returns a set of Strings for the supported languages for this SdmxBean
	 * 
	 * The returned set is immutable so can not be modified externally
	 * @return
	 */
	Set<String> getSupportedLanguages();
	
	/**
	 * Recurses up the parent hierarchy to return the first occurrence of parent of the given type that this SDMXBean belongs to 
	 * <p/>
	 * If a parent of the given type does not exist in the hierarchy, null will be returned
	 * @param includeThisInSearch if true then this type will be first checked to see if it is of the given type
	 * @return
	 */
	<T> T getParent(Class<T> type, boolean includeThisInSearch);
	
	/**
	 * Returns a set of composite beans to this bean
	 * @return
	 */
	Set<SDMXBean> getComposites();
	
	/**
	 * Returns any composites of this SdmxBean of the given type
	 * @param <T>
	 * @param type
	 * @return
	 */
	<T> Set<T> getComposites(Class<T> type);
	
	/**
	 * Returns true if this SdmxBean equals the given bean in every respect (except for the validTo property of a maintainable artefact, this is not taken into consideration)
	 * <p/>
	 * This method calls deepEquals on any SdmxBean composites.
	 * 
	 * @param bean if null, then false will be returned
	 * @param includeFinalProperties - if true, then this method will check every single property from this bean is 
	 * equal to the passed in bean.  If false, then this method will ignore the following properties:
	 *  <ul>
	 *    <li>Name</li>
	 *    <li>Description</li>
	 *    <li>Annotation</li>
	 *    <li>Valid From (Start Date)</li>
	 *    <li>Valid To (End Date)</li>
	 *    <li>Structure URL</li>
	 *    <li>Service URL</li>
	 *    <li>URI</li>
	 *    <li>Is External Reference</li>
	 *  </ul>
	 * 
	 * @return
	 */
	boolean deepEquals(SDMXBean bean, boolean includeFinalProperties);
	
	/**
	 * Same as deepEquals but also populates the diffReport with differences, if diffReport is not null.
	 * @param bean
	 * @param includeFinalProperties
	 * @param diff
	 * @return
	 */
	boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff);
	
	
}
