
package io.sdmx.api.sdmx.model.beans.reference.complex;


/**
 * Defines the structure parameters for querying for a structure
 * @see ComplexStructureQuery
 */
@Deprecated //unused
public interface ComplexStructureReferenceBean extends ComplexNameableReference {

	/**
	 * Returns the Id of the maintainable item to be returned
	 * @return
	 */
	ComplexTextReference getId();
	

	/**
	 * Returns the agencyId of the maintainable item  to be returned
	 * @return
	 */
	ComplexTextReference getAgencyId();
	
	/**
	 * Returns the version reference for the maintainable item to be returned
	 * @return
	 */
	ComplexVersionReference getVersionReference(); 
	
	/**
	 * Returns the child reference
	 */
	ComplexIdentifiableReferenceBean getChildReference();
	
}
