package io.sdmx.api.sdmx.model.beans;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;

/**
 * A container used to carry the information required to read a metadataset, MSD and Metadataflow are mandatory 
 * other structures are optional
 */
public interface IMetadatasetStructures {

	/**
	 * @return the MSD needed to read the metadata.  This will always return a MSD and may never be null
	 */
	MetadataStructureDefinitionBean getMetadataStructure();

	/**
	 * @return the Metadataflow that the MSD is reported against, this will not return null 
	 */
	MetadataFlowBean getMetadataflow();

	/**
	 * @return optional Metadata Provision Agreement
	 */
	MetadataProvisionAgreementBean getProvisionAgreement();

	/**
	 * @return optional Metadata Provider
	 */
	IMetadataProviderBean getDataProvider();
	
	/**
	 * @return highest level constrainable - either the provision if not null, dataflow if not null, or dsd
	 */
	default ConstrainableBean getConstrainable() {
		if(getProvisionAgreement() != null) { return getProvisionAgreement(); }
		if(getMetadataflow() != null) { return getMetadataflow(); }
		return getMetadataStructure();
	}

}
