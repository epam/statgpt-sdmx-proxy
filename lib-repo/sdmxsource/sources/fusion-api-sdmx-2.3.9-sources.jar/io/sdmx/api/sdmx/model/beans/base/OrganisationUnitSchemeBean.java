
package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;

/**
 * Represents an SDMX OrganisationUnitScheme
 * @author Matt Nelson
 *
 */
public interface OrganisationUnitSchemeBean extends OrganisationSchemeBean<OrganisationUnitBean>, INoCrossReferencesMaintainableBean {
	static final String FIXED_VERSION = "1.0";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<OrganisationUnitSchemeBean> getURN();
	
	/**
	 * Returns an mutable representation of itself
	 */
	@Override
	OrganisationUnitSchemeMutableBean getMutableInstance();
}
