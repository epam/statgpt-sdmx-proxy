
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;


public interface HierarchicalItemMutableBean<T extends ItemMutableBean> extends ItemMutableBean {

	/**
	 * Returns any child items, if non exist then an empty list is returned
	 * @return
	 */
	List<T> getItems();
	
	/**
	 * Returns any child items, if non exist then an empty list is returned
	 * @return
	 */
	void setItems(List<T> items);
	
	/**
	 * Adds an item
	 * @param item
	 */
	void addItem(T item);
	
}
