package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

/**
 * Details a name personalisation that is used in a transformation
 */
public interface INamePersonalisationBean extends ItemBean, INoCrossReferencesBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<INamePersonalisationBean> getURN();
	
	/**
	 * Identifies the type of VTL model artefact that is being personalised.  In VTL 2.0, this is valuedomain or variable
	 * @return not null
	 */
	String getVtlArtefact();
	
	/**
	 * Provides the VTL standard name that is being personalised
	 * @return not null
	 */
	String getVtlDefaultName();
	
	/**
	 * Provides the personalised name that is used in place of the VTL standard name in the transformation expression
	 * @return not null
	 */
	String getPersonalisedName();
	
}
