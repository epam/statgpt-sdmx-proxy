
package io.sdmx.api.sdmx.model.mutable.mapping;

import java.util.List;


@Deprecated
public interface CategorySchemeMapMutableBean extends ItemSchemeMapMutableBean<ItemMapMutableBean> {

	List<CategoryMapMutableBean> getCategoryMaps();
	
	void setCategoryMaps(List<CategoryMapMutableBean> categoryMaps);
	
	void addCategoryMap(CategoryMapMutableBean categoryMap);
	
}
