package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;

public interface IRulesetSchemeMutableBean extends IVtlSchemeMutableBean<IRulesetMutableBean> {
	/**
	 * @return optional reference to a VTL mapping scheme which defines aliases for given SDMX artefacts that are used in the rulesets.  Rulesets 
	 * defined on the value domains reference Codelists or Concept Schemes (the latter in VTL are considered as the Value Domains of the variables corresponding to the 
	 * SDMX Measure Dimensions). The rulesets defined on varaibles reference Concepts (for which a definite representation is assumed).  There fore
	 * a ruleset should only refer to Codelists, Concept Schemes, an Concepts
	 */
	StructureReferenceBean getVtlMappingSchemeRef();
	void setVtlMappingSchemeRef(StructureReferenceBean  ref);
	
	/**
	 * adds and returns a new IRulesetMutableBean
	 * @param id
	 * @param rulesetDefinition
	 * @param rulesetType
	 * @param getRulesetScope
	 * @return
	 */
	IRulesetMutableBean addRuleSet(String id, String rulesetDefinition, String rulesetType, String rulesetScope);
	
	
	@Override
	IRulesetSchemeBean getImmutableInstance();
}
