
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;


public interface CubeRegionBean extends SdmxStructureBean, INoCrossReferencesBean {

	List<KeyValues> getKeyValues();
	
	List<KeyValues> getAttributeValues();
	
	/**
	 * Returns the KeyValues for the given componentId
	 * @param componentId
	 * @return
	 */
	KeyValues getKeyValues(String componentId);
	
	
	/**
	 * Returns the cascade values for the component with the given id or an empty set if there are none specified for the component
	 * A cascade value, for example EUR could also be in the getValues set, in which case it equates to cascade and include root, if it is only in the cascade
	 * set, it equates to cascade but exclude root
	 * @param componentId
	 * @return
	 */
	Set<String> getCascadeValues(String componentId);
	
}
