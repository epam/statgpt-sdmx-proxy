
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.Date;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;


/**
 * Defines a notification event sent out from a registry.  The notification contains reference to the object that
 * caused the notification to occur.  In the case of an identifiable the object urn is provided, from which the object
 * can be queries.  In the case of a Registration, which has no URN the registration itself is sent inside the NotificationEvent.
 * @author Matt Nelson
 *
 */
public interface NotificationEvent {
	
	/**
	 * Returns the time that the event was created
	 * @return
	 */
	Date getEventTime();

	/**
	 * Returns the urn of the object that caused the notification event to be created (no applicable for registrations)
	 * @return
	 */
	String getObjectUrn();
	
	/**
	 * Returns the urn of the subscription that this notification event was triggered from
	 * @return
	 */
	String getSubscriptionUrn();
	
	/**
	 * Returns the action on the object that this event was triggered from
	 * @return
	 */
	DATASET_ACTION getAction();
	
	/**
	 * Returns the Registaration that triggered thiws event.  This can be null if it was not a registartion that triggered the 
	 * event.
	 * @return
	 */
	RegistrationBean getRegistration();

	/**
	 * Returns the structures contained in this subscription
	 * @return
	 */
	SdmxBeans getBeans();
}
