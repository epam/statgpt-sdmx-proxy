package io.sdmx.api.sdmx.model.mutable.refmetadata;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Represents a metadata set which is reported aganist a {@link MetadataProvisionAgreementBean}
 */
public interface IReportedMetadataSetMutableBean extends MaintainableMutableBean {

	/**
	 * @return reference to the provision agreement or dataflow that this metadata set is reported against
	 */
	StructureReferenceBean getStructure();
	IReportedMetadataSetMutableBean setStructure(StructureReferenceBean ref);
	
	/**
	 * @return target structures (optionally wildcarded) for which the report is against
	 */
	List<StructureReferenceBean> getTargets();
	IReportedMetadataSetMutableBean setTargets(List<StructureReferenceBean> targets);
	IReportedMetadataSetMutableBean addTarget(StructureReferenceBean target);
	
	/**
	 * @return list of attributes in the report
	 */
	List<IReportedMetadataAttributeMutableBean> getAttributes();
	IReportedMetadataSetMutableBean setAttributes(List<IReportedMetadataAttributeMutableBean> attrs);
	IReportedMetadataSetMutableBean addAttribute(IReportedMetadataAttributeMutableBean attr);
	
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	IReportedMetadataSetBean getImmutableInstance();
}
