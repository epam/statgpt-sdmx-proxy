package io.sdmx.api.sdmx.model.beans.base;

import java.util.Collection;

import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;

/**
 * Represents an SDMX AgencyScheme
 * @author Matt Nelson
 */
public interface AgencySchemeBean extends OrganisationSchemeBean<AgencyBean> {
	static final String DEFAULT_SCHEME = "SDMX"; // AgencyId
	static final String FIXED_ID = "AGENCIES";
	static final String FIXED_VERSION = "1.0";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<AgencySchemeBean> getURN();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	AgencySchemeMutableBean getMutableInstance();
	
	/**
	 * Returns true if the agency Id of the scheme is that same as AgencySchemeBean.DEFAULT_SCHEME
	 * @return
	 */
	boolean isDefaultScheme();
	

	/**
	 * Returns a new AgencySchemeBean based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @return
	 */
	AgencySchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet);
	
}
