package io.sdmx.api.sdmx.model.beans.reference;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;


/**
 * A resolved Cross Reference is a {@link ICrossReferenceBean} where the IdentifiableBean that is being referenced has been resolved 
 * 
 * ICrossReferenceBeanResolved may become out of date if external structures change, for example if the original reference is using a semantic 
 * late bind syntax (latest v1.0.+)
 */
public interface ICrossReferenceBeanResolved<T extends IdentifiableBean> extends ICrossReferenceBean<T> {

	/**
	 * @return not null, the reference to the given structure 
	 */
	@Override 
	IURNAbsolute<T> getReference();

	/**
	 * @return the resolved {@link IdentifiableBean}
	 */
	IdentifiableBean getResolvedBean();
	
	/**
	 * @return the underlying cross reference for which this absolute cross reference was built
	 */
	ICrossReferenceBean<T> getBaseReference();

}
