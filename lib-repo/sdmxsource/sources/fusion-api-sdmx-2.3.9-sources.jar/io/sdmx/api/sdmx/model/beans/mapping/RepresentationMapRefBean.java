
package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;


/**
 * Represents an SDMX Representation Map
 * @author Matt Nelson
 *
 */
public interface RepresentationMapRefBean extends SdmxStructureBean, INoCrossReferencesBean {
	
	CodelistMapBean getCodelistMap();

	TextFormatBean getToTextFormat();

	TO_VALUE getToValueType();

	Map<String, Set<String>> getValueMappings();
	
	@Override
	StructureSetBean getMaintainableParent();

}
