package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface ITransformationMutableBean extends ItemMutableBean {


	/**
	 * @return true if the result is permanently stored. A persistent result can be used by transformation defines in
	 * other transformation schemes, but a non-persistent result can only be used by transformations within the same transformation scheme
	 */
	boolean isPersistent();
	void setPersistent(boolean persistent);

	/**
	 * @return not null - the left hand side of the VTL statement.  This identifies the result artefact which may be used in subsequent transformations
	 * If the result is an SDMX Artefact this is expressed using the alias; see Section 6 SDMX Standards ("Abbreviation of the URN").
	 */
	String getResult();
	void setResult(String result);
	
	/**
	 * The right hand side of the VTL statement. This is the expression that is executed for this transformation. It includes references to operands and other
	 * artefacts.  The expression may contain references to SDMX artefacts using the reduced URN format; see Section 6 SDMX Standards ("Abbreviation of the URN").
	 * 
	 * @return not null 
	 */
	String getExpression();
	void setExpression(String expression);
	
}
