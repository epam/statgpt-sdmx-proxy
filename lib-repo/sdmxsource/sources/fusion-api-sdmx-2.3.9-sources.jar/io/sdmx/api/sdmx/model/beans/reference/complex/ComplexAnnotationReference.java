
package io.sdmx.api.sdmx.model.beans.reference.complex;

/**
 * ComplexAnnotationReference is used to reference annotations
 */
@Deprecated //unused
public interface ComplexAnnotationReference {

	/**
	 * A reference parameter to the annotation type - this can be null
	 * @return
	 */
	ComplexTextReference getTypeReference();
	
	/**
	 * A reference parameter to the annotation title - this can be null
	 * @return
	 */
	ComplexTextReference getTitleReference();
	
	/**
	 * A reference parameter to the annotation text - this can be null
	 * @return
	 */
	ComplexTextReference getTextReference();
	
	
}
