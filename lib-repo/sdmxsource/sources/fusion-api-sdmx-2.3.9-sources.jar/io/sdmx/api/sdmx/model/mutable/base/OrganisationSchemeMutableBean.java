
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;

public interface OrganisationSchemeMutableBean<T extends OrganisationMutableBean> extends ItemSchemeMutableBean<T> {

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	OrganisationSchemeBean<?> getImmutableInstance();
}
