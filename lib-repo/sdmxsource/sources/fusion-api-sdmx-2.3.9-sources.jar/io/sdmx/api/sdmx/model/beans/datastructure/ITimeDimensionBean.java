package io.sdmx.api.sdmx.model.beans.datastructure;

public interface ITimeDimensionBean extends DimensionBean {

	/**
	 * This is the time dimension
	 */
	@Override
	default boolean isTimeDimension() {
		return true;
	}
	
}
