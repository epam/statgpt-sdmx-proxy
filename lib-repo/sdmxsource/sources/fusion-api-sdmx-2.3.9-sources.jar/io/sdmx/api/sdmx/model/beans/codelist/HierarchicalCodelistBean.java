
package io.sdmx.api.sdmx.model.beans.codelist;

import java.net.URL;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;

@Deprecated
/**
 * Represents an SDMX Hierarchical Code List
 * @deprecated replaced in SDMX v3.0 with {@link HierarchyBean}
 */
public interface HierarchicalCodelistBean extends MaintainableBean {

    /**
     * Returns any child hierarchies as a copy of the underlying list.
     * <p/>
     * Returns an empty list if no child hierarchies exist
     * @return
     */
    List<HierarchyBean> getHierarchies();

    /**
     * Returns any CodelistRefBeans as a copy of the underlying list.
     * <p/>
     * Returns an empty list if no CodelistRefBean exist
     * @return
     */
    List<CodelistRefBean> getCodelistRef();

    /**
     * Returns the alias of the codelist with the given URN or null if there is no alias for this codelist
     * @param codelistURN
     * @return
     */
    String getCodelistAlias(String codelistURN);

    /**
     * Returns a stub reference of itself.
     * <p/>
     * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
     * contained within the Maintainable
     * @return
     * @param actualLocation the URL indicating where the full structure can be returned from
     * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
     * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
     */
    @Override
    HierarchicalCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

    /**
     * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
     * are not reflected in the instance of the MaintainableBean.
     * @return
     */
    @Override
    HierarchicalCodelistMutableBean getMutableInstance();

    /**
     * Clone this Hierarchical Codelist for the date specified.
     * This will return a version of this Hierarchical Codelist, with the items contained only being valid for the date specified.
     * @param date
     * @return
     */
    HierarchicalCodelistBean cloneForDate(Date aDate);
}