
package io.sdmx.api.sdmx.model.beans.categoryscheme;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;


/**
 * Represents an SDMX Categorisation
 * @author Matt Nelson
 *
 */
public interface CategorisationBean extends MaintainableBean {
	

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<CategorisationBean> getURN();
	
	/**
	 * Returns a reference to the structure that this is categorising - this can not be null
	 * @return
	 */
	ICrossReferenceBean<?> getStructureReference(); 
	
	/**
	 * Returns a reference to the category that is categorising the structure - this can not be null
	 * @return
	 */
	ICrossReferenceBean<CategoryBean> getCategoryReference();
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are 
	 * contained within the Maintainable
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	CategorisationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	CategorisationMutableBean getMutableInstance();
}
