package io.sdmx.api.sdmx.model.mutable.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Contains a set of conditional rules for an attribute
 *
 */
public interface ReportingTemplateConditionalAttributeMutableBean extends MutableBean {

	/**
	 * Returns the attribute id
	 * @return
	 */
	String getAttributeId();
	void setAttributeId(String attId);
	
	/**
	 * Returns the set of output attribute values for the given conditions 
	 * @return
	 */
	List<ConditionalAttributeMappingBeanMutableBean> getConditions();
	void setConditions(List<ConditionalAttributeMappingBeanMutableBean> conditions);
	void addCondition(ConditionalAttributeMappingBeanMutableBean condition);
	
}
