
package io.sdmx.api.sdmx.model.beans.codelist;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;

/**
 * Represents an SDMX Hierarchy, belonging to a HierarchicalCodelist
 */
public interface HierarchyBean extends MaintainableBean, INoCrossReferencesBean  {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<HierarchyBean> getURN();
	
	/**
	 * Clones this structure, removing any hieaararchical codes which are not valid for the date passed in
	 * @param aDate
	 * @return
	 */
	HierarchyBean cloneForDate(Date aDate);

	/**
	 * @return the child Hierarchical Codes for this hierarchy, returns an empty list if there are no children
	 */
	List<HierarchicalCodeBean> getHierarchicalCodeBeans();
	
	/**
	 * @return the level for this hierarchy, returns null if there is no level
	 */
	LevelBean getLevel();
	
	/**
	 * Returns the LevelBean at the position indicated, by recursing the LevelBean hierarchy of this Hierarchy bean, returns null if there is no level
	 * @param levelPos
	 * @return the level at the given hierarchical position (1 indexed) - returns null if there is no level at that position
	 */
	LevelBean getLevelAtPosition(int levelPos);
	
	/**
	 * returns the level with the given id, period separated
	 * @param levelId
	 * @return
	 */
	LevelBean getLevelById(String levelId);
	
	/**
	 * If true this indicates that the hierarchy has formal levels. In this case, every code should have a level associated with it.
	 * 
	 * If false this does not have formal levels.  This hierarchy may still have levels, getLevel() may still return a value, the levels are not formal and the call to a code for its level may return null.
	 * 
	 */
	boolean hasFormalLevels();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	HierarchyMutableBean getMutableInstance();
}
