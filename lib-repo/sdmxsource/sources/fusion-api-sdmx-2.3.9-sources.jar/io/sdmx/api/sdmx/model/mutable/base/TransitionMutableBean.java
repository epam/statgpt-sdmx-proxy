
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;



public interface TransitionMutableBean extends IdentifiableMutableBean {
	
	String getTargetStep();
	
	List<TextTypeWrapperMutableBean> getConditions();
	
	void setTargetStep(String targetStep);
	
	void addCondition(TextTypeWrapperMutableBean condition);
	
	void setConditions(List<TextTypeWrapperMutableBean> condition);

	String getLocalId();

	void setLocalId(String localId);
}
