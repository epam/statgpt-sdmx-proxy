package io.sdmx.api.sdmx.model.beans.validityperiod;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;

/**
 * For ItemSchemes that are able to contain items that have validity periods
 */
public interface ValidatableBean<T extends ItemBean> extends ItemSchemeBean<T> {
	/**
	 * Returns whether this instance was created by a request for a specific point in time.
	 * For example, if the instance was constructed via new() then this should returned false.
	 * However if the instance was constructed via a cloneForDate() method then this should return true.
	 */
	boolean createdFromTimeRequest();

	/**
	 * return the validity Type
	 * @return
	 */
	MAINT_VALIDITY_TYPE getValidityType();
}