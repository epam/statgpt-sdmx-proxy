
package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;

/**
 * Represents an SDMX Structure Map at SDMX version 2.1, deprecated in SDMX version 3.0
 * @deprecated use {@link IStructureMapBean} 
 */
public interface StructureMapBean extends SchemeMapBean {

	List<ComponentMapBean> getComponents();
	
	boolean isExtension();
}
