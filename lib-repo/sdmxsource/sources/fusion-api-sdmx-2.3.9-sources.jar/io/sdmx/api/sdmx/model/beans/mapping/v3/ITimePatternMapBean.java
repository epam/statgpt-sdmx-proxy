package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 *  <p>A specialisation of {@link ITimeComponentMapBean} used to describe a string representation of time, and how this maps to SDMX Time Periods.</p>
 *  <br/>  
 *  <p>Describes the patterns for each supported time representation e.g. 2002 31 12 could be expressed as YYYY DD MM<p/>
 */
public interface ITimePatternMapBean extends ITimeComponentMapBean, INoCrossReferencesBean {

	/**
	 * @return the pattern to match
	 */
	String getPattern();
	
	/**
	 * @return pattern locale, default en
	 */
	String getLocale();
	
}
