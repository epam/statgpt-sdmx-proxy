
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;


/**
 * Represents an SDMX Dimension List
 * @author Matt Nelson
 *
 */
public interface DimensionListBean extends IdentifiableBean, INoCrossReferencesBean {
	static final String FIXED_ID = "DimensionDescriptor";
	
	/**
	 * Returns the list of dimensions that this dimension list is holding.
	 * <p/>
	 * The returned list will be a copy of the underlying list, and is expected to have at least one DimensionBean
	 * @return
	 */
	List<DimensionBean> getDimensions();
	
}
