
package io.sdmx.api.sdmx.model.beans.reference;

import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * A more specific type of Cross Reference which references a single structure either by semantic or absolute reference
 */
public interface ICrossReferenceBean<T extends IdentifiableBean> extends ICrossReferenceBeanBase { 

	/**
	 * @return not null, the target identifiable structure that is being referenced
	 */
	IURNSingle<T> getReference();
	
	/**
	 * An indirect reference is one where a structure indirectly references another structure, for example a Constraint indirectly references a Dimension and Codes in a Codelist
	 * 
	 * @return true if the reference is indirect
	 */
	boolean isIndirectReference();
	
	/**
	 * A weak reference is one which is derived at run time by assessing pattern matching rules on references.  The reference is weak because it should not prevent
	 * any structure from being deleted if it is weakly referenced
	 * 
	 * @return true if the reference is weak
	 */
	boolean isWeakReference();
	
	/**
	 * @return mutable reference
	 */
	default StructureReferenceBean asMutable() {
		return getReference().asMutable();
	}
	
}
