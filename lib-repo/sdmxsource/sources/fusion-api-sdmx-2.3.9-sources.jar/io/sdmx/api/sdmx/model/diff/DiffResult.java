package io.sdmx.api.sdmx.model.diff;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;

/**
 * Describes the differences between two maintainable structures
 */
public interface DiffResult {

	/**
	 * Returns the MaintainableBean that is providing the comparison from
	 * @return
	 */
	MaintainableBean getCompareFrom();

	/**
	 * Returns the MaintainableBean that is providing the comparison to
	 * @return
	 */
	MaintainableBean getCompareTo();

	/**
	 * Returns true if there were modifications to the Maintainable, false if the two structures are identical
	 * @return
	 */
	boolean hasModifications();

	/**
	 * Returns the modifications made to the compare from when comparing it to the compare to
	 * @return
	 */
	Set<IdentifiableModification> getModifications();

	/**
	 * Describes a modification by its type
	 */
	interface Modification {
		/**
		 * Returns the type of modification (add/delete/edit)
		 * @return
		 */
		ModificationAction getModification();
	}


	/**
	 * Defines a modification to a structure, for example
	 * a ProcessStepBean which is Identifiable may have had new InputOutputBean added, these are not identifiable, they are
	 * of type SDMXBean.
	 *
	 * The super interface describes the modification type (add, delete, edit)
	 *
	 * @author mnelson
	 *
	 */
	interface StructureModification extends Modification {

		/**
		 * Get the modified structure
		 * @return
		 */
		SDMXBean getStructure();

		/**
		 * Returns true if there are text modifications
		 * @return
		 */
		boolean hasTextModification();

		/**
		 * Returns true if there are attribute modifications
		 * @return
		 */
		boolean hasAttributeModification();

		/**
		 * Returns a set of all the text modifications, or null if there are none
		 * @return
		 */
		Set<TextModification> getTextModification();

		/**
		 * Returns a set of all the attribute modifications, or null if there are none
		 * @return
		 */
		Set<AttributeModification> getAttributeModification();

	}

	/**
	 * Describes the difference between two identifiable structures
	 *
	 */
	interface IdentifiableModification extends StructureModification {

		/**
		 * Returns the new identifiable,
		 * @return
		 */
		IdentifiableBean getIdentifiable();

		/**
		 * Returns true if there are structure modificaitons for this identifiable (for example a CodeBean may have modifications to Annotations)
		 * @return
		 */
		boolean hasStructureModification();

		/**
		 * Returns modifications to 'sub structures' which are not identifiable, such as annotations
		 * @return
		 */
		Set<StructureModification> getStructureModification();
	}

	/**
	 * Returns the modified text
	 * @author mnelson
	 *
	 */
	interface TextModification extends Modification {

		/**
		 * Returns the text that was modified (null indicates a delete)
		 * @return
		 */
		TextTypeWrapper getNewText();

		/**
		 * Returns the previous version (null indicates an addition)
		 * @return
		 */
		TextTypeWrapper getOldText();
	}

	/**
	 * Defines a modification to a structure
	 * @author mnelson
	 *
	 */
	interface AttributeModification extends Modification {

		/**
		 * Returns the attribute name that was modified
		 * @return
		 */
		String getAttributeName();

		/**
		 * Returns the new value (null would indicate a delete)
		 * @return
		 */
		String getNewValue();

		/**
		 * Returns the old value (null indicates an addition)
		 * @return
		 */
		String getOldValue();
	}

}
