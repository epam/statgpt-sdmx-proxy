
package io.sdmx.api.sdmx.model.mutable.base;

public interface DataSourceMutableBean extends MutableBean {

	boolean isRESTDatasource();
	
	void setRESTDatasource(boolean restDatasource);
	
	boolean isWebServiceDatasource();
	
	void setWebServiceDatasource(boolean webServiceDatasource);
	
	boolean isSimpleDatasource();
	
	void setSimpleDatasource(boolean simpleDatasource);
	
	String getDataUrl();
	
	void setDataUrl(String dataUrl);
	
	String getWSDLUrl();

	void setWSDLUrl(String wsdlUrl);
	
	String getWADLUrl();

	void setWADLUrl(String wadlUrl);
	
}
