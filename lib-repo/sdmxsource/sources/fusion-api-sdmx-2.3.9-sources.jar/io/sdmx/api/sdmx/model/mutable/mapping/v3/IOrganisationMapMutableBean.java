package io.sdmx.api.sdmx.model.mutable.mapping.v3;

/**
 * Represents an SDMX Organisation Map
 */
public interface IOrganisationMapMutableBean extends IItemMapMutableBean<IOrganisationMapMutableBean> {

}
