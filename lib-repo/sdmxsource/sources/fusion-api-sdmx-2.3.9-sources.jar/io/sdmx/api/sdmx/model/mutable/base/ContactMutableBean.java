
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;

public interface ContactMutableBean extends MutableBean {

	/**
	 * Returns the id of the contact
	 * @return the id, or null if there is no id
	 */
	String getId();
	
	/**
	 * Sets the id of the contact
	 */
	void setId(String id);
	
	/**
	 * Returns the names of the contact
	 * @return list of names, or an empty list if none exist
	 */
	List<TextTypeWrapperMutableBean> getNames();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setNames(List<TextTypeWrapperMutableBean>  names);

	/**
	 * Adds a new name to the list, creates a new list if it is null
	 * @param name
	 */
	void addName(TextTypeWrapperMutableBean name);

	/**
	 * Returns the roles of the contact
	 * @return list of roles, or an empty list if none exist
	 */
	List<TextTypeWrapperMutableBean> getRoles();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setRoles(List<TextTypeWrapperMutableBean> roles);

	/**
	 * Adds a new role to the list, creates a new list if it is null
	 * @param name
	 */
	void addRole(TextTypeWrapperMutableBean role);
	
	/**
	 * Returns the departments of the contact
	 * @return list of departments, or an empty list if none exist
	 */
	List<TextTypeWrapperMutableBean> getDepartments();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setDepartments(List<TextTypeWrapperMutableBean> depts);
	
	/**
	 * Adds a new department to the list, creates a new list if it is null
	 * @param name
	 */
	void addDepartment(TextTypeWrapperMutableBean role);
	
	/**
	 * Returns the email of the contact
	 * @return list of email, or an empty list if none exist
	 */
	List<String> getEmail();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setEmail(List<String> email);
	
	/**
	 * Adds a new email to the list, creates a new list if it is null
	 * @param name
	 */
	void addEmail(String email);

	/**
	 * Returns the fax of the contact
	 * @return list of fax, or an empty list if none exist
	 */
	List<String> getFax();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setFax(List<String> fax);
	
	/**
	 * Adds a new fax to the list, creates a new list if it is null
	 * @param name
	 */
	void addFax(String fax);

	/**
	 * Returns the telephone of the contact
	 * @return list of telephone, or an empty list if none exist
	 */
	List<String> getTelephone();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setTelephone(List<String> telephone);
	
	/**
	 * Adds a new telephone to the list, creates a new list if it is null
	 * @param name
	 */
	void addTelephone(String telephone);
	/**
	 * Returns the uris of the contact
	 * @return list of uris, or an empty list if none exist
	 */
	List<String> getUri();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setUri(List<String> uri);
	
	/**
	 * Adds a new uri to the list, creates a new list if it is null
	 * @param name
	 */
	void addUri(String uri);

	/**
	 * Returns the x400 of the contact
	 * @return list of emails, or an empty list if none exist
	 */
	List<String> getX400();
	
	/**
	 * Overwrites the existing list with the one passed in
	 * @param names
	 */
	void setX400(List<String> uri);
	
	/**
	 * Adds a new X400 to the list, creates a new list if it is null
	 * @param name
	 */
	void addX400(String uri);
	
	
	
}
