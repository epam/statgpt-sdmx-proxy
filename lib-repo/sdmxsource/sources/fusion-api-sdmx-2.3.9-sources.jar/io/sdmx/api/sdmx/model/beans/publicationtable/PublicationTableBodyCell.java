package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * represents an observation cell in the publication table
 */
public interface PublicationTableBodyCell extends Styleable, Numerical, SDMXBean, INoCrossReferencesBean {

	/**
	 * Returns the observation key, excluding time, for example
	 * Q:*:C:G:TO1:A:5J:A:5A:A:5J:N
	 * Q:*:C:G:TO1:A:5J:A:5A:A:5J:N
	 * Q:*:C:A:$TO1-USD-EUR-JPY-GBP-CHF-UN9:A:5J:A:5A:U:5J:N  showing calculated data
	 * 
	 * @return
	 */
	String getObservationKey();
	
	/**
	 * Returns true if the observation key contains a calculation expression
	 * @return
	 */
	boolean isCalculation();
	
	/**
	 * Returns true if the observation key is free text
	 * @return
	 */
	boolean isFreeText();
	
	/**
	 * Returns true if the is cell is an observation cell (the observation key is a series key and not a calculation expression or free text)
	 * @return
	 */
	boolean isObservation();
	
	/**
	 * returns an unmodifiable set of wildcarded positions in the key
	 * @return
	 */
	Set<Integer>  getVariableDimensions();
	
	/**
	 * Returns the column index, zero indexed
	 * @return
	 */
	int getColIdx();
	
	/**
	 * Returns the row index, zero indexed
	 * @return
	 */
	int getRowIdx();
	
	/**
	 * Takes a the row index and col index, and converts it to an Excel style alpha  for example A1, B1, C1, D1....AA1, AB1, AC1
	 * @param i
	 * @return
	 */
	String getAlphaIndex();
	
}
