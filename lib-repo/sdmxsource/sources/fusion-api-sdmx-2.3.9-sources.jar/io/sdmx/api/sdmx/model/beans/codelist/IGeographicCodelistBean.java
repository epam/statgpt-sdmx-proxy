package io.sdmx.api.sdmx.model.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;

import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;

/**
 * Geographic codelist - each code provides a geo feature set, representing a set of points defining 
 * a feature in a format defined a predefined pattern
 */
public interface IGeographicCodelistBean extends CodelistBean {

	@Override
	IGeographicCodelistBean cloneForDate(Date date);
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	IGeographicCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

	/**
	 * Returns the item with the given id, returns null if there is no item with the id provided
	 * @param id
	 * @return
	 */
	IGeoFeatureSetCodeBean getItemById(String id);

	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	IGeographicCodelistMutableBean getMutableInstance();

	/**
	 * Returns a new item scheme based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @return
	 */
	@Override
	IGeographicCodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet);

}
