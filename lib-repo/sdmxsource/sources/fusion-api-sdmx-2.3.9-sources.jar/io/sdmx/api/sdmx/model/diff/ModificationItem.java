package io.sdmx.api.sdmx.model.diff;

public interface ModificationItem {

	String getName();
	String getDescription();
	String getDate();
	String getUserId();
	String getAction();
	int getChangeCount();
	String getLinkLocation();
}
