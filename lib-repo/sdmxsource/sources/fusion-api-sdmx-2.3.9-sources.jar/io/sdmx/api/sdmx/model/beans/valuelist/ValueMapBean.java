package io.sdmx.api.sdmx.model.beans.valuelist;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * A value maps allows for ids, which do not have to be of IdType to map to a list of values, which can be accessed by id or position
 */
public interface ValueMapBean extends MaintainableBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ValueMapBean> getURN();
	
	/**
	 * Mandatory (can not be null or empty), can be used in queries (to obtain maps of type)
	 * 
	 * @return the type/purpose of this map, for example if it is storing css it might return 'css'
	 */
	String getType();

	/**
	 * Returns the mapping between a variable and the list of text representation
	 * 
	 * For example UK ->  
	 *   				A -> 50 Pounds
	 *   				B -> 20 Pounds
	 *   				C -> 10 Pounds
	 *   		   US ->  
	 *   				A -> 50 Dollars
	 *   				B -> 20 Dollars
	 *   				C -> 10 Dollars
	 * @return
	 */
	Map<String, List<VariableBean>> getValueMap();
	
}
