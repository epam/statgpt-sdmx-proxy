package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents a URN with absolute values (no late bind on the version, no wildcard/multiple references)
 */
public interface IURNAbsolute<K extends IdentifiableBean> extends IURNSingle<K> {

	/**
	 * Casts this type to the given type T if it is able to do so
	 * @param <T>
	 * @param type
	 * @return
	 * @throws IllegalArgumentException - if the type T is not assignable to the structure type this URN is referencing
	 */
	default <T extends IdentifiableBean> IURNAbsolute<T> toType(Class<T> type) {
		if(isType(type)) {
			return (IURNAbsolute<T>)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: " +type.getCanonicalName());
	}
	
	/**
	 * @return the full version, not semantic
	 */
	ISdmxVersion getAbsoluteVersion();
	
	/**
	 * @return fixed ABSOLUTE
	 */
	@Override
	default REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.ABSOLUTE;
	}
	
	@Override
	IURNMaintainable<?> getMaintainableURN();
}
