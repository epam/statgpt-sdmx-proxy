package io.sdmx.api.sdmx.model.mutable.calculation;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface ValidationSchemeMutableBean extends ItemSchemeMutableBean<ValidationRuleMutableBean> {

	/**
	 * Returns a reference to either the Dataflow or Provision Agreement that this scheme is defining rules for
	 * @return
	 */
	StructureReferenceBean getAttachment();
	
	/**
	 * Sets a reference to either the Dataflow or Provision Agreement that this scheme is defining rules for
	 * @return
	 */
	void setAttachment(StructureReferenceBean sRef);
	
	/**
	 * Adds a new validation rule
	 * @param ruleId
	 * @param ruleName
	 * @param result
	 * @param equality
	 * @param expression
	 * @return
	 */
	ValidationRuleMutableBean addValidationRule(String ruleId, String ruleName, String result, EQUALITY equality, String expression);
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	ValidationSchemeBean getImmutableInstance();
}
