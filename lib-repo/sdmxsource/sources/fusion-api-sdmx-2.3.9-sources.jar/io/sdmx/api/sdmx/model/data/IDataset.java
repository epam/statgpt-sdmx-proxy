package io.sdmx.api.sdmx.model.data;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;

public interface IDataset {

	/**
	 * 
	 * @return
	 */
	DataflowBean getDataflowBean();

	/**
	 * @return a read only map of the data
	 */
	Map<Keyable, List<Observation>> getData();
	
}
