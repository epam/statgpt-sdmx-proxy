
package io.sdmx.api.sdmx.model.superbeans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.superbeans.base.IdentifiableSuperBean;


/**
 * A group is a subset of the dimensionality of the full key.  It is purely to attach attributes.
 * @author Matt Nelson
 *
 */
public interface GroupSuperBean extends IdentifiableSuperBean<GroupBean> {

	List<DimensionSuperBean> getDimensions();
	
	DimensionSuperBean getDimensionById(String conceptId);
	
	ICrossReferenceBean getAttachmentConstraintRef();
	
}
