package io.sdmx.api.sdmx.model.beans;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;

/**
 * A container used to carry the information required to read a dataset, DSD is mandatory all other structures are optional
 */
public interface IDatasetStructures {

	/**
	 * @return the DSD needed to read the data.  This will always return a DSD and may never be null
	 */
	DataStructureBean getDataStructure();

	/**
	 * @return optional Dataflow
	 */
	DataflowBean getDataflow();

	/**
	 * @return optional Provision Agreement
	 */
	ProvisionAgreementBean getProvisionAgreement();

	/**
	 * @return optional Data Provider
	 */
	DataProviderBean getDataProvider();
	
	/**
	 * @return highest level constrainable - either the provision if not null, dataflow if not null, or dsd
	 */
	default IDSDRelatedBean getConstrainable() {
		if(getProvisionAgreement() != null) { return getProvisionAgreement(); }
		if(getDataflow() != null) { return getDataflow(); }
		return getDataStructure();
	}

	
}
