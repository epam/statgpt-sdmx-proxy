package io.sdmx.api.sdmx.model.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;

/**
 * Geographic codelist - each code provides a geo feature set, representing a set of points defining 
 * a feature in a format defined a predefined pattern
 */
public interface IGeographicCodelistMutableBean extends CodelistMutableBean {
	
	@Override
	IGeographicCodelistBean getImmutableInstance();
}
