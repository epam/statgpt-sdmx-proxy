
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;


public interface OrganisationUnitSchemeMutableBean extends OrganisationSchemeMutableBean<OrganisationUnitMutableBean> {


	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the OrganisationUnitSchemeBean.
	 * @return
	 */
	@Override
	OrganisationUnitSchemeBean getImmutableInstance();
	
}
