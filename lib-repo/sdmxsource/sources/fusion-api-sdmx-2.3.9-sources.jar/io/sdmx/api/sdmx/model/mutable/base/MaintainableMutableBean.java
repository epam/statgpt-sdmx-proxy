
package io.sdmx.api.sdmx.model.mutable.base;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface MaintainableMutableBean extends VersionableMutableBean {
	
	/**
	 * Sets all the properties on this maintainable from the bean passed in
	 * @param bean - to copy from
	 * @param includeInheritedProperties - if true, all properties will be set on the inherited interfaces
	 */
	void copyProperties(MaintainableBean bean, boolean includeInheritedProperties);
	void copyProperties(MaintainableMutableBean bean, boolean includeInheritedProperties);
	
	String getAgencyId();
	
	boolean getFinalStructure();
	
	boolean getExternalReference();
	
	boolean isStub();
	
	default MaintainableMutableBean setMaintainableProperties(IMaintainableProperties props) {
		setAgencyId(props.getAgencyId());
		setId(props.getId());
		setVersion(props.getVersion());
		return this;
	}
	
	MaintainableMutableBean changeIdentifiers(String agencyId, String id, String version);
	
	MaintainableMutableBean setStub(boolean isStub);
	
	MaintainableMutableBean setAgencyId(String agencyId);
	
	MaintainableMutableBean setFinalStructure(boolean isFinal);
	 
	MaintainableMutableBean setExternalReference(boolean isExternalReference);
	
	String getServiceURL();
	
	MaintainableMutableBean setServiceURL(String serviceURL);
	default MaintainableMutableBean setServiceURL(URL url) {
        if(url != null) {
            setServiceURL(url.toString());
        }
        return this;
    }
	
	MaintainableMutableBean setStructureURL(String structureURL);
    default MaintainableMutableBean setStructureURL(URL url) {
        if(url != null) {
            setStructureURL(url.toString());
        }
        return this;
    }
	
	String getStructureURL();
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	MaintainableBean getImmutableInstance();
	
}
