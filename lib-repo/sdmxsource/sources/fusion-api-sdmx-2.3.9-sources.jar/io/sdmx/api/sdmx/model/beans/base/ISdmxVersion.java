package io.sdmx.api.sdmx.model.beans.base;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.VERSION_PART;

/**
 * Represents a version number, with a minimum of 1 part, and a maximum of 3, where each part is period separated, e.g. 1, 1.0, 1.0.0
 * 
 * Comparable by returning +1 for a higher version, -1 for lower, and 0 for the same
 */
public interface ISdmxVersion extends Comparable<ISdmxVersion>, Serializable {
	
	/**
	 * Increments the version part to the next integer, i.e 1.12.5 incrementing on the minor would return 1.13.5
	 * @param part
	 * @return
	 */
	ISdmxVersion incrementVersion(VERSION_PART part);
	
	/**
	 * @return true if this version is later then the version passed in, a stable version is deemed later then a draft, drafts comparisons are based on a string compare of the suffix
	 */
	boolean isLater(ISdmxVersion version);
	
	/**
	 * @return true for a three part version with no suffix
	 */
	boolean isStable();

	/**
	 * @return true if the version only has 2 parts
	 */
	boolean isTwoPart();
	
	/**
	 * @return major version 
	 */
	int getMajor();

	/**
	 * @return minor version or -1 if there is no patch version
	 */
	int getMinor();
	
	/**
	 * @return patch version or -1 if there is no patch version
	 */
	int getPatch();
	
	/**
	 * If the version has a suffix, e.g. 1.2.1-draft
	 * 
	 * @return the version suffix, or null if there is not one
	 */
	String getSuffix();
	
	@Override
	/**
	 * @return version as string e.g. 1.2.3
	 */
	String toString();
	
}
