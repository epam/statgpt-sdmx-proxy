
package io.sdmx.api.sdmx.model.superbeans.categoryscheme;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;

/**
 * Wraps a categorisation bean, has all referenced structures by composition
 */
public interface CategorisationSuperBean extends MaintainableSuperBean<CategorisationBean> {

	/**
	 * Returns a the structure that this is categorising - this can not be null
	 * @return
	 */
	IdentifiableBean getStructure(); 
	
	/**
	 * Returns the category that is categorising the structure - this can not be null
	 * @return
	 */
	CategoryBean getCategory();
	
}
