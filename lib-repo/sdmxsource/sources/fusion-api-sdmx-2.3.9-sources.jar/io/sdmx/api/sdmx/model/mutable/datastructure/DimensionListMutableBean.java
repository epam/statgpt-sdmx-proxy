
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;


public interface DimensionListMutableBean extends IdentifiableMutableBean {

	List<DimensionMutableBean> getDimensions();
	
	void setDimensions(List<DimensionMutableBean> dimensions);
	
	void addDimension(DimensionMutableBean dimension);
	
}
