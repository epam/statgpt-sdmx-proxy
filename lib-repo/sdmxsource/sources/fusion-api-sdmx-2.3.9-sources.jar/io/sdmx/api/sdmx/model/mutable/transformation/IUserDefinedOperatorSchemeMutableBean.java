package io.sdmx.api.sdmx.model.mutable.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;

public interface IUserDefinedOperatorSchemeMutableBean extends IVtlSchemeMutableBean<IUserDefinedOperatorMutableBean> {

	/**
	 * References a VTL mapping scheme which defines aliases for given SDMX artefacts that are used in the user defined operators.
	 * ALthough the VTL user defined operators are concieved to be defined on generic operands, so that the specific artefacts to be manipulated
	 * are passed as parameters at the invocation, is is also possible that they reference specific c SDMX artefacts like Dataflows, Codelists, and 
	 * Concept Schemes. In this case, the mapping schemes referenced here defined the mappings to those artefacts
	 * @return optional
	 */
	StructureReferenceBean getVtlMappingSchemeRef();
	void setVtlMappingSchemeRef(StructureReferenceBean ref);

	/**
	 * References a rules set scheme defining rulesets utilized in the user defined operators
	 * @return immutable lists, nullable
	 */
	List<StructureReferenceBean> getRulesetSchemeRef();
	void setRulesetSchemeRef(List<StructureReferenceBean> ref);
	IUserDefinedOperatorSchemeMutableBean addRulesetSchemeRef(StructureReferenceBean ref);
	
	/**
	 * Adds a new {@link IUserDefinedOperatorMutableBean} to the list of items
	 * @param operator
	 * @return
	 */
	IUserDefinedOperatorMutableBean addUserDefinedOperator(String id, String operator);
	
	IUserDefinedOperatorSchemeBean getImmutableInstance();
	
}
