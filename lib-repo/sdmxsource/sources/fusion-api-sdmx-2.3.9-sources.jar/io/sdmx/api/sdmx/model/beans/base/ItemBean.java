
package io.sdmx.api.sdmx.model.beans.base;

/**
 * An Item is an abstract super type of elements such as <code>CodeBean</code> and must exist within an ItemScheme such as
 * a <code>CodeListBean</code>
 * @author Matt Nelson
 *
 */
public interface ItemBean extends NameableBean {

	/**
	 * Returns the position of the item in the list of items, 1 indexed
	 * @return
	 */
	int getPosition();

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<? extends ItemBean> getURN();
	
}
