package io.sdmx.api.sdmx.model.beans.reference;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Acts as a filter on maintainable beans
 */
public interface IMultiMaintainableRef {

	/**
	 * @return an immutable set of valid agencies that the structure can be owned by, or an empty set to indicate any
	 */
	Set<String> getAgencyId();
	
	default boolean hasAgency() {
		return !getAgencyId().isEmpty();
	}
	
	/**
	 * A match is if any of the following are true:
	 * 1. no agency id passed in
	 * 2. no agency id in this filter
	 * 3. one agency id in the filter matches
	 * 
	 * @param agencyId
	 * @return
	 */
	default boolean agencyMatch(String agencyId) {
		return agencyId == null || getAgencyId().size() == 0 || getAgencyId().contains(agencyId);
	}
	
	/**
	 * @return an immutable set of IDs that the structure has, or an empty set to indicate any
	 */
	Set<String> getId();
	
	default boolean hasId() {
		return !getId().isEmpty();
	}
	
	/**
	 * A match is if any of the following are true:
	 * 1. no id passed in
	 * 2. no id in this filter
	 * 3. one id in the filter matches
	 * 
	 * @param agencyId
	 * @return
	 */
	default boolean idMatch(String id) {
		return id == null || getId().size() == 0 || getId().contains(id);
	}
	
	/**
	 * @return the version(s) of the maintainables to return
	 */
	IVersionRef getVersion();
	
	/**
	 * @return true if this query is for all structures (no filters)
	 */
	default boolean isAll() {
		return !hasAgency() && !hasId() && getVersion().isAll();
	}
	
	/**
	 * @param maintainable
	 * @return true if the maintainable passed in matches the rules of this reference
	 */
	boolean isMatch(MaintainableBean maint);
}
