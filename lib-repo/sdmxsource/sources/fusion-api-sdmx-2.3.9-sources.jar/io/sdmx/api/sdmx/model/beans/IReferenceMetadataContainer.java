package io.sdmx.api.sdmx.model.beans;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;

/**
 * A container for 0 to many reference metadata reports
 */
public interface IReferenceMetadataContainer extends IMetadataContainer {
	
	/**
	 * @return the number of reports
	 */
	default int reportCount() {
		return getReferenceMetadata().size();
	}

	/**
	 * @return the metadata sets in this container
	 */
	Set<IReportedMetadataSetBean> getReferenceMetadata();
	
	/**
	 * Add a metadata set into thihs container
	 * @param metadataSet
	 */
	void addReferenceMetadata(IReportedMetadataSetBean metadataSet);
	
	/**
	 * Merge the metadata sets from the given container into this one
	 * @param container
	 */
	default void merge(IReferenceMetadataContainer container) {
		if(container != null) {
			for(IReportedMetadataSetBean set : container.getReferenceMetadata()) {
				addReferenceMetadata(set);
			}
		}
	}
}
