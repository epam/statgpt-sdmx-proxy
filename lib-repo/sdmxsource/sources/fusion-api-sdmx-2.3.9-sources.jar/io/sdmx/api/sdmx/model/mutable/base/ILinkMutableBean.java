package io.sdmx.api.sdmx.model.mutable.base;

import java.net.URI;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURN;

public interface ILinkMutableBean {

	/**
	 * @return not null - The type of object that is being linked to
	 */
	String getRel();
	ILinkMutableBean setRel(String rel);
	
	/**
	 * @return not null - the URL of the object being linked
	 */
	URI getUrl();
	ILinkMutableBean setUrl(URI rel);
	
	/**
	 * @return optional - a registry URN of the object being linked
	 */
	IURN<?> getUrn();
	ILinkMutableBean setUrn(IURN<?> urn);
	
	/**
	 * @return optional - the type of link (e.g. The type of link (e.g. PDF, text, HTML, reference metadata)
	 */
	String getType();
	ILinkMutableBean setType(String type);
	
	/**
	 * Adds a name, edits the current value if the locale already exists
	 * @param locale
	 * @param name
	 */
	void addTitle(String locale, String name);
	void addTitle(TextTypeWrapperMutableBean text);
	List<TextTypeWrapperMutableBean> getTitles();

}
