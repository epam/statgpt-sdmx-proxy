package io.sdmx.api.sdmx.model.beans.base;

import java.net.URI;
import java.util.List;

/**
 * Allows for the linking of other resources to identifiable objects. 
 * 
 * For example, if there is reference metadata associated with a structure, a link to the metadata report can be dynamically inserted in the structure metadata.
 */
public interface ILinkBean {

	/**
	 * @return not null - The type of object that is being linked to
	 */
	String getRel();
	
	/**
	 * @return not null - the URL of the object being linked
	 */
	URI getHRef();
	
	/**
	 * @return optional - the URL of the object being linked
	 */
	URI getUri();
	
	/**
	 * @return optional - a registry URN of the object being linked
	 */
	IURN getUrn();
	
	/**
	 * @return optional - the type of link (e.g. The type of link (e.g. PDF, text, HTML, reference metadata)
	 */
	String getType();
	

	/**
	 * @param disableLocaleFilter if true, all titles will be returned, if false, if a LocaleFilter is in effect then the returned List may be filtered by Locale
	 * @return not null list of titles 
	 */
    List<TextTypeWrapper> getTitles(boolean disableLocaleFilter);

	/**
	 * @return optional title in the default locale
	 */
	String getTitle();
	

	/**
	 * @return optional the name in the given locale
	 */
	String getTitle(String locale);
	
	
}
