
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;


public interface AttributeListMutableBean extends IdentifiableMutableBean {

	List<AttributeMutableBean> getAttributes();
	
	void setAttributes(List<AttributeMutableBean> attributes);
	
	void addAttribute(AttributeMutableBean attribute);
	
}
