package io.sdmx.api.sdmx.model.data.calculation;

import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;

/**
 * Defines a calculation against a single dimension
 */
public interface IDimensionValidationExpression extends ValidationExpression {
	
	/**
	 * @return the rule from which this was built
	 */
	ValidationRuleBean getRule();
	
	/**
	 * @return the dimension index in the DSD
	 */
	int getDimensionIndex();
}
