
package io.sdmx.api.sdmx.model.beans.categoryscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;


/**
 * A Reporting Category is used to group structures (dataflows or metadataflows) into useful sub-packages.
 * @author Matt Nelson
 *
 */
public interface ReportingCategoryBean extends HierarchicalItemBean<ReportingCategoryBean> {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<ReportingCategoryBean> getURN();
	
	List<ICrossReferenceBean<?>> getStructuralMetadata();

	List<ICrossReferenceBean<?>> getProvisioningMetadata();

	
}
