
package io.sdmx.api.sdmx.model.beans.base;


/**
 * Contains a locale alongside the String value, the value may be in HTML
 * @author Matt Nelson
 */
public interface TextTypeWrapper extends SDMXBean, INoCrossReferencesBean {
	final String name = "Text";
	
	/**
	 * Documented from the java.util.Locale
	 * Returns the language code of this Locale. 
	 * Note: ISO 639 is not a stable standard— some languages' codes have changed. Locale's constructor recognizes both the new and the old codes for the languages whose codes have changed, but this function always returns the old code. If you want to check for a specific language whose code has changed, don't do 
	 * 
	 * To fix this, the comparison between a Local language should be done on this method, not the getLocaleMethod
	 * if (locale.getLanguage().equals(textType.getLocale())) // BAD!
     *
	 * Instead, do 
 	 * if (locale.getLanguage().equals(textType.getISO639Language()))
	 * 
	 */
	String getISO639Language();
	
	/**
	 * Returns the locale of the text string, retrievable by getValue()
	 * @return
	 */
	String getLocale();

	/**
	 * The text, in the locale given by getLocale()
	 * @return
	 */
	String getValue();
	
	/**
	 * Returns true if this is HTML text
	 * @return
	 */
	boolean isHtml();
}
