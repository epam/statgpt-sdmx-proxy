package io.sdmx.api.sdmx.model.beans.publicationtable;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;

/**
 * Defines a table row 
 */
public interface PublicationTableBodyRow extends SdmxStructureBean, INoCrossReferencesBean {
	
	/**
	 * Returns the row label cell
	 * @return
	 */
	PublicationTableHeadCell getHeadCell();
	
	/**
	 * Returns an immutable list of all the table cells for this row
	 * @return
	 */
	List<PublicationTableBodyCell> getTableCells();
	
	/**
	 * Returns the level of this row, starting from 1.  The level defines the level in the hierarchy 
	 * @return
	 */
	default int getLevel() {
		return getRowLabel().getLevel();
	}
	
	/**
	 * Returns the row number, 0 indexed
	 * @return
	 */
	int getRowIdx();
	
	/**
	 * @return the {@link PublicationTableHeadCell} label parsed into a {@link IHeadLabel}
	 */
	default IHeadLabel getRowLabel() {
		return getHeadCell().getRowLabel();
	}
	
	
}
