package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface IMetadataProvisionAgreementMutableBean extends IMetadataTargetIdentifiableMutable {
	
	StructureReferenceBean getMetadataflowRef();

	StructureReferenceBean getMetadataProviderRef();
	
	void setMetadataflowRef(StructureReferenceBean structureUseage);
	
	void setMetadataProviderRef(StructureReferenceBean dataproviderRef);
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	@Override
	MetadataProvisionAgreementBean getImmutableInstance();
}
