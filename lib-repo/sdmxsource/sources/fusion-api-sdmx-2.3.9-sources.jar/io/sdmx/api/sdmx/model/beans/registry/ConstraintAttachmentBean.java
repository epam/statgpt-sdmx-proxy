
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.DataAndMetadataSetReference;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;


public interface ConstraintAttachmentBean extends SdmxStructureBean {
	
	/**
	 * If this constraint is built from a dataset/metadataset, this will returns the data provider and dataset id
	 * @return
	 */
	DataAndMetadataSetReference getDataOrMetadataSetReference();
	
	/**
	 * Returns the structures that this constraint is attached to, this can be one or more of the following:
	 * <ul>
	 *   <li>Data Provider</li>
	 *   <li>Data Structure</li>
	 *   <li>Metadata Structure</li>
	 *   <li>Data Flow</li>
	 *   <li>Metadata Flow</li>
	 *   <li>Provision Agreement</li>
	 *   <li>Registration Bean</li>
	 * </ul>
	 * <p><strong>NOTE: </strong> This list of cross references can not be a mixed bag, it can be one or more OF THE SAME TYPE.
	 * @return
	 */
	Set<IDirectCrossReferenceBean<?>> getStructureReference();

	/**
	 * Returns the target structure type that this constraint is attached to (depending on the structure type referenced from the getStructureReference() cross reference(s)).
	 * <p/>
	 * Returns null if getStructureReference() does not contain any references.
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getAttachedStructure();
	
	/**
	 * Returns the datasource(s) that this constraint is built from
	 * @return not null
	 */
	List<DataSourceBean> getDataSources();
	
	ConstraintAttachmentMutableBean createMutableInstance();
}
