package io.sdmx.api.sdmx.model.beans.reference.complex;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;

import java.util.List;

/**
 * represents values of a multilingual attribute or measure as introduced in SDMX v3. MultilingualValueNode contains
 * texts of multilingual value.
 */
public interface IMultilingualNodeValue {

    /**
     * returns texts of the complex node. Returns null if node contains no texts.
     * @return
     */
    List<TextTypeWrapper> getTexts();

}

