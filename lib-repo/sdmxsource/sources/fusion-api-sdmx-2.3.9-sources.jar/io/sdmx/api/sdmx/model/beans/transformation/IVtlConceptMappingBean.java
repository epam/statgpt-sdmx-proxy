package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;

public interface IVtlConceptMappingBean extends IVtlMappingBean<ConceptBean> {
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IVtlConceptMappingBean> getURN();
}
