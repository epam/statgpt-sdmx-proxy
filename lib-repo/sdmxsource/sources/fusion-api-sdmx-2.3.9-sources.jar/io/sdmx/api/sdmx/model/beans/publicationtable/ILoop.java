package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

public interface ILoop {
	
	enum LOOP_ORDER {
		NATURAL(1),
		BY_ID(2),
		BY_NAME(3);
		
		int val;
		
		private LOOP_ORDER(int val) {
			this.val = val;
		}
		
		public static LOOP_ORDER parseVal(int val) {
			for(LOOP_ORDER order : LOOP_ORDER.values()) {
				if(order.val == val) {
					return order;
				}
			}
			throw new IllegalArgumentException("Unsupported Loop Order: "+val);
		}
	}
	
	/**
	 * @return label to which the loop belongs
	 */
	IHeadLabel getHeadLabel();
	
	/**
	 * @return not null - the order in which to loop the values
	 */
	LOOP_ORDER getLoopOrder();

	/**
	 * @return not null  - the Dimension ID or a Codelist Alias in the Publication Table
	 */
	String getInputVariable();
	
	/**
	 * @return not null - the variable that the loop value will be stored in, to be referenced by Observation Keys
	 */
	String getOutputVariable();
	
	/**
	 * @return true if the hierarchy of the underlying Codelist is to be preserved when creating the table output
	 */
	boolean preserveHierarchy();
	
	/**
	 * @return not null - an optional fixed list of values to loop, or an empty list to indicate that it should loop all available values 
	 */
	List<String> getLoopValues();
	
}
