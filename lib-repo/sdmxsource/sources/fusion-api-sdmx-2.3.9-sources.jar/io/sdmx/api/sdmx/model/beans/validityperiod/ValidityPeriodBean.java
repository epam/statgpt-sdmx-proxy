package io.sdmx.api.sdmx.model.beans.validityperiod;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

public interface ValidityPeriodBean extends SDMXBean {
	static final String VALIDITY_PERIOD = "FR_VALIDITY_PERIOD";  //Annotation Types for storing validity information
	static final String VALIDITY_TYPE = "FR_VALIDITY_TYPE";	  //Annotation Types for storing validity information
	
	/**
	 * Returns the validity period (valid from and to dates) for this ValidityPeriodBean, or null if undefined
	 * @return
	 */
	SdmxPeriod getValidityPeriod();

	/**
	 * Returns true if there is a the validity period (valid from and to dates) for this ValidityPeriodBean
	 * @return
	 */
	default boolean hasValidityPeriod() {
		return getValidityPeriod() != null;
	}

	
}
