package io.sdmx.api.sdmx.model.mutable.transformation;

public interface IVtlConceptMappingMutableBean extends IVtlMappingMutableBean {

}
