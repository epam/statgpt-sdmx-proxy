package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.List;

/**
 * Represents an SDMX Item Scheme Map
 * @author Matt Nelson
 * @deprecated use mapping.v3
 */
@Deprecated
public interface ItemSchemeMapBean<T extends ItemMapBean> extends SchemeMapBean {

	List<T> getItems();
	
}
