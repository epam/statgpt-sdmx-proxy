
package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.regex.Pattern;

import io.sdmx.api.sdmx.constants.MAPPING_FUNCTION;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;

/**
 * Represents an SDMX Codelist Map
 * @deprecated use {@link IRepresentationMapBean} 
 */
public interface CodelistMapBean extends ItemSchemeMapBean<CodeMapBean> {

	/**
	 * returns the mapping function to apply
	 * @return
	 */
	MAPPING_FUNCTION getMappingFunction();
	
	/**
	 * Returns true if there is a mapping function
	 * @return
	 */
	boolean hasMappingFunction();
	
	/**
	 * If the mapping function is substring then this returns the start index (required)
	 * @return
	 */
	int getSubStringStart();

	/**
	 * If the mapping function is substring then this returns the end index (-1 if to end of string)
	 * @return
	 */
	int getSubStringEnd();
	
	/**
	 * If the mapping function is regular expressions, then this returns the regex pattern
	 * @return
	 */
	Pattern getRegExPattern();
	
}
