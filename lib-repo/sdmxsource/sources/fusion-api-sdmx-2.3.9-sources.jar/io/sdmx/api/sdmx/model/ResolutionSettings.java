package io.sdmx.api.sdmx.model;

import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;

/**
 * Contains all the settings for parsing structures.
 * <p/>
 * The setting are given by enumerated flags at construction, making instances immutable.
 * <p/>
 * Functions are available to reinterpret these settings when applied to parsing XML structures into beans.
 * <p/>
 * The StructureSettings take into account two settings for parsing SDMX-ML documents
 * <ol>
 *   <li>Resolve Cross References</li>
 *   <li>Resolve External References</li>
 * </ol>
 *  
 * Cross References are declared by structures such as Key Families also known as a Data Structure Definition (DSD) (see <code>DataStructureBean</code>).  A DSD
 * contains a number of Dimensions (<code>DimensionBean</code>) a Dimension may declare a reference to a Codelist and a Concept through reference parameters.
 *  <p/>
 * If a system is to resolve the cross references, then it can do this by either of the following ways:
 * <ul>
 *   <li>Resolve the external reference exists at the given URI</li>
 *   <li>Resolve the external reference exists, and substitute it for the provided 'stub' artifact</li>
 *   <li>Either of the above two can be lenient (do not error if it can not be done) or not (throw exception if this could not be done)</li>
 * </ul>
 * <p/>
 * External References are declared by MaintainableBean structures by having their isExternal attribute set to true.  In this instance the Maintainable artifact
 * is declaring that it is not the full artifact, but just an empty container whose purpose is to declare the existence of the artifact (stub).  The stub also has
 * the responsibility of declaring where to get the full artifact, this is defined by the URI attribute.  
 * <p/>
 * The StructureSettings provides the following options for resolving cross references:
 * <ul>
 *   <li>Do  not resolve</li>
 *   <li>Resolve all the references (it is up to the implementation to decide how deep to resolve)</li>
 *   <li>Resolve all the references except for Agencies</li>
 * </ul>
 * <p/>
 * External references are when a structure is declared, like a codelist, as a 'stub'  
 * containing the minimum possible information for it to be valid against the schema;
 * i.e it has a name, id and agency id, but it also has a URI which says: 
 * if you want the full codelists, with a 100 million codes, it's retrievable from this location.
 * This is useful if someone wants to store information in the registry, but maintain the contents of the artifacts externally.
 * <p/>
 * @see DataStructureBean which is built from an XML message.
 * @see KeyFamliySuperBean which is built from resolving all the cross referenced artifacts.
 */
public class ResolutionSettings implements Cloneable {
	private RESOLVE_EXTERNAL_SETTING resolveExternal;
	private RESOLVE_CROSS_REFERENCES resolveCrossRef;
	private int resolutionDepth;

	/**
	 * Flag options for handling External References (structures not present but specified with a URI, 
	 * indicating a remote file containing the missing structures).
	 */
	public enum RESOLVE_EXTERNAL_SETTING {
		/** DO NOT RESOLVE EXTERNAL REFERENCES **/
		DO_NOT_RESOLVE,
		/** RESOLVE EXTERNAL REFERENCES **/
		RESOLVE,
		/** RESOLVE EXTERNAL REFERENCES AND SUBSTITUTE THEM IN FOR THE STUB **/
		RESOLVE_SUBSTITUTE,
		/** RESOLVE EXTERNAL REFERENCES - ADD ERROR ANNOTATIONS IF ERRORS OCCUR **/
		RESOLVE_LENIENT,
		/** RESOLVE EXTERNAL REFERENCES AND SUBSTITUTE THEM IN FOR THE STUB - ADD ERROR ANNOTATIONS IF ERRORS OCCUR **/
		RESOLVE_SUBSTITUTE_LENIENT,
	}
	
	/**
	 * Flag options for handling Cross References
	 */
	public enum RESOLVE_CROSS_REFERENCES {
		/** DO NOT RESOLVE CROSS REFERENCES **/
		DO_NOT_RESOLVE,
		/** RESOLVE CROSS REFERENCES INCLUDING AGENCIES **/
		RESOLVE_ALL,
		/** RESOLVE CROSS REFERENCES EXCLUDING AGENCIES **/
		RESOLVE_EXCLUDE_AGENCIES;
	}
	
	/**
	 * Constructor, all settings provided here, immutable hereafter.
	 * @param resolveExternal
	 * @param resolveCrossRef
	 * @param resolutionDepth - required if resolving references.  0 indicates resolve all, any other positive integer is the level of recursion to resolve
	 */
	public ResolutionSettings(RESOLVE_EXTERNAL_SETTING resolveExternal,	RESOLVE_CROSS_REFERENCES resolveCrossRef,
			int resolutionDepth) {
		this.resolveExternal = resolveExternal;
		this.resolveCrossRef = resolveCrossRef;
		this.resolutionDepth = resolutionDepth;
	}
	
	/**
	 * Clone Constructor, which creates a new ResolutionSettings instance from a source.
	 * This constructor is preferred rather that using the Java clone method.
     * @param source the object to use as the clone.
	 */
	public ResolutionSettings(ResolutionSettings source) {
	    this.resolveExternal = source.getResolveExternal();
        this.resolveCrossRef = source.getResolveCrossRef();
        this.resolutionDepth = source.getResolutionDepth();
	}
	
	/**
	 * Constructor, all settings provided here, immutable hereafter.
	 * @param resolveExternal
	 * @param resolveCrossRef
	 */
	public ResolutionSettings(RESOLVE_EXTERNAL_SETTING resolveExternal,	RESOLVE_CROSS_REFERENCES resolveCrossRef) {
		this.resolveExternal = resolveExternal;
		this.resolveCrossRef = resolveCrossRef;
	}
	
	
	public int getResolutionDepth() {
		return resolutionDepth;
	}


	public RESOLVE_EXTERNAL_SETTING getResolveExternal() {
		return resolveExternal;
	}


	public RESOLVE_CROSS_REFERENCES getResolveCrossRef() {
		return resolveCrossRef;
	}


	/**
	 * Returns true if external references are to be retrieved and replace the stub
	 * @return
	 */
	public boolean isResolveExternalReferences() {
		return resolveExternal != RESOLVE_EXTERNAL_SETTING.DO_NOT_RESOLVE;
	}
	
	/**
	 * Returns true if the cross referenced structures need to be resolved to exist
	 * @return
	 */
	public boolean isResolveCrossReferences() {
		return resolveCrossRef != RESOLVE_CROSS_REFERENCES.DO_NOT_RESOLVE;
	}
	
	/**
	 * Returns true if the cross referenced structures need to be resolved to exist
	 * @return
	 */
	public boolean isResolveAgencyReferences() {
		return resolveCrossRef == RESOLVE_CROSS_REFERENCES.RESOLVE_ALL;
	}

	/**
	 * Returns true if the resolved external references should be substituted for the maintainable stub
	 * @return
	 */
	public boolean isSubstituteExternal() {
		return resolveExternal == RESOLVE_EXTERNAL_SETTING.RESOLVE_SUBSTITUTE ||
		resolveExternal == RESOLVE_EXTERNAL_SETTING.RESOLVE_SUBSTITUTE_LENIENT;
	}
	
	/**
	 * Returns true if the cross referenced structures need to be resolved to exist
	 * @return
	 */
	public boolean isLenient() {
		return  resolveExternal == RESOLVE_EXTERNAL_SETTING.RESOLVE_LENIENT ||
		resolveExternal == RESOLVE_EXTERNAL_SETTING.RESOLVE_SUBSTITUTE_LENIENT;
	}

	@Override
	public String toString() {
		return "Resolve external="+resolveExternal+", resolve cross references="+resolveCrossRef+", resolution depth="+resolutionDepth;
	}
	
}
