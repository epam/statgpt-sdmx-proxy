
package io.sdmx.api.sdmx.model.header;

import java.util.Date;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;


/**
 * Contains information specifically related to a single dataset
 *
 */
public interface DatasetHeaderBean {
	
	/**
	 * Creates a new DatasetHeaderBean, copying over all the attributes of this header, but replacing the DatasetStructureReferenceBean with the one passed in
	 * @param datasetStructureReferenceBean
	 * @return
	 */
	DatasetHeaderBean modifyDataStructureReference(DatasetStructureReferenceBean datasetStructureReferenceBean);
	
	/**
	 * Returns the action for this dataset, defaults to INFORMATION
	 * @return
	 */
	DATASET_ACTION getAction();
	DatasetHeaderBean setAction(DATASET_ACTION action);
	
	/**
	 * Returns true if the DataReaderEngine is reading time series data (observations iterate over time).  If false time will be at the series level
	 * @return
	 */
	boolean isTimeSeries();

	/**
	 * Returns a reference to the data provider for this data.
	 * @return returns null if there is no reference
	 */
	IURNAbsolute<DataProviderBean> getDataProviderReference();
	
	/**
	 * Returns a DatasetStructureReferenceBean containing information about what structure is used to descirbe the structure of this dataset
	 * @return returns null if there is no reference
	 */
	DatasetStructureReferenceBean getDataStructureReference();
	
	
	/**
	 * Returns an id for the dataset
	 * @return returns null if no id was given
	 */
	String getDatasetId();
	
	/**
	 * Returns the reporting begin date for this dataset
	 * @return returns null if there is no reporting begin date defined
	 */
	Date getReportingBeginDate();

	/**
	 * Returns the reporting end date for this dataset
	 * @return returns null if there is no reporting end date defined
	 */
	Date getReportingEndDate();
	
	/**
	 * Returns the reporting end date for this dataset
	 * @return returns null if there is no valid from date defined
	 */
	Date getValidFrom();

	/**
	 * Returns the reporting end date for this dataset
	 * @return returns null if there is no valid to defined
	 */
	Date getValidTo();
		
	/**
	 * Returns the reporting end date for this dataset
	 * @return returns -1 if there is no publication year given defined
	 */
	int getPublicationYear();
	
	/**
	 * Returns the reporting end date for this dataset
	 * @return returns null if there is no publication period defined
	 */
	String getPublicationPeriod();
}
