
package io.sdmx.api.sdmx.model.beans.base;

import java.net.URL;

import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;

/**
 * Describes the location and type of DataSource.
 */
public interface DataSourceBean extends SdmxStructureBean, INoCrossReferencesBean {

	/**
	 * Returns true if the getDataUrl() is pointing at a REST web service.
	 * @return
	 */
	boolean isRESTDatasource();
	
	/**
	 * Returns true if the getDataUrl() is pointing at a SOAP web service.
	 * @return
	 */
	boolean isWebServiceDatasource();
	
	/**
	 * Returns true if the getDataUrl() is pointing at a file location.
	 * @return
	 */
	boolean isSimpleDatasource();
	
	/**
	 * Returns the URL of the datasource, this can never be null.
	 * @return
	 */
	URL getDataUrl();
	
	/**
	 * Returns the URL of the WSDL or null if no WSDL location has been defined.
	 * @return
	 */
	URL getWSDLUrl();
	
	/**
	 * Returns the WADL URL or null if no WADL location has been defined.
	 * @return
	 */
	URL getWadlUrl();
	
	/**
	 * Returns a mutable version of this bean instance.
	 * @return
	 */
	DataSourceMutableBean createMutableInstance();	
}
