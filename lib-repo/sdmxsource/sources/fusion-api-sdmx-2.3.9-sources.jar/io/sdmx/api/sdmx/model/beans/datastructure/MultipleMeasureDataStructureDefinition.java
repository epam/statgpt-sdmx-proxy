package io.sdmx.api.sdmx.model.beans.datastructure;

/**
 * This is a Data Structure with multiple measures 
 */
public interface MultipleMeasureDataStructureDefinition extends DataStructureBean {

	default boolean hasMultipleMeasures() {
		return true;
	}
}
