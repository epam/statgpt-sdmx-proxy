package io.sdmx.api.sdmx.model.beans.mapping.v3;

/**
 * Represents an SDMX Concept Map
 */
public interface IConceptMapBean extends IItemMapBean {

}
