package io.sdmx.api.sdmx.model.diff;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Contains information about the changes made when moving from one version of a Maintainale to the next version
 * for example DiffReport.getSource would be 1.0 and the DiffReport.getTarget would be 1.1 or 2.0 (the next immeditate version)
 * 
 * It can also contain information about comparing one structure to another
 * 
 * Comparable on the version, followed by the date of change (if the version is the same of the source and target)
 * 
 */
public interface BeanDiff extends Comparable<BeanDiff> {

	/**
	 * Returns the source structure
	 * @return
	 */
	MaintainableBean getSource();
	
	/**
	 * Returns the target structure 
	 * @return
	 */
	MaintainableBean getTarget();
	
	/**
	 * The report
	 * @return
	 */
	DiffReport getDiffReport();
	
}
