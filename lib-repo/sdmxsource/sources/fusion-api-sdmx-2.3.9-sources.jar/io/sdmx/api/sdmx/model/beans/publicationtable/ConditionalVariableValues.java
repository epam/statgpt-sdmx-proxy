package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * Returns mapped values for a conditional variable (e.g. UK) to a number of conditions, for example
 * 0 -> UKP50
 * 1 -> UKP20
 * 2 -> UKP10
 * 3 -> UKP5
 */
public interface ConditionalVariableValues extends SDMXBean, INoCrossReferencesBean {

	/**
	 * The mapped id, for example UK
	 * @return
	 */
	String getMappedId();
	
	/**
	 * Returns the source ids in the order they are given
	 * @return
	 */
	List<String> getSourceIds();

	/**
	 * Returns the mapped value for the given source id
	 * @return
	 */
	String getMappedValue(String sourceId);

	/**
	 * Returns the mapped value for the source id at the given index
	 * @param sourceIdx
	 * @return
	 */
	String getMappedValue(int sourceIdx);

}
