package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents a URN which matches on a single structure type != WILDCARD, this could be either an absolute URN or Semantically versioned URN
 * 
 * <K> is the structure type this URN is referencing
 */
public interface IURNSingle<K extends IdentifiableBean> extends IURN<K> {
	
	/**
	 * Casts this type to the given type T if it is able to do so
	 * @param <T>
	 * @param type
	 * @return
	 * @throws IllegalArgumentException - if the type T is not assignable to the structure type this URN is referencing
	 */
	@Override
	default <T extends IdentifiableBean> IURNSingle<T> toType(Class<T> type) {
		if(isType(type)) {
			return (IURNSingle<T>)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: " +type.getCanonicalName());
	}
	
	/**
	 * Casts this type to the given type T if it is able to do so
	 * @param <T>
	 * @param type
	 * @return
	 * @throws IllegalArgumentException - if the type T is not assignable to the structure type this URN is referencing
	 */
	default <T extends IdentifiableBean> IURNSingle<? extends T> toSubType(Class<T> type) {
		if(isType(type)) {
			return (IURNSingle<? extends T>)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: " +type.getCanonicalName());
	}
	
	/**
	 * @return fixed SEMANTIC
	 */
	@Override
	default REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.SEMANTIC;
	}
	
	@Override
	IURNSingle<? extends MaintainableBean> getMaintainableURN();
	
	/**
	 * @return not null - urn without the version information e.g. urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=ECB:TRD
	 */
	default String getURNNoVersion() {
		String urnNoVersion = getStructureType().getFullyQualifiedClass()+"="+getAgencyId()+":"+getMaintainableId();
		if(!this.isMaintainableReference()) {
			urnNoVersion += "." + getFullIdentifiableId();
		}
		return urnNoVersion;
	}
	
}
