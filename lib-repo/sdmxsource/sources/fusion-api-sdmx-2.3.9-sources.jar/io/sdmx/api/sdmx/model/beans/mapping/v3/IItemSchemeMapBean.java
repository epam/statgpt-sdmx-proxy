
package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.List;

/**
 * Represents an SDMX Item Scheme Map
 * @author Matt Nelson
 *
 */
public interface IItemSchemeMapBean<T extends IItemMapBean> extends ISchemeMapBean {

	List<T> getItems();
	
}
