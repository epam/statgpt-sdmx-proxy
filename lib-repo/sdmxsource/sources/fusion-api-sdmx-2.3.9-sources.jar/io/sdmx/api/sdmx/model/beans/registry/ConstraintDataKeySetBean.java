
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;


/**
 * Contains a list of constrained series keys, or wildcarded series keys
 */
public interface ConstraintDataKeySetBean extends SdmxStructureBean, INoCrossReferencesBean {
	
	/**
	 * Returns a list of constrained series keys
	 * @return
	 */
	List<ConstrainedDataKeyBean> getConstrainedDataKeys();
	
}
