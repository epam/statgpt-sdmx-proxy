package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * A constrainable bean is one which can have constraints associated with it.
 * <p/>
 * Constraints are not `by composition` but `by reference` therefore a constraint can only reference a constrainable artifact,
 * a constrainable artifact does not contain the constraint.
 * 
 * @author Matt Nelson
 */
public interface ConstrainableBean extends IdentifiableBean {

	
	/**
	 * Returns a reference to any referenced structures that can also be constrained, examples are:
	 * <ul>
	 *  <li>Registration would return reference to a provision agreement</li>
	 *  <li>Provision Agreement would return a reference to a dataflow and a Data Provider</li>
	 *  <li>Dataflow would return a reference to a data structure</li>
	 *  <li>Data Structure would return null</li>
	 * </ul>
	 * 
	 * @return a list of references
	 */
	List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables();
	
}