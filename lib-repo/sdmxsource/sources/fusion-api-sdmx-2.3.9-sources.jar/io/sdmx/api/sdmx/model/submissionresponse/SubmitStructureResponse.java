
package io.sdmx.api.sdmx.model.submissionresponse;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

/**
 * Created after a submission of a document to a SDMX web service
 */
public interface SubmitStructureResponse {
	
	/**
	 * Returns the structure that this response is for - this may be null if there were errors in the submission
	 * @return
	 */
	StructureReferenceBean getStructureReference();

	/**
	 * Returns true if getErrorList() returns a not null ErrorList, and the returned ErrorList is of type error (not warning)
	 * @return
	 */
	boolean isError();
	
	/**
	 * Returns the list of errors, returns null if there were no errors for this response (if it was a success)
	 * @return
	 */
	ErrorList getErrorList();
	
	/**
	 * Returns the action type associated with this response
	 * @return
	 */
	DATASET_ACTION getActionType();
}
