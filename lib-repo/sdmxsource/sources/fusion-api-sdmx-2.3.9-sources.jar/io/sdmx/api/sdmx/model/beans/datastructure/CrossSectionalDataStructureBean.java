
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.CrossSectionalDataStructureMutableBean;


/**
 * A Cross Sectional Data Structure extends DataStructure by adding cross sectional information as it was modelled in SDMX Version 2.0
 * @author Matt Nelson
 *
 */
public interface CrossSectionalDataStructureBean extends DataStructureBean {

	/**
	 * Returns the cross sectional measure with the given id.
	 * <p/>
	 * Returns null if no measure is found with the id.
	 * @param id
	 * @return
	 */
	CrossSectionalMeasureBean getCrossSectionalMeasure(String id);
	
	/**
	 * Returns true if the given dimension is to be treated as the measure dimension
	 * @param dim
	 * @return
	 */
	boolean isMeasureDimension(DimensionBean dim);
	
	/**
	 * Returns a list of the cross sectional measures
	 * @return
	 */
	List<CrossSectionalMeasureBean> getCrossSectionalMeasures();
	
	/**
	 * Returns the codelist reference for the dimension with the given id
	 * @param dimensionId
	 * @return
	 */
	ICrossReferenceBean getCodelistForMeasureDimension(String dimensionId);
	
	/**
	 * Returns a list of components that are cross sectional attach dataset.
	 * <p/>
	 * Returns an empty list if no dimensions's are marked as cross sectional attach dataset.
	 * 
	 * @param returnOnlyIfLowestLevel if true only return the components that do not have an attachment to a lower level (i.e observation)
	 * @param returnTypes optional filter on return types example SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE, SDMX_STRUCTURE_TYPE.GROUP, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)
	 * @return
	 */
	List<ComponentBean> getCrossSectionalAttachDataSet(boolean returnOnlyIfLowestLevel, SDMX_STRUCTURE_TYPE... returnTypes);
	
	/**
	 * Returns a list of components that are cross sectional attach group.
	 * <p/>
	 * Returns an empty list if no dimensions's are marked as cross sectional attach group.
	 * 
	 * @param returnOnlyIfLowestLevel if true only return the components that do not have an attachment to a lower level (i.e observation)
	 * @param returnTypes optional filter on return types example SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE, SDMX_STRUCTURE_TYPE.GROUP, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)
	 * @return
	 */
	List<ComponentBean> getCrossSectionalAttachGroup(boolean returnOnlyIfLowestLevel, SDMX_STRUCTURE_TYPE... returnTypes);
	
	/**
	 * Returns a list of components that are cross sectional attach section.
	 * <p/>
	 * Returns an empty list if no dimensions's are marked as cross sectional attach section.
	 * 
	 * @param returnOnlyIfLowestLevel if true only return the components that do not have an attachment to a lower level (i.e observation)
	 * @param returnTypes optional filter on return types example SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE, SDMX_STRUCTURE_TYPE.GROUP, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)
	 * @return
	 */
	List<ComponentBean> getCrossSectionalAttachSection(boolean returnOnlyIfLowestLevel, SDMX_STRUCTURE_TYPE... returnTypes);
	
	/**
	 * Returns a list of components that are cross sectional attach group.
	 * <p/>
	 * Returns an empty list if no dimensions's are marked as cross sectional attach group.
	 * @param returnTypes optional filter on return types example SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE, SDMX_STRUCTURE_TYPE.GROUP, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)
	 * @return
	 */
	List<ComponentBean> getCrossSectionalAttachObservation(SDMX_STRUCTURE_TYPE... returnTypes);
	
	/**
	 * Get the cross sectional measures that the attribute is linked to, returns an empty list if there is no cross sectional measures
	 * defined by the attribute. 
	 * @param attribute
	 * @return
	 */
	List<CrossSectionalMeasureBean> getAttachmentMeasures(AttributeBean attribute);

	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	CrossSectionalDataStructureMutableBean getMutableInstance();
	
}
