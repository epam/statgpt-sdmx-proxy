package io.sdmx.api.sdmx.model.beans.mapping;

import java.net.URL;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.CodeReferenceableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;

/**
 * Represents an SDMX Structure Set
 * @deprecated use {@link IStructureMapBean} and {@link IRepresentationMapBean}
 */
public interface StructureSetBean extends MaintainableBean, CodeReferenceableBean, INoCrossReferencesBean {

	/**
	 * RelatedStructures contains references to structures (key families and metadata structure definitions) and
	 * structure usages (data flows and metadata flows) to indicate that a semantic relationship exist between them.
	 * The details of these relationships can be found in the structure maps.
	 * @return
	 */
	RelatedStructuresBean getRelatedStructures();

	/**
	 * StructureMap maps components from one structure to components to another structure,
	 * and can describe how the value of the components are related.
	 * @return
	 */
	List<StructureMapBean> getStructureMapList();

	/**
	 * CodelistMap links a source and target codes from different
	 * lists where there is a semantic equivalence between them.
	 * @return
	 */
	List<CodelistMapBean> getCodelistMapList() ;


	/**
	 * Returns the codelist map with the given id
	 * @return
	 */
	CodelistMapBean getCodelistMap(String id);


	List<CategorySchemeMapBean> getCategorySchemeMapList();

	/**
	 * ConceptSchemeMap links a source and target concepts from different schemes where there is a semantic equivalence between them.
	 * @return
	 */
	List<ConceptSchemeMapBean> getConceptSchemeMapList();


	List<OrganisationSchemeMapBean> getOrganisationSchemeMapList();


	//ReportingTaxonomyMap links a source and target reporting categories from different taxonomies where there is a semantic equivalence between them.


	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 * @return
	 */
	@Override
	StructureSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	StructureSetMutableBean getMutableInstance();

	/**
	 * Clone this Structure Set for the date specified.
	 * This will return a version of this StructureSet, with the items contained only being valid for the date specified.
	 * @param aDate
	 * @return
	 */
	StructureSetBean cloneForDate(Date aDate);
}