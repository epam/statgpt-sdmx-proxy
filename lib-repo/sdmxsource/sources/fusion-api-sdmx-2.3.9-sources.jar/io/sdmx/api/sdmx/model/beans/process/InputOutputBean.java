
package io.sdmx.api.sdmx.model.beans.process;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * An InputOutputBean defines an input OR an output to a ProcessStep.
 * <p/>
 * The InputOutputBean has a local id, and references any SDMX Identifiable Structure
 * @author Matt Nelson
 * @see ProcessStepBean
 */
public interface InputOutputBean extends AnnotableBean {
	
	/**
	 * The localID attribute is an optional identification for the input or output within the process.
	 * @return
	 */
	String getLocalId();
	
	/**
	 * Returns the reference to the input / output structure.  This can reference any identifiable structure and will not be null.
	 * @return
	 */
	ICrossReferenceBean<?> getStructureReference();
	
}
