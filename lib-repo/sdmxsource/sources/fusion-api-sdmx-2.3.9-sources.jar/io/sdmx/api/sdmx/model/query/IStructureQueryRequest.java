package io.sdmx.api.sdmx.model.query;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.StructureFormat;

/**
 * Defines a request for structural metadata, backed by the request and response
 */
public interface IStructureQueryRequest {
	
	/**
	 * @return true if the structure format was defaulted (i.e. not explicitly requested by the user) in which case
	 * the API has more flexibilty to choose a different format if not supported
	 */
	boolean wasFormatDefaulted();
	
	/**
	 * @return true if the response is needed in a Registry document (SDMX 2.1 only)
	 */
	boolean isReturnAsRegistryResponse();
	
	/**
	 * @return the structure query
	 */
	RESTStructureQuery getStructureQueryRequest();
	
	/**
	 * @return access to the HTTP request
	 */
	Request getRequest();
	
	/**
	 * @return access to the response stream and status
	 */
	IResponse getResponse();
	
	/**
	 * @return desired response format
	 */
	StructureFormat getFormat();
}
