package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;

/**
 * To support beans that are not necessarily nameable as they may not be identifiable, but have names and possibly descriptions
 */
public interface INamedBean extends SDMXBean {
	
	/**
	 * Returns the Id
	 * @return
	 */
	String getId();
	
	/**
	 * Returns the names for this item.
	 * The returned list may be filtered by any LocaleFilters that are in effect.
	 * @return
	 */
	List<TextTypeWrapper> getNames();

	/**
     * Returns the names for this item.
     * The returned list may be filtered by any LocaleFilters that are in effect unless the parameter disableLocaleFilter is set to true.
	 * @param disableLocaleFilter if true, all names will be returned, if false, if a LocaleFilter is in effect then the returned List may be filtered by Locale
	 * @return
	 */
    List<TextTypeWrapper> getNames(boolean disableLocaleFilter);

	/**
     * Returns the descriptions for this item.
     * The returned list may be filtered by any LocaleFilters that are in effect.
	 * @return
	 */
	List<TextTypeWrapper> getDescriptions();

	/**
     * Returns the descriptions for this item.
     * The returned list may be filtered by any LocaleFilters that are in effect unless the parameter disableLocaleFilter is set to true.
     * @param disableLocaleFilter if true, all descriptions will be returned, if false, if a LocaleFilter is in effect then the returned List may be filtered by Locale
     * @return
     */
    List<TextTypeWrapper> getDescriptions(boolean disableLocaleFilter);

	/**
	 * Returns the name in the default locale
	 * @return
	 */
	String getName();
	

	/**
	 * Returns the name in the given locale
	 * @return
	 */
	String getName(String locale);

	/**
	 * Returns the description in the default locale
	 * @return first locale value it finds or null if there are none
	 */
	String getDescription();

}
