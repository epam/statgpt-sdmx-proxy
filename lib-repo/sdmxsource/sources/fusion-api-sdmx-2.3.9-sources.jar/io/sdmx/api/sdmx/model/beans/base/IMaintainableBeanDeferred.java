package io.sdmx.api.sdmx.model.beans.base;

import java.lang.ref.SoftReference;

import io.sdmx.api.io.IDeferred;

/**
 * A IMaintainableBeanDeferred is a MaintainableBean instance where the main content of the {@link MaintainableBean}
 * is lazily loaded on demand.  The 'guts' of the instance is held in as {@link SoftReference} enabling the garbage collection
 * to remove any content from the heap when it requires the memory to be cleared. The instance is able to load its content in
 * at any time, even if cleared by the garbage collection, meaning this bean is a lightweight container which can be passed around
 * a system as if it were the full instance, without requiring the memory that a 'normal' instance of this type would require.
 * 
 * @param <T>
 */
public interface IMaintainableBeanDeferred<T extends MaintainableBean> extends MaintainableBean, IDeferred<MaintainableBean> {

    
}
