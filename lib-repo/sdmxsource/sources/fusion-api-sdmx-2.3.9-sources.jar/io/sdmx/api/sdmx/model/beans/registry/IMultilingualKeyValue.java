package io.sdmx.api.sdmx.model.beans.registry;

import java.io.Serializable;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;

/**
 * Contains one or more collections of multilingual values, i.e. 
 * 
 * Concept=Country
 * 
 * IMultilingualNodeValue
 *   en: United Kingdom
 *   fr: Royaume-Uni
 * 
 * IMultilingualNodeValue
 *   en: France
 *   fr: la France
 *   
 */
public interface IMultilingualKeyValue extends Comparable<IMultilingualKeyValue>, Serializable {

    /**
     * @return the Component ID (Dimension/Attribute/Measure) that this complex KeyValue is for
     */
    String getConcept();
    
    /**
     * @return not null, immutable list of {@link IMultilingualNodeValue}
     */
    List<IMultilingualNodeValue> getMultilingualNodeValues();
    
}
