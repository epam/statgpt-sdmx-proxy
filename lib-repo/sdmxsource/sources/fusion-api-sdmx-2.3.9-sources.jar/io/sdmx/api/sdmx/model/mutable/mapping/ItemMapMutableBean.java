
package io.sdmx.api.sdmx.model.mutable.mapping;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;


@Deprecated
public interface ItemMapMutableBean extends AnnotableMutableBean {

	String getSourceId();

	String getTargetId();

	void setSourceId(String srcId);

	void setTargetId(String targetId);

}
