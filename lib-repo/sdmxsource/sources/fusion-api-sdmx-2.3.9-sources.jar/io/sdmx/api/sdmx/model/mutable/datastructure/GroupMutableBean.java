
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;



public interface GroupMutableBean extends IdentifiableMutableBean {

	List<String> getDimensionRef();
	
	StructureReferenceBean getAttachmentConstraintRef();
	
	void addDimensionRef(String dimId);
	
	void setDimensionRef(List<String> dimensionRef);
	
	void setAttachmentConstraintRef(StructureReferenceBean attachmentConstraintRef);
	
	
}
