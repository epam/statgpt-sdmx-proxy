
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.Date;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


public interface RegistrationMutableBean extends MaintainableMutableBean {
	
	TERTIARY_BOOL getIndexTimeSeries();

	void setIndexTimeSeries(TERTIARY_BOOL indexTimeSeries);

	TERTIARY_BOOL getIndexDataset();

	void setIndexDataset(TERTIARY_BOOL indexDataset);

	TERTIARY_BOOL getIndexAttributes();

	void setIndexAttributes(TERTIARY_BOOL indexAttributes);

	TERTIARY_BOOL getIndexReportingPeriod();

	void setIndexReportingPeriod(TERTIARY_BOOL indexReportingPeriod);
	
	Date getLastUpdated();
	
	void setLastUpdated(Date lastUpdated);
	
	Date getValidFrom();
	
	void setValidFrom(Date validFrom);
	
	Date getValidTo();
	
	void setValidTo(Date validTo);
	
	DataSourceMutableBean getDataSource();
	
	void setDataSource(DataSourceMutableBean dataSource);

	StructureReferenceBean getProvisionAgreementRef();

	void setProvisionAgreementRef(StructureReferenceBean provisionAgreementRef);
	

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * are not reflected in the returned instance of the RegistrationBean.
	 * @return
	 */
	@Override
	RegistrationBean getImmutableInstance();
	
	
	
}
