package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;

public interface IReportingTaxonomyMapMutableBean extends IItemSchemeMapMutableBean<IReportingCategoryMapMutableBean> {

	@Override
	IReportingTaxonomyMapBean getImmutableInstance();
}
