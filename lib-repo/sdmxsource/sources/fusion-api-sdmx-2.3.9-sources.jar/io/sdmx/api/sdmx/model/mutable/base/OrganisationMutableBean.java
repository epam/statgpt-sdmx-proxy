
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;




public interface OrganisationMutableBean extends ItemMutableBean {

	/**
	 * Returns all the contacts for this organisation, this might reutrn null
	 * @return
	 */
	List<ContactMutableBean> getContacts();
	
	/**
	 * Overright the exiting contacts
	 * @param contacts
	 */
	void setContacts(List<ContactMutableBean> contacts);
	
	/**
	 * Add a new contact to the list
	 * @param contact
	 */
	void addContact(ContactMutableBean contact);
	
}
