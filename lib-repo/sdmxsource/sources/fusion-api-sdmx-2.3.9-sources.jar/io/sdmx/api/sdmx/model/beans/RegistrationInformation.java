
package io.sdmx.api.sdmx.model.beans;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;

/**
 * Contains a container to tie a registraion to an action
 * @author Matt Nelson
 *
 */
public interface RegistrationInformation {
	
	/**
	 * Returns the Registration actions
	 * @return
	 */
	DATASET_ACTION getRegistrationAction();
	
	/**
	 * Returns the registration for this container
	 * @return
	 */
	RegistrationBean getRegistration();
}
