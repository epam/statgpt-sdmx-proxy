package io.sdmx.api.sdmx.model.beans.categoryscheme;

import java.net.URL;
import java.util.Date;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesMaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;

/**
 * Represents an SDMX Category Scheme
 * @author Matt Nelson
 */
public interface CategorySchemeBean extends ValidatableBean<CategoryBean>, INoCrossReferencesMaintainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<CategorySchemeBean> getURN();
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 * @return
	 */
	@Override
	CategorySchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

	/**
	 * Returns the category with the given id, additional ids are used to represent the categories parents if it is in a hierarchy.
	 * <p/>
	 * Returns null if the category can not be found with the given id
	 * @param id
	 * @return
	 */
	CategoryBean getCategory(String... id);
	
	@Override
	CategorySchemeBean cloneForDate(Date date);

	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 */
	@Override
	CategorySchemeMutableBean getMutableInstance();

	/**
	 * Returns whether this instance was created by a request for a specific point in time.
	 * For example, if the instance was constructed via new() then this should returned false.
	 * However if the instance was constructed via a cloneForDate() method then this should return true.
	 */
	@Override
    boolean createdFromTimeRequest();

}
