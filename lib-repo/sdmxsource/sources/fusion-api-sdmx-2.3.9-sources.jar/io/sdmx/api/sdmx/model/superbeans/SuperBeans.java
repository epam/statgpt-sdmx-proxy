package io.sdmx.api.sdmx.model.superbeans;

import java.util.Set;

import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;
import io.sdmx.api.sdmx.model.superbeans.base.SuperBean;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;

/**
 * SuperBeans is a container for objects of type <strong>SuperBean</strong>

 * @author Matt Nelson
 * @see SuperBean
 */
public interface SuperBeans {
	
	/**
	 * Merges the super
	 * @param superBeans
	 */
	void merge(SuperBeans superBeans);
	
	
	void addMaintainable(MaintainableSuperBean bean);
	void removeMaintainable(MaintainableSuperBean bean);
	
	//ADD
	/**
	 * Add a ConceptSchemeSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addConceptScheme(ConceptSchemeSuperBean bean);
	
	/**
	 * Add a DataflowSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addDataflow(DataflowSuperBean bean);
	
	/**
	 * Add a HierarchicalCodelistSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addHierarchy(HierarchySuperBean bean);
	
	/**
	 * Add a HierarchicalCodelistSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addMetadataStructure(MetadataStructureSuperBean bean);
	
	/**
	 * Add a DataStructureSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addDataStructure(DataStructureSuperBean bean);
	/**
	 * Add a ProvisionAgreementSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addProvision(ProvisionAgreementSuperBean bean);

	/**
	 * Add a RegistrationSuperBean to this container, overwrite if one already exists with the same URN
	 * @param bean
	 */
	void addRegistration(RegistrationSuperBean bean);
	
	//REMOVE

	
	/**
	 * Remove the given CategorySchemeSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeConceptScheme(ConceptSchemeSuperBean bean);
	/**
	 * Remove the given DataflowSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeDataflow(DataflowSuperBean bean);
	/**
	 * Remove the given HierarchicalCodelistSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeHierarchy(HierarchySuperBean bean);
	/**
	 * Remove the given DataStructureSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeDataStructure(DataStructureSuperBean bean);
	/**
	 * Remove the given MetadataStructureSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeMetadataStructure(MetadataStructureSuperBean bean);
	
	/**
	 * Remove the given ProvisionAgreementSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeProvision(ProvisionAgreementSuperBean bean);
	
	/**
	 * Remove the given RegistrationSuperBean from this container, do nothing if it is not in this container
	 * @param bean
	 */
	void removeRegistration(RegistrationSuperBean bean);
	
	//GET
	/**
	 * Returns a <strong>copy</strong> of the DataflowSuperBean Set.  Returns an empty set if no DataflowSuperBeans are stored in this container
	 * @return
	 */
	Set<DataflowSuperBean> getDataflows();
	
	/**
	 * Returns a <strong>copy</strong> of the ConceptSchemeSuperBean Set.  Returns an empty set if no ConceptSchemeSuperBeans are stored in this container
	 * @return
	 */
	Set<ConceptSchemeSuperBean> getConceptSchemes();
	
	/**
	 * Returns a <strong>copy</strong> of the HierarchyBean Set.  Returns an empty set if no HierarchyBean are stored in this container
	 * @return
	 */
	Set<HierarchySuperBean> getHierarchies();
	/**
	 * Returns a <strong>copy</strong> of the DataStructureSuperBean Set.  Returns an empty set if no DataStructureSuperBean are stored in this container
	 * @return
	 */
	Set<DataStructureSuperBean> getDataStructures();
	
	/**
	 * Returns a <strong>copy</strong> of the MetadataStructureSuperBean Set.  Returns an empty set if no MetadataStructureSuperBean are stored in this container
	 * @return
	 */
	Set<MetadataStructureSuperBean> getMetadataStructures();
	/**
	 * Returns a <strong>copy</strong> of the ProvisionAgreementSuperBean Set.  Returns an empty set if no ProvisionAgreementSuperBeans are stored in this container
	 * @return
	 */
	Set<ProvisionAgreementSuperBean>  getProvisions();
	/**
	 * Returns a <strong>copy</strong> of the MaintainableSuperBean Set.  Returns an empty set if no MaintainableSuperBeans are stored in this container
	 * @return
	 */
	Set<MaintainableSuperBean> getAllMaintainables();
	
	/**
	 * Returns a <strong>copy</strong> of the RegistrationSuperBean Set.  Returns an empty set if no RegistrationSuperBeans are stored in this container
	 * @return
	 */
	Set<RegistrationSuperBean> getRegistrations();
}
