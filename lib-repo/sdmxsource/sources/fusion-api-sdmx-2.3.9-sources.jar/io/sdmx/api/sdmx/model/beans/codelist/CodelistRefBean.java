package io.sdmx.api.sdmx.model.beans.codelist;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

@Deprecated
/**
 * Represents an SDMX Codelist Reference as referenced from a HierarchicalCodeist (includes alias)
 */
public interface CodelistRefBean {

    /**
     * returns the alias, this may be null
     * @return
     */
    String getAlias();

    /**
     * This can never be null
     * @return
     */
    ICrossReferenceBean<CodelistBean> getCodelistReference();

}