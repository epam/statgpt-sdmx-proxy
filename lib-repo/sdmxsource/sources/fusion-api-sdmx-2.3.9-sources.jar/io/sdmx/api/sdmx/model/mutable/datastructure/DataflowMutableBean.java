
package io.sdmx.api.sdmx.model.mutable.datastructure;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface DataflowMutableBean extends MaintainableMutableBean {

	StructureReferenceBean getDataStructureRef();
	
	void setDataStructureRef(StructureReferenceBean keyFamilyRef);
	 
	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	DataflowBean getImmutableInstance();
}
