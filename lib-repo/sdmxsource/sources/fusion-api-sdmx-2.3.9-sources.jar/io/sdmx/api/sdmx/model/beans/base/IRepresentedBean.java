package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Represents a Bean which optionally defines its representation by a text format and/or enuerated type
 */
public interface IRepresentedBean {
	
	
	/**
	 * @return minimum number of values that can be reported against this component
	 */
	default int getMinOccurs() {
		if(getRepresentation() != null && getRepresentation().getMinOccurs() != null) {
			return getRepresentation().getMinOccurs();
		}
		return 0;
	}
	
	/**
	 * @return maximum number of values that can be reported against this attribute, default 1, Integer.MAX is unbounded
	 */
	default int getMaxOccurs() {
		if(getRepresentation() != null  && getRepresentation().getMaxOccurs() != null) {
			return getRepresentation().getMaxOccurs();
		}
		return 1;
	}
	
	/**
	 * @return true if the maximum number of occurrences is unbounded
	 */
	default boolean isUnboundedMax() {
		return getMaxOccurs() == Integer.MAX_VALUE;
	}
	

	/**
	 * @return true if the text format allows for multilingual text
	 */
	default boolean isMultilingual() {
		if(getTextFormat() == null) {
			return false;
		}
		return getTextFormat().getMultiLingual() == TERTIARY_BOOL.TRUE;
	}


	/**
	 * Returns the text format, which is typically (but does not have to be) present for an uncoded component (one which does not reference an enumerated list).
	 * </p>
	 * Returns null if there is no text format present
	 * @return
	 */
	default TextFormatBean getTextFormat() {
		if(getRepresentation() == null) {
			return null;
		}
		return getRepresentation().getTextFormat();
	}


	/**
	 * Returns the text type, which is typically (but does not have to be) present for an uncoded component (one which does not reference an enumerated list).
	 * </p>
	 * Returns null if there is no text format present
	 * @return
	 */
	default TEXT_TYPE getTextType() {
		if(getTextFormat() == null) {
			return null;
		}
		return getTextFormat().getTextType();
	}


	/**
	 * @return reference to an enumerated list of allowable values, or null if there is no such reference
	 */
	default ICrossReferenceBean<? extends EnumeratedListBean> getEnumeratedRepresentation() {
		if(getRepresentation() == null) {
			return null;
		}
		return getRepresentation().getRepresentation();
	}

	/**
	 * @return the representation for this component, returns null if there is no representation
	 */
	RepresentationBean getRepresentation();

	/**
	 * @ return true if this identifier component has coded representation
	 */
	default boolean hasCodedRepresentation() {
		return getEnumeratedRepresentation() != null;
	}
}
