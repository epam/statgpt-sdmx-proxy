package io.sdmx.api.sdmx.model.beans.datastructure;

import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;

/**
 */
public interface MeasureDimensionBean extends IDataStructureComponentBean {
	
	/**
	 * @return overridden to return the absolute type
	 */
	@Override
	IURNAbsolute<MeasureDimensionBean> getURN();

	
	/**
	 * @return true if this is the primary measure with ID of OBS_VALUE
	 * @see PrimaryMeasureBean
	 */
	boolean isPrimaryMeasure();

}
