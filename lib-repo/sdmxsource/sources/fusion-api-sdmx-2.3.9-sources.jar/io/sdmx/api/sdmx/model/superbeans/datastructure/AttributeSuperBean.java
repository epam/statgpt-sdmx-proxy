
package io.sdmx.api.sdmx.model.superbeans.datastructure;

import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;


/**
 * An Attribute is a item of information used to add additional metadata to a key or observation or
 * group.
 * 
 * @author Matt Nelson
 *
 */
public interface AttributeSuperBean extends ComponentSuperBean<AttributeBean> {


	/**
	 * Replace, add, or remove the codelist in this component
	 * @param cl the codelist to replace with, null to remove the codelist
	 * @return
	 */
	AttributeSuperBean replaceCodelist(CodelistBean cl);
}
