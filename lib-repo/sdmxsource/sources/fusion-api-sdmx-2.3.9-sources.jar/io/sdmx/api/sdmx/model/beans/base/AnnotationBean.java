package io.sdmx.api.sdmx.model.beans.base;

import java.net.URI;
import java.util.List;

/**
 * Contains annotation information
 * <p/>
 * Provides for non-documentation notes and annotations to be embedded in data and structure messages. 
 * It provides optional fields for providing a title, a type description, a URI, and the text of the annotation.
 * <p/>
 * This is an immutable bean - this bean can not be modified
 * @author Matt Nelson
 *
 */
public interface AnnotationBean extends SDMXBean, INoCrossReferencesBean {
	
	/**
	 * Returns true if this annotation was dynamically added to an existing MaintainableBean (i.e it is not a persisted property)
	 * @return
	 */
	boolean isDynamic();
	
	/**
	 * Returns the id of the annotation, this is a free text field.
	 * @return
	 */
	String getId();
	
	/**
	 * Returns the title of the annotation, this is a free text field.
	 * @return
	 */
	String getTitle();
	
	/**
	 * Returns the type of annotation, this is a free text field.
	 * <p/>
	 * Is used to distinguish between annotations designed to support various uses. 
	 * The types are not enumerated, as these can be specified by the user or creator of the annotations. 
	 * The definitions and use of annotation types should be documented by their creator.
	 * @return
	 */
	String getType();
	
	/**
	 * This is a language-specific string which holds the text of the annotation.
	 * <p/>
	 * <strong>NOTE</strong>The list is a copy so modify the returned list will not 
	 * be reflected in the AnnotableBean instance.
	 * @return
	 */
	List<TextTypeWrapper> getText();
	
	
	List<TextTypeWrapper> getText(boolean disableLocaleFilter);
	
	/**
	 * Returns a URI - typically a URL - which points to an external resource which may contain or supplement the annotation. 
	 * <p/>
	 * If a specific behaviour is desired, an annotation type should be defined which specifies the use of this field more exactly.
	 * @return
	 */
	URI getUri();

}
