package io.sdmx.api.sdmx.model.mutable.valuelist;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface ValueListMutableBean extends MaintainableMutableBean {

	/**
	 * @return true if this is a partial list
	 */
	boolean isPartial();
	void setPartial(boolean partial);
	
	
	List<ValueItemMutableBean> getItems();
	
	void setItems(List<ValueItemMutableBean> items);
	void addItem(ValueItemMutableBean item);

	/**
	 * Adds an item to the list of items, at a specified position, creates a list if it does not already exist
	 * @param item
	 * @param pos
	 */
	void addItemAtPosition(ValueItemMutableBean item, int pos);
	
	/**
	 * override from parent
	 */
	@Override
	ValueListBean getImmutableInstance();
}
