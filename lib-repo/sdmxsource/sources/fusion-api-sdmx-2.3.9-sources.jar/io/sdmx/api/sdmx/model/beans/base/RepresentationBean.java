
package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Represents an SDMX Representation, this Bean references a TextFormat and / or a Codelist to define how the data should be 
 * represented
 * @author Matt Nelson
 *
 */
public interface RepresentationBean extends SdmxStructureBean {
	
	/**
	 * @return minimum number of values that can be reported against this attribute. 
	 */
	Integer getMinOccurs();
	
	/**
	 * @return maximum number of values that can be reported against this attribute
	 */
	Integer getMaxOccurs();
	
	/**
	 * @return true if the maximum number of occurrences is unbounded
	 */
	default boolean isUnboundedMax() {
		return getMaxOccurs() == Integer.MAX_VALUE;
	}
	

	/**
	 * Returns the text format, which is typically present for an uncoded component (one which does not reference a codelist).
	 * </p>
	 * Returns null if there is no text format present
	 * @return
	 */
	TextFormatBean getTextFormat();
	
	/**
	 * @return Text type from the text format, or null if there is no text format/text type
	 */
	default TEXT_TYPE getTextType() {
		TextFormatBean tf = getTextFormat();
		if(tf != null) {
			return tf.getTextType();
		}
		return null;
	}
	
	/**
	 * Returns the codelist or valuelist reference, returns null if there is no reference
	 * @return
	 */
	ICrossReferenceBean<? extends EnumeratedListBean> getRepresentation();
	
}
