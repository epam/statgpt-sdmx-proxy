package io.sdmx.api.sdmx.model.beans.pdq;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * A filter on a component in the DSD for a {@link IPreDefinedQueryBean}
 */
public interface IPreDefinedQueryComponentFilterBean extends SDMXBean, INoCrossReferencesBean {
 
	/**
	 * @return the component that is being filtered
	 */
	String getComponentId();
	
	/**
	 * @return map of filters which together are joined as an OR, i.e where FREQ= "A" OR "D" OR IN("Q", M");
	 */
	Map<MATCH_FUNCTION, Set<String>> getFilters();

}
