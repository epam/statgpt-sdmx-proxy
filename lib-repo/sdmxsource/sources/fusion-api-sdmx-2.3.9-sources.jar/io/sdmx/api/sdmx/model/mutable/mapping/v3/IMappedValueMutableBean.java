package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines the rule for a mapping from a single source value for example 
 * to map a value GBP, the value should simply be GBP.  However complex rules such as value must
 * start with GBP can be applied using value as GBP and an end index of 2 (0 indexed) which is interpreted as
 * the first three letters should be GBP.  The value may also be a regular expression used to pattern match.
 */
public interface IMappedValueMutableBean extends MutableBean {

	/**
	 * @return the value to match
	 */
	String getValue();
	IMappedValueMutableBean setValue(String value);
	
	/**
	 * @return true if the value should be processed as a regular expression
	 */
	boolean isRegEx();
	IMappedValueMutableBean setRegEx(boolean isRegEx);
	
	/**
	 * @return the start index of the string to match, zero indexed, -1 to indicate N/A
	 */
	int getStartIndex();
	IMappedValueMutableBean setStartIndex(int startIndex);

	/**
	 * @return the end index of the string to match, zero indexed, -1 to indicate N/A
	 */
	int getEndIndex();
	IMappedValueMutableBean setEndIndex(int endIndex);
	
}
