package io.sdmx.api.sdmx.model.superbeans.hierarchy;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.superbeans.base.IdentifiableSuperBean;

public interface HierarchicalCodeSuperBean extends IdentifiableSuperBean<HierarchicalCodeBean> {

	/**
	 * @return the resolved code
	 */
	CodeBean getCode();
	

	/**
	 * @return child code refs
	 */
	List<HierarchicalCodeSuperBean> getCodeRefs();
	 
}
