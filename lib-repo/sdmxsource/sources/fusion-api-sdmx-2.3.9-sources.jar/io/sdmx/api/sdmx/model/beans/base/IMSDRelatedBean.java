package io.sdmx.api.sdmx.model.beans.base;

/**
 *  Ultimately links back to a MSD, and can therefore be used to process data.
 *  
 *  This will be either a Metadata Provision Agreement, MetaDataflow, or MSD
 */
public interface IMSDRelatedBean extends MaintainableBean, ConstrainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<? extends IMSDRelatedBean> getURN();
	
}
