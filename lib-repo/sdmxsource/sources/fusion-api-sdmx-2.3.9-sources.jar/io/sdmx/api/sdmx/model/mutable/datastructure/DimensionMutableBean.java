
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;



public interface DimensionMutableBean extends ComponentMutableBean {

	boolean isMeasureDimension();
	
	boolean isFrequencyDimension();
	
	boolean isTimeDimension();
	
	void setMeasureDimension(boolean bool);
	
	void setFrequencyDimension(boolean bool);
	
	void setTimeDimension(boolean bool);
	
	List<StructureReferenceBean> getConceptRole();

	void addConceptRole(StructureReferenceBean conceptRole);
	
	void setConceptRole(List<StructureReferenceBean> conceptRole);
}
