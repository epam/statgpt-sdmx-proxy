package io.sdmx.api.sdmx.model.util;

import java.util.Collection;

public interface HierarchyNode<T> {

	
	/**
	 * Returns the items of this hierarchy
	 * @return
	 */
	Collection<HierarchicalItem<T>> getChildren();
}
