
package io.sdmx.api.sdmx.model.beans.process;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;


/**
 * ComputationType describes a computation in a process.
 * @author Matt Nelson
 *
 */
public interface ComputationBean extends AnnotableBean, INoCrossReferencesBean {

	/**
	 * The localID attribute is an optional identification for the computation within the process.
	 * @return
	 */
	String getLocalId();
	
	/**
	 * The softwarePackage attribute holds the name of the software package that is used to perform the computation.
	 * @return
	 */
	String getSoftwarePackage();
	
	/**
	 * The softwareLanguage attribute holds the coding language that the software package used to perform the computation is written in.
	 * @return
	 */
	
	String getSoftwareLanguage();
	
	/**
	 * The softwareVersion attribute hold the version of the software package that is used to perform that computation.
	 * @return
	 */
	String getSoftwareVersion();
	
	/**
	 * Description describe the computation in any form desired by the user 
	 * (these are informational rather than machine-actionable), 
	 * and so may be supplied in multiple, parallel-language versions,
	 * @return
	 */
	List<TextTypeWrapper> getDescription();
		
}
