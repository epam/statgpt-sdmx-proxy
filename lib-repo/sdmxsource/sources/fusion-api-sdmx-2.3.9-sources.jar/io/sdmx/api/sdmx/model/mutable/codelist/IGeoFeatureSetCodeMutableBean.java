package io.sdmx.api.sdmx.model.mutable.codelist;


public interface IGeoFeatureSetCodeMutableBean extends CodeMutableBean {

	/**
	 * @return  geo feature set, representing a set of points defining a feature in a format defined a predefined pattern
	 */
	String getGeoFeatureSet();
	void setGeoFeatureSet(String geoFeatureSet);
	
}
