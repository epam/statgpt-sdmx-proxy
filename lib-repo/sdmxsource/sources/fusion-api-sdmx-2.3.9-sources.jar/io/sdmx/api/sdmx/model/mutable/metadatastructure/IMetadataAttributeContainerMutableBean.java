package io.sdmx.api.sdmx.model.mutable.metadatastructure;

import java.util.List;

public interface IMetadataAttributeContainerMutableBean {
	List<MetadataAttributeMutableBean> getMetadataAttributes();
	void setMetadataAttributes(List<MetadataAttributeMutableBean> metadataAttributes);
	MetadataAttributeMutableBean addMetadataAttributes(MetadataAttributeMutableBean metadataAttributes);
}
