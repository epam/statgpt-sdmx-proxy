package io.sdmx.api.sdmx.model.beans;

import io.sdmx.api.sdmx.event.IStructureEvent;

/**
 * A beans event which has a transaction identification associated with it
 */
public interface ITransactionalBeansEvent extends IStructureEvent {

	/**
	 * @return the unique transaction id for this event
	 */
	Integer getTransactionId();
	
}