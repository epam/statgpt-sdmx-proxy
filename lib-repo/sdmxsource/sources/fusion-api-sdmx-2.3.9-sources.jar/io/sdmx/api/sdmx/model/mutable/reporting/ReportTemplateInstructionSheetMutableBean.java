package io.sdmx.api.sdmx.model.mutable.reporting;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ReportTemplateInstructionSheetMutableBean extends MutableBean {

	/**
	 * @return name of worksheet
	 */
	String getName();
	void setName(String name);
	
	/**
	 * @return optional title
	 */
	String getTitle();
	void setTitle(String title);
	
	/**
	 * @return immutable list of instructions
	 */
	List<ReportTemplateInstructionTextMutableBean> getInstructions();
	void addInstruction(ReportTemplateInstructionTextMutableBean instructionSheet);
	
}
