package io.sdmx.api.sdmx.model.beans.mapping.v3;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;

/**
 * Describes a mapping relationship between two Dataflows or data structures (DSDs).  Ultimatley the mapping rules
 * are defined for the DSD, even if the structure map is in the context of a Dataflow.
 */
public interface IStructureMapBean extends MaintainableBean, IStructureMapRelatedBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IStructureMapBean> getURN();
	
	/**
	 * Properties as reported in the Diff
	 */
	enum Properties {
		MAPPED_COMPONENTS("Mapped Components"),
		MAPPED_TIME_PATTERNS("Mapped Time Pattern"),
		MAPPED_EPOCHS("Mapped Epoch"),
		FIXED_INPUTS("Fixed outputs"),
		FIXED_OUTPUTS("Fixed inputs");
		
		private String property;
		
		private Properties(String property) {
			this.property = property;
		}

		public String getProperty() {
			return property;
		}
	}
	
	/**
	 * @return reference to the source DSD or Dataflow
	 */
	ICrossReferenceBean<? extends IStructureMapRelatedBean> getSourceRef();

	/**
	 * @return reference to the source DSD or Dataflow
	 */
	ICrossReferenceBean<? extends IStructureMapRelatedBean> getTargetRef();
	
	/**
	 * @return immutable map, component id to a fixed output values which is true for every mapping.  Map is empty if there are no fixed outputs
	 */
	Map<String, String> getFixedOutputs();
	
	/**
	 * A fixed input value describes expected inputs for a mapping to be true, for example a fixed input of DOMAIN=CGD would only 
	 * map data if the DOMAIN coming in is CGD, in all other cases, there are no mapped values
	 * 
	 * @return immutable map, component id to a fixed input values. Map is empty if there are no fixed inputs
	 */
	Map<String, String> getFixedInputs();
	
	/**
	 * @return immutable list to describe the relationship between the source and target components of the DSD
	 */
	List<IComponentMapBean> getComponentMaps();
	
	/**
	 * @return immutable list to describe the relationship between the a source component which reads time value corresponding to a pattern, and a target component which expects SDMX Time
	 */
	List<ITimePatternMapBean> getTimePatternMaps();
	
	/**
	 * @return immutable list to describe the relationship between the a source component which reads time value encoded as a numerical value, and a target component which expects SDMX Time
	 */
	List<IEpochMapBean> getEpochMap();
	
	/**
	 * <p>For Time Based Map rules: The output frequency determines the output date format (if not explicitly set), 
	 * but there can be ambiguous situations where there are two ways to format the same frequency. </p> 
	 * <p>
	 * To support this use case, the Structure Map can optionally reference a Time Format mapping to force explicit rules 
	 * on how the output time period is formatted.</p>  
	 * <p>
	 * A Time format mapping is a reference to a representation map, 
	 * the representation map is expected to contain a source frequency identifier, and a target pattern.</p>  
	 * 
	 * <p>For example A->YYYY.</p>
	 * 
	 * @return optional reference to a mapping relationship for time 
	 */
	ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	IStructureMapMutableBean getMutableInstance();
	
	
}
