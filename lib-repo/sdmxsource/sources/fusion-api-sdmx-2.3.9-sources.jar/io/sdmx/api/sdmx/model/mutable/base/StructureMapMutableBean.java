
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;

/**
 * @deprecated use  {@link IStructureMapMutableBean}
 *
 */
public interface StructureMapMutableBean extends SchemeMapMutableBean {
	
	/**
	 * Remove the components in this Structure Map that satisfy the given target id
	 * @param target
	 * @return true if a component was removed, false if not
	 */
	default boolean removeComponentByTarget(String target) {
		return this.getComponents().removeIf(comp -> {
		   List<String> mapTargetConceptRef = comp.getMapTargetConceptRef();
		   for (String ref : mapTargetConceptRef) {
			   if(ref.equals(target)) {
				   return true;
			   }
		   }
		   return false;
		});
	}
	
	List<ComponentMapMutableBean> getComponents();
	
	void setComponents(List<ComponentMapMutableBean> components);
	
	void addComponent(ComponentMapMutableBean component);
	
	boolean isExtension();

	void setExtension(boolean extension);	
	
}
