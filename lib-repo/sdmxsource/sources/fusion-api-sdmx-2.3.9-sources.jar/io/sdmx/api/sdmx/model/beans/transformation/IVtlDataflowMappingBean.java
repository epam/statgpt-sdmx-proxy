package io.sdmx.api.sdmx.model.beans.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;

public interface IVtlDataflowMappingBean extends IVtlMappingBean<DataflowBean> {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IVtlDataflowMappingBean> getURN();
	
	/**
	 * @return optional.  The mapping method used when mapping from SDMX to VTL.  This is typically a standandardToVtlMappingMethodType, 
	 * but can be any other value to allow for non-standard methods.  The implied default is basic
	 */
	String getFromMethod();
	
	/**
	 * @return optional.  The mapping method used when mapping from SDMX to VTL.  This is typically a standandardToVtlMappingMethodType, 
	 * but can be any other value to allow for non-standard methods.  The implied default is basic for single measure VTL data structures and Unpivot for
	 * multi-measure VTL data structures
	 */
	String getToMethod();
	
	
	/**
	 * @return immutable list, not null.  Identifies a sub space of the mapped dataflow that the mapping applies to. This is  a collection of references to the dimensions 
	 * that make up the space
	 */
	List<String> getFromSubSpace();
	
	/**
	 * @return immutable list, not null.  Identifies a sub space of the mapped dataflow that the mapping applies to. This is  a collection of references to the dimensions 
	 * that make up the space
	 */
	List<String> getToSubSpace();
	
}
