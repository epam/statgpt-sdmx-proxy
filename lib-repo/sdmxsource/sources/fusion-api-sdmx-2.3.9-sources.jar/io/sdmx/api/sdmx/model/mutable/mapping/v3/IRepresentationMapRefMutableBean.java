package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines either a reference to a Codelist or Value List - or a Data Type
 */
public interface IRepresentationMapRefMutableBean extends MutableBean{

	/**
	 * @return reference to a Codelist or Valuelist - can be null
	 */
	StructureReferenceBean getEnumerationRef(); 
	void setEnumerationRef(StructureReferenceBean ref); 
	
	TEXT_TYPE getTextType();
	void setTextType(TEXT_TYPE tt);
}
