
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;


/**
 * Constrains a series key (or wildcarded series key) by providing a list of key value pairs
 */
public interface ConstrainedDataKeyBean extends SdmxStructureBean, ValidityPeriodBean, INoCrossReferencesBean {
	
	/**
	 * @return true if the rule is for series to be allowed, false for exclusion
	 */
	boolean isIncluded();

	/**
	 * Returns the list of key values
	 * @return
	 */
	List<IConstrainedKeyValue> getKeyValues();
	
	/**
	 * Returns the list of Component values which are non-dimension (attribute or measure)
	 * @return
	 */
	List<IConstrainedKeyValue> getComponentValues();
	
	/**
	 * Returns the key value for the given dimension, returns null if none exist
	 * @param dimensionId
	 * @return
	 */
	IConstrainedKeyValue getKeyValue(String dimensionId);
	
}
