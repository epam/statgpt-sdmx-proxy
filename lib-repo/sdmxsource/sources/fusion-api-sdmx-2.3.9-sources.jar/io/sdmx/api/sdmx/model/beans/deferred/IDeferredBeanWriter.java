package io.sdmx.api.sdmx.model.beans.deferred;

import io.sdmx.api.io.IDeferred;
import io.sdmx.api.io.IDeferredWriter;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Writes MaintainableBean and has the ability to re-load from a given {@link IDeferred} object
 */
public interface IDeferredBeanWriter extends IDeferredWriter<MaintainableBean> {

}
