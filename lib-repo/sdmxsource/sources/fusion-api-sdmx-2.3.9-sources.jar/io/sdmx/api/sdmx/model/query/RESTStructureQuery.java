
package io.sdmx.api.sdmx.model.query;

import java.io.Serializable;

import io.sdmx.api.sdmx.model.beans.base.IURN;



/**
 * Represents a query for Maintainable Structure(s) and maps to the SDMX REST query
 * @author Matt Nelson
 *
 */
public interface RESTStructureQuery extends Serializable {


	/**
	 * Returns information about the response detail, and which referenced artefacts should be referenced in the response
	 * @return
	 */
	StructureQueryMetadata getStructureQueryMetadata();
	
	/**
	 * @return not null, structure reference, full or wildcarded
	 */
	IURN<?> getStructureReference();

}
