package io.sdmx.api.sdmx.model.beans.valuelist;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * An item in a value list, which has an Id (potentially non-sdmx conformant) and a value which may or may not be multilingual
 */
public interface ValueItemBean extends EnumeratedItemBean, AnnotableBean, INoCrossReferencesBean {
	
	
}

