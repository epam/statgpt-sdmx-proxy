package io.sdmx.api.sdmx.model.mutable.calculation;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ValidationRuleHierarchyMutableBean extends MutableBean {

	/**
	 * Returns a reference to a hierarchy which describes the expected aggregation totals - returns null if hasExpression() is true
	 * @return
	 */
	StructureReferenceBean getHierarchyReference();
	void setHierarchyReference(StructureReferenceBean ref);
	
	/**
	 * Get the reference to the Dimension that the hierarchy is applied to
	 * @return
	 */
	StructureReferenceBean getDimensionReference();
	void setDimensionReference(StructureReferenceBean ref);
}
