
package io.sdmx.api.sdmx.model.beans.metadatastructure;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IMSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;

/**
 * Represents an SDMX Provision Agreement
 * @author Matt Nelson
 *
 */
public interface MetadataProvisionAgreementBean extends MaintainableBean, ConstrainableBean, IMetadataTargetIdentifier, IMSDRelatedBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<MetadataProvisionAgreementBean> getURN();
	
	/**
	 * Returns the reference to the dataflow
	 * <p/>
	 * This reference is mandatory and will never return <code>null</code>
	 * 
	 * @return
	 */
	ICrossReferenceBean<MetadataFlowBean> getMetadataflowRef();
	
	/**
	 * Returns a reference to the data provider that this provision agreement is for. 
	 * <p/>
	 * This reference is mandatory and will never return <code>null</code>
	 * @return
	 */
	ICrossReferenceBean<IMetadataProviderBean> getMetadataProviderRef();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	IMetadataProvisionAgreementMutableBean getMutableInstance();
}
