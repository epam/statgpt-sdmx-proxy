package io.sdmx.api.sdmx.model.beans.calculation;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public interface ValidationRuleHierarchyBean extends SDMXBean {
	
	/**
	 * @return a reference to a hierarchy which describes the expected aggregation totals - returns null if hasExpression() is true
	 */
	ICrossReferenceBean<HierarchyBean> getHierarchyReference();
	
	/**
	 * Get the reference to the Dimension that the hierarchy is applied to
	 * @return
	 */
	ICrossReferenceBean<DimensionBean> getDimensionReference();
}
