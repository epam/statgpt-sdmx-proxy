
package io.sdmx.api.sdmx.model.beans;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;


/**
 * RegistryBeans is a container for all registry content including the following; SdmxBeans which is a container for all structural metadata,
 * RegistrationBeans and SubscriptionBeans.    
 * @author Matt Nelson
 *
 */
public interface RegistryBeans  {
	
	/**
	 * Returns true if there are SdmxBeans contained in this container
	 * @return
	 */
	boolean hasSdmxBeans();
	
	/**
	 * Returns the Sdmxbeans contained in this container, returns <code>null</code> if there are none
	 * @return
	 */
	SdmxBeans getSdmxBeans();
	
	/**
	 * Returns true if there are RegistrationBean contained in this container
	 * @return
	 */
	boolean hasRegistrationBean();
	
	/**
	 * Returns all the registrations in this container, returns an empty list if there are none
	 * @return
	 */
	List<RegistrationBean> getRegistrations();
	
	/**
	 * Returns true if there are SubscriptionBean contained in this container
	 * @return
	 */
	boolean hasSubscriptionBean();
	
	/**
	 * Returns all the subscriptions in this container, returns an empty list if there are none
	 */
	List<SubscriptionBean> getSubscriptions();
	
}
