package io.sdmx.api.sdmx.model.query;

import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.METADATA_QUERY_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.beans.base.IURN;

/**
 * Query for reference metadata, to match the SDMX REST API v2.0.0
 */
public interface IRESTMetadataQuery {

	/**
	 * The type will depend on the getQueryType:
	 * 
	 * METADATA_QUERY_TYPE.BY_METADATASET   - resolves to a IReportedMetadataSetBean
	 * METADATA_QUERY_TYPE.BY_METADATAFLOW  - resolves to a MetadataFlowBean
	 * METADATA_QUERY_TYPE.BY_STRUCTURE     - resolves to <? extends MaintainableBean>
	 * 
	 * @return not null, the urn containing filter parameters
	 */
	IURN<?> getURN();
	
	/**
	 * @return nullable, optional to request for the metadata as it was for a point in time
	 */
	SdmxDate getAsOf();
	
	/**
	 * @return the query detail for this structure query, can not be null
	 */
	STRUCTURE_QUERY_DETAIL getStructureQueryDetail();
	
	/**
	 * @return not null, list of additional path parameters, for query type of by metadataflow this can include the metadata provider id
	 */
	List<String> getAdditionalPathParameters();
	
	/**
	 * The query type is taken from the path parameter in the URL, i.e /metadata/dataflow resolves to metadata by flow 
	 * 
	 * @return not null, the query type, used to interpret how to handle the filter parameters
	 */
	METADATA_QUERY_TYPE getQueryType();
	
}
