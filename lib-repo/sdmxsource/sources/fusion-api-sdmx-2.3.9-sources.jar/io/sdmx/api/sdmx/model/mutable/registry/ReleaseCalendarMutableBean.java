
package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ReleaseCalendarMutableBean extends MutableBean {

	String getPeriodicity();
	
	void setPeriodicity(String periodicity);
	
	String getOffset();
	
	void setOffset(String offset);
	
	String getTolerance();
	
	void setTolerance(String tolerance);
}
