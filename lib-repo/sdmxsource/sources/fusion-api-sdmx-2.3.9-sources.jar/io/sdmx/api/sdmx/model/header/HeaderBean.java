package io.sdmx.api.sdmx.model.header;

import java.util.Date;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;


/**
 * A Header Contains any information to go at the beginning of an exchange message.
 */
public interface HeaderBean {
	public static final String DSD_REF = "DSD_REFERENCE";
	public static final String DSD_AGENCY_REF = "DSD_AGENCY_ID";
	public static final String DATASET_AGENCY = "DATASET_AGENCY";

	/**
	 * Copies the values from the merged in header, overwrites any values in this header, lists are overwritten if they exist in both this header and the merged in header
	 * @param header
	 */
	void merge(HeaderBean header);
	
	
	/**
	 * Returns true if this Header instance has a value stored for this property in its additional attributes @See getAdditionalAttributes()
	 * @param headerField
	 * @return
	 */
	boolean hasAdditionalAttribute(String headerField);

	/**
	 * Returns the header value for a given field. For example getHeaderValue(Header.DSD_REF) would return the value given for the keyFamilyRef (SDMX 2.0)
	 * @param headerField
	 * @return
	 */
	String getAdditionalAttribute(String headerField);

	/**
	 * Returns a map of any additional attributes that are stored in the header - the key is the field, such as Header.DSD_REF, the value is the value of that field
	 * @return
	 */
	Map<String, String> getAdditionalAttributes();

	/**
	 * Returns the data provider reference
	 * @return
	 */
	IURNSingle<DataProviderBean> getDataProviderReference();

	/**
	 * Sets the data provider reference
	 * @param dataProvider
	 */
	void setDataProviderReference(IURNSingle<DataProviderBean> dataProvider);


	/**
	 * Gets the action for the message
	 * @return
	 */
	DATASET_ACTION getAction();

	/**
	 * Sets the action for the message
	 * @param action
	 */
	void setAction(DATASET_ACTION action);

	/**
	 * Gets the id of the header
	 * @return
	 */
	String getId();

	/**
	 * Sets the id of the message, can not be null
	 * @param id
	 */
	void setId(String id);

	/**
	 * Gets a dataset id for the message
	 * @return
	 */
	String getDatasetId();

	/**
	 * Sets a dataset id for the message
	 * @param datasetId
	 */
	void setDatasetId(String datasetId);

	/**
	 * Returns the embargo date for the message
	 * @return embargo of null if undefined
	 */
	Date getEmbargoDate();

	/**
	 * Sets the embargo date for the message
	 * @param embargoDate
	 */
	void setEmbargoDate(Date embargoDate);

	/**
	 * Returns the extracted date for the message
	 * @return extracted or null if undefined
	 */
	Date getExtracted();

	/**
	 * @param extracted
	 */
	void setExtracted(Date extracted);

	/**
	 * Returns the prepared date for the message
	 * @return prepared or null if undefined
	 */
	Date getPrepared();

	/**
	 * Returns the name, or an empty list if none are defined
	 * @return
	 */
	List<TextTypeWrapper> getName();

	/**
	 * Adds a name to the list
	 * @param name
	 */
	void addName(TextTypeWrapper name);

	/**
	 * Returns the list of receivers or an empty list if none are defined
	 * @return
	 */
	List<PartyBean> getReceiver();

	/**
	 * Adds a receiver to the list of receivers
	 * @param receiver
	 */
	void addReceiver(PartyBean receiver);

	/**
	 * Replaces the receiver list with the receiver specified
	 * @param receiver
	 */
	void setReceiver(PartyBean receiver);

	/**
	 * Returns the reporting begin date
	 * @return
	 */
	Date getReportingBegin();

	/**
	 * Sets the reporting being date
	 * @param date
	 */
	void setReportingBegin(Date date);

	/**
	 * Returns the reporting end date
	 * @return
	 */
	Date getReportingEnd();

	/**
	 * Sets the reporting end date
	 * @param date
	 */
	void setReportingEnd(Date date);

	/**
	 * Returns the list of sources, or an empty list if none are defined
	 * @return
	 */
	List<TextTypeWrapper> getSource();

	/**
	 * Adds a source to the list of sources
	 * @param source
	 */
	void addSource(TextTypeWrapper source);

	/**
	 * Returns the sender
	 * @return
	 */
	PartyBean getSender();

	/**
	 * Sets the sender (can not be null)
	 * @param party
	 */
	void setSender(PartyBean party);

	/**
	 * Returns true if this is a test message
	 * @return
	 */
	boolean isTest();

	/**
	 * True if this is a test message
	 * @param test
	 */
	void setTest(boolean test);

	/**
	 * Returns the structure for the given id
	 * @param structureId
	 * @return
	 */
	DatasetStructureReferenceBean getStructureById(String structureId);

	/**
	 * Returns all data structure references
	 * @return
	 */
	List<DatasetStructureReferenceBean> getStructures();

	/**
	 * Adds a dataset structure reference to the list
	 */
	void addStructure(DatasetStructureReferenceBean ref);
}
