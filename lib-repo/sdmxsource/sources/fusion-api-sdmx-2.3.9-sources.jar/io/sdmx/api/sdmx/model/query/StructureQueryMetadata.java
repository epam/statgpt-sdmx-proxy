
package io.sdmx.api.sdmx.model.query;

import java.io.Serializable;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;

/**
 * Contains information about a Structure Query.  The information includes the response detail,
 * and which referenced artefacts should be  referenced in the response
 * @return
 */
public interface StructureQueryMetadata extends Serializable {

	/**
	 * Return the SdmxPeriod supplied by dateFrom = or/and dateTo =
	 * @return SdmxPeriod - the SdmxPeriod parsed by the date from and date to
	 */
	SdmxPeriod getValidFromTo();
	
	/**
	 * @return nullable, if not null the metadata must be returned as it was for this timestamp
	 */
	SdmxDate getAsOf();

	/**
	 * Returns the SdmxDate supplied by 'validOn' on the REST query.
	 * @return
	 */
	String getValidOn();

	/**
	 * Returns the query detail for this structure query, can not be null
	 * @return
	 */
	STRUCTURE_QUERY_DETAIL getStructureQueryDetail();

	/**
	 * Returns the reference detail for this structure query, can not be null
	 * @return
	 */
	STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail();

	/**
	 * If STRUCTURE_REFERENCE_DETAIL == SPECIFIC, this method will return the specific structure reference, returns null otherwise
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getSpecificStructureReference();
}
