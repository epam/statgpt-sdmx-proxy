
package io.sdmx.api.sdmx.model.mutable.categoryscheme;

import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface ReportingTaxonomyMutableBean extends ItemSchemeMutableBean<ReportingCategoryMutableBean> {
	
	
	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	ReportingTaxonomyBean getImmutableInstance();
}
