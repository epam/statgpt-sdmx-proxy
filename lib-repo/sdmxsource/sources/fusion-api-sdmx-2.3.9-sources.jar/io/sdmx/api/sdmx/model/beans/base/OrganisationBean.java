
package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;


/**
 * Represents an SDMX organisation such as an Agency, DataProvider or DataConsumer
 * @author Matt Nelson
 *
 */
public interface OrganisationBean extends ItemBean, INoCrossReferencesBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<? extends OrganisationBean> getURN();
	
	/**
	 * Returns a list of contacts for the organisation
	 * @return
	 */
	List<ContactBean> getContacts();
	
}
