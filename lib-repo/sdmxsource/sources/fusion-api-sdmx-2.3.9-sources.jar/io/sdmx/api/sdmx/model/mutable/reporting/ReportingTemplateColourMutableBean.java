package io.sdmx.api.sdmx.model.mutable.reporting;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Contains information about the attribute which is used to define the colours used in the observation cells
 */
public interface ReportingTemplateColourMutableBean extends MutableBean {

	/**
	 * Returns the id of the attribute to use
	 * @return
	 */
	String getAttributeId();
	void setAttributeId(String str);
	
	/**
	 * The default colour to use 
	 * @return
	 */
	String getDefaultColour();
	void setDefaultColour(String str);
	
	/**
	 * The Code Ids to associated colour with them
	 * @return
	 */
	Map<String, String> getColourCodes();
	void setColourCodes(Map<String, String> map);
	
	/**
	 * Returns a set of comma delimited series strings against the colour it is mapped to, e.g A,UK,FR=#C2C2C2
	 * @return
	 */
	Map<Set<String>, String> getSeriesColours();
	void setSeriesColours(Map<Set<String>, String> map);
	
	
}
