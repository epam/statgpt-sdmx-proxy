package io.sdmx.api.sdmx.model.mutable.calculation;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface ValidationRuleMutableBean extends ItemMutableBean {

	/**
	 * Returns the expression, returns null if hasExpression() is false
	 * 
	 * Example expression is [A:UK:TOTAL]=[A:UK:EMPLOYMENT]+[A:UK:UNEMPLOYMENT]
	 * 
	 * Or wildcarded:
	 * [::TOTAL]=[::EMPLOYMENT]+[::UNEMPLOYMENT]
	 * 
	 * @return
	 */
	String getExpression();
	
	void setExpression(String string);
	
	
	/**
	 * Returns the result of the expression, for example [::TOTAL]
	 * @return
	 */
	String getResultant();
	void setResultant(String resultant);
	
	/**
	 * Returns the equality operator
	 * @return
	 */
	EQUALITY getEqualityOperator();
	void setEqualityOperator(EQUALITY equality);
	
	/**
	 * Returns a reference to a hierarchy which describes the expected aggregation totals - returns null if hasExpression() is true
	 * @return
	 */
	ValidationRuleHierarchyMutableBean getHierarchyReference();
	
	/**
	 * Set a reference to a hierarchy which describes the expected aggregation totals - returns null if hasExpression() is true
	 * @return
	 */
	void setHierarchyReference(ValidationRuleHierarchyMutableBean ref);
	
	
	void setHierarchyReference(String hierarhcyURN, String dimURN);
}
