package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * <p>A specialisation of {@link ITimeComponentMapBean} used to describe a numerical representation of time, and how this maps to SDMX Time Periods.</p>
 * <br/>
 * <p>For example 1605719750 is 2020-11-18 if the Epoch is milliseconds and the base period is 1970 with output frequency as daily </p>
 */
public interface IEpochMapBean extends ITimeComponentMapBean, INoCrossReferencesBean {
	
	/**
	 * @return non null property, the start period where the first interval starts, for example UNIX Time would return 1970
	 */
	SdmxDate getBasePeriod();
	
	/**
	 * @return non null property, the duration of each interval, for example UNIX time would return MILLISECONDS
	 */
	EPOCH getEpochInterval();
	
}
