package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

/**
 * Defines how a variable e.g. REF_AREA maps to another variable e.g. CURRENCY_DEMON, so for example UK may map to the denominations UKP50, UKP20, UKP10, UKP5 
 * whereas USD would map to $100, $50,$20,$10,$5
 */
public interface ConditionalVariable extends SDMXBean {
	
	/**
	 * Returns the id of this variable, for example BANKNOTES
	 * @return
	 */
	String getId();
	
	/**
	 * Returns the name of this variable
	 * @return
	 */
	String getName();
	
	/**
	 * @return the alias of the dimension which the conditional variable relates to
	 */
	String getDataflowAlias();
	
	/**
	 * Returns the conditional dimension, for example REF_AREA
	 * @return
	 */
	String getDimensionCondition();
	
	/**
	 * Returns the condition map based on the id of the Dimension code
	 * @param id
	 * @return
	 */
	List<ConditionalVariableValues> getConditionalVariableValues();
	

}
