
package io.sdmx.api.sdmx.model.data;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;


/**
 * An Attributable artifact has the ability to contain attribute values
 */
public interface Attributable extends IPositionalDataElement {

	/**
	 * @return not null, immutable list of all the attribute values or an empty list if there are none
	 */
	List<KeyValue> getAttributes();
	
	/**
	 * Returns an attribute for the given concept/attribute id
	 * @return
	 */
	default KeyValue getAttribute(String concept) {
		for(KeyValue attr : getAttributes()) {
			if(attr.getConcept().equals(concept)) {
				return attr;
			}
		}
		return null;
	}

	/**
	 * returns a complex attribute for the given concept/attribute id
	 * @param concept
	 * @return
	 */
	IMultilingualKeyValue getMultilingualAttribute(String concept);

	/**
	 * @return an immutable list of all complex attribute values or an ampty list if there are none
	 */
	List<IMultilingualKeyValue> getMultilingualAttributes();

	/**
	 * Returns true if there are any annotations
	 * @return
	 */
	default boolean hasAnnotations() {
		return getAnnotations().size() > 0;
	}

	/**
	 * @return an immutable list of annotations or an empty list if there are none
	 */
	List<AnnotationBean> getAnnotations();
	
	/**
	 * Returns the value for the attribute or null if it does not exist
	 * @param concept
	 * @return
	 */
	default String getAttributeValue(String concept) {
		KeyValue kv = getAttribute(concept);
		if(kv == null) {
			return null;
		}
		return kv.getCode();
	}
	
	@Override
	/**
	 * @param obj
	 * @return true if all properties equal, ignoring Annotations and Position
	 */
	boolean equals(Object obj);
}
