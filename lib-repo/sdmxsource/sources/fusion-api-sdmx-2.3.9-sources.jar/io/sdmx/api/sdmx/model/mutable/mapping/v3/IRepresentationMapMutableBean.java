package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Represents a SDMX v3.0 representation map, where source and target can be one of the following:
 * <ul>
 *  <li>Codelist</li>
 *  <li>Valuelist</li>
 *  <li>Free Text</li>
 * </ul>
 * <p/>
 * The source and target can be mixed types allowing for Codelists to map to free text for example.
 * <p/>
 * SDMX v2.1 and lower only supports Codelist to Codelist mapping (via a structure called the CodelistMap)
 */
public interface IRepresentationMapMutableBean extends MaintainableMutableBean {
	

	/**
	 * Reverses the source and target references and mapped codes
	 * <br/>
	 * <p>A set of valid targets should be provided if the representation map contains regular expressions, or substring matches as the only way to know what the 
	 * matched targets are when reversing the rule, is to know what all the possible targets can be.  </p>
	 * <br/>
	 * <p><b>For Example:</b> </p>
	 * A rule that states that the source code starts with 'UK' maps to GB can not be reversed, as GB does not map to UK.  
	 * Knowing that valid inputs are UK1, UK2 and UK3 allows the rule to be re-written as 3 distinct rules, GB->UK1, GB->UK2, GB-UK3.  
	 *
	 * @param validSources - optional and only required for mappings whose source code defines a substring or regular expression match.
	 * @return this
	 */ 
	IRepresentationMapMutableBean reverseMapping(Set<String> validSources);

	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	IRepresentationMapBean getImmutableInstance();
	
	/**
	 * @return a Cross Reference to either a Codelist or Valuelist, a null response indicates that the source is free text
	 */
	List<IRepresentationMapRefMutableBean> getSourceRef();
	IRepresentationMapMutableBean setSourceRef(List<IRepresentationMapRefMutableBean> ref);
	IRepresentationMapMutableBean addSourceRef(StructureReferenceBean ref);
	IRepresentationMapMutableBean addSourceRef(TEXT_TYPE ref);
	
	/**
	 * @return a Cross Reference to either a Codelist or Valuelist, a null response indicates that the target is free text
	 */
	List<IRepresentationMapRefMutableBean> getTargetRef();
	IRepresentationMapMutableBean setTargetRef(List<IRepresentationMapRefMutableBean> ref);
	IRepresentationMapMutableBean addTargetRef(StructureReferenceBean ref);
	IRepresentationMapMutableBean addTargetRef(TEXT_TYPE ref);
	
	/**
	 * @return immutable list of mapped values, or an empty list if no mapped values exist
	 */
	List<IMappedRelationshipMutableBean> getMappedValues();
	IRepresentationMapMutableBean setMappedValues(List<IMappedRelationshipMutableBean> values);
	/**
	 * Creates, adds, and returns a new IMappedRelationshipMutableBean
	 * @return
	 */
	IMappedRelationshipMutableBean addMappedRelationship();
	
}
