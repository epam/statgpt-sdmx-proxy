
package io.sdmx.api.sdmx.model.beans.metadatastructure;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.IMetadataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;


/**
 * A MetadataAttributeBean is used in a <code>ReportStructureBean</code> and is similar to a <code>DimensionBean</code>
 * in that it contains reference to a semantic (<code>ConceptBean</code>) and representation (codelists/free text)
 * @author Matt Nelson
 *
 */
public interface MetadataAttributeBean extends IMetadataStructureComponentBean, MetadataAttributeContainerBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<MetadataAttributeBean> getURN();
	
	/**
	 * @return maximum number of values that can be reported against this attribute, Integer.MAX is unbounded
	 */
	@Override
	default int getMaxOccurs() {
		if(getRepresentation() != null  && getRepresentation().getMaxOccurs() != null) {
			return getRepresentation().getMaxOccurs();
		}
		return Integer.MAX_VALUE;
	}
	
	TERTIARY_BOOL getPresentational();
	
	/**
	/**
	 * Returns true if the TEXT Type is not XHTML and not of type Multilingual String
	 * @return
	 */
	boolean isSimpleText();
	
	/**
	 * Returns true if the TEXT Type is XHTML
	 * @return
	 */
	boolean isXHTML();
	
	/**
	 * Returns the position of the item in the list of items
	 * @return
	 */
	int getPosition();
	
}
