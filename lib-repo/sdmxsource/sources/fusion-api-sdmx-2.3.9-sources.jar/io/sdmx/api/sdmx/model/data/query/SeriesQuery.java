package io.sdmx.api.sdmx.model.data.query;

import java.util.Set;

/**
 * Defines a data query which is asking for a basket of series
 */
@Deprecated //use DataQuery which now supports series selections
public interface SeriesQuery extends BaseDataQuery {
	
	/**
	 * returns the id of the query, this can be used for calculation purposes
	 * @return
	 */
	String getId();
	
	/**
	 * <p>Returns an immutable list set containing the basket of series which are expected to be returned as a result of this query.</p>
	 * <p>The syntax is colon separated A:B:C:D</p>
	 * <p>Series can be wildcarded, and may contain + operators to indicate multiple selections, example: A:::D</p>
	 * @return
	 */
	Set<String> getSeries();
	
}
