
package io.sdmx.api.sdmx.model.beans.base;


/**
 * Represents an SDMX Data Provider
 * @author Matt Nelson
 *
 */
public interface IMetadataProviderBean extends OrganisationBean, ConstrainableBean{

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IMetadataProviderBean> getURN();
	
	
	@Override
	IMetadataProviderSchemeBean getMaintainableParent();
}
