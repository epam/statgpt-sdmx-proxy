package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents an enumerated item in an enumerated list (Codelist or ValueList being examples of enumerated lists)
 */
public interface EnumeratedItemBean extends INamedBean {


	/**
	 * @return id of parent item, or null if this item has no parent
	 */
	String getParentCode();


	/**
	 * Returns the position of the item in the list of items, 1 indexed
	 * @return
	 */
	int getPosition();

}
