
package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;



/**
 * Used to reference an SDMX identifiable artifact
 * @author Matt Nelson
 *
 */
@Deprecated //use IURN
public interface IdentifiableRefBean extends Serializable {
	
	/**
	 * Returns the identifiable structure that is being referenced (at this level of the referencing hierarchy)
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getStructureType();

	/**
	 * Returns the id of the identifiable that is being referenced (at this level of the referencing hierarchy)
	 * @return
	 */
	String getId();
	
	/**
	 * Returns a reference to the child identifiable artifact that is being referenced.
	 * returns null if there is no child identifiable being referenced (i.e. this is the end of the reference chain)
	 * @return
	 */
	IdentifiableRefBean getChildReference();
	
	/**
	 * Returns a reference to the parent identifiable artifact (not maintainable) that this identifiable
	 * artifact is a child of, returns null if the identifiable artifact has no parent identifiable artifact
	 * @return
	 */
	IdentifiableRefBean getParentIdentifiableReference();
	
	/**
	 * Returns a reference to the parent maintainable that this identifiable is a child of, this will never be null
	 * @return
	 */
	StructureReferenceBean getParentMaintainableReferece();
	
	/**
	 * Returns the matched identifiable bean, from the given identifiable - returns null if no match is found
	 * @param reference
	 * @return
	 */
	IdentifiableBean getMatch(IdentifiableBean reference);
	
}
