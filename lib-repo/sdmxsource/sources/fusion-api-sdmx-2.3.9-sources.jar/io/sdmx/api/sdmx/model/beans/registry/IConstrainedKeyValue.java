package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.collection.KeyValue;

public interface IConstrainedKeyValue extends KeyValue {
	
	boolean isRemovePrefix();
	
}
