package io.sdmx.api.sdmx.model.beans.refmetadata;

import java.net.URL;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;

/**
 * Represents a metadata set which is reported against a {@link MetadataProvisionAgreementBean}
 */
public interface IReportedMetadataSetBean extends MaintainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IReportedMetadataSetBean> getURN();
	
	/**
	 * @return reference to the provision agreement or dataflow that this metadata set is reported against
	 */
	ICrossReferenceBean<? extends IMetadataTargetIdentifier> getStructure();
	
	/**
	 * @return target structures (optionally wildcarded) for which the report is against
	 */
	List<ICrossReferenceBeanBase> getTargets();
	
	/**
	 * @return list of attributes in the report
	 */
	List<IReportedMetadataAttributeBean> getAttributes();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	IReportedMetadataSetMutableBean getMutableInstance();
	
	@Override
	IReportedMetadataSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
}
