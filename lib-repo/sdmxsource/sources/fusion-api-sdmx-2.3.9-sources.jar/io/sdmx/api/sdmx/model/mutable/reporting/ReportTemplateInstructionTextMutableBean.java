package io.sdmx.api.sdmx.model.mutable.reporting;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ReportTemplateInstructionTextMutableBean extends MutableBean {

	/**
	 * @return text content for the sheet, simple markdown supported
	 */
	String getContent();
	void setContent(String content);

	/**
	 * @return number of columns to merge to fit the content, text wrap is enabled
	 */
	int getColWidth();
	void setColWidth(int width);
	
	/**
	 * @return number of rows to merge to fit the content, text wrap is enabled
	 */
	int getColHeight();
	void setColHeight(int width);
	
}
