package io.sdmx.api.sdmx.model.data.calculation;

import java.util.List;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.exception.CalculationErrorHandler;

/**
 * Describes a validation which has an output code and input codes, it is possible to set the reported values for each input and output
 * for each shortcode which may represent a series key for example.  The ValidationExpression can then be used to validate the expression
 */
public interface ValidationExpression {
	
	/**
	 * @return true if the output code is actually a number instead of a code, for example 12 > UK + FR would return true, EUR = UK + FR would return false
	 */
	boolean isOutputNumerical();
	
	/**
	 * @return the equality operator to use on the inputs to test the output is correct
	 */
	EQUALITY getEquality();

	/**
	 * Returns the output code id
	 */
	String getOutputCode();

	/**
	 * Returns the input code ids that can be used by this expression
	 */
	List<String> getInputCodes();
	
	/**
	 * Add a reported output value for the short code
	 */
	void addOutput(String shortCode, Double value);
	
	/**
	 * Add a reported input value for the short code
	 */
	void addInput(String shortCode, int index, Double value);

	/**
	 * Validate this expression with the data that has been added via the addOutput and addInput methods 
	 */
	void validate(CalculationErrorHandler errorHandler);
}
