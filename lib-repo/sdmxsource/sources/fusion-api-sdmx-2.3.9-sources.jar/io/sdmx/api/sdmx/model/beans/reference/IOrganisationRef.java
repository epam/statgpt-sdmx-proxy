package io.sdmx.api.sdmx.model.beans.reference;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;

/**
 * Reference to 1 or more organisations
 */
public interface IOrganisationRef {

	/**
	 * @return an optional agency Id to which the oranisation(s) belong
	 */
	String getAgencyId();
	
	/**
	 * @return not null, min size 1 set of organisation ids 
	 */
	Set<String> getOrganisationIds();
	
	/**
	 * @return the organisation type
	 */
	SDMX_STRUCTURE_TYPE getOrganisationType();
}
