package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface IVtlSchemeMutableBean<T extends ItemMutableBean> extends ItemSchemeMutableBean<T> {

	/**
	 * @return the version of VTL that this scheme is compliant with
	 */
	String getVtlVersion();
	void setVtlVersion(String vtlVersion);
}
