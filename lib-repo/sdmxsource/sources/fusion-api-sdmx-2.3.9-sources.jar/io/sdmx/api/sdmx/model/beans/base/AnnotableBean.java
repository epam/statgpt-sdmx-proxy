package io.sdmx.api.sdmx.model.beans.base;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * An AnnotableBean Bean is one which can contain annotations
 * <p/>
 * This is an immutable bean - this bean can not be modified
 * 
 * @author Matt Nelson
 */
public interface AnnotableBean extends SdmxStructureBean {
	static final Set<String> INTERNAL = new HashSet<>();  //A Set of INTERNAL Annotations (by Title), not output on getAnnotations() method, unless explicity told to do so
	static final String INCLUDE_INTERNAL_KEY = "INCLUDE_INTERNAL_ANNOTATIONS";
	
	/**
	 * Returns the list of annotations 
	 * <p/>
	 * <strong>NOTE</strong>The list is a copy so modify the returned list will not 
	 * be reflected in the AnnotableBean instance
	 * @return 
	 */
	List<AnnotationBean> getAnnotations();
	
	/**
	 * Returns true if this bean has an annotation with the given type
	 * @param annoationType
	 * @return
	 */
	boolean hasAnnotationType(String annoationType);
	
	/**
	 * Returns the annotations with the given type, returns an empty Set is no annotations exist that have a type which
	 * matches the given String
	 * @param type
	 * @return
	 */
	Set<AnnotationBean> getAnnotationsByType(String type);
	
	/**
	 * Returns the annotations with the given title, returns an empty Set is no annotations exist that have a type which
	 * matches the given String
	 * @param type
	 * @return
	 */
	Set<AnnotationBean> getAnnotationsByTitle(String title);

}
