package io.sdmx.api.sdmx.model.data;

/**
 * Interfaces that extend {@link IPositionalDataElement} have the ability to know their original location
 * in a Dataset.
 * 
 * The type of positional information depends on the data format, for example a text file based format may know its position
 * based on byte offset from the start of the file, whereas an Excel file format may define position by workbook, row, and column index.
 * 
 */
public interface IPositionalDataElement {

	/**
	 * @return position, optional - only present if the dataset is both able to and is recording its position
	 */
	IDataPosition getPosition();
	
	
	default boolean hasPositionInforamtion() {
		return getPosition() != null;
	}
}
