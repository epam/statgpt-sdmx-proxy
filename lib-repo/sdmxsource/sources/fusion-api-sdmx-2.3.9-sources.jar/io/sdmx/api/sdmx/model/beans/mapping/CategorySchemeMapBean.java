
package io.sdmx.api.sdmx.model.beans.mapping;


/**
 * Represents an SDMX Category Scheme Map
 * @author Matt Nelson
 *
 * @deprecated use mapping.v3
 */
@Deprecated
public interface CategorySchemeMapBean extends ItemSchemeMapBean<ItemMapBean> {

	
}
