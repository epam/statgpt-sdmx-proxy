
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;


public interface CubeRegionMutableBean extends MutableBean {

	List<KeyValuesMutable> getKeyValues();
	
	void setKeyValues(List<KeyValuesMutable> keyvalues);
	
	void addKeyValues(KeyValuesMutable keyvalue);

	List<KeyValuesMutable> getAttributeValues();
	
	void setAttributeValues(List<KeyValuesMutable> attvalues);
	
	void addAttributeValue(KeyValuesMutable attvalue);

}
