
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface ConstraintBean extends MaintainableBean {

	/**
	 * Returns the series keys that this constraint defines as ones that either 
	 * have data, or are allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetBean getIncludedSeriesKeys();
	
	
	/**
	 * Returns the series keys that this constraint defines as ones that either 
	 * do not have data, or are not allowed to have data (depending on isDefiningActualDataPresent() value)
	 * @return
	 */
	ConstraintDataKeySetBean getExcludedSeriesKeys();
	
	
	
	/**
	 * Returns the structure(s) that this constraint is constraining.
	 * @return
	 */
	ConstraintAttachmentBean getConstraintAttachment();
	
}
