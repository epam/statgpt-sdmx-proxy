package io.sdmx.api.sdmx.model.beans.calculation;

import java.util.List;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;

/**
 * A validation rule, to describe a mathematical expression, contains a unique id, and has a name and optional description.
 * <p/>
 * A validation rule either consists of an mathematical expression, or a link to a hierarchy reference, it does not contain both
 *
 */
public interface ValidationRuleBean extends ItemBean, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<ValidationRuleBean> getURN();
	
	/**
	 * Expression result type
	 * @author Matt Nelson
	 *
	 */
	enum EXPRESSION_RESULT {
		NUMBER,
		SERIES
	}
	
	/**
	 * Returns the expression, returns null if hasExpression() is false
	 * 
	 * Example expression is 
	 * [A:UK:EMPLOYMENT]+[A:UK:UNEMPLOYMENT]+[A:UK:UNEMPLOYMENT]
	 * [A:UK:EMPLOYMENT]*[A:UK:UNEMPLOYMENT]
	 * [A:UK:EMPLOYMENT]*[A:UK:UNEMPLOYMENT]-[A:UK:UNEMPLOYMENT]
	 * 
	 * Or wildcarded:
	 * [::EMPLOYMENT]+[::UNEMPLOYMENT]
	 * 
	 * @return
	 */
	String getExpression();
	
	/**
	 * Returns the expression with the series filters replaced with variables a[x], where [x] is an integer started from 0
	 * @param an optional array to replace the variables a[x] with something else
	 * @return
	 */
	String getExpressionDeReferenced(String...replacements);
	
	/**
	 * Returns a list of series filters for the expression, where each String is a series filter ":" separated code which can be used to replace the 
	 * expression at index i, wildcarded values are null entries in the array
	 * @return
	 */
	List<String> getExpressionSeries();
	
	/**
	 * Returns the result of the expression, for example [::TOTAL]
	 * @return
	 */
	String getResultant();
	
	/**
	 * In the case where the resultant is not numerical, it will be a series. Returns the output series as ":" separated code ids, where wildcarded values are empty string entries in the array
	 * @return
	 */
	String getOutputSeries();
	
	/**
	 * Returns the result type for this expression, either numerical or an output series
	 * @return
	 */
	EXPRESSION_RESULT getResultType();
	
	/**
	 * Returns the equality operator
	 * @return
	 */
	EQUALITY getEqualityOperator();
	
	/**
	 * Returns true if this rule contains a mathematical expression, false if it contains a reference to a Hierarchy
	 * @return
	 */
	boolean hasExpression();
	
	/**
	 * Returns true if this rule has a validaiton hierarhcy
	 * @return
	 */
	boolean hasValidationHierarchy();
	
	/**
	 * Returns a validation hierarchy which describes the expected aggregation totals - returns null if hasExpression() is true
	 * @return
	 */
	ValidationRuleHierarchyBean getValidationHierarchy();
	
}
