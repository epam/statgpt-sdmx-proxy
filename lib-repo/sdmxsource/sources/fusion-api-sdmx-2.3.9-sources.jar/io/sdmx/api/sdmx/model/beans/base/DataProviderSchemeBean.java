
package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;


/**
 * Represents an SDMX Data Provider Scheme
 * @author Matt Nelson
 *
 */
public interface DataProviderSchemeBean extends OrganisationSchemeBean<DataProviderBean> {
	static final String FIXED_ID = "DATA_PROVIDERS";
	static final String FIXED_VERSION = "1.0";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<DataProviderSchemeBean> getURN();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	DataProviderSchemeMutableBean getMutableInstance();
}
