package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Describes a mapping relationship between two Dataflows or data structures (DSDs).  Ultimatley the mapping rules
 * are defined for the DSD, even if the structure map is in the context of a Dataflow.
 */
public interface IStructureMapMutableBean extends MaintainableMutableBean {
	
	/**
	 * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	 * after this point will not be reflected in the returned instance of the MaintainableBean.
	 * @return
	 */
	IStructureMapBean getImmutableInstance();
	
	/**
	 * Reverses the source and target references and components
	 * @return itself
	 */
	IStructureMapMutableBean reverseMapping();
	
	/**
	 * @return component id to a fixed output values which is true for every mapping.  Map is empty if there are no fixed outputs
	 */
	Map<String, String> getFixedOutputs();
	IStructureMapMutableBean addFixedOutput(String componentId, String outputValue);
	void setFixedOutputs(Map<String, String> outputs);

	/**
	 * A fixed input value describes expected inputs for a mapping to be true, for example a fixed input of DOMAIN=CGD would only 
	 * map data if the DOMAIN coming in is CGD, in all other cases, there are no mapped values
	 * 
	 * @return immutable map, component id to a fixed input values. Map is empty if there are no fixed inputs
	 */
	Map<String, String> getFixedInputs();
	IStructureMapMutableBean addFixedInput(String componentId, String outputValue);
	void setFixedInputs(Map<String, String> inputs);
	
	/**
	 * @return reference to the source DSD or Dataflow
	 */
	StructureReferenceBean getSourceRef();
	IStructureMapMutableBean setSourceRef(StructureReferenceBean sourceRef);
	

	/**
	 * @return reference to the source DSD or Dataflow
	 */
	StructureReferenceBean getTargetRef();
	IStructureMapMutableBean setTargetRef(StructureReferenceBean targetRef);
	
	/**
	 * @return immutable list to describe the relationship between the source and target components of the DSD
	 */
	List<IComponentMapMutableBean> getComponentMaps();
	IStructureMapMutableBean setComponentMaps(List<IComponentMapMutableBean> componentMaps);
	/**
	 * Creates, adds, and returns a component map
	 * @return
	 */
	IComponentMapMutableBean addComponentMap();
	
	/**
	 * @return list to describe the relationship between the a source component which reads time value corresponding to a pattern, and a target component which expects SDMX Time
	 */
	List<ITimePatternMapMutableBean> getTimePatternMaps();
	/**
	 * Creates, adds, and returns a ITimePatternMapMutableBean
	 * @return
	 */
	ITimePatternMapMutableBean addTimePatternMap();
	
	/**
	 * @return list to describe the relationship between the a source component which reads time value encoded as a numerical value, and a target component which expects SDMX Time
	 */
	List<IEpochMapMutableBean> getEpochMap();
	
	/**
	 * Creates, adds, and returns a IEpochMapMutableBean
	 * @return
	 */
	IEpochMapMutableBean addEpochMap();
	
	/**
	 * <p>For Time Based Map rules: The output frequency determines the output date format (if not explicitly set), 
	 * but there can be ambiguous situations where there are two ways to format the same frequency. </p> 
	 * <p>
	 * To support this use case, the Structure Map can optionally reference a Time Format mapping to force explicit rules 
	 * on how the output time period is formatted.</p>  
	 * <p>
	 * A Time format mapping is a reference to a representation map, 
	 * the representation map is expected to contain a source frequency identifier, and a target pattern.</p>  
	 * 
	 * <p>For example A->YYYY.</p>
	 * 
	 * @return optional reference to a mapping relationship for time 
	 */
	StructureReferenceBean getTimeFormatMapping();
	IStructureMapMutableBean setTimeFormatMapping(StructureReferenceBean timeFormatMapping);
}
