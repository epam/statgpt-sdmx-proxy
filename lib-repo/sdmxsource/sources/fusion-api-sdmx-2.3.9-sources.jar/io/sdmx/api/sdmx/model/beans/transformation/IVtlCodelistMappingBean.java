package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;

public interface IVtlCodelistMappingBean extends IVtlMappingBean<CodelistBean> {
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<IVtlCodelistMappingBean> getURN();
}
