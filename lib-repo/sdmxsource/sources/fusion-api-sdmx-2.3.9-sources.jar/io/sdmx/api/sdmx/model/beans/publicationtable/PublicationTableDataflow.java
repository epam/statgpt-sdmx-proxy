package io.sdmx.api.sdmx.model.beans.publicationtable;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Defines a reference to a dataflow, the reference can be referred to by the id
 */
public interface PublicationTableDataflow extends SDMXBean {
	
	/**
	 * Returns the alias of this reference
	 * @return
	 */
	String getAlias();
	
	/**
	 * Returns the cross reference to the dataflow
	 * @return
	 */
	ICrossReferenceBean<DataflowBean> getDataflowRef();
	
	
}
