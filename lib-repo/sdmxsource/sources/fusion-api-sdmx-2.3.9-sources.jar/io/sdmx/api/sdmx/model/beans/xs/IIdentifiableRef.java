package io.sdmx.api.sdmx.model.beans.xs;

import java.io.Serializable;


public interface IIdentifiableRef extends Serializable  {
	
	String getId();
	
	
}
