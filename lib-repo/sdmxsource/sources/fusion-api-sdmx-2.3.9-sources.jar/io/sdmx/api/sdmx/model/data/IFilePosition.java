package io.sdmx.api.sdmx.model.data;

/**
 * Position in a file which can be read and understood as text, i.e. XML, EDI, CSV 
 */
public interface IFilePosition extends IDataPosition {

	/**
	 * @return offset, in bytes, of the input fragment from the beginning of the input stream
	 */
	long getOffset();
	
	/**
	 * 
	 * @return length, in bytes, of the input fragment
	 */
	long getBytes();
	
	/**
	 * Overridden to provide additional JavaDoc to describe response
	 * 
	 * fip:[offset]:[bytes] 
	 * 
	 * example
	 * 
	 * fip:200:23
	 * 
	 */
	@Override
	String toPositionalString();
	
}
