
package io.sdmx.api.sdmx.model.submissionresponse;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;

/**
 * Response from a SDMX Registry for a Registration submission
 */
public interface SubmitRegistrationResponse  {

	RegistrationBean getRegistration();
	
	/**
	 * Returns true if getErrorList() returns a not null ErrorList, and the returned ErrorList is of type error (not warning)
	 * @return
	 */
	boolean isError();
	
	/**
	 * Returns the list of errors, returns null if there were no errors for this response (if it was a success)
	 * @return
	 */
	ErrorList getErrorList();
	
}
