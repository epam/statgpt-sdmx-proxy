
package io.sdmx.api.sdmx.model.beans.reference.complex;

import io.sdmx.api.sdmx.constants.TEXT_SEARCH;

/**
 * Used to search for items with certain text fields 
 * @see ComplexStructureReferenceBean
 */
@Deprecated //unused
public interface ComplexTextReference {
	
	/**
	 * Returns the language to search, this can be null
	 * @return
	 */
	String getLanguage();
	
	/**
	 * Returns the operator to apply, can not be null, defaults to EQUAL
	 * @return
	 */
	TEXT_SEARCH getOperator();
	
	/**
	 * Returns the seach String, can not be null or empty
	 * @return
	 */
	String getSearchParameter();
}
