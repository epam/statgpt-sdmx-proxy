package io.sdmx.api.sdmx.model.beans.codelist;

public interface IGeoFeatureSetCodeBean extends CodeBean {

	/**
	 * @return  a set of points defining a feature in a format defined a predefined pattern
	 */
	String getGeoFeatureSet();
	
}
