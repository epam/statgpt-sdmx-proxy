package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface IVtlMappingMutableBean extends ItemMutableBean {

	/**
	 * @return nullable. The reference used to refer to the reference SDMX artefact in the transformations. 
	 * This must be unique within th emappping scheme in which it is defined.
	 */
	String getAlias();
	void setAlias(String alias);
	
	/**
	 * @return nullable. The reference to the mapped structure that the mapping is defined for.
	 */
	StructureReferenceBean getMapped();
	void setMapped(StructureReferenceBean  mapped);
}
