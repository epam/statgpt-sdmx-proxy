
package io.sdmx.api.sdmx.model.mutable.base;



public interface DataConsumerMutableBean extends OrganisationMutableBean {

}
