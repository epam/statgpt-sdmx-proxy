
package io.sdmx.api.sdmx.model.beans.mapping;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * Represents an SDMX Component Map
 * @author Matt Nelson
 *
 */
public interface ComponentMapBean extends AnnotableBean, INoCrossReferencesBean {
	
	List<String> getMapConceptRef();
	
	List<String> getMapTargetConceptRef();
	
	RepresentationMapRefBean getRepMapRef();
}
