package io.sdmx.api.sdmx.model.beans.publicationtable;

import java.util.List;

/**
 * An object that can have a style applied to it
 */
public interface Styleable   {

	/**
	 * Returns the styles or an empty list if no styles are defined
	 */
	List<String> getStyles();
	
}
