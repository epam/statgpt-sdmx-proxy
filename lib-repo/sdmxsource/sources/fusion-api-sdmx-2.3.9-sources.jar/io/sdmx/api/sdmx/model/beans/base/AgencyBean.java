package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents an SDMX Agency
 * @author Matt Nelson
 *
 */
public interface AgencyBean extends OrganisationBean  {
	static final String DEFAULT_AGENCY = "SDMX";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<AgencyBean> getURN();
	
	/**
	 * Returns the id of the agency scheme concatenated with the id of the agency, for all agencies that are not in the default scheme.
	 * If an Agency is in the default scheme, this method will just return the agencies' id.
	 * @return the id
	 */
	String getFullId();
	
	@Override
	AgencySchemeBean getMaintainableParent();
}
