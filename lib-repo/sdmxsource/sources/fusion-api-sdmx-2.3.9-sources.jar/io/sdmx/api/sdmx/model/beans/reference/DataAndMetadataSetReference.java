
package io.sdmx.api.sdmx.model.beans.reference;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.mutable.reference.DataAndMetadataSetMutableReference;

/**
 * Represents a SDMX Data and MetadataSet Reference
 */
public interface DataAndMetadataSetReference extends SDMXBean {

	/**
	 * Returns the dataset referenced by data flow/provider/provision
	 * @return
	 */
	ICrossReferenceBean<?> getDataSetReference();
	
	/**
	 * Returns the id of the data or metadata set
	 * @return
	 */
	String getSetId();
	
	/**
	 * Returns true if this is a dataset reference, false if it is a metadata set reference
	 * @return
	 */
	boolean isDataSetReference();
	
	/**
	 * Returns a mutable version
	 * @return
	 */
	DataAndMetadataSetMutableReference createMutableInstance();
}
