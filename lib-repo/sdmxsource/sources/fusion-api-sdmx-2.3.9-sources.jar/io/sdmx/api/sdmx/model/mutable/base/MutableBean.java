
package io.sdmx.api.sdmx.model.mutable.base;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface MutableBean extends Serializable  {

	/**
	 * Returns the structure type of this component.
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getStructureType();
	
	/**
	 * Returns a list of StructureReferenceBean this bean references, or any composite bean of this bean.  Note this is a list
	 * as the same references may be made multiple times in the same MutableBean
	 * 
	 * @return
	 */
	List<StructureReferenceBean> getStructureReferences();
	
	/**
	 * Returns the parent mutable bean.  Note there is no guarantee this will return anything.
	 * @return
	 */
	MutableBean getParent();
	
	/**
	 * Recurses up the parent hierarchy to return the first occurrence of parent of the given type that this MutableBean belongs to 
	 * <p/>
	 * If a parent of the given type does not exist in the hierarchy, null will be returned
	 * @param includeThisInSearch if true then this type will be first checked to see if it is of the given type
	 * @return
	 */
	<T> T getParent(Class<T> type, boolean includeThisInSearch);
	
	/**
	 * Returns a set of composite beans to this bean
	 * @return
	 */
	Set<MutableBean> getComposites();
	
	/**
	 * Returns any composites of this SdmxBean of the given type
	 * @param <T>
	 * @param type
	 * @return
	 */
	<T> Set<T> getComposites(Class<T> type);
}
