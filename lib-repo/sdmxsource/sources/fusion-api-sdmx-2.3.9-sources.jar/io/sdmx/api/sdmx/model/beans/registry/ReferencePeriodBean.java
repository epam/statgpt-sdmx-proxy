
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;

/**
 * Represents an SDMX Rererence Period
 * @author Matt Nelson
 *
 */
public interface ReferencePeriodBean extends SdmxStructureBean, INoCrossReferencesBean {

	/**
	 * Returns an inclusive start time for the reference period
	 * @return an inclusive start time for the reference period, not null
	 */
	SdmxDate getStartTime();
	
	/**
	 * Returns an inclusive end time for the reference period
	 * @return an inclusive end time for the reference period, not null
	 */
	SdmxDate getEndTime();
	
	/**
	 * Returns a mutable version
	 * @return
	 */
	ReferencePeriodMutableBean createMutableBean();
}
