
package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;


/**
 * A StructureReferenceBean is used to reference an identifiable artifact using a combination of reference parameters.  
 * 
 * It is a mutable bean
 * 
 * <p/>
 * If all reference parameters are present then the reference is for a single identifiable item, if any are missing, then this represents
 * a wildcard parameter / or ALL.
 * <p/>
 * SDMX_STRUCTURE_TYPE is a mandatory reference parameter, all others are optional
 * 
 * @author Matt Nelson
 */
public interface StructureReferenceBean extends Serializable, IMaintainableRef {

	default IURNAbsolute<?> buildURNAbsolute() {
		return getURN().asAbsolute();
	}
	
	default <T extends IdentifiableBean> IURNAbsolute<T> buildURNAbsolute(Class<T> claz) {
		return buildURNAbsolute().toType(claz);
	}
	
	default IURNSingle<?> buildURNSingle() {
		return getURN().asSingle();
	}
	
	default <T extends IdentifiableBean> IURNSingle<T> buildURNSingle(Class<T> claz) {
		return buildURNSingle().toType(claz);
	}
	
	default <T extends IdentifiableBean> IURN<T> buildURN(Class<T> claz) {
		return getURN().toType(claz);
	}

	IURN<?> getURN();
	
	void setAgencyId(String agencyId);
	void setMaintainableId(String maintId);
	void setIdentifiableId(String identId);
	void setVersion(String version);
	void setVersion(IVersionRef versionRef);
	
	/**
	 * Returns the SDMX Structure that is being referenced at the top level (maintainable level) by this reference bean.
	 * <p/>
	 * Any child references will further refine the structure type that is being referenced.
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getMaintainableStructureType();
	
	/**
	 * Returns the SDMX Structure that is being referenced by this reference bean.
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getTargetReference();
	
	/**
	 * Returns a string array of any child ids (obtained from getChildReference()), returns null if getChildReference() is null
	 * @return
	 */
	String[] getIdentifiableIds();
	
	/**
	 * Returns the full id of the identifiable reference.  This is a dot '.' separated id which consists of the parent identifiable ids and the target.
	 * If the referenced structure is a Sub-Agency then this will include the parent Agency ids, and the id of the target agency.  If this reference
	 * is referencing a maintainable then null will be returned.  If there is only one child identifiable, then the id of that identifable will be returned, with no '.' seperators.
	 * 
	 * @return
	 */
	String getFullId();

	/**
	 * Returns the reference parameters as a maintainable reference
	 * @return
	 */
	IMaintainableRef getMaintainableReference();
	
	/**
	 * Returns true if getChildReference returns a value
	 * @return
	 */
	boolean hasChildReference();
	
	/**
	 * Returns the URN of the target structure that is being referenced, returns null if there is no URN available
	 */
	String getTargetUrn();
	
	/**
	 * @param includeWildcards if true, then any missing URN parts will be replaced with a *
	 * @return
	 */
	String getTargetUrn(boolean includeWildcards);

	/**
	 * Returns true if getTargetUrn returns a value
	 * @return
	 */
	boolean hasTargetUrn();
	
	/**
	 * Returns the URN of the maintainable structure that is being referenced, returns null if there is no URN available
	 */
	String getMaintainableUrn();

	/**
	 * Returns true if this reference matches the MaintainableBean, or one of its identifiable composites.
	 * <p/>
	 * This bean does not require all reference parameters to be set, this method will return true if all the parameters that are set match
	 * the bean passed in.  If this reference is referencing an Identifiable composite, then the maintainable's identifiable composites will also be
	 * checked to determine if this is a match.
	 * 
	 * @param reference
	 * @return
	 */
	boolean hasMatch(MaintainableBean reference);
	
	/**
	 * Returns the matched Identifiable Beans from this reference, returns the original Maintainable if this is a Maintainable reference that matches the maintainable.  Returns null if no match
	 * is found
	 * @param maintainbleBean
	 * @return
	 */
	Set<IdentifiableBean> getMatches(MaintainableBean maintainbleBean);

	/**
	 * Returns whether this references an explicit (i.e. not wild-carded) identifiable child
	 * @return
	 */
	boolean referencesIdentifiableChild();
}
