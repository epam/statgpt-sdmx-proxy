
package io.sdmx.api.sdmx.model.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface MetadataTargetKeyValuesMutable extends KeyValuesMutable {

	List<StructureReferenceBean> getObjectReferences();
	
	void setObjectReferences(List<StructureReferenceBean> sRef);

	void addObjectReference(StructureReferenceBean sRef);
	

	List<DataSetReferenceMutableBean> getDatasetReferences();

	void setDatasetReferences(List<DataSetReferenceMutableBean> datasetReference);

	void addDatasetReference(DataSetReferenceMutableBean reference);

}
