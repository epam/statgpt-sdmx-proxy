
package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

import java.util.regex.Pattern;
/**
 * Represents an SDMX Item Map - cross references are built on the parent ItemSchemeMap
 */
public interface IItemMapBean extends AnnotableBean, INoCrossReferencesBean {

	/**
	 * @return true if the source mapping references the source by absolute ID, not using a pattern or with substring mapping
	 */
	default boolean isSourceAbsolute() {
		if(isSourceRegEx()) return false;
		if(getSourceStartIdx() > 0 || getSourceEndIdx() > 0) return false;
		return true;
	}
	
	/**
	 * @return true if the target mapping references the target by absolute ID, not using a regEx capture group
	 */
	default boolean isTargetAbsolute() {
		if(!isSourceRegEx()) return true;
		if(getTargetId().contains("\\")) return false;  //source is regex and target contains a capture group reference (i.e) \1
		return true;
	}
	
	/**
	 * @return not null, the ID of the map from Item
	 */
	String getSourceId();

	/**
	 * @return not null, the ID of the map to Item
	 */
	String getTargetId();
	
	/**
	 * @param idx nullable
	 * @return the index to substring the source ID
	 */
	Integer getSourceStartIdx();
	
	/**
	 * @param idx nullable
	 * @return the index to substring the source ID
	 */
	Integer getSourceEndIdx();
	
	/**
	 * if the source value is a regular expression
	 */
	boolean isSourceRegEx();
	
	/**
	 * @return nullable, the period which this mapping is valid for
	 */
	SdmxPeriod getValidityPeriod();

	/**
	 * 
	 * @return compiled pattern or null if source is not regex
	 */
	Pattern getSourcePattern();
}
