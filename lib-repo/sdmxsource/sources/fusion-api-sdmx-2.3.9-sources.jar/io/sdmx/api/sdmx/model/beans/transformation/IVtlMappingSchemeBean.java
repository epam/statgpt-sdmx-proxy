package io.sdmx.api.sdmx.model.beans.transformation;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;

/**
 * A container for {@link IVtlMappingBean}
 */
public interface IVtlMappingSchemeBean extends ItemSchemeBean<IVtlMappingBean>, INoCrossReferencesBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IVtlMappingSchemeBean> getURN();
	
	@Override
	IVtlMappingSchemeMutableBean getMutableInstance();

	@Override
	IVtlMappingSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
}
