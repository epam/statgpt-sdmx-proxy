
package io.sdmx.api.sdmx.model.beans.codelist;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;

/**
 * Represents an SDMX Level as defined by a HierarchyBean
 * @author Matt Nelson
 * @see HierarchyBean
 */
public interface LevelBean extends NameableBean, INoCrossReferencesBean {

	/**
	 * @return the codeing format for this level
	 */
	TextFormatBean getCodingFormat();
	
	/**
	 * Returns the child level, returns null if there is no child
	 * @return
	 */
	LevelBean getChildLevel();
	
	/**
	 * Returns true if there is a child level, in which case the call to getChildLevel will always return a value
	 */
	boolean hasChild();
	
	
}
