
package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

@Deprecated
public interface SchemeMapMutableBean extends NameableMutableBean {

	StructureReferenceBean getSourceRef();

	StructureReferenceBean getTargetRef();

	void setSourceRef(StructureReferenceBean sourceRef);

	void setTargetRef(StructureReferenceBean targetRef);


}
