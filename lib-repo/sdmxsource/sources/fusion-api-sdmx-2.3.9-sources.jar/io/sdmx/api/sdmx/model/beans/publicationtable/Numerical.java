package io.sdmx.api.sdmx.model.beans.publicationtable;

/**
 * Can contain numbers, and as such, can have a value operation performed up it, such as divide by 1000
 */
public interface Numerical {
	
	/**
	 * ? what is the syntax of this?
	 * @return
	 */
	String getValueOperation();
	
	/**
	 * Returns the formatting information  ? what is the syntax of this?
	 * @return
	 */
	String getFormatInformation();

}
