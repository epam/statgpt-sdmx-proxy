package io.sdmx.api.sdmx.model.mutable.codelist;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;

public interface HierarchicalCodelistMutableBean extends MaintainableMutableBean {

    List<HierarchyMutableBean> getHierarchies();

    List<CodelistRefMutableBean> getCodelistRef();

    void setHierarchies(List<HierarchyMutableBean> hierarchies);

    void addHierarchies(HierarchyMutableBean hierarchy);

    void setCodelistRef(List<CodelistRefMutableBean> codelistRefs);

    void addCodelistRef(CodelistRefMutableBean codelistRef);

    /**
     * Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
     * are not reflected in the returned instance of the MaintainableBean.
     * @return
     */
    @Override
    HierarchicalCodelistBean getImmutableInstance();

    /**
     * Removes items from the hierarchy that are not valid for the specified Date.
     * @param aDate
     * @return
     */
    HierarchicalCodelistMutableBean stripItems(Date aDate);
}