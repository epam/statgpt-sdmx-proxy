package io.sdmx.api.sdmx.model.mutable.refmetadata;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;

/**
 * represents a metadata attribute which has been reproted against a metadata set
 */
public interface IReportedMetadataAttributeMutableBean extends AnnotableMutableBean {

	/**
	 * @param id the ID of the MSD Metadata Attribute this value is reported against
	 */
	void setId(String id);
	String getId();
	
	/**
	 * @return nullable - list of simple values, mutually exclusive with get structured value
	 */
	String getValue();
	IReportedMetadataAttributeMutableBean setValue(String value);
	
	/**
	 * @return nullable - list of structured values, mutually exclusive with get value
	 */
	TextTypeMutableBean getStructuredValues();
	IReportedMetadataAttributeMutableBean setStructuredValues(TextTypeMutableBean values);
	IReportedMetadataAttributeMutableBean addStructuredValue(String locale, String text);
	
	
	/**
	 * @return not null - any child attributes of this attribute
	 */
	List<IReportedMetadataAttributeMutableBean> getAttributes();
	IReportedMetadataAttributeMutableBean setAttributes(List<IReportedMetadataAttributeMutableBean> attributes);
	IReportedMetadataAttributeMutableBean addAttribute(IReportedMetadataAttributeMutableBean attribute);
	
}
