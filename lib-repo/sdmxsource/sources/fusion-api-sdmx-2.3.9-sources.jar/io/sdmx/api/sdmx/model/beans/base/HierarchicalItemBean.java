
package io.sdmx.api.sdmx.model.beans.base;

import java.util.List;

/**
 * HierarchicalItemBean are ItemBeans that can contain child ItemBeans
 * @author Matt Nelson
 *
 * @param <T>
 */
public interface HierarchicalItemBean<T extends ItemBean> extends ItemBean {

	/**
	 * Returns any child items, if no children exist then an empty list is returned
	 * <p/>
	 * <strong>NOTE</strong>The list is a copy so modify the returned set will not 
	 * be reflected in the GroupBean instance
	 * @return
	 */
	List<T> getItems();
	
	/**
	 * Returns true when the hierarchy is explicitly part of the model, i.e a category has child categories, or if it is derived from 
	 * a reference, i.e a codelist is a flat list of codes, where one code can reference another as being its parent
	 * @return
	 */
	boolean isHierarchyExplicit();
	
	/**
	 * Return true if this item has children items
	 * @return
	 */
	default boolean hasChildren() {
		return !getItems().isEmpty();
	}
}
