
package io.sdmx.api.sdmx.model.validation;

/**
 * A marker Interface where each implementation provides information on the error format 
 */
public interface ErrorFormat {

}
