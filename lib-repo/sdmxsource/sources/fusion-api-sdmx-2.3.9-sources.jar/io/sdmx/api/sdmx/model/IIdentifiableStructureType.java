package io.sdmx.api.sdmx.model;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * This specialised for of ISDMXStructureStructure is the IIdentifiableStructureType type (which is describing a structure that is not a maintainable, but is identifiable)
 */
public interface IIdentifiableStructureType<K extends MaintainableBean, V extends IdentifiableBean> extends ISDMXStructureType<K, V> {

	/**
	 * @return true if this STRUCTURE_TYPE is representing a maintainable artifact.
	 */
	default boolean isMaintainable() {
		return false;
	}
}
