package io.sdmx.api.sdmx.model.beans.mapping;

import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;

public interface CodeMapBean extends ItemMapBean, ValidityPeriodBean {

}
