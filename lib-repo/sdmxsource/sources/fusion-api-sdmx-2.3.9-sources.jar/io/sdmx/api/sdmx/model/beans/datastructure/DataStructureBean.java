
package io.sdmx.api.sdmx.model.beans.datastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;


/**
 * A Data Structure also known as a Data Structure Definition (DSD) or KeyFamily describes the dimensionality 
 * of the data.  
 * <p/>
 * A Data Structure contains Dimensions, Attributes, Groups, and a Measure. Each of these components is 
 * held in its respective identifiable list container (DimensionList, AttributeList, MeasureList), 
 * however the DataStructureBean exposes the methods to obtain the Dimensions, Attributes, Measure, and Groups
 * without having to navigate through the list.
 */
public interface DataStructureBean extends MaintainableBean, ConstrainableBean, IDSDRelatedBean, IStructureMapRelatedBean  {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<DataStructureBean> getURN();
	
	/**
	 * @return immutable set of dimension IDs, excluding time
	 */
	List<String> getDimensionIds();
	
	/**
	 * Returns the Dimension List. The Dimension List is an identifiable container for the DataStructure's dimensions.
	 * @return
	 */
	DimensionListBean getDimensionList();

	/**
	 * Returns the Attribute List. The Attribute List is an identifiable container for the DataStructure's attributes.
	 * @return
	 */
	AttributeListBean getAttributeList();
	
	default boolean hasMeasures() {
		return this.getMeasureList() != null && this.getMeasureList().getMeasures().size() > 0;
	}

	/**
	 * Returns the Measure List. The Measure List is an identifiable container for the DataStructure's measure.
	 * This can be null if there are no measures
	 * @return
	 */
	MeasureListBean getMeasureList();
	
	/**
	 * @return a list of all the measure dimensions, or an empty list if none exist
	 */
	List<MeasureDimensionBean> getMeasures();
	
	/**
	 * @param id
	 * @return the measure dimension with the given id, or null if it does not exist
	 */
	MeasureDimensionBean getMeasure(String id);
	
	/**
	 * Returns the list of dimensions that belong to this DataStructure.
	 * @param include - an optional parameter of dimension types to include, types not specified will be excluded - the list must be from one of the following:
	 * <ul>
	 *   <li>DIMENSION - referring to a normal dimension, not measure or time</li>
	 *   <li>MEASURE_DIMENSION</li>
	 *   <li>TIME_DIMENSION</li>
	 * </ul>
	 * @return
	 */
	List<DimensionBean> getDimensions(SDMX_STRUCTURE_TYPE... include);
	
	/**
	 * Returns the dimension that is playing the role of frequency. Returns <code>null</code> if no dimension is playing the role of frequency.
	 * @return
	 */
	DimensionBean getFrequencyDimension();
	
	/**
	 * @return an optional reference to a Metadata Structure Definition which is used to capture metadata atrributes reported against the data
	 */
	ICrossReferenceBean<MetadataStructureDefinitionBean> getMSDRef();
	
	/**
	 * Returns true if there is a dimension that is playing the role of frequency.
	 * @return
	 */
	boolean hasFrequencyDimension();
	
	/**
	 * Returns the dimension with the given Id.
	 * @param conceptId
	 * @return
	 */
	DimensionBean getDimension(String id);
	
	/**
	 * Returns the index of the dimension with the given Id. Returns -1 if no dimension is found with the id provided
	 * 
	 * @param conceptId
	 * @return
	 */
	int getDimensionIndex(String id);
	
	/**
	 * Returns the component with the given id.
	 * @param conceptId
	 * @return
	 */
	ComponentBean getComponent(String id);
	
	/**
	 * Returns a list of all components that belong to this DSD
	 * @return
	 */
	List<ComponentBean> getComponents();
	
	/**
	 * Returns the list of groups that belongs to this DataStructure. If there are no groups then an empty list is returned.
	 * @return
	 */
	List<GroupBean> getGroups();
	
	/**
	 * Gets the group with the given id that belongs to this DataStructure.
	 * <p/>
	 * If there are no groups with the given id then <code>null</code> will be returned.
	 * @param groupId
	 * @return
	 */
	GroupBean getGroup(String groupId);
	
	/**
	 * Gets the time dimension that belongs to this DataStructure.
	 * <p/>
	 * If there is no time dimension then <code>null</code> is returned
	 * @return
	 */
	DimensionBean getTimeDimension();
	
	/**
	 * Gets the primary measure that belongs to this DataStructure. 
	 * A DataStructure must have a primary measure so this method will always return a value.
	 * @return
	 */
	PrimaryMeasureBean getPrimaryMeasure();
	
	/**
	 * Returns the attributes that belong to this DataStructure.
	 * If the DataStructure has no attributes then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getAttributes();
	
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of DataSet.
	 * <p/>
	 * If there are no attributes that match this criteria then an empty list is returned
	 * @return
	 */
	List<AttributeBean> getDatasetAttributes();
	
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of Group.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getGroupAttributes();
	
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of Group, that are attached to the group with the given id.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @param groupId the group id of the group to return the attributes for
	 * @param includeDimensionGroups if true, this will include attributes which are attached to a dimension group, which group the same dimensions as the 
	 * group with the given id
	 * @return
	 * @throws IllegalArgumentException if the groupId does not match any groups for this Data Structure
	 */
	List<AttributeBean> getGroupAttributes(String groupId, boolean includeDimensionGroups);
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of DimensionGroup.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getDimensionGroupAttributes();
	
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of DimensionGroup,
	 * where none of the dimensions referenced in the group are the cross sectional attribute.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getSeriesAttributes(String crossSectionalConcept);
	
	/**
	 * Returns a subset of the DataStructure's attributes.  
	 * Returns the attributes with Attachment Level of Observation when time is at the observation level.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getObservationAttributes();
	
	/**
	 * Returns a subset of the DataStructure's attributes.
	 * Returns the attributes with Attachment Level of Observation,
	 * or an Attachment level of DimensionGroup, where one of the dimensions in the group is the one at the cross sectional level.
	 * If there are no attributes that match this criteria then an empty list is returned.
	 * @return
	 */
	List<AttributeBean> getObservationAttributes(String crossSectionalConcept);

	/**
	 * Returns the attribute with the given id, returns <code>null</code> if no such attribute exists.
	 * @param id
	 * @return
	 */
	AttributeBean getAttribute(String id);
	
	/**
	 * Returns the group attribute with the given id, returns <code>null</code> if no such attribute exists.
	 * @param id
	 * @return
	 */
	AttributeBean getGroupAttribute(String id);
	
	/**
	 * Returns the series attribute with the given id, returns <code>null</code> if no such attribute exists.
	 * @param id
	 * @return
	 */
	AttributeBean getDimensionGroupAttribute(String id);
	
	/**
	 * Returns the observation attribute with the given id, returns <code>null</code> if no such attribute exists.
	 * @param id
	 * @return
	 */
	AttributeBean getObservationAttribute(String id);
	
	/**
	 * Returns a stub reference of itself.
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are 
	 * contained within the Maintainable.
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	DataStructureBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	DataStructureMutableBean getMutableInstance();
}
