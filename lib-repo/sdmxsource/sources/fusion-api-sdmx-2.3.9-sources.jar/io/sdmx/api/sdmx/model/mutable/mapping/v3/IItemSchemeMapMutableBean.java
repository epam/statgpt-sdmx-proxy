
package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import java.util.List;


public interface IItemSchemeMapMutableBean<T extends IItemMapMutableBean> extends ISchemeMapMutableBean {

	List<T> getItems();

	void setItems(List<T> items);

	void addItem(T item);


}
