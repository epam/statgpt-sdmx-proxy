package io.sdmx.api.sdmx.model.mutable.mapping.v3;

/**
 * Represents an SDMX Category Map
 */
public interface ICategoryMapMutableBean extends IItemMapMutableBean<ICategoryMapMutableBean> {

}
