
package io.sdmx.api.sdmx.model.beans.base;

import java.util.Set;

/**
 * An SdmxStructureBean is a bean which represents an SDMX Structural metadata artefact, such as a Code / Codelist etc.
 * @author Matt Nelson
 *
 */
public interface SdmxStructureBean extends SDMXBean {
	
	/**
	 * Returns the parent that this SDMXBean belongs to 
	 * <p/>
	 * If this is a MaintainableBean, then there will be no parent to return, so will return a value of null
	 * @return
	 */
	@Override
	SdmxStructureBean getParent();
	
	/**
	 * Recurses up the parent tree to find the maintainable parent.  If this is a maintainable then 
	 * it will return a reference to itself
	 * @return
	 */
	MaintainableBean getMaintainableParent();
	
	
	/**
	 * Returns a set of identifiables that are contained within this identifiable
	 * @return
	 */
	Set<IdentifiableBean> getIdentifiableComposites();
}
