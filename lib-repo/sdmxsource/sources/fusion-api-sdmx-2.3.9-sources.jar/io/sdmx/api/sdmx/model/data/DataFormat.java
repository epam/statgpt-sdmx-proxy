
package io.sdmx.api.sdmx.model.data;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.constants.DATA_TYPE;

/**
 * Data format is an Interface which wrappers a strongly typed and non-extensible {@link DATA_TYPE} enumeration.  The purpose of the wrapper is to
 * allow for additional implementations to be provided which may describe non-sdmx formats which are not supported by the {@link DATA_TYPE} enum.
 */
public interface DataFormat extends InformationFormat {}
