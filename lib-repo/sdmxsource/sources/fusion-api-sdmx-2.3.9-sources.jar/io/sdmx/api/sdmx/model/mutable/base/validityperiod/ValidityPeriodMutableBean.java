package io.sdmx.api.sdmx.model.mutable.base.validityperiod;

import java.util.Date;
import java.util.Optional;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ValidityPeriodMutableBean extends MutableBean{
	ValidityPeriodMutableBean setStartDate(Date startDate);

	ValidityPeriodMutableBean setEndDate(Date endDate);

	Date getStartDate();

	Date getEndDate();

	/**
	 * Convenience  method to parse this ValidityPeriodBean's start and end date into an  Sdmx Period
	 * @return
	 */
	Optional<SdmxPeriod> getSdmxPeriod();

	default boolean hasValidityPeriod(){
		return this.getSdmxPeriod().isPresent();
	}
}