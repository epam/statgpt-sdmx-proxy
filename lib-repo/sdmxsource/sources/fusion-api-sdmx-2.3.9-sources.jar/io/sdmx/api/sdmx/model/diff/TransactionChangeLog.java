package io.sdmx.api.sdmx.model.diff;

/**
 * Describes a change between the same structure at for different transactions (i.e modifications to the same codelist)
 */
public interface TransactionChangeLog extends Changelog {


}