package io.sdmx.api.sdmx.model.data;

public interface ICellPosition extends IDataPosition {

	/**
	 * In the case of excel style data, the worksheet is zero indexed, defaults to 0 if there is no worksheet concept in the data file
	 */
	int getWorksheet();
	
	/**
	 * @return column of the cell, zero indexed
	 */
	int getColumn();
	
	/**
	 * @return row of the cell, zero indexed
	 */
	int getRow();
	
	/**
	 * Overridden to provide additional JavaDoc to describe response
	 * 
	 * exl:[workksheet]:[column]:[row]
	 * 
	 * example
	 * 
	 * exl:200:23:,:1:3:4:7
	 * 
	 */
	@Override
	String toPositionalString();
}
