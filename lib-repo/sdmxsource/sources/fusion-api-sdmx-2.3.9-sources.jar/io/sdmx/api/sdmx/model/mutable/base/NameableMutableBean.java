
package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;

public interface NameableMutableBean extends IdentifiableMutableBean {
	
	/**
	 * Sets all the properties on this bean from the bean passed in
	 * @param bean - to copy from
	 * @param includeInheritedProperties - if true, all properties will be set on the inherited interfaces
	 */
	void copyNameableProperties(NameableBean bean, boolean includeInheritedProperties);
	void copyNameableProperties(NameableMutableBean bean, boolean includeInheritedProperties);

	/**
	 * Adds a name, edits the current value if the locale already exists
	 * @param locale
	 * @param name
	 */
	void addName(String locale, String name);

	void addName(TextTypeWrapperMutableBean text);


	/**
	 * Adds a description, edits the current value if the locale already exists
	 * @param locale
	 * @param name
	 */
	void addDescription(String locale, String name);


	void addDescription(TextTypeWrapperMutableBean text);

	String getName(boolean defaultIfNull);

	List<TextTypeWrapperMutableBean> getNames();

	/**
	 * Returns the name with the given locale, or null if there is no name with the given locale
	 * @param locale
	 * @return
	 */
	TextTypeWrapperMutableBean getName(String locale);


	List<TextTypeWrapperMutableBean> getDescriptions();

	/**
	 * Returns the description with the given locale, or null if there is no name with the given locale
	 * @param locale
	 * @return
	 */
	TextTypeWrapperMutableBean getDescription(String locale);


	void setNames(List<TextTypeWrapperMutableBean> names);

	void setDescriptions(List<TextTypeWrapperMutableBean> description);

	void removeDescription(String locale);
	void removeName(String locale);

}
