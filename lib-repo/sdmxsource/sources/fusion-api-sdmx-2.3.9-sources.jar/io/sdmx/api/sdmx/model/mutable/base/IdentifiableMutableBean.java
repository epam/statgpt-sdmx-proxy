package io.sdmx.api.sdmx.model.mutable.base;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

public interface IdentifiableMutableBean extends AnnotableMutableBean {
	
	/**
	 * Sets all the properties on this bean from the bean passed in
	 * @param bean - to copy from
	 * @param includeInheritedProperties - if true, all properties will be set on the inherited interfaces
	 */
	void copyIdentifiableProperties(IdentifiableBean bean, boolean includeInheritedProperties);
	void copyIdentifiableProperties(IdentifiableMutableBean bean, boolean includeInheritedProperties);

	String getId();

	String getUrn();

	String getUri();

	IdentifiableMutableBean setId(String id);

	void setUri(String uri);

	List<ILinkBean> getLinks();
	IdentifiableMutableBean setLinks(List<ILinkBean> links);
	IdentifiableMutableBean addLink(ILinkBean link);
	
	/**
	 * Used to store the previous id
	 * @return
	 */
	void setOldId(String oldId);

	/**
	 * If the id has changed, this will return the old id
	 * @return
	 */
	String getOldId();

	/**
	 * Returns a clone of this item
	 * @return
	 */
	IdentifiableMutableBean deepClone();
}
