package io.sdmx.api.sdmx.model.mutable.codelist;

import java.util.List;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface CodelistMutableBean extends ItemSchemeMutableBean<CodeMutableBean> {

	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	CodelistBean getImmutableInstance();

	@Override
	boolean isPartial();

	void setIsPartial(boolean isPartial);

	/**
	 * Returns the code with the given id, returns null if no such code exists
	 * @param id
	 * @return
	 */
	CodeMutableBean getCodeById(String id);

	/**
	 * Returns the Validity Type
	 * @return
	 */
	MAINT_VALIDITY_TYPE getValidityType();

	/**
	 * Sets the Validity Type
	 * @return
	 */
	void setValidityType(MAINT_VALIDITY_TYPE validityType);
	

	List<ICodelistInheritanceRuleMutableBean> getInheritenceRules();
	CodelistMutableBean setInheritenceRules(List<ICodelistInheritanceRuleMutableBean> rules);
	CodelistMutableBean addInheritenceRules(ICodelistInheritanceRuleMutableBean rule);

	/**
	 * Set to true if this Codelist include Codes inherited as part of the inheritence rules
	 * @param isInherited
	 * @return
	 */
	CodelistMutableBean setInherited(boolean isInherited);
	boolean isInherited();
	
}