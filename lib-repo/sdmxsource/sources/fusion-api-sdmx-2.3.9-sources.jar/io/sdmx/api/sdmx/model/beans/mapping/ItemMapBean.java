
package io.sdmx.api.sdmx.model.beans.mapping;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * Represents an SDMX Item Map
 * @author Matt Nelson
 *
 */
public interface ItemMapBean extends AnnotableBean, INoCrossReferencesBean {

	String getSourceId();

	String getTargetId();
}
