package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.IMaintainableStructureType;

/**
 * Represents an absolute URN for a Maintainable type
 */
public interface IURNMaintainable<K extends MaintainableBean> extends IURNAbsolute<K> {
	
	
	/**
	 * Casts this type to the given type T if it is able to do so
	 * @param <T>
	 * @param type
	 * @return
	 * @throws IllegalArgumentException - if the type T is not assignable to the structure type this URN is referencing
	 */
	default <T extends MaintainableBean> IURNMaintainable<T> toMaintainableType(Class<T> type) {
		if(isType(type)) {
			return (IURNMaintainable<T>)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: " +type.getCanonicalName());
	}
	
	
	/**
	 * @return not null - the definition for the type of structure this is
	 */
	@Override
	IMaintainableStructureType<K> getStructureType();
	
	/**
	 * Converts this maintainable URN to an identifiable composite, e.g a Codelist urn to a Code URN.
	 * 
	 * @param <V>
	 * @param identifiable Identifiable Class to convert to, it must be a valid Concrete (non-abstract) composite of this type,
	 * e.g. can not convert a Codelist URN to a Concept URN or a Codelist URN to an Item URN
	 * @param identifableIds ID to give the Identifiable, e.g. Code ID
	 * @return the URN to the identifiable type
	 */
	<V extends IdentifiableBean> IURNAbsolute<V> toIdentifiable(Class<V> identifiable, String...identifableIds);

	
}
