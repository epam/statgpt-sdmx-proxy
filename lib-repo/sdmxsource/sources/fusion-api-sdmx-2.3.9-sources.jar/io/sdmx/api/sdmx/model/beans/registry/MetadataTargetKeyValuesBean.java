
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;

public interface MetadataTargetKeyValuesBean extends KeyValues {

	List<IDirectCrossReferenceBean<?>> getObjectReferences();
	
	List<DataSetReferenceBean> getDatasetReferences();
	
}
