
package io.sdmx.api.sdmx.model.mutable.base;



public interface ConceptBaseMutableBean extends NameableMutableBean {
	
	boolean isStandAloneConcept();
	
	
}
