package io.sdmx.api.sdmx.model.beans.mapping;

public interface CategoryMapBean extends ItemMapBean {

}
