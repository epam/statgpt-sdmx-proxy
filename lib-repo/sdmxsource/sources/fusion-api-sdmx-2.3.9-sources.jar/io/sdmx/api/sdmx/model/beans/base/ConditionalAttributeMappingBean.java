package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.constants.CONDITION;

/**
 * Defines which value an attribute should take when the conditions defined in this object are met
 */
public interface ConditionalAttributeMappingBean extends INoCrossReferencesBean {
	
	/**
	 * @return the value the attribute should take
	 */
	String getAttributeValue();
	
	/**
	 * @return the condition that must be met
	 */
	CONDITION getCondition();
	
	/**
	 * Additional condition rules, only applicable for certain conditions 
	 * @return the Additional condition rules
	 */
	String getConditionDetail();
	
}