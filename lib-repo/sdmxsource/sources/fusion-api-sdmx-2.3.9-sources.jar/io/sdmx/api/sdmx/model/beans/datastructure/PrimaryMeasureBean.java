
package io.sdmx.api.sdmx.model.beans.datastructure;

/**
 * PrimaryMeasureBean defines the structure of the primary measure, which is the concept that 
 * is the phenomenon to be measured in a data set. In a data set the instance of the measure is often called the observation.
 * @author Matt Nelson
 *
 */
public interface PrimaryMeasureBean extends MeasureDimensionBean {

	String FIXED_ID="OBS_VALUE";
	
}
