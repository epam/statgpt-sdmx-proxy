package io.sdmx.api.sdmx.model.beans.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;

/**
 * Attribute describes the definition of a data attribute, which is defined as a characteristic of an object or entity.
 * <p/>
 * This is an immutable bean - this bean can not be modified
 * @author Matt Nelson
 *
 */
public interface AttributeBean extends IDataStructureComponentBean {

	@Override
	/**
	 * @return overridden to return the absolute type
	 */
	IURNAbsolute<AttributeBean> getURN();
	
	
	/**
	 * Returns true IF the Id = TIME_FORMAT
	 * @return
	 */
	boolean isTimeFormat();
	
	/**
	 * Returns the list of dimension ids that this attribute references, this is only relevant if ATTRIBUTE_ATTACHMENT_LEVEL is
	 * DIMENSION_GROUP.  The returned list is a copy of the underlying list
	 * <p/>
	 * Returns an empty list if this attribute does not reference any dimensions
	 * @return
	 */
	List<String> getDimensionReferences();
	
	/**
	 * @return the list of measures that this attribute references, if this is an empty list, then the attribute is relevant to all measures
	 */
	List<String> getMeasureReferences();
	
	
	/**
	 * Returns a list of cross references to concepts that are used to define the role(s) of this attribute.
	 * The returned list is a copy of the underlying list
	 *  <p/>
	 * Returns an empty list if this attribute does not reference any concept roles
	 * @return
	 */
	List<IDirectCrossReferenceBean<ConceptBean>> getConceptRoles();
	
	/**
	 * If ATTRIBUTE_ATTACHMENT_LEVEL is GROUP then returns a reference to the Group id that this attribute is attached to.  Returns
	 * null if ATTRIBUTE_ATTACHMENT_LEVEL is not GROUP
	 * @return
	 */
	String getAttachmentGroup();
	
	/**
	 * Returns the ATTRIBUTE_ATTACHMENT_LEVEL attribute indicating the level to which the attribute is attached in time-series formats
	 * (generic, compact, utility data formats).
	 * Attributes with an attachment level of Group are only available if the data is organised in groups,
	 * and should be used appropriately, as the values may not be communicated if the data is not grouped.
	 * @return
	 */
	ATTRIBUTE_ATTACHMENT_LEVEL getAttachmentLevel();
	
}
