package io.sdmx.api.sdmx.model.beans.transformation;

import java.net.URL;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;

/**
 * Container for {@link IUserDefinedOperatorBean}
 */
public interface IUserDefinedOperatorSchemeBean extends IVtlSchemeBean<IUserDefinedOperatorBean> {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<IUserDefinedOperatorSchemeBean> getURN();
	
	/**
	 * References a VTL mapping scheme which defines aliases for given SDMX artefacts that are used in the user defined operators.
	 * ALthough the VTL user defined operators are concieved to be defined on generic operands, so that the specific artefacts to be manipulated
	 * are passed as parameters at the invocation, is is also possible that they reference specific c SDMX artefacts like Dataflows, Codelists, and
	 * Concept Schemes. In this case, the mapping schemes referenced here defined the mappings to those artefacts
	 * @return optional
	 */
	ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef();

	/**
	 * References a rules set scheme defining rulesets utilized in the user defined operators
	 * @return immutable lists, not null
	 */
	List<IDirectCrossReferenceBean<IRulesetSchemeBean>> getRulesetSchemeRef();
	
	@Override
	IUserDefinedOperatorSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

	@Override
	IUserDefinedOperatorSchemeMutableBean getMutableInstance();
}
