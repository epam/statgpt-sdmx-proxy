package io.sdmx.api.sdmx.model.mutable.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;

public interface ITransformationSchemeMutableBean extends IVtlSchemeMutableBean<ITransformationMutableBean> {

	/**
	 * Adds and returns the transformation
	 * @param id
	 * @param isPersistent
	 * @param result
	 * @param expression
	 * @return
	 */
	ITransformationMutableBean addTransformation(String id, boolean isPersistent, String result, String expression);
	
	/**
	 * References a VTL mapping scheme which defines aliases for given SDMX artefacts that are used in the transformations
	 * as well as the mapping methods used when converting between SDMX and VTL data structur4es. All aliases must be defined in the referenced scheme.  
	 * This also must be used if the basic mapping methods are not used
	 * @return optional
	 */
	StructureReferenceBean getVtlMappingSchemeRef();
	void setVtlMappingSchemeRef(StructureReferenceBean ref);

	/**
	 * References a name personalisation scheme which defines the overriding of some standard VTL names (to be assigned
	 * to some measures and/or attributes of the data structure) with some corresponding personalised names.
	 * This muse be used if transformations within a transformation scheme personalised standard names.  
	 * All personalisations must be defined in the referenced scheme
	 * @return optional
	 */
	StructureReferenceBean getNamePersonalisationSchemeRef();
	void setNamePersonalisationSchemeRef(StructureReferenceBean ref);
	

	/**
	 * References a custom type scheme which defines custom conversions of VTL sshcmeecaler types to SDMX data types.  This must be used if custom
	 * type conversions are used in the transformations defined in a transformation scheme.  
	 * All custom conversions must be defined in the referenced scheme
	 * @return optional
	 */
	StructureReferenceBean getCustomTypeSchemeRef();
	void setCustomTypeSchemeRef(StructureReferenceBean ref);
	

	/**
	 * References a rules set scheme that defines on or more previously defined rulesets which can be invoked by VTL operators.
	 * If a transformation defined in a transformation scheme refers to t a ruleset, the scheme in which the reset is defined must be 
	 * referenced here
	 * @return list nullable
	 */
	List<StructureReferenceBean> getRulesetSchemeRef();
	void setRulesetSchemeRef(List<StructureReferenceBean> refs);
	ITransformationSchemeMutableBean addRulesetSchemeRef(StructureReferenceBean refs);
	

	/**
	 * References a user defined operator scheme that defines one or more user defined operators used by the transformations
	 * defined in a transformation scheme. If a transformation in a transformation scheme refers to a user defined operator, 
	 * the scheme in which the user defined operator is defined must be referenced here
	 * @return list nullable
	 */
	List<StructureReferenceBean> getUserDefinedOperatorSchemeRef();
	void setUserDefinedOperatorSchemeRef(List<StructureReferenceBean> refs);
	ITransformationSchemeMutableBean addUserDefinedOperatorSchemeRef(StructureReferenceBean refs);
	
	@Override
	ITransformationSchemeBean getImmutableInstance();

}
