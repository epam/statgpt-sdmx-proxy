package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;

/**
 * Defines a relationship between one or more source values (in combination) which are the equivalent to one or more
 * target values (in combination)
 */
public interface IMappedRelationshipMutableBean extends AnnotableMutableBean {
	
	/**
	 * Reverses the source and target references and mapped codes
	 * <br/>
	 * <p>A set of valid targets should be provided if the representation map contains regular expressions, or substring matches as the only way to know what the 
	 * matched targets are when reversing the rule, is to know what all the possible targets can be.  </p>
	 * <br/>
	 * <p><b>For Example:</b> </p>
	 * A rule that states that the source code starts with 'UK' maps to GB can not be reversed, as GB does not map to UK.  
	 * Knowing that valid inputs are UK1, UK2 and UK3 allows the rule to be re-written as 3 distinct rules, GB->UK1, GB->UK2, GB-UK3.  
	 *
	 * @param validSources - optional and only required for mappings whose source code defines a substring or regular expression match.
	 */ 
	void reverseMapping(Set<String> validSources);
	
	/**
	 * @return when this mapping is valid from or null if not defined
	 */
	String getValidFrom();
	IMappedRelationshipMutableBean setValidFrom(String period);
	
	
	/**
	 * @return when this mapping is valid to or null if not defined
	 */
	String getValidTo();
	IMappedRelationshipMutableBean setValidTo(String period);

	/**
	 * @return one or more source values which map to the target, as a matched value can contain rules these are captured in the {@link IMappedValueMutableBean}
	 */
	List<IMappedValueMutableBean> getSourceValue();
	IMappedRelationshipMutableBean setSourceValue(List<IMappedValueMutableBean> values);
	/**
	 * Creates, adds, and returns a new IMappedValueMutableBean
	 * @return
	 */
	IMappedValueMutableBean addSourceValue();
	
	/**
	 * @return one or more output target values mapped from the source, target values are absolute values
	 */
	List<String> getTargetValue();
	IMappedRelationshipMutableBean setTargetValue(List<String> values);
	IMappedRelationshipMutableBean addTargetValue(String value);
}
