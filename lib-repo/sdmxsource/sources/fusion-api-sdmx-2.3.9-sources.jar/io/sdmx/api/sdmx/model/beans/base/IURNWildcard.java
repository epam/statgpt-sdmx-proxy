package io.sdmx.api.sdmx.model.beans.base;

/**
 * Represents a URN with wildcard values (no late bind on the version, no wildcard/multiple references)
 */
public interface IURNWildcard<K extends IdentifiableBean> extends IURN<K> {

	default REFERENCE_TYPE getType() {
		return REFERENCE_TYPE.WILDCARD;
	}
	
}
