package io.sdmx.api.sdmx.model.notifier;

import io.sdmx.api.sdmx.model.modify.IURNChangeRequest;

/**
 * Called when a URN change request has been requested and is about to be actioned
 */
public interface URNChangeRequestRecievedListener {

	/**
	 * The URN of a structure will change
	 * @param changeFromTo key of the map is the old reference the target is the new reference
	 */
	void notifyURNChangeRequst(IURNChangeRequest urnChanged);
	
}
