package io.sdmx.api.sdmx.model.mutable.mapping;

import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;

@Deprecated
public interface CodeMapMutableBean extends ItemMapMutableBean, ValidityPeriodMutableBean {

}
