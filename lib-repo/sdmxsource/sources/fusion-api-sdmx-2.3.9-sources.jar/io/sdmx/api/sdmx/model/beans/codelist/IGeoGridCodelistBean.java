package io.sdmx.api.sdmx.model.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;

import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;

public interface IGeoGridCodelistBean extends CodelistBean {

	@Override
	IGeoGridCodelistBean cloneForDate(Date date);
	
	/**
	 * Returns a stub reference of itself.
	 * <p/>
	 * A stub bean only contains Maintainable and Identifiable Attributes, not the composite Objects that are
	 * contained within the Maintainable
	 * @return
	 * @param actualLocation the URL indicating where the full structure can be returned from
	 * @param isServiceUrl if true this URL will be present on the serviceURL attribute, otherwise it will be treated as a structureURL attribute
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 */
	@Override
	IGeoGridCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);

	/**
	 * Returns the item with the given id, returns null if there is no item with the id provided
	 * @param id
	 * @return
	 */
	IGeoGridCodeBean getItemById(String id);

	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	IGeoGridCodelistMutableBean getMutableInstance();

	/**
	 * Returns a new item scheme based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @return
	 */
	@Override
	IGeoGridCodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet);
	
	/**
	 * <p>The GridDefinition is a string expression with a defined syntax:
	 * <p>
	 * <i>[CRS]:[REFERENCE_CORNER];[REFERENCE_COORDINATES];[CELL_WIDTH],[CELL_HEIGHT]:[GEO_STD]</i></p>
	 * 
	 * <ul>
	 *  <li>
	 *  <b>CRS - Optional</b>: 
	 *  The code of the Coordinate Reference System is used to reference the coordinates in the flow. 
	 *  The code of the CRS will be as it appears in the EPSG Geodetic Parameter Registry ( ) 
	 *  maintained by the International Association of Oil and Gas Producers. 
	 *  If this component is omitted, by default the CRS will be the World Geodetic System 1984 (WGS 84, EPSG:4326).
	 *  </li>
	 *  <li>
	 *  <b>REFERENCE_CORNER - Optional</b>:
	 *  A code composed of two characters to define the position of the coordinates that will be used as a starting reference to locate the cells. 
	 *  The possible values of this code can be UL (Upper Left), UR (Upper Right), LL (Lower Left), or LR (Lower Right).
	 *  If this component is omitted the value LL (Lower Left) will be taken by default. 
	 *  </li>
	 *  <li>
	 *  <b>REFERENCE_COORDINATES -  This element is mandatory if GEO_STD is omitted.</b>:
	 *  Represents the starting point to reference the cells of the grid, accordingly to the CRS and the REFERENCE_CORNER. 
	 *  It is represented by an individual set of coordinates composed by the X_COORDINATE (X) and Y_COORDINATE (Y) in the following way "X,Y". 
	 *  </li>
	 *  <li>
	 *  <b>CELL_WIDTH -  This element is mandatory if GEO_STD is omitted</b>: 
	 *  The size in meters of a horizontal side of the cells in the grid. 
	 *  </li>
	 *  <li>
	 *  <b>CELL_HEIGHT -  This element is mandatory if GEO_STD is omitted</b>: 
	 *  The size in meters of a vertical side of the cells in the grid.
	 *  </li>
	 *  <li>
	 *  <b>GEO_STD - Optional</b>: 
	 *  A restricted text value expressing that the cells in the grid will provide information 
	 *  about matching codes existing in another reference system that establishes a mechanism to define the grid. 
	 *  </li>
	 * </ul>
	 * 
	 * <p>
	 * Accepted values for the <b>GEO_STD</b> component are included in the Geographical Grids Codelist (CL_GEO_GRIDS). Examples contained in the mentioned document are: 
	 * </p>
	 * <ul>
	 * <li>
	 * 	<b>GEOHASH</b> : GeoHash
	 * </li>
	 * <li>
	 * 	<b>GEOREF</b> : World Geographic Reference System
	 * </li>
	 * <li>
	 * 	<b>MGRS</b> : Military Grid Reference System
	 * </li>
	 * <li>
	 * 	<b>OLC</b> : Open Location Code / Plus Code
	 * </li>
	 * <li>
	 * 	<b>QTH</b> : Maidenhead Locator System /QTH Locator / IAURU Locator
	 * </li>
	 * <li>
	 * 	<b>W3W</b> : What3words
	 * </li>
	 * <li>
	 * 	<b>WOEID</b> : 	Where On Earth Identifier
	 * </li>
	 * </ul>
	 * 
	 * <b>Example:</b> 4326:UL;9.580078,55.103516;1000,1000:W3W
	 * 
	 * @return 
	 */
	String getGridDefinition();
}
