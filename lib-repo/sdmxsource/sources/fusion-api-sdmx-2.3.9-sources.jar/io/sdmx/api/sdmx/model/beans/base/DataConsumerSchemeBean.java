
package io.sdmx.api.sdmx.model.beans.base;

import java.util.Collection;

import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;


/**
 * Represents an SDMX Data Consumer Scheme
 * @author Matt Nelson
 *
 */
public interface DataConsumerSchemeBean extends OrganisationSchemeBean<DataConsumerBean> {

	static final String FIXED_ID = "DATA_CONSUMERS";
	static final String FIXED_VERSION = "1.0";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<DataConsumerSchemeBean> getURN();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	DataConsumerSchemeMutableBean getMutableInstance();
	
	@Override
	DataConsumerSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet);
	
}
