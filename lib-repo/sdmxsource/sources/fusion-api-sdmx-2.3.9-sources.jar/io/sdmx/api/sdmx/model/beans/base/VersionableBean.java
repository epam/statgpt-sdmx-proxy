package io.sdmx.api.sdmx.model.beans.base;

import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;

public interface VersionableBean extends NameableBean, ValidityPeriodBean{
	static String DEFAULT_VERSION ="1.0";
	
	/**
	 * @return the version of this maintainable object
	 */
	ISdmxVersion getVersion();
}
