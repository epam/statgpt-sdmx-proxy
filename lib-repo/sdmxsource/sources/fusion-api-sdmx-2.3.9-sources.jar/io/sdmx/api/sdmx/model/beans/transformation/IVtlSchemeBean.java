package io.sdmx.api.sdmx.model.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;

public interface IVtlSchemeBean<T extends ItemBean> extends ItemSchemeBean<T> {

	/**
	 * @return not null. The version of VTL that this scheme is compliant with
	 */
	String getVtlVersion();
	
}
