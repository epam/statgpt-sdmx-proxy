
package io.sdmx.api.sdmx.model.beans.reference.complex;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;

/**
 * Used for complex queries
 * @see ComplexStructureReferenceBean
 */
@Deprecated //unused
public interface ComplexVersionReference {

	/**
	 * Returns if the version to be returned is the latest version
	 * @return
	 */
	TERTIARY_BOOL isReturnLatest();
	
	/**
	 * returns the version that is being reference, this can be null
	 * @return
	 */
	String getVersion();
	
	/**
	 * Returns the period from which the version should be valid from - this can be null
	 * @return
	 */
	TimeRange getVersionValidFrom();
	
	/**
	 * Returns the period from which the version should be valid to - this can be null
	 * @return
	 */
	TimeRange getVersionValidTo();
	
}
