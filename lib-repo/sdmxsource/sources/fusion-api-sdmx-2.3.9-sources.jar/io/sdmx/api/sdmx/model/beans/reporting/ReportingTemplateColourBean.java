package io.sdmx.api.sdmx.model.beans.reporting;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;

/**
 * Contains information about the attribute which is used to define the colours used in the observation cells
 */
public interface ReportingTemplateColourBean extends INoCrossReferencesBean {

	/**
	 * Returns the id of the attribute to use
	 * @return
	 */
	String getAttributeId();
	
	/**
	 * The default colour to use 
	 * @return
	 */
	String getDefaultColour();
	
	/**
	 * The Code Ids to associated colour with them
	 * @return
	 */
	Map<String, String> getColourCodes();
	
	/**
	 * Returns a set of comma delimited series strings against the colour it is mapped to, e.g A,UK,FR=#C2C2C2
	 * @return
	 */
	Map<Set<String>, String> getSeriesColours();
	
	
}
