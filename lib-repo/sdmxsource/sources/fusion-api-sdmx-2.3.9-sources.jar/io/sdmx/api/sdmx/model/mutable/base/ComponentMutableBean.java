package io.sdmx.api.sdmx.model.mutable.base;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public interface ComponentMutableBean extends IdentifiableMutableBean {
	
	StructureReferenceBean getConceptRef();
	
	void setConceptRef(StructureReferenceBean conceptRef);

	/**
	 * proxy on RepresentationMutableBean
	 */
	ComponentMutableBean setMinOccurs(Integer num);
	/**
	 * proxy on RepresentationMutableBean
	 */
	ComponentMutableBean setMaxOccurs(Integer num);
	
	RepresentationMutableBean getRepresentation();
	
	void setRepresentation(RepresentationMutableBean representation);
	
	
	/**
	 * bypass the setRepresentationMutableBean (creates it if null)
	 * @param textFormat
	 */
	void setTextFormat(TextFormatMutableBean textFormat);
	
	/**
	 * bypass the setRepresentationMutableBean (creates it if null)
	 * @param representationRef
	 */
	void setEnumeration(StructureReferenceBean representationRef);
	
	/**
	 * bypass the setRepresentationMutableBean (creates it if null)
	 * @param tt
	 */
	TextFormatMutableBean setTextType(TEXT_TYPE tt); 

	/**
	 * The assignmentStatus attribute indicates whether a 
	 * value must be provided for the attribute when sending documentation along with the data.
	 * @return
	 */
	boolean isMandatory();
	
	ComponentMutableBean setMandatory(boolean assignmentStatus);
	
}
