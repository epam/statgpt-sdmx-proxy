package io.sdmx.api.sdmx.model.beans.refmetadata;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;

/**
 * represents a metadata attribute which has been reported against a metadata set
 */
public interface IReportedMetadataAttributeBean extends AnnotableBean, INoCrossReferencesBean {

	/**
	 * @return ID of the MSD's Metadata Attribute that this value is reported against
	 */
	String getId();
	
	/**
	 * @return the full ID path if this IReportedMetadataAttributeBean is in a hierarchy, i.e. LICENSE[0].AUTHOR[1]
	 * would indicate first occurrence of the LICENSE attribute the second occurrence of the AUTHOR attribute within the LICENSE 
	 */
	String getFullId();
	
	/**
	 * The unique identifier is the full ID
	 */
	default String getKey() {
		return getFullId();
	}
	
	/**
	 * @return not null - list of simple values, mutually exclusive with get structured value
	 */
	String getValue();
	
	/**
	 * @return not null - list of structured values, mutually exclusive with get value
	 */
	TextTypeBean getStructuredValue();
	
	/**
	 * @return not null - any child attributes of this attribute
	 */
	List<IReportedMetadataAttributeBean> getAttributes();
	
	default boolean isPresentational() {
		return getValue() == null && getStructuredValue() == null;
	}
	
}
