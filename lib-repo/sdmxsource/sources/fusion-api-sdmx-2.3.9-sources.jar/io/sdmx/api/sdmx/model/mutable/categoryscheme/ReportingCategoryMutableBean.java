
package io.sdmx.api.sdmx.model.mutable.categoryscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchicalItemMutableBean;


public interface ReportingCategoryMutableBean extends HierarchicalItemMutableBean<ReportingCategoryMutableBean> {
	
	List<StructureReferenceBean> getStructuralMetadata();

	void setStructuralMetadata(List<StructureReferenceBean> structuralMetadata);
	
	void addStructuralMetadata(StructureReferenceBean structuralMetadata);

	List<StructureReferenceBean> getProvisioningMetadata();

	void setProvisioningMetadata(List<StructureReferenceBean> provisioningMetadata);
	
	void addProvisioningMetadata(StructureReferenceBean provisioningMetadata);

}
