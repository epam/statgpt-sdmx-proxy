
package io.sdmx.api.sdmx.model.mutable.datastructure;

import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;

public interface CrossSectionalMeasureMutableBean extends ComponentMutableBean {

	String getMeasureDimension();
	
	String getCode();
	
	void setMeasureDimension(String measureDimension);
	
	void setCode(String code);
	
}
