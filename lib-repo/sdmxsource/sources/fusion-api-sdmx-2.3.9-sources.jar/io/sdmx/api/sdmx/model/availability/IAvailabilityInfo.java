package io.sdmx.api.sdmx.model.availability;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;

/**
 * Describes available data for a Dataflow
 */
public interface IAvailabilityInfo {
	
	/**
	 * @return not null, immutable set of 0 to many data providers
	 */
	Set<DataProviderBean>  getDataProviders();
	
	/**
	 * @return structures to which the availability information relates
	 */
	IDatasetStructures getStructures();
	
	/**
	 * @return immutable map, the valid values each dimension, a mapped empty set to indicate no valid values
	 */
	Map<String, Set<String>> getValidValues();
	
	/**
	 * @return count of series that match the availability query, or -1 if unknown
	 */
	long getSeriesCount();
	
	/**
     * @return count of obs that match the availability query, or -1 if unknown
     */
    long getObsCount();
    
}
