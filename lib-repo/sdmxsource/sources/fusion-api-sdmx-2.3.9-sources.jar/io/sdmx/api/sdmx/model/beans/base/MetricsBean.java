package io.sdmx.api.sdmx.model.beans.base;

import java.util.Date;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Defines a bean which can be enriched with metrics
 */
public interface MetricsBean {
	public static final String METRICS_ANNOTATION_TYPE = "FR_METRIC";
	public static final String LAST_UPDATED_ANNOTATION_TITLE = "LAST_UPDATED";
	public static final String SERIES_COUNT_ANNOTATION_TITLE = "SERIES_COUNT";
	public static final String DATAFLOW_ANNOTATION_TITLE = "DATAFLOW";

	/**
	 * Returns true if this bean has metrics
	 * @return
	 */
	boolean hasMetrics();
	
	/**
	 * Returns the dataflows this bean is linked to which have data
	 * @return
	 */
	Set<ICrossReferenceBean> getLinkedDataflowsWithData();
	
	/**
	 * Returns the number of series loaded for this bean
	 * @return
	 */
	Integer getSeriesCount();
	
	/**
	 * Returns the last updated dataset
	 * @return
	 */
	Date getLastUpdated();
	
}
