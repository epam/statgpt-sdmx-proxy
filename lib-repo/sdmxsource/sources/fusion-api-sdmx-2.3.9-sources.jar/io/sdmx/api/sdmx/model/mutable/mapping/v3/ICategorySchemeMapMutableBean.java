package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;

public interface ICategorySchemeMapMutableBean extends IItemSchemeMapMutableBean<ICategoryMapMutableBean> {

	@Override
	ICategorySchemeMapBean getImmutableInstance();
}
