
package io.sdmx.api.sdmx.model.beans.base;


/**
 * Represents an SDMX Dataflow or Metadataflow
 * @author Matt Nelson
 *
 */
public interface StructureUsage extends MaintainableBean, ConstrainableBean {

}
