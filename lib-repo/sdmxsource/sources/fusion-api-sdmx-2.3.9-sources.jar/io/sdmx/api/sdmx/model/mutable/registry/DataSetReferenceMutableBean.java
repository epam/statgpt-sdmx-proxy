
package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface DataSetReferenceMutableBean extends MutableBean {

	String getDatasetId();
	
	void setDatasetId(String datasetId);
	
	StructureReferenceBean getDataProviderReference();
	
	void setDataProviderReference(StructureReferenceBean sRef);
	
}
