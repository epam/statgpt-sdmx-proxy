package io.sdmx.api.sdmx.model.format;

import io.sdmx.api.format.InformationFormat;

public interface IMetadataFormat extends InformationFormat {

}
