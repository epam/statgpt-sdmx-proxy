
package io.sdmx.api.sdmx.model.data.query;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.model.query.RESTDataQuery;


/**
 * A DataQuery is a Schema independent representation of a DataWhere/REST query.
 */
public interface DataQuery extends BaseDataQuery {
	
	/**
	 * Returns the id of the dimension to be attached at the observation level, 
	 * if not specified the returned data will be time series.
	 * @return
	 */
	String dimensionAtObservation();
	void setDimensionAtObservation(String dimAtObs);
	
	String getExpression();

	
	/**
	 * Adds a set of code selections for a concept with the given id
	 * @param concept
	 * @param selections
	 */
	void addQuerySelections(String concept, Set<String> selections, MATCH_FUNCTION match);
	
	/**
	 * Adds a query selection for this concept
	 * @param coneptId
	 * @param selection
	 */
	void addQuerySelection(String coneptId, String selection, MATCH_FUNCTION match);
	
	/**
	 * Clears all query selections for this concept
	 * @param coneptId
	 */
	void clearQuerySelections(String coneptId);
	
	
	/**
	 * Returns the selection(s) for the given component id (dimension or attribute) or returns null if no selection exists for the component id.
	 * @param coneptId
	 * @return
	 */
	Map<MATCH_FUNCTION, DataQuerySelection> getSelectionsForConcept(String componentId);
	
	/**
	 * Returns true if selections exist for this dimension Id.
	 * @param conceptId
	 * @return
	 */
	boolean hasSelectionForConcept(String componentId);
	
	/**
	 * Returns the set of selections for this group. These DataQuerySelections are implicitly ANDED together. 
	 * @return
	 */
	Set<DataQuerySelection> getSelections();
	
	
	/**
	 * <p>Returns an immutable list set containing the basket of series which are expected to be returned as a result of this query.</p>
	 * <p>The syntax is colon separated A:B:C:D</p>
	 * <p>Series can be wildcarded, and may contain + operators to indicate multiple selections, example: A:::D</p>
	 * @return
	 */
	Set<String> getSeries();
	
	/**
	 * Add a new series selection to the data query, colon separated, the dimensionality
	 * is padded to match the dimensions in the DSD (i.e if the DSD has 5 Dimensions, and there are only 3 columns A:B:C, the series will be padded to A:B:C::)
	 * @param series
	 */
	void addSeriesSelection(String... series);
	
	/**
	 * Removes the series selections if they exist in this data query
	 * @param series
	 */
	void removeSeriesSelection(String...series);
	
	/**
	 * Removes all series selections
	 */
	void clearSeriesSelections();
	
	/**
	 * Sets the query parameters based on the REST query.  This sets query parameters from the dimension selection and Matrix Parameters.
	 * It only sets query parameters from the Matrix parameters if the Component exists on the DSD.  This method does not alter the Dataflow or DSD
	 * used by the DataQuery, just the dimension and time filters of the query.
	 * @param restDataQuery
	 */
	void setQueryParameters(RESTDataQuery restDataQuery);
	
	
	/**
	 * If true then the response message will contain previous versions of the data as they were disseminated in the past
	 * past ("history" or "timeline" functionality)
	 * @return 
	 */
	boolean includeHistory();
	DataQuery setIncludeHistory(boolean bool);
	

	/**
	 * Returns the dataset id to query, this can be null
	 * @return
	 */
	String getDatasetId();
	
	
	/**
	 * To support paginiation of data queries.  The series number to start writing the results for
	 * 
	 * @return offset, 0 indicates no offset, any positive value indicates the series number to start from
	 */
	int getOffset();
	void setOffset(int pageNumber);
	
	/**
	 * @return maximum number of series to return, -1 indicates no limit, 0 indicates no data
	 */
	int getLimit();
	void setLimit(int pageSize);
	
}