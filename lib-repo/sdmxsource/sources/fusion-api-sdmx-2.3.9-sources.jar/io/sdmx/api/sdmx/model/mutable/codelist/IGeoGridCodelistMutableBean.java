package io.sdmx.api.sdmx.model.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;

public interface IGeoGridCodelistMutableBean extends CodelistMutableBean {
	
	/**
	 * @return a regular expression string corresponding to the grid definition for the GeoGrid Codelist
	 */
	String getGridDefinition();
	void setGridDefinition(String gridDefinition);
	
	
	@Override
	IGeoGridCodelistBean getImmutableInstance();
}