
package io.sdmx.api.sdmx.model.format;

/**
 * Marker interface, used to describe a data query format, the implementation is expected to offer more information describing the format
 */
public interface DataQueryFormat<T> {
	
}
