package io.sdmx.api.sdmx.model.beans.base;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

/**
 * An ItemScheme contains a list of items
 * @param <T>
 */
public interface ItemSchemeBean<T extends ItemBean> extends MaintainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<? extends ItemSchemeBean<T>> getURN();
	
	/**
	 * Returns the list of items contained within this scheme.
	 * <p/>
	 * <strong>NOTE</strong>The list is a copy so modify the returned set will not
	 * be reflected in the ItemSchemeBean instance
	 * @return
	 */
	List<T> getItems();

	/**
	 * Returns the list of items contained within this scheme for a specific  date. <br />
	 * If the items do not have a Validity Period then, it will be added, else, only items that are valid from the date specified are returned
	 * <p/>
	 * <strong>NOTE</strong>The list is a copy so modify the returned set will not
	 * be reflected in the ItemSchemeBean instance
	 * @return
	 */
	List<T> getItems(Date date);

	/**
	 * Returns true if this is a partial item scheme
	 * @return
	 */
	boolean isPartial();

	/**
	 * Returns a new item scheme based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @return
	 */
	ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet);
	
	/**
	 * Returns a new item scheme based on the item filters, which are either removed or kept depending on the isKeepSet argument
	 * @param filterIds
	 * @param isKeepSet if true then the returned item scheme will contain only items with these ids
	 * @param action the action to perform such as "keep parent"
	 * @return
	 */
	ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet, ITEM_FILTER_ACTION action);

	/**
	 * Returns the item with the given id, returns null if there is no item with the id provided
	 * @param id
	 * @return
	 */
	T getItemById(String id);

	/**
	 * Get all the items that match the given Id. <br />
	 * This can contain invalid and valid codes for the current date
	 * @param id
	 * @return
	 */
	List<T> getAllItemsById(String id);

	/**
	 * return true if any of the items in the scheme have a validity period
	 */
	@Override
	boolean hasValidityPeriod();

	/**
	 * Clone this Item scheme for the date specified.
	 * This will return a version of this itemScheme, with the items contained only being valid for the date specified.
	 * @param date
	 * @return
	 */
	ItemSchemeBean<T> cloneForDate(Date date);

	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ItemSchemeMutableBean<?> getMutableInstance();

	/**
	 * Returns a list of items, where each items is one of: <br />
	 * <ul>
	 * 	<li>Has no validity period</li>
	 * 	<li>Valid for the current time</li>
	 * 	<li>If not valid for the current time, the nearest valid item from the past</li>
	 * </ul>
	 * @return
	 */
	List<T> getItemsValidForTodayAndClosestToToday();

	/**
	 * For the specified ID return the items which are NOT valid for the current time
	 * @param id
	 * @return
	 */
	List<T> getInvalidItems(String id);

	/**
	 * return true if any of the items of these scheme has any validity periods
	 * @return
	 */
	boolean itemsHasValidityPeriod();
}