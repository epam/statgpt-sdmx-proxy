
package io.sdmx.api.sdmx.model.beans.reference.complex;

/**
 * Used to idenftify identifiable structures
 */
@Deprecated //unused
public interface ComplexIdentifiableReferenceBean extends ComplexNameableReference {

	/**
	 * Returns the Id of the item to be returned
	 * @return
	 */
	ComplexTextReference getId();
	
	/**
	 * Returns a child reference, null if there is not child reference 
	 * @return
	 */
	ComplexIdentifiableReferenceBean getChildReference();
	
}
