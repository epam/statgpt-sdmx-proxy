package io.sdmx.api.sdmx.model.beans.codelist;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;

/**
 * The HierarchyAssociation is a simple Artefact to link a Hierarchy to an Identifiable, it operates like a Categorisation. The former specifies three references:
 * <ol>
 *   <li>The link to a Hierarchy;</li>
 *   <li>The link to the IdentifiableArtefact that the Hierarchy is linked (e.g., a Dimension);</li>
 *   <li>The link to the context that the linking is taking place (e.g., a DSD).</li>
 * </ol>
 * <p>As an example, let’s assume:
 * <p>A DSD with a COUNTRY Dimension that uses Codelist CL_AREA as representation.
 * <p>A Hierarchy (e.g., EU_COUNTRIES) that builds a hierarchy for the CL_AREA Codelist.
 * <p>In order to use this Hierarchy for data of a Dataflow (e.g., EU_INDICATORS), we need to build the following HierarchyAssociation:
 * <ol>
 *   <li>Links to the Hierarchy EU_COUNTRIES (what is associated?)</li>
 * 	 <li>Links to the Dimension COUNTRY (where is it associated?)</li>
 *   <li>Links to the context: Dataflow EU_INDICATORS (when is it associated?)</li>
 * </ol>
 */
public interface HierarchyAssociationBean extends MaintainableBean {

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<HierarchyAssociationBean> getURN();
	
	/**
	 * @return not null - reference to the Hierarchy with which this is linking
	 */
	ICrossReferenceBean<HierarchyBean> getHierarchyRef();

	/**
	 * @return not null - reference to the identifiable which the hierarchy is being linked to
	 */
	ICrossReferenceBean<?> getLinkedStructureRef();
	
	/**
	 * @return optional reference to a structure to give the link context, e.g. if the Link is to Dimension the Context could be a Dataflow (i.e. only link to this in the context of that)
	 */
	ICrossReferenceBean<?> getContextStructureRef();
	
	@Override
	HierarchyAssociationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub);
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	HierarchyAssociationMutableBean getMutableInstance();
}
