package io.sdmx.api.sdmx.model.tx;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;

/**
 *  Provides 0 to many filters on transactions
 *  @see IObjectTransactionManager
 */
public interface ITransactionQuery {
	
	/**
	 * @return not null, the date or date range or AllPeriods
	 */
	SdmxPeriod getPeriod();

	/**
	 * @return true if there is a max result filter present
	 */
	default boolean hasMaxResults() {
		return getMaxResults() != null;
	}

	/**
	 * @return nullable - the maximum number of results to return
	 */
	Integer getMaxResults();
	
	/**
	 * @return true to order by time descending (latest transaction first)
	 */
	boolean isOrderDesc();
	
	/**
	 * @return nullable - username to filter by
	 */
	String getUser();
	
	/**
	 * @return nullable Action Number to filter by
	 * @see DATASET_ACTION
	 */
	Integer getAction();
	
	/**
	 * @return nullable, the store where the object was assigned (structure, metadata)
	 */
	String getStore();
}
