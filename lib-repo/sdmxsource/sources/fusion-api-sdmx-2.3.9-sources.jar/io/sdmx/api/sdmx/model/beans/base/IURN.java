package io.sdmx.api.sdmx.model.beans.base;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

/**
 * Represents an SDMX URN or parts of a URN which can be used to reference one or more structures,
 * the IURN is itself an {@link IMaintainableRef} which it derives from it's internally held {@link IMaintainableRef}
 */
public interface IURN<K extends IdentifiableBean> extends Serializable, IMaintainableRef {

	enum REFERENCE_TYPE {
		ABSOLUTE(true),  //a reference to a single artifact fixed in time - all URN parts present									   (IURNAbsolute)
		SEMANTIC(true),  //a reference to a single artifact can change on version - all URN parts semantic version reference present (IURNSingle)
		WILDCARD(false),  //a reference which can match more then one structure by omitting values for one or more properties		   (IURN)
		MULTIPLE(false);  //a reference which can match more then one structure through multiple values for each property             (IURNMultiple)
	
		private boolean isSingle;

		private REFERENCE_TYPE(boolean isSingle) {
			this.isSingle = isSingle;
		}

		/**
		 * @return true if the reference type resolves to a single structure (Absolute and semantic) false if it
		 * can resolve to mulitple (wildcard, multiple)
		 */
		public boolean isSingle() {
			return isSingle;
		}
	}
	
	/**
	 * @return this URN as a multiple reference, this only possible if this URN is a REFERENCE_TYPE of MULTIPLE
	 * @throws IllegalArgumentException if the REFERENCE_TYPE of this URN is not MULTIPLE
	 */
	default IURNMultiple<K> asMultiple() {
		if(this instanceof IURNMultiple) {
			return (IURNMultiple)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: IURNMultiple");
	}
	
	/**
	 * @return this URN as a multiple reference, this only possible if this URN is a REFERENCE_TYPE of SEMANTIC or ABSOLUTE
	 * @throws IllegalArgumentException if the REFERENCE_TYPE of this URN is not SEMANTIC or ABSOLUTE
	 */
	default IURNSingle<K> asSingle() {
		if(this instanceof IURNSingle) {
			return (IURNSingle)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: IURNSingle");
	}
	
	/**
	 * @return this URN as an absolute reference, this only possible if this URN is a REFERENCE_TYPE of ABSOLUTE
	 * @throws IllegalArgumentException if the REFERENCE_TYPE of this URN is not ABSOLUTE
	 */
	default IURNAbsolute<K> asAbsolute(){
		if(this instanceof IURNSingle) {
			return (IURNAbsolute)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: IURNSingle");
	}
	
	/**
	 * @param <T>
	 * @param type
	 * @return true if the URN is this type
	 */
	default <T extends IdentifiableBean> boolean isType(Class<T> type) {
		//The Class.isAssignableFrom method will return true if the Class on the left-hand side of the statement is the same as
		//or is a superclass or superinterface of the provided Class parameter.
		return type.isAssignableFrom(getStructureClass());
	}
	
	/**
	 * Casts this type to the given type T if it is able to do so
	 * @param <T>
	 * @param type
	 * @return
	 * @throws IllegalArgumentException - if the type T is not assignable to the structure type this URN is referencing
	 */
	default <T extends IdentifiableBean> IURN<T> toType(Class<T> type) {
		if(isType(type)) {
			return (IURN<T>)this;
		}
		throw new IllegalArgumentException("URN  '"+getURN()+"' can not be assiged to type: " +type.getCanonicalName());
	}

	/**
	 * @return true if this URN is referencing a maintainable type.  A maintainable type would mean getStructureClass returns
	 * a Class K which is either {@link MaintainableBean} or a sub-interface of this interface
	 */
	default boolean isMaintainableReference() {
		return getStructureType().isMaintainable();
	}
	
	/**
	 * @return  a mutable copy of itself
	 */
	StructureReferenceBean asMutable();
	
	/**
	 * @return not null - the URN as a String
	 */
	String getURN();
	String toURNString();
	
	default Class<K> getStructureClass() {
		return getStructureType().getClassType();
	}
	
	/**
	 * @return not null - the maintainable URN for this instance, if this instance is a maintainable type returns this, otherwise returns a URN with the agencyid, id, version and maintainable
	 * type set
	 */
	IURN<? extends MaintainableBean> getMaintainableURN();
	
	/**
	 * @return enum of SDMX structure, or SDMX_STRUCTURE_TYPE.NON_SDMX if this is an extended structure
	 */
	SDMX_STRUCTURE_TYPE getSdmxStructure();
	
	/**
	 * @return not null - the definition for the type of structure this is
	 */
	ISDMXStructureType<?, K> getStructureType();

	/**
	 * @return not null - the type of URN reference this is, defaults to wildcard, overidden by sub types
	 */
	default REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.WILDCARD;
	}
	
	/**
	 * @return not null - urn without the URN prefix (everything after the '=')
	 */
	String getShortURN();
	
	/**
	 * @return nullable the identifiable ID
	 */
	String getIdentifiableId();

	/**
	 * @return the identifiable ID include parent Identifiable IDs i.e. AGRICULTURE.HAY
	 */
	String getFullIdentifiableId();
	
	/**
	 * @return true if there is a maintainable id set
	 */
	default boolean hasIdentifiableId() {
		return getIdentifiableId() != null && !getIdentifiableId().equals("*");
	}
	
	/**
	 * @param identifiableBean to test the match against
	 * @return true if this cross reference matches the attributes of the {@link IdentifiableBean}
	 */
	default boolean isMatch(IdentifiableBean identifiableBean) {
		return isMatch(identifiableBean.getURN());
	}
	
	/**
	 * @param that to test the match against
	 * @return true if this cross reference matches the attributes of the passed in urn
	 */
	default boolean isMatch(IURN<?> that) {
	    ISDMXStructureType<?,?> thisSt = this.getStructureType();
        
		if(!thisSt.matchesType(that)) {
			return false;
		}
		if(this.hasAgencyId() && that.hasAgencyId() && !this.getAgencyId().equals(that.getAgencyId())) {
			return false;
		}
		if(this.hasMaintainableId() && that.hasMaintainableId() && !this.getMaintainableId().equals(that.getMaintainableId())) {
			return false;
		}
		if(!this.getVersion().isMatch(that.getVersion())) {
			return false;
		}
		//If one URL has an identifiable ID which is not * and the other does not have anything then return false
		if(this.getIdentifiableId() == null && that.hasIdentifiableId()) {
		    return false;
		}
		if(that.getIdentifiableId() == null && this.hasIdentifiableId()) {
            return false;
        }
		if(this.hasIdentifiableId() && that.hasIdentifiableId() && !this.getFullIdentifiableId().equals(that.getFullIdentifiableId())) {
		    return false;
		}
		return true;
	}
}
