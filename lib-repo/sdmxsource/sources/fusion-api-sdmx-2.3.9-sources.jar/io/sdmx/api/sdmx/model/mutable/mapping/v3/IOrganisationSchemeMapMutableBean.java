package io.sdmx.api.sdmx.model.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;

public interface IOrganisationSchemeMapMutableBean extends IItemSchemeMapMutableBean<IOrganisationMapMutableBean> {

	@Override
	IOrganisationSchemeMapBean getImmutableInstance();
}
