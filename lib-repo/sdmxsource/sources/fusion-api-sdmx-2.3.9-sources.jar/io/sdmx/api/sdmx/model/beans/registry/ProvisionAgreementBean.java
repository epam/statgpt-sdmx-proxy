
package io.sdmx.api.sdmx.model.beans.registry;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;

/**
 * Represents an SDMX Provision Agreement
 *
 */
public interface ProvisionAgreementBean extends MaintainableBean, ConstrainableBean, IDSDRelatedBean {
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<ProvisionAgreementBean> getURN();
	
	/**
	 * @return not null, reference to the Dataflow this provision is for
	 */
	ICrossReferenceBean<DataflowBean> getStructureUseage();
	
	/**
	 * @return not null, reference to the Data Provider this provision is for
	 */
	ICrossReferenceBean<DataProviderBean> getDataproviderRef();
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	ProvisionAgreementMutableBean getMutableInstance();
}
