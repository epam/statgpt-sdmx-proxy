package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public interface IVtlMappingSchemeMutableBean extends ItemSchemeMutableBean<IVtlMappingMutableBean> {

	@Override
	IVtlMappingSchemeBean getImmutableInstance();
	
	/**
	 * Adds a codelist mapping and returns it
	 * @param id of mapping
	 * @param ref to codelist
	 * @return mapping
	 */
	IVtlCodelistMappingMutableBean addCodelistMapping(String id, String alias, IMaintainableRef ref);
	
	/**
	 * Adds a concept scheme mapping and returns it
	 * @param id id of mapping
	 * @param ref concept scheme reference
	 * @param conceptId id of concept
	 * @return mapping
	 */
	IVtlConceptMappingMutableBean addConceptMapping(String id, String alias, IMaintainableRef ref, String conceptId);
	
	/**
	 * Adds a dataflow mapping and returns it
	 * @param id id of mapping
	 * @param ref dataflow reference
	 * @return mapping
	 */
	IVtlDataflowMappingMutableBean addDataflowMapping(String id, String alias, IMaintainableRef ref);
	
}
