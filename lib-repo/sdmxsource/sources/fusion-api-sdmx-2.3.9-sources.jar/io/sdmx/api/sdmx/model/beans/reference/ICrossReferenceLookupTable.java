package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;
import java.util.Set;

/**
 * Holds a collection of direct and indirect references
 */
public interface ICrossReferenceLookupTable extends Serializable {

	/**
	 * @return not null, a set of direct references (those that can be determined from the link as it is a URN)
	 */
	Set<IMaintainableReferences> getMaintDirectReferences();

	/**
	 * @return not null, a set of indirect references (those that can only be determined by using other structures as the link is typically an ID, example
	 * a constraint on a Dataflow constraining FREQ, the only way to know what the URN is of FREQ is to lookup the DSD to find the Concept URN for the corresponding
	 * FREQ Component
	 */
	Set<IMaintainableReferences> getMaintIndirectReferences();
}
