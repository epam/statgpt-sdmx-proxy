package io.sdmx.api.sdmx.model.beans.xs;

import java.io.Serializable;

import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;

/**
 * An {@link IMaintainableRef} is a reference to a maintainable type, this acts as a filter, null properties indicate no filter i.e.  'all'
 * 
 * Can also be used as a {@link MaintainableRefBean} until removed from system
 */
public interface IMaintainableRef extends Serializable  {
	
	/**
	 * @return nullable the agency id
	 */
	String getAgencyId();
		
	/**
	 * @return true if there is an agency Id set
	 */
	default boolean hasAgencyId() {
		return getAgencyId() != null;
	}
	
	/**
	 * @return nullable the maintainable id 
	 */
	String getMaintainableId();
	
	/**
	 * @return true if there is a maintainable id set
	 */
	default boolean hasMaintainableId() {
		return getMaintainableId() != null;
	}
	
	/**
	 * @return not null - the version to return, this can be all versions if {@link IVersionRef} isAll returns true
	 */
	IVersionRef getVersion();
	
	
	default boolean isWildcard() {
		return !hasAgencyId() || !hasMaintainableId() || getVersion().isAll();
	}
	
}
