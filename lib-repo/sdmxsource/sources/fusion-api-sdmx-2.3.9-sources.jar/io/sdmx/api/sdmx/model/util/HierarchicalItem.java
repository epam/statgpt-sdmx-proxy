package io.sdmx.api.sdmx.model.util;


public interface HierarchicalItem<T> extends HierarchyNode<T> {

	/**
	 * Returns the item in the Hierarchy
	 * @return
	 */
	T getItem();
	
	/**
	 * Returns the parent of this item, or null if there is no parent
	 * @return
	 */
	HierarchyNode<T> getParent();
	
}
