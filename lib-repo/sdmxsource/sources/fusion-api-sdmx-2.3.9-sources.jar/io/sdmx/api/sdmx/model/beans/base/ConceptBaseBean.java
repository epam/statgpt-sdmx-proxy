package io.sdmx.api.sdmx.model.beans.base;

/**
 * To be extended by concept or standalone concept.
 * <p/>
 * Concept base contains the common methods and inheritance tree for both concepts maintained within schemes (<code>ConceptBean</code>)
 * and those maintained outside of schemes (<code>StandAloneConceptBean</code>).
 * @author Matt Nelson
 *
 */
public interface ConceptBaseBean extends NameableBean {

	/**
	 * Returns true if this concept is maintained outside of a scheme.
	 * If this is true then the concept will be a <code>MaintainableBean</code>
	 * @return true if this concept is maintained outside of a scheme.
	 */
	boolean isStandAloneConcept();

}