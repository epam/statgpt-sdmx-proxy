
package io.sdmx.api.sdmx.model.beans.reference.complex;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;

@Deprecated //unused
public interface ComplexNameableReference {
	
	/**
	 * Returns the structure type that is being referenced, this can not be null
	 * @return
	 */
	SDMX_STRUCTURE_TYPE getReferencedStructureType();
	
	/**
	 * 
	 * @return an annotation reference
	 */
	ComplexAnnotationReference getAnnotationReference();
	
	/**
	 *  
	 * @return a name reference
	 */
	ComplexTextReference getNameReference();
	
	/**
	 * 
	 * @return a description reference for a NameableBean
	 */
	ComplexTextReference getDescriptionReference();
	
	
}
