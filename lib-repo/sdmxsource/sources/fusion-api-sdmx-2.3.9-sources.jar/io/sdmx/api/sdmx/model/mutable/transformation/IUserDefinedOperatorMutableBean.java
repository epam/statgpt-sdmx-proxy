package io.sdmx.api.sdmx.model.mutable.transformation;

import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public interface IUserDefinedOperatorMutableBean extends ItemMutableBean {

	/**
	 * A VTL statement for the definition of a new operator; it specifies the operator name,
	 * its parameters and the data types, the VTL expression that defines its behaviour
	 * @return not null. 
	 */
	String getOperatorDefinition();
	void setOperatorDefinition(String operatorDefinition);
	
}
