package io.sdmx.api.sdmx.model.mutable.base;

public interface TextTypeWrapperMutableBean extends MutableBean {

	String getLocale();

	String getValue();

	void setLocale(String locale);

	void setValue(String value);
}
