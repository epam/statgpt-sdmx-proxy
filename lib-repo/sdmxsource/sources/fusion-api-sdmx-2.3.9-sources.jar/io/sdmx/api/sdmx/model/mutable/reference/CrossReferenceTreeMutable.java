
package io.sdmx.api.sdmx.model.mutable.reference;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Contains a maintainable with all the maintainables that it references
 */
public interface CrossReferenceTreeMutable {
	
	MaintainableMutableBean getMaintianableBean();
	
	void setMaintianableBean(MaintainableMutableBean maintianableBean);
	
	List<CrossReferenceTreeMutable> getReferencingBeans();
	
	void setReferencingBeans(List<CrossReferenceTreeMutable> referencingBeans);

}
