
package io.sdmx.api.sdmx.model.beans.registry;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.registry.SubscriptionMutableBean;


/**
 * Represents an SDMX Subscription
 * @author Matt Nelson
 *
 */
public interface SubscriptionBean extends MaintainableBean {
	static String WILDCARD= "%";
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNMaintainable<SubscriptionBean> getURN();
	
	/**
	 * Returns a reference to the owner of this subscription
	 * @return
	 */
	ICrossReferenceBean<? extends OrganisationBean> getOwner();
	
	/**
	 * Returns a list of email addresses to mail any notifications to
	 * @return
	 */
	List<String> getMailTo();
	
	/**
	 * Returns a list of HTTP addresses to POST any notifications to
	 * @return
	 */
	List<String> getHTTPPostTo();
	
	/**
	 * Returns a list of structures that this subscription is subscribing to,
	 * or in the case that this is subscribing to a provision or registration, returns the structure
	 * reference that it is subscribing to the provision or registration by.
	 * @return
	 */
	List<IURN<?>> getReferences();
	
	
	/**
	 * Returns if this is a subscription for a structure event a provision event or a registration event
	 * @return
	 */
	SUBSCRIPTION_TYPE getSubscriptionType();
	
	
	/**
	 * Returns a representation of itself in a bean which can be modified, modifications to the mutable bean
	 * are not reflected in the instance of the MaintainableBean.
	 * @return
	 */
	@Override
	SubscriptionMutableBean getMutableInstance();
	
	
	enum SUBSCRIPTION_TYPE {
		DATA_REGISTRATION,
		METADATA_REGISTRATION,
		STRUCTURE;
	}
}
