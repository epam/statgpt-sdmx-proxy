package io.sdmx.api.sdmx.model.mutable.registry;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

import java.util.List;

/**
 * MetadataConstraint defines the structure of a metadata constraint.
 * A metadata constraint can specify allowed attribute values for metadata
 * described by the constrained artefact.
 */
public interface IMetadataConstraintMutableBean extends MaintainableMutableBean {
	
	@Override
	IMetadataConstraintBean getImmutableInstance();

	List<StructureReferenceBean> getAttachments();
	IMetadataConstraintMutableBean setAttachments(List<StructureReferenceBean> constraintAttachments);
	
	List<KeyValuesMutable> getIncludedTarget();
	IMetadataConstraintMutableBean setIncludedTarget(List<KeyValuesMutable> includedTargets);
	
	List<KeyValuesMutable> getExcludedTarget();
	IMetadataConstraintMutableBean setExcludedTarget(List<KeyValuesMutable> excludedTargets);

	ReleaseCalendarMutableBean getReleaseCalendar();
	IMetadataConstraintMutableBean setReleaseCalendar(ReleaseCalendarMutableBean releaseCalendar);
}
