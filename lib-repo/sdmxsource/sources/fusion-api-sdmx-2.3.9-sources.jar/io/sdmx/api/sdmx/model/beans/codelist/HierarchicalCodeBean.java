package io.sdmx.api.sdmx.model.beans.codelist;

import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;


/**
 * Represents an SDMX Hierarchical Code
 * @author Matt Nelson
 *
 */
public interface HierarchicalCodeBean extends IdentifiableBean, ValidityPeriodBean {
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	IURNAbsolute<HierarchicalCodeBean> getURN();
	
	/**
	 * Returns the level of this code ref bean in the hierarchy, 1 indexed
	 * @return
	 */
	int getLevelInHierarchy();
	
	/**
	 * Returns true if this HierarchicalCodeBean has child HierarchicalCodeBeans
	 * @return true if getCodeRefs() returns a non-empty list
	 * @see getCodeRefs
	 */
	boolean hasChildren();
	
	/**
	 * @return immutable list of code refs, or an empty list if there are none
	 */
	List<HierarchicalCodeBean> getCodeRefs();
	
	/**
	 * Returns the code referenced by this CodeRef, this will never be null as it will be resolved from the codelist alias and code id
	 * @return
	 */
	ICrossReferenceBean<CodeBean> getCodeReference();
	
	default String getCodeId() {
		return getCodeReference().getReference().getFullIdentifiableId();
	}
	
	/**
	 * @param acceptDefault - if this code reference was not explicitly assigned a level, but the hierarchy is leveled then this code
	 * reference will default the level to that of the level in the same hierarchical level.  If true then will pass out the defaulted level if the
	 * level was not explicitly set on creation, if false, then will return the level if it was explicitly set, and will return null if it wasn't.
	 * @return the level associated with this code
	 */
	LevelBean getLevel(boolean acceptDefault);
	
	SdmxDate getValidFrom();

	SdmxDate getValidTo(); 
	
	String getVersion();
}
