
package io.sdmx.api.sdmx.model.beans.reference;

import java.io.Serializable;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;


/**
 * Defines a tree structure of Identifiable along with a set of all the structures that cross reference the Identifiable
 */
public interface CrossReferencingTree extends Serializable {
	
	/**
	 * Returns the maintainable for which the structures are referencing 
	 * @return
	 */
	MaintainableBean getMaintainable();
	
	/**
	 * Returns a set of maintainables that reference the given identifiable
	 * @return
	 */
	List<CrossReferencingTree> getReferencingStructures();
	
}
