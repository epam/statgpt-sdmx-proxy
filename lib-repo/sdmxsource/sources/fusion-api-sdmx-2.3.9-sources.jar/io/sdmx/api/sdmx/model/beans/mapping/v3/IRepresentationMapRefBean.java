package io.sdmx.api.sdmx.model.beans.mapping.v3;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Defines either a reference to a Codelist or Value List - or a Data Type
 */
public interface IRepresentationMapRefBean extends SDMXBean {

	/**
	 * @return reference to a Codelist or Valuelist - can be null
	 */
	ICrossReferenceBean<? extends EnumeratedListBean> getEnumerationRef(); 
	
	default boolean hasEnumerationRef() {
		return getEnumerationRef() != null;
	}
	
	/**
	 * @return if there is no enumeration ref, there will be a text type to define what is being mapped
	 */
	TEXT_TYPE getTextType();
}
