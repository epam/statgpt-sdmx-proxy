
package io.sdmx.api.sdmx.model.mutable.datastructure;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface DataStructureMutableBean extends MaintainableMutableBean {

	void addGroup(GroupMutableBean group);

	List<GroupMutableBean> getGroups();

	void setGroups(List<GroupMutableBean> groups);

	DimensionListMutableBean getDimensionList();

	/**
	 * Removes the component (dimension or attribute) with the given id
	 * @param id
	 * @return this
	 */
	DataStructureMutableBean removeComponent(String id);

	void addAttribute(AttributeMutableBean attribute);

	void addDimension(DimensionMutableBean dimension);

	void addMeasure(MeasureMutableBean measure);

	ComponentMutableBean getComponentById(String id);

	DimensionMutableBean addDimension(StructureReferenceBean conceptRef, StructureReferenceBean codelistRef);

	AttributeMutableBean addAttribute(StructureReferenceBean conceptRef, StructureReferenceBean codelistRef);

	MeasureMutableBean addPrimaryMeasure(StructureReferenceBean conceptRef);

	void setDimensionList(DimensionListMutableBean dimensionList);

	AttributeListMutableBean getAttributeList();

	void setAttributeList(AttributeListMutableBean attributeList);

	MeasureMutableBean getPrimaryMeasure();

	MeasureListMutableBean getMeasureList();

	void setMeasureList(MeasureListMutableBean measureList);

	void setPrimaryMeasure(MeasureMutableBean primaryMeasure);
	
	void setMSDReference(StructureReferenceBean sRef);
	StructureReferenceBean getMSDReference();
	
	/**
	 * Returns the dimension with the given id, or null if there is no match
	 * @return
	 */
	DimensionMutableBean getDimension(String id);

	/**
	 * Returns the list of dimensions, this may return null or an empty list if none exist
	 * @return
	 */
	List<DimensionMutableBean> getDimensions();

	/**
	 * Returns the list of attributes, this may return null or an empty list if none exist
	 * @return
	 */
	List<AttributeMutableBean> getAttributes();

	/**
	 * Returns the list of attributes, this may return null or an empty list if none exist
	 * @return
	 */
	List<MeasureMutableBean> getMeasures();

	/**
	 * Returns the attribute with the given id, or null if there is no match
	 * @return
	 */
	AttributeMutableBean getAttribute(String id);

	/**
	* Returns a representation of itself in a bean which can not be modified, modifications to the mutable bean
	* are not reflected in the returned instance of the MaintainableBean.
	* @return
	*/
	@Override
	DataStructureBean getImmutableInstance();
}
