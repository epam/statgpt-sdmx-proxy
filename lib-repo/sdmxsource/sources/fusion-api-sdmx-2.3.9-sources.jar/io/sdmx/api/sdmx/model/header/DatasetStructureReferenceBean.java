
package io.sdmx.api.sdmx.model.header;

import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;

/**
 * Structure is used in a Dataset header, where there is a one to one mapping between a Structure (which defines the DSD/Flow/or Provision and the Dimension at the observation level)
 * @author Matt Nelson
 *
 */
public interface DatasetStructureReferenceBean {

	String ALL_DIMENSIONS = "AllDimensions";
	
	/**
	 * Returns the id of this structure, this 
	 * @return
	 */
	String getId();
	/**
	 * Returns the structure reference, either a provision agreement, dataflow, a data structure definition (DSD), or metadata structure definition (MSD)
	 * @return
	 */
	IURNSingle<? extends IDSDRelatedBean> getStructureReference();
	
	/**
	 * The serviceURL attribute indicates the URL of an SDMX SOAP web service from which the 
	 * details of the object can be retrieved. 
	 * <p/>
	 * Note that this can be a registry or and SDMX structural metadata repository, as they both implement that same web service interface.
	 * @return
	 */
	String getServiceURL();
	
	/**
	 * The structureURL attribute indicates the URL of a SDMX-ML structure message 
	 * (in the same version as the source document) in which the externally referenced object is contained. 
	 * <p/>
	 * Note that this may be a URL of an SDMX RESTful web service which will return the referenced object.
	 * @return
	 */
	String getStructureURL();
	
	/**The dimensionAtObservation is used to reference the dimension at the observation level for data messages. 
	 * <p/>
	 * Structure.ALL_DIMENSIONS denotes that the cross sectional data is in the flat format.
	 * <p/>
	 * PrimaryMeasureBean.FIXED_ID denotes that the data is in time series format
	 */
	String getDimensionAtObservation();
	
	/**
	 * Returns true if getDimensionAtObservation() returns PrimaryMeasureBean.FIXED_ID
	 * @return
	 */
	boolean isTimeSeries();
	
}
