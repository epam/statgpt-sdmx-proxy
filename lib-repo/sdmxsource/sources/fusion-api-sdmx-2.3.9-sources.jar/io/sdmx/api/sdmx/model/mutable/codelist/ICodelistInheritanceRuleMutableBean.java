package io.sdmx.api.sdmx.model.mutable.codelist;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ICodelistInheritanceRuleMutableBean extends MutableBean {
	
	/**
	 * @return the reference to the Codelist to inherit from
	 */
	StructureReferenceBean getCodelistRef();
	ICodelistInheritanceRuleMutableBean setCodelistRef(StructureReferenceBean ref);
	
	/**
	 * @return the prefix to include on the inherited Codelist
	 */
	String getPrefix();
	ICodelistInheritanceRuleMutableBean setPrefix(String prefix);

	/**
	 * @return list of ids to include from inheritance, the presence of a % indicates a wildcard
	 */
	List<String> getInclusiveInheritenceIds();
	ICodelistInheritanceRuleMutableBean setInclusiveInheritenceIds(List<String> ids);
	ICodelistInheritanceRuleMutableBean addInclusiveInheritenceId(String id);
	
	/**
	 * @return set of Code Ids to cascade down from in the inheritance inclusion rule
	 */
	Set<String> getInclusiveInheritenceCascades();
	ICodelistInheritanceRuleMutableBean addInclusiveInheritenceCascades(String codeId);
	ICodelistInheritanceRuleMutableBean setInclusiveInheritenceCascades(Set<String> codes);
	/**
	 * @return list of ids to exclude from inheritance, the presence of a % indicates a wildcard
	 */
	List<String> getExclusiveInheritenceIds();
	ICodelistInheritanceRuleMutableBean setExclusiveInheritenceIds(List<String> ids);
	ICodelistInheritanceRuleMutableBean addExclusiveInheritenceId(String id);

	/**
	 * @return set of Code Ids to cascade down from in the inheritance exclusion rule
	 */
	Set<String> getExclusiveInheritenceCascades();
	ICodelistInheritanceRuleMutableBean addExclusiveInheritenceCascades(String codeId);
	ICodelistInheritanceRuleMutableBean setExclusiveInheritenceCascades(Set<String> codes);
}
