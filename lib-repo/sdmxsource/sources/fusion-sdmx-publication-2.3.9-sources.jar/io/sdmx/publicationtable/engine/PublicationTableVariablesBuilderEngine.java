package io.sdmx.publicationtable.engine;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.core.data.model.mapping.FrequencyFormatMap;
import io.sdmx.core.data.model.mapping.value.ComponentMappingRules;
import io.sdmx.publicationtable.api.engine.IPublicationTableVariablesBuilderEngine;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.variable.PublicationVariables;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Creates PublicationVariables which contain variable values for all DSD Components, including variables for all Codes for each coded component
 * @author Matt Nelson
 *
 */
public class PublicationTableVariablesBuilderEngine implements IPublicationTableVariablesBuilderEngine {
	private static final Logger LOG = LoggerFactory.getLogger(PublicationTableVariablesBuilderEngine.class);
	
	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	

	public PublicationTableVariablesBuilderEngine(SdmxSuperBeanRetrievalManager superBeanRetrievalManager, SdmxBeanRetrievalManager beanRetrievalManager) {
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}


	public ICellVariables build(PublicationTableBean publicationTable, Map<String, String> queryParameters) {
		//Expand any variable mappings
		if(publicationTable.getVariableMapping() != null) {
			queryParameters = queryParameters == null ? new HashMap<>() : new HashMap<>(queryParameters); //Create editable map
			for(PublicationTableVariableMappingBean mapping : publicationTable.getVariableMapping()) {
				String dimId = mapping.getInputDimensionId();
				String dimValue = queryParameters.get(dimId);
				
				if(dimValue != null) {
					IRepresentationMapBean repMap = beanRetrievalManager.getBean(mapping.getMappingRules().getReference());
					ComponentMappingRules mappingRules = new ComponentMappingRules(CollectionUtil.getImmutableList(dimId), mapping.getOutputDimensionId(), repMap, false);
					
					String variableTime = queryParameters.get(DimensionBean.TIME_DIMENSION_FIXED_ID);
					SdmxPeriod period =  variableTime == null ? SdmxPeriodImpl.ALL_PERIODS : new SdmxPeriodImpl(variableTime, variableTime);
					Map<SdmxPeriod, Set<KeyValue>> mapped = mappingRules.getMappedCodes(period, dimValue);
					if(mapped != null) {
						for(SdmxPeriod currentPeriod : mapped.keySet()) {
							if(period.isInPeriod(currentPeriod)) {
								for(KeyValue kv : mapped.get(currentPeriod)) {
									String concept = kv.getConcept();
									if(!ObjectUtil.validString(queryParameters.get(concept))) {
										queryParameters.put(concept, kv.getCode());
									}
								}
							}
 						}
					}
				}
			}
		}
		
		//Create Variables based on passed in values
		PublicationVariables variables = new PublicationVariables(publicationTable, queryParameters);

		for(PublicationTableDataflow df : publicationTable.getDataflowReferences()) {
			DataflowSuperBean dfSb = superBeanRetrievalManager.getDataflowSuperBean(df.getDataflowRef().getReference());
			if(dfSb != null) {
				variables.addDataflow(df.getAlias(), dfSb);
			}
		}
		
		if(publicationTable.getTimeFormatMapping() != null) {
			IRepresentationMapBean repMap = beanRetrievalManager.getBean(publicationTable.getTimeFormatMapping().getReference());
			if(repMap != null) {
				variables.setFrequencyFormatMapping(new FrequencyFormatMap(repMap));
			} else {
				LOG.error("Can not find referenced time format mapping: "+publicationTable.getTimeFormatMapping().getTargetUrn());
			}
		}
		
		
		//Imported Variables
		for(PublicationVariableBean variable : publicationTable.getVariables()) {
			String alias = variable.getId();
			EnumeratedListBean cl = beanRetrievalManager.getBean(variable.getCodelistReference().getReference());
			if(cl != null) {
				variables.setCodelist(alias, cl);
			}
		}
		for(ConditionalVariable cv : publicationTable.getConditionalVariables()) {
			String id = cv.getId();  //BANKNOTE
			String dimId = cv.getDimensionCondition();
			String dimVal = queryParameters.get(dimId);
			if(ObjectUtil.validString(dimVal)) {
				for(ConditionalVariableValues cvVals : cv.getConditionalVariableValues()) {
					String variableId = cvVals.getMappedId();  // Badly named method, needs to change to getVariableId()
					String targetVal = cvVals.getMappedValue(dimVal);
					if(ObjectUtil.validString(dimVal)) {
						String variable = id+"["+variableId+"]";
						variables.addStringVariable(variable, targetVal);
					}
				}
			}
		}
		return variables;
	}
}
