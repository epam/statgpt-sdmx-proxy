package io.sdmx.publicationtable.engine;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.Styleable;
import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBody;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBodyRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHead;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHeadRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTextCell;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;

/**
 * Writes the data table in JSON format
 */
public class OutputTableJSONWriterEngine implements OutputTableWriterEngine {

	/**
	 * Example format
	 * 
	 * {
			"Id" : "A10",
			"TDef" : urn,
			"Dataflows" : {
				"Alias" : urn
				
			 }
			"Title" : "Summary of locational statistics, by currency, instrument and residence and sector of Counterparty",
			"SubTitle" : "Outstanding at end-December 2017, in billions of US dollars",
			"Period" : "2008-Q1",
			"Legend" : "Data are incomplete. See Table A2 for a list of countries that report non-bank sub-sectors.",
			"Styles" : ["t1"],
			"Variables" : {
				"TIME_PERIOD" : "2008",
				"MEASURE"     : "S"
			}
			"THead" : [
			  [
				{
					"Label" : "All sectors",
					"Colspan" : 1,
					"Rowspan" : 2,
					"Styles": ["h1"]
				}, ... object for each cell
			  ],   ... array of row cells
			],     ... array for each row
			"TBody" : [
				{
					"Label":  "Cross-border positions",
					"Styles": ["h1"]
					"Cells": [
						{
							"Key" : "Q:G:L:T01:A:5J:A:A:B:NI:N",
							"Value" : 29,815
						}  ... object for each cell
					]
					"Children" : [
						"Label":
						"Cells": []
						"Children" : [
							...
						]
					]
				 
				}  ... object for each row
			]
		}
	 */
	//TODO Modify this description
	@Override
	public void writeOutputTable(OutputPublicationTable outputTable, OutputStream out) {
		try (JsonGenerator jsonGenerator  = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)){
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("Id", outputTable.getId());
			jsonGenerator.writeStringField("Title", outputTable.getTitle());
			if(outputTable.getSubTitle() != null) {
				jsonGenerator.writeStringField("SubTitle", outputTable.getSubTitle());
			}
			jsonGenerator.writeStringField("TDef", outputTable.getTableDef().getUrn());
			writeDataflows(outputTable.getTableDef(), jsonGenerator);
			
			//Period is output as part of the variables
//			if(outputTable.getPeriod() != null) {
//				jsonGenerator.writeStringField("Period", outputTable.getPeriod());
//			}
			if(outputTable.getAvailablePeriod() != null) {
				jsonGenerator.writeStringField("EarliestPeriod", outputTable.getAvailablePeriod().getStartPeriod().getDateInSdmxFormat());
				jsonGenerator.writeStringField("LatestPeriod", outputTable.getAvailablePeriod().getEndPeriod().getDateInSdmxFormat());
			}
			
			writeVariables(outputTable.getPublicationVariables(), jsonGenerator);
			writeStyles(outputTable, jsonGenerator);
			writeTHead(outputTable.getTHead(), jsonGenerator);
			writeTBody(outputTable.getTBody(), jsonGenerator);
			writeFootnotes(outputTable.getFootnotes(), jsonGenerator);
			jsonGenerator.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private void writeDataflows(PublicationTableBean tableDef, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("Dataflows");
		for(PublicationTableDataflow ptDataflow : tableDef.getDataflowReferences()) {
			String alias = ObjectUtil.validString(ptDataflow.getAlias()) ? ptDataflow.getAlias() : "DEFAULT";
			jsonGenerator.writeStringField(alias, ptDataflow.getDataflowRef().getTargetUrn());
		}
		jsonGenerator.writeEndObject();
	}
	
	private void writeVariables(ICellVariables variables, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeObjectFieldStart("Variables");
		if(variables.getTimePeriod() != null) {
			jsonGenerator.writeStringField(DimensionBean.TIME_DIMENSION_FIXED_ID, variables.getTimePeriod().getBasePeriod().getDateInSdmxFormat());
		}
		for(String dimId : variables.getVariableDimensions()) {
			jsonGenerator.writeStringField(dimId, variables.getDimensionValue(dimId));
		}
		jsonGenerator.writeEndObject();
	}
	
	private void writeTHead(OutputPublicationTableTHead tHead, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeArrayFieldStart("THead");
		for(OutputPublicationTableTHeadRow row : tHead.getRows()) {
			jsonGenerator.writeStartArray();
			for(OutputPublicationTextCell textCell : row.getCells()) {
				jsonGenerator.writeStartObject();
				if(textCell.getCellText() != null) {
					jsonGenerator.writeStringField("Label", textCell.getCellText());
				}
				jsonGenerator.writeNumberField("Colspan", textCell.getColSpan());
				jsonGenerator.writeNumberField("Rowspan", textCell.getRowSpan());
				writeStyles(textCell, jsonGenerator);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
		jsonGenerator.writeEndArray();
	}
	
	private void writeTBody(OutputPublicationTableTBody tBody, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeArrayFieldStart("TBody");
		
		for(OutputPublicationTableTBodyRow tRow : tBody.getRows()) {
			writeTableRow(tRow, jsonGenerator);
		}
		jsonGenerator.writeEndArray();
	}
	
	/**
	 * {
		"Label":  "Cross-border positions",
		"Level" : 1,
		"Styles": ["h1"],
		"Cells": [
			{
				"Key" : "Q:G:L:T01:A:5J:A:A:B:NI:N",
				"Value" : 29,815
			}  ... object for each cell
		]
	}  ... object for each row
	 */
	private void writeTableRow(OutputPublicationTableTBodyRow tRow, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeStartObject();

		OutputPublicationTextCell textCell = tRow.getRowLabel();
		if(textCell != null) {
			jsonGenerator.writeStringField("Label", textCell.getCellText());
		}

		jsonGenerator.writeNumberField("Level", tRow.getLevel());
		jsonGenerator.writeArrayFieldStart("Cells");
		for(ICellValue cell : tRow.getCells()) {
			jsonGenerator.writeStartObject();
			if(cell != null) {
				if(cell.getCellKey() != null) {
					jsonGenerator.writeStringField("Key", cell.getCellKey());
					if(ObjectUtil.validString(cell.getDataflowAlias())) {
						jsonGenerator.writeStringField("DataflowRef", cell.getDataflowAlias());
					}
				}
				jsonGenerator.writeStringField("Value", cell.getCellValue());
				if(ObjectUtil.validCollection(cell.getFootnotes())) {
					writeFootnotes(cell.getFootnotes(), jsonGenerator);
				}
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}
	
	private void writeStyles(Styleable styleable, JsonGenerator jsonGenerator) throws IOException {
		if(ObjectUtil.validCollection(styleable.getStyles())) {
			jsonGenerator.writeArrayFieldStart("Styles");
			for(String style : styleable.getStyles()) {
				jsonGenerator.writeString(style);
			}
			jsonGenerator.writeEndArray();
		}
	}
	
	private void writeFootnotes(List<String> footnotes, JsonGenerator jsonGenerator) throws IOException {
		jsonGenerator.writeArrayFieldStart("Footnotes");
		for(String footnote : footnotes) {
			jsonGenerator.writeString(footnote);
		}
		jsonGenerator.writeEndArray();
	}
}
