package io.sdmx.publicationtable.engine;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBodyRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHeadRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTextCell;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.xlsx.api.model.FusionCell;
import io.sdmx.utils.xlsx.api.model.IFontStyle.FONT_COLOUR;
import io.sdmx.utils.xlsx.api.model.SheetProperties;
import io.sdmx.utils.xlsx.api.model.SimpleExcelWriter;
import io.sdmx.utils.xlsx.constant.CELL_FORMAT;
import io.sdmx.utils.xlsx.model.CellImpl;
import io.sdmx.utils.xlsx.model.FontStyle;
import io.sdmx.utils.xlsx.model.FusionCellStyle;
import io.sdmx.utils.xlsx.model.SheetPropertiesImpl;
import io.sdmx.utils.xlsx.model.SimpleExcelWriterImpl;
import io.sdmx.utils.xlsx.util.XLSXStyleUtil;

public class ExcelPublicationTableWriter implements OutputTableWriterEngine {
	private static final String TITLE_STYLE = "TITLE_STYLE";
	private static final String SUBTITLE_STYLE = "SUBTITLE_STYLE";
	private static final String BOLD_STYLE = "BOLD_STYLE";
	private static final String FOOTNOTE_STYLE = "FOOTNOTE_STYLE";
	
	
	@Override
	public void writeOutputTable(OutputPublicationTable outputTable, OutputStream out) {
		SimpleExcelWriter writer = new SimpleExcelWriterImpl();
		XLSXStyleUtil.createStyles(writer);
		
		//Header Component
		writer.registerStyle(FusionCellStyle.getInstance(TITLE_STYLE).setFontStyle(new FontStyle(FONT_COLOUR.GREY_80_PERCENT, 14, true)).setWrapText(true));
		writer.registerStyle(FusionCellStyle.getInstance(SUBTITLE_STYLE).setFontStyle(new FontStyle(FONT_COLOUR.GREY_80_PERCENT, 12, false)).setWrapText(true));
		writer.registerStyle(FusionCellStyle.getInstance(BOLD_STYLE).setFontStyle(new FontStyle(FONT_COLOUR.GREY_80_PERCENT, 10, true)));
		writer.registerStyle(FusionCellStyle.getInstance(FOOTNOTE_STYLE).setFontStyle(new FontStyle(FONT_COLOUR.GREY_80_PERCENT, 9, false)).setWrapText(true));
		
		writer.createWorkSheet(getSheetProperties(outputTable));
		writeTable(outputTable, writer);
		writer.save(out);
	}
	
	private void writeTable(OutputPublicationTable table, SimpleExcelWriter writer) {
		int rowIdx = 0;
		CellImpl.getInstance(rowIdx, rowIdx, writer);
		
		writer.writeCell(getTitleCell(table.getTitle(), TITLE_STYLE, rowIdx++));
		if(table.getSubTitle() != null) {
			writer.writeCell(getTitleCell(table.getSubTitle(), SUBTITLE_STYLE, rowIdx++));
		}
		
		rowIdx = writeHead(table.getTHead().getRows(), writer, rowIdx);
		writeBody(table.getTBody().getRows(), writer, rowIdx);
		writeFootnotes(table.getFootnotes(), writer, rowIdx);
	}
	
	private FusionCell getTitleCell(String title, String style, int rowIdx) {
		return (FusionCell) CellImpl.getInstance(2, rowIdx, title).setColspan(15).setWrapText(true).setStyleName(style);
		
	}
	
	private int writeHead(List<OutputPublicationTableTHeadRow> rows, SimpleExcelWriter writer, int rowIdx) {
		int startCol = 1;
	
		//Key is the row in which the range is no longer applicable
		Map<Integer, List<RowRange>> rowRanges = new HashMap<>();  //Used when a row spans multiple rows
		for(OutputPublicationTableTHeadRow headRow : rows) {
			int colIdx = startCol;
			rowRanges.remove(rowIdx); //Any row ranges which are no longer valid
			for(OutputPublicationTextCell headCell : headRow.getCells()) {
				//Does this cell clash with a rowRange
				for(Integer rangeIdx : rowRanges.keySet()) {
					for(RowRange range : rowRanges.get(rangeIdx)) {
						if(range.inRange(colIdx)) {
							colIdx = range.endCol+1;
						}
					}
				}
				
				String text = headCell == null ? "" : headCell.getCellText();
				int rowspan = headCell == null ? 1 : headCell.getRowSpan();
				int colspan = headCell == null ? 1 : headCell.getColSpan();
				if(rowspan > 1) {
					CollectionUtil.addToMappedList(rowRanges, (rowIdx+rowspan), new RowRange(colIdx, (colIdx+colspan-1)));
				}
				String styleName = text == null || text.length() == 0 && colIdx == startCol ? XLSXStyleUtil.OBS_VALUE_STYLE : XLSXStyleUtil.HEAD_BORDER_STYLE;
					
				FusionCell cell = (FusionCell) CellImpl.getInstance(colIdx, rowIdx, text).setColspan(colspan).setRowspan(rowspan).setStyleName(styleName);
				
				writer.writeCell(cell);
				colIdx += colspan;
			}
			rowIdx++;
		}
		return rowIdx;
	}

	private void writeBody(List<OutputPublicationTableTBodyRow> rows, SimpleExcelWriter writer, int rowIdx) {
		for(OutputPublicationTableTBodyRow row : rows) {		
			int colIdx = 1;
			String cellText = row.getRowLabel().getCellText();
			if(row.getLevel() > 1) {
				StringBuilder sb = new StringBuilder();
				for(int i = 1; i < row.getLevel(); i++) {
					sb.append(" ");
				}
				sb.append(cellText);
				cellText = sb.toString();
			}
			writer.writeCell(cellText, colIdx, rowIdx, XLSXStyleUtil.HEAD_COMP_STYLE);
			
			for(ICellValue cell : row.getCells()) {
				colIdx++;
				String text = cell == null || cell.getCellValue() == null ? "" : cell.getCellValue();
				
				//TODO Cell level footnotes - how to show them?
				FusionCell fCell = (FusionCell) CellImpl.getInstance(colIdx, rowIdx, text).setFormat(CELL_FORMAT.AUTO_DETECT).setStyleName(XLSXStyleUtil.OBS_VALUE_STYLE);
				
				writer.writeCell(fCell);
			}
			rowIdx++;
		}
	}
	
	private void writeFootnotes(List<String> footnotes, SimpleExcelWriter writer, int rowIdx) {
		if(!ObjectUtil.validCollection(footnotes)) {
			return;
		}
		rowIdx = rowIdx+4;
		writer.writeCell((FusionCell) CellImpl.getInstance(1, rowIdx, "Footnotes").setStyleName(BOLD_STYLE));	
		
		int fnIdx = 0;
		for(String footnote : footnotes) {
			fnIdx++;
			rowIdx++;
			writer.writeCell((FusionCell) CellImpl.getInstance(1, rowIdx, fnIdx).setFormat(CELL_FORMAT.INTEGER).setStyleName(FOOTNOTE_STYLE));
			writer.writeCell((FusionCell) CellImpl.getInstance(2, rowIdx, footnote).setColspan(26).setWrapText(true).setStyleName(FOOTNOTE_STYLE));
		}
		
	}
	
	private SheetProperties getSheetProperties(OutputPublicationTable table) {
		SheetProperties props = new SheetPropertiesImpl(table.getId());
		props.setAutoScaleWidth(true);
		props.setAutoScleMultiplier(300f);
		props.setAutoScaleMaxWidth(26);
		props.addColumnWidth(0, 500);  //2. Make Column 'A' thin
		props.setFreezePaneColSplit(2);
	
		int freezePane = table.getTHead().getRows().size() + 1; //first row is empty second row is the series key header for each column
		if(table.getSubTitle() != null) {
			freezePane++;
		}
		if(freezePane < 25) {
			props.setFreezePaneRowSplit(freezePane);
		}
		return props;
	}
	
	
	private class RowRange {
		private int startCol;
		private int endCol;
		
		public RowRange(int startCol, int endCol) {
			this.startCol = startCol;
			this.endCol = endCol;
		}
		
		public boolean inRange(int col) {
			return col >= startCol && col <= endCol;
		}
	}
}
