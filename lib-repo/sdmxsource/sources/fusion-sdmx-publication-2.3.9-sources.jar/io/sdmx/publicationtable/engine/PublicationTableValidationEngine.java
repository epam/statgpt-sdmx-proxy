package io.sdmx.publicationtable.engine;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.model.calcuation.Calculator;
import io.sdmx.core.sdmx.api.manager.structure.IStructureParsePostValidationEngine;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.publicationtable.model.data.EmptyPublicationTableCellValueStore;
import io.sdmx.publicationtable.model.output.OutputPublicationTableImpl;
import io.sdmx.publicationtable.model.table.PublicationTableCells;
import io.sdmx.publicationtable.model.variable.ValidationPublicationVariable;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.TimePeriod;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

public class PublicationTableValidationEngine implements IStructureParsePostValidationEngine, IFusionSingleton {
    private static PublicationTableValidationEngine INSTANCE;

	public static PublicationTableValidationEngine registerInstance() {
        if(INSTANCE == null) {
            INSTANCE = new PublicationTableValidationEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }


	@Override
	public SDMX_STRUCTURE_TYPE getStructureType() {
		return SDMX_STRUCTURE_TYPE.PUBLICATION_TABLE_DEF;
	}

	@Override
	public void validateMaintainble(MaintainableBean maint, SdmxBeanRetrievalManager brm) {
		PublicationTableBean publicationTable = (PublicationTableBean)maint;
		
		int flowRefCount = publicationTable.getDataflowReferences().size();
		Map<String, DatasetStructures> structures = new HashMap<>(flowRefCount);
		Set<String> allDimensions = new HashSet<>();
		for(PublicationTableDataflow flowRef : publicationTable.getDataflowReferences()) {
			DatasetStructures dsdStructures = new DatasetStructures(flowRef.getDataflowRef().getReference(), brm);
			
			allDimensions.addAll(dsdStructures.getDataStructure().getDimensionIds());
			structures.put(flowRef.getAlias(), dsdStructures);
		}
		
		ValidationPublicationVariable variables = new ValidationPublicationVariable(publicationTable, brm);
		
		//Try to build the series - if this fails, then the table is in error
		IPublicationTableCells tableSeries = new PublicationTableCells(publicationTable, variables);
		
		validateVariableMapping(publicationTable, tableSeries, brm);
		
		variables.setCellValueStore(EmptyPublicationTableCellValueStore.getInstance());
		OutputPublicationTable outputTable = new OutputPublicationTableImpl(publicationTable, variables, null);

		validateBasePeriod(variables);
		validateVariables(publicationTable, variables, structures, allDimensions);
		validateCalculatedCells(publicationTable, tableSeries);
	}
	
	private void validateVariableMapping(PublicationTableBean publicationTable, IPublicationTableCells tableSeries, SdmxBeanRetrievalManager brm) {
		if(!publicationTable.getVariableMapping().isEmpty()) {
			for(PublicationTableVariableMappingBean variableMapping : publicationTable.getVariableMapping()) {
				if(!isMissingDimension(publicationTable, tableSeries, variableMapping.getInputDimensionId())) {
					throw new SdmxSemmanticException("Publication Table references a representation map for a dimension which is not a variable Dimension in the table cells: "+variableMapping.getInputDimensionId());
				}
				IRepresentationMapBean repMap = brm.getBean(variableMapping.getMappingRules().getReference());
				if(repMap != null && repMap.getTargetRef().size() != variableMapping.getOutputDimensionId().size()) {
					throw new SdmxSemmanticException("Publication Table references a representation map '"+variableMapping.getMappingRules().getTargetUrn().split("=")[1]+"' which has a different number of outputs");
				}
			}
		}
	}
	
	/**
	 * @param dimId
	 * @return true if the dimension is a variable in at least one of the Observation Keys
	 */
	private boolean isMissingDimension(PublicationTableBean publicationTable, IPublicationTableCells tableSeries, String dimId) {
		for(PublicationTableDataflow flowRef : publicationTable.getDataflowReferences()) {
			Set<String> missingDimensions = tableSeries.getMissingDimensions(flowRef.getAlias());
			if(missingDimensions != null && missingDimensions.contains(dimId)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Ensure that if there is a time dimension, at least 1 cell is defining a base period (not a cast)
	 */
	private void validateBasePeriod(ValidationPublicationVariable variables) {
		//If there is a time dimension, and all time periods are cast, then there is an error
		if(variables.hasTimeDimension() && variables.getTimePeriod().hasCastPeriod() && !variables.getTimePeriod().hasBasePeriod()) {
			throw new SdmxSemmanticException("Publication Table requires at least 1 body cell with a base period 'P'");
		}
	}
	
	/**
	 * Ensure variables resolve to a dataflow, external variable, conditional variable, component, or footnote, 
	 */
	private void validateVariables(PublicationTableBean publicationTable, ValidationPublicationVariable variables, Map<String, DatasetStructures> structures, Set<String> allDimensions) {
		for(String dim : variables.getDimensions()) {
			if(!allDimensions.contains(dim)) {
				throw new SdmxSemmanticException("Variable '"+dim+"' does not resolve to a Dimension");
			}
		}
		
		Set<String> conditionalVariables = publicationTable.getConditionalVariables().stream().map(e->e.getId()).collect(Collectors.toSet());
		for(String conditionalVariableId : variables.getConditionalVaraibles().keySet()) {
			if(!conditionalVariables.contains(conditionalVariableId)) {
				throw new SdmxSemmanticException("Conditional Variable '"+conditionalVariableId+"' does not exist in Publication Table definition");
			}
		}
		Set<String> allComponentIds = new HashSet<>();
		for(String alias : structures.keySet()) {
			DataStructureBean dsd = structures.get(alias).getDataStructure();
			if(dsd != null) {
				allComponentIds.addAll(SdmxCollectionUtil.identifiablesIds(dsd.getComponents()));
			}
		}
		for(String dotVariableId : variables.getDotVariables().keySet()) {
			//Is it the dataflow
			DataflowBean flow = variables.getDataflow(dotVariableId);
			if(flow != null) {
				Set<String> values = variables.getDotVariables().get(dotVariableId);
				for(String val : values) {
					switch(val) {
					case "id":
					case "desc":
					case "name":
					case "version":
						break;
						default : throw new SdmxSemmanticException("Unexpected Dataflow variable '"+dotVariableId+"."+val+"' postfix '"+val+"' is not supported.  Valid postfixes are: name, desc, id, or version");
					}
				}
			} else if(!allComponentIds.contains(dotVariableId)){
				//It is not a component ID
				throw new SdmxSemmanticException("Variable starting with '"+dotVariableId+".' does not resolve to a Dataflow or Component in the table");
			}
		}
		for(String variableId : variables.getVariables()) {
			DataflowBean flow = variables.getDataflow(variableId);
			if(flow == null && !allComponentIds.contains(variableId) && !TimePeriod.isExpresion(variableId)) {
				throw new SdmxSemmanticException("Variable '"+variableId+"' does not resolve to a Dataflow Alias, Component Id, or valid Time Expression");
			}
		}
		for(Integer footnote : variables.getFootnoteReferences()) {
			if(publicationTable.getFootnotes().size() < footnote) {
				throw new SdmxSemmanticException("Footnote #"+footnote+"  does not exist.  Only '"+publicationTable.getFootnotes().size()+"' defined in Publication Table");
			}
		}
	}
	
	
	/**
	 * Ensures calculation syntax is parseable
	 * @param publicationTable
	 * @param tableSeries
	 */
	private void validateCalculatedCells(PublicationTableBean publicationTable, IPublicationTableCells tableSeries) {
		Calculator calculator = new Calculator();
		for(PublicationTableBodyRow row : publicationTable.getBodyRows()) {
			for(PublicationTableBodyCell bodyCell : row.getTableCells()) {
				try {
					ICellCalculation calc = tableSeries.getCalculationKey(bodyCell);
					validateCalculatedCells(calc, calculator);
				} catch(ArithmeticException th) {
					//Ignore, we were probably just unlucky enough to hit division by zero
				}  catch(Throwable th) {
					throw new SdmxSemmanticException(th, "Illegal calculation expression "+bodyCell.getObservationKey());
				}
			}
		}
	}
	
	private void validateCalculatedCells(ICellCalculation calculation, Calculator calculator) {
		if(calculation == null) {
			return;
		}
		//Example $(1) - $(2)
		String expression = calculation.getCalculation();
		
		//Replace variables, $n with a number
		int varIdx = 0;
		for(ISeriesCalculation seriesCalc : calculation.getSeriesCalculations()) {
			testCalculation(seriesCalc, calculator);
			
			//an increasing decimal, 1.1, 1.2, 1.3 to try to avoid division by zero
			expression = expression.replace("${"+varIdx+"}", "1."+varIdx);
			varIdx++;
		}
		calculator.execute(expression);
	}
	
	private void testCalculation(ISeriesCalculation calc, Calculator calculator) {
		if(!calc.hasCalculatedDimension()) {
			return;
		} 
		String expression = calc.getCalculationExpression();
		Map<String, ICellKey> var2ObsKey = calc.getVariableToCell();
		int varIdx = 0;
		for(String variable : var2ObsKey.keySet()) {
			Double obsValue = Double.parseDouble("1."+varIdx);  //an increasing decimal, 1.1, 1.2, 1.3 to try to avoid division by zero
			expression = expression.replaceAll("\\{"+variable+"\\}", obsValue.toString());
			varIdx++;
		}
		calculator.execute(expression);
	}

}
