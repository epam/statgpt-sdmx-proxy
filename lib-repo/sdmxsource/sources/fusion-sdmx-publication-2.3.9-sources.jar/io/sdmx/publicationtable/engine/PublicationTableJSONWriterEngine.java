package io.sdmx.publicationtable.engine;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonStaticHelper;
import io.sdmx.format.json.engine.structure.writer.RegistryJsonMaintainableStructureWriterEngine;
import io.sdmx.format.json.engine.structure.writer.fusion.FusionJsonMaintainableStructureWriterEngineImpl;
import io.sdmx.format.json.engine.structure.writer.fusion.FusionJsonStructureWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonWriterUtil;

/**
 * Maintainable written out in JSON format, example
 *
 * {
	//All the usual maintainable stuff
	"dataflowRefs": [
		{
			"alias": "DISS",
			"urn": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=BIS:BIS_LBS_DISS(1.0)"
		}
	],
	"formatting": {


	},
	"css" : [ "urn1", "urn2" ],
	"footer": "<sup>1</sup> Data are incomplete. See Table A2 for a list of countries that report non-bank subsectors.",
	"tHead": [
		{
			"cells": [
				{
					"label": "$(TIMENAV)",
					"rowSpan": 2,
					"styles": [
						"timenav",
						"first"
					]
				},
			]
		},
	],
	"tBody": [
		{
			"heading": {
				"label": "Cross-border positions"
			},
			"level": 1,
			"cells": ["DISS.Q::C:A:TO1:A:5J:A:5A:A:5J:N"]
		},
	]
}
 *
 *
 *
 */
public class PublicationTableJSONWriterEngine extends FusionJsonMaintainableStructureWriterEngineImpl<PublicationTableBean> implements RegistryJsonMaintainableStructureWriterEngine<PublicationTableBean>, IFusionSingleton {
	private static PublicationTableJSONWriterEngine INSTANCE;
	static {
		FusionJsonStructureWriterEngine.getInstance();
	}

	public static PublicationTableJSONWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new PublicationTableJSONWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	private PublicationTableJSONWriterEngine() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_TABLE_DEF);
	}

	@Override
	protected void writeStructureInternal(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, PublicationTableBean tableDef) throws JsonGenerationException, IOException {
		writeDataflowReferences(jsonGenerator, tableDef.getDataflowReferences());
		writeTimeFormatMapping(jsonGenerator, tableDef);
		writeMissingValueFormatting(jsonGenerator, tableDef);
		writeObsFormatting(jsonGenerator, tableDef);
		writePublicationTableVariables(jsonGenerator, externalLinks, tableDef);
		writeConditionalVariables(jsonGenerator, tableDef.getConditionalVariables());
		writeDependentVariables(jsonGenerator, tableDef);
		writePublicationTableHeadRows(jsonGenerator, tableDef.getHeaderRows());
		writePublicationTableBodyRows(jsonGenerator, tableDef.getBodyRows());
		writeFootNotes(jsonGenerator, tableDef.getFootnotes());
	}

	private void writeTimeFormatMapping(JsonGenerator jsonGenerator, PublicationTableBean table) throws IOException {
		if(table.getTimeFormatMapping() != null) {
			jsonGenerator.writeStringField("freqFormatMapping", table.getTimeFormatMapping().getTargetUrn());
		}
	}


	private void writeObsFormatting(JsonGenerator jsonGenerator, PublicationTableBean table) throws IOException {
		if(ObjectUtil.validCollection(table.getObservationFormatting())) {
			jsonGenerator.writeObjectFieldStart("formatting");
			jsonGenerator.writeArrayFieldStart("obs");

			for(IObservationFormatting obsFormatting : table.getObservationFormatting()) {
				jsonGenerator.writeStartObject();
				if(obsFormatting.getPrecision() >=0) {
					jsonGenerator.writeStringField("roundingMode", obsFormatting.getRoundingMode().toString());
					jsonGenerator.writeNumberField("precision", obsFormatting.getPrecision());
				}
				if(obsFormatting.isNormalise()) {
					jsonGenerator.writeBooleanField("normalise", obsFormatting.isNormalise());
				}
				if(obsFormatting.isPrecisionDP()) {
					jsonGenerator.writeBooleanField("decimalPlaces", obsFormatting.isPrecisionDP());
				}
				if(obsFormatting.isScientificNotation()) {
					jsonGenerator.writeBooleanField("scientificNotation", obsFormatting.isScientificNotation());
				}
				
				if(obsFormatting.getScalingFactor() != null) {
					jsonGenerator.writeNumberField("scalingFactor", obsFormatting.getScalingFactor());
				}
				if(obsFormatting.getLocale() != null) {
					String locale = obsFormatting.getLocale().equals(Locale.ROOT) ? "dynamic" : obsFormatting.getLocale().getLanguage();
					jsonGenerator.writeStringField("locale", locale);
				}
				if(ObjectUtil.validCollection(obsFormatting.getKeyMatch())) {
					JsonWriterUtil.writeStringArray(jsonGenerator, "keys",  obsFormatting.getKeyMatch());
				}
				jsonGenerator.writeEndObject();
			}

			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
	}

	private void writeMissingValueFormatting(JsonGenerator jsonGenerator, PublicationTableBean table) throws IOException {
		if(table.getMissingValueRules() != null) {
			jsonGenerator.writeObjectFieldStart("missingValues");
			PublicationTableMVBean mvBean = table.getMissingValueRules();
			if(mvBean.getDefaultMissingValue() != null) {
				jsonGenerator.writeStringField("mvDefault", mvBean.getDefaultMissingValue());
			}
			if(mvBean.getMissingValueMapping() != null) {
				jsonGenerator.writeStringField("mvMap", mvBean.getMissingValueMapping().getTargetUrn());
				jsonGenerator.writeStringField("mvComponent", mvBean.getComponentId());
			}
			jsonGenerator.writeEndObject();
		}
	}

	private void writeDataflowReferences(JsonGenerator jsonGenerator, Collection<PublicationTableDataflow> flowRefs) throws IOException {
		jsonGenerator.writeArrayFieldStart("dataflowRefs");
		for(PublicationTableDataflow flowRef : flowRefs) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeStringField("alias", flowRef.getAlias());
			jsonGenerator.writeStringField("urn", flowRef.getDataflowRef().getTargetUrn());
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writePublicationTableVariables(JsonGenerator jsonGenerator, IExternalMaintainableLinks externalLinks, PublicationTableBean tableDef) throws IOException {
		jsonGenerator.writeArrayFieldStart("variables");
		for(PublicationVariableBean variable : tableDef.getVariables()) {
			jsonGenerator.writeStartObject();
			FusionJsonStaticHelper.writeIdentifiable(jsonGenerator, externalLinks, variable);
			jsonGenerator.writeStringField("codelistRef", variable.getCodelistReference().getTargetUrn());
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeDependentVariables(JsonGenerator jsonGenerator, PublicationTableBean tableDef) throws IOException {
		if(tableDef.getVariableMapping().size() > 0) {
			jsonGenerator.writeArrayFieldStart("dependentVariables");
			for(PublicationTableVariableMappingBean variable : tableDef.getVariableMapping()) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField("inputDimension", variable.getInputDimensionId());
				JsonWriterUtil.writeStringArray(jsonGenerator, "outputDimensions", variable.getOutputDimensionId());
				jsonGenerator.writeStringField("representationMap", variable.getMappingRules().getTargetUrn());
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
	}

	private void writePublicationTableHeadRows(JsonGenerator jsonGenerator, List<PublicationTableHeadRow> headerRows) throws IOException {
		jsonGenerator.writeArrayFieldStart("tHead");
		for(PublicationTableHeadRow headRow : headerRows) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeArrayFieldStart("cells");
			for(PublicationTableHeadCell headCell : headRow.getHeaderCells()) {
				jsonGenerator.writeStartObject();
				writeHeadCell(jsonGenerator, headCell);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
	}

	private void writeHeadCell(JsonGenerator jsonGenerator, PublicationTableHeadCell headCell) throws IOException {
		String label = headCell.getLabel();
		jsonGenerator.writeStringField("label", label);
		if(headCell.getRowSpan() > 1) {
			jsonGenerator.writeNumberField("rowSpan", headCell.getRowSpan());
		}
		if(headCell.getColSpan() > 1) {
			jsonGenerator.writeNumberField("colSpan", headCell.getColSpan());
		}
	}

	private void writePublicationTableBodyRows(JsonGenerator jsonGenerator, List<PublicationTableBodyRow> bodyRows) throws IOException {
		jsonGenerator.writeArrayFieldStart("tBody");
		for(PublicationTableBodyRow row : bodyRows) {
			writePublicationTableBodyRow(jsonGenerator, row);
		}
		jsonGenerator.writeEndArray();
	}

	private void writePublicationTableBodyRow(JsonGenerator jsonGenerator, PublicationTableBodyRow row) throws IOException {
		jsonGenerator.writeStartObject();

		jsonGenerator.writeObjectFieldStart("heading");
		writeHeadCell(jsonGenerator, row.getHeadCell());
		jsonGenerator.writeEndObject();

		jsonGenerator.writeNumberField("level", row.getLevel());
		jsonGenerator.writeArrayFieldStart("cells");
		for(PublicationTableBodyCell bodyCell : row.getTableCells()) {
			jsonGenerator.writeStartObject();
			if(bodyCell.getObservationKey() != null) {
				StringBuilder obsKey = new StringBuilder();
				String cellObsKey = bodyCell.getObservationKey();
				obsKey.append(cellObsKey);
				jsonGenerator.writeStringField("key", obsKey.toString());
			}
			jsonGenerator.writeEndObject();
		}
		jsonGenerator.writeEndArray();
		jsonGenerator.writeEndObject();
	}

	/**
	 * Writes the following JSON
	 *
	 * conditionalVariables : [{
	 *   	"Id": "Currency ",
	 *   	"Name" : "Currency to Banknotes",
	 *   	"DimensionId" : "REF_AREA",
	 *   	"Maps" {
	 *   		"UK" : {
	 *   			"Note1" : "5 Pounds",
	 *   			"Note2" : "10 Pounds",
	 *   			"Note3" : "20 Pounds",
	 *   		},
	 *   		"US" : [
	 *   			"Note1" : "5 Pounds",
	 *   			"Note2" : "10 Pounds",
	 *   			"Note3" : "20 Pounds",
	 *   		]
	 *   	}
	 *   }
	 * ]
	 *
	 *
	 * @param jsonGenerator
	 * @param conditionalVaraibles
	 * @throws IOException
	 */
	private void writeConditionalVariables(JsonGenerator jsonGenerator, List<ConditionalVariable> conditionalVaraibles) throws IOException {
		if(ObjectUtil.validCollection(conditionalVaraibles)) {
			jsonGenerator.writeArrayFieldStart("conditionalVariables");

			for(ConditionalVariable condition : conditionalVaraibles) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField("Id", condition.getId());
				jsonGenerator.writeStringField("Name", condition.getName());

				String dimId = condition.getDimensionCondition();
				if(ObjectUtil.validString(condition.getDataflowAlias())) {
					dimId = condition.getDataflowAlias()+"."+dimId;
				}
				jsonGenerator.writeStringField("DimensionId", dimId);

				jsonGenerator.writeObjectFieldStart("Maps");
				for(ConditionalVariableValues variableValues : condition.getConditionalVariableValues()) {
					String dimCodeId = variableValues.getMappedId();
					jsonGenerator.writeObjectFieldStart(dimCodeId);
					for(String sourceId : variableValues.getSourceIds()) {
						jsonGenerator.writeStringField(sourceId, variableValues.getMappedValue(sourceId));
					}
					jsonGenerator.writeEndObject();
				}
				jsonGenerator.writeEndObject();
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
	}

	/**
	 * footnotes [
	 * 	{
	 *    en : footnote1,
	 *    fr : le footnote un
	 *  }...
	 * ]
	 * @param jsonGenerator
	 * @param footnotes
	 * @throws IOException
	 */
	private void writeFootNotes(JsonGenerator jsonGenerator, List<TextTypeBean> footnotes) throws IOException {
		if(ObjectUtil.validCollection(footnotes)) {
			jsonGenerator.writeArrayFieldStart("footnotes");
			for(TextTypeBean currentFootnote : footnotes) {
				jsonGenerator.writeStartObject();
				for(TextTypeWrapper tt : currentFootnote.getText()) {
					jsonGenerator.writeStringField(tt.getLocale(), tt.getValue());
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
		}
	}
}
