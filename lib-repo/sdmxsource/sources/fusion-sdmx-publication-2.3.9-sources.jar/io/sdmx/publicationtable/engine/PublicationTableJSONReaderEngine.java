package io.sdmx.publicationtable.engine;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.data.model.formatting.ObservationFormatting;
import io.sdmx.format.json.engine.structure.reader.fusion.FusionJsonMaintainableBeanReaderEngineImpl;
import io.sdmx.format.json.engine.structure.reader.util.FusionJsonIdentifiableUtil;
import io.sdmx.format.json.manager.FusionJsonStructureReaderManager;
import io.sdmx.im.mutable.base.TextTypeMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableDataflowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableVariableMappingMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationVariableMutableBean;
import io.sdmx.publicationtable.model.bean.mutable.ConditionalVariableMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.ConditionalVariableValuesMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableBodyCellMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableBodyRowMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableDataflowMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableHeadCellMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableHeadRowMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableMutableBeanImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableVariableMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class PublicationTableJSONReaderEngine extends FusionJsonMaintainableBeanReaderEngineImpl<PublicationTableBean, PublicationTableMutableBean> implements IFusionSingleton {
	private static PublicationTableJSONReaderEngine INSTANCE;

	static {
		FusionJsonStructureReaderManager.getInstance();
	}

	public static PublicationTableJSONReaderEngine registerInstance() {
		if(INSTANCE == null) {
			INSTANCE = new PublicationTableJSONReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
    protected Class<PublicationTableBean> getMaintainableType() {
        return PublicationTableBean.class;
    }
	
	@Override
	protected PublicationTableMutableBean getMutable() {
		return new PublicationTableMutableBeanImpl();
	}

	@Override
	protected boolean processMaintainableProperty(String fieldName, PublicationTableMutableBean mutable, JsonReader jReader) {
		switch(fieldName) {
		case "footnotes" :
			processFootnotes(jReader, mutable);
			break;
		case "dataflowRefs":
			processDataflowRefs(jReader, mutable);
			break;
		case "conditionalVariables" :
			processConditionalVariables(jReader, mutable);
			break;
		case "freqFormatMapping" :
			String urn = jReader.getValueAsString();
			if(ObjectUtil.validString(urn)) {
				mutable.setTimeFormatMapping(new StructureReferenceBeanImpl(urn));
			}
			break;
		case "variables":
			processVariables(jReader, mutable);
			break;
		case "formatting":
			processFormatting(jReader, mutable);
			break;
		case "dependentVariables":
			processVariableMappings(jReader, mutable);
			break;
		case "tHead" :
			processTHead(jReader, mutable);
			break;
		case "tBody":
			processTBody(jReader, mutable);
			break;
		case "missingValues":
			processMissingValues(jReader, mutable);
			break;
		default : return false;
		}
		return true;
	}

	private void processDataflowRefs(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if (jReader.isStartObject()) {
				processDataflowRef(jReader, mutable);
			}
		}
	}

	private void processDataflowRef(JsonReader jReader, PublicationTableMutableBean mutable) {
		PublicationTableDataflowMutable dfRef = new PublicationTableDataflowMutableImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				mutable.addDataflowReference(dfRef);
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("alias")) {
				dfRef.setAlias(jReader.getValueAsString());
			} else if (fieldName.equals("urn")) {
				dfRef.setDataflowRef(new StructureReferenceBeanImpl(jReader.getValueAsString()));
			}
		}
	}

	private void processMissingValues(JsonReader jReader, PublicationTableMutableBean mutable) {
		String mvMap = null;
		String mvComponent = null;
		String defaultMV = null;
		
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			String fieldValue = jReader.getValueAsString();
			switch(fieldName) {
			case "mvMap" :
				mvMap = fieldValue;
				break;
			case "mvComponent" :
				mvComponent = fieldValue;
				break;
			case "mvDefault" :
				defaultMV = fieldValue;
				break;
			}
		}
		if(ObjectUtil.validOneString(mvMap, mvComponent, defaultMV)) {
			StructureReferenceBean mvMapRef = mvMap != null ? new StructureReferenceBeanImpl(mvMap) : null;
			mutable.addMissingValueRules().setDefaultMissingValue(defaultMV).setComponentId(mvComponent).setMissingValueMapping(mvMapRef);
		}
	}


	private void processFormatting(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "obs" :
				List<IObservationFormatting> obsFormatting = processObsFormattingRules(jReader, mutable);
				mutable.setObservationFormatting(obsFormatting);
			break;
			}
		}
	}
	
	private List<IObservationFormatting> processObsFormattingRules(JsonReader jReader, PublicationTableMutableBean mutable) {
		List<IObservationFormatting> formatting = new ArrayList<>();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				break;
			}
			if (jReader.isStartObject()) {
				formatting.add(processObsFormatting(jReader, mutable));
			}
		}
		return formatting;
	}
	
	private IObservationFormatting processObsFormatting(JsonReader jReader, PublicationTableMutableBean mutable) {
		int precision = -1;
		boolean decimalPlaces = false;
		boolean scientific = false;
		boolean normalise = false;
		RoundingMode roundingMode = null;
		Locale locale = null;
		List<String> keys = null;
		Integer scalingFactor = null;
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				break;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "precision" :
				precision = jReader.getValueAsInt();
			break;
			case "scalingFactor" :
				scalingFactor = jReader.getValueAsInt();
			break;
			case "decimalPlaces" :
				decimalPlaces = jReader.getValueAsBoolean();
			break;
			case "scientificNotation" :
				scientific = jReader.getValueAsBoolean();
			break;
			case "normalise" :
				normalise = jReader.getValueAsBoolean();
			break;
			case "roundingMode" :
				roundingMode = RoundingMode.valueOf(jReader.getValueAsString());
			break;
			case "locale" :
				String val = jReader.getValueAsString();
				locale = val.equals("dynamic") ? Locale.ROOT : Locale.forLanguageTag(val);
			break;
			case "keys" :
				keys = jReader.readStringArray();
			break;
			}
		}
		return new ObservationFormatting(keys, locale, precision, scalingFactor, decimalPlaces, scientific, normalise, roundingMode);
	}
	
	private void processVariables(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if(jReader.isStartObject()) {
				processVariable(jReader, mutable);
			}
		}
	}

	private void processVariable(JsonReader jReader, PublicationTableMutableBean mutable) {
		PublicationVariableMutableBean variable = new PublicationTableVariableMutableBeanImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				mutable.addVariableReference(variable);
				return;
			}
			if(!FusionJsonIdentifiableUtil.processBean(variable, jReader)) {
				String fieldName = jReader.getCurrentFieldName();
				if(fieldName.equals("codelistRef")) {
					variable.setCodelistReference(StructureReferenceBeanImpl.buildAndVerify(jReader.getValueAsString(), SDMX_STRUCTURE_TYPE.CODE_LIST, SDMX_STRUCTURE_TYPE.VALUE_LIST));
				}
			}
		}
	}
	
	
	private void processVariableMappings(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if(jReader.isStartObject()) {
				processVariableMapping(jReader, mutable);
			}
		}
	}

	private void processVariableMapping(JsonReader jReader, PublicationTableMutableBean mutable) {
		PublicationTableVariableMappingMutableBean variable = mutable.addVariableMapping();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "inputDimension" :
				variable.setInputDimensionId(jReader.getValueAsString());
				break;
			case "outputDimensions" :
				variable.setOutputDimensions(jReader.readStringArray());
				break;
			case "representationMap" :
				variable.setMappingRules(new StructureReferenceBeanImpl(jReader.getValueAsString()));
				break;
			}
		}
	}

	/**
	 * Reads the following JSON
	 * conditionalVariables : [{
	 *   	"Id": "Currency ",
	 *   	"DimensionId" : "REF_AREA",
	 *   	"Maps" {
	 *   		"UK" : [
	 *   			{"Note1" : "5 Pounds"},
	 *   			{"Note2" : "10 Pounds"},
	 *   			{"Note3" : "20 Pounds"},
	 *   		],
	 *   		"US" : [
	 *   			{"Note1" : "5 Dollars"},
	 *   			{"Note2" : "10 Dollars"},
	 *   			{"Note3" : "20 Dollars"},
	 *   		]
	 *   	}
	 *   }
	 * ]
	 * @param jReader
	 * @param mutable
	 */
	private void processConditionalVariables(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if(jReader.isStartObject()) {
				ConditionalVariableMutable conditionalVariableMutable = new ConditionalVariableMutableImpl();
				mutable.addConditionalVariable(conditionalVariableMutable);
				processConditionalVariable(jReader, conditionalVariableMutable);
			}
		}
	}

	/**
	 * Reads the following JSON
	 *	"Id": "Currency ",
	 *  "Name" : "Currency to Banknotes",
	 *  "DimensionId" : "REF_AREA",
	 *  "Maps" {
	 *  	"UK" : [
	 *  		{"Note1" : "5 Pounds"},
	 *   		{"Note2" : "10 Pounds"},
	 *   		{"Note3" : "20 Pounds"},
	 *   	],
	 *   	"US" : [
	 *   		{"Note1" : "5 Dollars"},
	 *   		{"Note2" : "10 Dollars"},
	 *   		{"Note3" : "20 Dollars"},
	 *   	]
	 *   }
	 * @param jReader
	 * @param mutable
	 */
	private void processConditionalVariable(JsonReader jReader, ConditionalVariableMutable mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			switch(fieldName) {
			case "Id" : mutable.setId(jReader.getValueAsString());
			break;
			case "Name" : mutable.setName(jReader.getValueAsString());
			break;
			case "DimensionId" :
				String dimId = jReader.getValueAsString();
				String alias = "";
				String[] split = dimId.split("\\.", 2);
				if(split.length > 1) {
					alias = split[0];
					dimId = split[1];
				}
				mutable.setDimensionCondition(dimId);
				mutable.setFlowAlias(alias);
				break;
			case "Maps" : processConditionalMaps(jReader, mutable);
			break;
			}
		}
	}

	/**
	 * Reads the following JSON
	 *  "Maps" {
	 *  	"UK" : {
	 *  		"Note1" : "5 Pounds",
	 *   		"Note2" : "10 Pounds",
	 *   		"Note3" : "20 Pounds",
	 *   	},
	 *   	"US" : {
	 *   		"Note1" : "5 Dollars",
	 *   		"Note2" : "10 Dollars",
	 *   		"Note3" : "20 Dollars",
	 *   	}
	 *   }
	 * @param jReader
	 * @param mutable
	 */
	private void processConditionalMaps(JsonReader jReader, ConditionalVariableMutable mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			if(jReader.isStartObject()) {
				String fieldName = jReader.getCurrentFieldName();
				ConditionalVariableValuesMutable values = new ConditionalVariableValuesMutableImpl();
				values.setMappedId(fieldName);
				mutable.addConditionalVariableValues(values);
				processConditionalMap(jReader, values);
			}
		}
	}

	/**
	 * Reads the following JSON
	 *
	 *   	{"Note1" : "5 Pounds"},
	 *   	{"Note2" : "10 Pounds"},
	 *   	{"Note3" : "20 Pounds"},
	 *   ,
	 * @param jReader
	 * @param mutable
	 */
	private void processConditionalMap(JsonReader jReader, ConditionalVariableValuesMutable mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			//if (jReader.isStartObject()) {
			String sourceId = jReader.getCurrentFieldName();
			String targetId = jReader.getValueAsString();
			mutable.addMappedValue(sourceId, targetId);
			//	jReader.moveNext();
			//}
		}
	}

	private void processTHead(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			if(fieldName.equals("cells")) {
				processTHeadRow(jReader, mutable);
			}
		}
	}

	private void processTHeadRow(JsonReader jReader, PublicationTableMutableBean mutable) {
		PublicationTableHeadRowMutable row = new PublicationTableHeadRowMutableImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				mutable.addHeaderRow(row);
				return;
			}
			if (jReader.isStartObject()) {
				row.addHeaderCell(processTHeadCell(jReader));
			}
		}
	}

	private PublicationTableHeadCellMutable processTHeadCell(JsonReader jReader) {
		PublicationTableHeadCellMutable cell = new PublicationTableHeadCellMutableImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return cell;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("label")) {
				cell.setLabel(jReader.getValueAsString());
			} else if (fieldName.equals("rowSpan")) {
				cell.setRowSpan(jReader.getValueAsInt());
			} else if (fieldName.equals("colSpan")) {
				cell.setColSpan(jReader.getValueAsInt());
			}
		}
		return null;
	}

	private void processTBody(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if (jReader.isStartObject()) {
				processTBodyRow(jReader, mutable);
			}
		}
	}

	private void processTBodyRow(JsonReader jReader, PublicationTableMutableBean mutable) {
		PublicationTableBodyRowMutable row = new PublicationTableBodyRowMutableImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				mutable.addBodyRow(row);
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("heading")) {
				row.setHeadCell(processTHeadCell(jReader));
			} else if (fieldName.equals("cells")) {
				processTBodyCells(jReader, row);
			}
		}
	}

	private void processTBodyCells(JsonReader jReader, PublicationTableBodyRowMutable mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if (jReader.isStartObject()) {
				processTBodyCell(jReader, mutable);
			}
		}
	}

	private void processTBodyCell(JsonReader jReader, PublicationTableBodyRowMutable mutable) {
		PublicationTableBodyCellMutable cell = new PublicationTableBodyCellMutableImpl();
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				mutable.addTableCell(cell);
				return;
			}
			String fieldName = jReader.getCurrentFieldName();
			if (fieldName.equals("key")) {
				cell.setObservationKey(jReader.getValueAsString());
			}
		}
	}



	private void processFootnotes(JsonReader jReader, PublicationTableMutableBean mutable) {
		while (jReader.moveNext()) {
			if (jReader.isEndArray()) {
				return;
			}
			if (jReader.isStartObject()) {
				processFootnote(jReader, mutable);
			}
		}
	}

	/**
	 * footnotes [
	 * 	{
	 *    en : footnote1,
	 *    fr : le footnote un
	 *  }...
	 * ]
	 **/
	private void processFootnote(JsonReader jReader, PublicationTableMutableBean mutable) {
		TextTypeMutableBean footnote = new TextTypeMutableBeanImpl();
		mutable.addFootnote(footnote);
		while (jReader.moveNext()) {
			if (jReader.isEndObject()) {
				return;
			}
			String locale = jReader.getCurrentFieldName();
			String value = jReader.getValueAsString();
			footnote.addText(new TextTypeWrapperMutableBeanImpl(locale, value));
		}
	}
}