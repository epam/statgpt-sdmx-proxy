package io.sdmx.publicationtable.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.writer.PeriodInfoDataWriterEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableAvailabilityRetreivalEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableCellBuilderEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableLoopProcessorEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableVariablesBuilderEngine;
import io.sdmx.publicationtable.api.model.availability.IPublicationTableAvailableData;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.table.PublicationTableCells;
import io.sdmx.publicationtable.model.variable.PublicationVariablesProxy;
import io.sdmx.publicationtable.util.PublicationTableUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.comparator.SeriesComparator;

public class PublicationTableCellBuilderEngine implements IPublicationTableCellBuilderEngine {

	private IPublicationTableVariablesBuilderEngine publicationTableVariablesBuilderEngine;
	private IPublicationTableLoopProcessorEngine loopProcessorEngine;
	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;
	private IPublicationTableAvailabilityRetreivalEngine availabilityRetreivalEngine;


	public PublicationTableCellBuilderEngine(IPublicationTableVariablesBuilderEngine publicationTableBuilderEngine,
			IPublicationTableLoopProcessorEngine loopProcessorEngine,
			SdmxDataRetrievalWithWriter dataRetrievalWithWriter,
			IPublicationTableAvailabilityRetreivalEngine availabilityRetreivalEngine) {
		this.publicationTableVariablesBuilderEngine = publicationTableBuilderEngine;
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
		this.loopProcessorEngine = loopProcessorEngine;
		this.availabilityRetreivalEngine = availabilityRetreivalEngine;
	}

	@Override
	public IPublicationTableCells build(PublicationTableBean publicationTable, Map<String, String> dimensionVariables) {
		if(dimensionVariables == null) {
			dimensionVariables = Collections.emptyMap();
		}

		List<String> allAlias = publicationTable.getDataflowReferences().stream().map(e->e.getAlias()).collect(Collectors.toList());
		IPublicationTableCells tableSeries = getPublicationTableCells(publicationTable, dimensionVariables, allAlias);
		boolean missingForAllFlows  = hasMissingDimensionValuesForAll(tableSeries, allAlias);
		if(missingForAllFlows) {
			throw new SdmxNoResultsException("No Data for Table");
		}
		return loopProcessorEngine.processLoops(tableSeries);
	}
	
	private boolean hasMissingDimensionValuesForAll(IPublicationTableCells tableSeries, List<String> allAlias) {
		for(String alias : allAlias) {
			Set<String> missingDims = tableSeries.getMissingDimensions(alias); 
			if(!ObjectUtil.validCollection(missingDims)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Builds the response by determining if any Dataflow inputs have missing (variable) dimension values for which a variable value was not supplied.  If this is 
	 * the case the system will determine which default values to use.  This is achieved by:
	 * 
	 * 1. Ordering the Dataflows by alias to ensure there is a consistent order and to ensure that the default dataflow is checked first
	 * 2. Creating a map of variable Dimension ID to the Dataflows which use the Dimension
	 * 3. Asking which missing Dimensions exist for the current Dataflow (default Dataflow is first) 
	 * 4. Determining what values to use as a default for the missing Dimenisons for the current flow (based on the data that exists)
	 * 5. Adding these values into the Variables (same as if they were passed in on the request) 
	 * 6. Asking if any other Dataflows also use any of the Dimensions which were resolved
	 * 7. If the answer to #6 is yes, then this method is called again (recursive) to rebuild and restart from #1 this time passing in the current variables that have been resolved
	 * 8. If the answer to #6 is no, then the next dataflow is checked for any additional missing variables, (repeat step 3)
	 * 9. Based on the new dynamically generated variables, rebuild for the final time the IPublicationTableCells, which should now contain full referneces to series keys based on combining any partial
	 * cell keys with the variables
	 * 
	 * @param publicationTable
	 * @param dimensionVariables
	 * @return
	 */
	private IPublicationTableCells getPublicationTableCells(PublicationTableBean publicationTable, Map<String, String> dimensionVariables, List<String> allAlias) {
		ICellVariables publicationVariables = publicationTableVariablesBuilderEngine.build(publicationTable, dimensionVariables);
		IPublicationTableCells tableSeries = new PublicationTableCells(publicationTable, publicationVariables);

		Map<String, Set<String>> missingDims2Flow = null;  //Dimension to dataflows for which this requires a value


		//create an ordered set of alias which have missing dimensions
		List<String> orderedAlias = new ArrayList<>();  //This should have the default alias first
		for(String alias : allAlias) {
			Set<String> missingDims = tableSeries.getMissingDimensions(alias); 
			if(missingDims.size() > 0) {
				orderedAlias.add(alias);
				if(missingDims2Flow == null) {
					missingDims2Flow = new HashMap<>();
				}
				for(String key : missingDims) {
					CollectionUtil.addToMappedSet(missingDims2Flow, key, alias);
				}
			}
		}
		
		if(orderedAlias.size() == 0) {
			return tableSeries;
		}

		//For each alias that has missing dimension values, work out what can be used
		for(String alias : orderedAlias) {
			try {
				Set<String> missingDims = tableSeries.getMissingDimensions(alias); 
				Map<String, String> resolvedValues =  getDefaultVariableValues(tableSeries, publicationTable, alias, publicationVariables, missingDims);
				dimensionVariables = new HashMap<>(dimensionVariables);
				if(resolvedValues != null) {
					dimensionVariables.putAll(resolvedValues);
				}
				//If these missing values are required by another dataflow, then rebuild the publication cells now with these details filled in
				for(String missingDimension : missingDims) {
					if(missingDims2Flow.get(missingDimension).size() > 1) {
						orderedAlias = orderedAlias.subList(1, orderedAlias.size());
						return getPublicationTableCells(publicationTable, dimensionVariables, orderedAlias);  //recursive
					}
				}

			} catch(SdmxNoResultsException e) {}
		}
		
		//Rebuild the series with the updated variables
		publicationVariables = publicationTableVariablesBuilderEngine.build(publicationTable, dimensionVariables);
		return new PublicationTableCells(publicationTable, publicationVariables);

	}

	/**
	 * @param missingDims
	 * @return a map of Dimension ID to variable value that can be used in the table
	 */
	private Map<String, String> getDefaultVariableValues(IPublicationTableCells tableCells, PublicationTableBean publicationTable, String flowAlias, ICellVariables publicationVariables, Set<String> missingDimensions) {
		boolean hasTime = missingDimensions.contains(DimensionBean.TIME_DIMENSION_FIXED_ID);
		Map<String, String> returnMap = new HashMap<>(missingDimensions.size());
		int missingSize = hasTime ? 2 : 1;
		
		IPublicationTableAvailableData availbleData = null;
		if(missingDimensions.size() >= missingSize) {
			availbleData = availabilityRetreivalEngine.getAvailableData(flowAlias, publicationTable, tableCells, publicationVariables);
			List<String[]> series = availbleData == null ? Collections.emptyList() : availbleData.getSeries();
			if(series.size() == 0) {
				throw new SdmxNoResultsException("No Data for Table");
			}
			Collections.sort(series, SeriesComparator.getInstance());
			
			String[] dimensions = availbleData.getDimensionPosition();
			String[] firstSeries = series.get(0);
			
			for(int i=0; i < dimensions.length; i++) {
				if(missingDimensions.contains(dimensions[i])) {
					String dimValue = firstSeries[i];
					returnMap.put(dimensions[i], dimValue);
				}
			}
		}
		
		//Re-run the query if we also need to resolve the time period - this time the query is more specific because it will only have
		//the time period as the missing dimension
		if(missingDimensions.contains(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
			if(returnMap.size() > 0) {
				tableCells = new PublicationTableCells(publicationTable, new PublicationVariablesProxy(publicationVariables, returnMap));
			}
			
			DataQuery dataQuery = PublicationTableUtil.buildDataQuery(tableCells, flowAlias);
			dataQuery.setDataQueryDetail(DATA_QUERY_DETAIL.FULL);
			PeriodInfoDataWriterEngine periodInfo = new PeriodInfoDataWriterEngine(); 
			dataRetrievalWithWriter.getData(dataQuery, periodInfo);
			if(periodInfo.getEndPeriod() != null) {
				returnMap.put(DimensionBean.TIME_DIMENSION_FIXED_ID, periodInfo.getEndPeriod().getDateInSdmxFormat());
			}
		}
		return returnMap;
	}
	
}
