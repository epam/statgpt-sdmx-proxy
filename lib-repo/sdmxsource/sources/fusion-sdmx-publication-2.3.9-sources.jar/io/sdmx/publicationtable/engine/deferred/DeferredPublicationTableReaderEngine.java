package io.sdmx.publicationtable.engine.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.core.sdmx.engine.structure.deferred.AbstractDeferredStructureReaderEngine;
import io.sdmx.im.beans.registry.ProvisionAgreementBeanDeferred;
import io.sdmx.publicationtable.model.bean.PublicationTableBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ProvisionAgreementBeanDeferred}
 */
public class DeferredPublicationTableReaderEngine extends AbstractDeferredStructureReaderEngine<PublicationTableBean> {
    private static DeferredPublicationTableReaderEngine INSTANCE;
    
    private DeferredPublicationTableReaderEngine() {
        super(PublicationTableBean.class);
    }
    
    public static DeferredPublicationTableReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredPublicationTableReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<PublicationTableBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new PublicationTableBeanDeferred(bean, loader);
    }

}
