package io.sdmx.publicationtable.engine;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.writer.SubConstraintDataWriterEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableAvailabilityRetreivalEngine;
import io.sdmx.publicationtable.api.model.availability.IPublicationTableAvailableData;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.data.PublicationTableAvailableData;
import io.sdmx.publicationtable.util.PublicationTableUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class PublicationTableAvailabilityRetreivalEngine implements IPublicationTableAvailabilityRetreivalEngine {
	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;
	
	public PublicationTableAvailabilityRetreivalEngine(SdmxDataRetrievalWithWriter dataRetrievalWithWriter) {
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
	}

	/**
	 * Determines availability by executing the data query and capturing the sub constraint
	 */
	public IPublicationTableAvailableData getAvailableData(String dfAlias, PublicationTableBean publicationTable, 
			IPublicationTableCells tableCells, 
			ICellVariables publicationVariables) {
		Set<String> setVariableDims = publicationVariables.getVariableDimensions();
		
		DataQuery dataQuery = PublicationTableUtil.buildDataQuery(tableCells, dfAlias);
		
		Set<String> unsetVariables =  tableCells.getMissingDimensions(dfAlias);
		Set<String> subsetComps = new HashSet<>(setVariableDims.size()+unsetVariables.size());
		for(String dimId : setVariableDims) {
			if(!dimId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID) && dataQuery.getDataStructure().getDimension(dimId) != null) {
				subsetComps.add(dimId);
			}
		}
		for(String dimId : unsetVariables) {
			if(!dimId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID) && dataQuery.getDataStructure().getDimension(dimId) != null) {
				subsetComps.add(dimId);
			}
		}
		for(PublicationTableVariableMappingBean mapping : publicationTable.getVariableMapping()) {
			//These are all derived
			subsetComps.removeAll(mapping.getOutputDimensionId());
		}
		
		dataQuery.setDataQueryDetail(DATA_QUERY_DETAIL.SERIES_KEYS_ONLY);
		if(!ObjectUtil.validCollection(dataQuery.getSeries())) {
			//No series for dataflow with alias
			return null;
		}
		if(!ObjectUtil.validCollection(subsetComps)) {
			throw new SdmxNoResultsException("Publication Table has no variable components");
		}
		SubConstraintDataWriterEngine dataInfo = new SubConstraintDataWriterEngine(subsetComps, false);
		dataRetrievalWithWriter.getData(dataQuery, dataInfo);  
		return new PublicationTableAvailableData(dataInfo, dataQuery);
	}

}
