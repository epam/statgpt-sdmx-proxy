package io.sdmx.publicationtable.engine;

import java.io.OutputStream;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.availability.IAvailabilityInfo;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.data.engine.retrieval.IAvailabilityBeansRetreivalEngine;
import io.sdmx.core.data.engine.writer.PeriodInfoDataWriterEngine;
import io.sdmx.im.availability.AvailabilityInfo;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.publicationtable.api.engine.IPublicationTableAvailabilityRetreivalEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableAvailabilityWriterEngine;
import io.sdmx.publicationtable.api.model.availability.IPublicationTableAvailableData;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.table.PublicationTableCells;
import io.sdmx.publicationtable.util.PublicationTableUtil;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * 
 */
public class PublicationTableAvailabilityWriterEngine implements IPublicationTableAvailabilityWriterEngine {
	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;
	private IPublicationTableAvailabilityRetreivalEngine availabilityRetreivalEngine;
	private IAvailabilityBeansRetreivalEngine availabilityBeansRetreivalEngine;
	private StructureWriterManager structureWriterManager;

	public PublicationTableAvailabilityWriterEngine(SdmxDataRetrievalWithWriter dataRetrievalWithWriter,
			IAvailabilityBeansRetreivalEngine availabilityBeansRetreivalEngine,
			StructureWriterManager structureWriterManager,
			IPublicationTableAvailabilityRetreivalEngine availabilityRetreivalEngine) {
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
		this.availabilityBeansRetreivalEngine = availabilityBeansRetreivalEngine;
		this.structureWriterManager = structureWriterManager;
		this.availabilityRetreivalEngine = availabilityRetreivalEngine;
	}

	@Override
	public SdmxPeriod getAvailablePeriod(IPublicationTableCells tableCells) {
		Map<String, DataQuery> queries = PublicationTableUtil.buildDataQueries(tableCells);

		PeriodInfoDataWriterEngine periodInfoDwe = new PeriodInfoDataWriterEngine();
		for(String alias : queries.keySet()) {
			DataQuery query = queries.get(alias);
			query.clearPeriods();
			query.setFirstNObs(1);
			query.setLastNObs(1);
			try {
				dataRetrievalWithWriter.getData(query, periodInfoDwe);
			} catch(SdmxNoResultsException e) {}
			
		}
		return periodInfoDwe.getPeriod();
	}

	@Override
	public void writeAvailability(PublicationTableBean publicationTable,
			ICellVariables publicationVariables,
			StructureFormat format,
			STRUCTURE_REFERENCE_DETAIL ref,
			OutputStream out) {
		IPublicationTableCells tableSeries = new PublicationTableCells(publicationTable, publicationVariables);


		Set<IAvailabilityInfo> validValues = new HashSet<>();
		Set<String> subsetComponents = new TreeSet<>();
		SdmxNoResultsException ex = null;
		boolean allInError = true;
		for(String dataflowAlias : publicationVariables.getDataflowAlias()) {
			try {
				IPublicationTableAvailableData availableData = availabilityRetreivalEngine.getAvailableData(dataflowAlias, publicationTable, tableSeries, publicationVariables);
				subsetComponents.addAll(CollectionUtil.arrayToSet(availableData.getDimensionPosition()));
				DataflowBean dataflow = publicationVariables.getDataflow(dataflowAlias);
				DataStructureBean dsd = publicationVariables.getDataStructure(dataflowAlias);
				
				validValues.add(new AvailabilityInfo(new DatasetStructures(dsd, dataflow, null, null), null, availableData.getDistinctValuesByComponent(), availableData.getValidSeries(), -1l));
				allInError = false;
			} catch(SdmxNoResultsException e) {
				ex = e;
			}
		}
		if(ex != null && allInError) {
			throw ex;
		}
		SdmxBeans beans = availabilityBeansRetreivalEngine.getBeans(validValues, subsetComponents, ref, null);
		structureWriterManager.writeStructures(beans, format, out);
	}

}
