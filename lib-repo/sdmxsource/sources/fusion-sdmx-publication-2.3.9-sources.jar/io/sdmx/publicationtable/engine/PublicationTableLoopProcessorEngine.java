package io.sdmx.publicationtable.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

import io.sdmx.api.collection.IHierarchyElement;
import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel.ANCHOR;
import io.sdmx.api.sdmx.model.beans.publicationtable.ILoop;
import io.sdmx.api.sdmx.model.beans.publicationtable.ILoop.LOOP_ORDER;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.writer.SubConstraintDataWriterEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableLoopProcessorEngine;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.constant.PUB_TABLE_CONST;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableBodyCellMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableBodyRowMutableImpl;
import io.sdmx.publicationtable.model.table.PublicationTableCells;
import io.sdmx.publicationtable.model.variable.Variable;
import io.sdmx.publicationtable.util.PublicationTableUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.HierarchyElement;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class PublicationTableLoopProcessorEngine implements IPublicationTableLoopProcessorEngine {

	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;

	public PublicationTableLoopProcessorEngine(SdmxDataRetrievalWithWriter dataRetrievalWithWriter) {
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
	}

	@Override
	public IPublicationTableCells processLoops(IPublicationTableCells cells) {
		PublicationTableBean publicationTable = cells.getPublicationTable();
		Map<PublicationTableBodyRow, ILoop> loopRowMap = getRowLoops(publicationTable);
		Map<PublicationTableHeadCell, ILoop> loopHeadMap = getColLoops(publicationTable);

		Set<ILoop> distinctLoops = new HashSet<>(loopRowMap.values().size() + loopHeadMap.values().size());
		distinctLoops.addAll(loopRowMap.values());
		distinctLoops.addAll(loopHeadMap.values());

		if(distinctLoops.size() == 0) {
			return cells;  //no change
		}

		Set<String> allDims = new HashSet<>();
		for(String alias : cells.getVariables().getDataflowAlias()) {
			allDims.addAll(cells.getVariables().getDataStructure(alias).getDimensionIds());
		}

		//Verify loops
		for(ILoop loop : distinctLoops) {
			if(!loop.getInputVariable().equals(loop.getOutputVariable())) {
				//The input variable should be a reference to an external codelist
				if(!publicationTable.getVariables().stream().map(e->e.getId()).collect(Collectors.toSet()).contains(loop.getInputVariable())) {
					throw new SdmxSemmanticException("Invalid loop '"+loop.toString()+"' variable alias '"+loop.getInputVariable()+"' does not exist in publication table");
				}
			} 
			//This should be a Dimension ID
			String dimId = loop.getOutputVariable();
			if(!allDims.contains(dimId)) {
				throw new SdmxSemmanticException("Invalid loop '"+loop.toString()+"' dimension '"+dimId+"' does not exist in input data");
			}

		}

		Map<ILoop, List<IHierarchyElement<KeyValue>>> loopValues = getLoopValues(cells, distinctLoops);

		//Rebuild the publication table by expanding the loops
		return processLoops(publicationTable, loopValues, cells.getVariables());  
	}

	/**
	 * Converts a set of loops to an ordered list of variables values (ID and Label) over which the loop iterates
	 * @param cells
	 * @param distinctLoops
	 * @return
	 */
	private Map<ILoop, List<IHierarchyElement<KeyValue>>> getLoopValues(IPublicationTableCells cells, Set<ILoop> distinctLoops) {
		Set<String> loopInputVaraibles = distinctLoops.stream().map(e -> e.getInputVariable()).collect(Collectors.toSet()); 
		Set<String> loopDimensionIds = distinctLoops.stream().map(e -> e.getOutputVariable()).collect(Collectors.toSet()); 

		Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> loopLists = getVariableLists(cells.getVariables(), loopInputVaraibles);
		//We don't care what data exists for loops that are set up to show all rows (even ones without data)
		for(ILoop currentLoop : distinctLoops) {
			EnumeratedListBean<? extends EnumeratedItemBean> valueLabels = loopLists.get(currentLoop.getInputVariable());
			if(currentLoop.getHeadLabel().getAnchor() != ANCHOR.NO_ANCHOR && valueLabels != null) {
				loopDimensionIds.remove(currentLoop.getOutputVariable());
			}
		}
		Map<String, Set<String>> loopValues = getValidValues(cells, loopDimensionIds); 

		Map<ILoop, List<IHierarchyElement<KeyValue>>> returnMap = new HashMap<>(distinctLoops.size());
		for(ILoop currentLoop : distinctLoops) {
			//TODO This only works if the output variable is the same as the dimension IDs
			Set<String> dataValues = loopValues.get(currentLoop.getOutputVariable());
			EnumeratedListBean<? extends EnumeratedItemBean> valueLabels = loopLists.get(currentLoop.getInputVariable());
			if(currentLoop.getHeadLabel().getAnchor() != ANCHOR.NO_ANCHOR && valueLabels != null) {
				dataValues = valueLabels.getItems().stream().map(e->e.getId()).collect(Collectors.toSet());
			}
			if(dataValues != null) {
				returnMap.put(currentLoop, orderValues(currentLoop, dataValues, valueLabels));
			}
		}
		return returnMap;
	}

	/**
	 * Order the values based on the loop ordering
	 * @param loop
	 * @param dataValues - values for which there is data
	 * @param valueLabels - nullable - provided if the values are pointers to items in an item scheme
	 * @return list of key values (code Id to code label) built into an optional hierarchy (if loop is set to preserve hierarchy) - the 
	 */
	private List<IHierarchyElement<KeyValue>> orderValues(ILoop loop, Set<String> dataValues, EnumeratedListBean<? extends EnumeratedItemBean> valueLabels) {
		if(loop.getLoopOrder() == LOOP_ORDER.BY_ID) {
			dataValues = new TreeSet<>(dataValues);
		} else {
			dataValues = new HashSet<>(dataValues);  //create copy as set is immutable
		}
		if(valueLabels == null) {
			List<IHierarchyElement<KeyValue>> returnList = new ArrayList<>();
			//flat list of values
			for(String value : dataValues) {
				returnList.add(new HierarchyElement<KeyValue>(null, KeyValueImpl.getInstance(value, value)));
			}
			return returnList;
		} 

		//		valueLabels.filterItems(dataValues, false);
		LoopComparator loopComparator = new LoopComparator(loop.getLoopOrder()); 
		Map<EnumeratedItemBean, IHierarchyElement<EnumeratedItemBean>> values = new TreeMap<>(loopComparator); 
		if(ObjectUtil.validCollection(loop.getLoopValues())) {
			//A defined set of values
			dataValues.retainAll(loop.getLoopValues());  //remove any datapoints which are not in the defined list
		}
		if(loop.preserveHierarchy()) {
			//include any parent nodes in the list, even if they don't have data/not included in loop values

			List<String> rootCodes = new ArrayList<>();      //child code to parent code
			Map<String, Set<String>> childMap = new HashMap<>();  //code to child codes

			for(String codeId : dataValues) {
				EnumeratedItemBean listItem = valueLabels.getItemById(codeId);
				if(!childMap.containsKey(listItem.getId())) {
					childMap.put(listItem.getId(), null);
					if(listItem.getParentCode() == null) {
						rootCodes.add(listItem.getId());
					}
				}
				while(listItem != null && listItem.getParentCode() != null) {
					if(listItem.getParentCode() == null) {
						rootCodes.add(listItem.getId());
					}
					CollectionUtil.addToMappedSet(childMap, listItem.getParentCode(), listItem.getId());
					listItem = valueLabels.getItemById(listItem.getParentCode());
					if(listItem != null) {
						CollectionUtil.addToMappedSet(childMap, listItem.getParentCode(), listItem.getId());
						if(listItem.getParentCode() == null) {
							rootCodes.add(listItem.getId());
						}
					}
				}
			}
			//Process top level codes, building hierarchy underneath
			for(String codeId : rootCodes) {
				EnumeratedItemBean listItem = valueLabels.getItemById(codeId);
				if(listItem != null) {
					values.put(listItem, new HierarchyElement<EnumeratedItemBean>(buildCodeHierarchy(childMap.get(codeId), childMap, valueLabels, loopComparator), listItem));
				}
			}
		} else {
			//Flat list of codes (sorted by loop order)
			for(String codeId : dataValues) {
				EnumeratedItemBean listItem = valueLabels.getItemById(codeId);
				if(listItem != null) {
					values.put(listItem, new HierarchyElement<EnumeratedItemBean>(null, listItem));
				}
			}
		}
		List<IHierarchyElement<EnumeratedItemBean>> rootItems = new ArrayList<>();
		for(EnumeratedItemBean rootItem : values.keySet()) {
			rootItems.add(values.get(rootItem));
		}
		//Convert the map of sorted values into a hierarchical list of key values
		return buildHierarchyElements(rootItems);
	}

	/**
	 * Converts a hierarchy of items into a hierarchy of key values
	 * @param hierarchyItems
	 * @return
	 */
	private List<IHierarchyElement<KeyValue>> buildHierarchyElements(List<IHierarchyElement<EnumeratedItemBean>> hierarchyItems) {
		if(hierarchyItems == null) {
			return null;
		}
		List<IHierarchyElement<KeyValue>> elements = new ArrayList<>(hierarchyItems.size());
		for(IHierarchyElement<EnumeratedItemBean> kv : hierarchyItems) {
			elements.add(new HierarchyElement<KeyValue>(buildHierarchyElements(kv.getChildren()), KeyValueImpl.getInstance(kv.getValue().getId(), kv.getValue().getName())));
		}
		return elements;
	}

	private List<IHierarchyElement<EnumeratedItemBean>> buildCodeHierarchy(Set<String> childCodes, Map<String, Set<String>> childMap, EnumeratedListBean<? extends EnumeratedItemBean> valueLabels, Comparator<EnumeratedItemBean> comparator) {
		if(childCodes == null) {
			return null;
		}
		List<IHierarchyElement<EnumeratedItemBean>> returnList = new ArrayList<IHierarchyElement<EnumeratedItemBean>>();

		for(String childCodeId : childCodes) {
			EnumeratedItemBean listItem = valueLabels.getItemById(childCodeId);
			returnList.add(new HierarchyElement<EnumeratedItemBean>(buildCodeHierarchy(childMap.get(childCodeId), childMap, valueLabels, comparator), listItem));
		}
		returnList.sort((a, b)-> {
			return comparator.compare(a.getValue(), b.getValue());
		});
		return returnList;
	}

	private class LoopComparator implements Comparator<EnumeratedItemBean> {
		private LOOP_ORDER order;

		public LoopComparator(LOOP_ORDER order) {
			this.order = order;
		}

		@Override
		public int compare(EnumeratedItemBean o1, EnumeratedItemBean o2) {
			switch(order) {
			case BY_ID:
				return o1.getId().compareTo(o2.getId());
			case BY_NAME:
				int compare = o1.getName().compareTo(o2.getName());
				if(compare != 0) {
					return compare;
				}
				//otherwise return natural position
			case NATURAL:
				return o1.getPosition() - o2.getPosition();
			}
			return o1.getPosition() - o2.getPosition();
		}
	}


	/**
	 * Queries the data source to determine the possible values for each loop dimension
	 * @param cells
	 * @param distinctLoops
	 * @return map of Dimension ID to valid value
	 */
	private Map<String, Set<String>> getValidValues(IPublicationTableCells cells, Set<String> loopDimensions) {
		Map<String, Set<String>> validDimenisonValues = new HashMap<>();
		for(String flowAlias : cells.getVariables().getDataflowAlias()) {
			DataQuery dataQuery = PublicationTableUtil.buildDataQuery(cells, flowAlias);
			dataQuery.setDataQueryDetail(DATA_QUERY_DETAIL.SERIES_KEYS_ONLY);
			SubConstraintDataWriterEngine dataInfo = new SubConstraintDataWriterEngine(loopDimensions, false);
			dataRetrievalWithWriter.getData(dataQuery, dataInfo);
			for(String id : loopDimensions) {
				Set<String> values = dataInfo.getValidValues(id);
				if(values != null) {
					CollectionUtil.addToMappedSet(validDimenisonValues, id, values);
				}
			}
		}
		for(String key : validDimenisonValues.keySet()) {
			validDimenisonValues.put(key, Collections.unmodifiableSet(validDimenisonValues.get(key)));
		}
		return validDimenisonValues;
	}

	private Map<PublicationTableBodyRow, ILoop> getRowLoops(PublicationTableBean publicationTable) {
		Map<PublicationTableBodyRow, ILoop> loopMap = new HashMap<>();
		for(PublicationTableBodyRow row : publicationTable.getBodyRows()) {
			if(row.getRowLabel().getLoop() != null) {
				loopMap.put(row, row.getRowLabel().getLoop());
			}
		}
		return loopMap;
	}

	private Map<PublicationTableHeadCell, ILoop> getColLoops(PublicationTableBean publicationTable) {
		Map<PublicationTableHeadCell, ILoop> loopMap = new HashMap<>();
		for(PublicationTableHeadRow row : publicationTable.getHeaderRows()) {
			for(PublicationTableHeadCell headCell : row.getHeaderCells()) {
				ILoop loop = headCell.getRowLabel().getLoop();
				if(loop != null) {
					loopMap.put(headCell, loop);
				}
			}
		}
		return loopMap;
	}

	/**
	 * Expands all the loops in order to rebuild the PublicationTableCells
	 * @param publicationTable
	 * @param validLoopValues
	 * @param variables
	 * @return
	 */
	private IPublicationTableCells processLoops(PublicationTableBean publicationTable, Map<ILoop, List<IHierarchyElement<KeyValue>>> variableValues, ICellVariables variables) {
		publicationTable = processLoopColumns(publicationTable, variableValues, variables);
		publicationTable = processLoopRows(publicationTable, variableValues, variables);
		return new PublicationTableCells(publicationTable, variables);
	}

	/**
	 * Expands the loop rows and headers in order to rebuild a new PublicationTable
	 * @param publicationTable
	 * @param validLoopValues
	 * @param variables
	 * @return
	 */
	private PublicationTableBean processLoopColumns(PublicationTableBean publicationTable, Map<ILoop, List<IHierarchyElement<KeyValue>>> variableValues, ICellVariables variables) {
		//TODO
		//		for(PublicationTableHeadRow row : publicationTable.getHeaderRows()) {
		//			String rowLabel = row.getHeadCell().getLabel();
		//			ILoop loop = PublicationTableUtil.isLoop(rowLabel);
		//			if(loop != null) {
		//				//loop values
		//				String variableId = loop.getInputVariable();
		//				
		//			}
		//		}
		return publicationTable;
	}

	/**
	 * Expands the loop rows and headers in order to rebuild a new PublicationTable
	 * @param publicationTable
	 * @param validLoopValues
	 * @param variables
	 * @return
	 */
	private PublicationTableBean processLoopRows(PublicationTableBean publicationTable, Map<ILoop, List<IHierarchyElement<KeyValue>>> variableValues, ICellVariables variables) {
		PublicationTableMutableBean pMut = (PublicationTableMutableBean) publicationTable.getMutableInstance();

		List<PublicationTableBodyRowMutable> existingRows = pMut.getBodyRows();
		List<PublicationTableBodyRowMutable> newRows = new ArrayList<>(Math.max(30, existingRows.size()));
		pMut.setBodyRows(newRows);
		Map<PublicationTableBodyRowMutable, ILoop> loops = getLoops(existingRows);
		if(loops.size() == 0) {
			//Early Out
			return publicationTable;
		}

		for(int rowIdx = 0; rowIdx < existingRows.size(); rowIdx++) {
			PublicationTableBodyRowMutable row = existingRows.get(rowIdx);
			ILoop loop = row.getRowLabel().getLoop();
			if(loop == null) {
				newRows.add(row);
			} else {
				//A list of children of this loop, for example
				// Loop Parent
				// > Loop Child 1
				// >> Loop SubChild 1 
				// >> Loop SubChild 2 
				// > Loop Child 2
				//Where each loop child either sets up a new loop, or is an absolute row
				List<IHierarchyElement<PublicationTableBodyRowMutable>> childLoops = buildChildLoops(existingRows, rowIdx);

				int skipRows = 0;
				for(IHierarchyElement<PublicationTableBodyRowMutable> hEl : childLoops) {
					skipRows += hEl.getSize();
				}
				rowIdx += skipRows;
				expandRow(loop, variableValues, row, newRows, childLoops, row.getLevel()-1, new HashMap<>());
			}
		}
		return pMut.getImmutableInstance();
	}

	/**
	 * For a loop row - child loops are de
	 * @return
	 */
	private List<IHierarchyElement<PublicationTableBodyRowMutable>> buildChildLoops(List<PublicationTableBodyRowMutable> existingRows, int rowIdx) {
		PublicationTableBodyRowMutable row = existingRows.get(rowIdx);
		int level = row.getLevel();

		List<IHierarchyElement<PublicationTableBodyRowMutable>> returnList = new ArrayList<>();
		for(int i=(rowIdx+1); i < existingRows.size(); i++) {
			row = existingRows.get(i);
			if(row.getLevel() > level) {
				IHierarchyElement<PublicationTableBodyRowMutable> el = new HierarchyElement<>(buildChildLoops(existingRows, i), row);
				i += (el.getSize()-1);
				returnList.add(el);
			} else {
				break;
			}
		}
		return returnList;
	}

	/**
	 * @param variables
	 * @param variableId this is either a Dimension ID or an alias to an external Codelist/Valuelist
	 * @return nullable - variableId to list - if the variable resolves to an enumerated list
	 */
	private Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> getVariableLists(ICellVariables variables, Set<String> loopInputVaraibles) {
		Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> returnMap = new HashMap<>(loopInputVaraibles.size());
		for(String variableId : loopInputVaraibles) {
			returnMap.put(variableId, getVariableList(variables, variableId));
		}
		return returnMap;
	}


	/**
	 * @param variables
	 * @param variableId this is either a Dimension ID or an alias to an external Codelist/Valuelist
	 * @return nullable - if the variable resolves to an enumerated list
	 */
	private EnumeratedListBean<? extends EnumeratedItemBean> getVariableList(ICellVariables variables, String variableId) {
		return variables.getValues(variableId);
	}

	/**
	 * @param existingRows
	 * @return a map of row to loop
	 */
	private Map<PublicationTableBodyRowMutable, ILoop> getLoops(List<PublicationTableBodyRowMutable> existingRows) {
		Map<PublicationTableBodyRowMutable, ILoop> returnMap = new HashMap<>();

		for(PublicationTableBodyRowMutable row : existingRows) {
			ILoop loop = row.getRowLabel().getLoop();
			if(loop != null) {
				returnMap.put(row, loop);
			}
		}

		return returnMap;
	}


	private PublicationTableBodyRowMutable copyRow(PublicationTableBodyRowMutable expandRow, String label, int levelAppends, Map<String, String> replaceVariables) {
		PublicationTableBodyRowMutable newRow = replaceRowVariables(expandRow, replaceVariables);
		label = prefixLevel(label, levelAppends);
		newRow.setHeadCell().setLabel(label);
		return newRow;
	}

	private PublicationTableBodyRowMutable replaceRowVariables(PublicationTableBodyRowMutable expandRow, Map<String, String> replaceVariables) {
		PublicationTableBodyRowMutable newRow = new PublicationTableBodyRowMutableImpl();
		for(PublicationTableBodyCellMutable td : expandRow.getTableCells()) {
			String obsKey = td.getObservationKey();
			PublicationTableBodyCellMutable tdNew = new PublicationTableBodyCellMutableImpl();
			if(obsKey != null) {
				for(String dimId : replaceVariables.keySet()) {
					obsKey = obsKey.replaceAll("\\$\\("+dimId+"\\)", replaceVariables.get(dimId));
				}
			}
			tdNew.setObservationKey(obsKey);
			newRow.addTableCell(tdNew);

			//Process any inner loops
		}
		return newRow;
	}

	private String prefixLevel(String label, int levelCount) {
		if(levelCount == 0) {
			return label;
		}
		char levelChar = PUB_TABLE_CONST.LEVEL_PREFIX.charAt(0);
		char[] labelChars = label.toCharArray();
		StringBuilder labelSb = null;
		for(int i=0; i < levelCount; i++) {
			if(labelChars.length > i && labelChars[i] == levelChar) {
				continue;
			}
			if(labelSb == null) {
				labelSb = new StringBuilder();
			}
			labelSb.append(">");
		}
		if(labelSb == null) {
			return label;
		}
		labelSb.append(label);
		return labelSb.toString();
	}

	/**
	 * Expands a row in the table based on the valid values for that row (loopValues)
	 * @param outputVariableId the variable ID to set for each loopValue
	 * @param variableValues a hierarchy of values in the order that they are to be displayed, example EUR, FR, DE where FR and DE are a child of EUR
	 * @param expandRow the row to expand
	 * @param newRows any new rows built in place of the expand row (or the childRows) are added to this list 
	 * @param childRows if non-empty, each loop value will output a row with these child rows present - a child row may itself introduce a new loop
	 */
	private void expandRow(ILoop loop,
			Map<ILoop, List<IHierarchyElement<KeyValue>>> variableValues,
			PublicationTableBodyRowMutable expandRow, 
			List<PublicationTableBodyRowMutable> newRows,
			List<IHierarchyElement<PublicationTableBodyRowMutable>> childRows,
			int startLevel,
			Map<String, String> replaceVariables) {

		int nextLevel = startLevel + 1;
		List<IHierarchyElement<KeyValue>> loopValues = variableValues.get(loop);
		if(loopValues != null) {
			for(IHierarchyElement<KeyValue> variableValueNode : loopValues) {
				String outputId = variableValueNode.getValue().getConcept();
				String outputLabel = variableValueNode.getValue().getCode();
				replaceVariables.put(loop.getOutputVariable(), outputId);
				if(loop.getHeadLabel().getLabel() != null) {
					//A footnote placeholder e.g. $(1) - replace any variables from loop, e.g. $(1,$(REF_AREA),$(INDICATOR)) replaced with $(1,UK,EMP)
					String footnote = loop.getHeadLabel().getLabel();
					Variable footNoteVar = Variable.build(footnote);
					StringBuilder fnSb = new StringBuilder();
					if(footNoteVar.isVariable()) {
						fnSb.append("$(");
					}
					buildFootnote(footNoteVar, replaceVariables, fnSb);
					if(footNoteVar.isVariable()) {
						fnSb.append(")");
					}
					outputLabel += " " +fnSb.toString();
				}

				newRows.add(copyRow(expandRow, outputLabel, startLevel, replaceVariables));

				//Process all child rows (1 level deeper)
				if(childRows.size() > 0) {
					//The child row is either a 'standard row' or is a new loop
					subloop(variableValues, childRows, newRows, nextLevel, replaceVariables);
				}

				//Still in the expand row, but 1 level deeper
				if(variableValueNode.getChildren().size() > 0) {
					Map<ILoop, List<IHierarchyElement<KeyValue>>> variableSubValues = new HashMap<>(variableValues);
					variableSubValues.put(loop, variableValueNode.getChildren());
					expandRow(loop, variableSubValues, expandRow, newRows, childRows, nextLevel, replaceVariables);
				}
			}
		}
		replaceVariables.remove(loop.getOutputVariable());
	}

	private void buildFootnote(Variable footnoteVar, Map<String, String> replaceVariables, StringBuilder sb) {
		if(footnoteVar.getText() != null) {
			String text = footnoteVar.getText();
			if(footnoteVar.isVariable() && replaceVariables.containsKey(text)) {
				sb.append(replaceVariables.get(text));
			} else {
				sb.append(text);
			}
		}
		for(Variable subvar : footnoteVar.getVariables()) {
			buildFootnote(subvar, replaceVariables, sb);
		}
	}

	/**
	 * Expands a row in the table based on the valid values for that row (loopValues)
	 * @param outputVariableId the variable ID to set for each loopValue
	 * @param variableValues a hierarchy of values in the order that they are to be displayed, example EUR, FR, DE where FR and DE are a child of EUR
	 * @param loopRow the row to expand
	 * @param newRows any new rows built in place of the expand row (or the childRows) are added to this list 
	 * @param childRows if non-empty, each loop value will output a row with these child rows present - a child row may itself introduce a new loop
	 */
	private void subloop(Map<ILoop, List<IHierarchyElement<KeyValue>>> variableValues,
			List<IHierarchyElement<PublicationTableBodyRowMutable>> childRows,
			List<PublicationTableBodyRowMutable> newRows,
			int startLevel,
			Map<String, String> replaceVariables) {

		for(IHierarchyElement<PublicationTableBodyRowMutable> childRow : childRows) {
			PublicationTableBodyRowMutable row = childRow.getValue();
			ILoop loop = row.getRowLabel().getLoop();
			if(loop == null) {
				//Copy the row, replacing the variables
				newRows.add(copyRow(row, row.getHeadCell().getLabel(), startLevel, replaceVariables));
				subloop(variableValues, childRow.getChildren(), newRows, startLevel, replaceVariables);
			} else {
				//Another loop
				expandRow(loop, variableValues, row, newRows, childRow.getChildren(), startLevel, replaceVariables);
			}
		}
	}
}

