package io.sdmx.publicationtable.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.format.json.engine.structure.writer.fusion.FusionJsonStructureWriterEngine;
import io.sdmx.format.json.manager.FusionJsonStructureReaderManager;
import io.sdmx.publicationtable.engine.PublicationTableJSONReaderEngine;
import io.sdmx.publicationtable.engine.PublicationTableJSONWriterEngine;
import io.sdmx.publicationtable.engine.PublicationTableValidationEngine;
import io.sdmx.publicationtable.engine.deferred.DeferredPublicationTableReaderEngine;
import io.sdmx.publicationtable.factory.ExcelPublicationTableDataWriterFactory;
import io.sdmx.publicationtable.factory.JsonPublicationTableWriterFactory;
import io.sdmx.publicationtable.factory.PublicationTableCrossReferenceRetrievalFactory;

public class PublicationTableModule  implements IFusionModule {

	public static void register() {
        FusionJsonStructureWriterEngine.getInstance().registerWriter(PublicationTableJSONWriterEngine.getInstance());
        FusionJsonStructureReaderManager.getInstance().registerReader(PublicationTableJSONReaderEngine.registerInstance());
        PublicationTableCrossReferenceRetrievalFactory.registerInstance();
        JsonPublicationTableWriterFactory.registerInstance();
        PublicationTableValidationEngine.registerInstance();
        ExcelPublicationTableDataWriterFactory.registerInstance();
        DeferredPublicationTableReaderEngine.getInstance();
	}

}
