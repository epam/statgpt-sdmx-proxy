package io.sdmx.publicationtable.constant;

public class PUB_TABLE_CONST {

	public static final String LEVEL_PREFIX = ">";

	public static final String ARRAY_VARIABLE_ID = "id";
	public static final String ARRAY_VARIABLE_NAME = "name";
	public static final String ARRAY_VARIABLE_DESC = "desc";
}
