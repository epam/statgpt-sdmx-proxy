package io.sdmx.publicationtable.manager;

import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;
import io.sdmx.publicationtable.api.factory.IMaterialisedPublicationTableWriterFactory;
import io.sdmx.publicationtable.api.manager.IMaterialisedPublicationTableWriterManager;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.utils.core.application.FusionBeanStore;

public class MaterialisedPublicationTableWriterManager implements IMaterialisedPublicationTableWriterManager {
	private Set<IMaterialisedPublicationTableWriterFactory> factories;
	
	private InformationFormat defaultFormat;
	
	public MaterialisedPublicationTableWriterManager(InformationFormat defaultFormat) {
		this.defaultFormat = defaultFormat;
	}

	@Override
	public void writeTable(OutputPublicationTable outputTable, InformationFormat format, OutputStream out) {
		if(format == null) {
			format = defaultFormat;
		}
		if(format == null){
			throw new IllegalArgumentException("Can not write Publication Table - output format is not specified ");
		}
		getWriter(format).writeOutputTable(outputTable, out);
	}
	
	private OutputTableWriterEngine getWriter(InformationFormat format) {
		for(IMaterialisedPublicationTableWriterFactory factory : getFactories()) {
			OutputTableWriterEngine writer = factory.getOutputTableWriterEngine(format);
			if(writer != null) {
				return writer;
			}
		}
		throw new SdmxSemmanticException("Unsupported format for writing publication tables");
	}

	private Collection<IMaterialisedPublicationTableWriterFactory> getFactories() {
		if(factories == null) {
			synchronized(this) {
				factories = new HashSet<>();
				factories.addAll(FusionBeanStore.getBeans(IMaterialisedPublicationTableWriterFactory.class));
			}
		}
		return factories;
	}

}
