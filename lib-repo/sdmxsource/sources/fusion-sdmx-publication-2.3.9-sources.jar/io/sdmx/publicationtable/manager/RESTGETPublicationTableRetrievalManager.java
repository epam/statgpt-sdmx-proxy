package io.sdmx.publicationtable.manager;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.publicationtable.IPublicationTableManager;
import io.sdmx.api.sdmx.manager.publicationtable.IRESTGETPublicationTableRetrievalManager;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.format.json.constant.SDMXJSON_VERSION;
import io.sdmx.format.json.model.SdmxJsonStructureFormat;
import io.sdmx.utils.core.format.GenericFormatJSON;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

public class RESTGETPublicationTableRetrievalManager implements IRESTGETPublicationTableRetrievalManager {
	private IPublicationTableManager publicationTableManager;
	private static final StructureFormat DEFAULT_FORMAT = SdmxJsonStructureFormat.getInstance(SDMXJSON_VERSION.V2);
	
	public RESTGETPublicationTableRetrievalManager(IPublicationTableManager publicationTableManager) {
		this.publicationTableManager = publicationTableManager;
	}


	@Override
	public void processQuery(IRESTGET getRequest, InformationFormat format, IResponse response) {
		if(format == null) {
			format  = GenericFormatJSON.getInstance();
		}
		response.setContentType(format.getFormatDetails().getMimeType());
		boolean includePeriod = getRequest.getBooleanParamValue("includePeriod") == Boolean.TRUE;
		publicationTableManager.writePublicationTable(getRef(getRequest), getRequest.getQueryParameters(), includePeriod, format, response.getOutputStream());
	}

	@Override
	public void processAvailabilityQuery(IRESTGET getRequest, InformationFormat format, IResponse response) {
		StructureFormat sf = DEFAULT_FORMAT;
		if(format instanceof StructureFormat) {
			sf = (StructureFormat) format;
		}
		String references = getRequest.getStringParamValue("references");
		STRUCTURE_REFERENCE_DETAIL ref = STRUCTURE_REFERENCE_DETAIL.NONE;
		if(references != null) {
			ref = STRUCTURE_REFERENCE_DETAIL.parseString(references);
		}
		response.setContentType(sf.getFormatDetails().getMimeType());
		publicationTableManager.writeAvailability(getRef(getRequest), getRequest.getQueryParameters(), sf, ref, response.getOutputStream());
	}

	
	private IMaintainableRef getRef(IRESTGET getRequest) {
		String agencyId = getRequest.getPathParameter(1);
		String id = getRequest.getPathParameter(2);
		String version = getRequest.getPathParameter(3);
		return MaintainableRef.getInstance(agencyId, id, version);
	}
}
