package io.sdmx.publicationtable.manager;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.publicationtable.IPublicationTableManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.data.api.model.dataset.IObservationValueFormatter;
import io.sdmx.core.data.model.formatting.MultiFormatter;
import io.sdmx.core.data.model.formatting.NumericalValueFormatter;
import io.sdmx.core.data.model.formatting.ObservationFormatting;
import io.sdmx.core.data.model.formatting.RepresentationMapMVFormatter;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.publicationtable.api.engine.IPublicationTableAvailabilityWriterEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableCellBuilderEngine;
import io.sdmx.publicationtable.api.engine.IPublicationTableVariablesBuilderEngine;
import io.sdmx.publicationtable.api.manager.IMaterialisedPublicationTableWriterManager;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.data.PublicationTableCellValueStore;
import io.sdmx.publicationtable.model.output.OutputPublicationTableImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class PublicationTableManager implements IPublicationTableManager {
	private IMaterialisedPublicationTableWriterManager outputTableWriterManager;
	private IPublicationTableVariablesBuilderEngine publicationTableVariablesManager;
	private IPublicationTableAvailabilityWriterEngine publicationTableAvailabilityWriterEngine;
	private SdmxDataRetrievalWithWriter dataRetrievalWithWriter;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private IPublicationTableCellBuilderEngine publicationTableCellBuilderEngine;

	public PublicationTableManager(SdmxBeanRetrievalManager beanRetrievalManager, 
									   SdmxDataRetrievalWithWriter dataRetrievalWithWriter,
									   IPublicationTableVariablesBuilderEngine publicationTableVariablesManager,
									   IPublicationTableCellBuilderEngine publicationTableCellBuilderEngine,
									   IPublicationTableAvailabilityWriterEngine publicationTableAvailabilityWriterEngine,
									   IMaterialisedPublicationTableWriterManager outputTableWriterManager) {
		this.publicationTableVariablesManager = publicationTableVariablesManager;
		this.publicationTableCellBuilderEngine = publicationTableCellBuilderEngine;
		this.publicationTableAvailabilityWriterEngine = publicationTableAvailabilityWriterEngine;
		this.dataRetrievalWithWriter = dataRetrievalWithWriter;
		this.outputTableWriterManager = outputTableWriterManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	

	@Override
	public void writePublicationTable(IMaintainableRef ref, 
									  Map<String, String> queryParameters,
									  boolean includePeriod, 
									  InformationFormat format, 
									  OutputStream out) {
		
		PublicationTableBean publicationTable = getPublicationTable(ref);
		IPublicationTableCells tableCells = publicationTableCellBuilderEngine.build(publicationTable, queryParameters);
		
		
		IObservationValueFormatter mvFormatter = null;
		String emptyCellValue = null;
		if(publicationTable.getMissingValueRules() != null) {
			PublicationTableMVBean mvRules = publicationTable.getMissingValueRules();
			emptyCellValue = mvRules.getDefaultMissingValue();
			if(mvRules.getMissingValueMapping() != null) {
				IRepresentationMapBean repMap =  this.beanRetrievalManager.getBean(mvRules.getMissingValueMapping().getReference());
				if(repMap != null) {
					mvFormatter = new RepresentationMapMVFormatter(mvRules.getComponentId(), repMap);
				}
			}
		}
		IObservationValueFormatter numericalFormatting = null;
		Integer globalScale = null;
		Map<String, Integer> scaleFactor = new HashMap<>();
		if(ObjectUtil.validCollection(publicationTable.getObservationFormatting())) {
			Map<String, DataStructureBean> dsdMap = new HashMap<>();
			for(PublicationTableDataflow dfRef : publicationTable.getDataflowReferences()) {
				String alias = dfRef.getAlias();
				IDatasetStructures dsStructures = new DatasetStructures(dfRef.getDataflowRef().getReference(), beanRetrievalManager);
				if(dsStructures.getDataStructure() != null) {
					dsdMap.put(alias, dsStructures.getDataStructure());
				}
			}
			//DEV-1840 Remove scaling as this is formatted separately in the PublicationTableCellValueStore
			List<IObservationFormatting> formatting = new ArrayList<>(publicationTable.getObservationFormatting().size());
			for(IObservationFormatting obsFormatting : publicationTable.getObservationFormatting()) {
				if(obsFormatting.getScalingFactor() != null) {
					Integer scale = obsFormatting.getScalingFactor();
					if(!ObjectUtil.validCollection(obsFormatting.getKeyMatch())) {
						globalScale = scale;
					} else {
						for(String seriesKey : obsFormatting.getKeyMatch()) {
							scaleFactor.put(seriesKey, scale);
						}
					}
					obsFormatting = new ObservationFormatting(obsFormatting).scalingFactor(null);
				}
				if(obsFormatting.getPrecision() >=0 || obsFormatting.isScientificNotation() || obsFormatting.getLocale() != null) {
					formatting.add(obsFormatting);
				}
				
			}
			if(formatting.size() > 0) {
				numericalFormatting = new NumericalValueFormatter(formatting, dsdMap);
			}
		}
		
		IObservationValueFormatter obsValueFormatter = mvFormatter != null && numericalFormatting != null ? new MultiFormatter(true, numericalFormatting, mvFormatter) : numericalFormatting != null ? numericalFormatting : mvFormatter;
		
		IPublicationTableCellValueStore obsStore = new PublicationTableCellValueStore(tableCells, obsValueFormatter, emptyCellValue, globalScale, scaleFactor, dataRetrievalWithWriter);
		if(!obsStore.hasData()) {
			throw new SdmxNoResultsException("No Data for Table for Input Variables");
		}
		tableCells.getVariables().setCellValueStore(obsStore);
		
		SdmxPeriod period = null;
		if(includePeriod) {
			//Run a data query to obtain earliest and latest periods - do not include cast frequencies or calculated cells
			period = publicationTableAvailabilityWriterEngine.getAvailablePeriod(tableCells);
		}
		
		OutputPublicationTable outputTable = new OutputPublicationTableImpl(tableCells.getPublicationTable(), tableCells.getVariables(), period);
		outputTableWriterManager.writeTable(outputTable, format, out);
	}

	
	@Override
	public void writeAvailability(IMaintainableRef mRef, 
									Map<String, String> queryParameters, 
									StructureFormat format,
									STRUCTURE_REFERENCE_DETAIL ref, 
									OutputStream out) {
		PublicationTableBean publicationTable = getPublicationTable(mRef);
		ICellVariables publicationVariables = publicationTableVariablesManager.build(publicationTable, queryParameters);
		publicationTableAvailabilityWriterEngine.writeAvailability(publicationTable, publicationVariables, format, ref, out);
	}

	private PublicationTableBean getPublicationTable(IMaintainableRef ref) {
		if(ref == null) {
			throw new SdmxException("Can not obtain Publication Table - Table Reference was not provided");
		}
		IURNSingle<PublicationTableBean> urn = URN.builder().ref(ref).buildSingle(PublicationTableBean.class);
		PublicationTableBean publicationTable = beanRetrievalManager.getBean(urn);
		if(publicationTable == null) {
			throw new SdmxReferenceException(urn);
		}
		return publicationTable;
	}
}
