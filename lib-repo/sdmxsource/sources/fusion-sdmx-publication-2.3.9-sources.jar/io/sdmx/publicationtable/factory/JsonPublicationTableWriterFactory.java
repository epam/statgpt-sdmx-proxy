package io.sdmx.publicationtable.factory;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;
import io.sdmx.publicationtable.api.factory.IMaterialisedPublicationTableWriterFactory;
import io.sdmx.publicationtable.engine.OutputTableJSONWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.GenericFormatJSON;

public class JsonPublicationTableWriterFactory implements IMaterialisedPublicationTableWriterFactory, IFusionSingleton {
	private static final OutputTableJSONWriterEngine ENGINE = new OutputTableJSONWriterEngine();
	private static JsonPublicationTableWriterFactory INSTANCE;
	
	public static JsonPublicationTableWriterFactory registerInstance() {
        if(INSTANCE == null) {
            INSTANCE = new JsonPublicationTableWriterFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	
	@Override
	public OutputTableWriterEngine getOutputTableWriterEngine(InformationFormat format) {
		if(format == GenericFormatJSON.getInstance()) {
			return ENGINE;
		}
		return null;
	}
	
}
