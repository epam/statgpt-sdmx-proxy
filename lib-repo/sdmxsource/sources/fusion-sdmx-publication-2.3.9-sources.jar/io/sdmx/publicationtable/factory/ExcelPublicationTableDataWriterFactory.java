package io.sdmx.publicationtable.factory;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;
import io.sdmx.publicationtable.api.factory.IMaterialisedPublicationTableWriterFactory;
import io.sdmx.publicationtable.engine.ExcelPublicationTableWriter;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.GenericFormatXLSX;

public class ExcelPublicationTableDataWriterFactory implements IMaterialisedPublicationTableWriterFactory , IFusionSingleton {
    private static ExcelPublicationTableDataWriterFactory INSTANCE;
    private static final ExcelPublicationTableWriter WRITER = new ExcelPublicationTableWriter();
    
   	//Private constructor - lazy load instance
   	public static ExcelPublicationTableDataWriterFactory getInstance() {
   		if(INSTANCE == null) {
   			INSTANCE = new ExcelPublicationTableDataWriterFactory();
   			FusionBeanStore.registerInstance(INSTANCE);
   		}
   		return INSTANCE;
   	}

   	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

   	public static ExcelPublicationTableDataWriterFactory registerInstance() {
   		FusionBeanStore.registerInstance(getInstance());
   		return getInstance();
   	}

	@Override
	public OutputTableWriterEngine getOutputTableWriterEngine(InformationFormat format) {
		if(format == GenericFormatXLSX.getInstance()) {
			return WRITER;
		}
		return null;
	}

	
}
