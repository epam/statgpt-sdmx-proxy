package io.sdmx.publicationtable.factory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.model.ref.DataStructureReferences;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.publicationtable.model.data.EmptyPublicationTableCellValueStore;
import io.sdmx.publicationtable.model.output.OutputPublicationTableImpl;
import io.sdmx.publicationtable.model.table.PublicationTableCells;
import io.sdmx.publicationtable.model.variable.ValidationPublicationVariable;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public class PublicationTableCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory , IFusionSingleton {
	private static PublicationTableCrossReferenceRetrievalFactory INSTANCE;

	public static PublicationTableCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new PublicationTableCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
	public Class<PublicationTableBean> getSupportedType() {
		return PublicationTableBean.class;
	}

	public static PublicationTableCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}


	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		PublicationTableBean publicationTable = (PublicationTableBean) maintBean;
		ValidationPublicationVariable cellVairable = new ValidationPublicationVariable(publicationTable, retrievalManager);

		Map<String, ICrossReferenceBean<? extends EnumeratedListBean>> comp2ClRef = new HashMap<>();
		Map<String, DataflowRef> aliasToFlow = new HashMap<>(publicationTable.getDataflowReferences().size());
		for(PublicationTableDataflow flowRef : publicationTable.getDataflowReferences()) {
			DataStructureReferences dsdReferences = new DataStructureReferences(retrievalManager, flowRef.getDataflowRef());
			for(ComponentBean comp : dsdReferences.getEnumerationReferences().keySet()) {
				comp2ClRef.put(comp.getId(), dsdReferences.getEnumerationReferences().get(comp));
			}
			aliasToFlow.put(flowRef.getAlias(), new DataflowRef(dsdReferences));
		}

		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();

		resolveTableSeriesReferences(publicationTable, returnReferences, cellVairable, aliasToFlow);
		resolveConditionalVariableReferences(publicationTable, returnReferences, aliasToFlow);
		
		
		resolveImportedVariables(publicationTable, returnReferences, retrievalManager, cellVairable, comp2ClRef);
		return returnReferences;
	}

	/**
	 * Resolves indirect references to codes in external codelists imported for this table
	 * @param publicationTable
	 * @param returnReferences
	 * @param retrievalManager
	 * @param cellVariables
	 */
	private void resolveImportedVariables(PublicationTableBean publicationTable, 
										  Set<ICrossReferenceBean<?>> returnReferences, 
										  SdmxBeanRetrievalManager retrievalManager, 
										  ValidationPublicationVariable cellVariables,
										  Map<String, ICrossReferenceBean<? extends EnumeratedListBean>> comp2ClRef) {
		cellVariables.setCellValueStore(EmptyPublicationTableCellValueStore.getInstance());
		OutputPublicationTable outputTable = new OutputPublicationTableImpl(publicationTable, cellVariables, null);
		
		//Check External Variables
		Map<String, Set<String>> externalVaraibles = cellVariables.getExternalVariables();
		for(PublicationVariableBean variable : publicationTable.getVariables()) {
			if(variable.getCodelistReference().getTargetReference() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
				Set<String> variableValues = externalVaraibles.get(variable.getId());
				if(variableValues != null) {
					for(String variableVal : variableValues) {
						
						returnReferences.add(new IndirectReferenceBean<>(publicationTable, toCodeRef(variable.getCodelistReference(), variableVal)));
					}
				}
			}
		}
		
		//Check Variables with DIM.VAL syntax
		Map<String, Set<String>> dotVariables = cellVariables.getDotVariables();
		for(String dotVariableId : dotVariables.keySet()) {
			if(comp2ClRef.containsKey(dotVariableId)){
				ICrossReferenceBean<? extends EnumeratedListBean> clRef = comp2ClRef.get(dotVariableId);
				if(clRef.getTargetReference() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
					for(String codeId : dotVariables.get(dotVariableId)) {
						returnReferences.add(new IndirectReferenceBean<>(publicationTable, toCodeRef(clRef, codeId)));
					}
				}
			}
		}
	}

	private void resolveConditionalVariableReferences(PublicationTableBean publicationTable, Set<ICrossReferenceBean<?>> returnReferences, Map<String, DataflowRef> aliasToFlow) {
		for(ConditionalVariable conVar : publicationTable.getConditionalVariables()) {
			String alias = conVar.getDataflowAlias();
			String dimID = conVar.getDimensionCondition();

			DataflowRef flowRef = aliasToFlow.get(alias);

			IURNSingle<DimensionBean> dimRef = URN.builder().toIdentifiable(flowRef.dsd.getURN(), SDMX_STRUCTURE_TYPE.DIMENSION, dimID).buildSingle(DimensionBean.class);
			returnReferences.add(new IndirectReferenceBean<>(publicationTable, dimRef));

			ICrossReferenceBean<CodelistBean> clRef = flowRef.enumRefs.get(dimID);
			if(clRef != null) {
				if(clRef.getTargetReference() == SDMX_STRUCTURE_TYPE.VALUE_LIST) {
					//Reference to Valuelist
					returnReferences.add(new IndirectReferenceBean<>(publicationTable, clRef.getReference()));
				} else {
					for(ConditionalVariableValues varVals : conVar.getConditionalVariableValues()) {
						//Reference to CodeID
						for(String codeId : varVals.getSourceIds()) {
							IURNSingle<CodeBean> codeUrn = toCodeRef(clRef, codeId);
							returnReferences.add(new IndirectReferenceBean<>(publicationTable, codeUrn));
						}
					}
				}
			}
		}
	}
	
	/**
	 * Resolved references table cell observation and calculation keys, i.e A:UK:EMP or A:=UK+FR:EMP
	 */
	private void resolveTableSeriesReferences(PublicationTableBean publicationTable, Set<ICrossReferenceBean<?>> returnReferences, ICellVariables cellVairable, Map<String, DataflowRef> aliasToFlow) {
		IPublicationTableCells tableSeries = new PublicationTableCells(publicationTable, cellVairable);
		
		Set<String> flowsInTable = new HashSet<>(aliasToFlow.size());

		for(PublicationTableBodyRow bodyRow : publicationTable.getBodyRows()) {
			for(PublicationTableBodyCell bodyCell : bodyRow.getTableCells()) {
				if(tableSeries.getObservationKey(bodyCell) == null) {
					ICellCalculation calcKey = tableSeries.getCalculationKey(bodyCell);
					if(calcKey != null) {
						for(ISeriesCalculation calc : calcKey.getSeriesCalculations()) {
							if(calc.getVariableToCell().size() > 0) {
								for(ICellKey inputKey : calc.getVariableToCell().values()) {
									flowsInTable.add(inputKey.getDataflowAlias());
									DataflowRef ref = aliasToFlow.get(inputKey.getDataflowAlias());
									processCellKey(ref, inputKey);
								}
							} else {
								ICellKey inputKey = calc.getOriginalExpression();
								flowsInTable.add(inputKey.getDataflowAlias());
								DataflowRef ref = aliasToFlow.get(inputKey.getDataflowAlias());
								processCellKey(ref, inputKey);
							}
						}
					}
				} else {
					ICellKey cellKey = tableSeries.getObservationKey(bodyCell);
					flowsInTable.add(cellKey.getDataflowAlias());
					DataflowRef ref = aliasToFlow.get(cellKey.getDataflowAlias());
					processCellKey(ref, cellKey);
				}
			}
		}

		for(String flowAlias : aliasToFlow.keySet()) {
			DataflowRef flowRef = aliasToFlow.get(flowAlias);
			for(String compId : flowRef.enumRefs.keySet()) {
				ICrossReferenceBean<CodelistBean> xsRef =  flowRef.enumRefs.get(compId);
				for(String codeId : flowRef.uniqueCodeIds.get(compId)) {
					IURNSingle<CodeBean> codeUrn = URN.builder().urn(xsRef.getReference()).structure(SDMX_STRUCTURE_TYPE.CODE).identifableId(codeId).buildAbsolute(CodeBean.class);
					IndirectReferenceBean<CodeBean> indirectRef = new IndirectReferenceBean<>(publicationTable, codeUrn);
					returnReferences.add(indirectRef);
				}
			}
		}

		for(String flowAlias : flowsInTable) {
			//For each dataflow, add all the DSD Dimensions in as they are all used in the key descriptor
			DataflowRef ref = aliasToFlow.get(flowAlias);
			if(ref != null) {
				for(DimensionBean dim : ref.dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
					returnReferences.add(new IndirectReferenceBean<>(publicationTable, dim.getURN()));
				}
				for(MeasureDimensionBean mDim : ref.dsd.getMeasures()) {
					returnReferences.add(new IndirectReferenceBean<>(publicationTable, mDim.getURN()));
				}
			}
		}
	}
	
	/**
	 * Converts a Codelist reference to a Code reference
	 * @param codelistRef the check that this is a Codelist should have already been performed before calling this method
	 * @param codeId
	 * @return
	 */
	private IURNSingle<CodeBean> toCodeRef(ICrossReferenceBean<? extends EnumeratedListBean> codelistRef, String codeId) {
		return URN.builder().toIdentifiable(codelistRef.getReference(), SDMX_STRUCTURE_TYPE.CODE, codeId).buildSingle(CodeBean.class);
	}

	private class DataflowRef {
		private DataStructureBean dsd;
		private String[] dimIds;
		private Map<String, Set<String>> uniqueCodeIds = new HashMap<>();
		private Map<String, ICrossReferenceBean<CodelistBean>> enumRefs = new HashMap<>();

		public DataflowRef(DataStructureReferences dsRefs) {
			this.dsd = dsRefs.getDsd();

			List<DimensionBean> dimensions = dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION);
			this.dimIds = new String[dimensions.size()];
			for(int i=0; i < dimensions.size(); i++) {
				DimensionBean dim = dimensions.get(i);
				ICrossReferenceBean enumRef = dsRefs.getEnumerationReferences().get(dim);
				if(enumRef != null && enumRef.getTargetReference() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
					enumRefs.put(dim.getId(), enumRef);
					uniqueCodeIds.put(dim.getId(), new HashSet<>());
					this.dimIds[i] = dim.getId();
				}
			}
		}
	}

	private void processCellKey(DataflowRef ref, ICellKey cellKey) {
		if(cellKey.getSeriesKey() != null) {
			String[] sk = SeriesUtil.splitKey(cellKey.getSeriesKey());
			for(int i = 0; i < Math.max(ref.dimIds.length, sk.length); i++) {
				String dimId = ref.dimIds[i];
				if(dimId != null && sk[i].length()>0) {
					String codeId = sk[i];
					if(codeId.contains("|")) {
						codeId = codeId.substring(0, codeId.indexOf("|"));
					}
					ref.uniqueCodeIds.get(dimId).add(codeId);
				}
			}
		}
	}

}
