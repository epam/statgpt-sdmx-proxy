package io.sdmx.publicationtable.util;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.core.data.model.formatting.ObservationFormatting;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.im.superbeans.builder.DataflowSuperBeanBuilder;
import io.sdmx.im.util.model.TestDSDUtil;
import io.sdmx.im.util.model.TestDataflowUtil;
import io.sdmx.im.util.model.testinstances.TestDSDInstances;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.model.bean.mutable.ConditionalVariableValuesMutableImpl;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableMutableBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class TestPublicationTableInstances {

	/**
	 * @return simple table definition with fixed observation keys, including time period
	 */
	public static PublicationTableBean fixedObs() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("2010");
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2010");
		bodyRow.addTableCell().setObservationKey("A:UK:UEMP:2010");
		
		bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("2011");
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2011");
		bodyRow.addTableCell().setObservationKey("A:UK:UEMP:2011");

		return bean.getImmutableInstance();
	}
	
	/**
	 * @return fixedObs() table with a scale factor of 2 on the Dataflow 
	 */
	public static PublicationTableBean scaleFactor(int scalingFactor) {
		PublicationTableMutableBean bean = (PublicationTableMutableBean)fixedObs().getMutableInstance();
		List<IObservationFormatting> obsFormatting = new ArrayList<>();
		obsFormatting.add(ObservationFormatting.get().scalingFactor(scalingFactor));
		bean.setObservationFormatting(obsFormatting);
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return simple table definition with variable placeholders which are imported from an external codelist
	 */
	public static PublicationTableBean externalVariables() {
		PublicationTableMutableBean bean = (PublicationTableMutableBean) fixedObs().getMutableInstance();
		
		bean.addVariableReference("VAR_CL").setCodelistReference(new StructureReferenceBeanImpl("TEST", "CL_VAR", "1.0", SDMX_STRUCTURE_TYPE.CODE_LIST));
		bean.addVariableReference("VAR_VL").setCodelistReference(new StructureReferenceBeanImpl("TEST", "VL_VAR", "1.0", SDMX_STRUCTURE_TYPE.VALUE_LIST));
		
		bean.getHeaderRows().get(0).getHeaderCells().get(0).setLabel("$(VAR_CL.A) and $(VAR_CL.Z)");
		bean.getHeaderRows().get(0).getHeaderCells().get(1).setLabel("$(VAR_VL.A)");
		

		return bean.getImmutableInstance();
	}
	
	/**
	 * @param compId optional
	 * @param defaultMv optional 
	 * @param repMapId optional
	 * @return fixedObs publication table for rules on how to create missing values
	 */
	public static PublicationTableBean missingValue(String compId, String defaultMv, String repMapId) {
		PublicationTableMutableBean bean = (PublicationTableMutableBean) fixedObs().getMutableInstance();
		StructureReferenceBean repMap = repMapId == null ? null : new StructureReferenceBeanImpl("TEST", repMapId, "1.0", SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
		bean.addMissingValueRules().setComponentId(compId).setDefaultMissingValue(defaultMv).setMissingValueMapping(repMap);
		return bean.getImmutableInstance();
	}

	/**
	 * @return simple table definition with levels
	 */
	public static PublicationTableBean levels() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("Employed");
		
		bean.addBodyRow().setHeadCell().setLabel("UK Data"); 			//Row 1 Level 1
		bean.addBodyRow().setHeadCell().setLabel(">Employment"); 		//Row 2 Level 2

		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();     //Row 3
		bodyRow.setHeadCell().setLabel(">>2010");
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2010");      
		bodyRow = bean.addBodyRow();                                     
		bodyRow.setHeadCell().setLabel(">>2011"); 						//Row 4
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2011");

		bean.addBodyRow().setHeadCell().setLabel(">UnEmployment"); 	    //Row 5  Level 2
		bodyRow = bean.addBodyRow();                                    //Row 6 
		bodyRow.setHeadCell().setLabel(">>2010");
		bodyRow.addTableCell().setObservationKey("A:UK:UEMP:2010");
		bodyRow = bean.addBodyRow(); 								    //Row 7
		bodyRow.setHeadCell().setLabel(">>2011");
		bodyRow.addTableCell().setObservationKey("A:UK:UEMP:2011");
		

		bean.addBodyRow().setHeadCell().setLabel("French Data");        //Row 8
		bean.addBodyRow().setHeadCell().setLabel(">Employment"); 		//Row 9 Level 2
		bodyRow = bean.addBodyRow();   
		bodyRow.setHeadCell().setLabel(">>2010");
		bodyRow.addTableCell().setObservationKey("A:FR:EMP:2010");
		bodyRow = bean.addBodyRow();                                    //Row 10
		bodyRow.setHeadCell().setLabel(">>2011");
		bodyRow.addTableCell().setObservationKey("A:FR:EMP:2011");

		bean.addBodyRow().setHeadCell().setLabel(">UnEmployment"); 	    //Row 11 Level 2
		bodyRow = bean.addBodyRow();                                    //Row 12
		bodyRow.setHeadCell().setLabel(">>2010");
		bodyRow.addTableCell().setObservationKey("A:FR:UEMP:2010");
		bodyRow = bean.addBodyRow();                                    //Row 13 
		bodyRow.setHeadCell().setLabel(">>2011");
		bodyRow.addTableCell().setObservationKey("A:FR:UEMP:2011");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return simple table definition with levels
	 */
	public static PublicationTableBean skipLevels() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("Employed");
		
		bean.addBodyRow().setHeadCell().setLabel(">UK Data"); 			//Row 1 Level 1

		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();     //Row 3
		bodyRow.setHeadCell().setLabel(">>>2010");
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2010");      
		bodyRow = bean.addBodyRow();                                     
		bodyRow.setHeadCell().setLabel(">>>2011"); 						//Row 4
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:2011");

	

		bean.addBodyRow().setHeadCell().setLabel(">French Data");        //Row 8
		bodyRow = bean.addBodyRow();   
		bodyRow.setHeadCell().setLabel(">>>2010");
		bodyRow.addTableCell().setObservationKey("A:FR:EMP:2010");
		bodyRow = bean.addBodyRow();                                    //Row 10
		bodyRow.setHeadCell().setLabel(">>>2011");
		bodyRow.addTableCell().setObservationKey("A:FR:EMP:2011");

		
		return bean.getImmutableInstance();
	}
	

	/**
	 * @return series are fixed, but time is variable
	 */
	public static PublicationTableBean fixedObsVariableTime() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		bean.addName("en", "Employment $(P)");

		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("UK");
		bodyRow.addTableCell().setObservationKey("A:UK:EMP");
		bodyRow.addTableCell().setObservationKey("A:UK:UEMP");
		
		bodyRow.setHeadCell().setLabel("FR");
		bodyRow.addTableCell().setObservationKey("A:FR:EMP");
		bodyRow.addTableCell().setObservationKey("A:FR:UEMP");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with series containing 1 variable dimension
	 */
	public static PublicationTableBean variableDimensions1() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("$(REF_AREA)");
		bodyRow.addTableCell().setObservationKey("A::EMP");
		bodyRow.addTableCell().setObservationKey("A::UEMP");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with series containing 2 variable dimensionss
	 */
	public static PublicationTableBean variableDimensions2() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();

		bean.addName("en", "Employment for $(REF_AREA) $(SEX)");
		bean.addDescription("en", "For Time Period $(P)");
		
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("$(REF_AREA) $(SEX)");
		bodyRow.addTableCell().setObservationKey("A:::EMP");
		bodyRow.addTableCell().setObservationKey("A:::UEMP");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with series containing 3 variable dimensions - includes rowspan and colspan in header cells
	 */
	public static PublicationTableBean variableDimensions3() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		//Row 1
		row.addHeaderCell().setRowSpan(2).setLabel("$(P)");
		row.addHeaderCell().setColSpan(2).setLabel("$(REF_AREA)");
		
		//Row 2
		row = bean.addHeaderRow();
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("$(SEX) Age: $(AGE)");
		bodyRow.addTableCell().setObservationKey("A::::EMP");
		bodyRow.addTableCell().setObservationKey("A::::UEMP");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table with multiple dataflows, each with variable dimensions, one does not overlap
	 */
	public static PublicationTableBean variableDimensionsMultipleFlows() {
		PublicationTableMutableBean bean = getMutable();
		bean.setDataflowReferences(new ArrayList<>());
		bean.addDataflowReference().setAlias("DF1").setDataflowRef(new StructureReferenceBeanImpl("TEST", "BANKING1", "1.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
		bean.addDataflowReference().setAlias("DF2").setDataflowRef(new StructureReferenceBeanImpl("TEST", "BANKING2", "1.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
		bean.addDataflowReference().setAlias("DF3").setDataflowRef(new StructureReferenceBeanImpl("TEST", "BANKING3", "1.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("Employed $(REF_AREA)");
		row.addHeaderCell().setLabel("UnEmployed  $(REF_AREA)");
		row.addHeaderCell().setLabel("Employed  $(REF_AREA) $(SEX)");
		row.addHeaderCell().setLabel("Total: $(INDICATOR) $(SEX) $(AGE)");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("2010");
		bodyRow.addTableCell().setObservationKey("DF1.A::EMP:2010");	//"FREQ", "REF_AREA", "INDICATOR"
		bodyRow.addTableCell().setObservationKey("DF1.A::UEMP:2010");   //"FREQ", "REF_AREA", "INDICATOR"
		bodyRow.addTableCell().setObservationKey("DF2.A:::EMP:2010");	//"FREQ", "REF_AREA", "SEX", "INDICATOR"
		bodyRow.addTableCell().setObservationKey("DF3.A:TOT::::2010");  	//"FREQ", "REF_AREA", "SEX", "AGE", "INDICATOR"

		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with calculated series where calculations are inline =A:UK+FR+DE:EMP)
	 */
	public static PublicationTableBean calculatedCellsInline() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("UK");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:EMP]+10");
		bodyRow.addTableCell().setObservationKey(":=10+[A:UK:UEMP]");
		bodyRow.setHeadCell().setLabel("DE");
		bodyRow.addTableCell().setObservationKey(":=[A:DE:EMP]-10");
		bodyRow.addTableCell().setObservationKey(":=10-[A:DE:UEMP]");
		bodyRow.setHeadCell().setLabel("Total");
		bodyRow.addTableCell().setObservationKey(":=[A:(UK+FR+DE):EMP]");
		bodyRow.addTableCell().setObservationKey(":=[A:(UK+FR+DE):UEMP]");
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with observation formatted defined
	 */
	public static PublicationTableBean observationFormatting() {
		PublicationTableMutableBean bean = (PublicationTableMutableBean) fixedObs().getMutableInstance();
		
		List<IObservationFormatting> obsFormatting = new ArrayList<>();
		obsFormatting.add(new ObservationFormatting(CollectionUtil.toList("=A:UK+FR:EMP", "=A:+UEMP"), null, 2, null, true, true, false, RoundingMode.HALF_UP));
		obsFormatting.add(new ObservationFormatting(null, Locale.ENGLISH, 1, null, false, false, true, RoundingMode.DOWN));
		bean.setObservationFormatting(obsFormatting);
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with calculated series where calculations are multiple series =[key1]+[key2]
	 */
	public static PublicationTableBean calculatedCellsMultiple() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("Employed");
		row.addHeaderCell().setLabel("UnEmployed");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("UK");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:EMP]+10");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:UEMP]+20");
		bodyRow.setHeadCell().setLabel("DE");
		bodyRow.addTableCell().setObservationKey(":=[A:DE:(EMP+UEMP)]");
		bodyRow.setHeadCell().setLabel("Total");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:EMP]+[A:FR:EMP]+[A:DE:EMP]");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:UEMP]+[A:FR:UEMP]+[A:DE:UEMP]");
		
		
		
		return bean.getImmutableInstance();
	}
	
	
	/**
	 * @return table definition where variable values are conditional on the value of REF_AREA which is a variable Dimension
	 */
	public static PublicationTableBean conditionalVariables() {
		PublicationTableMutableBean bean = (PublicationTableMutableBean) variableDimensions1().getMutableInstance();
		
		ConditionalVariableMutable cv = bean.addConditionalVariable();
		cv.setDimensionCondition("REF_AREA");
		cv.setFlowAlias("");
		cv.setName("Banknotes");
		cv.setId("BANKNOTE");
		
		ConditionalVariableValuesMutable cvVals = new ConditionalVariableValuesMutableImpl();
		cvVals.setMappedId("NOTE1");
		cvVals.addMappedValue("UK", "£5");
		cvVals.addMappedValue("FR", "5Eur");
		cvVals.addMappedValue("US", "$5");
		cv.addConditionalVariableValues(cvVals);
		
		cvVals = new ConditionalVariableValuesMutableImpl();
		cvVals.setMappedId("NOTE2");
		cvVals.addMappedValue("UK", "£10");
		cvVals.addMappedValue("FR", "10 Eur");
		cvVals.addMappedValue("US", "$10");
		cv.addConditionalVariableValues(cvVals);
		
		return bean.getImmutableInstance();
	}
	
	/**
	 * @return table definition with calculated series where calculations contain variable placeholders  =  [A::EMP] + [A::UEMP]
	 */
	public static PublicationTableBean calculatedCellsVariableDimensions() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("$(INDICATOR)");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("UK");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:]+10");
		bodyRow.setHeadCell().setLabel("DE");
		bodyRow.addTableCell().setObservationKey(":=[A:DE:]+20");
		bodyRow.setHeadCell().setLabel("Total");
		bodyRow.addTableCell().setObservationKey(":=[A:UK:]+[A:FR:]+[A:DE:]");
		
		return bean.getImmutableInstance();
	}
	
	
	/**
	 * @return table with multiple frequencies built off base frequency
	 */
	public static PublicationTableBean multipleFrequencies() {
		PublicationTableMutableBean bean = getMutable();
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		
		row.addHeaderCell().setLabel("$(M(P))");
		row.addHeaderCell().setLabel("$(A(P))");
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("$(S(P))");
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("UK");
		bodyRow.addTableCell().setObservationKey("M:UK:EMP:M(P)");	
		bodyRow.addTableCell().setObservationKey("A:UK:EMP:A(P)");   
		bodyRow.addTableCell().setObservationKey("Q:UK:EMP:P");	
		bodyRow.addTableCell().setObservationKey("S:UK:EMP:S(P)");	

		return bean.getImmutableInstance();
	}
	
	/**
	 * @return a table whose INDICATOR value is based on the value of the REF_AREA (derived from an external representation map referenced from the publication table)
	 */
	public static PublicationTableBean variableMappings() {
		PublicationTableMutableBean bean = getMutable();
		bean.addVariableMapping().addOutputDimensionId("INDICATOR").setInputDimensionId("REF_AREA").setMappingRules(new StructureReferenceBeanImpl("TEST", "VAR_DIM_REPMAP", "1.0", SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP));
		
		PublicationTableHeadRowMutable row = bean.addHeaderRow();
		row.addHeaderCell().setLabel("$(REF_AREA)").setColSpan(2);
		row = bean.addHeaderRow();
		row.addHeaderCell().setLabel("$(P)");
		row.addHeaderCell().setLabel("$(P-1)");
		
		
		PublicationTableBodyRowMutable bodyRow = bean.addBodyRow();
		bodyRow.setHeadCell().setLabel("$(INDICATOR)");
		bodyRow.addTableCell().setObservationKey("A::");		//2 variable dimensions, but INDICATOR is derived from the REF_AREA as per the mapping rule
		bodyRow.addTableCell().setObservationKey("A:::P-1");
		
		return bean.getImmutableInstance();
	}
	
	
	
	public static DataflowSuperBean geDataflow(String alias, int dimensions) {
		SdmxBeanRetrievalManager brm = getRetrievalManager(alias, dimensions);
		DataflowBean flow = brm.getBean(URN.builder().agencyId("TEST").maintId("BANKING").version("1.0").buildSingle(DataflowBean.class));
		return DataflowSuperBeanBuilder.getInstance().build(flow, brm, null, null);
	}
	
	public static InMemoryRetrievalManager getRetrievalManager(String alias, int dimensions) {
		DataStructureBean dsd = getDSD("BANKING", dimensions);
		
		SdmxBeans beans = TestDSDInstances.generateReferences(dsd, true);
		DataflowBean flow = TestDataflowUtil.generateDataflow(dsd.asReference());

		
		DataflowMutableBean dfMutable = flow.getMutableInstance();
		dfMutable.addName("en", "Test Banking");
		dfMutable.addDescription("en", "Test Banking Description");
		dfMutable.setAgencyId("TEST");
		dfMutable.setId("BANKING");
		dfMutable.setVersion("1.0");
		beans.addIdentifiable(dfMutable.getImmutableInstance());
		return new InMemoryRetrievalManager(beans);
	}
	
	public static DataStructureBean getDSD(String id, int dimensions) {
		String[] dims = null;
		switch(dimensions) {
		case 3 : dims = new String[] {"FREQ:CL", "REF_AREA:CL","INDICATOR:CL"}; break;
		case 4 : dims = new String[] {"FREQ:CL", "REF_AREA:CL", "SEX:CL", "INDICATOR:CL"}; break;
		case 5 : dims = new String[] {"FREQ:CL", "REF_AREA:CL", "SEX:CL", "AGE", "INDICATOR:CL"}; break;
		}
		DataStructureBean dsd = TestDSDUtil.generateDSD(true, true, dims);
		 dsd.getMutableInstance();
		
		return ((DataStructureMutableBean) dsd.getMutableInstance().changeIdentifiers("TEST", id, "1.0")).getImmutableInstance();
	}
	
	public static PublicationTableMutableBean getMutable() {
		PublicationTableMutableBean bean = new PublicationTableMutableBeanImpl();
		bean.setAgencyId("TEST");
		bean.setId("TEST");
		bean.setVersion("1.0.0");
		bean.addName("en", "Test PT");
		bean.addDataflowReference().setAlias("").setDataflowRef(new StructureReferenceBeanImpl("TEST", "BANKING", "1.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
		return bean;
	}
}
