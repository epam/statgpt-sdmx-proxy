package io.sdmx.publicationtable.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.variable.Variable;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.NumberUtils;

public class FootnoteUtil {
	
	public static String getFootnote(String footnote, PublicationTableBean table, ICellVariables variables) {
		int footnoteIdx;
		List<String> variablePlaceholders = null;
		if(footnote.contains(",")) {
			String[] split = footnote.split(",");
			footnoteIdx = Integer.parseInt(split[0]);
			variablePlaceholders = new ArrayList<>(split.length-1);
			for(int i=1; i < split.length; i++) {
				variablePlaceholders.add(split[i].trim());	
			}
		} else {
			footnoteIdx = Integer.parseInt(footnote);
		}
		
		if(table.getFootnotes().size() < footnoteIdx) {
			int maxLength = table.getFootnotes().size();
			throw new SdmxSemmanticException("Can not get footnote at index '"+footnoteIdx+"' max lengh = "+maxLength);
		}
		String footnoteText = table.getFootnotes().get(footnoteIdx-1).getTextForCurrentLanguage();
		
		//replace placeholder in footnote i.e. A:{1}:{2}:OBS_COMMENT with values from the variablePlaceholders
		if(variablePlaceholders != null) {
			Exp exp = Exp.get().setSupportLevels(false).blockCopy(CHARS.OPEN_BRACE, CHARS.CLOSE_BRACE).parse(footnoteText);
			StringBuilder sb = new StringBuilder();
			for(int i=0; i < exp.size(); i++) {
				String block = exp.getBlock(i);
				int level = exp.getLevel(i);
				if(level ==0) {
					if(NumberUtils.isInteger(block, false)) {
						int placeholder = Integer.parseInt(block) - 1;
						if(variablePlaceholders.size() > placeholder) {
							sb.append(variablePlaceholders.get(placeholder));
						}
					} else {
						sb.append("{"+block+"}");
					}
				} else {
					sb.append(block);
				}
			}
			footnoteText = sb.toString();
		}
		//Footnote may contain variables, i.e. $(A:{1}:{2}:EMP:OBS_COMMENT)
		Variable variable = Variable.build(footnoteText);
		if(!variable.isVariable() && variable.getVariables().size() ==0) {
			return footnoteText;
		}
		if(variable.getVariables().size() == 0) {
			//just a variable
			String var = variable.getText();
			return variables.getVariableValue(var);
		}
		StringBuilder sb = new StringBuilder();  //replace variables
		walkVariables(variable.getVariables(), variables, sb);
		return sb.toString();
	}
	
	private static void walkVariables(List<Variable> vars, ICellVariables variables, StringBuilder sb) {
		for(Variable var : vars) {
			String text = var.getText();
			if(text != null) {
				if(var.isVariable()) {
					String value = variables.getVariableValue(var.getText());
					if(value != null) {
						sb.append(value);
					}
				} else {
					sb.append(var.getText());
				}
			} else {
				StringBuilder subBuilder = var.isVariable() ? new StringBuilder() : sb;
				walkVariables(var.getVariables(), variables, subBuilder);
				if(var.isVariable()) {
					String variableValue = variables.getVariableValue(subBuilder.toString());
					if(variableValue != null) {
						sb.append(variableValue);
					}
				}
			}
		}
	}
	
	public static boolean isFootnote(String str) {
		if(str.startsWith("$(")) {
			str = str.substring(2, str.length()-1);
		}
		//starts with a number up to the first ',' (if it exists)
		return NumberUtils.startWithNumber(str, ",".charAt(0));
	}
}
