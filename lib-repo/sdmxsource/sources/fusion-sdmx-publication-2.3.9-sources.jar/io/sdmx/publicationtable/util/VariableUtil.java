package io.sdmx.publicationtable.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Methods for extracting or replacing variable values in strings
 *
 */
public class VariableUtil {
	private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\$\\((\\w*)\\)");
	private static char DOLLAR = "$".charAt(0);
	
	/**
	 * @return true if the string matches the pattern $(....)
	 */
	public static boolean isVariable(String str) {
		if(str.charAt(0) != DOLLAR) {
			return false;
		}
		return VARIABLE_PATTERN.matcher(str).matches();
	}
	
	/**
	 * @return for when isVariable == true, this will return the variable value isVariable
	 */
	public static String getVariable(String str) {
		Matcher matcher = VARIABLE_PATTERN.matcher(str);
		if(matcher.matches()) {
			return matcher.group(1);
		}
		return null;
	}
	
	/**
	 * Extracts 
	 * @param inputString
	 * @param variables
	 * @return
	 */
	public static String replaceVariables(String inputString, ICellVariables variables) {
		if(!ObjectUtil.validString(inputString)) {
			return null;
		}
		//Split the input string into blocks, 
		//whenever we encounter a $ create a block at level -1
		//whenever we encounter a (  )  copy the whole block at level 0
		//all other text is a block at level 1
		//we can use this to find variables which are defined as $(var) as it is level 0 text which is preceeded by level -1, anything else is just text
		Exp exp = Exp.get("$".charAt(0)).setSupportLevels(false).blockCopy("(".charAt(0), ")".charAt(0)).parse(inputString);
		if(exp.size() == 1) {
			//protection around the inputString=(Some Text ($var)) where the block size is 1, but it contains variables in it
			if(exp.getBlock(0).equals(inputString)) {
				return inputString;
			}
			//This is a block  (...) 
			return "("+replaceVariables(exp.getBlock(0), variables)+")";
		}
		
		//This string contains multiple blocks, so it could have a mix of text and variables
		boolean variablePrefix = false;  //set to true when we encounter level -1
		StringBuilder sb = new StringBuilder();
		for(int i=0; i < exp.size(); i++) {
			int level = exp.getLevel(i);
			String block = exp.getBlock(i);
			if(level == 0) {
				if(variablePrefix) {
					//This is a varaible
					block = variables.getVariableValue(block);
				} else {
					//Protection around the inputString=Some text(and more ($var)) where the non variable block contains variables in it
					//put the paranthesis back on
					block = "("+replaceVariables(block, variables)+")";
				}
			} else if(variablePrefix) {
				//The variable prefix '$' was not followed by a variable block, so treat it as text
				sb.append("$");
			}
			variablePrefix = level == -1;
			if(!variablePrefix && block != null) {
				sb.append(block);
			}
		}
		return sb.toString();
	}

}
