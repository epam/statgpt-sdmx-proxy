package io.sdmx.publicationtable.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.im.data.query.DataQueryImpl;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.utils.core.collection.CollectionUtil;

public class PublicationTableUtil {


	public static Map<String, DataQuery> buildDataQueries(IPublicationTableCells tableSeries) {
		ICellVariables variables = tableSeries.getVariables();
		Set<String> dfAlias = variables.getDataflowAlias();
		Map<String, DataQuery> queries = new HashMap<>(dfAlias.size());
		for(String alias : dfAlias) {
			queries.put(alias, buildDataQuery(tableSeries, alias));
		}
		return queries;
	}

	public static DataQuery buildDataQuery(IPublicationTableCells tableSeries, String alias) {
		ICellVariables variables = tableSeries.getVariables();
		DataflowBean flow = variables.getDataflow(alias);
		DataStructureBean dsd = variables.getDataStructure(alias);
		DataQuery dq = DataQueryImpl.buildEmptyQuery(dsd, flow, DATA_QUERY_DETAIL.FULL);
		Set<String> series = cellsToSeries(tableSeries.getCellsForFlow(alias));
		if(dsd.getTimeDimension() != null) {
			SdmxPeriod period = tableSeries.getFlowPeriod(alias);
			if(period != null) {
				dq.setDateFrom(period.getStartPeriod());
				dq.setDateTo(period.getEndPeriod());
			} else {
				dq.setLastNObs(1);
			}
		}
		dq.addSeriesSelection(CollectionUtil.toArray(series));
		return dq;
	}

	private static Set<String> cellsToSeries(List<ICellKey> cells) {
		Set<String> series = new HashSet<>(cells.size());

		for(ICellKey cellKey : cells) {
			if(cellKey.getObsTime() == null && cellKey.getTimeExpression() != null) {
				//There is no time period, but there is an expression - only include this series if the expression
				//starts with P
				if(!cellKey.getTimeExpression().startsWith("P")) {
					continue;
				}
			}
			series.add(cellKey.getSeriesKey());
		}
		if(cells.size() > 0 && series.size() == 0) {
			throw new SdmxSemmanticException("Unable to determine base time period 'P' from Cell Keys. Ensure at least one cell key refers to P to set the base period");
		}
		return series;
	}
}
