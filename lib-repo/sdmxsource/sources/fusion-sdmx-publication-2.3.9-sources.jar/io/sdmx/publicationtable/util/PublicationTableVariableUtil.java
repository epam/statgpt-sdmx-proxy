package io.sdmx.publicationtable.util;

import io.sdmx.api.chars.CHARS;
import io.sdmx.utils.core.expression.Exp;

/**
 * Utility for processing variable strings specific to publication tables
 */
public class PublicationTableVariableUtil {

	
	/**
	 * Split on period, copy anything between [ and ]
	   The output of this is between 1 and 3 parts
	   part 1 = main variable
	   part 2 = dot variable
	   part 3 = square brackets variable
	   
	   Example 1
	   REF_AREA = [REF_AREA,null,null]
	   REF_AREA.UK = [REF_AREA,UK,null]
	   REF_AREA[id] = [REF_AREA,null,id]
	   REF_AREA.UK[desc] = [REF_AREA,UK,description]
	   
	 * @param variable
	 * @return
	 */
	public static String[] getVariableParts(String variable) {
		String[] parts = new String[3];
		if(variable == null) {
			return parts;
		}
		Exp exp = Exp.build(CHARS.PERIOD).setSupportLevels(false).blockCopy(CHARS.OPEN_BRACKET, CHARS.CLOSE_BRACKET).parse(variable);
		parts[0] = exp.getBlock(0);
		for(int i=1; i < exp.size(); i++) {
			int level = exp.getLevel(i);
			if(level < 0) {
				continue;
			}
			String part = exp.getBlock(i);
			
			if(level == 0) {
				parts[2] = part;
			} else {
				parts[1] = part;
			}
		}
		
		return parts;
	}
	
}
