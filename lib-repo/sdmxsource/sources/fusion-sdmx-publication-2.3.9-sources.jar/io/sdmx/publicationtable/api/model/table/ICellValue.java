package io.sdmx.publicationtable.api.model.table;

import java.util.List;

/**
 * Represents a value in the table cell of a publication table, along with the corresponding key
 */
public interface ICellValue {
	
	/**
	 * @return not null   if the cell represents the result of a calculation
	 */
	ICellCalculation getCellCalculation();
	
	/**
	 * @return the cell value - not null empty string allowed
	 */
	String getCellValue();
	
	/**
	 * @return nullable - the cell key is typically the observation key, but for calculated observations this value can be a user defined key, or a generated key
	 * for free text cells this will be null
	 */
	String getCellKey();
	
	/**
	 * @return nullable the dataflow alias for the cell key
	 */
	String getDataflowAlias();
	
	List<String> getFootnotes();
}
