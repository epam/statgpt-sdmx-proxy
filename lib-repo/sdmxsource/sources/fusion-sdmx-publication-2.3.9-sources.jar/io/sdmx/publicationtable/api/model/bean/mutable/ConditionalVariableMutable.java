package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines how a variable e.g. REF_AREA maps to another variable e.g. CURRENCY_DEMON, so for example UK may map to the denominations UKP50, UKP20, UKP10, UKP5 
 * whereas USD would map to $100, $50,$20,$10,$5
 */
public interface ConditionalVariableMutable extends MutableBean {
	
	/**
	 * Returns the id of this variable, for example BANKNOTES
	 * @return
	 */
	String getId();
	ConditionalVariableMutable setId(String id);
	
	/**
	 * Returns the name of this variable
	 * @return
	 */
	String getName();
	ConditionalVariableMutable setName(String name);
	
	/**
	 * Returns the conditional dimension, for example REF_AREA
	 * @return
	 */
	String getDimensionCondition();
	ConditionalVariableMutable setDimensionCondition(String dimId);
	
	/**
	 * @return the dataflow alias to which the condition is for
	 */
	String getFlowAlias();
	ConditionalVariableMutable setFlowAlias(String alias);
	
	/**
	 * Returns the condition map based on the id of the Dimension code
	 * @param id
	 * @return
	 */
	List<ConditionalVariableValuesMutable> getConditionalVariableValues();
	ConditionalVariableMutable addConditionalVariableValues(ConditionalVariableValuesMutable values);
	
}
