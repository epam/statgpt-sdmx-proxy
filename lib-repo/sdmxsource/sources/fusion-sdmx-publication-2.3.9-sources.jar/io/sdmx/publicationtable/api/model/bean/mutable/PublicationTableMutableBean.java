package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;

/**
 * Contains the full definition of a publication table, 
 * 
 * Table title is the Name of this bean, and subtitle is the description, both of which can contain variables such as $(TIME_PERIOD) or $(MEASURE.ID)
 */
public interface PublicationTableMutableBean extends MaintainableMutableBean{
	
	/**
	 * Returns the table footer text for example
	 * 
	 * <sup>1</sup> Data are incomplete. See Table A2 for a list of countries that report non-bank subsectors.
	 * 
	 * @return
	 */
	List<TextTypeMutableBean> getFootnotes();
	void setFootnotes(List<TextTypeMutableBean> footnotes);
	void addFootnote(TextTypeMutableBean footnote);
	void addFootnote(String footnote);
	
	/**
	 * Returns a reference to all the variables used
	 * @return
	 */
	List<PublicationVariableMutableBean> getVariableReferences();
	void setVariableReferences(List<PublicationVariableMutableBean> refs);
	void addVariableReference(PublicationVariableMutableBean ref);	
	PublicationVariableMutableBean addVariableReference(String id);	
	
	
	/**
	 * Returns the list of table header rows 
	 * @return
	 */
	List<PublicationTableHeadRowMutable> getHeaderRows();
	void setHeaderRows(List<PublicationTableHeadRowMutable> rows);
	void addHeaderRow(PublicationTableHeadRowMutable row);
	PublicationTableHeadRowMutable addHeaderRow();
	
	/**
	 * Returns the list of table body rows 
	 * @return
	 */
	List<PublicationTableBodyRowMutable> getBodyRows();
	void setBodyRows(List<PublicationTableBodyRowMutable> rows);
	void addBodyRow(PublicationTableBodyRowMutable row);
	PublicationTableBodyRowMutable addBodyRow();
	
	/**
	 * Returns a list of the conditional variables used for this table
	 * @return
	 */
	List<ConditionalVariableMutable> getConditionalVariables();
	void setConditionalVariables(List<ConditionalVariableMutable> rows);
	void addConditionalVariable(ConditionalVariableMutable row);
	ConditionalVariableMutable addConditionalVariable();
	
	/**
	 * Returns a list of dataflow references for this table
	 * @return
	 */
	List<PublicationTableDataflowMutable> getDataflowReferences();
	void setDataflowReferences(List<PublicationTableDataflowMutable> rows);
	void addDataflowReference(PublicationTableDataflowMutable row);
	PublicationTableDataflowMutable addDataflowReference();

	StructureReferenceBean getTimeFormatMapping();
	PublicationTableMutableBean setTimeFormatMapping(StructureReferenceBean ref);
	
	/**
	 * @return optional missing value rules
	 */
	PublicationTableMVMutableBean getMissingValueRules();
	PublicationTableMVMutableBean addMissingValueRules();
	PublicationTableMutableBean setMissingValueRules(PublicationTableMVMutableBean rules);
	
	
	List<PublicationTableVariableMappingMutableBean> getVariableMapping();
	PublicationTableVariableMappingMutableBean addVariableMapping();
	PublicationTableMutableBean setMissingValueRules(List<PublicationTableVariableMappingMutableBean> rules);
	
	
	/**
	 * @return formatting to use for the observation values - empty string mapping represents a global rule, other strings are mapped on a series key
	 * or partial key in the format A:B:C
	 */
	List<IObservationFormatting> getObservationFormatting();
	void setObservationFormatting(List<IObservationFormatting> obsFormatting);
	
	/**
	 * Override from MaintainableMutableBean
	 */
	@Override
	PublicationTableBean getImmutableInstance();
}
