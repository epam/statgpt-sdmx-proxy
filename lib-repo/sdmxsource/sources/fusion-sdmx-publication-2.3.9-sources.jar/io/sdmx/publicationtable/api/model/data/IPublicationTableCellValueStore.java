package io.sdmx.publicationtable.api.model.data;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.publicationtable.api.model.table.IObsKey;

/**
 * provides access to the resolved value for a publication table cell
 */
public interface IPublicationTableCellValueStore {

	/**
	 * @param cell
	 * @return the resolved value for the cell
	 */
	ICellValue getCellValue(PublicationTableBodyCell cell);
	
	/**
	 * @param obsKey
	 * @return an observation's measure or attribute value based on the obskey
	 */
	String getObsValue(IObsKey obsKey);
	
	/**
	 * @return true if there is data for this table
	 */
	boolean hasData();
	
}
