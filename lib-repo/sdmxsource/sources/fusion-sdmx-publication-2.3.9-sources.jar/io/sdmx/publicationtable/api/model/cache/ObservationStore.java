package  io.sdmx.publicationtable.api.model.cache;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.data.Observation;

public interface ObservationStore {

	/**
	 * Returns the observation value for the series key, and time period combination
	 * 
	 * @return
	 */
	Observation getObservationValue(PublicationTableBodyCell bodyCell);
	
	/**
	 * Returns true if the store has at least one valid observation
	 * @return
	 */
	boolean hasData();
	
}
