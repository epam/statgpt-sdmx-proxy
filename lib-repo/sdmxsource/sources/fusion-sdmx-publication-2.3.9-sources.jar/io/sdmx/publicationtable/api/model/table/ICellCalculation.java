package io.sdmx.publicationtable.api.model.table;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;

/**
 * Defines a single calculated cell in the publication table. 
 * 
 * The cell will contain at least 1 ISeriesCalculation, but may contain multiple if the cell defines a number of series keys in a calculation expression.
 * 
 * Example 1: ([A:UK:EMP]+[A:FR:EMP])/2  - this would result in 2 ISeriesCalculation with the series A:UK:EMP and A:FR:EMP
 * Example 2: ([A:(UK+FR):EMP])/2  - this would result in 1 ISeriesCalculation with a calculation expression [UK]+[FR] in the 2nd Dimension
 * 
 */
public interface ICellCalculation {
	
	
	default boolean hasOutputCellKey() {
		return getOutputCellKey() != null;
	}
	
	/**
	 * @return nullable - the cell key (see ICellKey.getCellKey) to use for the output cell enabling external references to this cell.  This can be null if
	 * no cell key was provided
	 */
	String getOutputCellKey();
	
	/**
	 * @return the output data structure
	 */
	DataStructureBean getOutputDSD();

	/**
	 * @return the original cell value, with variable place holders replaced,  example ([A:UK:]+[A:FR:])/2 would become ([A:UK:EMP]+[A:FR:EMP])/2
	 */
	String getObsCellValue();
	
	/**
	 * The observation cell rewritten to replace ISeriesCalculation with a placeholder, , example ([A:UK:EMP]+[A:FR:EMP])/2 becomes ($[1]+$[2])/2
	 * 
	 * @return the cell value replaced as a calculation expression, where each ISeriesCalculation is replaced with $n where n is the integer position in the list, starting from 0
	 */
	String getCalculation();

	/**
	 * @return the calculation used in each placeholder in the calculation
	 */
	List<ISeriesCalculation> getSeriesCalculations();
	
}
