package io.sdmx.publicationtable.api.model.variable;

import java.util.List;
import java.util.Set;

import io.sdmx.api.date.ITimePeriod;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;

public interface ICellVariables {

	/**
	 * @return all the Dataflow alias that exist for the table
	 */
	Set<String> getDataflowAlias();
	
	/**
	 * @return a list of footnotes in the order that have been referenced by the variables processed so far from the method calls to getVariableValue
	 */
	List<String> getReferencedFootnotes();

	/**
	 * @param variable for example UNIT, UNIT.NAME, UNIT.DESCRIPTION, UNIT.ID, REF_AREA.UK.NAME, TIME_PERIOD, P, A(P)
	 * @return the value for the variable passed in
	 */
	String getVariableValue(String variable);
	
	
	/**
	 * @param variable id of Dimension or id of external variable (Codelist/Valulist)
	 * @return all the possible values
	 */
	EnumeratedListBean<? extends EnumeratedItemBean> getValues(String variable);
	
	/**
	 * If a Dimension is wildcarded in the PublicationTableModel then a value for the Dimension will be required to build the table output, this 
	 * method returns the value to use for the Dimension for the dataflow with the given alias

	 * @param alias the alias to the dataflow
	 * @param dimensionIndex
	 * @return
	 */
	String getDimensionValue(String dimensionId);
	
	/**
	 * Returns all the dimension ids that had variable values
	 * @return
	 */
	Set<String> getVariableDimensions();
	
	/**
	 * @param alias
	 * @return the DSD for the given alias
	 */
	DataflowBean getDataflow(String alias);
	
	/**
	 * @param alias
	 * @return the DSD for the given alias
	 */
	DataStructureBean getDataStructure(String alias);
	
	/**
	 * @return nullable - if the DSD has a time element then this will return the ITimePeriod which defines the base time period for which the table is being built
	 */
	ITimePeriod getTimePeriod();
	
	/**
	 * Sets the store of data, which can be used to retrieve observation attribute and measure values which may be referred to in variables
	 * @param store
	 */
	void setCellValueStore(IPublicationTableCellValueStore store);
	
	/**
	 * @return the store used to get observation from
	 */
	IPublicationTableCellValueStore getCellValueStore();
}
