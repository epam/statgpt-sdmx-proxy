package io.sdmx.publicationtable.api.model.variable;

import java.util.Map;

import io.sdmx.publicationtable.api.model.table.ICellKey;

/**
 * A wrapper around a single 'standard' series key 'A:UK:FR' or a single series key with calculations embedded in a dimension 'A:(UK+FR+DE):EMP'
 * 
 * If the series has calculations, hasCalculatedDimension will return true and the getCalculationExpression and getVariableToseries can be used to get the calculation
 * details
 */
public interface ISeriesCalculation {

	/**
	 * @return nullable, the default value to use if the input components to this calculation have no data
	 */
	Double getDefaultValue();
	
	/**
	 * @param variable, to match the getVariableToCell map key
	 * @return nullable, the default value to use if the input components to this calculation have no data
	 */
	Double getDefaultValue(String variable);
	
	/**
	 * @return true if this object contains calculation information, false if it is just a plain series key
	 */
	boolean hasCalculatedDimension();

	/**
	 * @return zero indexed dimension position that contained the calculation expression, example A:(UK+FR+DE):EMP returns 1 as it is in the second dimension
	 */
	Integer getCalculatedDimension();

	/**
	 * @return the original expression, e.g: A:(UK+FR+DE):EMP
	 */
	ICellKey getOriginalExpression();

	/**
	 * @return a map of calculated part of the key, e.g. UK to the series/obs key e.g A:UK:EMP:2008
	 */
	Map<String, ICellKey> getVariableToCell();
	
	/**
	 * @return the calculated part of the series key extracted, example A:(UK+FR+DE):EMP will return [UK]+[FR]+[DE]
	 */
	String getCalculationExpression();
	
}
