package  io.sdmx.publicationtable.api.model.variable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.core.data.api.model.mapping.IFrequencyFormatMap;

/**
 * Contains variables with accessor methods for resolving variable values
 */
public interface IPublicationVariables extends ICellVariables {
	
	/**
	 * Returns a list of footnotes in the order that have been referenced by the variables processed so far from the method calls to getVariableValue
	 * @return
	 */
	List<String> getReferencedFootnotes();

	/**
	 * optional mapping for frequency
	 * @param frequencyFormatMapping
	 */
	void setFrequencyFormatMapping(IFrequencyFormatMap frequencyFormatMapping);
	
	/**
	 * Sets all the codes from a codelist to the variable pool, against the alias
	 * @param alias
	 * @param codelist
	 */
	void setCodelist(String alias, EnumeratedListBean<? extends EnumeratedItemBean> codelist);
	
	/**
	 * Sets the time period
	 * @param timePeriod
	 */
	void setTimePeriod(String timePeriod);
	
	/**
	 * Adds a string variable
	 * @param variableId
	 * @param variableValue
	 */
	void addStringVariable(String variableId, String variableValue);

	/**
	 * Adds a dataflow and realted structures to the variables
	 * @param dataflow
	 * @param dfSb
	 * @param index
	 */
	void addDataflow(String dataflow, DataflowSuperBean dfSb);
	
	/**
	 * Adds a value for the dimension
	 * @param alias the alias to the dataflow
	 * @param dimId
	 * @param dimValue
	 */
	void addDimensionValue(String alias, String dimId, String dimValue);
	
}
