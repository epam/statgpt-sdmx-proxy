package io.sdmx.publicationtable.api.model.table;

import io.sdmx.api.date.SdmxDate;

/**
 * A pointer to an Observation's Measure or Attribute
 *  
 */
public interface IObsKey {
	
	/**
	 * @return mutually exclusive with getMeasure, returns the ID of the Attribute to display
	 */
	String getAttribute();

	/**
	 * @return  mutually exclusive with getAttribute, the ID of the Measure Dimension to display
	 */
	String getMeasure();

	/**
	 * @return alias to the dataflow for the key
	 */
	String getDataflowAlias();

	/**
	 * @return the series key e.g. A:UK:EMP
	 */
	String getSeriesKey();
	
	/**
	 * @return time aspect to cell key if the DSD has a time dimension
	 */
	SdmxDate getObsTime();
	
	/**
	 * @return the original expression used to generate the time period, i.e. P, A(P), A(P-1) 
	 */
	String getTimeExpression();
	
}
