package io.sdmx.publicationtable.api.factory;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.publicationtable.api.engine.OutputTableWriterEngine;

public interface IMaterialisedPublicationTableWriterFactory {

	/**
	 * @param format
	 * @return writer if the format is known and supported
	 */
	OutputTableWriterEngine getOutputTableWriterEngine(InformationFormat format);
	
}
