package io.sdmx.publicationtable.api.model.bean.mutable;

/**
 * Can contain numbers, and as such, can have a value operation performed up it, such as divide by 1000
 */
public interface NumericalMutable {
	
	/**
	 * ? what is the syntax of this?
	 * @return
	 */
	String getValueOperation();
	
	/**
	 * Returns the formatting information  ? what is the syntax of this?
	 * @return
	 */
	String getFormatInformation();

}
