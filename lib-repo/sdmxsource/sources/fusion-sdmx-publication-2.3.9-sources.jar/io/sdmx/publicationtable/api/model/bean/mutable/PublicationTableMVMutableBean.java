package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface PublicationTableMVMutableBean extends MutableBean {
	
	/**
	 * @return the component whose reported value will be used to determine the missing value
	 */
	String getComponentId();
	PublicationTableMVMutableBean setComponentId(String compId);
	
	/**
	 * @return the default missing value to use if no mapping rules exist (or if no rules match)
	 */
	String getDefaultMissingValue();
	PublicationTableMVMutableBean setDefaultMissingValue(String mv);
	
	
	/**
	 * @return optional reference to a mapping relationship for missing values
	 */
	StructureReferenceBean getMissingValueMapping();
	PublicationTableMVMutableBean setMissingValueMapping(StructureReferenceBean ref);
}
