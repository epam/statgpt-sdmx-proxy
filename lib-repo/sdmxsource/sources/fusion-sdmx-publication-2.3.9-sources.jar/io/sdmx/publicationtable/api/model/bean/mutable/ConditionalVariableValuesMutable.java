package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface ConditionalVariableValuesMutable extends MutableBean {
	
	/**
	 * The mapped id, for example UK
	 * @return
	 */
	String getMappedId();
	void setMappedId(String id);
	

	/**
	 * Returns the source ids in the order they are given
	 * @return
	 */
	List<String> getSourceIds();
	void addMappedValue(String sourceId, String targetId);

	/**
	 * Returns the mapped value for the given source id
	 * @return
	 */
	String getMappedValue(String sourceId);

}
