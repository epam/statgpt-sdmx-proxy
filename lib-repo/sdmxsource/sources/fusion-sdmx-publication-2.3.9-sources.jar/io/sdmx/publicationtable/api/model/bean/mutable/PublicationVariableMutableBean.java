package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;

public interface PublicationVariableMutableBean extends IdentifiableMutableBean {

	/**
	 * Returns a reference to the codelist
	 * @return
	 */
	StructureReferenceBean getCodelistReference();
	PublicationVariableMutableBean setCodelistReference(StructureReferenceBean refs);
	
}
