package io.sdmx.publicationtable.api.engine;

import java.util.Map;

import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;

public interface IPublicationTableCellBuilderEngine {

	/**
	 * Resolves the table cells for the table definition with the given dimension variables - if any variables
	 * are missing which are required by the table, this engine will resolve which defaults can be used to build a valid
	 * table
	 * 
	 * @param table
	 * @param dimensionVariables
	 * @return
	 */
	IPublicationTableCells build(PublicationTableBean table, Map<String, String> dimensionVariables);

}
