package  io.sdmx.publicationtable.api.model.output;

import java.util.List;

import io.sdmx.publicationtable.api.model.variable.ICellVariables;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.Styleable;

/**
 * Defines the output table, which is a result of processing the PublicationTableDefinition against supplied variables
 */
public interface OutputPublicationTable extends Styleable {

	/**
	 * @return not null id of the table
	 */
	String getId();

	/**
	 * @return not null title of the table
	 */
	String getTitle();
	
	/**
	 * @return nullable subtitle of the table
	 */
	String getSubTitle();
	
	/**
	 * @return nullable, earliest and latest period that has data for this table
	 */
	SdmxPeriod getAvailablePeriod();

	/**
	 * @return table definition that was used to create this output
	 */
	PublicationTableBean getTableDef();
	
	/**
	 * @return not null, immutable, footer of the table
	 */
	List<String> getFootnotes();
	
	/**
	 * @return the SDMX Period the table is built for
	 */
	String getPeriod();

	/**
	 * @return the table head
	 */
	OutputPublicationTableTHead getTHead();
	
	/**
	 * @return the table body
	 */
	OutputPublicationTableTBody getTBody();
	
	/**
	 * @return the variables that were used to create this table
	 */
	ICellVariables getPublicationVariables();
	
}
