package  io.sdmx.publicationtable.api.model.output;

import java.util.List;

public interface OutputPublicationTableTHead {

	/**
	 * Returns the rows for the header
	 * @return
	 */
	List<OutputPublicationTableTHeadRow> getRows();
}
