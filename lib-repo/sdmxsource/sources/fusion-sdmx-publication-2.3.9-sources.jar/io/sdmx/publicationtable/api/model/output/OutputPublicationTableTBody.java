package  io.sdmx.publicationtable.api.model.output;

import java.util.List;

public interface OutputPublicationTableTBody {
	
	/**
	 * Returns the rows for the body
	 * @return
	 */
	List<OutputPublicationTableTBodyRow> getRows();
	
}
