package io.sdmx.publicationtable.api.model.table;

import java.util.List;
import java.util.Set;

/**
 * Decomposes a cell key into its parts. Examples:
 * 
 * DF1.UK:FR:DE:2008:OBS_VALUE  - DF1 is an optional Dataflow Alias, OBS_VALUE is an optional measure ID, 2008 is the time period if the DSD has a Time Dimension
 * UK:FR:DE:2008:OBS_VALUE  	- No Dataflow alias (default flow)
 * UK:FR:DE:2008				- No Measure, expects a DSD with only 1 measure and will use that
 * UK:FR:DE						- No Obs Time, expects a DSD with no time period and only 1 measure and will use that
 * UK:FR:DE:BIRTHS				- Explicit measure and no obs time, expects a DSD with no time period and a BIRTHS measure ID
 *  
 */
public interface ICellKey extends IObsKey {
	
	/**
	 * @return the original cell key, e.g. DF1.UK:FR:DE:2008:OBS_VALUE
	 */
	String getCellKey();
	
	/**
	 * @return a set of Dimension ids that have no value in the key
	 */
	Set<String> getMissingDimensions();
	
	/**
	 * @return list of footnotes
	 */
	List<String> getFootnotes();
	
	/**
	 * @return the original expression used to generate the time period, i.e. P, A(P), A(P-1) 
	 */
	String getTimeExpression();
	
}
