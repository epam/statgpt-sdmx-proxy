package  io.sdmx.publicationtable.api.model.output;

import java.util.List;

public interface OutputPublicationTableTHeadRow {

	/**
	 * Returns all the table cells
	 * @return
	 */
	List<OutputPublicationTextCell> getCells();
	
}
