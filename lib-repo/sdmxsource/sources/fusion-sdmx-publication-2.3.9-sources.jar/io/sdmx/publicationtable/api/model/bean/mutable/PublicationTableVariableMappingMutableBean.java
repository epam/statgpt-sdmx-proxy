package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface PublicationTableVariableMappingMutableBean extends MutableBean {

	/**
	 * @return the dimension id whose value is used as an input to this mapping
	 */
	String getInputDimensionId();
	PublicationTableVariableMappingMutableBean setInputDimensionId(String dimId);
	
	/**
	 * @return list of output dimension ids - at least one is required
	 */
	List<String> getOutputDimensionId();
	PublicationTableVariableMappingMutableBean addOutputDimensionId(String dimId);
	PublicationTableVariableMappingMutableBean setOutputDimensions(List<String> dimIds);
	
	/**
	 * @return a reference to the representation map which must have as many mapped output as there are output dimension ids
	 */
	StructureReferenceBean getMappingRules();
	PublicationTableVariableMappingMutableBean setMappingRules(StructureReferenceBean sRef);
}
