package  io.sdmx.publicationtable.api.model.output;

import java.util.List;

import io.sdmx.publicationtable.api.model.table.ICellValue;

public interface OutputPublicationTableTBodyRow {

	/**
	 * Returns the label cell for the row
	 * @return
	 */
	OutputPublicationTextCell getRowLabel();

	/**
	 * Returns the Observation values for each of the table cells, or null if there is not a value 
	 * @return
	 */
	List<ICellValue> getCells();
	
	/**
	 * returns true if this row or any child rows have data
	 * @return
	 */
	boolean hasData();
	
	/**
	 * @return 1 indexed level
	 */
	int getLevel();
	
}
