package  io.sdmx.publicationtable.api.model.variable;

import java.util.List;

/**
 * Represents a String which may / may not have variable placeholders.  
 * A placeholder consists of $(HELLO) parenthesis or $[Hi] Square brackets
 */
public interface VariableString {

	/**
	 * Returns a list of all the parenthesis variables in the string
	 * @return
	 */
	List<String> getParenthesisVaraibles();
	
	/**
	 * Returns a list of all the square bracket variables in the string
	 * @return
	 */
	List<String> getSquareBracketVaraibles();
	
	/**
	 * Returns true if there are one or more parenthesis variables in the string
	 * @return
	 */
	boolean hasParenthesisVaraibles();
	
	/**
	 * Returns true if there are one or more square bracket variables in the string
	 * @return
	 */
	boolean hasSquareBracketVaraibles();
	
	/**
	 * Replaces the parenthesis brackets variable at the given index with the value
	 * @param variableIdx
	 * @param value
	 */
	void replaceParenthesisVaraible(int variableIdx, String value);
	
	/**
	 * Replaces the square brackets variable at the given index with the value
	 * @param variableIdx
	 * @param value
	 */
	void replaceSquareBracketVaraible(int variableIdx, String value);
	
	/**
	 * Returns the final string with the variables replaced
	 * @return
	 */
	String getString();
}
