package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines a reference to a dataflow
 */
public interface PublicationTableDataflowMutable extends MutableBean {
	
	/**
	 * Returns the alias of this reference
	 * @return
	 */
	String getAlias();
	PublicationTableDataflowMutable setAlias(String alias);
	
	/**
	 * sets the cross reference URN to the dataflow
	 * @return
	 */
	StructureReferenceBean getDataflowRef();
	PublicationTableDataflowMutable setDataflowRef(StructureReferenceBean ref);
}
