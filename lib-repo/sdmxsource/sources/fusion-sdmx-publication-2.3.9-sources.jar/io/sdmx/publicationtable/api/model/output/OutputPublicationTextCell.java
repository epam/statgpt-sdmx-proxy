package  io.sdmx.publicationtable.api.model.output;

import io.sdmx.api.sdmx.model.beans.publicationtable.Styleable;

public interface OutputPublicationTextCell extends Styleable {

	/**
	 * Returns the text of the cell if the value is textual
	 * @return
	 */
	String getCellText();
	
	/**
	 * Returns the rowspan
	 * @return
	 */
	int getRowSpan();
	
	/**
	 * Returns the column span
	 * @return
	 */
	int getColSpan();
	
}
