package io.sdmx.publicationtable.api.manager;

import java.io.OutputStream;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;

public interface IMaterialisedPublicationTableWriterManager {

	
	/**
	 * Writes the table to the output stream in the given format
	 * 
	 * @param outputTable
	 * @param format
	 * @param out
	 */
	void writeTable(OutputPublicationTable outputTable, InformationFormat format, OutputStream out);
	
}
