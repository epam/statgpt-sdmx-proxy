package io.sdmx.publicationtable.api.model.availability;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * Describes values that can be used in a publication table in place of the wildcard dimensions
 */
public interface IPublicationTableAvailableData {

	/**
	 * @return the data query that was built from the publication table - this will be a list of series/wildcarded series
	 */
	DataQuery getDataQuery();

	/**
	 * @return a list of dimnesion values which are valid to use as placeholders for the missing dimension values
	 */
	List<String[]> getSeries();

	/**
	 * @return the number of series that matched the query
	 */
	long getValidSeries();

	/**
	 * @return Dimension ID in the same order as the Code Ids for the getSeries() method, for example if this returns FREQ, REF_AREA then the getSeries will return values such as [A,UK]
	 */
	String[] getDimensionPosition();

	/**
	 * @return a map of Dimension ID to a set of unique code Is for that Dimension
	 */
	Map<String, Set<String>> getDistinctValuesByComponent();
}
