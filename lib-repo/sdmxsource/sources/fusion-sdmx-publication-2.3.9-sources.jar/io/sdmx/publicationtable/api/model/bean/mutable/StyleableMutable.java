package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface StyleableMutable extends MutableBean {


	/**
	 * Returns the styles to apply to this cell, or null if there is no style to apply
	 * @return
	 */
	String[] getStyles();
	
	/**
	 * Sets the styles
	 * @param styles
	 */
	void setStyles(String[] styles);
	
	/**
	 * Adds a style
	 * @param style
	 */
	void addStyle(String style);
}
