package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines a table row 
 */
public interface PublicationTableBodyRowMutable extends MutableBean {
	
	/**
	 * Returns the row label cell
	 * @return
	 */
	PublicationTableHeadCellMutable getHeadCell();
	void setHeadCell(PublicationTableHeadCellMutable tHead);
	PublicationTableHeadCellMutable setHeadCell();
	
	/**
	 * Returns an immutable list of all the table cells for this row
	 * @return
	 */
	List<PublicationTableBodyCellMutable> getTableCells();
	void setTableCells(List<PublicationTableBodyCellMutable> tBody);
	void addTableCell(PublicationTableBodyCellMutable cell);
	PublicationTableBodyCellMutable addTableCell();
	
	/**
	 * Returns the level of this row, starting from 1.  The level defines the level in the hierarchy 
	 * @return
	 */  
	default int getLevel() {
		return getRowLabel().getLevel();
	}
	
	/**
	 * @return the {@link PublicationTableHeadCell} label parsed into a {@link IHeadLabel}
	 */
	IHeadLabel getRowLabel();
	
}
