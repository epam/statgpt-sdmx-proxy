package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public interface PublicationTableBodyCellMutable extends MutableBean {

	/**
	 * Returns an unmodified  the observation key, including time, for example
	 * Q:$(MEAS):C:G:TO1:A:5J:A:5A:A:5J:N:T    (where T is now)
	 * Q:$(MEAS):C:G:TO1:A:5J:A:5A:A:5J:N:T-1  (where T-1 is now minus 1 period)
	 * Q:$(MEAS):C:A:$TO1-USD-EUR-JPY-GBP-CHF-UN9:A:5J:A:5A:U:5J:N:T  showing calculated data
	 * 
	 * @return
	 */
	String getObservationKey();
	/**
	 * Sets the observation key as a colon delimited string (e.g. A:B:C:D)
	 * @param obsKey
	 */
	PublicationTableBodyCellMutable setObservationKey(String obsKey);
	
}
