package io.sdmx.publicationtable.api.engine;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.publicationtable.api.model.availability.IPublicationTableAvailableData;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

public interface IPublicationTableAvailabilityRetreivalEngine {


	/**
	 * Issues a series keys only query, to detemine which unique value combinations will return data,  only
	 * keeping the value combinations of the IPublicationTableCells.getMissingDimensions
	 * 
	 * @param dfAlias
	 * @param publicationTable
	 * @param tableCells
	 * @param publicationVariables
	 * @return the series that match given the publication table definition and the varaibles used
	 */
	IPublicationTableAvailableData getAvailableData(String dfAlias, 
													PublicationTableBean publicationTable, 
													IPublicationTableCells tableCells, 
													ICellVariables publicationVariables);
}
