package io.sdmx.publicationtable.api.model.bean.mutable;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * This cell is used as a header (either column header or row header)
 */
public interface PublicationTableHeadCellMutable extends MutableBean {

	/**
	 * @return the text for the label, variables can be used, for example $(SECTOR.A.NAME)
	 */
	String getLabel();
	PublicationTableHeadCellMutable setLabel(String label);
	
	/**
	 * Returns the row span
	 * @return
	 */
	int getRowSpan();
	PublicationTableHeadCellMutable setRowSpan(int span);
	
	/**
	 * Returns the column span
	 * @return
	 */
	int getColSpan();
	PublicationTableHeadCellMutable setColSpan(int span);
	
}
