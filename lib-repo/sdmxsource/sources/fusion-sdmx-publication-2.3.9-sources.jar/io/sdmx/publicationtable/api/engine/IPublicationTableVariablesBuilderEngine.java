package io.sdmx.publicationtable.api.engine;

import java.util.Map;

import io.sdmx.publicationtable.api.model.variable.ICellVariables;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;

public interface IPublicationTableVariablesBuilderEngine {

	/**
	 * builds {@link ICellVariables} from the publication table and the query parameters
	 * 
	 * @param publicationTable
	 * @param queryParameters
	 * @return  
	 */
	ICellVariables build(PublicationTableBean publicationTable, Map<String, String> queryParameters);
}
