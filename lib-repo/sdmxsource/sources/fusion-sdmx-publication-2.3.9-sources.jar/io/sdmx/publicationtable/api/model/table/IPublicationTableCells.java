package io.sdmx.publicationtable.api.model.table;

import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

/**
 * Holds all the cells for a publication table 
 */
public interface IPublicationTableCells {

	/**
	 * @return the publication table used to build these cells
	 */
	PublicationTableBean getPublicationTable();
	
	/**
	 * @return variables used to build these cells
	 */
	ICellVariables getVariables();

	/**
	 * @return immutable set of series keys required in the table for the dataflow of the given alias
	 */
	List<ICellKey> getCellsForFlow(String flowAlias);

	/**
	 * @param flowAlias
	 * @return set of dimension Ids that have no values set for the given dataflow
	 */
	Set<String> getMissingDimensions(String flowAlias);
	
	/**
	 * @param flowAlias
	 * @return earliest and latest period in the cell keys for the flow
	 */
	SdmxPeriod getFlowPeriod(String flowAlias);
	
	/**
	 * @param cell
	 * @return
	 */
	ICellKey getObservationKey(PublicationTableBodyCell cell);

	/**
	 * @param cell
	 * @return calculation key or null if the cell is not a calculation cell or not part of this dataflow
	 */
	ICellCalculation getCalculationKey(PublicationTableBodyCell cell);
	
}
