package io.sdmx.publicationtable.api.engine;

import java.io.OutputStream;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

/**
 * Writes the data availability 
 * @param out
 */
public interface IPublicationTableAvailabilityWriterEngine {

	/**
	 * Writes the availability of data based on the table definition and passed in variables
	 * @param publicationTableBean
	 * @param publicationVariables
	 * @param out the output stream to write to
	 */
	
	void writeAvailability(PublicationTableBean publicationTableBean, 
						   ICellVariables publicationVariables, 
						   StructureFormat format, 
						   STRUCTURE_REFERENCE_DETAIL ref,
						   OutputStream out);
	
	
	/**
	 * Writes the earliest and latest period that data is available for the series defined in the cells - only
	 * includes series which are not casting time period from the base period
	 * 
	 * @param tableCells
	 * @return {@link SdmxPeriod} or null if there is no data for the given cells
	 */
	SdmxPeriod getAvailablePeriod(IPublicationTableCells tableCells);
	
}
