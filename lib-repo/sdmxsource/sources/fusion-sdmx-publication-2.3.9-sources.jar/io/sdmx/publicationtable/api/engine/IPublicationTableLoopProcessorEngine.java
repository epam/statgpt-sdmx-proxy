package io.sdmx.publicationtable.api.engine;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.model.table.PublicationTableCells;

/**
 * Expands publication tables based on loop logic in row and colum headers
 */
public interface IPublicationTableLoopProcessorEngine {

	/**
	 * If the {@link PublicationTableBean} contains loops the {@link PublicationTableBean} will be modified to expand the loops, and the {@link PublicationTableCells}
	 * will be updated accordingly
	 * @param cells
	 * @return
	 */
	IPublicationTableCells processLoops(IPublicationTableCells cells);
	
}
