package io.sdmx.publicationtable.api.model.bean.mutable;

import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

/**
 * Defines one row of the table header
 */
public interface PublicationTableHeadRowMutable extends MutableBean {
	
	/**
	 * Returns the list of table header cells for this row
	 * @return
	 */
	List<PublicationTableHeadCellMutable> getHeaderCells();
	void setHeaderCells(List<PublicationTableHeadCellMutable> cells);
	void addHeaderCell(PublicationTableHeadCellMutable cell);
	PublicationTableHeadCellMutable addHeaderCell();	
}
