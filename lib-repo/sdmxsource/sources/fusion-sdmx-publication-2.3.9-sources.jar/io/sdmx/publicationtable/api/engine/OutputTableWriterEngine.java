package io.sdmx.publicationtable.api.engine;

import java.io.OutputStream;

import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;

public interface OutputTableWriterEngine {

	/**
	 * Writes the output table to the output stream
	 * @param outputTable
	 */
	void writeOutputTable(OutputPublicationTable outputTable, OutputStream out);
	
}
