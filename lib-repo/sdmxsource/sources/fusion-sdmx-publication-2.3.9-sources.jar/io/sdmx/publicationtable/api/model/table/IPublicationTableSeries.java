package io.sdmx.publicationtable.api.model.table;

import java.util.List;

/**
 * A container of series for a dataflow, with the variable information required to modify a series if it has variable placeholders
 */
public interface IPublicationTableSeries {

	/**
	 * @return a set of series keys for this Dataflow
	 */
	List<ICellKey> getCellsForFlow(String flowAlias);

	/**
	 * Adds a series key to the set of series for the publication table - any variables in the key are replaced with
	 * values if they are known
	 * 
	 * @param series - full key (with or without time period) or key with placeholders. e.g. A:UK:EMP, A:UK:EMP:A(P), A::EMP:P-1
	 * @return the series key with variables resolved, example A::EMP:P returns A:UK:EMP:2008 if REF_AREA and base time period are known
	 */
	ICellKey addSeries(ICellKey cellKey);

}
