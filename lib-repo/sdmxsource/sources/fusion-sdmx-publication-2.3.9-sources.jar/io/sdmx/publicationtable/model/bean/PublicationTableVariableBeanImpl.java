package io.sdmx.publicationtable.model.bean;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationVariableMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PublicationTableVariableBeanImpl extends IdentifiableBeanImpl implements PublicationVariableBean {
	private static final long serialVersionUID = 1L;

	private IDirectCrossReferenceBean<? extends EnumeratedListBean> codelistRef;

	public PublicationTableVariableBeanImpl(PublicationVariableMutableBean bean, PublicationTableBean parent) {
		super(bean, parent);
		if(bean.getCodelistReference() != null) {
			codelistRef = DirectCrossReferenceBean.build(this, "codelist", bean.getCodelistReference().buildURNSingle(EnumeratedListBean.class));
		}
		validate();
	}

	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return PublicationVariableBean.class;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(codelistRef == null) {
			throw new SdmxSemmanticException("Publication Variable is missing reference to Codelist");
		}
		if(codelistRef.getTargetReference() != SDMX_STRUCTURE_TYPE.CODE_LIST  && codelistRef.getTargetReference() != SDMX_STRUCTURE_TYPE.VALUE_LIST) {
			throw new SdmxSemmanticException("Publication Variable is references incorrect structure type of '"+codelistRef.getTargetReference().getType()+"' expecting Codelist or Valuelist");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public ICrossReferenceBean<? extends EnumeratedListBean> getCodelistReference() {
		return codelistRef;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationVariableBean that = (PublicationVariableBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.codelistRef, that.getCodelistReference(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.add(codelistRef);
	}
}
