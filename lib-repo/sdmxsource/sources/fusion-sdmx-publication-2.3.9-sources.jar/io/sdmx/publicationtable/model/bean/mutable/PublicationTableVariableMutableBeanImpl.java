package  io.sdmx.publicationtable.model.bean.mutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationVariableMutableBean;

public class PublicationTableVariableMutableBeanImpl extends IdentifiableMutableBeanImpl implements PublicationVariableMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean codelistRef;
	
	public PublicationTableVariableMutableBeanImpl(PublicationVariableBean bean, MutableBean parent) {
		super(bean, parent);
		this.codelistRef = bean.getCodelistReference().asMutable();
	}

	public PublicationTableVariableMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_VARIABLE);
	}

	@Override
	public StructureReferenceBean getCodelistReference() {
		return codelistRef;
	}

	@Override
	public PublicationVariableMutableBean setCodelistReference(StructureReferenceBean ref) {
		this.codelistRef = ref;
		return this;
	}

}
