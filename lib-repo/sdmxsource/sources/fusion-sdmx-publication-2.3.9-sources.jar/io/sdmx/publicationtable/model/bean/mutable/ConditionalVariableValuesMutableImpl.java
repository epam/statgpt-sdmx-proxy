package  io.sdmx.publicationtable.model.bean.mutable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.im.mutable.base.MutableBeanImpl;

import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;

public class ConditionalVariableValuesMutableImpl extends MutableBeanImpl implements ConditionalVariableValuesMutable, Serializable {
	private static final long serialVersionUID = 1L;
	private List<String> sourceIds = new ArrayList<String>();
	private Map<String, String> sourceTargetMap = new HashMap<>();
	private String mappedId;
	
	public ConditionalVariableValuesMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_CONDITIONAL_VARIABLE_VALUES);
	}
	public ConditionalVariableValuesMutableImpl(ConditionalVariableValues immutable, ConditionalVariableMutable parent) {
		super(immutable, parent);
		this.mappedId = immutable.getMappedId();
		for(String sourceId : immutable.getSourceIds()) {
			String target = immutable.getMappedValue(sourceId);
			this.addMappedValue(sourceId, target);
		}
	}

	@Override
	public List<String> getSourceIds() {
		return sourceIds;
	}
	
	@Override
	public String getMappedId() {
		return mappedId;
	}

	@Override
	public void setMappedId(String id) {
		this.mappedId = id;
	}
	
	@Override
	public void addMappedValue(String sourceId, String targetId) {
		sourceTargetMap.put(sourceId, targetId);
		if(!sourceIds.contains(sourceId)) {
			sourceIds.add(sourceId);
		}
	}

	@Override
	public String getMappedValue(String sourceId) {
		return sourceTargetMap.get(sourceId);
	}
}
