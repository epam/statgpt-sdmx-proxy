package io.sdmx.publicationtable.model.table;

import java.util.Collections;
import java.util.List;

import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.ICellValue;

public class CellValue implements ICellValue {
	private ICellCalculation cellCalculation;
	private String cellValue;
	private List<String> footnotes = Collections.emptyList();
	private String cellKey;
	private String dataflowAlias;
	
	public static ICellValue getObsCell(ICellKey cellKey, String cellValue, List<String> footnotes) {
		return new CellValue(cellKey, cellValue, footnotes);
	}
	
	public static ICellValue getCalcCell(ICellCalculation calcKey, String cellKey, String cellValue, List<String> footnotes) {
		return new CellValue(calcKey, cellKey, cellValue, footnotes);
	}
	
	public static ICellValue getTextCell(String cellValue, List<String> footnotes) {
		return new CellValue(cellValue, footnotes);
	}

	private CellValue(String cellKey, String dataflowAlias, ICellCalculation calc, String cellValue, List<String> footnotes) {
		this.cellKey = cellKey;
		this.cellValue = cellValue;
		this.cellCalculation = calc;
		if(footnotes != null) {
			this.footnotes = Collections.unmodifiableList(footnotes);
		}
	}
	
	private CellValue(String cellValue, List<String> footnotes) {
		this.cellValue = cellValue;
		if(footnotes != null) {
			this.footnotes = Collections.unmodifiableList(footnotes);
		}
	}
	
	private CellValue(ICellKey cellKey, String cellValue, List<String> footnotes) {
		this(cellValue, footnotes);
		this.cellKey = cellKey.getCellKey();
		this.dataflowAlias = cellKey.getDataflowAlias();
	}
	
	private CellValue(ICellCalculation cellCalculation, String cellKey, String cellValue, List<String> footnotes) {
		this(cellValue, footnotes);
		this.cellKey = cellKey;
		this.cellCalculation = cellCalculation;
	}
	
	@Override
	public String getDataflowAlias() {
		return dataflowAlias;
	}

	@Override
	public ICellCalculation getCellCalculation() {
		return cellCalculation;
	}

	@Override
	public String getCellKey() {
		return cellKey;
	}

	@Override
	public String getCellValue() {
		return cellValue;
	}

	@Override
	public List<String> getFootnotes() {
		return footnotes;
	}
}
