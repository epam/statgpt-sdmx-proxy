package io.sdmx.publicationtable.model.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.NumberUtils;

/**
 * Defines a single calculated cell in the publication table - this cell may contain 1 or more series as input to the calculation, each series input may 
 * contain calculated values.  Example calculation cells are:
 */
public class CellCalculation implements ICellCalculation {
	private String outputCellKey;		//If assigned, this is the output cell key that will be used
	private String obsCellValue;  						//Example 	A:(EUR-(UK+FR)):EMP
	private String calculation;   						 //Example ($0-($1+$2))
	private List<ISeriesCalculation> seriesCalculations;  //Contains the inputs to each calculation part
	
	private DataStructureBean outputDSD;
	
	/**
	 * 
	 * @param variables
	 * @param obsCellValue
	 * @param loopDimensions
	 */
	public CellCalculation(ICellVariables variables, String obsCellValue, Set<String> loopDimensions) {
		if(obsCellValue.startsWith(":=")) {
			obsCellValue = obsCellValue.substring(2);
		} else if(obsCellValue.contains(":=")) {
			int splitIdx = obsCellValue.indexOf(":=");
			outputCellKey = obsCellValue.substring(0, splitIdx).trim();
			obsCellValue = obsCellValue.substring(splitIdx+2, obsCellValue.length()).trim();
		}
		//A calculation cell may contain multiple series, in which case they are in square brackets [key1]+[key2] 
		//each series key can contain an embedded calculation [A:(UK+FR+DE):EMP] 
		//Extract keys, example [key1]+[key2] (can be null to indicate this part of the key is not a calculation)
		//If a calculation contains only 1 series then it does not need to be in square brackets
		StringBuilder calcSb = new StringBuilder();  //to build the a0+a1+a2 expression

		int variableIdx = 0;
		Exp exp = Exp.get().blockCopy("[".charAt(0), "]".charAt(0)).setSupportLevels(false).parse(obsCellValue);
		this.seriesCalculations = new ArrayList<>(exp.size()); //default size to the total number of blocks
		
		for(int blockPos=0; blockPos < exp.size(); blockPos++) {
			String block = exp.getBlock(blockPos);
			int level = exp.getLevel(blockPos);
			if(level == 0) {
				Double defaultValue = null;
				if(block.contains("||")) {
					String[] blockSplit = block.split("\\|\\|");
					if(blockSplit.length > 2) {
						throw new SdmxSemmanticException("Illegal value '["+block+"]'.  The reserved character '|' cannot occur multiple times in a series key part");
					}
					block = blockSplit[0];
					defaultValue = NumberUtils.asDouble(blockSplit[1]);
					
				}
				ICellKey cellKey = new CellKey(block, variables, loopDimensions);

				//TODO support multiple DSDs
				outputDSD = variables.getDataStructure(cellKey.getDataflowAlias());
				
				
				//block - which is a series key or calculation key
				SeriesCalculation calculation = new SeriesCalculation(variables, cellKey, loopDimensions, defaultValue);
				this.seriesCalculations.add(calculation);
				calcSb.append("${"+variableIdx+"}");
				variableIdx++;
			} else {
				calcSb.append(block);
			}
		}
		this.calculation = calcSb.toString();
		this.seriesCalculations = Collections.unmodifiableList(this.seriesCalculations);
		
		int var = 0;
		this.obsCellValue = calculation;
		for(ISeriesCalculation calc : this.seriesCalculations) {
			String replace = "${"+var+"}";
			String replaceWith = "["+calc.getOriginalExpression().getCellKey()+"]";
			this.obsCellValue = this.obsCellValue.replace(replace, replaceWith);
			var++;
		}
	}
	
	@Override
	public String getOutputCellKey() {
		return outputCellKey;
	}
	
	@Override
	public DataStructureBean getOutputDSD() {
		return outputDSD;
	}

	@Override
	public String getObsCellValue() {
		return obsCellValue;
	}

	@Override
	public String getCalculation() {
		return calculation;
	}

	@Override
	public List<ISeriesCalculation> getSeriesCalculations() {
		return seriesCalculations;
	}
}