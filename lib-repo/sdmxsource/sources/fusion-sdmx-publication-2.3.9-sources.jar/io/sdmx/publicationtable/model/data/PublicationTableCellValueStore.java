package io.sdmx.publicationtable.model.data;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.engine.SdmxDataRetrievalWithWriter;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.api.model.dataset.IObservationValueFormatter;
import io.sdmx.core.data.engine.writer.ScalingDataWriterEngine;
import io.sdmx.core.data.model.calcuation.Calculator;
import io.sdmx.core.data.model.formatting.SeriesKeyPattern;
import io.sdmx.core.sdmx.empty.EmptySeriesObsDataWriterEngine;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.publicationtable.api.model.table.IObsKey;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.publicationtable.model.table.CellValue;
import io.sdmx.publicationtable.util.PublicationTableUtil;
import io.sdmx.publicationtable.util.VariableUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.object.StringUtil;

/**
 *  Obtains, formats and caches all the Observations required for a PublicationTable - making these values retrievable via the Interface
 */
public class PublicationTableCellValueStore implements IPublicationTableCellValueStore {
	private Map<String, DataflowObsStore> obsStores;
	private IPublicationTableCells tableSeries;
	private Calculator calculator = new Calculator(5, RoundingMode.HALF_UP);
	private IObservationValueFormatter obsValueFormatter;
	
	private String emptyCellValue;
	
	
	
	/**
	 * @param tableSeries used to derive which observations to pull from the data retreival
	 * @param obsValueFormatter nullable if provided it will be used to format the observation measure values with
	 * @param emptyCellValue to use if there are no observations for an observation cell
	 * @param globalScale  a scale factor describes how the output observation should be scaled using 10^[scale factor].  For example if the scale factor is 6, then the
	 * desired unit multiplier is millions, if the observation is already scaled and defines its scale using the UNIT_MULT attribute then the current scale will
	 * be taken into account when calculating the new observation value, for example 1.1 scaled to millions (UNIT_MULT=6) would be 1100 if rescaled to thousands (UNIT_MULT=3)
	 * @param scaleFactor applies a scale factor to all observations whos series key matches the given pattern.
	 * <p/>
	 * The pattern can be in one of the following formats:
	 * <ol>
	 *  <li>=A:UK:EMP - series key</li>
	 *  <li>=FLOW.A:UK:EMP - Series key for Dataflow alias FLOW</li>
	 *  <li>=FLOW.A:UK:EMP - Series key with multiple values for a key component</li>
	 *  <li>CURRENCY=GBP,FREQ=A - Component Values</li>
	 *</ol>
	 * @param dataRetrieval used to get the data for this store
	 */
	public PublicationTableCellValueStore(IPublicationTableCells tableSeries,
			IObservationValueFormatter obsValueFormatter,
			String emptyCellValue,
			Integer globalScale,
			Map<String, Integer> scaleFactor,
			SdmxDataRetrievalWithWriter dataRetrieval) {
		this.tableSeries = tableSeries;
		this.obsValueFormatter = obsValueFormatter;
		this.emptyCellValue = emptyCellValue;

		Map<String, DataQuery> queries = PublicationTableUtil.buildDataQueries(tableSeries);
		obsStores = new HashMap<>(queries.size());

		Map<SeriesKeyPattern, Integer> scalingBySeries = new HashMap<>();
		if(scaleFactor != null) {
			Set<String> allFlows = tableSeries.getVariables().getDataflowAlias();
			DataStructureBean singleDSD = null;
			if(allFlows.size() == 1) {
				singleDSD = tableSeries.getVariables().getDataStructure(allFlows.toArray()[0].toString());
			}
			for(String key : scaleFactor.keySet()) {
				DataStructureBean dsd = singleDSD;
				boolean notRule = false;
				if(key.startsWith("!")) {
					notRule = true;
					key = key.substring(1);
				}
				if(key.startsWith("=")) {
					//Series Key Match
					key = key.substring(1);
					String alias = "";
					if(key.contains(".")) {
						//DSD Alias to key
						String[] aliasSplit = key.split("\\.", 2);
						alias = aliasSplit[0];
						key = aliasSplit[1];
					}
					key = "="+key;
					if(dsd == null) {
						dsd = tableSeries.getVariables().getDataStructure(alias);
						if(dsd == null) {
							if(alias.length() == 0) {
								alias = "(default)";
							}
							throw new SdmxSemmanticException("Unable to process formatting rule '"+key+"' DSD not found for alias '"+alias+"'");
						}
					}
				}
				if(notRule) {
					key = "!"+key;
				}
				scalingBySeries.put(new SeriesKeyPattern(key, dsd), scaleFactor.get(key));
			}
		}

		for(String alias : queries.keySet()) {
			DataQuery dq = queries.get(alias);
			obsStores.put(alias, new DataflowObsStore(dataRetrieval, dq, globalScale, scalingBySeries));
		}
	}
	
	@Override
	public boolean hasData() {
		for(DataflowObsStore store : obsStores.values()) {
			if(store.hasData()) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public ICellValue getCellValue(PublicationTableBodyCell cell) {
		List<String> footnotes = null;
		if(cell.isFreeText()) {
			String text = cell.getObservationKey().substring(1);  //Start from the 2nd char as the first char is the ' to indicate it is free text
			text = VariableUtil.replaceVariables(text, tableSeries.getVariables());
			return CellValue.getTextCell(text, footnotes);
		}
		if(cell.isCalculation()) {
			List<Observation> obsList = new ArrayList<>();  //a container to add the observation to that were used in this calculation
			ICellCalculation calculationKey = tableSeries.getCalculationKey(cell);
			String cellValue = resolveCalculatedCells(calculationKey, obsList);
			if(obsList.isEmpty()) {
				cellValue = StringUtil.EMPTY;
			}
			for(ISeriesCalculation seriesCalc : calculationKey.getSeriesCalculations()) {
				if(seriesCalc.getOriginalExpression() != null) {
					ICellKey cellKey = seriesCalc.getOriginalExpression();
					if(footnotes == null) {
						footnotes = new ArrayList<>(cellKey.getFootnotes().size());
					}
					for(String footnote : cellKey.getFootnotes()) {
						footnotes.add(VariableUtil.replaceVariables(footnote, tableSeries.getVariables()));
					}
				}
			}
			Observation obs = null;
			
			//Short code is the user assigned short code, which may be null
			String shortCode = calculationKey.getOutputCellKey();
			
			//In the case the short code is null, generate one based on the observation inputs to the calculation
			//'merge' the keys and replace variable dimensions with '#'
			if(shortCode == null) {
				String[] split = null;
				for(Observation currentObs : obsList) {
					String[] currentSplit = SeriesUtil.splitKey(currentObs.getSeriesKey().getShortCode());
					if(split == null) {
						split = currentSplit;
					} else {
						int iMax = Math.max(currentSplit.length, split.length);
						for(int i=0; i < iMax; i++) {
							if(split[i] == null) {
								continue;
							}
							String reportedValue = currentSplit[i];
							if(!split[i].equals(reportedValue)) {
								split[i] = null;
							}
						}
					}
				}
				shortCode = SeriesUtil.toSeriesKey(split, "#");
			}
			SdmxDate period = null;
			for(Observation currentObs : obsList) {
				SdmxDate thisPeriod = currentObs.getSdmxObsTime();
				if(thisPeriod == null) continue;
				if(period == null) {
					period = thisPeriod;
				} else if(!period.equals(thisPeriod)){
					period = null;
					break;
				}
			}
			
			//If there is a common time element, add it to the end of this short code
			if(shortCode != null) {
				if(period != null) {
					shortCode+=":"+period.getDateInSdmxFormat();
				} else {
					shortCode+=":#";
				}
			}
			
			if(calculationKey.getOutputDSD() != null && shortCode != null) {
				Keyable outputSeriesKey = KeyableImpl.buildFromShortCode(null, calculationKey.getOutputDSD(), shortCode);
				obs = ObservationImpl.timeSeries(outputSeriesKey, null, cellValue, null);
				
				if(this.obsValueFormatter != null) {
					cellValue = this.obsValueFormatter.getObservationValue(obs, PrimaryMeasureBean.FIXED_ID);
				}
			}
			return CellValue.getCalcCell(calculationKey, shortCode, cellValue, footnotes);
		}
		
		if(cell.getObservationKey() != null) {
			ICellKey cellKey = tableSeries.getObservationKey(cell);
			String cellValue = getObsValue(cellKey);
			if(ObjectUtil.validCollection(cellKey.getFootnotes())) {
				footnotes = new ArrayList<>(cellKey.getFootnotes().size());
				for(String footnote : cellKey.getFootnotes()) {
					footnotes.add(VariableUtil.replaceVariables(footnote, tableSeries.getVariables()));
				}
			}
			if(cellValue != null) {
				return CellValue.getObsCell(cellKey, cellValue, footnotes);
			}
		}
		return null;
	}
	
	@Override
	public String getObsValue(IObsKey cellKey) {
		DataflowObsStore store = obsStores.get(cellKey.getDataflowAlias());
		if(store == null) {
			return null;
		}
		Observation obs = store.getObservation(cellKey);
		if(obs == null) {
			return emptyCellValue;
		}
		if(cellKey.getAttribute() != null) {
			String attrVal = obs.getAttributeValue(cellKey.getAttribute());
			if(attrVal == null) {
				attrVal = obs.getSeriesKey().getAttributeValue(cellKey.getAttribute());
			}
			return attrVal;
		}
	
		if(this.obsValueFormatter != null) {
			return this.obsValueFormatter.getObservationValue(obs, cellKey.getMeasure());
		}
		return obs.getMeasureCode(cellKey.getMeasure());
	}

	/**
	 * @param calculation
	 * @param obs an empty contains to add observations to which form part of this calculated cell
	 * @return
	 */
	private String resolveCalculatedCells(ICellCalculation calculation, List<Observation> obsList) {
		if(calculation == null) {
			return StringUtil.EMPTY;
		}
		//Example $(1) - $(2)
		String expression = calculation.getCalculation();
		
		//Replace variables, $n with a number
		int varIdx = 0;
		boolean isEmpty = false;
		for(ISeriesCalculation seriesCalc : calculation.getSeriesCalculations()) {
			String number = executeCalculation(seriesCalc, obsList);
			if(number == null) {
				isEmpty = true;  //even though we could stop here, we need to get every obs for the calculation so the obs key can be correctly written
			} else {
				expression = expression.replace("${"+varIdx+"}", number);
			}
			varIdx++;
		}
		if(isEmpty) {
			return StringUtil.EMPTY;
		}
		try {
			return calculator.executeAsBigDecimal(expression).toPlainString();
		} catch(Throwable th) {
			throw new RuntimeException("Error calculating expression '"+expression+"' on cell calculation "+calculation.getObsCellValue());
		}
	}
	
	private String executeCalculation(ISeriesCalculation calc, List<Observation> obsList) {
		if(!calc.hasCalculatedDimension()) {
			return getObsValueAsDouble(calc.getOriginalExpression(), obsList, calc.getDefaultValue());
		}
		String expression = calc.getCalculationExpression();
		Map<String, ICellKey> var2ObsKey = calc.getVariableToCell();
		for(String variable : var2ObsKey.keySet()) {
			ICellKey obsKey = var2ObsKey.get(variable);
			Double defaultValue = calc.getDefaultValue(variable);
			String obsValue = getObsValueAsDouble(obsKey, obsList, defaultValue);
			if(obsValue == null) {
				return calc.getDefaultValue() != null ? calc.getDefaultValue().toString() : null;
			}
			expression = expression.replaceAll("\\{"+variable+"\\}", obsValue);
		}
		return calculator.executeAsBigDecimal(expression).toPlainString();
	}
	
	private String getObsValueAsDouble(ICellKey cellKey, List<Observation> obsList, Double missingValue) {
		DataflowObsStore store = obsStores.get(cellKey.getDataflowAlias());
		if(store == null) {
			return missingValue == null  ? null : missingValue.toString();
		}
		Observation obs = store.getObservation(cellKey);
		if(obs == null) {
			return missingValue == null  ? null : missingValue.toString();
		}

		obsList.add(obs);
		if(obs.getMeasure(cellKey.getMeasure()) != null && !obs.getMeasure(cellKey.getMeasure()).hasMultipleValues()){
			BigDecimal bd = obs.getNumericalMeasureValues().get(cellKey.getMeasure()).get(0);
			if(bd == null) {
				return missingValue == null  ? null : missingValue.toString();
			}
			return bd.toPlainString();
		}
		return null;
	}
	
	private class DataflowObsStore extends EmptySeriesObsDataWriterEngine implements ISeriesObsDataWriterEngine {
		private Map<String, Observation> obsKeyToValue = new HashMap<>();
		
		/**
		 * Build a cache of observation values for the query
		 * 
		 * @param dataRetrieval to get the data from
		 * @param query containing all the unique observations required for the publication table
		 * @param globalScale nullable - if not null this is the scale factor applied to the observation values (taking into account any scaling already applied via the UNIT_MULT attribute)
		 * @param scalingBySeries nullable - if not null this is the scale factor applied to observation values that match the pattern (taking into account any scaling already applied via the UNIT_MULT attribute)
		 */
		public DataflowObsStore(SdmxDataRetrievalWithWriter dataRetrieval, DataQuery query, Integer globalScale, Map<SeriesKeyPattern, Integer> scalingBySeries) {
			this.obsKeyToValue = new HashMap<>(query.getSeries().size());
			
			ISeriesObsDataWriterEngine dwe = this;
			if(globalScale != null || ObjectUtil.validMap(scalingBySeries)) {
				dwe = new ScalingDataWriterEngine(this, globalScale, scalingBySeries);
			}
			try {
				dataRetrieval.getData(query, dwe);
			} catch(SdmxNoResultsException e) {}
		}
		
		@Override
		public void writeObservation(Observation obs) {
			obsKeyToValue.put(obs.getShortCode(), obs);
		}
		
		public boolean hasData() {
			return obsKeyToValue.size() > 0;
		}
		
		/**
		 * @param cellKey identifier for observation (without dataflow alias) - example A:UK:EMP:2008
		 * @return
		 */
		private Observation getObservation(IObsKey cellKey) {
			return getObservationFromCache(cellKey);
		}
		
		/**
		 * @param cellKey identifier for observation (without dataflow alias) - example A:UK:EMP:2008
		 * @return
		 */
		private Observation getObservationFromCache(IObsKey cellKey) {
			String key = cellKey.getSeriesKey();
			if(cellKey.getObsTime() != null) {
				key += ":"+cellKey.getObsTime();
			}
			if(obsKeyToValue.containsKey(key)) {
				return obsKeyToValue.get(key);
			}
			return null;
		}
	}
}


