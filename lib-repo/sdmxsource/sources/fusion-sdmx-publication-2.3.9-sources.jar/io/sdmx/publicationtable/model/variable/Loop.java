package io.sdmx.publicationtable.model.variable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel;
import io.sdmx.api.sdmx.model.beans.publicationtable.ILoop;
import io.sdmx.utils.core.object.AssertUtil;

public class Loop implements ILoop {
	private String inputVariable;
	private String outputVariable;
	private boolean preserveHierarchy;
	private LOOP_ORDER order = LOOP_ORDER.NATURAL;
	private List<String> loopValues;
	private IHeadLabel label;
	private String asString;
	
	public Loop(String outputVariable, String inputVariable, boolean preserveHierarchy, LOOP_ORDER order, List<String> loopValues, IHeadLabel label) {
		AssertUtil.notNull(outputVariable, "Loop output variable required");
		AssertUtil.notNull(inputVariable, "Loop input variable required");
		
		this.inputVariable = inputVariable;
		this.outputVariable = outputVariable;
		this.preserveHierarchy = preserveHierarchy;
		if(order != null) {
			this.order = order;
		}
		this.loopValues = loopValues == null ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList<>(loopValues));
		this.label = label;
	}
	
	@Override
	public IHeadLabel getHeadLabel() {
		return label;
	}

	@Override
	public LOOP_ORDER getLoopOrder() {
		return order;
	}

	@Override
	public String getInputVariable() {
		return inputVariable;
	}

	@Override
	public String getOutputVariable() {
		return outputVariable;
	}

	@Override
	public boolean preserveHierarchy() {
		return preserveHierarchy;
	}

	@Override
	public List<String> getLoopValues() {
		return loopValues;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof Loop) {
			return obj.toString().equals(this.toString());
		}
		return false;
	}



	@Override
	public String toString() {
		if(asString == null) {
			StringBuilder sb = new StringBuilder();
			sb.append(outputVariable+":=LOOP("+inputVariable+","+preserveHierarchy+","+(order.ordinal()+1));
			if(loopValues != null) {
				for(String val : loopValues) {
					sb.append(","+val);
				}
			}
			sb.append(")");
			asString = sb.toString();
		}
		return asString;
	}

}
