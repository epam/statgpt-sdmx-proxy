package io.sdmx.publicationtable.model.bean;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableDataflowMutable;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PublicationTableDataflowImpl extends SDMXBeanImpl implements PublicationTableDataflow {
	private static final long serialVersionUID = 1L;
	private String alias;
	private IDirectCrossReferenceBean<DataflowBean> dataflowRef;

	public PublicationTableDataflowImpl(PublicationTableDataflowMutable mutableBean, PublicationTableBean parent) {
		super(mutableBean, parent);
		this.alias = mutableBean.getAlias();
		if(mutableBean.getDataflowRef() != null) {
			this.dataflowRef = DirectCrossReferenceBean.build(parent, "dataflow", mutableBean.getDataflowRef(), DataflowBean.class);
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(alias == null) {
			throw new SdmxSemmanticException("Dataflow Reference missing Id");
		}
		if(dataflowRef == null) {
			throw new SdmxSemmanticException("Dataflow Reference missing target URN");
		}
		if(dataflowRef.getTargetReference() != SDMX_STRUCTURE_TYPE.DATAFLOW) {
			throw new SdmxSemmanticException("Dataflow reference is to unexpected target structure: "+dataflowRef.getTargetReference().getType());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getKey() {
		return alias;
	}
	@Override
	public String getAlias() {
		return alias;
	}

	@Override
	public ICrossReferenceBean<DataflowBean> getDataflowRef() {
		return dataflowRef;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableDataflow that = (PublicationTableDataflow) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.alias, that.getAlias(), "Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getDataflowRef(), that.getDataflowRef(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.add(dataflowRef);
	}
}
