package  io.sdmx.publicationtable.model.output;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHeadRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTextCell;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;

public class OutputPublicationTableTHeadRowImpl implements OutputPublicationTableTHeadRow {
	
	private List<OutputPublicationTextCell> textCells = new ArrayList<>();
	
	public OutputPublicationTableTHeadRowImpl(PublicationTableHeadRow row, ICellVariables variables) {
		for(PublicationTableHeadCell cell : row.getHeaderCells()) {
			this.textCells.add(new OutputPublicationTextCellImpl(cell, variables));
		}
		textCells = Collections.unmodifiableList(textCells);
	}

	@Override
	public List<OutputPublicationTextCell> getCells() {
		return textCells;
	}

}
