package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;

public class ConditionalVariableImpl extends SDMXBeanImpl implements ConditionalVariable, INoCrossReferencesBean {
	private static final long serialVersionUID = 2L;
	private String id;
	private String dimensionCondition;
	private String dataflowAlias = StringUtil.EMPTY;
	private String name;
	private List<ConditionalVariableValues> conditionalVariableValues = new ArrayList<>();

	public ConditionalVariableImpl(ConditionalVariableMutable mutableBean, SDMXBean parent) {
		super(mutableBean, parent);
		this.id = mutableBean.getId();
		this.name = mutableBean.getName();
		this.dimensionCondition = mutableBean.getDimensionCondition();
		if(mutableBean.getFlowAlias() != null) {
			this.dataflowAlias = mutableBean.getFlowAlias();
		}
		List<ConditionalVariableValuesMutable> mappedVariables = mutableBean.getConditionalVariableValues();
		if(mappedVariables != null) {
			for(ConditionalVariableValuesMutable variable : mappedVariables) {
				this.conditionalVariableValues.add(new ConditionalVariableValuesImpl(variable, this));
			}
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(id)) {
			throw new SdmxSemmanticException("Conditional Variable missing Id");
		}
		if(!ObjectUtil.validString(dimensionCondition)) {
			throw new SdmxSemmanticException("Conditional Variable '"+id+"' missing Dimension Id");
		}
		this.dimensionCondition = ValidationUtil.cleanAndValidateId(dimensionCondition, true);  //Must be a valid ID
		if(!ObjectUtil.validString(name)) {
			throw new SdmxSemmanticException("Conditional Variable '"+id+"' missing Name");
		}
		if(conditionalVariableValues.size() == 0) {
			throw new SdmxSemmanticException("Conditional Variable '"+id+"' missing mapped values");
		}
		conditionalVariableValues = Collections.unmodifiableList(conditionalVariableValues);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConditionalVariable that = (ConditionalVariable) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.conditionalVariableValues, that.getConditionalVariableValues(), includeFinalProperties, "Conditional Values", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.id, that.getId(), "Id", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.name, that.getName(), "Name", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.dataflowAlias, that.getDataflowAlias(), "Alias", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.dimensionCondition, that.getDimensionCondition(), "Dimension Id", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getKey() {
		return id;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getDataflowAlias() {
		return dataflowAlias;
	}

	@Override
	public String getDimensionCondition() {
		return dimensionCondition;
	}

	@Override
	public List<ConditionalVariableValues> getConditionalVariableValues() {
		return conditionalVariableValues;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>(conditionalVariableValues);
	}

}
