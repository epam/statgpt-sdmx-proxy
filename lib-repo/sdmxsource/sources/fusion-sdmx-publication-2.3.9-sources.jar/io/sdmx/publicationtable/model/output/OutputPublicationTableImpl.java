package  io.sdmx.publicationtable.model.output;

import java.util.List;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTable;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBody;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHead;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.util.VariableUtil;

public class OutputPublicationTableImpl implements OutputPublicationTable {
	private String id;
	private String title;
	private String subTitle;
	private List<String> footnotes;
	private List<String> styles;
	private OutputPublicationTableTHead tHead;
	private OutputPublicationTableTBody tBody;
	private String timePeriod;
	private SdmxPeriod availablePeriod;
	private ICellVariables variables;
	private PublicationTableBean tableDef;
	

	/**
	 * @param tableBean - provides the structure of the report
	 * @param variables - to use to replace variable headings
	 * @param availablePeriod - optional, the earliest and latest time periods which have data for this table
	 * @param store
	 */
	public OutputPublicationTableImpl(
			PublicationTableBean tableBean, 
			ICellVariables variables,
			SdmxPeriod availablePeriod) {
		this.id = tableBean.getId();
		this.variables = variables;
		this.title = VariableUtil.replaceVariables(tableBean.getName(), variables);
		this.subTitle = VariableUtil.replaceVariables(tableBean.getDescription(), variables);

		this.tHead = new OutputPublicationTableTHeadImpl(tableBean, variables);
		this.tBody = new OutputPublicationTableTBodyImpl(tableBean, variables);
		if(variables.getTimePeriod() != null) {
			//TODO Date formatting
			this.timePeriod = variables.getTimePeriod().getBasePeriod().getDateInSdmxFormat();
		}
		this.availablePeriod = availablePeriod;
		this.tableDef = tableBean;
		this.footnotes = variables.getReferencedFootnotes();
	}

	@Override
	public PublicationTableBean getTableDef() {
		return tableDef;
	}

	@Override
	public ICellVariables getPublicationVariables() {
		return variables;
	}

	@Override
	public String getPeriod() {
		return timePeriod;
	}
	
	@Override
	public SdmxPeriod getAvailablePeriod() {
		return availablePeriod;
	}

	@Override
	public List<String> getStyles() {
		return styles;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getSubTitle() {
		return subTitle;
	}

	@Override
	public List<String> getFootnotes() {
		return footnotes;
	}

	@Override
	public OutputPublicationTableTHead getTHead() {
		return tHead;
	}

	@Override
	public OutputPublicationTableTBody getTBody() {
		return tBody;
	}
}
