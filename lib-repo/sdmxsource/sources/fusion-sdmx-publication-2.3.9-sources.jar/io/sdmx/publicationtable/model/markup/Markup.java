package io.sdmx.publicationtable.model.markup;

public class Markup {
	private String label;
	private char sybmol;
	
	
	public Markup(String label, char sybmol) {
		this.label = label;
		this.sybmol = sybmol;
	}
}
