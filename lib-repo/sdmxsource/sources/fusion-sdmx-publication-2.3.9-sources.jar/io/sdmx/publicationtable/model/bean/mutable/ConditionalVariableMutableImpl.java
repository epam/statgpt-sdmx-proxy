package  io.sdmx.publicationtable.model.bean.mutable;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.im.mutable.base.MutableBeanImpl;

import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;

public class ConditionalVariableMutableImpl extends MutableBeanImpl implements ConditionalVariableMutable {
	private static final long serialVersionUID = 1L;
	private String id;
	private String dimensionCondition;
	private String name;
	private String flowAlias;
	private List<ConditionalVariableValuesMutable> conditionalVariables = new ArrayList<>();
	
	public ConditionalVariableMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_CONDITIONAL_VARIABLE);
	}

	public ConditionalVariableMutableImpl(ConditionalVariable createdFrom, PublicationTableMutableBean parent) {
		super(createdFrom, parent);
		this.id = createdFrom.getId();
		this.name = createdFrom.getName();
		this.flowAlias = createdFrom.getDataflowAlias();
		this.dimensionCondition = createdFrom.getDimensionCondition();
		for(ConditionalVariableValues variable : createdFrom.getConditionalVariableValues()) {
			conditionalVariables.add(new ConditionalVariableValuesMutableImpl(variable, this));
		}
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public ConditionalVariableMutable setId(String id) {
		this.id = id;
		return this;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public ConditionalVariableMutable setName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public String getDimensionCondition() {
		return dimensionCondition;
	}

	@Override
	public ConditionalVariableMutable setDimensionCondition(String dimId) {
		this.dimensionCondition = dimId;
		return this;
	}
	
	@Override
	public String getFlowAlias() {
		return flowAlias;
	}

	@Override
	public ConditionalVariableMutable setFlowAlias(String alias) {
		this.flowAlias = alias;
		return this;
	}

	@Override
	public List<ConditionalVariableValuesMutable> getConditionalVariableValues() {
		return conditionalVariables;
	}

	@Override
	public ConditionalVariableMutable addConditionalVariableValues(ConditionalVariableValuesMutable values) {
		conditionalVariables.add(values);		
		return this;
	}

}
