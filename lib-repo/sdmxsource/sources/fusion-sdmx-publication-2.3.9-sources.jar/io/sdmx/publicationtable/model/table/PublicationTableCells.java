package io.sdmx.publicationtable.model.table;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ILoop;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.publicationtable.api.model.table.ICellCalculation;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.table.IPublicationTableCells;
import io.sdmx.publicationtable.api.model.table.IPublicationTableSeries;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

/**
 * Contains the set of all series keys referenced in the table
 */
public class PublicationTableCells implements IPublicationTableCells, IPublicationTableSeries {
	private Map<PublicationTableBodyCell, ICellKey> tableCell2ObsKey = new HashMap<>();
	private Map<PublicationTableBodyCell, ICellCalculation> tableCell2Calc = new HashMap<>();
	private ICellVariables variables;
	
	private Map<String, List<ICellKey>> cellsForFlow = new HashMap<>();
	
	
	private Map<String, SdmxPeriod> flow2Period;
	private Map<String, Set<String>> missingDimensionsPerFlow;
	
	private PublicationTableBean publicationTable;
	
	/**
	 * @param flowDataCells
	 * @param dataflowAlias
	 * @param variables
	 * @param includeTimePeriods if false the time period part of the key is not preserved, and any series which cast time are ignored
	 */
	public PublicationTableCells(PublicationTableBean publicationTable, ICellVariables variables) {
		this.variables = variables;
		this.publicationTable = publicationTable;
		
		Stack<ILoop> loops = null;
		
		int lastLevel = -1;
		int loopLevel = -1;  //The level at which the outermost loop started
		for(PublicationTableBodyRow row : publicationTable.getBodyRows()) {
			ILoop loop = row.getRowLabel().getLoop();
			
			int level = row.getLevel();
			if(loopLevel == level) {
				//Clear Loop as we are back at the same level when the loop started
				loops = null;
				loopLevel = -1;
				lastLevel = -1;
			}
			if(loop != null && loopLevel < 0) {
				//this is in a new loop
				loopLevel = level;
				loops = new Stack<>();
			}
			//We are in a loop
			if(loopLevel >= 0) {
				if(level < lastLevel) {  //we are 1 level less then the last loop level (but we are still in the loop)
					loops.pop();
				} else {  //we are 1 level deeper then the last loop or this is the first item in the loop
					loops.push(loop);
				}
			}
			Set<String> loopDimensions = loops == null ? Collections.emptySet() : loops.stream().map(e-> e == null ? null : e.getOutputVariable()).collect(Collectors.toSet());
			for(PublicationTableBodyCell tableCell : row.getTableCells()) {
				storeCellSeries(tableCell, loopDimensions);
			}
		}

		//Build the start and end period required in the data cells for each Dataflow
		Set<String> flowAlias = variables.getDataflowAlias();
		flow2Period = new HashMap<>(flowAlias.size());
		missingDimensionsPerFlow  = new HashMap<>(flowAlias.size());
		for(String alias : flowAlias) {
			Set<String> missingDimensions = null;
			DataStructureBean dsd = variables.getDataStructure(alias);
			boolean hasTime  = dsd.getTimeDimension() != null;
			SdmxDate earliestDate = null;
			SdmxDate latestDate = null;
			for(ICellKey cellKey : getCellsForFlow(alias)) {
				if(cellKey.getObsTime() != null) {
					if(earliestDate == null || cellKey.getObsTime().isEarlier(earliestDate)) {
						earliestDate = cellKey.getObsTime();
					}
					if(latestDate == null || cellKey.getObsTime().isLater(latestDate)) {
						latestDate = cellKey.getObsTime();
					}
				} else if(hasTime)  {
					if(missingDimensions == null) {
						missingDimensions = new HashSet<>(3);
					}
					missingDimensions.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
					hasTime = false; //already added so no need to keep adding time dimension
				}
				if(cellKey.getMissingDimensions().size() > 0) {
					if(missingDimensions == null) {
						missingDimensions = new HashSet<>(cellKey.getMissingDimensions().size());
					}
					missingDimensions.addAll(cellKey.getMissingDimensions());
				}
			}
			if(earliestDate != null) {
				SdmxPeriod flowPeriod = new SdmxPeriodImpl(earliestDate, latestDate);
				flow2Period.put(alias, flowPeriod);
			}
			if(missingDimensions == null) {
				missingDimensions = Collections.emptySet();
			}
			missingDimensionsPerFlow.put(alias, missingDimensions);
		}
 	}
	
	@Override
	public PublicationTableBean getPublicationTable() {
		return publicationTable;
	}

	@Override
	public Set<String> getMissingDimensions(String flowAlias) {
		return missingDimensionsPerFlow.get(flowAlias);
	}

	@Override
	/**
	 * @return all cell keys, including ones that make up calculations
	 */
	public List<ICellKey> getCellsForFlow(String flowAlias) {
		List<ICellKey> series = cellsForFlow.get(flowAlias);
		if(series == null) {
			return Collections.emptyList();
		}
		return Collections.unmodifiableList(series);
	}

	@Override
	public ICellKey addSeries(ICellKey cellKey) { 
		CollectionUtil.addToMappedList(this.cellsForFlow, cellKey.getDataflowAlias(), cellKey);
		return cellKey;
	}
	
	@Override
	public ICellVariables getVariables() {
		return variables;
	}

	@Override
	public SdmxPeriod getFlowPeriod(String flowAlias) {
		return flow2Period.get(flowAlias);
	}

	@Override
	public ICellKey getObservationKey(PublicationTableBodyCell cell) {
		return tableCell2ObsKey.get(cell);
	}
	
	@Override
	public ICellCalculation getCalculationKey(PublicationTableBodyCell cell) {
		return tableCell2Calc.get(cell);
	}
	
	private void storeCellSeries(PublicationTableBodyCell tableCell, Set<String> loopDimensions) {
		String obsCellValue = tableCell.getObservationKey();
		
		if(tableCell.getObservationKey() != null) {
			if(tableCell.isCalculation()) {
				ICellCalculation calc = new CellCalculation(variables, obsCellValue, loopDimensions);
				for(ISeriesCalculation sCalc : calc.getSeriesCalculations()) {
					if(sCalc.getCalculatedDimension() == null) {
						this.addSeries(sCalc.getOriginalExpression());
					} else {
						for(ICellKey cellKey : sCalc.getVariableToCell().values()) {
							this.addSeries(cellKey);
						}
					}
				}
				this.tableCell2Calc.put(tableCell, calc);
			} else if (tableCell.isObservation()) {
				//cell key with variables replaced
				ICellKey cellKey = this.addSeries(new CellKey(obsCellValue, variables, loopDimensions));
				this.tableCell2ObsKey.put(tableCell, cellKey);
			}
		}
	}
}
