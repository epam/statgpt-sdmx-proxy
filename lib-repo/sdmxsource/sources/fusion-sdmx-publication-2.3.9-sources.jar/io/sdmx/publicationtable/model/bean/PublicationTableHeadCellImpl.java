package io.sdmx.publicationtable.model.bean;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;
import io.sdmx.publicationtable.model.table.HeadLabel;

public class PublicationTableHeadCellImpl extends SDMXBeanImpl implements PublicationTableHeadCell {
	private static final long serialVersionUID = 1L;
	private String label;
	private int rowSpan;
	private int colSpan;
	
	private transient IHeadLabel rowLabel;
	
	public PublicationTableHeadCellImpl(PublicationTableHeadCellMutable headerCell, SDMXBean parent) {
		super(headerCell, parent);
		
		this.label = headerCell.getLabel();
		this.rowSpan = headerCell.getRowSpan();
		this.colSpan = headerCell.getColSpan();
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(rowSpan == 0) {
			rowSpan = 1;
		}
		if(colSpan == 0) {
			colSpan = 1;
		}
		if(rowSpan < 1) {
			throw new SdmxSemmanticException("Rowspan can not be less then 1");
		}
		if(colSpan < 1) {
			throw new SdmxSemmanticException("Colspan can not be less then 1");
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getKey() {
		return label;
	}

	@Override
	public String getLabel() {
		return label;
	}

	@Override
	public int getRowSpan() {
		return rowSpan;
	}

	@Override
	public int getColSpan() {
		return colSpan;
	}
	
	@Override
	public IHeadLabel getRowLabel() {
		if(rowLabel == null) {
			this.rowLabel = new HeadLabel(label);
		}
		return this.rowLabel;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableHeadCell that = (PublicationTableHeadCell) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.label, that.getLabel(), "Header Cells", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.colSpan, that.getColSpan(), "Colspan", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.rowSpan, that.getRowSpan(), "Rowspan", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	@Override
	public String toString() {
		return this.label;
	}
	
}
