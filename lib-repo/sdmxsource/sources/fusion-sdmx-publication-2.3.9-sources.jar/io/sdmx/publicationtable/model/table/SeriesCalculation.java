package io.sdmx.publicationtable.model.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.api.model.variable.ISeriesCalculation;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.SeriesUtil;

/**
 * A wrapper around a 'standard' series key 'A:UK:FR' or a series key with calculations in a dimension 'A:(UK+FR+DE):EMP'
 * 
 * If the series has calculations, hasCalculatedDimension will return true and the getCalculationExpression and getVariableToseries can be used to get the calculation
 * details
 */
public class SeriesCalculation implements ISeriesCalculation {
	private static final char[] SPLIT_CHARS = new char[] {":".charAt(0), "+".charAt(0), "-".charAt(0), "/".charAt(0), "*".charAt(0)};
	
	private ICellKey originalExpression;    //Example - basic series such as A:UK:EMP or an expression such as A:(UK+FR):EMP
	private Map<String, ICellKey> variable2Cell = Collections.emptyMap();   //Series keys
	private Map<String, Double> variable2Default = Collections.emptyMap();   //Series keys
	private String calculationExpression; //expression rewritten to remove series and replace with a[n] for example  A:(UK+FR):EMP becomes [UK]+[FR]
	private Integer calculatedDimension;
	private Double defaultValue;
	
	
	/**
	 * @param tableSeries
	 * @param cellKey with variable placeholders replaced
	 */
	public SeriesCalculation(ICellVariables variables, ICellKey cellKey, Set<String> loopDimensions, Double defaultValue) {
		this.originalExpression = cellKey;
		this.defaultValue = defaultValue;
		processSeries(variables, loopDimensions);
	}

	@Override
	public Double getDefaultValue() {
		return defaultValue;
	}
	
	@Override
	public Double getDefaultValue(String variable) {
		return variable2Default.get(variable);
	}

	/**
	 * @return true if this object contains calculation information, false if it is just a plain series key
	 */
	@Override
	public boolean hasCalculatedDimension() {
		return calculatedDimension != null;
	}

	/**
	 * @return zero indexed dimension position that contained the calculation expression, example A:(UK+FR+DE):EMP returns 1 as it is in the second dimension
	 */
	@Override
	public Integer getCalculatedDimension() {
		return calculatedDimension;
	}

	/**
	 * @return the original expression, e.g: A:(UK+FR+DE):EMP
	 */
	@Override
	public ICellKey getOriginalExpression() {
		return originalExpression;
	}

	/**
	 * @return a map of calculated part of the key, e.g. UK to the series/obs key e.g A:UK:EMP:2008
	 */
	@Override
	public Map<String, ICellKey> getVariableToCell() {
		return variable2Cell;
	}

	/**
	 * @return the calculated part of the series key extracted, example A:(UK+FR+DE):EMP will return [UK]+[FR]+[DE]
	 */
	@Override
	public String getCalculationExpression() {
		return calculationExpression;
	}

	@Override
	public int hashCode() {
		return originalExpression.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof SeriesCalculation) {
			return ((SeriesCalculation) obj).getOriginalExpression().equals(this.getOriginalExpression());
		}
		return false;
	}

	@Override
	public String toString() {
		return getOriginalExpression().toString();
	}
	
	/**
	 * Takes a series key and splits it into individual series, example A:(UK+FR+DE):EMP is split into A:UK:EMP, A:FR:EMP, A:DE:EMP
	 * these are stored in the series list in the order in which 
	 * @param seriesKey  A:(TOT-(UK+FR+DE)):EMP
	 */
	private void processSeries(ICellVariables variables, Set<String> loopDimensions) {
		/**
		 * Example: A:(EUR-(UK+FR+DE)/(2+ES)):EMP:(M+F)
		 * 
		 * ["A", ":", "EUR", "-", "UK", "+", "FR", "+", "DE", "/", "2", "+", "ES", ":", "EMP", ":","M", "+", "F"]
		 * [ 1,  -1 ,  2,  , -2 ,  3  , -3 ,  3  ,  -3,  3  , -2 ,  3,  -3 ,  3  , -1 ,  1   , -1 , 2 ,  -2,  2 ]   //position in tree structure
		 */
		Exp exp =  Exp.get(SPLIT_CHARS).parse(this.originalExpression.getSeriesKey());

		StringBuilder calculationSb = null;
		
		StringBuilder seriesSb = new StringBuilder();  //includes all the series codes in a series key, e.g. A:UK+FR+DE:EMP

		List<String> calculationStrings = new ArrayList<>();

		//Step 1 - rewrite the key as multiple keys
		int parentLevel = 0;
		int charPos = 0;
		String concat = "";
		int calcDimension = -1;
		int currentDimension = 0;
		for(int blockPos=0; blockPos < exp.size(); blockPos++) {
			String block = exp.getBlock(blockPos);
			int level = exp.getLevel(blockPos);
			if(level == 2 && parentLevel < 2 && parentLevel >= -1) {
				calcDimension = currentDimension;
				//Start calculation expression
				calculationSb = new StringBuilder();
			}
			charPos += block.toCharArray().length;

			//escape char
			if(level < 0) {
				switch(block) {
				case ":" :  
					concat = "";
					currentDimension++;
					//Dimension separator in series key always expected at level -1
					if(level == -1) {
						seriesSb.append(block);
					} else {
						throw new SdmxSemmanticException("Syntax error in expression:"+originalExpression + ". ':' at position '"+charPos+"' should be escaped using '\' if part of an expression.");
					}
					//next dimension
					break;
				default :
					if(level < -1) {
						//a special character is either a part of the calculation if we are in one, or part of the dimension expression if we are not
						calculationSb.append(block);
					} 
				}
			} else {
				//A non-special character, this is either a constant (number) or a dimension selection
				//if we are in a calculation, add it to the expression, a
				boolean isNumeric = false;
				if(level > 1) {
					isNumeric = block.startsWith("#") && NumberUtils.isParsable(block.substring(1));
					if(isNumeric) {
						//This is a number not a code ID 
						//TODO What if the code ID is a number, should it be escaped so the system knows?
						calculationSb.append(block.substring(1)); 
					} else {
						String calc = block;
						if(block.contains("|")) {
							String[] blockSplit = block.split("\\|");
							calc = blockSplit[0];
						}
						calculationSb.append("{"+calc+"}");  //use squigily brackets as the str.repalceAll takes a regex and [] means something in regex where {} does not (in this context)
					}
				} 
				if(!isNumeric) {
					seriesSb.append(concat+block);
					concat = "+";
				}
			}
			parentLevel = level;
		}
		if(calculationSb != null) {
			calculationStrings.add(calculationSb.toString());
		}
		String seriesKey = seriesSb.toString();
		if(calculationSb != null) {
			calculatedDimension = calcDimension;
			Set<String> expandedSeries = SeriesUtil.expandSeries(seriesKey);
			this.variable2Cell = new HashMap<>(expandedSeries.size());
			this.variable2Default = new HashMap<>(expandedSeries.size()); 
			for(String currentSeries : expandedSeries) {
				String keyComponent = SeriesUtil.splitKey(currentSeries)[calcDimension];
				
				if(keyComponent.contains("|")) {
					String[] blockSplit = keyComponent.split("\\|");
					keyComponent = blockSplit[0];
					if(blockSplit.length > 2) {
						throw new SdmxSemmanticException("Illegal value '["+keyComponent+"]'.  The reserved character '|' cannot occur multiple times in a series key part");
					}
					keyComponent = blockSplit[0];
					Double keyPartDefaultValue = NumberUtils.asDouble(blockSplit[1]);
					this.variable2Default.put(keyComponent, keyPartDefaultValue);
				}
				
				//Rebuild the key 
				StringBuilder rebuiltKeySb = new StringBuilder();
				String flowAlias = originalExpression.getDataflowAlias();
				if(flowAlias.length() > 0) {
					rebuiltKeySb.append(flowAlias+".");
				}
				rebuiltKeySb.append(currentSeries);
				if(this.originalExpression.getObsTime() != null) {
					rebuiltKeySb.append(":"+this.originalExpression.getObsTime());
				} else if(variables.getDataStructure(flowAlias).getTimeDimension() != null) {
					rebuiltKeySb.append(":P");
				}
				if(this.originalExpression.getMeasure() != null) {
					rebuiltKeySb.append(":"+this.originalExpression.getMeasure());
				}
				this.variable2Cell.put(keyComponent, new CellKey(rebuiltKeySb.toString(), variables, loopDimensions));
			}
			this.calculationExpression = calculationSb.toString();
			this.variable2Cell = Collections.unmodifiableMap(this.variable2Cell);
		} else {
			this.calculationExpression = seriesKey;  //There is no calculation - only a series key
		}
	}
}
