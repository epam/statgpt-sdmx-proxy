package  io.sdmx.publicationtable.model.output;

import java.util.List;

import io.sdmx.publicationtable.api.model.output.OutputPublicationTextCell;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.util.VariableUtil;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;

public class OutputPublicationTextCellImpl implements OutputPublicationTextCell {
	private List<String> styles;
	private String cellText;
	private int rowSpan;
	private int colSpan;
	
	public OutputPublicationTextCellImpl(PublicationTableHeadCell cell, ICellVariables variables) {
		this.cellText = VariableUtil.replaceVariables(cell.getRowLabel().getLabel(), variables);
		
		this.rowSpan = cell.getRowSpan();
		this.colSpan = cell.getColSpan();
	}

	@Override
	public List<String> getStyles() {
		return styles;
	}

	@Override
	public String getCellText() {
		return cellText;
	}

	@Override
	public int getRowSpan() {
		return rowSpan;
	}

	@Override
	public int getColSpan() {
		return colSpan;
	}

	@Override
	public String toString() {
		return cellText;
	}
	
	
}
