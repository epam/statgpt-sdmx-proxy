package  io.sdmx.publicationtable.model.output;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel.ANCHOR;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBody;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBodyRow;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

public class OutputPublicationTableTBodyImpl implements OutputPublicationTableTBody {
	private List<OutputPublicationTableTBodyRow> rows = new ArrayList<>();
	
	/**
	 * A counter we can add to in the build process
	 * @author Matthew Nelson
	 *
	 */
	private class Counter  {
		private int idx;
	}
	
	/**
	 * Creates Table Body Rows.  A Table Row is excluded from output if it has no data, and has no child rows which have data
	 * 
	 * @param tableDef
	 * @param variables
	 * @param store
	 */
	public OutputPublicationTableTBodyImpl(PublicationTableBean tableDef, ICellVariables variables) {
		Map<String, ICrossReferenceBean> flowRefs = new HashMap<>();
		for(PublicationTableDataflow dataflowRef : tableDef.getDataflowReferences()) {
			flowRefs.put(dataflowRef.getAlias(), dataflowRef.getDataflowRef());
		}
		List<PublicationTableBodyRow> allRows = tableDef.getBodyRows();
		this.rows = buildRows(new Counter(), flowRefs, allRows, 0, variables, ANCHOR.NO_ANCHOR);
		rows = Collections.unmodifiableList(rows);
	}
	
	private List<OutputPublicationTableTBodyRow> buildRows(Counter counter,
												 Map<String, ICrossReferenceBean> flowRefs, 
												 List<PublicationTableBodyRow> rows, int idx, 
												 ICellVariables variables, 
												 ANCHOR anchor) {
		List<OutputPublicationTableTBodyRow> builtRows = new ArrayList<>();
		int thisLevel = rows.get(idx).getLevel();
		
		OutputPublicationTableTBodyRow lastNoDataRow = null;
		for(int i=idx; i < rows.size(); i++) {
			//Build This Row
			PublicationTableBodyRow thisRow = rows.get(i);
			int rowLevel = thisRow.getLevel();
			
			ANCHOR thisAnchor = anchor;
			if(anchor == ANCHOR.NO_ANCHOR) {
				//only override the anchor if it is no anchor
				thisAnchor = thisRow.getRowLabel().getAnchor();
			}
			
			if(rowLevel == thisLevel) {
				//counter.add();
				OutputPublicationTableTBodyRow builtRow = new OutputPublicationTableTBodyRowImpl(flowRefs, rows, i, variables);
				if(builtRow.hasData() || thisAnchor != ANCHOR.NO_ANCHOR) {
					lastNoDataRow = null;
					builtRows.add(builtRow);
				} else {
					//If the row has no data, but subsequent child levels do - then keep this row
					lastNoDataRow = builtRow;
				}
			} else if(rowLevel > thisLevel) {
				Counter nextCounter = new Counter();
				ANCHOR parentAnchor = thisAnchor ==  ANCHOR.ANCHOR_FOLLLOWING ? thisAnchor : anchor;
				if(i > 0 && parentAnchor == ANCHOR.NO_ANCHOR) {
					parentAnchor = rows.get(i-1).getRowLabel().getAnchor();
				}
				List<OutputPublicationTableTBodyRow> childRows = buildRows(nextCounter, flowRefs, rows, i, variables, parentAnchor);
				i = nextCounter.idx-1;
				if(childRows.size() > 0) {
					if(lastNoDataRow != null) {
						builtRows.add(lastNoDataRow);
					}
					builtRows.addAll(childRows);
				}
				lastNoDataRow = null;
			} else if(rowLevel <= thisLevel) {
				counter.idx = i;
				return builtRows;
			}
		}
		counter.idx = rows.size();
		return builtRows;
	}

	@Override
	public List<OutputPublicationTableTBodyRow> getRows() {
		return rows;
	}
}
