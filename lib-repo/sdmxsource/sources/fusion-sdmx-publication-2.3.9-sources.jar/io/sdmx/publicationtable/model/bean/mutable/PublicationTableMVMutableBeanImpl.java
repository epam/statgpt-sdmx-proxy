package io.sdmx.publicationtable.model.bean.mutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMVMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class PublicationTableMVMutableBeanImpl extends MutableBeanImpl implements PublicationTableMVMutableBean {
	private static final long serialVersionUID = 1L;
	private String componentId;
	private String defaultMissingValue;
	private StructureReferenceBean missingValueMapping;
	
	public PublicationTableMVMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_MV_RULES);
	}

	public PublicationTableMVMutableBeanImpl(PublicationTableMVBean createdFrom, PublicationTableMutableBean parent) {
		super(createdFrom, parent);
		this.componentId = createdFrom.getComponentId();
		this.defaultMissingValue = createdFrom.getDefaultMissingValue();
		if(createdFrom.getMissingValueMapping() != null) {
			this.missingValueMapping = new StructureReferenceBeanImpl(createdFrom.getMissingValueMapping().getTargetUrn());
		}
	}

	@Override
	public String getComponentId() {
		return this.componentId;
	}

	@Override
	public PublicationTableMVMutableBean setComponentId(String compId) {
		this.componentId = compId;
		return this;
	}

	@Override
	public String getDefaultMissingValue() {
		return this.defaultMissingValue;
	}

	@Override
	public PublicationTableMVMutableBean setDefaultMissingValue(String mv) {
		this.defaultMissingValue = mv;
		return this;
	}

	@Override
	public StructureReferenceBean getMissingValueMapping() {
		return this.missingValueMapping;
	}

	@Override
	public PublicationTableMVMutableBean setMissingValueMapping(StructureReferenceBean ref) {
		this.missingValueMapping = ref;
		return this;
	}


	
}
