package io.sdmx.publicationtable.model.variable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.utils.core.expression.Exp;

/**
 * Parses a mix of variable text and 'normal' text to return a tree of Variable example
 * 
 * This is a $(variable) with $(a, $(sub), variable)
 * 
 * Outputs
 * |- This is a 
 * |- Variable  //TODO
 *  
 */
public class Variable {
	private boolean isVariable;
	private boolean hasChildVariables;
	private String text;
	private List<Variable> variables = Collections.emptyList();
	
	public static Variable build(String text) {
		return  new Variable(text, (text != null && text.startsWith("$(") && text.endsWith(")")));
	}
	
	private Variable(String text, boolean isVariable) {
		if(text == null) {
			return;
		}
		this.isVariable = isVariable;
		if(text.length() == 1) {
			this.text = text;
			return;
		}
		Exp exp = Exp.get("$".charAt(0)).blockCopy("(".charAt(0), ")".charAt(0)).parse(text);
		if(exp.size() > 1) {
			variables = new ArrayList<>(exp.size());
			boolean previousDollar = false;
			for(int i=0; i < exp.size(); i++) {
				int level = exp.getLevel(i);
				String val = exp.getBlock(i);
				if(level == 0) {
					//in parenthesis, did it start with a $
					if(previousDollar) {
						variables.add(new Variable(val, true));
						hasChildVariables = true;
					} else {
						Variable var = new Variable("("+val+")", false);
						variables.add(var);
						hasChildVariables = hasChildVariables || var.hasChildVaraibles();
					}
				} else if(level > 0) {
					if(previousDollar) {
						variables.add(new Variable("$", false));
					}
					variables.add(new Variable(val, false));
				}
				previousDollar = level == -1;
			}
			if(!hasChildVariables) {
				StringBuilder sb = new StringBuilder();
				for(Variable var : this.variables) {
					sb.append(var.getText());
				}
				this.text = sb.toString();
				this.variables = Collections.emptyList();
			} else {
				variables = Collections.unmodifiableList(variables);
			}
			
		} else {
			this.text = text;
		}
	}

	public boolean hasChildVaraibles() {
		return hasChildVariables;
	}
	
	public boolean isVariable() {
		return isVariable;
	}


	public void setVariable(boolean isVariable) {
		this.isVariable = isVariable;
	}


	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<Variable> getVariables() {
		return variables;
	}


	public void setVariables(List<Variable> variables) {
		this.variables = variables;
	}

	@Override
	public String toString() {
		String asString = text;
		if(asString == null) {
			StringBuilder sb = new StringBuilder();
			for(Variable var : variables) {
				sb.append(var.toString());
			}
			asString = sb.toString();
		}
		
		return isVariable ? "$("+asString+")" : asString;
	}
	
	
}
