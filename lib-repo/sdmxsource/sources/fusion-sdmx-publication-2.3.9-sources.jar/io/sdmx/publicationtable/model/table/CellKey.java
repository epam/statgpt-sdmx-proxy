package io.sdmx.publicationtable.model.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.publicationtable.api.model.table.ICellKey;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.variable.Variable;
import io.sdmx.publicationtable.util.FootnoteUtil;
import io.sdmx.publicationtable.util.VariableUtil;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.TimePeriod;
import io.sdmx.utils.core.object.AssertUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Decomposes a cell key into its parts. Examples:
 * 
 * DF1.UK:FR:DE:2008:OBS_VALUE  - DF1 is an optional Dataflow Alias, OBS_VALUE is an optional measure ID, 2008 is the time period if the DSD has a Time Dimension
 * UK:FR:DE:2008:OBS_VALUE  	- No Dataflow alias (default flow)
 * UK:FR:DE:2008				- No Measure, expects a DSD with only 1 measure and will use that
 * UK:FR:DE						- No Obs Time, expects a DSD with no time period and only 1 measure and will use that
 * UK:FR:DE:BIRTHS				- Explicit measure and no obs time, expects a DSD with no time period and a BIRTHS measure ID
 * 
 */
public class CellKey implements ICellKey {
	private String dataflowAlias = StringUtil.EMPTY;
	private String seriesKey;
	private SdmxDate obsTime;
	private String timeExpression;
	private String measure;
	private String attribute;
	private String cellKey;
	private List<String> footnotes;    //any footnote variables, e.g. $(1)
	private Set<String> missingDimensions = null; //Collections.emptySet();
	private Map<String, String> varaibleDimensions = null; //These are dimensions that have variable placeholders - variable id to dimension id

	/**
	 * @param cellKey Full Syntax: DF1.UK:FR:DE:2008:OBS_VALUE where DF1 is an optional dataflow alias,
	 * 
	 */
	public CellKey(String cellKey, ICellVariables variables, Set<String> loopDimensions) {
		if(loopDimensions == null) {
			loopDimensions = Collections.emptySet();
		}
		cellKey = cellKey.trim();
		Variable cellKeyVariables = Variable.build(cellKey);
		if(cellKeyVariables.getText() == null) {
			StringBuilder variableSb = new StringBuilder();
			for(Variable varaible : cellKeyVariables.getVariables()) {
				if(!varaible.isVariable()) {
					variableSb.append(StringUtil.trim(varaible.getText()));
				} else {
					String variablePart = varaible.toString();  //e.g. REF_AREA
					if(FootnoteUtil.isFootnote(variablePart)) {
						if(footnotes == null) {
							footnotes = new ArrayList<>(cellKeyVariables.getVariables().size());
						}
						footnotes.add(varaible.toString());
					} else {
						String variable = VariableUtil.getVariable(variablePart);
						if(!loopDimensions.contains(variable)) {
							throw new SdmxSemmanticException("Illegal cell key '"+cellKey+"' no variable to replace '"+variable+"'");
						}
						variableSb.append(varaible);
					}
				}
			}
			cellKey = variableSb.toString();
		}
		this.footnotes = footnotes == null ? Collections.emptyList() : Collections.unmodifiableList(footnotes);
		
		AssertUtil.notNull(variables, "Cell Variables");
		StringBuilder cellKeySb = new StringBuilder();
		
		String[] keyParts = SeriesUtil.splitKey(cellKey);
		
		boolean hasAlias = !keyParts[0].startsWith("(") && keyParts[0].contains(".");
		if(hasAlias) {
			String[] aliasSplit = keyParts[0].split("\\.", 2);
			this.dataflowAlias = aliasSplit[0];
			keyParts[0] = aliasSplit[1];
		}

		if(dataflowAlias.length() > 0) {
			cellKeySb.append(this.dataflowAlias+".");
		}
		
		DataStructureBean dsd = variables.getDataStructure(this.dataflowAlias);
		if(dsd == null) {
			throw new SdmxSemmanticException("No Dataflow with Alias '"+dataflowAlias+"' found");
		}
		List<String> dimIds = dsd.getDimensionIds();
		int dimSize = dimIds.size();

		//Replace variables in keys
//		String[] keyParts = SeriesUtil.splitKey(cellKey);
		if(keyParts.length < dimSize) {
			throw new SdmxSemmanticException("Key '"+cellKey+"' for DSD '"+dsd.getShortURN()+"' is too short. Expected size="+dimSize+" Dimensions");
		}
		
		for(int dimIdx=0; dimIdx < Math.min(keyParts.length, dimSize); dimIdx++) {
			String keyPart = keyParts[dimIdx];
			String dimId = dimIds.get(dimIdx);
			if(keyPart.length() == 0) {
//				if(loopDimensions.contains(dimId)) {
//					continue;
//				}
				keyParts[dimIdx] = variables.getDimensionValue(dimId);
				if(keyParts[dimIdx] == null) {
					if(missingDimensions == null) {
						missingDimensions = new HashSet<>(3);
					}
					this.missingDimensions.add(dimId);
				}
			} else if(VariableUtil.isVariable(keyPart)) {
				//The key part is a variable, $(VAR) replace it will null and store the variable placeholder on the key
				String variable = VariableUtil.getVariable(keyPart);
				if(!loopDimensions.contains(variable)) {
					throw new SdmxSemmanticException("Illegal cell key '"+cellKey+"' no variable to replace '"+variable+"'");
				}
				if(this.varaibleDimensions == null) {
					this.varaibleDimensions = new HashMap<>(3);
				}
				this.varaibleDimensions.put(variable, dimId);
				keyParts[dimIdx] = null;
			}
		}
		//Extract time string
		boolean hasTime = dsd.getTimeDimension() != null;
		this.timeExpression = hasTime ? "P" : null;  //Default to time 'now' unless otherwise stated
		if(keyParts.length > dimSize) {
			if(keyParts.length > dimSize+2) {
				throw new SdmxSemmanticException("Key '"+cellKey+"' for DSD '"+dsd.getShortURN()+"' exceeds expected length");
			}
			if(hasTime) {
				this.timeExpression = keyParts[dimSize];
				if(keyParts.length > (dimSize + 1)) {
					this.measure = keyParts[dimSize+1];
				}
			} else {
				measure = keyParts[dimSize];
			}
			this.seriesKey = SeriesUtil.toSeriesKey(keyParts, dimSize);
		} else {
			this.seriesKey = SeriesUtil.toSeriesKey(keyParts);
		}
		cellKeySb.append(this.seriesKey);
		
		if(this.timeExpression != null) {
			if(DateUtil.isSdmxDate(this.timeExpression)) {
				this.obsTime = SdmxDateImpl.getSdmxDate(this.timeExpression);
			}else if(variables.getTimePeriod() != null) {
				if(!TimePeriod.isExpresion(this.timeExpression)) {
					throw new SdmxSemmanticException("Error in key '"+cellKey+"'. Invalid time expression in key: "+this.timeExpression);
				}
				this.obsTime = variables.getTimePeriod().getTimePeriod(this.timeExpression);
			}
		}
		if(this.obsTime != null) {
			cellKeySb.append(":"+this.obsTime.getDateInSdmxFormat());
		} else if(hasTime) {
			if(this.missingDimensions == null) {
				this.missingDimensions = new HashSet<>(1);
			}
			this.missingDimensions.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
		if(this.missingDimensions == null) {
			this.missingDimensions = Collections.emptySet();
		} else {
			this.missingDimensions = Collections.unmodifiableSet(this.missingDimensions);
		}
		
		if(this.measure == null) {
			if(dsd.getMeasures().size() > 1) {
				throw new SdmxSemmanticException("Multiple Measures exist for DSD '"+dsd.getShortURN()+"'.  Cell key '"+cellKey+"' must define a Measure ID");
			}
			this.measure = dsd.getMeasures().get(0).getId();
		} else {
			if(dsd.getMeasure(measure) == null) {
				if(dsd.getAttribute(measure) != null) {
					this.attribute = measure;
					this.measure = null;
				} else {
					IURNSingle<?> measureURN = URN.builder().toIdentifiable(dsd.getURN(), SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION, measure).buildSingle();
					throw new SdmxReferenceException(measureURN);
				}
			}
			if(this.attribute != null) {
				cellKeySb.append(":"+this.attribute);
			} else if(dsd.getMeasures().size() > 1) {
				cellKeySb.append(":"+this.measure);
			}
		}
		this.cellKey = cellKeySb.toString();
	}
	
	@Override
	public List<String> getFootnotes() {
		return this.footnotes;
	}

	@Override
	public String getAttribute() {
		return this.attribute;
	}

	@Override
	public String getTimeExpression() {
		return timeExpression;
	}

	@Override
	public Set<String> getMissingDimensions() {
		return this.missingDimensions;
	}

	@Override
	public String getCellKey() {
		return this.cellKey;
	}

	/**
	 * @return the Measure Dimension ID
	 */
	@Override
    public String getMeasure() {
		return measure;
	}

	/**
	 * @return alias to the dataflow for the key
	 */
	@Override
    public String getDataflowAlias() {
		return dataflowAlias;
	}

	/**
	 * @return the series key e.g. A:UK:EMP
	 */
	@Override
    public String getSeriesKey() {
		return seriesKey;
	}

	/**
	 * @return time aspect to cell key if the DSD has a time dimension
	 */
	@Override
    public SdmxDate getObsTime() {
		return obsTime;
	}

	@Override
	public int hashCode() {
		return cellKey.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof CellKey) {
			return ((CellKey)obj).cellKey.equals(cellKey);
		}
		return false;
	}

	@Override
	public String toString() {
		return cellKey;
	}
}
