package  io.sdmx.publicationtable.model.bean.mutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;

public class PublicationTableHeadCellMutableImpl extends MutableBeanImpl implements PublicationTableHeadCellMutable {
	private static final long serialVersionUID = 1L;
	private String label;
	private int rowSpan;
	private int colSpan;
	
	public PublicationTableHeadCellMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_HEAD_CELL);
	}

	public PublicationTableHeadCellMutableImpl(String label, int colspan, int rowspan) {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_HEAD_CELL);
		this.label = label;
		this.rowSpan = rowspan;
		this.colSpan = colspan;
	}

	
	public PublicationTableHeadCellMutableImpl(PublicationTableHeadCell createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.label = createdFrom.getLabel();
		this.rowSpan = createdFrom.getRowSpan();
		this.colSpan = createdFrom.getColSpan();
	}

	@Override
	public String getLabel() {
		return label;
	}

	@Override
	public PublicationTableHeadCellMutable setLabel(String label) {
		this.label = label;
		return this;
	}

	@Override
	public int getRowSpan() {
		return rowSpan;
	}

	@Override
	public PublicationTableHeadCellMutable setRowSpan(int span) {
		this.rowSpan = span;
		return this;
	}

	@Override
	public int getColSpan() {
		return colSpan;
	}

	@Override
	public PublicationTableHeadCellMutable setColSpan(int span) {
		this.colSpan = span;
		return this;
	}
}
