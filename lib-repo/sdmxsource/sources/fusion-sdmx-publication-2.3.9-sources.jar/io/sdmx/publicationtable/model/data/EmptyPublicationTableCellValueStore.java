package io.sdmx.publicationtable.model.data;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.publicationtable.api.model.table.IObsKey;

/**
 * Used for validation purposes, this store is empty
 * @author Matthew Nelson
 *
 */
public class EmptyPublicationTableCellValueStore  implements IPublicationTableCellValueStore {
	private static EmptyPublicationTableCellValueStore INSTANCE = new EmptyPublicationTableCellValueStore();
	
	public static EmptyPublicationTableCellValueStore getInstance() {
		return INSTANCE;
	}
	
	private EmptyPublicationTableCellValueStore() {}

	@Override
	public ICellValue getCellValue(PublicationTableBodyCell cell) {
		return null;
	}
	
	@Override
	public String getObsValue(IObsKey obsKey) {
		return null;
	}

	@Override
	public boolean hasData() {
		return false;
	}

	
}
