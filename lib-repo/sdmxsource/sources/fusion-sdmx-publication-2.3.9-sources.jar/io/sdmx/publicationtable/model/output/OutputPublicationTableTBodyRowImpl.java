package  io.sdmx.publicationtable.model.output;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTBodyRow;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTextCell;
import io.sdmx.publicationtable.api.model.table.ICellValue;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

public class OutputPublicationTableTBodyRowImpl implements OutputPublicationTableTBodyRow {
	private OutputPublicationTextCell rowLabel;
	private List<ICellValue> cells;
	private boolean hasData = false;
	private int level;
	
	public OutputPublicationTableTBodyRowImpl(Map<String, ICrossReferenceBean> flowRefs, List<PublicationTableBodyRow> rows, int idx, ICellVariables variables) {
		PublicationTableBodyRow row = rows.get(idx);
		this.rowLabel = new OutputPublicationTextCellImpl(row.getHeadCell(), variables);
		this.level = row.getLevel();
		
		 cells = new ArrayList<>(row.getTableCells().size());
		for(PublicationTableBodyCell bodyCell : row.getTableCells()) {
			ICellValue cv = variables.getCellValueStore().getCellValue(bodyCell);
			if(cv != null && cv.getCellValue() != null && (cv.getCellKey() != null || cv.getCellCalculation() != null)) {
				hasData = true;
			}
			cells.add(cv);
		}
		this.cells = Collections.unmodifiableList(cells);
	}
	

	@Override
	public boolean hasData() {
		return hasData;
	}

	@Override
	public OutputPublicationTextCell getRowLabel() {
		return rowLabel;
	}

	@Override
	public List<ICellValue> getCells() {
		return cells;
	}

	@Override
	public int getLevel() {
		return level;
	}

	@Override
	public String toString() {
		if(rowLabel != null) {
			return rowLabel.toString();
		}
		return super.toString();
	}
}
