package io.sdmx.publicationtable.model.variable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.ITimePeriod;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.INamedBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.core.data.api.model.mapping.IFrequencyFormatMap;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.variable.IPublicationVariables;
import io.sdmx.publicationtable.constant.PUB_TABLE_CONST;
import io.sdmx.publicationtable.model.data.EmptyPublicationTableCellValueStore;
import io.sdmx.publicationtable.model.table.CellKey;
import io.sdmx.publicationtable.util.FootnoteUtil;
import io.sdmx.publicationtable.util.PublicationTableVariableUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.TimePeriod;
import io.sdmx.utils.core.object.ObjectUtil;

public class PublicationVariables implements IPublicationVariables {
	private IPublicationTableCellValueStore store = EmptyPublicationTableCellValueStore.getInstance();
	private Map<String, DataflowSuperBean> dataflowMap = new HashMap<>();

	private Map<String, String> dimensionVariables = new HashMap<>();

	//Variable Values
	private Map<String, EnumeratedListBean<? extends EnumeratedItemBean>> codedVariables = new HashMap<>();
	private Map<String, String> stringVariables = new HashMap<>();
	private Map<String, Integer> footnotesUsed = new HashMap<>();  //set footnote id to idx
	private List<String> footnotes = new ArrayList<>(); //footnote text

	private PublicationTableBean publicationTableBean;
	private IFrequencyFormatMap frequencyFormatMapping;  //optional


	private TimePeriod defaultPeriod;

	private Map<String, ComponentSuperBean<ComponentBean>> compSb = new HashMap<>();

	/**
	 * Constructor
	 * @param queryParameters
	 */
	public PublicationVariables(PublicationTableBean publicationTableBean, Map<String, String> queryParameters) {
		if(queryParameters != null) {
			for(String key : queryParameters.keySet()) {
				addStringVariable(key, queryParameters.get(key));
			}
			String variableTime = queryParameters.get(DimensionBean.TIME_DIMENSION_FIXED_ID);
			if(ObjectUtil.validString(variableTime)) {
				defaultPeriod = new TimePeriod(SdmxDateImpl.getSdmxDate(variableTime));
			} else {
				//TODO - exception, or default?
			}
		}
		this.publicationTableBean = publicationTableBean;
	}

	@Override
	public ITimePeriod getTimePeriod() {
		return defaultPeriod;
	}

	@Override
	public void setTimePeriod(String timePeriod) {
		defaultPeriod = new TimePeriod(SdmxDateImpl.getSdmxDate(timePeriod));
		addStringVariable(DimensionBean.TIME_DIMENSION_FIXED_ID, timePeriod);
	}

	@Override
	public List<String> getReferencedFootnotes() {
		return new ArrayList<>(this.footnotes);
	}

	@Override
	public DataStructureBean getDataStructure(String alias) {
		return getDataflowSb(alias).getDataStructure().getBuiltFrom();
	}

	@Override
	public DataflowBean getDataflow(String alias) {
		return getDataflowSb(alias).getBuiltFrom();
	}

	@Override
	public void setCodelist(String alias, EnumeratedListBean<? extends EnumeratedItemBean>  codelist) {
		codedVariables.put(alias, codelist);
	}
	

	@Override
	public void setFrequencyFormatMapping(IFrequencyFormatMap frequencyFormatMapping) {
		this.frequencyFormatMapping = frequencyFormatMapping;
	}

	@Override
	public void addDataflow(String alias, DataflowSuperBean dfSb) {
		if(dfSb != null) {
			dataflowMap.put(alias, dfSb);
			addStringVariable(alias, dfSb.getBuiltFrom().getName());
			addStringVariable(alias+"["+PUB_TABLE_CONST.ARRAY_VARIABLE_DESC+"]", dfSb.getBuiltFrom().getDescription());
			addStringVariable(alias+"["+PUB_TABLE_CONST.ARRAY_VARIABLE_ID+"]", dfSb.getId());
			addStringVariable(alias+".version", dfSb.getVersion().toString());

			PublicationTableDataflow df = getPublicationTableDataflow(alias);
			if(df == null) {
				throw new IllegalArgumentException("No Dataflow with alias '"+alias+"' found");
			}
			List<DimensionSuperBean> dimensions = dfSb.getDataStructure().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
			for(DimensionSuperBean dim : dimensions) {
				String dimId = dim.getId();
				String dimValue = stringVariables.get(dimId);
				if(ObjectUtil.validString(dimValue)) {
					addDimensionValue(df.getAlias(), dimId, dimValue);
				}
			}

			//			//Only add the variable if they exist in the map
			//			if(missingDimensions.size() > 0) {
			//				missingVariables.put(alias, missingDimensions);
			//			}
			for(ComponentSuperBean comp : dfSb.getDataStructure().getComponents()) {
				this.compSb.put(comp.getId(), comp);
			}
		} else {
			//TODO No Dataflow found
		}
	}

	private PublicationTableDataflow getPublicationTableDataflow(String alias) {
		for(PublicationTableDataflow ref : this.publicationTableBean.getDataflowReferences()) {
			if(ref.getAlias().equals(alias)) {
				return ref;
			}
		}
		return null;
	}

	@Override
	public void addDimensionValue(String alias, String dimId, String dimValue) {
		DataflowSuperBean df = dataflowMap.get(alias);
		if(df != null) {
			DimensionSuperBean dimSb = df.getDataStructure().getDimensionById(dimId);
			dimValue = dimValue.trim();
			dimensionVariables.put(dimSb.getId(), dimValue);
		}
	}


	@Override
	public void addStringVariable(String variableId, String variableValue) {
		this.stringVariables.put(variableId, variableValue);
	}
	
	@Override
	public Set<String> getVariableDimensions() {
		return dimensionVariables.keySet();
	}

	@Override
	public String getDimensionValue(String dimensionId) {
		return dimensionVariables.get(dimensionId);
	}

	@Override
	public Set<String> getDataflowAlias() {
		return dataflowMap.keySet();
	}

	private DataflowSuperBean getDataflowSb(String alias) {
		DataflowSuperBean dfSb = dataflowMap.get(alias);
		if(dfSb == null) {
			throw new SdmxSemmanticException("Dataflow with alias '"+alias+"' not found");
		}
		return dfSb;
			
	}
	
	@Override
	public EnumeratedListBean<? extends EnumeratedItemBean> getValues(String variableId) {
		ComponentSuperBean<ComponentBean> comp = compSb.get(variableId);
		if(comp != null) {
			return comp.getCodelist(true);
		}
		return codedVariables.get(variableId);
	}

	
	
	@Override
	/**
	 * @param variable expected either:
	 * number - pointer to a footnote
	 * string - pointer to a component, dataflow alias, time expression, or a query parameter
	 * string.string -  pointer to a component.codeid, or compoent.name, component.desc, dataflow (name), dataflow.desc, dataflow.id, dataflow.version,
	 * string[string] - pointer to a conditional variable
	 */
	public String getVariableValue(String variable) {
		//Footnotes is denoted by a variable in a number i.e. $(1), so if the variable string is a number it is a reference to a footnote
		if(FootnoteUtil.isFootnote(variable)) {
			String footnoteText = FootnoteUtil.getFootnote(variable, publicationTableBean, this);
			if(!ObjectUtil.validString(footnoteText)) {
				return null;
			}
			Integer footnoteIdx = footnotesUsed.get(footnoteText);
			if(footnoteIdx == null) {
				footnoteIdx= this.footnotes.size()+1;
				this.footnotes.add(footnoteText);
				footnotesUsed.put(footnoteText, footnoteIdx);
			}
			return "<sup>"+footnoteIdx+"</sup>";
		}

		//part 1 = main variable
		//part 2 = dot variable
		//part 3 = square brackets variable
		String[] variableParts = PublicationTableVariableUtil.getVariableParts(variable);
		String mainVariable = variableParts[0];
		String dotVariable = variableParts[1];
		String arrayVariable = variableParts[2];
		
		
		//Does it match a dynamic variable for the Dimension (i.e. the table is built for a particular REF_AREA)
		//If so return the value used for the Dimension
		String variableVal = dimensionVariables.get(mainVariable);
		if(variableVal != null) {
			if(arrayVariable != null) {
				if(arrayVariable.equals(PUB_TABLE_CONST.ARRAY_VARIABLE_ID)) {
					return variableVal;
				}
			}
			ComponentSuperBean<ComponentBean> comp = compSb.get(mainVariable);
			if(comp != null) {
				EnumeratedListBean<? extends EnumeratedItemBean> cl = comp.getCodelist(true);
				if(cl != null) {
					EnumeratedItemBean item = cl.getItemById(variableVal);
					if(item != null) {
						return getNameableValue(item, arrayVariable);
					}
				}
			}
			return variableVal;
		}
		
		//Is the variable a reference to a Cell Key if so return the reported measure or attribute for the observation
		if(variable.contains(":")) {
			CellKey cellkey = new CellKey(mainVariable, this, null);
			String reportedValue = store.getObsValue(cellkey);
			if(reportedValue != null && cellkey.getAttribute() != null) {
				ComponentSuperBean<ComponentBean> compSb = this.compSb.get(cellkey.getAttribute());
				EnumeratedListBean<? extends EnumeratedItemBean> cl = compSb.getCodelist(true);
				if(cl != null) {
					EnumeratedItemBean item	= cl.getItemById(reportedValue);
					if(item != null) {
						return getNameableValue(item, arrayVariable);
					}
				}
			}
			return reportedValue;
		}

		//Does the variable match a component in a DSD, if so return the component name/id/desc unless there is a dot variable, which indicates to use the Code for the Component
		ComponentSuperBean<ComponentBean> comp = compSb.get(mainVariable);
		EnumeratedListBean<? extends EnumeratedItemBean> cl = null;
		if(comp != null) {
			//this is drilling into the codelist for the component
			if(dotVariable != null) {
				cl = comp.getCodelist(true);
			} else {
				return getNameableValue(comp.getConcept().getBuiltFrom(), arrayVariable);
			}
		}
		//If there is no Codelist, is this an external variable
		if(cl == null) {
			cl = codedVariables.get(mainVariable);
		}
		if(cl != null && dotVariable != null) {
			EnumeratedItemBean item	= cl.getItemById(dotVariable);
			if(item != null) {
				return getNameableValue(item, arrayVariable);
			}
		}
		variableVal = stringVariables.get(variable);
		if(variableVal != null) {
			return variableVal;
		}
		if(this.defaultPeriod != null) {
			if(defaultPeriod.isExpression(variable)) {
				SdmxDate date = defaultPeriod.getTimePeriod(variable);
				if(frequencyFormatMapping != null) {
					return frequencyFormatMapping.formatDate(date);
				}
				return date.getDateInSdmxFormat();
			}
			
		}
		return variable;
	}
	
	private String getNameableValue(INamedBean nameable, String arrayVariable) {
		if(arrayVariable == null) {
			return nameable.getName();
		}
		switch(arrayVariable) {
		case PUB_TABLE_CONST.ARRAY_VARIABLE_ID:
			return nameable.getId();
		case PUB_TABLE_CONST.ARRAY_VARIABLE_DESC :
			return nameable.getDescription();
		case PUB_TABLE_CONST.ARRAY_VARIABLE_NAME :
			return nameable.getName();
			default : throw new SdmxSemmanticException("unknown array part: "+arrayVariable);
		}
	}

	@Override
	public void setCellValueStore(IPublicationTableCellValueStore store) {
		this.store = store;
	}

	@Override
	public IPublicationTableCellValueStore getCellValueStore() {
		return store;
	}
	
	
}


