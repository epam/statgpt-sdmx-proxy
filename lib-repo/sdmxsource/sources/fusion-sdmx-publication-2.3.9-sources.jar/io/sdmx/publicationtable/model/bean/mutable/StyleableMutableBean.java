package  io.sdmx.publicationtable.model.bean.mutable;

import java.util.Arrays;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.Styleable;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

import io.sdmx.publicationtable.api.model.bean.mutable.StyleableMutable;

public abstract class StyleableMutableBean extends MutableBeanImpl implements StyleableMutable {
	private static final long serialVersionUID = 1L;

	String[] styles;
	
	public StyleableMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public StyleableMutableBean(SDMXBean createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		if(createdFrom instanceof Styleable) {
			Styleable styleable = (Styleable) createdFrom;
			this.styles = new String[styleable.getStyles().size()];
			this.styles = styleable.getStyles().toArray(styles);
		}
	}

	@Override
	public String[] getStyles() {
		return styles;
	}

	@Override
	public void setStyles(String[] styles) {
		this.styles = styles;
	}

	@Override
	public void addStyle(String style) {
		if(styles == null || styles.length == 0) {
			styles = new String[1];
			styles[0] = style;
		} else {
			styles = Arrays.copyOf(styles, styles.length + 1);
			styles[styles.length-1] = style;
		}
	}
}
