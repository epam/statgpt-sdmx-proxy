package io.sdmx.publicationtable.model.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.data.engine.writer.SubConstraintDataWriterEngine;
import io.sdmx.publicationtable.api.model.availability.IPublicationTableAvailableData;

public class PublicationTableAvailableData implements IPublicationTableAvailableData {
	private DataQuery dataQuery;
	private String[] dimensionPosition;
	private List<String[]> series;
	private long seriesCount;
	
	public PublicationTableAvailableData(SubConstraintDataWriterEngine dwe, DataQuery dataQuery) {
		this.dataQuery = dataQuery;
		this.dimensionPosition = dwe.getDimensions();
		this.seriesCount = dwe.getSeriesCount();
		this.series = new ArrayList<>(dwe.getSeries().size());
		for(String series : dwe.getSeries()) {
			this.series.add(series.split(":"));
		}
	}
	
	@Override
    public DataQuery getDataQuery() {
		return dataQuery;
	}

	@Override
    public List<String[]> getSeries() {
		return series;
	}

	@Override
    public long getValidSeries() {
		return this.seriesCount;
	}
	
	@Override
    public String[] getDimensionPosition() {
		return dimensionPosition;
	}

	@Override
    public Map<String, Set<String>> getDistinctValuesByComponent() {
		Map<String, Set<String>> returnMap = new HashMap<>();
		for(int i = 0; i < dimensionPosition.length; i++) {
			String dimId = dimensionPosition[i];
			Set<String> validValues = new HashSet<>();
			for(String[] currentSeries : series) {
				validValues.add(currentSeries[i]);
			}
			returnMap.put(dimId, validValues);
		}
		return returnMap;
	}
	
}
