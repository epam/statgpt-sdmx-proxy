package  io.sdmx.publicationtable.model.bean.mutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;

public class PublicationTableBodyCellMutableImpl extends MutableBeanImpl implements PublicationTableBodyCellMutable {
	private static final long serialVersionUID = 1L;
	private String observationKey;
	
	public PublicationTableBodyCellMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_BODY_CELL);
	}
	
	public PublicationTableBodyCellMutableImpl(String observationKey, String valueOperation, String formatInformation) {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_BODY_CELL);
		this.observationKey = observationKey;
	}

	public PublicationTableBodyCellMutableImpl(PublicationTableBodyCell createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.observationKey = createdFrom.getObservationKey();
	}

	@Override
	public String getObservationKey() {
		return observationKey;
	}

	@Override
	public PublicationTableBodyCellMutable setObservationKey(String obsKey) {
		this.observationKey = obsKey;
		return this;
	}

}
