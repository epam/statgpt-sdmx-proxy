package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariableValues;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableValuesMutable;

public class ConditionalVariableValuesImpl extends SDMXBeanImpl implements ConditionalVariableValues {
	private static final long serialVersionUID = 1L;

	private String mappedId;
	private List<String> sourceIds = new ArrayList<String>();
	private Map<String, String> sourceTargetMap = new HashMap<>(); 

	public ConditionalVariableValuesImpl(ConditionalVariableValuesMutable variableMutable, ConditionalVariable parent) {
		super(variableMutable, parent);
		this.mappedId = variableMutable.getMappedId();
		List<String> sourceIds  = variableMutable.getSourceIds();
		if(sourceIds != null) {
			this.sourceIds = sourceIds;
			for(String sourceId : sourceIds) {
				sourceTargetMap.put(sourceId, variableMutable.getMappedValue(sourceId));
			}
		}
		validate();
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(mappedId)) {
			throw new SdmxSemmanticException("Conditional Variable missing Id");
		}
		if(sourceIds.size() == 0) {
			throw new SdmxSemmanticException("Conditional Variable Mapping for '"+mappedId+"' does not contain any mapped values");
		}
		sourceIds = Collections.unmodifiableList(sourceIds);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConditionalVariableValuesImpl that = (ConditionalVariableValuesImpl) bean;
			boolean returnVal = true;
			if(!super.equivalentCollection(this, this.getSourceIds(), that.getSourceIds(), "Conditional Source Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalentMap(this, this.sourceTargetMap, that.sourceTargetMap, "Conditional Source Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.mappedId, that.getMappedId(), "MappedId", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public String getKey() {
		return mappedId;
	}
	
	@Override
	public String getMappedId() {
		return mappedId;
	}

	@Override
	public List<String> getSourceIds() {
		return sourceIds;
	}

	@Override
	public String getMappedValue(String sourceId) {
		if(sourceId == null) {
			return null;
		}
		return sourceTargetMap.get(sourceId);
	}

	@Override
	public String getMappedValue(int sourceIdx) {
		if(sourceIds.size() <= sourceIdx) {
			return null;
		}
		String sourceId = sourceIds.get(sourceIdx);
		return getMappedValue(sourceId);
	}
}
