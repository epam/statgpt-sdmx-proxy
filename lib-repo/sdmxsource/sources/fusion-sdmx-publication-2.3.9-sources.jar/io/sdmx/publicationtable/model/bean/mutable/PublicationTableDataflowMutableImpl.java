package  io.sdmx.publicationtable.model.bean.mutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableDataflowMutable;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class PublicationTableDataflowMutableImpl extends MutableBeanImpl implements PublicationTableDataflowMutable {
	private static final long serialVersionUID = 1L;
	private String alias;
	private StructureReferenceBean dataflowRef;
	
	public PublicationTableDataflowMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_DATAFLOW_REF);
	}
	
	public PublicationTableDataflowMutableImpl(String id, String dataflowRef) {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_DATAFLOW_REF);
		this.alias = id;
		this.dataflowRef = new StructureReferenceBeanImpl(dataflowRef);
	}



	public PublicationTableDataflowMutableImpl(PublicationTableDataflow createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.alias = createdFrom.getAlias();
		this.dataflowRef = createdFrom.getDataflowRef().getReference().asMutable();
	}

	@Override
	public String getAlias() {
		return alias;
	}

	@Override
	public PublicationTableDataflowMutable setAlias(String alias) {
		this.alias = alias;
		return this;
	}

	@Override
	public StructureReferenceBean getDataflowRef() {
		return dataflowRef;
	}

	@Override
	public PublicationTableDataflowMutable setDataflowRef(StructureReferenceBean ref) {
		this.dataflowRef = ref;
		return this;
	}
}
