package io.sdmx.publicationtable.model.table;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel;
import io.sdmx.api.sdmx.model.beans.publicationtable.ILoop;
import io.sdmx.publicationtable.constant.PUB_TABLE_CONST;
import io.sdmx.publicationtable.model.variable.Loop;
import io.sdmx.utils.core.expression.Exp;

/**
 * A row label is text which can be parsed into a number of facets, markup, loop declaration, and a label
 */
public class HeadLabel implements IHeadLabel {
	//Match 	R:=LOOP(REF_AREA, FALSE, 1, UK, FR, DE) , Group 1=R, Group 2 = REF_AREA, FALSE, 1, UK, FR, DE
	private static final Pattern LOOP_PATTERN = Pattern.compile("(\\w+)*:=LOOP\\(([\\w,0-9 ]+)\\)(.*)");

		
	private ANCHOR anchor = ANCHOR.NO_ANCHOR;
	private ILoop loop;
	private String label;
	private int level = 1;

	public HeadLabel(String label) {
		if(label == null) {
			this.label = "";
			return;
		} 
		label = label.trim();
		//This could contain markup
		Exp exp = Exp.get().blockCopy("[".toCharArray()[0], "]".toCharArray()[0]).setSupportLevels(false).parse(label).trim();
		for(int i=0 ; i < exp.size(); i++) {
			if(exp.getLevel(i) == 0) {
				String expString = exp.substring(i, i);
				if(expString.startsWith("[anchor")) {
					String withoutBrackets = expString.substring(1, expString.length()-1);
					String lastChar = withoutBrackets.substring(withoutBrackets.length()-1);
					switch(lastChar) {
					case "*" :
						anchor = ANCHOR.ANCHOR_FOLLLOWING;
						break;
					case "+" : 
						anchor = ANCHOR.ANCHOR_CHILDREN;
						break;
					default : anchor = ANCHOR.ANCHOR_ROW;
					}
					label = label.replace(expString, "").trim();
					break;
				} 
			}
		}
		//levels
		char whitespace = " ".toCharArray()[0];
		char level = PUB_TABLE_CONST.LEVEL_PREFIX.toCharArray()[0];
		int i=0;
		for(char lChar : label.toCharArray()) {
			if(lChar == whitespace && level ==1) {
				i++;
				continue;
			}
			if(lChar == level) {
				i++;
				this.level++;
			} else {
				break;
			}
		}
		if(i> 0) {
			label = label.substring(i).trim();
		}
		loop = getLoop(label);
		if(loop == null) {
			this.label = label.trim();
		}
	}

	public ANCHOR getAnchor() {
		return anchor;
	}

	public ILoop getLoop() {
		return loop;
	}

	public String getLabel() {
		return label;
	}

	public int getLevel() {
		return level;
	}

	/**
	 * Checks if the string is representing a loop - if it is, it will return the loop information as an {@link ILoop}
	 * @param str
	 * @return {@link ILoop} if the string represents a loop, otherwise will return null
	 */
	private ILoop getLoop(String str) {
		Matcher matcher = LOOP_PATTERN.matcher(str);
		if(matcher.matches()) {
			String outVariable = matcher.group(1);
			String[] args = matcher.group(2).split(",");
			this.label = matcher.groupCount() > 2 ? matcher.group(3).trim() : null;
			if(this.label != null && this.label.length() ==0) {
				this.label = null;
			}
			
			int argMax = args.length;
			String inVariable = args[0].trim();
			boolean preserveHierarhcy = argMax > 1 ? Boolean.parseBoolean(args[1].trim()) : false;
			int order = argMax > 2 ? Integer.parseInt(args[2].trim()) : 1;
			List<String> varValues = null;
			if(argMax > 3) {
				varValues = new ArrayList<>(argMax-3);
				for(int i= 3; i < argMax; i++) {
					varValues.add(args[i].trim());
				}
			}
			if(outVariable == null) {
				outVariable = inVariable;
			}
			return new Loop(outVariable, inVariable, preserveHierarhcy, ILoop.LOOP_ORDER.parseVal(order),  varValues, this);
		}
		return null;
	}
}
