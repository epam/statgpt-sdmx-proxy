package  io.sdmx.publicationtable.model.bean.mutable;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.core.data.model.formatting.ObservationFormatting;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableDataflowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMVMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableVariableMappingMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationVariableMutableBean;
import io.sdmx.publicationtable.model.bean.PublicationTableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class PublicationTableMutableBeanImpl extends MaintainableMutableBeanImpl implements PublicationTableMutableBean {
	private static final long serialVersionUID = 1L;

	private List<TextTypeMutableBean> footnotes;
	private List<PublicationTableHeadRowMutable> headerRows;
	private List<PublicationTableBodyRowMutable> bodyRows;
	private List<ConditionalVariableMutable> conditionalVariables;
	private List<PublicationTableDataflowMutable> dataflowRefs;
	private List<PublicationVariableMutableBean> variableReferences;
	private StructureReferenceBean timeFormatMapping;
	private PublicationTableMVMutableBean missingValueRules;
	private List<PublicationTableVariableMappingMutableBean> variableMappings;
	private List<IObservationFormatting> obsFormatting;
	
	public PublicationTableMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_TABLE_DEF);
	}
	
	public PublicationTableMutableBeanImpl(PublicationTableBean bean) {
		super(bean);
		this.footnotes = new ArrayList<>();
		
		this.headerRows = new ArrayList<>();
		this.bodyRows = new ArrayList<>();
		this.conditionalVariables = new ArrayList<>();
		this.dataflowRefs = new ArrayList<>();
		this.variableReferences = new ArrayList<>();
		this.obsFormatting = new ArrayList<>();

		for(TextTypeBean footnote : bean.getFootnotes()) {
			this.footnotes.add(new TextTypeMutableBeanImpl(footnote, this));
		}
		for(PublicationTableHeadRow headerRow : bean.getHeaderRows()) {
			this.headerRows.add(new PublicationTableHeadRowMutableImpl(headerRow, this));
		}
		for(PublicationTableBodyRow bodyRow : bean.getBodyRows()) {
			this.bodyRows.add(new PublicationTableBodyRowMutableImpl(bodyRow, this));
		}
		for(ConditionalVariable cv : bean.getConditionalVariables()) {
			this.conditionalVariables.add(new ConditionalVariableMutableImpl(cv, this));
		}
		for(PublicationTableDataflow ref : bean.getDataflowReferences()) {
			this.dataflowRefs.add(new PublicationTableDataflowMutableImpl(ref, this));
		}
		for(PublicationVariableBean var : bean.getVariables()) {
			this.variableReferences.add(new PublicationTableVariableMutableBeanImpl(var, this));
		}
		if(bean.getTimeFormatMapping() != null) {
			this.timeFormatMapping = new StructureReferenceBeanImpl(bean.getTimeFormatMapping().getTargetUrn());
		}
		if(bean.getMissingValueRules() != null) {
			this.missingValueRules = new PublicationTableMVMutableBeanImpl(bean.getMissingValueRules(), this);
		}
		if(bean.getVariableMapping() != null) {
			this.variableMappings = new ArrayList<>(bean.getVariableMapping().size());
			for(PublicationTableVariableMappingBean currentMapping : bean.getVariableMapping()) {
				this.variableMappings.add(new PublicationTableVariableMappingMutableBeanImpl(currentMapping, this));
			}
		}
		if(bean.getObservationFormatting() != null) {
			for(IObservationFormatting that : bean.getObservationFormatting()) {
				this.obsFormatting.add(new ObservationFormatting(that));
			}
		}
	}
	
	@Override
	public List<IObservationFormatting> getObservationFormatting() {
		return this.obsFormatting;
	}

	@Override
	public void setObservationFormatting(List<IObservationFormatting> obsFormatting) {
		this.obsFormatting = obsFormatting;
	}

	@Override
	public List<PublicationTableVariableMappingMutableBean> getVariableMapping() {
		return variableMappings;
	}

	@Override
	public PublicationTableVariableMappingMutableBean addVariableMapping() {
		if(variableMappings == null) {
			variableMappings = new ArrayList<>(3);
		}
		PublicationTableVariableMappingMutableBean newMapping = new PublicationTableVariableMappingMutableBeanImpl();
		variableMappings.add(newMapping);
		return newMapping;
	}

	@Override
	public PublicationTableMutableBean setMissingValueRules(List<PublicationTableVariableMappingMutableBean> rules) {
		this.variableMappings = rules;
		return this;
	}

	@Override
	public PublicationVariableMutableBean addVariableReference(String id) {
		PublicationVariableMutableBean mutable = new PublicationTableVariableMutableBeanImpl();
		mutable.setId(id);
		if(this.variableReferences == null) {
			this.variableReferences = new ArrayList<>();
		}
		this.variableReferences.add(mutable);
		return mutable;
	}

	@Override
	public PublicationTableHeadRowMutable addHeaderRow() {
		PublicationTableHeadRowMutable mutable = new PublicationTableHeadRowMutableImpl();
		if(this.headerRows == null) {
			this.headerRows = new ArrayList<>();
		}
		this.headerRows.add(mutable);
		return mutable;
	}

	@Override
	public PublicationTableBodyRowMutable addBodyRow() {
		PublicationTableBodyRowMutable mutable = new PublicationTableBodyRowMutableImpl();
		if(this.bodyRows == null) {
			this.bodyRows = new ArrayList<>();
		}
		this.bodyRows.add(mutable);
		return mutable;
	}

	@Override
	public ConditionalVariableMutable addConditionalVariable() {
		ConditionalVariableMutable mutable = new ConditionalVariableMutableImpl();
		if(this.conditionalVariables == null) {
			this.conditionalVariables = new ArrayList<>();
		}
		this.conditionalVariables.add(mutable);
		return mutable;
	}

	@Override
	public PublicationTableDataflowMutable addDataflowReference() {
		PublicationTableDataflowMutable mutable = new PublicationTableDataflowMutableImpl();
		if(this.dataflowRefs == null) {
			this.dataflowRefs = new ArrayList<>();
		}
		this.dataflowRefs.add(mutable);
		return mutable;
	}
	
	@Override
	public StructureReferenceBean getTimeFormatMapping() {
		return this.timeFormatMapping;
	}

	@Override
	public PublicationTableMutableBean setTimeFormatMapping(StructureReferenceBean ref) {
		this.timeFormatMapping = ref;
		return this;
	}

	@Override
	public PublicationTableBean getImmutableInstance() {
		return new PublicationTableBeanImpl(this);
	}

	@Override
	public List<TextTypeMutableBean> getFootnotes() {
		return footnotes;
	}

	@Override
	public void setFootnotes(List<TextTypeMutableBean> footnotes) {
		this.footnotes = footnotes;
	}
	
	@Override
	public void addFootnote(String footnote) {
		TextTypeMutableBean tt = new TextTypeMutableBeanImpl();
		tt.addText(new TextTypeWrapperMutableBeanImpl("en", footnote));
		addFootnote(tt);
	}

	@Override
	public void addFootnote(TextTypeMutableBean footnote) {
		if(this.footnotes == null) {
			this.footnotes = new ArrayList<>();
		}
		this.footnotes.add(footnote);
	}

	@Override
	public List<PublicationTableHeadRowMutable> getHeaderRows() {
		return headerRows;
	}

	@Override
	public void setHeaderRows(List<PublicationTableHeadRowMutable> rows) {
		this.headerRows = rows;
	}

	@Override
	public void addHeaderRow(PublicationTableHeadRowMutable row) {
		if(this.headerRows == null) {
			this.headerRows = new ArrayList<>();
		}
		this.headerRows.add(row);
	}

	@Override
	public List<PublicationTableBodyRowMutable> getBodyRows() {
		return this.bodyRows;
	}

	@Override
	public void setBodyRows(List<PublicationTableBodyRowMutable> rows) {
		this.bodyRows = rows;
	}

	@Override
	public void addBodyRow(PublicationTableBodyRowMutable row) {
		if(this.bodyRows == null) {
			this.bodyRows = new ArrayList<>();
		}
		this.bodyRows.add(row);
	}

	@Override
	public List<ConditionalVariableMutable> getConditionalVariables() {
		return this.conditionalVariables;
	}

	@Override
	public void setConditionalVariables(List<ConditionalVariableMutable> rows) {
		this.conditionalVariables = rows;
	}

	@Override
	public void addConditionalVariable(ConditionalVariableMutable row) {
		if(this.conditionalVariables == null) {
			this.conditionalVariables = new ArrayList<>();
		}
		this.conditionalVariables.add(row);
	}

	@Override
	public List<PublicationTableDataflowMutable> getDataflowReferences() {
		return dataflowRefs;
	}

	@Override
	public void setDataflowReferences(List<PublicationTableDataflowMutable> rows) {
		this.dataflowRefs = rows;
	}

	@Override
	public void addDataflowReference(PublicationTableDataflowMutable row) {
		if(this.dataflowRefs == null) {
			this.dataflowRefs = new ArrayList<>();
		}
		this.dataflowRefs.add(row);
	}
	
	
	@Override
	public void addVariableReference(PublicationVariableMutableBean ref) {
		if(this.variableReferences == null) {
			this.variableReferences = new ArrayList<>();
		}
		this.variableReferences.add(ref);
	}

	@Override
	public List<PublicationVariableMutableBean> getVariableReferences() {
		return variableReferences;
	}

	@Override
	public void setVariableReferences(List<PublicationVariableMutableBean> refs) {
		this.variableReferences = refs;
	}
	
	@Override
	public PublicationTableMVMutableBean addMissingValueRules() {
		this.missingValueRules = new PublicationTableMVMutableBeanImpl();
		return this.missingValueRules;
	}

	@Override
	public PublicationTableMVMutableBean getMissingValueRules() {
		return this.missingValueRules;
	}

	@Override
	public PublicationTableMutableBean setMissingValueRules(PublicationTableMVMutableBean rules) {
		this.missingValueRules = rules;
		return this;
	}
	
}
