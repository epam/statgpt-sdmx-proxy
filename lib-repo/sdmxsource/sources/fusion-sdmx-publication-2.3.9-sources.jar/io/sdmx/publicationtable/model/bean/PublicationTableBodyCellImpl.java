package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;

public class PublicationTableBodyCellImpl extends SdmxStructureBeanImpl implements PublicationTableBodyCell {
	private static final long serialVersionUID = 3L;
	private List<String> styles = new ArrayList<>();
	private String observationKey;
	private String valueOperation;
	private String formatInformation;
	private int colIdx;
	
	private boolean isCalculation;
	private boolean isFreeText;
	
	private transient Set<Integer> variableDimensions = null;
	
	public PublicationTableBodyCellImpl(PublicationTableBodyCellMutable mutable, PublicationTableBodyRow parent, int cellIdx) {
		super(mutable, parent);

		this.colIdx = cellIdx;
		if(mutable.getObservationKey() != null) {
			String key = mutable.getObservationKey();
			if(key.startsWith("'")) {
				observationKey = key;
				this.isFreeText = true;
			} else if(key.contains(":=")) {
				observationKey = key;
				isCalculation = true;
			}  else {
				this.observationKey = key;
			}
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(observationKey)) {
			observationKey = null;
		}
	}
	

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public List<String> getStyles() {
		return styles;
	}

	@Override
	public String getValueOperation() {
		return valueOperation;
	}

	@Override
	public String getFormatInformation() {
		return formatInformation;
	}

	@Override
	public String getKey() {
		return getAlphaIndex();
	}
	
	@Override
	public boolean isCalculation() {
		return isCalculation;
	}

	@Override
	public String getObservationKey() {
		return observationKey;
	}
	
	@Override
	public int getColIdx() {
		return colIdx;
	}
	
	@Override
	public int getRowIdx() {
		return ((PublicationTableBodyRow)getParent()).getRowIdx();
	}

	@Override
	public String getAlphaIndex() {
		return ObjectUtil.intToAlpha(getColIdx()) + (getRowIdx()+1);
	}

	@Override
	public boolean isFreeText() {
		return isFreeText;
	}
	
	@Override
	public boolean isObservation() {
		return isFreeText() == false && isCalculation() == false;
	}

	@Override
	public Set<Integer> getVariableDimensions() {
		if(this.variableDimensions == null) {
			Set<Integer> variableDimensions = new HashSet<>();
			if(this.isObservation()) {
				String obsKey = getObservationKey();
				if(obsKey != null) {
					String[] keySplit = SeriesUtil.splitKey(obsKey);
					for(int i=0; i < keySplit.length; i++) {
						String keyAtPos = keySplit[i];
						if(!ObjectUtil.validString(keyAtPos) || keyAtPos.equals("*")) {
							variableDimensions.add(i);
						}
					}
				}
			}
			this.variableDimensions = Collections.unmodifiableSet(variableDimensions);
		}
		return variableDimensions;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableBodyCell that = (PublicationTableBodyCell) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.observationKey, that.getObservationKey(), "Observation Key", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.styles, that.getStyles(), "Styles", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.isCalculation, that.isCalculation(),  "is calculation", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.isFreeText, that.isFreeText(),  "is free text", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.formatInformation, that.getFormatInformation(), "Observation Format", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.valueOperation, that.getValueOperation(), "Value Operation", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	@Override
	public String toString() {
		return getAlphaIndex() + "="+getObservationKey();
	}

}
