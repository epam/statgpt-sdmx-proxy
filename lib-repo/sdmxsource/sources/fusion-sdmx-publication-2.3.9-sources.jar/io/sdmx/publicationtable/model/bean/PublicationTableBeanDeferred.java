package io.sdmx.publicationtable.model.bean;

import java.net.URL;
import java.util.Collection;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;
import io.sdmx.im.format.FusionMetadataStandard;

public class PublicationTableBeanDeferred extends MaintainableBeanDeferred<PublicationTableBean> implements PublicationTableBean {
    
    private static final long serialVersionUID = 1L;

    public PublicationTableBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public PublicationTableBeanDeferred(PublicationTableBean maint) {
        super(maint);
    }
    
    @Override
    public PublicationTableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new PublicationTableBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected PublicationTableBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new PublicationTableBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<PublicationTableBean> getURN() {
        return (IURNMaintainable<PublicationTableBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return PublicationTableBean.class;
    }
    
    @Override
    public IMetadataStandard getDefaultStandard() {
        return FusionMetadataStandard.getInstance();
    }

    @Override
    public MaintainableMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public Collection<PublicationTableDataflow> getDataflowReferences() {
        return load().getDataflowReferences();
    }

    @Override
    public ICrossReferenceBean<DataflowBean> getDataflowReference(String alias) {
        return load().getDataflowReference(alias);
    }

    @Override
    public ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping() {
        return load().getTimeFormatMapping();
    }

    @Override
    public List<PublicationTableVariableMappingBean> getVariableMapping() {
        return load().getVariableMapping();
    }

    @Override
    public PublicationTableMVBean getMissingValueRules() {
        return load().getMissingValueRules();
    }

    @Override
    public List<PublicationVariableBean> getVariables() {
        return load().getVariables();
    }

    @Override
    public List<PublicationTableHeadRow> getHeaderRows() {
        return load().getHeaderRows();
    }

    @Override
    public List<PublicationTableBodyRow> getBodyRows() {
        return load().getBodyRows();
    }

    @Override
    public List<ConditionalVariable> getConditionalVariables() {
        return load().getConditionalVariables();
    }

    @Override
    public List<TextTypeBean> getFootnotes() {
        return load().getFootnotes();
    }

    @Override
    public List<IObservationFormatting> getObservationFormatting() {
        return load().getObservationFormatting();
    }
}
