package io.sdmx.publicationtable.model.bean.mutable;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableVariableMappingMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class PublicationTableVariableMappingMutableBeanImpl extends MutableBeanImpl implements PublicationTableVariableMappingMutableBean {
	private static final long serialVersionUID = 1L;

	private String inputDimensionId;
	private List<String> outputDimensionId;
	private StructureReferenceBean mappingRules;
	
	public PublicationTableVariableMappingMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_VAR_MAPPING);
	}

	public PublicationTableVariableMappingMutableBeanImpl(PublicationTableVariableMappingBean createdFrom, PublicationTableMutableBean parent) {
		super(createdFrom, parent);
		this.inputDimensionId = createdFrom.getInputDimensionId();
		this.outputDimensionId = new ArrayList<>();
		this.outputDimensionId.addAll(createdFrom.getOutputDimensionId());
		this.mappingRules = new StructureReferenceBeanImpl(createdFrom.getMappingRules().getTargetUrn());
	}

	@Override
	public String getInputDimensionId() {
		return inputDimensionId;
	}

	@Override
	public PublicationTableVariableMappingMutableBean setInputDimensionId(String dimId) {
		this.inputDimensionId = dimId;
		return this;
	}

	@Override
	public List<String> getOutputDimensionId() {
		return outputDimensionId;
	}

	@Override
	public PublicationTableVariableMappingMutableBean addOutputDimensionId(String dimId) {
		if(outputDimensionId == null) {
			this.outputDimensionId = new ArrayList<>(3);
		}
		this.outputDimensionId.add(dimId);
		return this;
	}

	@Override
	public PublicationTableVariableMappingMutableBean setOutputDimensions(List<String> dimIds) {
		this.outputDimensionId = dimIds;
		return this;
	}

	@Override
	public StructureReferenceBean getMappingRules() {
		return mappingRules;
	}

	@Override
	public PublicationTableVariableMappingMutableBean setMappingRules(StructureReferenceBean sRef) {
		this.mappingRules = sRef;
		return this;
	}

}
