package io.sdmx.publicationtable.model.variable;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;
import io.sdmx.publicationtable.model.table.CellKey;
import io.sdmx.publicationtable.util.FootnoteUtil;
import io.sdmx.publicationtable.util.PublicationTableVariableUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * Used for validation purposes where only the DSD is required
 */
public class ValidationPublicationVariable implements ICellVariables {
	private IPublicationTableCellValueStore store;
	private Map<String, DatasetStructures> structures;
	private ValidationTimePeriod timePeriod = new ValidationTimePeriod();  //Just pick a random date to prevent NPE later
	private boolean hasTimeDimension = false;
	
	private Set<String> dimensionIds = new HashSet<>();

	private Set<String> variables = new HashSet<>();  //text variables
	private Set<Integer> footnoteReferences = new HashSet<>();
	private Map<String, Set<String>> dotVariables = new HashMap<>(); //variables in syntax string.string
	private Map<String, Set<String>> externalVariables = new HashMap<>(); //variables that are are an external codelist or valuelist
	private Map<String, Set<String>> conditionalVaraibles = new HashMap<>(); //variables in syntax string[string]

	private Set<String> dataflowAlias;
	
	private PublicationTableBean publicationTable;
	
	public ValidationPublicationVariable(PublicationTableBean publicationTable, SdmxBeanRetrievalManager brm) {
		this.publicationTable = publicationTable;
		int flowRefCount = publicationTable.getDataflowReferences().size();
		structures = new HashMap<>(flowRefCount);
		for(PublicationTableDataflow flowRef : publicationTable.getDataflowReferences()) {
			DatasetStructures dsdStructures = new DatasetStructures(flowRef.getDataflowRef().getReference(), brm);
			structures.put(flowRef.getAlias(), dsdStructures);
			if(dsdStructures.getDataStructure().getTimeDimension() != null) {
				hasTimeDimension = true;
			}
		}
		for(String id : SdmxCollectionUtil.identifiablesIdList(publicationTable.getVariables())) {
			externalVariables.put(id, new HashSet<>());
		}
		this.dataflowAlias = publicationTable.getDataflowReferences().stream().map(e -> e.getAlias()).collect(Collectors.toSet());
	}
	
	@Override
	public EnumeratedListBean<? extends EnumeratedItemBean> getValues(String variable) {
		return null;
	}

	public boolean hasTimeDimension() {
		return hasTimeDimension;
	}

	public Map<String, DatasetStructures> getStructures() {
		return structures;
	}
	
	/**
	 * @return a set of Dimension Ids referenced from within the table
	 */
	public Set<String> getDimensions() {
		return dimensionIds;
	}
	
	public Map<String, Set<String>> getDotVariables() {
		return dotVariables;
	}

	public Map<String, Set<String>> getConditionalVaraibles() {
		return conditionalVaraibles;
	}
	
	public Map<String, Set<String>> getExternalVariables() {
		return externalVariables;
	}

	public Set<Integer> getFootnoteReferences() {
		return footnoteReferences;
	}

	/**
	 * @return a set of variables used in the table
	 */
	public Set<String> getVariables() {
		return variables;
	}

	@Override
	public Set<String> getDataflowAlias() {
		return dataflowAlias;
	}

	@Override
	public List<String> getReferencedFootnotes() {
		return Collections.emptyList();
	}
	
	@Override
	public String getVariableValue(String variable) {
		if(FootnoteUtil.isFootnote(variable)) {
			variable = variable.split(",")[0];
			this.footnoteReferences.add(Integer.parseInt(variable));
		} else {
			String[] variableParts = PublicationTableVariableUtil.getVariableParts(variable);
			String mainVariable = variableParts[0];
			String dotVariable = variableParts[1];
			String arrayVariable = variableParts[2];
			
			
			if(variable.contains(":")) {
				//this is a cell reference - check it conforms
				CellKey cellKey = new CellKey(mainVariable, this, null);
				if(cellKey.getAttribute() == null) {
					throw new SdmxSemmanticException("Illegal variable '"+variable+"'. Cell Key must resolve to an attribute");
				}
				validateArrayVariable(variable, arrayVariable);
			} else if(dotVariable != null) {
				if(externalVariables.containsKey(mainVariable)) {
					externalVariables.get(mainVariable).add(dotVariable);
				} else {
					CollectionUtil.addToMappedSet(dotVariables, mainVariable, dotVariable);
				}
				if(arrayVariable != null) {
					validateArrayVariable(variable, arrayVariable);
				}
			} else if(arrayVariable != null) {
				//only the main and array variable present
				//either a conditional variable, or a id/name/label
				Set<String> conditionalVariables = this.publicationTable.getConditionalVariables().stream().map(e->e.getId()).collect(Collectors.toSet());
				if(conditionalVariables.contains(mainVariable)) {
					CollectionUtil.addToMappedSet(conditionalVaraibles, mainVariable, arrayVariable);
				} else {
					validateArrayVariable(variable, arrayVariable);
					this.variables.add(mainVariable);
				}
			} else {
				//only the main variable present
				this.variables.add(mainVariable);
			}
		}
		return null;
	}
	
	private void validateArrayVariable(String fullVariable, String arrayVariable) {
		if(arrayVariable != null) {
			if(!arrayVariable.equals("name") && !arrayVariable.equals("id") && !arrayVariable.equals("desc")) {
				throw new SdmxSemmanticException("Illegal variable '"+fullVariable+"' Array part expected to have a value of 'name', 'id', or 'desc' - but was "+arrayVariable);
			}
		}
	}

	@Override
	public String getDimensionValue(String dimensionId) {
		dimensionIds.add(dimensionId);  //This is a referenced dimension from a variable perspective
		return null;
	}

	@Override
	public Set<String> getVariableDimensions() {
		return Collections.emptySet();
	}

	@Override
	public DataflowBean getDataflow(String alias) {
		if(!structures.containsKey(alias)) {
			return null;
		}
		return structures.get(alias).getDataflow();
	}

	@Override
	public DataStructureBean getDataStructure(String alias) {
		if(!structures.containsKey(alias)) {
			return null;
		}
		return structures.get(alias).getDataStructure();
	}

	@Override
	public ValidationTimePeriod getTimePeriod() {
		return timePeriod;
	}

	@Override
	public void setCellValueStore(IPublicationTableCellValueStore store) {
		this.store = store;
	}

	@Override
	public IPublicationTableCellValueStore getCellValueStore() {
		return store;
	}
}