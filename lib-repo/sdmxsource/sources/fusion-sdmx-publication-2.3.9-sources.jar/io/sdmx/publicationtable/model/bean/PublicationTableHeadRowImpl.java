package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;

import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;

public class PublicationTableHeadRowImpl extends SDMXBeanImpl implements PublicationTableHeadRow {
	private static final long serialVersionUID = 1L;
	private List<PublicationTableHeadCell> headerCells = new ArrayList<>();
	
	public PublicationTableHeadRowImpl(PublicationTableHeadRowMutable mutableBean, PublicationTableBean parent) {
		super(mutableBean, parent);
		if(mutableBean.getHeaderCells() != null) {
			for(PublicationTableHeadCellMutable headerCell : mutableBean.getHeaderCells()) {
				this.headerCells.add(new PublicationTableHeadCellImpl(headerCell, this));
			}
		}
		validate();
	}

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		headerCells = Collections.unmodifiableList(headerCells);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getKey() {
		return null;
	}
	
	@Override
	public List<PublicationTableHeadCell> getHeaderCells() {
		return headerCells;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableHeadRow that = (PublicationTableHeadRow) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.headerCells, that.getHeaderCells(), includeFinalProperties, "Header Cells", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>(headerCells);
	}

}
