package io.sdmx.publicationtable.model.bean;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.ConditionalVariable;
import io.sdmx.api.sdmx.model.beans.publicationtable.IObservationFormatting;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableDataflow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.core.data.model.formatting.ObservationFormatting;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.beans.base.TextTypeBeanImpl;
import io.sdmx.im.format.FusionMetadataStandard;
import io.sdmx.publicationtable.api.model.bean.mutable.ConditionalVariableMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableDataflowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableVariableMappingMutableBean;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationVariableMutableBean;
import io.sdmx.publicationtable.model.bean.mutable.PublicationTableMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PublicationTableBeanImpl extends MaintainableBeanImpl implements PublicationTableBean {
	private static final long serialVersionUID = 4L;

	private List<TextTypeBean> footnotes;
	private List<PublicationTableHeadRow> headerRows;
	private List<PublicationTableBodyRow> bodyRows;
	private List<ConditionalVariable> conditionalVariables;
	private Map<String, PublicationTableDataflow> dataflowRefs;
	private List<PublicationVariableBean> publicationVariables;
	private IDirectCrossReferenceBean<IRepresentationMapBean> timeFormatMapping;
	private PublicationTableMVBean missingValueRules;
	private List<PublicationTableVariableMappingBean> variableMapping;
	private List<IObservationFormatting> obsFormatting;
	
	PublicationTableBeanImpl(PublicationTableBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public PublicationTableBeanImpl(PublicationTableMutableBean mutable) {
		super(mutable);
		if(ObjectUtil.validCollection(mutable.getFootnotes())) {
			this.footnotes = new ArrayList<>(mutable.getFootnotes().size());
			for(TextTypeMutableBean tt : mutable.getFootnotes()) {
				this.footnotes.add(new TextTypeBeanImpl("footnote", tt, this));
			}
		}
		if(ObjectUtil.validCollection(mutable.getDataflowReferences())) {
			this.dataflowRefs = new LinkedHashMap<>(mutable.getDataflowReferences().size());
			for(PublicationTableDataflowMutable dfRef : mutable.getDataflowReferences()) {
				PublicationTableDataflow dataflowRef = new PublicationTableDataflowImpl(dfRef, this);
				if(this.dataflowRefs.containsKey(dataflowRef.getAlias())) {
					throw new SdmxSemmanticException("Duplicate dataflow reference id '"+dataflowRef.getAlias()+"'");
				}
				this.dataflowRefs.put(dataflowRef.getAlias(), dataflowRef);
			}
		}

		if(ObjectUtil.validCollection(mutable.getHeaderRows())) {
			this.headerRows = new ArrayList<>(mutable.getHeaderRows().size());
			for(PublicationTableHeadRowMutable headerRow : mutable.getHeaderRows()) {
				this.headerRows.add(new PublicationTableHeadRowImpl(headerRow, this));
			}
		}
		if(ObjectUtil.validCollection(mutable.getBodyRows())) {
			int i = 0;
			this.bodyRows = new ArrayList<>(mutable.getBodyRows().size());
			for(PublicationTableBodyRowMutable bodyRow : mutable.getBodyRows()) {
				this.bodyRows.add(new PublicationTableBodyRowImpl(bodyRow, this, i));
				i++;
			}
		}
		if(ObjectUtil.validCollection(mutable.getVariableReferences())) {
			this.publicationVariables = new ArrayList<>(mutable.getVariableReferences().size());
			for(PublicationVariableMutableBean variable : mutable.getVariableReferences()) {
				this.publicationVariables.add(new PublicationTableVariableBeanImpl(variable, this));
			}
		}
		if(ObjectUtil.validCollection(mutable.getConditionalVariables())) {
			this.conditionalVariables = new ArrayList<>(mutable.getConditionalVariables().size());
			for(ConditionalVariableMutable cv : mutable.getConditionalVariables()) {
				this.conditionalVariables.add(new ConditionalVariableImpl(cv, this));
			}
		}
		if(ObjectUtil.validCollection(mutable.getVariableMapping())) {
			variableMapping = new ArrayList<>(mutable.getVariableMapping().size());
			for(PublicationTableVariableMappingMutableBean vm : mutable.getVariableMapping()) {
				this.variableMapping.add(new PublicationTableVariableMappingBeanImpl(vm, this));
			}
		}
		if(mutable.getTimeFormatMapping() != null) {
			this.timeFormatMapping = DirectCrossReferenceBean.build(this, "timeformatmapping", mutable.getTimeFormatMapping(), IRepresentationMapBean.class);
		}
		if(mutable.getMissingValueRules() != null) {
			this.missingValueRules = new PublicationTableMVBeanImpl(mutable.getMissingValueRules(), this);
		}
		if(mutable.getObservationFormatting() != null) {
			this.obsFormatting = new ArrayList<>();
			for(IObservationFormatting that : mutable.getObservationFormatting()) {
				this.obsFormatting.add(new ObservationFormatting(that));
			}
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return PublicationTableBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<PublicationTableBean> getURN() {
		return (IURNMaintainable<PublicationTableBean>)super.getURN();
	}
	
	@Override
	public Collection<PublicationTableDataflow> getDataflowReferences() {
		return dataflowRefs.values();
	}

	@Override
	public List<PublicationTableVariableMappingBean> getVariableMapping() {
		return variableMapping;
	}

	@Override
	public ICrossReferenceBean<DataflowBean> getDataflowReference(String alias) {
		PublicationTableDataflow dfRef = dataflowRefs.get(alias);
		if(dfRef != null) {
			return dfRef.getDataflowRef();
		}
		return null;
	}

	@Override
	public PublicationTableMVBean getMissingValueRules() {
		return this.missingValueRules;
	}

	@Override
	public List<PublicationVariableBean> getVariables() {
		return publicationVariables;
	}

	@Override
	public List<TextTypeBean> getFootnotes() {
		return footnotes;
	}

	@Override
	public List<PublicationTableHeadRow> getHeaderRows() {
		return headerRows;
	}

	@Override
	public List<PublicationTableBodyRow> getBodyRows() {
		return bodyRows;
	}

	@Override
	public List<ConditionalVariable> getConditionalVariables() {
		return conditionalVariables;
	}

	@Override
	public ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping() {
		return this.timeFormatMapping;
	}

	@Override
	public List<IObservationFormatting> getObservationFormatting() {
		return this.obsFormatting;
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new PublicationTableBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public MaintainableMutableBean getMutableInstance() {
		return new PublicationTableMutableBeanImpl(this);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		headerRows = headerRows == null ? Collections.emptyList() : Collections.unmodifiableList(headerRows);
		bodyRows = bodyRows == null ? Collections.emptyList() : Collections.unmodifiableList(bodyRows);
		conditionalVariables = conditionalVariables == null ? Collections.emptyList() : Collections.unmodifiableList(conditionalVariables);
		publicationVariables = publicationVariables == null ? Collections.emptyList() : Collections.unmodifiableList(publicationVariables);
		dataflowRefs = dataflowRefs == null ? Collections.emptyMap() : Collections.unmodifiableMap(dataflowRefs);
		footnotes = footnotes == null ? Collections.emptyList() : Collections.unmodifiableList(footnotes);
		variableMapping = variableMapping == null ? Collections.emptyList() : Collections.unmodifiableList(variableMapping);
		obsFormatting = obsFormatting == null ? Collections.emptyList() : Collections.unmodifiableList(obsFormatting);
		
		if(this.timeFormatMapping != null) {
			if(this.timeFormatMapping.getTargetReference() != SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP) {
				throw new SdmxSemmanticException("Time Format Mapping must reference a Representation Map");
			}
		}
		
		if(!isExternalReference) {
			if(dataflowRefs.size() == 0) {
				throw new SdmxSemmanticException("Publication Table is missing data inputs");
			}
			if(headerRows.size() == 0) {
				throw new SdmxSemmanticException("Publication Table is missing table header rows");
			}
			if(bodyRows.size() == 0) {
				throw new SdmxSemmanticException("Publication Table is missing table body rows");
			}
		}

		Set<String> uniqueIds = new HashSet<>();
		for(PublicationTableDataflow flowRef : this.getDataflowReferences()) {
			if(uniqueIds.contains(flowRef.getDataflowRef().getTargetUrn())) {
				throw new SdmxSemmanticException("Duplicate dataflow reference '"+flowRef.getDataflowRef().getTargetUrn()+"'");
			}
			uniqueIds.add(flowRef.getDataflowRef().getTargetUrn());
		}

		Set<String> uniqueVariableIds = new HashSet<>();
		for(PublicationVariableBean variable : this.getVariables()) {
			if(!uniqueVariableIds.add(variable.getId())) {
				throw new SdmxSemmanticException("Duplicate variable id '"+variable.getId()+"'");
			}
		}
		for(ConditionalVariable variable : this.getConditionalVariables()) {
			if(!uniqueVariableIds.add(variable.getId())) {
				throw new SdmxSemmanticException("Duplicate variable id '"+variable.getId()+"'");
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableBean that = (PublicationTableBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.headerRows, that.getHeaderRows(), includeFinalProperties, "Header Rows", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.bodyRows, that.getBodyRows(), includeFinalProperties, "Body Rows", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.conditionalVariables, that.getConditionalVariables(), includeFinalProperties, "Conditional Variables", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.missingValueRules, that.getMissingValueRules(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getFootnotes(), that.getFootnotes(), includeFinalProperties, "Footnotes", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.publicationVariables, that.getVariables(), "Variable", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.variableMapping, that.getVariableMapping(), includeFinalProperties, "Variable Mapping",  diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.timeFormatMapping, that.getTimeFormatMapping(), "Time Format Mapping", diff)) {
				returnVal =  false;
			}
			if(!super.equivalentCollection(this, this.obsFormatting, that.getObservationFormatting(), "Observation Formatting", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(this.getDataflowReferences(), that.getDataflowReferences(), includeFinalProperties, "Dataflow Reference", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(headerRows, composites);
		super.addToCompositeSet(bodyRows, composites);
		super.addToCompositeSet(conditionalVariables, composites);
		super.addToCompositeSet(this.publicationVariables, composites);
		super.addToCompositeSet(this.missingValueRules, composites);
		super.addToCompositeSet(this.variableMapping, composites);
		super.addToCompositeSet(this.dataflowRefs.values(), composites);
		return composites;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(this.timeFormatMapping != null) {
			references.add(this.timeFormatMapping);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////OVERRIDE DEFAULT FORMAT			     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IMetadataStandard getDefaultStandard() {
		return FusionMetadataStandard.getInstance();
	}

    @Override
    public PublicationTableBeanDeferred toDeferred() {
        return new PublicationTableBeanDeferred(this);
    }
    
    @Override
    public PublicationTableBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new PublicationTableBeanDeferred(getDeferredDefinition(), loader);
    }
}
