package  io.sdmx.publicationtable.model.bean.mutable;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadRowMutable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class PublicationTableHeadRowMutableImpl extends MutableBeanImpl implements PublicationTableHeadRowMutable {
	private static final long serialVersionUID = 1L;
	private List<PublicationTableHeadCellMutable> headerCells;
	
	public PublicationTableHeadRowMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_HEAD_ROW);
	}

	public PublicationTableHeadRowMutableImpl(PublicationTableHeadRow createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.headerCells = new ArrayList<>();
		for(PublicationTableHeadCell headCell : createdFrom.getHeaderCells()) {
			this.headerCells.add(new PublicationTableHeadCellMutableImpl(headCell, this));
		}
	}
	
	@Override
	public PublicationTableHeadCellMutable addHeaderCell() {
		if(headerCells == null) {
			headerCells = new ArrayList<>();
		}
		PublicationTableHeadCellMutable mutable = new PublicationTableHeadCellMutableImpl();
		headerCells.add(mutable);
		return mutable;
	}

	@Override
	public List<PublicationTableHeadCellMutable> getHeaderCells() {
		return headerCells;
	}

	@Override
	public void setHeaderCells(List<PublicationTableHeadCellMutable> cells) {
		this.headerCells = cells;
	}

	@Override
	public void addHeaderCell(PublicationTableHeadCellMutable cell) {
		if(headerCells == null) {
			headerCells = new ArrayList<>();
		}
		this.headerCells.add(cell);
	}

}
