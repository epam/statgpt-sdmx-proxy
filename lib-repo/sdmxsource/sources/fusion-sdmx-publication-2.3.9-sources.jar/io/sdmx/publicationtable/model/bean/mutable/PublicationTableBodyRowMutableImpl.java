package  io.sdmx.publicationtable.model.bean.mutable;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.publicationtable.IHeadLabel;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableHeadCellMutable;
import io.sdmx.publicationtable.model.table.HeadLabel;

public class PublicationTableBodyRowMutableImpl extends MutableBeanImpl implements PublicationTableBodyRowMutable {
	private static final long serialVersionUID = 1L;
	private PublicationTableHeadCellMutable headCell;
	private List<PublicationTableBodyCellMutable> tableCells = new ArrayList<>();
	private int level;
	
	public PublicationTableBodyRowMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.PUBLICATION_BODY_ROW);
	}

	public PublicationTableBodyRowMutableImpl(PublicationTableBodyRow createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.headCell = new PublicationTableHeadCellMutableImpl(createdFrom.getHeadCell(), this);
		for(PublicationTableBodyCell tbody : createdFrom.getTableCells()) {
			tableCells.add(new PublicationTableBodyCellMutableImpl(tbody, this));
		}
		this.level = createdFrom.getLevel();
	}

	
	@Override
	public IHeadLabel getRowLabel() {
		if(headCell == null) {
			return new HeadLabel("");
		}
		return new HeadLabel(headCell.getLabel());
	}

	@Override
	public PublicationTableHeadCellMutable setHeadCell() {
		this.headCell = new PublicationTableHeadCellMutableImpl();
		return this.headCell;
	}

	@Override
	public PublicationTableBodyCellMutable addTableCell() {
		PublicationTableBodyCellMutable cell = new PublicationTableBodyCellMutableImpl();
		if(tableCells == null) {
			tableCells = new ArrayList<>();
		}
		this.tableCells.add(cell);
		return cell;
	}

	@Override
	public PublicationTableHeadCellMutable getHeadCell() {
		return headCell;
	}

	@Override
	public void setHeadCell(PublicationTableHeadCellMutable tHead) {
		this.headCell = tHead;
	}

	@Override
	public List<PublicationTableBodyCellMutable> getTableCells() {
		return tableCells;
	}

	@Override
	public void setTableCells(List<PublicationTableBodyCellMutable> tableCells) {
		this.tableCells = tableCells;
	}

	@Override
	public void addTableCell(PublicationTableBodyCellMutable cell) {
		if(tableCells == null) {
			tableCells = new ArrayList<>();
		}
		tableCells.add(cell);
	}

	@Override
	public int getLevel() {
		return level;
	}
}
