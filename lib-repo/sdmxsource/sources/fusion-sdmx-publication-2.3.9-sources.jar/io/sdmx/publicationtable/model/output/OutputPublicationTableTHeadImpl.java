package  io.sdmx.publicationtable.model.output;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHead;
import io.sdmx.publicationtable.api.model.output.OutputPublicationTableTHeadRow;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadRow;

public class OutputPublicationTableTHeadImpl implements OutputPublicationTableTHead {

	private List<OutputPublicationTableTHeadRow> rows = new ArrayList<>();
	
	public OutputPublicationTableTHeadImpl(PublicationTableBean tableDef, ICellVariables variables) {
		for(PublicationTableHeadRow row : tableDef.getHeaderRows()) {
			rows.add(new OutputPublicationTableTHeadRowImpl(row, variables));
		}
		rows = Collections.unmodifiableList(rows);
	}

	@Override
	public List<OutputPublicationTableTHeadRow> getRows() {
		return rows;
	}

}
