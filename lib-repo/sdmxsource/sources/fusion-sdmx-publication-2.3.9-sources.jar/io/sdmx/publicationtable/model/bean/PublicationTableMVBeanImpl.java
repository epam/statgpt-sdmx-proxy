package io.sdmx.publicationtable.model.bean;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableMVBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableMVMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PublicationTableMVBeanImpl extends SDMXBeanImpl implements PublicationTableMVBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<IRepresentationMapBean> mvMapping;
	private String componentId;
	private String defaultMv;
	
	
	public PublicationTableMVBeanImpl(PublicationTableMVMutableBean mutableBean, PublicationTableBean parent) {
		super(mutableBean, parent);
		this.componentId = mutableBean.getComponentId();
		this.defaultMv = mutableBean.getDefaultMissingValue();
		if(mutableBean.getMissingValueMapping() != null) {
			this.mvMapping = DirectCrossReferenceBean.build(parent, "mvmapping", mutableBean.getMissingValueMapping(), IRepresentationMapBean.class);
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.mvMapping != null && componentId == null) {
			throw new SdmxSemmanticException("Missing value Representation Map reference requires a Componet ID to map");
		} else if(this.componentId != null && mvMapping == null) {
			throw new SdmxSemmanticException("Missing value Component requires a Representation Map reference");
		}
	}

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableMVBean that = (PublicationTableMVBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.mvMapping, that.getMissingValueMapping(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.componentId, that.getComponentId(), "Component Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.defaultMv, that.getDefaultMissingValue(), "Default MV", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	
	@Override
	public String getKey() {
		return componentId;
	}

	@Override
	public String getComponentId() {
		return componentId;
	}

	@Override
	public String getDefaultMissingValue() {
		return defaultMv;
	}

	@Override
	public ICrossReferenceBean<IRepresentationMapBean> getMissingValueMapping() {
		return mvMapping;
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(mvMapping != null) {
			references.add(mvMapping);
		}
	}

}
