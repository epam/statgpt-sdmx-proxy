package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableVariableMappingBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableVariableMappingMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PublicationTableVariableMappingBeanImpl extends SDMXBeanImpl implements PublicationTableVariableMappingBean {
	private static final long serialVersionUID = 1L;
	private String inputDimensionId;
	private List<String> outputDimensionId;
	private IDirectCrossReferenceBean<IRepresentationMapBean> mappingRules;

	public PublicationTableVariableMappingBeanImpl(PublicationTableVariableMappingMutableBean mutableBean, PublicationTableBean parent) {
		super(mutableBean, parent);
		this.inputDimensionId = mutableBean.getInputDimensionId();
		if(mutableBean.getMappingRules() != null) {
			this.mappingRules = DirectCrossReferenceBean.build(parent, "mappingrules", mutableBean.getMappingRules(), IRepresentationMapBean.class);
		}
		if(mutableBean.getOutputDimensionId() != null) {
			this.outputDimensionId = Collections.unmodifiableList(new ArrayList<>(mutableBean.getOutputDimensionId()));
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.inputDimensionId == null) {
			throw new SdmxSemmanticException("Can not create publication table variables - missing input Dimension ID");
		}
		if(this.outputDimensionId == null || this.outputDimensionId.size() < 1) {
			throw new SdmxSemmanticException("Can not create publication table variables - at least one output Dimension ID required");
		}
		if(this.mappingRules == null) {
			throw new SdmxSemmanticException("Can not create publication table variables - reference to representation map required");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableVariableMappingBean that = (PublicationTableVariableMappingBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.inputDimensionId, that.getInputDimensionId(), "Dimension ID", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.outputDimensionId, that.getOutputDimensionId(), "Output Dimension(s)", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.mappingRules, that.getMappingRules(),  diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	public String getKey() {
		return getInputDimensionId();
	}

	@Override
	public String getInputDimensionId() {
		return inputDimensionId;
	}

	@Override
	public List<String> getOutputDimensionId() {
		return outputDimensionId;
	}

	@Override
	public ICrossReferenceBean<IRepresentationMapBean> getMappingRules() {
		return mappingRules;
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.add(getMappingRules());
	}

}
