package io.sdmx.publicationtable.model.bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyCell;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBodyRow;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableHeadCell;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyCellMutable;
import io.sdmx.publicationtable.api.model.bean.mutable.PublicationTableBodyRowMutable;

public class PublicationTableBodyRowImpl extends SdmxStructureBeanImpl implements PublicationTableBodyRow {
	private static final long serialVersionUID = 2L;
	private PublicationTableHeadCell headCell;
	private List<PublicationTableBodyCell> tableCells = new ArrayList<>();
	private int rowIdx;
	
	public PublicationTableBodyRowImpl(PublicationTableBodyRowMutable mutable, PublicationTableBean parent, int rowNum) {
		super(mutable, parent);
		
		this.headCell = new PublicationTableHeadCellImpl(mutable.getHeadCell(), this);
		int i = 0;
		for(PublicationTableBodyCellMutable tc : mutable.getTableCells()) {
			tableCells.add(new PublicationTableBodyCellImpl(tc, this, i));
			i++;
		}
		this.rowIdx = rowNum;
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(headCell == null) {
			throw new SdmxSemmanticException("Table Body Row missing Header Cell");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				                 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
	public String getKey() {
		return null;
	}

	@Override
	public PublicationTableHeadCell getHeadCell() {
		return headCell;
	}

	@Override
	public List<PublicationTableBodyCell> getTableCells() {
		return tableCells;
	}

	@Override
	public int getRowIdx() {
		return rowIdx;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			PublicationTableBodyRow that = (PublicationTableBodyRow) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.headCell, that.getHeadCell(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.tableCells, that.getTableCells(), includeFinalProperties, "Table Cells", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> returnSet = new HashSet<>();
		returnSet.add(headCell);
		returnSet.addAll(tableCells);
		return returnSet;
	}

	@Override
	public String toString() {
		if(this.headCell != null) {
			return this.headCell.toString();
		}
		return super.toString();
	}
	
	

}
