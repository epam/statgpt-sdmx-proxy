package io.sdmx.publicationtable.model.variable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.ITimePeriod;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.publicationtable.api.model.data.IPublicationTableCellValueStore;
import io.sdmx.publicationtable.api.model.variable.ICellVariables;

public class PublicationVariablesProxy implements ICellVariables {
	private ICellVariables proxy;
	private Map<String, String> dimValues = null;

	
	public PublicationVariablesProxy(ICellVariables proxy, Map<String, String> dimValues) {
		this.proxy = proxy;
		this.dimValues = dimValues;
	}

	@Override
	public Set<String> getDataflowAlias() {
		return proxy.getDataflowAlias();
	}

	@Override
	public String getVariableValue(String variable) {
		return proxy.getVariableValue(variable);
	}

	@Override
	public EnumeratedListBean<? extends EnumeratedItemBean> getValues(String variable) {
		return proxy.getValues(variable);
	}

	@Override
	public String getDimensionValue(String dimensionId) {
		return dimValues != null && dimValues.containsKey(dimensionId) ? dimValues.get(dimensionId) : proxy.getDimensionValue(dimensionId);
	}

	@Override
	public Set<String> getVariableDimensions() {
		return proxy.getVariableDimensions();
	}

	@Override
	public DataflowBean getDataflow(String alias) {
		return proxy.getDataflow(alias);
	}

	@Override
	public DataStructureBean getDataStructure(String alias) {
		return proxy.getDataStructure(alias);
	}

	@Override
	public ITimePeriod getTimePeriod() {
		return proxy.getTimePeriod();
	}

	@Override
	public void setCellValueStore(IPublicationTableCellValueStore store) {
		proxy.setCellValueStore(store);
	}

	@Override
	public IPublicationTableCellValueStore getCellValueStore() {
		return proxy.getCellValueStore();
	}

	@Override
	public List<String> getReferencedFootnotes() {
		return proxy.getReferencedFootnotes();
	}
}


