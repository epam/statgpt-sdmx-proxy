package io.sdmx.publicationtable.model.variable;

import io.sdmx.api.date.ITimePeriod;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.TimePeriod;

public class ValidationTimePeriod implements ITimePeriod {
	private ITimePeriod timePeriod;
	private boolean hasBasePeriod;
	private boolean hasCastPeriod;

	public ValidationTimePeriod() {
		this.timePeriod = new TimePeriod(SdmxDateImpl.getSdmxDate("2010"));
	}

	@Override
	public SdmxDate getBasePeriod() {
		return timePeriod.getBasePeriod();
	}

	@Override
	public boolean isExpression(String expression) {
		return timePeriod.isExpression(expression);
	}

	@Override
	public SdmxDate getTimePeriod(String expression) {
		if(expression.startsWith("P")) {
			hasBasePeriod = true;
		} else {
			hasCastPeriod = true;
		}
		return timePeriod.getTimePeriod(expression);
	}
	
	public boolean hasCastPeriod() {
		return hasCastPeriod;
	}

	public boolean hasBasePeriod() {
		return hasBasePeriod;
	}
	
}
