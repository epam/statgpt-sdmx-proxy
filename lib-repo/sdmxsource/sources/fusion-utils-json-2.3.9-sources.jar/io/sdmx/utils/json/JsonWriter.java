package io.sdmx.utils.json;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.process.IProcess;
import io.sdmx.api.process.IProcessWithArgument;

public class JsonWriter {
    private final JsonGenerator jsonGenerator;
    
    public JsonWriter(JsonGenerator jsonGenerator) {
        this.jsonGenerator = jsonGenerator;
    }

    public JsonWriter(OutputStream out) {
        this.jsonGenerator = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON);
    }

    /**
     * Writes the array start and end, with an object start and end for each item T in the collection.
     * The provided Process is responsible for writing the object properties.
     * 
     * [
     *   { T[0] }
     *   { T[1] }
     *   { T[2] }
     * ]
     * 
     * @param <T>
     * @param fieldName
     * @param collection
     * @param p
     */
    public <T> void writeArray(String fieldName, Collection<T> collection, IProcessWithArgument<T> p) {
        try {
            this.jsonGenerator.writeArrayFieldStart(fieldName);
            for(T o : collection) {
                jsonGenerator.writeStartObject();
                p.runProcess(o);
                jsonGenerator.writeEndObject();
            }
            this.jsonGenerator.writeEndArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public <T> void writeStringArray(String fieldName, Collection<String> collection) {
        try {
            this.jsonGenerator.writeArrayFieldStart(fieldName);
            for(String o : collection) {
                this.jsonGenerator.writeString(o);
            }
            this.jsonGenerator.writeEndArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void writeObject(IProcess p) {
        try {
            jsonGenerator.writeStartObject();
            p.runProcess();
            jsonGenerator.writeEndObject();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void writeObject(String fieldName, IProcess p) {
        try {
            jsonGenerator.writeObjectFieldStart(fieldName);
            p.runProcess();
            jsonGenerator.writeEndObject();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void writeOptional(String fieldName, String value) {
        if(value != null) {
            try {
                jsonGenerator.writeStringField(fieldName, value);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    public void writeOptional(String fieldName, Object value) {
        if(value != null) {
            try {
                jsonGenerator.writeStringField(fieldName, value.toString());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    /**
     * Calls the process if T is not null
     * @param <T>
     * @param value
     * @param object
     */
    public <T> void writeOptional(T value, IProcessWithArgument<T> object) {
        if(value != null) {
            object.runProcess(value);
        }
    }
    
    public void writeMap(String fieldName, Map<String, String> prop2val) throws IOException {
        if(prop2val.isEmpty()) {
            return;
        }
        writeObject(fieldName, ()-> {
            prop2val.forEach((loc,val)-> {
                try {
                    jsonGenerator.writeStringField(loc, val);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        });
    }
    
    /**
     * Writes a collection of Objects as a JSON object container with the fieldName as
     * the container key. Each item in the collection is an entry in the
     * container. The process supplied to this method is responsible for creating a single entry
     * and is expected to create a field name and value (simple value, or object / array)
     * 
     * fieldName : {
     *   [key1] : value,
     *   [key2] : value,
     * }
     * @param <T>
     * @param fieldName
     * @param collection
     * @param p
     */
    public <T> void writeMap(String fieldName, Collection<T> collection, IProcessWithArgument<T> p) {
        writeObject(fieldName, ()-> {
            for(T o : collection) {
                p.runProcess(o);
            }
        });
    }
}
