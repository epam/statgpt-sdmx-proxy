package io.sdmx.utils.json;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import io.sdmx.api.io.ReadableDataLocation;

public class YAMLReader extends JsonReader {

    public YAMLReader(ReadableDataLocation rdl) {
        super(rdl);
    }

    @Override
    protected JsonFactory getJsonFactory() {
        return new YAMLFactory();
    }
    
    

}
