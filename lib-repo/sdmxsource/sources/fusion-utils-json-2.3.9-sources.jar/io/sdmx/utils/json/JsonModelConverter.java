package io.sdmx.utils.json;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonModelConverter<T> {
    private static final Logger LOG = LoggerFactory.getLogger(JsonModelConverter.class);
    private final ObjectMapper mapper = new ObjectMapper();
    private final Class<T> modelType;

    public JsonModelConverter(Class<T> modelType){
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.FAIL_ON_SELF_REFERENCES, false);
        this.modelType = modelType;
    }

    public T deserialize(String jsonString) {
        try {
            // Deserialize the JSON string into modelType T
            return mapper.readValue(jsonString, this.modelType);
        } catch (Exception e) {
            LOG.error("Could not deserialize json string to model!", e.getCause());
            return null;
        }
    }

    public String serialize(T object) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            LOG.error("Could not serialize model to json string!", e.getCause());
            return null;
        }
    }
}
