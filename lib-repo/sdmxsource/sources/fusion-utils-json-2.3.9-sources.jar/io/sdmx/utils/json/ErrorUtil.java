package io.sdmx.utils.json;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;

public class ErrorUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(ErrorUtil.class);
	
	public static int getResponseStatus(Throwable th) {
		Throwable th2 = th;
		int status = -1;
		while(th2 != null) {
			if(th2 instanceof SdmxException) {
				SdmxException e = (SdmxException)th2;
				if(e.getHttpRestErrorCode() != null) {
					status = e.getHttpRestErrorCode();
				}
			}
			th2 = th2.getCause();
		}
		if(status < 0) {
		    if (th == null) {
		        status = 200;
		    } else if(th instanceof IllegalArgumentException) {
		        status = 400; //Bad Request
		    } else if(th instanceof RuntimeException) {
                status = 500; //Server Error
			} else {
			    status = 400;
			}
		}
		return status;
	}
	
	public static String getErrorMessage(Throwable th, String separator) {
		Throwable th2 = th;
		StringBuilder sb = new StringBuilder();
		String previousMessage = "";
		
		while(th2 != null) {
			String newMessage = th2.getMessage();
			if(newMessage == null) {
				newMessage = th.getClass().getName();
			} else if(newMessage.contains("Exception: ")) {
				newMessage = newMessage.split("Exception: ")[1];
			}
			if(!newMessage.equals(previousMessage)) {
				sb.append(newMessage+separator);
			}
			previousMessage = newMessage;
			th2 = th2.getCause();
		}
		return sb.toString();
	}
	
	public static void writeError(Throwable th, OutputStream out) {
		writeError(getErrorMessage(th, System.getProperty("line.separator")), getResponseStatus(th),  out);
	}

	public static void writeError(String message, OutputStream out) {
		writeError(message, 200, out);
	}
	
	public static void writeError(String message, int status, OutputStream out) {
		try {
			if(message == null) {
				message = "Null Pointer Exception";
			}
			JSONObject jsonError = getJsonError(message, status);
			try(OutputStreamWriter writer = new OutputStreamWriter(out, StandardCharsets.UTF_8);){
				jsonError.write(writer);
			}
		} catch (Throwable e) {
			LOG.error("Unable to create JSON Error message. " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public static JSONObject getJsonError(String message, int status) {
		JSONObject errorResponse = new JSONObject();
		JSONArray arr = new JSONArray();
		for(String currentError : message.split(System.lineSeparator())) {
			arr.put(currentError);
		}
		try {
			errorResponse.put("Error", arr);
			errorResponse.put("Status", status);
		} catch (JSONException e) {
			LOG.error("Unable to create JSON Error message. " + e.getMessage());
			e.printStackTrace();
		}
		return errorResponse;
	}
	
	public static JSONObject getSuccess() {
		JSONObject successResponse = new JSONObject();
		try {
			successResponse.append("Success", true);
		} catch (JSONException e) {
			LOG.error("Unable to create JSON Success message. " + e.getMessage());
			e.printStackTrace();
		}
		return successResponse;
	}

	public static void writeSuccess(OutputStream out) {
		try (OutputStreamWriter writer = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
			getSuccess().write(writer);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
