package io.sdmx.utils.json;

/**
 * The key shared characteristic of JSON and YAML is:
 * They are tree-structured, key–value–centric, JSON-schema–compatible,
 * data-serialization languages that can be represented by a JsonParser / JsonGenerator.
 */
public enum JSON_COMPATIBLE_FORMAT {
    JSON,
    YAML;
}
