package io.sdmx.utils.json;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonValidationUtil {
	
	/**
	 * @param json the String to evaluate
	 * @return Whether the supplied string is valid JSON or not
	 */
    public static boolean isJsonValid(String json) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.readTree(json);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
