package io.sdmx.utils.json;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.IJsonCompatible;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class JsonObjectUtil {

	private static ObjectMapper objMapper =  new ObjectMapper();

	public static void writeJsonObjects(Collection<? extends IJsonCompatible> json, OutputStream out) {
		JSONArray responseArray = new JSONArray();
		for(IJsonCompatible obj : json) {
			responseArray.put(obj.getJson());
		}
		try {
			out.write(responseArray.toString().getBytes("UTF-8"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static JSONObject getJsonObject(InputStream is) {
		byte[] bytes = StreamUtil.toByteArray(is);
		return getJsonObject(bytes);
	}

	public static JSONObject getJsonObject(byte[] bytes) {
		try {
			return new JSONObject(new String(bytes));
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}
	
	public static JSONArray getJsonArray(InputStream is) {
		byte[] bytes = StreamUtil.toByteArray(is);
		return getJsonArray(bytes);
	}
	
	public static JSONArray getJsonArray(byte[] bytes) {
		try {
			return new JSONArray(new String(bytes));
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Array");
		}
	}

	/**
	 * Copies the properties from one object that do not exist in the other object,
	 * only works at the root level, if two objects contain the same property, the first one wins
	 * @param objects
	 * @return
	 */
	public static JSONObject mergeObjects(JSONObject...objects) {
		JSONObject returnJson = new JSONObject();
		for(JSONObject currentJson : objects) {
			@SuppressWarnings("unchecked")
			Iterator<String> keys = currentJson.keys();
			while(keys.hasNext()) {
				String key = keys.next();
				if(!returnJson.has(key)) {
					try {
						returnJson.put(key, currentJson.get(key));
					} catch (JSONException e) {
						throw new RuntimeException(e);
					}
				}
			}
		}
		return returnJson;
	}

	public static void writeJsonObjects(JSONObject jsonObj, String property, Collection<? extends IJsonCompatible> json) {
		JSONArray responseArray = new JSONArray();
		for(IJsonCompatible obj : json) {
			responseArray.put(obj.getJson());
		}
		try {
			jsonObj.put(property, responseArray);
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}

	public static void writeBoolean(JSONObject json, String property, Boolean value) {
		if(value != null) {
			try {
				json.put(property, value);
			} catch (JSONException e) {
				throw new SdmxException(e, "Could not write Boolean property '"+property+"' to JSON Object");
			}
		}
	}

	public static void writeString(JSONObject json, String property, String value) {
		if(value != null) {
			try {
				json.put(property, value);
			} catch (JSONException e) {
				throw new SdmxException(e, "Could not write String property '"+property+"' to JSON Object");
			}
		}
	}

	public static void writeInteger(JSONObject json, String property, Integer value) {
		if(value != null) {
			try {
				json.put(property, value);
			} catch (JSONException e) {
				throw new SdmxException(e, "Could not write Integer property '"+property+"' to JSON Object");
			}
		}
	}

	public static void writeLong(JSONObject json, String property, Long value) {
		if(value != null) {
			try {
				json.put(property, value);
			} catch (JSONException e) {
				throw new SdmxException(e, "Could not write Long property '"+property+"' tp JSON Object");
			}
		}
	}

	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static void writeCollection(JSONObject object, String property, Collection<String> inputs) {
		if(inputs == null) {
			return;
		}
		try {
			for(String input : inputs) {
				object.append(property, input);
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}

	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static void writeCollection(JSONArray arr, Collection<String> inputs) {
		if(inputs == null) {
			return;
		}
		for(String input : inputs) {
			arr.put(input);
		}
	}
	
	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static JSONArray writeJsonArray(Collection<String> inputs) {
		JSONArray array = new JSONArray();
		if(inputs != null) {
			writeCollection(array, inputs);
		}
		return array;
	}

	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static void writeMap(JSONObject object, String property, Map<String, String> inputs) {
		if(inputs == null) {
			return;
		}
		try {
			JSONObject map = new JSONObject();
			object.put(property, map);
			for(String input : inputs.keySet()) {
				map.put(input, inputs.get(input));
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}

	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static void writeCollectionOfCollection(JSONObject object, String property, Map<String, List<String>> inputs) {
		if(inputs == null) {
			return;
		}
		try {
			JSONObject json = new JSONObject();
			object.put(property, json);
			for(String input : inputs.keySet()) {
				writeCollection(json, input, inputs.get(input));
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}

	/**
	 * From an array of strings, builds a JsonObject with the property mapping to the array
	 * @param inputs
	 * @return
	 */
	public static void appendStringArray(JSONObject object, String property, String... inputs) {
		try {
			for(String input : inputs) {
				object.append(property, input);
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}

	public static void addMap(JSONObject json, String property, Map<String, String> map) {
		if(map == null) {
			return;
		}
		try {
			json.put(property, getJsonObject(map));
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not add map to JSON Object");
		}
	}

	public static JSONObject getJsonObject(Map<String, String> map) {
		try {
			JSONObject json = new JSONObject();
			for(String key : map.keySet()) {
				json.put(key, map.get(key));
			}
			return json;
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not create JSON Object");
		}
	}

	/**
	 * Unpacks a List from a JSONObject which is expected to have a property with an array of Strings
	 *
	 * unpackStringArray(json, "tableRows")
	 *
	 * with the following JSON:
	 * {
	 *    tableRows : ["Dim1", "Dim2"],
	 * }
	 *
	 * would return a list with Dim1, and Dim2
	 *
	 * @param json
	 * @param property
	 * @return
	 */
	public static List<String> unpackStringArray(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		JSONArray array = getArray(json, property, allowNulls);
		try {
			return unpackStringArray(array);
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException("JSON Array '"+property+"' expected to be of an array containing types 'string'");
		}
	}

	public static List<String> unpackStringArray(JSONArray array) {
		List<String> returnList = new ArrayList<>();
		if (array != null) {
			for(int i = 0; i < array.length(); i++) {
				try {
					returnList.add(array.getString(i));
				} catch (JSONException e) {
					throw new SdmxSemmanticException("JSON Array expected to be of an array containing types 'string'");
				}
			}
		}
		return returnList;
	}

	public static Set<String> unpackStringSet(JSONArray array) {
		Set<String> returnList = new HashSet<>();
		if (array != null) {
			for(int i = 0; i < array.length(); i++) {
				try {
					returnList.add(array.getString(i));
				} catch (JSONException e) {
					throw new SdmxSemmanticException("JSON Array expected to be of an array containing types 'string'");
				}
			}
		}
		return returnList;
	}

	/**
	 * Unpacks a Set from a JSONObject which is expected to have a property with an array of Strings
	 *
	 * unpackStringArray(json, "tableRows")
	 *
	 * with the following JSON:
	 * {
	 *    tableRows : ["Dim1", "Dim2", "Dim1"],
	 * }
	 *
	 * would return a set with Dim1, and Dim2
	 *
	 * @param json
	 * @param property
	 * @return
	 */
	public static Set<String> unpackStringSet(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		Set<String> returnList = new HashSet<>();
		JSONArray array = getArray(json, property, allowNulls);

		if (array != null) {
			for(int i = 0; i < array.length(); i++) {
				try {
					returnList.add(array.getString(i));
				} catch (JSONException e) {
					throw new SdmxSemmanticException("JSON Array '"+property+"' expected to be of an array containing types 'string'");
				}
			}
		}
		return returnList;
	}

	/**
	 * Unpacks a JSONObject which is expected to have a property with key to string pairs, example
	 *
	 * unpackMap(json, "myprop")
	 *
	 * with the following JSON:
	 * {
	 * 	myprop : {
	 *    key1 : "value1",
	 *    key2 : "value2",
	 *  }
	 * }
	 *
	 * would return a map with key1, and key2
	 *
	 * @param object
	 * @param property
	 * @return
	 */
	public static Map<String, String> unpackMap(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		JSONObject object = getJsonObject(json, property, allowNulls);
		return unpackMap(object, allowNulls);
	}


	public static Map<String, String> unpackMap(JSONObject json, String property, boolean allowNulls, boolean makeImmutable) {
		Map<String, String> map = unpackMap(json, property, allowNulls);
		if(map == null) {
			return null;
		}
		return Collections.unmodifiableMap(map);
	}

	public static Map<String, String> unpackMap(JSONObject json, boolean allowNulls) {
		if(json == null) {
			throw new SdmxSemmanticException("Can not unpack JSONObject, null was passed");
		}
		Map<String, String> returnMap = new HashMap<>();
		Iterator<String> keys = json.keys();
		while(keys.hasNext()) {
			String key = keys.next();
			returnMap.put(key, getString(json, key, allowNulls));
		}
		return returnMap;
	}

	public static Map<String, JSONObject> unpackObjectMap(JSONObject json) {
		if(json == null) {
			throw new SdmxSemmanticException("Can not unpack JSONObject, null was passed");
		}
		Map<String, JSONObject> returnMap = new HashMap<>();
		Iterator<String> keys = json.keys();
		while(keys.hasNext()) {
			String key = keys.next();
			try {
				returnMap.put(key, json.getJSONObject(key));
			} catch (JSONException e) {
				throw new SdmxSemmanticException("JSON property '"+key+"' expects JSON Object as value");
			}
		}
		return returnMap;
	}

	public static Map<String, List<String>> unpackStringListMap(JSONObject json, boolean allowNulls, boolean makeImmutable) {
		if(json == null) {
			throw new SdmxSemmanticException("Can not unpack JSONObject, null was passed");
		}
		Map<String, List<String>> returnMap = new HashMap<>();
		Iterator<String> keys = json.keys();
		while(keys.hasNext()) {
			String key = keys.next();
			List<String> list = unpackStringArray(json, key, allowNulls);
			if(list == null) {
				continue;
			}
			if(makeImmutable) {
				list = Collections.unmodifiableList(list);
			}
			returnMap.put(key, list);
		}
		if(makeImmutable) {
			returnMap = Collections.unmodifiableMap(returnMap);
		}
		return returnMap;
	}

	public static boolean assertExists(JSONObject object, String property, boolean allowNulls) {
		if(object == null) {
			if(allowNulls) {
				return false;
			}
			throw new SdmxSemmanticException("JSON is NULL");
		}
		if(!object.has(property)) {
			if(allowNulls) {
				return false;
			}
			throw new SdmxSemmanticException("JSON Missing required property  '"+property+"'");
		}
		if(object.isNull(property)) {
			if(allowNulls) {
				return false;
			}
			throw new SdmxSemmanticException("JSON Missing required property  '"+property+"'");
		}
		return true;
	}

	/**
	 * Returns a Path value - or throws an exception if the value is not of type boolean
	 * @param json
	 * @param property
	 * @param allowNulls if false, then a missing value will return false, if true then will throw an exception if the value is not present
	 * @return
	 */
	public static Path getPath(JSONObject json, String property, boolean allowNulls) {
		String uri = getString(json, property, allowNulls);
		if(uri == null) {
			return null;
		}
		return Paths.get(uri);
	}


	/**
	 * Returns a boolean value - or throws an exception if the value is not of type boolean
	 * @param json
	 * @param property
	 * @param allowNulls if false, then a missing value will return false, if true then will throw an exception if the value is not present
	 * @return
	 */
	public static boolean getBoolean(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return false;
		}
		try {
			return json.getBoolean(property);
		} catch (JSONException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'boolean'");
		}
	}
	
	public static URL getURL(JSONObject json, String property, boolean allowNulls) {
		try {
			String returnProp = getString(json, property, allowNulls);
			if(returnProp == null) {
				return null;
			}
			return new URL(returnProp);
		} catch (MalformedURLException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'url'");
		}
	}
	
	public static URI getURI(JSONObject json, String property, boolean allowNulls) {
		try {
			String returnProp = getString(json, property, allowNulls);
			if(returnProp == null) {
				return null;
			}
			return new URI(returnProp);
		} catch (URISyntaxException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'uri'");
		}
	}

	public static String getString(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		try {
			String returnProp = json.getString(property);
			if(allowNulls == false && !ObjectUtil.validString(returnProp)) {
				throw new SdmxSemmanticException("JSON required property '"+property+"' is empty");
			}
			return returnProp;
		} catch (JSONException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'string'");
		}
	}
	
	public static String getString(JSONObject json, String property, String defaultValue) {
		String value = getString(json, property, true);
		if(value == null || value.length() == 0) {
			value = defaultValue;
		}
		return value;
	}

	public static Long getLong(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		try {
			Long returnProp = json.getLong(property);
			return returnProp;
		} catch (JSONException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'long'");
		}
	}
	
	public static Long getLong(JSONObject json, String property, Long defaultValue) {
		Long value = getLong(json, property, true);
		if(value == null) {
			value = defaultValue;
		}
		return value;
	}

	public static Integer getInteger(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		try {
			return json.getInt(property);
		} catch (JSONException e) {
			throw new SdmxException("JSON property '"+property+"' was not of expected type 'int'");
		}
	}
	
	public static Integer getInteger(JSONObject json, String property, Integer defaultValue) {
		Integer value = getInteger(json, property, true);
		if(value == null) {
			value = defaultValue;
		}
		return value;
	}

	/**
	 * Returns an array of json objects as a Java list
	 *  Example
	 *
	 *  [
	 *   {
	 *     "id" : "my object",
	 *     "arr" : ["has", "lots", "more" "complexity"]
	 *   }, {
	 *     "id" : "my object",
	 *     "arr" : ["then", "a", "standard" "string"]
	 *   }
	 * ]
	 * @param json
	 * @param property
	 * @param allowNulls
	 * @return
	 */
	public static List<JSONObject> getArrayOfObjects(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		JSONArray arr = getArray(json, property, allowNulls);
		return getArrayOfObjects(arr);
	}
	
	/**
	 * Returns an array of json objects as a Java list
	 *  Example
	 *
	 *  [
	 *   {
	 *     "id" : "my object",
	 *     "arr" : ["has", "lots", "more" "complexity"]
	 *   }, {
	 *     "id" : "my object",
	 *     "arr" : ["then", "a", "standard" "string"]
	 *   }
	 * ]
	 * @param json
	 * @param property
	 * @param allowNulls
	 * @return
	 */
	public static List<JSONObject> getArrayOfObjects(JSONArray arr) {
		if(arr == null) {
			return null;
		}
		List<JSONObject> returnList = new ArrayList<>(arr.length());
		for(int i=0; i < arr.length(); i++) {
			try {
				returnList.add(arr.getJSONObject(i));
			} catch (JSONException e) {
				throw new SdmxSemmanticException(e, "could not get JsonObject from JsonArray");
			}
		}
		return returnList;
	}

	/**
	 * Returns an array of JSON arrays as a Java list
	 *  Example:
	 *  [
	 *   ["my object","foo"],
	 *
	 *   ["my object","foobar"]
	 * ]
	 * @param json
	 * @param property
	 * @param allowNulls
	 * @return
	 */
	public static List<JSONArray> getArrayOfArrays(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		JSONArray arr = getArray(json, property, allowNulls);
		if(arr == null) {
			return null;
		}
		List<JSONArray> returnList = new ArrayList<>();
		for(int i=0; i < arr.length(); i++) {
			try {
				returnList.add(arr.getJSONArray(i));
			} catch (JSONException e) {
				throw new SdmxSemmanticException(e, "could not get JsonObject from JsonArray");
			}
		}
		return returnList;
	}

	public static JSONArray getArray(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		try {
			return json.getJSONArray(property);
		} catch (JSONException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'array'");
		}
	}

	public static JSONObject getJsonObject(JSONObject json, String property, boolean allowNulls) {
		if(!assertExists(json, property, allowNulls)) {
			return null;
		}
		try {
			return json.getJSONObject(property);
		} catch (JSONException e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' was not of expected type 'object'");
		}
	}
	/**
	 * Return the serialisation of any Java object as a Json string. this is the same as calling new ObjectMapper().writeValueAsString(obj);
	 * @param obj
	 * @return
	 * @throws JsonProcessingException
	 */
	public static String objectAsString(Object obj) throws JsonProcessingException {
		return objMapper.writeValueAsString(obj);
	}

}
