package io.sdmx.utils.json;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonTokenId;
import com.fasterxml.jackson.databind.MappingJsonFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.process.IProcessWithArgument;
import io.sdmx.api.process.IProcessWithResponse;
import io.sdmx.utils.core.date.DateUtil;

public class JsonReader implements Closeable{
	private static final Logger LOG = LoggerFactory.getLogger(JsonReader.class);

	public static final SkipObjectIterator SKIP_OBJECT_ITERATOR  = new JsonReader().new SkipObjectIterator();
	private ReadableDataLocation rdl;
	private JsonParser jParser;
	private JsonToken token;

	private Stack<JsonStackItem> stack;
	private Stack<Iterator> iteratorStack;
	private boolean iterating = false;
	private JsonStackItem currentStackItem;
	private String fieldName;

	public interface Iterator {

		void next(String fieldName);

		void end(String fieldName, boolean isObject);

		Iterator start(String fieldName, boolean isObject);
	}
	
	public interface PropertyIterator {
	    
	    void processProperty(String name, String value);
	    
	}

	private JsonReader() {}

	public enum STACK_TYPE {
		OBJECT,
		ARRAY;
	}

	public class JsonStackItem {
		private JsonStackItem parentItem;
		private String fieldName;
		private STACK_TYPE type;

		private JsonStackItem(JsonStackItem parentItem, String fieldName, STACK_TYPE type) {
			this.parentItem = parentItem;
			this.fieldName = fieldName;
			this.type = type;
		}

		public JsonStackItem getParentItem() {
			return parentItem;
		}

		public String getFieldName() {
			return fieldName;
		}

		public STACK_TYPE getType() {
			return type;
		}

		public boolean isRoot() {
			return parentItem == null;
		}

	}

	public JsonReader(ReadableDataLocation rdl) {
		this.rdl =rdl;
		reset();
	}


	public ReadableDataLocation getRdl() {
		return rdl;
	}
	
	public void iteratorObjectProperties() {
	    
	}


	public static boolean isValidJson(ReadableDataLocation rdl) {
		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
		SdmxException.disableExceptionTrace(true);
		try {
			//Try and read it as a JSON dataset
			try(JsonReader reader = new JsonReader(rdl);){
				// Attempt to moveNext 10 times. If this succeeds we are very likely in a valid JSON file.
				for (int i=0; i < 10; i++) {
					boolean retVal = reader.moveNext();
					if (retVal == false) {
						return i > 0;  //If we have moved only once, and it returned false, then the file is empty, return false
					}
				}
				return true;
			}
		} catch(Throwable th) {
			return false;
		} finally {
			SdmxException.disableExceptionTrace(wasDisabled);
		}
	}


	@Override
	public void close() {
		try {
			jParser.close();
		} catch (IOException e) {
			LOG.warn("Error attempting to close JsonParser", e);
		}
	}

	public void reset() {
		LOG.debug("Reset");
		token = null;
		stack = new Stack<>();
		currentStackItem = null;
		iteratorStack = new Stack<>();
		JsonFactory jfactory = getJsonFactory();
		if(jParser != null) {
			try {
				jParser.close();
			} catch (IOException e) {

			}
		}
		try {
			jParser = jfactory.createParser(new BufferedReader(new InputStreamReader(rdl.getInputStream(), StandardCharsets.UTF_8), 8192));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	protected JsonFactory getJsonFactory() {
	    return new MappingJsonFactory();
	}

	public void iterate(Iterator it) {
		LOG.debug("iterate");
		iterating = true;
		iteratorStack = new Stack<>();
		while(iterating == true && it != null && moveNext()) {
			if(isEndObject() || isEndArray()) {
				String fieldName = currentStackItem != null ? currentStackItem.getFieldName() : null;
				it.end(fieldName, isEndObject());
				if(iteratorStack.isEmpty()) {
					break;
				}
				it = iteratorStack.pop();
			} else if(isStartObject() || isStartArray())  {
				String fieldName = currentStackItem != null ? currentStackItem.getFieldName() : null;
				Iterator subObjectIt = it.start(fieldName, isStartObject());
				iteratorStack.push(it);  //Store the old iterator
				if(subObjectIt != null) {
					it = subObjectIt;
				}
			} else {
				it.next(fieldName);
			}
		}
	}

	public void stopIterating() {
		iterating = false;
	}


	private class SkipObjectIterator implements Iterator {

		@Override
		public void next(String fieldName) {}

		@Override
		public void end(String fieldName, boolean isObject) {}

		@Override
		public Iterator start(String fieldName, boolean isObject) {
			return null;
		}
	}

	public boolean moveNextStartObject() {
		while(moveNext()) {
			if(isStartObject()) {
				return true;
			}
		}
		return false;
	}

	public boolean moveNextStartArray() {
		while(moveNext()) {
			if(isStartArray()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Moves the reader to the end of the array
	 * @return
	 */
	public boolean moveToEndArray() {
		int i=1;
		while(moveNext()) {
			if(isEndArray()) {
				i--;
				if(i == 0) {
					return true;
				}
			}
			if(isStartArray()) {
				i++;
			}
		}
		return false;
	}

	public boolean moveToEndObject() {
		int i = 0;
		while (moveNext()) {
			if (isEndObject()) {
				i--;
				if (i < 1) {
					return true;
				}
			}
			if (isStartObject()) {
				i++;
			}
		}
		return false;
	}

	public boolean moveToEndCurrentObject() {
		int i=1;
		while(moveNext()) {
			if(isEndObject()) {
				i--;
				if(i < 1) {
					return true;
				}
			}
			if(isStartObject()) {
				i++;
			}
		}
		return false;
	}

	public boolean isField() {
		return token == JsonToken.FIELD_NAME;
	}

	public boolean isStartObject() {
		return token == JsonToken.START_OBJECT;
	}

	public boolean isEndObject() {
		return token == JsonToken.END_OBJECT;
	}

	public boolean isStartArray() {
		return token == JsonToken.START_ARRAY;
	}

	public boolean isEndArray() {
		return token == JsonToken.END_ARRAY;
	}

	public String getCurrentFieldName() {
		return fieldName;
	}

	public int getValueAsInt() {
		try {
			return jParser.getValueAsInt();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public long getValueAsLong() {
		try {
			return jParser.getValueAsLong();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	public String getValueAsString() {
		try {
			return jParser.getValueAsString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public Date getValueAsDate() {
		try {
			return DateUtil.formatDate(jParser.getValueAsString(), true);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public Boolean getValueAsBoolean() {
		try {
			return jParser.getValueAsBoolean();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public JsonToken getToken() {
		return token;
	}


	/**
	 * Unpacks a JSONObject which is expected to have a property with key to string pairs, example
	 *
	 * readStringMap(json)
	 *
	 * with the following JSON:
	 *  {
	 *    key1 : "value1",
	 *    key2 : "value2",
	 *  }
	 *
	 * would return a map with key1, and key2
	 *
	 * @param object
	 * @param property
	 * @return
	 */
	public Map<String, String> readStringMap() {
		Map<String, String> returnMap = new HashMap<>();
		if(!isStartObject()) {
			throw new SdmxSemmanticException("JSON '"+getCurrentFieldName()+"' expected to be of type Object");
		}
		while (moveNext()) {
			if (isEndObject()) {
				break;
			}
			returnMap.put(getCurrentFieldName(), getValueAsString());
		}
		return returnMap;
	}


	public List<String> readStringArray() {
		List<String> list = new ArrayList<>();
		while(moveNext() && token != JsonToken.END_ARRAY) {
			try {
				list.add(jParser.getValueAsString());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return list;
	}

	public <T> List<T> readObjectArray(JsonReader reader, IProcessWithResponse<T> p) {
	    List<T> returnList = new ArrayList<>();
        while(reader.moveNext()) {
            if(reader.isStartObject()) {
                returnList.add(p.runProcess());
            }
            if(reader.isEndArray()) {
                break;
            }
        }
        return returnList;
    }
	
	public void iterateFields(IProcessWithArgument<String> field) {
	    while(moveNext()) {
	        if(isEndObject()) {
                return;
            }
            if(getCurrentFieldName() != null) {
                field.runProcess(getCurrentFieldName());
            }
	    }
	}
	
	public Set<String> readStringSet() {
		Set<String> set = new HashSet<>();
		while(moveNext() && token != JsonToken.END_ARRAY) {
			try {
				set.add(jParser.getValueAsString());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return set;
	}

	public List<Integer> readIntegerArray() {
		return readIntegerArray(false);
	}

	/**
	 * Reads an Integer Array and returns it.
	 * @param valuesMustBeInt if true then the values in the JSON input must be either the word "null" or an int. They may not be Strings.
	 * @return
	 */
	public List<Integer> readIntegerArray(boolean valuesMustBeInt) {
		List<Integer> list = new ArrayList<>();
		while(moveNext() && token != JsonToken.END_ARRAY) {
			try {
				String asStr = jParser.getValueAsString();
				if(asStr == null || "null".equals(asStr)) {
					list.add(null);
				} else {
					if (valuesMustBeInt && jParser.currentToken().id() == JsonTokenId.ID_STRING) {
						throw new NumberFormatException("The input was expected to be a number but was a string: " + asStr);
					}
					list.add(Integer.parseInt(asStr));
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return list;
	}

	/**
	 * Returns true if the parent field has the name
	 * @return
	 */
	public boolean isParentField(String name) {
		if(currentStackItem != null && currentStackItem.getParentItem() != null) {
			if(name == null) {
				if(currentStackItem.getParentItem().getFieldName() == null) {
					return true;
				}
			} else if(name.equals(currentStackItem.getParentItem().getFieldName())) {
				return true;
			}
		}
		return false;
	}

	public JsonStackItem getCurrentStackItem() {
		return currentStackItem;
	}

	public boolean moveNext() {
		JsonStackItem newStackItem = null;
		try {
			token = jParser.nextToken();
			if(token != null) {
				switch(token) {
				case START_ARRAY:
					//Root Item
					//System.out.println("Start Array: "+jParser.getCurrentName());
					newStackItem = new JsonStackItem(currentStackItem, null, STACK_TYPE.ARRAY);
					stack.push(newStackItem);
					break;
				case START_OBJECT:
					//Root Item
					//					System.out.println("Start Object: "+jParser.getCurrentName());
					newStackItem = new JsonStackItem(currentStackItem, null, STACK_TYPE.OBJECT);
					stack.push(newStackItem);
					break;
				case FIELD_NAME:
					fieldName = jParser.getCurrentName();
					token = jParser.nextToken();
					switch(token) {
					case START_ARRAY:
						//							System.out.println("Start Array: "+jParser.getCurrentName());
						LOG.debug("Start Array: "+jParser.getCurrentName());
						newStackItem = new JsonStackItem(currentStackItem, fieldName, STACK_TYPE.ARRAY);
						stack.push(newStackItem);
						break;
					case START_OBJECT:
						//							System.out.println("Start Object: "+jParser.getCurrentName());
						LOG.debug("Start Object: "+jParser.getCurrentName());
						newStackItem = new JsonStackItem(currentStackItem, fieldName, STACK_TYPE.OBJECT);
						stack.push(newStackItem);
						break;
					}
					break;
				case END_ARRAY:
				case END_OBJECT:
					stack.pop();
					if(stack.size() > 0) {
						currentStackItem = stack.lastElement();
					} else {
						currentStackItem = null;
					}
					if(currentStackItem != null) {
						//						System.out.println("End Object|Array: "+currentStackItem.getFieldName());
						LOG.debug("End Object|Array: "+currentStackItem.getFieldName());
					}
				}
			}
			if(newStackItem != null) {
				currentStackItem = stack.lastElement();
			}
			return token != null;
		} catch (JsonParseException e) {
			throw new SdmxException(e, "Error Reading JSON");
		} catch (IOException e) {
			throw new SdmxException(e, "Error Reading JSON");
		}
	}
}
