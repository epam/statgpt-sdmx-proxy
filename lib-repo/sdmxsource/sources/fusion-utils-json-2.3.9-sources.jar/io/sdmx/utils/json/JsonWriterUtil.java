package io.sdmx.utils.json;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Utility functions for both JSON and YAML, both formats are represented by the JsonGenerator
 */
public class JsonWriterUtil {

	public static JsonGenerator createJsonWriter(OutputStream out, JSON_COMPATIBLE_FORMAT format) {
		JsonFactory factory = format == JSON_COMPATIBLE_FORMAT.YAML ? new YAMLFactory() : new JsonFactory();
		try {
			return factory.createGenerator(out, JsonEncoding.UTF8);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Writes an array of Strings as JSON
	 * ["Foo","Bar"]
	 * @param json
	 * @param property the property name of the array - if null then writes an array with no name
	 * @return
	 */
	public static void writeStringArray(JsonGenerator jsonGenerator, String property, String[] array) {
		try {
			if(ObjectUtil.validString(property)) {
				jsonGenerator.writeArrayFieldStart(property);
			} else {
				jsonGenerator.writeStartArray();
			}
			if(array != null) {
				for(String str : array) {
					jsonGenerator.writeString(str);
				}
			}
			jsonGenerator.writeEndArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Writes an array of Strings as JSON
	 * ["Foo","Bar"]
	 * @param json
	 * @param property the property name of the array - if null then writes an array with no name
	 * @return
	 */
	public static void writeStringArray(JsonGenerator jsonGenerator, String property, Collection<String> array) {
		try {
			if(ObjectUtil.validString(property)) {
				jsonGenerator.writeArrayFieldStart(property);
			} else {
				jsonGenerator.writeStartArray();
			}
			if(array != null) {
				for(String str : array) {
					jsonGenerator.writeString(str);
				}
			}
			jsonGenerator.writeEndArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Writes an map of Strings
	 * {
	 *   "A" : "B",
	 *   "C" : "D"
	 * }
	 * 
	 * @param json
	 * @param property the property name of the array
	 * @return
	 */
	public static void writeStringMap(JsonGenerator jsonGenerator, String property, Map<String, String> map) {
		try {
			if(ObjectUtil.validString(property)) {
				jsonGenerator.writeObjectFieldStart(property);
			} else {
				jsonGenerator.writeStartObject();
			}
			if(map != null) {
				for(String str : map.keySet()) {
					jsonGenerator.writeStringField(str, map.get(str));
				}
			}
			jsonGenerator.writeEndObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Writes the JSONObject to the JsonGenerator
	 * @param jsonGenerator
	 * @param jObj
	 */
	public static void writeJsonObject(JsonGenerator jsonGenerator, JSONObject jObj) {
		try {
			jsonGenerator.writeStartObject();
			Iterator<String> iter = jObj.keys();
			while(iter.hasNext()) {
				String aKey = iter.next();
				Object val = jObj.get(aKey);
				if (val instanceof JSONArray) {
					writeJsonArray(jsonGenerator, aKey, (JSONArray)val);
				} else if (val instanceof String) {
					jsonGenerator.writeStringField(aKey, (String)val);
				} else if (val.equals(JSONObject.NULL)) {
					jsonGenerator.writeStringField(aKey, null);
				} else {
					throw new SdmxException("Unexpected element when writing JSONObject. Element of type: " + val.getClass());
				}
			}
			jObj.keys();
			jsonGenerator.writeEndObject();
		} catch(Exception e) {
			throw new SdmxException(e, "Unable to add JSONObject to jsonGenerator. Error: " + e.getMessage());
		}
	}
	
	/**
	 * Writes the JSONArray to the JsonGenerator
	 * @param jsonGenerator
	 * @param arrayName
	 * @param jArr
	 */
	public static void writeJsonArray(JsonGenerator jsonGenerator, String arrayName, JSONArray jArr) {
		try {
			jsonGenerator.writeArrayFieldStart(arrayName);
			for (int i=0; i < jArr.length(); i++) {
				Object obj = jArr.get(i);
				if (obj instanceof JSONObject) {
					writeJsonObject(jsonGenerator, (JSONObject)jArr.get(i));
				} else if (obj instanceof String) {
					jsonGenerator.writeString((String)obj);
				} else if (obj.equals(JSONObject.NULL)) {
					jsonGenerator.writeNull();
			    } else {
			    	throw new SdmxException("Unexpected element when writing JSONArray. Element of type: " + obj.getClass());
				}
			}
			jsonGenerator.writeEndArray();
		
		} catch(Exception e) {
			throw new SdmxException(e, "Unable to add JSONArray to jsonGenerator. Error: " + e.getMessage());
		}
	}
}
