package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.superbeans.base.IdentifiableSuperBean;

/**
 * Compares two IdentifiableBeans with each other.
 */
public class IdentifiableSuperBeanComparator implements Comparator<IdentifiableSuperBean>{
	public static final IdentifiableSuperBeanComparator INSTANCE = new IdentifiableSuperBeanComparator();
	private IdentifiableSuperBeanComparator() {}
	
	
	@Override
	public int compare(IdentifiableSuperBean iBean1, IdentifiableSuperBean iBean2) {
		String id1 = iBean1.getId();
		String id2 = iBean2.getId();
		int compare =  id1.compareToIgnoreCase(id2);
		if(compare == 0) {
			return iBean1.getUrn().compareTo(iBean2.getUrn());
		}
		return compare;
	}
}
