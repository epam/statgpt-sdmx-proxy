package io.sdmx.utils.sdmx.structure;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.VersionRef;

/**
 * This class provides utility methods that can be performed on a MaintainableBean
 */
public class MaintainableUtil<T extends MaintainableBean> {
	
	
	/**
	 * <pre>
		   _                             .-.
		  / )  .-.    ___          __   (   )
		 ( (  (   ) .'___)        (__'-._) (
		  \ '._) (,'.'               '.     '-.
		   '.      /  "\               '    -. '.
		     )    /   \ \   .-.   ,'.   )  (  ',_)    _
		   .'    (     \ \ (   \ . .' .'    )    .-. ( \
		  (  .''. '.    \ \|  .' .' ,',--, /    (   ) ) )
		   \ \   ', :    \    .-'  ( (  ( (     _) (,' /
		    \ \   : :    )  / _     ' .  \ \  ,'      /
		  ,' ,'   : ;   /  /,' '.   /.'  / / ( (\    (
		  '.'      "   (    .-'. \       ''   \_)\    \
		                \  |    \ \__             )    )
		              ___\ |     \___;           /  , /
		             /  ___)                    (  ( (
		             '.'                         ) ;) ;
		                                        (_/(_/
     * </pre>
     * 
     * Strip Off....dates
	 */
	@SuppressWarnings("unchecked")
	public static  <T extends MaintainableBean>  T stripOff(T maint) {
		//Strip off start and end periods
		MaintainableMutableBean mutable = maint.getMutableInstance();
		//Strip off start and end periods
		mutable.setStartDate(null);
		mutable.setEndDate(null);
		return (T)mutable.getImmutableInstance();
	}
	
	/**
	 * Filters a set of Maintainable Beans by structure type
	 * 
	 * @param <T>
	 * @param maints to filter, if null an empty immutable set is returned
	 * @param filterFor nullable, can include abstract types e.g. ItemSchemeBean, MaintainableBean or concrete types like CodelistBean
	 * @return filtered set of type T
	 */
	public static <T extends MaintainableBean> Set<T> filterSet(Set<MaintainableBean> maints, Class<T> filterFor) {
        if(maints == null) {
            return Collections.emptySet();
        }
        if(filterFor == null || filterFor == MaintainableBean.class) {
            return (Set<T>)maints;
        }
        return (Set<T>)maints.stream().filter(e-> filterFor.isAssignableFrom(e.getStructureClass().getClassType())).collect(Collectors.toSet());
    }
	
	/**
	 * Returns a collection keeping only the latest versions of each maintainable passed in.
	 * <p/>
	 * Note, the returned Set is a new Set, no changes are made to the passed in collection.
	 * 
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public static Set<MaintainableBean> filterCollectionGetLatest(Collection<MaintainableBean> maintianables) {
		Map<String, MaintainableBean> resultMap = new HashMap<>();
		boolean filteredResponse = false;
		for(MaintainableBean currentMaint : maintianables) {
			String key = currentMaint.getStructureClass().getUrnClass() + "_" + currentMaint.getAgencyId() + "_" + currentMaint.getId();
			if(resultMap.containsKey(key)) {
				filteredResponse = true;
				MaintainableBean storedAgainstKey = resultMap.get(key);
				if(currentMaint.getVersion().isLater(storedAgainstKey.getVersion())) {
					resultMap.put(key, currentMaint);
				}
			} else {
				resultMap.put(key, currentMaint);
			}
		}
		if(filteredResponse) {
			return new HashSet<>(resultMap.values());
		}
		return new HashSet<>(maintianables);
	}

	/**
	 * Returns a collection keeping only the latest versions of each maintainable passed in.
	 * <p/>
	 * Note, the returned Set is a new Set, no changes are made to the passed in collection.
	 * 
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public Set<T> filterCollectionGetLatestOfType(Collection<T> maintianables) {
		Map<String, T> resultMap = new HashMap<>();
		boolean filteredResponse = false;
		for(T currentMaint : maintianables) {
			String key = currentMaint.getAgencyId() + "_" + currentMaint.getId();
			if(resultMap.containsKey(key)) {
				filteredResponse = true;
				T storedAgainstKey = resultMap.get(key);
				if(currentMaint.getVersion().isLater(storedAgainstKey.getVersion())) {
					resultMap.put(key, currentMaint);
				}
			} else {
				resultMap.put(key, currentMaint);
			}
		}
		if(filteredResponse) {
			return new HashSet<>(resultMap.values());
		}
		return new HashSet<>(maintianables);
	}
	/**
	 * Returns a collection of maintainables that match the input reference
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public Set<T> filterCollection(Collection<T> maintianables, IMaintainableRef ref) {
		Set<T> returnSet = new HashSet<>();
		
		String agencyId = null;
		String id = null;
		IVersionRef version = VersionRef.ALL;
		
		if(ref != null) {
			agencyId = ref.getAgencyId();
			id = ref.getMaintainableId();
			version = ref.getVersion();
		}
		
		for(T currentMaintainable : maintianables) {
			if(agencyId == null || currentMaintainable.getAgencyId().equals(agencyId)) {
				if(id == null || currentMaintainable.getId().equals(id)) {
					if(version.isMatch(currentMaintainable.getVersion())) {
						returnSet.add(currentMaintainable);
					}
				}
			}
		}
		return returnSet;
	}

	/**
	 * For a set of maintainables, this method will return the maintainable that has the same urn as the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn, then it will return any matches for the agency id, id and version
	 * as the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn OR agency id, id and version set then it will return all the beans.
	 * <p/>
	 * <p/>
	 * 
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public static void findMatches(Collection<MaintainableBean> populateCollection, Collection<? extends MaintainableBean> maintianables, IURNMaintainable<?> ref) {
		if(ref == null) {
			throw new IllegalArgumentException("Ref is null");
		}

		if(maintianables != null) {
			for(MaintainableBean currentMaintainable : maintianables) {
				if(match(currentMaintainable, ref)) {
					populateCollection.add(currentMaintainable);
				}
			}
		}
	}

	/**
	 * For a set of maintainables, this method will return the maintainable that has the same urn as the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn, then it will return any matches for the agency id, id and version
	 * as the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn OR agency id, id and version set then it will return all the beans.
	 * <p/>
	 * <p/>
	 * 
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public static Set<MaintainableBean> findMatches(Collection<? extends MaintainableBean> maintianables, IURNMaintainable<?> ref) {
		if(ref == null) {
			throw new IllegalArgumentException("Ref is null");
		}
		Set<MaintainableBean> returnSet = new HashSet<>();

		if(maintianables != null) {
			for(MaintainableBean currentMaintainable : maintianables) {
				if(match(currentMaintainable, ref)) {
					returnSet.add(currentMaintainable);
				}
			}
		}
		return returnSet;
	}

	public static boolean match(MaintainableBean maint, IURNMaintainable<?> ref) {
		if(ref==null) {
			return true;
		}
		return ref.isMatch(maint);
	}
	
	public static boolean subsetOf(IMaintainableRef ref, IMaintainableRef ref2) {
		boolean match = true;
		
		if(ObjectUtil.validString(ref.getAgencyId())) {
			match = ref.getAgencyId().equals(ref2.getAgencyId());
		}
		if(match) {
			if(ObjectUtil.validString(ref.getMaintainableId())) {
				match = ref.getMaintainableId().equals(ref2.getMaintainableId());
			}
		}
		if(match) {
			match = ref.getVersion().isMatch(ref2.getVersion());
		}
		return match;
	}
	/**
	 * For a set of maintainables, this method will return the maintainable that matches the parameters of the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn, then it will return the maintainable that has the same agency id, id and version
	 * as the ref bean.
	 * <p/>
	 * If the ref bean does not have a urn OR agency id, id and version set then it will result in an error.
	 * <p/>
	 * This method will stop at the first match and return it, no checks are performed on the type of maintainables in the set.
	 * <p/>
	 * If no match is found null is returned.
	 * 
	 * @param maintianables
	 * @param ref
	 * @return
	 */
	public static MaintainableBean resolveReference(Collection<? extends MaintainableBean> maintianables, IURNMaintainable<?> ref) {
		if(ref == null) {
			throw new IllegalArgumentException("Ref is null");
		}
		if(maintianables != null) {
			for(MaintainableBean currentMaintainable : maintianables) {
				if(match(currentMaintainable, ref)) {
					return currentMaintainable;
				}
			}
		}
		return null;
	}

	public static MaintainableBean resolveReference(Collection<? extends MaintainableBean> maintainables, IMaintainableRef ref) {
		if(!ObjectUtil.validCollection(maintainables)) {
			return null;
		}
		if(ref == null) {
			if(maintainables.size() == 1) {
				return maintainables.iterator().next();
			}
			throw new IllegalArgumentException("Can not resolve reference, more then one bean supplied and no reference parameters passed in");
		}
		if(maintainables != null) {
			for(MaintainableBean currentMaintainable : maintainables) {
				if(ref.getAgencyId() == null || currentMaintainable.getAgencyId().equals(ref.getAgencyId())) {
					if(ref.getMaintainableId() == null || currentMaintainable.getId().equals(ref.getMaintainableId())) {
						if(ref.getVersion() == null || ref.getVersion().isMatch(currentMaintainable.getVersion())) {
							return currentMaintainable;
						}
					}
				}
			}
		}
		return null;
	}
	
	/**
	 * Parses the unique identifier which is made up in the following format:
     * <agency>:<id>(<version>)
     * and returns a MaintainableRefBean from these values.
	 * @param identifier
	 * @param type Simply a value for the error message
	 * @return
	 */
	public static IMaintainableRef parseUniqueIdentifier(String identifier, String type) {
		// Everything up to the first colon is the agency id
		int colonPos = identifier.indexOf(":");
		if (colonPos == -1) {
			throw new IllegalArgumentException(type + " was specified in an invalid manner. Format is [agency]:[id]([version]). Value specified: " + identifier);
		}
		String[] split = identifier.split(":");
		String agencyId = split[0];
		
		String remainder = split[1];
		int openBracketPos = remainder.indexOf("(");
		if (openBracketPos == -1) {
			throw new IllegalArgumentException(type + " was specified in an invalid manner. Format is [agency]:[id]([version]). Value specified: " + identifier);
		}
		String id = remainder.substring(0, openBracketPos);
		String version = remainder.substring(openBracketPos +1, remainder.length()-1);
		
		return MaintainableRef.getInstance(agencyId, id, version);
	}
	
	/**
	 * Generates a random id that can be used for a Maintainable
	 * @return
	 */
	public static String generateRandomId() {
		//Start with a letter
		return "a"+UUID.randomUUID().toString();
	}
	/**
	 * Gets the the unique identifier of the specified MaintainableBean which is in the following format:
     * <agency>:<id>(<version>)
	 * @param maint
	 * @return
	 */
	public static String getUniqueIdentifier(MaintainableBean maint) {
		StringBuilder sb = new StringBuilder();
		sb.append(maint.getAgencyId());
		sb.append(":");
		sb.append(maint.getId());
		sb.append("(");
		sb.append(maint.getVersion());
		sb.append(")");
		return sb.toString();
	}
	
	/**
	 * Gets the the unique identifier of the specified MaintainableBean which is in the following format:
     * <agency>:<id>(<version>)
	 * @param maint
	 * @return
	 */
	public static String getUniqueIdentifier(MaintainableSuperBean maint) {
		StringBuilder sb = new StringBuilder();
		sb.append(maint.getAgencyId());
		sb.append(":");
		sb.append(maint.getId());
		sb.append("(");
		sb.append(maint.getVersion());
		sb.append(")");
		return sb.toString();
	}
}
