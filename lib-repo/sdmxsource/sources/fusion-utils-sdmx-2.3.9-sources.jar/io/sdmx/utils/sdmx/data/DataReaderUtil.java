package io.sdmx.utils.sdmx.data;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.collection.KeyValueUtil;
import io.sdmx.utils.core.object.AssertUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataReaderUtil {
	
	public static void assertSame(DataReaderEngine dre1, DataReaderEngine dre2) {
		while(dre1.moveNextDataset()) {
			AssertUtil.boolMatch(true, dre2.moveNextDataset(), "Data Reader Move Next Dataset=false, expecting true");
			assertSame(dre1.getDatasetAttributes(), dre2.getDatasetAttributes());
			while(dre1.moveNextKeyable()) {
				AssertUtil.boolMatch(true, dre2.moveNextKeyable(), "Data Reader Move Next Key=false, expecting true");
				assertSame(dre1.getCurrentKey(), dre2.getCurrentKey());
				while(dre1.moveNextObservation()) {
					AssertUtil.boolMatch(true, dre2.moveNextObservation(), "Data Reader Move Next Obs=false, expecting true");
					assertSame(dre1.getCurrentObservation(), dre2.getCurrentObservation());
				}
				AssertUtil.boolMatch(false, dre2.moveNextObservation(), "Data Reader Move Obs Key=true, expecting false");
			}
			AssertUtil.boolMatch(false, dre2.moveNextKeyable(), "Data Reader Move Next Key=true, expecting false");
		}
		AssertUtil.boolMatch(false, dre2.moveNextDataset(), "Data Reader Move Next Dataset=true, expecting false");
	}
	
	public static void assertSame(Keyable key1, Keyable key2) {
		assertSameAttributes(key1, key2);
		AssertUtil.equivalent(key1.getDataflow(), key2.getDataflow(), "Dataflows are not equal on key: "+key1.getShortCode());
		AssertUtil.equivalent(key1.getDataStructure(), key2.getDataStructure(), "DSDs are not equal on key: "+key1.getShortCode());
		assertSame(key1.getKey(), key2.getKey());
		
		AssertUtil.equivalent(key1.getDataStructure(), key2.getDataStructure(), "DSDs are not equal on key: "+key1.getShortCode());
		
	}
	
	public static void assertSame(IDatasetAttributes dsAttr1, IDatasetAttributes dsAttr2) {
		assertSameAttributes(dsAttr1, dsAttr2);
	}
	
	public static void assertSame(Observation obs1, Observation obs2) {
		assertSameAttributes(obs1, obs2);
		AssertUtil.equivalent(obs1.getDimensionId(), obs2.getDimensionId(),  "Obs are different");
		AssertUtil.equivalent(obs1.getDimensionValue(), obs2.getDimensionValue(),  "Obs are different");
		AssertUtil.equivalent(obs1.getSdmxObsTime(), obs2.getSdmxObsTime(),  "Obs are different");
	}
	
	public static void assertSameAttributes(Attributable dsAttr1, Attributable dsAttr2) {
		assertSame(dsAttr1.getAttributes(), dsAttr2.getAttributes());
		
		
		dsAttr1.getMultilingualAttributes().forEach(attr-> {
			IMultilingualKeyValue mkv = dsAttr2.getMultilingualAttribute(attr.getConcept());
			AssertUtil.notNull(mkv, "Missing Attribute for Concept: "+attr.getConcept());
			List<Set<String>> mvList2 = mkv.getMultilingualNodeValues().stream().map(
					e->e.getTexts().stream().map(e2->e2.getLocale() + ":" +e2.getValue()).collect(Collectors.toSet())
					).collect(Collectors.toList());
			
			List<Set<String>> mvList1 = mkv.getMultilingualNodeValues().stream().map(
					e->e.getTexts().stream().map(e2->e2.getLocale() + ":" +e2.getValue()).collect(Collectors.toSet())
					).collect(Collectors.toList());
			
			for(int i=0; i < Math.min(mvList1.size(),  mvList2.size()); i++) {
				AssertUtil.assertSet(mvList1.get(i), mvList2.get(i));
			}
			AssertUtil.equivalent(mvList1.size(), mvList2.size(), "Multivalue Attribtue List Size");
		});
		
		
	}
	
	public static void assertSame(List<KeyValue> kvs1, List<KeyValue> kvs2) {
		Map<String, KeyValue> kvMap1 = kvs2.stream().collect(Collectors.toMap(e->e.getConcept(), e->e));
		Map<String, KeyValue> kvMap2 = kvs2.stream().collect(Collectors.toMap(e->e.getConcept(), e->e));
		
		kvs1.forEach((kv1)-> {
			assertSame(kv1, kvMap2.get(kv1.getConcept()));
		});
		kvMap2.keySet().forEach((conceptId)-> {
			AssertUtil.notNull(kvMap1.get(conceptId), "Missing Key for Concept: "+conceptId);
		});
	}
	
	public static void assertSame(KeyValue kv1, KeyValue kv2) {
		AssertUtil.boolMatch(kv1.hasMultipleValues(), kv2.hasMultipleValues(), "Keys are different");
		
		if(kv1.hasMultipleValues()) {
			AssertUtil.boolMatch(true, ObjectUtil.equivalentCollection(kv1.getValues(), kv2.getValues()), "Keys are different");
		} else {
			AssertUtil.equivalent(kv1.getCode(), kv2.getCode(),  "Keys are different");
		}
	}

	/**
	 * Writes the dataset to the console
	 * @param dre
	 */
	public static void sysout(DataReaderEngine dre) {
		while(dre.moveNextDataset()) {
			
			IDatasetAttributes dsAttributes = dre.getDatasetAttributes();
			if(dsAttributes != null) {
				StringBuilder sb = new StringBuilder();
				sysout(sb, dsAttributes);
				System.out.println(sb.toString());
			}
			
			while(dre.moveNextKeyable()) {
				Keyable key = dre.getCurrentKey();
				StringBuilder sb = new StringBuilder();
				if(key.getGroupName() != null) {
					sb.append(key.getGroupName()+"=");
				}
				sb.append(key.getShortCode());
				sysout(sb, key);
				System.out.println(sb.toString());
				while(dre.moveNextObservation()) {
					System.out.println(dre.getCurrentObservation());
				}
			}
		}
	}
	
	private static void sysout(StringBuilder sb, Attributable attributable) {
		for(KeyValue attr : attributable.getAttributes()) {
			sb.append(";"+attr.getConcept()+"="+KeyValueUtil.getValueString(attr));
		}
	}
	
}
