package io.sdmx.utils.sdmx.data;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataWriterUtil {

	public static void writeAsPrimaryMeasureObservation(DataWriterEngine dwe, Observation obs, boolean includeAttributes) {
		List<AnnotationBean> annotations = obs.getAnnotations();
		if(ObjectUtil.validCollection(annotations)) {
			AnnotationBean[] arr = new AnnotationBean[annotations.size()];
			arr = annotations.toArray(arr);
			writeAsPrimaryMeasureObservation(dwe, obs.getDimensionId(), obs.getDimensionValue(), obs.getMeasures(), arr);
			
		} else {
			writeAsPrimaryMeasureObservation(dwe, obs.getDimensionId(), obs.getDimensionValue(), obs.getMeasures());
		}
    	if(includeAttributes) {
    		for(KeyValue kv : obs.getAttributes()) {
    			dwe.writeAttributeValue(kv.getConcept(), kv.getCode());
    		}
    	}
	}

	public static void writeAsPrimaryMeasureObservation(DataWriterEngine dwe, String dimId, String dimValue, List<KeyValue> measures, AnnotationBean... annotations) {
		if(measures.size() >1){
			throw new SdmxNotImplementedException("Multiple measures not supported");
		}
		KeyValue measure = measures.get(0);
		if(!Objects.equals(measure.getConcept(), PrimaryMeasureBean.FIXED_ID)){
			throw new SdmxNotImplementedException("Can not write measure '"+measure.getConcept()+"'. Only Primary Measure supported");
		} else {
			dwe.writePrimaryMeasure(dimId, dimValue, measure.getCode(), annotations);
		}
	}

	public static void writeMeasures(DataWriterEngine dwe, String dimId, String dimValue, Map<String, String> measures, AnnotationBean... annotations) {
		if(measures == null || measures.size() == 0) {
			dwe.writePrimaryMeasure(dimId, dimValue, null, annotations);
		} else if(measures.size() > 1) {
			throw new SdmxNotImplementedException("Multiple measures not supported");
		} else if(!measures.containsKey(PrimaryMeasureBean.FIXED_ID)) {
			throw new SdmxNotImplementedException("Can not write measure '"+measures.keySet().toArray()[0]+"'. Only Primary Measure supported");
		} else {
			dwe.writePrimaryMeasure(dimId, dimValue, measures.get(PrimaryMeasureBean.FIXED_ID), annotations);
		}
	}


	/**
	 * Walks the datasets in three ways to ensure dataset, key, and obs positions accurately report the correct values:
	 * 1. Walks every dataset, key, and obs ensuring the count increments each time
	 * 2. Walks every dataset, key, skips obs
	 * 3. Walks every dataset
	 * 
	 * The reset method is used between each run to ensure it is also working correctly.  
	 * This method leaves the reader at the end of the dataset
	 */
	public void testPositions(DataReaderEngine dre) {
		int datasetPosion = dre.getDatasetPosition();
		if(datasetPosion != -1) {
			dre.reset();
		}
		int expectedDatasetPosition = -1;
		int expectedKeyPosition = -1;
		int expectedObsPosition = -1;

		ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
		ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
		ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());

		while(dre.moveNextDataset()) {
			expectedDatasetPosition++;
			ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
			ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
			ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
			while(dre.moveNextKeyable()) {
				expectedKeyPosition++;
				expectedObsPosition = -1;
				ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
				ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
				ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
				while(dre.moveNextObservation()) {
					expectedObsPosition++;
					ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
					ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
					ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
				}
			}
		}

		dre.reset();
		expectedDatasetPosition = -1;
		expectedKeyPosition = -1;
		expectedObsPosition = -1;
		while(dre.moveNextDataset()) {
			expectedDatasetPosition++;
			ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
			ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
			ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
			while(dre.moveNextKeyable()) {
				expectedKeyPosition++;
				ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
				ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
				ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
			}
		}

		dre.reset();
		expectedDatasetPosition = -1;
		expectedKeyPosition = -1;
		expectedObsPosition = -1;
		while(dre.moveNextDataset()) {
			expectedDatasetPosition++;
			ObjectUtil.assertEquals(expectedDatasetPosition, dre.getDatasetPosition());
			ObjectUtil.assertEquals(expectedKeyPosition, dre.getKeyablePosition());
			ObjectUtil.assertEquals(expectedObsPosition, dre.getObsPosition());
		}
	}

}
