package io.sdmx.utils.sdmx.date;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.exception.TimeFormatParsingException;

/**
 * Specific SDMX Date related functions
 */
public class SdmxDateUtil {
	/**
     * This method enforces particular standards for particular time formats and can also modify the supplied time value, returning a "unified" value.
     * <p>
     * The rules are:
     * <p>
     * <ul>
     * <li>For SDMX Version 2.1:</li>
     * <ul><li> Will not throw an error unless "enforce strict" is set on. </li>
     * <li>Week format</li>
     * <ul>
     * <li>If "enforce strict", weeks must be: 8 characters long and always with 2 digits following the 'W'</li>
     * <li>If not "enforce strict", pad the week with a '0' at position 7 if required</li>
     * </ul>
     * <li>Half of year</li>
     * <ul>
     * <li>If "enforce strict", the time value must be 7 characters with an 'S' at position 6</li>
     * <li>If not "enforce strict", convert the 'B' to an 'S' if required</li>
     * </ul>
     * </ul>
     *
     * <li>For SDMX Version 2.0:</li>
     * <ul>
     * <li>Week format</li>
     * <ul>
     * <li>If there is a W at position 6 and is 7 or 8 characters long this is correct. Pad the value with a 0 in position 7</li>
     * <li>For all other cases throw an error</li>
     * </ul>
     * <li>Half of year</li>
     * <ul>
     * <li>if there is a 'B' at position 5 and the value is 7 characters long, convert the 'B' to an 'S'</li>
     * <li>For all other cases throw an error</li>
     * </ul>
     * <li>Month</li>
     * <ul>
     * <li>must be 7 or 8 characters long and have an 'M' at position 6. Cannot have zero padding before the single months</li>
     * <li>all other cases throw an error</li>
     * </ul>
     * </ul>
     *
     * <li>For SDMX Version 1.0:</li>
     * <ul>
     * <li>Quarter of Year</li>
     * <ul>
     * <li>must be 7 characters long and converts 01, 04, 07 and 10 to Q1, Q2, Q3 and Q4 respectively</li>
     * <li>all other cases throw an error</li>
     * </ul>
     * <li>Half of Year</li>
     * <ul>
     * <li>must be 7 characters long and converts 01, 07 to S1 S2 respectively</li>
     * <li>all other cases throw an error</li>
     * </ui>
     * </ul>
     * </ul>
	 *
	 * @param obsTime the time value to check
	 * @param schemaVersion the version of the schema that the obsTime is for
	 * @param timeFormat the time format the obsTime should be checked against
	 * @param enforceStrict2_1 whether to enforce SDMX 2.1 "strict rules"
	 * @return a unified version of obsTime
	 * @throws TimeFormatParsingException
	 */
    public static String unifyObservationTime(String obsTime, SDMX_SCHEMA schemaVersion, TIME_FORMAT timeFormat, boolean enforceStrict2_1) throws TimeFormatParsingException {
        if (timeFormat == null || obsTime == null || schemaVersion == null) {
            return obsTime;
        }

        if (SDMX_SCHEMA.VERSION_TWO_POINT_ONE.equals(schemaVersion)) {
            if (TIME_FORMAT.WEEK.equals(timeFormat)) {
                // SDMX 2.1 defines a Week of the format YYYY-Www
                if (enforceStrict2_1 && (obsTime.length() != 8 || (obsTime.length() > 5 && obsTime.charAt(5) != 'W'))) {
                    throw new TimeFormatParsingException("Weekly data in SDMX 2.1 is of the format YYYY-Www. Reported value is: " + obsTime);
                } else if (obsTime.length() == 7 && obsTime.charAt(5) == 'W') {
                    // FR-4524 any weekly times that are in the format YYYY-WX need to be converted to 2 digits thus: YYYY-WXX.
                    // E.g. 2001-W1 becomes 2001-W01
                    return obsTime.substring(0,6) + "0" + obsTime.charAt(6);
                }
                return obsTime;
            }

            if (TIME_FORMAT.HALF_OF_YEAR.equals(timeFormat)) {
                if (obsTime.length() == 7 && obsTime.charAt(5) == 'B') {
                    if (enforceStrict2_1) {
                        throw new TimeFormatParsingException("Biannual data in SDMX 2.1 is of the format YYYY-S[1-2]. Reported value is: " + obsTime);
                    } else {
                        // FR-4537 any Half-Year times in 2.0 format should be converted to to 2.1 format.
                        // E.g. 2001-B1 becomes 2001-S1
                        obsTime= obsTime.substring(0,5) + "S" + obsTime.charAt(6);
                    }
                }
                return obsTime;
            }

            return obsTime;
        }

        if (SDMX_SCHEMA.VERSION_TWO.equals(schemaVersion)) {
            if (TIME_FORMAT.WEEK.equals(timeFormat)) {
                if (obsTime.charAt(5) == 'W') {
                    if (obsTime.length() == 8) {
                        if (obsTime.charAt(6) == '0') {
                            // zero-padding is not allowed in SDMX 2.0
                            throw new TimeFormatParsingException("Weekly data in SDMX 2.0 is of the format W1-W9,W10-W52. Reported value is: " + obsTime);
                        }
                        return obsTime;
                    }
                    if (obsTime.length() == 7) {
                        // FR-4524 any weekly times that are in the format YYYY-WX need to be converted to 2 digits thus: YYYY-WXX.
                        // E.g. 2001-W1 becomes 2001-W01
                        return obsTime.substring(0,6) + "0" + obsTime.charAt(6);
                    }
                }
                throw new TimeFormatParsingException("Weekly data in SDMX 2.0 is of the format W1-W9,W10-W52. Reported value is: " + obsTime);
            }

            if (TIME_FORMAT.HALF_OF_YEAR.equals(timeFormat)) {
                if (obsTime.length() == 7) {
                    if (obsTime.charAt(5) == 'B') {
                        // FR-4537 any Half-Year times in 2.0 format should be converted to to 2.1 format.
                        // E.g. 2001-B1 becomes 2001-S1
                        return obsTime.substring(0,5) + "S" + obsTime.charAt(6);
                    }
                }
                throw new TimeFormatParsingException("Biannual data in SDMX 2.0 is of the format YYYY-B[1-2]. Reported value is: " + obsTime);
            }

            if (TIME_FORMAT.MONTH.equals(timeFormat)) {
                // Monthly data is of the M prefix format M1-9,M10-M12 but must also support the ISO YYYY-MM
                // Need a check to ensure that M0 is not supported in SDMX 2.0
                if (obsTime.charAt(4) == '-' ) {
                    if (obsTime.charAt(5) == 'M') {
                        if (obsTime.length() == 7) {
                            return obsTime;
                        }
                        if (obsTime.length() == 8) {
                            if (obsTime.charAt(6) != '1') {
                                throw new TimeFormatParsingException("Monthly data in SDMX 2.0 is of the format M1-M9,M10-M12. Reported value is: " + obsTime);
                            }
                            return obsTime;
                        }
                    } else if (obsTime.length() == 7) {
                        return obsTime;
                    }
                }
                throw new TimeFormatParsingException("Monthly data in SDMX 2.0 is of the format M1-M9,M10-M12. Reported value is: " + obsTime);
            }

            return obsTime;
        }

        if (SDMX_SCHEMA.VERSION_ONE.equals(schemaVersion)) {
            if (timeFormat.equals(TIME_FORMAT.QUARTER_OF_YEAR)) {
                // For quarterly convert 01, 04, 07 and 10 to Q1, Q2, Q3 and Q4 respectively.
                if (obsTime.length() == 7 && obsTime.charAt(4) == '-') {
                    String year = obsTime.substring(0,4);
                    String suffix = obsTime.substring(5);
                    String quarterOfYearValue = null;
                    switch (suffix) {
                    case "01":
                        quarterOfYearValue = "-Q1";
                        break;
                    case "04":
                        quarterOfYearValue = "-Q2";
                        break;
                    case "07":
                        quarterOfYearValue = "-Q3";
                        break;
                    case "10":
                        quarterOfYearValue = "-Q4";
                        break;
                    default:
                        throw new TimeFormatParsingException("Quarterly data in SDMX 1.0 is of the format YYYY-QQ. Reported value is: " + obsTime);
                    }
                    if (quarterOfYearValue != null) {
                        obsTime = year + quarterOfYearValue;
                    }
                } else {
                    throw new TimeFormatParsingException("Quarterly data in SDMX 1.0 is of the format YYYY-QQ. Reported value is: " + obsTime);
                }
                return obsTime;
            }
            if (timeFormat.equals(TIME_FORMAT.HALF_OF_YEAR)) {
                // For semi-annual convert 01 and 07 to S1 and S2 respectively.
                if (obsTime.length() == 7 && obsTime.charAt(4) == '-') {
                    String year = obsTime.substring(0,4);
                    String suffix = obsTime.substring(5);
                    String halfYearValue = null;
                    switch (suffix) {
                    case "01":
                        halfYearValue = "-S1";
                        break;
                    case "07":
                        halfYearValue = "-S2";
                        break;
                    default:
                        throw new TimeFormatParsingException("Half-Yearly data in SDMX 1.0 is of the format YYYY-0S. Reported value is: " + obsTime);
                    }
                    if (halfYearValue != null) {
                        obsTime = year + halfYearValue;
                    }
                }
                return obsTime;
            }
            return obsTime;
        }

        return obsTime;
    }

}
