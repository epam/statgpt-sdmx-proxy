package io.sdmx.utils.sdmx.structure;

import static java.util.stream.Collectors.groupingBy;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.VersionRef;

public class UrnUtil {
	private static final Logger LOG = LoggerFactory.getLogger(UrnUtil.class);
	
	private static final Pattern OLD_ACY_URN = Pattern.compile("urn:sdmx:org.sdmx.infomodel.base.Agency=\\w+[\\.\\w*]*");
    private static final Pattern VERSION_REGEX = Pattern.compile("((?=\\().*?(?<=\\)))");
    public static final String HCL_UPGRADE_SYMBOL = "@"; //Symbol used to concatenate a hierarchy ID with a HCL ID
    
    
    
    /**
     * Filters URNs based on version, the version syntax is two or three parts:
     * 
     * 1.0
     * 1.0.0
     * 
     * If a suffix exists, the version is deemed unstable
     * 1.0.0-draft
     * 
     * If a part contains a * it indicates all versions that match
     * 1.0.* will match 1.0.0 and 1.0.1
     * 1.* will match 1.0.0 and 1.0.1 and 1.1.0
     * 
     * 
     * If a part contains a ~ it will match all latest versions which are stable
     * 1.0.~ will match 1.0.5 only if assessing the following versions: 1.0.3, 1.0.4, 1.0.5, and 1.0.6-draft
     * 
     * If a part contains a + it will match all latest versions which are stable or unstable
     * 1.0.~ will match 1.0.6-draft only if assessing the following versions: 1.0.3, 1.0.4, 1.0.5, and 1.0.6-draft
     * 
     * When filtering latest, the latest versions for each object will be returned that fall within the VersionReference , i.e.
     * 
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.0.0)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.0.5)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.1.0)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.1.0)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.2.0)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_FREQ(1.0.0)
     * 
     * With a Version reference of 1.0.+ would return
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_BIS_UNIT(1.0.5)
     * urn:sdmx:org.sdmx.infomodel.codelist.Codelist=BIS:CL_FREQ(1.0.0)
     * 
     * @param urns to filter - if null will default to an empty set
     * @param latestVRef provides filter parameters if null defaults to ALL
     * @return not null mutable set of URNs
     */
    public static Set<IURNMaintainable<?>> filterByVersion(Set<IURNMaintainable<?>> urnsToFilter, IVersionRef vRef) {
    	if(vRef == null) {
    		vRef = VersionRef.ALL;
    	}
    	if(urnsToFilter == null) {
    		return new HashSet<>();
    	}
    	if(vRef.isAll()) {
    		return urnsToFilter;
    	}
    	Set<IURNMaintainable<?>> filteredUrns = new HashSet<>();
		if(vRef.isLatest()) {
			//Find the latest version only - group by type
			Map<String, List<IURNMaintainable<?>>> groupedSet = urnsToFilter.stream().collect(groupingBy(e-> e.getURNNoVersion()));
			boolean includeAllDrafts = "*".equals(vRef.getVersionSuffix());
			String filterSuffix = vRef.getVersionSuffix();
			for(String urnObject : groupedSet.keySet()) {
				List<IURNMaintainable<?>> urns = groupedSet.get(urnObject);
				IURNMaintainable<?> latest = null;
				for(IURNMaintainable<?> urn : urns) {
					ISdmxVersion version = urn.getAbsoluteVersion();
					//Do not include all suffix version - and the version or the reference has a suffix
					if(!includeAllDrafts) {
					    if(!ObjectUtil.equivalent(version.getSuffix(), filterSuffix)) {
					        continue;  //the two values are not equal
					    }
					}
					if(vRef.isMatch(version) && (latest == null || version.isLater(latest.getAbsoluteVersion()))) {
						latest = urn;
					}
				}
				if(latest != null) {
					filteredUrns.add(latest);
				}
			}
		} else {
			//match all versions
			for(IURNMaintainable<?> currentUrn : urnsToFilter) {
				if(vRef.isMatch(currentUrn.getVersion())) {
					filteredUrns.add(currentUrn);
				}
			}
		}
		return filteredUrns;
    }
    
	/**
	 * Validates a URN - upgrading it if required (i.e a 2.1 Hierarchy is not a maintainable)
	 * @param urn
	 * @param structureType
	 * @return
	 */
	public static String validateURN(String urn, SDMX_STRUCTURE_TYPE structureType) {
		if (urn == null) {
			throw new IllegalArgumentException("Specified urn may not be null");
		}
		String[] split = urn.split("=");
		if(split.length == 0) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
		}
		urn = convertFromSdmx2ToSdmx3(urn);
		String urnPrefix = split[0];
		
		SDMX_STRUCTURE_TYPE targetType =  SDMX_STRUCTURE_TYPE.parsePrefix(urnPrefix);
		if(targetType == SDMX_STRUCTURE_TYPE.MAINTAINABLE) {
			return urn;
		}
		
		if(targetType == SDMX_STRUCTURE_TYPE.AGENCY && OLD_ACY_URN.matcher(urn).matches()) {
			//upgrade Agency URN
			String[] agencyId = AgencyUtil.splitAgencyId(urn.split("=")[1]);
			urn = urnPrefix + "=" + agencyId[0] + ":AGENCIES(1.0)."+agencyId[1];
		} else {
			urn = targetType.getUrnPrefix() + split[1];
		}
		
		String version = getVersionFromUrn(urn);
		if(version == null && targetType != SDMX_STRUCTURE_TYPE.AGENCY) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
		}
		String[] components = getUrnComponents(urn);
		if(targetType.isMaintainable()) {
			if(components == null) {
				throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
			}
			if(targetType == SDMX_STRUCTURE_TYPE.SUBSCRIPTION) {
				if(components.length != 4) {
					throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
				}
			} else if(components.length != 2) {
				if(components.length == 3 && targetType == SDMX_STRUCTURE_TYPE.HIERARCHY) {
					//Hierarchy ID is URN part 3 if it is the same as URN part 2 then we only use 1
					//If they are different we concatenate
					String hclId = components[1];
					String hcyId = components[2];
					String newId = hclId;
					if(!hclId.equals(hcyId)) {
						newId +=  HCL_UPGRADE_SYMBOL+hcyId;
					}
					return SDMX_STRUCTURE_TYPE.HIERARCHY.generateUrn(components[0], newId.toUpperCase(), version);
				}
				throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
			}
		} else if(structureType.isIdentifiable()) {
			if(components == null || components.length <= 2) {
				if(components.length == 1 && structureType == SDMX_STRUCTURE_TYPE.AGENCY) {
					
				} else {
					throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
				}
			}
		}
		for(String currentComponent : components) {
			if(!ObjectUtil.validString(currentComponent)) {
				throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
			}
		}
		return urn;
	}
	
	/**
	 * Returns the type of identifiable object that this urn represents
	 * @param urn
	 * @return
	 * @throws StructureException
	 */
	public static SDMX_STRUCTURE_TYPE getIdentifiableType(String urn) throws SdmxSemmanticException {
		if (urn == null) {
			throw new IllegalArgumentException("Specified urn may not be null");
		}
		if(urn.split("=").length == 0) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
		}
		String urnPrefix = urn.split("=")[0];
		urnPrefix = convertUrnPrefixFromSdmx2ToSdmx3(urnPrefix);
		return SDMX_STRUCTURE_TYPE.parsePrefix(urnPrefix);
	}
	
	/**
	 * Converts an SDMX version 2 URN into a URN that is legal to the SDMX 3 specification
	 * @param urn
	 * @return
	 */
	public static String convertFromSdmx2ToSdmx3(String urn) {
		if (urn == null) {
			throw new IllegalArgumentException("Specified urn may not be null");
		}
		if (urn.split("=").length == 0) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_URN_MALFORMED, urn);
		}
		String[] splitArray = urn.split("=");
		String prefix = convertUrnPrefixFromSdmx2ToSdmx3(splitArray[0]);
		return prefix + "=" + splitArray[1];
	}
	
	/**
	 * Converts an SDMX version 2 URN prefix (the part before the equals sign) into a URN prefix that is legal to the SDMX 3 specification
	 * @param urn
	 * @return
	 */
	private static String convertUrnPrefixFromSdmx2ToSdmx3(String urnPrefix) {
		// Convert the SDMX 2.1 ValueList URN into SDMX 3 format
		if (urnPrefix.equals("urn:sdmx:org.sdmx.infomodel.valuelist.ValueList")) {
			return "urn:sdmx:org.sdmx.infomodel.codelist.ValueList";
		}
		
		if (urnPrefix.equals("urn:sdmx:org.sdmx.infomodel.codelist.HierarchicalCodelist")) {
			return "urn:sdmx:org.sdmx.infomodel.codelist.Hierarchy";
		}
		
		return urnPrefix;
	}
	
    public static String getUrnPostfix(String urn) {
        return urn.split("=")[1];
    }
    
    public static String getUrnPrefix(String urn) {
        return urn.split("=")[0];
    }
    
    public static String getUrnPostfix(String agencyId, String id, IVersionRef version) {
    	return getUrnPostfix(agencyId,  id, version == null ? "1,0" : version.toString());
    }
    
    public static String getUrnPostfix(String agencyId, String id, String version) {
        return agencyId + ":" + id + "("+version+")";
    }
    
    public static String getUrnPostfix(String agencyId, String maintid, String version, String... id) {
        String idPost="";
    	for(int i = 0 ; i < id.length ; i++) {
    		idPost+=".";
    		idPost+= id[i];
    		i++;
    	}
    	return agencyId + ":" + maintid + "("+version+")" + idPost;
    }
    
    private static String removeVersionsFromUrn(String urn) {
    	if(urn.contains("[") || urn.contains("]")) {
    		LOG.warn("URN using pre 2.1 syntax [#version] upgrading to (#version) : " + urn);
    		urn = urn.replace("[", "(");
    		urn = urn.replace("]", ")");
    	}
        return urn.replaceAll("(?=\\().*?(?<=\\))", "");
    }
    
    /**
	 * Builds a MaintainableRefBean from a URN or partial URN:
	 * example partial URN: BIS:RT(1.0)
	 * @param urn
	 */
    public static IMaintainableRef getMaintainableRef(String urn) {
    	String[] components = getUrnComponents(urn);
    	String version = getVersionFromUrn(urn);
    	return MaintainableRef.getInstance(components[0], components[1], version);
    }

    /**
     * returns the agency id, id, and any identifiable ids of a URN or partial URN
     * @param urn example partial URN BIS:CL_FREQ(1.0)
     * @return
     */
    public static String[] getUrnComponents(String urn) {
    	String mainUrn;
    	if(urn.contains("=")) {
    		mainUrn = getUrnPostfix(urn);
    	} else {
    		mainUrn = urn;
    	}
        
        String urnVersionsRemoved = removeVersionsFromUrn(mainUrn);
        String[] majorComponents = urnVersionsRemoved.split("\\:");
        if(majorComponents.length == 1) {
        	throw new SdmxSemmanticException("URN agency id is expected to be followed by a ':' character : '"+urn+"'");
        }
        if(majorComponents.length != 2) {
        	throw new SdmxSemmanticException("URN should not contain more than one ':' character: '"+urn+"'");
        }
        String[] minorComponents = majorComponents[1].split("\\.");
        String[] returnArray = new String[minorComponents.length + 1];
        returnArray[0] = majorComponents[0];
        for(int i = 0; i < minorComponents.length; i++) {
        	returnArray[i+1] = minorComponents[i];
        }
        return returnArray;
    }
    
    public static String getVersionFromUrn(String urn) {
    	if(urn.contains("[") || urn.contains("]")) {
    		LOG.warn("URN using pre 2.1 syntax [#version] upgrading to (#version) : " + urn);
    		urn = urn.replace("[", "(");
    		urn = urn.replace("]", ")");
    	}
    	String mainUrn;
    	if(urn.contains("=")) {
    		mainUrn = getUrnPostfix(urn);
    	} else {
    		mainUrn = urn;
    	}
        Matcher m = VERSION_REGEX.matcher(mainUrn);
        if(m.find()) {
        	String version = m.group();
        	version = version.replace("(", "");
        	version = version.replace(")", "");
        	return version;
        }
        return null;
    }
    
    public static String createURN(SDMX_STRUCTURE_TYPE type, String shortUrl) {
		return type.getUrnPrefix() + shortUrl;
	}
}
