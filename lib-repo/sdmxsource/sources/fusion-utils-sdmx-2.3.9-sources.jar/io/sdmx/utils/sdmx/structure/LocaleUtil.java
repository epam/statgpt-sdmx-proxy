package io.sdmx.utils.sdmx.structure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.utils.core.object.ObjectUtil;

public class LocaleUtil {
	private static List<Locale> defaultLocales;

	public static List<Locale> getDefaultLocales() {
		if(defaultLocales == null) {
			defaultLocales = new ArrayList<>();
			defaultLocales.add(Locale.ENGLISH);
		}
		return defaultLocales;
	}

	public void setDefaultLocale(Locale defaultLocale) {
		defaultLocales = new ArrayList<>();
		defaultLocales.add(defaultLocale);
	}

	public void setDefaultLocale(List<Locale> defaultLocales) {
		LocaleUtil.defaultLocales = defaultLocales;
	}

	public static String getStringByDefaultLocale(Map<Locale, String> localToStringMap) {
		if(!ObjectUtil.validCollection(LocaleUtil.getDefaultLocales())) {
			throw new IllegalArgumentException("No Default Locale found");
		}
		for(Locale currentLocale : LocaleUtil.getDefaultLocales()) {
			String str = localToStringMap.get(currentLocale);
			if(ObjectUtil.validString(str)) {
				return str;
			}
		}
		return null;
	}

	public static Map<Locale, String> buildLocalMap(List<TextTypeWrapper> textTypes) {
		if(textTypes == null) {
			return null;
		}
		Map<Locale, String> buildLocalMap = new HashMap<>();
		for(TextTypeWrapper currentTextType : textTypes) {
			String lang = currentTextType.getLocale();
			String value = currentTextType.getValue();
			Locale loc = new Locale(lang);
			buildLocalMap.put(loc, value);
		}
		return buildLocalMap;
	}

	/**
     * Returns the Locale for the specified headerStr.
     *
     * The headerString can be a complicated value (e.g.: fr-CA, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5 )
     * In Java7 you cannot simply use:  new Locale(headerStr)
     * This will give the WRONG result.
     * Solution: split the headerStr and use the first element.
     *
     * @param headerStr a value as obtained from a browser
     * @return the Locale
     */
    public static Locale obtainLocale(String headerStr) {
        Locale aLocale = null;
        for (String str : headerStr.split(",")) {
            String[] arr = str.trim().replace("-", "_").split(";");

            // Parse the locale
            String[] l = arr[0].split("_");
            switch(l.length) {
                case 2: aLocale = new Locale(l[0], l[1]); break;
                case 3: aLocale = new Locale(l[0], l[1], l[2]); break;
                default: aLocale = new Locale(l[0]); break;
            }

            if (aLocale != null) {
                return aLocale;
            }
        }
        return null;
    }
}
