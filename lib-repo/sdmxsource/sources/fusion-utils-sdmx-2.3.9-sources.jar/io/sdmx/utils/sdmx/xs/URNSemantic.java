package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNSemantic;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

public class URNSemantic extends URN implements IURNSemantic {
	private static final long serialVersionUID = 1L;

	/**
	 * Package protected, constructed via the URN.getInstance method
	 */
	URNSemantic(ISDMXStructureType structureType, IMaintainableRef ref, String identifiableId, String urn) {
		super(structureType, ref, identifiableId, urn);
	}

	@Override
	public IURNSingle<? extends MaintainableBean> getMaintainableURN() {
		return (IURNSingle<? extends MaintainableBean>)super.getMaintainableURN();
	}
	
	
	@Override
	public REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.SEMANTIC;
	}

}