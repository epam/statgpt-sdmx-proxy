package io.sdmx.utils.sdmx.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import io.sdmx.api.http.Request;

/**
 * Utility for processing REST URL parameters
 */
public class SdmxRESTUtil {
	private static Pattern COMPONENT_PTN = Pattern.compile("c\\[[A-Za-z\\@0-9_\\$\\-]*\\]");

	/**
	 * Process the request to extract all of the Component query parameters, where a component parameter
	 * is a parameter which meets the pattern c[string]=value
	 * 
	 * For example
	 * 
	 * c[FREQ]=M,Q,P would result in a map with FREQ and the value M,Q,P
	 * 
	 * @param request
	 * @return
	 */
	public static Map<String, String> processComponentQueryParamters(Request request) {
		Map<String, String> requestParameters = request.getParameters();
		Map<String, String> returnParameters = new HashMap<>();
		
		for(String paramName : requestParameters.keySet()) {
			if(COMPONENT_PTN.matcher(paramName).matches()) {
				String componentId = paramName.substring(2, paramName.length()-1);
				returnParameters.put(componentId, requestParameters.get(paramName));
			}
 		}
		return returnParameters;
	}
	
}
