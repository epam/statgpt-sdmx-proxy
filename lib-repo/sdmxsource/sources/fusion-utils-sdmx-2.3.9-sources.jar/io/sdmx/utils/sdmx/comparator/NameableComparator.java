package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;

public class NameableComparator implements Comparator<NameableBean> {
	public static final NameableComparator INSTANCE = new NameableComparator();

	private NameableComparator() {}

	@Override
	/**
	 * Compares two nameables by name
	 */
	public int compare(NameableBean iBean1, NameableBean iBean2) {
		String id1 = iBean1.getName();
		String id2 = iBean2.getName();
		int compare =  id1.compareToIgnoreCase(id2);
		if(compare == 0) {
			return iBean1.getUrn().compareTo(iBean2.getUrn());
		}
		return compare;
	}
	
}
