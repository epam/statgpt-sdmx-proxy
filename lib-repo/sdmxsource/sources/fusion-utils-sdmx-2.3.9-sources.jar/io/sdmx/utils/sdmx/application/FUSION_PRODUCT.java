package io.sdmx.utils.sdmx.application;

public enum FUSION_PRODUCT {
	FUSION_REGISTRY("Fusion Registry"),
	FUSION_MATRIX("Fusion Matrix"),
	FUSION_MATRIX_ADMIN("Fusion Matrix Manager"),
	FUSION_SECURITY("Fusion Security"),
	FUSION_SCRIBE("Fusion Scribe"),
	FUSION_SCRIBE_ADMIN("Fusion Scribe (Admin)"),
	FUSION_AUDIT("Fusion Audit");
	
	private String humanName;
	
	private FUSION_PRODUCT(String humanName) {
		this.humanName = humanName;
	}

	public String getHumanName() {
		return humanName;
	}
	
	public static FUSION_PRODUCT parseString(String str) {
		for(FUSION_PRODUCT currentProduct : FUSION_PRODUCT.values()) {
			if(currentProduct.getHumanName().equals(str) || currentProduct.toString().equals(str)) {
				return currentProduct;
			}
		}
		return null;
	}
}
