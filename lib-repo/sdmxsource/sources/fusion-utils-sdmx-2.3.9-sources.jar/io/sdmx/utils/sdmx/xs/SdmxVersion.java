package io.sdmx.utils.sdmx.xs;

import java.util.Map;
import java.util.WeakHashMap;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.VERSION_PART;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.utils.core.object.StringUtil;

public class SdmxVersion implements ISdmxVersion {
	private static final Map<String, SdmxVersion> cache = new WeakHashMap<>();
	public static final ISdmxVersion DEFAULT = SdmxVersion.getInstance("1.0");
	private static final long serialVersionUID = 1L;
	private String version;
	private String suffix;
	private int major;
	private int minor = -1;
	private int patch = -1;

	public static synchronized ISdmxVersion getInstance(int major, int minor, int patch) {
	    return getInstance(major, minor, patch, null);
	}
	
	public static synchronized ISdmxVersion getInstance(int major, int minor, int patch, String suffix) {
		StringBuilder sb = new StringBuilder();
		sb.append(major);
		if(minor >=0) {
			sb.append("."+minor);
			if(patch >=0) {
				sb.append("."+patch);
			}
		}
		if(suffix != null) {
		    sb.append("-"+suffix);
		}
		return getInstance(sb.toString());
	}
	
	public static synchronized ISdmxVersion getInstance(String version) {
		if(version == null) {
			return DEFAULT;
		}
		//Ensure version has 2 parts
		if(!version.contains(".")) {
		    version += ".0";
		}
		SdmxVersion sdxmVersion = cache.get(version);
		if(sdxmVersion == null) {
			sdxmVersion = new SdmxVersion(version);
			cache.put(version, sdxmVersion);
		}
		return sdxmVersion;
	}

	private SdmxVersion(String version) {
		this.version = StringUtil.manualIntern(version);
		String[] splitSuffix = version.split("-", 2);
		if(splitSuffix.length > 1) {
			this.suffix = splitSuffix[1];
		}
		String[] versionParts = splitSuffix[0].split("\\.");
		if(versionParts.length > 3) {
			throw new SdmxSemmanticException("Unsupported version syntax '"+version+"'. Only 3 version parts supported major.minor.patch e.g. 1.0.0");
		}
		try {
			major = Integer.parseInt(versionParts[0]);
			if(versionParts.length > 1) {
				minor = Integer.parseInt(versionParts[1]);
			}
			if(versionParts.length > 2) {
				patch = Integer.parseInt(versionParts[2]);
			}
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Unable to parse version '"+version+"'");
		}
	}
	
	@Override
	public ISdmxVersion incrementVersion(VERSION_PART part) {
		switch(part) {
		case MAJOR: return SdmxVersion.getInstance(major+1, minor, patch);
		case MINOR: return SdmxVersion.getInstance(major, minor+1, patch);
		case PATCH: return SdmxVersion.getInstance(major, minor, patch+1);
		}
		return this;
	}

	@Override
	public int compareTo(ISdmxVersion that) {
		int i = this.major - that.getMajor();
		if(i == 0) {
			i = this.minor - that.getMinor();
		}
		if(i == 0) {
			i = this.patch - that.getPatch();
		}
		if(i == 0) {
			if(this.suffix != null) {
				if(that.getSuffix() != null) {
					return this.suffix.compareTo(that.getSuffix());
				}
				return -1;
			}
			if(that.getSuffix() != null) {
				return 1;
			}
		}
		return i;
	}
	
	@Override
	public boolean isLater(ISdmxVersion that) {
		return this.compareTo(that) > 0;
	}

	@Override
	public boolean isStable() {
		return suffix == null && isTwoPart() == false;
	}

	@Override
	public boolean isTwoPart() {
		return patch  < 0;
	}

	@Override
	public int getMajor() {
		return major;
	}

	@Override
	public int getMinor() {
		return minor;
	}

	@Override
	public int getPatch() {
		return patch;
	}

	@Override
	public String getSuffix() {
		return suffix;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		return version;
	}

	@Override
	public boolean equals(Object obj) {
		if(this == obj) {
			return true;
		}
		if(obj instanceof SdmxVersion) {
			SdmxVersion that = (SdmxVersion)obj;
			return this.version.equals(that.version);
		}
		return false;
	}
}
