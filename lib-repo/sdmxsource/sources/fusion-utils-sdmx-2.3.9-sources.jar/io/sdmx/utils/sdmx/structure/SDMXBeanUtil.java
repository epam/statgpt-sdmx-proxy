package io.sdmx.utils.sdmx.structure;

import java.util.Set;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class SDMXBeanUtil {

	public static TERTIARY_BOOL createTertiary(boolean isSet, boolean value) {
		if(!isSet) {
			return TERTIARY_BOOL.UNSET;
		}
		return value ? TERTIARY_BOOL.TRUE : TERTIARY_BOOL.FALSE;
	}
	
	/**
	 * given a set of MaintainableBeans, this will return a set of the StructureReference for each maint
	 * @param maints
	 * @return
	 */
	public static Set<StructureReferenceBean> toStructureReferenceSet(Set<MaintainableBean> maints){
		return ObjectUtil.collectToSet(maints.stream().map(MaintainableBean::asReference));
	}
	
}
