package io.sdmx.utils.sdmx.application;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Objects;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.FusionProduct;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.version.VersionableUtil;

/**
 * Note that for a version in the format: 9.10.3 , 9 would be the major version, 10 the minor version and 3 the revision.
 */
public class FusionProductImpl implements FusionProduct {
	private static final Logger LOG = LoggerFactory.getLogger(FusionProductImpl.class);
	
	private String version;
	private String majorVersion;
	private String productName;
	private String product;
	private String releaseDate;
	private Date releaseDateAsDate;
	
	public FusionProductImpl(JSONObject json) {
		Objects.requireNonNull(json, "FusionProductInformation: JSONObject is required");
		try {
			if(json.has("Product")) {
				this.product = (String)json.get("Product");
			}
			if(json.has("Version")) {
				this.version = (String)json.get("Version");
			}
			if(json.has("ProductName")) {
				this.productName = (String)json.get("ProductName");
			}
			if(json.has("ReleaseDate")) {
				this.releaseDate = (String)json.get("ReleaseDate");
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not read FusionProductInformation from JSON: " +  json.toString());
		}
		validate();
	}
	
	public FusionProductImpl(String product, String productName, String version, String releaseDate) {
		this.product = product;
		this.productName = productName;
		this.version = version;
		this.releaseDate = releaseDate;
		validate();
	}

	private void validate() {
		Objects.requireNonNull(releaseDate, "FusionProduct: releaseDate is required");
		Objects.requireNonNull(version, "FusionProduct: version is required");
		Objects.requireNonNull(productName, "FusionProduct: productName is required");
		Objects.requireNonNull(product, "FusionProduct: product is required");
		generateReleaseDateAsDate();
		setVersionInformation();
	}
	
	@Override
	public String getMajorVersion() {
		return majorVersion;
	}

	@Override
	public Date getReleaseDateAsDate() {
		if(releaseDateAsDate == null && ObjectUtil.validString(releaseDate)) {
			generateReleaseDateAsDate();
		}
		return releaseDateAsDate;
	}
	
	private void generateReleaseDateAsDate() {
		DateFormat df = DateUtil.getDateFormatter("yyyy-MM-dd'T'HH:mm:ss'Z'");
		try {
			this.releaseDateAsDate = df.parse(releaseDate);
		} catch (ParseException e) {
			LOG.warn("Could not parse Registry Build Date '"+releaseDate+"' - Expected date format yyyy-MM-dd'T'HH:mm:ss'Z'.");
		}
	}

	@Override
	public String getVersion() {
		return version;
	}


	@Override
	public String getProductName() {
		if(!ObjectUtil.validString(productName)) {
			return product;
		}
		return productName;
	}

	@Override
	public String getProduct() {
		return product;
	}

	@Override
	public String getReleaseDate() {
		return releaseDate;
	}
	
	private void setVersionInformation() {
		String[] versionSplit = this.version.split("-");
		if(!VersionableUtil.validVersion(versionSplit[0])) {
			LOG.warn("Version '"+version+"' is invalid Format. Unable to determine Major version.");
			return;
		}
		
//		if(versionSplit.length > 1) {
//			this.version = versionSplit[0] + "- (Beta)";
//		} else {
//			this.version = versionSplit[0];
//		}

		majorVersion = this.version.split("\\.")[0];
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
}
