package io.sdmx.utils.sdmx.structure;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.query.BaseDataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.api.sdmx.model.data.query.SeriesQuery;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataQueryUtil {

	private static DataQuerySelectionComparator COMPARATOR = new DataQuerySelectionComparator();


	public static String genereateHash(SeriesQuery sq) {
		StringBuilder sb = new StringBuilder(generateBaseHash(sq));
		if(ObjectUtil.validCollection(sq.getSeries())) {
			Set<String> sorted = new TreeSet<String>(sq.getSeries());
			for(String selection : sorted) {
				sb.append(selection);
			}
		}
		return sb.toString();
	}
	
	
	public static String genereateHash(DataQuery dq) {
		StringBuilder sb = new StringBuilder(generateBaseHash(dq));
		sb.append("h"+(dq.includeHistory() ? 1 : 0));
		Set<DataQuerySelection> selections = dq.getSelections();
		if(selections != null) {
			Set<DataQuerySelection> sortedGroups = new TreeSet<>(COMPARATOR);
			sortedGroups.addAll(selections);
			for(DataQuerySelection dqs : sortedGroups) {
				sb.append(dqs.getComponentId()+ (dqs.isExcluded() ? "!=" : "="));
				Set<String> sorted = new TreeSet<>(dqs.getValues());
				for(String selection : sorted) {
					sb.append(selection);
				}
			}
		}
		if(ObjectUtil.validCollection(dq.getSeries())) {
			Set<String> sortedSeries = new TreeSet<>(dq.getSeries());
			for(String selection : sortedSeries) {
				sb.append(selection);
			}
		}
		if (dq.getMaxSeries() != null) {
			sb.append("MAX_SERIES="+dq.getMaxSeries());
		}
		if (dq.getMaxObservations() != null) {
			sb.append("MAX_OBS="+dq.getMaxObservations());
		}
		if (dq.getLimit() > 0 ) {
			sb.append("LIMIT="+dq.getLimit());
		}
		if (dq.getOffset() >= 0) {
			sb.append("OFFSET="+dq.getOffset());
		}
		if(dq.getDataProvider() != null) {
			for(DataProviderBean dp : dq.getDataProvider()) {
				sb.append("dp"+dp.getShortURN());
			}
		}
		return sb.toString();
	}

	private static String generateBaseHash(BaseDataQuery dq) {
		boolean hasFirstNObs = dq.getFirstNObservations() != null;
		boolean hasLastNObs = dq.getLastNObservations() != null;
		boolean hasLastUpdatedDate = dq.getLastUpdatedDate() != null;
		SdmxPeriod period =  dq.getQueryPeriod();

		boolean hasDateFrom = period != null && period.hasStartPeriod();
		boolean hasDateTo = period != null && period.hasEndPeriod();

		long lastUpdatedDate = hasLastUpdatedDate ? dq.getLastUpdatedDate().getDate().getTime() : -1;
		int firstNObs = hasFirstNObs ? dq.getFirstNObservations() : -1;
		int lastNObs = hasLastNObs ? dq.getLastNObservations() : -1;
		long dateFrom = hasDateFrom ? period.getStartPeriod().getDate().getTime() : -1;
		long dateTo = hasDateTo ?  period.getEndPeriod().getDate().getTime() : -1;
		int limitObs = dq.getMaxObservations() != null ? dq.getMaxObservations() : -1;
		int limitSeries =  dq.getMaxSeries() != null ?  dq.getMaxSeries() : -1;

		int dqd = -1;
		DATA_QUERY_DETAIL detail =  dq.getDataQueryDetail();
		if(detail != null) {
			dqd = detail.ordinal();
		}
		StringBuilder sb = new StringBuilder();
		sb.append("l"+lastUpdatedDate+"f"+firstNObs+"l"+lastNObs+"s"+dateFrom+"e"+dateTo+"lo"+limitObs+"ls"+limitSeries+"d"+dqd);

		for(ProvisionAgreementBean curentProv :  dq.getProvisionAgreements()) {
			sb.append("pv:"+curentProv.getShortURN());
		}
		if(dq.getExcludeAttributes().size() > 0) {
			sb.append("EXC_ATT:");
			for(String exclude : dq.getExcludeAttributes()) {
				sb.append(exclude+",");
			}
		}
		if(dq.getParameters().size() > 0) {
			sb.append("EP:");
			for(String param : dq.getParameters()) {
				sb.append(param+":"+dq.getParameter(param));
			}
		}
		return sb.toString();
	}

	private static class DataQuerySelectionComparator implements Comparator<DataQuerySelection> {

		@Override
		public int compare(DataQuerySelection o1, DataQuerySelection o2) {
			return o1.getComponentId().compareTo(o2.getComponentId());
		}

	}

}
