package io.sdmx.utils.sdmx.structure;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

/**
 * This class provides utility methods that can be performed on a MaintainableSuperBean
 */
public class SuperBeanRefUtil<T extends MaintainableSuperBean> {

	/**
	 * For a set of maintainables, this method will return the maintainable that has the same agencyId, Id and version as the reference bean.
	 * <p/>
	 * If the ref bean does not have a agency id, id and then it will result in an error.  If version information is missing, then the latest version
	 * will be assumed.
	 * <p/>
	 * This method will stop at the first match and return it, no checks are performed on the type of maintainables in the set.
	 * <p/>
	 * If no match is found null is returned.  
	 *  
	 * @param maintainables
	 * @param ref
	 * @return
	 */
	public static MaintainableSuperBean resolveReference(Collection<? extends MaintainableSuperBean> maintainables, IMaintainableRef ref) {
		if(ref == null) {
			throw new IllegalArgumentException("Ref is null");
		}
		if(!ref.hasAgencyId()) {
			throw new IllegalArgumentException("Ref is mising AgencyId");
		}
		if(!ref.hasMaintainableId()) {
			throw new IllegalArgumentException("Ref is mising Id");		
		}
		
		MaintainableSuperBean latestVersionSb = null;
		ISdmxVersion latestVersion = null;
			if(maintainables != null) {
			for(MaintainableSuperBean currentMaintainable : maintainables) {
				if(currentMaintainable.getAgencyId().equals(ref.getAgencyId())) {
					if(currentMaintainable.getId().equals(ref.getMaintainableId())) {
						ISdmxVersion maintVersion = currentMaintainable.getBuiltFrom().getVersion();
						if(ref.getVersion().isMatch(maintVersion)) {
							if(!ref.getVersion().isAbsolute()) {
								if(maintVersion == null || maintVersion.isLater(latestVersion)) {
									latestVersionSb = currentMaintainable;
									latestVersion = maintVersion;
								}
							} else {
								return currentMaintainable;
							}
						}
					}
				}
			}
		}
		return latestVersionSb;
	}
	
	public Set<T> resolveReferences(Collection<T> maintainables, IMaintainableRef ref) {
		Set<T> returnSet = new HashSet<>();
		
		if(ref == null) {
			ref = MaintainableRef.getInstance(null, null);
		}
		boolean hasAgencyFilter = ObjectUtil.validString(ref.getAgencyId());
		boolean hasIdFilter = ObjectUtil.validString(ref.getMaintainableId());
		
		String agencyId = ref.getAgencyId();
		String id = ref.getMaintainableId();
		IVersionRef version = ref.getVersion();
		
		if(maintainables != null) {
			for(T currentMaintainable : maintainables) {
				if(hasAgencyFilter && !agencyId.equals(currentMaintainable.getAgencyId())) {
					continue;
				}
				if(hasIdFilter && !id.equals(currentMaintainable.getId())) {
					continue;
				}
				if(!version.isMatch(currentMaintainable.getBuiltFrom().getVersion())) {
					continue;
				}
				returnSet.add(currentMaintainable);
			}
		}
		return returnSet;
	}
}
