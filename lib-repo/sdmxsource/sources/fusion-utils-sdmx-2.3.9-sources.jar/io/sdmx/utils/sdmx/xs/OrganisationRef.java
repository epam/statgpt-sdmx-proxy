package io.sdmx.utils.sdmx.xs;

import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.IOrganisationRef;
import io.sdmx.utils.core.collection.CollectionUtil;

public class OrganisationRef implements IOrganisationRef {
	private String agencyId;
	private Set<String> organisationIds;
	private SDMX_STRUCTURE_TYPE strctureType;
	
	
	public OrganisationRef(String agencyId, Set<String> organisationIds, SDMX_STRUCTURE_TYPE strctureType) {
		this.agencyId = agencyId;
		if(organisationIds == null || organisationIds.size() < 1) {
			throw new SdmxSemmanticException("requires at least 1 organisation id");
		}
		this.organisationIds = CollectionUtil.copyToImmutable(organisationIds);
		this.strctureType = strctureType;
	}
	
	/**
	 * @param orgId string identifying the org. The syntax is agency id, org id, separated by a ",". 
			For example: AGENCY_ID,PROVIDER_ID. In case the string only contains one out of these 2 elements, it is considered to be the provider id, i.e. all,PROVIDER_ID
			The OR operator is supported using the + character. 
			For example, the following value can be used to indicate that the metadataset should be provided 
			by the Swiss National Bank (CH2) or Central Bank of Norway (NO2): CH2+NO2.
	 * @param type
	 * @return
	 */
	public static OrganisationRef fromString(String orgId, SDMX_STRUCTURE_TYPE type) {
		String[] orgAgencySplit = orgId.split(",", 2);
		String orgAgency = orgAgencySplit.length == 1 ? null : orgAgencySplit[0];
		orgId = orgAgencySplit.length == 1 ? orgId : orgAgencySplit[1];
		String[] orgIdSplit = orgId.split("\\+");
		return new OrganisationRef(orgAgency, CollectionUtil.arrayToSet(orgIdSplit), type);
		
	}

	@Override
	public String getAgencyId() {
		return this.agencyId;
	}

	@Override
	public Set<String> getOrganisationIds() {
		return this.organisationIds;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getOrganisationType() {
		return this.strctureType;
	}
}
