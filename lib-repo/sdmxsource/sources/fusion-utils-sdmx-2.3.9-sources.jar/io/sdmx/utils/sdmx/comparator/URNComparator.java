package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;

public class URNComparator implements Comparator<IURNAbsolute<?>> {
	public static final URNComparator INSTANCE = new URNComparator();

	private URNComparator() {}

	@Override
	public int compare(IURNAbsolute<?> ref1, IURNAbsolute<?> ref2) {
		int comp =  0;
		if(ref1.getStructureType() != ref2.getStructureType()) {
			comp = ref1.getStructureType().getUrnPackage().compareTo(ref2.getStructureType().getUrnPackage());
			if(comp != 0) {
				return comp;
			}
			comp = ref1.getStructureType().getUrnClass().compareTo(ref2.getStructureType().getUrnClass());
		}
		if(comp != 0) {
			return comp;
		}

		String agencyId1 = ref1.getAgencyId();
		String agencyId2 = ref2.getAgencyId();
		comp = agencyId1.compareTo(agencyId2);
		if(comp != 0) {
			return comp;
		}

		String id1 = ref1.getMaintainableId();
		String id2 = ref2.getMaintainableId();
		comp = id1.compareTo(id2);
		if(comp != 0) {
			return comp;
		}

		ISdmxVersion v1 = ref1.getAbsoluteVersion();
		ISdmxVersion v2 = ref2.getAbsoluteVersion();

		//TODO what about URN with absolute version vs URN with version ref
		comp = v2.isLater(v1) ? -1 : 1;

		if(ref1.getIdentifiableId() != null) {
			if(ref2.getIdentifiableId() == null) {
				return 1;
			}
			String[] identId1 = ref1.getFullIdentifiableId().split("\\.");
			String[] identId2 = ref2.getFullIdentifiableId().split("\\.");

			for(int i = 0; i < Math.max(identId1.length, identId2.length); i++) {
				String i1 = identId1[i];
				String i2 = identId2[i];
				comp = i1.compareTo(i2);
				if(comp != 0) {
					return comp;
				}
			}
		}
		return ref1.getURN().compareTo(ref2.getURN());
	}



}
