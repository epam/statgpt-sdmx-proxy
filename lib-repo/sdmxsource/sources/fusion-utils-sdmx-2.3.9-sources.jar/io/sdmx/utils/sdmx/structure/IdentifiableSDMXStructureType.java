package io.sdmx.utils.sdmx.structure;

import java.io.ObjectStreamException;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.sdmx.model.IIdentifiableStructureType;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class IdentifiableSDMXStructureType<K extends MaintainableBean, V extends IdentifiableBean> extends AbstractStructureType<K, V> implements IIdentifiableStructureType<K, V> {
	private static final long serialVersionUID = 1L;
	
	public static final IdentifiableSDMXStructureType<?,?> ANY = new IdentifiableSDMXStructureType<>(MaintainableSDMXStructureType.ANY, IdentifiableBean.class,
			"Any", null, null, "Any", true);
	
	private IMaintainableStructureType<K> maintainableStructureType;
	private Class<V> classType;
	private boolean isAbtract;
	
	public static <K extends MaintainableBean, V extends IdentifiableBean> IdentifiableSDMXStructureType<K, V> getInstance(
			IMaintainableStructureType<K> maintainableStructureType,
			Class<V> identType,
			String urnClass) {
		return getInstance(maintainableStructureType, identType, urnClass, urnClass);  //URN class is the same as the string
	}
	
	public static <K extends MaintainableBean, V extends IdentifiableBean> IdentifiableSDMXStructureType<K, V> getAbstractInstance(
			IMaintainableStructureType<K> maintainableStructureType,
			Class<V> identType,
			String urnClass,
			String asString) {
		return new IdentifiableSDMXStructureType<K, V>(maintainableStructureType, identType, urnClass, null, null, asString, true);
	}
	
	public static <K extends MaintainableBean, V extends IdentifiableBean> IdentifiableSDMXStructureType<K, V> getInstance(
			IMaintainableStructureType<K> maintainableStructureType,
			Class<V> identType,
			String urnClass,
			String asString) {
		return new IdentifiableSDMXStructureType<K, V>(maintainableStructureType, identType, urnClass, null, null, asString, false);
	}

	private IdentifiableSDMXStructureType(IMaintainableStructureType<K> maintainableStructureType,
			Class<V> classType,
			String urnClass,
			String fixedId, String fixedVersion,
			String asString, boolean isAbstract) {
		super(URN_INFOMODEL_PREFIX, urnClass, maintainableStructureType.getUrnPackage(), fixedId, fixedVersion, asString);
		this.classType = classType;
		this.maintainableStructureType = maintainableStructureType;
		this.isAbtract = isAbstract;
	}
	
	@Override
    public String getFixedId() {
        return getMaintainableStructureType().getFixedId();
    }

    @Override
    public String getFixedVersion() {
        return getMaintainableStructureType().getFixedVersion();
    }
	
	@Override
	public boolean isAbstract() {
		return isAbtract;
	}

	@Override
	public boolean isAny() {
		return this == ANY;
	}
	
	@Override
	public IMaintainableStructureType<K> getMaintainableStructureType() {
		return maintainableStructureType;
	}

	@Override
	public Class<V> getClassType() {
		return classType;
	}
	
	@Override
    protected HashCodeBuilder getHashCodeBuilder() {
		HashCodeBuilder builder = super.getHashCodeBuilder();
		builder.append(this.classType.getCanonicalName());
		return builder;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof IIdentifiableStructureType) {
			ISDMXStructureType that = (ISDMXStructureType) obj;
			return super.equals(this) && this.classType == that.getClassType();
		}
		return false;
	}
	
	 /**
     * Deserialisation behaviour
     * @return
     * @throws ObjectStreamException
     */
    private Object readResolve() throws ObjectStreamException {
        // Return the canonical instance instead of this newly deserialized one
        ISDMXStructureType type = StructureTypes.getAnyStructureType(this.getClassType());
        if(type != null && type instanceof IIdentifiableStructureType) {
            return type;
        }
        return this;
    }

}
