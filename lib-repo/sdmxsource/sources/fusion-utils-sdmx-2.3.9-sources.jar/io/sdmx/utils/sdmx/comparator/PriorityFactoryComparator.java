package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.factory.PriorityFactory;

public class PriorityFactoryComparator implements Comparator<PriorityFactory> {
	public static final PriorityFactoryComparator INSTANCE = new PriorityFactoryComparator();
	private PriorityFactoryComparator() {}

	
	@Override
	public int compare(PriorityFactory o1, PriorityFactory o2) {
		if(o1 == o2) {
			return 0;
		}
		int priority = o2.getPriority() - o1.getPriority();  //The higer the number the more priority
		if(priority == 0) {
			//If they share the same priority, there still has to be a winner otherwise
			//a set will not work.  The comparison should be on the class name
			String clasName1 = o1.getClass().getCanonicalName();
			String clasName2 = o2.getClass().getCanonicalName();
			return clasName1.compareTo(clasName2);
		}
		return priority;
	}
}
