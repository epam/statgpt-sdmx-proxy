package io.sdmx.utils.sdmx.json;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import org.codehaus.jettison.json.JSONObject;

public class SDMXJSONUtil {


	/**
	 * Unpacks StructureReferenceBeans of the same type from an array of urns property of a JsonObject
	 * @param json - the JSON object to unpack the property from 
	 * @param property - the property of the JSON object which contains the URN string
	 * @param st - expected structure type to be defined by the URN, or null to indicate any
	 * @param allowNulls - if true then null can be returned, if false then a {@link SdmxSemmanticException} will be thrown in the property is missing or empty
	 * @return
	 */
	public static Set<StructureReferenceBean> unpackStructureReferenceSet(JSONObject json, String property, SDMX_STRUCTURE_TYPE st, boolean allowNulls) {
		Set<StructureReferenceBean> returnset = new HashSet<>();
		Set<String> urns = JsonObjectUtil.unpackStringSet(json, property, allowNulls);
		if(urns != null) {
			for(String urn : urns) {
				returnset.add(new StructureReferenceBeanImpl(urn, st));
			}
		}
		return returnset;
	}
	/**
	 * Unpacks a StructureReferenceBean from a urn string property of a JsonObject
	 * @param json - the JSON object to unpack the property from 
	 * @param property - the property of the JSON object which contains the URN string
	 * @param st - expected structure type to be defined by the URN, or null to indicate any
	 * @param allowNulls - if true then null can be returned, if false then a {@link SdmxSemmanticException} will be thrown in the property is missing or empty
	 * @return
	 */
	public static StructureReferenceBean unpackStructureReference(JSONObject json, String property, SDMX_STRUCTURE_TYPE st, boolean allowNulls) {
		String urn = JsonObjectUtil.getString(json, property, allowNulls);
		if(urn == null) {
			return null;
		}
		StructureReferenceBean sRef;
		try {
			sRef = new StructureReferenceBeanImpl(urn);
		} catch (Throwable e) {
			throw new SdmxSemmanticException("JSON property '"+property+"' illegal URN  '"+urn+"'");
		}
		if(st != null) {
			if(sRef.getTargetReference() != st) {
				throw new SdmxSemmanticException("JSON property '"+property+"' URN expected to reference "+st.getType()+" but was '"+sRef.getTargetReference().getType()+"'");
			}
		}
		return sRef;
	}
	
}
