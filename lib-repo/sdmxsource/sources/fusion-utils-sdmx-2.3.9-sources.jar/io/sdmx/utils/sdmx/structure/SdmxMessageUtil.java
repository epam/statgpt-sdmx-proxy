package io.sdmx.utils.sdmx.structure;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxInternalServerException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxResponseTooLargeException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxServiceUnavailableException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.QUERY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.REGISTRY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.exception.ParseException;
import io.sdmx.api.sdmx.exception.SdmxResponseSizeExceedsLimitException;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.MutlipleReadableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.xml.StaxReader;

public class SdmxMessageUtil {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMessageUtil.class);
	
	private static boolean isJsonError(ReadableDataLocation dataLocation) {
		try {
			byte[] jsonByteArray = StreamUtil.toByteArray(dataLocation.getInputStream());
			JSONObject response = new JSONObject(new String(jsonByteArray));
			return response.has("errors");
		} catch (Exception e) {
			return false;
		}
	}

	public static void parseSdmxErrorMessage(ReadableDataLocation dataLocation) {
		if(LOG.isDebugEnabled()) {
			LOG.debug(new String(StreamUtil.getFirstXBytes(dataLocation.getInputStream(), 2048)));
		}
		
		FILE_FORMAT format = dataLocation.getFormat();
		
		if(format == FILE_FORMAT.JSON) {
			if(!isJsonError(dataLocation)) {
				return;
			}
			try {
				try(ByteArrayOutputStream bos = new ByteArrayOutputStream();){
					StreamUtil.copyStream(dataLocation.getInputStream(), bos);
					JSONObject response = new JSONObject(new String(bos.toByteArray()));
					if(response.has("errors")) {
						String errorMsg = response.getString("errors");
						SDMX_ERROR_CODE errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
						JSONArray jsonArray = response.getJSONArray("errors");
						JSONObject object = jsonArray.getJSONObject(0);
						if(jsonArray.length() == 1) {
						    if(object.has("message")) {
						        errorMsg = object.getString("message");
						    }
						}
						String code = null;
						try {
							code = object.getString("code");
						}catch (JSONException e) {}
						if(code != null) {
							Integer codeint = Integer.parseInt(code);
							if(codeint == 200) {
								//Bizarrely OECD.STAT returns Error messages to indicate success,
								//If the status is a 200 then it's an Error to say everything worked :-)
								return;
							}
							errorCode = SDMX_ERROR_CODE.parseClientCode(codeint);
							if(errorCode == null) {
	                            //in case the http code was used
	                            errorCode = SDMX_ERROR_CODE.parseHttpCode(codeint);
	                        }
						}
						parseErrors(errorMsg, errorCode);
					}
				}
			} catch (JSONException | IOException e) {
				throw new RuntimeException(e);
			}
		} else if(format == FILE_FORMAT.XML) {
			StaxReader staxReader = new StaxReader(dataLocation);
			String code = null;
			SDMX_ERROR_CODE errorCode = null;
			try {
				while(staxReader.moveNextStartNode()) {
					String nodeName = staxReader.getElementName();
					if(nodeName.equals("ErrorMessage")) {
						code = staxReader.getAttributeValue(null, "code");
						Integer codeint = Integer.parseInt(code);
						if(codeint == 200) {
							//Bizarrely OECD.STAT returns Error messages to indicate success,
							//If the status is a 200 then it's an Error to say everything worked :-)
							return;
						}
						errorCode = SDMX_ERROR_CODE.parseClientCode(codeint);
						if(errorCode == null) {
						    //in case the http code was used
						    errorCode = SDMX_ERROR_CODE.parseHttpCode(codeint);
						}
					} else if(nodeName.equals("Text")) {
						if(errorCode == null) {
							errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
						}
						parseErrors(staxReader.getElementText(), errorCode);
						/*switch(errorCode) {
					case NO_RESULTS_FOUND :	throw new SdmxNoResultsException(staxReader.getElementText());
					case NOT_IMPLEMENTED :	throw new SdmxNotImplementedException(staxReader.getElementText());
					case SEMANTIC_ERROR :	throw new SdmxSemmanticException(staxReader.getElementText());
					case UNAUTHORISED :	throw new SdmxUnauthorisedException(staxReader.getElementText());
					case SERVICE_UNAVAILABLE :	throw new SdmxServiceUnavailableException(staxReader.getElementText());
					case SYNTAX_ERROR :	throw new SdmxSyntaxException(staxReader.getElementText());
					case RESPONSE_SIZE_EXCEEDS_SERVICE_LIMIT :	throw new SdmxResponseSizeExceedsLimitException(staxReader.getElementText());
					case RESPONSE_TOO_LARGE :	throw new SdmxResponseTooLargeException(staxReader.getElementText());
					case INTERNAL_SERVER_ERROR :	throw new SdmxInternalServerException(staxReader.getElementText());
					default : throw new SdmxException(staxReader.getElementText(), errorCode);
						}*/
					}
				}
			} finally {
				staxReader.close();
			}
		}
		throw new SdmxException("Can not process format: "+format);
	}

	private static void parseErrors(String errorMsg, SDMX_ERROR_CODE errorCode) {
		if(errorCode == null) {
			throw new SdmxException(errorMsg);
		}
		switch(errorCode) {
		case NO_RESULTS_FOUND :	throw new SdmxNoResultsException(errorMsg);
		case NOT_IMPLEMENTED :	throw new SdmxNotImplementedException(errorMsg);
		case SEMANTIC_ERROR :	throw new SdmxSemmanticException(errorMsg);
		case UNAUTHORISED :	throw new SdmxUnauthorisedException(errorMsg);
		case SERVICE_UNAVAILABLE :	throw new SdmxServiceUnavailableException(errorMsg);
		case SYNTAX_ERROR :	throw new SdmxSyntaxException(errorMsg);
		case RESPONSE_SIZE_EXCEEDS_SERVICE_LIMIT :	throw new SdmxResponseSizeExceedsLimitException(errorMsg);
		case RESPONSE_TOO_LARGE :	throw new SdmxResponseTooLargeException(errorMsg);
		case INTERNAL_SERVER_ERROR :	throw new SdmxInternalServerException(errorMsg);
		default : throw new SdmxException(errorMsg, errorCode);
		}
	}

	/**
	 * Returns the version of the schema that the document stored at this URI points to.
	 * <br/>
	 * The URI is inferred by the namespaces declared in the root element of the document.
	 * <br/>
	 * This will throw an error if there is no way of determining the schema version
	 * @param uri
	 * @return
	 */
	public static SDMX_SCHEMA getSchemaVersion(ReadableDataLocation sourceData) throws ParseException {
		FILE_FORMAT format = sourceData.getFormat();
		if(format == FILE_FORMAT.EDI) {
			return SDMX_SCHEMA.EDI;
		}
		if(format == FILE_FORMAT.JSON) {
			return SDMX_SCHEMA.JSON;
		}
		if(format != FILE_FORMAT.XML) {
			throw new SdmxSyntaxException(ExceptionCode.XML_PARSE_EXCEPTION, "No root node found");
		}
		InputStream stream = sourceData.getInputStream();
		try {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
			XMLStreamReader parser = factory.createXMLStreamReader(stream);
			while (parser.hasNext()) {
				int event = parser.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					for(int i = 0 ; i < parser.getNamespaceCount(); i ++) {
						String ns = parser.getNamespaceURI(i);
						if(SdmxConstants.getNamespacesV1().contains(ns)) {
							return SDMX_SCHEMA.VERSION_ONE;
						}
						if(SdmxConstants.getNamespacesV2().contains(ns)) {
							return SDMX_SCHEMA.VERSION_TWO;
						}
						if(SdmxConstants.getNamespacesV2_1().contains(ns)) {
							return SDMX_SCHEMA.VERSION_TWO_POINT_ONE;
						}
						if(SdmxConstants.getNamespacesV3().contains(ns)) {
							return SDMX_SCHEMA.VERSION_THREE;
						}
					}
					throw new SdmxSyntaxException("Can not get Scheme Version from SDMX message.  Unable to determine structure type from Namespaces- please ensure this is a valid SDMX document");
				}
			}
			throw new SdmxSyntaxException(ExceptionCode.XML_PARSE_EXCEPTION, "No root node found");
		} catch(XMLStreamException e) {
			throw new SdmxSyntaxException(ExceptionCode.XML_PARSE_EXCEPTION, e);
		} finally {
			StreamUtil.closeStream(stream);
		}
	}

	/**
	 * Returns MESSAGE_TYPE for the URI.  This is determined from the root node.
	 *
	 * @param uri
	 * @return MESSAGE_TYPE
	 */
	public static MESSAGE_TYPE getMessageType(ReadableDataLocation sourceData) {
		if (ZipUtil.isAZip(sourceData)) {
			if (sourceData instanceof MutlipleReadableDataLocation) {
				MutlipleReadableDataLocation x = (MutlipleReadableDataLocation)sourceData;
				MESSAGE_TYPE prevMessageType = null;
				if (x.getItems().size() == 0) {
					throw new IllegalArgumentException("Unable to determine message type from Zip file, since it has no entries");
				}
				for (ReadableDataLocation anRDL: x.getItems()) {
					MESSAGE_TYPE messageType = getMessageType(anRDL);
					if (prevMessageType == null) {
						prevMessageType = messageType;
					} else {
						if (!prevMessageType.equals(messageType)) {
							throw new IllegalArgumentException("Unable to process Zip file, since it contains messages of mixed types.");
						}
					}
				}
				return prevMessageType;
			}
		}
		FILE_FORMAT format = sourceData.getFormat();
		switch(format) {
		case CSV:
			break;
		case EDI:
			return MESSAGE_TYPE.SDMX_EDI;
		case HTML:
			break;
		case JSON:
			if(isJsonError(sourceData)) {
				return MESSAGE_TYPE.ERROR;
			}
			break;
		case TEXT:
			break;
		case XLSX:
			break;
		case XML:
			StaxReader staxReader = new StaxReader(sourceData);
			try {
				while(staxReader.moveNextStartNode()) {
					String rootNode = staxReader.getElementName();
					try {
						return MESSAGE_TYPE.parseString(rootNode);
					} catch(Throwable th) {
						throw new SdmxSyntaxException(th, ExceptionCode.PARSE_ERROR_NOT_SDMX);
					}
				}
			} finally {
				staxReader.close();
			}
			break;
		case ZIP:
			break;
		default:
		}
		return null;
	}

	/**
	 * Returns the registry message type - this will ony work if the XML at the
	 * URI is a RegistryInterface message.
	 *
	 * The registry message type may be one of the following:
	 * <ul>
	 *  <li>SUBMIT STRUCTURE REQUEST</li>
	 *	<li>SUBMIT PROVISION REQUEST</li>
	 *	<li>SUBMIT REGISTRATION REQUEST</li>
	 *	<li>SUBMIT SUBSCRIPTION REQUEST</li>
	 *	<li>QUERY STRUCTURE REQUEST</li>
	 *	<li>QUERY PROVISION REQUEST</li>
	 *	<li>QUERY REGISTRATION REQUEST</li>
	 *	<li>SUBMIT STRUCTURE RESPONSE</li>
	 *	<li>SUBMIT PROVISION RESPONSE</li>
	 *	<li>SUBMIT REGISTRATION RESPONSE</li>
	 *	<li>QUERY STRUCTURE RESPONSE</li>
	 *	<li>QUERY PROVISION RESPONSE</li>
	 *	<li>QUERY REGISTRATION RESPONSE</li>
	 *	<li>SUBMIT SUBSCRIPTION RESPONSE</li>
	 *	<li>NOTIFY REGISTRY EVENT</li>
	 * </ul>
	 * @param uri
	 * @return
	 */
	public static REGISTRY_MESSAGE_TYPE getRegistryMessageType(ReadableDataLocation sourceData) {

		StaxReader staxReader = new StaxReader(sourceData);
		try {
			boolean skippedHeader = staxReader.skipToEndNode("Header");
			if(!skippedHeader) {
				throw new IllegalArgumentException("Header not found");
			}
			if(staxReader.moveNextStartNode()) {
				String rootNode = staxReader.getElementName();
				return REGISTRY_MESSAGE_TYPE.getMessageType(rootNode);
			}
			throw new IllegalArgumentException("No nodes found after header");
		} finally {
			staxReader.close();
		}
	}

	/**
	 * Determines the query message types for an input SDMX-ML query message
	 * @param sourceData
	 * @return for v2.1 it will be always one query message due to schema constraints.
	 */
	public static List<QUERY_MESSAGE_TYPE> getQueryMessageTypes(ReadableDataLocation sourceData) {
		MESSAGE_TYPE messageType = getMessageType(sourceData);
		if(messageType == null) {
			throw new IllegalArgumentException("Can not determine message type");
		}
		if(messageType != MESSAGE_TYPE.QUERY) {
			throw new IllegalArgumentException("Can not determine query type, as message is of type : " + messageType.toString());
		}
		List<QUERY_MESSAGE_TYPE> returnList = new ArrayList<>();

		StaxReader staxReader = new StaxReader(sourceData);
		try {
			if(!staxReader.moveNextStartNode()) {
				throw new IllegalArgumentException("Could not get root start element!");
			}
			String rootNode = staxReader.getElementName();

			if (rootNode.equals(QUERY_MESSAGE_TYPE.GENERIC_DATA_QUERY.getNodeName()) || rootNode.equals(QUERY_MESSAGE_TYPE.STRUCTURE_SPECIFIC_DATA_QUERY.getNodeName()) ||
					rootNode.equals(QUERY_MESSAGE_TYPE.GENERIC_TIME_SERIES_DATA_QUERY.getNodeName()) || rootNode.equals(QUERY_MESSAGE_TYPE.STRUCTURE_SPECIFIC_TIME_SERIES_DATA_QUERY.getNodeName())
					|| rootNode.equals(QUERY_MESSAGE_TYPE.GENERIC_METADATA_QUERY.getNodeName()) || rootNode.equals(QUERY_MESSAGE_TYPE.STRUCTURE_SPECIFIC_METADATA_QUERY.getNodeName())) { // don't like but checking with parsingString exception is worse. May be boolean isQueryMessageType() in enum

				returnList.add(QUERY_MESSAGE_TYPE.parseString(rootNode));
				return returnList;
			}
			staxReader.skipToNode("Query");
			while(staxReader.moveNextNode()) {
				String nodeName = staxReader.getElementName();
				if(staxReader.isStartElement()) {
					if (nodeName.equals("ReturnDetails")) { //Skip details of 2.1 queries
						staxReader.skipToEndNode("ReturnDetails");
					} else {
						returnList.add(QUERY_MESSAGE_TYPE.parseString(nodeName));
						staxReader.skipToEndNode(nodeName);
					}
				} else if(nodeName.equals("Query")) {
					break;
				}
			}
		} finally {
			staxReader.close();
		}
		return returnList;
	}

	/**
	 * Retruns the dataset action
	 * @param uri
	 * @return
	 */
	public static DATASET_ACTION getDataSetAction(ReadableDataLocation sourceData) {
		//		if(!XmlUtil.isXML(uri)) {
		//			throw new ParseException(ExceptionCode.PARSE_ERROR_NOT_XML);
		//		}
		MESSAGE_TYPE message = getMessageType(sourceData);
		boolean continueToSubmitStructureRequest = false;
		if(message == MESSAGE_TYPE.REGISTRY_INTERFACE) {
			REGISTRY_MESSAGE_TYPE registryMessageType = getRegistryMessageType(sourceData);
			if(registryMessageType == REGISTRY_MESSAGE_TYPE.SUBMIT_STRUCTURE_REQUEST) {
				continueToSubmitStructureRequest = true;
			}
		}

		try ( InputStream stream = sourceData.getInputStream() ) {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
			XMLStreamReader parser = factory.createXMLStreamReader(stream);
			String currentNode = null;
			while (parser.hasNext()) {
				int event = parser.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					currentNode = parser.getLocalName();
					if(currentNode.equals("DataSetAction")) {
						String action = parser.getElementText();
						if(action.equals("Append") || action.equals("Update")) {
							return DATASET_ACTION.APPEND;
						}
						if(action.equals("Replace")) {
							return DATASET_ACTION.REPLACE;
						}
						if(action.equals("Delete")) {
							return DATASET_ACTION.DELETE;
						}
						if(action.equals("Information")) {
							return DATASET_ACTION.INFORMATION;
						}
					}
					if(currentNode.equals("SubmitStructureRequest")) {
						String action = parser.getAttributeValue(null, "action");
						if(action != null) {
							return DATASET_ACTION.getAction(action);
						}
						return DATASET_ACTION.APPEND;
					}
				} else if (event == XMLStreamConstants.END_ELEMENT) {
					currentNode = parser.getLocalName();
					if(currentNode.equals("Header")) {
						if(!continueToSubmitStructureRequest) {
							return DATASET_ACTION.INFORMATION;
						}
					}
				}
			}
			return DATASET_ACTION.APPEND;
		} catch (Exception th) {
			throw new RuntimeException(th);
		}
	}
}
