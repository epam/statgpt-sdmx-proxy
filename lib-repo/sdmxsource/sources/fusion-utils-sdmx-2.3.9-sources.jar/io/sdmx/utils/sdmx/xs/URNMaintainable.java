package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

public class URNMaintainable extends URNAbsolute implements IURNMaintainable {
	private static final long serialVersionUID = 1L;

	private IMaintainableStructureType maintainableStructureType;
	
	/**
	 * Package protected, constructed via the URN.getInstance method
	 */
	URNMaintainable(IMaintainableStructureType structureType, IMaintainableRef ref, String identifiableId, String urn) {
		super(structureType, ref, identifiableId, urn);
		this.maintainableStructureType = structureType;
	}
	
	/**
	 * @return not null - the definition for the type of structure this is
	 */
	@Override
	public IMaintainableStructureType getStructureType() {
		return maintainableStructureType;
	}

	@Override
	public IURNAbsolute toIdentifiable(Class identifiable, String... identifableIds) {
		URNBuilder builder = URN.builder(this.getAgencyId(), this.getMaintainableId(), this.getVersion().toString(), identifableIds);
		
		return builder.buildAbsolute(identifiable);
	}
	
	
}
