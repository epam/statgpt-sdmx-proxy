package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class MaintainableSortByIdentifiers implements Comparator<MaintainableBean> {
	public static final MaintainableSortByIdentifiers INSTANCE = new MaintainableSortByIdentifiers();

	private MaintainableSortByIdentifiers() {}
	
	@Override
	public int compare(MaintainableBean maintOne, MaintainableBean maintTwo) {
		if(maintOne.equals(maintTwo)) {
			return 0;
		}
		
		int comp = maintOne.getStructureType().getType().compareTo(maintTwo.getStructureType().getType());
		if(comp != 0) {
			return comp;
		}
		
		String agencyId1 = maintOne.getAgencyId();
		String agencyId2 = maintTwo.getAgencyId();
		comp = agencyId1.compareTo(agencyId2);
		if(comp != 0) {
			return comp;
		}
		
		String id1 = maintOne.getId();
		String id2 = maintTwo.getId();
		comp = id1.compareTo(id2);
		if(comp != 0) {
			return comp;
		}
		
		ISdmxVersion v1 = maintOne.getVersion();
		ISdmxVersion v2 = maintTwo.getVersion();
		if(v1.equals(v2)) {
			//SHOULD NEVER HAPPEN
			return -1;
		}
		return v2.isLater(v1) ? -1 : 1;	
	}
}
