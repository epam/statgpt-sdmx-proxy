package io.sdmx.utils.sdmx.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.process.IProcessWithArgument;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_URN;
import io.sdmx.api.sdmx.model.IIdentifiableStructureType;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.CrossSectionalMeasureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.ITimeDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationTableBean;
import io.sdmx.api.sdmx.model.beans.publicationtable.PublicationVariableBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlCodelistMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlConceptMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.utils.core.collection.CollectionUtil;

@SuppressWarnings({"unchecked", "rawtypes"})
public class StructureTypes {
    private static final Logger LOG = LoggerFactory.getLogger(StructureTypes.class);
	private static boolean init = false;
	private static final Map<Class<? extends IdentifiableBean>, ISDMXStructureType> identTypes = new HashMap<>();
	private static final Map<Class<? extends MaintainableBean>, IMaintainableStructureType> maintTypes = new HashMap<>();
	private static final Map<IMaintainableStructureType, List<IMaintainableStructureType>> concreteTypes = new HashMap<>();
	private static final Map<String, ISDMXStructureType> typesByPackageAndClass = new HashMap<>();
	private static final Map<String, IMaintainableStructureType> typesByRESTResource = new HashMap<>();
	
	private static final String SDMX_PACKAGE_BASE = "base";
	private static final String SDMX_PACKAGE_CODELIST = "codelist";
	private static final String SDMX_PACKAGE_CATEGORY_SCHEME = "categoryscheme";
	private static final String SDMX_PACKAGE_CONCEPT_SCHEME = "conceptscheme";
	private static final String SDMX_PACKAGE_TRANSFORMATION = "transformation";
	private static final String SDMX_PACKAGE_DSD = "datastructure";
	private static final String SDMX_PACKAGE_MSD = "metadatastructure";
	private static final String SDMX_PACKAGE_REGISTRY = "registry";
	private static final String SDMX_PACKAGE_PROCESS = "process";
	private static final String SDMX_PACKAGE_MAPPING = "structuremapping";
	

	static {
		registerType(MaintainableSDMXStructureType.ANY, "*");
		registerType(IdentifiableSDMXStructureType.ANY);
	}

	public static IMaintainableStructureType<?> getSdmxMaintinableType(SDMX_STRUCTURE_TYPE st) {
		registerCoreTypes();
		return getMaintStructureType(st.getMaintainableInterface());
	}


	/**
	 * Returns the type by the properties to uniquely identify the object
	 * @param prefix not null example urn:sdmx:org.sdmx.infomodel.
	 * @param packageName not null example codelist
	 * @param className not null example Codelist
	 * @return the ISDMXStructureType registeredAgainst the package and class
	 */
	public static ISDMXStructureType getStructureType(String prefix, String packageName, String className) {
		registerCoreTypes();
		String objectKey = getObjectKey(prefix, packageName, className);
		ISDMXStructureType returnType = typesByPackageAndClass.get(getObjectKey(prefix, packageName, className));
		if(returnType == null) {
			//Try case insensitive
			objectKey = objectKey.toLowerCase();
			for(String key : typesByPackageAndClass.keySet()) {
				if(key.toLowerCase().equals(objectKey)) {
					return typesByPackageAndClass.get(key);
				}
			}
			throw new IllegalArgumentException("SDMX type not found by prefix '"+prefix+"', package '"+packageName+"', and class '"+className+"'");
		}
		return returnType;
	}

	/**
	 * Returns the SDMX identifiable type by class and prefix, package is set to the SDMX URN prefix of 'urn:sdmx:org.sdmx.infomodel'
	 * @param packageName
	 * @param className
	 * @return the ISDMXStructureType registeredAgainst the package and class
	 */
	public static ISDMXStructureType getStructureType(String packageName, String className) {
		registerCoreTypes();
		ISDMXStructureType returnType = typesByPackageAndClass.get(getObjectKey(SDMX_URN.SDMX_NAMESPACE, packageName, className));
		if(returnType == null) {
			throw new IllegalArgumentException("SDMX type not found by package '"+packageName+"' and class '"+className+"'");
		}
		return returnType;
	}

	public static ISDMXStructureType getSdmxIdentifiableType(SDMX_STRUCTURE_TYPE st) {
		registerCoreTypes();
		if(st == null) {
			return MaintainableSDMXStructureType.ANY;
		}
		return getAnyStructureType(st.getIdentifiableInterface());
	}
	
	/**
	 * Register all the SDMX, extended, and Abstract types
	 */
	public static void registerCoreTypes() {
		if(init) return;
		
		init = true;  //set true here to prevent stack overflow

		registerBasePackage();
		registerCodelistPackage();
		registerCategoryPackage();
		registerConceptSchemePackage();
		registerVTLPackage();
		registerNonSDMXPackage();
		registerDataStructurePackage();
		registerMetadataStructurePackage();
		registerMappingPackage();
		registerProcessPackage();
		registerRegistryPackage();
		registerAbstractTypes();
		registerDeprecatedTypes();
	}
	
	public static void registerDeprecatedTypes()  {
		typesByPackageAndClass.put(getObjectKey(MaintainableSDMXStructureType.URN_INFOMODEL_PREFIX, "registry", "ContentConstraint"), StructureTypes.getAnyStructureType(ContentConstraintBean.class));
		typesByPackageAndClass.put(getObjectKey(MaintainableSDMXStructureType.URN_INFOMODEL_PREFIX, "valuelist", "ValueList"), StructureTypes.getAnyStructureType(ValueListBean.class));
	}
	

	private static IMaintainableStructureType registerType(Class<? extends MaintainableBean> claz, SDMX_STRUCTURE_TYPE st) {
		return registerType(MaintainableSDMXStructureType.getInstance(claz, st.getUrnPackage(),
				st.getUrnClass(),
				st.getFixedId(),
				st.getFixedId() != null ? MaintainableBean.DEFAULT_VERSION : null,
						st.getType()) ,
				st.getUrnClass().toLowerCase());
	}

	private static void registerType(IMaintainableStructureType maintType, Class<? extends IdentifiableBean> claz, SDMX_STRUCTURE_TYPE st) {
		registerType(IdentifiableSDMXStructureType.getInstance(maintType, claz,  st.getUrnClass(), st.getType()));
	}

	public static List<ISDMXStructureType> getChildTypes(IMaintainableStructureType maintType) {
		List<ISDMXStructureType> returnList = new ArrayList<>();
		List<ISDMXStructureType> allTypes = new ArrayList<>(identTypes.size() + maintTypes.size());
		allTypes.addAll(identTypes.values());
		allTypes.addAll(getAbstractMaintStructureTypes(maintType));

		allTypes.forEach(v-> {
			if(v.getMaintainableStructureType() == maintType || (v.isAbstract() && v.getClassType().isAssignableFrom(maintType.getClassType()))) {
				returnList.add(v);
			}
		});
		return returnList;
	}

	/**
	 * @param resourceId
	 */
	public static IMaintainableStructureType byRESTResource(String resourceId) {
		return typesByRESTResource.get(resourceId);
	}

	private static void registerBasePackage() {
		//Agency Scheme
		registerType(MaintainableSDMXStructureType.getInstance(AgencySchemeBean.class, SDMX_PACKAGE_BASE, "AgencyScheme", AgencySchemeBean.FIXED_ID, AgencySchemeBean.FIXED_VERSION, "Agency Scheme"), "agencyscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, AgencyBean.class, "Agency", "Agency"));
		});
		
		//Data Consumer Scheme
		registerType(MaintainableSDMXStructureType.getInstance(DataConsumerSchemeBean.class, SDMX_PACKAGE_BASE, "DataConsumerScheme", DataConsumerSchemeBean.FIXED_ID, DataConsumerSchemeBean.FIXED_VERSION, "Data Consumer Scheme"), "dataconsumerscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, DataConsumerBean.class, "DataConsumer", "Data Consumer"));
		});

		//Data Provider Scheme
		registerType(MaintainableSDMXStructureType.getInstance(DataProviderSchemeBean.class, SDMX_PACKAGE_BASE, "DataProviderScheme", DataProviderSchemeBean.FIXED_ID, DataProviderSchemeBean.FIXED_VERSION,  "Data Provider Scheme"), "dataproviderscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, DataProviderBean.class, "DataProvider", "Data Provider"));
		});

		//Data Consumer Scheme
		registerType(MaintainableSDMXStructureType.getInstance(IMetadataProviderSchemeBean.class, SDMX_PACKAGE_BASE, "MetadataProviderScheme", IMetadataProviderSchemeBean.FIXED_ID, IMetadataProviderSchemeBean.FIXED_VERSION, "Metadata Provider Scheme"), "metadataproviderscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IMetadataProviderBean.class, "MetadataProvider", "Metadata Provider"));
		});
		
		//Organisation Unit Scheme
		registerType(MaintainableSDMXStructureType.getInstance(OrganisationUnitSchemeBean.class, SDMX_PACKAGE_BASE, "OrganisationUnitScheme", null, OrganisationUnitSchemeBean.FIXED_VERSION, "Organisation Unit Scheme"), "organisationunitscheme",  maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, OrganisationUnitBean.class, "OrganisationUnit", "Organisation Unit"));
		});
	}
	
	private static void registerCodelistPackage() {
		String pk = SDMX_PACKAGE_CODELIST;
		
		registerType(MaintainableSDMXStructureType.getInstance(CodelistBean.class, pk, "Codelist"), "codelist", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, CodeBean.class, "Code"));
		});
		
		registerType(MaintainableSDMXStructureType.getInstance(HierarchicalCodelistBean.class, pk, "HierarchicalCodelist"), "hierarchicalcodelist", maintType -> {
            
        });
		
		registerType(MaintainableSDMXStructureType.getInstance(HierarchyBean.class, pk, "Hierarchy"), "hierarchy", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, HierarchicalCodeBean.class, "HierarchicalCode", "Hierarchical Code"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, LevelBean.class, "Level"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(HierarchyAssociationBean.class, pk, "HierarchyAssociation", "Hierarchy Association"), "hierarchyassociation");
		registerType(MaintainableSDMXStructureType.getInstance(ValueListBean.class, pk, "ValueList", "Value List"), "valuelist");
	}
	
	private static void registerCategoryPackage() {
		String pk = SDMX_PACKAGE_CATEGORY_SCHEME;
		
		registerType(MaintainableSDMXStructureType.getInstance(CategorySchemeBean.class, pk, "CategoryScheme", "Category Scheme"), "categoryscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, CategoryBean.class, "Category"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(ReportingTaxonomyBean.class, pk, "ReportingTaxonomy", "Reporting Taxonomy"), "reportingtaxonomy", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ReportingCategoryBean.class, "ReportingCategory", "Reporting Category"));
		});

		registerType(MaintainableSDMXStructureType.getInstance(CategorisationBean.class, pk, "Categorisation"), "categorisation");
	}
	
	private static void registerConceptSchemePackage() {
		registerType(MaintainableSDMXStructureType.getInstance(ConceptSchemeBean.class, SDMX_PACKAGE_CONCEPT_SCHEME, "ConceptScheme", "Concept Scheme"), "conceptscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ConceptBean.class, "Concept"));
		});
	}
	
	private static void registerDataStructurePackage() {
		String pk = SDMX_PACKAGE_DSD;
		
		registerType(MaintainableSDMXStructureType.getInstance(DataStructureBean.class, pk, "DataStructure", "Data Structure Definition"), "datastructure", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, AttributeListBean.class, "AttributeDescriptor", "Attribute Descriptor"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, AttributeBean.class, "DataAttribute",  "Data Attribute"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, DimensionListBean.class, "DimensionDescriptor", "Dimension Descriptor"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, DimensionBean.class, "Dimension"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, GroupBean.class, "GroupDimensionDescriptor", "Group Dimension Descriptor"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, CrossSectionalMeasureBean.class, "CrossSectionalMeasure", "Cross Sectional Measure"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, MeasureListBean.class, "MeasureDescriptor", "Measure Descriptor"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, MeasureDimensionBean.class, "Measure"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, PrimaryMeasureBean.class, "PrimaryMeasure", "Primary Measure"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ITimeDimensionBean.class, "TimeDimension","Time Dimension"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(DataflowBean.class, pk, "Dataflow"), "dataflow");
	}
	
	private static void registerMetadataStructurePackage() {
		String pk = SDMX_PACKAGE_MSD;
		registerType(MaintainableSDMXStructureType.getInstance(MetadataStructureDefinitionBean.class, pk, "MetadataStructure", "Metadata Structure Definition"), "metadatastructure", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, MetadataAttributeBean.class, "MetadataAttribute", "Metadata Attribute"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(MetadataFlowBean.class, pk, "Metadataflow"), "metadataflow");
		registerType(MaintainableSDMXStructureType.getInstance(IReportedMetadataSetBean.class, pk, "MetadataSet", "Metadata Report"), "metadata");
	}
	
	private static void registerMappingPackage() {
		String pk = SDMX_PACKAGE_MAPPING;
		
		registerType(MaintainableSDMXStructureType.getInstance(IStructureMapBean.class, pk, "StructureMap", "Structure Map"), "structuremap");
		registerType(MaintainableSDMXStructureType.getInstance(IRepresentationMapBean.class, pk, "RepresentationMap", "Representation Map"), "representationmap");
		registerType(MaintainableSDMXStructureType.getInstance(IReportingTaxonomyMapBean.class, pk, "ReportingTaxonomyMap", "Reporting Taxonomy Map"), "reportingtaxonomymap");
		registerType(MaintainableSDMXStructureType.getInstance(ICategorySchemeMapBean.class, pk, "CategorySchemeMap", "Category Scheme Map"), "categoryschememap");
		registerType(MaintainableSDMXStructureType.getInstance(IConceptSchemeMapBean.class, pk, "ConceptSchemeMap", "Concept Scheme Map"), "conceptschememap");
		registerType(MaintainableSDMXStructureType.getInstance(IOrganisationSchemeMapBean.class, pk, "OrganisationSchemeMap", "Organistion Scheme Map"), "organisationschememap");
		
		//Deprecated Mapping Types
		IMaintainableStructureType ss = registerType(StructureSetBean.class, SDMX_STRUCTURE_TYPE.STRUCTURE_SET);
		registerType(ss, StructureMapBean.class, SDMX_STRUCTURE_TYPE.STRUCTURE_MAP);
		registerType(ss, CategorySchemeMapBean.class, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME_MAP);
		registerType(ss, CodelistMapBean.class, SDMX_STRUCTURE_TYPE.CODE_LIST_MAP);
		registerType(ss, ConceptSchemeMapBean.class, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME_MAP);
		
	}
	
	private static void registerProcessPackage() {
		String pk = SDMX_PACKAGE_PROCESS;
		registerType(MaintainableSDMXStructureType.getInstance(ProcessBean.class, pk, "Process"), "process", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ProcessStepBean.class, "ProcessStep", "Process Step"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, TransitionBean.class, "Transition"));
		});
	}
	
	private static void registerRegistryPackage() {
		String pk = SDMX_PACKAGE_REGISTRY;
		registerType(MaintainableSDMXStructureType.getInstance(IMetadataConstraintBean.class, pk, "MetadataConstraint", "Metadata Constraint"), "metadataconstraint");
		registerType(MaintainableSDMXStructureType.getInstance(MetadataProvisionAgreementBean.class, pk, "MetadataProvisionAgreement", "Metadata Provision Agreement"), "metadataprovisionagreement");
		registerType(MaintainableSDMXStructureType.getInstance(ProvisionAgreementBean.class, pk, "ProvisionAgreement", "Provision Agreement"), "provisionagreement");
		registerType(MaintainableSDMXStructureType.getInstance(RegistrationBean.class, pk, "Registration"), "registration");
		registerType(MaintainableSDMXStructureType.getInstance(ContentConstraintBean.class, pk, "DataConstraint", "Data Constraint"), "dataconstraint");
		registerType(MaintainableSDMXStructureType.getInstance(SubscriptionBean.class, pk, "Subscription"), "subscription");
	}
	
	private static void registerVTLPackage() {
		String pk = SDMX_PACKAGE_TRANSFORMATION;
		
		registerType(MaintainableSDMXStructureType.getInstance(IVtlMappingSchemeBean.class, pk, "VtlMappingScheme", "VTL Mapping Scheme"), "vtlmappingscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IVtlCodelistMappingBean.class, "VtlCodelistMapping", "VTL Codelist Mapping"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IVtlConceptMappingBean.class, "VtlConceptMapping",  "VTL Concept Mapping"));
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IVtlDataflowMappingBean.class, "VtlDataflowMapping", "VTL Dataflow Mapping"));
		});
		
		registerType(MaintainableSDMXStructureType.getInstance(IUserDefinedOperatorSchemeBean.class, pk, "UserDefinedOperatorScheme", "User Defined Operator Scheme"), "userdefinedoperatorscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IUserDefinedOperatorBean.class, "UserDefinedOperator", "User Defined Operator"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(ITransformationSchemeBean.class, pk, "TransformationScheme", "Transformation Scheme"), "transformationscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ITransformationBean.class, "Transformation"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(IRulesetSchemeBean.class, pk, "RulesetScheme", "Ruleset Scheme"), "rulesetscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, IRulesetBean.class, "Ruleset"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(INamePersonalisationSchemeBean.class, pk, "NamePersonalisationScheme", "Name Personalisation Scheme"), "namepersonalisationscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, INamePersonalisationBean.class, "NamePersonalisation"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(ICustomTypeSchemeBean.class, pk, "CustomTypeScheme", "Custom Type Scheme"), "customtypescheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ICustomTypeBean.class, "CustomType"));
		});
	}
	
	/**
	 * Extended types
	 */
	private static void registerNonSDMXPackage() {
		registerType(MaintainableSDMXStructureType.getInstance(PublicationTableBean.class, "publicationtable", "PublicationTable", "Publication Table"), "publicationtable", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, PublicationVariableBean.class, "PublicationVariable"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(ValidationSchemeBean.class, "vtl", "ValidationScheme", "Validation Scheme"), "validationscheme", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ValidationRuleBean.class, "ValidationRule"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(ReportingTemplateBean.class, "reporting", "ReportingTemplate", "Reporting Template"), "reportingtemplate", maintType -> {
			registerType(IdentifiableSDMXStructureType.getInstance(maintType, ReportingTemplateWorksheetBean.class, "ReportingTemplateSheet", "Reporting Template Sheet"));
		});
		registerType(MaintainableSDMXStructureType.getInstance(IPreDefinedQueryBean.class, "pdq", "PreDefinedQuery", "Pre-Defined Query"), "predefinedquery");
	}

	/**
	 * An Abstract type is one which has multiple concrete subtypes, for example a Data Component is either a DataAttribute, Dimension, Measure, or Time Dimension
	 * 
	 * Registering a type as abstract will allow it to have a URN
	 * 
	 * i.e. urn:sdmx:org.sdmx.infomodel.abstract.AbstractClass=[agency]:[id]([version])
	 * 
	 * An abstract type can have a rest api resource, i.e. itemscheme will be a valid rest API call for any concrete interface which extends ItemSchemeBean and is registered with StructureTypes
	 */
	private static void registerAbstractTypes() {
		//Abstract Maintainable Types are in the abstract package
		registerType(MaintainableSDMXStructureType.getInstance(ItemSchemeBean.class, "abstract", "ItemScheme",  "Item Scheme"), "itemscheme");
		registerType(MaintainableSDMXStructureType.getInstance(OrganisationSchemeBean.class,  "abstract", "OrganisationScheme", "Organisation Scheme"), "organisationscheme");
		
		//Abstract Identifiable Types
		registerType(IdentifiableSDMXStructureType.getAbstractInstance(getMaintStructureType(MaintainableBean.class), ComponentBean.class, "Component", "Component"));
		registerType(IdentifiableSDMXStructureType.getAbstractInstance(getMaintStructureType(DataStructureBean.class), IDataStructureComponentBean.class, "DataComponent", "Data Component"));
		registerType(IdentifiableSDMXStructureType.getAbstractInstance(getMaintStructureType(MetadataStructureDefinitionBean.class), IMetadataStructureComponentBean.class, "MetadataComponent", "Metadata Component"));
	}

	/**
	 * Returns abstract types from the concrete type
	 * @param claz
	 * @return
	 */
	public static List<IMaintainableStructureType> getAbstractMaintStructureTypes(IMaintainableStructureType type) {
		if(type.isAbstract()) {
			return CollectionUtil.toList(type);
		}
		List<IMaintainableStructureType> resolvedAbstractTypes = new ArrayList<>();  //TODO CACHING
		for(IMaintainableStructureType currentType : maintTypes.values()) {
			if(currentType.isAbstract() && currentType.getClassType().isAssignableFrom(type.getClassType())) {
				resolvedAbstractTypes.add(currentType);
			}
		}
		return resolvedAbstractTypes;
	}

	/**
	 * Resolves an abstract type to concrete types
	 * @param claz
	 * @return
	 */
	public static List<IMaintainableStructureType> getConcreteMaintStructureTypes(IMaintainableStructureType type) {
		if(!type.isAbstract()) {
			return CollectionUtil.toList(type);
		}
		List<IMaintainableStructureType> resolvedConcreteTypes = concreteTypes.get(type);
		if(resolvedConcreteTypes == null) {
			resolvedConcreteTypes = new ArrayList<>();
			for(IMaintainableStructureType currentCT : maintTypes.values()) {
				if(type.getClassType().isAssignableFrom(currentCT.getClassType())) {
					resolvedConcreteTypes.add(currentCT);
				}
			}
			resolvedConcreteTypes = Collections.unmodifiableList(resolvedConcreteTypes);
			concreteTypes.put(type, resolvedConcreteTypes);
		}
		return resolvedConcreteTypes;
	}

	/**
	 * @param claz
	 * @return not null, immutable list of maintainable structure types
	 */
	public static List<IMaintainableStructureType> getMaintStructureTypes() {
		return Collections.unmodifiableList(new ArrayList<>(maintTypes.values()));
	}

	/**
	 * @param claz
	 * @return the registered definition for the structure type argument
	 */
	public static IMaintainableStructureType getMaintStructureType(Class<? extends MaintainableBean> claz) {
		registerCoreTypes();
		if(claz == null) {
			throw new IllegalArgumentException("getStructureType can not return value for null input");
		}

		IMaintainableStructureType type = maintTypes.get(claz);

		if(type == null) {
			throw new IllegalArgumentException("Unable to obtain definition for unregistered structure type: "+claz.getName());
		}

		return type;
	}

	/**
	 * @param claz
	 * @return the registered definition for the structure type argument
	 */
	public static <T extends IdentifiableBean> ISDMXStructureType<?, T> getAnyStructureType(Class<T> claz) {
		registerCoreTypes();
		if(claz == null) {
			throw new IllegalArgumentException("getStructureType can not return value for null input");
		}

		ISDMXStructureType type = identTypes.get(claz);
		type = type == null ? maintTypes.get(claz) : type;

		if(type == null) {
			throw new IllegalArgumentException("Unable to obtain definition for unregistered structure type: "+claz.getName());
		}

		return type;
	}

	/**
	 * Registration for any maintainable type
	 * @param type
	 */
	public static IMaintainableStructureType registerType(IMaintainableStructureType type, String restResource) {
		if(type != null) {
			maintTypes.put(type.getMaintainableType(), type);
			typesByRESTResource.put(restResource, type);
			registerTypeGeneric(type);
		}
		return type;
	}

	public static void registerType(IMaintainableStructureType type, String restResource, IProcessWithArgument<IMaintainableStructureType> process) {
		registerType(type, restResource, process, true);
	}
	/**
	 * 
	 * @param type
	 * @param restResource
	 * @param process
	 * @param registerPackageAndClass - set to false if registing a deprecated class which has the same package and class already registered
	 */
	public static void registerType(IMaintainableStructureType type, String restResource, IProcessWithArgument<IMaintainableStructureType> process, boolean registerPackageAndClass) {
		maintTypes.put(type.getMaintainableType(), type);
		typesByRESTResource.put(restResource, type);
		if(registerPackageAndClass) {
			registerTypeGeneric(type);
		}
		if(process != null) {
			process.runProcess(type);
		}
	}
	public static void registerType(IIdentifiableStructureType type) {
		registerType(type, true);
	}
	/**
	 * Registration for non-maintainable types
	 * @param type
	 */
	public static void registerType(IIdentifiableStructureType type, boolean registerPackageAndClass) {
		if(type != null) {
			//registerType(type.getMaintainableStructureType());  //ensure the maintainable parent is registered
			identTypes.put(type.getClassType(), type);
			if(registerPackageAndClass) {
				registerTypeGeneric(type);
			}
		}
	}

	/**
	 * Generic registration for all types
	 * @param type
	 */
	private static void registerTypeGeneric(ISDMXStructureType type) {
		String objectKey = getObjectKey(type.getUrnNamespace(), type.getUrnPackage(), type.getUrnClass());
		if(typesByPackageAndClass.containsKey(objectKey)) {
			LOG.warn("Duplicate class for package and type: "+objectKey);
		}
		typesByPackageAndClass.put(objectKey, type);
			
	}

	private static String getObjectKey(String urnPrefix, String packageName, String className) {
		if(!urnPrefix.endsWith(".")) {
			urnPrefix += ".";
		}
		return urnPrefix + ":" +packageName + ":" + className;
	}
}
