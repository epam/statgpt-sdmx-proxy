package io.sdmx.utils.sdmx.application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.FusionProduct;
import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductPlugin;
import io.sdmx.api.application.IApplicationWebService;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Contains product information for a fusion product
 */
public class FusionProductInformationImpl implements FusionProductInformation, JSONString  {
	private static final Logger LOG = LoggerFactory.getLogger(FusionProductInformationImpl.class);

	private String applicationURL;
	private FusionProduct fusionProduct;
	private List<FusionProductPlugin> supportedPlugins = new ArrayList<>();
	private Map<IApplicationWebService, String> publicApiUrls = new HashMap<>();
	private Set<IApplicationWebService> supportedWebServices = new HashSet<>();
	private String publicServerURL;

	public FusionProductInformationImpl(FusionProduct fusionProduct) {
		this.fusionProduct = fusionProduct;
	}
	
	public FusionProductInformationImpl(
			String applicationURL,
			FusionProduct fusionProduct,
			List<FusionProductPlugin> supportedPlugins,
			Map<IApplicationWebService, String> publicApiUrls,
			Set<IApplicationWebService> supportedWebServices,
			String publicServerURL) {
		super();
		this.applicationURL = applicationURL;
		this.fusionProduct = fusionProduct;
		if(supportedPlugins != null) {
			this.supportedPlugins.addAll(supportedPlugins);
		}
		if(publicApiUrls != null) {
			this.publicApiUrls.putAll(publicApiUrls);
		}
		if(supportedWebServices != null) {
			this.supportedWebServices.addAll(supportedWebServices);
		}
		this.publicServerURL = publicServerURL;
	}

	public FusionProductInformationImpl(JSONObject json) {
		Objects.requireNonNull(json, "FusionProductInformation: JSONObject is required");
		try {
			fusionProduct = new FusionProductImpl(json);
			if(json.has("ApplicationURL")) {
				this.applicationURL = (String)json.get("ApplicationURL");
			}
			if(json.has("Plugins")) {
				JSONArray jsonArray = json.getJSONArray("Plugins");
				for(int i =0; i < jsonArray.length(); i++) {
					supportedPlugins.add(new FusionProductPluginImpl(jsonArray.getJSONObject(i)));
				}
			}
			publicApiUrls = new HashMap<>();
			if(json.has("WebServices")) {
				JSONArray jsonArray = json.getJSONArray("WebServices");
				for(int i =0; i < jsonArray.length(); i++) {
					JSONObject wsJson = jsonArray.getJSONObject(i);
					String key = (String) wsJson.keys().next();
					if(key != null) {
						String value = wsJson.getString(key);
						WEB_SERVICE ws = WEB_SERVICE.getByProperty(value);
						if(ws != null) {
							publicApiUrls.put(ws.service(), value);
						}
					}
				}
			}
		} catch (JSONException e) {
			LOG.error("Could not read FusionProductInformation from JSON: ", e);
			throw new SdmxException(e, "Could not read FusionProductInformation from JSON: " +  json.toString());
		}
	}

	public FusionProductInformationImpl(String applicationURL,
			FusionProduct fusionProduct,
			List<FusionProductPlugin> supportedPlugins,
			String publicServerURL,
			Map<IApplicationWebService, String> publicApiUrls) {
		this.applicationURL = applicationURL;
		this.fusionProduct = fusionProduct;
		this.supportedPlugins = supportedPlugins;
		this.publicServerURL = publicServerURL;
		if(publicApiUrls != null) {
			this.publicApiUrls = Collections.unmodifiableMap(new HashMap<>(publicApiUrls));
		} else {
			this.publicApiUrls = Collections.emptyMap();
		}
	}

	@Override
	public String getServiceURL(IApplicationWebService serivce) {
		String postFix = null;
		if(publicApiUrls != null) {
			postFix =  publicApiUrls.get(serivce);
		}
		if(postFix == null) {
			return this.applicationURL + serivce.getServicePostFix();
		}
		if(publicServerURL == null) {
			return postFix;
		}
		return publicServerURL + postFix;
	}

	@Override
	public FusionProduct getProductDetails() {
		return fusionProduct;
	}

	@Override
	public List<FusionProductPlugin> getSupportedPlugins() {
		return supportedPlugins;
	}

	@Override
	public String getApplicationURL() {
		return applicationURL;
	}

	/**
	 * 
	 * @param pluginString a delimited string of all supported plugins, in the following format
	 * <pre>
	 *   pluginName:1,2,3|pluginName:1|pluginName:3
	 * </pre>
	 */
	public void setPlugins(String pluginString) {
		if(ObjectUtil.validString(pluginString)) {
			String[] plugins = pluginString.split("\\|");
			for(String currentPlugin : plugins) {
				String[] nameVersionSplit = currentPlugin.split(":");
				String pluginName = nameVersionSplit[0];
				String pluginVersions = nameVersionSplit[1];
				String[] versions = pluginVersions.split(",");
				Integer[] versionInts = new Integer[versions.length];
				for(int i = 0; i < versions.length; i++ ) {
					versionInts[i] = Integer.parseInt(versions[i]);
				}
				this.supportedPlugins.add(new FusionProductPluginImpl(pluginName, versionInts));
			}
		}
	}

	@Override
	public String toString() {
		return toJSONString();
	}

	@Override
	public String publicApiToString() {
		return getJsonRepresentationPublic().toString();
	}

	@Override
	/**
	 * Returns the following JSON:
	 * {
	 *  Product : "FUSION_MATRIX",
	 *  ProductName : "My Org Matrix",
	 *  Version : "1.0",
	 *  ReleaseDate : 2138123285
	 *  ApplicationURL : "http://...."
	 *  TimeNow : 2314123145
	 * }
	 * 
	 */
	public String toJSONString() {
		return getJsonRepresentation().toString();
	}

	public JSONObject getJsonRepresentation() {
		JSONObject jsonObject = new JSONObject();
		try {
			if(fusionProduct != null) {
				jsonObject.put("Product", fusionProduct.getProduct());
				jsonObject.put("ProductName", fusionProduct.getProductName());
				jsonObject.put("Version", fusionProduct.getVersion());
				jsonObject.put("ReleaseDate", fusionProduct.getReleaseDate());
			}
			jsonObject.put("ApplicationURL", applicationURL);
			if(this.fusionProduct == null || !this.fusionProduct.getProduct().equals("Fusion Security")) { // security does not have public web service mapping, possibly a better way of doing this,
				writeWEBServices(jsonObject, false);
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not write FusionProductInformation as JSON");
		}
		return jsonObject;
	}


	public JSONObject getJsonRepresentationPublic() {
		JSONObject jsonObject = new JSONObject();
		try {
			if(fusionProduct != null) {
				jsonObject.put("Product", fusionProduct.getProduct());
				jsonObject.put("ProductName", fusionProduct.getProductName());
				jsonObject.put("Version", fusionProduct.getVersion());
			}

			writeWEBServices(jsonObject, true);
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not write FusionProductInformation as JSON");
		}
		return jsonObject;
	}

	private void writeWEBServices(JSONObject json, boolean isPublic) throws JSONException {
		if(this.supportedPlugins != null) {
			JSONArray plugins = new JSONArray(this.supportedPlugins);
			json.put("Plugins", plugins);
		}
		List<JSONObject> allServices = new ArrayList<>();
		if(supportedWebServices != null) {
			for(IApplicationWebService ws : supportedWebServices) {
				JSONObject wsJson = writeWEBService(ws, isPublic);
				if(wsJson != null) {
					allServices.add(wsJson);
				}
			}
		}
		JSONArray arr = new JSONArray(allServices);
		json.put("WebServices", arr);
	}

	private JSONObject writeWEBService(IApplicationWebService ws, boolean isPublic) throws JSONException {
		if(this.supportedWebServices != null && !this.supportedWebServices .contains(ws)) {
			return null;
		}
		String servicePostfix;
		if(isPublic) {
			servicePostfix =  publicApiUrls.get(ws);
		} else {
			servicePostfix = ws.getServicePostFix();
		}
		if(servicePostfix != null) {
			JSONObject json = new JSONObject();
			json.put(ws.getServiceName(), applicationURL+""+servicePostfix);
			return json;
		}
		return null;
	}

//	public void setSupportedWebServices(Map<String, String> supportedWebServices) {
//		this.supportedWebServices = new HashSet<>();
//		Map<IApplicationWebService, String> publicApiUrls = new HashMap<>();
//		if(this.publicApiUrls != null) {
//			publicApiUrls.putAll(this.publicApiUrls);
//		}
//		for(String wsEnumString : supportedWebServices.keySet()) {
//			WEB_SERVICE webService = WEB_SERVICE.valueOf(wsEnumString);
//			this.supportedWebServices.add(webService);
//			String url = supportedWebServices.get(wsEnumString);
//			if(ObjectUtil.validString(url)) {
//				if(!url.startsWith("/")) {
//					url = "/"+url;
//				}
//				publicApiUrls.put(webService, url);
//			}
//		}
//		if(publicApiUrls.size() > 0) {
//			this.publicApiUrls = publicApiUrls;
//		}
//	}

	public void setApplicationURL(String applicationURL) {
		if (applicationURL.endsWith("/")) {
			applicationURL = applicationURL.substring(0, applicationURL.length() - 1);
		}
		this.applicationURL = applicationURL;
	}
}
