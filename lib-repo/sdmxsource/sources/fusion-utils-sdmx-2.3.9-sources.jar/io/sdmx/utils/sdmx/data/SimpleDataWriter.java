package io.sdmx.utils.sdmx.data;

import java.util.*;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.SeriesUtil;

public class SimpleDataWriter {
	private DataWriterEngine dwe;
	private String[] dimensions;
	private String[] datsetAttributes;
	private String[] seriesAttributes;
	private String[] measureIds;
	private String[] measureAttributes;
	private String dimConceptId;
	private boolean hasTimeDimension;
	private boolean crossSectional;
	private Map<String, String[]> groupAttributes;
	
	private String splitMultiValue = ";";
	
	
	public SimpleDataWriter(DataWriterEngine dwe, String dimConceptId) {
		this.dwe = dwe;
		this.dimConceptId = dimConceptId;
	}
	
	public void startDataset(ProvisionAgreementBean provision, DataflowBean dataflow, DataStructureBean dataStructureBean, DatasetHeaderBean header) {
		dwe.startDataset(provision, dataflow, dataStructureBean, header);
		List<String> dimIds = new ArrayList<>(dataStructureBean.getDimensionIds());
		this.crossSectional = hasTimeDimension && this.dimConceptId != null && !this.dimConceptId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID);
		if(this.crossSectional) {
			dimIds.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
		this.groupAttributes = new HashMap<>();
		for(GroupBean group : dataStructureBean.getGroups()) {
			this.groupAttributes.put(group.getId(), SdmxCollectionUtil.identifiablesIdArray(dataStructureBean.getGroupAttributes(group.getId(), false)));
		}
		this.datsetAttributes = SdmxCollectionUtil.identifiablesIdArray(dataStructureBean.getDatasetAttributes());
		this.dimensions = CollectionUtil.toArray(dimIds);
		this.seriesAttributes = SdmxCollectionUtil.identifiablesIdArray(dataStructureBean.getSeriesAttributes(this.dimConceptId));
		this.measureIds = SdmxCollectionUtil.identifiablesIdArray(dataStructureBean.getMeasures());
		this.measureAttributes = SdmxCollectionUtil.identifiablesIdArray(dataStructureBean.getObservationAttributes(this.dimConceptId));
		this.hasTimeDimension = dataStructureBean.getTimeDimension() != null;
	}
	
	public void writeDatasetAttributes(String... attributes) {
		for(int i=0; i < datsetAttributes.length; i++) {
			if(attributes.length > i) {
				this.dwe.writeAttributeValue(datsetAttributes[i], attributes[i]);
			}
		}
	}

	/**
	 * @param seriesKey - colon delimited series key
	 * @param attributes optional reported values, in same order as defined by DSD
	 */
	public void writeSeries(String seriesKey, String... attributes) {
		dwe.startSeries();
		String[] keySplit = SeriesUtil.splitKey(seriesKey);
		for(int i=0; i < keySplit.length; i++) {
			if(keySplit[i].length() > 0) {
				dwe.writeSeriesKeyValue(dimensions[i], keySplit[i]);
			}
		}
		writeAttributes(seriesAttributes, attributes);
	}
	
	/**
	 * @param seriesKey - colon delimited series key
	 * @param attributes optional reported values, in same order as defined by DSD
	 */
	public void writeGroup(String groupId, String seriesKey, String... attributes) {
		dwe.startGroup(groupId);
		String[] keySplit = SeriesUtil.splitKey(seriesKey);
		for(int i=0; i < keySplit.length; i++) {
			if(keySplit[i].length() > 0) {
				dwe.writeGroupKeyValue(dimensions[i], keySplit[i]);
			}
		}
		writeAttributes(groupAttributes.get(groupId), attributes);
	}


	/**
	 * @param dimConceptValue nullable, if time series this is the time period - otherwise it is the value of the cross section
	 * @param measureValues values for each measure in the order defined in the DSD, followed by the values for the attributes in the order defined by the DSD
	 */
	public void writeObs(String dimConceptValue, String...measureValues) {
        int i = 0;
        List<KeyValue> measures = new ArrayList<>();
        for (String measureId : measureIds) {
            if (measureValues.length == i) {
                break;
            }
            String val = measureValues[i];
            if (val != null) {
                measures.add(KeyValueImpl.getInstance(measureId, val));
            }
            i++;
        }
        i = measureIds.length;
        dwe.writeObservation(dimConceptId, dimConceptValue, measures);

        writeAttributes(measureAttributes, measureValues, i);
    }
	
	private void writeAttributes(String[] attrIds, String[] attributeValues) {
		writeAttributes(attrIds, attributeValues, 0);
	}
	
	private void writeAttributes(String[] attrIds, String[] attributeValues, int startIdx) {
		if(attributeValues != null) {
			for(int i=0; i < attrIds.length; i++) {
				if(attributeValues.length <= (i+startIdx)) {
					break;
				}
				String attId = attrIds[i];
				String attVal = attributeValues[i+startIdx];
				if(attVal != null) {
					if(attVal.contains(splitMultiValue)) {
						String[] split = attVal.split(splitMultiValue);
						for(String currentVal : split) {
							dwe.writeAttributeValue(attId, currentVal);
						}
					} else {
						dwe.writeAttributeValue(attId, attVal);
					}
				}
			}
		}
	}

	
	public void close() {
		dwe.close();
	}
}
