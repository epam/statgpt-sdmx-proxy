package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;

public class LinkComparator implements Comparator<ILinkBean> {
    public static final LinkComparator INSTANCE = new LinkComparator();

    private LinkComparator() {}

    @Override
    public int compare(ILinkBean iBean1, ILinkBean iBean2) {
        int result = 0;
        result = compareObjects(iBean1.getRel(), iBean2.getRel());
        if(result == 0) {
            result = compareObjects(iBean1.getTitle(), iBean2.getTitle());
        }
        if(result == 0) {
            result = compareObjects(iBean1.getType(), iBean2.getType());
        }
        if(result == 0) {
            result = compareObjects(iBean1.getHRef(), iBean2.getHRef());
        }
        if(result == 0) {
            result = compareObjects(iBean1.getUrn(), iBean2.getUrn());
        }
        if(result == 0) {
            result = compareObjects(iBean1.getUri(), iBean2.getUri());
        }
        return result;
        
    }
    
    private int compareObjects(Object obj1, Object obj2) {
        if(obj1 == null & obj2 == null) {
            return 0;
        }
        if(obj1 != null & obj2 == null) {
            return -1;
        }
        if(obj1 == null & obj2 != null) {
            return 1;
        }
        return obj1.toString().compareTo(obj2.toString());
    }

}
