package io.sdmx.utils.sdmx.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;

public class CategoryUtil {

	
	public static List<String> getIdAsHierarchy(CategoryBean category) {
		List<String> idAsHierarchy = new ArrayList<>();
		buildIdAsHierarchy(idAsHierarchy, category);
		Collections.reverse(idAsHierarchy);
		
		return idAsHierarchy;
	}
	
	private static void buildIdAsHierarchy(List<String> idAsHierarchy, CategoryBean category) {
		idAsHierarchy.add(category.getId());
		if(category.getParent() instanceof CategoryBean) {
			buildIdAsHierarchy(idAsHierarchy, (CategoryBean)category.getParent());
		}		
	}
	
}
