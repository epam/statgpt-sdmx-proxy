package io.sdmx.utils.sdmx.xs;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanFuzzy;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public class CrossReferenceBeanFuzzy extends CrossRefrenceBeanBase implements ICrossReferenceBeanFuzzy {
	private static final long serialVersionUID = 1L;
	private IURN<?> refTo;
	private Integer hashCode;
	
	public static CrossReferenceBeanFuzzy getInstance(IdentifiableBean refFrom, IURN<?> refTo) {
		return new CrossReferenceBeanFuzzy(refFrom, refTo);
	}
	
	private CrossReferenceBeanFuzzy(IdentifiableBean refFrom, IURN<?> refTo) {
		super(refFrom);
		this.refTo = refTo;
	}

	public IURN<?> getReference() {
		return refTo;
	}
	

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ICrossReferenceBeanFuzzy) {
			ICrossReferenceBeanFuzzy that = (ICrossReferenceBeanFuzzy) obj;
			return this.getReferencedFrom().equals(that.getReferencedFrom()) &&
					this.getTargetUrn().equals(that.getTargetUrn());
		}
		return false;
	}

	@Override
	public int hashCode() {
		if(hashCode == null) {
			hashCode = new HashCodeBuilder(7, 31).append(getReference())
					.append(getReferencedFrom())
					.build();
		}
		return hashCode;
	}

	@Override
	public StructureReferenceBean asMutable() {
		return new StructureReferenceBeanImpl(refTo);
	}

}
