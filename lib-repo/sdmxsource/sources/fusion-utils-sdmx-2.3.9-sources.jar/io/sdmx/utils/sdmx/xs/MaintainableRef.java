package io.sdmx.utils.sdmx.xs;

import java.lang.ref.SoftReference;
import java.util.Map;

import org.apache.commons.collections4.map.ReferenceMap;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.object.ObjectUtil;

public class MaintainableRef implements IMaintainableRef {
	private static final Map<String, SoftReference<IMaintainableRef>> cache = new ReferenceMap<>();
	public static final IMaintainableRef ALL = getInstance(null, null, VersionRef.ALL);
	
	private static final long serialVersionUID = 1L;
	private String agencyId;
	private String maintainableId;
	private IVersionRef version;
	
	/**
	 * @param agencyId
	 * @param maintainableId
	 * @return instance, all versions
	 */
	public static IMaintainableRef getInstance(MaintainableBean maint) {
		return getInstance(maint.getAgencyId(), maint.getId(), maint.getVersion().toString());
	}
	
	/**
	 * @param agencyId
	 * @param maintainableId
	 * @return instance, all versions
	 */
	public static IMaintainableRef getInstance(String agencyId, String maintainableId) {
		return getInstance(agencyId, maintainableId, VersionRef.ALL);
	}
	
	public static IMaintainableRef getInstance(String agencyId, String maintainableId, String version) {
		return getInstance(agencyId, maintainableId, VersionRef.getInstance(version));
	}
	
	public static IMaintainableRef getInstance(String agencyId, String maintainableId, IVersionRef version) {
		agencyId = cleanString(agencyId);
		maintainableId = cleanString(maintainableId);
		version = version == null ? VersionRef.ALL : version;
		String cacheKey = cacheKey(agencyId, maintainableId, version.toString());
		SoftReference<IMaintainableRef> mRef = cache.get(cacheKey);
		if(mRef == null) {
			mRef = new SoftReference<>(new MaintainableRef(agencyId, maintainableId, version));
			cache.put(cacheKey, mRef);
		}
		return mRef.get();
	}
	
	private static String cleanString(String str)  {
		if(str != null) {
			str = str.trim();
			if(str.length() == 0) {
				return null;
			} 
			if(str.equals("*")) {
				return null;
			}
		}
		return str;
	}
	
	private static String cacheKey(String agencyId, String maintainableId, String version) {
		return agencyId + ":" + maintainableId + ":" + version;
	}
	
	private MaintainableRef(String agencyId, String maintainableId, String version) {
		this(agencyId, maintainableId, VersionRef.getInstance(version));
	}
	
	private MaintainableRef(String agencyId, String maintainableId, IVersionRef version) {
		this.agencyId = agencyId;
		this.maintainableId = maintainableId;
		this.version = version == null ? VersionRef.getInstance(null) : version;
	}

	@Override
	public String getAgencyId() {
		return agencyId;
	}

	@Override
	public String getMaintainableId() {
		return maintainableId;
	}

	@Override
	public IVersionRef getVersion() {
		return version;
	}


	@Override
	public boolean equals(Object obj) {
		if(obj == this) return true;
		
		if(obj instanceof MaintainableRef) {
			MaintainableRef that = (MaintainableRef) obj;
			return ObjectUtil.equivalent(getAgencyId(), that.getAgencyId()) && 
					ObjectUtil.equivalent(getMaintainableId(), that.getMaintainableId()) &&
					ObjectUtil.equivalent(getVersion(), that.getVersion());
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return cacheKey(agencyId, maintainableId, version.toString()).hashCode();
	}
	
	
}
