package io.sdmx.utils.sdmx.xml;

import java.util.Date;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.utils.core.date.DateUtil;

public class SdmxStaxUtil {


	public static void writeHeader(XMLStreamWriter writer, String id, String senderId) throws XMLStreamException {
		writer.writeStartElement("Header");
		//WRITE ID
		writer.writeStartElement("ID");
		writer.writeCharacters(id);
		writer.writeEndElement();
		//WRITE TEST
		writer.writeStartElement("Test");
		writer.writeCharacters("false");
		writer.writeEndElement();
		//WRITE PREPARED
		writer.writeStartElement("Prepared");
		writer.writeCharacters(DateUtil.formatDate(new Date()) + "Z");
		writer.writeEndElement();
		//WRITE SENDER
		writer.writeStartElement("Sender");
		writer.writeAttribute("id", senderId);
		writer.writeEndElement();

		//END HEADER
		writer.writeEndElement();
	}
}
