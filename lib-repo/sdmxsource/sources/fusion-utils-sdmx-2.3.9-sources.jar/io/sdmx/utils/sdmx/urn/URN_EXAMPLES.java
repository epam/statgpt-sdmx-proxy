package io.sdmx.utils.sdmx.urn;

/**
 * Example URNs for test purposes
 */
public class URN_EXAMPLES {

	public static final String URN_DSD = "urn:sdmx:org.sdmx.infomodel.datastructure.DataStructure=ECB:ECB_EXR1(1.0.0)";
}
