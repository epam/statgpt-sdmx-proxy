package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.date.TIME_FORMAT;

public class TimeFormatComparator implements Comparator<TIME_FORMAT> {
	public static final TimeFormatComparator INSTANCE = new TimeFormatComparator();
	
	private TimeFormatComparator() {};

	@Override
	public int compare(TIME_FORMAT o1, TIME_FORMAT o2) {
		if(o1.getMillisInPeriod() == o2.getMillisInPeriod()) {
			return 0;
		}
		return o1.getMillisInPeriod() > o2.getMillisInPeriod() ? 1 : -1;
	}
}
