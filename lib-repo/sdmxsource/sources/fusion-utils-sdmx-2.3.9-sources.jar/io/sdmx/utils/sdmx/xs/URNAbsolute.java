package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

public class URNAbsolute extends URN implements IURNAbsolute {
	private static final long serialVersionUID = 1L;

	/**
	 * Package protected, constructed via the URN.getInstance method
	 */
	URNAbsolute(ISDMXStructureType structureType, IMaintainableRef ref, String identifiableId, String urn) {
		super(structureType, ref, identifiableId, urn);
	}

	@Override
	public IURNMaintainable getMaintainableURN() {
		return (IURNMaintainable) super.getMaintainableURN();
	}

	
	@Override
	public REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.ABSOLUTE;
	}

	@Override
	public ISdmxVersion getAbsoluteVersion() {
		return super.getVersion().getMinVersion();
	}
}
