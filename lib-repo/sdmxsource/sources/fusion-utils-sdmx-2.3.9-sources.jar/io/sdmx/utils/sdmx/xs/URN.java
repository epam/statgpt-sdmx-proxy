package io.sdmx.utils.sdmx.xs;

import java.lang.ref.SoftReference;
import java.util.Collections;
import java.util.Map;

import org.apache.commons.collections4.map.ReferenceMap;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.structure.MaintainableSDMXStructureType;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.structure.UrnUtil;

public abstract class URN implements IURN {
	public static final String URN_WILDCARD = "*";
	private static final long serialVersionUID = 1L;

	private static final Map<String, SoftReference<IURN<?>>> cache;
	
	static {
		cache = Collections.synchronizedMap(new ReferenceMap<>());
	}

	private ISDMXStructureType<?,?> structureType;
	private IMaintainableRef maintainableRef;
	private String identifiableId;
	private String fullIdentifiableId;
	private String urn;
	private String shortUrn;
	private SDMX_STRUCTURE_TYPE sdmxType;

	public static final IURN<?> ANY = URN.builder().structure(SDMX_STRUCTURE_TYPE.ANY).build();
	public static final IURN<MaintainableBean> ANY_MAINTINABLE = URN.builder().build(MaintainableBean.class);

	public static URNBuilder builder() {
		return new URNBuilder();
	}
	public static URNBuilder builder(String urn) {
		return new URNBuilder(urn);
	}

	/**
	 * Builds a URN reference for all structures that match the given class type
	 * 
	 * @param <T> class type to match
	 * @param type the type of Interface to target, this could be a concrete interface such as CodelistBean or an abstract interface such
	 * as MaintainableBean
	 * @return
	 */
	public static <T extends IdentifiableBean> IURN<T> build(Class<T> type) {
		return builder().build(type);
	}

	/**
	 * @param urn can be null
	 * @return {@link IURNAbsolute} or null if the urn string is null;
	 */
	public static <T extends IdentifiableBean> IURNAbsolute<T> buildOrNull(String urn, Class<T> type) {
		if(urn == null) {
			return null;
		}
		return builder(urn).buildAbsolute(type);
	}
	public static URNBuilder builder(String agency, String id, String version, String... identIds) {
		return builder().agencyId(agency).maintId(id).version(version).identifableId(identIds);
	}
	public static URNBuilder builder(SDMX_STRUCTURE_TYPE st, String agency, String id, String version, String... identIds) {
		return builder().structure(st).agencyId(agency).maintId(id).version(version).identifableId(identIds);
	}

	public static URNBuilder builder(ISDMXStructureType<?, ?> st, String agency, String id, String version, String... identIds) {
		return builder().structure(st).agencyId(agency).maintId(id).version(version).identifableId(identIds);
	}
	public static URNBuilder builder(IURN urn) {
		return builder().structure(urn.getStructureType()).agencyId(urn.getAgencyId()).maintId(urn.getMaintainableId()).versionRef(urn.getVersion()).identifableId(urn.getFullIdentifiableId());
	}

	public static class URNBuilder {
		private String urn;
		private ISDMXStructureType<?, ?> structureType;
		private String version;
		private String maintId;
		private String agencyId;
		private String identifiableId;

		public URNBuilder() {}

		public URNBuilder(String urn) {
			this.urn = urn;
		}
		
		public boolean hasStruture() {
			return structureType != null;
		}
		public boolean hasAgency() {
			return agencyId != null;
		}
		public boolean hasMaint() {
			return maintId != null;
		}
		public boolean hasVersion() {
			return version != null;
		}
		public String getIdentifable() {
			return identifiableId;
		}
		public boolean hasIdentifable() {
			return identifiableId != null;
		}
		
		public IURN<?> build() {
			if(urn == null) {
				if(!ObjectUtil.validString(agencyId)) {
					agencyId = URN.URN_WILDCARD;
				}
				if(!ObjectUtil.validString(maintId)) {
					maintId = URN.URN_WILDCARD;
				}
				if(!ObjectUtil.validString(version)) {
					version = URN.URN_WILDCARD;
				}
				if(structureType == null) {
					structureType = MaintainableSDMXStructureType.ANY;
				} else {
					IMaintainableStructureType maintType = structureType.getMaintainableStructureType();
					if(maintType.hasFixedId()) {
						maintId = maintType.getFixedId();
					}
					if(maintType.hasFixedVersion()) {
						version = maintType.getFixedVersion();
					}
					if(!structureType.isMaintainable() && identifiableId == null) {
						identifiableId = URN.URN_WILDCARD;
					}
				}
				urn = structureType.generateURN(agencyId, maintId, version, identifiableId);
			}
			return URN.getInstance(urn);
		}
		public IURNMaintainable<?> buildMaintainable() {
			return buildMaintainable(null);
		}

		public <T extends MaintainableBean> IURNMaintainable<T> buildMaintainable(Class<T> expectedType) {
			IURN<?> anyURN = build(expectedType);
			checkMaintainable(anyURN);
			checkType(anyURN, expectedType);
			return (IURNMaintainable<T>) anyURN;
		}

		@SuppressWarnings("unchecked")
		public <T extends IdentifiableBean> IURN<T> build(Class<T> expectedType) {
			boolean typeSet = false;
			if(structureType == null && expectedType != null && this.urn == null) {
				structure(expectedType);
				typeSet = true;
			}
			IURN<?> anyURN = build();
			//if(!typeSet) {
			checkType(anyURN, expectedType);
			//}
			return (IURN<T>) anyURN;
		}

		public IURNAbsolute<?> buildAbsolute() {
			IURN<?> anyURN = build();
			checkAbsolute(anyURN);
			return (IURNAbsolute<?>) anyURN;
		}

		@SuppressWarnings("unchecked")
		public <T extends IdentifiableBean> IURNAbsolute<T> buildAbsolute(Class<T> expectedType) {
			IURN<?> anyURN = build(expectedType);
			checkAbsolute(anyURN);
			return (IURNAbsolute<T>) anyURN;
		}

		public IURNSingle<?> buildSingle() {
			IURN<?> anyURN = build();
			checkSingle(anyURN);
			return (IURNSingle<?>) anyURN;
		}

		@SuppressWarnings("unchecked")
		public <T extends IdentifiableBean> IURNSingle<T> buildSingle(Class<T> expectedType) {
			IURN<?> anyURN = build(expectedType);
			checkSingle(anyURN);
			return (IURNSingle<T>) anyURN;
		}

		private void checkType(IURN<?> urn, Class<? extends IdentifiableBean> expectedType) {
			if(!urn.getStructureType().matchesType(expectedType)) {
				String type = expectedType.getName();
				try {
					type = StructureTypes.getAnyStructureType(expectedType).toString();
				} catch(Throwable th) {}
				throw new SdmxSemmanticException("URN '"+urn.getURN()+"' is not of expected type '"+type+"'");
			}
		}
		private void checkAbsolute(IURN<?> urn) {
			if(urn instanceof IURNAbsolute) {
				return;
			}
			throw new SdmxSemmanticException("URN '"+urn.getURN()+"' is not an absolute reference");
		}
		private void checkSingle(IURN<?> urn) {
			if(urn instanceof IURNSingle) {
				return;
			}
			throw new SdmxSemmanticException("URN '"+urn.getURN()+"' does not reference a single structure (it contains wildcards)");
		}
		private void checkMaintainable(IURN<?> urn) {
			if(urn instanceof IURNMaintainable) {
				return;
			}
			throw new SdmxSemmanticException("URN '"+urn.getURN()+"' is not a valid absolute Maintainable URN");
		}

		public URNBuilder urn(IURN<?> urn) {
			if(urn != null) {
				this.urn = urn.getURN();
				this.structure(urn.getStructureType());
				agencyId(urn.getAgencyId());
				identifableId(urn.getFullIdentifiableId());
				maintId(urn.getMaintainableId());
				version(urn.getVersion().toString());
			} else {
				this.urn = null;
			}
			return this;
		}

		/**
		 * Converts a URN to an identifiable URN
		 * @param urn
		 * @param identifiableType
		 * @param identifiableId
		 * @return
		 */
		public URNBuilder toIdentifiable(IURN<?> urn, SDMX_STRUCTURE_TYPE identifiableType, String identifiableId) {
			return urn(urn).structure(identifiableType).identifableId(identifiableId);
		}

		public URNBuilder structure(ISDMXStructureType<?, ?> st) {
			urn = null;
			this.structureType = st;
			return this;
		}
		public URNBuilder structure(Class<? extends IdentifiableBean> claz) {
			urn = null;
			if(claz == null) {
				this.structureType = null;
				return this;
			}
			return structure(StructureTypes.getAnyStructureType(claz));
		}
		public URNBuilder structure(SDMX_STRUCTURE_TYPE sdmxStructure) {
			urn = null;
			if(sdmxStructure == null) {
				this.structureType = null;
			} else if(sdmxStructure != SDMX_STRUCTURE_TYPE.ANY) {
				return structure(sdmxStructure.getIdentifiableInterface());
			}
			return this;
		}
		public SDMX_STRUCTURE_TYPE sdmxStructure() {
			return structureType == null ? SDMX_STRUCTURE_TYPE.ANY : SDMX_STRUCTURE_TYPE.getTypeByClass(structureType.getClassType());
		}

		public URNBuilder maint(MaintainableBean maint) {
			urn = null;
			if(maint != null) {
				this.agencyId = maint.getAgencyId();
				this.maintId = maint.getId();
				this.version = maint.getVersion().toString();
				this.structureType= maint.getStructureClass();
			}
			return this;
		}
		public URNBuilder maint(IMultiMaintainableRef maint) {
			urn = null;
			if(maint != null) {
				this.agencyId = CollectionUtil.join(",", "", maint.getAgencyId());
				this.maintId = CollectionUtil.join(",", "", maint.getId());
				this.version = maint.getVersion().toString();
			}
			return this;
		}
		public URNBuilder maint(IMaintainableRef mRef) {
			urn = null;
			if(mRef != null) {
				this.agencyId = mRef.getAgencyId();
				this.maintId = mRef.getMaintainableId();
				this.version = mRef.getVersion().toString();
			}
			return this;
		}
		public URNBuilder maint(IMaintainableProperties mProps) {
			urn = null;
			if(mProps != null) {
				this.agencyId = mProps.getAgencyId();
				this.maintId = mProps.getId();
				this.version = mProps.getVersion() != null ? mProps.getVersion().toString() : null;
			}
			return this;
		}
		public URNBuilder ref(StructureReferenceBean sRef) {
			urn = null;
			if(sRef != null) {
				agencyId(sRef.getAgencyId());
				maintId(sRef.getMaintainableId());
				versionRef(sRef.getVersion());
				identifableId(sRef.getFullId());
			}
			return this;
		}
		public URNBuilder ref(IMaintainableRef mRef) {
			urn = null;
			if(mRef != null) {
				agencyId(mRef.getAgencyId());
				maintId(mRef.getMaintainableId());
				versionRef(mRef.getVersion());
			}
			return this;
		}
		public URNBuilder agencyId(String agencyId) {
			urn = null;
			this.agencyId = agencyId;
			return this;
		}
		public String agencyId() {
			return this.agencyId;
		}

		public URNBuilder maintId(String maintId) {
			urn = null;
			//			if(maintId != null) {
			this.maintId = maintId; //.toUpperCase();  //to be consistent with MaintainableBean
			//			}
			return this;
		}
		public String maintId() {
			return this.maintId;
		}

		public URNBuilder version(String version) {
			urn = null;
			this.version = version;
			return this;
		}
		public String version() {
			return this.version;
		}

		public URNBuilder versionRef(IVersionRef version) {
			urn = null;
			return version(version == null ? null : version.toString());
		}
		public URNBuilder removeIdentifable() {
			urn = null;
			this.identifiableId = null;
			return this;
		}

		public URNBuilder identifableId(String fullId) {
			urn = null;
			this.identifiableId = fullId;
			return this;
		}
		public String identifableId() {
			return this.identifiableId;
		}
		public URNBuilder identifableId(String[] idParts) {
			urn = null;
			if(idParts == null || idParts.length == 0) {
				this.identifiableId = null;
			} else {
				if(idParts.length == 1) {
					this.identifiableId = idParts[0];
				} else {
					this.identifiableId = String.join(".", idParts);
				}
			}
			return this;
		}
	}
	/**
	 * Protected Constructor, the public static methods should be used to construct the URN
	 * @param sRef
	 * @param version
	 * @param urn
	 */
	protected URN(ISDMXStructureType<?, ?> structureType, IMaintainableRef ref, String identifiableID, String originalUrn) {
		this.structureType = structureType;
		this.urn = originalUrn;
		this.maintainableRef = ref;
		this.shortUrn = urn.split("=")[0];
		if(identifiableID != null && identifiableID.length() > 0) {
			this.fullIdentifiableId = identifiableID;
			if(identifiableID.contains(".")) {
				this.identifiableId = identifiableID.substring(identifiableID.lastIndexOf(".")+1);
			} else {
				this.identifiableId = identifiableID;
			}
		}
		this.sdmxType = SDMX_STRUCTURE_TYPE.getTypeByClass(structureType.getClassType());
	}

	public static IURN<?> changeAgencyId(IURN<?> urn, String newAgencyId) {
		return URN.builder(urn).agencyId(newAgencyId).build();
	}


	public static <T extends IdentifiableBean> IURNSingle<T> getInstanceSingle(Class<T> st, String urn) {
		return URN.builder(urn).buildSingle(st);
	}

	/**
	 * Builds either a URNWildcard, URNAbsolute or URNSemantic depending on the parameters present in the URN
	 * 
	 * Syntax example of the URN
	 *   urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=ECB:BSI(1.0)
	 * 
	 *  Prefix  = urn:sdmx:org.sdmx.infomodel.
	 *  Package = datastructure
	 *  Class   = Dataflow
	 *  Agency ID = ECB
	 *  Maintainable ID = BSI
	 *  Version = 1.0
	 * 
	 * @param urnStr
	 * @return a URN instance from the cache pool or built and cached
	 */
	public static IURN<?> getInstance(String urnStr, ISDMXStructureType<?, ?>... expectedType) {
		if(urnStr == null) {
			throw new IllegalArgumentException("urn can not be null");
		}
		SoftReference<IURN<?>> iurn = cache.get(urnStr);
		if(iurn == null) {
			urnStr = StringUtil.cleanString(urnStr);
			iurn = cache.get(urnStr);
		}
		IURN<?> urn = iurn == null ? null : iurn.get();
		if(urn == null) {
			//Parse URN
			String[] urnParts = urnStr.split("=");  // [0] urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow   [1] ECB:BSI(1.0)
			if(urnParts.length < 2) {
				throw new SdmxSemmanticException("URN '"+urnStr+"' is not well formed, missing '='");
			}
			if(urnParts.length > 2) {
				throw new SdmxSemmanticException("URN '"+urnStr+"' is not well formed, only on '=' expected");
			}
			String objectPart = urnParts[0];     //urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow
			String referencePart = urnParts[1];  //ECB:BSI(1.0) or ECB:BSI(1.0).SUBID.SUBID

			ISDMXStructureType<?, ?> structureType = getStructureType(objectPart);

			SDMX_STRUCTURE_TYPE sdmxType = SDMX_STRUCTURE_TYPE.getTypeByClass(structureType.getClassType());
			if(sdmxType != null) {
				//This step can change the URN, for example if it is a 2.1 URN to a Hierarhcy it will be upgraded to a 3.0 URN to a Hierarchy
				String validatedUrn = UrnUtil.validateURN(urnStr, sdmxType);
				if(!validatedUrn.equals(urnStr)) {
					return getInstance(validatedUrn, expectedType);
				}
			}

			StringBuilder sb = new StringBuilder();
			String agencyId = null;
			String maintId = null;
			String version = null;
			String identifiableId = null;

			char lastChar = 0;
			for(char c : referencePart.toCharArray()) {
				switch(c) {
				case ' ' :
					continue;  //strip
				case ':' :
					if(agencyId != null) {
						//agencyId has already been set! this means the URN has more then one ':' character
						throw new SdmxSemmanticException("URN syntax error '"+objectPart+"' expected AgencyId:MaintId(version)");
					}
					//Agency part is complete
					agencyId = sb.toString();
					sb = new StringBuilder();
					break;
				case '[' :
					c = CHARS.OPEN_PARENTHESIS.getChar(); //Update the char from the '[' char to the '(' char
					//Fall into the next case statement
				case '(' :
					if(agencyId == null) {
						//The agency ID should have been set before the '(' of the version
						throw new SdmxSemmanticException("URN syntax error '"+objectPart+"' expected AgencyId:MaintId(version)");
					}
					if(maintId != null) {
						//maintId has already been set! this means the URN has more then one '(' character
						throw new SdmxSemmanticException("URN syntax error '"+objectPart+"' expected AgencyId:MaintId(version)");
					}

					//maintainable part is now complete
					maintId = sb.toString().toUpperCase();
					sb = new StringBuilder();
					break;
				case ']' :
					c = CHARS.CLOSE_PARENTHESIS.getChar(); //Update the char from the ']' char to the ')' char
				case ')' :
					if(maintId == null) {
						//The maint ID should have been set before the ')' of the version
						throw new SdmxSemmanticException("URN syntax error '"+objectPart+"' expected AgencyId:MaintId(version)");
					}
					if(version != null) {
						//version has already been set! this means the URN has more then one ')' character
						throw new SdmxSemmanticException("URN syntax error '"+objectPart+"' expected AgencyId:MaintId(version)");
					}
					//maintainable part is now complete
					version = sb.toString();
					sb = new StringBuilder();
					break;
				default :
					if(c == CHARS.PERIOD.getChar()) {
						//This might be the separator between the version and the identifiable ID, in which case we don't need it in the StringBuilder
						//It could also be used to indicate sub agency, or sub-identifble ID in which case we do need it in the StringBuilder
						if(lastChar == CHARS.CLOSE_PARENTHESIS.getChar()) {
							continue;
						}
					}
					//Commented this out as the * is required at the end of a version string, i.e. 1.1.*
					//If maintId=* it will be dropped
					//					if(c == CHARS.STAR.getChar()) {
					//						continue;
					//					}
					sb.append(c);
					break;
				}
				lastChar = c;
			}
			identifiableId = sb.toString();
			IMaintainableRef maintainableRef = MaintainableRef.getInstance(agencyId, maintId, version);
			boolean hasMultiple = maintainableRef.hasAgencyId() && maintainableRef.getAgencyId().contains(",") ||
					maintainableRef.hasMaintainableId() && maintainableRef.getMaintainableId().contains(",") ||
					identifiableId != null && identifiableId.contains(",");

			boolean wildcard = maintainableRef.isWildcard() || URN.URN_WILDCARD.equals(identifiableId) || structureType.isAny();
			if(!wildcard && structureType.isAbstract()) {
				//If the abstract type has multiple possible subtypes then it is a URNMultiple - i.e. ComponentBean can resolve
				//to a MSD Component or a DSD Component
				if(structureType.isMaintainable()) {
					IMaintainableStructureType<?> maintSt = (IMaintainableStructureType<?>) structureType;
					wildcard = StructureTypes.getConcreteMaintStructureTypes(maintSt).size() > 1;
				} else if (structureType.getMaintainableStructureType() == MaintainableSDMXStructureType.ANY) {
					wildcard = true;
				}
			}
			if(hasMultiple) {
				urn = new URNMultiple(structureType, maintainableRef, identifiableId, urnStr);
			} else if(wildcard) {
				urn = new URNWildcard(structureType, maintainableRef, identifiableId, urnStr);
			} else if(maintainableRef.getVersion().isAbsolute()) {
				if(structureType.isMaintainable()) {
					urn = new URNMaintainable((IMaintainableStructureType)structureType, maintainableRef, identifiableId, urnStr);
				} else {
					urn = new URNAbsolute(structureType, maintainableRef, identifiableId, urnStr);
				}
			} else {
				urn = new URNSemantic(structureType, maintainableRef, identifiableId, urnStr);
			}
			iurn = new SoftReference<>(urn);
			cache.put(urnStr, iurn);
		}
		if(expectedType != null && expectedType.length > 0) {
			for(ISDMXStructureType<?, ?> type : expectedType) {
				if(type.matchesType(urn)) {
					return urn;
				}
			}
			throw new SdmxSemmanticException("URN '"+urnStr+"' is not of expected type");
		}
		return urn;
	}

	@Override
	public String getAgencyId() {
		return maintainableRef.getAgencyId();
	}
	@Override
	public String getMaintainableId() {
		return maintainableRef.getMaintainableId();
	}
	@Override
	public IVersionRef getVersion() {
		return maintainableRef.getVersion();
	}
	@Override
	public StructureReferenceBean asMutable() {
		return new StructureReferenceBeanImpl(this);
	}

	private static ISDMXStructureType getStructureType(String objectPart) {
		String[] objectPartSplit = objectPart.split("\\.");
		if(objectPartSplit.length < 3) {
			throw new SdmxSemmanticException("URN prefix '"+objectPart+"' is not well formed, URN prefix expected to contain 'prefix.package.class' example urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow");
		}

		String className = objectPartSplit[objectPartSplit.length-1];
		String packageName = objectPartSplit[objectPartSplit.length-2];
		StringBuilder urnPrefixSb = new StringBuilder();
		for(int i=0; i < objectPartSplit.length -2; i++) {
			urnPrefixSb.append(objectPartSplit[i]+".");
		}
		String urnPrefix = urnPrefixSb.toString();

		return StructureTypes.getStructureType(urnPrefix, packageName, className);
	}

	@Override
	public String getURN() {
		return urn;
	}

	@Override
	public IURN<? extends MaintainableBean> getMaintainableURN() {
		return getStructureType().isMaintainable() ? (IURN<? extends MaintainableBean>) this :
			(IURN<? extends MaintainableBean>) URN.builder().structure(getStructureType().getMaintainableStructureType())
			.agencyId(getAgencyId())
			.maintId(getMaintainableId())
			.versionRef(getVersion()).build();
	}


	@Override
	public SDMX_STRUCTURE_TYPE getSdmxStructure() {
		return this.sdmxType;
	}

	@Override
	public ISDMXStructureType getStructureType() {
		return structureType;
	}

	@Override
	public String getIdentifiableId() {
		return identifiableId;
	}

	@Override
	public String getFullIdentifiableId() {
		return fullIdentifiableId;
	}

	@Override
	public String getShortURN() {
		return this.shortUrn;
	}

	@Override
	public int hashCode() {
		return getURN().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof IURN) {
			IURN that = (IURN) obj;
			if(!ObjectUtil.equivalent(this.getURN(), that.getURN())) {
				return false;
			}
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return this.getURN();
	}

	@Override
	public String toURNString() {
		return this.getURN();
	}

}
