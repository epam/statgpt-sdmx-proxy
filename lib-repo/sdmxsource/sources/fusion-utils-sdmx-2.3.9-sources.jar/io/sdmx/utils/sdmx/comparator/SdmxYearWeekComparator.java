package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

/**
 * An intentionally simple comparator that compares 2 Strings which are expected to be in the SDMX Week format
 * e.g. 2020-W52
 * This exists so that a date like 2020-W10 comes before 2020-W9
 */
public class SdmxYearWeekComparator implements Comparator<String> {

    @Override
    public int compare(String s1, String s2) {
        try {
            // In Weekly data the "W" will always be the sixth character
            if (s1.charAt(5) == 'W' && s2.charAt(5) == 'W') {
                // Compare the first 4 characters if they are not the same then use a String comparison on the numbers. This will work since they MUST be 4 digits
                String year1 = s1.substring(0, 4);
                String year2 = s2.substring(0, 4);
                int res = year1.compareTo(year2);
                if (res != 0) {
                    // Years are not the same
                    return res;
                }
                // The years are the same, so compare just the numeric values after the W
                Integer i1 = Integer.parseInt( s1.substring(6) );
                Integer i2 = Integer.parseInt( s2.substring(6) );
                return i1.compareTo(i2);
            }
        } catch (Exception e) {
            // Intentionally do nothing - if anything goes wrong defer to String comparator
        }

        return s1.compareTo(s2);
    }
}
