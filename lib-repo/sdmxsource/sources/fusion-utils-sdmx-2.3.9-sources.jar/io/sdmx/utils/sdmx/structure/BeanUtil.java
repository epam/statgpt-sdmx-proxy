package io.sdmx.utils.sdmx.structure;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;

public class BeanUtil {

	/**
	 * Returns true if:
	 * <ul>
	 *   <li>Both Strings are null</li>
	 *   <li>Both Strings are equal</li>
	 * </ul>
	 * @param o1
	 * @param o2
	 * @return
	 */
	public static boolean equivalentBean(SDMXBean o1, SDMXBean o2) {
		if(o1 == null && o2 == null) {
			return true;
		}
		if(o1 == null && o2 != null) {
			return false;
		}
		if(o2 == null && o1 != null) {
			return false;
		}

		return o1.deepEquals(o2, true);
	}

}
