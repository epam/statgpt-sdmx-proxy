package io.sdmx.utils.sdmx.xs;

import java.util.Map;
import java.util.WeakHashMap;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * A reference to a specific version or range of versions of artifacts, using the semantic versioning syntax
 */
public class VersionRef implements IVersionRef {
	private static final long serialVersionUID = 1L;
	private static Map<String, VersionRef> refMap = new WeakHashMap<>();
	public static final IVersionRef ALL = new VersionRef("*");  //This must come AFTER the refMap has been assigned to prevent NPE
	//A version which includes + (latest) must only match stable versions, i.e 3 part semantic with no draft
	
	/**
	 * '+' This matches the latest available stable semantic version of an artefact in
	 *   form of x.y.z where x > 0. It is equivalent to querying for: +.0.0 or 1+.0.0
	 */
	public static final IVersionRef LATEST = new VersionRef("1+.0.0");  //This must come AFTER the refMap has been assigned to prevent NPE
	
	public static final IVersionRef LATEST_ANY = new VersionRef("~");  //This must come AFTER the refMap has been assigned to prevent NPE
	
	
	
	private String versionRef;
	private boolean isAll = false;
	private boolean isLatest = false;
	private boolean isAbsolute = true;
	private String versionSuffix;
	private boolean allSuffix = false;
	private ISdmxVersion minVersion;
	private ISdmxVersion maxVersion;
	
	/**
	 * Returns a version which references the latest minor, from a given major /minor starting point
	 * e.g. latest minor from 1.2 would be 1.2+.0
	 * @param major
	 * @param minor
	 * @param patch
	 * @return
	 */
	public static IVersionRef getLatestMinorReference(int major, int minor) {
	    String version = major + "." +minor + "+.0";
	    return getInstance(version);
	}
	
	public static IVersionRef getInstance(String versionRef) {
		if(!ObjectUtil.validString(versionRef) || versionRef.equals("*")) {
			return VersionRef.ALL;
		}
		if(versionRef.startsWith("+")) {
			if(versionRef.length() == 1 || versionRef.equals("+.0.0")) {
				return LATEST;
			} 
			throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"'. Expected '+.0.0' or '+' to indicate latest major version");
		} else if(versionRef.equals("~")) {
			return LATEST_ANY;
		}
		synchronized(refMap) {
			VersionRef instance = refMap.get(versionRef);
			if(instance == null) {
				instance = new VersionRef(versionRef);
				refMap.put(versionRef, instance);
			}
			return instance;
		}
	}

	/**
	 * Syntax 2 part:
	 * <ol>
	 *   <li><b>1.+</b> latest stable 1.x, e.g. 1.4</li>
	 *   <li><b>1.~</b> latest 2 part stable or draft  1.x, e.g. 1.4-draft</li>
	 *   <li><b>1.*</b> all 1.x versions, e.g. 1.0, 1.1, 1.2</li>
	 * </ol>
	 * 
	 * Syntax 3 part only stable:
	 * <ol>
	 *   <li><b>1.2.0</b>  explicit reference</li>
	 *   <li><b>+</b>latest stable version</li>
	 *   <li><b>1.2.+</b> latest stable 1.2.x</li>
	 * </ol>
	 * 
	 * Syntax 3 part stable or unstable:
	 * <ol>
	 *   <li><b>~</b>latest stable or draft version</li>
	 *   <li><b>1.~.0</b> latest 3 part stable or draft  1.x.x</li>
	 *   <li><b>1.2.~</b> latest stable or draft 1.2.x</li>
	 * </ol>
	 * 
	 * Syntax 3 all:
	 * <ol>
	 *   <li><b>*</b>all stable or draft version, e.g. 1.0, 1.0.0, 1.1.0-draft </li>
	 *   <li><b>1.2.*</b> all 3 part versions, 1.2.0, 1.2.2, 1.2.1</li>
	 *   <li><b>1.*.0</b> minimum version 1.0.0 with a 1 major, e.g. 1.0.0, 1.1.0, 1.2.0, 1.2.1, 1.2.2, 1.3.0 and 1.3.1-draft</li>
	 *   <li><b>1.2*.0</b> minimum version 1.2.0 with a 1 major, e.g. 1.2.0, 1.2.1, 1.2.2, 1.3.0 and 1.3.1-draft</li>
	 * </ol>
	 * 
	 * 
	 * @param versionRef
	 */
	private VersionRef(String versionRef) {
		this.versionRef = versionRef;
		
		String[] suffixSplit = versionRef.split("-", 2);

		this.versionSuffix = suffixSplit.length > 1 ? suffixSplit[1] : null;

		int[] fromVersion = new int[3];
		int[] toVersion = new int[3];
		for(int i=0; i < 3; i++) {  //initialise arrays to -1
			fromVersion[i] = -1;
			toVersion[i] = -1;
		}

		String versionPart = suffixSplit[0];
		if(versionPart.equals("~") || versionPart.equals("*")) {
			isAbsolute = false;
			allSuffix = true;
			versionSuffix = "*";  		 //not stable only, so any version suffix
			isLatest = !versionPart.endsWith("*");
			isAll = !isLatest;

			String suffix = this.versionSuffix == null || this.versionSuffix.equals("*") ? null : this.versionSuffix;
			this.minVersion = SdmxVersion.getInstance(0, 0, -1, suffix);
			this.maxVersion = SdmxVersion.getInstance(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, suffix);
		} else {
			//multipart reference
			String[] versionSplit = suffixSplit[0].split("\\.");
			if(versionSplit.length > 3) {
				throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"' a maximum of 3 parts expected, where each part is separated by a period seperator");
			}
			for(int i=0; i < versionSplit.length; i++) {
				String part = versionSplit[i];
				if(part.endsWith("+") || part.endsWith("~") || part.endsWith("*")) {
					isAbsolute = false;
					if(!part.endsWith("+")) { //stable only
						allSuffix = true;
						versionSuffix = "*";    	 //not stable only, so any version suffix
					} else if(versionSplit.length != 3) {
						throw new SdmxSemmanticException("Illegal version '"+versionRef+"', the '+' can only be used with 3 part versions");
					}
					isLatest = !part.endsWith("*");
					fromVersion[i] = part.length() > 1 ? Integer.parseInt(part.substring(0, part.length()-1)) : 0;
					toVersion[i] = Integer.MAX_VALUE;
					i++;
					while(i < versionSplit.length) {
						if(!NumberUtils.isInteger(versionSplit[i], true)) {
							throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"'");
						}
						
						Integer reportedVersion = Integer.parseInt(versionSplit[i]);
						if(reportedVersion != 0) {
							throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"'"); 
						}
						fromVersion[i] = 0;
						toVersion[i] = Integer.MAX_VALUE;
						i++;
					}
				} else if(!NumberUtils.isInteger(part, false)) {
					throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"'");
				} else {
					try {
						int parsedInt = Integer.parseInt(versionSplit[i]);
						fromVersion[i] = parsedInt;
						toVersion[i] = parsedInt;
					} catch(NumberFormatException e) {
						throw new SdmxSemmanticException("Illegal version reference '"+versionRef+"'");
					}
				}
			}
			String suffix = this.versionSuffix == null || this.versionSuffix.equals("*") ? null : this.versionSuffix;
			this.minVersion = SdmxVersion.getInstance(fromVersion[0], fromVersion[1], fromVersion[2], suffix);
			this.maxVersion = SdmxVersion.getInstance(toVersion[0], toVersion[1], toVersion[2], suffix);
		}
	}

	@Override
	public boolean isLatest() {
		return isLatest;
	}

	@Override
	public boolean isAbsolute() {
		return isAbsolute;
	}
	
	@Override
	public boolean isAll() {
		return isAll;
	}

	@Override
	public String getVersionSuffix() {
		return versionSuffix;
	}

	@Override
	public ISdmxVersion getMinVersion() {
		return minVersion;
	}

	@Override
	public ISdmxVersion getMaxVersion() {
		return maxVersion;
	}

	@Override
	public boolean isMatch(ISdmxVersion version) {
		if(isAll || this == LATEST_ANY) {
			return true;
		}
		if(versionSuffix == null && version.getSuffix() != null) {
			return false;
		}
		if(versionSuffix != null && !allSuffix && !versionSuffix.equals(version.getSuffix())) {
			return false;
		}
		
		
		//a three part minimum version does not match a 2 part version
		if (this.minVersion.getPatch() >= 0 && version.getPatch() < 0) {
			return false;
		}
		//a three part version does not match on a 2 part version reference
		if (version.getPatch() >=0 && minVersion.getPatch() < 0) {
			return false;
		}

		//Check Major
		if((version.getMajor() < this.minVersion.getMajor()) || (version.getMajor() > this.maxVersion.getMajor())) {
			return false;
		}
		//If major versions match, check minor version is not out of range
		if(version.getMajor() == this.minVersion.getMajor()) {
			//Check Minor
			if((version.getMinor() < this.minVersion.getMinor()) || (version.getMinor() > this.maxVersion.getMinor())) {
				return false;
			}
		}
		//If minor versions match check patch version is not out of range
		if(version.getMinor() == this.minVersion.getMinor()) {
			// Absolute values must match on all the elements
			if (this.minVersion.getPatch() >= 0 &&  ((version.getPatch() < this.minVersion.getPatch()) || (version.getPatch() > this.maxVersion.getPatch()))) {
				return false;
			}
		} 
		return true;
	}

	@Override
	/**
	 * As both this version and that version can have a range (i.e. 1.2.0 -> 1.[any].[any]) or a fixed version,
	 * this method returns true if there is any overlap, ie. 1.2.[any] with 1.[any].[any].
	 */
	public boolean isMatch(IVersionRef vRef) {
		if(isAll || vRef.isAll()) {
			return true;
		}
		String thatSuffix = vRef.getVersionSuffix();
		String thisSuffix = getVersionSuffix();
		
		if(!ObjectUtil.equivalent(thatSuffix, thisSuffix)) {
		    //Suffix do not match, this is only allowed if one is a *
		    if(!"*".equals(thisSuffix) && !"*".equals(thatSuffix)) {
		        return false;
		    }
		}
		
		ISdmxVersion min1 = vRef.getMinVersion();
		ISdmxVersion max1 = vRef.getMaxVersion();
		
		ISdmxVersion min2 = this.getMinVersion();
        ISdmxVersion max2 = this.getMaxVersion();
        
        
		return hasOverlap(min1.getMajor(), max1.getMajor(), min2.getMajor(), max2.getMajor()) &&
		        hasOverlap(min1.getMinor(), max1.getMinor(), min2.getMinor(), max2.getMinor()) &&
		        hasOverlap(min1.getPatch(), max1.getPatch(), min2.getPatch(), max2.getPatch());
	}
	
	/**
	 * Returns true if the min1 - max1 range has an overlap with min2 - max2 for example
	 * 2-4 with 1-1=false (RHS lower then min)
	 * 1-1 with 2-4=false (LHS lower then min)
     * 
     * 1-3 with 2-4=true (LHS inside on the min)
     * 2-4 with 1-3=true (RHS inside on the min)
     * 
	 * 4-8 with 5-6=true  (LHS fully inside)
     * 5-6 with 4-8=true  (RHS fully inside)
     * 
     * 4-6 with 2-5=true (LHS inside on the max)
     * 2-5 with 4-6=true (RHS inside on the max)
     * 
     * First determine if the min or max are equal, if yes then there is an overlap
     * Then take the lowest min and assign this pair as lMin,lMax with the other pair hMin, hMin
     * We know lMin is lower then hMin, check if lMax is greater hMin, to see if it overlaps if it does it covers all possible
     * overlaps (LHS, RHS and full)

	 * @param min1
	 * @param min2
	 * @param max1
	 * @param max2
	 * @return
	 */
	private boolean hasOverlap(int min1, int max1, int min2, int max2) {
	    if(min1 == min2 || max1 == max2) {
	        return true;
	    }
	    int lMax, hMin;
	    if(min1 < min2) {
	        lMax = max1; hMin = min2;
	    } else {
	        lMax = max2; hMin = min1;
	    }
	    return lMax >= hMin;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof VersionRef) {
			return obj.toString().equals(this.toString());
		}
		return false;
	}

	@Override
	public int hashCode() {
		return versionRef.hashCode();
	}

	@Override
	public String toString() {
		return versionRef;
	}
}
