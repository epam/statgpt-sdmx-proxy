package io.sdmx.utils.sdmx.structure;

import java.util.Date;

public class HeaderUtil {
	private static int i = 0;
	private static int j = 0;
	
	/**
	 * Generates an IREF for the Header Id which is compliant with the EDI Specification, i.e
	 * IREF number should be 10 characters like IREFXXXXXX
	 * @return
	 */
	public synchronized static String generateIREF() {
		Long timeNow = new Date().getTime();
		String asString = timeNow.toString();
		//Example time 1566901778083
		//Extract the period '0177' from the string, this is tens, hundreds, thousands, hundred thousands of seconds 
		String last4 = asString.substring(5, 9);
		
		//i and j combined will be a number between 00 and 99 inclusive
		j++;
		if(j > 9) {
			j = 0;
			i++;
			if(i > 9) {
				i = 0;
			}
		}
		
		return "IREF"+last4+i+j;
	}
}
