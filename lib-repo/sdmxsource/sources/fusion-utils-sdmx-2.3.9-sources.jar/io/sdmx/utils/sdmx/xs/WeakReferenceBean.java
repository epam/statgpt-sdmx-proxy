package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * A weak reference is a reference which is made by pattern matching - for example a constraint can reference any code which includes the term AA.
 * A weak reference is created for all matching codes, but these references should not preclude the deletion of a code in the codelist
 */
public class WeakReferenceBean<T extends IdentifiableBean> extends CrossReferenceBean<T> {
	private static final long serialVersionUID = 1L;
	private boolean isIndirect;

	public WeakReferenceBean(IdentifiableBean referencedFrom, boolean isIndirect, IURNSingle<T> urn) {
		super(referencedFrom, urn);
		this.isIndirect = isIndirect;
	}
	
	@Override
	public boolean isWeakReference() {
		return true;
	}

	@Override
	public boolean isIndirectReference() {
		return isIndirect;
	}
	
	@Override
	public String toString() {
		return "Weak Cross Reference : " + getReference().getURN();
	}
}
