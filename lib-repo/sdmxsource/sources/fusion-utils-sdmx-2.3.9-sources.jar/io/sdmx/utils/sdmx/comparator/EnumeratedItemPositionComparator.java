package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;

/**
 * Comparator based on position of code / value item, in the parent list
 *
 */
public class EnumeratedItemPositionComparator implements Comparator<EnumeratedItemBean> {
	public static final EnumeratedItemPositionComparator INSTANCE = new EnumeratedItemPositionComparator();
	
	private EnumeratedItemPositionComparator() {};

	@Override
	public int compare(EnumeratedItemBean o1, EnumeratedItemBean o2) {
		return o1.getPosition() - o2.getPosition();
	}
}
