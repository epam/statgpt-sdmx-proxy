package io.sdmx.utils.sdmx.structure;

import java.io.ObjectStreamException;

import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class MaintainableSDMXStructureType<T extends MaintainableBean> extends AbstractStructureType<T, T> implements IMaintainableStructureType<T> {
    private static final long serialVersionUID = 1L;
    private Class<T> maintainableType;

    public static final IMaintainableStructureType<?> ANY = new MaintainableSDMXStructureType<>(MaintainableBean.class, "base", "Any", null, null, "Any");

    public static <T extends MaintainableBean> MaintainableSDMXStructureType<T> getInstance(Class<T> maintType,
            String urnPackage,
            String urnClass) {
        return getInstance(maintType, urnPackage, urnClass, urnClass); //urnClass is the same as the asString
    }

    public static <T extends MaintainableBean> MaintainableSDMXStructureType<T> getInstance(Class<T> maintType,
            String urnPackage,
            String urnClass,
            String asString) {
        return new MaintainableSDMXStructureType<T>(maintType, urnPackage, urnClass, null, null, asString);
    }

    public static <T extends MaintainableBean> MaintainableSDMXStructureType<T> getInstance(Class<T> maintType,
            String urnPackage,
            String urnClass,
            String fixedId, String fixedVersion,
            String asString) {
        return new MaintainableSDMXStructureType<T>(maintType, urnPackage, urnClass, fixedId, fixedVersion, asString);
    }

    private MaintainableSDMXStructureType(Class<T> maintType,
            String urnPackage,
            String urnClass,
            String fixedId, String fixedVersion,
            String asString) {
        super(URN_INFOMODEL_PREFIX, urnClass, urnPackage, fixedId, fixedVersion, asString);
        this.maintainableType = maintType;
    }

    @Override
    public boolean isAny() {
        return this == ANY;
    }

    @Override
    public Class<T> getClassType() {
        return maintainableType;
    }

    @Override
    public Class<T> getMaintainableType() {
        return maintainableType;
    }

    @Override
    public IMaintainableStructureType<T> getMaintainableStructureType() {
        return this;
    }

    /**
     * Deserialisation behaviour
     * @return
     * @throws ObjectStreamException
     */
    private Object readResolve() throws ObjectStreamException {
        // Return the canonical instance instead of this newly deserialized one
        IMaintainableStructureType<?> type = StructureTypes.getMaintStructureType(this.getMaintainableType());
        if(type != null) {
            return type;
        }
        return this;
    }

}
