package io.sdmx.utils.sdmx.application;

import java.util.Objects;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONString;

import io.sdmx.api.application.FusionProductPlugin;
import io.sdmx.api.exception.SdmxException;

public class FusionProductPluginImpl implements FusionProductPlugin, JSONString {
	private String pluginName;
	private Integer[] pluginCommsVersion;
	
	public FusionProductPluginImpl(String pluginName, Integer[] pluginCommsVersion) {
		this.pluginName = pluginName;
		this.pluginCommsVersion = pluginCommsVersion;
	}

	public FusionProductPluginImpl(JSONObject json) {
		Objects.requireNonNull(json, "FusionProductPlugin: JSONObject is required");
		try {
			if(json.has("PluginName")) {
				this.pluginName = json.getString("PluginName");
			}
			if(json.has("CommsVersions")) {
				JSONArray commsVersions = json.getJSONArray("CommsVersions");
				this.pluginCommsVersion = new Integer[commsVersions.length()];
				for(int i = 0; i < commsVersions.length(); i++) {
					this.pluginCommsVersion[i] = commsVersions.getInt(i);
				}
			}
		} catch (JSONException e) {
			throw new SdmxException(e, "Could not read FusionProductPluginImpl from JSON: " +  json.toString());
		}
	}
	
	@Override
	public String getPluginName() {
		return pluginName;
	}

	@Override
	public Integer[] getPluginCommsVersion() {
		return pluginCommsVersion;
	}

	@Override
	public String toJSONString() {
		JSONObject json = new JSONObject();
		try {
			json.put("PluginName", pluginName);
			JSONArray comsVersions = new JSONArray();
			
			for(Integer comVersion : pluginCommsVersion) {
				comsVersions.put(comVersion);
//				json.append("CommsVersions", comVersion);
			}
			json.put("CommsVersions", comsVersions);
		} catch (JSONException e) {
			throw new SdmxException(e, "Error attempting to write FusionProductPlugin");
		}
		return json.toString();
	}

	@Override
	public String toString() {
		return toJSONString();
	}
	
}
