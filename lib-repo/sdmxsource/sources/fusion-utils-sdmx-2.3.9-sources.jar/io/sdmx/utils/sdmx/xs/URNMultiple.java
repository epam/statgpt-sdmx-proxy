package io.sdmx.utils.sdmx.xs;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNMultiple;
import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.collection.CollectionUtil;

public class URNMultiple extends URN implements IURNMultiple {
	private IMultiMaintainableRef multiMaintainableRef;
	private Set<String> identifiableIds;
	
	/**
	 * Package protected, constructed via the URN.getInstance method
	 */
	URNMultiple(ISDMXStructureType structureType, IMaintainableRef ref, String identifiableId, String urn) {
		super(structureType, ref, identifiableId, urn);
		
		multiMaintainableRef = new MultiMaintainableRef(ref);
		if(identifiableId == null || identifiableId.equals("*")) {
			this.identifiableIds = Collections.emptySet();
		} else {
			identifiableIds = Collections.unmodifiableSet(CollectionUtil.arrayToSet(identifiableId.split(",")));
		}
	}
	
	@Override
	public IMultiMaintainableRef getMutltiReference() {
		return multiMaintainableRef;
	}

	@Override
	public Set<String>  getIdentifiableIds() {
		return identifiableIds;
	}
	
}
