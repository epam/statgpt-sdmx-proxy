package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;

/**
 * This class represents a resolved cross reference, which is a cross reference which has been resolved to one specific URN (no semantic versioing)
 * @param <T>
 */
@SuppressWarnings("rawtypes")
public class ResolvedCrossReferenceBean<T extends IdentifiableBean> implements ICrossReferenceBeanResolved {
	private static final long serialVersionUID = 1L;
	private IURNAbsolute<T> urn;
	private ICrossReferenceBean<T> baseReference;
	private T identifiableBean;
	
	@SuppressWarnings({"unchecked"})
	public static ResolvedCrossReferenceBean build(ICrossReferenceBean<?> baseReference, IdentifiableBean identifiableBean) {
		return new ResolvedCrossReferenceBean(baseReference, identifiableBean);
	}
	
	@SuppressWarnings("unchecked")
	ResolvedCrossReferenceBean(ICrossReferenceBean<T> baseReference, T identifiableBean) {
		this.baseReference = baseReference;
		this.urn = (IURNAbsolute<T>) identifiableBean.getURN();
		this.identifiableBean = identifiableBean;
	}

	@Override
	public IdentifiableBean getReferencedFrom() {
		return baseReference.getReferencedFrom();
	}

	@Override
	public IURNAbsolute<T> getReference() {
		return urn;
	}
	
	@Override
	public IdentifiableBean getResolvedBean() {
		return identifiableBean;
	}

	@Override
	public boolean isIndirectReference() {
		return baseReference.isIndirectReference();
	}

	@Override
	public boolean isWeakReference() {
		return baseReference.isWeakReference();
	}

	/**
	 * @return the underlying cross reference for which this absolute cross reference was built
	 */
	@Override
	public ICrossReferenceBean<T> getBaseReference() {
		return baseReference;
	}

	@Override
	public String toString() {
		return "From '"+baseReference.getReferencedFrom()+"' to " + getReference().getURN();
	}
}
