package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.constants.VERSION_PART;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;

public class SdmxVersionUtil {

	/**
	 * Increments the version by the part to give the next version, i.e.
	 * <ul>
	 *  <li>a major version increment on 1.2.3 would return 2.0.0</li>
	 *  <li>a minor version increment on 1.2.3 would return 1.3.0</li>
	 *  <li>a patch version increment on 1.2.3 would return 1.2.4</li>
	 * </ul>  
	 * 
	 * 
	 * @param version
	 * @param part
	 * @return
	 */
	public static ISdmxVersion incrementVersion(ISdmxVersion version, VERSION_PART part) {
		if(part == null) {
			return version;
		}
		int major = version.getMajor();
		int minor = version.getMinor();
		int patch = version.getPatch();
		
		switch(part) {
		case MAJOR:
			++major;
			minor = 0;
			patch = 0;
			break;
		case MINOR:
			++minor;
			patch = 0;
			break;
		case PATCH:
			++patch;
			break;
		}
		
		return SdmxVersion.getInstance(major, minor, patch);
	}
	
}
