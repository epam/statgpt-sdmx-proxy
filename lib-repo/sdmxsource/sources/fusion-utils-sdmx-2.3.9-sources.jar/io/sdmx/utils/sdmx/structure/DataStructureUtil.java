package io.sdmx.utils.sdmx.structure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public class DataStructureUtil {

	public static String getTimeConcept(DataStructureBean dataStructureBean) {
		if(dataStructureBean.getTimeDimension() != null) {
			return dataStructureBean.getTimeDimension().getId();
		}
		return null;
	}


	public static List<String> getMeasureConcepts(DataStructureBean dataStructureBean) {
		return dataStructureBean.getMeasures().stream().map(IdentifiableBean::getId).collect(Collectors.toList());
	}

	/**
	 * Returns the series key concepts.
	 * @param dataStructureBean
	 * @return
	 */
	public static  List<String> getSeriesKeyConcepts(DataStructureBean dataStructureBean) {
		List<String> keyConcepts = new ArrayList<>();
		for(DimensionBean currentDimension : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
			keyConcepts.add(currentDimension.getId());
		}
		return keyConcepts;
	}
	
	/**
	 * Returns the concept id's belonging to each series attributes in the order they appear in the DataStructureBean,
	 * followed by the concept id's belonging to each group attributes in the order of the groups,
	 * and attributes within each group.
	 * 
	 * A concept id will not be added to the list twice, so if a concept id appears in a series attribute
	 * and a group attribute, then the first occurrence will be added to the list, which will be the series
	 * attribute, the second occurrence will not be added.
	 * @param dataStructureBean
	 * @return
	 */
	public static  List<String> getSeriesAndGroupAttributeConcepts(DataStructureBean dataStructureBean) {
		List<String> attributeConcepts = new ArrayList<>();
		if(dataStructureBean.getDimensionGroupAttributes() != null) {
			for(AttributeBean currentAttribute : dataStructureBean.getDimensionGroupAttributes()) {
				attributeConcepts.add(currentAttribute.getId());
			}
			for(AttributeBean currentAttribute : dataStructureBean.getGroupAttributes()) {
				if(!attributeConcepts.contains(currentAttribute.getId())) {
					attributeConcepts.add(currentAttribute.getId());
				}
			}
		}
		return attributeConcepts;
	}
	
	/**
	 * Returns the concepts of all the dimensions and attributes that are not attached at the observation level.
	 * @param dataStructureBean
	 * @return
	 */
	public static List<String> getSeriesAttributeConcepts(DataStructureBean dataStructureBean) {
		List<String> keyConcepts = new ArrayList<>();
		for(AttributeBean currentBean : dataStructureBean.getDimensionGroupAttributes()) {
			keyConcepts.add(currentBean.getId());
		}
		return keyConcepts;
	}
	
	/**
	 * Returns the group id, along with a list of concepts that belong to the group key.
	 * @param dataStructureBean
	 * @return
	 */
	public static Map<String, List<String>> getGroupConcepts(DataStructureBean dataStructureBean) {
		Map<String, List<String>> returnMap = new HashMap<>();
		if(dataStructureBean.getGroups() != null) {
			for(GroupBean currentBean : dataStructureBean.getGroups()) {
				returnMap.put(currentBean.getId(), currentBean.getDimensionRefs());
			}
		}
		return returnMap;
	}
	
	/**
	 * Returns the concepts of all the dimensions and attributes that are not attached at the observation level.
	 * @param dataStructureBean
	 * @return
	 */
	public static List<String> getGroupAttributeConcepts(DataStructureBean dataStructureBean) {
		List<String> keyConcepts = new ArrayList<>();
		for(AttributeBean currentBean : dataStructureBean.getGroupAttributes()) {
			keyConcepts.add(currentBean.getId());
		}
		return keyConcepts;
	}
	
	/**
	 * Returns the observation concepts including the measure concept,
	 * and all the attribute concepts that are attached to the observation.
	 * The measure concept is always the first concept in the list, the others are added in the order they appear
	 * in the DataStructureBean.
	 * @param dataStructureBean
	 * @return
	 */
	public static List<String> getObservationConcepts(DataStructureBean dataStructureBean) {
		List<String> obsConcepts = getObservationAttributeConcepts(dataStructureBean);
		obsConcepts.addAll(0, getMeasureConcepts(dataStructureBean));
		return obsConcepts;
	}

	public static List<String> getObservationAttributeConcepts(DataStructureBean dataStructureBean) {
		List<String> obsConcepts = new ArrayList<>();
		if(dataStructureBean.getAttributes() != null) {
			for(AttributeBean currentAttribute : dataStructureBean.getAttributes()) {
				String conceptId = currentAttribute.getId();
				if(currentAttribute.getAttachmentLevel()== ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION) {
					if(!obsConcepts.contains(conceptId)) {
						obsConcepts.add(conceptId);
					}
				}
			}
		}
		return obsConcepts;
	}
	
	/**
	 * Returns an EnumeratedList from the specified component from the specified DataStructure if either the component is coded or has a concept which is coded.
	 * @param dataStructureBean
	 * @param componentId
	 * @param retrievalManager
	 * @return
	 */
	public static EnumeratedListBean getEnumeratedList(DataStructureBean dataStructureBean, String componentId, SdmxBeanRetrievalManager retrievalManager) {
		ComponentBean component = dataStructureBean.getComponent(componentId);
		if (component != null) {
			if(component.hasCodedRepresentation()) {
				ICrossReferenceBean<? extends EnumeratedListBean> codelistRef = component.getRepresentation().getRepresentation();
				return retrievalManager.getBean(codelistRef.getReference());
			} else {
				ConceptBean concept = retrievalManager.getBean(component.getConceptRef().getReference());
				if (concept != null && concept.hasCodedRepresentation()) {
					ICrossReferenceBean<? extends EnumeratedListBean> enumeratedRep = concept.getEnumeratedRepresentation();
					return retrievalManager.getBean(enumeratedRep.getReference());
				}
			}
		}
		return null;
	}
}
