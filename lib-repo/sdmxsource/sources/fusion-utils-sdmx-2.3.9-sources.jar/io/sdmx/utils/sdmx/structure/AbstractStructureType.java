package io.sdmx.utils.sdmx.structure;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class AbstractStructureType<K extends MaintainableBean, V extends IdentifiableBean> implements ISDMXStructureType<K, V> {
	protected static final String URN_INFOMODEL_PREFIX = "urn:sdmx:org.sdmx.infomodel.";
	
	private static final long serialVersionUID = 1L;
	private String urnPrefix;
	private String fixedId;
	private String fixedVersion;
	private String urnClass;
	private String urnPackage;
	private String toString;
	
	/**
	 * Minimum constructor
	 * @param urnPrefix
	 * @param urnClass
	 * @param urnPackage
	 * @param asString
	 */
	public AbstractStructureType(String urnPrefix, String urnClass, String urnPackage, String asString) {
		this.urnPrefix = urnPrefix;
		this.urnClass = urnClass;
		this.urnPackage = urnPackage;
		this.toString = asString;
	}

	/**
	 * Minimum constructor
	 * @param urnPrefix
	 * @param urnClass
	 * @param urnPackage
	 * @param asString
	 */
	public AbstractStructureType(String urnPrefix, String urnClass, String urnPackage, String fixedId, String fixedVersion, String asString) {
		this.urnPrefix = urnPrefix;
		this.urnClass = urnClass;
		this.urnPackage = urnPackage;
		this.toString = asString;
		this.fixedId = fixedId;
		this.fixedVersion = fixedVersion;
	}

	@Override
	public String getUrnNamespace() {
		return urnPrefix;
	}

	@Override
	public String getFixedId() {
		return fixedId;
	}

	@Override
	public String getFixedVersion() {
		return fixedVersion;
	}

	@Override
	public String getUrnClass() {
		return urnClass;
	}

	@Override
	public String getUrnPackage() {
		return urnPackage;
	}

	@Override
	public int hashCode() {
		return getHashCodeBuilder().build();
	}
	
	protected HashCodeBuilder getHashCodeBuilder() {
		HashCodeBuilder builder = new HashCodeBuilder(7, 31)
											.append(getMaintainableType().getCanonicalName())
											.append(this.getUrnClass())
											.append(this.getUrnPackage())
											.append(this.getUrnNamespace());
		if(getFixedId() != null) {
			builder.append(this.getFixedId());
		}
		if(getFixedVersion() != null) {
			builder.append(this.getFixedVersion());
		}
		return builder;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ISDMXStructureType) {
			ISDMXStructureType that = (ISDMXStructureType) obj;
			return  that.getMaintainableType() == this.getMaintainableType() &&
				    that.getUrnClass().equals(this.getUrnClass()) &&
					that.getUrnPackage().equals(this.getUrnPackage()) &&
					that.getUrnNamespace().equals(this.getUrnNamespace()) &&
					ObjectUtil.equivalent(that.getFixedId(), this.getFixedId()) &&
					ObjectUtil.equivalent(that.getFixedVersion(), this.getFixedVersion());
					
		}
		return false;
	}

	@Override
	public String toString() {
		return toString;
	}
}
