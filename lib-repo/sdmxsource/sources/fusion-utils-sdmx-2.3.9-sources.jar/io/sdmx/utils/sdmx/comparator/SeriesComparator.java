package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SeriesComparator implements Comparator<String[]>, IFusionSingleton {
	private static SeriesComparator INSTANCE;

	private SeriesComparator() {}

	public static SeriesComparator getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SeriesComparator();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public int compare(String[] o1, String[] o2) {
		if(o1.length > o2.length) {
			return 1;
		}
		if(o1.length < o2.length) {
			return -1;
		}
		for(int i=0; i < o1.length; i++) {
			int returnVal = o1[i].compareTo(o2[i]);
			if(returnVal != 0) {
				return returnVal;
			}
		}
		return 0;
	}

}
