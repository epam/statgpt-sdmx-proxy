package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

public class IdentifiableSortByType implements Comparator<IdentifiableBean> {
	public static final IdentifiableSortByType INSTANCE = new IdentifiableSortByType();

	private IdentifiableSortByType() {}

	@Override
	public int compare(IdentifiableBean iBean1, IdentifiableBean iBean2) {
	    if(iBean1.equals(iBean2)) {
            return 0;
        }

        int comp = iBean1.getStructureType().getType().compareTo(iBean2.getStructureType().getType());
        if(comp != 0) {
            return comp;
        }

        String id1 = iBean1.getId();
        String id2 = iBean2.getId();
        int compare =  id1.compareToIgnoreCase(id2);
        if(compare == 0) {
            return iBean1.getUrn().compareTo(iBean2.getUrn());
        }
        return compare;
	}
}
