package io.sdmx.utils.sdmx.xs;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.collection.CollectionUtil;

public class MultiMaintainableRef implements IMultiMaintainableRef {
	public static final MultiMaintainableRef QUERY_ALL = new MultiMaintainableRef(null, null, null);
	public static final MultiMaintainableRef QUERY_ALL_LATEST = new MultiMaintainableRef(null, null, VersionRef.LATEST);
	private Set<String> agencies;
	private Set<String> ids;
	private IVersionRef version;
	
	public MultiMaintainableRef(IMaintainableRef ref) {
		this(ref == null ? null : ref.getAgencyId(),
			 ref == null ? null : ref.getMaintainableId(),
			 ref == null ? null : ref.getVersion());
	}

	/**
	 * @param agencies - comma separated if there are multiple
	 * @param ids - comma separated if there are multiple
	 * @param version - this can use semantic versioning syntax (* indicates all versions)
	 */
	public MultiMaintainableRef(String agencies, String ids, IVersionRef version) {
		if(agencies == null || agencies.equals("*")) {
			this.agencies = Collections.emptySet();
		} else {
			this.agencies = Collections.unmodifiableSet(CollectionUtil.arrayToSet(agencies.split(",")));
		}
		if(ids == null || ids.equals("*")) {
			this.ids = Collections.emptySet();
		} else {
			// Create a Set of IDs in upper case
			this.ids = Collections.unmodifiableSet(Arrays.stream(ids.split(",")).map(String::toUpperCase).collect(Collectors.toSet()));
		}
		//TODO SUPPORT MULTIPLE VERSIONS
		if(version == null) {
			version = VersionRef.ALL;
		}
		this.version = version;
	}
	
	
	@Override
	public Set<String> getAgencyId() {
		return agencies;
	}

	@Override
	public Set<String> getId() {
		return ids;
	}

	@Override
	public IVersionRef getVersion() {
		return version;
	}

	@Override
	public boolean isMatch(MaintainableBean maint) {
		if(this.agencies.size() > 0 && !this.agencies.contains(maint.getAgencyId())) {
			return false;
		}
		if(this.ids.size() > 0 && !this.ids.contains(maint.getId())) {
			return false;
		}
		return this.version.isMatch(maint.getVersion());
	}
}
