package io.sdmx.utils.sdmx.comparator;

import java.util.Comparator;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;

/**
 * Compares two IdentifiableBeans with each other.
 */
public class IdentifiableComparator implements Comparator<IdentifiableBean>{
	public static final IdentifiableComparator INSTANCE = new IdentifiableComparator();
	private IdentifiableComparator() {}
	
	@Override
	public int compare(IdentifiableBean iBean1, IdentifiableBean iBean2) {
		String id1 = iBean1.getId();
		String id2 = iBean2.getId();
		int compare =  id1.compareToIgnoreCase(id2);
		if(compare == 0) {
			return iBean1.getUrn().compareTo(iBean2.getUrn());
		}
		return compare;
	}
}
