package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public class DirectCrossReferenceBean<T extends IdentifiableBean> extends CrossReferenceBean<T> implements IDirectCrossReferenceBean<T> {
    private static final long serialVersionUID = 1L;
    
    private String structureProperty;

    public static <T extends IdentifiableBean> DirectCrossReferenceBean<T> build(IdentifiableBean referencedFrom, String structureProperty, IURNSingle<T> urnReference) {
        return new DirectCrossReferenceBean<>(referencedFrom, structureProperty, urnReference);
    }
    
    public static <T extends IdentifiableBean> DirectCrossReferenceBean<T> build(IdentifiableBean referencedFrom, String structureProperty, StructureReferenceBean sRef, Class<T> expectedTarget) {
        return new DirectCrossReferenceBean<>(referencedFrom, structureProperty, URN.builder(sRef.getTargetUrn(true)).buildSingle(expectedTarget));
    }
    
    protected DirectCrossReferenceBean(IdentifiableBean referencedFrom,
            String structureProperty,
            IURNSingle<T> urnReference) {
        super(referencedFrom, urnReference);
        this.structureProperty = structureProperty;
    }

    @Override
    public String getProperty() {
        return structureProperty;
    }
}
