package io.sdmx.utils.sdmx.application;

import io.sdmx.api.application.IApplicationWebService;
import io.sdmx.utils.core.object.ObjectUtil;

public class ApplicationWebService implements IApplicationWebService{
	private String serviceName;
	private String servicePostFix;
	private String systemProperty;
	
	//TODO Validate parameters
	public ApplicationWebService(String serviceName, String servicePostFix, String systemProperty) {
		this.serviceName = serviceName;
		this.servicePostFix = servicePostFix;
		this.systemProperty = systemProperty;
	}

	@Override
	public String getServiceName() {
		return serviceName;
	}

	@Override
	public String getServicePostFix() {
		return servicePostFix;
	}

	@Override
	public String getSystemProperty() {
		return systemProperty;
	}
	
	

	@Override
	public int compareTo(IApplicationWebService arg0) {
		if(servicePostFix.equals(arg0.getServicePostFix())) {
			return 0;
		}
		String[] path1 = servicePostFix.split("/");
		String[] path2 = arg0.getServicePostFix().split("/");
		
		int maxLength = Math.min(path1.length, path2.length);
		for(int i= 0; i < maxLength; i++) {
			int compare = path1[i].compareTo(path2[i]);
			if(compare != 0) {
				return compare;
			}
		}
		
		return path1.length > path2.length ? 1 : -1;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof IApplicationWebService) {
			IApplicationWebService ws = (IApplicationWebService) obj;
			return ObjectUtil.equivalent(serviceName, ws.getServiceName())
					&& ObjectUtil.equivalent(servicePostFix, ws.getServicePostFix())
					&& ObjectUtil.equivalent(systemProperty, ws.getSystemProperty());
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return systemProperty.hashCode();
	}

	@Override
	public String toString() {
		return systemProperty+"="+servicePostFix;
	}
	
	
}
