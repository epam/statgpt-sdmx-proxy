package io.sdmx.utils.sdmx.structure;

import java.util.regex.Pattern;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.object.ObjectUtil;

public class ValidationUtil {
	private static final Pattern xsdID = Pattern.compile("([A-Z]|[a-z]|_)+([A-Z]|[a-z]|\\\\|[0-9]|_|\\-|\\.)*");
	private static final Pattern idWithInt = Pattern.compile("([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*");
	private static final Pattern idWithNoInt = Pattern.compile("([A-Z]|[a-z])+([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*");



	/**
	 * Is this a valid xsd:Id type.
	 * An xsd:ID value must be an NCName. This means that it must start with a letter or underscore, and can only contain letters, digits,
	 * underscores, hyphens, and periods.
	 *
	 * @param id
	 * @return
	 */
	public static boolean isValidXsdId(String id) {
		if(!ObjectUtil.validString(id)) {
			return false;
		}
		return xsdID.matcher(id).matches();
	}


	/**
	 * Trims the leading and trailing whitespace from the specified id
	 * <p>
	 * Validates that the id starts with an alpha character (or alpha numeric if startWithIntAllowed is true).
	 *
	 * The id may that also contains one or more of the following:
	 * <ul>
	 *   <li>alphabetics in either case</li>
	 *   <li>a 'star' symbol (*)</li>
	 *   <li>an 'at' symbol (@)</li>
	 *   <li>integers (0-9)<li>
	 *   <li>an underscore (_)</li>
	 *   <li>a dollar ($)</li>
	 *   <li>a dash (-)</li>
	 * </ul>
	 * @param id The string to
	 * @param startWithIntAllowed Determines whether an integer is allowed to be the first character of the string
	 * @throws SdmxSemmanticException if the string id not valid - empty strings or null strings are not validated
	 */
	public static String cleanAndValidateId(String id, boolean startWithIntAllowed) throws SdmxSemmanticException {
		if (!ObjectUtil.validString(id)) {
			return null;
		}

		String trimmedId = id.trim();
		if(!isValidId(trimmedId, startWithIntAllowed)) {
			if(startWithIntAllowed) {
				throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_INVALID_ID, trimmedId);
			}
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_INVALID_ID_START_ALPHA, trimmedId);
		}
		return trimmedId;
	}

	public static boolean isValidId(String id, boolean startWithIntAllowed) {
		if (!ObjectUtil.validString(id)) {
			return false;
		}

		String trimmedId = id.trim();
		Pattern idPattern;

		if(startWithIntAllowed) {
			idPattern = idWithInt;
		} else {
			idPattern = idWithNoInt;
		}
		if(!idPattern.matcher(trimmedId).matches()) {
			return false;
		}
		return true;
	}
}
