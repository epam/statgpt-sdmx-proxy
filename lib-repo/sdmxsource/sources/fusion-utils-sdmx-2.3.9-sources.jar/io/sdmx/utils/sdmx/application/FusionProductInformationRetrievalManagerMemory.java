package io.sdmx.utils.sdmx.application;

import java.util.Objects;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.http.ClientRequest;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * Returns an in-memory copy of the Fusion Product Information
 */
public class FusionProductInformationRetrievalManagerMemory implements FusionProductInformationRetrievalManager {

	private FusionProductInformation fusionProductInformation;
	
	public FusionProductInformationRetrievalManagerMemory(FusionProductInformation fusionProductInformation) {
		Objects.requireNonNull(fusionProductInformation, "FusionProductInformation required");
		this.fusionProductInformation = fusionProductInformation;
	}

	@Override
	public FusionProductInformation getFusionProductInformation() {
		if(!ObjectUtil.validString(fusionProductInformation.getApplicationURL())) {
			ClientRequest clientRequest = ThreadLocalUtil.getClientRequest();
			if(clientRequest != null) {
				((FusionProductInformationImpl)fusionProductInformation).setApplicationURL(clientRequest.getServerUrl());
			}
		}
		return fusionProductInformation;
	}
}
