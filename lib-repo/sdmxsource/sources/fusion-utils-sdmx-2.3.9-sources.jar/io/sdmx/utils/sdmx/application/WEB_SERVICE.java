package io.sdmx.utils.sdmx.application;

import io.sdmx.api.application.IApplicationWebService;

public enum WEB_SERVICE {
	SDMX_GET("SDMXGET", "/ws/public/sdmxapi/rest", "registry.api.rest.get"),
	SDMX_GET_V2("SDMXGET_V2", "/sdmx/v2", "registry.api.rest.get.v2"),
	SDMX_POST("SDMXPOST", "/ws/secure/sdmxapi/rest",  "registry.api.rest.post"),
	LOGIN("Login", "/ws/public/security/login",  "registry.api.security.login"),
	LOGOUT("Logout", "/j_spring_security_logout",  "registry.api.security.logout"),
	PIVOT_EXPORT("PivotExport", "/ws/public/pivottable/export",  "registry.api.pivot.export"),
	DATA_SEARCH("DataSearch", "/ws/public/datasearch",  "registry.api.data.search"),
	SERIES_SEARCH("SeriesSearch", "/ws/public/seriessearch",  "registry.api.series.search"),
	SEARCH("Search", "/ws/public/search",  "registry.api.search"),
	USER_DETAILS("UserDetails", "/ws/public/currentuser/user",  "registry.api.user.details");

	private IApplicationWebService service;

	private WEB_SERVICE(String serviceName, String servicePostFix, String property) {
		this.service = new ApplicationWebService(serviceName, servicePostFix, property);
	}
	
	public static WEB_SERVICE getByProperty(String property) {
		for(WEB_SERVICE ws : WEB_SERVICE.values()) {
			if(ws.service.getSystemProperty().equals(property)) {
				return ws;
			}
		}
		return null;
	}

	public IApplicationWebService service() {
		return service;
	}
}
