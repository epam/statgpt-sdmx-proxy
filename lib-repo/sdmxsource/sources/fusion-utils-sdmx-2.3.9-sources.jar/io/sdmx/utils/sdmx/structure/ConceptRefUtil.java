package io.sdmx.utils.sdmx.structure;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class ConceptRefUtil {

	public static String getConceptId(IURNSingle<ConceptBean> sRef) {
		return sRef.getFullIdentifiableId();		
	}
	
	public static StructureReferenceBean buildConceptRef (
			String conceptSchemeAgency, 
			String conceptSchemeId, 
			String conceptSchemeVersion,
			String conceptAgency, 
			String conceptId) {
		boolean isFreeStanding = false;
		if(!ObjectUtil.validString(conceptSchemeId)) {
			isFreeStanding = true;
		} 
		if(ObjectUtil.validOneString(conceptId, conceptSchemeAgency, conceptSchemeId, conceptSchemeVersion)) {
			if(!ObjectUtil.validString(conceptSchemeAgency)) {
				conceptSchemeAgency = conceptAgency;
			}
			if(isFreeStanding) {
				return new StructureReferenceBeanImpl(conceptSchemeAgency, ConceptSchemeBean.DEFAULT_SCHEME_ID, ConceptSchemeBean.DEFAULT_SCHEME_VERSION, SDMX_STRUCTURE_TYPE.CONCEPT, conceptId);
			}
			
			return new StructureReferenceBeanImpl(conceptSchemeAgency, conceptSchemeId, conceptSchemeVersion, SDMX_STRUCTURE_TYPE.CONCEPT, conceptId);
		}
		//TODO Exception
		throw new IllegalArgumentException("Concept Reference missing parameters");
	}
}
