package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanFuzzy;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public abstract class CrossRefrenceBeanBase implements ICrossReferenceBeanBase {
	private static final long serialVersionUID = -1103372297741893400L;
	private IdentifiableBean referencedFrom;
	
	/**
	 * @param referencedFrom not null, the structure that is doing the reference
	 * @param structureReference not null, providing the URN that is being referenced
	 * @return either a {@link ICrossReferenceBean} or {@link ICrossReferenceBeanFuzzy} depending on whether the structureReference targets one or multiple structures
	 */
	public static ICrossReferenceBeanBase build(IdentifiableBean referencedFrom, String property, StructureReferenceBean structureReference) {
		IURN<?> urn = URN.builder(structureReference.getTargetUrn()).build();
		if(urn.getReferenceType().isSingle()) {
			return DirectCrossReferenceBean.build(referencedFrom, property, urn.asSingle());
		} else {
			return CrossReferenceBeanFuzzy.getInstance(referencedFrom, urn);
		}
	}
	
	protected CrossRefrenceBeanBase(IdentifiableBean referencedFrom) {
		this.referencedFrom = referencedFrom;
	}

	@Override
	public IdentifiableBean getReferencedFrom() {
		return referencedFrom;
	}
	

	@Override
	public String toString() {
		return "Cross Reference : " + getReference().getURN();
	}
}
