package io.sdmx.utils.sdmx.audit;

import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.IResource;
import io.sdmx.api.process.IProcess;
import io.sdmx.utils.core.audit.AuditUtil;

/**
 * A utility methods on AuditUtil for SDMX Specific Events
 */
public class SdmxAuditUtil {
	
	/**
	 * An operation is performed on an audited process
	 * @param processId example CACHE
	 * @param action example REFRESH
	 * @param auditProcss
	 */
	public static String startSdmxEvent(IResource resource, HTTP_METHOD method, IProcess auditProcss) {
		String eventName = "SDMX_"+method.getMethod();
		return AuditUtil.startAuditEvent(eventName, resource.getResource(), ()-> {
			auditProcss.runProcess();
		});
	}
}
