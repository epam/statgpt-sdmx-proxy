package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNWildcard;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

public class URNWildcard extends URN implements IURNWildcard {
	private static final long serialVersionUID = 1L;

	/**
	 * Package protected, constructed via the URN.getInstance method
	 */
	URNWildcard(ISDMXStructureType structureType, IMaintainableRef ref, String identifiableId, String urn) {
		super(structureType, ref, identifiableId, urn);
	}

	@Override
	public REFERENCE_TYPE getReferenceType() {
		return REFERENCE_TYPE.WILDCARD;
	}
	
}
