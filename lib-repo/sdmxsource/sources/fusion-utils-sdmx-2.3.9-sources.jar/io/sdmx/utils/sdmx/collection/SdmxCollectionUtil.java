package io.sdmx.utils.sdmx.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.INamedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxCollectionUtil {
	
	/**
	 * @param beans1
	 * @param beans2
	 * @return true if both SdmxBeans containers contain the same maintainables with the same deepequals
	 */
	public static boolean isEquivalent(SdmxBeans beans1, SdmxBeans beans2) {
		Map<String, MaintainableBean> maints1 = SdmxCollectionUtil.maintCollectionToMap(beans1.getAllMaintainables());
		Map<String, MaintainableBean> maints2 = SdmxCollectionUtil.maintCollectionToMap(beans2.getAllMaintainables());
		if(!ObjectUtil.equivalentMap(maints1, maints2)) {
			return false;
		}
		for(String key : maints1.keySet()) {
			MaintainableBean m1 = maints1.get(key);
			MaintainableBean m2 = maints2.get(key);
			
			if(m1 == null && m2 == null) {
				continue;
			}
			if(m1 == null && m2 != null) {
				return false;
			}
			if(m1 != null && m2 == null) {
				return false;
			}
			if(!m1.deepEquals(m2, true)) {
				return false;
			}
		}
		return true;
	}
	

	public static Set<String> baseRefUrns(Collection<? extends ICrossReferenceBeanBase> refs) {
		return refs.stream().map(e->e.getTargetUrn()).collect(Collectors.toSet());
	}
	
	public static Set<String> refUrns(Collection<? extends ICrossReferenceBean<?>> refs) {
		return refs.stream().map(e->e.getTargetUrn()).collect(Collectors.toSet());
	}

	public static Set<String> identifiablesIds(Collection<? extends IdentifiableBean> idents) {
		return idents.stream().map(e->e.getId()).collect(Collectors.toSet());
	}
	
	/**
	 * @param named
	 * @return a Set of Strings of the IDs from the objects of type INamedBean
	 */
	public static Set<String> namedItemIds(Collection<? extends INamedBean> named) {
		return named.stream().map(e->e.getId()).collect(Collectors.toSet());
	}
	
	public static Set<IURNMaintainable<?>> urnsMaint(Collection<? extends MaintainableBean> idents) {
		return idents.stream().map(e->e.getURN()).collect(Collectors.toSet());
	}
	public static Set<IURNAbsolute<?>> urnsIdent(Collection<? extends IdentifiableBean> idents) {
		return idents.stream().map(e->e.getURN()).collect(Collectors.toSet());
	}
	public static Set<String> urnsString(Collection<? extends IdentifiableBean> idents) {
		return idents.stream().map(e->e.getUrn()).collect(Collectors.toSet());
	}
	
	public static Set<StructureReferenceBean> sRefs(Collection<? extends IdentifiableBean> idents) {
		return idents.stream().map(e->e.asReference()).collect(Collectors.toSet());
	}
	
	public static Set<String> enumeratedListIds(EnumeratedListBean<? extends EnumeratedItemBean> list) {
		if(list == null) {
			return new HashSet<>();
		}
		return list.getItems().stream().map(e->e.getId()).collect(Collectors.toSet());
	}
	
	/**
	 * Converts a list of values to a map of id to position
	 * @param compIds
	 * @param posMap
	 */
	public static Map<String, Integer> identifiableIdToPosition(Collection<? extends IdentifiableBean> idents) {
		Map<String, Integer> returnMap = new HashMap<>();
		CollectionUtil.listToPosition(identifiablesIdList(idents), returnMap);
		return returnMap;
	}

	public static String[] identifiablesIdArray(Collection<? extends IdentifiableBean> idents) {
		List<String> l = identifiablesIdList(idents);
		String[] returnArray = new String[l.size()];
		return l.toArray(returnArray);
	}
	
	public static <T> List<T> toList(T... str) {
		List<T> list = new ArrayList<>();
		if(str != null) {
			for(T s : str) {
				list.add(s);
			}
		}
		return list;
	}
	
	public static List<String> identifiablesIdList(Collection<? extends IdentifiableBean> idents) {
		return identifiablesIdList(idents, false);
	}
	
	public static List<String> identifiablesIdList(Collection<? extends IdentifiableBean> idents, boolean makeImmutable) {
		List<String> l = idents.stream().map(e->e.getId()).collect(Collectors.toList());
		if(makeImmutable) {
			return Collections.unmodifiableList(l);
		}
		return l;
	}
	
	public static Set<String> agenciesIds(Collection<? extends MaintainableBean> maints, boolean makeImmutable) {
		Set<String> l = maints.stream().map(e->e.getAgencyId()).collect(Collectors.toSet());
		if(makeImmutable) {
			return Collections.unmodifiableSet(l);
		}
		return l;
	}
	
	public static Map<String, MaintainableBean> maintCollectionToMap(MaintainableBean... maints) {
		Map<String, MaintainableBean> maintMap = new HashMap<>();
		if(maints != null) {
			for(MaintainableBean maint : maints) {
				maintMap.put(maint.getUrn(), maint);
			}
		}
		return maintMap;
	}
	
	
	public static Map<String, MaintainableBean> maintCollectionToMap(Collection<? extends MaintainableBean> maints) {
		return maints.stream().collect(Collectors.toMap(e-> e.getUrn(), e -> e));
	}
	

	public static Map<String, IdentifiableBean> identCollectionToMap(Collection<IdentifiableBean> ident) {
		return ident.stream().collect(Collectors.toMap(e-> e.getUrn(), e -> e));
	}
}
