package io.sdmx.utils.sdmx.xs;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

public class CrossReferenceBean<T extends IdentifiableBean> extends CrossRefrenceBeanBase implements ICrossReferenceBean<T> {
	private static final long serialVersionUID = -1103372297741893400L;
	private IURNSingle<T> urnReference;
	private Integer hashCode;
	
	public static <T extends IdentifiableBean> CrossReferenceBean<T> build(IdentifiableBean referencedFrom, IURNSingle<T> urnReference) {
		return new CrossReferenceBean<>(referencedFrom, urnReference);
	}
	
	public static <T extends IdentifiableBean> CrossReferenceBean<T> build(IdentifiableBean referencedFrom, String urn, Class<T> expectedTarget) {
		return new CrossReferenceBean<>(referencedFrom, URN.builder(urn).buildSingle(expectedTarget));
	}
	
	protected CrossReferenceBean(IdentifiableBean referencedFrom, IURNSingle<T> urnReference) {
		super(referencedFrom);
		this.urnReference = urnReference;
		
		//build this now otherwise deserialisation fails because the hashcode method is called
		//before the getReferencedFrom is fully constructed and the getUrn fails because of this
		this.hashCode = hashCode();
	}

	@Override
	public IURNSingle<T> getReference() {
		return urnReference;
	}

	@Override
	public boolean isIndirectReference() {
		return false;
	}

	@Override
	public boolean isWeakReference() {
		return false;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ICrossReferenceBean) {
			ICrossReferenceBean<?> that = (ICrossReferenceBean) obj;
			return this.getReferencedFrom().equals(that.getReferencedFrom()) &&
					this.getTargetUrn().equals(that.getTargetUrn()) &&
					this.isIndirectReference() == that.isIndirectReference() &&
					this.isWeakReference() == that.isWeakReference();
		}
		return false;
	}

	@Override
	public int hashCode() {
		if(hashCode == null) {
			hashCode = new HashCodeBuilder(7, 31).append(getReference())
					.append(isIndirectReference())
					.append(isWeakReference())
					.append(getReferencedFrom())
					.build();
		}
		return hashCode;
	}
}
