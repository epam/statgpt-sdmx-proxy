package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;

/**
 * Only gets the identifiable on demand
 */
public class LazyLoadResolvedReference<T extends IdentifiableBean> implements ICrossReferenceBeanResolved<T> {
	private static final long serialVersionUID = 1L;
	private T identifiableBean;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	private IURNAbsolute fromUrn;
	private IURNAbsolute toUrn;
	
	private boolean isIndirect;
	private boolean isWeak;
	
	private ICrossReferenceBean baseReference;

	@SuppressWarnings({"unchecked"})
	public static LazyLoadResolvedReference build(SdmxBeanRetrievalManager beanRetrievalManager,
												  IURNAbsolute<?> fromUrn, 
												  IURNAbsolute<?> toUrn, 
												  boolean isIndirect, 
												  boolean isWeak) {
		return new LazyLoadResolvedReference(beanRetrievalManager, fromUrn, toUrn, isIndirect, isWeak);
	}
	
	@SuppressWarnings("unchecked")
	LazyLoadResolvedReference(SdmxBeanRetrievalManager beanRetrievalManager, IURNAbsolute<?> fromUrn, IURNAbsolute<?> toUrn, boolean isIndirect, boolean isWeak) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.fromUrn = fromUrn;
		this.toUrn = toUrn;
		this.isIndirect = isIndirect;
		this.isWeak = isWeak;
	}

	@Override
	public T getResolvedBean() {
		if(identifiableBean == null) {
			identifiableBean = (T) beanRetrievalManager.getBean(toUrn);
		}
		return identifiableBean;
	}

	@Override
	public boolean isIndirectReference() {
		return isIndirect;
	}

	@Override
	public boolean isWeakReference() {
		return isWeak;
	}

	@Override
	public IdentifiableBean getReferencedFrom() {
		return getBaseReference().getReferencedFrom();
	}
	
	@Override
	public IURNAbsolute<?> getReferencedFromURN() {
		return this.fromUrn;
	}

	@Override
	public IURNAbsolute<T> getReference() {
		return this.toUrn;
	}

	@Override
	public ICrossReferenceBean<T> getBaseReference() {
		if(baseReference == null) {  //TODO the bean retrieval manager does not work if the from reference is a different store, i.e the metadata store with a metadata set referencing a dataflow
			IdentifiableBean referencedFrom = beanRetrievalManager.getBean(this.fromUrn);
			this.baseReference = CrossReferenceBean.build(referencedFrom, toUrn);
		}
		return baseReference;
	}
	
	
	
}
