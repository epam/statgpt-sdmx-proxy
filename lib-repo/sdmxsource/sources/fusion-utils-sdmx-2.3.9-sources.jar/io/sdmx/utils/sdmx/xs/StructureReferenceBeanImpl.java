package io.sdmx.utils.sdmx.xs;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

public class StructureReferenceBeanImpl implements StructureReferenceBean {
	private static final long serialVersionUID = 1L;
	private IURN<?> urn;
	private URNBuilder urnBuilder;
	
	public static StructureReferenceBean buildAndVerify(String urn, SDMX_STRUCTURE_TYPE... expectedType) {
		StructureReferenceBean ref = new StructureReferenceBeanImpl(urn);
		if(expectedType != null && expectedType.length > 0 && expectedType[0] != null) {
			boolean isType = false;
			for(SDMX_STRUCTURE_TYPE currentEt : expectedType) {
				if(currentEt != null && (currentEt == SDMX_STRUCTURE_TYPE.ANY || ref.getTargetReference() == currentEt)) {
					isType = true;
					break;
				}
			}
			if(!isType) {
				final StringBuilder sb = new StringBuilder();
				String concat = "";
				for(SDMX_STRUCTURE_TYPE currentType : expectedType) {
					sb.append(concat+currentType.getType());
					concat = ", ";
				}
				throw new SdmxSemmanticException("URN '"+urn+"' not of expected type: "+sb.toString());
			}
		}
		return ref;
	}
	
	
	public static StructureReferenceBean fromProperties(IMaintainableProperties props, SDMX_STRUCTURE_TYPE structureType) {
		return new StructureReferenceBeanImpl(URN.builder().maint(props).structure(structureType).build());
	}
	
	/**
	 * Builds from a short code, example Codelist=SDMX:CL_FREQ(1.0)
	 * @param shortCode
	 * @param expectedType
	 * @return
	 */
	public static StructureReferenceBean fromShortCode(String shortCode, SDMX_STRUCTURE_TYPE... expectedType) {
		String[] shortCodeSplit = shortCode.split("=");
		if(shortCodeSplit.length != 2) {
			throw new SdmxSemmanticException("Short Code '"+shortCode+"' is not of expected syntax '<class>=<agencyid>:<id>(<version>)'");
		}
		String structureClass = shortCodeSplit[0];
		SDMX_STRUCTURE_TYPE st = SDMX_STRUCTURE_TYPE.parseClass(structureClass);
		String urn = st.getUrnPrefix() + shortCodeSplit[1];
		return StructureReferenceBeanImpl.buildAndVerify(urn, expectedType);
	}
	
	public StructureReferenceBeanImpl(SDMX_STRUCTURE_TYPE type) {
		this(URN.builder().build(type.getIdentifiableInterface()));
	}
	
	public StructureReferenceBeanImpl(String urn, SDMX_STRUCTURE_TYPE expectedType) {
		this(URN.builder(urn).build(StructureTypes.getSdmxIdentifiableType(expectedType).getClassType()));
	}
	
	public StructureReferenceBeanImpl(IMaintainableRef ref, SDMX_STRUCTURE_TYPE expectedType, String...identifiableIds) {
		this(URN.builder().structure(expectedType).maint(ref).identifableId(identifiableIds).build());
	}
	
	public StructureReferenceBeanImpl(String agencyId, String id, String version, SDMX_STRUCTURE_TYPE expectedType, String...identifableIds) {
		this(URN.builder().structure(StructureTypes.getSdmxIdentifiableType(expectedType)).agencyId(agencyId).maintId(id).version(version).identifableId(identifableIds).build());
	}
	
	public StructureReferenceBeanImpl(String urn) {
		this(URN.getInstance(urn));
	}
	
	public StructureReferenceBeanImpl(IURN<?> urn) {
		this.urn = urn;
	}
	

	@Override
	public IURN<?> getURN() {
		if(this.urn == null) {
			this.urn = urnBuilder.build();
		}
		return this.urn;
	}


	@Override
	public void setAgencyId(String agencyId) {
		mutate().agencyId(agencyId);
	}

	@Override
	public void setMaintainableId(String maintId) {
		mutate().maintId(maintId);
	}

	@Override
	public void setVersion(String version) {
		mutate().version(version);
	}

	@Override
	public void setVersion(IVersionRef versionRef) {
		mutate().versionRef(versionRef);
	}
	
	@Override
	public void setIdentifiableId(String identId) {
		mutate().identifableId(identId);
	}
	
	/**
	 * Ensures any previously built URN is null, and create a URNBuilder or return the one in current use
	 */
	private URNBuilder mutate() {
		if(this.urnBuilder == null) {
			this.urnBuilder = URN.builder(urn);
		}
		urn = null;
		return this.urnBuilder;
	}


	@Override
	public String getAgencyId() {
		String acy = urn != null ? urn.getAgencyId() : urnBuilder.agencyId();
		acy = acy != null && acy.equals("*") ? null : acy;
		return acy;
	}

	@Override
	public String getMaintainableId() {
		String id = urn != null ? urn.getMaintainableId() : urnBuilder.maintId();
		id = id != null && id.equals("*") ? null : id;
		return id;
	}

	@Override
	public IVersionRef getVersion() {
		return urn != null ? urn.getVersion() : VersionRef.getInstance(urnBuilder.version());
	}

	@Override
	public SDMX_STRUCTURE_TYPE getMaintainableStructureType() {
		return getTargetReference().getMaintainableStructureType();
	}

	@Override
	public SDMX_STRUCTURE_TYPE getTargetReference() {
		return  urn != null ? urn.getSdmxStructure() : urnBuilder.sdmxStructure() ;
	}
	@Override
	public String[] getIdentifiableIds() {
		return getFullId() == null ? null : getFullId().split("\\.");
	}

	@Override
	public String getFullId() {
		return urn != null ?  urn.getIdentifiableId() : urnBuilder.identifableId();
	}

	@Override
	public IMaintainableRef getMaintainableReference() {
		return getURN();
	}

	@Override
	public boolean hasChildReference() {
		return getFullId() != null;
	}

	@Override
	public String getTargetUrn() {
		return getURN().getURN();
	}

	@Override
	public String getTargetUrn(boolean includeWildcards) {
		if(!includeWildcards && !hasTargetUrn()) {
			return null;
		} 
		return getTargetUrn();
	}

	@Override
	public boolean hasTargetUrn() {
		return getURN().isWildcard() == false;
	}

	@Override
	public String getMaintainableUrn() {
		if(getURN().getStructureType().isMaintainable()) {
			return getURN().getURN();
		}
		return getURN().getMaintainableURN().getURN();
	}

	@Override
	public boolean hasMatch(MaintainableBean reference) {
		return getURN().isMatch(reference);
	}

	@Override
	public Set<IdentifiableBean> getMatches(MaintainableBean maintainbleBean) {
		Set<IdentifiableBean> returnSet = new HashSet<>();
		for(IdentifiableBean ident : maintainbleBean.getIdentifiableComposites()) {
			if(getURN().isMatch(ident)) {
				returnSet.add(ident);
			}
		}
		return returnSet;
	}

	@Override
	public boolean referencesIdentifiableChild() {
		return getFullId() != null;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof StructureReferenceBean) {
			return ((StructureReferenceBean) obj).getURN().equals(this.getURN());
		}
		return false;
	}


	@Override
	public int hashCode() {
		return getURN().toString().hashCode();
	}

	@Override
	public String toString() {
		return getURN().toString();
	}
	
	
}
