package io.sdmx.utils.sdmx.structure;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.utils.sdmx.xs.URN;

public class AgencyUtil {
	
    /**
     * Given an agency string which may include a sub agency (e.g. "SDMX.SUB1" ) return the parent agency.
     * @param fullAgencyId
     * @return
     */
    public static String obtainParentAgency(String fullAgencyId) {
        if (fullAgencyId == null) {
            return null;
        }
        int firstDot = fullAgencyId.indexOf(".");
        if (firstDot == -1) {
            return fullAgencyId;
        }
        return fullAgencyId.substring(0,firstDot);
    }
	
    /**
	 * Converts the Agency Id if the {@link MaintainableBean} to an agency Reference
	 * @param acyId
	 */
	public static IURNSingle<AgencyBean> toRef(MaintainableBean maint) {
		return toRef(maint.getAgencyId());
	}
	
	/**
	 * Converts an Agency Id to a Structure Reference
	 * @param acyId
	 */
	public static IURNSingle<AgencyBean> toRef(String acyId) {
		String[] split = splitAgencyId(acyId);
		return URN.builder().agencyId(split[0]).identifableId(split[1]).buildSingle(AgencyBean.class);
	}
	/**
	 * Splits an agency ID into its owning agency and the id.  If the ID is a top level agency, the owning agency id SDMX.
	 * Examples:
	 * ECB splits into SDMX and ECB
	 * ECB.DEPT1 splits into ECB and DEPT1
	 * ECB.DEPT1.SUB splits into ECB.DEPT1 and SUB
	 * 
	 * 
	 * @param acyId
	 * @return array of length 2, position 0=agency owner, position 1=agency id
	 */
	public static String[] splitAgencyId(String acyId) {
		String[] returnArray = new String[2];
		String[] split1 = acyId.split("\\.");
		if(split1.length == 1) {
			returnArray[0] = "SDMX";
			returnArray[1] = acyId;
		} else {
			acyId = acyId.substring(0, acyId.lastIndexOf("."));
			returnArray[0] = acyId;
			returnArray[1] = split1[split1.length-1];
		}
		return returnArray;
	}


	public static boolean isParentAgency(String acyId, String targetAgencyId) {
		String[] split1 = acyId.split("\\.");
		String[] split2 = targetAgencyId.split("\\.");
		if(split1.length >= split2.length) {
			return false;
		}
		short i = 0;
		for (String currentId : split1) {
			if(!currentId.equals(split2[i])) {
                return false;
            }
			i++;
		}
		return true;
	}

	/**
	 * returns true if the agency id passed in is in the set of agencies, or if it is a sub agency of any agencies in the set.
	 * Example ESTAT.NA will return true if the userAgencies contains the String ESTAT, as ESTAT is a parent agency
	 *
	 * @param agencyId full id can be a sub agency
	 * @param userAgencies ids of agencies or sub agencies to checck against
	 * @return
	 */
	public static boolean isMaintainedBy(String agencyId, Set<String> userAgencies) {
	    if (agencyId == null) {
            return false;
        }

	    if(userAgencies.contains(agencyId)) {
			return true;
		}

		//Check if the maintainable is a sub agency of the current user, then they can view it
		if(agencyId.contains(".") && userAgencies.size() > 0) {
			String[] acySplit = agencyId.split("\\.");
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(int i = 0; i < acySplit.length-1; i++) {
				sb.append(concat+acySplit[i]);
				if(userAgencies.contains(sb.toString())) {
					return true;
				}
				concat = ".";
			}
		}
		return false;
	}
}
