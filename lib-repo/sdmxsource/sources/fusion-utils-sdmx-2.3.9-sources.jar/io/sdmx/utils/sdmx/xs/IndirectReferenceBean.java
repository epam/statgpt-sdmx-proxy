package io.sdmx.utils.sdmx.xs;

import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

/**
 * An indirect reference is one which does not directly cross reference a structure but does so via another structure
 * for example a Constraint does not directly reference a Code, but it does via the DSD
 */
public class IndirectReferenceBean<T extends IdentifiableBean> extends CrossReferenceBean<T> {
	private static final long serialVersionUID = 1L;
	private boolean weakReference;

	public IndirectReferenceBean(IdentifiableBean referencedFrom, IURNSingle<T> urn) {
		super(referencedFrom, urn);
	}
	
	public static <T extends IdentifiableBean> IndirectReferenceBean<T> weakReference(IdentifiableBean referencedFrom, IURNSingle<T> urn) {
		return new IndirectReferenceBean<>(referencedFrom, urn);
	}
	
	public static <T extends IdentifiableBean> IndirectReferenceBean<T> strongReference(IdentifiableBean referencedFrom, 
			  IMaintainableRef maintRef, 
			  ISDMXStructureType<?, T> structureType, 
			  String... identifiableIds) {
		IURNSingle<T> urn = URN.builder().maint(maintRef).identifableId(identifiableIds).buildSingle(structureType.getClassType());
		IndirectReferenceBean<T> ref = new IndirectReferenceBean<>(referencedFrom, urn);
		ref.weakReference = false;
		return ref;
	}
			
			
	public static <T extends IdentifiableBean> IndirectReferenceBean<T> weakReference(IdentifiableBean referencedFrom, 
																					  IMaintainableRef maintRef, 
																					  ISDMXStructureType<?, T> structureType, 
																					  String... identifiableIds) {
		IURNSingle<T> urn = URN.builder().maint(maintRef).identifableId(identifiableIds).buildSingle(structureType.getClassType());
		IndirectReferenceBean<T> ref = new IndirectReferenceBean<>(referencedFrom, urn);
		ref.weakReference = true;
		return ref;
	}
	

	@Override
	public boolean isWeakReference() {
		return weakReference;
	}

	@Override
	public boolean isIndirectReference() {
		return true;
	}
	
	@Override
	public String toString() {
		return "Indirect Cross Reference : " + getReference().getURN();
	}
}
