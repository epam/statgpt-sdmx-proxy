package io.sdmx.utils.sdmx.application;

public interface FusionServiceManager {

	/**
	 * Validates that the URL of the service resolves to a valid fusion product of the given type
	 * @param product expected product
	 * @param serviceUrl service URL
	 */
	void validateService(FUSION_PRODUCT product, String serviceUrl);
	
	/**
	 * Validates that the URL of the service resolves to a valid fusion product of the given type
	 * @param product expected product
	 * @param serviceUrl service URL
	 * @param minVersion the minimum required version of the product
	 */
	void validateService(FUSION_PRODUCT product, String serviceUrl, String minVersion);
	
	
	
}
