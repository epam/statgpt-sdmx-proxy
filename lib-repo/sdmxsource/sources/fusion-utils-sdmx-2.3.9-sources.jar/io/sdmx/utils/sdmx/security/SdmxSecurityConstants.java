package io.sdmx.utils.sdmx.security;

import io.sdmx.api.security.ISecurityAdminFunction;
import io.sdmx.utils.core.security.SecurityAdminFunction;

public class SdmxSecurityConstants {
	public static ISecurityAdminFunction SDMX_STRUCTURE_ADMIN_FUNCTION = SecurityAdminFunction.getInstance("STRUCTURE_ADMIN", "Structure Admin", "Full access rights to structural metadata");
	public static ISecurityAdminFunction SDMX_METADATA_ADMIN_FUNCTION = SecurityAdminFunction.getInstance("METADATA_ADMIN", "Reference Metadata Admin", "Full access rights to reference metadata");
	
}
