package io.sdmx.utils.sdmx.data;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * Used to perform asserts on a dataset
 */
public class DataReaderAsserter {
	private DataReaderEngine dre;
	private String[] dimensions;
	private String[] seriesAttributes;
	private String[] measureIds;
	private String[] measureAttributes;

	public DataReaderAsserter(DataReaderEngine dre) {
		this.dre = dre;
	}

	public DataReaderEngine getDre() {
		return dre;
	}
	
	public void assertNextDataset() {
		dre.moveNextDataset();
		setValues();
	}
	
	private void setValues() {
		DataStructureBean dsd = dre.getDataStructure();
		this.dimensions = CollectionUtil.toArray(dsd.getDimensionIds());
		this.seriesAttributes = SdmxCollectionUtil.identifiablesIdArray(dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID));
		this.measureIds = SdmxCollectionUtil.identifiablesIdArray(dsd.getMeasures());
		this.measureAttributes = SdmxCollectionUtil.identifiablesIdArray(dsd.getObservationAttributes());
	}
	
	public void assertEndDataset() {
		ObjectUtil.assertFalse(dre.moveNextDataset());
	}

	/**
	 * @param groupId
	 * @param shortCode  in syntax Keyable.getShortCode()
 	 * @param expectedAttributes in syntax UNIT:A where UNIT is the attribute ID and A is the attribute value
	 */
	public void assertGroup(String groupId, String shortCode, String... expectedAttributes) {
		ObjectUtil.assertTrue(dre.moveNextKeyable());
		Keyable group = dre.getCurrentKey();
		ObjectUtil.assertFalse(group.isSeries());
		ObjectUtil.assertEquals(groupId, group.getGroupName());
		ObjectUtil.assertEquals(shortCode, group.getShortCode());
		ObjectUtil.assertEquals(expectedAttributes.length, group.getAttributes().size());
		for(String attr : expectedAttributes) {
			String[] split = attr.split(":", 2);
			ObjectUtil.assertEquals(split[1], group.getAttributeValue(split[0]));
		}
	}

	public void assertKey(String expectedKey, String... expectedAttributes) {
		ObjectUtil.assertTrue(dre.moveNextKeyable());
		String expectedDims[] = expectedKey.split(":", 1000);
		Keyable currentKey = dre.getCurrentKey();
		ObjectUtil.assertNotNull(currentKey);
		if(dimensions == null) {
			setValues();
		}
		int i=0;
		for (i=0; i < dimensions.length; i++) {
			String dimId = dimensions[i];
			String expected = expectedDims[i];
			String keyValue = currentKey.getReportedValue(dimId);
			ObjectUtil.assertEquals(expected, keyValue);
		}

		if(expectedAttributes == null) {
			return;
		}
		for (i=0; i < seriesAttributes.length; i++) {
			if(expectedAttributes.length == i) {
				break;
			}
			String attId = seriesAttributes[i];
			String attributeVal = currentKey.getAttributeValue(attId);
			ObjectUtil.assertEquals(attributeVal, expectedAttributes[i]);
		}
	}

	public void assertEndKeys() {
		ObjectUtil.assertFalse(dre.moveNextKeyable());
	}

	/**
	 * @param expectedDimensionId if the observation is expected to have a dimension id, it must match
	 * @param expectedDimensionValue if the observation is expected to have a dimension value, it must match
	 * @param expectedValues a value per measure, values with colon will be treated as attribute values in the syntax OBS_STATUS:A - will only check the values that are passed in, if values are not passed in and they are reported the reported
	 * values will not be checked
	 */
	public void assertObs(String expectedDimensionId, String expectedDimensionValue, String... expectedValues) {
		ObjectUtil.assertTrue("moveNextObservation was false, expected true", dre.moveNextObservation());
		Observation obs = dre.getCurrentObservation();
		ObjectUtil.assertNotNull(obs);
		ObjectUtil.assertEquals(expectedDimensionId, obs.getDimensionId());
		ObjectUtil.assertEquals(expectedDimensionValue, obs.getDimensionValue());
		
		if(expectedValues != null) {
			int i = 0;
			for(String expectedValue : expectedValues) {
				if(expectedValue.contains(":")) {
					String[] attribute = expectedValue.split(":");
					String reportedValue = obs.getAttributeValue(attribute[0]);
					expectedValue = attribute[1];
					ObjectUtil.assertEquals(expectedValue, reportedValue);
				} else {
					String reportedValue = obs.getMeasure(measureIds[i]).getCode();
					ObjectUtil.assertEquals(expectedValue, reportedValue);
					i++;
				}
			}
		}
	}

	public void assertEndObs() {
		ObjectUtil.assertFalse("moveNextObservation was true, expected false", dre.moveNextObservation());
	}
	

}
