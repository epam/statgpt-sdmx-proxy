package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.RelatedStructuresBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RelatedStructuresMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class RelatedStructuresMutableBeanImpl extends MutableBeanImpl implements RelatedStructuresMutableBean {
	private static final long serialVersionUID = 1L;

	private List<StructureReferenceBean> dsdRef = new ArrayList<>();
	private List<StructureReferenceBean> msdRef = new ArrayList<>();
	private List<StructureReferenceBean> conceptSchemeRef = new ArrayList<>();
	private List<StructureReferenceBean> categorySchemeRef = new ArrayList<>();
	private List<StructureReferenceBean> orgSchemeRef = new ArrayList<>();
	private List<StructureReferenceBean> hclRef = new ArrayList<>();

	public RelatedStructuresMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.RELATED_STRUCTURES);
	}

	public RelatedStructuresMutableBeanImpl(RelatedStructuresBean bean, MutableBean parent) {
		super(bean, parent);
		this.dsdRef = bean.getDataStructureRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());
		this.msdRef = bean.getMetadataStructureRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());;
		this.conceptSchemeRef = bean.getConceptSchemeRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());;
		this.categorySchemeRef = bean.getCategorySchemeRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());;
		this.orgSchemeRef = bean.getOrgSchemeRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());;
		this.hclRef = bean.getHierCodelistRef().stream().map(e -> e.getReference().asMutable()).collect(Collectors.toList());;
	}

	@Override
	public void addRelatedStructure(StructureReferenceBean sRef) {
		switch(sRef.getTargetReference()) {
		case DSD : this.dsdRef.add(sRef);
			break;
		case MSD : this.msdRef.add(sRef);
			break;
		case CONCEPT_SCHEME : this.conceptSchemeRef.add(sRef);
			break;
		case CATEGORY_SCHEME : this.categorySchemeRef.add(sRef);
			break;
		case ORGANISATION_UNIT_SCHEME : this.orgSchemeRef.add(sRef);
			break;
		case HIERARCHY : this.hclRef.add(sRef);
			break;
		default : throw new SdmxSemmanticException("Can not add related structure of type: "+sRef.getTargetReference().getType());
		}
	}

	@Override
	public List<StructureReferenceBean> getDataStructureRef() {
		return dsdRef;
	}

	@Override
	public List<StructureReferenceBean> getMetadataStructureRef() {
		return msdRef;
	}

	@Override
	public List<StructureReferenceBean> getConceptSchemeRef() {
		return conceptSchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getCategorySchemeRef() {
		return categorySchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getOrgSchemeRef() {
		return orgSchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getHierCodelistRef() {
		return hclRef;
	}

	@Override
	public void setDataStructureRef(List<StructureReferenceBean> keyFamilyRef) {
		this.dsdRef = keyFamilyRef;
	}

	@Override
	public void setMetadataStructureRef(List<StructureReferenceBean> metadataStructureRef) {
		this.msdRef = metadataStructureRef;
	}

	@Override
	public void setConceptSchemeRef(List<StructureReferenceBean> conceptSchemeRef) {
		this.conceptSchemeRef = conceptSchemeRef;
	}

	@Override
	public void setCategorySchemeRef(List<StructureReferenceBean> categorySchemeRef) {
		this.categorySchemeRef = categorySchemeRef;
	}

	@Override
	public void setOrgSchemeRef(List<StructureReferenceBean> orgSchemeRef) {
		this.orgSchemeRef = orgSchemeRef;
	}

	@Override
	public void setHierCodelistRef(List<StructureReferenceBean> hierCodelistRef) {
		this.hclRef = hierCodelistRef;
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet =  super.getStructureReferencesInternal();
	    if (dsdRef != null) {
	        returnSet.addAll(dsdRef);
	    }
	    if (msdRef != null) {
	        returnSet.addAll(msdRef);
	    }
	    if (conceptSchemeRef != null) {
	        returnSet.addAll(conceptSchemeRef);
	    }
	    if (categorySchemeRef != null) {
	        returnSet.addAll(categorySchemeRef);
	    }
	    if (orgSchemeRef != null) {
	        returnSet.addAll(orgSchemeRef);
	    }
	    if (hclRef != null) {
	        returnSet.addAll(hclRef);
	    }
	    return returnSet;
	}
}
