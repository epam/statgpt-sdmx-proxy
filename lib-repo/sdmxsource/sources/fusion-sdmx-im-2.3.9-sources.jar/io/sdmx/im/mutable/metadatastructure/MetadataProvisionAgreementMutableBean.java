package io.sdmx.im.mutable.metadatastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.im.beans.metadatastructure.MetadataProvisionAgreementBeanImpl;

public class MetadataProvisionAgreementMutableBean extends MetadataTargetIdentifierMutable implements IMetadataProvisionAgreementMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean metadataflowRef;
	private StructureReferenceBean metadataProviderRef;
	
	public MetadataProvisionAgreementMutableBean() {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVISION);
	}

	public MetadataProvisionAgreementMutableBean(DataflowBean dataflowBean, DataProviderBean dataProviderBean) {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVISION);
		this.metadataflowRef = dataflowBean.asReference();
		this.metadataProviderRef = dataProviderBean.asReference();
		this.setAgencyId(dataflowBean.getAgencyId());
		this.setId(dataflowBean.getId() + "_" + dataProviderBean.getId());
		this.setVersion("1.0");
		this.addName("en", dataProviderBean.getName() + " for "+ dataflowBean.getName());
	}
	
	public MetadataProvisionAgreementMutableBean(MetadataProvisionAgreementBean bean) {
		super(bean);
		if(bean.getMetadataflowRef() != null) {
			this.metadataflowRef = bean.getMetadataflowRef().asMutable();
		}
		
		if(bean.getMetadataProviderRef() != null) {
			this.metadataProviderRef = bean.getMetadataProviderRef().asMutable();
		}
	}
           
	@Override
	public StructureReferenceBean getMetadataflowRef() {
		return metadataflowRef;
	}

	@Override
	public StructureReferenceBean getMetadataProviderRef() {
		return metadataProviderRef;
	}

	@Override
	public void setMetadataflowRef(StructureReferenceBean structureUseage) {
		this.metadataflowRef = structureUseage;
	}

	@Override
	public void setMetadataProviderRef(StructureReferenceBean dataproviderRef) {
		this.metadataProviderRef = dataproviderRef;
	}

	@Override
	public MetadataProvisionAgreementBean getImmutableInstance() {
		return new MetadataProvisionAgreementBeanImpl(this);
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (metadataflowRef != null) {
	        returnSet.add(metadataflowRef);
	    }
	    if (metadataProviderRef != null) {
	        returnSet.add(metadataProviderRef);
	    }
	    return returnSet;
	}
}