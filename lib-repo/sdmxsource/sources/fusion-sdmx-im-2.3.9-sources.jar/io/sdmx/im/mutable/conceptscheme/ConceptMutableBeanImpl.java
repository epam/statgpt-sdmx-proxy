
package io.sdmx.im.mutable.conceptscheme;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.structure.ValidityPeriodItemMutableBean;


public class ConceptMutableBeanImpl extends ValidityPeriodItemMutableBean implements ConceptMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String parent;
	private String parentAgency;
	private RepresentationMutableBean coreRepresentation;
	private StructureReferenceBean isoConceptReference;
	
	public ConceptMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT);
	}

	public ConceptMutableBeanImpl(ConceptBean bean, MutableBean parent) {
		super(bean, parent, bean.getValidityPeriod());
		if(bean.getRepresentation() != null) {
			this.coreRepresentation = new RepresentationMutableBeanImpl(bean.getRepresentation(), this);
		}
		if(bean.getIsoConceptReference() != null) {
			this.isoConceptReference = bean.getIsoConceptReference().asMutable();
		}
		this.parent = bean.getParentConcept();
		this.parentAgency = bean.getParentAgency();
	}
	
	/**
	 * Creates a new instance with an id and an english name
	 * @param id
	 * @param name
	 * @return
	 */
	public static ConceptMutableBean getInstance(String id, String name) {
		ConceptMutableBean newInstance = new ConceptMutableBeanImpl();
		newInstance.setId(id);
		newInstance.addName("en", name);
		return newInstance;
	}
	
	@Override
	public IdentifiableMutableBean setId(String id) {
		ConceptSchemeMutableBean maintMutable = getParent(ConceptSchemeMutableBean.class, false);
		if(maintMutable != null && getId() != null) {
			if(maintMutable.getItems() != null) {
				for(ConceptMutableBean concept : maintMutable.getItems()) {
					if(concept.getParentConcept() != null && concept.getParentConcept().equals(getId())) {
						concept.setParentConcept(id);
					}
				}
			}
		}
		super.setId(id);
		return this;
	}
	
	@Override
	public void setParentConcept(String parent) {
		this.parent = parent;
	}

	@Override
	public void setParentAgency(String parentAgency) {
		this.parentAgency = parentAgency;
	}

	@Override
	public boolean isStandAloneConcept() {
		return false;
	}

	@Override
	public RepresentationMutableBean getCoreRepresentation() {
		return coreRepresentation;
	}

	@Override
	public void setCoreRepresentation(RepresentationMutableBean coreRepresentation) {
		this.coreRepresentation = coreRepresentation;
	}

	@Override
	public StructureReferenceBean getIsoConceptReference() {
		return isoConceptReference;
	}

	@Override
	public void setIsoConceptReference(StructureReferenceBean isoConceptReference) {
		this.isoConceptReference = isoConceptReference;
	}

	@Override
	public String getParentConcept() {
		return parent;
	}

	@Override
	public String getParentAgency() {
		return parentAgency;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(coreRepresentation, composites);
		return composites;
	}
}
