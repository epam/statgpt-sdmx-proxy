package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.im.beans.base.OrganisationUnitSchemeBeanImpl;

public class OrganisationUnitSchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<OrganisationUnitMutableBean> implements OrganisationUnitSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public OrganisationUnitSchemeMutableBeanImpl(OrganisationUnitSchemeBean bean) {
		super(bean);
		for(OrganisationUnitBean organisationUnit : bean.getItems()) {
			addItem(new OrganisationUnitMutableBeanImpl(organisationUnit, this));
		}
	}
	
	@Override
	public OrganisationUnitMutableBean createItem(String id, String name) {
		OrganisationUnitMutableBean orgUnit = new OrganisationUnitMutableBeanImpl();
		orgUnit.setId(id);
		orgUnit.addName("en", name);
		addItem(orgUnit);
		return orgUnit;
	}

	public OrganisationUnitSchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME);
	}

	@Override
	public OrganisationUnitSchemeBean getImmutableInstance() {
		return new OrganisationUnitSchemeBeanImpl(this);
	}

	
}