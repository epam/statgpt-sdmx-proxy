package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class DataConsumerMutableBeanImpl extends OrganisationMutableBeanImpl implements DataConsumerMutableBean {
	private static final long serialVersionUID = 1L;
	
	public DataConsumerMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATA_CONSUMER);
	}

	public DataConsumerMutableBeanImpl(DataConsumerBean bean, MutableBean parent) {
		super(bean, parent);
	}
}
