package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.beans.registry.CubeRegionBeanImpl;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class CubeRegionMutableBeanImpl extends MutableBeanImpl implements CubeRegionMutableBean {
	private static final long serialVersionUID = 1L;
	private List<KeyValuesMutable> keyValues = new ArrayList<>();
	private List<KeyValuesMutable> attributeValues = new ArrayList<>();
	
	public CubeRegionMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CUBE_REGION);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CubeRegionMutableBeanImpl(CubeRegionBean bean, MutableBean parent) {
		super(bean, parent);
		if (ObjectUtil.validCollection(bean.getKeyValues())) {
			for(KeyValues mutable : bean.getKeyValues()) {
				this.keyValues.add(new KeyValuesMutableImpl(mutable, this));
			}
		}
		if (ObjectUtil.validCollection(bean.getAttributeValues())) {
			for(KeyValues mutable : bean.getAttributeValues()) {
				this.attributeValues.add(new KeyValuesMutableImpl(mutable, this));
			}
		}
	}

	@Override
	public List<KeyValuesMutable> getKeyValues() {
		return this.keyValues;
	}

	@Override
	public void setKeyValues(List<KeyValuesMutable> keyvalues) {
		if (keyValues != null)
			this.keyValues = keyvalues;
	}

	@Override
	public void addKeyValues(KeyValuesMutable inputValue) {
		if (inputValue == null) {
			return;
		}
		this.keyValues.add(inputValue);
	}

	@Override
	public List<KeyValuesMutable> getAttributeValues() {
		return this.attributeValues;
	}

	@Override
	public void setAttributeValues(List<KeyValuesMutable> attvalues) {
		if (attvalues != null)
			this.attributeValues = attvalues;
	}

	@Override
	public void addAttributeValue(KeyValuesMutable attvalue) {
		this.attributeValues.add(attvalue);
	}

	public CubeRegionBean createMutableInstance(ContentConstraintBean parent) {
		return new CubeRegionBeanImpl(this, parent); 
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(keyValues, composites);
        super.addToCompositeSet(attributeValues, composites);
        return composites;
    }
}