package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;

/**
 * <p>A specialisation of {@link TimeComponentMapMutableBean} used to describe a numerical representation of time, and how this maps to SDMX Time Periods.</p>
 * <br/>
 * <p>For example 1605719750 is 2020-11-18 if the Epoch is milliseconds and the base period is 1970 with output frequency as daily </p>
 */
public class EpochMapMutableBean extends TimeComponentMapMutableBean implements IEpochMapMutableBean {
	private static final long serialVersionUID = 1L;
	private String basePeriod;
	private EPOCH epochInterval;
	
	public EpochMapMutableBean() {}

	public EpochMapMutableBean(IEpochMapBean bean, StructureMapMutableBean parent) {
		super(bean, parent);
		this.basePeriod = bean.getBasePeriod().getDateInSdmxFormat();
		this.epochInterval = bean.getEpochInterval();
	}
	
	@Override
	public String getBasePeriod() {
		return basePeriod;
	}

	@Override
	public IEpochMapMutableBean setBasePeriod(String basePeriod) {
		this.basePeriod = basePeriod;
		return this;
	}
	
	@Override 
	public EPOCH getEpochInterval() {
		return epochInterval;
	}
	
	@Override
	public IEpochMapMutableBean setEpochInterval(EPOCH epochInterval) {
		this.epochInterval = epochInterval;
		return this;
	}
	
}
