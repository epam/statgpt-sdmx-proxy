package io.sdmx.im.mutable.base;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.im.beans.base.TimeRangeBeanImpl;

public class TimeRangeMutableBeanImpl extends MutableBeanImpl implements TimeRangeMutableBean {
	
	private static final long serialVersionUID = -1105081442071478375L;
	
	private SdmxDate startDate;
	private SdmxDate endDate;
	private boolean isRange;
	private boolean isStartInclusive;
	private boolean isEndInclusive;
	
	private SdmxDate validFrom;
	private SdmxDate validTo;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEFAULT CONSTRUCTOR						 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public TimeRangeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.TIME_RANGE);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public TimeRangeMutableBeanImpl(TimeRangeBean immutable) {
		super(SDMX_STRUCTURE_TYPE.TIME_RANGE);
		if(immutable.getStartDate() != null) {
			this.startDate =immutable.getStartDate();
		}
		if(immutable.getEndDate() != null) {
			this.endDate = immutable.getEndDate();
		}
		this.isRange = immutable.isRange();
		this.isStartInclusive = immutable.isStartInclusive();
		this.isEndInclusive = immutable.isEndInclusive();
		if(immutable.getValidFrom() != null) {
			validFrom = immutable.getValidFrom();
		}
		if(immutable.getValidTo() != null) {
			validTo = immutable.getValidTo();
		}
	}
	
	@Override
	public boolean isRange() {
		return isRange;
	}
	
	@Override
	public void setIsRange(boolean isRange) {
		this.isRange = isRange;
	}

	@Override
	public SdmxDate getStartDate() {
		if(startDate == null) {
			return null;
		}
		return this.startDate;
	}

	@Override
	public SdmxDate getEndDate() {
		if(endDate == null) {
			return null;
		}
		return this.endDate;
	}

	@Override
	public boolean isStartInclusive() {
		return isStartInclusive;
	}

	@Override
	public boolean isEndInclusive() {
		return isEndInclusive;
	}

	@Override
	public void setStartDate(SdmxDate start) {
		this.startDate = start;
	}

	@Override
	public void setEndDate(SdmxDate end) {
		this.endDate = end;
	}

	@Override
	public void setIsStartInclusive(boolean includeStart) {
		this.isStartInclusive = includeStart;
	}

	@Override
	public void setIsEndInclusive(boolean includeEnd) {
		this.isEndInclusive = includeEnd;
	}

	@Override
	public SdmxDate getValidFrom() {
		return validFrom;
	}

	@Override
	public void setValidFrom(SdmxDate validFrom) {
		this.validFrom = validFrom;
	}

	@Override
	public SdmxDate getValidTo() {
		return validTo;
	}

	@Override
	public void setValidTo(SdmxDate validTo) {
		this.validTo = validTo;
	}

	@Override
	public TimeRangeBean createImmutableInstance(SdmxStructureBean parent) {
		return new TimeRangeBeanImpl(this,parent);
	}
}
