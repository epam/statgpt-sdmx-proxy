package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

public class ComponentMapMutableBeanImpl extends AnnotableMutableBeanImpl implements ComponentMapMutableBean {
	private static final long serialVersionUID = 3882017582441362269L;
	private List<String> mapConceptRef;
	private List<String> mapTargetConceptRef;
	private RepresentationMapRefMutableBean repMapRef;


	public ComponentMapMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.COMPONENT_MAP);
	}

	public ComponentMapMutableBeanImpl(ComponentMapBean compMap, MutableBean parent) {
		super(compMap, parent);
		if(compMap.getMapConceptRef() != null) {
			mapConceptRef = new ArrayList<>(compMap.getMapConceptRef());
		}
		if(compMap.getMapTargetConceptRef() != null) {
			mapTargetConceptRef = new ArrayList<>(compMap.getMapTargetConceptRef());
		}
		if(compMap.getRepMapRef() != null) {
			repMapRef = new RepresentationMapRefMutableBeanImpl(compMap.getRepMapRef(), this);
		}
	}

	@Override
	public List<String> getMapConceptRef() {
		return mapConceptRef;
	}

	@Override
	public void setMapConceptRef(List<String> mapConceptRef) {
		this.mapConceptRef = mapConceptRef;
	}

	@Override
	public List<String> getMapTargetConceptRef() {
		return mapTargetConceptRef;
	}

	@Override
	public void setMapTargetConceptRef(List<String> mapTargetConceptRef) {
		this.mapTargetConceptRef = mapTargetConceptRef;
	}
	
	

	@Override
	public void addMapConceptRef(String sourceRef) {
		if(mapConceptRef == null) {
			mapConceptRef = new ArrayList<>();
		}
		mapConceptRef.add(sourceRef);
	}

	@Override
	public void addMapTargetConceptRef(String targetRef) {
		if(mapTargetConceptRef == null) {
			mapTargetConceptRef = new ArrayList<>();
		}
		mapTargetConceptRef.add(targetRef);
	}

	@Override
	public RepresentationMapRefMutableBean getRepMapRef() {
		return repMapRef;
	}

	@Override
	public void setRepMapRef(RepresentationMapRefMutableBean repMapRef) {
		this.repMapRef = repMapRef;
	}

	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(repMapRef, composites);
		return composites;
	}
	
	@Override
	public String toString() {
		return this.mapConceptRef+"-"+this.mapTargetConceptRef;
	}
}
