package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.structure.SDMXBeanUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public abstract class MutableBeanImpl implements MutableBean {
	private static final long serialVersionUID = 1L;
	protected SDMX_STRUCTURE_TYPE structureType;
	private MutableBean parent;


	protected MutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		this.structureType = structureType;
	}

	protected MutableBeanImpl(SDMXBean createdFrom, MutableBean parent) {
		this.structureType = createdFrom.getStructureType();
		this.parent = parent;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getStructureType() {
		return structureType;
	}

	protected static TERTIARY_BOOL createTertiary(boolean isSet, boolean value) {
		return SDMXBeanUtil.createTertiary(isSet, value);
	}

	@Override
    public Set<MutableBean> getComposites() {
		return new HashSet<>();
	}

	@Override
    public MutableBean getParent() {
		return parent;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> T getParent(Class<T> type, boolean includeThisType) {
		if(parent != null) {
			if(type.isAssignableFrom(parent.getClass())) {
				T returnObj = (T)parent;
				return returnObj;
			} else {
				return parent.getParent(type, false);
			}
		}
		if(type.isAssignableFrom(this.getClass())) {
			return (T)this;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> Set<T> getComposites(Class<T> type) {
		Set<T> returnSet = new HashSet<>();
		for(MutableBean currentComposite : getComposites()) {
			if(type.isAssignableFrom(currentComposite.getClass())) {
				returnSet.add((T)currentComposite);
			}
		}
		return returnSet;
	}

	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		return new ArrayList<>();
	}

	@Override
	public final List<StructureReferenceBean> getStructureReferences() {
		List<StructureReferenceBean> returnSet = getStructureReferencesInternal();
		if(returnSet == null) {
			returnSet = new ArrayList<>();
		}
		for(MutableBean bean : getComposites()) {
			returnSet.addAll(bean.getStructureReferences());
		}
		return returnSet;
	}
	
	protected StructureReferenceBean getStructureReference(ICrossReferenceBean xsRef) {
		if(xsRef != null) {
			return new StructureReferenceBeanImpl(xsRef.getTargetUrn());
		}
		return null;
	}
	
	protected List<StructureReferenceBean> getStructureReference(List<? extends ICrossReferenceBean<?>> xsRefs) {
		List<StructureReferenceBean> returnList = new ArrayList<>();
		if(xsRefs != null) {
			for(ICrossReferenceBean currentRef : xsRefs) {
				returnList.add(getStructureReference(currentRef));
			}
		}
		return returnList;
	}


	protected void addToCompositeSet(Collection<? extends MutableBean> comp, Set<MutableBean> compositesSet) {
		if (comp != null) {
			for(MutableBean composite : comp) {
				addToCompositeSet(composite, compositesSet);
			}
		}
	}

	protected void addToCompositeSet(MutableBean composite, Set<MutableBean> composites) {
		if (composite != null) {
			composites.add(composite);

			//Add Bean's Composites
			Set<MutableBean> getComposites = composite.getComposites();
			if (getComposites != null) {
				composites.addAll(getComposites);
			}
		}
	}
}
