package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;

public abstract class ItemSchemeMapMutableBeanImpl<T extends ItemMapMutableBean> extends SchemeMapMutableBeanImpl implements ItemSchemeMapMutableBean<T> {
	private static final long serialVersionUID = 1L;

	private List<T> items = new ArrayList<>();

	public ItemSchemeMapMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public ItemSchemeMapMutableBeanImpl(ItemSchemeMapBean bean, MutableBean parent) {
		super(bean, parent);
	}

	@Override
	public void setItems(List<T> items) {
		this.items = items;
	}

	@Override
	public void addItem(T item) {
		this.items.add(item);
	}

	@Override
	public List<T> getItems() {
		return items;
	}

	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(items, composites);
		return composites;
	}
	
	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnReferences = super.getStructureReferencesInternal();
		StructureReferenceBean sourceScheme = this.getSourceRef();
		StructureReferenceBean targetScheme = this.getTargetRef();
		if(this.getItems() != null) {
			for(ItemMapMutableBean itemMap : this.getItems()) {
				if(sourceScheme != null) {
					returnReferences.add(new StructureReferenceBeanImpl(sourceScheme, getItemType(), itemMap.getSourceId()));
				}
				if(targetScheme != null) {
					returnReferences.add(new StructureReferenceBeanImpl(targetScheme, getItemType(), itemMap.getTargetId()));
				}
			}
		}
		return returnReferences;
	}
	
	protected abstract SDMX_STRUCTURE_TYPE getItemType();
}