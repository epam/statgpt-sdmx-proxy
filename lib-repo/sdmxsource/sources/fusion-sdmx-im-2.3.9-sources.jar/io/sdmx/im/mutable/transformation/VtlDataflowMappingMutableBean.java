package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlDataflowMappingMutableBean;

public class VtlDataflowMappingMutableBean extends VtlMappingMutableBean implements IVtlDataflowMappingMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String fromMethod;
	private String toMethod;
	private List<String> fromSubSpace;
	private List<String> toSubSpace;
	
	public VtlDataflowMappingMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_DATAFLOW_MAPPING);
	}

	public VtlDataflowMappingMutableBean(IVtlDataflowMappingBean bean, MutableBean parent) {
		super(bean, parent);
		this.fromMethod = bean.getFromMethod();
		this.toMethod = bean.getToMethod();
		if(bean.getFromSubSpace() != null) {
			this.fromSubSpace = new ArrayList<>(bean.getFromSubSpace());
		}
		if(bean.getToSubSpace() != null) {
			this.toSubSpace = new ArrayList<>(bean.getToSubSpace());
		}
	}

	@Override
	public String getFromMethod() {
		return fromMethod;
	}

	@Override
	public void setFromMethod(String fromMethod) {
		this.fromMethod = fromMethod;
	}

	@Override
	public String getToMethod() {
		return toMethod;
	}

	@Override
	public void setToMethod(String toMethod) {
		this.toMethod = toMethod;
	}

	@Override
	public List<String> getFromSubSpace() {
		return fromSubSpace;
	}

	@Override
	public void setFromSubSpace(List<String> fromSubSpace) {
		this.fromSubSpace = fromSubSpace;
	}

	@Override
	public List<String> getToSubSpace() {
		return toSubSpace;
	}

	@Override
	public void setToSubSpace(List<String> toSubSpace) {
		this.toSubSpace = toSubSpace;
	}
}
