package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.CONDITION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class ConditionalAttributeMappingBeanMutableBeanImpl extends MutableBeanImpl implements ConditionalAttributeMappingBeanMutableBean {
	private static final long serialVersionUID = 1L;
	private String attributeValue;
	private CONDITION condition;
	private String conditionRule;
	
	public ConditionalAttributeMappingBeanMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_CONDITIONAL_ATTR);
	}

	public ConditionalAttributeMappingBeanMutableBeanImpl(ConditionalAttributeMappingBean condition, MutableBean parent) {
		super(condition, parent);
		this.attributeValue = condition.getAttributeValue();
		this.condition = condition.getCondition();
		this.conditionRule = condition.getConditionDetail();
	}

	@Override
	public String getAttributeValue() {
		return attributeValue;
	}

	@Override
	public void setAttributeValue(String attVal) {
		this.attributeValue = attVal;
	}

	@Override
	public CONDITION getCondition() {
		return condition;
	}

	@Override
	public void setCondition(CONDITION condition) {
		this.condition = condition;
	}

	@Override
	public String getConditionDetail() {
		return conditionRule;
	}

	@Override
	public void setConditionDetail(String rule) {
		this.conditionRule = rule;
	}
}
