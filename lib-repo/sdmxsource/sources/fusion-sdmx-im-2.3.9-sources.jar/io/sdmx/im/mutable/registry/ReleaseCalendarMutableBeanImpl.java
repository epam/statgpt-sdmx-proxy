
package io.sdmx.im.mutable.registry;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;


public class ReleaseCalendarMutableBeanImpl extends MutableBeanImpl implements ReleaseCalendarMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String periodicity;
	private String offset;
	private String tolerance;
	
	public ReleaseCalendarMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.RELEASE_CALENDAR);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReleaseCalendarMutableBeanImpl(ReleaseCalendarBean bean, MutableBean parent) {
		super(bean, parent);
		this.periodicity = bean.getPeriodicity();
		this.offset = bean.getOffset();
		this.tolerance = bean.getTolerance();
	}

	@Override
	public String getPeriodicity() {
		return this.periodicity;
	}

	@Override
	public void setPeriodicity(String periodicity) {
		this.periodicity = periodicity;
	}

	@Override
	public String getOffset() {
		return this.offset;
	}

	@Override
	public void setOffset(String offset) {
		this.offset = offset;
	}

	@Override
	public String getTolerance() {
		return this.tolerance;
	}

	@Override
	public void setTolerance(String tolerance) {
		this.tolerance = tolerance;
	}
}
