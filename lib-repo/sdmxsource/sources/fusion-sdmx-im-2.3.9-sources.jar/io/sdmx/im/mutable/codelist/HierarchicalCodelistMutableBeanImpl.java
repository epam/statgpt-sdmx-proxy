package io.sdmx.im.mutable.codelist;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistRefBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.im.beans.codelist.HierarchicalCodelistBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodelistRefMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

@Deprecated
public class HierarchicalCodelistMutableBeanImpl extends MaintainableMutableBeanImpl implements HierarchicalCodelistMutableBean {
    private static final long serialVersionUID = 1L;

    private List<HierarchyMutableBean> hierarchies = new ArrayList<>();
    private List<CodelistRefMutableBean> codelistRef = new ArrayList<>();

    public HierarchicalCodelistMutableBeanImpl() {
        super(SDMX_STRUCTURE_TYPE.HIERARCHICAL_CODELIST);
    }

    public HierarchicalCodelistMutableBeanImpl(HierarchicalCodelistBean bean) {
        super(bean);

        // Convert the lists into mutable bean lists
        if(bean.getHierarchies() != null) {
            for(HierarchyBean currentBean : bean.getHierarchies()) {
                this.addHierarchies(new HierarchyMutableBeanImpl(currentBean));
            }
        }
        if(bean.getCodelistRef() != null) {
            for(CodelistRefBean currentBean : bean.getCodelistRef()) {
                this.addCodelistRef(new CodelistRefMutableBeanImpl(currentBean, this));
            }
        }
    }

    @Override
    public HierarchicalCodelistBean getImmutableInstance() {
        return new HierarchicalCodelistBeanImpl(this);
    }

    @Override
    public void setHierarchies(List<HierarchyMutableBean> hierarchies) {
        if(hierarchies != null) {
            hierarchies.forEach(h-> {
                h.setAgencyId(getAgencyId());
                h.setVersion(getVersion());
            });
        }
        this.hierarchies = hierarchies;
    }

    @Override
    public void setCodelistRef(List<CodelistRefMutableBean> codelistRefs) {
        this.codelistRef = codelistRefs;
    }

    @Override
    public void addHierarchies(HierarchyMutableBean hierarchy) {
        this.hierarchies.add(hierarchy);
    }

    @Override
    public void addCodelistRef(CodelistRefMutableBean codelistRef) {
        this.codelistRef.add(codelistRef);
    }

    @Override
    public List<HierarchyMutableBean> getHierarchies() {
        return hierarchies;
    }

    @Override
    public List<CodelistRefMutableBean> getCodelistRef() {
        return codelistRef;
    }

    @Override
    public Set<MutableBean> getComposites() {
        Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(hierarchies, composites);
        return composites;
    }

    @Override
    public HierarchicalCodelistMutableBean stripItems(Date aDate) {
        if (this.getHierarchies().isEmpty()) {
            return this;
        }

        for (HierarchyMutableBean aHierarchy : this.getHierarchies()) {
            List<CodeRefMutableBean> retVal = evaluateCodeRefs(aHierarchy.getHierarchicalCodeBeans(), aDate);
            aHierarchy.setHierarchicalCodeBeans(retVal);
        }
        return this;
    }

    private List<CodeRefMutableBean> evaluateCodeRefs(List<CodeRefMutableBean> hierarchicalCodeBeans, Date aDate) {
        ArrayList<CodeRefMutableBean> retVal = new ArrayList<>();
        for (CodeRefMutableBean aCodeRef: hierarchicalCodeBeans) {
            if (aCodeRef.hasValidityPeriod()) {
                Optional<SdmxPeriod> itemSdmxPeriod = aCodeRef.getSdmxPeriod();
                if (itemSdmxPeriod.isPresent() && !itemSdmxPeriod.get().isInPeriod(aDate)) {
                    continue;
                }
            }

            retVal.add(aCodeRef);
            if (ObjectUtil.validCollection(aCodeRef.getCodeRefs())) {
                aCodeRef.setCodeRefs(evaluateCodeRefs(aCodeRef.getCodeRefs(), aDate));
            }
        }
        return retVal;
    }
}