package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public class ContactMutableBeanImpl extends MutableBeanImpl implements ContactMutableBean {
	private static final long serialVersionUID = -9000931565464863175L;
	private String id;
	private List<TextTypeWrapperMutableBean> names = new ArrayList<>();
	private List<TextTypeWrapperMutableBean> roles = new ArrayList<>();
	private List<TextTypeWrapperMutableBean> departments = new ArrayList<>();
	private List<String> email = new ArrayList<>();
	private List<String> fax = new ArrayList<>();
	private List<String> telephone = new ArrayList<>();
	private List<String> uri = new ArrayList<>();
	private List<String> x400 = new ArrayList<>();
	
	
	public ContactMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONTACT);
	}
	
	public ContactMutableBeanImpl(ContactBean contact, MutableBean parent) {
		super(contact, parent);
		this.id = contact.getId();
		
		copyTextTypes(contact.getName(), names);
		copyTextTypes(contact.getRole(), roles);
		copyTextTypes(contact.getDepartments(), departments);
		this.email = new ArrayList<>(contact.getEmail());
		this.fax = new ArrayList<>(contact.getFax());
		this.telephone = new ArrayList<>(contact.getTelephone());
		this.uri = new ArrayList<>(contact.getUri());
		this.x400 = new ArrayList<>(contact.getX400());
	}
	
	private void copyTextTypes(List<TextTypeWrapper> textType, List<TextTypeWrapperMutableBean> copyTo) {
		if(textType != null) {
			for (TextTypeWrapper currentTextType : textType) {
				copyTo.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}
	
	@Override
	public void addName(TextTypeWrapperMutableBean name) {
		if(this.names == null) {
			this.names = new ArrayList<>();
		}
		this.names.add(name);
	}
	@Override
	public void addRole(TextTypeWrapperMutableBean role) {
		if(this.roles == null) {
			this.roles = new ArrayList<>();
		}
		this.roles.add(role);
	}
	@Override
	public void addDepartment(TextTypeWrapperMutableBean dept) {
		if(this.departments == null) {
			this.departments = new ArrayList<>();
		}
		this.departments.add(dept);
	}
	
	@Override
	public void addEmail(String email) {
		if(this.email == null) {
			this.email = new ArrayList<>();
		}
		this.email.add(email);
	}
	
	@Override
	public void addFax(String fax) {
		if(this.fax == null) {
			this.fax = new ArrayList<>();
		}
		this.fax.add(fax);
	}
	
	@Override
	public void addTelephone(String telephone) {
		if(this.telephone == null) {
			this.telephone = new ArrayList<>();
		}
		this.telephone.add(telephone);
	}
	
	@Override
	public void addUri(String uri) {
		if(this.uri == null) {
			this.uri = new ArrayList<>();
		}
		this.uri.add(uri);	
	}
	
	@Override
	public void addX400(String x400) {
		if(this.x400 == null) {
			this.x400 = new ArrayList<>();
		}
		this.x400.add(x400);
	}
	
	@Override
	public String getId() {
		return id;
	}
	@Override
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public List<TextTypeWrapperMutableBean> getNames() {
		List<TextTypeWrapperMutableBean> copy = new ArrayList<>(names);
		return TextTypeUtil.optionalFilterOnMutableTextType(copy);
	}
	@Override
	public void setNames(List<TextTypeWrapperMutableBean> name) {
		this.names = name;
	}
	@Override
	public List<TextTypeWrapperMutableBean> getRoles() {
		return roles;
	}
	@Override
	public void setRoles(List<TextTypeWrapperMutableBean> role) {
		this.roles = role;
	}
	@Override
	public List<TextTypeWrapperMutableBean> getDepartments() {
		return departments;
	}
	@Override
	public void setDepartments(List<TextTypeWrapperMutableBean> departments) {
		this.departments = departments;
	}
	@Override
	public List<String> getEmail() {
		return email;
	}
	@Override
	public void setEmail(List<String> email) {
		this.email = email;
	}
	@Override
	public List<String> getFax() {
		return fax;
	}
	@Override
	public void setFax(List<String> fax) {
		this.fax = fax;
	}
	@Override
	public List<String> getTelephone() {
		return telephone;
	}
	@Override
	public void setTelephone(List<String> telephone) {
		this.telephone = telephone;
	}
	@Override
	public List<String> getUri() {
		return uri;
	}
	@Override
	public void setUri(List<String> uri) {
		this.uri = uri;
	}
	@Override
	public List<String> getX400() {
		return x400;
	}
	@Override
	public void setX400(List<String> x400) {
		this.x400 = x400;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(names, composites);
	    super.addToCompositeSet(roles, composites);
	    super.addToCompositeSet(departments, composites);
	    return composites;
	}
}