package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.im.beans.registry.MetadataConstraintBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class MetadataConstraintMutableBean extends MaintainableMutableBeanImpl implements IMetadataConstraintMutableBean {

	private List<StructureReferenceBean> attachments;
	private List<KeyValuesMutable> includedTarget;
	private List<KeyValuesMutable> excludedTarget;
	private ReleaseCalendarMutableBean releaseCalendar;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// BUILD EMPTY BEAN					 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataConstraintMutableBean() {
		super(SDMX_STRUCTURE_TYPE.METADATA_CONSTRAINT);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// BUILD FROM IMMUTABLE BEAN			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataConstraintMutableBean(IMetadataConstraintBean immutable) {
		super(immutable);

		if (immutable.getAttachments() != null) {
			attachments = new ArrayList<>();
			for (ICrossReferenceBean<?> reference : immutable.getAttachments()) {
				attachments.add(reference.asMutable());
			}
		}
		if (immutable.getIncludedTarget() != null) {
			includedTarget = new ArrayList<>();
			for (KeyValues keyValues : immutable.getIncludedTarget()) {
				includedTarget.add(new KeyValuesMutableImpl(keyValues, this));
			}
		}
		if (immutable.getExcludedTarget() != null) {
			excludedTarget = new ArrayList<>();
			for (KeyValues keyValues : immutable.getExcludedTarget()) {
				excludedTarget.add(new KeyValuesMutableImpl(keyValues, this));
			}
		}
		if (immutable.getReleaseCalendar() != null) {
			releaseCalendar = new ReleaseCalendarMutableBeanImpl(immutable.getReleaseCalendar(), this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// GET SET							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IMetadataConstraintBean getImmutableInstance() {
		return new MetadataConstraintBean(this);
	}

	@Override
	public List<StructureReferenceBean> getAttachments() {
		return attachments;
	}

	@Override
	public IMetadataConstraintMutableBean setAttachments(List<StructureReferenceBean> constraintAttachments) {
		this.attachments = constraintAttachments;
		return this;
	}

	@Override
	public List<KeyValuesMutable> getIncludedTarget() {
		return includedTarget;
	}

	@Override
	public IMetadataConstraintMutableBean setIncludedTarget(List<KeyValuesMutable> includedTarget) {
		this.includedTarget = includedTarget;
		return this;
	}

	@Override
	public List<KeyValuesMutable> getExcludedTarget() {
		return excludedTarget;
	}

	@Override
	public IMetadataConstraintMutableBean setExcludedTarget(List<KeyValuesMutable> excludedTarget) {
		this.excludedTarget = excludedTarget;
		return this;
	}

	@Override
	public ReleaseCalendarMutableBean getReleaseCalendar() {
		return releaseCalendar;
	}

	@Override
	public IMetadataConstraintMutableBean setReleaseCalendar(ReleaseCalendarMutableBean releaseCalendar) {
		this.releaseCalendar = releaseCalendar;
		return this;
	}
}
