package io.sdmx.im.mutable.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.im.mutable.base.NameableMutableBeanImpl;

public class ProcessStepMutableBeanImpl extends NameableMutableBeanImpl implements ProcessStepMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<InputOutputMutableBean> input = new ArrayList<>();
	private List<InputOutputMutableBean> output = new ArrayList<>();
	private List<TransitionMutableBean> transitions = new ArrayList<>();
	private List<ProcessStepMutableBean> processSteps = new ArrayList<>();
	private ComputationMutableBean computation;

	public ProcessStepMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PROCESS_STEP);
	}

	public ProcessStepMutableBeanImpl (ProcessStepBean bean, MutableBean parent) {
		super(bean, parent);
	
		if(bean.getInput() != null) {
			for(InputOutputBean currentIo : bean.getInput()) {
				this.input.add(new InputOutputMutableBeanImpl(currentIo, this));
			}
		}
		if(bean.getOutput() != null) {
			for(InputOutputBean currentIo : bean.getOutput()) {
				this.output.add(new InputOutputMutableBeanImpl(currentIo, this));
			}
		}
		
		// make into mutable bean lists
		if(bean.getProcessSteps() != null) {
			for(ProcessStepBean currentBean : bean.getProcessSteps()) {
				this.addProcessStep(new ProcessStepMutableBeanImpl(currentBean, this));
			}
		}
		if(bean.getTransitions() != null) {
			for(TransitionBean currentBean : bean.getTransitions()) {
				this.addTransition(new TransitionMutableBeanImpl(currentBean, this));
			}
		}
		if(bean.getComputation() != null) {
			this.computation = new ComputationMutableBeanImpl(bean.getComputation(), this);
		}
	}
	
	@Override
	public List<InputOutputMutableBean> getInput() {
		return input;
	}

	@Override
	public void setInput(List<InputOutputMutableBean> input) {
		this.input = input;
	}

	@Override
	public List<InputOutputMutableBean> getOutput() {
		return output;
	}

	@Override
	public void setOutput(List<InputOutputMutableBean> output) {
		this.output = output;
	}
	
	@Override
	public void addInput(InputOutputMutableBean input) {
		if(this.input == null) {
			this.input = new ArrayList<>();
		}
		this.input.add(input);
	}

	@Override
	public void addOutput(InputOutputMutableBean output) {
		if(this.output == null) {
			this.output = new ArrayList<>();
		}
		this.output.add(output);
	}

	@Override
	public ComputationMutableBean getComputation() {
		return computation;
	}

	@Override
	public void setComputation(ComputationMutableBean computation) {
		this.computation = computation;
	}

	@Override
	public List<TransitionMutableBean> getTransitions() {
		return transitions;
	}
	@Override
	public List<ProcessStepMutableBean> getProcessSteps() {
		return processSteps;
	}

	@Override
	public void setTransitions(List<TransitionMutableBean> transitions) {
		this.transitions = transitions;
	}

	@Override
	public void addTransition(TransitionMutableBean transition) {
		if(this.transitions == null) {
			this.transitions = new ArrayList<>();
		}
		this.transitions.add(transition);
	}
	
	@Override
	public void setProcessSteps(List<ProcessStepMutableBean> processSteps) {
		this.processSteps = processSteps;
	}

	@Override
	public void addProcessStep(ProcessStepMutableBean processStep) {
		this.processSteps.add(processStep);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(input, composites);
        super.addToCompositeSet(output, composites);
        super.addToCompositeSet(transitions, composites);
        super.addToCompositeSet(processSteps, composites);
        super.addToCompositeSet(computation, composites);
        return composites;
    }
}