package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public class TextTypeWrapperMutableBeanImpl extends MutableBeanImpl implements TextTypeWrapperMutableBean {
	private static final long serialVersionUID = 1L;
	private String locale;
	private String value;

	public TextTypeWrapperMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.TEXT_TYPE);
	}

	public TextTypeWrapperMutableBeanImpl(String locale, String value) {
		super(SDMX_STRUCTURE_TYPE.TEXT_TYPE);
		setLocale(locale);
		this.value = value;
	}
	
	public static TextTypeWrapperMutableBean getInstance(String locale, String value) {
		return new TextTypeWrapperMutableBeanImpl(locale, value);
	}

	public TextTypeWrapperMutableBeanImpl(TextTypeWrapper textType, MutableBean parent) {
		super(textType, parent);
		setLocale(textType.getLocale());
		this.value = textType.getValue();
	}

	@Override
	public String getLocale() {
		return locale;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public void setLocale(String locale) {
	    this.locale = (locale == null ? null : locale.trim());
	}

	@Override
	public void setValue(String value) {
		this.value = value;
	}
}