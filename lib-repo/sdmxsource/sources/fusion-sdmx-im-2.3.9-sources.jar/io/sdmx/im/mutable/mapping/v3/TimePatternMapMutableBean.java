package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;

/**
 *  <p>A specialisation of {@link TimeComponentMapMutableBean} used to describe a string representation of time, and how this maps to SDMX Time Periods.</p>
 *  <br/>  
 *  <p>Describes the patterns for each supported time representation e.g. 2002 31 12 could be expressed as YYYY DD MM<p/>
 */
public class TimePatternMapMutableBean extends TimeComponentMapMutableBean implements ITimePatternMapMutableBean {
	private static final long serialVersionUID = 1L;
	private String pattern;
	private String locale;
	
	public TimePatternMapMutableBean() {
	}

	public TimePatternMapMutableBean(ITimePatternMapBean bean, StructureMapMutableBean parent) {
		super(bean, parent);
		this.pattern = bean.getPattern();
		this.locale = bean.getLocale();
	}

	@Override
	public String getPattern() {
		return pattern;
	}
	
	@Override
	public String getLocale() {
		return locale;
	}

	@Override
	public ITimePatternMapMutableBean setLocale(String str) {
		this.locale = str;
		return this;
	}

	@Override
	public ITimePatternMapMutableBean setPattern(String pattern) {
		this.pattern = pattern;
		return this;
	}
	
}
