package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.im.mutable.base.ComponentMutableBeanImpl;

public class AttributeMutableBeanImpl extends ComponentMutableBeanImpl implements AttributeMutableBean {
	private static final long serialVersionUID = -4692032103270271465L;
	private ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel;
	
	private String attachmentGroup;
	private List<String> dimensionReference = new ArrayList<>();
	private List<String> measureReference = new ArrayList<>();
	private List<StructureReferenceBean> conceptRoles = new ArrayList<>();
	
	public AttributeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE);
	}

	public AttributeMutableBeanImpl(AttributeBean bean, MutableBean parent) {
		super(bean, parent);
		this.attachmentLevel = bean.getAttachmentLevel();
		setMandatory(bean.isMandatory());
		this.attachmentGroup = bean.getAttachmentGroup();
		this.dimensionReference = new ArrayList<>(bean.getDimensionReferences());
		this.measureReference = new ArrayList<>(bean.getMeasureReferences());
		if(bean.getConceptRoles() != null) {
			for(ICrossReferenceBean currentConceptRole : bean.getConceptRoles()) {
				this.conceptRoles.add(currentConceptRole.asMutable());
			}
		}
	}
	
	@Override
	public void addConceptRole(StructureReferenceBean sRef) {
		if(conceptRoles == null) {
			conceptRoles = new ArrayList<>();
		}
		conceptRoles.add(sRef);
	}

	@Override
	public List<StructureReferenceBean> getConceptRoles() {
		return conceptRoles;
	}

	@Override
	public void setConceptRoles(List<StructureReferenceBean> conceptRoles) {
		this.conceptRoles = conceptRoles;
	}

	@Override
	public ATTRIBUTE_ATTACHMENT_LEVEL getAttachmentLevel() {
		return attachmentLevel;
	}

	@Override
	public AttributeMutableBean setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel) {
		this.attachmentLevel = attachmentLevel;
		return this;
	}

	@Override
	public String getAttachmentGroup() {
		return attachmentGroup;
	}

	@Override
	public AttributeMutableBean setAttachmentGroup(String attachmentGroup) {
		this.attachmentGroup = attachmentGroup;
		return this;
	}

	@Override
	public List<String> getDimensionReferences() {
		return dimensionReference;
	}
	

	
	@Override
	public List<String> getMeasureReferences() {
		return measureReference;
	}

	@Override
	public AttributeMutableBean addMeasureReference(String measureReference) {
		if(this.measureReference == null) {
			this.measureReference = new ArrayList<>();
		}
		this.measureReference.add(measureReference);
		return this;
	}

	@Override
	public AttributeMutableBean setMeasureReferences(List<String> measureReference) {
		this.measureReference = measureReference;
		return this;
	}

	@Override
	public AttributeMutableBean addDimensionReferences(String dimensionRef) {
		if(this.dimensionReference == null) {
			this.dimensionReference = new ArrayList<>();
		}
		this.dimensionReference.add(dimensionRef);
		return this;
	}

	@Override
	public AttributeMutableBean setDimensionReferences(List<String> dimensionReference) {
		this.dimensionReference = dimensionReference;
		return this;
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> references =  super.getStructureReferencesInternal();
		if(conceptRoles != null) {
			references.addAll(conceptRoles);
		}
		return references;
	}
}
