package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.im.beans.transformation.TransformationSchemeBean;

public class TransformationSchemeMutableBean extends VtlSchemeMutableBean<ITransformationMutableBean> implements ITransformationSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	private StructureReferenceBean vtlMappingSchemeRef;
	private StructureReferenceBean namePersonalisationSchemeRef;
	private StructureReferenceBean customTypeSchemeRef;
	private List<StructureReferenceBean> rulesetSchemeRef;
	private List<StructureReferenceBean> userDefinedOperatorSchemeRef;
	
	public TransformationSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME);
	}

	public TransformationSchemeMutableBean(ITransformationSchemeBean bean) {
		super(bean);
		this.items = new ArrayList<>(bean.getItems().size());
		for(ITransformationBean item : bean.getItems()) {
			this.items.add(new TransformationMutableBean(item, this));
		}
		this.vtlMappingSchemeRef = getStructureReference(bean.getVtlMappingSchemeRef());
		this.namePersonalisationSchemeRef = getStructureReference(bean.getNamePersonalisationSchemeRef());
		this.customTypeSchemeRef = getStructureReference(bean.getCustomTypeSchemeRef());
		this.rulesetSchemeRef = getStructureReference(bean.getRulesetSchemeRef());
		this.userDefinedOperatorSchemeRef = getStructureReference(bean.getUserDefinedOperatorSchemeRef());
	}
	
	@Override
	public ITransformationMutableBean addTransformation(String id, boolean isPersistent, String result, String expression) {
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
		ITransformationMutableBean bean = new TransformationMutableBean();
		bean.setId(id);
		bean.setPersistent(isPersistent);
		bean.setResult(result);
		bean.setExpression(expression);
		this.items.add(bean);
		return bean;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean>  returnList = super.getStructureReferencesInternal();
		if(vtlMappingSchemeRef != null) {
			returnList.add(vtlMappingSchemeRef);
		}
		if(namePersonalisationSchemeRef != null) {
			returnList.add(namePersonalisationSchemeRef);
		}
		if(customTypeSchemeRef != null) {
			returnList.add(customTypeSchemeRef);
		}
		if(rulesetSchemeRef != null) {
			returnList.addAll(rulesetSchemeRef);
		}
		if(userDefinedOperatorSchemeRef != null) {
			returnList.addAll(userDefinedOperatorSchemeRef);
		}
		return returnList;
	}

	@Override
	public StructureReferenceBean getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public void setVtlMappingSchemeRef(StructureReferenceBean vtlMappingSchemeRef) {
		this.vtlMappingSchemeRef = vtlMappingSchemeRef;
	}

	@Override
	public StructureReferenceBean getNamePersonalisationSchemeRef() {
		return namePersonalisationSchemeRef;
	}

	@Override
	public void setNamePersonalisationSchemeRef(StructureReferenceBean namePersonalisationSchemeRef) {
		this.namePersonalisationSchemeRef = namePersonalisationSchemeRef;
	}

	@Override
	public StructureReferenceBean getCustomTypeSchemeRef() {
		return customTypeSchemeRef;
	}

	@Override
	public void setCustomTypeSchemeRef(StructureReferenceBean customTypeSchemeRef) {
		this.customTypeSchemeRef = customTypeSchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getRulesetSchemeRef() {
		return rulesetSchemeRef;
	}

	@Override
	public ITransformationSchemeMutableBean addRulesetSchemeRef(StructureReferenceBean ref) {
		if(ref == null) {
			return this;
		}
		if(this.rulesetSchemeRef == null) {
			this.rulesetSchemeRef = new ArrayList<>();
		}
		this.rulesetSchemeRef.add(ref);
		return this;
	}

	@Override
	public void setRulesetSchemeRef(List<StructureReferenceBean> rulesetSchemeRef) {
		this.rulesetSchemeRef = rulesetSchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getUserDefinedOperatorSchemeRef() {
		return userDefinedOperatorSchemeRef;
	}

	@Override
	public ITransformationSchemeMutableBean addUserDefinedOperatorSchemeRef(StructureReferenceBean ref) {
		if(ref == null) {
			return this;
		}
		if(this.userDefinedOperatorSchemeRef == null) {
			this.userDefinedOperatorSchemeRef = new ArrayList<>();
		}
		this.userDefinedOperatorSchemeRef.add(ref);
		return this;
	}

	@Override
	public void setUserDefinedOperatorSchemeRef(List<StructureReferenceBean> userDefinedOperatorSchemeRef) {
		this.userDefinedOperatorSchemeRef = userDefinedOperatorSchemeRef;
	}
	
	@Override
	public ITransformationSchemeBean getImmutableInstance() {
		return new TransformationSchemeBean(this);
	}
}
