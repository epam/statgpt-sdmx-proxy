package io.sdmx.im.mutable.reference;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistRefBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

@Deprecated
public class CodelistRefMutableBeanImpl extends MutableBeanImpl implements CodelistRefMutableBean {
    private static final long serialVersionUID = 1L;

    private String alias;
    private StructureReferenceBean structureReference;

    public CodelistRefMutableBeanImpl() {
        super(SDMX_STRUCTURE_TYPE.CODE_LIST_REF);
    }

    public CodelistRefMutableBeanImpl(CodelistRefBean bean, MutableBean parent) {
        super((SDMXBean) bean, parent);
        this.alias = bean.getAlias();
        this.structureReference = new StructureReferenceBeanImpl(bean.getCodelistReference().getTargetUrn());
    }

    @Override
    public String getAlias() {
        return alias;
    }

    @Override
    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Override
    public StructureReferenceBean getCodelistReference() {
        return structureReference;
    }

    @Override
    public void setCodelistReference(StructureReferenceBean structureReference) {
        this.structureReference = structureReference;
    }

    @Override
    public List<StructureReferenceBean> getStructureReferencesInternal() {
        List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
        if(structureReference != null) {
            returnSet.add(structureReference);
        }
        return returnSet;
    }

}
