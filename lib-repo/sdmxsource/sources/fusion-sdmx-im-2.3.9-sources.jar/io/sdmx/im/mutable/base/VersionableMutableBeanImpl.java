package io.sdmx.im.mutable.base;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.SdmxReader;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.VersionableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.VersionableMutableBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class VersionableMutableBeanImpl extends NameableMutableBeanImpl implements VersionableMutableBean {

	private static final long serialVersionUID = 3L;

	private Date endDate;
	private Date startDate;
	protected String version;
	
	public VersionableMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public VersionableMutableBeanImpl(VersionableBean bean, MutableBean parent) {
		super(bean, parent);
		copyVersionableProperties(bean, false);
	}
	
	@Override
	public void copyVersionableProperties(VersionableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyNameableProperties(bean, includeInheritedProperties);
		}
		if(bean.getValidityPeriod() != null) {
			if(bean.getValidityPeriod().hasStartPeriod()) {
				setStartDate(bean.getValidityPeriod().getStartPeriod().getDate());
			}
			if(bean.getValidityPeriod().hasEndPeriod()) {
				setEndDate(bean.getValidityPeriod().getEndPeriod().getDate());
			}
		}
		setVersion(bean.getVersion().toString());
	}
	
	@Override
	public void copyVersionableProperties(VersionableMutableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyNameableProperties(bean, includeInheritedProperties);
		}
		if(bean.getSdmxPeriod().isPresent()) {
			if(bean.getSdmxPeriod().get().hasStartPeriod()) {
				setStartDate(bean.getSdmxPeriod().get().getStartPeriod().getDate());
			}
			if(bean.getSdmxPeriod().get().hasEndPeriod()) {
				setEndDate(bean.getSdmxPeriod().get().getEndPeriod().getDate());
			}
		}
		setVersion(bean.getVersion());
	}
	
	@Override
	public VersionableMutableBean setVersion(ISdmxVersion vRef) {
		if(vRef != null) {
			setVersion(vRef.toString());
		} else {
			this.version = null;
		}
		return this;
	}

	@Override
	public VersionableMutableBean setEndDate(Date endDate) {
		this.endDate = endDate;
		return this;
	}

	@Override
	public VersionableMutableBean setStartDate(Date startDate) {
		this.startDate = startDate;
		return this;
	}

	@Override
	public Date getEndDate() {
		return endDate;
	}

	@Override
	public Date getStartDate() {
		return startDate;
	}

	@Override
	public VersionableMutableBean setVersion(String version) {
		if(!ObjectUtil.validString(version)) {
			version = "1.0";
		}
		this.version = version;
		return this;
	}

	@Override
	public String getVersion() {
		return version;
	}

	protected void buildMaintainableAttributes(SdmxReader reader) {
		super.buildIdentifiableAttributes(reader);
		Map<String, String> attributes = reader.getAttributes();
		if(attributes.containsKey("validFrom")) {
			this.startDate = SdmxDateImpl.getSdmxDate(attributes.get("validFrom")).getDate();
		}
		if(attributes.containsKey("validTo")) {
			this.endDate = SdmxDateImpl.getSdmxDate(attributes.get("validTo")).getDate();
		}
		this.version = attributes.get("version");
	}

	@Override
	public Optional<SdmxPeriod> getSdmxPeriod() {
		return DateUtil.parseStartAndEndDateToSdmxPeriod(startDate, endDate);
	}
}
