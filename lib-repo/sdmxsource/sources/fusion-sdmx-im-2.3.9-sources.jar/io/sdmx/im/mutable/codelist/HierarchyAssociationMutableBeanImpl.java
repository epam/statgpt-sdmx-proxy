package io.sdmx.im.mutable.codelist;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.im.beans.codelist.HierarchyAssociationBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class HierarchyAssociationMutableBeanImpl extends MaintainableMutableBeanImpl implements HierarchyAssociationMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean hierarchyRef;
	private StructureReferenceBean maintainableRef;
	private StructureReferenceBean contextRef;
	
	public HierarchyAssociationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION);
	}	
	
	public HierarchyAssociationMutableBeanImpl(HierarchyAssociationBean bean) {
		super(bean);
		this.hierarchyRef = new StructureReferenceBeanImpl(bean.getHierarchyRef().getTargetUrn());
		this.maintainableRef = new StructureReferenceBeanImpl(bean.getLinkedStructureRef().getTargetUrn());
		if(bean.getContextStructureRef() != null) {
			this.contextRef = new StructureReferenceBeanImpl(bean.getContextStructureRef().getTargetUrn());
		}
	}


	@Override
	public HierarchyAssociationBean getImmutableInstance() {
		return new HierarchyAssociationBeanImpl(this);
	}

	@Override
	public StructureReferenceBean getHierarchyRef() {
		return hierarchyRef;
	}

	@Override
	public HierarchyAssociationMutableBean setHierarchyRef(StructureReferenceBean ref) {
		this.hierarchyRef = ref;
		return this;
	}

	@Override
	public StructureReferenceBean getLinkedStructure() {
		return maintainableRef;
	}

	@Override
	public HierarchyAssociationMutableBean setLinkedStructure(StructureReferenceBean ref) {
		this.maintainableRef = ref;
		return this;
	}

	@Override
	public StructureReferenceBean getContextStructure() {
		return contextRef;
	}

	@Override
	public HierarchyAssociationMutableBean setContextStructure(StructureReferenceBean ref) {
		this.contextRef = ref;
		return this;
	}

}
