package io.sdmx.im.mutable.codelist;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;
import io.sdmx.im.beans.codelist.GeoGridCodelistBean;

public class GeoGridCodelistMutableBean extends CodelistMutableBeanImpl implements IGeoGridCodelistMutableBean {
	private static final long serialVersionUID = 19743748L;

	private String gridDefinition;
	
	public GeoGridCodelistMutableBean() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}
	
	
	
	public GeoGridCodelistMutableBean(IGeoGridCodelistBean cl) {
		super(cl);
		this.gridDefinition = cl.getGridDefinition();
	}

	
	@Override
	protected CodeMutableBean buildMutableCode(CodeBean code) {
		return new GeoGridCodeMutableBean((IGeoGridCodeBean)code, this);
	}

	@Override
	public IGeoGridCodeMutableBean createItem(String id, String name) {
		IGeoGridCodeMutableBean code = new GeoGridCodeMutableBean();
		code.setId(id);
		code.addName("en", name);
		addItem(code);
		return code;
	}
	
	@Override
	public String getGridDefinition() {
		return gridDefinition;
	}

	@Override
	public void setGridDefinition(String gridDefinition) {
		this.gridDefinition = gridDefinition;
	}

	@Override
	public IGeoGridCodelistBean getImmutableInstance() {
		return new GeoGridCodelistBean(this);
	}
}