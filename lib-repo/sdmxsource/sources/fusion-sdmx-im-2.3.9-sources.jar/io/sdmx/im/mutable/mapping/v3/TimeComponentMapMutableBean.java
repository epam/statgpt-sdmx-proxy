package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimeComponentMapMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

/**
 * Defines the rules for mapping a Component whose value defines a point in time, but where the syntax of time does not match the SDMX specification, 
 * the exact rules for how the source value is formatted are defined in sub interfaces, which include {@link EpochMapMutableBean} and {@link TimePatternMapMutableBean} 
 */
public abstract class TimeComponentMapMutableBean extends AnnotableMutableBeanImpl implements ITimeComponentMapMutableBean {
	private static final long serialVersionUID = 1L;
	private String sourceComponent;
	private String targetComponent;
	private String outputFrequencyId;
	private String outputFrequencyDimId;
	private PERIOD_POSITION periodResolution;
	
	public TimeComponentMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.TIME_COMPONENT_MAP);
	}

	public TimeComponentMapMutableBean(ITimeComponentMapBean bean, StructureMapMutableBean parent) {
		super(bean, parent);
		this.sourceComponent = bean.getSourceComponent();
		this.targetComponent = bean.getTargetComponent();
		this.outputFrequencyId = bean.getOutputFrequencyId();
		this.periodResolution = bean.getPeriodResolution();
	}

	@Override
	public String getSourceComponent() {
		return sourceComponent;
	}

	@Override
	public ITimeComponentMapMutableBean setSourceComponent(String sourceComponent) {
		this.sourceComponent = sourceComponent;
		return this;
	}

	@Override
	public String getTargetComponent() {
		return targetComponent;
	}

	@Override
	public ITimeComponentMapMutableBean setTargetComponent(String targetComponent) {
		this.targetComponent = targetComponent;
		return this;
	}

	@Override
	public String getOutputFrequencyId() {
		return outputFrequencyId;
	}

	@Override
	public ITimeComponentMapMutableBean setOutputFrequencyId(String outputFrequencyId) {
		this.outputFrequencyId = outputFrequencyId;
		return this;
	}

	@Override
	public String getOutputFrequencyDimId() {
		return outputFrequencyDimId;
	}

	@Override
	public ITimeComponentMapMutableBean setOutputFrequencyDimId(String outputFrequencyDimId) {
		this.outputFrequencyDimId = outputFrequencyDimId;
		return this;
	}

	@Override
	public PERIOD_POSITION getPeriodResolution() {
		return periodResolution;
	}

	@Override
	public ITimeComponentMapMutableBean setPeriodResolution(PERIOD_POSITION periodResolution) {
		this.periodResolution = periodResolution;
		return this;
	}
}
