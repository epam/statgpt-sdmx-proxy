package io.sdmx.im.mutable.metadatastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.im.beans.metadatastructure.MetadataStructureDefinitionBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class MetadataStructureDefinitionMutableBeanImpl extends MaintainableMutableBeanImpl implements MetadataStructureDefinitionMutableBean {
	private static final long serialVersionUID = 720851779528287427L;
	
	private List<MetadataAttributeMutableBean> metadataAttributes = new ArrayList<>();
	
	public MetadataStructureDefinitionMutableBeanImpl(MetadataStructureDefinitionBean bean) {
		super(bean);
		if(bean.getMetadataAttributes() != null) {
			for(MetadataAttributeBean currentBean : bean.getMetadataAttributes()) {
				this.metadataAttributes.add(new MetadataAttributeMutableBeanImpl(currentBean, this));
			}
		}
	}

	public MetadataStructureDefinitionMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.MSD);
	}

	@Override
	public List<MetadataAttributeMutableBean> getMetadataAttributes() {
		return this.metadataAttributes;
	}

	@Override
	public void setMetadataAttributes(List<MetadataAttributeMutableBean> metadataAttributes) {
		this.metadataAttributes = metadataAttributes;
	}

	@Override
	public MetadataAttributeMutableBean addMetadataAttributes(MetadataAttributeMutableBean metadataAttributes) {
		if(this.metadataAttributes == null) {
			this.metadataAttributes = new ArrayList<>();
		}
		this.metadataAttributes.add(metadataAttributes);
		return metadataAttributes;
	}

	@Override
	public MetadataStructureDefinitionBean getImmutableInstance() {
		return new MetadataStructureDefinitionBeanImpl(this);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(metadataAttributes, composites);
        return composites;
    }
}