package io.sdmx.im.mutable.categoryscheme;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.im.beans.categoryscheme.CategorisationBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class CategorisationMutableBeanImpl extends MaintainableMutableBeanImpl implements CategorisationMutableBean {
	private static final long serialVersionUID = 129560498625554240L;
	private StructureReferenceBean categoryRefBean;
	private StructureReferenceBean structureReference;
	
	public CategorisationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CATEGORISATION);
	}

	public CategorisationMutableBeanImpl(CategorisationBean bean) {
		super(bean);
	
		if(bean.getCategoryReference() != null) {
			this.categoryRefBean = bean.getCategoryReference().asMutable();
		}
		if(bean.getStructureReference() != null) {
			this.structureReference = bean.getStructureReference().asMutable(); 
		}
	}
	
	@Override
	public StructureReferenceBean getCategoryReference() {
		return categoryRefBean;
	}

	@Override
	public StructureReferenceBean getStructureReference() {
		return structureReference;
	}

	@Override
	public void setCategoryReference(StructureReferenceBean categoryRef) {
		this.categoryRefBean = categoryRef;
	}

	@Override
	public void setStructureReference(StructureReferenceBean structureReference) {
		this.structureReference = structureReference;
	}

	@Override
	public CategorisationBean getImmutableInstance() {
		return new CategorisationBeanImpl(this);
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (categoryRefBean != null) {
	    	returnSet.add(categoryRefBean);
	    }
	    if (structureReference != null) {
	    	returnSet.add(structureReference);
	    }
	    return returnSet;
	}
}