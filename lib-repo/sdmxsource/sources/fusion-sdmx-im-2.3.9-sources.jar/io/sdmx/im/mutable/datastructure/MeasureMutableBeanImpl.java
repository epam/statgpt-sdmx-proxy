package io.sdmx.im.mutable.datastructure;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.mutable.base.ComponentMutableBeanImpl;

public class MeasureMutableBeanImpl extends ComponentMutableBeanImpl implements MeasureMutableBean {
	private static final long serialVersionUID = 1L;

	public MeasureMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
	}

	public MeasureMutableBeanImpl(MeasureDimensionBean bean, MutableBean parent) {
		super(bean, parent);
	}

//	@Override
//	public SDMX_STRUCTURE_TYPE getStructureType() {
//		if(PrimaryMeasureBean.FIXED_ID.equals(this.getId())) {
//			return SDMX_STRUCTURE_TYPE.PRIMARY_MEASURE;
//		}
//		return super.getStructureType();
//	}
}
