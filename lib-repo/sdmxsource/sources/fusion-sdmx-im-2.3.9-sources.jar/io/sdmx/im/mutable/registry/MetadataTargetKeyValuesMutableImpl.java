package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.DataSetReferenceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetKeyValuesMutable;

public class MetadataTargetKeyValuesMutableImpl extends KeyValuesMutableImpl implements MetadataTargetKeyValuesMutable {
	private static final long serialVersionUID = -5410698485721209102L;
	private List<StructureReferenceBean> objectReferences = new ArrayList<>();
	private List<DataSetReferenceMutableBean> datasetReferences = new ArrayList<>();
	
	public MetadataTargetKeyValuesMutableImpl() {
		super();
	}

	public MetadataTargetKeyValuesMutableImpl(MetadataTargetKeyValuesBean bean, MutableBean parent) {
		super(bean, parent);
		for(ICrossReferenceBean crossRef : bean.getObjectReferences()) {
			this.objectReferences.add(new StructureReferenceBeanImpl(crossRef.getTargetUrn()));
		}
		for(DataSetReferenceBean dsRef : bean.getDatasetReferences()) {
			this.datasetReferences.add(new DataSetReferenceMutableBeanImpl(dsRef, this));
		}
	}

	@Override
	public List<StructureReferenceBean> getObjectReferences() {
		return objectReferences;
	}

	@Override
	public void setObjectReferences(List<StructureReferenceBean> sRef) {
		this.objectReferences = sRef;
	}

	@Override
	public void addObjectReference(StructureReferenceBean sRef) {
		if(this.objectReferences == null) {
			this.objectReferences = new ArrayList<>();
		}
		this.objectReferences.add(sRef);
	}

	@Override
	public List<DataSetReferenceMutableBean> getDatasetReferences() {
		return datasetReferences;
	}

	@Override
	public void setDatasetReferences(List<DataSetReferenceMutableBean> datasetReference) {
		this.datasetReferences = datasetReference;
	}

	@Override
	public void addDatasetReference(DataSetReferenceMutableBean reference) {
		if(this.datasetReferences == null) {
			this.datasetReferences = new ArrayList<>();
		}
		this.datasetReferences.add(reference);
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if(objectReferences != null) {
	    	returnSet.addAll(objectReferences);
		}
	    return returnSet;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(datasetReferences, composites);
		return composites;
	}
}