package io.sdmx.im.mutable.structure;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class ValidityPeriodItemMutableBean extends ItemMutableBeanImpl implements ValidityPeriodMutableBean {
	private static final long serialVersionUID = 13L;
	private Date startDate;
	private Date endDate;

	public ValidityPeriodItemMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public ValidityPeriodItemMutableBean(ItemBean bean, MutableBean parent, SdmxPeriod validityPeriod) {
		super(bean, parent);
		if(validityPeriod != null){
			if (validityPeriod.getStartPeriod() != null) {
				this.startDate = validityPeriod.getStartPeriod().getDate();
			}
			if (validityPeriod.getEndPeriod() != null) {
				this.endDate = validityPeriod.getEndPeriod().getDate();
			}
		}
	}

	private void processValidityPeriodAnnotations(AnnotationMutableBean bean) {
		if (!(this instanceof ValidityPeriodMutableBean)) {
			return;
		}

		if (this instanceof CodeBean) {
		} else {
			String title = bean.getTitle();
			if (title.indexOf('/') == -1) {
				// Throw error - there MUST be at least one /
				throw new RuntimeException("Validity formatting error, title expects '/' to separate from and to period");
			}
			String[] titleSplit = title.split("/");
			String startDate = titleSplit[0];
			String endDate = (titleSplit.length == 1 ? null: titleSplit[1]);

			if (ObjectUtil.validString(startDate)) {
				this.startDate = DateUtil.formatDate(startDate, true);
			}

			if (ObjectUtil.validString(endDate)) {
				// JIRA: FRCE-61
		        // The following code addresses an odd issue noticed in DateUtil.
		        // If the cellVaLue includes a Time (e.g. 2001-12-31T14:00:00) if startOfPeriod is true the time does not change.
		        // However if startOFPeriod is false then the time is moved to 23:59:59 even though the user specified a time..
		        // We do NOT want to move to the END of the time period if the user has specified a time, only if the user hasn't specified a time.
				// So the workaround is that if the cell contains a Time, pretend that it is the start of period, so that the time does not change.
				boolean isStartOfPeriod = false;
				if (endDate != null && endDate.contains("T") && endDate.charAt(endDate.length()-1) != 'T') {
					isStartOfPeriod = true;
				}
				this.endDate =  DateUtil.formatDate(endDate, isStartOfPeriod);
			}
		}
	}

	@Override
	public ValidityPeriodMutableBean setEndDate(Date endDate) {
		this.endDate = endDate;
		return this;
	}

	@Override
	public ValidityPeriodMutableBean setStartDate(Date startDate) {
		this.startDate = startDate;
		return this;
	}

	@Override
	public Date getEndDate() {
		return endDate;
	}

	@Override
	public Date getStartDate() {
		return startDate;
	}


	@Override
	public Optional<SdmxPeriod> getSdmxPeriod() {
		return DateUtil.parseStartAndEndDateToSdmxPeriod(startDate, endDate);
	}
	
	

	@Override
	public void setAnnotations(List<AnnotationMutableBean> annotations) {
		if(annotations == null) {
			super.setAnnotations(annotations);
		} else {
			for(AnnotationMutableBean annotation : annotations) {
				addAnnotation(annotation);
			}
		}
	}

	@Override
	public AnnotationMutableBean addAnnotation(String title, String type, String url) {
		AnnotationMutableBean addAnnotation = super.addAnnotation(title, type, url);

		if(type.equals(ValidityPeriodBean.VALIDITY_PERIOD)){
			this.processValidityPeriodAnnotations(addAnnotation);
		}
		return addAnnotation;
	}
}
