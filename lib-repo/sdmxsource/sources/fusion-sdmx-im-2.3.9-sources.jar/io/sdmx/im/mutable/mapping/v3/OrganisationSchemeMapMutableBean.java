package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;
import io.sdmx.im.beans.mapping.v3.OrganisationSchemeMapBean;

public class OrganisationSchemeMapMutableBean extends GenericItemSchemeMapMutableBean<IOrganisationMapMutableBean, IOrganisationMapBean> implements IOrganisationSchemeMapMutableBean {
	private static final long serialVersionUID = 1L;

	public OrganisationSchemeMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME_MAP);
	}

	public OrganisationSchemeMapMutableBean(IOrganisationSchemeMapBean bean) {
		super(bean);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		StructureReferenceBean sourceScheme = this.getSourceRef();
		if (sourceScheme != null) {
			SDMX_STRUCTURE_TYPE targetType = null;
			switch(sourceScheme.getMaintainableStructureType()) {
				case AGENCY_SCHEME : return SDMX_STRUCTURE_TYPE.AGENCY;
				case DATA_CONSUMER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_CONSUMER;
				case DATA_PROVIDER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_PROVIDER;
				case ORGANISATION_UNIT_SCHEME : return SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT;
			}
		}
		return null;
	}

	@Override
	public IOrganisationSchemeMapBean getImmutableInstance() {
		return new OrganisationSchemeMapBean(this);
	}

	@Override
	protected IOrganisationMapMutableBean buildItemMap(IOrganisationMapBean mutable) {
		return new OrganisationMapMutableBean(mutable, this);

	}
}