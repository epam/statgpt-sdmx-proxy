package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.im.beans.base.DataProviderSchemeBeanImpl;

public class DataProviderSchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<DataProviderMutableBean> implements DataProviderSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public DataProviderSchemeMutableBeanImpl(DataProviderSchemeBean bean) {
		super(bean);
		for(DataProviderBean dataProviderBean : bean.getItems()) {
			this.addItem(new DataProviderMutableBeanImpl(dataProviderBean, this));
		}
	}
	
	@Override
	public DataProviderMutableBean createItem(String id, String name) {
		DataProviderMutableBean dpBean = new DataProviderMutableBeanImpl();
		dpBean.setId(id);
		dpBean.addName("en", name);
		addItem(dpBean);
		return dpBean;
	}

	public DataProviderSchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME);
	}

	@Override
	public DataProviderSchemeBean getImmutableInstance() {
		return new DataProviderSchemeBeanImpl(this);
	}
}