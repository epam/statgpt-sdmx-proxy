package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class CustomTypeMutableBean extends ItemMutableBeanImpl implements ICustomTypeMutableBean {
	private static final long serialVersionUID = 1L;
	private String dataType;
	private String vtlLiteralFormat;
	private String vtlScalarType;
	private String outputFormat;
	private String nullValue;
	
	public CustomTypeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE);
	}
	
	public CustomTypeMutableBean(ICustomTypeBean bean, MutableBean parent) {
		super(bean, parent);
		this.dataType = bean.getDataType();
		this.vtlLiteralFormat = bean.getVtlLiteralFormat();
		this.vtlScalarType = bean.getVtlScalarType();
		this.outputFormat = bean.getOutputFormat();
		this.nullValue = bean.getNullValue();
	}

	@Override
	public String getVtlScalarType() {
		return vtlScalarType;
	}

	@Override
	public void setVtlScalarType(String vtlScalarType) {
		this.vtlScalarType = vtlScalarType;
	}

	@Override
	public String getDataType() {
		return dataType;
	}

	@Override
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	@Override
	public String getOutputFormat() {
		return outputFormat;
	}

	@Override
	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}

	@Override
	public String getNullValue() {
		return nullValue;
	}

	@Override
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	@Override
	public String getVtlLiteralFormat() {
		return vtlLiteralFormat;
	}

	@Override
	public void setVtlLiteralFormat(String vtlLiteralFormat) {
		this.vtlLiteralFormat = vtlLiteralFormat;
	}
}
