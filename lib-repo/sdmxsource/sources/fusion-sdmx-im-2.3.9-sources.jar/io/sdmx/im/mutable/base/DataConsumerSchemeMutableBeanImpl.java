package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.im.beans.base.DataConsumerSchemeBeanImpl;

public class DataConsumerSchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<DataConsumerMutableBean> implements DataConsumerSchemeMutableBean {

	private static final long serialVersionUID = 1L;
	
	public DataConsumerSchemeMutableBeanImpl(DataConsumerSchemeBean bean) {
		super(bean);
		for(DataConsumerBean dataConsumerBean : bean.getItems()) {
			this.addItem(new DataConsumerMutableBeanImpl(dataConsumerBean, this));
		}
	}

	@Override
	public DataConsumerMutableBean createItem(String id, String name) {
		DataConsumerMutableBean dcBean = new DataConsumerMutableBeanImpl();
		dcBean.setId(id);
		dcBean.addName("en", name);
		addItem(dcBean);
		return dcBean;
	}

	public DataConsumerSchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME);
	}

	@Override
	public DataConsumerSchemeBean getImmutableInstance() {
		return new DataConsumerSchemeBeanImpl(this);
	}
}
