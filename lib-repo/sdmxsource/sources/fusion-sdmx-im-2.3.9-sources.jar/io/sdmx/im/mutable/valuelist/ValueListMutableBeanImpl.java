package io.sdmx.im.mutable.valuelist;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.im.beans.valuelist.ValueListBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class ValueListMutableBeanImpl extends MaintainableMutableBeanImpl implements ValueListMutableBean {
	private static final long serialVersionUID = 1L;
	private List<ValueItemMutableBean> valueItems;
	private boolean partial;
	
	/**
	 * Constructor from immutable instance
	 * @param bean
	 */
	public ValueListMutableBeanImpl(ValueListBean bean) {
		super(bean);
		this.partial = bean.isPartial();
		valueItems = new ArrayList<ValueItemMutableBean>();
		for(ValueItemBean valueItem : bean.getItems()) {
			valueItems.add(new ValueItemMutableBeanImpl(valueItem, this));
		}
	}

	/**
	 * Default constructor
	 */
	public ValueListMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.VALUE_LIST);
	}

	@Override
	public ValueListBean getImmutableInstance() {
		return new ValueListBeanImpl(this);
	}

	@Override
	public boolean isPartial() {
		return this.partial;
	}

	@Override
	public void setPartial(boolean partial) {
		this.partial = partial;
	}

	@Override
	public List<ValueItemMutableBean> getItems() {
		return valueItems;
	}

	@Override
	public void setItems(List<ValueItemMutableBean> items) {
		this.valueItems = items;
	}

	@Override
	public void addItem(ValueItemMutableBean item) {
		if(valueItems == null) {
			valueItems = new ArrayList<>();
		}
		valueItems.add(item);
	}

	@Override
	public void addItemAtPosition(ValueItemMutableBean item, int pos) {
		if(valueItems == null) {
			valueItems = new ArrayList<>();
		}
		if(pos > valueItems.size()) {
			valueItems.add(item);
		}else {
			valueItems.add(pos, item);
		}
	}

}
