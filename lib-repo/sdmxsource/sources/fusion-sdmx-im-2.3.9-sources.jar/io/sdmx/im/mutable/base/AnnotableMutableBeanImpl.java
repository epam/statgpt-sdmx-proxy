package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public abstract class AnnotableMutableBeanImpl extends MutableBeanImpl implements AnnotableMutableBean {
	private static final long serialVersionUID = 1L;
	private List<AnnotationMutableBean> annotations = new ArrayList<>();

	public AnnotableMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public AnnotableMutableBeanImpl(AnnotableBean bean, MutableBean parent) {
		super(bean, parent);
		copyAnnotableProperties(bean);
	}
	
	@Override
	public void copyAnnotableProperties(AnnotableBean bean) {
		if(bean == null) {
			return;
		}
		if(bean.getAnnotations() != null) {
			for(AnnotationBean annotationBean : bean.getAnnotations()) {
				this.addAnnotation(annotationBean);
			}
		}
	}
	
	@Override
    public void addAnnotation(AnnotationBean annotationBean) {
	    this.addAnnotation(new AnnotationMutableBeanImpl(annotationBean, this));
	}
	
	@Override
	public void copyAnnotableProperties(AnnotableMutableBean bean) {
		if(bean == null) {
			return;
		}
		if(bean.getAnnotations() != null) {
			for(AnnotationMutableBean annotationBean : bean.getAnnotations()) {
				this.addAnnotation(new AnnotationMutableBeanImpl(annotationBean));
			}
		}
	}

	@Override
	public void removeAnnotationsByType(String annotationType) {
		if(annotationType == null) {
			return;
		}
		List<AnnotationMutableBean> copy = new ArrayList<>();
		for(AnnotationMutableBean currentAnnotation : annotations) {
			if(!annotationType.equals(currentAnnotation.getType())) {
				copy.add(currentAnnotation);
			}
		}
		annotations = copy;
	}

	@Override
	public void removeAnnotationsByTitle(String annotationTitle) {
		if(annotationTitle == null) {
			return;
		}
		List<AnnotationMutableBean> copy = new ArrayList<>();
		for(AnnotationMutableBean currentAnnotation : annotations) {
			if(!annotationTitle.equals(currentAnnotation.getTitle())) {
				copy.add(currentAnnotation);
			}
		}
		annotations = copy;
	}

	@Override
	public List<AnnotationMutableBean> getAnnotations() {
		return annotations;
	}

	@Override
	public void setAnnotations(List<AnnotationMutableBean> annotations) {
		this.annotations = annotations;
	}

	@Override
	public void addAnnotation(AnnotationMutableBean annotation) {
		if(annotations == null) {
			annotations = new ArrayList<>();
		}
		this.annotations.add(annotation);
	}

	/**
	 * Adds an annotation and returns it
	 * @param title
	 * @param type
	 * @param url
	 * @return
	 */
	@Override
	public AnnotationMutableBean addAnnotation(String title, String type, String url) {
		return addAnnotation(null, title, type, url);
	}

	@Override
	public AnnotationMutableBean addAnnotation(String id, String title, String type, String url) {
		AnnotationMutableBean mutable = new AnnotationMutableBeanImpl();
		mutable.setId(id);
		mutable.setTitle(title);
		mutable.setType(type);
		mutable.setUri(url);
		addAnnotation(mutable);
		return mutable;
	}

	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		addToCompositeSet(annotations, composites);
		return composites;
	}

	@Override
	public Set<AnnotationMutableBean> getAnnotationsByType(String type) {
		Set<AnnotationMutableBean> returnSet = new HashSet<>();
		for(AnnotationMutableBean currentAnnotation : this.annotations) {
			if(currentAnnotation.getType() != null && currentAnnotation.getType().equals(type)) {
				returnSet.add(currentAnnotation);
			}
		}
		return returnSet;
	}

	@Override
	public Set<AnnotationMutableBean> getAnnotationsByTitle(String title) {
		Set<AnnotationMutableBean> returnSet = new HashSet<>();
		for(AnnotationMutableBean currentAnnotation : this.annotations) {
			if(currentAnnotation.getTitle() != null && currentAnnotation.getTitle().equals(title)) {
				returnSet.add(currentAnnotation);
			}
		}
		return returnSet;
	}
}