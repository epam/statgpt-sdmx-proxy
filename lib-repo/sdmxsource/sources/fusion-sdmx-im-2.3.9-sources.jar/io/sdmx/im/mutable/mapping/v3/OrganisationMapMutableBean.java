package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;

public class OrganisationMapMutableBean extends ItemMapMutableBean<IOrganisationMapMutableBean> implements IOrganisationMapMutableBean {

	public OrganisationMapMutableBean() {
		super();
	}

	public OrganisationMapMutableBean(IOrganisationMapBean bean, IOrganisationSchemeMapMutableBean parent) {
		super(bean, parent);
	}

	@Override
	public IOrganisationMapMutableBean getThis() {
		return this;
	}
}
