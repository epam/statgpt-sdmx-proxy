package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.DataAndMetadataSetMutableReference;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ContentConstraintAttachmentMutableBeanImpl extends MutableBeanImpl implements ConstraintAttachmentMutableBean {
	private static final long serialVersionUID = 1L;
	
	private DataAndMetadataSetMutableReference dataOrMetadataSetReference;
	private Set<StructureReferenceBean> structureReference = new HashSet<>();
	private List<DataSourceMutableBean> dataSources = new ArrayList<>();
	
	public ContentConstraintAttachmentMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT_ATTACHMENT);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ContentConstraintAttachmentMutableBeanImpl(ConstraintAttachmentBean bean, MutableBean parent) {
		super(bean, parent);
		if (bean.getDataOrMetadataSetReference() != null)
			this.dataOrMetadataSetReference = bean.getDataOrMetadataSetReference().createMutableInstance();
		if (bean.getStructureReference() != null)
			for(ICrossReferenceBean<?> xsRef : bean.getStructureReference()) {
				this.structureReference.add(xsRef.asMutable());
			}
		if (ObjectUtil.validCollection(bean.getDataSources())) {
			for (DataSourceBean dsbean : bean.getDataSources()) {
				this.dataSources.add(dsbean.createMutableInstance());
			}
		}
	}


	@Override
	public DataAndMetadataSetMutableReference getDataOrMetadataSetReference() {
		return this.dataOrMetadataSetReference;
	}

	@Override
	public void setDataOrMetadataSetReference(DataAndMetadataSetMutableReference ref) {
		this.dataOrMetadataSetReference = ref;
	}

	@Override
	public void addStructureReference(StructureReferenceBean bean) {
		if(structureReference == null) {
			structureReference = new HashSet<>();
		}
		structureReference.add(bean);
	}

	@Override
	public Set<StructureReferenceBean> getStructureReference() {
		return structureReference;
	}

	@Override
	public void setStructureReference(Set<StructureReferenceBean> structureReference) {
		if (structureReference == null) {
			structureReference = new HashSet<>();
		}
		this.structureReference = structureReference;
	}

	@Override
	public List<DataSourceMutableBean> getDataSources() {
		return this.dataSources;
	}

	@Override
	public void setDataSources(List<DataSourceMutableBean> beans) {
		if (beans == null) {
			beans = new ArrayList<>();
		}
		this.dataSources = beans;
	}

	@Override
	public void addDataSources(String url) {
		if(this.dataSources == null) {
			this.dataSources = new ArrayList<>();
		}
		if (url != null) {
			DataSourceMutableBean simpleDs = new DataSourceMutableBeanImpl();
			simpleDs.setDataUrl(url);
			simpleDs.setSimpleDatasource(true);
			this.dataSources.add(simpleDs);
		}
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (structureReference != null) {
	        returnSet.addAll(structureReference);
	    }
	    return returnSet;
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(dataSources, composites);
        return composites;
    }

	@Override
	public void addDataSource(DataSourceMutableBean dsBean) {
		if(this.dataSources == null) {
			this.dataSources = new ArrayList<>();
		}
		this.dataSources.add(dsBean);
	}
}