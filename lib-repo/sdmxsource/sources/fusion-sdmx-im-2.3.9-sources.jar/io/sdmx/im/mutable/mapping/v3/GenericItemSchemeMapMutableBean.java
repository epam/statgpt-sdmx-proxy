package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;

public abstract class GenericItemSchemeMapMutableBean<T extends IItemMapMutableBean, V extends IItemMapBean> extends ItemSchemeMapMutableBean<T> {
	private static final long serialVersionUID = 1L;

	public GenericItemSchemeMapMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public GenericItemSchemeMapMutableBean(IItemSchemeMapBean<V> bean) {
		super(bean);
		if (bean.getItems() != null) {
			for (V item : bean.getItems()) {
				super.addItem(buildItemMap(item));
			}
		}
	}

	protected abstract T buildItemMap(V mutable);
}
