package io.sdmx.im.mutable.mapping;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.CodeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;

public class CodelistMapMutableBeanImpl extends ItemSchemeMapMutableBeanImpl<CodeMapMutableBean> implements CodelistMapMutableBean {
	private static final long serialVersionUID = -5966222908821523257L;

	public CodelistMapMutableBeanImpl () {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST_MAP);
	}

	public CodelistMapMutableBeanImpl (CodelistMapBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getItems() != null) {
			for(CodeMapBean item : bean.getItems()) {
				addItem(new CodeMapMutableBeanImpl(item, this));
			}
		}
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CODE;
	}
	
}