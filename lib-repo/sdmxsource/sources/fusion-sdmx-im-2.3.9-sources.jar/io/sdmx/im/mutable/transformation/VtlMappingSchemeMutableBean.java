package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlCodelistMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlConceptMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlCodelistMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlConceptMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlDataflowMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.im.beans.transformation.VtlMappingSchemeBean;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class VtlMappingSchemeMutableBean extends ItemSchemeMutableBeanImpl<IVtlMappingMutableBean> implements IVtlMappingSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public VtlMappingSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME);
	}

	public VtlMappingSchemeMutableBean(VtlMappingSchemeBean bean) {
		super(bean);
		this.items = new ArrayList<>(bean.getItems().size());
		for(IVtlMappingBean item : bean.getItems()) {
			switch(item.getStructureType()) {
			case VTL_CODELIST_MAPPING :
				this.items.add(new VtlCodelistMappingMutableBean((IVtlCodelistMappingBean)item, this));
				break;
			case VTL_CONCEPT_MAPPING :
				this.items.add(new VtlConceptMappingMutableBean((IVtlConceptMappingBean)item, this));
				break;
			case VTL_DATAFLOW_MAPPING :
				this.items.add(new VtlDataflowMappingMutableBean((IVtlDataflowMappingBean)item, this));
				break;
			}
		}
	}
	
	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean>  returnList = super.getStructureReferencesInternal();
		for(IVtlMappingMutableBean item : this.getItems()) {
			returnList.add(item.getMapped());
		}
		return returnList;
	}
	

	@Override
	public IVtlCodelistMappingMutableBean addCodelistMapping(String id, String alias, IMaintainableRef ref) {
		ensureItemsNotNull();
		IVtlCodelistMappingMutableBean mapping = new VtlCodelistMappingMutableBean();
		mapping.setId(id);
		mapping.setAlias(alias);
		mapping.setMapped(new StructureReferenceBeanImpl(ref, SDMX_STRUCTURE_TYPE.CODE_LIST));
		this.items.add(mapping);
		return mapping;
	}


	@Override
	public IVtlConceptMappingMutableBean addConceptMapping(String id, String alias, IMaintainableRef ref, String conceptId) {
		ensureItemsNotNull();
		IVtlConceptMappingMutableBean mapping = new VtlConceptMappingMutableBean();
		mapping.setId(id);
		mapping.setAlias(alias);
		mapping.setMapped(new StructureReferenceBeanImpl(ref, SDMX_STRUCTURE_TYPE.CONCEPT, conceptId));
		this.items.add(mapping);
		return mapping;
	}

	@Override
	public IVtlDataflowMappingMutableBean addDataflowMapping(String id, String alias, IMaintainableRef ref) {
		ensureItemsNotNull();
		IVtlDataflowMappingMutableBean mapping = new VtlDataflowMappingMutableBean();
		mapping.setId(id);
		mapping.setAlias(alias);
		mapping.setMapped(new StructureReferenceBeanImpl(ref, SDMX_STRUCTURE_TYPE.DATAFLOW));
		this.items.add(mapping);
		return mapping;
	}

	@Override
	public IVtlMappingSchemeBean getImmutableInstance() {
		return new VtlMappingSchemeBean(this);
	}
}
