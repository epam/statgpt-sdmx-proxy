package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class NamePersonalisationMutableBean extends ItemMutableBeanImpl implements INamePersonalisationMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String vtlArtefact;
	private String vtlDefaultName;
	private String personalisedName;
	
	public NamePersonalisationMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION);
	}

	public NamePersonalisationMutableBean(INamePersonalisationBean bean, MutableBean parent) {
		super(bean, parent);
		this.vtlArtefact = bean.getVtlArtefact();
		this.vtlDefaultName = bean.getVtlDefaultName();
		this.personalisedName = bean.getPersonalisedName();
	}

	@Override
	public String getVtlArtefact() {
		return vtlArtefact;
	}

	@Override
	public String getVtlDefaultName() {
		return vtlDefaultName;
	}

	@Override
	public String getPersonalisedName() {
		return personalisedName;
	}

	@Override
	public void setVtlArtefact(String vtlArtefact) {
		this.vtlArtefact = vtlArtefact;
	}

	@Override
	public void setVtlDefaultName(String vtlDefaultName) {
		this.vtlDefaultName = vtlDefaultName;
	}

	@Override
	public void setPersonalisedName(String personalisedName) {
		this.personalisedName = personalisedName;
	}
}
