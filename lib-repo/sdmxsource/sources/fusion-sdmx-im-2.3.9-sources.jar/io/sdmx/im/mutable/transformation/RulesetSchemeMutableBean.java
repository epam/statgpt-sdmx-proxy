package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.im.beans.transformation.RulesetSchemeBean;

public class RulesetSchemeMutableBean extends VtlSchemeMutableBean<IRulesetMutableBean> implements IRulesetSchemeMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean vtlMappingSchemeRef;
	
	public RulesetSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME);
	}

	public RulesetSchemeMutableBean(IRulesetSchemeBean bean) {
		super(bean);
		if(bean.getVtlMappingSchemeRef() != null) {
			this.vtlMappingSchemeRef = new StructureReferenceBeanImpl(bean.getVtlMappingSchemeRef().getTargetUrn());
		}
		this.items = new ArrayList<>(bean.getItems().size());
		for(IRulesetBean item : bean.getItems()) {
			this.items.add(new RulesetMutableBean(item, this));
		}
	}
	
	@Override
	public IRulesetMutableBean addRuleSet(String id, String rulesetDefinition, String rulesetType,String rulesetScope) {
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
		IRulesetMutableBean bean = new RulesetMutableBean();
		bean.setId(id);
		bean.setRulesetDefinition(rulesetDefinition);
		bean.setRulesetType(rulesetType);
		bean.setRulesetScope(rulesetScope);
		
		this.items.add(bean);
		
		return bean;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean>  returnList = super.getStructureReferencesInternal();
		if(vtlMappingSchemeRef != null) {
			returnList.add(vtlMappingSchemeRef);
		}
		return returnList;
	}

	@Override
	public StructureReferenceBean getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public void setVtlMappingSchemeRef(StructureReferenceBean vtlMappingSchemeRef) {
		this.vtlMappingSchemeRef = vtlMappingSchemeRef;
	}

	@Override
	public IRulesetSchemeBean getImmutableInstance() {
		return new RulesetSchemeBean(this);
	}
}
