package io.sdmx.im.mutable.reporting;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionSheetMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionTextMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ReportTemplateInstructionSheetMutableBeanImpl extends MutableBeanImpl implements ReportTemplateInstructionSheetMutableBean {
	private static final long serialVersionUID = 1L;
	private String name;
	private String title;
	private List<ReportTemplateInstructionTextMutableBean> instructions = new ArrayList<>();
	
	public ReportTemplateInstructionSheetMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_INSTRUCTION_SHEET);
	}
	
	public ReportTemplateInstructionSheetMutableBeanImpl(ReportTemplateInstructionSheetBean bean, ReportingTemplateMutableBean parent) {
		super(bean, parent);
		this.name = bean.getName();
		this.title = bean.getTitle();
		for(ReportTemplateInstructionTextBean currentInstruction : bean.getInstructions()) {
			this.instructions.add(new ReportTemplateInstructionTextMutableBeanImpl(currentInstruction, this));
		}
	}


	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public List<ReportTemplateInstructionTextMutableBean> getInstructions() {
		return instructions;
	}

	@Override
	public void addInstruction(ReportTemplateInstructionTextMutableBean instructionSheet) {
		if(this.instructions == null) {
			this.instructions = new ArrayList<>();
		}
		this.instructions.add(instructionSheet);
	}

}
