package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public abstract class VtlMappingMutableBean extends ItemMutableBeanImpl implements IVtlMappingMutableBean {
	private static final long serialVersionUID = 1L;

	private String alias;
	private StructureReferenceBean mapped;
	
	public VtlMappingMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public VtlMappingMutableBean(IVtlMappingBean bean, MutableBean parent) {
		super(bean, parent);
		this.alias = bean.getAlias();
		this.mapped = super.getStructureReference(bean.getMapped());
	}

	@Override
	public String getAlias() {
		return alias;
	}

	@Override
	public void setAlias(String alias) {
		this.alias = alias;
	}

	@Override
	public StructureReferenceBean getMapped() {
		return mapped;
	}

	@Override
	public void setMapped(StructureReferenceBean mapped) {
		this.mapped = mapped;
	}
}
