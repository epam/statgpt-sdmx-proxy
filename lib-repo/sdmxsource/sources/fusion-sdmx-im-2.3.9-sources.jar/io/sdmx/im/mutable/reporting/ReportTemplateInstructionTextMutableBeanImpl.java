package io.sdmx.im.mutable.reporting;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionSheetMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionTextMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ReportTemplateInstructionTextMutableBeanImpl extends MutableBeanImpl implements ReportTemplateInstructionTextMutableBean {
	private static final long serialVersionUID = 1L;
	private String content;
	private int colWidth;
	private int colHeight;

	public ReportTemplateInstructionTextMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_INSTRUCTION_TEXT);
	}
	
	public ReportTemplateInstructionTextMutableBeanImpl(ReportTemplateInstructionTextBean createdFrom, ReportTemplateInstructionSheetMutableBean parent) {
		super(createdFrom, parent);
		this.content = createdFrom.getContent();
		this.colHeight = createdFrom.getColHeight();
		this.colWidth = createdFrom.getColWidth();
	}

	@Override
	public String getContent() {
		return content;
	}

	@Override
	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public int getColWidth() {
		return colWidth;
	}

	@Override
	public void setColWidth(int width) {
		this.colWidth = width;
	}

	@Override
	public int getColHeight() {
		return colHeight;
	}

	@Override
	public void setColHeight(int width) {
		this.colHeight = width;
	}

}
