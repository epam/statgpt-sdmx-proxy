package io.sdmx.im.mutable.pdq;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryComponentFilterMutableBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;
import io.sdmx.im.beans.pdq.PreDefinedQueryBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class PreDefinedQueryMutableBean extends MaintainableMutableBeanImpl implements IPreDefinedQueryMutableBean {
	private static final long serialVersionUID = 1L;
	private Set<StructureReferenceBean> dataflow = new HashSet<>();
	private List<IPreDefinedQueryComponentFilterMutableBean> selections = new ArrayList<>();
	private Set<String> series = new HashSet<>();
	private Map<String, String> parameters = new HashMap<>();
	private boolean isVirtualFlow;

	public PreDefinedQueryMutableBean(IPreDefinedQueryBean bean) {
		super(bean);
		this.isVirtualFlow = bean.isVirtualFlow();
		for(ICrossReferenceBean xsRef : bean.getDataflow()) {
			this.dataflow.add(new StructureReferenceBeanImpl(xsRef.getTargetUrn()));
		}
		for(IPreDefinedQueryComponentFilterBean filter : bean.getSelections()) {
			this.selections.add(new PreDefinedQueryComponentFilterMutableBean(filter, this));
		}
		this.series = new HashSet<>(bean.getSeries());
		this.parameters = new HashMap<>(bean.getParameters());
	}

	public PreDefinedQueryMutableBean() {
		super(SDMX_STRUCTURE_TYPE.PREDEFINED_QUERY);
	}

	@Override
	public IPreDefinedQueryBean getImmutableInstance() {
		return new PreDefinedQueryBean(this);
	}
	
	@Override
	public boolean isVirtualFlow() {
		return isVirtualFlow;
	}

	@Override
	public void setVirtualFlow(boolean bool) {
		this.isVirtualFlow = bool;
	}

	@Override
	public Set<StructureReferenceBean> getDataflow() {
		return this.dataflow;
	}

	@Override
	public void setDataflow(Set<StructureReferenceBean> dataflows) {
		this.dataflow = dataflows;
	}

	@Override
	public void addDataflow(StructureReferenceBean dataflow) {
		if(this.dataflow == null) {
			this.dataflow = new HashSet<>();
		}
		this.dataflow.add(dataflow);
	}

	@Override
	public List<IPreDefinedQueryComponentFilterMutableBean> getSelections() {
		return selections;
	}

	@Override
	public void setSelections(List<IPreDefinedQueryComponentFilterMutableBean> selections) {
		this.selections = selections;
	}

	@Override
	public void addSelection(IPreDefinedQueryComponentFilterMutableBean selection) {
		if(this.selections == null) {
			this.selections = new ArrayList<>();
		}
		selections.add(selection);
	}

	@Override
	public Set<String> getSeries() {
		return this.series;
	}

	@Override
	public void setSeries(Set<String> series) {
		this.series = series;
	}

	@Override
	public void addSeries(String series) {
		if(this.series == null) {
			this.series = new HashSet<>();
		}
		this.series.add(series);
	}

	@Override
	public Map<String, String> getParameters() {
		return this.parameters;
	}

	@Override
	public void setParameters(Map<String, String> map) {
		this.parameters = map;
	}

	@Override
	public void addParameter(String key, String value) {
		if(this.parameters == null) {
			this.parameters = new HashMap<>();
		}
		this.parameters.put(key, value);
	}
}
