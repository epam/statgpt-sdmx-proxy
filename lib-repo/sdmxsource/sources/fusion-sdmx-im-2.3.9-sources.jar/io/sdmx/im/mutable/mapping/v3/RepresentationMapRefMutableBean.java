package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapRefMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class RepresentationMapRefMutableBean extends MutableBeanImpl implements IRepresentationMapRefMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean enumerationRef;
	private TEXT_TYPE textType;

	public RepresentationMapRefMutableBean() {
		super(SDMX_STRUCTURE_TYPE.ANY);
	}

	public RepresentationMapRefMutableBean(IRepresentationMapRefBean createdFrom, IRepresentationMapMutableBean parent) {
		super(createdFrom, parent);
		if(createdFrom.getEnumerationRef() != null) {
			this.enumerationRef = new StructureReferenceBeanImpl(createdFrom.getEnumerationRef().getTargetUrn());
		}
		this.textType = createdFrom.getTextType();
	}

	@Override
	public StructureReferenceBean getEnumerationRef() {
		return enumerationRef;
	}

	@Override
	public void setEnumerationRef(StructureReferenceBean ref) {
		this.enumerationRef = ref;
	}

	@Override
	public TEXT_TYPE getTextType() {
		return textType;
	}

	@Override
	public void setTextType(TEXT_TYPE tt) {
		this.textType = tt;
	}
}
