package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;
import io.sdmx.im.beans.mapping.v3.CategorySchemeMapBean;

public class CategorySchemeMapMutableBean extends GenericItemSchemeMapMutableBean<ICategoryMapMutableBean, ICategoryMapBean> implements ICategorySchemeMapMutableBean {
	private static final long serialVersionUID = 8829767446075036603L;

	public CategorySchemeMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME_MAP);
	}

	public CategorySchemeMapMutableBean(ICategorySchemeMapBean bean) {
		super(bean);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CATEGORY;
	}

	@Override
	public ICategorySchemeMapBean getImmutableInstance() {
		return new CategorySchemeMapBean(this);
	}

	@Override
	protected ICategoryMapMutableBean buildItemMap(ICategoryMapBean mutable) {
		return new CategoryMapMutableBean(mutable, this);
	}
}