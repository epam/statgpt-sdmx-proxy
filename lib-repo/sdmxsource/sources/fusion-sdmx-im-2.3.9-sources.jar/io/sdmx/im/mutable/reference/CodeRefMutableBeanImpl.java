package io.sdmx.im.mutable.reference;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;

public class CodeRefMutableBeanImpl extends IdentifiableMutableBeanImpl implements CodeRefMutableBean {
	private static final long serialVersionUID = 1L;

	private List<CodeRefMutableBean> codeRefs = new ArrayList<>();
	private StructureReferenceBean codeReference;
	private Date validFrom;
	private Date validTo;
	private String levelReference;

	private String version;


	public CodeRefMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHICAL_CODE);
	}

	public CodeRefMutableBeanImpl(HierarchicalCodeBean bean, MutableBean parent) {
		super(bean, parent);
		this.codeReference = bean.getCodeReference().asMutable();

		// change list to Mutable CodeRefBeans
		if(bean.getCodeRefs() != null) {
			for(HierarchicalCodeBean currentCodeRef : bean.getCodeRefs()) {
				this.codeRefs.add(new CodeRefMutableBeanImpl(currentCodeRef, this));
			}
		}
		if(bean.getLevel(false) != null) {
			levelReference = bean.getLevel(false).getFullIdPath(false);
		}
		if (bean.getValidFrom() != null) {
			this.setValidFrom(bean.getValidFrom().getDate());
		}
		if (bean.getValidTo() != null) {
			this.setValidTo(bean.getValidTo().getDate());
		}
	}

	@Override
	public String getLevelReference() {
		return levelReference;
	}

	@Override
	public void setLevelReference(String levelReference) {
		this.levelReference = levelReference;
	}

	@Override
	public Date getValidFrom() {
		return validFrom;
	}

	@Override
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	@Override
	public Date getValidTo() {
		return validTo;
	}

	@Override
	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}

	@Override
	public void setCodeRefs(List<CodeRefMutableBean> codeRefs) {
		this.codeRefs = codeRefs;
	}

	@Override
	public void addCodeRef(CodeRefMutableBean codeRef) {
		this.codeRefs.add(codeRef);
	}

	@Override
	public List<CodeRefMutableBean> getCodeRefs() {
		return codeRefs;
	}

	@Override
	public StructureReferenceBean getCodeReference() {
		return codeReference;
	}

	@Override
	public void setCodeReference(StructureReferenceBean codeReference) {
		this.codeReference = codeReference;
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> references = super.getStructureReferencesInternal();
		if(codeReference != null) {
			references.add(codeReference);
		}
		return references;
	}

    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(codeRefs, composites);
        return composites;
    }

	@Override
	public Optional<SdmxPeriod> getSdmxPeriod() {
		return DateUtil.parseStartAndEndDateToSdmxPeriod(getValidFrom(), getValidTo());
	}

	@Override
	public CodeRefMutableBean setVersion(String version) {
		this.version = version;
		return this;
	}

	@Override
	public String getVersion() {
		return this.version;
	}
}
