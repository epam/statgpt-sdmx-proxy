package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;

public class CategoryMapMutableBean extends ItemMapMutableBean<ICategoryMapMutableBean> implements ICategoryMapMutableBean {

	public CategoryMapMutableBean() {
		super();
	}

	public CategoryMapMutableBean(ICategoryMapBean bean, ICategorySchemeMapMutableBean parent) {
		super(bean, parent);
	}

	@Override
	public ICategoryMapMutableBean getThis() {
		return this;
	}
}
