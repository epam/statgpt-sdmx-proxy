package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class UserDefinedOperatorMutableBean extends ItemMutableBeanImpl implements IUserDefinedOperatorMutableBean {
	private static final long serialVersionUID = 1L;

	private String operatorDefinition;
	
	public UserDefinedOperatorMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR);
	}
	
	public UserDefinedOperatorMutableBean(IUserDefinedOperatorBean bean, IUserDefinedOperatorSchemeMutableBean parent) {
		super(bean, parent);
		this.operatorDefinition = bean.getOperatorDefinition();
	}

	@Override
	public String getOperatorDefinition() {
		return operatorDefinition;
	}

	@Override
	public void setOperatorDefinition(String operatorDefinition) {
		this.operatorDefinition = operatorDefinition;
	}
}
