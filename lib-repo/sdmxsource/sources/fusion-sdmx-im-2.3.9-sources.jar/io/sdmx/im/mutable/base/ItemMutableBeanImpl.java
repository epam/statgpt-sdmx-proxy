package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public abstract class ItemMutableBeanImpl extends NameableMutableBeanImpl		 {
	private static final long serialVersionUID = 1L;

	public ItemMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public ItemMutableBeanImpl(ItemBean bean, MutableBean parent) {
		super(bean, parent);
	}
}
