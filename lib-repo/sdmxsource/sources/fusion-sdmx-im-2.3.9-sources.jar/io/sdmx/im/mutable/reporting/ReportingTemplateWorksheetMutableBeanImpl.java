package io.sdmx.im.mutable.reporting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateColourMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateConditionalAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;

public class ReportingTemplateWorksheetMutableBeanImpl extends IdentifiableMutableBeanImpl implements ReportingTemplateWorksheetMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean dataflow;
	private String sliceBy;
	private List<String> tableCols;
	private List<String> tableRows;
	private Map<String, String> fixedAttributeValues;
	private Set<String> variableAttributes;
	private Set<String> variableDimensions;
	private Set<String> worksheetAttributes;
	private Set<String> separateAttributes;
	private Set<String> excludeDimensions;
	private ReportingTemplateColourMutableBean colourAttribute;
	private Map<String, TEXT_DISPLAY> textDisplay;
	private Map<String, StructureReferenceBean> hierarhcyReferences;
	private Set<String> implicitHierarchices;
	private Set<ReportingTemplateConditionalAttributeMutableBean> conditionalAttributes;
	private Integer roundDecimals;
	private Integer maxWidth;

	public ReportingTemplateWorksheetMutableBeanImpl(ReportingTemplateWorksheetBean bean, ReportingTemplateMutableBean parent) {
		super(bean, parent);
		this.dataflow = new StructureReferenceBeanImpl(bean.getDataflow().getTargetUrn());
		this.tableCols = new ArrayList<>(bean.getTableCols());
		this.tableRows = new ArrayList<>(bean.getTableRows());
		this.fixedAttributeValues = new HashMap<>();
		this.maxWidth = bean.getColMaxWidth();
		this.sliceBy = bean.getSliceBy();
		for(String fixedDim : bean.getFixedAttributes()) {
			fixedAttributeValues.put(fixedDim, bean.getFixedAttributeValue(fixedDim));
		}
		this.variableAttributes = new HashSet<>(bean.getVariableAttributes());
		this.worksheetAttributes = new HashSet<>(bean.getWorksheetAttributes());
		this.separateAttributes = new HashSet<>(bean.getSeparateAttributes());
		if(bean.getColourAttribute() != null) {
			this.colourAttribute = new ReportingTemplateColourMutableBeanImpl(bean.getColourAttribute(), this);
		}
		this.textDisplay = new HashMap<>(bean.getTextDisplay());

		hierarhcyReferences = new HashMap<>();
		for(String hId : bean.getHierarhcyReferences().keySet()) {
			hierarhcyReferences.put(hId, new StructureReferenceBeanImpl(bean.getHierarhcyReferences().get(hId).getTargetUrn()));
		}
		this.implicitHierarchices = new HashSet<>(bean.getImplicitHierarchices());
		this.excludeDimensions = new HashSet<>(bean.getExcludeDimensions());
		this.conditionalAttributes = new HashSet<>();
		for(ReportingTemplateConditionalAttributeBean attr : bean.getConditionalAttributes()) {
			this.conditionalAttributes.add(new ReportingTemplateConditionalAttributeMutableBeanImpl(attr, this));
		}
		this.roundDecimals = bean.getRoundDecimals();
		this.variableDimensions = new HashSet<>(bean.getVariableDimensions());
	}

	public ReportingTemplateWorksheetMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_WS);
	}


	@Override
	public StructureReferenceBean getDataflow() {
		return dataflow;
	}

	@Override
	public void setDataflow(StructureReferenceBean sRef) {
		this.dataflow = sRef;
	}

	@Override
	public String getSliceBy() {
		return sliceBy;
	}

	@Override
	public void setSliceBy(String sliceBy) {
		this.sliceBy = sliceBy;
	}

	@Override
	public Integer getColMaxWidth() {
		return maxWidth;
	}

	@Override
	public void setColMaxWidth(Integer width) {
		this.maxWidth = width;
	}

	@Override
	public List<String> getTableCols() {
		return tableCols;
	}

	@Override
	public void setTableCols(List<String> cols) {
		this.tableCols = cols;
	}

	@Override
	public List<String> getTableRows() {
		return tableRows;
	}

	@Override
	public void setTableRows(List<String> cols) {
		this.tableRows = cols;
	}

	@Override
	public Map<String, String> getFixedAttributeValues() {
		return fixedAttributeValues;
	}

	@Override
	public void setFixedAttributeValues(Map<String, String> map) {
		this.fixedAttributeValues = map;
	}

	@Override
	public Set<String> getVariableAttributes() {
		return variableAttributes;
	}

	@Override
	public void setVariableAttributes(Set<String> attributes) {
		this.variableAttributes = attributes;
	}

	@Override
	public Set<String> getVariableDimensions() {
		return this.variableDimensions;
	}

	@Override
	public void setVariableDimensions(Set<String> dimensions) {
		this.variableDimensions = dimensions;
	}

	@Override
	public Set<String> getExcludeDimensions() {
		return excludeDimensions;
	}

	@Override
	public void setExcludeDimensions(Set<String> dimensions) {
		this.excludeDimensions = dimensions;
	}

	@Override
	public Set<String> getWorksheetAttributes() {
		return worksheetAttributes;
	}

	@Override
	public void setWorksheetAttributes(Set<String> attributes) {
		this.worksheetAttributes = attributes;
	}

	@Override
	public Set<String> getSeparateAttributes() {
		return separateAttributes;
	}

	@Override
	public void setSeparateAttributes(Set<String> attributes) {
		this.separateAttributes = attributes;
	}

	@Override
	public ReportingTemplateColourMutableBean getColourAttribute() {
		return colourAttribute;
	}

	@Override
	public void setColourAttribute(ReportingTemplateColourMutableBean attribute) {
		this.colourAttribute = attribute;
	}


	@Override
	public Set<ReportingTemplateConditionalAttributeMutableBean> getConditionalAttributes() {
		return conditionalAttributes;
	}

	@Override
	public void setConditionalAttributes(Set<ReportingTemplateConditionalAttributeMutableBean> attrs) {
		this.conditionalAttributes = attrs;
	}
	
	@Override
	public Map<String, TEXT_DISPLAY> getTextDisplay() {
		return textDisplay;
	}

	@Override
	public void setTextDisplay(Map<String, TEXT_DISPLAY> display) {
		this.textDisplay = display;
	}

	@Override
	public void addTextDisplay(String componentId, TEXT_DISPLAY display) {
		if(this.textDisplay == null) {
			this.textDisplay = new HashMap<>();
		}
		this.textDisplay.put(componentId, display);
	}

	@Override
	public Map<String, StructureReferenceBean> getHierarhcyReferences() {
		return hierarhcyReferences;
	}

	@Override
	public void setHierarhcyReferences(Map<String, StructureReferenceBean> hRefs) {
		this.hierarhcyReferences = hRefs;
	}

	@Override
	public Set<String> getImplicitHierarchices() {
		return implicitHierarchices;
	}

	@Override
	public void setImplicitHierarchices(Set<String> hierarchies) {
		this.implicitHierarchices = hierarchies;
	}

	@Override
	public Integer getRoundDecimals() {
		return roundDecimals;
	}

	@Override
	public void setRoundDecimals(Integer decimals) {
		this.roundDecimals = decimals;
	}

	@Override
    public List<StructureReferenceBean> getStructureReferencesInternal() {
        List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
        returnSet.add(getDataflow());
        return returnSet;
    }
}
