package io.sdmx.im.mutable.mapping.v3;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ISchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ISchemeMapMutableBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public abstract class SchemeMapMutableBean extends MaintainableMutableBeanImpl implements ISchemeMapMutableBean {

	private static final long serialVersionUID = 1L;

	private StructureReferenceBean sourceRef;
	private StructureReferenceBean targetRef;

	public SchemeMapMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public SchemeMapMutableBean(ISchemeMapBean bean) {
		super(bean);
		if(bean.getSourceRef() != null) {
			this.sourceRef = bean.getSourceRef().asMutable();
		}
		if(bean.getTargetRef() != null) {
			this.targetRef =  bean.getTargetRef().asMutable();
		}
	}

	@Override
	public void setSourceRef(StructureReferenceBean sourceRef) {
		this.sourceRef = sourceRef;
	}

	@Override
	public void setTargetRef(StructureReferenceBean targetRef) {
		this.targetRef = targetRef;
	}

	@Override
	public StructureReferenceBean getSourceRef() {
		return sourceRef;
	}

	@Override
	public StructureReferenceBean getTargetRef() {
		return targetRef;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (sourceRef != null) {
	        returnSet.add(sourceRef);
	    }
	    if (targetRef != null) {
	        returnSet.add(targetRef);
	    }
	    return returnSet;
	}
}