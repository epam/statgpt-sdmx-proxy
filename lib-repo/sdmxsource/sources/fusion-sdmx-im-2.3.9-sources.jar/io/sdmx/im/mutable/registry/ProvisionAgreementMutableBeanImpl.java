
package io.sdmx.im.mutable.registry;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.im.beans.registry.ProvisionAgreementBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class ProvisionAgreementMutableBeanImpl extends MaintainableMutableBeanImpl implements ProvisionAgreementMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean structureUseage;
	private StructureReferenceBean dataproviderRef;
	
	public ProvisionAgreementMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
	}

	public ProvisionAgreementMutableBeanImpl(DataflowBean dataflowBean, DataProviderBean dataProviderBean) {
		super(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
		this.structureUseage = dataflowBean.asReference();
		this.dataproviderRef = dataProviderBean.asReference();
		this.setAgencyId(dataflowBean.getAgencyId());
		this.setId(dataflowBean.getId() + "_" + dataProviderBean.getId());
		this.setVersion("1.0");
		this.addName("en", dataProviderBean.getName() + " for "+ dataflowBean.getName());
	}
	
	public ProvisionAgreementMutableBeanImpl(ProvisionAgreementBean bean) {
		super(bean);
		if(bean.getStructureUseage() != null) {
			this.structureUseage = bean.getStructureUseage().asMutable();
		}
		
		if(bean.getDataproviderRef() != null) {
			this.dataproviderRef = bean.getDataproviderRef().asMutable();
		}
	}
                                  
	@Override
	public StructureReferenceBean getStructureUsage() {
		return structureUseage;
	}

	@Override
	public void setStructureUsage(StructureReferenceBean structureUseage) {
		this.structureUseage = structureUseage;
	}

	@Override
	public void setDataproviderRef(StructureReferenceBean dataproviderRef) {
		this.dataproviderRef = dataproviderRef;
	}

	@Override
	public StructureReferenceBean getDataproviderRef() {
		return dataproviderRef;
	}

	@Override
	public ProvisionAgreementBean getImmutableInstance() {
		return new ProvisionAgreementBeanImpl(this);
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (structureUseage != null) {
	        returnSet.add(structureUseage);
	    }
	    if (dataproviderRef != null) {
	        returnSet.add(dataproviderRef);
	    }
	    return returnSet;
	}
}