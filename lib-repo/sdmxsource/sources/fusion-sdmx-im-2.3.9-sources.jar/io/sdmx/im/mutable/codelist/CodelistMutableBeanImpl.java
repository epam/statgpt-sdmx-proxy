package io.sdmx.im.mutable.codelist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.im.beans.codelist.CodelistBeanImpl;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;

public class CodelistMutableBeanImpl extends ItemSchemeMutableBeanImpl<CodeMutableBean> implements CodelistMutableBean {

	private static final long serialVersionUID = 19743748L;

	private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;
	
	private List<ICodelistInheritanceRuleMutableBean> inheritenceRules = new ArrayList<>();
	
	private boolean isInherited;
	
	public CodelistMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST);
	}
	
	public CodelistMutableBeanImpl(CodelistBean bean) {
		super(bean);
		this.isInherited = bean.isInherited();
		// change Codelist beans in Mutable Codelist beans
		// MutableBean must have a copy of allItems since it may be for a particular date
		List<CodeBean> allItems = bean.getItems();
		this.validityType = bean.getValidityType();
		for(CodeBean currentBean : allItems) {
			this.addItem(buildMutableCode(currentBean));
		}
		for(ICodelistInheritanceRuleBean iRule : bean.getInheritedCodelists()) {
			inheritenceRules.add(new CodelistInheritanceRuleMutableBean(iRule, null));
		}
	}
	
	protected CodeMutableBean buildMutableCode(CodeBean code) {
		return new CodeMutableBeanImpl(code, this);
	}
	

	@Override
	public CodeMutableBean createItem(String id, String name) {
		CodeMutableBean code = new CodeMutableBeanImpl();
		code.setId(id);
		code.addName("en", name);
		addItem(code);
		return code;
	}

	public CodelistMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	@Override
	public CodeMutableBean getCodeById(String id) {
		for(CodeMutableBean currentCode : getItems()) {
			if(currentCode.getId().equals(id)) {
				return currentCode;
			}
		}
		return null;
	}

	@Override
	public CodelistBean getImmutableInstance() {
		return new CodelistBeanImpl(this);
	}

	@Override
	protected MaintainableMutableBean createPartial(Set<String> itemSet, boolean keep, boolean isUrn, ITEM_FILTER_ACTION filterAction) {
		Map<String, Set<CodeMutableBean>> itemMap = new HashMap<>();
		for(CodeMutableBean code : super.getItems()) {
			Set<CodeMutableBean> codes = itemMap.get(code.getId());
			if(codes == null) {
				codes = new HashSet<>();
				itemMap.put(code.getId(), codes);
			}
			codes.add(code);
		}
		super.createPartial(itemSet, keep, isUrn, filterAction);
		if(filterAction != ITEM_FILTER_ACTION.NO_ACTION) {
			List<CodeMutableBean> toCheck = items;
			Set<String> allCodeIds = items.stream().map(CodeMutableBean::getId).collect(Collectors.toSet());
			while(toCheck.size() > 0) {
				List<CodeMutableBean> toAdd = new ArrayList<CodeMutableBean>();
				for(CodeMutableBean currentItem : toCheck) {
					String parentCode = currentItem.getParentCode();
					if (parentCode != null && !allCodeIds.contains(parentCode)) {
						if(filterAction == ITEM_FILTER_ACTION.KEEP_PARENT) {
							toAdd.addAll(itemMap.get(parentCode));
							allCodeIds.add(parentCode);
						} else {
							currentItem.setParentCode(null);
						}
					}
				}
				items.addAll(toAdd);
				toCheck = toAdd;
			}
		}
		return this;
	}

	@Override
	public CodelistMutableBean setInherited(boolean isInherited) {
		this.isInherited = isInherited;
		return this;
	}

	@Override
	public boolean isInherited() {
		return this.isInherited;
	}

	@Override
	public void setIsPartial(boolean isPartial) {
		super.setPartial(isPartial);
	}

	@Override
	public MAINT_VALIDITY_TYPE getValidityType() {
		return this.validityType;
	}

	@Override
	public void setValidityType(MAINT_VALIDITY_TYPE validityType) {
		this.validityType = validityType;
	}

	@Override
	public List<ICodelistInheritanceRuleMutableBean> getInheritenceRules() {
		return inheritenceRules;
	}

	@Override
	public CodelistMutableBean setInheritenceRules(List<ICodelistInheritanceRuleMutableBean> rules) {
		this.inheritenceRules = rules;
		return this;
	}

	@Override
	public CodelistMutableBean addInheritenceRules(ICodelistInheritanceRuleMutableBean rule) {
		if(this.inheritenceRules == null) {
			this.inheritenceRules = new ArrayList<>();
		}
		this.inheritenceRules.add(rule);
		return this;
	}
}