
package io.sdmx.im.mutable.registry;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.im.beans.registry.ContentConstraintBeanImpl;


public class ContentConstraintMutableBeanImpl extends ConstraintMutableBeanImpl implements ContentConstraintMutableBean {
	private static final long serialVersionUID = 1L;
	
	private MetadataTargetRegionMutableBean metadataTargetRegionBean;
	
	private CubeRegionMutableBean includedCubeRegion;
	private CubeRegionMutableBean excludedCubeRegion;
	
	private ReferencePeriodMutableBean referencePeriodBean = null;
	private ReleaseCalendarMutableBean releaseCalendarBean = null;
	private boolean isDefiningActualDataPresent = true;  //Default Value

	public ContentConstraintMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ContentConstraintMutableBeanImpl(ContentConstraintBean bean) {
		super(bean);
		if(bean.getIncludedCubeRegion() != null) {
			includedCubeRegion = new CubeRegionMutableBeanImpl(bean.getIncludedCubeRegion(), this);
		}
		if(bean.getExcludedCubeRegion() != null) {
			excludedCubeRegion = new CubeRegionMutableBeanImpl(bean.getExcludedCubeRegion(), this);
		}			
		if (bean.getReferencePeriod() != null) {
			this.referencePeriodBean = bean.getReferencePeriod().createMutableBean();
		}
		if (bean.getReleaseCalendar() != null) {
			this.releaseCalendarBean = bean.getReleaseCalendar().createMutableBean();
		}
		if(bean.getMetadataTargetRegion() != null) {
			this.metadataTargetRegionBean = new MetadataTargetRegionMutableBeanImpl(bean.getMetadataTargetRegion(), this);
		}
		this.isDefiningActualDataPresent = bean.isDefiningActualDataPresent();
	}

	
	@Override
	public MetadataTargetRegionMutableBean getMetadataTargetRegion() {
		return metadataTargetRegionBean;
	}

	@Override
	public void setMetadataTargetRegion(MetadataTargetRegionMutableBean mtr) {
		this.metadataTargetRegionBean = mtr;
	}

	@Override
	public boolean getIsDefiningActualDataPresent() {
		return this.isDefiningActualDataPresent;
	}

	@Override
	public void setIsDefiningActualDataPresent(boolean present) {
		this.isDefiningActualDataPresent = present;
	}

	@Override
	public CubeRegionMutableBean getIncludedCubeRegion() {
		return includedCubeRegion;
	}

	@Override
	public void setIncludedCubeRegion(CubeRegionMutableBean includedCubeRegion) {
		this.includedCubeRegion = includedCubeRegion;
	}

	@Override
	public CubeRegionMutableBean getExcludedCubeRegion() {
		return excludedCubeRegion;
	}

	@Override
	public void setExcludedCubeRegion(CubeRegionMutableBean excludedCubeRegion) {
		this.excludedCubeRegion = excludedCubeRegion;
	}

	@Override
	public ReferencePeriodMutableBean getReferencePeriod() {
		return this.referencePeriodBean;
	}

	@Override
	public void setReferencePeriod(ReferencePeriodMutableBean bean) {
		this.referencePeriodBean = bean;
	}

	@Override
	public ReleaseCalendarMutableBean getReleaseCalendar() {
		return this.releaseCalendarBean;
	}

	@Override
	public void setReleaseCalendar(ReleaseCalendarMutableBean bean) {
		this.releaseCalendarBean = bean;
	}

	@Override
	public ContentConstraintBean getImmutableInstance() {
		return ContentConstraintBeanImpl.getInstance(this);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(includedCubeRegion, composites);
        super.addToCompositeSet(excludedCubeRegion, composites);
        super.addToCompositeSet(referencePeriodBean, composites);
        super.addToCompositeSet(releaseCalendarBean, composites);
        super.addToCompositeSet(metadataTargetRegionBean, composites);
        return composites;
    }
}
