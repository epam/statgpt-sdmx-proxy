package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RelatedStructuresMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.im.beans.mapping.StructureSetBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class StructureSetMutableBeanImpl extends MaintainableMutableBeanImpl implements StructureSetMutableBean {

	private static final long serialVersionUID = 1L;

	private RelatedStructuresMutableBean relatedStructures;
	private List<StructureMapMutableBean> structureMapList;
	private List<CodelistMapMutableBean> codelistMapList;
	private List<CategorySchemeMapMutableBean> categorySchemeMapList;
	private List<ConceptSchemeMapMutableBean> conceptSchemeMapList;
	private List<OrganisationSchemeMapMutableBean> organisationSchemeMapList;

	/**
	 * Constructor.
	 */
	public StructureSetMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_SET);
	}

	/**
	 * Copy constructor
	 * @param bean immutable variant to copy from
	 */
	public StructureSetMutableBeanImpl(StructureSetBean bean) {
		super(bean);
		if(bean.getRelatedStructures() != null) {
			setRelatedStructures(new RelatedStructuresMutableBeanImpl(bean.getRelatedStructures(), this));
		}
		for (StructureMapBean each : bean.getStructureMapList()) {
			addStructureMap(new StructureMapMutableBeanImpl(each, this));
		}
		for (CodelistMapBean each : bean.getCodelistMapList()) {
			addCodelistMap(new CodelistMapMutableBeanImpl(each, this));
		}
		for (CategorySchemeMapBean each : bean.getCategorySchemeMapList()) {
			addCategorySchemeMap(new CategorySchemeMapMutableBeanImpl(each, this));
		}
		for (ConceptSchemeMapBean each : bean.getConceptSchemeMapList()) {
			addConceptSchemeMap(new ConceptSchemeMapMutableBeanImpl(each, this));
		}
		for (OrganisationSchemeMapBean each : bean.getOrganisationSchemeMapList()) {
			addOrganisationSchemeMap(new OrganisationSchemeMapMutableBeanImpl(each, this));
		}
	}

	/**
	 * Create immutable variant
	 */
	@Override
	public StructureSetBean getImmutableInstance() {
		return new StructureSetBeanImpl(this);
	}


	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public RelatedStructuresMutableBean getRelatedStructures() {
		return relatedStructures;
	}
	@Override
	public List<StructureMapMutableBean> getStructureMapList() {
		if (structureMapList == null) structureMapList = new ArrayList<>();
		return structureMapList;
	}

	@Override
	public List<CodelistMapMutableBean> getCodelistMapList() {
		if (codelistMapList == null) codelistMapList = new ArrayList<>();
		return codelistMapList;
	}

	@Override
	public List<CategorySchemeMapMutableBean> getCategorySchemeMapList() {
		if (categorySchemeMapList == null) categorySchemeMapList = new ArrayList<>();
		return categorySchemeMapList;
	}

	@Override
	public List<ConceptSchemeMapMutableBean> getConceptSchemeMapList() {
		if (conceptSchemeMapList == null) conceptSchemeMapList = new ArrayList<>();
		return conceptSchemeMapList;
	}

	@Override
	public List<OrganisationSchemeMapMutableBean> getOrganisationSchemeMapList() {
		if (organisationSchemeMapList == null) organisationSchemeMapList = new ArrayList<>();
		return organisationSchemeMapList;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////SETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void setRelatedStructures(RelatedStructuresMutableBean relatedStructures) {
		this.relatedStructures = relatedStructures;
	}

	@Override
	public void setStructureMapList(List<StructureMapMutableBean> structureMapList) {
		this.structureMapList = structureMapList;
	}

	@Override
	public void setCodelistMapList(List<CodelistMapMutableBean> codelistMapList) {
		this.codelistMapList = codelistMapList;
	}

	@Override
	public void setCategorySchemeMapList(List<CategorySchemeMapMutableBean> categorySchemeMapList) {
		this.categorySchemeMapList = categorySchemeMapList;
	}

	@Override
	public void setConceptSchemeMapList(List<ConceptSchemeMapMutableBean> conceptSchemeMapList) {
		this.conceptSchemeMapList = conceptSchemeMapList;
	}

	@Override
	public void setOrganisationSchemeMapList(List<OrganisationSchemeMapMutableBean> organisationSchemeMapList) {
		this.organisationSchemeMapList = organisationSchemeMapList;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////ADDERS 								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void addRelatedStructure(StructureReferenceBean sRef) {
		if(relatedStructures == null) {
			relatedStructures = new RelatedStructuresMutableBeanImpl();
		}
		relatedStructures.addRelatedStructure(sRef);
	}


	@Override
	public void addCategorySchemeMap(CategorySchemeMapMutableBean categorySchemeMap) {
		getCategorySchemeMapList().add(categorySchemeMap);
	}

	@Override
	public void addCodelistMap(CodelistMapMutableBean codelistMap) {
		getCodelistMapList().add(codelistMap);
	}

	@Override
	public void addConceptSchemeMap(ConceptSchemeMapMutableBean conceptSchemeMap) {
		getConceptSchemeMapList().add(conceptSchemeMap);
	}

	@Override
	public void addOrganisationSchemeMap(OrganisationSchemeMapMutableBean organisationSchemeMap) {
		getOrganisationSchemeMapList().add(organisationSchemeMap);
	}

	@Override
	public void addStructureMap(StructureMapMutableBean structureMap) {
		getStructureMapList().add(structureMap);
	}

    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(relatedStructures, composites);
        super.addToCompositeSet(structureMapList, composites);
        super.addToCompositeSet(codelistMapList, composites);
        super.addToCompositeSet(categorySchemeMapList, composites);
        super.addToCompositeSet(conceptSchemeMapList, composites);
        super.addToCompositeSet(organisationSchemeMapList, composites);
        return composites;
    }

	@Override
	public StructureSetMutableBean stripItems(Date aDate) {
		if (this.getCodelistMapList().isEmpty()) {
			return this;
		}

		for (CodelistMapMutableBean codelistMap : this.getCodelistMapList()) {
			evaluateCodelistMap(codelistMap, aDate);
		}
		return this;
	}

	private void evaluateCodelistMap(CodelistMapMutableBean codelistMap, Date aDate) {
		List<CodeMapMutableBean> items = codelistMap.getItems();
		ArrayList<CodeMapMutableBean> retVal = new ArrayList<>();
		if(items != null) {
			for (CodeMapMutableBean codeMap : items) {
				if (codeMap.hasValidityPeriod()) {
				    Optional<SdmxPeriod> itemSdmxPeriod = codeMap.getSdmxPeriod();
					if (itemSdmxPeriod.isPresent() && !itemSdmxPeriod.get().isInPeriod(aDate)) {
						continue;
					}
				}
				retVal.add(codeMap);
			}
		}
		codelistMap.setItems(retVal);
	}
}