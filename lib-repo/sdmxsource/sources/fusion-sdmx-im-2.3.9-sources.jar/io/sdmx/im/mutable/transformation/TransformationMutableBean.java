package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class TransformationMutableBean extends ItemMutableBeanImpl implements ITransformationMutableBean {
	private static final long serialVersionUID = 1L;
	private String result;
	private boolean isPersistent;
	private String expression;

	public TransformationMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION);
	}
	
	public TransformationMutableBean(ITransformationBean bean, ITransformationSchemeMutableBean parent) {
		super(bean, parent);
		this.result = bean.getResult();
		this.isPersistent = bean.isPersistent();
		this.expression = bean.getExpression();
	}

	@Override
	public String getResult() {
		return result;
	}

	@Override
	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public boolean isPersistent() {
		return isPersistent;
	}

	@Override
	public void setPersistent(boolean isPersistent) {
		this.isPersistent = isPersistent;
	}

	@Override
	public String getExpression() {
		return expression;
	}

	@Override
	public void setExpression(String expression) {
		this.expression = expression;
	}
}
