package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetKeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetRegionMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class MetadataTargetRegionMutableBeanImpl extends MutableBeanImpl implements MetadataTargetRegionMutableBean {
	private static final long serialVersionUID = 7159174068190000136L;
	private boolean include;
	private String report;
	private String metadataTarget;
	private List<KeyValuesMutable> attributes = new ArrayList<>();
	private List<MetadataTargetKeyValuesMutable> key = new ArrayList<>();
	
	public MetadataTargetRegionMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.METADATA_TARGET_REGION);
	}
	

	public MetadataTargetRegionMutableBeanImpl(MetadataTargetRegionBean bean, MutableBean parent) {
		super(bean, parent);
		this.include  = bean.isInclude();
		this.report = bean.getReport();
		this.metadataTarget = bean.getMetadataTarget();
		for(MetadataTargetKeyValuesBean currentKv : bean.getTargetKeyValues()) {
			key.add(new MetadataTargetKeyValuesMutableImpl(currentKv, this));
		}
		for(KeyValues currentKv : bean.getAttributes()) {
			attributes.add(new KeyValuesMutableImpl(currentKv, this));
		}
	}



	@Override
	public boolean isInclude() {
		return include;
	}

	@Override
	public String getReport() {
		return report;
	}

	@Override
	public String getMetadataTarget() {
		return metadataTarget;
	}

	@Override
	public List<MetadataTargetKeyValuesMutable> getKey() {
		return this.key;
	}

	@Override
	public void setKey(List<MetadataTargetKeyValuesMutable> key) {
		this.key = key;
	}

	@Override
	public void addKey(MetadataTargetKeyValuesMutable key) {
		if(this.key == null) {
			this.key = new ArrayList<>();
		}
		this.key.add(key);
	}

	@Override
	public List<KeyValuesMutable> getAttributes() {
		return attributes;
	}

	@Override
	public void setAttributes(List<KeyValuesMutable> attributes) {
		this.attributes = attributes;
	}

	@Override
	public void addAttribute(KeyValuesMutable attribute) {
		if(this.attributes == null) {
			this.attributes = new ArrayList<>();
		}
		this.attributes.add(attribute);
	}

    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(key, composites);
        super.addToCompositeSet(attributes, composites);
        return composites;
    }


	@Override
	public void setIsInclude(boolean include) {
		this.include = include;
	}


	@Override
	public void setMetadataTarget(String metadatatarget) {
		this.metadataTarget = metadatatarget;
		
	}


	@Override
	public void setReport(String report) {
		this.report = report;
	}
}