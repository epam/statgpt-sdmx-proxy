package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;

public class ConceptMapMutableBean extends ItemMapMutableBean<IConceptMapMutableBean> implements IConceptMapMutableBean {

	public ConceptMapMutableBean() {
		super();
	}

	public ConceptMapMutableBean(IConceptMapBean bean, IConceptSchemeMapMutableBean parent) {
		super(bean, parent);
	}

	@Override
	public IConceptMapMutableBean getThis() {
		return this;
	}
}
