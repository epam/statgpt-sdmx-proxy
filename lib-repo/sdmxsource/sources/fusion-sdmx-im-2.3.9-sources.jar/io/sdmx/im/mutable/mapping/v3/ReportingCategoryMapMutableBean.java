package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingCategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;

public class ReportingCategoryMapMutableBean extends ItemMapMutableBean<IReportingCategoryMapMutableBean> implements IReportingCategoryMapMutableBean {

	public ReportingCategoryMapMutableBean() {
		super();
	}

	public ReportingCategoryMapMutableBean(IReportingCategoryMapBean bean, IReportingTaxonomyMapMutableBean parent) {
		super(bean, parent);
	}

	@Override
	public IReportingCategoryMapMutableBean getThis() {
		return this;
	}
}
