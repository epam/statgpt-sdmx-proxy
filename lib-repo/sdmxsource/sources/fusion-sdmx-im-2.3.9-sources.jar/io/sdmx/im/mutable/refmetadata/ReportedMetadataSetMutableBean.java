package io.sdmx.im.mutable.refmetadata;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.im.beans.refmetadata.ReportedMetadataSetBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class ReportedMetadataSetMutableBean extends MaintainableMutableBeanImpl implements IReportedMetadataSetMutableBean {
	private static final long serialVersionUID = 1L;

	private StructureReferenceBean structure;
	private List<StructureReferenceBean> targets = new ArrayList<>();
	private List<IReportedMetadataAttributeMutableBean> attributes = new ArrayList<>();

	public ReportedMetadataSetMutableBean() {
		super(SDMX_STRUCTURE_TYPE.METADATA_SET);
	}
	
	public ReportedMetadataSetMutableBean(IReportedMetadataSetBean bean) {
		super(bean);
		this.structure = new StructureReferenceBeanImpl(bean.getStructure().getTargetUrn());
		for(ICrossReferenceBeanBase target : bean.getTargets()) {
			this.targets.add(target.asMutable());
		}
		for(IReportedMetadataAttributeBean attr : bean.getAttributes()) {
			this.attributes.add(new ReportedMetadataAttributeMutableBean(attr, this));
		}
	}

	@Override
	public StructureReferenceBean getStructure() {
		return structure;
	}

	@Override
	public IReportedMetadataSetMutableBean setStructure(StructureReferenceBean ref) {
		this.structure = ref;
		return this;
	}

	@Override
	public List<StructureReferenceBean> getTargets() {
		return this.targets;
	}

	@Override
	public IReportedMetadataSetMutableBean setTargets(List<StructureReferenceBean> targets) {
		this.targets = targets;
		return this;
	}

	@Override
	public IReportedMetadataSetMutableBean addTarget(StructureReferenceBean target) {
		if(this.targets == null) {
			this.targets = new ArrayList<>();
		}
		this.targets.add(target);
		return this;
	}

	@Override
	public List<IReportedMetadataAttributeMutableBean> getAttributes() {
		return attributes;
	}

	@Override
	public IReportedMetadataSetMutableBean setAttributes(List<IReportedMetadataAttributeMutableBean> attrs) {
		this.attributes = attrs;
		return this;
	}

	@Override
	public IReportedMetadataSetMutableBean addAttribute(IReportedMetadataAttributeMutableBean attr) {
		if(this.attributes == null) {
			this.attributes = new ArrayList<>();
		}
		this.attributes.add(attr);
		return this;
	}

	@Override
	public IReportedMetadataSetBean getImmutableInstance() {
		return new ReportedMetadataSetBean(this);
	}
}
