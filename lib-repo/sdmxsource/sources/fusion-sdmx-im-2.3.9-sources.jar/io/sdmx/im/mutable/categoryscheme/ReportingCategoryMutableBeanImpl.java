package io.sdmx.im.mutable.categoryscheme;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class ReportingCategoryMutableBeanImpl extends ItemMutableBeanImpl implements ReportingCategoryMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<StructureReferenceBean> structuralMetadata = new ArrayList<>();
	private List<StructureReferenceBean> provisioningMetadata = new ArrayList<>();
	private List<ReportingCategoryMutableBean> reportingCategories = new ArrayList<>();
	
	/**
	 * Default Constructor
	 */
	public ReportingCategoryMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_CATEGORY);
	}
	
	/**
	 * Construct from ReportingCategoryBean Bean
	 * @param bean
	 */
	public ReportingCategoryMutableBeanImpl(ReportingCategoryBean bean, MutableBean parent) {
		super(bean, parent);
		
		if(bean.getStructuralMetadata() != null) {
			for(ICrossReferenceBean<?> currentBean : bean.getStructuralMetadata()) {
				structuralMetadata.add(currentBean.asMutable());
			}
		}
		if(bean.getProvisioningMetadata() != null) {
			for(ICrossReferenceBean<?> currentBean : bean.getProvisioningMetadata()) {
				provisioningMetadata.add(currentBean.asMutable());
			}
		}
		if(bean.getItems() != null) {
			for(ReportingCategoryBean reportingCategoryBean : bean.getItems()) {
				this.reportingCategories.add(new ReportingCategoryMutableBeanImpl(reportingCategoryBean, this));
			}
		}		
	}

	@Override
	public List<StructureReferenceBean> getStructuralMetadata() {
		return structuralMetadata;
	}

	@Override
	public void setStructuralMetadata(List<StructureReferenceBean> structuralMetadata) {
		this.structuralMetadata = structuralMetadata;
	}

	@Override
	public List<StructureReferenceBean> getProvisioningMetadata() {
		return provisioningMetadata;
	}

	@Override
	public void setProvisioningMetadata(
			List<StructureReferenceBean> provisioningMetadata) {
		this.provisioningMetadata = provisioningMetadata;
	}

	@Override
	public List<ReportingCategoryMutableBean> getItems() {
		return reportingCategories;
	}

	@Override
	public void setItems(List<ReportingCategoryMutableBean> reportingCategories) {
		this.reportingCategories = reportingCategories;
	}
	
	@Override
	public void addItem(ReportingCategoryMutableBean reportingCategory) {
		if(this.reportingCategories == null) {
			this.reportingCategories = new ArrayList<>();
		}
		this.reportingCategories.add(reportingCategory);
	}

	@Override
	public void addStructuralMetadata(StructureReferenceBean structuralMetadata) {
		if(this.structuralMetadata == null) {
			this.structuralMetadata = new ArrayList<>();
		}
		this.structuralMetadata.add(structuralMetadata);
	}

	@Override
	public void addProvisioningMetadata(StructureReferenceBean provisioningMetadata) {
		if(this.provisioningMetadata == null) {
			this.provisioningMetadata = new ArrayList<>();
		}
		this.provisioningMetadata.add(provisioningMetadata);
	}
	
	@Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
    	super.addToCompositeSet(reportingCategories, composites);
    	return composites;
    }
}