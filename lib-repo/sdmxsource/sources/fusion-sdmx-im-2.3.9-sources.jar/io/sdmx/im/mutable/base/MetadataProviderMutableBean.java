package io.sdmx.im.mutable.base;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class MetadataProviderMutableBean extends OrganisationMutableBeanImpl implements IMetadataProviderMutableBean {
	private static final long serialVersionUID = 1L;
	
	public MetadataProviderMutableBean() {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVIDER);
	}

	public MetadataProviderMutableBean(IMetadataProviderBean bean, MutableBean parent) {
		super(bean, parent);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
        return super.getComposites();
    }
}
