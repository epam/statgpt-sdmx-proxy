package io.sdmx.im.mutable.categoryscheme;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.im.beans.categoryscheme.ReportingTaxonomyBeanImpl;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;

public class ReportingTaxonomyMutableBeanImpl extends ItemSchemeMutableBeanImpl<ReportingCategoryMutableBean> implements ReportingTaxonomyMutableBean {
	
	private static final long serialVersionUID = 1L;

	public ReportingTaxonomyMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY);
	}

	public ReportingTaxonomyMutableBeanImpl(ReportingTaxonomyBean bean) {
		super(bean);
		
		// make into a Category mutable list
		if(bean.getItems() != null) {
			for(ReportingCategoryBean currentBean : bean.getItems()) {
				this.addReportingCategory(new ReportingCategoryMutableBeanImpl(currentBean, this));
			}
		}
	}
	
	@Override
	public ReportingCategoryMutableBean createItem(String id, String name) {
		ReportingCategoryMutableBean rcMut = new ReportingCategoryMutableBeanImpl();
		rcMut.setId(id);
		rcMut.addName("en", name);
		addItem(rcMut);
		return rcMut;
	}
	
	@Override
	public boolean removeItem(String id) {
		if(id.contains(".")) {
			String[] idArray = id.split("\\.");
			for(ReportingCategoryMutableBean cat : getItems()) {
				if(cat.getId().equals(idArray[0])) {
					return removeItem(cat, idArray, 1);
				}
			}
			return false;
		} 
		return super.removeItem(id);
		
	}
	
	private boolean removeItem(ReportingCategoryMutableBean parent, String[] idArray, int pos) {
		String searchId = idArray[pos];
		ReportingCategoryMutableBean removeCat = null;
		for(ReportingCategoryMutableBean cat : parent.getItems()) {
			if(cat.getId().equals(searchId)) {
				if(idArray.length > ++pos) {
					return removeItem(cat, idArray, ++pos);
				} else {
					removeCat = cat;
					break;
				}
			}
		}
		if(removeCat != null) {
			parent.getItems().remove(removeCat);
		}
		return removeCat != null;
	}

	@Override
	public ReportingTaxonomyBean getImmutableInstance() {
		return new ReportingTaxonomyBeanImpl(this);
	}
	
	public void addReportingCategory(ReportingCategoryMutableBean category) {
		super.addItem(category);
	}
}
