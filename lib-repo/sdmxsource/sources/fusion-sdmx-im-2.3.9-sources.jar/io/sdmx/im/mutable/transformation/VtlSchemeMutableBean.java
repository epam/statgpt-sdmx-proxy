package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlSchemeMutableBean;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;

public abstract class VtlSchemeMutableBean<T extends ItemMutableBean> extends ItemSchemeMutableBeanImpl<T> implements IVtlSchemeMutableBean<T> {
	private static final long serialVersionUID = 1L;

	private String vtlVersion;

	public VtlSchemeMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}
	
	public VtlSchemeMutableBean(IVtlSchemeBean bean) {
		super(bean);
		this.vtlVersion = bean.getVtlVersion();
	}
	
	@Override
	public String getVtlVersion() {
		return vtlVersion;
	}

	@Override
	public void setVtlVersion(String vtlVersion) {
		this.vtlVersion = vtlVersion;
	}
}
