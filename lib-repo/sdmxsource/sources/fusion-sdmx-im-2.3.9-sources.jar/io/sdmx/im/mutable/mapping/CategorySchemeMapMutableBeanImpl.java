package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;

public class CategorySchemeMapMutableBeanImpl extends GenericItemSchemeMapMutableBean implements CategorySchemeMapMutableBean {
	private static final long serialVersionUID = 8829767446075036603L;
	private List<CategoryMapMutableBean> categoryMaps = new ArrayList<>();

	public CategorySchemeMapMutableBeanImpl () {
		super(SDMX_STRUCTURE_TYPE.V2_CATEGORY_SCHEME_MAP);
	}

	public CategorySchemeMapMutableBeanImpl(CategorySchemeMapBean bean, MutableBean parent) {
		super(bean, parent);
	}

	@Override
	public List<CategoryMapMutableBean> getCategoryMaps() {
		return categoryMaps;
	}

	@Override
	public void setCategoryMaps(List<CategoryMapMutableBean> categoryMaps) {
		this.categoryMaps = categoryMaps;
	}

	@Override
	public void addCategoryMap(CategoryMapMutableBean categoryMap) {
		this.categoryMaps.add(categoryMap);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CATEGORY;
	}
}