package io.sdmx.im.mutable.reporting;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionSheetMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.beans.reporting.ReportingTemplateBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class ReportingTemplateMutableBeanImpl extends MaintainableMutableBeanImpl implements ReportingTemplateMutableBean {
	private static final long serialVersionUID = -8335046325726052578L;
	
	private ReportTemplateInstructionSheetMutableBean instructionSheet;
	private List<ReportingTemplateWorksheetMutableBean> worksheets;
	private boolean includeFormulaCheckingSummary;

	public ReportingTemplateMutableBeanImpl(ReportingTemplateBean reportingTemplateBean) {
		super(reportingTemplateBean);
		this.worksheets = new ArrayList<>();
		for(ReportingTemplateWorksheetBean rtWorksheet : reportingTemplateBean.getWorksheets()) {
			this.worksheets.add(new ReportingTemplateWorksheetMutableBeanImpl(rtWorksheet, this));
		}
		this.includeFormulaCheckingSummary = reportingTemplateBean.includeFormulaCheckingSummary();
		if(reportingTemplateBean.getInstructionSheet() != null) { 
			this.instructionSheet = new ReportTemplateInstructionSheetMutableBeanImpl(reportingTemplateBean.getInstructionSheet(), this);
		}
	}

	public ReportingTemplateMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE);
	}

	@Override
	public void setInstructionSheet(ReportTemplateInstructionSheetMutableBean instructionSheet) {
		this.instructionSheet = instructionSheet;
	}

	@Override
	public ReportTemplateInstructionSheetMutableBean getInstructionSheet() {
		return instructionSheet;
	}

	@Override
	public List<ReportingTemplateWorksheetMutableBean> getWorksheets() {
		return worksheets;
	}

	@Override
	public void setWorksheets(List<ReportingTemplateWorksheetMutableBean> worksheets) {
		this.worksheets = worksheets;
	}
	

	@Override
	public boolean includeFormulaCheckingSummary() {
		return includeFormulaCheckingSummary;
	}

	@Override
	public void setIncludeFormulaCheckingSummary(boolean bool) {
		this.includeFormulaCheckingSummary = bool;
	}

	@Override
    public Set<MutableBean> getComposites() {
        Set<MutableBean> composites = super.getComposites();
        for (ReportingTemplateWorksheetMutableBean rtmb : worksheets) {
            composites.addAll(rtmb.getComposites());
        }
        return composites;
    }

	@Override
    public List<StructureReferenceBean> getStructureReferencesInternal() {
        List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
        for (ReportingTemplateWorksheetMutableBean rtmb : worksheets) {
            returnSet.addAll(rtmb.getStructureReferences());
        }
        return returnSet;
    }

	@Override
	public ReportingTemplateBean getImmutableInstance() {
		return new ReportingTemplateBeanImpl(this);
	}
}
