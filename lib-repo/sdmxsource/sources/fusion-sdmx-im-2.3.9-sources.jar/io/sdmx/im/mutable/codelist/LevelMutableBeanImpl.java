package io.sdmx.im.mutable.codelist;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.im.mutable.base.NameableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;

public class LevelMutableBeanImpl extends NameableMutableBeanImpl implements LevelMutableBean {
	private static final long serialVersionUID = 1L;
	
	private LevelMutableBean childLevel;
	private TextFormatMutableBean codingFormat;
	
	public LevelMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.LEVEL);
	}

	public LevelMutableBeanImpl(LevelBean level, MutableBean parent) {
		super(level, parent);
		if(level.hasChild()) {
			this.childLevel = new LevelMutableBeanImpl(level.getChildLevel(), this);		
		}
		if(level.getCodingFormat() != null) {
			this.codingFormat = new TextFormatMutableBeanImpl(level.getCodingFormat(), this);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public LevelMutableBean getChildLevel() {
		return childLevel;
	}

	@Override
	public void setChildLevel(LevelMutableBean childLevel) {
		this.childLevel = childLevel;
	}

	@Override
	public TextFormatMutableBean getCodingFormat() {
		return codingFormat;
	}

	@Override
	public void setCodingFormat(TextFormatMutableBean codingFormat) {
		this.codingFormat = codingFormat;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(childLevel, composites);
		super.addToCompositeSet(codingFormat, composites);
		return composites;
	}
}
