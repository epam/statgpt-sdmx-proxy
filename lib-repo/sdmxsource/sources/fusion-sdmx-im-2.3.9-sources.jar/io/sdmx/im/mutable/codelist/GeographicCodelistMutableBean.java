package io.sdmx.im.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoFeatureSetCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.im.beans.codelist.GeographicCodelistBean;

public class GeographicCodelistMutableBean extends CodelistMutableBeanImpl implements IGeographicCodelistMutableBean {
	private static final long serialVersionUID = 1L;

	public GeographicCodelistMutableBean() {
		super();
	}

	public GeographicCodelistMutableBean(IGeographicCodelistBean bean) {
		super(bean);
	}

	@Override
	protected IGeoFeatureSetCodeMutableBean buildMutableCode(CodeBean code) {
		return new GeoFeatureSetCodeMutableBean((IGeoFeatureSetCodeBean)code, this);
	}

	@Override
	public IGeographicCodelistBean getImmutableInstance() {
		return new GeographicCodelistBean(this);
	}
}
