package io.sdmx.im.mutable.mapping;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

public class ItemMapMutableBeanImpl extends AnnotableMutableBeanImpl implements ItemMapMutableBean {

	private static final long serialVersionUID = 1L;

	private String sourceId;
	private String targetId;

	public ItemMapMutableBeanImpl () {
		super(SDMX_STRUCTURE_TYPE.ITEM_MAP);
	}

	public ItemMapMutableBeanImpl (ItemMapBean bean, MutableBean parent) {
		super(bean, parent);
		setSourceId(bean.getSourceId());
		setTargetId(bean.getTargetId());
	}

	@Override
	public String getSourceId() {
		return sourceId;
	}

	@Override
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	@Override
	public String getTargetId() {
		return targetId;
	}

	@Override
	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}
}