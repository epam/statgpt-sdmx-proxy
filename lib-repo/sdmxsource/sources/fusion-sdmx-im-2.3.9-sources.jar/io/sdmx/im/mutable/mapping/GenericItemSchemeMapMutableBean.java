package io.sdmx.im.mutable.mapping;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;

public abstract class GenericItemSchemeMapMutableBean extends ItemSchemeMapMutableBeanImpl<ItemMapMutableBean> {
	private static final long serialVersionUID = 1L;

	public GenericItemSchemeMapMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public GenericItemSchemeMapMutableBean(ItemSchemeMapBean<ItemMapBean> bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getItems() != null) {
			for(ItemMapBean item : bean.getItems()) {
				super.addItem(new ItemMapMutableBeanImpl(item, this));
			}
		}
	}
	
}
