
package io.sdmx.im.mutable.registry;

import java.util.Date;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;


public class ReferencePeriodMutableBeanImpl extends MutableBeanImpl implements ReferencePeriodMutableBean {
	private static final long serialVersionUID = 1L;
	
	private Date startTime;
	private Date endTime;
	
	public ReferencePeriodMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REFERENCE_PERIOD);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReferencePeriodMutableBeanImpl(ReferencePeriodBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getStartTime() != null) {
			this.startTime = bean.getStartTime().getDate();
		}
		if(bean.getEndTime() != null) {
			this.endTime = bean.getEndTime().getDate();
		}
	}

	@Override
	public Date getStartTime() {
		return this.startTime;
	}

	@Override
	public void setStartTime(Date start) {
		this.startTime = start;
	}

	@Override
	public Date getEndTime() {
		return this.endTime;
	}

	@Override
	public void setEndTime(Date end) {
		this.endTime = end;
	}	
}
