package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.im.beans.transformation.UserDefinedOperatorSchemeBean;

public class UserDefinedOperatorSchemeMutableBean extends VtlSchemeMutableBean<IUserDefinedOperatorMutableBean> implements IUserDefinedOperatorSchemeMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean vtlMappingSchemeRef;
	private List<StructureReferenceBean> rulesetSchemeRef;
	
	public UserDefinedOperatorSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME);
	}

	public UserDefinedOperatorSchemeMutableBean(IUserDefinedOperatorSchemeBean bean) {
		super(bean);
		
		this.items = new ArrayList<>(bean.getItems().size());
		for(IUserDefinedOperatorBean item : bean.getItems()) {
			this.items.add(new UserDefinedOperatorMutableBean(item, this));
		}
		this.vtlMappingSchemeRef = super.getStructureReference(bean.getVtlMappingSchemeRef());
		this.rulesetSchemeRef = super.getStructureReference(bean.getRulesetSchemeRef());
	}
	
	
	
	@Override
	public IUserDefinedOperatorMutableBean addUserDefinedOperator(String id, String operator) {
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
		IUserDefinedOperatorMutableBean item = new UserDefinedOperatorMutableBean();
		item.setId(id);
		item.setOperatorDefinition(operator);
		this.items.add(item);
		return item;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean>  returnList = super.getStructureReferencesInternal();
		if(vtlMappingSchemeRef != null) {
			returnList.add(vtlMappingSchemeRef);
		}
		if(rulesetSchemeRef != null) {
			returnList.addAll(rulesetSchemeRef);
		}
		return returnList;
	}
	
	@Override
	public StructureReferenceBean getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public void setVtlMappingSchemeRef(StructureReferenceBean vtlMappingSchemeRef) {
		this.vtlMappingSchemeRef = vtlMappingSchemeRef;
	}

	@Override
	public List<StructureReferenceBean> getRulesetSchemeRef() {
		return rulesetSchemeRef;
	}

	@Override
	public IUserDefinedOperatorSchemeMutableBean addRulesetSchemeRef(StructureReferenceBean ref) {
		if(ref == null) {
			return this;
		}
		if(this.rulesetSchemeRef == null) {
			this.rulesetSchemeRef = new ArrayList<>();
		}
		this.rulesetSchemeRef.add(ref);
		return this;
	}


	@Override
	public void setRulesetSchemeRef(List<StructureReferenceBean> rulesetSchemeRef) {
		this.rulesetSchemeRef = rulesetSchemeRef;
	}

	@Override
	public IUserDefinedOperatorSchemeBean getImmutableInstance() {
		return new UserDefinedOperatorSchemeBean(this);
	}
	
}
