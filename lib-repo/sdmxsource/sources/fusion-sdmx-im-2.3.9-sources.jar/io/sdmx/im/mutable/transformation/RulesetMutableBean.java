package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class RulesetMutableBean extends ItemMutableBeanImpl implements IRulesetMutableBean {
	private static final long serialVersionUID = 1L;
	private String rulesetDefinition;
	private String rulesetType;
	private String rulesetScope;

	public RulesetMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_RULESET);
	}

	public RulesetMutableBean(IRulesetBean bean, MutableBean parent) {
		super(bean, parent);
		this.rulesetDefinition = bean.getRulesetDefinition();
		this.rulesetType = bean.getRulesetType();
		this.rulesetScope = bean.getRulesetScope();
	}

	@Override
	public String getRulesetDefinition() {
		return rulesetDefinition;
	}

	@Override
	public void setRulesetDefinition(String rulesetDefinition) {
		this.rulesetDefinition = rulesetDefinition;
	}

	@Override
	public String getRulesetType() {
		return rulesetType;
	}

	@Override
	public void setRulesetType(String rulesetType) {
		this.rulesetType = rulesetType;
	}

	@Override
	public String getRulesetScope() {
		return rulesetScope;
	}

	@Override
	public void setRulesetScope(String rulesetScope) {
		this.rulesetScope = rulesetScope;
	}
}
