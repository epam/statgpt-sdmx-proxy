package io.sdmx.im.mutable.conceptscheme;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.im.beans.conceptscheme.ConceptSchemeBeanImpl;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;

public class ConceptSchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<ConceptMutableBean> implements ConceptSchemeMutableBean {

	private static final long serialVersionUID = 1L;

	private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

	public ConceptSchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
	}

	public ConceptSchemeMutableBeanImpl(ConceptSchemeBean bean) {
		super(bean);
		this.validityType = bean.getValidityType();
		for (ConceptBean currentBean : bean.getItems()) {
			this.addItem(new ConceptMutableBeanImpl(currentBean, this));
		}
	}


	@Override
	public ConceptMutableBean createItem(String id, String name) {
		ConceptMutableBean concept = new ConceptMutableBeanImpl();
		concept.setId(id);
		concept.addName("en", name);
		addItem(concept);
		return concept;
	}

	@Override
	public ConceptSchemeBean getImmutableInstance() {
		return new ConceptSchemeBeanImpl(this);
	}

    @Override
    protected MaintainableMutableBean createPartial(Set<String> itemSet, boolean keep, boolean isUrn, ITEM_FILTER_ACTION filterAction) {
    	Map<String, Set<ConceptMutableBean>> itemMap = new HashMap<>();
		for(ConceptMutableBean concept : super.getItems()) {
			Set<ConceptMutableBean> concepts = itemMap.get(concept.getId());
			if(concepts == null) {
				concepts = new HashSet<>();
				itemMap.put(concept.getId(), concepts);
			}
			concepts.add(concept);
		}
		
		super.createPartial(itemSet, keep, isUrn, filterAction);


		if(filterAction != ITEM_FILTER_ACTION.NO_ACTION) {
			List<ConceptMutableBean> toCheck = items;
			Set<String> allCodeIds = items.stream().map(ConceptMutableBean::getId).collect(Collectors.toSet());
			while(toCheck.size() > 0) {
				List<ConceptMutableBean> toAdd = new ArrayList<ConceptMutableBean>();
				for(ConceptMutableBean currentItem : toCheck) {
					String parentCode = currentItem.getParentConcept();
					if (parentCode != null && !allCodeIds.contains(parentCode)) {
						if(filterAction == ITEM_FILTER_ACTION.KEEP_PARENT) {
							toAdd.addAll(itemMap.get(parentCode));
							allCodeIds.add(parentCode);
						} else {
							currentItem.setParentConcept(null);
						}
					}
				}
				items.addAll(toAdd);
				toCheck = toAdd;
			}
		}
        return this;
    }

	@Override
	public MAINT_VALIDITY_TYPE getValidityType() {
		return this.validityType;
	}

	@Override
	public void setValidityType(MAINT_VALIDITY_TYPE validityType) {
		this.validityType = validityType;
	}
}