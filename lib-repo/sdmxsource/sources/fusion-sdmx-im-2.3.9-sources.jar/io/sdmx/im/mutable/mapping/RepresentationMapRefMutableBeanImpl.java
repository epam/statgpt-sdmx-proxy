package io.sdmx.im.mutable.mapping;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;

public class RepresentationMapRefMutableBeanImpl extends MutableBeanImpl implements RepresentationMapRefMutableBean {
	private static final long serialVersionUID = -860429690903269870L;
	private String codelistMap;
	private TextFormatMutableBean toTextFormat;
	private TO_VALUE toValueType;
	private Map<String, Set<String>> valueMappings = new LinkedHashMap<>();

	public RepresentationMapRefMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
	}

	public RepresentationMapRefMutableBeanImpl(RepresentationMapRefBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getCodelistMap() != null) {
			this.codelistMap = bean.getCodelistMap().getId();
		}
		if(bean.getToTextFormat() != null) {
			this.toTextFormat = new TextFormatMutableBeanImpl(bean.getToTextFormat(), this);
		}
		this.toValueType = bean.getToValueType();

		//Create a Copy
		if(bean.getValueMappings() != null) {
			for(String key : bean.getValueMappings().keySet()) {
				this.valueMappings.put(key, new HashSet<>(bean.getValueMappings().get(key)));
			}
		}
	}

	@Override
	public void addMapping(String componentId, String componentValue) {
		Set<String> mappings = valueMappings.get(componentId);
		if(mappings == null) {
			mappings = new HashSet<>();
			valueMappings.put(componentId, mappings);
		}
		mappings.add(componentValue);
	}

	@Override
	public String getCodelistMapRef() {
		return codelistMap;
	}



	@Override
	public void setCodelistMapRef(String codelistMap) {
		this.codelistMap = codelistMap;
	}

	@Override
	public TextFormatMutableBean getToTextFormat() {
		return toTextFormat;
	}

	@Override
	public void setToTextFormat(TextFormatMutableBean toTextFormat) {
		this.toTextFormat = toTextFormat;
	}

	@Override
	public TO_VALUE getToValueType() {
		return toValueType;
	}

	@Override
	public void setToValueType(TO_VALUE toValueType) {
		this.toValueType = toValueType;
	}

	@Override
	public Map<String, Set<String>> getValueMappings() {
		return valueMappings;
	}

	@Override
	public void setValueMappings(Map<String, Set<String>> valueMappings) {
		this.valueMappings = valueMappings;
	}


    @Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(toTextFormat, composites);
	    return composites;
	}

	@Override
	public Set<String> getMappingsFromComponentId(String componentId) {
		Set<String> mappings = valueMappings.get(componentId);
		if(mappings == null) {
			return new HashSet<>();
		}
		return mappings;
	}
}