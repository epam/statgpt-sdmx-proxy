package io.sdmx.im.mutable.reporting;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateColourBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateColourMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ReportingTemplateColourMutableBeanImpl extends MutableBeanImpl implements ReportingTemplateColourMutableBean {
	private static final long serialVersionUID = 8501153281254638315L;
	private String attributeId;
	private String defaultColour;
	private Map<String, String> colourCodes;
	private Map<Set<String>, String> seriesColours;
	
	public ReportingTemplateColourMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_COLOUR);
	}

	public ReportingTemplateColourMutableBeanImpl(ReportingTemplateColourBean createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.attributeId = createdFrom.getAttributeId();
		this.defaultColour = createdFrom.getDefaultColour();
		this.colourCodes = new HashMap<>(createdFrom.getColourCodes());
		
		this.seriesColours = new HashMap<>();
		Map<Set<String>, String> colours = createdFrom.getSeriesColours();
		for(Set<String> key : colours.keySet()) {
			seriesColours.put(new HashSet<>(key), colours.get(key));
		}
	}

	@Override
	public String getAttributeId() {
		return attributeId;
	}

	@Override
	public String getDefaultColour() {
		return defaultColour;
	}

	@Override
	public Map<String, String> getColourCodes() {
		return colourCodes;
	}

	@Override
	public Map<Set<String>, String> getSeriesColours() {
		return seriesColours;
	}

	@Override
	public void setAttributeId(String str) {
		this.attributeId = str;
	}

	@Override
	public void setDefaultColour(String str) {
		this.defaultColour = str;
	}

	@Override
	public void setColourCodes(Map<String, String> map) {
		this.colourCodes = map;
	}

	@Override
	public void setSeriesColours(Map<Set<String>, String> map) {
		this.seriesColours = map;
	}
}
