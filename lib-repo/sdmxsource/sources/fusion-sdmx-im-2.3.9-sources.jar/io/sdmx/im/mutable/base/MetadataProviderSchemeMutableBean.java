package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;
import io.sdmx.im.beans.base.MetadataProviderSchemeBean;

public class MetadataProviderSchemeMutableBean extends ItemSchemeMutableBeanImpl<IMetadataProviderMutableBean> implements IMetadataProviderSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public MetadataProviderSchemeMutableBean(IMetadataProviderSchemeBean bean) {
		super(bean);
		for(IMetadataProviderBean dataProviderBean : bean.getItems()) {
			this.addItem(new MetadataProviderMutableBean(dataProviderBean, this));
		}
	}
	
	@Override
	public IMetadataProviderMutableBean createItem(String id, String name) {
		IMetadataProviderMutableBean dpBean = new MetadataProviderMutableBean();
		dpBean.setId(id);
		dpBean.addName("en", name);
		addItem(dpBean);
		return dpBean;
	}

	public MetadataProviderSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.METADATA_PROVIDER_SCHEME);
	}

	@Override
	public IMetadataProviderSchemeBean getImmutableInstance() {
		return new MetadataProviderSchemeBean(this);
	}
}