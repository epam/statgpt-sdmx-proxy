package io.sdmx.im.mutable.valuelist;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;

public class ValueItemMutableBeanImpl extends AnnotableMutableBeanImpl implements ValueItemMutableBean {
	private static final long serialVersionUID = 1L;
	private String id;
	private List<TextTypeWrapperMutableBean> names;
	private List<TextTypeWrapperMutableBean> descriptions;
	
	public ValueItemMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.VALUE_ITEM);
	}

	public ValueItemMutableBeanImpl(ValueItemBean bean, ValueListMutableBean parent) {
		super(bean, parent);
		this.id = bean.getId();
		setNames(bean.getNames());
		setDescriptions(bean.getDescriptions());
	}
	
	public void setNames(List<TextTypeWrapper> thatNames) {
		if(thatNames != null) {
			names = new ArrayList<>();
			for (TextTypeWrapper currentTextType : thatNames) {
				names.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}
	

	public void setDescriptions(List<TextTypeWrapper> thatDesc) {
		if(thatDesc != null) {
			descriptions = new ArrayList<>();
			for (TextTypeWrapper currentTextType : thatDesc) {
				descriptions.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public List<TextTypeWrapperMutableBean> getNames() {
		return names;
	}

	@Override
	public void addName(String locale, String value) {
		if(names == null) {
			this.names = new ArrayList<>();
		}
		this.names.add(new TextTypeWrapperMutableBeanImpl(locale, value));
	}

	@Override
	public void setName(List<TextTypeWrapperMutableBean> name) {
		this.names = name;
	}

	@Override
	public List<TextTypeWrapperMutableBean> getDescriptions() {
		return descriptions;
	}

	@Override
	public void setDescription(List<TextTypeWrapperMutableBean> description) {
		this.descriptions = description;
	}

	@Override
	public void addDescription(String locale, String value) {
		if(descriptions == null) {
			this.descriptions = new ArrayList<>();
		}
		this.descriptions.add(new TextTypeWrapperMutableBeanImpl(locale, value));
	}

}
