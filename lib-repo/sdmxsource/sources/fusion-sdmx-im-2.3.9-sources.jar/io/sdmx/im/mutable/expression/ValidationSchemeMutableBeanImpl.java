package io.sdmx.im.mutable.expression;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;
import io.sdmx.im.beans.calculation.ValidationSchemeBeanImpl;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;

public class ValidationSchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<ValidationRuleMutableBean> implements ValidationSchemeMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean attachment;
	
	public ValidationSchemeMutableBeanImpl(ValidationSchemeBean bean) {
		super(bean);
		this.attachment = new StructureReferenceBeanImpl(bean.getAttachment().getTargetUrn());
	}

	public ValidationSchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.VALIDATION_SCHEME);
	}

	@Override
	public ValidationRuleMutableBean createItem(String id, String name) {
		ValidationRuleMutableBean newItem = new ValidationRuleMutableBeanImpl();
		newItem.setId(id);
		newItem.addName("en", name);
		addItem(newItem);
		return newItem;
	}
	
	@Override
	public ValidationRuleMutableBean addValidationRule(String ruleId, String ruleName, String result, EQUALITY equality, String expression) {
		ValidationRuleMutableBean rule = createItem(ruleId, ruleName);
		rule.setResultant(result);
		rule.setEqualityOperator(equality);
		rule.setExpression(expression);
		return rule;
	}

	@Override
	public StructureReferenceBean getAttachment() {
		return attachment;
	}

	@Override
	public void setAttachment(StructureReferenceBean sRef) {
		this.attachment = sRef;
	}

	@Override
	public ValidationSchemeBean getImmutableInstance() {
		return new ValidationSchemeBeanImpl(this);
	}

}
