package io.sdmx.im.mutable.metadatastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.im.mutable.base.ComponentMutableBeanImpl;

public class MetadataAttributeMutableBeanImpl extends ComponentMutableBeanImpl implements MetadataAttributeMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<MetadataAttributeMutableBean> metadataAttributes = new ArrayList<>();
	private TERTIARY_BOOL presentational = TERTIARY_BOOL.UNSET;
	
	public MetadataAttributeMutableBeanImpl(MetadataAttributeBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getMetadataAttributes() != null) {
			for(MetadataAttributeBean currentMetadatAttribute : bean.getMetadataAttributes()) {
				this.metadataAttributes.add(new MetadataAttributeMutableBeanImpl(currentMetadatAttribute, this));
			}
		}
		this.presentational = bean.getPresentational();
	}

	public MetadataAttributeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.METADATA_ATTRIBUTE);
	}
	
	@Override
	public TERTIARY_BOOL getPresentational() {
		return this.presentational;
	}

	@Override
	public MetadataAttributeMutableBean addMetadataAttributes(MetadataAttributeMutableBean metadataAttribute) {
		if(this.metadataAttributes == null) {
			this.metadataAttributes = new ArrayList<>();
		}
		this.metadataAttributes.add(metadataAttribute);
		return this;
	}

	@Override
	public List<MetadataAttributeMutableBean> getMetadataAttributes() {
		return metadataAttributes;
	}

	@Override
	public MetadataAttributeMutableBean setPresentational(TERTIARY_BOOL bool) {
		this.presentational = bool;
		return this;
	}

	@Override
	public void setMetadataAttributes(List<MetadataAttributeMutableBean> list) {
		this.metadataAttributes = list;
	}

	@Override
    public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(metadataAttributes, composites);
		return composites;
	}
}