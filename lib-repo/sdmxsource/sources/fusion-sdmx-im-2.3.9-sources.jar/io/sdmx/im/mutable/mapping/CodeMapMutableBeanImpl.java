package io.sdmx.im.mutable.mapping;

import java.util.Date;
import java.util.Optional;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.mapping.CodeMapBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class CodeMapMutableBeanImpl extends ItemMapMutableBeanImpl implements CodeMapMutableBean {

	private static final long serialVersionUID = 1L;
	private Date startDate;
	private Date endDate;

	public CodeMapMutableBeanImpl(CodeMapBean item, ItemSchemeMapMutableBean<CodeMapMutableBean> parent) {
		super(item, parent);
		if(item.getValidityPeriod() != null){
			if( item.getValidityPeriod().getStartPeriod() != null){
				this.startDate = item.getValidityPeriod().getStartPeriod().getDate();
			}
			if(item.getValidityPeriod().getEndPeriod() != null){
				this.endDate = item.getValidityPeriod().getEndPeriod().getDate();
			}
		}

	}

	public CodeMapMutableBeanImpl() {
		this.startDate = null;
		this.endDate = null;
	}

	@Override
	public ValidityPeriodMutableBean setStartDate(Date startDate) {
		this.startDate = startDate;
		return this;
	}

	@Override
	public ValidityPeriodMutableBean setEndDate(Date endDate) {
		this.endDate = endDate;
		return this;
	}

	@Override
	public Date getStartDate() {
		return this.startDate;
	}

	@Override
	public Date getEndDate() {
		return this.endDate;
	}

	@Override
	public Optional<SdmxPeriod> getSdmxPeriod() {
		SdmxDate start = null;
		if (this.startDate != null) {
			start = new SdmxDateImpl(this.startDate, TIME_FORMAT.DATE_TIME);
		}
		SdmxDate end = null;
		if (this.endDate != null) {
			end = new SdmxDateImpl(this.endDate, TIME_FORMAT.DATE_TIME);
		}
		if(end == null && start == null){
			return Optional.empty();
		}
		SdmxPeriod period = new SdmxPeriodImpl(start, end);
		return Optional.ofNullable(period);
	}

}