package io.sdmx.im.mutable.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;

public class ComputationMutableBeanImpl extends AnnotableMutableBeanImpl implements ComputationMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String localId;
	private String softwarePackage;
	private String softwareLanguage;
	private String softwareVersion;
	private List<TextTypeWrapperMutableBean> descriptions = new ArrayList<>();
	
	public ComputationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.COMPUTATION);
	}
	
	public ComputationMutableBeanImpl(ComputationBean bean, MutableBean parent) {
		super(bean, parent);
		this.localId = bean.getLocalId();
		this.softwareLanguage = bean.getSoftwareLanguage();
		this.softwarePackage = bean.getSoftwarePackage();
		this.softwareVersion = bean.getSoftwareVersion();
		if(bean.getDescription() != null) {
			descriptions = new ArrayList<>();
			for (TextTypeWrapper currentTextType : bean.getDescription()) {
				descriptions.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}
	
	@Override
	public String getLocalId() {
		return localId;
	}

	@Override
	public void setLocalId(String localId) {
		this.localId = localId;
	}

	@Override
	public String getSoftwarePackage() {
		return softwarePackage;
	}

	@Override
	public void setSoftwarePackage(String softwarePackage) {
		this.softwarePackage = softwarePackage;
	}

	@Override
	public String getSoftwareLanguage() {
		return softwareLanguage;
	}

	@Override
	public void setSoftwareLanguage(String softwareLanguage) {
		this.softwareLanguage = softwareLanguage;
	}

	@Override
	public String getSoftwareVersion() {
		return softwareVersion;
	}

	@Override
	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	@Override
	public List<TextTypeWrapperMutableBean> getDescriptions() {
		return descriptions;
	}
	
	@Override
	public void addDescriptions(TextTypeWrapperMutableBean description) {
		if(this.descriptions == null) {
			this.descriptions = new ArrayList<>();
		}
		this.descriptions.add(description);
	}

	@Override
	public void setDescriptions(List<TextTypeWrapperMutableBean> descriptions) {
		this.descriptions = descriptions;
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(descriptions, composites);
        return composites;
    }
}