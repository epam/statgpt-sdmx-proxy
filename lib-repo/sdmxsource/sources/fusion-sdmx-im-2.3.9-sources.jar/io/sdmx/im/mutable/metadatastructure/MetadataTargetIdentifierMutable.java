package io.sdmx.im.mutable.metadatastructure;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataTargetIdentifiableMutable;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public abstract class MetadataTargetIdentifierMutable extends MaintainableMutableBeanImpl implements IMetadataTargetIdentifiableMutable {
	private static final long serialVersionUID = 1L;
	private List<StructureReferenceBean> targets;
	
	
	protected MetadataTargetIdentifierMutable(SDMX_STRUCTURE_TYPE st) {
		super(st);
	}
	
	protected MetadataTargetIdentifierMutable(IMetadataTargetIdentifier bean) {
		super(bean);
		for(ICrossReferenceBeanBase sRef : bean.getTargets()) {
			this.addTarget(sRef.asMutable());
		}
	}

	@Override
	public List<StructureReferenceBean> getTargets() {
		return this.targets;
	}

	@Override
	public void setTargets(List<StructureReferenceBean> targets) {
		this.targets = targets;
	}

	@Override
	public void addTarget(StructureReferenceBean sRef) {
		if(this.targets == null) {
			this.targets = new ArrayList<>();
		}
		this.targets.add(sRef);
	}
}
