package io.sdmx.im.mutable.mapping.v3;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

/**
 * Maps one or more source components to one or more target components between two DSDs referenced by the {@link StructureMapMutableBean}
 */
public class ComponentMapMutableBean extends AnnotableMutableBeanImpl implements IComponentMapMutableBean {
	private static final long serialVersionUID = 1L;
	private List<String> sourceComponents;
	private List<String> targetComponents;
	private StructureReferenceBean representationMapRef;

	public ComponentMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.COMPONENT_MAP);
	}

	public ComponentMapMutableBean(IComponentMapBean bean, IStructureMapMutableBean parent) {
		super(bean, parent);
		this.sourceComponents = new ArrayList<>(bean.getSourceComponents());
		this.targetComponents = new ArrayList<>(bean.getTargetComponents());
		if(bean.getRepresentationMapRef() != null) {
			representationMapRef = new StructureReferenceBeanImpl(bean.getRepresentationMapRef().getTargetUrn());
		}
	}
	
	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnList = new ArrayList<>(1);
		returnList.add(representationMapRef);
		return returnList;
	}

	@Override
	public void reverseMapping() {
		List<String> sourceComponentsCopy = sourceComponents;
		List<String> targetComponentsCopy = targetComponents;
		targetComponents = sourceComponentsCopy;
		sourceComponents = targetComponentsCopy;
	}

	@Override
	public List<String> getSourceComponents() {
		return sourceComponents;
	}
	
	@Override
	public IComponentMapMutableBean setSourceComponents(List<String> sourceComponents) {
		this.sourceComponents = sourceComponents;
		return this;
	}

	@Override
	public IComponentMapMutableBean addSourceComponent(String compId) {
		if(sourceComponents == null) {
			sourceComponents = new ArrayList<>();
		}
		sourceComponents.add(compId);
		return this;
	}

	@Override
	public List<String> getTargetComponents() {
		return targetComponents;
	}
	
	@Override
	public IComponentMapMutableBean setTargetComponents(List<String> targetComponents) {
		this.targetComponents = targetComponents;
		return this;
	}

	@Override
	public IComponentMapMutableBean addTargetComponent(String compId) {
		if(targetComponents == null) {
			targetComponents = new ArrayList<>();
		}
		targetComponents.add(compId);
		return this;
	}

	@Override
	public StructureReferenceBean getRepresentationMapRef() {
		return representationMapRef;
	}

	@Override
	public IComponentMapMutableBean setRepresentationMapRef(StructureReferenceBean ref) {
		this.representationMapRef = ref;
		return this;
	}
}
