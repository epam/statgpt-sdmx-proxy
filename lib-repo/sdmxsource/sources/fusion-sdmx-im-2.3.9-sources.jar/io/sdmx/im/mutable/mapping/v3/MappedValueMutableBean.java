package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

/**
 * Defines the rule for a mapping from a single source value for example 
 * to map a value GBP, the value should simply be GBP.  However complex rules such as value must
 * start with GBP can be applied using value as GBP and an end index of 2 (0 indexed) which is interpreted as
 * the first three letters should be GBP.  The value may also be a regular expression used to pattern match.
 */
public class MappedValueMutableBean extends MutableBeanImpl implements IMappedValueMutableBean {
	private static final long serialVersionUID = 1L;
	private String value;
	private boolean isRegEx;
	private int startIndex = 0;
	private int endIndex = 0;

	public MappedValueMutableBean() {
		super(SDMX_STRUCTURE_TYPE.MAPPED_VALUE);
	}

	public MappedValueMutableBean(IMappedValueBean createdFrom) {
		super(SDMX_STRUCTURE_TYPE.MAPPED_VALUE);
		this.value = createdFrom.getValue();
		this.isRegEx = createdFrom.isRegEx();
		this.startIndex = createdFrom.getStartIndex();
		this.endIndex = createdFrom.getEndIndex();
	}

	public String getValue() {
		return value;
	}

	public IMappedValueMutableBean setValue(String value) {
		this.value = value;
		return this;
	}

	public boolean isRegEx() {
		return isRegEx;
	}

	public IMappedValueMutableBean setRegEx(boolean isRegEx) {
		this.isRegEx = isRegEx;
		return this;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public IMappedValueMutableBean setStartIndex(int startIndex) {
		this.startIndex = startIndex;
		return this;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public IMappedValueMutableBean setEndIndex(int endIndex) {
		this.endIndex = endIndex;
		return this;
	}
}
