package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;

public class DimensionListMutableBeanImpl extends IdentifiableMutableBeanImpl implements DimensionListMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<DimensionMutableBean> dimensions = new ArrayList<>();
	
	public DimensionListMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DIMENSION_DESCRIPTOR);
	}
	
	public DimensionListMutableBeanImpl(DimensionListBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getDimensions() != null) {
			for(DimensionBean currentDimension : bean.getDimensions()) {
				this.dimensions.add(new DimensionMutableBeanImpl(currentDimension, this));
			}
		}
	}

	@Override
	public List<DimensionMutableBean> getDimensions() {
		return dimensions;
	}

	@Override
	public void setDimensions(List<DimensionMutableBean> dimensions) {
		this.dimensions = dimensions;
	}
	
	@Override
	public void addDimension(DimensionMutableBean dimension) {
		if(this.dimensions == null) {
			this.dimensions = new ArrayList<>();
		}
		this.dimensions.add(dimension);
	}
	
	@Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(dimensions, composites);
        return composites;
    }
}