package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.im.beans.base.AgencySchemeBeanImpl;

public class AgencySchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<AgencyMutableBean> implements AgencySchemeMutableBean {
	
	private static final long serialVersionUID = 1L;

	public AgencySchemeMutableBeanImpl(AgencySchemeBean bean) {
		super(bean);
		for(AgencyBean acy : bean.getItems()) {
			addItem(new AgencyMutableBeanImpl(acy, this));
		}
	}

	public AgencySchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME);
	}

	@Override
	public AgencyMutableBean createItem(String id, String name) {
		AgencyMutableBean acy = new AgencyMutableBeanImpl();
		acy.setId(id);
		acy.addName("en", name);
		addItem(acy);
		return acy;
	}

	@Override
	public AgencySchemeBean getImmutableInstance() {
		return new AgencySchemeBeanImpl(this);
	}
}