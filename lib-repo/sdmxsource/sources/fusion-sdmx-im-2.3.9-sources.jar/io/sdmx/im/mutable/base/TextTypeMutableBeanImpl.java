package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public class TextTypeMutableBeanImpl extends MutableBeanImpl implements TextTypeMutableBean {
	private static final long serialVersionUID = 1L;
	private List<TextTypeWrapperMutableBean> text;
	private Set<String> locales = new HashSet<>();
	
	public TextTypeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.TEXT_TYPE_CONTAINER);
	}

	public TextTypeMutableBeanImpl(TextTypeBean createdFrom, MutableBean parent) {
		super(createdFrom, parent);
		this.text = new ArrayList<>();
		for(TextTypeWrapper ttWrapper : createdFrom.getText()) {
			this.text.add(new TextTypeWrapperMutableBeanImpl(ttWrapper.getLocale(), ttWrapper.getValue()));
		}
	}

	@Override
	public List<TextTypeWrapperMutableBean> getText() {
		return text;
	}

	@Override
	public void setText(List<TextTypeWrapperMutableBean> text) {
		this.text = text;
		locales = new HashSet<>();
		if(text != null) {
			for(TextTypeWrapperMutableBean tt : text) {
				locales.add(tt.getLocale());
			}
		}
	}

	@Override
	public void addText(TextTypeWrapperMutableBean text) {
		if(this.text == null) {
			this.text = new ArrayList<>();
		}
		if(locales.contains(text.getLocale())) {
			for(TextTypeWrapperMutableBean tt : this.text) {
				if(tt.getLocale().contentEquals(text.getLocale())) {
					tt.setValue(text.getValue());
				}
			}
		}
		locales.add(text.getLocale());
		this.text.add(text);
	}
}
