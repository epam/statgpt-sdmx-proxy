package io.sdmx.im.mutable.codelist;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class CodelistInheritanceRuleMutableBean extends MutableBeanImpl implements ICodelistInheritanceRuleMutableBean {
	private static final long serialVersionUID = 1L;
	private List<String> inclusiveInheritenceIds;
	private Set<String> inclusiveInheritenceCascades;
	private List<String> exclusiveInheritenceIds;
	private Set<String> exclusiveInheritenceCascades;
	private StructureReferenceBean codelistRef;
	private String prefix;
	
	public CodelistInheritanceRuleMutableBean() {
		super(SDMX_STRUCTURE_TYPE.CODE_LIST_INHERITANCE);
	}

	public CodelistInheritanceRuleMutableBean(ICodelistInheritanceRuleBean bean, CodelistMutableBean parent) {
		super(bean, parent);
		if(bean.getInclusiveInheritenceIds().size() > 0) {
			this.inclusiveInheritenceIds = new ArrayList<>(bean.getInclusiveInheritenceIds());
		}
		if(bean.getExclusiveInheritenceIds().size() > 0) {
			this.exclusiveInheritenceIds = new ArrayList<>(bean.getExclusiveInheritenceIds());
		}
		if(bean.getInclusiveInheritenceCascades().size() > 0) {
			this.inclusiveInheritenceCascades = new HashSet<>(bean.getInclusiveInheritenceCascades());
		}
		if(bean.getExclusiveInheritenceCascades().size() > 0) {
			this.exclusiveInheritenceCascades = new HashSet<>(bean.getExclusiveInheritenceCascades());
		}
		this.prefix = bean.getPrefix();
		this.codelistRef = new StructureReferenceBeanImpl(bean.getCodelistRef().getTargetUrn());
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> l = new ArrayList<>();
		l.add(codelistRef);
		return l;
	}

	@Override
	public StructureReferenceBean getCodelistRef() {
		return codelistRef;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setCodelistRef(StructureReferenceBean ref) {
		this.codelistRef = ref;
		return this;
	}

	@Override
	public String getPrefix() {
		return prefix;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setPrefix(String prefix) {
		this.prefix = prefix;
		return this;
	}

	@Override
	public List<String> getInclusiveInheritenceIds() {
		return this.inclusiveInheritenceIds;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setInclusiveInheritenceIds(List<String> ids) {
		this.inclusiveInheritenceIds = ids;
		return this;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean addInclusiveInheritenceId(String id) {
		if(this.inclusiveInheritenceIds == null) {
			this.inclusiveInheritenceIds = new ArrayList<>();
		}
		this.inclusiveInheritenceIds.add(id);
		return this;
	}

	@Override
	public Set<String> getInclusiveInheritenceCascades() {
		return this.inclusiveInheritenceCascades;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean addInclusiveInheritenceCascades(String codeId) {
		if(this.inclusiveInheritenceCascades == null) {
			this.inclusiveInheritenceCascades = new HashSet<>();
		}
		this.inclusiveInheritenceCascades.add(codeId);
		return this;
	}

	@Override
	public List<String> getExclusiveInheritenceIds() {
		return exclusiveInheritenceIds;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setExclusiveInheritenceIds(List<String> ids) {
		this.exclusiveInheritenceIds = ids;
		return this;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean addExclusiveInheritenceId(String id) {
		if(this.exclusiveInheritenceIds == null) {
			this.exclusiveInheritenceIds = new ArrayList<>();
		}
		this.exclusiveInheritenceIds.add(id);
		return this;
	}

	@Override
	public Set<String> getExclusiveInheritenceCascades() {
		return exclusiveInheritenceCascades;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean addExclusiveInheritenceCascades(String codeId) {
		if(this.exclusiveInheritenceCascades == null) {
			this.exclusiveInheritenceCascades = new HashSet<>();
		}
		this.exclusiveInheritenceCascades.add(codeId);
		return this;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setInclusiveInheritenceCascades(Set<String> codes) {
		this.inclusiveInheritenceCascades = codes;
		return this;
	}

	@Override
	public ICodelistInheritanceRuleMutableBean setExclusiveInheritenceCascades(Set<String> codes) {
		this.exclusiveInheritenceCascades = codes;
		return this;
	}


}
