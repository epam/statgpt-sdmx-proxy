package io.sdmx.im.mutable.pdq;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryComponentFilterMutableBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class PreDefinedQueryComponentFilterMutableBean extends MutableBeanImpl implements IPreDefinedQueryComponentFilterMutableBean {
	private static final long serialVersionUID = 1L;
	private String componentId;
	private Map<MATCH_FUNCTION, Set<String>> filters = new HashMap<>();
	
	public PreDefinedQueryComponentFilterMutableBean() {
		super(SDMX_STRUCTURE_TYPE.PREDEFINED_QUERY_FILTER);
	}

	public PreDefinedQueryComponentFilterMutableBean(IPreDefinedQueryComponentFilterBean createdFrom, IPreDefinedQueryMutableBean parent) {
		super(createdFrom, parent);
		this.componentId = createdFrom.getComponentId();
		for(MATCH_FUNCTION filter : createdFrom.getFilters().keySet()) {
			this.filters.put(filter, new HashSet<>(createdFrom.getFilters().get(filter)));
		}
	}

	@Override
	public String getComponentId() {
		return this.componentId;
	}

	@Override
	public void setComponentId(String id) {
		this.componentId = id;
	}

	@Override
	public void addFilter(MATCH_FUNCTION function, Collection<String> values) {
		if(this.filters == null) {
			this.filters = new HashMap<>();
		}
		this.filters.put(function, new HashSet<>(values));
	}

	@Override
	public Map<MATCH_FUNCTION, Set<String>> getFilters() {
		return filters;
	}
}
