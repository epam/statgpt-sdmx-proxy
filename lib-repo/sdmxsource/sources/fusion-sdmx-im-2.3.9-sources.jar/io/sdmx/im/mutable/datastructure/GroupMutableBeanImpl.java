package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;

public class GroupMutableBeanImpl extends IdentifiableMutableBeanImpl implements GroupMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<String> dimensionRef;
	private StructureReferenceBean attachmentConstraintRef;
	
	public GroupMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.GROUP);
	}

	public GroupMutableBeanImpl(GroupBean bean, MutableBean parent) {
		super(bean, parent);
		this.dimensionRef = bean.getDimensionRefs(); 
	}

	@Override
	public void setDimensionRef(List<String> dimensionRef) {
		this.dimensionRef = dimensionRef;
	}

	@Override
	public StructureReferenceBean getAttachmentConstraintRef() {
		return attachmentConstraintRef;
	}

	@Override
	public void setAttachmentConstraintRef(StructureReferenceBean attachmentConstraintRef) {
		this.attachmentConstraintRef = attachmentConstraintRef;
	}
	
	@Override
	public void addDimensionRef(String dimId) {
		if(this.dimensionRef == null) {
			this.dimensionRef = new ArrayList<>();
		}
		this.dimensionRef.add(dimId);
	}

	@Override
	public List<String> getDimensionRef() {
		return dimensionRef;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if(attachmentConstraintRef != null) {
	    	returnSet.add(attachmentConstraintRef);
	    }
	    return returnSet;
	}
}