package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;

public abstract class OrganisationMutableBeanImpl extends ItemMutableBeanImpl implements OrganisationMutableBean {
	private static final long serialVersionUID = 4846360904109815354L;
	private List<ContactMutableBean> contacts = new ArrayList<>();
	
	public OrganisationMutableBeanImpl(OrganisationBean bean, MutableBean parent) {
		super(bean, parent);
		for(ContactBean contact : bean.getContacts()) {
			addContact(new ContactMutableBeanImpl(contact, this));
		}
	}

	public OrganisationMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	@Override
	public List<ContactMutableBean> getContacts() {
		return contacts;
	}

	@Override
	public void setContacts(List<ContactMutableBean> contacts) {
		this.contacts = contacts;
	}

	@Override
	public void addContact(ContactMutableBean contact) {
		if(contacts == null) {
			contacts = new ArrayList<>();
		}
		contacts.add(contact);
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(contacts, composites);
		return composites;
	}
}
