package io.sdmx.im.mutable.mapping;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.SchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;
import io.sdmx.im.mutable.base.NameableMutableBeanImpl;

public abstract class SchemeMapMutableBeanImpl extends NameableMutableBeanImpl implements SchemeMapMutableBean {

	private static final long serialVersionUID = 1L;

	private StructureReferenceBean sourceRef;
	private StructureReferenceBean targetRef;

	public SchemeMapMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public SchemeMapMutableBeanImpl(SchemeMapBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getSourceRef() != null) {
			this.sourceRef = bean.getSourceRef();
		}
		if(bean.getTargetRef() != null) {
			this.targetRef =  bean.getTargetRef();
		}
	}

	@Override
	public void setSourceRef(StructureReferenceBean sourceRef) {
		this.sourceRef = sourceRef;
	}

	@Override
	public void setTargetRef(StructureReferenceBean targetRef) {
		this.targetRef = targetRef;
	}

	@Override
	public StructureReferenceBean getSourceRef() {
		return sourceRef;
	}

	@Override
	public StructureReferenceBean getTargetRef() {
		return targetRef;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (sourceRef != null) {
	        returnSet.add(sourceRef);
	    }
	    if (targetRef != null) {
	        returnSet.add(targetRef);
	    }
	    return returnSet;
	}
}