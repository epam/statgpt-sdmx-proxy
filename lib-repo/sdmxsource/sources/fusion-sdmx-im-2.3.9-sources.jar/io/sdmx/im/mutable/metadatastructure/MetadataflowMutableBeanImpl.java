
package io.sdmx.im.mutable.metadatastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.im.beans.metadatastructure.MetadataflowBeanImpl;

public class MetadataflowMutableBeanImpl extends MetadataTargetIdentifierMutable implements MetadataFlowMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean metadataStructureRef;
	
	public MetadataflowMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
	}

	public MetadataflowMutableBeanImpl(MetadataFlowBean bean) {
		super(bean);
		if(bean.getMetadataStructureRef() != null) {
			this.metadataStructureRef = bean.getMetadataStructureRef().asMutable();
		}
	}
	
	@Override
	public MetadataFlowBean getImmutableInstance() {
		return new MetadataflowBeanImpl(this);
	}

	@Override
	public void setMetadataStructureRef(StructureReferenceBean metadataStructureRef) {
		this.metadataStructureRef = metadataStructureRef;
	}

	@Override
	public StructureReferenceBean getMetadataStructureRef() {
		return metadataStructureRef;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (metadataStructureRef != null) {
	        returnSet.add(metadataStructureRef);
	    }
	    return returnSet;
	}
}