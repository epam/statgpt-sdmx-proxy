package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlCodelistMappingBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlCodelistMappingMutableBean;

public class VtlCodelistMappingMutableBean extends VtlMappingMutableBean implements IVtlCodelistMappingMutableBean {
	private static final long serialVersionUID = 1L;
	
	public VtlCodelistMappingMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_CODELIST_MAPPING);
	}

	public VtlCodelistMappingMutableBean(IVtlCodelistMappingBean bean, MutableBean parent) {
		super(bean, parent);
	}
}
