package io.sdmx.im.mutable.categoryscheme;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.im.beans.categoryscheme.CategorySchemeBeanImpl;
import io.sdmx.im.mutable.base.ItemSchemeMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class CategorySchemeMutableBeanImpl extends ItemSchemeMutableBeanImpl<CategoryMutableBean> implements CategorySchemeMutableBean {

	private static final long serialVersionUID = 1L;

	private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

	public CategorySchemeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME);
	}

	public CategorySchemeMutableBeanImpl(CategorySchemeBean bean) {
		super(bean);
		this.validityType = bean.getValidityType();
		// convert Category list to Mutable Category beans
		for(CategoryBean category : bean.getItems()) {
			this.addItem(new CategoryMutableBeanImpl(category, this));
		}
	}

	@Override
	public CategorySchemeBean getImmutableInstance() {
		return new CategorySchemeBeanImpl(this);
	}

	@Override
	public CategoryMutableBean createItem(String id, String name) {
		CategoryMutableBean cat = new CategoryMutableBeanImpl();
		cat.setId(id);
		cat.addName("en", name);
		addItem(cat);
		return cat;
	}

	@Override
	protected MaintainableMutableBean createPartial(Set<String> itemSet, boolean keep, boolean isUrn, ITEM_FILTER_ACTION setParentsToNull) {
		if(itemSet == null) {
			itemSet = new HashSet<>();
		}
		createPartialCategories(items, itemSet, keep, isUrn, setParentsToNull);
		return this;
	}

	/**
	 * Creates a partial list of categories based on the URNs to keep, also keeps a category if it has child categories which should be kept
	 *
	 * @param categories
	 * @param itemSet
	 * @param keep
	 * @param isUrn
	 * @param setParentsToNull
	 */
	private void createPartialCategories(List<CategoryMutableBean> categories, Set<String> itemSet, boolean keep, boolean isUrn, ITEM_FILTER_ACTION setParentsToNull) {
		int sizeStart = categories.size();
		Map<String, CategoryMutableBean> map = new HashMap<>();
		Set<String> categoriesWithChildren = new HashSet<>();
		for(CategoryMutableBean currentItem : categories) {
			if(currentItem.getItems() != null) {
				createPartialCategories(currentItem.getItems(), itemSet, keep, isUrn, setParentsToNull);
				if(ObjectUtil.validCollection(currentItem.getItems())) {
					categoriesWithChildren.add(isUrn ? currentItem.getUrn() : currentItem.getId());
				}
			}
			map.put(isUrn ? currentItem.getUrn() : currentItem.getId(), currentItem);
		}
		if(keep) {
			itemSet.addAll(categoriesWithChildren);
			map.keySet().retainAll(itemSet);
		} else {
			itemSet.removeAll(categoriesWithChildren);
			map.keySet().removeAll(itemSet);
		}
		categories.retainAll(itemSet);
		if(this.isPartial == false) {
			this.isPartial = categories.size() < sizeStart;
		}
	}

	@Override
	public boolean removeItem(String id) {
		if(id.contains(".")) {
			String[] idArray = id.split("\\.");
			for(CategoryMutableBean cat : getItems()) {
				if(cat.getId().equals(idArray[0])) {
					return removeItem(cat, idArray, 1);
				}
			}
			return false;
		}
		return super.removeItem(id);

	}

	private boolean removeItem(CategoryMutableBean parent, String[] idArray, int pos) {
		String searchId = idArray[pos];
		CategoryMutableBean removeCat = null;
		for(CategoryMutableBean cat : parent.getItems()) {
			if(cat.getId().equals(searchId)) {
				if(idArray.length > ++pos) {
					return removeItem(cat, idArray, pos);
				} else {
					removeCat = cat;
					break;
				}
			}
		}
		if(removeCat != null) {
			parent.getItems().remove(removeCat);
		}
		return removeCat != null;
	}

	@Override
	public MAINT_VALIDITY_TYPE getValidityType() {
		return this.validityType;
	}

	@Override
	public void setValidityType(MAINT_VALIDITY_TYPE validityType) {
		this.validityType = validityType;
	}
}