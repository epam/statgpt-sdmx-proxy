package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public abstract class NameableMutableBeanImpl extends IdentifiableMutableBeanImpl implements NameableMutableBean {
	private static final long serialVersionUID = 1L;
	private List<TextTypeWrapperMutableBean> names;
	private List<TextTypeWrapperMutableBean> descriptions;

	public NameableMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public NameableMutableBeanImpl(NameableBean bean, MutableBean parent) {
		super(bean, parent);
		copyNameableProperties(bean, false);
	}
	
	@Override
	public void copyNameableProperties(NameableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyIdentifiableProperties(bean, includeInheritedProperties);
		}
		if(bean.getName() != null) {
			names = new ArrayList<>();
			for (TextTypeWrapper currentTextType : bean.getNames(true)) {
				names.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
		if(bean.getDescription() != null) {
			descriptions = new ArrayList<>();
			for (TextTypeWrapper currentTextType : bean.getDescriptions(true)) {
				descriptions.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}

	@Override
	public void copyNameableProperties(NameableMutableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyIdentifiableProperties(bean, includeInheritedProperties);
		}
		if(bean.getNames() != null) {
			names = new ArrayList<>();
			for (TextTypeWrapperMutableBean currentTextType : bean.getNames()) {
				names.add(new TextTypeWrapperMutableBeanImpl(currentTextType.getLocale(), currentTextType.getValue()));
			}
		}
		if(bean.getDescriptions() != null) {
			descriptions = new ArrayList<>();
			for (TextTypeWrapperMutableBean currentTextType : bean.getDescriptions()) {
				descriptions.add(new TextTypeWrapperMutableBeanImpl(currentTextType.getLocale(), currentTextType.getValue()));
			}
		}
	}
	
	@Override
	public void addDescription(String locale, String name) {
		TextTypeWrapperMutableBean tt = new TextTypeWrapperMutableBeanImpl();
		tt.setLocale(locale);
		tt.setValue(name);
		addDescription(tt);
	}


	@Override
	public void addName(TextTypeWrapperMutableBean text) {
		if(text == null) {
			return;
		}
		if(this.names == null) {
			this.names = new ArrayList<>();
		}
		for(TextTypeWrapperMutableBean currentTT : this.names) {
			if(currentTT.getLocale().equals(text.getLocale())) {
				currentTT.setValue(text.getValue());
				return;
			}
		}
		this.names.add(text);
	}

	@Override
	public void addDescription(TextTypeWrapperMutableBean text) {
		if(text == null) {
			return;
		}
		if(this.descriptions == null) {
			this.descriptions = new ArrayList<>();
		}
		for(TextTypeWrapperMutableBean currentTT : this.descriptions) {
			if(currentTT.getLocale().equals(text.getLocale())) {
				currentTT.setValue(text.getValue());
				return;
			}
		}
		this.descriptions.add(text);
	}

	@Override
	public void addName(String locale, String name) {
		TextTypeWrapperMutableBean tt = new TextTypeWrapperMutableBeanImpl();
		tt.setLocale(locale);
		tt.setValue(name);
		addName(tt);
	}


	@Override
	public TextTypeWrapperMutableBean getName(String locale) {
		return getTextTypeByLocale(locale, names);
	}

	@Override
	public TextTypeWrapperMutableBean getDescription(String locale) {
		return getTextTypeByLocale(locale, descriptions);
	}

	private TextTypeWrapperMutableBean getTextTypeByLocale(String locale, List<TextTypeWrapperMutableBean> tts) {
	    String localeStr = (locale == null ? null: locale.trim());
		if(tts != null) {
			for(TextTypeWrapperMutableBean tt : tts) {
				if(tt.getLocale().equals(localeStr)) {
					return tt;
				}
			}
		}
		return null;
	}

	@Override
	public String getName(boolean defaultIfNull) {
		for(TextTypeWrapperMutableBean mutable : getNames()) {
			return mutable.getValue();
		}
		return null;
	}

	@Override
	public List<TextTypeWrapperMutableBean> getNames() {
		if (names == null) {
			return null;
		}
		if(!TextTypeUtil.hasLocaleFilter()) {
			return names;
		}
		List<TextTypeWrapperMutableBean> copy = new ArrayList<>(names);
		return TextTypeUtil.optionalFilterOnMutableTextType(copy);
	}

	@Override
	public void setNames(List<TextTypeWrapperMutableBean> names) {
		this.names = names;
	}

	@Override
	public List<TextTypeWrapperMutableBean> getDescriptions() {
		if (descriptions == null) {
			return null;
		}
		if(!TextTypeUtil.hasLocaleFilter()) {
			return descriptions;
		}
		List<TextTypeWrapperMutableBean> copy = new ArrayList<>(descriptions);
		return TextTypeUtil.optionalFilterOnMutableTextType(copy);
	}

	@Override
	public void setDescriptions(List<TextTypeWrapperMutableBean> description) {
		this.descriptions = description;
	}

	@Override
	public void removeDescription(String locale) {
		if(descriptions == null){
			return;
		}
		this.descriptions = descriptions.stream().filter(getLocaleFromStream(locale)).collect(Collectors.toList());

	}

	@Override
	public void removeName(String locale) {
		if(names == null){
			return;
		}
		this.names = names.stream().filter(getLocaleFromStream(locale)).collect(Collectors.toList());
	}

	private Predicate<? super TextTypeWrapperMutableBean> getLocaleFromStream(String locale) {
	    String localeStr =  (locale != null ? locale.trim() : null);
		return streamValue -> !streamValue.getLocale().equals(localeStr);
	}

	@Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(getNames(), composites);
		super.addToCompositeSet(getDescriptions(), composites);
	    return composites;
	}
}
