package io.sdmx.im.mutable.mapping.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

/**
 * Defines a relationship between one or more source values (in combination) which are the equivalent to one or more
 * target values (in combination)
 */
public class MappedRelationshipMutableBean extends AnnotableMutableBeanImpl implements IMappedRelationshipMutableBean {
	private static final long serialVersionUID = 1L;
	private String validFrom;
	private String validTo;
	private List<IMappedValueMutableBean> sourceValue = new ArrayList<>();
	private List<String> targetValue;
	
	public MappedRelationshipMutableBean() {
		super(SDMX_STRUCTURE_TYPE.RELATIONSHIP_MAP);
	}

	public MappedRelationshipMutableBean(IMappedRelationshipBean bean, IRepresentationMapMutableBean parent) {
		super(bean, parent);
		if(bean.getValidityPeriod() != null) {
			if(bean.getValidityPeriod().getStartPeriod() != null) {
				this.validFrom = bean.getValidityPeriod().getStartPeriod().getDateInSdmxFormat();
			}
			if(bean.getValidityPeriod().getEndPeriod() != null) {
				this.validTo = bean.getValidityPeriod().getEndPeriod().getDateInSdmxFormat();
			}
		}
		for(IMappedValueBean mappedValue : bean.getSourceValue()) {
			this.sourceValue.add(new MappedValueMutableBean(mappedValue));
		}
		this.targetValue= new ArrayList<>(bean.getTargetValue());
	}
	
	@Override
	public void reverseMapping(Set<String> validSources) {
		List<IMappedValueMutableBean> sourceValueCopy = sourceValue;
		
		this.sourceValue = new ArrayList<>();
		for(String targetValue : targetValue) {
			this.sourceValue.add(new MappedValueMutableBean().setValue(targetValue));
		}
		
		this.targetValue = new ArrayList<>();
		for(IMappedValueMutableBean sourceValue : sourceValueCopy) {
			String value = sourceValue.getValue();
			if(sourceValue.getStartIndex() > 0 || sourceValue.getEndIndex() > 0) {
				//TODO 
			}
			this.targetValue.add(value);
		}
	}

	@Override
	public String getValidFrom() {
		return validFrom;
	}

	@Override
	public IMappedRelationshipMutableBean setValidFrom(String period) {
		this.validFrom = period;
		return this;
	}

	@Override
	public String getValidTo() {
		return validTo;
	}

	@Override
	public IMappedRelationshipMutableBean setValidTo(String period) {
		this.validTo = period;
		return this;
	}

	public List<IMappedValueMutableBean> getSourceValue() {
		return sourceValue;
	}
	
	public IMappedRelationshipMutableBean setSourceValue(List<IMappedValueMutableBean> sourceValue) {
		this.sourceValue = sourceValue;
		return this;
	}
	
	@Override
	public IMappedValueMutableBean addSourceValue() {
		IMappedValueMutableBean newRelationship = new MappedValueMutableBean();
		if(this.sourceValue == null)  {
			this.sourceValue = new ArrayList<>();
		}
		this.sourceValue.add(newRelationship);
		return newRelationship;
	}
	
	public List<String> getTargetValue() {
		return targetValue;
	}
	
	public IMappedRelationshipMutableBean setTargetValue(List<String> targetValue) {
		this.targetValue = targetValue;
		return this;
	}

	@Override
	public IMappedRelationshipMutableBean addTargetValue(String value) {
		if(this.targetValue == null)  {
			this.targetValue = new ArrayList<>();
		}
		this.targetValue.add(value);
		return this;
	}
}
