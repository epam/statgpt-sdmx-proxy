
package io.sdmx.im.mutable.datastructure;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.mutable.base.ComponentMutableBeanImpl;


public class PrimaryMeasureMutableBeanImpl extends ComponentMutableBeanImpl implements MeasureMutableBean {
	
	private static final long serialVersionUID = 1L;

	public PrimaryMeasureMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
	}
	
	public PrimaryMeasureMutableBeanImpl(PrimaryMeasureBean bean, MutableBean parent) {
		super(bean, parent);
	}

	@Override
	public String getId() {
		return PrimaryMeasureBean.FIXED_ID;
	}
}
