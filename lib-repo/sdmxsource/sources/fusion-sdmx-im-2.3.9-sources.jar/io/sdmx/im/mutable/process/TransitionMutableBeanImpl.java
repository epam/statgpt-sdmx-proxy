package io.sdmx.im.mutable.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;

public class TransitionMutableBeanImpl extends IdentifiableMutableBeanImpl implements TransitionMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String targetStep;
	private List<TextTypeWrapperMutableBean> conditions = new ArrayList<>();
	private String localId;
	
	public TransitionMutableBeanImpl () {
		super(SDMX_STRUCTURE_TYPE.TRANSITION);
	}
	
	public TransitionMutableBeanImpl (TransitionBean bean, MutableBean parent) {
		super(bean, parent);
		this.targetStep = bean.getTargetStep().getFullIdPath(false);
		if(bean.getCondition() != null) {
			for(TextTypeWrapper currentTT : bean.getCondition()) {
				this.conditions.add(new TextTypeWrapperMutableBeanImpl(currentTT, this));
			}
		}
		this.localId = bean.getLocalId();
	}

	@Override
	public String getLocalId() {
		return localId;
	}

	@Override
	public void setLocalId(String localId) {
		this.localId = localId;
	}

	@Override
	public String getTargetStep() {
		return targetStep;
	}
	
	@Override
	public void setTargetStep(String targetStep) {
		this.targetStep = targetStep;
	}
	
	@Override
	public List<TextTypeWrapperMutableBean> getConditions() {
		return conditions;
	}

	@Override
	public void setConditions(List<TextTypeWrapperMutableBean> conditions) {
		this.conditions = conditions;
	}

	@Override
	public void addCondition(TextTypeWrapperMutableBean condition) {
		if(this.conditions == null) {
			this.conditions = new ArrayList<>();
		}
		this.conditions.add(condition);
	}

    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(conditions, composites);
        return composites;
    }
}