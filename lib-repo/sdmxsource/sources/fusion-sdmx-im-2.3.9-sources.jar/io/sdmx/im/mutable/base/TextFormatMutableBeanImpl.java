package io.sdmx.im.mutable.base;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;

public class TextFormatMutableBeanImpl extends MutableBeanImpl implements TextFormatMutableBean {
	private static final long serialVersionUID = 1L;
	
	private TEXT_TYPE textType;
	private TERTIARY_BOOL isSequence=TERTIARY_BOOL.UNSET; 
	private TERTIARY_BOOL isMultiLingual=TERTIARY_BOOL.UNSET;
	private BigDecimal minValue;
	private BigDecimal maxValue;
	private BigInteger minLength;
	private BigInteger maxLength;
	private BigDecimal startValue;
	private BigDecimal endValue;
	private BigDecimal interval;
	private String timeInterval;
	
	private Date startTime;
	private Date endTime;
	
	
	private BigInteger decimals;
	private String pattern;
	
	public TextFormatMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.TEXT_FORMAT);
	}
	
	public TextFormatMutableBeanImpl(TextFormatBean txtBean, MutableBean parent) {
		super(txtBean, parent);
		this.textType = txtBean.getTextType();
		this.isSequence = txtBean.getSequence(); 
		this.maxLength = txtBean.getMaxLength(); 
		this.minLength = txtBean.getMinLength(); 
		this.startValue = txtBean.getStartValue(); 
		this.endValue = txtBean.getEndValue();
		this.interval = txtBean.getInterval(); 
		this.maxValue = txtBean.getMaxValue();
		this.minValue = txtBean.getMinValue();
		this.isMultiLingual = txtBean.getMultiLingual();
		if(txtBean.getTimeInterval() != null) {
			this.timeInterval = txtBean.getTimeInterval().toString();
		}
		this.decimals = txtBean.getDecimals(); 
		this.pattern = txtBean.getPattern();
		if(txtBean.getStartTime() != null) {
			this.startTime = txtBean.getStartTime().getDate();
		}
		if(txtBean.getEndTime() != null) {
			this.endTime = txtBean.getEndTime().getDate();
		}
	}
	
	@Override
    public Date getStartTime() {
		return startTime;
	}

	@Override
    public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@Override
    public Date getEndTime() {
		return endTime;
	}

	@Override
    public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Override
	public BigDecimal getMinValue() {
		return minValue;
	}
	@Override
	public void setMinValue(BigDecimal minValue) {
		this.minValue = minValue;
	}

	@Override
	public BigDecimal getMaxValue() {
		return maxValue;
	}

	@Override
	public void setMaxValue(BigDecimal maxValue) {
		this.maxValue = maxValue;
	}

	@Override
	public TERTIARY_BOOL getMultiLingual() {
		return isMultiLingual;
	}

	@Override
	public void setMultiLingual(TERTIARY_BOOL isMultiLingual) {
		this.isMultiLingual = isMultiLingual;
	}

	@Override
	public TEXT_TYPE getTextType() {
		return textType;
	}

	@Override
	public BigInteger getMinLength() {
		return minLength;
	}

	@Override
	public BigInteger getMaxLength() {
		return maxLength;
	}

	@Override
	public BigDecimal getStartValue() {
		return startValue;
	}

	@Override
	public BigDecimal getEndValue() {
		return endValue;
	}

	@Override
	public BigDecimal getInterval() {
		return interval;
	}

	@Override
	public String getTimeInterval() {
		return timeInterval;
	}

	@Override
	public BigInteger getDecimals() {
		return decimals;
	}

	@Override
	public String getPattern() {
		return pattern;
	}

	@Override
	public void setTextType(TEXT_TYPE textType) {
		this.textType = textType;
	}

	@Override
	public TERTIARY_BOOL getSequence() {
		return isSequence;
	}

	@Override
	public void setSequence(TERTIARY_BOOL isSequence) {
		this.isSequence = isSequence;
	}

	@Override
	public void setMinLength(BigInteger minLength) {
		this.minLength = minLength;
	}

	@Override
	public void setMaxLength(BigInteger maxLength) {
		this.maxLength = maxLength;
	}

	@Override
	public void setStartValue(BigDecimal startValue) {
		this.startValue = startValue;
	}

	@Override
	public void setEndValue(BigDecimal endValue) {
		this.endValue = endValue;
	}

	@Override
	public void setInterval(BigDecimal interval) {
		this.interval = interval;
	}

	@Override
	public void setTimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}

	@Override
	public void setDecimals(BigInteger decimals) {
		this.decimals = decimals;
	}

	@Override
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
}