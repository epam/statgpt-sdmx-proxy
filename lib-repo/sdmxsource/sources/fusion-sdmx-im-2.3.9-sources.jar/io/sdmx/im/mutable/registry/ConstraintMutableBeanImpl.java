
package io.sdmx.im.mutable.registry;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public abstract class ConstraintMutableBeanImpl extends MaintainableMutableBeanImpl implements ConstraintMutableBean  {
	private static final long serialVersionUID = 1L;
	private ConstraintAttachmentMutableBean contentConstraintAttachmentBean = null;
	private ConstraintDataKeySetMutableBean includedSeriesKeys;
	private ConstraintDataKeySetMutableBean excludedSeriesKeys;
	private ConstraintDataKeySetMutableBean includedMetadataKeys;
	private ConstraintDataKeySetMutableBean excludedMetadataKeys;
	
	public ConstraintMutableBeanImpl(ConstraintBean bean) {
		super(bean);
		if (bean.getConstraintAttachment() != null) {
			this.contentConstraintAttachmentBean = bean.getConstraintAttachment().createMutableInstance();
		}
		if(bean.getIncludedSeriesKeys() != null) {
			includedSeriesKeys = new ConstraintDataKeySetMutableBeanImpl(bean.getIncludedSeriesKeys());
		}
		if(bean.getExcludedSeriesKeys() != null) {
			excludedSeriesKeys = new ConstraintDataKeySetMutableBeanImpl(bean.getExcludedSeriesKeys());
		}
	}

	public ConstraintMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}
	
	@Override
	public ConstraintAttachmentMutableBean getConstraintAttachment() {
		return this.contentConstraintAttachmentBean;
	}

	@Override
	public void setConstraintAttachment(ConstraintAttachmentMutableBean bean) {
		this.contentConstraintAttachmentBean = bean;
	}

	@Override
	public ConstraintDataKeySetMutableBean getIncludedSeriesKeys() {
		return includedSeriesKeys;
	}

	@Override
	public void setIncludedSeriesKeys(ConstraintDataKeySetMutableBean includedSeriesKeys) {
		this.includedSeriesKeys = includedSeriesKeys;
	}

	@Override
	public ConstraintDataKeySetMutableBean getExcludedSeriesKeys() {
		return excludedSeriesKeys;
	}

	@Override
	public void setExcludedSeriesKeys(ConstraintDataKeySetMutableBean excludedSeriesKeys) {
		this.excludedSeriesKeys = excludedSeriesKeys;
	}

	@Override
	public ConstraintDataKeySetMutableBean getIncludedMetadataKeys() {
		return includedMetadataKeys;
	}

	@Override
	public void setIncludedMetadataKeys(ConstraintDataKeySetMutableBean includedMetadataKeys) {
		this.includedMetadataKeys = includedMetadataKeys;
	}

	@Override
	public ConstraintDataKeySetMutableBean getExcludedMetadataKeys() {
		return excludedMetadataKeys;
	}

	@Override
	public void setExcludedMetadataKeys(ConstraintDataKeySetMutableBean excludedMetadataKeys) {
		this.excludedMetadataKeys = excludedMetadataKeys;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(includedSeriesKeys, composites);
		super.addToCompositeSet(excludedSeriesKeys, composites);
		super.addToCompositeSet(includedMetadataKeys, composites);
		super.addToCompositeSet(excludedMetadataKeys, composites);
		super.addToCompositeSet(contentConstraintAttachmentBean, composites);
		return composites;
	}
}