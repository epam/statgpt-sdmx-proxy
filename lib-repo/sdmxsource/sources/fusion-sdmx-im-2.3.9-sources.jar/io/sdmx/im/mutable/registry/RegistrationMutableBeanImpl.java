
package io.sdmx.im.mutable.registry;

import java.util.Date;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.im.beans.registry.RegistrationBeanImpl;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class RegistrationMutableBeanImpl extends MaintainableMutableBeanImpl implements RegistrationMutableBean {
	private static final long serialVersionUID = 1L;
	private DataSourceMutableBean dataSource;
	private Date lastUpdated;
	private Date validFrom;
	private Date validTo;
	private StructureReferenceBean provisionAgreementRef;
	private TERTIARY_BOOL indexTimeSeries = TERTIARY_BOOL.UNSET;
	private TERTIARY_BOOL indexDataset = TERTIARY_BOOL.UNSET;
	private TERTIARY_BOOL indexAttributes = TERTIARY_BOOL.UNSET;
	private TERTIARY_BOOL indexReportingPeriod = TERTIARY_BOOL.UNSET;
	
	public RegistrationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REGISTRATION);
	}

	public RegistrationMutableBeanImpl(String url, ProvisionAgreementBean prov, boolean isfile)  {
		super(SDMX_STRUCTURE_TYPE.REGISTRATION);
		this.addName("en", prov.getDataproviderRef().getReference().getIdentifiableId() + " data for " + prov.getStructureUseage().getReference().getMaintainableId());
		this.setProvisionAgreementRef(prov.asReference());
		DataSourceMutableBean dataSource = new DataSourceMutableBeanImpl();
		dataSource.setDataUrl(url);
		if(isfile) {
			dataSource.setSimpleDatasource(true);
		} else {
			dataSource.setRESTDatasource(true);
		}
		this.setDataSource(dataSource);
	}

	public RegistrationMutableBeanImpl(RegistrationBean registration) {
		super(registration);
		if(registration.getDataSource() != null) {
			this.dataSource = new DataSourceMutableBeanImpl(registration.getDataSource(), this);
		}
		if(registration.getLastUpdated() != null) {
			this.lastUpdated = registration.getLastUpdated().getDate();
		}
		if(registration.getValidFrom() != null) {
			this.validFrom = registration.getValidFrom().getDate();
		}
		if(registration.getValidTo() != null) {
			this.validTo = registration.getValidTo().getDate();
		}
		if(registration.getProvisionAgreementRef() != null) {
			this.provisionAgreementRef = registration.getProvisionAgreementRef().asMutable();
		}
		this.indexTimeSeries = registration.getIndexTimeSeries();
		this.indexDataset = registration.getIndexDataset();
		this.indexAttributes = registration.getIndexAttributes();
		this.indexReportingPeriod = registration.getIndexReportingPeriod();
	}
	
	@Override
	public TERTIARY_BOOL getIndexTimeSeries() {
		return indexTimeSeries;
	}

	@Override
	public void setIndexTimeSeries(TERTIARY_BOOL indexTimeSeries) {
		this.indexTimeSeries = indexTimeSeries;
	}

	@Override
	public TERTIARY_BOOL getIndexDataset() {
		return indexDataset;
	}

	@Override
	public void setIndexDataset(TERTIARY_BOOL indexDataset) {
		this.indexDataset = indexDataset;
	}

	@Override
	public TERTIARY_BOOL getIndexAttributes() {
		return indexAttributes;
	}

	@Override
	public void setIndexAttributes(TERTIARY_BOOL indexAttributes) {
		this.indexAttributes = indexAttributes;
	}

	@Override
	public TERTIARY_BOOL getIndexReportingPeriod() {
		return indexReportingPeriod;
	}

	@Override
	public void setIndexReportingPeriod(TERTIARY_BOOL indexReportingPeriod) {
		this.indexReportingPeriod = indexReportingPeriod;
	}

	@Override
	public StructureReferenceBean getProvisionAgreementRef() {
		return provisionAgreementRef;
	}

	@Override
	public void setProvisionAgreementRef(
			StructureReferenceBean provisionAgreementRef) {
		this.provisionAgreementRef = provisionAgreementRef;
	}

	@Override
	public RegistrationBean getImmutableInstance() {
		return new RegistrationBeanImpl(this);
	}

	@Override
	public DataSourceMutableBean getDataSource() {
		return this.dataSource;
	}

	@Override
	public Date getLastUpdated() {
		return this.lastUpdated;
	}

	@Override
	public Date getValidFrom() {
		return this.validFrom;
	}

	@Override
	public Date getValidTo() {
		return this.validTo;
	}

	@Override
	public void setDataSource(DataSourceMutableBean dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	@Override
	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (provisionAgreementRef != null) {
	        returnSet.add(provisionAgreementRef);
	    }
	    return returnSet;
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(dataSource, composites);
        return composites;
    }
}