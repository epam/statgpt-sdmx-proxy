package io.sdmx.im.mutable.mapping.v3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.im.beans.mapping.v3.StructureMapBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Describes a mapping relationship between two Dataflows or data structures (DSDs).  Ultimately the mapping rules
 * are defined for the DSD, even if the structure map is in the context of a Dataflow.
 */
public class StructureMapMutableBean extends MaintainableMutableBeanImpl implements IStructureMapMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean sourceRef;
	private StructureReferenceBean targetRef;
	private List<IComponentMapMutableBean> componentMaps = new ArrayList<>();
	private List<ITimePatternMapMutableBean> timePatternMaps = new ArrayList<>();
	private List<IEpochMapMutableBean> epochMap = new ArrayList<>();

	private StructureReferenceBean timeFormatMapping;
	private Map<String, String> fixedOutputs = new HashMap<>();
	private Map<String, String> fixedInputs = new HashMap<>();

	public StructureMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP);
	}

	public StructureMapMutableBean(IStructureMapBean bean) {
		super(bean);
		this.sourceRef = new StructureReferenceBeanImpl(bean.getSourceRef().getTargetUrn());
		this.targetRef = new StructureReferenceBeanImpl(bean.getTargetRef().getTargetUrn());
		if(bean.getTimeFormatMapping() != null) {
			this.timeFormatMapping = bean.getTimeFormatMapping().getReference().asMutable();
		}
		for(IComponentMapBean compMap : bean.getComponentMaps()) {
			componentMaps.add(new ComponentMapMutableBean(compMap, this));
		}
		this.fixedOutputs = new HashMap<>(bean.getFixedOutputs());
		this.fixedInputs = new HashMap<>(bean.getFixedInputs());
	}


	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnList = new ArrayList<>(2 + componentMaps.size());
		returnList.add(sourceRef);
		returnList.add(targetRef);
		for(IComponentMapMutableBean compMap : componentMaps) {
			if(compMap.getRepresentationMapRef() != null) {
				returnList.add(compMap.getRepresentationMapRef());
			}
		}
		return returnList;
	}


	@Override
	public IStructureMapBean getImmutableInstance() {
		return new StructureMapBean(this);
	}

	@Override
	public IStructureMapMutableBean reverseMapping() {
		StructureReferenceBean sourceRefCopy = sourceRef;
		StructureReferenceBean targetRefCopy = targetRef;
		Map<String, String> fixedInputsCopy = this.fixedInputs;
		Map<String, String> fixedOutputsCopy = this.fixedOutputs;
		sourceRef = targetRefCopy;
		targetRef = sourceRefCopy;
		this.fixedInputs = fixedOutputsCopy;
		this.fixedOutputs = fixedInputsCopy;
		for(IComponentMapMutableBean compMap : componentMaps) {
			compMap.reverseMapping();
		}
		return this;
	}

	@Override
	public StructureReferenceBean getSourceRef() {
		return sourceRef;
	}

	@Override
	public IStructureMapMutableBean setSourceRef(StructureReferenceBean sourceRef) {
		this.sourceRef = sourceRef;
		return this;
	}

	@Override
	public StructureReferenceBean getTargetRef() {
		return targetRef;
	}

	@Override
	public IStructureMapMutableBean setTargetRef(StructureReferenceBean targetRef) {
		this.targetRef = targetRef;
		return this;
	}

	@Override
	public List<IComponentMapMutableBean> getComponentMaps() {
		return componentMaps;
	}

	@Override
	public IStructureMapMutableBean setComponentMaps(List<IComponentMapMutableBean> componentMaps) {
		this.componentMaps = componentMaps;
		return this;
	}

	@Override
	public IComponentMapMutableBean addComponentMap() {
		if(componentMaps == null) {
			componentMaps = new ArrayList<>();
		}
		IComponentMapMutableBean newBean = new ComponentMapMutableBean();
		componentMaps.add(newBean);
		return newBean;
	}


	@Override
	public List<ITimePatternMapMutableBean> getTimePatternMaps() {
		return timePatternMaps;
	}

	@Override
	public ITimePatternMapMutableBean addTimePatternMap() {
		if(timePatternMaps == null) {
			timePatternMaps = new ArrayList<>();
		}
		ITimePatternMapMutableBean newBean = new TimePatternMapMutableBean();
		timePatternMaps.add(newBean);
		return newBean;
	}

	@Override
	public List<IEpochMapMutableBean> getEpochMap() {
		return epochMap;
	}

	@Override
	public IEpochMapMutableBean addEpochMap() {
		if(epochMap == null) {
			epochMap = new ArrayList<>();
		}
		IEpochMapMutableBean newBean = new EpochMapMutableBean();
		epochMap.add(newBean);
		return newBean;
	}

	@Override
	public StructureReferenceBean getTimeFormatMapping() {
		return timeFormatMapping;
	}

	@Override
	public IStructureMapMutableBean setTimeFormatMapping(StructureReferenceBean timeFormatMapping) {
		this.timeFormatMapping = timeFormatMapping;
		return this;
	}

	@Override
	public Map<String, String> getFixedOutputs() {
		return fixedOutputs;
	}

	@Override
	public IStructureMapMutableBean addFixedOutput(String componentId, String outputValue) {
		if(fixedOutputs == null) {
			fixedOutputs = new HashMap<>();
		}
		fixedOutputs.put(componentId, outputValue);
		return this;
	}


	@Override
	public void setFixedOutputs(Map<String, String> outputs) {
		this.fixedOutputs = outputs;
	}

	@Override
	public Map<String, String> getFixedInputs() {
		return fixedInputs;
	}

	@Override
	public IStructureMapMutableBean addFixedInput(String componentId, String outputValue) {
		if(fixedInputs == null) {
			fixedInputs = new HashMap<>();
		}
		fixedInputs.put(componentId, outputValue);
		return this;
	}

	@Override
	public void setFixedInputs(Map<String, String> inputs) {
		this.fixedInputs = inputs;
	}


}
