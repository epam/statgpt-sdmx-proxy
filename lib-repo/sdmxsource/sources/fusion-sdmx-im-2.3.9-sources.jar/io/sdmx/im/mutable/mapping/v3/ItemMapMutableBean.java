package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

public abstract class ItemMapMutableBean<T extends IItemMapMutableBean<T>> extends AnnotableMutableBeanImpl implements IItemMapMutableBean<T> {
	private static final long serialVersionUID = 1L;

	private String sourceId;
	private String targetId;
	private Integer sourceStartIdx = 0;
	private Integer sourceEndIdx = 0;
	private boolean isRegEx;
	private String validFrom;
	private String validTo;

	public ItemMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.ITEM_MAP);
	}

	public ItemMapMutableBean(IItemMapBean bean, MutableBean parent) {
		super(bean, parent);
		setSourceId(bean.getSourceId());
		setTargetId(bean.getTargetId());
	}

	@Override
	public String getSourceId() {
		return sourceId;
	}

	@Override
	public T setSourceId(String sourceId) {
		this.sourceId = sourceId;
		return getThis();
	}

	@Override
	public String getTargetId() {
		return targetId;
	}

	@Override
	public T setTargetId(String targetId) {
		this.targetId = targetId;
		return getThis();
	}

	@Override
	public T setSourceStartIdx(Integer idx) {
		this.sourceStartIdx = idx;
		return getThis();
	}

	@Override
	public Integer getSourceStartIdx() {
		return sourceStartIdx;
	}

	@Override
	public T setSourceEndIdx(Integer idx) {
		this.sourceEndIdx = idx;
		return getThis();
	}

	@Override
	public Integer getSourceEndIdx() {
		return sourceEndIdx;
	}

	@Override
	public T setSourceRegEx(boolean regEx) {
		this.isRegEx = regEx;
		return getThis();
	}

	@Override
	public boolean isSourceRegEx() {
		return isRegEx;
	}

	@Override
	public String getValidFrom() {
		return validFrom;
	}

	@Override
	public T setValidFrom(String period) {
		this.validFrom = period;
		return getThis();
	}

	@Override
	public String getValidTo() {
		return validTo;
	}

	@Override
	public T setValidTo(String period) {
		this.validTo = period;
		return getThis();
	}

	public abstract T getThis();
}