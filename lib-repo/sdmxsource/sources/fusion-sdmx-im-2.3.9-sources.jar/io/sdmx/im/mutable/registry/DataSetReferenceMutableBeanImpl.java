
package io.sdmx.im.mutable.registry;

import java.util.List;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.DataSetReferenceMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class DataSetReferenceMutableBeanImpl extends MutableBeanImpl implements DataSetReferenceMutableBean {
	private static final long serialVersionUID = -5015097893049847027L;
	private String datasetId;
	private StructureReferenceBean dataProviderRef;
	
	public DataSetReferenceMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATASET_REFERENCE);
	}

	public DataSetReferenceMutableBeanImpl(DataSetReferenceBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getDataProviderReference() != null)  {
			this.dataProviderRef = new StructureReferenceBeanImpl(bean.getDataProviderReference().getTargetUrn());
		}
		this.datasetId = bean.getDatasetId();
	}

	@Override
	public String getDatasetId() {
		return datasetId;
	}

	@Override
	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}

	@Override
	public StructureReferenceBean getDataProviderReference() {
		return dataProviderRef;
	}

	@Override
	public void setDataProviderReference(StructureReferenceBean sRef) {
		this.dataProviderRef = sRef;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (dataProviderRef != null) {
	        returnSet.add(dataProviderRef);
	    }
	    return returnSet;
	}
}