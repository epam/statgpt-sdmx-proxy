package io.sdmx.im.mutable.codelist;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.im.beans.codelist.HierarchyBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class HierarchyMutableBeanImpl extends MaintainableMutableBeanImpl implements HierarchyMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<CodeRefMutableBean> codeRefs = new ArrayList<>();
	private LevelMutableBean level;
	private boolean hasFormalLevels;
	
	public HierarchyMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.HIERARCHY);
	}

	public HierarchyMutableBeanImpl(HierarchyBean bean) {
		super(bean);
		if(bean.getHierarchicalCodeBeans() != null) {
			for(HierarchicalCodeBean currentBean : bean.getHierarchicalCodeBeans()) {
				this.addHierarchicalCodeBean(new CodeRefMutableBeanImpl(currentBean, this));
			}
 		}
		if(bean.getLevel() != null) {
			this.level = new LevelMutableBeanImpl(bean.getLevel(), this);
		}
		this.hasFormalLevels = bean.hasFormalLevels();
	}
	
	
	@Override
	public HierarchyBean getImmutableInstance() {
		return new HierarchyBeanImpl(this);
	}

	@Override
	public boolean isFormalLevels() {
		return hasFormalLevels;
	}

	@Override
	public void setFormalLevels(boolean bool) {
		this.hasFormalLevels = bool;
	}

	@Override
	public LevelMutableBean getChildLevel() {
		return level;
	}

	@Override
	public void setChildLevel(LevelMutableBean level) {
		this.level = level;
	}

	@Override
	public void setHierarchicalCodeBeans(List<CodeRefMutableBean> codeRefs) {
		this.codeRefs = codeRefs;
	}

	@Override
	public void addHierarchicalCodeBean(CodeRefMutableBean codeRef) {
		this.codeRefs.add(codeRef);
	}

	@Override
	public List<CodeRefMutableBean> getHierarchicalCodeBeans() {
		return codeRefs;
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(codeRefs, composites);
        super.addToCompositeSet(level, composites);
        return composites;
    }


	@Override
	public HierarchyMutableBean stripItems(Date aDate) {
		List<CodeRefMutableBean> retVal = evaluateCodeRefs(this.getHierarchicalCodeBeans(), aDate);
		setHierarchicalCodeBeans(retVal);
		return this;
	}
	
	private List<CodeRefMutableBean> evaluateCodeRefs(List<CodeRefMutableBean> hierarchicalCodeBeans, Date aDate) {
		ArrayList<CodeRefMutableBean> retVal = new ArrayList<>();
		for (CodeRefMutableBean aCodeRef: hierarchicalCodeBeans) {
			if (aCodeRef.hasValidityPeriod()) {
			    Optional<SdmxPeriod> itemSdmxPeriod = aCodeRef.getSdmxPeriod();
			    if (itemSdmxPeriod.isPresent() && !itemSdmxPeriod.get().isInPeriod(aDate)) {
			        continue;
			    }
			}

			retVal.add(aCodeRef);
			if (ObjectUtil.validCollection(aCodeRef.getCodeRefs())) {
				aCodeRef.setCodeRefs(evaluateCodeRefs(aCodeRef.getCodeRefs(), aDate));
			}
		}
		return retVal;
	}
}