package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ConstraintDataKeySetMutableBeanImpl extends MutableBeanImpl implements ConstraintDataKeySetMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<ConstrainedDataKeyMutableBean> constrainedKeys = new ArrayList<>();

	public ConstraintDataKeySetMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONSTRAINED_DATA_KEY_SET);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConstraintDataKeySetMutableBeanImpl(ConstraintDataKeySetBean immutable) {
		super(SDMX_STRUCTURE_TYPE.CONSTRAINED_DATA_KEY_SET);
		for (ConstrainedDataKeyBean each : immutable.getConstrainedDataKeys())
			this.constrainedKeys.add(new ConstrainedDataKeyMutableBeanImpl(each, this));
	}

	@Override
	public List<ConstrainedDataKeyMutableBean> getConstrainedDataKeys() {
		 return this.constrainedKeys;
	}

	@Override
	public void setConstrainedDataKeys(List<ConstrainedDataKeyMutableBean> keys) {
		if (keys == null) {
			constrainedKeys = new ArrayList<>();
		}
		this.constrainedKeys = keys;
	}

	@Override
	public void addConstrainedDataKey(ConstrainedDataKeyMutableBean key) {
		if (key == null) {
			constrainedKeys = new ArrayList<>();
		}
		this.constrainedKeys.add(key);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
    	super.addToCompositeSet(constrainedKeys, composites);
    	return composites;
    }
}