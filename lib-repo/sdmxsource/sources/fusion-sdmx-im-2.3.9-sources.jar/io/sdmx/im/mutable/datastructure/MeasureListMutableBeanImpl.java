
package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;


public class MeasureListMutableBeanImpl extends IdentifiableMutableBeanImpl implements MeasureListMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<MeasureMutableBean> measures = new ArrayList<>();
	
	public MeasureListMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.MEASURE_DESCRIPTOR);
	}

	public MeasureListMutableBeanImpl(MeasureListBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getMeasures() != null) {
			for(MeasureDimensionBean measure : bean.getMeasures()) {
				this.measures.add(new MeasureMutableBeanImpl(measure, this));
			}
		}
	}
	
	@Override
	public List<MeasureMutableBean> getMeasures() {
		return measures;
	}

	@Override
	public void setMeasures(List<MeasureMutableBean> measures) {
		this.measures = measures;
	}

	@Override
	public void addMeasures(MeasureMutableBean measure) {
		if(this.measures == null) {
			this.measures = new ArrayList<>();
		}
		this.measures.add(measure);
	} 

	@Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
    	if(this.measures != null) {
    		composites.addAll(this.measures);
    	}
        return composites;
    }
}