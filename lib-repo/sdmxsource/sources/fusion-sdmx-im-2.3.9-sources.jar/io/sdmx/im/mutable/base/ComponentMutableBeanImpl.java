package io.sdmx.im.mutable.base;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;

public abstract class ComponentMutableBeanImpl extends IdentifiableMutableBeanImpl implements ComponentMutableBean {
	private static final long serialVersionUID = 1L;
	private RepresentationMutableBean representation;
	private StructureReferenceBean conceptRef;
	protected boolean assignmentStatus;
	
	public ComponentMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public ComponentMutableBeanImpl(ComponentBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getRepresentation() != null) {
			representation = new RepresentationMutableBeanImpl(bean.getRepresentation(), this);
		}
		if(bean.getConceptRef() != null) {
			this.conceptRef = bean.getConceptRef().asMutable();
		}
		this.assignmentStatus = bean.isMandatory();
	}
	
	@Override
	public StructureReferenceBean getConceptRef() {
		return conceptRef;
	}

	@Override
	public ComponentMutableBean setMinOccurs(Integer num) {
		if(num != null) {
			if(this.representation == null) {
				this.representation = new RepresentationMutableBeanImpl();
			}
			this.representation.setMinOccurs(num);
		} else if(this.representation != null) {
			this.representation.setMinOccurs(null);
		}
		return this;
	}

	@Override
	public ComponentMutableBean setMaxOccurs(Integer num) {
		if(num != null) {
			if(this.representation == null) {
				this.representation = new RepresentationMutableBeanImpl();
			}
			this.representation.setMaxOccurs(num);
		} else if(this.representation != null) {
			this.representation.setMaxOccurs(null);
		}
		return this;
	}

	@Override
	public String getId() {
		if(super.getId() != null) {
			return super.getId();
		}
		if(this.getConceptRef() != null) {
			return this.getConceptRef().getFullId();
		}
		return null;
	}

	@Override
	public void setConceptRef(StructureReferenceBean conceptRef) {
		this.conceptRef = conceptRef;
	}

	@Override
	public RepresentationMutableBean getRepresentation() {
		return representation;
	}

	@Override
	public void setRepresentation(RepresentationMutableBean representation) {
		this.representation = representation;
	}
	
	
	
	@Override
	public void setTextFormat(TextFormatMutableBean textFormat) {
		if(this.representation == null) {
			this.representation = new RepresentationMutableBeanImpl();
		}
		this.representation.setTextFormat(textFormat);
		
	}

	@Override
	public void setEnumeration(StructureReferenceBean representationRef) {
		if(this.representation == null) {
			this.representation = new RepresentationMutableBeanImpl();
		}
		this.representation.setRepresentation(representationRef);
	}

	@Override
	public TextFormatMutableBean setTextType(TEXT_TYPE tt) {
		if(this.representation == null) {
			this.representation = new RepresentationMutableBeanImpl();
		}
		if(this.representation.getTextFormat() == null) {
			this.representation.setTextFormat(new TextFormatMutableBeanImpl());
		}
		this.representation.getTextFormat().setTextType(tt);
		return this.representation.getTextFormat();
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (conceptRef != null) {
	        returnSet.add(conceptRef);
	    }
	    return returnSet;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(getRepresentation(), composites);
		return composites;
	}
	
	/**
	 * The assignmentStatus attribute indicates whether a 
	 * value must be provided for the attribute when sending documentation along with the data.
	 * @return
	 */
	@Override
	public boolean isMandatory() {
		return assignmentStatus;
	}
	
	@Override
	public ComponentMutableBean setMandatory(boolean assignmentStatus) {
		this.assignmentStatus = assignmentStatus;
		return this;
	}
}