package io.sdmx.im.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.IGeoFeatureSetCodeBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;

public class GeoFeatureSetCodeMutableBean extends CodeMutableBeanImpl implements IGeoFeatureSetCodeMutableBean {
	private static final long serialVersionUID = 1L;
	private String geoFeatureSet;
	
	
	public GeoFeatureSetCodeMutableBean() {
		super();
	}

	public GeoFeatureSetCodeMutableBean(IGeoFeatureSetCodeBean bean, IGeographicCodelistMutableBean parent) {
		super(bean, parent);
		this.geoFeatureSet = bean.getGeoFeatureSet();
	}

	@Override
	public String getGeoFeatureSet() {
		return geoFeatureSet;
	}

	@Override
	public void setGeoFeatureSet(String geoFeatureSet) {
		this.geoFeatureSet = geoFeatureSet;
	}

}
