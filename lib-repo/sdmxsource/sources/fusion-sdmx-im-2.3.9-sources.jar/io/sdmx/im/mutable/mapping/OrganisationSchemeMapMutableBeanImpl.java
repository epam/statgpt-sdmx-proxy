package io.sdmx.im.mutable.mapping;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;

public class OrganisationSchemeMapMutableBeanImpl extends GenericItemSchemeMapMutableBean implements OrganisationSchemeMapMutableBean {

	private static final long serialVersionUID = 1L;

	public OrganisationSchemeMapMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.V2_ORGANISATION_SCHEME_MAP);
	}

	public OrganisationSchemeMapMutableBeanImpl(OrganisationSchemeMapBean bean, MutableBean parent) {
		super(bean, parent);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		StructureReferenceBean sourceScheme = this.getSourceRef();
		if(sourceScheme != null) {
			SDMX_STRUCTURE_TYPE targetType = null;
			switch(sourceScheme.getMaintainableStructureType()) {
			case AGENCY_SCHEME : return SDMX_STRUCTURE_TYPE.AGENCY;
			case DATA_CONSUMER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_CONSUMER;
			case DATA_PROVIDER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_PROVIDER;
			case ORGANISATION_UNIT_SCHEME : return SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT;
			}
		}
		return null;	
	}

}