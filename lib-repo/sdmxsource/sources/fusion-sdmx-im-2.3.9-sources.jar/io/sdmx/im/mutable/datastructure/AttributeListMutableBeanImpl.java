package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.im.mutable.base.IdentifiableMutableBeanImpl;

public class AttributeListMutableBeanImpl extends IdentifiableMutableBeanImpl implements AttributeListMutableBean {
	private static final long serialVersionUID = 7413119331825537279L;
	private List<AttributeMutableBean> attributes = new ArrayList<>();
	
	public AttributeListMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.ATTRIBUTE_DESCRIPTOR);
	}

	public AttributeListMutableBeanImpl(AttributeListBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getAttributes() != null) {
			for(AttributeBean currentAttribute : bean.getAttributes()) {
				attributes.add(new AttributeMutableBeanImpl(currentAttribute, this));
			}
		}
	}

	@Override
	public List<AttributeMutableBean> getAttributes() {
		return attributes;
	}

	@Override
	public void setAttributes(List<AttributeMutableBean> attributes) {
		this.attributes = attributes;
	}

	@Override
	public void addAttribute(AttributeMutableBean attribute) {
		if(attributes == null) {
			this.attributes = new ArrayList<>();
		}
		this.attributes.add(attribute);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(attributes, composites);
        return composites;
    }
}