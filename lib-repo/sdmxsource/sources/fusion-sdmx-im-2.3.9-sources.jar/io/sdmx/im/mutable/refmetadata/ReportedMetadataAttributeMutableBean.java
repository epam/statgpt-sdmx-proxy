package io.sdmx.im.mutable.refmetadata;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;

public class ReportedMetadataAttributeMutableBean extends AnnotableMutableBeanImpl implements IReportedMetadataAttributeMutableBean {
	private static final long serialVersionUID = 1L;
	private String value;
	private String id;
	private TextTypeMutableBean structuredValues;
	private List<IReportedMetadataAttributeMutableBean> attributes;
	
	public ReportedMetadataAttributeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.REPORTED_METADATA_ATTRIBUTE);
	}
	
	public ReportedMetadataAttributeMutableBean(IReportedMetadataAttributeBean bean, IReportedMetadataSetMutableBean parent) {
		super(bean, parent);
		
		this.value = bean.getValue();
		this.id = bean.getId();
		if(bean.getStructuredValue() != null) {
			this.structuredValues = new TextTypeMutableBeanImpl(bean.getStructuredValue(), this);
		}
	}
	
	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public IReportedMetadataAttributeMutableBean setValue(String value) {
		this.value = value;
		return this;
	}

	@Override
	public TextTypeMutableBean getStructuredValues() {
		return structuredValues;
	}

	@Override
	public IReportedMetadataAttributeMutableBean setStructuredValues(TextTypeMutableBean values) {
		this.structuredValues = values;
		return this;
	}

	@Override
	public List<IReportedMetadataAttributeMutableBean> getAttributes() {
		return attributes;
	}

	@Override
	public IReportedMetadataAttributeMutableBean setAttributes(List<IReportedMetadataAttributeMutableBean> attributes) {
		this.attributes = attributes;
		return this;
	}

	@Override
	public IReportedMetadataAttributeMutableBean addAttribute(IReportedMetadataAttributeMutableBean attribute) {
		if(this.attributes == null) {
			this.attributes = new ArrayList<>();
		}
		this.attributes.add(attribute);
		return this;
	}

	@Override
	public IReportedMetadataAttributeMutableBean addStructuredValue(String locale, String text) {
		if(this.structuredValues == null) {
			this.structuredValues = new TextTypeMutableBeanImpl();
		}
		this.structuredValues.addText(new TextTypeWrapperMutableBeanImpl(locale, text));
		return this;
	}
	
	
}
