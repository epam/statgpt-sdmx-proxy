package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ConstrainedDataKeyMutableBeanImpl extends MutableBeanImpl implements ConstrainedDataKeyMutableBean {
	private static final long serialVersionUID = 1L;

	private List<IConstrainedKeyValue> keyValues = new ArrayList<>();
	private List<IConstrainedKeyValue> componentValues = new ArrayList<>();
	private String validFrom;
	private String validTo;
	

	public ConstrainedDataKeyMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CONSTRAINED_DATA_KEY);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConstrainedDataKeyMutableBeanImpl(ConstrainedDataKeyBean bean, MutableBean parent) {
		super(bean, parent);
		for (IConstrainedKeyValue kv : bean.getKeyValues()) {
			this.keyValues.add(kv);
		}
		for (IConstrainedKeyValue kv : bean.getComponentValues()) {
			this.componentValues.add(kv);
		}
		if(bean.hasValidityPeriod() && bean.getValidityPeriod().hasStartPeriod()) {
			this.validFrom = bean.getValidityPeriod().getStartPeriod().getDateInSdmxFormat();
		}
		if(bean.hasValidityPeriod() && bean.getValidityPeriod().hasEndPeriod()) {
			this.validTo = bean.getValidityPeriod().getEndPeriod().getDateInSdmxFormat();
		}
	}

	@Override
	public List<IConstrainedKeyValue> getKeyValues() {
		return this.keyValues;
	}
	

	@Override
	public String getValidFrom() {
		return validFrom;
	}

	@Override
	public ConstrainedDataKeyMutableBean setValidFrom(String validFrom) {
		this.validFrom = validFrom;
		return this;
	}

	@Override
	public String getValidTo() {
		return validTo;
	}

	@Override
	public ConstrainedDataKeyMutableBean setValidTo(String validTo) {
		this.validTo = validTo;
		return this;
	}

	@Override
	public void setSimpleKeyValues(List<KeyValue> keyvalues) {
		if (keyvalues != null) {
			for(KeyValue kv : keyvalues) {
				this.addKeyValue(kv);
			}
		}
	}

	@Override
	public void setKeyValues(List<IConstrainedKeyValue> keyvalues) {
		if (keyvalues != null) {
			this.keyValues = keyvalues;
		}
	}

	@Override
	public void addKeyValue(IConstrainedKeyValue keyvalue) {
		if(this.keyValues == null) {
			this.keyValues = new ArrayList<>();
		}
		if (keyvalue != null) {
			this.keyValues.add(keyvalue);
		}
	}


	@Override
	public void addKeyValue(KeyValue keyvalue) {
		if(keyvalue != null) {
			addKeyValue(ConstrainedKeyValue.getInstance(keyvalue.getConcept(), false, keyvalue.getCode()));
		}
	}

	@Override
	public List<IConstrainedKeyValue> getComponentValues() {
		return componentValues;
	}

	@Override
	public void setComponentValues(List<IConstrainedKeyValue> componentValues) {
		this.componentValues = componentValues;
	}

	@Override
	public void addComponentValues(IConstrainedKeyValue componentValue) {
		if(this.componentValues == null) {
			this.componentValues = new ArrayList<>();
		}
		if (componentValue != null) {
			this.componentValues.add(componentValue);
		}
	}


}
