package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean.SUBSCRIPTION_TYPE;
import io.sdmx.api.sdmx.model.mutable.registry.SubscriptionMutableBean;
import io.sdmx.im.beans.registry.SubscriptionBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class SubscriptionMutableBeanImpl extends MaintainableMutableBeanImpl implements SubscriptionMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean owner;
	private List<String> mailTo = new ArrayList<>();
	private List<String> HTTPPostTo = new ArrayList<>();
	private List<StructureReferenceBean> references = new ArrayList<>(); 
	private SUBSCRIPTION_TYPE subscriptionType;

	public SubscriptionMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.SUBSCRIPTION);
	}
	
	public SubscriptionMutableBeanImpl(SubscriptionBean subscriptionBean) {
		super(subscriptionBean);
		if(subscriptionBean.getHTTPPostTo() != null) {
			this.HTTPPostTo = new ArrayList<>(subscriptionBean.getHTTPPostTo());
		}
		if(subscriptionBean.getMailTo() != null) {
			this.mailTo = new ArrayList<>(subscriptionBean.getMailTo());
		}
		if(subscriptionBean.getReferences() != null) {
			for(IURN<?> sRef : subscriptionBean.getReferences()) {
				this.references.add(sRef.asMutable());
			}
		}
		this.structureType = subscriptionBean.getStructureType();
		this.owner = subscriptionBean.getOwner().asMutable();
		this.subscriptionType = subscriptionBean.getSubscriptionType();
	}

	@Override
	public StructureReferenceBean getOwner() {
		return owner;
	}

	@Override
	public void setOwner(StructureReferenceBean owner) {
		this.owner = owner;
	}

	@Override
	public List<String> getMailTo() {
		return mailTo;
	}

	@Override
	public void setMailTo(List<String> mailTo) {
		this.mailTo = mailTo;
	}

	@Override
	public List<String> getHTTPPostTo() {
		return HTTPPostTo;
	}

	@Override
	public void setHTTPPostTo(List<String> hTTPPostTo) {
		HTTPPostTo = hTTPPostTo;
	}

	@Override
	public void addReference(StructureReferenceBean reference) {
		if(this.references == null) {
			this.references = new ArrayList<>();
		}
		this.references.add(reference);
	}
	
	@Override
	public List<StructureReferenceBean> getReferences() {
		return references;
	}

	@Override
	public void setReferences(List<StructureReferenceBean> references) {
		this.references = references;
	}

	@Override
	public SUBSCRIPTION_TYPE getSubscriptionType() {
		return subscriptionType;
	}

	@Override
	public void setSubscriptionType(SUBSCRIPTION_TYPE subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	@Override
	public SubscriptionBean getImmutableInstance() {
		return new SubscriptionBeanImpl(this);
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (owner != null) {
	        returnSet.add(owner);
	    }
	    return returnSet;
	}
}