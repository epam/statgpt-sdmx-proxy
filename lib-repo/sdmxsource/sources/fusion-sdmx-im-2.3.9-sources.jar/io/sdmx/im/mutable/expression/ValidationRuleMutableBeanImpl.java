package io.sdmx.im.mutable.expression;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleHierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;
import io.sdmx.im.mutable.base.ItemMutableBeanImpl;

public class ValidationRuleMutableBeanImpl extends ItemMutableBeanImpl implements ValidationRuleMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String resultant;
	private EQUALITY equality;
	private String expression;
	private ValidationRuleHierarchyMutableBean hierarchyRef;

	public ValidationRuleMutableBeanImpl(ValidationRuleBean bean, ValidationSchemeMutableBean parent) {
		super(bean, parent);
		if(bean.getValidationHierarchy() != null) {
			this.hierarchyRef = new ValidationRuleHierarchyMutableBeanImpl(bean.getValidationHierarchy(), this);
		}
		this.expression = bean.getExpression();
	}
	

	public ValidationRuleMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.VALIDATION_RULE);
	}

	
	
	@Override
	public void setHierarchyReference(String hierarchyURN, String dimURN) {
		ValidationRuleHierarchyMutableBean hVal = new ValidationRuleHierarchyMutableBeanImpl();
		hVal.setDimensionReference(new StructureReferenceBeanImpl(dimURN));
		hVal.setHierarchyReference(new StructureReferenceBeanImpl(hierarchyURN));
		this.hierarchyRef = hVal;
	}


	@Override
	public String getExpression() {
		return this.expression;
	}

	@Override
	public void setExpression(String string) {
		this.expression = string;
	}

	@Override
	public ValidationRuleHierarchyMutableBean getHierarchyReference() {
		return hierarchyRef;
	}

	@Override
	public void setHierarchyReference(ValidationRuleHierarchyMutableBean sRef) {
		this.hierarchyRef = sRef;
	}

	@Override
	public String getResultant() {
		return resultant;
	}

	@Override
	public void setResultant(String resultant) {
		this.resultant = resultant;
	}

	@Override
	public EQUALITY getEqualityOperator() {
		return equality;
	}


	@Override
	public void setEqualityOperator(EQUALITY equality) {
		this.equality = equality;
	}
}
