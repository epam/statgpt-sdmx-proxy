package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.im.beans.transformation.NamePersonalisationSchemeBean;

public class NamePersonalisationSchemeMutableBean extends VtlSchemeMutableBean<INamePersonalisationMutableBean> implements INamePersonalisationSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public NamePersonalisationSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME);
	}

	public NamePersonalisationSchemeMutableBean(INamePersonalisationSchemeBean bean) {
		super(bean);
		this.items = new ArrayList<>(bean.getItems().size());
		for(INamePersonalisationBean item : bean.getItems()) {
			this.items.add(new NamePersonalisationMutableBean(item, this));
		}
	}

	@Override
	public INamePersonalisationSchemeBean getImmutableInstance() {
		return new NamePersonalisationSchemeBean(this);
	}

	@Override
	public INamePersonalisationMutableBean addINamePersonalisation(String id, String vtlArtefact, String defaultName, String personalisedName) {
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
		INamePersonalisationMutableBean bean = new NamePersonalisationMutableBean();
		bean.setId(id);
		bean.setVtlArtefact(vtlArtefact);
		bean.setVtlDefaultName(defaultName);
		bean.setPersonalisedName(personalisedName);
		this.items.add(bean);
		return bean;
	}
}
