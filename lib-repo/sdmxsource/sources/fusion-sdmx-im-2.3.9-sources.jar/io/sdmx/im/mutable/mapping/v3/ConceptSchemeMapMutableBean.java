package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;
import io.sdmx.im.beans.mapping.v3.ConceptSchemeMapBean;

public class ConceptSchemeMapMutableBean extends GenericItemSchemeMapMutableBean<IConceptMapMutableBean, IConceptMapBean> implements IConceptSchemeMapMutableBean {
	private static final long serialVersionUID = 1L;

	public ConceptSchemeMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME_MAP);
	}

	public ConceptSchemeMapMutableBean(IConceptSchemeMapBean bean) {
		super(bean);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CONCEPT;
	}

	@Override
	public IConceptSchemeMapBean getImmutableInstance() {
		return new ConceptSchemeMapBean(this);
	}

	@Override
	protected IConceptMapMutableBean buildItemMap(IConceptMapBean mutable) {
		return new ConceptMapMutableBean(mutable, this);
	}
}