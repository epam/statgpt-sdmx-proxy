package io.sdmx.im.mutable.base;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;

public class RepresentationMutableBeanImpl extends MutableBeanImpl implements RepresentationMutableBean {
	private static final long serialVersionUID = 1L;

	private TextFormatMutableBean textFormat;
	private StructureReferenceBean representationRef;	
	private Integer minOccurs;
	private Integer maxOccurs;
	
	public RepresentationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.LOCAL_REPRESENTATION);
	}

	public RepresentationMutableBeanImpl(RepresentationBean bean, MutableBean parent) {
		super(bean, parent);
		if(bean.getTextFormat() != null) {
			this.textFormat = new TextFormatMutableBeanImpl(bean.getTextFormat(), this);
		}
		if(bean.getRepresentation() !=  null) {
			this.representationRef = bean.getRepresentation().asMutable();
		}
		this.minOccurs = bean.getMinOccurs();
		this.maxOccurs = bean.getMaxOccurs();
	}
	
	@Override
	public Integer getMinOccurs() {
		return minOccurs;
	}

	@Override
	public RepresentationMutableBean setMinOccurs(Integer num) {
		this.minOccurs = num;
		return this;
	}

	@Override
	public Integer getMaxOccurs() {
		return maxOccurs;
	}

	@Override
	public RepresentationMutableBean setMaxOccurs(Integer num) {
		this.maxOccurs = num;
		return this;
	}


	@Override
	public TextFormatMutableBean getTextFormat() {
		return textFormat;
	}
	@Override
	public void setTextFormat(TextFormatMutableBean textFormat) {
		this.textFormat = textFormat;
	}
	@Override
	public StructureReferenceBean getRepresentation() {
		return representationRef;
	}
	@Override
	public void setRepresentation(StructureReferenceBean representationRef) {
		this.representationRef = representationRef;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (representationRef != null) {
	        returnSet.add(representationRef);
	    }
	    return returnSet;
	}

	@Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(textFormat, composites);
	    return composites;
	}
}