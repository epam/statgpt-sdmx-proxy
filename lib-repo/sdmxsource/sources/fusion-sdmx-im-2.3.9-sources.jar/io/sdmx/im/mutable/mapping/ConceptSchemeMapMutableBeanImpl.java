package io.sdmx.im.mutable.mapping;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;

public class ConceptSchemeMapMutableBeanImpl extends GenericItemSchemeMapMutableBean implements ConceptSchemeMapMutableBean {

	private static final long serialVersionUID = 1L;

	public ConceptSchemeMapMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.V2_CONCEPT_SCHEME_MAP);
	}

	public ConceptSchemeMapMutableBeanImpl(ConceptSchemeMapBean bean, MutableBean parent) {
		super(bean, parent);
	}
	

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CONCEPT;
	}

}