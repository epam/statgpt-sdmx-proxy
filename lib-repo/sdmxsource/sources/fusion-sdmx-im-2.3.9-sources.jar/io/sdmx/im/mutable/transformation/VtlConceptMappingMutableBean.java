package io.sdmx.im.mutable.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlConceptMappingBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlConceptMappingMutableBean;

public class VtlConceptMappingMutableBean extends VtlMappingMutableBean implements IVtlConceptMappingMutableBean {
	private static final long serialVersionUID = 1L;
	
	public VtlConceptMappingMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_CONCEPT_MAPPING);
	}

	public VtlConceptMappingMutableBean(IVtlConceptMappingBean bean, MutableBean parent) {
		super(bean, parent);
	}
}
