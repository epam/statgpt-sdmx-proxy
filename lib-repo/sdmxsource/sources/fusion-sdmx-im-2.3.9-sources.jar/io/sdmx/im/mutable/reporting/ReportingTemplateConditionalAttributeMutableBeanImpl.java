package io.sdmx.im.mutable.reporting;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateConditionalAttributeMutableBean;
import io.sdmx.im.mutable.base.ConditionalAttributeMappingBeanMutableBeanImpl;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ReportingTemplateConditionalAttributeMutableBeanImpl extends MutableBeanImpl implements ReportingTemplateConditionalAttributeMutableBean {
	private static final long serialVersionUID = 1L;
	private String attributeId;
	private List<ConditionalAttributeMappingBeanMutableBean> conditions;
	
	
	public ReportingTemplateConditionalAttributeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TEMPLATE_CONDITIONAL_ATTR);
	}

	public ReportingTemplateConditionalAttributeMutableBeanImpl(ReportingTemplateConditionalAttributeBean bean, MutableBean parent) {
		super(bean, parent);
		this.attributeId = bean.getAttributeId();
		this.conditions = new ArrayList<>();
		for(ConditionalAttributeMappingBean currentBean : bean.getConditions()) {
			this.conditions.add(new ConditionalAttributeMappingBeanMutableBeanImpl(currentBean, this));
		}
	}
	
	@Override
	public String getAttributeId() {
		return attributeId;
	}

	@Override
	public void setAttributeId(String attId) {
		this.attributeId = attId;
	}

	@Override
	public List<ConditionalAttributeMappingBeanMutableBean> getConditions() {
		return conditions;
	}

	@Override
	public void setConditions(List<ConditionalAttributeMappingBeanMutableBean> conditions) {
		this.conditions = conditions;
	}

	@Override
	public void addCondition(ConditionalAttributeMappingBeanMutableBean condition) {
		if(this.conditions == null) {
			this.conditions = new ArrayList<>();
		}
		this.conditions.add(condition);
	}
}
