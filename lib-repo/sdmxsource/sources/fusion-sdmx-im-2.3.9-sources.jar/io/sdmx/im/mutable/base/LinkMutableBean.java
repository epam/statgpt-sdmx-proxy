package io.sdmx.im.mutable.base;

import java.net.URI;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.mutable.base.ILinkMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public class LinkMutableBean implements ILinkMutableBean {

	@Override
	public String getRel() {
		return null;
	}

	@Override
	public ILinkMutableBean setRel(String rel) {
		return null;
	}

	@Override
	public URI getUrl() {
		return null;
	}

	@Override
	public ILinkMutableBean setUrl(URI rel) {
		return null;
	}

	@Override
	public IURN getUrn() {
		return null;
	}

	@Override
	public ILinkMutableBean setUrn(IURN urn) {
		return null;
	}

	@Override
	public String getType() {
		return null;
	}

	@Override
	public ILinkMutableBean setType(String type) {
		return null;
	}

	@Override
	public void addTitle(String locale, String name) {

	}

	@Override
	public void addTitle(TextTypeWrapperMutableBean text) {

	}

	@Override
	public List<TextTypeWrapperMutableBean> getTitles() {
		return null;
	}

}
