package io.sdmx.im.mutable.base;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class DataProviderMutableBeanImpl extends OrganisationMutableBeanImpl implements DataProviderMutableBean {
	private static final long serialVersionUID = 1L;
	
	public DataProviderMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATA_PROVIDER);
	}

	public DataProviderMutableBeanImpl(DataProviderBean bean, MutableBean parent) {
		super(bean, parent);
	}
	
    @Override
    public Set<MutableBean> getComposites() {
        return super.getComposites();
    }
}
