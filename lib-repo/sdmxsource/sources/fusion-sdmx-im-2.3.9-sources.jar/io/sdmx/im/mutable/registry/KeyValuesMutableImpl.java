package io.sdmx.im.mutable.registry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.mutable.base.MutableBeanImpl;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;

public class KeyValuesMutableImpl extends MutableBeanImpl implements KeyValuesMutable {
	private static final long serialVersionUID = 1L;
	private String id;
	private List<String> values = new ArrayList<>();
	private List<String> cascade = new ArrayList<>();
//	private List<String> cascadeExcludeRoot = new ArrayList<>();
	private Map<String, String> validFromMap;
	private Map<String, String> validToMap;
	
	private TimeRangeMutableBean timeRangeBean;

	
	private boolean removePrefix;
	
	public KeyValuesMutableImpl() {
		super(SDMX_STRUCTURE_TYPE.KEY_VALUES);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public KeyValuesMutableImpl(KeyValues bean, MutableBean parent) {
		super(bean, parent);
		this.id = bean.getId();
		this.values.addAll(bean.getValues());
		this.cascade.addAll(bean.getCascadeValues());
		this.removePrefix = bean.isRemovePrefix();
		if(bean.getTimeRange() != null) {
			timeRangeBean = new TimeRangeMutableBeanImpl(bean.getTimeRange());
		}
		for(String value : bean.getValues()) {
			SdmxPeriod period = bean.getValidityPeriod(value);
			if(!period.isAllPeriods()) {
				if(period.getStartPeriod() != null) {
					if(validFromMap == null) {
						this.validFromMap = new HashMap<>();
					}
					validFromMap.put(value, period.getStartPeriod().getDateInSdmxFormat());
				}
				if(period.getEndPeriod() != null) {
					if(validToMap == null) {
						this.validToMap = new HashMap<>();
					}
					validToMap.put(value, period.getEndPeriod().getDateInSdmxFormat());
				}
			}
		}
		for(String cascade : bean.getCascadeValues()) {
			SdmxPeriod period = bean.getValidityPeriod(cascade);
			if(!period.isAllPeriods()) {
				if(period.getStartPeriod() != null) {
					if(validFromMap == null) {
						this.validFromMap = new HashMap<>();
					}
					validFromMap.put(cascade, period.getStartPeriod().getDateInSdmxFormat());
				}
				if(period.getEndPeriod() != null) {
					if(validToMap == null) {
						this.validToMap = new HashMap<>();
					}
					validToMap.put(cascade, period.getEndPeriod().getDateInSdmxFormat());
				}
			}
		}
	}
	
	@Override
	public String getId() {
		return id;
	}
	
	@Override
	public boolean isRemovePrefix() {
		return removePrefix;
	}

	@Override
	public void setRemovePrefix(boolean removePrefix) {
		this.removePrefix = removePrefix;
	}

	@Override
	public List<String> getCascade() {
		return cascade;
	}

//	@Override
//	public List<String> getCascadeExcludeRoot() {
//		return cascadeExcludeRoot;
//	}
//
//	@Override
//	public void setCascadeExcludeRoot(List<String> cascadeValues) {
//		this.cascadeExcludeRoot = cascadeValues;
//	}

	@Override
	public void setCascade(List<String> cascadeValues) {
		cascade = cascadeValues;
	}

	@Override
	public void addCascade(String value) {
//		if(excludeRoot) {
//			if(cascadeExcludeRoot == null) {
//				cascadeExcludeRoot = new ArrayList<>();
//			}
//			cascadeExcludeRoot.add(value);
//		} else {
			if(cascade ==null) {
				cascade = new ArrayList<>();
			}
			cascade.add(value);
//		}
	}

	@Override
	public boolean isCascadeValue(String value) {
		return cascade.contains(value);
	}

	@Override
	public TimeRangeMutableBean getTimeRange() {
		return timeRangeBean;
	}

	@Override
	public KeyValuesMutable setId(String id) {
		this.id = id;
		return this;
	}
	
	@Override
	public List<String> getKeyValues() {
		return values;
	}

	@Override
	public void setKeyValues(List<String> kv) {
		this.values = kv;
	}

	@Override
	public KeyValuesMutable addValue(String value) {
		if (values == null) {
			this.values = new ArrayList<>();
		}
		
		if (value != null) {
			this.values.add(value);
		}
		return this;
	}

	@Override
	public KeyValuesMutable setValidity(String value, String validFrom, String validTo) {
		if(validFrom != null) {
			if(this.validFromMap == null) {
				this.validFromMap = new HashMap<>();
			}
			this.validFromMap.put(value, validFrom);
		}
		if(validTo != null) {
			if(this.validToMap == null) {
				this.validToMap = new HashMap<>();
			}
			this.validToMap.put(value, validTo);
		}
		return this;
	}

	@Override
	public String getValidFrom(String value) {
		if(this.validFromMap == null) {
			return null;
		}
		return this.validFromMap.get(value);
	}

	@Override
	public String getValidTo(String value) {
		if(this.validToMap == null) {
			return null;
		}
		return this.validToMap.get(value);
	}

	@Override
	public void setTimeRange(TimeRangeMutableBean timeRange) {
		this.timeRangeBean = timeRange;
	}
	
    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(timeRangeBean, composites);
        return composites;
    }
}
