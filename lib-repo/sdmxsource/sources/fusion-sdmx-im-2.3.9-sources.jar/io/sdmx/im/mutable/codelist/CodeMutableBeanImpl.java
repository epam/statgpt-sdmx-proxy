package io.sdmx.im.mutable.codelist;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.im.mutable.structure.ValidityPeriodItemMutableBean;

public class CodeMutableBeanImpl extends ValidityPeriodItemMutableBean implements CodeMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String parentCode;
	private boolean inherited;
	
	public CodeMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CODE);
	}

	public CodeMutableBeanImpl(CodeBean bean, CodelistMutableBean parent) {
		super(bean, parent, bean.getValidityPeriod());
		this.parentCode = bean.getParentCode();
		this.inherited = bean.isInherited();
	}

	@Override
	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	@Override
	public String getParentCode() {
		return parentCode;
	}
	
	

	@Override
	public boolean isInherited() {
		return inherited;
	}

	@Override
	public void setInherited(boolean inherited) {
		this.inherited = inherited;
	}

	@Override
	public IdentifiableMutableBean setId(String id) {
		CodelistMutableBean maintMutable = getParent(CodelistMutableBean.class, false);
		if(maintMutable != null && getId() != null) {
			if(maintMutable.getItems() != null) {
				for(CodeMutableBean code : maintMutable.getItems()) {
					if(code.getParentCode() != null && code.getParentCode().equals(getId())) {
						code.setParentCode(id);
					}
				}
			}
		}
		super.setId(id);
		return this;
	}
}
