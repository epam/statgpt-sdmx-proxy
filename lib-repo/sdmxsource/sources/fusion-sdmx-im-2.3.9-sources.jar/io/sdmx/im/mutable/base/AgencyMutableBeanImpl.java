package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class AgencyMutableBeanImpl extends OrganisationMutableBeanImpl implements AgencyMutableBean {
	private static final long serialVersionUID = 1L;
	
	public AgencyMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.AGENCY);
	}

	public AgencyMutableBeanImpl(AgencyBean bean, MutableBean parent) {
		super(bean, parent);
	}
}
