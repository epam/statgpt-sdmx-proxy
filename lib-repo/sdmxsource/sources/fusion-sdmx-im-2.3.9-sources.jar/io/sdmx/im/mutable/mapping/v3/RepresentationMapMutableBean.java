package io.sdmx.im.mutable.mapping.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapRefMutableBean;
import io.sdmx.im.beans.mapping.v3.RepresentationMapBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

/**
 * Represents a SDMX v3.0 representation map, where source and target can be one of the following:
 * <ul>
 *  <li>Codelist</li>
 *  <li>Valuelist</li>
 *  <li>Free Text</li>
 * </ul>
 * <p/>
 * The source and target can be mixed types allowing for Codelists to map to free text for example.
 * <p/>
 * SDMX v2.1 and lower only supports Codelist to Codelist mapping (via a structure called the CodelistMap)
 */
public class RepresentationMapMutableBean extends MaintainableMutableBeanImpl implements IRepresentationMapMutableBean {
	private static final long serialVersionUID = 1L;
	private List<IRepresentationMapRefMutableBean> sourceRef = new ArrayList<>();
	private List<IRepresentationMapRefMutableBean> targetRef = new ArrayList<>();
	private List<IMappedRelationshipMutableBean> mappedValues = new ArrayList<>();
	
	public RepresentationMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
	}
	
	public RepresentationMapMutableBean(IRepresentationMapBean bean) {
		super(bean);
		addRefs(sourceRef, bean.getSourceRef());
		addRefs(targetRef, bean.getTargetRef());
		for(IMappedRelationshipBean mappeedRelationship : bean.getMappedValues()) {
			this.mappedValues.add(new MappedRelationshipMutableBean(mappeedRelationship, this));
		}
	}
	
	@Override
	public IRepresentationMapMutableBean reverseMapping(Set<String> validSources) {
		List<IRepresentationMapRefMutableBean> sourceRefCopy = sourceRef;
		List<IRepresentationMapRefMutableBean> targetRefCopy = targetRef;
		sourceRef = targetRefCopy;
		targetRef = sourceRefCopy;
		for(IMappedRelationshipMutableBean mappedValue : mappedValues) {
			mappedValue.reverseMapping(validSources);
		}
		return this;
	}
	
	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnList = new ArrayList<>();
		for(IRepresentationMapRefMutableBean ref : this.getSourceRef()) {
			if(ref.getEnumerationRef() != null) {
				returnList.add(ref.getEnumerationRef());
			}
		}
		for(IRepresentationMapRefMutableBean ref : this.getTargetRef()) {
			if(ref.getEnumerationRef() != null) {
				returnList.add(ref.getEnumerationRef());
			}
		}
		return returnList;
	}

	private void addRefs(List<IRepresentationMapRefMutableBean> refList, List<IRepresentationMapRefBean> fromSource) {
		for(IRepresentationMapRefBean xsRef : fromSource) {
			refList.add(new RepresentationMapRefMutableBean(xsRef, this));
		}
	}

	@Override
	public IRepresentationMapBean getImmutableInstance() {
		return new RepresentationMapBean(this);
	}

	@Override
	public List<IRepresentationMapRefMutableBean> getSourceRef() {
		return sourceRef;
	}

	@Override
	public IRepresentationMapMutableBean setSourceRef(List<IRepresentationMapRefMutableBean> ref) {
		this.sourceRef = ref;
		return this;
	}
	

	@Override
	public IRepresentationMapMutableBean addSourceRef(StructureReferenceBean ref) {
		if(this.sourceRef == null) {
			this.sourceRef = new ArrayList<>();
		}
		IRepresentationMapRefMutableBean mutable = new RepresentationMapRefMutableBean();
		if(ref == null) {
			mutable.setTextType(TEXT_TYPE.STRING);
		} else {
			mutable.setEnumerationRef(ref);
		}
		this.sourceRef.add(mutable);
		return this;
	}

	
	@Override
	public IRepresentationMapMutableBean addSourceRef(TEXT_TYPE ref) {
		if(this.sourceRef == null) {
			this.sourceRef = new ArrayList<>();
		}
		IRepresentationMapRefMutableBean mutable = new RepresentationMapRefMutableBean();
		mutable.setTextType(ref);
		this.sourceRef.add(mutable);
		return this;
	}

	@Override
	public IRepresentationMapMutableBean addTargetRef(TEXT_TYPE ref) {
		if(this.targetRef == null) {
			this.targetRef = new ArrayList<>();
		}
		IRepresentationMapRefMutableBean mutable = new RepresentationMapRefMutableBean();
		mutable.setTextType(ref);
		this.targetRef.add(mutable);
		return this;
	}

	@Override
	public IRepresentationMapMutableBean addTargetRef(StructureReferenceBean ref) {
		if(this.targetRef == null) {
			this.targetRef = new ArrayList<>();
		}
		IRepresentationMapRefMutableBean mutable = new RepresentationMapRefMutableBean();
		if(ref == null) {
			mutable.setTextType(TEXT_TYPE.STRING);
		} else {
			mutable.setEnumerationRef(ref);
		}
		this.targetRef.add(mutable);
		return this;
	}

	@Override
	public List<IRepresentationMapRefMutableBean> getTargetRef() {
		return targetRef;
	}

	@Override
	public IRepresentationMapMutableBean setTargetRef(List<IRepresentationMapRefMutableBean> ref) {
		this.targetRef = ref;
		return this;
	}

	@Override
	public IMappedRelationshipMutableBean addMappedRelationship() {
		IMappedRelationshipMutableBean newRelationship = new MappedRelationshipMutableBean();
		if(this.mappedValues == null)  {
			this.mappedValues = new ArrayList<>();
		}
		this.mappedValues.add(newRelationship);
		return newRelationship;
	}

	@Override
	public List<IMappedRelationshipMutableBean> getMappedValues() {
		return mappedValues;
	}

	@Override
	public IRepresentationMapMutableBean setMappedValues(List<IMappedRelationshipMutableBean> values) {
		this.mappedValues = values;
		return this;
	}
}
