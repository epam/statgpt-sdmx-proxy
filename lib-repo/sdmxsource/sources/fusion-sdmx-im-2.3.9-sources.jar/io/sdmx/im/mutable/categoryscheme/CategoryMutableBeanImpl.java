package io.sdmx.im.mutable.categoryscheme;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.im.mutable.structure.ValidityPeriodItemMutableBean;

public class CategoryMutableBeanImpl extends ValidityPeriodItemMutableBean implements CategoryMutableBean {
	private static final long serialVersionUID = 4480929740944683260L;
	private List<CategoryMutableBean> categories = new ArrayList<>();
	
	public CategoryMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.CATEGORY);
	}
	
	public CategoryMutableBeanImpl(CategoryBean bean, MutableBean parent) {
		super(bean, parent,  bean.getValidityPeriod());
		
		// make into mutable category beans
		if(bean.getItems() != null) {
			categories = new ArrayList<>();
			for(CategoryBean categoryBean : bean.getItems()) {
				this.addItem(new CategoryMutableBeanImpl(categoryBean, this));
			}
		}		
	}

	@Override
	public List<CategoryMutableBean> getItems() {
		return categories;
	}

	@Override
	public void addItem(CategoryMutableBean item) {
		this.categories.add(item);
	}

	@Override
	public void setItems(List<CategoryMutableBean> items) {
		this.categories = items;
	}

	@Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(categories, composites);
	    return composites;
	}
}
