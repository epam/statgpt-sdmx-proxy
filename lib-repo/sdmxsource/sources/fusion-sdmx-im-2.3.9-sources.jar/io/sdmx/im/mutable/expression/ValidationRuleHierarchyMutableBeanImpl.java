package io.sdmx.im.mutable.expression;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleHierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleHierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.im.mutable.base.MutableBeanImpl;

public class ValidationRuleHierarchyMutableBeanImpl extends MutableBeanImpl implements ValidationRuleHierarchyMutableBean {
	private static final long serialVersionUID = 1L;
	private StructureReferenceBean hierarchyReference;
	private StructureReferenceBean dimensionReference;
	
	public ValidationRuleHierarchyMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.VALIDATION_RULE_HIERARCHY);
	}

	public ValidationRuleHierarchyMutableBeanImpl(ValidationRuleHierarchyBean createdFrom, ValidationRuleMutableBean parent) {
		super(createdFrom, parent);
		this.hierarchyReference = new StructureReferenceBeanImpl(createdFrom.getHierarchyReference().getTargetUrn());
		this.dimensionReference = new StructureReferenceBeanImpl(createdFrom.getDimensionReference().getTargetUrn());
	}

	@Override
	public StructureReferenceBean getHierarchyReference() {
		return hierarchyReference;
	}

	@Override
	public void setHierarchyReference(StructureReferenceBean ref) {
		this.hierarchyReference = ref;
	}

	@Override
	public StructureReferenceBean getDimensionReference() {
		return dimensionReference;
	}

	@Override
	public void setDimensionReference(StructureReferenceBean ref) {
		this.dimensionReference = ref;
	}

}
