package io.sdmx.im.mutable.base;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.SdmxReader;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public abstract class IdentifiableMutableBeanImpl extends AnnotableMutableBeanImpl implements IdentifiableMutableBean {
	private static final long serialVersionUID = 1L;
	private String id;
	private String uri;
	private String urn;
	private String oldId;
	private List<ILinkBean> links;

	public IdentifiableMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public IdentifiableMutableBeanImpl(IdentifiableBean bean, MutableBean parent) {
		super(bean, parent);
		copyIdentifiableProperties(bean, false);
	}
	
	@Override
	public void copyIdentifiableProperties(IdentifiableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyAnnotableProperties(bean);
		}
		this.links = new ArrayList<>(bean.getLinks());
		setId(bean.getId());
		if(bean.getUri() != null) {
			this.uri = bean.getUri().toString();
		}
		setUrn(bean.getUrn());  //this breaks upgrade to v3 structure map as the object type is not registered
	}

	@Override
	public void copyIdentifiableProperties(IdentifiableMutableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyAnnotableProperties(bean);
		}
		setId(bean.getId());
		if(bean.getUri() != null) {
			this.uri = bean.getUri().toString();
		}
		setUrn(bean.getUrn());
	}
	
	protected void buildIdentifiableAttributes(SdmxReader reader) {
		id = reader.getAttributeValue("id", true);
		if(reader.getAttributeValue("uri", false) != null) {
			setUri(reader.getAttributeValue("uri", false));
		}
	}
	
	@Override
	public List<ILinkBean> getLinks() {
		return links;
	}

	@Override
	public IdentifiableMutableBean setLinks(List<ILinkBean> links) {
		this.links = links;
		return this;
	}

	@Override
	public IdentifiableMutableBean addLink(ILinkBean link) {
		if(this.links == null) {
			this.links = new ArrayList<>();
		}
		this.links.add(link);
		return this;
	}

	@Override
	public void setOldId(String oldId) {
		this.oldId = oldId;
	}

	@Override
	public String getOldId() {
		return oldId;
	}

	@Override
	public IdentifiableMutableBean setId(String id) {
		this.id = id;
		return this;
	}

	@Override
	public void setUri(String uri) {
		this.uri = uri;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getUri() {
		return uri;
	}

	public void setUrn(String urn) {
		this.urn = urn;
	}

	@Override
	public String getUrn() {
		return urn;
	}

	@Override
    public IdentifiableMutableBean deepClone() {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(this);

			ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(bais);
			return (IdentifiableMutableBean) ois.readObject();
		} catch (IOException e) {
			return null;
		} catch (ClassNotFoundException e) {
			return null;
		}
	}
}