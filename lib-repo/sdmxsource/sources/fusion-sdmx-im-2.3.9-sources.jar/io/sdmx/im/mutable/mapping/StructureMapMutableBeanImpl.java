package io.sdmx.im.mutable.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;

public class StructureMapMutableBeanImpl extends SchemeMapMutableBeanImpl implements StructureMapMutableBean {

	private static final long serialVersionUID = 1L;

	private List<ComponentMapMutableBean> components;
	private boolean extension;

	public StructureMapMutableBeanImpl () {
		super(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP);
	}

	public StructureMapMutableBeanImpl (StructureMapBean bean, MutableBean parent) {
		super(bean, parent);

		extension = bean.isExtension();
		// create mutable list of component maps
		if(bean.getComponents() != null) {
			for(ComponentMapBean currentBean : bean.getComponents()) {
				this.addComponent(new ComponentMapMutableBeanImpl(currentBean, this));
			}
		}
	}

	// has Component Map bean

	@Override
	public List<ComponentMapMutableBean> getComponents() {
		return components;
	}


	@Override
	public void setComponents(List<ComponentMapMutableBean> components) {
		this.components = components;
	}

	@Override
	public void addComponent(ComponentMapMutableBean component) {
		if(components == null) {
			components = new ArrayList<>();
		}
		this.components.add(component);
	}

	@Override
	public boolean isExtension() {
		return extension;
	}

	@Override
	public void setExtension(boolean extension) {
		this.extension = extension;
	}

    @Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(components, composites);
	    return composites;
	}
}