package io.sdmx.im.mutable.transformation;

import java.util.ArrayList;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.im.beans.transformation.CustomTypeSchemeBean;

public class CustomTypeSchemeMutableBean extends VtlSchemeMutableBean<ICustomTypeMutableBean> implements ICustomTypeSchemeMutableBean {
	private static final long serialVersionUID = 1L;

	public CustomTypeSchemeMutableBean() {
		super(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME);
	}
	
	public CustomTypeSchemeMutableBean(ICustomTypeSchemeBean bean) {
		super(bean);
		this.items = new ArrayList<>(bean.getItems().size());
		for(ICustomTypeBean item : bean.getItems()) {
			this.items.add(new CustomTypeMutableBean(item, this));
		}
	}
	

	@Override
	public ICustomTypeMutableBean addCustomType(String id, String name, String vtlScalerType, String dataType, String outputFormat, String nullValue, String vtlLiteralFormat) {
		ICustomTypeMutableBean mutable = new CustomTypeMutableBean();
		mutable.setId(id);
		mutable.addName("en", name);
		mutable.setVtlScalarType(vtlScalerType);
		mutable.setDataType(dataType);
		mutable.setOutputFormat(outputFormat);
		mutable.setNullValue(nullValue);
		mutable.setVtlLiteralFormat(vtlLiteralFormat);
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
		this.items.add(mutable);
		return mutable;
	}

	@Override
	public ICustomTypeSchemeBean getImmutableInstance() {
		return new CustomTypeSchemeBean(this);
	}
}
