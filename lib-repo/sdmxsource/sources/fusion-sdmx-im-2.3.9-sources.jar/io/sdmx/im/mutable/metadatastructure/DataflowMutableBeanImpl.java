
package io.sdmx.im.mutable.metadatastructure;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.im.beans.datastructure.DataflowBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;


public class DataflowMutableBeanImpl extends MaintainableMutableBeanImpl implements DataflowMutableBean {
	private static final long serialVersionUID = 1L;
	
	private StructureReferenceBean dataStructureRef;
	
	public DataflowMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATAFLOW);
	}

	public DataflowMutableBeanImpl(DataflowBean bean) {
		super(bean);
		if(bean.getDataStructureRef() != null) {
			this.dataStructureRef = bean.getDataStructureRef().asMutable();
		}
	}
	
	/**
	 * Constructs a dataflow from a datastrucutre, the agency id, id, version, name and descriptions are copied.
	 * The datastructure reference is set to the datastructure.
	 * 
	 * @param dataStructureBean
	 */
	public DataflowMutableBeanImpl(DataStructureBean dataStructureBean) {
		super(dataStructureBean);
		super.structureType = SDMX_STRUCTURE_TYPE.DATAFLOW;
		this.dataStructureRef = dataStructureBean.asReference();
	}

	@Override
	public DataflowBean getImmutableInstance() {
		return new DataflowBeanImpl(this);
	}

	@Override
	public void setDataStructureRef(StructureReferenceBean dataStructureRef) {
		this.dataStructureRef = dataStructureRef;
	}

	@Override
	public StructureReferenceBean getDataStructureRef() {
		return dataStructureRef;
	}

	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
		if (dataStructureRef != null) {
			returnSet.add(dataStructureRef);
		}
		return returnSet;
	}
}
