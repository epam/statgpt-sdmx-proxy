package io.sdmx.im.mutable.codelist;

import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;

public class GeoGridCodeMutableBean extends CodeMutableBeanImpl implements IGeoGridCodeMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String geoCell;
	
	public GeoGridCodeMutableBean() {}

	public GeoGridCodeMutableBean(IGeoGridCodeBean bean, GeoGridCodelistMutableBean parent) {
		super(bean, parent);
		this.geoCell = bean.getGeoCell();
	}

	@Override
	public String getGeoCell() {
		return geoCell;
	}

	@Override
	public void setGeoCell(String cell) {
		this.geoCell = cell;
	}
}
