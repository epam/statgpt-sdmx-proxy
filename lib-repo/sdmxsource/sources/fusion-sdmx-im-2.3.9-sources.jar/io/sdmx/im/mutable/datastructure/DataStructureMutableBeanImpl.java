package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.beans.datastructure.DataStructureBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;

public class DataStructureMutableBeanImpl extends MaintainableMutableBeanImpl implements DataStructureMutableBean {
	private static final long serialVersionUID = 1L;

	private List<GroupMutableBean> groups = new ArrayList<>();
	private DimensionListMutableBean dimensionList;
	private AttributeListMutableBean attributeList;
	private MeasureListMutableBean measureList;
	private StructureReferenceBean msdRef;

	public DataStructureMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DSD);
	}

	public DataStructureMutableBeanImpl(DataStructureBean bean) {
		super(bean);
		if (bean.getGroups() != null) {
			for (GroupBean currentGroupBean : bean.getGroups()) {
				this.groups.add(new GroupMutableBeanImpl(currentGroupBean, this));
			}
		}
		if (bean.getDimensionList() != null) {
			this.dimensionList = new DimensionListMutableBeanImpl(
					bean.getDimensionList(), this);
		}
		if (bean.getAttributeList() != null) {
			this.attributeList = new AttributeListMutableBeanImpl(
					bean.getAttributeList(), this);
		}
		if (bean.getMeasureList() != null) {
			this.measureList = new MeasureListMutableBeanImpl(
					bean.getMeasureList(), this);
		}
		if(bean.getMSDRef() != null) {
			this.msdRef = new StructureReferenceBeanImpl(bean.getMSDRef().getTargetUrn());
		}
	}

	@Override
	public ComponentMutableBean getComponentById(String id) {
		if(this.getDimensions()  != null) {
			for(DimensionMutableBean dim : getDimensions()) {
				if(id.equals(dim.getId())) {
					return dim;
				}
			}
		}
		if(this.getAttributes()  != null) {
			for(AttributeMutableBean att : getAttributes()) {
				if(id.equals(att.getId())) {
					return att;
				}
			}
		}
		if(this.getMeasures()  != null) {
			for(MeasureMutableBean meas : getMeasures()) {
				if(id.equals(meas.getId())) {
					return meas;
				}
			}
		}
		return null;
	}
	
	@Override
	public void setMSDReference(StructureReferenceBean sRef) {
		this.msdRef = sRef;
	}

	@Override
	public StructureReferenceBean getMSDReference() {
		return this.msdRef;
	}

	@Override
	public DataStructureMutableBean removeComponent(String id) {
		removeComponent(getDimensions(), id);
		removeComponent(getAttributes(), id);
		removeComponent(getMeasures(), id);
		return this;
	}


	@Override
	public DimensionMutableBean getDimension(String id) {
		return (DimensionMutableBean)getComponentById(getDimensions(), id);
	}

	@Override
	public AttributeMutableBean getAttribute(String id) {
		return (AttributeMutableBean)getComponentById(getAttributes(), id);
	}

	private void removeComponent(List<? extends ComponentMutableBean> comps, String removeId) {
		if(comps == null) {
			return;
		}
		ComponentMutableBean toRemove = getComponentById(comps, removeId);
		if(toRemove != null) {
			comps.remove(toRemove);
		}
	}

	private ComponentMutableBean getComponentById(List<? extends ComponentMutableBean> comps, String removeId) {
		if(comps == null) {
			return null;
		}
		for(ComponentMutableBean currentComponent : comps) {
			if(currentComponent.getId() != null && currentComponent.getId().equals(removeId)) {
				return currentComponent;
			}
		}
		return null;
	}



	@Override
	public DimensionMutableBean addDimension(StructureReferenceBean conceptRef,
			StructureReferenceBean codelistRef) {
		DimensionMutableBean newDimension = new DimensionMutableBeanImpl();
		newDimension.setConceptRef(conceptRef);
		if (codelistRef != null) {
			RepresentationMutableBean representation = new RepresentationMutableBeanImpl();
			representation.setRepresentation(codelistRef);
			newDimension.setRepresentation(representation);
		}
		this.addDimension(newDimension);
		return newDimension;
	}
	
	

	@Override
	public void addMeasure(MeasureMutableBean measure) {
		if(this.measureList == null) {
			this.measureList = new MeasureListMutableBeanImpl();
		}
		this.measureList.addMeasures(measure);
	}

	@Override
	public AttributeMutableBean addAttribute(StructureReferenceBean conceptRef,
			StructureReferenceBean codelistRef) {
		AttributeMutableBean newAttribute = new AttributeMutableBeanImpl();
		newAttribute.setConceptRef(conceptRef);
		if (codelistRef != null) {
			RepresentationMutableBean representation = new RepresentationMutableBeanImpl();
			representation.setRepresentation(codelistRef);
			newAttribute.setRepresentation(representation);
		}
		this.addAttribute(newAttribute);
		return newAttribute;
	}

	@Override
	public MeasureMutableBean addPrimaryMeasure(StructureReferenceBean conceptRef) {
		MeasureMutableBean primaryMeasure = new PrimaryMeasureMutableBeanImpl();
		primaryMeasure.setConceptRef(conceptRef);
		setPrimaryMeasure(primaryMeasure);
		return primaryMeasure;
	}
	
	@Override
	public List<MeasureMutableBean> getMeasures() {
		if (this.measureList != null) {
			return this.measureList.getMeasures();
		}
		return null;
	}

	@Override
	public List<DimensionMutableBean> getDimensions() {
		if (this.dimensionList != null) {
			return this.dimensionList.getDimensions();
		}
		return null;
	}

	@Override
	public List<AttributeMutableBean> getAttributes() {
		if (this.attributeList != null) {
			return this.attributeList.getAttributes();
		}
		return null;
	}

	@Override
	public void setPrimaryMeasure(MeasureMutableBean primaryMeasure) {
		if (measureList == null) {
			this.measureList = new MeasureListMutableBeanImpl();
		}
		if(primaryMeasure != null) {
			primaryMeasure.setId(PrimaryMeasureBean.FIXED_ID);
			this.measureList.addMeasures(primaryMeasure);
		}
	}

	@Override
	public void addGroup(GroupMutableBean group) {
		if (this.groups == null) {
			this.groups = new ArrayList<>();
		}
		this.groups.add(group);
	}

	@Override
	public DataStructureBean getImmutableInstance() {
		return new DataStructureBeanImpl(this);
	}

	@Override
	public List<GroupMutableBean> getGroups() {
		return groups;
	}

	@Override
	public void setGroups(List<GroupMutableBean> groups) {
		this.groups = groups;
	}

	@Override
	public DimensionListMutableBean getDimensionList() {
		return dimensionList;
	}

	@Override
	public void setDimensionList(DimensionListMutableBean dimensionList) {
		this.dimensionList = dimensionList;
	}

	@Override
	public AttributeListMutableBean getAttributeList() {
		return attributeList;
	}

	@Override
	public void setAttributeList(AttributeListMutableBean attributeList) {
		this.attributeList = attributeList;
	}

	@Override
	public MeasureMutableBean getPrimaryMeasure() {
		if(measureList == null || measureList.getMeasures() == null) {
			return null;
		}
		for(MeasureMutableBean measure : measureList.getMeasures()) {
			if(PrimaryMeasureBean.FIXED_ID.equals(measure.getId())) {
				return measure;
			}
		}
		return null;
	}

	@Override
	public MeasureListMutableBean getMeasureList() {
		return measureList;
	}

	@Override
	public void setMeasureList(MeasureListMutableBean measureList) {
		this.measureList = measureList;
	}

	@Override
	public void addAttribute(AttributeMutableBean attribute) {
		if (this.attributeList == null) {
			this.attributeList = new AttributeListMutableBeanImpl();
		}
		this.attributeList.addAttribute(attribute);
	}

	@Override
	public void addDimension(DimensionMutableBean dimension) {
		if (this.dimensionList == null) {
			this.dimensionList = new DimensionListMutableBeanImpl();
		}
		this.dimensionList.addDimension(dimension);
	}

	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(groups, composites);
		super.addToCompositeSet(dimensionList, composites);
		super.addToCompositeSet(attributeList, composites);
		super.addToCompositeSet(measureList, composites);
		return composites;
	}
}