package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingCategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;
import io.sdmx.im.beans.mapping.v3.ReportingTaxonomyMapBean;

public class ReportingTaxonomyMapMutableBean extends GenericItemSchemeMapMutableBean<IReportingCategoryMapMutableBean, IReportingCategoryMapBean> implements IReportingTaxonomyMapMutableBean {
	private static final long serialVersionUID = 1L;

	public ReportingTaxonomyMapMutableBean() {
		super(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY_MAP);
	}

	public ReportingTaxonomyMapMutableBean(IReportingTaxonomyMapBean bean) {
		super(bean);
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.REPORTING_CATEGORY;
	}

	@Override
	public IReportingTaxonomyMapBean getImmutableInstance() {
		return new ReportingTaxonomyMapBean(this);
	}

	@Override
	protected IReportingCategoryMapMutableBean buildItemMap(IReportingCategoryMapBean mutable) {
		return new ReportingCategoryMapMutableBean(mutable, this);
	}
}