package io.sdmx.im.mutable.mapping.v3;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemSchemeMapMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public abstract class ItemSchemeMapMutableBean<T extends IItemMapMutableBean> extends SchemeMapMutableBean implements IItemSchemeMapMutableBean<T> {
	private static final long serialVersionUID = 1L;

	private List<T> items = new ArrayList<>();

	public ItemSchemeMapMutableBean(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public ItemSchemeMapMutableBean(IItemSchemeMapBean bean) {
		super(bean);
	}

	@Override
	public void setItems(List<T> items) {
		this.items = items;
	}

	@Override
	public void addItem(T item) {
		if (items == null) {
			items = new ArrayList<>();
		}
		if (item != null) {
			this.items.add(item);
		}
	}

	@Override
	public List<T> getItems() {
		return items;
	}

	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(items, composites);
		return composites;
	}

	@Override
	protected List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnReferences = super.getStructureReferencesInternal();
		StructureReferenceBean sourceScheme = this.getSourceRef();
		StructureReferenceBean targetScheme = this.getTargetRef();
		if (this.getItems() != null) {
			for (IItemMapMutableBean itemMap : this.getItems()) {
				if (sourceScheme != null) {
					returnReferences.add(new StructureReferenceBeanImpl(sourceScheme, getItemType(), itemMap.getSourceId()));
				}
				if (targetScheme != null) {
					returnReferences.add(new StructureReferenceBeanImpl(targetScheme, getItemType(), itemMap.getTargetId()));
				}
			}
		}
		return returnReferences;
	}

	protected abstract SDMX_STRUCTURE_TYPE getItemType();
}