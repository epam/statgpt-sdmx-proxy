package io.sdmx.im.mutable.datastructure;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.im.mutable.base.ComponentMutableBeanImpl;

public class DimensionMutableBeanImpl extends ComponentMutableBeanImpl implements DimensionMutableBean {
	private static final long serialVersionUID = 1L;
	
	private boolean measureDimension;
	private boolean frequencyDimension;
	private boolean timeDimension;
	private List<StructureReferenceBean> conceptRole = new ArrayList<>();
	
	public DimensionMutableBeanImpl(){
		super(SDMX_STRUCTURE_TYPE.DIMENSION);
	}
	
	public DimensionMutableBeanImpl(DimensionBean bean, MutableBean parent) {
		super(bean, parent);
		this.assignmentStatus = false;
		this.measureDimension = bean.isMeasureDimension();
		this.frequencyDimension = bean.isFrequencyDimension();
		this.timeDimension = bean.isTimeDimension();
		if(bean.getConceptRole() != null) {
			for(ICrossReferenceBean currentConceptRole : bean.getConceptRole()) {
				conceptRole.add(currentConceptRole.asMutable());
			}
		}
	}
	
	@Override
	public IdentifiableMutableBean setId(String id) {
		DataStructureMutableBean dsdMutable = getParent(DataStructureMutableBean.class, false);
		if(dsdMutable != null && getId() != null) {
			if(dsdMutable.getAttributes() != null) {
				for(AttributeMutableBean attr : dsdMutable.getAttributes()) {
					if(attr.getDimensionReferences() != null && attr.getDimensionReferences().contains(getId())) {
						attr.getDimensionReferences().remove(getId());
						attr.getDimensionReferences().add(id);
					}
				}
			}
			if(dsdMutable.getGroups() != null) {
				for(GroupMutableBean group : dsdMutable.getGroups()) {
					if(group.getDimensionRef() != null  && group.getDimensionRef().contains(getId())) {
						group.getDimensionRef().remove(getId());
						group.getDimensionRef().add(id);
					}
				}
			}
		}
		super.setId(id);
		return this;
	}

	@Override
	public boolean isMeasureDimension() {
		return measureDimension;
	}

	@Override
	public boolean isFrequencyDimension() {
		return frequencyDimension;
	}
	
	@Override
	public void setFrequencyDimension(boolean bool) {
		this.frequencyDimension = bool;
	}

	@Override
	public void setMeasureDimension(boolean bool) {
		if(bool) {
			this.structureType = SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION;
		}
		this.measureDimension = bool;
	}

	@Override
	public boolean isTimeDimension() {
		return timeDimension;
	}

	@Override
	public void setTimeDimension(boolean timeDimension) {
		if(timeDimension) {
			this.structureType = SDMX_STRUCTURE_TYPE.TIME_DIMENSION;
		}
		this.timeDimension = timeDimension;
	}
	
	@Override
	public List<StructureReferenceBean> getConceptRole() {
		return conceptRole;
	}
	
	

	@Override
	public void addConceptRole(StructureReferenceBean conceptRole) {
		if(this.conceptRole == null) {
			this.conceptRole = new ArrayList<>();
		}
		this.conceptRole.add(conceptRole);
	}

	@Override
	public void setConceptRole(List<StructureReferenceBean> conceptRole) {
		this.conceptRole = conceptRole;
	}

	@Override
	public boolean isMandatory() {
		// A DimensionBean is always mandatory
		return true;
	}

	@Override
	public DimensionMutableBean setMandatory(boolean assignmentStatus) {
		// AssignmentStatus is always mandatory so cannot be set
		return this;
	}
}
