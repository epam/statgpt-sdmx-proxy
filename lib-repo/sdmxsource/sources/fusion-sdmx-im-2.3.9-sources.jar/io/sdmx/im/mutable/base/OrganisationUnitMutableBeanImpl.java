package io.sdmx.im.mutable.base;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;

public class OrganisationUnitMutableBeanImpl extends OrganisationMutableBeanImpl implements OrganisationUnitMutableBean {
	private static final long serialVersionUID = 1L;
	private String parentUnit;
	
	public OrganisationUnitMutableBeanImpl(OrganisationUnitBean bean, MutableBean parent) {
		super(bean, parent);
	}

	public OrganisationUnitMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT);
	}

	@Override
	public String getParentUnit() {
		return parentUnit;
	}

	@Override
	public void setParentUnit(String parentUnit) {
		this.parentUnit = parentUnit;
	}
}
