package io.sdmx.im.mutable.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.im.beans.process.ProcessBeanImpl;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;

public class ProcessMutableBeanImpl extends MaintainableMutableBeanImpl implements ProcessMutableBean {
	private static final long serialVersionUID = 1L;
	
	private List<ProcessStepMutableBean> processSteps = new ArrayList<>();

	public ProcessMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.PROCESS);
	}
	
	public ProcessMutableBeanImpl (ProcessBean bean) {
		super(bean);
	
		// make into mutable bean list
		if(bean.getProcessSteps() != null) {
			for(ProcessStepBean currentBean : bean.getProcessSteps()) {
				this.addProcessStep(new ProcessStepMutableBeanImpl(currentBean, this));
			}
		}
	}
	
	@Override
	public ProcessBean getImmutableInstance() {
		return new ProcessBeanImpl(this);
	}

	@Override
	public List<ProcessStepMutableBean> getProcessSteps() {
		return processSteps;
	}

	@Override
	public void setProcessSteps(List<ProcessStepMutableBean> processSteps) {
		this.processSteps = processSteps;
	}

	@Override
	public void addProcessStep(ProcessStepMutableBean processStep) {
		this.processSteps.add(processStep);
	}

    @Override
    public Set<MutableBean> getComposites() {
    	Set<MutableBean> composites = super.getComposites();
        super.addToCompositeSet(processSteps, composites);
        return composites;
    }
}
