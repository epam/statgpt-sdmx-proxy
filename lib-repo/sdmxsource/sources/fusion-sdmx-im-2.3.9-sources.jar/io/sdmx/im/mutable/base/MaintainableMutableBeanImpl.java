package io.sdmx.im.mutable.base;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.SdmxReader;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.utils.core.version.VersionableUtil;

public abstract class MaintainableMutableBeanImpl extends VersionableMutableBeanImpl implements MaintainableMutableBean, Comparable<MaintainableMutableBean> {
	private static final long serialVersionUID = 4L;

	private String agencyId;
	private boolean isFinalStructure;
	private boolean isExternalReference;
	private boolean isStub;
	private String serviceURL;
	private String structureURL;

	public MaintainableMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	public MaintainableMutableBeanImpl(MaintainableBean bean) {
		super(bean, null);
		copyProperties(bean, false);
	}
	
	@Override
	public void copyProperties(MaintainableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyVersionableProperties(bean, includeInheritedProperties);
		}
		setAgencyId(bean.getAgencyId());
		if(bean.getServiceURL() != null) {
			this.serviceURL = bean.getServiceURL().toString();
		}
		if(bean.getStructureURL() != null) {
			this.structureURL = bean.getStructureURL().toString();
		}
		setFinalStructure(bean.isFinal());

		setExternalReference(bean.isExternalReference());
	}
	
	@Override
	public void copyProperties(MaintainableMutableBean bean, boolean includeInheritedProperties) {
		if(bean == null) {
			return;
		}
		if(includeInheritedProperties) {
			copyVersionableProperties(bean, includeInheritedProperties);
		}
		setAgencyId(bean.getAgencyId());
		if(bean.getServiceURL() != null) {
			this.serviceURL = bean.getServiceURL().toString();
		}
		if(bean.getStructureURL() != null) {
			this.structureURL = bean.getStructureURL().toString();
		}
		setFinalStructure(bean.getFinalStructure());
		setExternalReference(bean.getExternalReference());
	}

	@Override
	protected void buildMaintainableAttributes(SdmxReader reader) {
		super.buildIdentifiableAttributes(reader);
		Map<String, String> attributes = reader.getAttributes();
		this.agencyId = attributes.get("agencyID");
		if(attributes.containsKey("serviceURL")) {
			setServiceURL(attributes.get("serviceURL"));
		}
		if(attributes.containsKey("structureURL")) {
			setStructureURL(attributes.get("structureURL"));
		}
	}
	
	@Override
	public MaintainableMutableBean changeIdentifiers(String agencyId, String id, String version) {
		this.setAgencyId(agencyId);
		this.setId(id);
		this.setVersion(version);
		return this;
	}

	@Override
	public MaintainableMutableBean setAgencyId(String agencyId) {
		this.agencyId = agencyId;
		return this;
	}

	@Override
	public boolean getFinalStructure() {
		return isFinalStructure;
	}

	@Override
	public MaintainableMutableBean setFinalStructure(boolean isFinalStructure) {
		this.isFinalStructure = isFinalStructure;
		return this;
	}

	@Override
	public MaintainableMutableBean setExternalReference(boolean isExternalReference) {
		this.isExternalReference = isExternalReference;
		return this;
	}

	@Override
	public String getAgencyId() {
		return agencyId;
	}


	@Override
	public String getServiceURL() {
		return serviceURL;
	}

	@Override
	public MaintainableMutableBean setServiceURL(String serviceURL) {
		this.serviceURL = serviceURL;
		return this;
	}

	@Override
	public MaintainableMutableBean setStructureURL(String structureURL) {
		this.structureURL = structureURL;
		return this;
	}

	@Override
	public String getStructureURL() {
		return structureURL;
	}

	@Override
	public boolean getExternalReference() {
		return this.isExternalReference;
	}

	@Override
	public boolean isStub() {
		return isStub;
	}

	@Override
	public MaintainableMutableBean setStub(boolean isStub) {
		this.isStub = isStub;
		return this;
	}

	//TODO Test this method orders a list index 0 higher version then a list with index 1
	@Override
	public int compareTo(MaintainableMutableBean maintainableMutableBean) {
		return VersionableUtil.isHigherVersion(this.version, maintainableMutableBean.getVersion()) ? -1 : +1;
	}

}
