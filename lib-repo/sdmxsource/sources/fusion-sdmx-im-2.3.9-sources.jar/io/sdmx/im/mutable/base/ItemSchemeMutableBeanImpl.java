package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;

public abstract class ItemSchemeMutableBeanImpl<T extends ItemMutableBean> extends MaintainableMutableBeanImpl implements ItemSchemeMutableBean<T> {
	private static final long serialVersionUID = 21L;

	protected List<T> items = new ArrayList<>();
	protected boolean isPartial;
	private boolean wasConstructedFromTimeRequest = false;

	@SuppressWarnings("rawtypes")
	public ItemSchemeMutableBeanImpl(ItemSchemeBean bean) {
		super(bean);
		this.isPartial = bean.isPartial();
	}

	public ItemSchemeMutableBeanImpl(SDMX_STRUCTURE_TYPE structureType) {
		super(structureType);
	}

	protected void ensureItemsNotNull() {
		if(this.items == null) {
			this.items = new ArrayList<>();
		}
	}
	
	@Override
	public boolean isPartial() {
		return isPartial;
	}

	@Override
	public void setPartial(boolean isPartial) {
		this.isPartial = isPartial;
	}

	@Override
	public List<T> getItems() {
		return items;
	}

	@Override
	public T getItemById(String id) {
		for(T currentItem: items) {
			if(currentItem.getId().equals(id)) {
				return currentItem;
			}
		}
		return null;
	}

	@Override
	public MaintainableMutableBean createPartialList(Set<String> itemSet, boolean keep, ITEM_FILTER_ACTION filterAction) {
		return createPartial(itemSet, keep, false, filterAction);
	}

	@Override
	public MaintainableMutableBean createPartialByUrn(Set<String> urns, boolean keep, ITEM_FILTER_ACTION filterAction) {
		return createPartial(urns, keep, true, filterAction);
	}

	protected MaintainableMutableBean createPartial(Set<String> itemSet, boolean keep, boolean isUrn, ITEM_FILTER_ACTION filterAction) {
		if(itemSet == null) {
			itemSet = new HashSet<>();
		}
		Map<String, T> map = new HashMap<>();
		int sizeStart = items.size();
		for(T currentItem : items) {
			map.put(isUrn ? currentItem.getUrn() : currentItem.getId(), currentItem);
		}
		if(keep) {
			map.keySet().retainAll(itemSet);
		} else {
			map.keySet().removeAll(itemSet);
		}
		//Retain Order
		List<T> newItems = new ArrayList<>();
		for(T currentItem : items) {
			if(map.containsKey(isUrn ? currentItem.getUrn() : currentItem.getId())) {
				newItems.add(currentItem);
			}
		}

		items = newItems;
		if(this.isPartial == false) {
			this.isPartial = items.size() < sizeStart;
		}
		return this;
	}


	@Override
	public ItemSchemeMutableBean<T> stripItems(Date aDate) {
		if (this.items.isEmpty()) {
			return this;
		}
		if (!(this.items.get(0) instanceof ValidityPeriodMutableBean)) {
			return this;
		}

		ArrayList<T> retVal = new ArrayList<>();
		for (T item: this.items) {
			ValidityPeriodMutableBean itemCast = (ValidityPeriodMutableBean) item;
			if (itemCast.hasValidityPeriod()) {
			    Optional<SdmxPeriod> itemSdmxPeriod = itemCast.getSdmxPeriod();
			    if (itemSdmxPeriod.isPresent() && itemSdmxPeriod.get().isInPeriod(aDate)) {
    				retVal.add(item);
    			}
			} else {
				retVal.add(item);
			}
		}

		this.wasConstructedFromTimeRequest = true;

		this.items = retVal;
		return this;
	}

	@Override
	public T createItem(String id, String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeItem(String id) {
		if(items != null && id != null) {
			T item = null;
			for(T currentItem : items) {
				if(currentItem.getId().equals(id)) {
					item = currentItem;
					break;
				}
			}

			if(item != null) {
				return items.remove(item);
			}
		}
		return false;
	}

	@Override
	public void setItems(List<T> list) {
		this.items = list;
	}

	@Override
	public void addItem(T item) {
		if(items == null) {
			this.items = new ArrayList<>();
		}
		items.add(item);
	}

	@Override
	public void addItemAtPosition(T item, int pos) {
		if(items == null) {
			this.items = new ArrayList<>();
		}
		if(pos > items.size()) {
			items.add(item);
		}else {
			items.add(pos, item);
		}
	}



	@Override
	public Set<MutableBean> getComposites() {
	    Set<MutableBean> composites = super.getComposites();
	    super.addToCompositeSet(items, composites);
	    return composites;
	}

	@Override
	public boolean createdFromTimeRequest() {
		return wasConstructedFromTimeRequest;
	}
}