package io.sdmx.im.mutable.base;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;

public class DataSourceMutableBeanImpl extends MutableBeanImpl implements DataSourceMutableBean {
	private static final long serialVersionUID = 1L;
	private String dataUrl;
	private String wsdlUrl;
	private String wadlUrl;
	private boolean isRestDatasource;
	private boolean isSimpleDatasource;
	private boolean isWebServiceDatasource;
	
	public DataSourceMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.DATASOURCE);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataSourceMutableBeanImpl(DataSourceBean datasourceBean, MutableBean parent) {
		super(datasourceBean, parent);
		if(datasourceBean.getDataUrl() != null) {
			this.dataUrl = datasourceBean.getDataUrl().toString();
		}
		if(datasourceBean.getWSDLUrl() != null) {
			this.wsdlUrl = datasourceBean.getWSDLUrl().toString();
		}
		if(datasourceBean.getWadlUrl() != null) {
			this.wadlUrl = datasourceBean.getWadlUrl().toString();
		}
		this.isRestDatasource = datasourceBean.isRESTDatasource();
		this.isSimpleDatasource = datasourceBean.isSimpleDatasource();
		this.isWebServiceDatasource = datasourceBean.isWebServiceDatasource();
	}
	
	@Override
	public String getDataUrl() {
		return dataUrl;
	}
	
	@Override
	public void setDataUrl(String dataUrl) {
		this.dataUrl = dataUrl;
	}
	
	@Override
	public String getWSDLUrl() {
		return wsdlUrl;
	}
		
	@Override
	public String getWADLUrl() {
		return wadlUrl;
	}

	@Override
	public void setWADLUrl(String wadlUrl) {
		this.wadlUrl = wadlUrl;
	}

	@Override
	public void setWSDLUrl(String wsdlUrl) {
		this.wsdlUrl = wsdlUrl;
	}
	
	@Override
	public boolean isRESTDatasource() {
		return isRestDatasource;
	}
	
	@Override
	public void setRESTDatasource(boolean isRestDatasource) {
		this.isRestDatasource = isRestDatasource;
	}
	
	@Override
	public boolean isSimpleDatasource() {
		return isSimpleDatasource;
	}
	
	@Override
	public void setSimpleDatasource(boolean isSimpleDatasource) {
		this.isSimpleDatasource = isSimpleDatasource;
	}
	
	@Override
	public boolean isWebServiceDatasource() {
		return isWebServiceDatasource;
	}
	
	@Override
	public void setWebServiceDatasource(boolean isWebServiceDatasource) {
		this.isWebServiceDatasource = isWebServiceDatasource;
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		return super.getComposites();
	}
}