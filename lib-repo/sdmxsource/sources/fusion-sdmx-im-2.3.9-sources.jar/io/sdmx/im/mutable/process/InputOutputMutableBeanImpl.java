package io.sdmx.im.mutable.process;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.im.mutable.base.AnnotableMutableBeanImpl;

public class InputOutputMutableBeanImpl extends AnnotableMutableBeanImpl implements InputOutputMutableBean {
	private static final long serialVersionUID = 1L;
	
	private String localId;
	private StructureReferenceBean structureReference;

	public InputOutputMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.INPUT_OUTPUT);
	}

	public InputOutputMutableBeanImpl(InputOutputBean bean, MutableBean parent) {
		super(bean, parent);
		this.localId = bean.getLocalId();
		if(bean.getStructureReference() != null) {
			this.structureReference = bean.getStructureReference().asMutable();
		}
	}

	@Override
	public String getLocalId() {
		return localId;
	}

	@Override
	public void setLocalId(String localId) {
		this.localId = localId;
	}

	@Override
	public StructureReferenceBean getStructureReference() {
		return structureReference;
	}

	@Override
	public void setStructureReference(StructureReferenceBean structureReference) {
		this.structureReference = structureReference;
	}
	
	@Override
	public List<StructureReferenceBean> getStructureReferencesInternal() {
		List<StructureReferenceBean> returnSet = super.getStructureReferencesInternal();
	    if (structureReference != null) {
	        returnSet.add(structureReference);
	    }
	    return returnSet;
	}
}