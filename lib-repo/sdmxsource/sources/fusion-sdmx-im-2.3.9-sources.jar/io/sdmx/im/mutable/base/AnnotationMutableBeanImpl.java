package io.sdmx.im.mutable.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;

public class AnnotationMutableBeanImpl extends MutableBeanImpl implements AnnotationMutableBean {
	private static final long serialVersionUID = 1L;
	private String id;
	private String title;
	private String type;
	private String uri;
	private List<TextTypeWrapperMutableBean> text;
	private boolean dynamic;
	
	public AnnotationMutableBeanImpl() {
		super(SDMX_STRUCTURE_TYPE.ANNOTATION);
	}
	
	public AnnotationMutableBeanImpl(AnnotationBean annotation, MutableBean parent) {
		super(annotation, parent);
		this.id = annotation.getId();
		this.title = annotation.getTitle();
		this.type = annotation.getType();
		this.dynamic = annotation.isDynamic();
		if(annotation.getUri() != null) {
			this.uri = annotation.getUri().toString();
		}
		if(annotation.getText(true) != null) {
			text = new ArrayList<>();
			for (TextTypeWrapper currentTextType : annotation.getText(true)) {
				text.add(new TextTypeWrapperMutableBeanImpl(currentTextType, this));
			}
		}
	}
	
	/**
	 * Copy Constructor
	 */
	public AnnotationMutableBeanImpl(AnnotationMutableBean annotation) {
		super(SDMX_STRUCTURE_TYPE.ANNOTATION);
		this.id = annotation.getId();
		this.title = annotation.getTitle();
		this.type = annotation.getType();
		this.dynamic = annotation.isDynamic();
		if(annotation.getUri() != null) {
			this.uri = annotation.getUri().toString();
		}
		if(annotation.getText() != null) {
			text = new ArrayList<>();
			for (TextTypeWrapperMutableBean currentTextType : annotation.getText()) {
				text.add(new TextTypeWrapperMutableBeanImpl(currentTextType.getLocale(), currentTextType.getValue()));
			}
		}
	}
	
	@Override
	public String getId() {
		return id;
	}
	
	@Override
	public void setId(String value) {
		this.id = value;
	}
	
	@Override
	public String getUri() {
		return uri;
	}

	@Override
	public void setUri(String uri) {
		this.uri = uri;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public List<TextTypeWrapperMutableBean> getText() {
		return text;
	}

	@Override
	public void setText(List<TextTypeWrapperMutableBean> text) {
		this.text = text;
	}

	@Override
	public void addText(TextTypeWrapperMutableBean text) {
		if(this.text == null) {
			this.text = new ArrayList<>();
		}
		this.text.add(text);
	}
	
	@Override
	public void addText(String locale, String text) {
		if(this.text == null) {
			this.text = new ArrayList<>();
		}
		TextTypeWrapperMutableBean tt = new TextTypeWrapperMutableBeanImpl();
		tt.setLocale(locale);
		tt.setValue(text);
		this.text.add(tt);
	}
	
	@Override
	public Set<MutableBean> getComposites() {
		Set<MutableBean> composites = super.getComposites();
		super.addToCompositeSet(text, composites);
		return composites;
	}

	@Override
	public boolean isDynamic() {
		return this.dynamic;
	}

	@Override
	public void setDynamic(boolean dynamic) {
		this.dynamic = dynamic;
		
	}
}