package io.sdmx.im.diff;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.Diff;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.diff.ModificationAction;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class DiffReportImpl implements DiffReport {
	private Map<ModificationAction, SortedSet<Diff>> diffMap;
	private MaintainableBean source;
	private MaintainableBean target;
	private MaintainableBean originalTarget;


	private Set<String> propsToIgnore;


	public DiffReportImpl(MaintainableBean source, MaintainableBean target) {
		if(source == null) {
			throw new SdmxException("Diff Report requires a Source Maintainable");
		}
		if(target == null) {
			throw new SdmxException("Diff Report requires a Target Maintainable");
		}
		this.source = source;
		this.target = target;
		diffMap = new HashMap<>();
		for(ModificationAction mod : ModificationAction.values()) {
			diffMap.put(mod, new TreeSet<Diff>());
		}
		if(!target.getAgencyId().equals(source.getAgencyId()) || !target.getId().equals(source.getId())) {
			this.originalTarget = target;
			MaintainableMutableBean mutated = target.getMutableInstance();
			mutated.setAgencyId(source.getAgencyId());
			mutated.setId(source.getId());
			this.target =mutated.getImmutableInstance();
		}
		this.propsToIgnore = new HashSet<>();
	}

	public DiffReportImpl(MaintainableBean soruce, MaintainableBean target, Set<String> ignoreProps) {
		this.source = soruce;
		this.target = target;
		diffMap = new HashMap<>();
		for(ModificationAction mod : ModificationAction.values()) {
			diffMap.put(mod, new TreeSet<Diff>());
		}
		this.propsToIgnore = ignoreProps;
	}

	@Override
	public void addDiff(SDMXBean source, String property, Object sourceVal, Object targetVal) {
		if(propsToIgnore.contains(property)) {
			return;
		}
		String sourceStr = toString(sourceVal);
		String targetStr = toString(targetVal);


		IdentifiableBean identifiable = source.getParent(IdentifiableBean.class, true);
		IURNAbsolute<?> urn;
		if(originalTarget != null && identifiable.getMaintainableParent() == target) {
			IURNAbsolute<?> newUrn = identifiable.getURN();
			urn = URN.builder().maint(originalTarget).versionRef(newUrn.getVersion()).identifableId(newUrn.getFullIdentifiableId()).buildAbsolute();
		} else {
			urn = identifiable.getURN();
		}
		boolean isSourceIdentifiable = identifiable == source;
		Diff diff = new DiffImpl(urn, isSourceIdentifiable, property, sourceStr, targetStr);
		diffMap.get(diff.getModification()).add(diff);
	}

	private String toString(Object val) {
		if(val == null) {
			return null;
		}
		if(val instanceof NameableBean) {
			StringBuilder sb = new StringBuilder();
			NameableBean nameable = ((NameableBean)val);
			sb.append("<strong>Id</strong>: "+nameable.getId() + "<br/><strong>Name</strong>: "+ nameable.getName());
			if(nameable.getDescription() != null) {
				sb.append("<br/><strong>Description</strong>: "+nameable.getDescription());
			}
			return sb.toString();
		} else {
			return val.toString();
		}
	}

	@Override
	public SortedSet<Diff> getdifferences(ModificationAction modificationType) {
		return new TreeSet<>(diffMap.get(modificationType));
	}
	
	@Override
	public Set<Diff> getDifferences() {
		Set<Diff> returnSet = new HashSet<>();
		for(ModificationAction action : diffMap.keySet()) {
			returnSet.addAll(diffMap.get(action));
		}
		return returnSet;
	}

	@Override
	public MaintainableBean getSource() {
		return this.source;
	}

	@Override
	public MaintainableBean getTarget() {
		return this.target;
	}
}
