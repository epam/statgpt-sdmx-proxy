package io.sdmx.im.diff;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.diff.Diff;
import io.sdmx.api.sdmx.model.diff.ModificationAction;
import io.sdmx.utils.core.object.ObjectUtil;

public class DiffImpl implements Diff, Comparable<DiffImpl> {
	private IURNAbsolute<?> urn;
	private String property;
	private String sourceValue;
	private String targetValue;
	private ModificationAction modification;

	public DiffImpl(IURNAbsolute<?> structureReference, boolean isSourceIdentifiable, String property, String sourceValue, String targetValue) {
		this.urn = structureReference;
		this.property = property;
		this.sourceValue = sourceValue;
		this.targetValue = targetValue;
		if(isSourceIdentifiable == false || ObjectUtil.validObject(sourceValue, targetValue)) {
			modification = ModificationAction.EDIT;
		} else if(ObjectUtil.validObject(sourceValue)) {
			modification = ModificationAction.REMOVAL;
		} else {
			modification = ModificationAction.ADDITION;
		}
	}

	private int compareStrings(String str1, String str2) {
		if(str1 == null) {
			if(str2 != null) {
				return 1;
			}
			return 0;
		} else if(str2 == null) {
			return 0;
		}
		return str1.compareTo(str2);
	}

	@Override
	public IURNAbsolute<?> getURN() {
		return urn;
	}

	@Override
	public String getProperty() {
		return property;
	}

	@Override
	public String getSourceValue() {
		return sourceValue;
	}

	@Override
	public String getTargetValue() {
		return targetValue;
	}

	@Override
	public ModificationAction getModification() {
		return modification;
	}

	@Override
	public String toString() {
		return modification+","+urn.getURN()+","+property+","+sourceValue+","+targetValue;
	}

	@Override
	public int compareTo(DiffImpl that) {
		int returnVal = modification.compareTo(that.modification);
		if(returnVal == 0) {
			returnVal = urn.getURN().compareTo(that.getURN().getURN());
		}
		if(returnVal == 0) {
			returnVal = compareStrings(this.property, that.property);
		}
		if(returnVal == 0) {
			returnVal = compareStrings(this.sourceValue, that.sourceValue);
		}
		if(returnVal == 0) {
			returnVal = compareStrings(this.targetValue, that.targetValue);
		}
		return returnVal;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DiffImpl) {
			return ((DiffImpl)obj).toString().equals(this.toString());
		}
		return false;
	}


}
