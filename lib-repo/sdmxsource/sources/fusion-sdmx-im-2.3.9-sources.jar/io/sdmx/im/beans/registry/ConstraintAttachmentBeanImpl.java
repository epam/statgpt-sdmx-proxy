package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.DataAndMetadataSetReference;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.im.beans.base.DataSourceBeanImpl;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ConstraintAttachmentBeanImpl extends SdmxStructureBeanImpl implements ConstraintAttachmentBean {
	private static final long serialVersionUID = -156955733515629246L;
	private DataAndMetadataSetReference dataOrMetadataSetReference;
	private Set<IDirectCrossReferenceBean<?>> crossReference = new HashSet<>();
	private List<DataSourceBean> dataSources = new ArrayList<>();
	//FUNC Validation of ALL Constraints and This CrossRefence/DataSource Pair should be grouped

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConstraintAttachmentBeanImpl(ConstraintAttachmentMutableBean mutable, ConstraintBean constraint) {
		super(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT_ATTACHMENT, constraint);
		if(mutable.getStructureReference() != null) {
			for(StructureReferenceBean sRef : mutable.getStructureReference()) {
				this.crossReference.add(DirectCrossReferenceBean.build(constraint, "attachment", sRef, IdentifiableBean.class));
			}
		}
		if (ObjectUtil.validCollection(mutable.getDataSources())) {
			for (DataSourceMutableBean each : mutable.getDataSources())
				this.dataSources.add(new DataSourceBeanImpl(each, this));
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConstraintAttachmentBean that = (ConstraintAttachmentBean) bean;
			boolean returnVal = true;
			if(!ObjectUtil.equivalent(dataOrMetadataSetReference, that.getDataOrMetadataSetReference())) {
				returnVal = false;
			}
			if(!ObjectUtil.equivalentCollection(crossReference, that.getStructureReference())) {
				returnVal = false;
			}
			if(!super.equivalent(dataSources, that.getDataSources(), includeFinalProperties, "Datasource",  diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		SDMX_STRUCTURE_TYPE constrainingType = null;

		// Checking that there is at least something in this Attachment
		if (dataOrMetadataSetReference == null &&
				!(ObjectUtil.validCollection(crossReference)) &&
				!(ObjectUtil.validCollection(dataSources))) {
			throw new SdmxSemmanticException("The ContentConstraint doesn't have a Constraint Attachment defined");
		}
		
		// May not have more than one Data Provider for a Content Constraint
		if (ObjectUtil.validCollection(crossReference) && crossReference.size() > 1) {
			boolean foundDp = false;
			for (ICrossReferenceBean xsRef : crossReference) {
				if (xsRef.getMaintainableStructureType() == SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME) {
					if (foundDp) {
						throw new SdmxSemmanticException("A ContentConstraint may not have multiple Data Providers as Constraint Attachments. A maximum of 1 Data Provider per Constraint Attachment is defined by the SDMX schema.");
					}
					foundDp = true;
				}
			}
		}

		for(ICrossReferenceBean xsRef : crossReference) {
			//NOTE this is to get around the issue where a constraint is linked to a registration (which is not allowed)
			//But it is required for an application to know which registration is associated with which constraint.
			//In this case, allow the attachment, but *hide* it, i.e it should not be written out in SDMX, and ignored in validation
			if(xsRef.getTargetReference() == SDMX_STRUCTURE_TYPE.REGISTRATION) {
				continue;
			}
			if(constrainingType == null) {
				constrainingType = xsRef.getTargetReference();
			} else if(constrainingType != xsRef.getTargetReference()) {
				throw new SdmxSemmanticException("ContentConstraint's ConstraintAttachment may only reference structures of the same type, got '"+constrainingType+"' and '"+xsRef.getTargetReference()+"'");
			}
		}
		crossReference = Collections.unmodifiableSet(crossReference);
		dataSources = Collections.unmodifiableList(dataSources);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DataAndMetadataSetReference getDataOrMetadataSetReference() {
		return dataOrMetadataSetReference;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.addAll(crossReference);
	}

	@Override
	public Set<IDirectCrossReferenceBean<?>> getStructureReference() {
		return crossReference;
	}

	@Override
	public List<DataSourceBean> getDataSources() {
		return dataSources;
	}

	@Override
	public ConstraintAttachmentMutableBean createMutableInstance() {
		return new ContentConstraintAttachmentMutableBeanImpl(this, null);
	}
	

	@Override
	public SDMX_STRUCTURE_TYPE getAttachedStructure() {
		for(ICrossReferenceBean xsRef : getStructureReference()) {
			return xsRef.getTargetReference();
		}
		return null;
 	}

    @Override
	public String getKey() {
		return null;
	}

    
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(dataSources, composites);
		return composites;
	}
}
