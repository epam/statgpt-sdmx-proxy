package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.sdmx.structure.ValidationUtil;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimeComponentMapMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

/**
 * Defines the rules for mapping a Component whose value defines a point in time, but where the syntax of time does not match the SDMX specification, 
 * the exact rules for how the source value is formatted are defined in sub interfaces, which include {@link EpochMapBean} and {@link TimePatternMapBean} 
 */
public abstract class TimeComponentMapBean extends AnnotableBeanImpl implements ITimeComponentMapBean {
	private static final long serialVersionUID = 1L;
	private String sourceComponent;
	private String targetComponent;
	private String outputFrequencyId;
	private String outputFrequencyDimId;
	private PERIOD_POSITION periodResolution;

	protected TimeComponentMapBean(ITimeComponentMapMutableBean bean, IStructureMapBean parent) {
		super(bean, parent);
		this.sourceComponent = bean.getSourceComponent();
		this.targetComponent = bean.getTargetComponent();
		this.outputFrequencyId = bean.getOutputFrequencyId();
		this.outputFrequencyDimId = bean.getOutputFrequencyDimId();
		this.periodResolution = bean.getPeriodResolution();
		validate();
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(sourceComponent == null) {
			throw new SdmxSemmanticException("Missing Source Component from mapping");
		}
		if(targetComponent == null) {
			throw new SdmxSemmanticException("Missing Target Component from mapping");
		}
		this.sourceComponent = StringUtil.manualIntern(ValidationUtil.cleanAndValidateId(sourceComponent, false));
		this.targetComponent = StringUtil.manualIntern(ValidationUtil.cleanAndValidateId(targetComponent, false));
		if(ObjectUtil.validString(outputFrequencyId, outputFrequencyDimId)) {
			throw new SdmxSemmanticException("Output Frequency Id is mutually exclusive with Output Frequency Dimension");
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(ITimeComponentMapBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		boolean returnVal = true;
		if(!super.equivalent(sourceComponent, bean.getSourceComponent(), "Source Component", diffReport)) {
			returnVal = false;
		}
		if(!super.equivalent(targetComponent, bean.getTargetComponent(), "Target Component", diffReport)) {
			returnVal = false;
		}
		if(!super.equivalent(outputFrequencyId, bean.getOutputFrequencyId(), "Output Frequency Id", diffReport)) {
			returnVal = false;
		}
		if(!super.equivalent(outputFrequencyDimId, bean.getOutputFrequencyDimId(), "Output Frequency Dim Id", diffReport)) {
			returnVal = false;
		}
		if(!super.equivalent(periodResolution, bean.getPeriodResolution(), "Period Resolution", diffReport)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diffReport) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getSourceComponent() {
		return sourceComponent;
	}

	@Override
	public String getTargetComponent() {
		return targetComponent;
	}

	@Override
	public String getOutputFrequencyId() {
		return outputFrequencyId;
	}

	@Override
	public String getOutputFrequencyDimId() {
		return outputFrequencyDimId;
	}

	@Override
	public PERIOD_POSITION getPeriodResolution() {
		return periodResolution;
	}
}
