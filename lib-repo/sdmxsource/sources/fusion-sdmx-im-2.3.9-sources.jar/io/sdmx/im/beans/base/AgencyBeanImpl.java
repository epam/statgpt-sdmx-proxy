package io.sdmx.im.beans.base;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;

public class AgencyBeanImpl extends OrganisationBeanImpl implements AgencyBean {
	private static final long serialVersionUID = 3L;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public AgencyBeanImpl(AgencyMutableBean bean, AgencySchemeBean parent) {
		super(bean, parent);
	}

	@Override
	protected Class<?> getConcreteInterface() {
		return AgencyBean.class;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean != null && bean instanceof AgencyBean) {
			AgencyBean that = (AgencyBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(getFullId(), that.getFullId(), "Id", diffReport)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diffReport) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	protected void validateId(boolean startWithIntAllowed) {
		//Not allowed to start with an integer
		super.validateId(false);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	

	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<AgencyBean> getURN() {
		return (IURNAbsolute<AgencyBean>)super.getURN();
	}
	
	@Override
	public String getFullId() {
		AgencySchemeBean parent = getMaintainableParent();
		if(parent.isDefaultScheme()) {
			return this.getId();
		}
		return parent.getAgencyId() + "." + this.getId();
	}

	@Override
	public AgencySchemeBean getMaintainableParent() {
		return (AgencySchemeBean)super.getMaintainableParent();
	}

}
