package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;

public class ConceptMapBean extends ItemMapBean implements IConceptMapBean {
	private static final long serialVersionUID = 1L;

    public ConceptMapBean(IItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
	}
}
