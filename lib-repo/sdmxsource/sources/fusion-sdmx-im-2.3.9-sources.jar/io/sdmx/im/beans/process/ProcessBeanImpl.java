package io.sdmx.im.beans.process;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.process.ProcessMutableBeanImpl;

public class ProcessBeanImpl extends MaintainableBeanImpl implements ProcessBean {
	private static final Logger LOG = LoggerFactory.getLogger(ProcessBeanImpl.class);
	private static final long serialVersionUID = 183L;
	private List<ProcessStepBean> processSteps = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	ProcessBeanImpl(ProcessBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub ProcessBean Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ProcessBeanImpl(ProcessMutableBean processBean) {
		super(processBean);
		LOG.debug("Building ProcessBean from Mutable Bean");
		try {
			if (processBean.getProcessSteps() != null) {
				for(ProcessStepMutableBean processStep : processBean.getProcessSteps()) {
					processSteps.add(new ProcessStepBeanImpl(this, processStep));
				}
			}
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("ProcessBean Built " + this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ProcessBean that = (ProcessBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(processSteps, that.getProcessSteps(), includeFinalProperties, "Process Step", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		Set<String> processStepReferences = new HashSet<>();  //Process Step References
		Set<String> processStepIds = new HashSet<>();            //Process Step Ids

		populateProcessStepSets(processSteps, processStepIds, processStepReferences);
		if(!processStepIds.containsAll(processStepReferences)) {
			for(String currentReference : processStepReferences) {
				if(!processStepIds.contains(currentReference)) {
					throw new SdmxSemmanticException("Transition references non existent process step '"+currentReference+"'");
				}
			}
		}
	}

	private void populateProcessStepSets(List<ProcessStepBean> processSteps, Set<String> processStepIds, Set<String> processStepReferences) {
		for(ProcessStepBean processStep : processSteps) {
			for(TransitionBean transition : processStep.getTransitions()) {
				processStepReferences.add(transition.getTargetStep().getFullIdPath(false));
			}
			processStepIds.add(processStep.getFullIdPath(false));
			populateProcessStepSets(processStep.getProcessSteps(), processStepIds, processStepReferences);
		}
	}



	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ProcessBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ProcessBean> getURN() {
		return (IURNMaintainable<ProcessBean>) super.getURN();
	}
	
	@Override
	public ProcessBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ProcessBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}


	@Override
	public ProcessMutableBean getMutableInstance() {
		return new ProcessMutableBeanImpl(this);
	}

	@Override
	public List<ProcessStepBean> getProcessSteps() {
		return new ArrayList<>(processSteps);
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(processSteps, composites);
        return composites;
    }

    @Override
    public ProcessBeanDeferred toDeferred() {
        return new ProcessBeanDeferred(this);
    }
    
    @Override
    public ProcessBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ProcessBeanDeferred(getDeferredDefinition(), loader);
    }
}
