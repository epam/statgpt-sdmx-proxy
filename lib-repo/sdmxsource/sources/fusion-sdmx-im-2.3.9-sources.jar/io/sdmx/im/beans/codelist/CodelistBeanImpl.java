package io.sdmx.im.beans.codelist;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.mutable.codelist.CodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class CodelistBeanImpl extends ItemSchemeBeanImpl<CodeBean> implements CodelistBean {
    private static final long serialVersionUID = 3L;

    private transient int idMinLength = -1;
    private transient int idMaxLength = -1;
    private MAINT_VALIDITY_TYPE  validityType = MAINT_VALIDITY_TYPE.STANDARD;
    private boolean createdFromTimeRequest = false;

    private List<ICodelistInheritanceRuleBean> inheritenceRules;

    private transient List<CodeBean> rootCodes;
    private transient Map<String, List<CodeBean>> childCodes;
    private transient List<CodeBean> emptyList;

    private boolean isInherited;

    @Override
    public boolean createdFromTimeRequest() {
        return createdFromTimeRequest;
    }

    /**
     * Ensure transient values are set
     * @param in
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        idMinLength = -1;
        idMaxLength = -1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected CodelistBeanImpl(CodelistBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
        this.inheritenceRules = Collections.emptyList();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public CodelistBeanImpl(CodelistMutableBean codelist) {
        super(codelist);
        if (codelist.createdFromTimeRequest()) {
            this.createdFromTimeRequest = true;
        }
        this.isInherited = codelist.isInherited();
        this.validityType = codelist.getValidityType();
        try {
            if(codelist.getInheritenceRules() != null) {
                for(ICodelistInheritanceRuleMutableBean ir : codelist.getInheritenceRules()) {
                    if(this.inheritenceRules == null) {
                        this.inheritenceRules = new ArrayList<>();
                    }
                    this.inheritenceRules.add(new CodelistInheritanceRuleBean(ir, this));
                }
            }
            if(ObjectUtil.validCollection(codelist.getItems())) {
                int i = 1;
                for(CodeMutableBean code : codelist.getItems()) {
                    this.items.add(createItem(code, i));
                    i++;
                }
            }
        } catch(SdmxSemmanticException ex) {
            throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        } catch(Throwable th) {
            throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        }
        try {
            validate();
        } catch(SdmxSemmanticException ex) {
            throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        } catch(Throwable th) {
            throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        }
    }

    @Override
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
        super.populateDeferredBeanBuilder(builder);
        if(validityType != MAINT_VALIDITY_TYPE.STANDARD) {
            builder.property("VPType", validityType.toString());
        }
        if(isInherited) {
            builder.property("Inherited", true);
        }
    }

    @Override
    public CodelistBean removePrefix(String prefix) {
        CodelistMutableBean mutable = this.getMutableInstance();
        List<CodeMutableBean> toKeep = new ArrayList<>();
        for(CodeMutableBean codeMutable : mutable.getItems()) {
            if(codeMutable.getId().startsWith(prefix)) {
                codeMutable.setId(codeMutable.getId().substring(prefix.length()));
                toKeep.add(codeMutable);
            }
        }
        mutable.setItems(toKeep);
        return mutable.getImmutableInstance();
    }

    @Override
    /**
     * Prior to SDMX 3.0 extending Codelists was supports using the extends annotation
     * if these exist on the Codelist - use it, and remove it
     */
    protected void addAnnotation(AnnotableMutableBean mutable, AnnotationBean annotation) {
        if("EXTENDS".equals(annotation.getType())) {
            if(annotation.getUri() != null) {
                String urn = annotation.getUri().toString();
                if(urn.startsWith(SDMX_STRUCTURE_TYPE.CODE_LIST.getUrnPrefix())) {
                    CodelistMutableBean cl = (CodelistMutableBean)mutable;
                    ICodelistInheritanceRuleMutableBean clInher = new CodelistInheritanceRuleMutableBean();
                    clInher.setCodelistRef(new StructureReferenceBeanImpl(urn));
                    cl.addInheritenceRules(clInher);
                    return;
                }
            }
        }
        super.addAnnotation(mutable, annotation);
    }

    protected CodeBean createItem(CodeMutableBean codeMutable, int pos) {
        return new CodeBeanImpl(this, codeMutable, pos);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP VALIDATION						 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }

        if (bean.getStructureType() != this.getStructureType()) {
            return false;
        }
        boolean returnVal = true;
        CodelistBean that = (CodelistBean) bean;
        MAINT_VALIDITY_TYPE beanValidityType = ((CodelistBean)bean).getValidityType();
        if (beanValidityType != null) {
            boolean typeEquals = beanValidityType.equals(this.getValidityType());
            if (!typeEquals){
                return false;
            }
        }
        if(!super.equivalent(this.inheritenceRules, that.getInheritedCodelists(), includeFinalProperties, "Inheritence Rules", diff)) {
            returnVal = false;
        }

        return super.deepEqualsInternal((CodelistBean)bean, includeFinalProperties, "Code", diff) && returnVal;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected void validate() throws SdmxSemmanticException {
        setHasValidityPeriod();
        Set<String> urns = new HashSet<>();

        if(this.inheritenceRules == null) {
            this.inheritenceRules = Collections.emptyList();
        } else {
            this.inheritenceRules = Collections.unmodifiableList(inheritenceRules);
        }

        if (this.hasValidityPeriod() && this.itemsHasValidityPeriod()) {
            throw new SdmxSemmanticException("Validity Period has been specified at both the maintainable level and the item level. This is not permitted.");
        }

        Set<AnnotationBean> annotationsByType = this.getAnnotationsByType("FR_RESTRICT_ITEMS");
        Pattern restrictionPattern = null;
        if (annotationsByType.size() > 0) {
            AnnotationBean restrictionBean = annotationsByType.iterator().next();
            String restrictionRegEx = restrictionBean.getTitle();
            restrictionPattern = Pattern.compile(restrictionRegEx);
        }

        if(items != null) {
            if(isPartial() == false) {
                //CHECK FOR DUPLICATION OF URN & ILLEGAL PARENTING
                Map<CodeBean, Set<CodeBean>> parentChildMap = new HashMap<>();

                for(CodeBean code : items) {

                    // Check Item matches defined restriction
                    if (restrictionPattern != null) {
                        Matcher matcher = restrictionPattern.matcher(code.getId());
                        if (!matcher.matches()) {
                            throw new SdmxSemmanticException("Code with ID: " + code.getId() + " does not conform to the Regular Expression restriction: " + restrictionPattern.toString());
                        }
                    }

                    if (urns.contains(code.getUrn())) {
                        List<CodeBean> existingCodes = getAllItemsById(code.getId());
                        if (existingCodes.size() > 1) {
                            List<SdmxPeriod> codeValidityPeriods = new ArrayList<>();
                            for (CodeBean existingCode : existingCodes) {
                                codeValidityPeriods.add(existingCode.getValidityPeriod());
                                if (existingCode == code) {
                                    continue;
                                }
                                if (!existingCode.hasValidityPeriod() && !code.hasValidityPeriod()) {
                                    // No validity period has been specified for either
                                    String errorMsg = "Code '" + code.getUrn() + "' has been specified twice in the codelist!";
                                    throw new SdmxSemmanticException(errorMsg);
                                }
                                if (!existingCode.hasValidityPeriod()) {
                                    // Code has already been specified with a Validity Period. Cannot add a non-validity Period
                                    String errorMsg = "Unable to specify the Code '" + code.getUrn() + "' with and without a validity Period!";
                                    throw new SdmxSemmanticException(errorMsg);
                                }
                                if (!code.hasValidityPeriod()) {
                                    // Code has already been specified with a Validity Period. Cannot add a non-validity Period
                                    String errorMsg = "Unable to specify the Code '" + code.getUrn() + "' with and without a validity Period!";
                                    throw new SdmxSemmanticException(errorMsg);
                                }
                                if (code.deepEquals(existingCode, true)) {
                                    // Validity Periods are the same
                                    String errorMsg = "the Code '" + code.getUrn() + "' has been specified more than once with the same Validity Period!";
                                    throw new SdmxSemmanticException(errorMsg);
                                }
                            }


                            // Check for overlapping periods
                            // Sort this list so we can compare to the next in the list
                            Collections.sort(codeValidityPeriods);

                            for (int i=0; i < codeValidityPeriods.size()-1; i++) {
                                SdmxPeriod period1 = codeValidityPeriods.get(i);
                                SdmxPeriod period2 = codeValidityPeriods.get(i+1);
                                if (period1.isInPeriod(period2)) {
                                    String errorMsg = "Code '" + code.getUrn() + "' specifies a Validity Period which overlaps " +
                                            "an existing Validity Period for the same code. Overlapping Validity Periods are not permitted.";
                                    throw new SdmxSemmanticException(errorMsg);
                                }
                            }
                        }

                    } else {
                        urns.add(code.getUrn());
                    }

                    if(isPartial() == false) {
                        if(ObjectUtil.validString(code.getParentCode())) {
                            CodeBean parentCode = getCode(items, code.getParentCode());
                            Set<CodeBean> children;
                            if(parentChildMap.containsKey(parentCode)) {
                                children = parentChildMap.get(parentCode);
                            } else {
                                children = new HashSet<>();
                                parentChildMap.put(parentCode, children);
                            }
                            children.add(code);

                            //Check that the parent code is not directly or indirectly a child of the code it is parenting
                            recurseParentMap(parentChildMap.get(code), parentCode, parentChildMap);
                        }
                    }
                }
            }
            items = Collections.unmodifiableList(items);
        }
    }





    @Override
    protected void validateId(boolean startWithIntAllowed) {
        //Not allowed to start with an integer
        super.validateId(false);
    }




    @Override
    public Set<SDMXBean> getCompositesInternal() {
        Set<SDMXBean> composites = super.getCompositesInternal();
        composites.addAll(this.getInheritedCodelists());
        return composites;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS  							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Class<?> getConcreteInterface() {
        return CodelistBean.class;
    }

    /**
     * Override from {@link IdentifiableBean} to give specific types in generics
     */
    @Override
    public IURNMaintainable<CodelistBean> getURN() {
        return (IURNMaintainable<CodelistBean>)super.getURN();
    }

    @Override
    public CodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CodelistBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public CodelistBean cloneForDate(Date date) {
        return (CodelistBean)super.cloneForDate(date);
    }

    @Override
    public CodelistMutableBean getMutableInstance() {
        return new CodelistMutableBeanImpl(this);
    }

    @Override
    public boolean hasInherited() {
        return ObjectUtil.validCollection(getInheritedCodelists());
    }

    @Override
    public List<CodeBean> getRootCodes() {
        if(rootCodes == null) {
            List<CodeBean> codes = new ArrayList<>();
            for(CodeBean code : this.getItems()) {
                if(code.getParentCode() == null) {
                    codes.add(code);
                }
            }
            this.rootCodes = Collections.unmodifiableList(codes);
        }
        return rootCodes;
    }

    @Override
    public List<CodeBean> getChildren(String id) {
        if(childCodes == null) {
            Map<String, List<CodeBean>> childCodes = new HashMap<>();
            for(CodeBean code : this.getItems()) {
                List<CodeBean> children = childCodes.get(code.getParentCode());
                if(children == null) {
                    children = new ArrayList<>();
                    childCodes.put(code.getParentCode(), children);
                }
                children.add(code);
            }
            Set<String> distinctCodeIds = new HashSet<>(childCodes.keySet());
            for(String codeId : distinctCodeIds) {
                childCodes.put(codeId, Collections.unmodifiableList(childCodes.get(codeId)));
            }
            this.childCodes = Collections.unmodifiableMap(childCodes);
        }
        List<CodeBean> returnList = childCodes.get(id);
        if(returnList == null) {
            if(emptyList == null) {
                emptyList = Collections.unmodifiableList(new ArrayList<>());
            }
            returnList = emptyList;
        }
        return returnList;
    }


    @Override
    public int getCodeMinLength() {
        if(idMinLength < 1) {
            if (items.size() == 0) {
                return -1;
            }
            idMinLength = Integer.MAX_VALUE;
            for(CodeBean currentCode : items) {
                int codeLength = currentCode.getId().length();
                idMinLength = Math.min(idMinLength, codeLength);
            }
        }
        return idMinLength;
    }

    @Override
    public int getCodeMaxLength() {
        if(idMaxLength < 1) {
            if (items.size() == 0) {
                return -1;
            }
            for(CodeBean currentCode : items) {
                int codeLength = currentCode.getId().length();
                idMaxLength = Math.max(idMaxLength, codeLength);
            }
        }
        return idMaxLength;
    }

    @Override
    public MAINT_VALIDITY_TYPE getValidityType() {
        return this.validityType;
    }

    @Override
    public List<ICodelistInheritanceRuleBean> getInheritedCodelists() {
        return inheritenceRules;
    }

    /**
     * Recurses the map checking the children of each child, if one of the children is the parent code, then an exception is thrown
     * @param children
     * @param parentCode
     * @param parentChildMap
     */
    private void recurseParentMap(Set<CodeBean> children, CodeBean parentCode, Map<CodeBean, Set<CodeBean>> parentChildMap) {
        //If the child is also a parent
        if(children != null) {
            if(children.contains(parentCode)) {
                throw new SdmxSemmanticException(ExceptionCode.PARENT_RECURSIVE_LOOP, parentCode.getId());
            }
            for(CodeBean currentChild : children) {
                recurseParentMap(parentChildMap.get(currentChild), parentCode, parentChildMap);
            }
        }
    }

    private CodeBean getCode(List<CodeBean> codes, String id) {
        for(CodeBean currentCode : codes) {
            if(currentCode.getId().equals(id)) {
                return currentCode;
            }
        }
        throw new SdmxSemmanticException(ExceptionCode.CAN_NOT_RESOLVE_PARENT, id);
    }


    @Override
    public CodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return (CodelistBean)super.filterItems(filterIds, isKeepSet);
    }

    @Override
    public boolean isInherited() {
        return isInherited;
    }

    @Override
    public CodelistBean getRootCodelist() {
        if(!isInherited) {
            return null;
        }
        CodelistMutableBean mutable = this.getMutableInstance();
        mutable.setInherited(false);
        List<CodeMutableBean> codesToKeep = new ArrayList<>();
        mutable.getItems().forEach(e-> {
            if(!e.isInherited()) {
                codesToKeep.add(e);
            }
        });
        mutable.setItems(codesToKeep);
        return mutable.getImmutableInstance();
    }

    @Override
    public boolean isGeoCodelist() {
        return false;
    }

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        return new CodelistBeanDeferred(this);
    }
    
    @Override
    public CodelistBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new CodelistBeanDeferred(getDeferredDefinition(), loader);
    }
}
