package io.sdmx.im.beans.reporting;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionTextMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReportTemplateInstructionTextBeanImpl extends SDMXBeanImpl implements ReportTemplateInstructionTextBean {
	private static final long serialVersionUID = 1L;
	private String content;
	private int colWidth = 1;
	private int colHeight = 1;
	
	public ReportTemplateInstructionTextBeanImpl(ReportTemplateInstructionTextMutableBean mutableBean, ReportTemplateInstructionSheetBean parent) {
		super(mutableBean, parent);
		this.content = mutableBean.getContent();
		if(mutableBean.getColWidth() > 0) {
			this.colWidth = mutableBean.getColWidth();
		}
		if(mutableBean.getColHeight() > 0) {
			this.colHeight = mutableBean.getColHeight();
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(content)) {
			throw new SdmxSemmanticException("Reporting Template Instruction is missing content");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ReportTemplateInstructionTextBean that = (ReportTemplateInstructionTextBean) bean;
			boolean returnVal = true;
			
			if(!super.equivalent(this.getColHeight(), that.getColHeight(), "Height", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getColWidth(), that.getColWidth(), "Width",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getContent(), that.getContent(), "Content", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.EMPTY_SET;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	

	@Override
	public String getKey() {
		return null;
	}


	@Override
	public String getContent() {
		return content;
	}

	@Override
	public int getColWidth() {
		return colWidth;
	}

	@Override
	public int getColHeight() {
		return colHeight;
	}
}
