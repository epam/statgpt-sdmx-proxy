package io.sdmx.im.beans.mapping;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;

@Deprecated
/**
 * @deprecated use mapping.v3
 */
public class OrganisationSchemeMapBeanImpl extends GenericItemSchemeMapBean implements OrganisationSchemeMapBean {
	private static final long serialVersionUID = 31L;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public OrganisationSchemeMapBeanImpl(OrganisationSchemeMapMutableBean orgBean, StructureSetBean parent) {
		super(orgBean, SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME_MAP, parent);
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(this.sourceRef == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "OrganisationSchemeRef");
		}
		if(this.targetRef == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "TargetOrganisationSchemeRef");
		}
		if(this.items == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "OrganisationMap");		
		}
		this.items = Collections.unmodifiableList(this.items);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(bean.getStructureType() == this.getStructureType()) {
			OrganisationSchemeMapBean that = (OrganisationSchemeMapBean) bean;
			return super.deepEqualsInternal(that, includeFinalProperties, "OrganisationMap", diff) && returnVal;
		}
		return false;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return OrganisationSchemeMapBean.class;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {}
	
	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		StructureReferenceBean sourceScheme = this.getSourceRef();
		switch(sourceScheme.getMaintainableStructureType()) {
		case AGENCY_SCHEME : return SDMX_STRUCTURE_TYPE.AGENCY;
		case DATA_CONSUMER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_CONSUMER;
		case DATA_PROVIDER_SCHEME : return SDMX_STRUCTURE_TYPE.DATA_PROVIDER;
		case ORGANISATION_UNIT_SCHEME : return SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT;
		default: throw new SdmxNotImplementedException("OrganisationSchemeMap with target type of '"+sourceScheme.getMaintainableStructureType().getType()+"'");
		}
	}
}