package io.sdmx.im.beans.metadatastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.im.beans.base.ComponentBeanImpl;

public class MetadataAttributeBeanImpl extends ComponentBeanImpl implements MetadataAttributeBean {
	private static final long serialVersionUID = 244L;
	private List<MetadataAttributeBean> metadataAttributes = new ArrayList<>();
	private TERTIARY_BOOL presentational = TERTIARY_BOOL.FALSE;
	private int position;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	public MetadataAttributeBeanImpl(IdentifiableBean parent, MetadataAttributeMutableBean bean, int position) {
		super(bean, parent);
		try {
			this.position = position;
			if(bean.getMetadataAttributes() != null) {
				int pos = 1;
				for(MetadataAttributeMutableBean currentMa : bean.getMetadataAttributes()) {
					metadataAttributes.add(new MetadataAttributeBeanImpl(this, currentMa, pos));
					pos++;
				}
			}
			if(bean.getPresentational() != null && bean.getPresentational() == TERTIARY_BOOL.TRUE) {
				this.presentational = TERTIARY_BOOL.TRUE;
			}
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Error creating structure: " + this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			MetadataAttributeBean that = (MetadataAttributeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(metadataAttributes, that.getMetadataAttributes(), includeFinalProperties, "Metadata Attribute", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(presentational, that.getPresentational(), "Is Presentational", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(position, that.getPosition(), "List Position", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(metadataAttributes != null) {
			Set<String> conceptIds = new HashSet<>();
			for(MetadataAttributeBean metadataAttribute : metadataAttributes) {
				if(metadataAttribute.getConceptRef() == null) {
					throw new SdmxSemmanticException("Metadata Attribute must reference a concept");
				}
				String ids = metadataAttribute.getId();
				if(conceptIds.contains(ids)) {
					throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_CONCEPT, metadataAttribute.toString());
				}
				conceptIds.add(ids);
			}
		}
		if(presentational.isTrue()) {
			if(getRepresentation() != null) {
				if(getRepresentation().getRepresentation() != null) {
					throw new SdmxSemmanticException("Metadata Attribute '"+getFullIdPath(false)+"' is presentational so can not have coded representation");
				}
				if(getRepresentation().getTextFormat() != null) {
					throw new SdmxSemmanticException("Metadata Attribute '"+getFullIdPath(false)+"' is presentational so can not define a Text Format");
				}
			}
		}
		if(getRepresentation() != null && getRepresentation().getTextFormat() != null) {
			TextFormatBean tf = getRepresentation().getTextFormat();
			if(tf.getMultiLingual().isTrue() ) {
				//Text Type must be String or XHTML
				TEXT_TYPE tt = tf.getTextType();
				if(tt == null || (tt != TEXT_TYPE.STRING && tt != TEXT_TYPE.XHTML)) {
					throw new SdmxSemmanticException("Metadata Attribtue '"+getFullIdPath(false)+"' can not be multilingual.  Text Type must be set to String or XHTML to support multilingual");
				}
			}
		}
		metadataAttributes = Collections.unmodifiableList(metadataAttributes);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return MetadataAttributeBean.class;
	}
	
	public IURNAbsolute<MetadataAttributeBean> getURN() {
		return (IURNAbsolute<MetadataAttributeBean>) super.getURN();
	}
	
	@Override
	public List<MetadataAttributeBean> getMetadataAttributes() {
		return metadataAttributes;
	}

	@Override
	public int getPosition() {
		return position;
	}

	@Override
	public TERTIARY_BOOL getPresentational() {
		return presentational;
	}
	
	@Override
	public COMPONENT_TYPE getType() {
		return COMPONENT_TYPE.METADATA_ATTRIBUE;
	}

	
	@Override
	public boolean isSimpleText() {
		if(hasCodedRepresentation()) {
			return true;
		}
		if(getRepresentation() != null && getRepresentation().getTextFormat() != null) {
			TextFormatBean tf = getRepresentation().getTextFormat();
			if(tf.getMultiLingual().isTrue() || isXHTML()) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public boolean isXHTML() {
		if(getRepresentation() != null && getRepresentation().getTextFormat() != null) {
			TextFormatBean tf = getRepresentation().getTextFormat();
			if(tf.getTextType() != null && tf.getTextType() == TEXT_TYPE.XHTML) {
				return true;
			}
		}
		return false;
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(metadataAttributes, composites);
		return composites;
	}
}
