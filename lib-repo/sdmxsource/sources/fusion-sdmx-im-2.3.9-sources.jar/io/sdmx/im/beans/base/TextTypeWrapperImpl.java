package io.sdmx.im.beans.base;

import java.util.HashSet;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class TextTypeWrapperImpl extends SDMXBeanImpl implements TextTypeWrapper {
	private static final long serialVersionUID = 1L;
	private String locale;
	private String value;
	private boolean isHtmlText;
	private transient String iso639Language = null;

	private String property;
	
	public TextTypeWrapperImpl(String locale, String value) {
		this(locale, value, null, null);
	}
	
	public TextTypeWrapperImpl(String locale, String value, SDMXBean parent) {
		this(locale, value, null, parent);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM VALUES BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	public TextTypeWrapperImpl(String locale, String value, String property,  SDMXBean parent) {
		super(parent);
		setLocale(locale);
		setValue(value);
		this.property = property;
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	public TextTypeWrapperImpl(TextTypeWrapperMutableBean textType, String property, SDMXBean parent) {
		super(textType, parent);
		setLocale(textType.getLocale());
		setValue(textType.getValue());
		this.property = property;
		validate();
	}

	private void setLocale(String locale) {
		if(!ObjectUtil.validString(locale)) {
			locale = "en";
		}
		//Bug fix, in XML Locale contains a '-' to be valid, in Java '_' is used
		locale = locale.replace("_", "-");
		this.locale = locale.toLowerCase();
	}

	boolean isValidLocale(String value) {
		return isValid(parseLocale(value));
	}
	private Locale parseLocale(String locale) {
		String[] parts = locale.split("-");
		switch (parts.length) {
		case 3: return new Locale(parts[0], parts[1], parts[2]);
		case 2: return new Locale(parts[0], parts[1]);
		case 1: return new Locale(parts[0]);
		default: throw new IllegalArgumentException("Invalid locale: " + locale);
		}
	}

	private boolean isValid(Locale locale) {
		try {
			return locale.getISO3Language() != null && locale.getISO3Country() != null;
		} catch (MissingResourceException e) {
			return false;
		}
	}

	private void setValue(String value) {
		if(value != null) {
//			if(!this.isHtmlText) {
//				ObjectUtil.validateSuspiciousStrings(value);
//			}
			this.value =  value.trim();
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof TextTypeWrapper) {
			TextTypeWrapper that = (TextTypeWrapper) bean;
			boolean returnVal = true;
			if(!super.equivalent(locale, that.getLocale(), property + " locale", diffReport)) {
				returnVal = false;
			}
			if(!super.equivalent(value, that.getValue(), property, diffReport)) {
				returnVal = false;
			}
			if(isHtmlText != that.isHtml()) {
				diffReport.addDiff(this, property + " HTML text", isHtmlText, that.isHtml());
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof TextTypeWrapper)  {
			return deepEquals((TextTypeWrapper)obj, true, null);
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(locale)) {
			//Default to english
			locale = Locale.ENGLISH.getLanguage();
		}
		if(!isValidLocale(locale)) {
			throw new SdmxSemmanticException("Illegal Locale: " +locale);
		}

		if(!ObjectUtil.validString(value)) {
			throw new SdmxSemmanticException("Text Type can not have an empty string value");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public String getLocale() {
		return locale;
	}
	
	@Override
	public String getStructureName() {
		return TextTypeWrapper.name;
	}

	@Override
	public String getISO639Language() {
		if(iso639Language == null) {
			iso639Language = new Locale(locale).getLanguage();
		}
		return iso639Language;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public boolean isHtml() {
		return isHtmlText;
	}
	
	@Override
	public String getKey() {
		return getLocale();
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES                           //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	


	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}
	
	@Override
	public String toString() {
		return this.getLocale() + ":" + this.getValue();
	}
}
