package io.sdmx.im.beans.transformation;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class NamePersonalisationSchemeBeanDeferred extends ItemSchemeBeanDeffered<INamePersonalisationBean, INamePersonalisationSchemeBean> implements INamePersonalisationSchemeBean {
    private static final long serialVersionUID = 1L;

    public NamePersonalisationSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public NamePersonalisationSchemeBeanDeferred(INamePersonalisationSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public INamePersonalisationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new NamePersonalisationSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected NamePersonalisationSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new NamePersonalisationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<INamePersonalisationSchemeBean> getURN() {
        return (IURNMaintainable<INamePersonalisationSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return INamePersonalisationSchemeBean.class;
    }
    
    @Override
    public INamePersonalisationSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public String getVtlVersion() {
        return load().getVtlVersion();
    }
}
