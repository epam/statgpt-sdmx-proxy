package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.OrganisationSchemeMapMutableBean;

public class OrganisationSchemeMapBean extends GenericItemSchemeMapBean<IOrganisationMapBean> implements IOrganisationSchemeMapBean {
	private static final long serialVersionUID = 12L;

	/**
	 * Stub constructor
	 */
	OrganisationSchemeMapBean(IOrganisationSchemeMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public OrganisationSchemeMapBean(IOrganisationSchemeMapMutableBean bean) {
		super(bean);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IOrganisationSchemeMapBean.class;
	}
	
	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.ORGANISATION;
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new OrganisationSchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public OrganisationSchemeMapMutableBean getMutableInstance() {
		return new OrganisationSchemeMapMutableBean(this);
	}

	@Override
	protected IOrganisationMapBean buildItemMap(IItemMapMutableBean mutable) {
		return new OrganisationMapBean(mutable, this);
	}

    @Override
    public OrganisationSchemeMapBeanDeferred toDeferred() {
        return new OrganisationSchemeMapBeanDeferred(this);
    }
    
    @Override
    public OrganisationSchemeMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationSchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
