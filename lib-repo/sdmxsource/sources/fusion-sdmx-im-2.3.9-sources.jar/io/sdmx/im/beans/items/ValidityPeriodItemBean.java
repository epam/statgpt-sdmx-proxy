package io.sdmx.im.beans.items;

import java.io.IOException;
import java.util.Date;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;

public abstract class ValidityPeriodItemBean extends ItemBeanImpl implements ValidityPeriodBean {
	private static final long serialVersionUID = -34958951L;
	private SdmxPeriod validityPeriod;
	protected transient Date today = new Date();

	public ValidityPeriodItemBean(ItemMutableBean bean, IdentifiableBean parent, int position, SdmxPeriod validityPeriod) {
		super(bean, parent, position);
		this.validityPeriod = validityPeriod;
	}

	@Override
	public SdmxPeriod getValidityPeriod() {
		return validityPeriod;
	}

	@Override
	public boolean hasValidityPeriod() {
		return validityPeriod != null;
	}

	public boolean isItemValidForToday(){
		return this.hasValidityPeriod() ? this.getValidityPeriod().isInPeriod(today) : true;
	}

	@Override
	public String getKey() {
		String currentKey = super.getKey();
		if(!this.hasValidityPeriod()){
			return currentKey;
		}
		return currentKey+"-"+this.getValidityPeriod().toString();
	}

	protected boolean  deepEqualsInternal(ValidityPeriodBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(includeFinalProperties) {
			if(!super.equivalent(this.validityPeriod, bean.getValidityPeriod(), "Validity Period", diff)) {
				returnVal =  false;
			}
		}

		//TODO: check this
		if(bean instanceof ValidityPeriodItemBean){
			if(((ValidityPeriodItemBean) bean).isItemValidForToday() != this.isItemValidForToday()){
				returnVal = false;
			}
		}

		return super.deepEqualsInternal((ItemBean)bean, includeFinalProperties, diff) && returnVal;
	}

	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException{
		in.defaultReadObject();
		today = new Date();
	}
}
