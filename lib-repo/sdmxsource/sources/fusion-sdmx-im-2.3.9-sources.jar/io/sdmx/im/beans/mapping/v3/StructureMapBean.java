package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * Describes a mapping relationship between two Dataflows or data structures (DSDs).  Ultimately the mapping rules
 * are defined for the DSD, even if the structure map is in the context of a Dataflow.
 */
public class StructureMapBean extends MaintainableBeanImpl implements IStructureMapBean {
	private static final long serialVersionUID = 2L;
	private IDirectCrossReferenceBean<? extends IStructureMapRelatedBean> sourceRef;
	private IDirectCrossReferenceBean<? extends IStructureMapRelatedBean> targetRef;
	private IDirectCrossReferenceBean<IRepresentationMapBean> timeFormatMapping;
	private List<IComponentMapBean> componentMap = new ArrayList<>();
	private Map<String, String> fixedOutputs = new HashMap<>();
	private Map<String, String> fixedInputs = new HashMap<>();
	private List<ITimePatternMapBean> timePatternMap = new ArrayList<>();
	private List<IEpochMapBean> epochMap = new ArrayList<>();
	
	/**
	 * Stub constructor
	 */
	StructureMapBean(IStructureMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public StructureMapBean(IStructureMapMutableBean bean) {
		super(bean);
		if(bean.getSourceRef() != null) {
			this.sourceRef = DirectCrossReferenceBean.build(this, "source", bean.getSourceRef(), IStructureMapRelatedBean.class);
		}
		if(bean.getTargetRef() != null) {
			this.targetRef = DirectCrossReferenceBean.build(this, "target", bean.getTargetRef(), IStructureMapRelatedBean.class);
		}
		if(bean.getTimeFormatMapping() != null) {
			this.timeFormatMapping = DirectCrossReferenceBean.build(this, "timeformat", bean.getTimeFormatMapping(), IRepresentationMapBean.class);
		}
		if(bean.getComponentMaps() != null) {
			for(IComponentMapMutableBean map : bean.getComponentMaps()) {
				this.componentMap.add(new ComponentMapBean(map, this));
			}
		}
		if(bean.getTimePatternMaps() != null) {
			for(ITimePatternMapMutableBean map : bean.getTimePatternMaps()) {
				this.timePatternMap.add(new TimePatternMapBean(map, this));
			}
		}
		if(bean.getEpochMap() != null) {
			for(IEpochMapMutableBean map : bean.getEpochMap()) {
				this.epochMap.add(new EpochMapBean(map, this));
			}
		}
		if(bean.getFixedOutputs() != null) {
			this.fixedOutputs.putAll(bean.getFixedOutputs());
		}
		if(bean.getFixedInputs() != null) {
			this.fixedInputs.putAll(bean.getFixedInputs());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!this.isExternalReference) {
			validateReference(sourceRef);
			validateReference(targetRef);
			if(sourceRef == null) {
				throw new SdmxSemmanticException("Structure Map missing source structure reference");
			}
			if(targetRef == null) {
				throw new SdmxSemmanticException("Structure Map missing target structure reference");
			}
			if(sourceRef.getTargetReference() != targetRef.getTargetReference()) {
				throw new SdmxSemmanticException("Source and target must both reference the same structure type");
			}
			if(timeFormatMapping != null) {
				if(timeFormatMapping.getTargetReference() != SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP) {
					throw new SdmxSemmanticException("Illegal reference to '"+timeFormatMapping.getTargetReference()+"'.  Reference expected to either a Codelist or Valuemap");
				}
			}
		}
		this.componentMap = Collections.unmodifiableList(componentMap);
		this.timePatternMap = Collections.unmodifiableList(timePatternMap);
		this.epochMap = Collections.unmodifiableList(epochMap);
		this.fixedOutputs = Collections.unmodifiableMap(fixedOutputs);
		this.fixedInputs = Collections.unmodifiableMap(fixedInputs);
	}

	private void validateReference(ICrossReferenceBean ref) {
		if(ref != null) {
			switch(ref.getTargetReference()) {
			case DATAFLOW :
			case DSD :  //OK
				break;
			default :
				throw new SdmxSemmanticException("Illegal reference to '"+ref.getTargetUrn()+"'.  Reference expected to either a Dataflow or DSD");
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IStructureMapBean that = (IStructureMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(sourceRef, that.getSourceRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetRef, that.getTargetRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(timeFormatMapping, that.getTimeFormatMapping(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.componentMap, that.getComponentMaps(), includeFinalProperties, Properties.MAPPED_COMPONENTS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.timePatternMap, that.getTimePatternMaps(), includeFinalProperties, Properties.MAPPED_TIME_PATTERNS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.epochMap, that.getEpochMap(), includeFinalProperties, Properties.MAPPED_EPOCHS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalentMap(bean, this.getFixedOutputs(), that.getFixedOutputs(), Properties.FIXED_OUTPUTS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalentMap(bean, this.getFixedInputs(), that.getFixedInputs(), Properties.FIXED_INPUTS.getProperty(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////REFERENCES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(sourceRef != null) {
			references.add(sourceRef);
		}
		if(targetRef != null) {
			references.add(targetRef);
		}
		if(timeFormatMapping != null) {
			references.add(timeFormatMapping);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(componentMap, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IStructureMapBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<IStructureMapBean> getURN() {
		return (IURNMaintainable<IStructureMapBean>)super.getURN();
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new StructureMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IStructureMapMutableBean getMutableInstance() {
		return  new StructureMapMutableBean(this);
	}

	@Override
	public ICrossReferenceBean<? extends IStructureMapRelatedBean> getSourceRef() {
		return sourceRef;
	}

	@Override
	public ICrossReferenceBean<? extends IStructureMapRelatedBean> getTargetRef() {
		return targetRef;
	}

	@Override
	public List<IComponentMapBean> getComponentMaps() {
		return componentMap;
	}

	@Override
	public List<ITimePatternMapBean> getTimePatternMaps() {
		return timePatternMap;
	}

	@Override
	public List<IEpochMapBean> getEpochMap() {
		return epochMap;
	}

	@Override
	public ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping() {
		return timeFormatMapping;
	}

	@Override
	public Map<String, String> getFixedOutputs() {
		return fixedOutputs;
	}

	@Override
	public Map<String, String> getFixedInputs() {
		return fixedInputs;
	}

    @Override
    public StructureMapBeanDeferred toDeferred() {
        return new StructureMapBeanDeferred(this);
    }
    
    @Override
    public StructureMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new StructureMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
