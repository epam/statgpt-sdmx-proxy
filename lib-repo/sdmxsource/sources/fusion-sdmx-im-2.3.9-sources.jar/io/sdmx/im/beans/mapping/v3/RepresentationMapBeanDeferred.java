package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class RepresentationMapBeanDeferred extends MaintainableBeanDeferred<IRepresentationMapBean> implements IRepresentationMapBean {
    private static final long serialVersionUID = 1L;

    public RepresentationMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public RepresentationMapBeanDeferred(IRepresentationMapBean maint) {
        super(maint);
    }
    
    @Override
    public IRepresentationMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new RepresentationMapBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected RepresentationMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new RepresentationMapBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IRepresentationMapBean> getURN() {
        return (IURNMaintainable<IRepresentationMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IRepresentationMapBean.class;
    }

    @Override
    public IRepresentationMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<IRepresentationMapRefBean> getSourceRef() {
        return load().getSourceRef();
    }

    @Override
    public List<IRepresentationMapRefBean> getTargetRef() {
        return load().getTargetRef();
    }

    @Override
    public List<IMappedRelationshipBean> getMappedValues() {
        return load().getMappedValues();
    }
}
