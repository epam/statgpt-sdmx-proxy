package io.sdmx.im.beans.base;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public abstract class AnnotableBeanImpl extends SdmxStructureBeanImpl implements AnnotableBean {
	private static final long serialVersionUID = 12L;
	private List<AnnotationBean> annotations = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	protected AnnotableBeanImpl(AnnotableBean bean, boolean completeStub) {
		//DO NOTHING
		super(bean);
		if(completeStub) {
			try {
				ThreadLocalUtil.storeOnThread(AnnotableBean.INCLUDE_INTERNAL_KEY, Boolean.TRUE);
				this.annotations = bean.getAnnotations();
			} finally {
				ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
			}
		}
	}
	
	protected AnnotableBeanImpl(SDMX_STRUCTURE_TYPE structureType, SdmxStructureBean parent) {
		super(structureType, parent);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	protected AnnotableBeanImpl(AnnotableMutableBean mutableBean, SdmxStructureBean parent) {
		super(mutableBean, parent);
		if(mutableBean != null && mutableBean.getAnnotations() != null) {
			addAnnotations(mutableBean, mutableBean.getAnnotations());
		}
	}

	void addAnnotations(AnnotableMutableBean mutable, Collection<AnnotationMutableBean> annotations) {
		this.addAnnotations(mutable, annotations, false);
	}
	/**
	 * Adds an annotation, can only be called from within this package
	 * @param annotation
	 */
	void addAnnotations(AnnotableMutableBean mutable, Collection<AnnotationMutableBean> annotations, boolean isDynamic) {
		for(AnnotationMutableBean annotation : annotations) {
			addAnnotation(mutable, new AnnotationBeanImpl(annotation, this));
		}
	}

	protected void addAnnotation(AnnotableMutableBean mutable, AnnotationBean annotation) {
		this.annotations.add(annotation);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(AnnotableBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(includeFinalProperties) {
			Object obj = ThreadLocalUtil.retrieveFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
			try {
				ThreadLocalUtil.storeOnThread(AnnotableBean.INCLUDE_INTERNAL_KEY, Boolean.TRUE);
				List<AnnotationBean> thatAnnotations = bean.getAnnotations();
				if(!super.equivalent(annotations, thatAnnotations, includeFinalProperties, "Annotation", diffReport)) {
					return false;
				}
			} finally {
				ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
				if(obj != null) {
					ThreadLocalUtil.storeOnThread(AnnotableBean.INCLUDE_INTERNAL_KEY, obj);
				}
			}
		}
		return true;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(annotations, composites);
		return composites;
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public List<AnnotationBean> getAnnotations() {
		if(!ThreadLocalUtil.contains(AnnotableBean.INCLUDE_INTERNAL_KEY)) {
			if(annotations.size() > 0) {
				List<AnnotationBean> returnList = new ArrayList<>();
				for(AnnotationBean currentAnnotation : annotations) {
					if(!AnnotableBean.INTERNAL.contains(currentAnnotation.getTitle()) && !AnnotableBean.INTERNAL.contains(currentAnnotation.getType())) {
						returnList.add(currentAnnotation);
					}
				}
				return returnList;
			}
		}
		return new ArrayList<>(annotations);
	}

	@Override
	public boolean hasAnnotationType(String annoationType) {
		return getAnnotationsByType(annoationType).size() > 0;
	}

	@Override
	public Set<AnnotationBean> getAnnotationsByType(String type) {
		Set<AnnotationBean> returnSet = null;
		for(AnnotationBean currentAnnotation : annotations) {
			if(currentAnnotation.getType() != null && currentAnnotation.getType().equals(type)) {
				if(returnSet == null) {
					returnSet = new HashSet<>(annotations.size());
				}
				returnSet.add(currentAnnotation);
			}
		}
		if(returnSet == null) {
			return Collections.emptySet();
		}
		return returnSet;
	}
	@Override
	public Set<AnnotationBean> getAnnotationsByTitle(String title) {
		Set<AnnotationBean> returnSet = null;
		for(AnnotationBean currentAnnotation : annotations) {
			if(returnSet == null) {
				returnSet = new HashSet<>(annotations.size());
			}
			if(currentAnnotation.getTitle() != null && currentAnnotation.getTitle().equals(title)) {
				returnSet.add(currentAnnotation);
			}
		}
		if(returnSet == null) {
			return Collections.emptySet();
		}
		return returnSet;
	}
	
}
