package io.sdmx.im.beans.mapping;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.im.beans.base.TextFormatBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class RepresentationMapRefBeanImpl extends SdmxStructureBeanImpl implements RepresentationMapRefBean {
	private static final long serialVersionUID = 41L;

	private String codelistMapId;
	private TextFormatBean toTextFormat;
	private TO_VALUE toValueType;
	private Map<String, Set<String>> valueMappings = new LinkedHashMap<>();

	private transient CodelistMapBean codelistMapBean;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected RepresentationMapRefBeanImpl(RepresentationMapRefMutableBean ref, SdmxStructureBean parent) {
		super(ref, parent);
		if(ObjectUtil.validString(ref.getCodelistMapRef())) {
			this.codelistMapId = ref.getCodelistMapRef();
		}
		if(ref.getToTextFormat() != null) {
			this.toTextFormat = TextFormatBeanImpl.getInstance(ref.getToTextFormat(), this);
		}
		if(ref.getValueMappings() != null) {
			this.valueMappings = ref.getValueMappings();
		}
		toValueType = ref.getToValueType();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			RepresentationMapRefBean that = (RepresentationMapRefBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.getCodelistMap(), that.getCodelistMap(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(toValueType, that.getToValueType(), "To Value", diff)) {
				returnVal = false;
			}
			//if(!super.equivalentCollection(this, valueMappings.keySet(), that.getValueMappings().keySet(), "", diff)) {
			//	returnVal = false;
			//}
			if(!super.equivalent(this.valueMappings, that.getValueMappings(), "value mappings", diff)) {
				returnVal = false;
			}
		//	if(!super.equivalentCollection(this, valueMappings.values(), that.getValueMappings().values(), "", diff)) {
			//	return false;
			//}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(valueMappings != null && valueMappings.size() > 0) {
			for(String key : valueMappings.keySet()) {
				if(key == null) {
					throw new SdmxSemmanticException("RepresentationMapping  can not have null entry in ValueMap");
				}
				if(valueMappings.get(key) == null) {
					throw new SdmxSemmanticException("RepresentationMapping  can not have null value in ValueMap");
				}
				for(String s :  valueMappings.get(key)) {
					if(s == null) {
						throw new SdmxSemmanticException("RepresentationMapping  can not have null entry in ValueMap");
					}
				}
			}
		}

		createUnModifiable();
		if(codelistMapId == null && valueMappings.size() == 0 && toTextFormat == null) {
			throw new SdmxSemmanticException("RepresentationMapping requires either a codelistMap, ToTextFormat or ValueMap");
		}
		if(toTextFormat != null) {
			if(toValueType == null) {
				throw new SdmxSemmanticException("For RepresentationMapping, if using ToTextFormat ToValueType is also required");
			}
		}
		if(ObjectUtil.validString(codelistMapId)) {
			codelistMapBean = getMaintainableParent().getCodelistMap(codelistMapId);
			if(codelistMapBean == null) {
				ComponentMapBean parent = (ComponentMapBean)getParent();
				StructureMapBean sMap = (StructureMapBean)parent.getIdentifiableParent();

				String sMapId = sMap.getId();
				throw new SdmxSemmanticException("Structure Set defines Structure Map '"+sMapId+"' which maps '"+parent.getKey()+"'.  This mapping references a Codelist Map '"+codelistMapId+"' which does not exist");
			}
		}
	}

	private void createUnModifiable() {
		Map<String, Set<String>> copy = new LinkedHashMap<>();
		if(valueMappings == null) {
			valueMappings = new LinkedHashMap<>();
		}
		if(valueMappings != null) {
			for(String key : valueMappings.keySet()) {
				copy.put(key, Collections.unmodifiableSet(new TreeSet<>(valueMappings.get(key))));
			}
		}
		this.valueMappings = Collections.unmodifiableMap(copy);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
	public CodelistMapBean getCodelistMap() {
		if(codelistMapId != null && codelistMapBean == null) {
			//From Deserialization
			codelistMapBean = getMaintainableParent().getCodelistMap(codelistMapId);
		}
		return codelistMapBean;
	}

	@Override
	public StructureSetBean getMaintainableParent() {
		return (StructureSetBean)super.getMaintainableParent();
	}

	@Override
	public TextFormatBean getToTextFormat() {
		return toTextFormat;
	}

	@Override
	public TO_VALUE getToValueType() {
		return toValueType;
	}

	@Override
	public Map<String, Set<String>> getValueMappings() {
		return valueMappings;  //Unmodifiable Map
	}

    @Override
	public String getKey() {
		return null;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(toTextFormat, composites);
        return composites;
    }

	@Override
	public String toString() {
		ComponentMapBean parent = this.getParent(ComponentMapBean.class, false);
		return "Representation Map for '"+parent.getMapConceptRef()+"' to '"+parent.getMapTargetConceptRef()+"'";
	}
}
