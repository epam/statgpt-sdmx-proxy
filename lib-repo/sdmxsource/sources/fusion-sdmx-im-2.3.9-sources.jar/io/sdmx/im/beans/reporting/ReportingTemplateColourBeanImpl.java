package io.sdmx.im.beans.reporting;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateColourBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateColourMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.colour.ColourUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportingTemplateColourBeanImpl extends SDMXBeanImpl implements ReportingTemplateColourBean {
	private static final Logger LOG = LoggerFactory.getLogger(ReportingTemplateColourBeanImpl.class);
	private static final long serialVersionUID = 593707852406349599L;
	private String colourAttribute;
	private String defaultColour;
	private Map<String, String> colourCodes;
	private Map<Set<String>, String> seriesColours = new HashMap<>();

	public ReportingTemplateColourBeanImpl(ReportingTemplateColourMutableBean mutableBean, ReportingTemplateWorksheetBean parent) {
		super(mutableBean, parent);
		this.colourAttribute = mutableBean.getAttributeId();
		this.defaultColour = mutableBean.getDefaultColour();
		
		if(mutableBean.getColourCodes() != null) {
			this.colourCodes = new HashMap<>(mutableBean.getColourCodes());
		}
		if(mutableBean.getSeriesColours() != null) {
			Map<Set<String>, String> colours = mutableBean.getSeriesColours();
			for(Set<String> key : colours.keySet()) {
				if(key != null) {
					String colour = colours.get(key);
					if(colour == null) {
						throw new SdmxSemmanticException("Missing colour for seriesColours");
					}
					if(this.colourCodes.containsValue(colour)) {
						//FR 2408 Excel template outputs white cells - fix only add a colour to series mapping if it exists in the colour codes
						Set<String> keySet = Collections.unmodifiableSet(new HashSet<>(key));
						seriesColours.put(keySet, formatColourCode(colour));
					}
				}
			}
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(colourAttribute == null) {
			throw new SdmxSemmanticException("Reporting Template Worksheet is missing a Colour Attribute");
		}
		if(!ObjectUtil.validMap(colourCodes)) {
			throw new SdmxSemmanticException("Reporting Template Worksheet is missing a Colour Map");
		}
		Map<String, String> colourCodesFormatted = new HashMap<>();
		for(String colour : colourCodes.keySet()) {
			colourCodesFormatted.put(colour, formatColourCode(colourCodes.get(colour)));
		}
		this.colourCodes = Collections.unmodifiableMap(colourCodesFormatted);
		this.seriesColours = Collections.unmodifiableMap(seriesColours);
		this.defaultColour = formatColourCode(defaultColour);
		if(defaultColour != null && !colourCodes.containsValue(defaultColour)) {
			throw new SdmxSemmanticException("Default Colour '"+defaultColour+"' is not a mapped colour code");
		}
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	/**
	 * Returns upper case and ensures the it leads with a hash 
	 * @return
	 */
	private String formatColourCode(String colour) {
		if(colour == null) {
			return null;
		}
		if(!colour.startsWith("#")) {
			colour = "#"+colour;
		}
		colour = colour.toUpperCase();
		try {
			ColourUtil.hex2Rgb(colour);
		} catch(Throwable th) {
			LOG.error("Could not parse colour string '"+colour+"'", th);
			throw new SdmxSemmanticException("Colour '"+colour+"' is not valid.  Hex must start with a hash and be 6 characters long, e.g #C2C2C2");
		}
		return colour;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ReportingTemplateColourBean that = (ReportingTemplateColourBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.colourAttribute, that.getAttributeId(), "colour attribute", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.defaultColour, that.getDefaultColour(), "default colour", diff)) {
				returnVal = false;
			}
			if(!super.equivalentMap(this, this.colourCodes, that.getColourCodes(), "colour code", diff)) {
				returnVal = false;
			}
			
			Map<String, Set<String>> reversedThis = reverseMap(this.seriesColours);
			Map<String, Set<String>> reversedThat = reverseMap(that.getSeriesColours());
			if(!reversedThis.keySet().containsAll(reversedThat.keySet())) {
				return false;
			} 
			if(!reversedThat.keySet().containsAll(reversedThis.keySet())) {
				return false;
			}
			for(String thisKey : reversedThis.keySet()) {
				Set<String> thisSet = reversedThis.get(thisKey);
				Set<String> thatSet = reversedThat.get(thisKey);
				if(!ObjectUtil.equivalentSet(thisSet, thatSet)) {
					return false;
				}
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	private Map<String, Set<String>> reverseMap(Map<Set<String>, String> map) {
		Map<String, Set<String>> returnMap = new HashMap<>();
		for(Set<String> set : map.keySet()) {
			returnMap.put(map.get(set), set);
		}
		return returnMap;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public String getAttributeId() {
		return colourAttribute;
	}

	@Override
	public String getDefaultColour() {
		return defaultColour;
	}

	@Override
	public Map<String, String> getColourCodes() {
		return colourCodes;
	}

	@Override
	public Map<Set<String>, String> getSeriesColours() {
		return seriesColours;
	}

	@Override
	public String getKey() {
		return colourAttribute;
	}
}
