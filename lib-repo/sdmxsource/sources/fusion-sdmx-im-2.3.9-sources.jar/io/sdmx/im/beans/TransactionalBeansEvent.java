package io.sdmx.im.beans;

import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.im.beans.container.SdmxBeansImmutable;

public class TransactionalBeansEvent implements ITransactionalBeansEvent {
	private Integer transactionId;
	private SdmxBeans modifications;
	private SdmxBeans additions;
	private SdmxBeans deletions;
	
	public static TransactionalBeansEvent getDeletionEvents(Integer transactionId, SdmxBeans deletions) {
		return new TransactionalBeansEvent(transactionId, SdmxBeansImmutable.EMPTY_BEANS, SdmxBeansImmutable.EMPTY_BEANS, deletions);
	}
	
	public static TransactionalBeansEvent getModificationEvents(Integer transactionId, SdmxBeans additions, SdmxBeans modifications) {
		return new TransactionalBeansEvent(transactionId, additions, modifications, SdmxBeansImmutable.EMPTY_BEANS);
	}
	
	private TransactionalBeansEvent(Integer transactionId, SdmxBeans additions, SdmxBeans modifications, SdmxBeans deletions) {
		this.transactionId = transactionId;
		this.additions = additions;
		this.modifications = modifications;
		this.deletions = deletions;
	}

	@Override
	public Integer getTransactionId() {
		return transactionId;
	}

	@Override
	public SdmxBeans getModification() {
		return modifications;
	}

	@Override
	public SdmxBeans getAdditions() {
		return additions;
	}

	@Override
	public SdmxBeans getDeletions() {
		return deletions;
	}
}
