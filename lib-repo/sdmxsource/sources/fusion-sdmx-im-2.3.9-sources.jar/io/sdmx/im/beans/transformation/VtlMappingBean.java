package io.sdmx.im.beans.transformation;

import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public abstract class VtlMappingBean<T extends IdentifiableBean> extends ItemBeanImpl implements IVtlMappingBean<T> {
	private static final long serialVersionUID = 1L;
	private String alias;
	private IDirectCrossReferenceBean<T> mapped;
	
	public VtlMappingBean(IVtlMappingMutableBean bean, Class<T> mappedType, IdentifiableBean parent, int position) {
		super(bean, parent, position);
		this.alias = bean.getAlias();
		this.mapped = DirectCrossReferenceBean.build(this, "mapped", URN.builder(bean.getMapped().getTargetUrn()).buildSingle(mappedType));
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<? extends IVtlMappingBean> getURN() {
		return (IURNAbsolute<? extends IVtlMappingBean>) super.getURN();
	}

	@Override
	public String getAlias() {
		return alias;
	}

	@Override
	public ICrossReferenceBean getMapped() {
		return mapped;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(mapped != null) {
			references.add(mapped);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.alias == null) {
			throw new SdmxSemmanticException("Alias required for VTL Mapping");
		}
		if(this.mapped == null) {
			throw new SdmxSemmanticException("Mapping Reference for VTL Mapping");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(IVtlMappingBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(!super.equivalent(alias, bean.getAlias(), "Alias", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(mapped, bean.getMapped(), diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}
}
