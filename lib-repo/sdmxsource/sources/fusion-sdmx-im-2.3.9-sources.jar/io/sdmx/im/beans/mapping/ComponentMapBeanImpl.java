package io.sdmx.im.beans.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ComponentMapBeanImpl extends AnnotableBeanImpl implements ComponentMapBean {
	private static final long serialVersionUID = 14L;

	private List<String> mapConceptRef = new ArrayList<>();
	private List<String> mapTargetConceptRef = new ArrayList<>();
	private RepresentationMapRefBean repMapRef;
	private String key;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected ComponentMapBeanImpl(ComponentMapMutableBean compMap, SdmxStructureBean parent) {
		super(compMap, parent);
		if(compMap.getMapConceptRef() != null) {
			mapConceptRef = new ArrayList<>(compMap.getMapConceptRef());
		}
		if(compMap.getMapTargetConceptRef() != null) {
			mapTargetConceptRef = new ArrayList<>(compMap.getMapTargetConceptRef());
		}
		if(compMap.getRepMapRef() != null) {
			repMapRef = new RepresentationMapRefBeanImpl(compMap.getRepMapRef(), this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ComponentMapBean that = (ComponentMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalentCollection(this, mapConceptRef, that.getMapConceptRef(), "Source Concepts", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, mapTargetConceptRef, that.getMapTargetConceptRef(), "Target Concepts", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(repMapRef, that.getRepMapRef(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validObject(mapConceptRef)) {
			throw new SdmxSemmanticException("Component Map missing source component");
		}

		if(!ObjectUtil.validObject(mapTargetConceptRef)) {
			throw new SdmxSemmanticException("Component Map missing target component");
		}
		mapConceptRef = Collections.unmodifiableList(mapConceptRef);
		mapTargetConceptRef = Collections.unmodifiableList(mapTargetConceptRef);

		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(String concept : mapConceptRef) {
			sb.append(concat+ concept);
			concat = ":";
		}
		sb.append("-");
		concat = "";
		for(String concept : mapTargetConceptRef) {
			sb.append(concat + concept);			
			concat = ":";
		}
		this.key = sb.toString();
	}



	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<String> getMapConceptRef() {
		return mapConceptRef;
	}

	@Override
	public List<String> getMapTargetConceptRef() {
		return mapTargetConceptRef;
	}

	@Override
	public RepresentationMapRefBean getRepMapRef() {
		return repMapRef;
	}

	@Override
	public String getKey() {
		return this.key;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(repMapRef, composites);
		return composites;
	}
}
