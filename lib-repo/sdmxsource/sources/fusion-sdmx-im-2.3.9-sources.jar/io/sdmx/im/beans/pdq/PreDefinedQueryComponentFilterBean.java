package io.sdmx.im.beans.pdq;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryComponentFilterMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class PreDefinedQueryComponentFilterBean extends SDMXBeanImpl implements IPreDefinedQueryComponentFilterBean {
	private static final long serialVersionUID = 1L;
	private String componentId;
	private Map<MATCH_FUNCTION, Set<String>> filters = new TreeMap<>();
	private transient String asString = null;
	
	public PreDefinedQueryComponentFilterBean(IPreDefinedQueryComponentFilterMutableBean createdFrom, IPreDefinedQueryBean parent) {
		super(createdFrom, parent);
		this.componentId = createdFrom.getComponentId();
		
		if(createdFrom.getFilters() != null) {
			for(MATCH_FUNCTION match : createdFrom.getFilters().keySet()) {
				if(createdFrom.getFilters().get(match) != null) {
					Set<String> values = createdFrom.getFilters().get(match);
					if(!ObjectUtil.validCollection(values)) {
						continue;
					}
					if(match == null) {
						match = MATCH_FUNCTION.EQUALS;
					}
					filters.put(match, Collections.unmodifiableSet(new TreeSet<>(values)));
				}
			}
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(this.filters.size() == 0) {
			throw new SdmxSemmanticException("Predefined Query Filter must define at least 1 Filter Value");
		}
		this.filters = Collections.unmodifiableMap(this.filters);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IPreDefinedQueryComponentFilterBean that = (IPreDefinedQueryComponentFilterBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(componentId, that.getComponentId(), "Component ID", diff)) {
				returnVal =  false;
			}
			if(!super.equivalentMap(this, filters, that.getFilters(), "Filters", diff)) {
				returnVal =  false;
			}
			return returnVal;
		}
		return false;
	}

	
	@Override
	public String getKey() {
		return null;
//		return componentId;
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getComponentId() {
		return this.componentId;
	}

	@Override
	public Map<MATCH_FUNCTION, Set<String>> getFilters() {
		return filters;
	}

	@Override
	public String toString() {
		if(asString == null) {
			StringBuilder sb = new StringBuilder();
			sb.append(componentId+"=");
			for(MATCH_FUNCTION match : filters.keySet()) {
				sb.append(match.getFunction()+":");
				String concat = "";
				for(String matchVal : filters.get(match)) {
					sb.append(concat + matchVal);
					concat = ",";
				}
			}
			asString = sb.toString();
		}
		return asString;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof PreDefinedQueryComponentFilterBean) {
			PreDefinedQueryComponentFilterBean that = (PreDefinedQueryComponentFilterBean) obj;
			if(!that.getComponentId().equals(this.getComponentId())) {
				return false;
			}
			return ObjectUtil.equivalentMap(filters, filters);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	
}
