package io.sdmx.im.beans.calculation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleHierarchyBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;

public class ValidationRuleBeanImpl extends ItemBeanImpl implements ValidationRuleBean {
	private static final long serialVersionUID = 2L;
	private String resultant;
	private EQUALITY equality;
	private String expression;
	
	private ValidationRuleHierarchyBean hierarchy;
	private final Pattern PATTERN = Pattern.compile("\\[([^]]+)\\]", Pattern.DOTALL);
	
	private String expressionDeRef;  //
	private String resultSeries;   //If the result is a series
	private List<String> expressionSeries;   //If the result is a series
	private EXPRESSION_RESULT expResult;
	
	public ValidationRuleBeanImpl(ValidationRuleMutableBean bean, IdentifiableBean parent, int position) {
		super(bean, parent, position);
		this.expression = bean.getExpression();
		this.equality = bean.getEqualityOperator();
		this.resultant = bean.getResultant();
		if(bean.getHierarchyReference() != null) {
			this.hierarchy = new ValidationRuleHierarchyBeanImpl(bean.getHierarchyReference(), this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(expression == null && hierarchy == null) {
			throw new SdmxSemmanticException("Validation Rule must have either an Expression or a Hierarchy Reference");
		}
		if(hierarchy == null) {
			validateExpression();
		} 
	}
	
	/**
	 * Expression such as [A:::]=[A:::]+[B:::]-10
	 */
	private void validateExpression() {
		if(!ObjectUtil.validString(resultant)) {
			throw new SdmxSemmanticException("Validation Rule is missing the output of the expression");
		}
		if(!ObjectUtil.validString(expression)) {
			throw new SdmxSemmanticException("Validation Rule is missing an expression");
		}
		if(equality == null) {
			throw new SdmxSemmanticException("Validation Rule is missing an equality operator");
		}
		//Check result is of format [A:B:C] or numerical
		try {
			Double.parseDouble(resultant);
			expResult = EXPRESSION_RESULT.NUMBER;
		} catch(NumberFormatException e) {
			expResult = EXPRESSION_RESULT.SERIES;
		}
		
		Matcher m = PATTERN.matcher(expression);
		
		List<String> seriesUnCleaned = new ArrayList<>();
		expressionDeRef = expression;
		int ai = 0;
		while(m.find()) {
			for(int i = 0 ; i < m.groupCount(); i++) {
				String found = m.group(i);
				String replaced = found.replace("[", "");
				replaced = replaced.replace("]", "");
				seriesUnCleaned.add(replaced);
				String variable = "a"+ai;
				expressionDeRef = expressionDeRef.replaceFirst("\\["+replaced+"\\]", variable);
				ai++;
			}
		}
		
		//Clean and Verify the series always use IdType for each part
		this.expressionSeries = new ArrayList<>();
		int dimLength = -1;
		
		List<String[]> inputSeries = new ArrayList<>();
		for(String seriesFilter : seriesUnCleaned) {
			int i= 0;
			String[] filterSplit = seriesFilter.split(":");
			if(dimLength == -1) {
				dimLength = filterSplit.length;
			}
			if(dimLength != filterSplit.length) {
				throw new SdmxSemmanticException("Expression '"+expression+"' is not valid. All series filters must have the same key length. Series filter differs in key length '"+seriesFilter+"' ");
			}
			for(String codeId : filterSplit) {
				if(codeId.length() == 0 || codeId.equals("*")) {
					codeId = "";
				}
				if(codeId.length() > 0) {
					try {
						codeId = ValidationUtil.cleanAndValidateId(codeId, true);
					} catch(Throwable th) {
						throw new SdmxSemmanticException("Expression '"+expression+"' is not valid.  '"+codeId+"' is not a valid code id in series filter '"+seriesFilter+"' ");
					}
				}
				filterSplit[i] = codeId;
				i++;
			}
			String updated = SeriesUtil.toSeriesKey(filterSplit);
			inputSeries.add(filterSplit);
			expressionSeries.add(updated);
		}
		this.expressionSeries = Collections.unmodifiableList(this.expressionSeries);
//		if(true) {
//			return;
//		}
		if(expResult == EXPRESSION_RESULT.SERIES) { //TODO in the future we need to account for storing results in varaibles
			if(!resultant.startsWith("[")) {
				throw new SdmxSemmanticException("Result must either be a number or a series matcher in the format [A:UK::T]");
			} 
			if(!resultant.endsWith("]")) {
				throw new SdmxSemmanticException("Series matcher must end in ']' for example [A:UK::T]");
			}
			String replaced = resultant.replaceFirst("\\[", "");
			replaced = replaced.substring(0, replaced.length()-1); //Remove final ']'
			String[] resultSplit = replaced.split(":");
			int i= 0;
			for(String codeId : resultSplit) {
				if(codeId.length() == 0 || codeId.equals("*")) {
					codeId = "";
				}
				if(codeId.length() > 0) {
					try {
						codeId = ValidationUtil.cleanAndValidateId(codeId, true);
					} catch(Throwable th) {
						throw new SdmxSemmanticException("Result expression '"+resultant+"' is not valid.  '"+codeId+"' is not a valid code id.  Format must be [A:UK::T]");
					}
				}
				resultSplit[i] = codeId;
				if(codeId == null) {
					//Check all the input equations also wildcard at the same position
					for(String[] currentInputSeries : inputSeries) {
						if(ObjectUtil.validString(currentInputSeries[i])) {
							throw new SdmxSemmanticException("Result expression '"+resultant+"' contains a wildcarded key component at position '"+i+"'.  "
									+ "This wildcard must also be balanced by series matcher '"+SeriesUtil.toSeriesKey(currentInputSeries)+" in expression '"+this.expression+"' ");
						}
					}
				}
				i++;
			}
			this.resultSeries = SeriesUtil.toSeriesKey(resultSplit);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ValidationRuleBean that = (ValidationRuleBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.expression, that.getExpression(), "Expression", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.resultant, that.getResultant(), "Resultant", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.equality, that.getEqualityOperator(), "Equality Operator", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.hierarchy, that.getValidationHierarchy(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ValidationRuleBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<ValidationRuleBean> getURN() {
		return (IURNAbsolute<ValidationRuleBean>) super.getURN();
	}

	@Override
	public String getExpression() {
		return expression;
	}

	@Override
	public boolean hasExpression() {
		return expression != null;
	}

	@Override
	public String getResultant() {
		return resultant;
	}

	@Override
	public EQUALITY getEqualityOperator() {
		return equality;
	}

	@Override
	public ValidationRuleHierarchyBean getValidationHierarchy() {
		return hierarchy;
	}

	@Override
	public boolean hasValidationHierarchy() {
		return getValidationHierarchy() != null;
	}
	
	///GENERATED ON CONSTRUCTION
	@Override
	public String getExpressionDeReferenced(String... replacements) {
		if(replacements != null) {
			String returnString = expressionDeRef;
			for(int i=0; i < replacements.length; i++) {
				returnString = returnString.replace("a"+i, replacements[i]);
			}
			return returnString;
		}
		return expressionDeRef;
	}

	@Override
	public List<String> getExpressionSeries() {
		return expressionSeries;
	}

	@Override
	public String getOutputSeries() {
		return resultSeries;
	}

	@Override
	public EXPRESSION_RESULT getResultType() {
		return expResult;
	}
	

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites =  super.getCompositesInternal();
		if(hierarchy != null) {
			composites.add(hierarchy);
		}
		return composites;
	}
}
