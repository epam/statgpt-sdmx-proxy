package io.sdmx.im.beans.reference;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.CrossReferencingTree;

public class CrossReferencingTreeImpl implements CrossReferencingTree {
	private static final long serialVersionUID = 1343644842488138440L;
	private MaintainableBean maintianableBean;
	private List<CrossReferencingTree> referencingBeans = new ArrayList<>();
	
	public CrossReferencingTreeImpl(MaintainableBean maintainableBean, List<CrossReferencingTree> referencingBeans) {
		this.maintianableBean = maintainableBean;
		if(referencingBeans != null) {
			this.referencingBeans = referencingBeans;
		}
	}

	@Override
	public MaintainableBean getMaintainable() {
		return maintianableBean;
	}

	@Override
	public List<CrossReferencingTree> getReferencingStructures() {
		return new ArrayList<>(referencingBeans);
	}
}
