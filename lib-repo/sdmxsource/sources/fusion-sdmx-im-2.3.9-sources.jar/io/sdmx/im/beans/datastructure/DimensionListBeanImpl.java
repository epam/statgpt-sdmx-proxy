package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;

public class DimensionListBeanImpl extends IdentifiableBeanImpl implements DimensionListBean {
	private static final long serialVersionUID = 823386049386394325L;
	private List<DimensionBean> dimensions = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DimensionListBeanImpl(DimensionListMutableBean bean, DataStructureBean parent) {
		super(bean, parent);
		if(bean.getDimensions() != null) {
			int pos = 1;
			DimensionMutableBean timeDimension = null;
			for(DimensionMutableBean currentDimension : bean.getDimensions()) {
				if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(currentDimension.getId())) {
					timeDimension = currentDimension;
					continue;
				}
				this.dimensions.add(new DimensionBeanImpl(currentDimension, pos, this));
				pos++;
			}
			if(timeDimension != null) {
				this.dimensions.add(new TimeDimensionBean(timeDimension, pos, this));
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			DimensionListBean that = (DimensionListBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(getDimensions(), that.getDimensions(), includeFinalProperties, "Dimension", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validateDimensionList() {
		List<String> idList = new ArrayList<>();
		Collections.sort(dimensions);
		for(DimensionBean currentDimensionBean : dimensions) {
			if(idList.contains(currentDimensionBean.getId())) {
				throw new SdmxSemmanticException("Duplicate Dimension Id : " + currentDimensionBean.getId());
			}
		}
	}



	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DimensionListBean.class;
	}
	
	@Override
	public String getId() {
		return FIXED_ID;
	}	

	@Override
	public List<DimensionBean> getDimensions() {
		return new ArrayList<>(dimensions);
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(dimensions, composites);
        return composites;
    }
}
