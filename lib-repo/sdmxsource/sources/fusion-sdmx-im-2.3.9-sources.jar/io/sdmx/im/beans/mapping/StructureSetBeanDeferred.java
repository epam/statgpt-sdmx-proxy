package io.sdmx.im.beans.mapping;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.CodeReferenceableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RelatedStructuresBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class StructureSetBeanDeferred extends MaintainableBeanDeferred<StructureSetBean> implements StructureSetBean {
    private static final long serialVersionUID = 1L;

    public StructureSetBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public StructureSetBeanDeferred(StructureSetBean maint) {
        super(maint);
    }
    
    @Override
    public StructureSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new StructureSetBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected StructureSetBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new StructureSetBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<StructureSetBean> getURN() {
        return (IURNMaintainable<StructureSetBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return StructureSetBean.class;
    }

    @Override
    public StructureSetMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public CodeReferenceableBean cloneItemWithCodeFilter(Set<String> urns, SdmxBeanRetrievalManager beanRet) {
        return load().cloneItemWithCodeFilter(urns, beanRet);
    }

    @Override
    public RelatedStructuresBean getRelatedStructures() {
        return load().getRelatedStructures();
    }

    @Override
    public List<StructureMapBean> getStructureMapList() {
        return load().getStructureMapList();
    }

    @Override
    public List<CodelistMapBean> getCodelistMapList() {
        return load().getCodelistMapList();
    }

    @Override
    public CodelistMapBean getCodelistMap(String id) {
        return load().getCodelistMap(id);
    }

    @Override
    public List<CategorySchemeMapBean> getCategorySchemeMapList() {
        return load().getCategorySchemeMapList();
    }

    @Override
    public List<ConceptSchemeMapBean> getConceptSchemeMapList() {
        return load().getConceptSchemeMapList();
    }

    @Override
    public List<OrganisationSchemeMapBean> getOrganisationSchemeMapList() {
        return load().getOrganisationSchemeMapList();
    }

    @Override
    public StructureSetBean cloneForDate(Date aDate) {
        return load().cloneForDate(aDate);
    }
}