package io.sdmx.im.beans.pdq;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class PreDefinedQueryBeanDeferred extends MaintainableBeanDeferred<IPreDefinedQueryBean> implements IPreDefinedQueryBean {
    private static final long serialVersionUID = 1L;

    public PreDefinedQueryBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public PreDefinedQueryBeanDeferred(PreDefinedQueryBean maint) {
        super(maint);
    }
    
    @Override
    public IPreDefinedQueryBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new PreDefinedQueryBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected PreDefinedQueryBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new PreDefinedQueryBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IPreDefinedQueryBean> getURN() {
        return (IURNMaintainable<IPreDefinedQueryBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return PreDefinedQueryBean.class;
    }

    @Override
    public IPreDefinedQueryMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public boolean isVirtualFlow() {
        return load().isVirtualFlow();
    }

    @Override
    public Set<IDirectCrossReferenceBean<DataflowBean>> getDataflow() {
        return load().getDataflow();
    }

    @Override
    public List<IPreDefinedQueryComponentFilterBean> getSelections() {
        return load().getSelections();
    }

    @Override
    public Set<String> getSeries() {
        return load().getSeries();
    }

    @Override
    public Map<String, String> getParameters() {
        return load().getParameters();
    }

}
