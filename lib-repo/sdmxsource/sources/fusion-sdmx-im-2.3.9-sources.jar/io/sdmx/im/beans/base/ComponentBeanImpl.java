package io.sdmx.im.beans.base;

import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public abstract class ComponentBeanImpl extends IdentifiableBeanImpl implements ComponentBean {
	private static final long serialVersionUID = 15L;
	private IDirectCrossReferenceBean<ConceptBean> conceptRef;
	protected RepresentationBean localRepresentation;
	protected boolean assignmentStatus;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected ComponentBeanImpl(ComponentMutableBean bean, IdentifiableBean parent) {
		super(bean,  parent);
		try {
			if(bean.getRepresentation() != null) {
				setRepresentation(bean.getRepresentation());
			}
			if(bean.getConceptRef() != null) {
				this.conceptRef = DirectCrossReferenceBean.build(this, "concept", bean.getConceptRef(), ConceptBean.class);
			}
			this.assignmentStatus = bean.isMandatory();
		} catch(SdmxSemmanticException th) {
			throw new SdmxSemmanticException(th, "Error creating component: " + this.toString());
		} catch(Throwable th) {
			throw new SdmxException(th, "Error creating component: " + this.toString());
		}
		validateComponentAttributes();
	}
	
	protected void setRepresentation(RepresentationMutableBean representationMutableBean) {
		this.localRepresentation = RepresentationBeanImpl.getInstance(representationMutableBean, this);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(ComponentBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(!super.equivalent(conceptRef, bean.getConceptRef(), "Concept", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(localRepresentation, bean.getRepresentation(), includeFinalProperties, diff)) {
			returnVal = false;
		}
		
		if (!super.equivalent(isMandatory(), bean.isMandatory(), "usage", diff)) {
			returnVal = false;
		}
		
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validateComponentAttributes() throws SdmxSemmanticException {
		validateComponetReference();
		validateTextFormat();
		super.validateId(false);
	}
	
	
	// Ensure that the enumerated type is correct
	private void validateTextFormat() {
		RepresentationBean representation = this.getRepresentation();
		if(representation == null) {
			return;
		}
		TextFormatBean textFormat = representation.getTextFormat();
		ICrossReferenceBean<? extends EnumeratedListBean> codelistRep = representation.getRepresentation();
		if(textFormat != null && codelistRep != null) {
			TextFormatBean tf = representation.getTextFormat();
			if (tf != null) {
				TEXT_TYPE textType = tf.getTextType();
				if (textType != null && !textType.isValidEnumeratedDimensionTextType()) {
					StringBuilder validTypes = new StringBuilder();
					String concat = "";
					for(TEXT_TYPE tt : TEXT_TYPE.values()) {
						if(tt.isValidEnumeratedDimensionTextType()) {
							validTypes.append(concat + tt.getSdmx21Value());
							concat =", ";
						}
					}
					throw new SdmxSemmanticException("The "+this.getStructureType().getType()+" " + this.getId() + " can not use an enumeration in combination with a Text Type of " + textType.toString()+".  Please either remove the Text Type, or change it to a valid Text Type.  Valid types are: "+validTypes.toString());
				}
			}
		}
	}
	
	protected void validateComponetReference() {
		if(this.conceptRef == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ATTRIBUTE, structureType.getType(), "conceptRef");
		}
	}

	@Override
	protected void validateId(boolean startWithIntAllowed) {
		//Do nothing yet, not yet fully built
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
    	super.addToCompositeSet(getRepresentation(), composites);
    	return composites;
    }

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.add(conceptRef);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getId() {
		if(ObjectUtil.validString(super.getId())) {
			return super.getId();
		}
		if(conceptRef != null) {
			return conceptRef.getReference().getFullIdentifiableId();
		}
		throw new SdmxSemmanticException("Id not set for component");
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<? extends ComponentBean> getURN() {
		return (IURNAbsolute<? extends ComponentBean>)super.getURN();
	}
	
	@Override
	public ICrossReferenceBean<ConceptBean> getConceptRef() {
		return conceptRef;
	}

	@Override
	public RepresentationBean getRepresentation() {
		return localRepresentation;
	}

	@Override
	public boolean hasCodedRepresentation() {
		if(localRepresentation != null) {
			return localRepresentation.getRepresentation() != null;
		}
		return false;
	}
	
	@Override
	public boolean isMandatory() {
		return assignmentStatus;
	}
}
