package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.Collections;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.im.mutable.transformation.CustomTypeSchemeMutableBean;

/**
 * Provides the details of a custom type scheme, in which user defined operators are described
 */
public class CustomTypeSchemeBean extends VtlSchemeBean<ICustomTypeBean> implements ICustomTypeSchemeBean {
	private static final long serialVersionUID = 1L;

	CustomTypeSchemeBean(ICustomTypeSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.unmodifiableList(this.items);
	}

	public CustomTypeSchemeBean(ICustomTypeSchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(ICustomTypeMutableBean item : bean.getItems()) {
				this.items.add(new CustomTypeBean(item, this, this.items.size()));
			}
		}
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		ICustomTypeSchemeBean that = (ICustomTypeSchemeBean) bean;
		return super.deepEqualsInternal(that, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE.getType(), diff);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ICustomTypeSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ICustomTypeSchemeBean> getURN() {
		return (IURNMaintainable<ICustomTypeSchemeBean>) super.getURN();
	}
	
	@Override
	public ICustomTypeSchemeMutableBean getMutableInstance() {
		return new CustomTypeSchemeMutableBean(this);
	}

	@Override
	public ICustomTypeSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new CustomTypeSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}

    @Override
    public CustomTypeSchemeBeanDeferred toDeferred() {
        return new CustomTypeSchemeBeanDeferred(this);
    }
    
    @Override
    public CustomTypeSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new CustomTypeSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
