package io.sdmx.im.beans.codelist;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoFeatureSetCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class GeoFeatureSetCodeBean extends CodeBeanImpl implements IGeoFeatureSetCodeBean {
	private static final long serialVersionUID = 1L;
	private String geoFeatureSet;
	
	public GeoFeatureSetCodeBean(IGeographicCodelistBean parent, IGeoFeatureSetCodeMutableBean bean, int position) {
		super(parent, bean, position);
		this.geoFeatureSet = bean.getGeoFeatureSet();
		
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof IGeoFeatureSetCodeBean) {
			IGeoFeatureSetCodeBean that = (IGeoFeatureSetCodeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(geoFeatureSet, that.getGeoFeatureSet(), "Geo Feature Set", diff)) {
				returnVal =  false;
			}
			return super.deepEquals(bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(geoFeatureSet)) {
			throw new SdmxSemmanticException("Geo Feature Set Code is missing required feature set");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getGeoFeatureSet() {
		return geoFeatureSet;
	}
}
