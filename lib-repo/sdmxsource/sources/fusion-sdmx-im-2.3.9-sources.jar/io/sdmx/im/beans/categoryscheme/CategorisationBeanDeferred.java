package io.sdmx.im.beans.categoryscheme;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class CategorisationBeanDeferred extends MaintainableBeanDeferred<CategorisationBean> implements CategorisationBean {
    
    private static final long serialVersionUID = 1L;

    public CategorisationBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public CategorisationBeanDeferred(CategorisationBean maint) {
        super(maint);
    }
    
    @Override
    public CategorisationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CategorisationBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected CategorisationBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new CategorisationBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<CategorisationBean> getURN() {
        return (IURNMaintainable<CategorisationBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return CategorisationBean.class;
    }

    @Override
    public ICrossReferenceBean<?> getStructureReference() {
        return load().getStructureReference();
    }

    @Override
    public ICrossReferenceBean<CategoryBean> getCategoryReference() {
        return load().getCategoryReference();
    }

    @Override
    public CategorisationMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
    
}
