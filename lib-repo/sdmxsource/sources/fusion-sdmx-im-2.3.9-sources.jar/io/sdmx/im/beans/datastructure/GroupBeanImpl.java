package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;

public class GroupBeanImpl extends IdentifiableBeanImpl implements GroupBean {
	private static final long serialVersionUID = 13L;
	private List<String> dimensionRef = new ArrayList<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public GroupBeanImpl(GroupMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		if(bean.getDimensionRef() != null) {
			this.dimensionRef = new ArrayList<>(bean.getDimensionRef());
		}
		validateGroupAttributes();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			GroupBean that = (GroupBean) bean;
			boolean returnVal = true;
			if(!super.equivalentCollection(this, dimensionRef, that.getDimensionRefs(), "Dimension Reference", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validateGroupAttributes() throws SdmxSemmanticException {
		DataStructureBean owningDsd = (DataStructureBean)getParent().getMaintainableParent();
		for(String dimensionRef : getDimensionRefs()) {
			if (owningDsd.getDimension(dimensionRef) == null) {
				DimensionBean timeDimensionBean = owningDsd.getTimeDimension();
				if (timeDimensionBean != null) {
					if (timeDimensionBean.getId().equals(dimensionRef)) {
						throw new SdmxSemmanticException(ExceptionCode.GROUP_CANNOT_REFERENCE_TIME_DIMENSION, this.getId());
					}
				}
				throw new SdmxSemmanticException(ExceptionCode.REFERENCE_ERROR,  SDMX_STRUCTURE_TYPE.DIMENSION + " " + dimensionRef, SDMX_STRUCTURE_TYPE.GROUP, this.toString());
			}
		}
		sortGroupDimensions();
		this.dimensionRef = Collections.unmodifiableList(dimensionRef);
	}

	/**
	 * Sort the groups into the order specified by the Dimensions. This was requested by the BIS - see FR-189
	 */
	private void sortGroupDimensions() {
		DataStructureBean owningDsd = (DataStructureBean)getParent().getMaintainableParent();
		DimensionListBean dimensionList = owningDsd.getDimensionList();

		Map<String, DimensionBean> dimensionMap = new HashMap<>();
		for (DimensionBean dimension: dimensionList.getDimensions()) {
			String conceptId = dimension.getId();
			dimensionMap.put(conceptId, dimension);
		}
		Collections.sort(dimensionRef, new GroupComparator(dimensionMap));
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return GroupBean.class;
	}
	
	@Override
	public List<String> getDimensionRefs() {
		return dimensionRef;
	}
	
	private class GroupComparator implements Comparator<String> {
		private Map<String, DimensionBean> dimensionMap;

		public GroupComparator(Map<String, DimensionBean> dimensionMap) {
			this.dimensionMap = dimensionMap;
		}

		@Override
		public int compare(String dimension1, String dimension2) {
			DimensionBean dimensionBean1 = dimensionMap.get(dimension1);
			int position1 = dimensionBean1.getPosition();
			DimensionBean dimensionBean2 = dimensionMap.get(dimension2);
			int position2 = dimensionBean2.getPosition();
			return position1 - position2;
		}
	}
}