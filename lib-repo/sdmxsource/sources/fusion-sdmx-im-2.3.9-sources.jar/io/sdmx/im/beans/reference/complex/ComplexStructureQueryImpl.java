package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexStructureQuery;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexStructureQueryMetadata;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexStructureReferenceBean;

public class ComplexStructureQueryImpl implements ComplexStructureQuery {

	private ComplexStructureReferenceBean structuRef;
	private ComplexStructureQueryMetadata queryMetadata;

	public ComplexStructureQueryImpl(ComplexStructureReferenceBean structureRef, ComplexStructureQueryMetadata queryMetadata) {
		if (structureRef == null) {
			throw new SdmxSemmanticException("StructureReference cannot be null");
		}
		this.structuRef = structureRef;
		
		if (queryMetadata == null) {
			throw new SdmxSemmanticException("StructureQueryMetadata cannot be null");
		}
		this.queryMetadata = queryMetadata;
		
	}
	
	@Override
	public ComplexStructureQueryMetadata getStructureQueryMetadata() {
		return queryMetadata;
	}

	@Override
	public ComplexStructureReferenceBean getStructureReference() {
		return structuRef;
	}
}