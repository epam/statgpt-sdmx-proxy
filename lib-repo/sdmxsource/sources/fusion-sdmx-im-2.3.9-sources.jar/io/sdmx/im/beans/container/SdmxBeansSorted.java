package io.sdmx.im.beans.container;

import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.utils.sdmx.comparator.IdentifiableComparator;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;

/**
 * An SdmxBeans implementation that returns all beans in a sorted order
 */
public class SdmxBeansSorted extends AbstractSdmxBeansProxy {
	private static final long serialVersionUID = 1L;
	
	private SdmxBeansSorted(SdmxBeans beans) {
		super(beans);
	}

	public static SdmxBeansSorted getInstance(SdmxBeans beans) {
		if(beans instanceof SdmxBeansSorted) {
			return (SdmxBeansSorted) beans;
		}
		return new SdmxBeansSorted(beans);
	}
	
	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(Class<T> structureType) {
		return createSortedSet( super.getMaintainableBeans(structureType) );
	}
	
	@Override
	public Set<MaintainableBean> getAllMaintainables(SDMX_STRUCTURE_TYPE... exclude) {
		return createSortedSet( super.getAllMaintainables(exclude) );
	}

	@Override
	public Set<MaintainableBean> getMaintainables(SDMX_STRUCTURE_TYPE structureType) {
		return createSortedSet( super.getMaintainables(structureType) );
	}
	
	@Override
	public Set<AgencyBean> getAgencies() {
		return createSortedSetItem( super.getAgencies() );
	}

	@Override
	public SdmxBeans filterMaintainables(Predicate<? super MaintainableBean> predicate) {
		return new SdmxBeansSorted( super.filterMaintainables(predicate));
	}
	
	@Override
	public Set<ContentConstraintBean> getContentConstraintBeans() {
		return createSortedSet( super.getContentConstraintBeans() );
	}
	
	@Override
	public Set<IMaintainableStructureType<?>> getDistinctTypes() {
		return new TreeSet<>(super.getDistinctTypes());
	}
	
	
	/**
	 * Given a Set of objects that extend MaintainableBeans, returns a new Set where they are in a sorted order.
	 * @param maintainables
	 * @return
	 */
	private <T extends MaintainableBean> Set<T> createSortedSet(Set<T> maintainables) {
		Set<T> returnSet = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
		returnSet.addAll(maintainables);
		return returnSet;
	}
	
	/**
	 * Given a Set of objects that extend MaintainableBeans, returns a new Set where they are in a sorted order.
	 * @param identifiables
	 * @return
	 */
	private <T extends ItemBean> Set<T> createSortedSetItem(Set<T> identifiables) {
		Set<T> returnSet = new TreeSet<>(IdentifiableComparator.INSTANCE);
		returnSet.addAll(identifiables);
		return returnSet;
	}
}
