package io.sdmx.im.beans.transformation;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Details a name personalisation that is used in a transformation
 */
public class NamePersonalisationBean extends ItemBeanImpl implements INamePersonalisationBean {
	private static final long serialVersionUID = 1L;
	private String vtlArtefact;
	private String vtlDefaultName;
	private String personalisedName;

	public NamePersonalisationBean(INamePersonalisationMutableBean bean, INamePersonalisationSchemeBean parent, int position) {
		super(bean, parent, position);
		this.vtlArtefact = bean.getVtlArtefact();
		this.vtlDefaultName = bean.getVtlDefaultName();
		this.personalisedName = bean.getPersonalisedName();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(this.vtlArtefact)) {
			throw new SdmxSemmanticException("VTL Artefact required for VTL Name Personalisation");
		}
		if(!ObjectUtil.validString(this.vtlDefaultName)) {
			throw new SdmxSemmanticException("VTL Default Name required for VTL Name Personalisation");
		}
		if(!ObjectUtil.validString(this.personalisedName)) {
			throw new SdmxSemmanticException("VTL Personalised Name required for VTL Name Personalisation");
		}
		this.vtlArtefact = this.vtlArtefact.trim();
		this.vtlDefaultName = this.vtlDefaultName.trim();
		this.personalisedName = this.personalisedName.trim();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		INamePersonalisationBean that = (INamePersonalisationBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(vtlArtefact, that.getVtlArtefact(), "VTL Artefact", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(vtlDefaultName, that.getVtlDefaultName(), "Default Name", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(personalisedName, that.getPersonalisedName(), "Personalised Name", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return INamePersonalisationBean.class;
	}
	
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<INamePersonalisationBean> getURN() {
		return (IURNAbsolute<INamePersonalisationBean>) super.getURN();
	}
	
	@Override
	public String getVtlArtefact() {
		return vtlArtefact;
	}

	@Override
	public String getVtlDefaultName() {
		return vtlDefaultName;
	}

	@Override
	public String getPersonalisedName() {
		return personalisedName;
	}
}
