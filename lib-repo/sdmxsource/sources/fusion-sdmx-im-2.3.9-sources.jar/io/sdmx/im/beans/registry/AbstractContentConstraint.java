package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;

public abstract class AbstractContentConstraint extends ConstraintBeanImpl implements ContentConstraintBean {
	private static final long serialVersionUID = 21L;

	public AbstractContentConstraint(ConstraintMutableBean bean) {
		super(bean);
	}

	public AbstractContentConstraint(MaintainableBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public boolean isBusinessValidity() {
		return false;
	}

	@Override
	public boolean isDefiningActualDataPresent() {
		return false;
	}

	@Override
	public boolean isCubeRegion() {
		return false;
	}

	@Override
	public boolean isConstrainingComponent(String componentId) {
		return false;
	}

	@Override
	public MetadataTargetRegionBean getMetadataTargetRegion() {
		return null;
	}

	@Override
	public CubeRegionBean getIncludedCubeRegion() {
		return null;
	}

	@Override
	public CubeRegionBean getExcludedCubeRegion() {
		return null;
	}

	@Override
	public boolean hasIncludedSeries() {
		return false;
	}

	@Override
	public boolean hasExcludedSeries() {
		return false;
	}

	@Override
	public boolean hasExcludedCubeRegion() {
		return false;
	}

	@Override
	public boolean hasIncludedCubeRegion() {
		return false;
	}

	@Override
	public Set<KeyValues> getRestrictedComponents() {
		return null;
	}

	@Override
	public ReferencePeriodBean getReferencePeriod() {
		return null;
	}

	@Override
	public ReleaseCalendarBean getReleaseCalendar() {
		return null;
	}

}
