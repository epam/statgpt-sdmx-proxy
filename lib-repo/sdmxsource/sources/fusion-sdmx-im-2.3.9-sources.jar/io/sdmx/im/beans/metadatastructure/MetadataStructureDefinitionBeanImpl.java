package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataStructureDefinitionMutableBeanImpl;

public class MetadataStructureDefinitionBeanImpl extends MaintainableBeanImpl implements MetadataStructureDefinitionBean {
	private static final Logger LOG = LoggerFactory.getLogger(MetadataStructureDefinitionBeanImpl.class);
	private static final long serialVersionUID = 138L;
	private List<MetadataAttributeBean> metadataAttributes = new ArrayList<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	MetadataStructureDefinitionBeanImpl(MetadataStructureDefinitionBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub MetadataStructureDefinitionBean Built");
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataStructureDefinitionBeanImpl(MetadataStructureDefinitionMutableBean bean) {
		super(bean);
		LOG.debug("Building MetadataStructureDefinitionBean from Mutable Bean");
		try {
			if(bean.getMetadataAttributes() != null) {
				int pos = 1;
				for(MetadataAttributeMutableBean currentMa : bean.getMetadataAttributes()) {
					metadataAttributes.add(new MetadataAttributeBeanImpl(this, currentMa, pos));
					pos++;
				}
			}
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("MetadataStructureDefinitionBean Built " + this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		Set<String> conceptIds = new HashSet<>();
		for(MetadataAttributeBean maBean : this.getMetadataAttributes()) {
			String conceptId = maBean.getConceptRef().getReference().getIdentifiableId();
			if(conceptIds.contains(conceptId)) {
				throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_CONCEPT, maBean.getUrn());
			}
			conceptIds.add(conceptId);
		}
		metadataAttributes = Collections.unmodifiableList(metadataAttributes);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			MetadataStructureDefinitionBean that = (MetadataStructureDefinitionBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(metadataAttributes, that.getMetadataAttributes(), includeFinalProperties, "Metadata Attributes", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return MetadataStructureDefinitionBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<MetadataStructureDefinitionBean> getURN() {
		return (IURNMaintainable<MetadataStructureDefinitionBean>) super.getURN();
	}
	
	
	@Override
	public MetadataStructureDefinitionBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new MetadataStructureDefinitionBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public MetadataStructureDefinitionMutableBean getMutableInstance() {
		return new MetadataStructureDefinitionMutableBeanImpl(this);
	}

	@Override
	public List<MetadataAttributeBean> getMetadataAttributes() {
		return metadataAttributes;
	}

	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		return Collections.emptyList();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(metadataAttributes, composites);
		return composites;
	}

    @Override
    public MetadataStructureDefinitionBeanDeferred toDeferred() {
        return new MetadataStructureDefinitionBeanDeferred(this);
    }
    
    @Override
    public MetadataStructureDefinitionBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataStructureDefinitionBeanDeferred(getDeferredDefinition(), loader);
    }
}
