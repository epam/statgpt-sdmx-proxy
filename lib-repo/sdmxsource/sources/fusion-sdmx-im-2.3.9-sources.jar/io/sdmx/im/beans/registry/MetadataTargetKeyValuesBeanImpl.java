package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.DataSetReferenceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetKeyValuesMutable;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class MetadataTargetKeyValuesBeanImpl extends KeyValuesImpl implements MetadataTargetKeyValuesBean {
	private static final long serialVersionUID = 42368365224779717L;
	private List<IDirectCrossReferenceBean<?>> objectReferences = new ArrayList<>();
	private List<DataSetReferenceBean> datasetReferences = new ArrayList<>();


	public MetadataTargetKeyValuesBeanImpl(MetadataTargetKeyValuesMutable mutable, MetadataTargetRegionBean parent) {
		super(mutable, parent);
		if(mutable.getObjectReferences() != null) {
			for(StructureReferenceBean sRef : mutable.getObjectReferences()) {
				this.objectReferences.add(DirectCrossReferenceBean.build(parent.getIdentifiableParent(), "structureref", sRef.buildURNSingle()));
			}
		}
		if(mutable.getDatasetReferences() != null) {
			for(DataSetReferenceMutableBean currentRef : mutable.getDatasetReferences()) {
				this.datasetReferences.add(new DataSetReferenceBeanImpl(currentRef, this));
			}
		}
		this.datasetReferences = Collections.unmodifiableList(this.datasetReferences);
		this.objectReferences = Collections.unmodifiableList(this.objectReferences);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(datasetReferences, composites);
		return composites;
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof MetadataTargetKeyValuesBean) {
			MetadataTargetKeyValuesBean that = (MetadataTargetKeyValuesBean) bean;
			boolean returnVal = true;
			if(!ObjectUtil.equivalentCollection(objectReferences, that.getObjectReferences())) {
				returnVal = false;
			}
			if(!super.equivalent(datasetReferences, that.getDatasetReferences(), includeFinalProperties, "Dataset Reference", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(objectReferences != null) {
			references.addAll(objectReferences);
		}
	}

	@Override
	public List<IDirectCrossReferenceBean<?>> getObjectReferences() {
		return objectReferences;
	}

	@Override
	public List<DataSetReferenceBean> getDatasetReferences() {
		return datasetReferences;
	}
}
