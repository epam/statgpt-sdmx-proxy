package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class AgencySchemeBeanImpl extends OrganisationSchemeBeanImpl<AgencyBean> implements AgencySchemeBean {
	private static final long serialVersionUID = 189L;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected AgencySchemeBeanImpl(AgencySchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public AgencySchemeBeanImpl(AgencySchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(AgencyMutableBean item : bean.getItems()) {
				this.items.add(new AgencyBeanImpl(item, this));
			}
			items = Collections.unmodifiableList(items);
		}
	}
	
	public static AgencySchemeBean createDefaultScheme() {
		AgencySchemeMutableBean mutable = new AgencySchemeMutableBeanImpl();
		mutable.setAgencyId(DEFAULT_SCHEME);
		mutable.setId(FIXED_ID);
		mutable.setVersion(FIXED_VERSION);
		mutable.addName("en", "SDMX Agency Scheme");
		AgencyMutableBean agencyMutableBean = new AgencyMutableBeanImpl();
		agencyMutableBean.addName("en", AgencyBean.DEFAULT_AGENCY);
		agencyMutableBean.setId(AgencyBean.DEFAULT_AGENCY);
		mutable.addItem(agencyMutableBean);
		return mutable.getImmutableInstance();
	}

	@Override
	protected Class<?> getConcreteInterface() {
		return AgencySchemeBean.class;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean != null && bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((AgencySchemeBean)bean, includeFinalProperties, "Agency", diffReport);
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<AgencySchemeBean> getURN() {
		return (IURNMaintainable<AgencySchemeBean>)super.getURN();
	}
	
	@Override
	public ISdmxVersion getVersion() {
		return SdmxVersion.DEFAULT;
	}

	@Override
	public String getId() {
		return FIXED_ID;
	}
	
	@Override
	public boolean isDefaultScheme() {
		return this.getAgencyId().equals(DEFAULT_SCHEME);
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new AgencySchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}
	
	//FR1645 Add agency breaks under certain conditions
	//Enforce an Agency Scheme is never external or has a service/structure url
	
	@Override
	public boolean isExternalReference() {
		return false;
	}

	@Override
	public URL getServiceURL() {
		return null;
	}

	@Override
	public URL getStructureURL() {
		return null;
	}

	@Override
	public AgencySchemeMutableBean getMutableInstance() {
		return new AgencySchemeMutableBeanImpl(this);
	}

	@Override
	public AgencySchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return (AgencySchemeBean)super.filterItems(filterIds, isKeepSet);
	}

    @Override
    public AgencySchemeBeanDeferred toDeferred() {
        return new AgencySchemeBeanDeferred(this);
    }

    @Override
    public AgencySchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new AgencySchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
