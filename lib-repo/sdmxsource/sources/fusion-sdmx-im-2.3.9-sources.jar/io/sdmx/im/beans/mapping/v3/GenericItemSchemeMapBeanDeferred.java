package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public abstract class GenericItemSchemeMapBeanDeferred<V extends IItemMapBean, T extends IItemSchemeMapBean<V>> extends MaintainableBeanDeferred<T> implements IItemSchemeMapBean<V> {
    private static final long serialVersionUID = 1L;

    protected GenericItemSchemeMapBeanDeferred(IDeferredBeanDefinition deferred,
            IDeferredLoader<MaintainableBean> loader) {
        super(deferred, loader);
    }
    
    protected GenericItemSchemeMapBeanDeferred(T maint) {
        super(maint);
    }

    @Override
    public ICrossReferenceBean<? extends ItemSchemeBean> getSourceRef() {
        return load().getSourceRef();
    }

    @Override
    public ICrossReferenceBean<? extends ItemSchemeBean> getTargetRef() {
        return load().getTargetRef();
    }

    @Override
    public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return load().getStub(actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public List<V> getItems() {
        return load().getItems();
    }

}
