package io.sdmx.im.beans.codelist;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class HierarchyAssociationBeanDeferred extends MaintainableBeanDeferred<HierarchyAssociationBean> implements HierarchyAssociationBean {
    private static final long serialVersionUID = 1L;

    public HierarchyAssociationBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public HierarchyAssociationBeanDeferred(HierarchyAssociationBean maint) {
        super(maint);
    }
    
    @Override
    public HierarchyAssociationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new HierarchyAssociationBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected HierarchyAssociationBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyAssociationBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<HierarchyAssociationBean> getURN() {
        return (IURNMaintainable<HierarchyAssociationBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return HierarchyAssociationBean.class;
    }

    @Override
    public HierarchyAssociationMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public ICrossReferenceBean<HierarchyBean> getHierarchyRef() {
        return load().getHierarchyRef();
    }

    @Override
    public ICrossReferenceBean<?> getLinkedStructureRef() {
        return load().getLinkedStructureRef();
    }

    @Override
    public ICrossReferenceBean<?> getContextStructureRef() {
        return load().getContextStructureRef();
    }
}
