package io.sdmx.im.beans.datastructure;

import java.util.List;

import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;

public class DataStructureDetails {
	private DataStructureBean dsd;
	private List<String> dimensions;
	private List<String> seriesAttributes;
	private List<String> measures;
	private List<String> obsAttributes;
	
	public static DataStructureDetails getInstance(DataStructureBean dsd, String dimensionAtObservation) {
		return new DataStructureDetails(dsd, dimensionAtObservation);
	}

	private DataStructureDetails(DataStructureBean dsd, String dimensionAtObservation) {
		this.dsd = dsd;
		this.dimensions = dsd.getDimensionIds();
		this.seriesAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getSeriesAttributes(dimensionAtObservation), true);
		this.measures = SdmxCollectionUtil.identifiablesIdList(dsd.getMeasures(), true);
		this.obsAttributes = SdmxCollectionUtil.identifiablesIdList(dsd.getObservationAttributes(), true);
	}

	public List<String> getDimensions() {
		return dimensions;
	}

	public List<String> getSeriesAttributes() {
		return seriesAttributes;
	}

	public boolean isHasTimeDimension() {
		return dsd.getTimeDimension() != null;
	}

	public List<String> getMeasures() {
		return measures;
	}

	public List<String> getObsAttributes() {
		return obsAttributes;
	}
	
}
