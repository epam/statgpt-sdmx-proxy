package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ReportingTaxonomyMapMutableBean;

public class ReportingTaxonomyMapBean extends GenericItemSchemeMapBean<IReportingCategoryMapBean> implements IReportingTaxonomyMapBean {
	private static final long serialVersionUID = 12L;

	/**
	 * Stub constructor
	 */
	ReportingTaxonomyMapBean(IReportingTaxonomyMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReportingTaxonomyMapBean(IReportingTaxonomyMapMutableBean bean) {
		super(bean);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IReportingTaxonomyMapBean.class;
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.REPORTING_CATEGORY;
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ReportingTaxonomyMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IReportingTaxonomyMapMutableBean getMutableInstance() {
		return new ReportingTaxonomyMapMutableBean(this);
	}

	@Override
	protected IReportingCategoryMapBean buildItemMap(IItemMapMutableBean mutable) {
		return new ReportingCategoryMapBean(mutable, this);
	}

    @Override
    public ReportingTaxonomyMapBeanDeferred toDeferred() {
        return new ReportingTaxonomyMapBeanDeferred(this);
    }
    
    @Override
    public ReportingTaxonomyMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTaxonomyMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
