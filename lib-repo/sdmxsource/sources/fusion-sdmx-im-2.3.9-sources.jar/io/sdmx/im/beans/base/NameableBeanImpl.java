package io.sdmx.im.beans.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public abstract class NameableBeanImpl extends IdentifiableBeanImpl implements NameableBean {
	private static final long serialVersionUID = 41L;

	protected List<TextTypeWrapper> name =  new ArrayList<>();
	private List<TextTypeWrapper> description = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected NameableBeanImpl(NameableBean bean, boolean completeStub) {
		super(bean, completeStub);
		TextTypeUtil.runProcessWithNoLocaleFilter(()-> {
			this.name = bean.getNames();
			if(completeStub) {
				this.description = bean.getDescriptions();
			}
		});
		validateNameableAttributes();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected NameableBeanImpl(NameableMutableBean bean,
			IdentifiableBean parent) {
		super(bean, parent);
		TextTypeUtil.runProcessWithNoLocaleFilter(()-> {
			if(bean.getNames() != null) {
				for(TextTypeWrapperMutableBean mutable : bean.getNames()) {
					if(ObjectUtil.validString(mutable.getValue())) {
						name.add(new TextTypeWrapperImpl(mutable, "Name", this));
					}
				}
			}
			if(bean.getDescriptions() != null) {
				for(TextTypeWrapperMutableBean mutable : bean.getDescriptions()) {
					if(ObjectUtil.validString(mutable.getValue())) {
						description.add(new TextTypeWrapperImpl(mutable, "Description", this));
					}
				}
			}
		});
		validateNameableAttributes();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validateNameableAttributes() throws SdmxSemmanticException {
		if(this instanceof SubscriptionBean || this instanceof RegistrationBean) {
			return;
		}
		if(this.name == null || this.name.size() == 0) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_IDENTIFIABLE_MISSING_NAME, this.getStructureName() + " '"+ this.getId()+"'");
		}
		TextTypeUtil.ensureNoDuplicates(this.name);
		TextTypeUtil.ensureNoDuplicates(this.description);
		
		this.name = Collections.unmodifiableList(this.name);
		this.description = Collections.unmodifiableList(this.description);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(NameableBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		//If the user has chosen not to include final properties, then ignore the name and description
		boolean returnVal = true;

		if(includeFinalProperties) {
			Locale locFilter = TextTypeUtil.getLocaleFilter();
			TextTypeUtil.clearLocaleFilter();
			try {
				if(!super.equivalent(name, bean.getNames(), includeFinalProperties, "Name", diff)) {
					returnVal = false;
				}
				if(!super.equivalent(description, bean.getDescriptions(), includeFinalProperties, "Description", diff)) {
					returnVal = false;
				}
			} finally {
				TextTypeUtil.setLocaleFilter(locFilter);
			}
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(name, composites);
		super.addToCompositeSet(description, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
	public List<TextTypeWrapper> getNames() {
		if(!TextTypeUtil.hasLocaleFilter()) {
			return name;
		}
		
		List<TextTypeWrapper> copy =  new ArrayList<>(name);
		return TextTypeUtil.optionalFilterOnTextType(copy);
	}

	@Override
	public String getName(String locale) {
		for(TextTypeWrapper name : this.name) {
			if(name.getLocale().equals(locale)) {
				return name.getValue();
			}
		}
		return null;
	}

	@Override
	public List<TextTypeWrapper> getNames(boolean disableLocaleFilter) {
		if (disableLocaleFilter || !TextTypeUtil.hasLocaleFilter()) {
			return name;
		}
		List<TextTypeWrapper> copy =  new ArrayList<>(name);
		return TextTypeUtil.optionalFilterOnTextType(copy);
	}

	@Override
	public List<TextTypeWrapper> getAllTextTypes() {
		List<TextTypeWrapper> returnList = super.getAllTextTypes();
		returnList.addAll(name);
		returnList.addAll(description);
		return returnList;
	}

	@Override
	public String getName() {
		TextTypeWrapper ttw = TextTypeUtil.getDefaultLocale(name);
		return (ttw == null)?null:ttw.getValue();
	}

	@Override
	public List<TextTypeWrapper> getDescriptions() {
		return getDescriptions(false);
	}

	@Override
	public List<TextTypeWrapper> getDescriptions(boolean disableLocaleFilter) {
		if(disableLocaleFilter || !TextTypeUtil.hasLocaleFilter()) {
			return description;
		}
		List<TextTypeWrapper> copy =  new ArrayList<>(description);
		if (disableLocaleFilter) {
			return copy;
		}
		return TextTypeUtil.optionalFilterOnTextType(copy);
	}

	@Override
	public String getDescription() {
		TextTypeWrapper ttw = TextTypeUtil.getDefaultLocale(description);
		return (ttw == null)?null:ttw.getValue();
	}
}
