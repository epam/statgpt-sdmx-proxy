package io.sdmx.im.beans.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.builder.IImmutableBeanBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.im.beans.upgrade.UpgradeToV3StructureMap;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.UrnUtil;

/**
 * Upgrades the information model to version 3.0
 */
public class V3BeansBuilder implements IBeansBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(V3BeansBuilder.class);
    public static IBeansBuilder DEFAULT_INSTANCE = new V3BeansBuilder(null);
    
    private final IImmutableBeanBuilder beanBuilder;
    
    public V3BeansBuilder(IImmutableBeanBuilder beanBuilder) {
        this.beanBuilder = beanBuilder != null ? beanBuilder : StandardImmutableBeanBuilder.INSTANCE;
    }
    

    @Override
    public void build(MaintainableMutableBean mutable, SdmxBeans beans) {
        if(mutable.getStructureType() == SDMX_STRUCTURE_TYPE.HIERARCHICAL_CODELIST) {
            HierarchicalCodelistMutableBean hcl = (HierarchicalCodelistMutableBean)mutable;
            upgradeHCL(hcl, beans);
        }else if(mutable.getStructureType() == SDMX_STRUCTURE_TYPE.STRUCTURE_SET) {
            StructureSetMutableBean ss = (StructureSetMutableBean)mutable;
            UpgradeToV3StructureMap.build(ss.getImmutableInstance(), beans);
        } else {
            beans.addIdentifiable(beanBuilder.build(mutable));
        }
    }
    
    private void upgradeHCL(HierarchicalCodelistMutableBean hcl, SdmxBeans beans) {
        //Copy Template across all built Hierarchies (a HCL in 2.1 can contains multiple hierarchies, in 3.0 it is one hierarchy per maintainable)
        
        for(HierarchyMutableBean hierarchy : hcl.getHierarchies()) {
            String hclId = hcl.getId();
            String hierarchyId = hierarchy.getId();
            
            // FMR#438: Change to the generated ID. Now it is hierarchyId + UrnUtil.HCL_UPGRADE_SYMBOL + hclId
            // This denotes that this Hierarchy is the "hierarchyId" that was @ the hclId HCL
            String outputId = hclId.equals(hierarchyId) ? hierarchyId : hierarchyId + UrnUtil.HCL_UPGRADE_SYMBOL + hclId;

            hierarchy.setAgencyId(hcl.getAgencyId());
            hierarchy.setId(outputId);
            hierarchy.setVersion(hcl.getVersion());
            hierarchy.setStartDate(hcl.getStartDate());
            hierarchy.setEndDate(hcl.getEndDate());
            // MEDIT: 335 - Annotations on a Hierarchy should be from the 2.1 HCL as well as the existing Annotations on the Hierarchy
            if (ObjectUtil.validCollection(hcl.getAnnotations())) {
                for(AnnotationMutableBean anno: hcl.getAnnotations()) {
                    hierarchy.addAnnotation(anno);
                }
            }
            MaintainableBean maint = beanBuilder.build(hierarchy);
            beans.addIdentifiable(maint);
        }
    }
}
