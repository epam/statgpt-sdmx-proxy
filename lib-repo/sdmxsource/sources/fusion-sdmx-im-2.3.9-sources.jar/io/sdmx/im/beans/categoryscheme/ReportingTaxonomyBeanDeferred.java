package io.sdmx.im.beans.categoryscheme;

import java.net.URL;
import java.util.Date;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class ReportingTaxonomyBeanDeferred extends ItemSchemeBeanDeffered<ReportingCategoryBean, ReportingTaxonomyBean> implements ReportingTaxonomyBean {
    
    private static final long serialVersionUID = 1L;

    public ReportingTaxonomyBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ReportingTaxonomyBeanDeferred(ReportingTaxonomyBean maint) {
        super(maint);
    }
    
    @Override
    public ReportingTaxonomyBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ReportingTaxonomyBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected ReportingTaxonomyBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTaxonomyBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ReportingTaxonomyBean> getURN() {
        return (IURNMaintainable<ReportingTaxonomyBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ReportingTaxonomyBean.class;
    }
    
    @Override
    public ReportingTaxonomyBean cloneForDate(Date date) {
        return (ReportingTaxonomyBean)super.cloneForDate(date);
    }

    @Override
    public ReportingTaxonomyMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
