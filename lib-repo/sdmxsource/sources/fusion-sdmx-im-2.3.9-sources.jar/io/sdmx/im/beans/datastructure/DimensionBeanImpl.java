package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.im.beans.base.ComponentBeanImpl;
import io.sdmx.im.beans.base.RepresentationBeanImpl;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class DimensionBeanImpl extends ComponentBeanImpl implements DimensionBean {
	private static final Logger LOG = LoggerFactory.getLogger(DimensionBeanImpl.class);
	private static final long serialVersionUID = 12L;
	private boolean measureDimension;
	private boolean timeDimension;
	private boolean freqDimension;
	private List<IDirectCrossReferenceBean<ConceptBean>> conceptRole = new ArrayList<>();
	private int position;
	
	private IURNSingle<ConceptSchemeBean> measureConceptSchemeRef;  //V2.1 and lower only
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	DimensionBeanImpl(DimensionMutableBean bean, int position, DimensionListBean parent) {
		super(bean, parent);

		this.assignmentStatus = true;
		
		// FR-4867: ensure that the structure type is correct
		if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(this.getId())) {
			super.structureType = SDMX_STRUCTURE_TYPE.TIME_DIMENSION;
		}

		try {
			this.position = position;
			this.measureDimension = bean.isMeasureDimension() || measureConceptSchemeRef != null;
			this.timeDimension = bean.isTimeDimension();
			if(bean.getConceptRole() != null) {
				for(StructureReferenceBean currentConceptRole : bean.getConceptRole()) {
					conceptRole.add(DirectCrossReferenceBean.build(this, "conceptrole", currentConceptRole, ConceptBean.class));
				}
			}
			validateDimension();
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Error creating structure: " + this.toString());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public static DimensionBean build(DimensionMutableBean bean, int position, DimensionListBean parent) {
		if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(bean.getId())) {
			return new TimeDimensionBean(bean, position, parent);
		}
		return new DimensionBeanImpl(bean, position, parent);
	}

	@Override
	protected void setRepresentation(RepresentationMutableBean bean) {
		if(bean.getRepresentation() != null
			&& bean.getRepresentation().getMaintainableStructureType() == SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME) {
			this.measureConceptSchemeRef = bean.getRepresentation().buildURNSingle(ConceptSchemeBean.class);
		} else {
			super.setRepresentation(bean);
		}
	}

	@Override
	public IURNSingle<ConceptSchemeBean> getConceptScheme() {
		return measureConceptSchemeRef;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			DimensionBean that = (DimensionBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(measureDimension, that.isMeasureDimension(), "Measure Dimension", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(timeDimension, that.isTimeDimension(), "Time Dimension", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(getPosition(), that.getPosition(), "List Position", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(conceptRole, that.getConceptRole(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validateDimension() {
		if(this.getId().equals(TIME_DIMENSION_FIXED_ID)) {
			this.timeDimension = true;
		}

		this.conceptRole = Collections.unmodifiableList(conceptRole);
		if(this.timeDimension) {
			setId(TIME_DIMENSION_FIXED_ID);
			if(this.hasCodedRepresentation()) {
				throw new SdmxSemmanticException("Time Dimension can not have a coded representation");
			}
			if(this.localRepresentation == null || this.localRepresentation.getTextFormat() == null) {
				RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
				TextFormatMutableBean textFormatMutable = new TextFormatMutableBeanImpl();
				textFormatMutable.setTextType(TEXT_TYPE.OBSERVATIONAL_TIME_PERIOD);
				rep.setTextFormat(textFormatMutable);
				this.localRepresentation = RepresentationBeanImpl.getInstance(rep, this);
			} else {
				// Validate only the allowed text format attributes have been set
				TextFormatBean textFormat = localRepresentation.getTextFormat();
				RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
				TextFormatMutableBeanImpl textFormatMutable = new TextFormatMutableBeanImpl();
				if(textFormat.getTextType() != null){
					if(!textFormat.getTextType().isValidTimeDimensionTextType()) {
						//STRIP THE INVALID TEXT FORMAT
						LOG.warn("Invalid Text Format found on Time Dimension, removing Text Format : "+ localRepresentation.getTextFormat().getTextType());
					} else {
						textFormatMutable.setTextType(textFormat.getTextType());
					}
				} else {
					textFormatMutable.setTextType(TEXT_TYPE.OBSERVATIONAL_TIME_PERIOD);
				}

				// STRIP any invalid values for the Time Dimension - SDMX 2.0 values which are not valid for 2.1 must be stripped
				if (textFormat.getMinValue() != null) {
					LOG.warn("MinValue is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getMaxValue() != null) {
					LOG.warn("MaxValue is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getMinLength() != null) {
					LOG.warn("MinLength is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getMaxLength() != null) {
					LOG.warn("MaxLength is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getStartValue() != null) {
					LOG.warn("StartValue is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getEndValue() != null) {
					LOG.warn("EndValue is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getInterval() != null) {
					LOG.warn("Interval is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getTimeInterval() != null) {
					LOG.warn("TimeInterval is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getDecimals() != null) {
					LOG.warn("Decimals is not permitted on the Time Dimension. Removing it");
				}
				if (textFormat.getPattern() != null) {
					LOG.warn("Parrern is not permitted on the Time Dimension. Removing it");
				}

				// Only startTime, endTime and textType are valid in SDMX 2.1
				if (textFormat.getStartTime() != null) {
					textFormatMutable.setStartTime(textFormat.getStartTime().getDate());
				}
				if (textFormat.getEndTime() != null) {
					textFormatMutable.setEndTime(textFormat.getEndTime().getDate());
				}
				rep.setTextFormat(textFormatMutable);

				this.localRepresentation = RepresentationBeanImpl.getInstance(rep, this);
			}
		} else {
			if(this.getId().equals(TIME_DIMENSION_FIXED_ID)) {
				DataStructureBean dsd = this.getParent(DataStructureBean.class, true);
				String msg = "In the Data Structure '" + dsd.getShortURN() + "' a dimension is NOT specified as the Time Dimension but is using the reserved id: " + TIME_DIMENSION_FIXED_ID;
				throw new SdmxSemmanticException(msg);
			}
		}

		if(this.measureDimension) {
			super.structureType = SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION;
			if(this.getConceptScheme() == null) {
				throw new SdmxSemmanticException("Measure Dimension missing reference to Concept Scheme");
			}
		} else {
			if(this.hasCodedRepresentation()) {
				if(this.getRepresentation().getRepresentation().getTargetReference() != SDMX_STRUCTURE_TYPE.CODE_LIST
						&& this.getRepresentation().getRepresentation().getTargetReference() != SDMX_STRUCTURE_TYPE.VALUE_LIST) {
					throw new SdmxSemmanticException("Dimension representation must reference a Codelist or ValueList, currently it references a "+
							this.getRepresentation().getRepresentation().getTargetReference().getType());
				}
			}
		}

		// Paranoia check: Ensure Dimension hasn't been declared as two things.
		if(this.measureDimension && this.timeDimension) {
			throw new SdmxSemmanticException("Dimension can not be both a Measure Dimension and a Time Dimension");
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DimensionBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<DimensionBean> getURN() {
		return (IURNAbsolute<DimensionBean>)super.getURN();
	}

	@Override
	protected List<String> getParentIds(boolean includeDifferentTypes) {
		List<String> returnList = new ArrayList<>();
		returnList.add(this.getId());
		return returnList;
	}

	@Override
	public COMPONENT_TYPE getType() {
		return COMPONENT_TYPE.DIMENSION;
	}

	@Override
	public boolean isMeasureDimension() {
		return measureDimension;
	}

	@Override
	public boolean isFrequencyDimension() {
		if(freqDimension) {
			return true;
		}
		return this.getId().equals("FREQ");
	}

	@Override
	public boolean isTimeDimension() {
		return timeDimension;
	}

	@Override
	public List<IDirectCrossReferenceBean<ConceptBean>> getConceptRole() {
		return conceptRole;
	}

	@Override
	public int getPosition() {
		return position;
	}

	@Override
	public int compareTo(DimensionBean o) {
		if(o.getPosition() == this.getPosition()) {
			if(!o.equals(this)) {
				throw new SdmxSemmanticException("Two dimensions ("+this.getId()+" & " +o.getId()+") can not share the same dimension position : " + getPosition());
			}
		}
		return o.getPosition() > this.getPosition() ? -1 : +1;
	}


	@Override
	public DataStructureBean getMaintainableParent() {
		return (DataStructureBean) super.getMaintainableParent();
	}

	@Override
	public boolean isMandatory() {
		// A DimensionBean is always mandatory
		return true;
	}

}
