package io.sdmx.im.beans.categoryscheme;

import java.net.URL;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;

public class ReportingTaxonomyBeanImpl extends ItemSchemeBeanImpl<ReportingCategoryBean> implements ReportingTaxonomyBean {
	private static final Logger LOG = LoggerFactory.getLogger(ReportingTaxonomyBeanImpl.class);
	private static final long serialVersionUID = 183L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	ReportingTaxonomyBeanImpl(ReportingTaxonomyBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub ReportingTaxonomyBean Built");
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReportingTaxonomyBeanImpl(ReportingTaxonomyMutableBean reportingTaxonomy) {
		super(reportingTaxonomy);
		LOG.debug("Building ReportingTaxonomyBean from Mutable Bean");
		try {
			if(reportingTaxonomy.getItems() != null) {
				int position = 1;
				for(ReportingCategoryMutableBean currentcategory : reportingTaxonomy.getItems()) {
					items.add(new ReportingCategoryBeanImpl(this, currentcategory, position));
					position++;
				}
				
			}
	
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("ReportingTaxonomyBean Built " + this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((ReportingTaxonomyBean)bean, includeFinalProperties, "Reporting Category", diff);
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(items != null) {
			items = Collections.unmodifiableList(items);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return ReportingTaxonomyBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ReportingTaxonomyBean> getURN() {
		return (IURNMaintainable<ReportingTaxonomyBean>)super.getURN();
	}
	
	@Override
	public ReportingTaxonomyBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ReportingTaxonomyBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}
	
	@Override
	public ReportingTaxonomyMutableBean getMutableInstance() {
		return new ReportingTaxonomyMutableBeanImpl(this);
	}

    @Override
    public ReportingTaxonomyBeanDeferred toDeferred() {
        return new ReportingTaxonomyBeanDeferred(this);
    }
    
    @Override
    public ReportingTaxonomyBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTaxonomyBeanDeferred(getDeferredDefinition(), loader);
    }
}
