package io.sdmx.im.beans.refmetadata;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class ReportedMetadataSetBeanDeferred extends MaintainableBeanDeferred<IReportedMetadataSetBean> implements IReportedMetadataSetBean {
    private static final long serialVersionUID = 1L;

    public ReportedMetadataSetBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ReportedMetadataSetBeanDeferred(IReportedMetadataSetBean maint) {
        super(maint);
    }
    
    @Override
    public IReportedMetadataSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ReportedMetadataSetBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ReportedMetadataSetBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ReportedMetadataSetBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IReportedMetadataSetBean> getURN() {
        return (IURNMaintainable<IReportedMetadataSetBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IReportedMetadataSetBean.class;
    }

    @Override
    public IReportedMetadataSetMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public ICrossReferenceBean<? extends IMetadataTargetIdentifier> getStructure() {
        return load().getStructure();
    }

    @Override
    public List<ICrossReferenceBeanBase> getTargets() {
        return load().getTargets();
    }

    @Override
    public List<IReportedMetadataAttributeBean> getAttributes() {
        return load().getAttributes();
    }
}
