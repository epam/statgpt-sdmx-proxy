package io.sdmx.im.beans.mapping.v3;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapRefMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class RepresentationMapRef extends SDMXBeanImpl implements IRepresentationMapRefBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<? extends EnumeratedListBean> enumerationRef;
	private TEXT_TYPE tt;

	public RepresentationMapRef(IRepresentationMapRefMutableBean mutableBean, IRepresentationMapBean parent) {
		super(mutableBean, parent);
		this.tt = mutableBean.getTextType();
		if(mutableBean.getEnumerationRef() != null) {
			this.enumerationRef = DirectCrossReferenceBean.build(parent, "enumeration", mutableBean.getEnumerationRef().buildURNSingle().toSubType(EnumeratedListBean.class));
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(enumerationRef != null) {
			switch(enumerationRef.getTargetReference()) {
			case CODE_LIST :
			case VALUE_LIST :  //OK
				break;
			default :
				throw new SdmxSemmanticException("Representation Map Illegal reference to '"+enumerationRef.getTargetUrn()+"'.  Reference expected to either a Codelist or Valuemap");
			}
		} else if(tt == null) {
			throw new SdmxSemmanticException("Representation Map expects either a reference to a Codelist/Valuelist or a Text Type");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof IRepresentationMapRefBean) {
			IRepresentationMapRefBean that = (IRepresentationMapRefBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(enumerationRef, that.getEnumerationRef(), "Reference", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(tt, that.getTextType(), "Text Type", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////REFERENCES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(enumerationRef != null) {
			references.add(enumerationRef);
		}
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}


	@Override
	public ICrossReferenceBean<? extends EnumeratedListBean> getEnumerationRef() {
		return enumerationRef;
	}

	@Override
	public TEXT_TYPE getTextType() {
		return tt;
	}


	@Override
	public String getKey() {
		return null;
	}
}
