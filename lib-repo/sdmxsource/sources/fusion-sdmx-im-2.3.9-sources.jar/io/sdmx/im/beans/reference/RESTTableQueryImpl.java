package io.sdmx.im.beans.reference;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.query.RESTTableQuery;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

public class RESTTableQueryImpl implements RESTTableQuery {
	private IMaintainableRef tableReference;
	private SdmxPeriod tablePeriod;
	private Map<String, String> queryParameters;
	
	public RESTTableQueryImpl(String[] restString, Map<String, String> queryParameters) {
		if (restString == null) {
			throw new IllegalArgumentException("Expected 'path' should not be null");
		}
		if(queryParameters == null) {
			queryParameters = new HashMap<>();
		}
		
		this.tableReference = parseTableRef(restString[1]);
		this.queryParameters = Collections.unmodifiableMap(queryParameters);
	}
	
	private IMaintainableRef parseTableRef(String str) {
		String split[] = str.split(",");
		if(split.length > 3) {
			throw new SdmxSemmanticException("Unexpected number of reference arguments (, separated) for reference: "+str +" - expecting a maximum of three arguments (Agency Id, Id, and Version)");
		}
		if(split.length == 3) {
			return MaintainableRef.getInstance(split[0], split[1], split[2]);
		}
		if(split.length == 2) {
			return MaintainableRef.getInstance(split[0], split[1]);
		}
		return MaintainableRef.getInstance(null, split[0]);
	}
	@Override
	public IMaintainableRef getTableReference() {
		return tableReference;
	}

	@Override
	public SdmxPeriod getTablePeriod() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, String> getQueryParameters() {
		return queryParameters;
	}

}
