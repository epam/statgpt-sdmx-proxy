package io.sdmx.im.beans.reporting;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;
import io.sdmx.im.format.FusionMetadataStandard;

public class ReportingTemplateBeanDeferred extends MaintainableBeanDeferred<ReportingTemplateBean> implements ReportingTemplateBean {
    private static final long serialVersionUID = 1L;

    public ReportingTemplateBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ReportingTemplateBeanDeferred(ReportingTemplateBean maint) {
        super(maint);
    }
    
    @Override
    public ReportingTemplateBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ReportingTemplateBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ReportingTemplateBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTemplateBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ReportingTemplateBean> getURN() {
        return (IURNMaintainable<ReportingTemplateBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ReportingTemplateBean.class;
    }

    @Override
    public IMetadataStandard getDefaultStandard() {
        return FusionMetadataStandard.getInstance();
    }
    
    @Override
    public ReportTemplateInstructionSheetBean getInstructionSheet() {
        return load().getInstructionSheet();
    }

    @Override
    public List<ReportingTemplateWorksheetBean> getWorksheets() {
        return load().getWorksheets();
    }

    @Override
    public boolean includeFormulaCheckingSummary() {
        return load().includeFormulaCheckingSummary();
    }

    @Override
    public ReportingTemplateMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
