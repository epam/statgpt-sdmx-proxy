package io.sdmx.im.beans;

import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.im.beans.container.SdmxBeansImmutable;

public class StructureEvent implements IStructureEvent {
	private SdmxBeans modified;
	private SdmxBeans added;
	private SdmxBeans delete;

	public StructureEvent(SdmxBeans added, SdmxBeans modified, SdmxBeans deleted) {
		this.added = added == null ? SdmxBeansImmutable.EMPTY_BEANS : new SdmxBeansImmutable(added);
		this.modified = modified == null ? SdmxBeansImmutable.EMPTY_BEANS : new SdmxBeansImmutable(modified);
		this.delete = deleted == null ? SdmxBeansImmutable.EMPTY_BEANS : new SdmxBeansImmutable(deleted);
	}

	@Override
	public SdmxBeans getModification() {
		return modified;
	}

	@Override
	public SdmxBeans getAdditions() {
		return added;
	}

	@Override
	public SdmxBeans getDeletions() {
		return delete;
	}
}
