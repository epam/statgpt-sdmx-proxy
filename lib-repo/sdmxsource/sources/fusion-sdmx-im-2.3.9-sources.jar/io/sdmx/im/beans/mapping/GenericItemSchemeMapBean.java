package io.sdmx.im.beans.mapping;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;

/**
 * Where source and target can be represented by ItemMapBean
 *
 */
public abstract class GenericItemSchemeMapBean extends ItemSchemeMapBeanImpl<ItemMapBean> {
	private static final long serialVersionUID = 1L;
	List<ItemMapBean> items = new ArrayList<>();
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public GenericItemSchemeMapBean(ItemSchemeMapMutableBean<ItemMapMutableBean> bean, SDMX_STRUCTURE_TYPE structureType, IdentifiableBean parent) {
		super(bean, structureType, parent);
		if(bean.getItems() != null) {
			for(ItemMapMutableBean item : bean.getItems()) {
				items.add(new ItemMapBeanImpl(item, this));
			}
		}
	}


	@Override
	public List<ItemMapBean> getItems() {
		return items;
	}
	
}
