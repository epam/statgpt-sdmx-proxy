package io.sdmx.im.beans.valuelist;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;

public class ValueListBeanImpl extends MaintainableBeanImpl implements ValueListBean {
	private static final long serialVersionUID = 2L;

	private transient int idMinLength = -1;
	private transient int idMaxLength = -1;

	private List<ValueItemBean>  items = new ArrayList<>();
	private boolean partial;

	private transient Map<String, ValueItemBean> byId = null;

	public ValueListBeanImpl(ValueListMutableBean bean) {
		super(bean);
		this.partial = bean.isPartial();
		if(bean.getItems() != null) {
			int i=1;
			for(ValueItemMutableBean currentItem : bean.getItems()) {
				items.add(new ValueItemBeanImpl(currentItem, this, i));
				i++;
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}

	}

	/**
	 * Stub Constructor
	 * @param bean
	 * @param actualLocation
	 * @param isServiceUrl
	 */
	ValueListBeanImpl(MaintainableBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	/**
	 * Ensure transient values are set
	 * @param in
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		idMinLength = -1;
		idMaxLength = -1;
	}
	

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ValueListBean> getURN() {
		return (IURNMaintainable<ValueListBean>) super.getURN();
	}

	@Override
	public int getCodeMinLength() {
		if(idMinLength < 1) {
			if (items.size() == 0) {
				return -1;
			}
			idMinLength = Integer.MAX_VALUE;
			for(ValueItemBean currentCode : this.getItems()) {
				int codeLength = currentCode.getId().length();
				idMinLength = Math.min(idMinLength, codeLength);
			}
		}
		return idMinLength;
	}

	@Override
	public int getCodeMaxLength() {
		if(idMaxLength < 1) {
			if (items.size() == 0) {
				return -1;
			}
			for(ValueItemBean currentCode : this.getItems()) {
				int codeLength = currentCode.getId().length();
				idMaxLength = Math.max(idMaxLength, codeLength);
			}
		}
		return idMaxLength;
	}



	@Override
	public ValueListBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ValueListBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ValueListMutableBean getMutableInstance() {
		return new ValueListMutableBeanImpl(this);
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		ValueListBean that = (ValueListBean)bean;
		boolean returnVal = true;
		if(!super.equivalent(items, that.getItems(), includeFinalProperties, "ValueItem", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(isPartial(), that.isPartial(), "Is Partial", diff)) {
			returnVal = false;
		}
		return returnVal && super.deepEqualsInternal((ValueListBean)bean, includeFinalProperties, diff);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		items = Collections.unmodifiableList(items);
		this.byId = new HashMap<>();
		for(ValueItemBean currentItem : items) {
			String itemId = currentItem.getId();
			if(this.byId.containsKey(itemId)) {
				String errorMsg = "Item '" + itemId + "' appears multiple times in the Value List";
				throw new SdmxSemmanticException(errorMsg);
			}
			this.byId.put(itemId, currentItem);
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ValueListBean.class;
	}
	
	@Override
	public List<ValueItemBean> getItems() {
		return items;
	}

	@Override
	public boolean isPartial() {
		return partial;
	}

	@Override
	public ValueItemBean getItemById(String id) {
		if(byId == null) {
			buildByIdMap();
		}
		return byId.get(id);
	}

	@Override
	public List<ValueItemBean> getChildren(String id) {
		return Collections.emptyList();
	}


	@Override
	public ValueListBean filterItems(Collection<String> items, boolean keep) {
		if(byId == null) {
			buildByIdMap();
		}
		Set<String> allIds = byId.keySet();
		ValueListMutableBean vlMutable;
		if(items.size() >= allIds.size() && allIds.containsAll(items)) {
			if(keep) {
				//Nothing to Filter
				return this;
			}
			vlMutable = this.getMutableInstance();
			vlMutable.setItems(null);
			vlMutable.setPartial(true);
			return vlMutable.getImmutableInstance();
		}
		vlMutable = this.getMutableInstance();

		List<ValueItemMutableBean> toKeep = new ArrayList<>();
		for(ValueItemMutableBean item : vlMutable.getItems()) {
			if(items.contains(item.getId())) {
				if(keep) {
					toKeep.add(item);
				}
			} else if(!keep) {
				toKeep.add(item);
			}
		}
		vlMutable.setItems(toKeep);
		vlMutable.setPartial(true);
		return vlMutable.getImmutableInstance();
	}

	private void buildByIdMap() {
		Map<String, ValueItemBean> byId = new HashMap<>();
		for(ValueItemBean currentItem : items) {
			byId.put(currentItem.getId(), currentItem);
		}
		this.byId = byId;
	}

    @Override
    public ValuelistBeanDeferred toDeferred() {
        return new ValuelistBeanDeferred(this);
    }
    
    @Override
    public ValuelistBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ValuelistBeanDeferred(getDeferredDefinition(), loader);
    }
}
