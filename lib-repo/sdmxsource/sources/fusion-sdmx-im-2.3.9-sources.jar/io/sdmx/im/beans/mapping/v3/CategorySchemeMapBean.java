package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.CategorySchemeMapMutableBean;

public class CategorySchemeMapBean extends GenericItemSchemeMapBean<ICategoryMapBean> implements ICategorySchemeMapBean {
	private static final long serialVersionUID = 12L;

	/**
	 * Stub constructor
	 */
	CategorySchemeMapBean(ICategorySchemeMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CategorySchemeMapBean(ICategorySchemeMapMutableBean bean) {
		super(bean);
	}

	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ICategorySchemeMapBean.class;
	}
	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CATEGORY;
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new CategorySchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ICategorySchemeMapMutableBean getMutableInstance() {
		return new CategorySchemeMapMutableBean(this);
	}

	@Override
	protected ICategoryMapBean buildItemMap(IItemMapMutableBean mutable) {
		return new CategoryMapBean(mutable, this);
	}

    @Override
    public CategorySchemeMapBeanDeferred toDeferred() {
        return new CategorySchemeMapBeanDeferred(this);
    }
    
    @Override
    public CategorySchemeMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new CategorySchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
