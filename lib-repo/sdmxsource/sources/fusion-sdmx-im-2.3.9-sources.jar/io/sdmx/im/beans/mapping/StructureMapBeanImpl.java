package io.sdmx.im.beans.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class StructureMapBeanImpl extends SchemeMapBeanImpl implements StructureMapBean {
	private static final long serialVersionUID = 24L;
	private List<ComponentMapBean> components = new ArrayList<>();
	private boolean extension;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public StructureMapBeanImpl (StructureMapMutableBean structMapType, StructureSetBean parent) {
		super(structMapType, parent);
		extension = structMapType.isExtension();
		if(structMapType.getComponents() != null) {
			for(ComponentMapMutableBean mutable : structMapType.getComponents()) {
				components.add(new ComponentMapBeanImpl(mutable, this));
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			StructureMapBean that = (StructureMapBean) bean;
			boolean returnVal = true;

			if(!super.equivalent(components, that.getComponents(), includeFinalProperties, "Component Map", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isExtension(), that.isExtension(), "Is Extension", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal((StructureMapBeanImpl)bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(sourceRef == null ) {
			throw new SdmxSemmanticException("Structure Map missing source component");
		}

		if(targetRef == null ) {
			throw new SdmxSemmanticException("Structure Map missing target component");
		}
		if(!ObjectUtil.validCollection(components)) {
			throw new SdmxSemmanticException("A Structure Map must map at least one Component");
		}
		Collections.sort(components, new Comparator<ComponentMapBean>() {

			@Override
			public int compare(ComponentMapBean o1, ComponentMapBean o2) {
				int i = o1.getKey().compareTo(o2.getKey());
				return i;
			}

		});
		components = Collections.unmodifiableList(components);
		Set<SDMX_STRUCTURE_TYPE> allowedTypes = new HashSet<>();
		allowedTypes.add(SDMX_STRUCTURE_TYPE.DATAFLOW);
		allowedTypes.add(SDMX_STRUCTURE_TYPE.DSD);
		allowedTypes.add(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
		allowedTypes.add(SDMX_STRUCTURE_TYPE.MSD);

		verifyTypes(allowedTypes, sourceRef.getTargetReference());
		verifyTypes(allowedTypes, targetRef.getTargetReference());

	}

	private void verifyTypes(Set<SDMX_STRUCTURE_TYPE> allowedTypes, SDMX_STRUCTURE_TYPE actualType) {
		if(!allowedTypes.contains(actualType)) {
			String allowedTypesStr = "";

			for(SDMX_STRUCTURE_TYPE currentType : allowedTypes) {
				allowedTypesStr+=currentType +",";
			}
			allowedTypesStr = allowedTypesStr.substring(0, allowedTypesStr.length()-2);

			throw new SdmxSemmanticException("Disallowed concept map type '"+actualType+"' allowed types are '"+allowedTypesStr+"'");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return StructureMapBean.class;
	}
	
	@Override
	public List<ComponentMapBean> getComponents() {
		return components;
	}

	@Override
	public boolean isExtension() {
		return extension;
	}

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(components, composites);
        return composites;
    }
}
