package io.sdmx.im.beans.valuelist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public class ValueItemBeanImpl extends AnnotableBeanImpl implements ValueItemBean {
	private static final long serialVersionUID = 1L;
	private String id;
	private List<TextTypeWrapper> name =  new ArrayList<>();
	private List<TextTypeWrapper> description = new ArrayList<>();
	private int poistion;

	ValueItemBeanImpl(ValueItemMutableBean bean, ValueListBean parent, int poistion) {
		super(bean, parent);
		this.id = bean.getId();
		this.poistion = poistion;
		if(bean.getNames() != null) {
			for(TextTypeWrapperMutableBean mutable : bean.getNames()) {
				if(ObjectUtil.validString(mutable.getValue())) {
					name.add(new TextTypeWrapperImpl(mutable, "Name", this));
				}
			}
		}
		if(bean.getDescriptions() != null) {
			for(TextTypeWrapperMutableBean mutable : bean.getDescriptions()) {
				if(ObjectUtil.validString(mutable.getValue())) {
					description.add(new TextTypeWrapperImpl(mutable, "Description", this));
				}
			}
		}
		validate();
	}

	@Override
	public String getKey() {
		return id;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(id == null) {
			String errorMsg = "Value Item missing id";
			throw new SdmxSemmanticException(errorMsg);
		}
		if(!ObjectUtil.validCollection(name)) {
			throw new SdmxSemmanticException("Value Item missing name");
		}
		this.name = Collections.unmodifiableList(name);
		this.description = Collections.unmodifiableList(description);

	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof ValueItemBean) {
			//If the user has choosen not to include final properties, then ignore the name and description
			ValueItemBean that = (ValueItemBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(id, that.getId(), "Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(name, that.getNames(), includeFinalProperties, "Name",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(description, that.getDescriptions(), includeFinalProperties, "Description", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public List<TextTypeWrapper> getNames() {
		return getNames(false);
	}

	@Override
    public List<TextTypeWrapper> getNames(boolean disableLocaleFilter) {
	    List<TextTypeWrapper> copy =  new ArrayList<>(name);
	    if (disableLocaleFilter)  {
	        return copy;
	    }
	    return TextTypeUtil.optionalFilterOnTextType(copy);
    }
	
	@Override
	public String getName(String locale) {
		for(TextTypeWrapper name : this.name) {
			if(name.getLocale().equals(locale)) {
				return name.getValue();
			}
		}
		return null;
	}

	@Override
	public List<TextTypeWrapper> getDescriptions() {
	    return getDescriptions(false);
	}

	@Override
    public List<TextTypeWrapper> getDescriptions(boolean disableLocaleFilter) {
        List<TextTypeWrapper> copy =  new ArrayList<>(description);
        if (disableLocaleFilter) {
            return copy;
        }
        return TextTypeUtil.optionalFilterOnTextType(copy);
    }

	@Override
	public String getName() {
		TextTypeWrapper ttw = TextTypeUtil.getDefaultLocale(name);
		return (ttw == null)?null:ttw.getValue();
	}

	@Override
	public String getDescription() {
		TextTypeWrapper ttw = TextTypeUtil.getDefaultLocale(description);
		return (ttw == null)?null:ttw.getValue();
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}

	@Override
	public String getParentCode() {
		return null;
	}

	@Override
	public int getPosition() {
		return poistion;
	}
	
	@Override
	public boolean equals(Object obj) {
	    if(obj instanceof ValueItemBeanImpl) {
	    	ValueItemBeanImpl that = (ValueItemBeanImpl)obj;
	        return that.getId().equals(this.getId());
	    }
	    return false;
	}
	 
	@Override
	public int hashCode() {
		return getId().hashCode();
	}
}
