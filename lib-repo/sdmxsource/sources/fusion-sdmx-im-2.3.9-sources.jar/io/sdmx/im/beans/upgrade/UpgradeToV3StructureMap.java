package io.sdmx.im.beans.upgrade;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.MAPPING_FUNCTION;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.constant.InternalConstants;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;

/**
 * Upgrades version 2.1 structureSets to version 3.0 StructureMap, RepresentationMap
 */
public class UpgradeToV3StructureMap {
	
	private static final Logger LOG = LoggerFactory.getLogger(UpgradeToV3StructureMap.class);

	public static void build(StructureSetBean v21Bean, SdmxBeans beans) {
		Set<String> generatedIds = new HashSet<>();
		generatedIds.addAll(SdmxCollectionUtil.identifiablesIds(beans.getStructureMaps()));
		generatedIds.addAll(SdmxCollectionUtil.identifiablesIds(beans.getRepresentationMaps()));
		
		SdmxPeriod validityPeriod = v21Bean.getValidityPeriod();
		for(StructureMapBean sMap : v21Bean.getStructureMapList()) {
			build(sMap, beans, generatedIds, validityPeriod);
		}

		for(CodelistMapBean clMap : v21Bean.getCodelistMapList()) {
			IRepresentationMapBean repMap =  build(clMap, generatedIds, validityPeriod);
			beans.addIdentifiable(repMap);
		}
	}
	
	/**
	 * Builds structure maps, and RepresentationMaps (from inline maps)
	 * @param v21Bean
	 * @param beans
	 */
	private static void build(StructureMapBean v21Bean, SdmxBeans beans, Set<String> generatedIds, SdmxPeriod validityPeriod) {
		IStructureMapMutableBean builtSMap = new StructureMapMutableBean();

		// Record that this was created from an SDMX 2.1 Structure Set
		AnnotationMutableBeanImpl anno = new AnnotationMutableBeanImpl();
		anno.setType(InternalConstants.STRUCTURE_SET_UPGRADE);
		builtSMap.addAnnotation(anno);
		
		//Create maintainable properties
		builtSMap.setAgencyId(v21Bean.getMaintainableParent().getAgencyId());
		builtSMap.setVersion(v21Bean.getMaintainableParent().getVersion());

		if (validityPeriod != null) {
			if (validityPeriod.getStartPeriod() != null) {
				builtSMap.setStartDate(validityPeriod.getStartPeriod().getDate());
			}
			if (validityPeriod.getEndPeriod() != null) {
				builtSMap.setEndDate(validityPeriod.getEndPeriod().getDate());
			}
		}
		
		// copy properties
		generateIdAndName(builtSMap, v21Bean, generatedIds);
		builtSMap.copyNameableProperties(v21Bean, true);

		builtSMap.setSourceRef(v21Bean.getSourceRef());
		builtSMap.setTargetRef(v21Bean.getTargetRef());
		
		for(ComponentMapBean compMap : v21Bean.getComponents()) {
			populateComponentMap(builtSMap, compMap, beans, generatedIds);
		}
		
		beans.addIdentifiable(builtSMap.getImmutableInstance());
	}

	private static void populateComponentMap(IStructureMapMutableBean sMapMutable, ComponentMapBean v21Bean, SdmxBeans beans, Set<String> generatedIds) {
		IRepresentationMapBean clMap = null;

		if(v21Bean.getRepMapRef() != null) {
			RepresentationMapRefBean repMapV21 = v21Bean.getRepMapRef();

			if(repMapV21.getCodelistMap() != null) {
				clMap = build(repMapV21.getCodelistMap(), generatedIds, null);
			} else if(ObjectUtil.validMap(repMapV21.getValueMappings())) {
				//is it a fixed output value?
				Map<String, Set<String>> valueMappings = repMapV21.getValueMappings();
				//Is it a single source of Primary Measure?
				if(v21Bean.getMapConceptRef().size() == 1 && v21Bean.getMapConceptRef().get(0).equals(PrimaryMeasureBean.FIXED_ID)) {
					Set<String> fixedValues = valueMappings.get("*");
					if(fixedValues != null && fixedValues.size() == 1) {
						for(String outputComponentId : v21Bean.getMapTargetConceptRef()) {
							sMapMutable.addFixedOutput(outputComponentId, (String)fixedValues.toArray()[0]);
						}
						//Fixed output mapping, drop component map
						return;
					}
				}
				//Is it a single target of Primary Measure with a single output of *?
				if(v21Bean.getMapTargetConceptRef().size() == 1 && v21Bean.getMapTargetConceptRef().get(0).equals(PrimaryMeasureBean.FIXED_ID) && valueMappings.size() == 1) {
					String fixedValue = (String)valueMappings.keySet().toArray()[0];
					if(valueMappings.get(fixedValue).size() == 1 && valueMappings.get(fixedValue).contains("*")) {
						sMapMutable.addFixedInput(v21Bean.getMapConceptRef().get(0), fixedValue);
						//Fixed input mapping, drop component map
						return;
					}
				}
				if(valueMappings != null) {
					clMap = build(v21Bean, v21Bean.getMapConceptRef().size(), v21Bean.getMapTargetConceptRef().size(), repMapV21.getValueMappings(), generatedIds);
				}
			}
		}
		IComponentMapMutableBean compMap = sMapMutable.addComponentMap();
		if(clMap != null) {
			compMap.setRepresentationMapRef(clMap.asReference());
			beans.addIdentifiable(clMap);
		}
		compMap.copyAnnotableProperties(v21Bean);
		compMap.setSourceComponents(v21Bean.getMapConceptRef());
		compMap.setTargetComponents(v21Bean.getMapTargetConceptRef());
	}

	/**
	 * Builds a representation map from a map of string to strings, to do this:
	 * <ol>
	 *  <li>Obtain the source and target component(s) from the owning Component Map</li>
	 *  <li>Obtain the Codelist for the source/targets and set them on the map and use to generate ID</li>
	 * </ol>
	 *
	 * @param v21Bean
	 * @param codelistMap
	 * @param generatedIds
	 * @return
	 */
	private static IRepresentationMapBean build(ComponentMapBean v21Bean, int sourceConceptSize, int targetConceptSize, Map<String, Set<String>> codelistMap, Set<String> generatedIds) {
		IRepresentationMapMutableBean repMapMutable = new RepresentationMapMutableBean();

		//Create maintainable properties
		repMapMutable.setAgencyId(v21Bean.getMaintainableParent().getAgencyId());

		// Set the ID and name on the an Representation Map
		generateIdAndName(repMapMutable, v21Bean, generatedIds);

		repMapMutable.setVersion(v21Bean.getMaintainableParent().getVersion());

		//Copy source and target codelist reference
		//TODO
		//		repMapMutable.addSourceRef(codelistMap.getSourceRef());
		//		repMapMutable.addTargetRef(codelistMap.getTargetRef());

		int sourceSize = 0;
		int targetSize = 0;
		for(String sourceId : codelistMap.keySet()) {
			boolean isRegEx = sourceId.startsWith("/") && sourceId.endsWith("/");
			String value = isRegEx  ? sourceId.substring(1, sourceId.length()-1) : sourceId;
			String[] sources = StringUtil.splitWithRegex(value, ":", sourceConceptSize);
			for(String target : codelistMap.get(sourceId)) {
				IMappedRelationshipMutableBean mappedRelationship = repMapMutable.addMappedRelationship();
				sourceSize = sources.length;
				for(String source : sources) {
					boolean elememtIsRegEx = isRegEx;
					if(source.equals("*")) { //Upgrade old 'match all' to a regex expression
						elememtIsRegEx = true;
						source = "(.*)"; //Match anything, store in a capture group in case the target is *
					}
					mappedRelationship.addSourceValue().setValue(source).setRegEx(elememtIsRegEx);
				}

				String[] targets = StringUtil.splitWithRegex(target, ":", targetConceptSize);
				targetSize = targets.length;
				for(String mappedOutput : targets) {
					if(mappedOutput.equals("*")) {
						//Old syntax for saying copy whatever was matched
						mappedOutput = "\\1";  //convert to a capture group
					}
					mappedRelationship.addTargetValue(mappedOutput);
				}
			}
		}
		for(int i=0; i < sourceSize; i++) {
			repMapMutable.addSourceRef(TEXT_TYPE.STRING);
		}
		for(int i=0; i < targetSize; i++) {
			repMapMutable.addTargetRef(TEXT_TYPE.STRING);
		}
		return repMapMutable.getImmutableInstance();
	}
	
	/**
	 * Generates an ID and sets the ID and name on the StructureMap.
	 * 
	 * Example:
	 * MACRO2TDS - srceRef: BIS:BIS_MACRO(1.0)
	 * trget Ref:  BIS:BIS_DEBT_SEC2_TDS(1.0)
	 * becomes:
	 * BIS_MACRO_BIS_DEBT_SEC2_TDS
	 * 
	 * 
	 * The ID will be created by concatenation of:
	 * <ul>
	 * <li>The values of the source References and separated by underscores.
	 * <li>Then the number 2
	 * <li>The values of the target References and separated by underscores.
	 * </ul>
	 * However, if there are more than 5 source and target references in total, then the source and target references and limited to only 4 characters
	 * <p>
	 * If necessary the new ID is then truncated to at most 100 characters.  A check to avoid collisions with other RepresentationMapBean is also performed. If the ID already exists a suffix of _<integer> is added
	 * <p>
	 * Examples of generated IDs:
	 * <p>
	 * Source: ISSUER_SECTOR Target: BIS_TOPIC results in ISSUER_SECTOR2BIS_TOPIC
	 * <p>
	 * Source: ISSUE_CUR Target: BIS_TOPIC results in ISSUER_CUR2BIS_TOPIC
	 * <p>
	 * A longer example:
	 * <p>
	 * FREQ_RPII_RPII_RPIT_CPSS_CPSS2FREQ_DEVI_FUNC_SUBF_TECH_ISSU
	 * @param repMapMutable
	 * @param v21Bean
	 * @param generatedIds
	 */
	private static void generateIdAndName(IStructureMapMutableBean repMapMutable, StructureMapBean v21Bean, Set<String> generatedIds) {
		StringBuilder sb = new StringBuilder();
		
		sb.append(v21Bean.getId());
		
		if (generatedIds.contains(sb.toString())) {
			sb.append("_");
			StructureReferenceBean sourceRef = v21Bean.getSourceRef();
			sb.append(sourceRef.getMaintainableId());
			sb.append("2");
			StructureReferenceBean targetRef = v21Bean.getTargetRef();
			sb.append(targetRef.getMaintainableId());
		}

		String newId = setBeanValuesAndUpdateGeneratedSet(repMapMutable, generatedIds, sb.toString());
		LOG.info("Converted " + v21Bean.getSourceRef().getMaintainableStructureType() + " Map: " + v21Bean.getId() + " into StructureMap: " + newId);
	}

	/**
	 * Generates an ID and sets the ID and name on the representationMap.
	 * The ID will be created by concatenation of:
	 * <ul>
	 * <li>The values of the source References and separated by underscores.
	 * <li>Then the number 2
	 * <li>The values of the target References and separated by underscores.
	 * </ul>
	 * However, if there are more than 5 source and target references in total, then the source and target references and limited to only 4 characters
	 * <p>
	 * If necessary the new ID is then truncated to at most 100 characters.  A check to avoid collisions with other RepresentationMapBean is also performed. If the ID already exists a suffix of _<integer> is added
	 * <p>
	 * Examples of generated IDs:
	 * <p>
	 * Source: ISSUER_SECTOR Target: BIS_TOPIC results in ISSUER_SECTOR2BIS_TOPIC
	 * <p>
	 * Source: ISSUE_CUR Target: BIS_TOPIC results in ISSUER_CUR2BIS_TOPIC
	 * <p>
	 * A longer example:
	 * <p>
	 * FREQ_RPII_RPII_RPIT_CPSS_CPSS2FREQ_DEVI_FUNC_SUBF_TECH_ISSU
	 * @param repMapMutable
	 * @param v21Bean
	 * @param generatedIds
	 */
	private static void generateIdAndName(IRepresentationMapMutableBean repMapMutable, ComponentMapBean v21Bean, Set<String> generatedIds) {
		boolean truncateID = false;
		if (v21Bean.getMapConceptRef().size() + v21Bean.getMapTargetConceptRef().size() > 5) {
			truncateID = true;
		}

		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(String source : v21Bean.getMapConceptRef()) {
			sb.append(concat);
			sb.append(truncateID ? limitTo4AlphaNumerics(source) : source);
			concat = "_";
		}
		sb.append("2");
		concat = "";
		for(String target : v21Bean.getMapTargetConceptRef()) {
			sb.append(concat);
			sb.append(truncateID ? limitTo4AlphaNumerics(target) : target);
			concat = "_";
		}
		
		StructureMapBean map = v21Bean.getParent(StructureMapBean.class, false);
		sb.append("4");
		sb.append(map.getTargetRef().getMaintainableId());

		String newId = setBeanValuesAndUpdateGeneratedSet(repMapMutable, generatedIds, sb.toString());
		LOG.info("Converted ComponentMap " + v21Bean.toString() + " into RepresentationMap: " + newId);
	}
	
	/**
	 * Sets the ID and name on the supplied maintainable and updates the set of generatedIDs. The value for both ID and name comes from the supplied String.
	 * If this string is greater than 100 characters, the ID will be truncated to 100 characters
	 * If the ID is contained in the Set already, the ID will be suffixed with _<num> where "num" will increase until a match is not found in the Set
	 * The Name will not be truncated.
	 * @param aMaint
	 * @param setOfIds
	 * @param inputValue
	 */
	private static String setBeanValuesAndUpdateGeneratedSet(MaintainableMutableBean aMaint, Set<String> setOfIds, String inputValue) {
		// If necessary truncate the ID to 100 characters
		String idValue;
		if (inputValue.length() > 100) {
			idValue = inputValue.substring(0,100);
		} else {
			idValue = inputValue;
		}

		String potentialId = idValue;
		int i = 1;
		while (setOfIds.contains(potentialId)) {
			i++;
			potentialId = idValue + "_" + i;
		}
		setOfIds.add(potentialId);

		// Set the ID and name on the map
		aMaint.setId(potentialId);
		aMaint.addName("en", inputValue);  // The non-truncated value
		return potentialId;
	}

	private static String limitTo4AlphaNumerics(String val) {
		if (val == null) {
			return null;
		}

		String stripped = val.replaceAll("[_|@|\\-|$]", "");
		return stripped.substring(0,(Math.min(4, stripped.length())));
	}

	/**
	 * Builds a representation map from the codelist map
	 * @param codelistMap
	 * @return
	 */
	private static IRepresentationMapBean build(CodelistMapBean codelistMap, Set<String> generatedIds, SdmxPeriod validityPeriod ) {
		IRepresentationMapMutableBean repMapMutable = new RepresentationMapMutableBean();
		repMapMutable.copyNameableProperties(codelistMap, true);  //copy all properties

		//Create maintainable properties
		repMapMutable.setAgencyId(codelistMap.getMaintainableParent().getAgencyId());
		repMapMutable.setId(codelistMap.getId());

		String potentialId = codelistMap.getId();
		int i = 1;
		while (generatedIds.contains(potentialId)) {
			i++;
			potentialId = codelistMap.getId() + "_" + i;
		}
		generatedIds.add(potentialId);
		repMapMutable.setVersion(codelistMap.getMaintainableParent().getVersion());

		//Copy source and target codelist reference
		repMapMutable.addSourceRef(codelistMap.getSourceRef());
		repMapMutable.addTargetRef(codelistMap.getTargetRef());
		
		if (validityPeriod != null) {
			if (validityPeriod.getStartPeriod() != null) {
				repMapMutable.setStartDate(validityPeriod.getStartPeriod().getDate());
			}
			if (validityPeriod.getEndPeriod() != null) {
				repMapMutable.setEndDate(validityPeriod.getEndPeriod().getDate());
			}
		}

		//Copy source and target code ids
		int startIndex = codelistMap.getMappingFunction() == MAPPING_FUNCTION.SUBSTRING ? codelistMap.getSubStringStart() : -1;
		int endIndex =  codelistMap.getMappingFunction() == MAPPING_FUNCTION.SUBSTRING ? codelistMap.getSubStringEnd() : -1;
		boolean isRegEx = codelistMap.getMappingFunction() == MAPPING_FUNCTION.REG_EX;
		String regEx = isRegEx ? codelistMap.getRegExPattern().pattern() : null;
		for(CodeMapBean codeMap : codelistMap.getItems()) {
			IMappedRelationshipMutableBean mappedRelationship = repMapMutable.addMappedRelationship();
			mappedRelationship.copyAnnotableProperties(codeMap);
			if(codeMap.getValidityPeriod() != null) {
				if(codeMap.getValidityPeriod().getStartPeriod() != null) {
					mappedRelationship.setValidFrom(codeMap.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
				}
				if(codeMap.getValidityPeriod().getEndPeriod() != null) {
					mappedRelationship.setValidTo(codeMap.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
				}
			}
			String source = isRegEx ? regEx + codeMap.getSourceId() : codeMap.getSourceId();
			mappedRelationship.addSourceValue()
			.setValue(source)
			.setRegEx(isRegEx)
			.setStartIndex(startIndex)
			.setEndIndex(endIndex);
			mappedRelationship.addTargetValue(codeMap.getTargetId());
		}
		return repMapMutable.getImmutableInstance();
	}
}
