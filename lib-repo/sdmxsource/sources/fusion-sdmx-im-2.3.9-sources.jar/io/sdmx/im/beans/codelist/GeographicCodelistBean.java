package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoFeatureSetCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.im.mutable.codelist.GeographicCodelistMutableBean;

public class GeographicCodelistBean extends CodelistBeanImpl implements IGeographicCodelistBean {
	private static final long serialVersionUID = 1L;

	public GeographicCodelistBean(IGeographicCodelistBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public GeographicCodelistBean(IGeographicCodelistMutableBean codelist) {
		super(codelist);
		try {
			validateGeoCL();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	
	@Override
	/**
	 * Not supported
	 */
    public IDeferredBeanDefinition getDeferredDefinition() {
        return null;
    }
	
	@Override
	public IGeographicCodelistBean removePrefix(String prefix) {
		IGeographicCodelistMutableBean mutable = this.getMutableInstance();
		for(CodeMutableBean codeMutable : mutable.getItems()) {
			if(codeMutable.getId().startsWith(prefix)) {
				codeMutable.setId(codeMutable.getId().substring(prefix.length()));
			}
		}
		return mutable.getImmutableInstance();
	}
	
	@Override
	protected CodeBean createItem(CodeMutableBean codeMutable, int pos) {
		return new GeoFeatureSetCodeBean(this, (IGeoFeatureSetCodeMutableBean)codeMutable, pos);
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validateGeoCL() throws SdmxSemmanticException {
		
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IGeographicCodelistBean cloneForDate(Date date) {
		return (IGeographicCodelistBean)super.cloneForDate(date);
	}

	@Override
	public IGeographicCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new GeographicCodelistBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IGeoFeatureSetCodeBean getItemById(String id) {
		return (IGeoFeatureSetCodeBean) super.getItemById(id);
	}

	@Override
	public IGeographicCodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return  (IGeographicCodelistBean) super.filterItems(filterIds, isKeepSet);
	}

	@Override
	public IGeographicCodelistMutableBean getMutableInstance() {
		return new GeographicCodelistMutableBean(this);
	}

	@Override
	public boolean isGeoCodelist() {
		return true;
	}
}
