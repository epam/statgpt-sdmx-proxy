package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.List;
import java.util.Map;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IStructureMapRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class StructureMapBeanDeferred extends MaintainableBeanDeferred<IStructureMapBean> implements IStructureMapBean {
    private static final long serialVersionUID = 1L;

    public StructureMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public StructureMapBeanDeferred(IStructureMapBean maint) {
        super(maint);
    }
    
    @Override
    public IStructureMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new StructureMapBean(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected StructureMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new StructureMapBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IStructureMapBean> getURN() {
        return (IURNMaintainable<IStructureMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IStructureMapBean.class;
    }

    @Override
    public IStructureMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public ICrossReferenceBean<? extends IStructureMapRelatedBean> getSourceRef() {
        return load().getSourceRef();
    }

    @Override
    public ICrossReferenceBean<? extends IStructureMapRelatedBean> getTargetRef() {
        return load().getTargetRef();
    }

    @Override
    public Map<String, String> getFixedOutputs() {
        return load().getFixedOutputs();
    }

    @Override
    public Map<String, String> getFixedInputs() {
        return load().getFixedInputs();
    }

    @Override
    public List<IComponentMapBean> getComponentMaps() {
        return load().getComponentMaps();
    }

    @Override
    public List<ITimePatternMapBean> getTimePatternMaps() {
        return load().getTimePatternMaps();
    }

    @Override
    public List<IEpochMapBean> getEpochMap() {
        return load().getEpochMap();
    }

    @Override
    public ICrossReferenceBean<IRepresentationMapBean> getTimeFormatMapping() {
        return load().getTimeFormatMapping();
    }
}
