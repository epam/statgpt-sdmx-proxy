package io.sdmx.im.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlConceptMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlConceptMappingMutableBean;

public class VtlConceptMappingBean extends VtlMappingBean<ConceptBean> implements IVtlConceptMappingBean {
	private static final long serialVersionUID = 1L;

	public VtlConceptMappingBean(IVtlConceptMappingMutableBean bean, IVtlMappingSchemeBean parent, int position) {
		super(bean, ConceptBean.class, parent, position);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IVtlConceptMappingBean that = (IVtlConceptMappingBean) bean;
		return super.deepEqualsInternal(that, includeFinalProperties, diff);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IVtlConceptMappingBean.class;
	}
	
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IVtlConceptMappingBean> getURN() {
		return (IURNAbsolute<IVtlConceptMappingBean> ) super.getURN();
	}
}
