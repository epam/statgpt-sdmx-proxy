package io.sdmx.im.beans.base;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TextFormatBeanImpl extends SDMXBeanImpl implements TextFormatBean {
	private static final Logger LOG = LoggerFactory.getLogger(TextFormatBeanImpl.class);
	private static final long serialVersionUID = 1L;

	private TEXT_TYPE textType;
	private TERTIARY_BOOL isSequence=TERTIARY_BOOL.UNSET; 
	private TERTIARY_BOOL isMultiLingual=TERTIARY_BOOL.UNSET;
	private BigInteger minLength;
	private BigInteger maxLength;
	private BigDecimal startValue;
	private BigDecimal endValue;
	private BigDecimal minValue;
	private BigDecimal maxValue;
	private BigDecimal interval;
	private String timeInterval;
	private BigInteger decimals;
	private String pattern;
	private SdmxDate startTime;
	private SdmxDate endTime;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	private TextFormatBeanImpl(TextFormatMutableBean txtBean, SDMXBean parent) {
		super(txtBean, parent);
		this.textType = txtBean.getTextType();
		if(txtBean.getSequence() != null) {
			this.isSequence = txtBean.getSequence(); 
		}
		this.maxLength = txtBean.getMaxLength(); 
		this.minLength = txtBean.getMinLength(); 
		this.startValue = txtBean.getStartValue(); 
		this.endValue = txtBean.getEndValue();
		this.maxValue = txtBean.getMaxValue();
		this.minValue = txtBean.getMinValue();
		this.interval = txtBean.getInterval(); 
		this.timeInterval = txtBean.getTimeInterval();
		this.decimals = txtBean.getDecimals(); 
		this.pattern = txtBean.getPattern(); 
		if(txtBean.getStartTime() != null) {
			this.startTime = new SdmxDateImpl(txtBean.getStartTime(), TIME_FORMAT.DATE_TIME);
		}
		if(txtBean.getEndTime() != null) {
			this.endTime = new SdmxDateImpl(txtBean.getEndTime(), TIME_FORMAT.DATE_TIME);
		}
		this.isMultiLingual = txtBean.getMultiLingual();
		validate();
	}
	
	/**
	 * @param txtBean
	 * @param parent
	 * @return an instance if there is something set on the text format, if everything is default then null is returned
	 */
	public static TextFormatBean getInstance(TextFormatMutableBean txtBean, SDMXBean parent) {
		//This fixes an issue with deep equals where some structures have an empty text format and others have null
		TextFormatBean tx = new TextFormatBeanImpl(txtBean, parent);
		if(tx.getDecimals() != null) {
			return tx;
		}	
		if(tx.getEndTime() != null) {
			return tx;
		}	
		if(tx.getEndValue() != null) {
			return tx;
		}	

		if(tx.getInterval() != null) {
			return tx;
		}	

		if(tx.getMaxLength() != null) {
			return tx;
		}	

		if(tx.getMaxValue() != null) {
			return tx;
		}	

		if(tx.getMinLength() != null) {
			return tx;
		}	

		if(tx.getMinValue() != null) {
			return tx;
		}	

		if(tx.getMultiLingual() != TERTIARY_BOOL.UNSET) {
			return tx;
		}	

		if(tx.getPattern() != null) {
			return tx;
		}	

		if(tx.getSequence() != TERTIARY_BOOL.UNSET) {
			return tx;
		}
		if(tx.getStartTime() != null) {
			return tx;
		}	
		if(tx.getStartValue() != null) {
			return tx;
		}	
		if(tx.getTextType() != null) {
			return tx;
		}
		return null;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(minLength != null) {
			if(minLength.intValue() ==0) {
				LOG.warn("Text format of 0 converted to 1");
				minLength = BigInteger.ONE;
			} else if(minLength.intValue() < 0) {
				throw new SdmxSemmanticException("Invalid Text Format, min length must be a positive integer - got " + minLength.intValue());
			}
		}
		if(maxLength != null) {
			if(maxLength.intValue() <= 0) {
				throw new SdmxSemmanticException("Invalid Text Format, max length must be a positive integer - got " + maxLength.intValue());
			}
		}
		if(minLength != null && maxLength != null) {
			if(minLength.compareTo(maxLength) > 0) {
				throw new SdmxSemmanticException("Invalid Text Format, min length can not be greater then max length");
			}
		} 
		if(minValue != null && maxValue != null) {
			if(minValue.compareTo(maxValue) > 0) {
				throw new SdmxSemmanticException("Invalid Text Format, min value can not be greater then max value");
			}
		} 
		if(decimals != null) {
			if(decimals.intValue() <=0) {
				throw new SdmxSemmanticException("Invalid Text Format, decimals must be a positive integer - got " + decimals.intValue());
			}
		}
		if(startTime != null && endTime != null) {
			if(startTime.isLater(endTime)) {
				throw new SdmxSemmanticException("Invalid Text Format, start time can not be after end time");
			}
		}
		if(isMultiLingual == TERTIARY_BOOL.TRUE) {
			TEXT_TYPE tt = getTextType();
			if(tt != null && !(tt == TEXT_TYPE.STRING || tt == TEXT_TYPE.XHTML)) {
				throw new SdmxSemmanticException("Invalid Text Format, multilingual can only be set for String or XHTML representations");
			}
		}
		// FR-901: Removed all validation for "isSequence"
		/*
		if(isSequence.isTrue()) {
			if(timeInterval == null && interval == null) {
				throw new SdmxSemmanticException("Invalid Text Format, time interval or interval must be set if isSequence is set to true");
			}
			if(ObjectUtil.validString(timeInterval) && startTime == null) {
				throw new SdmxSemmanticException("Invalid Text Format, start time must be set if time interval is set");
			}
			if(interval != null && startValue == null) {
				throw new SdmxSemmanticException("Invalid Text Format, start value must be set if interval is set");
			}
		} else {
			if(ObjectUtil.validString(timeInterval)) {
				throw new SdmxSemmanticException("Invalid Text Format, time interval can only be set if isSequence is set to true");
			}
//			if(startTime != null) {
//				throw new SdmxSemmanticException("Invalid Text Format, start time can only be set if isSequence is set to true");
//			}
			if(interval != null) {
				throw new SdmxSemmanticException("Invalid Text Format, interval can only be set if isSequence is set to true");
			}
			if(startValue != null) {
				throw new SdmxSemmanticException("Invalid Text Format, start value can only be set if isSequence is set to true");
			}
		}
		*/
		if(ObjectUtil.validString(timeInterval)) {
			//Validate that the time interval matches the allowed xs:duration format PnYnMnDTnHnMnS - Use the RegEx, and make sure the string
			//is greater then length 1, as the RegEx does not ensure that there is any content after the P
			//The RegEx ensures if there is anything after the P, it is of the valid type, example P5Y and P91DT12M are both valid formats
			Pattern timeIntervalPattern = Pattern.compile("P(([0-9]+Y)?([0-9]+M)?([0-9]+D)?)(T([0-9]+H)?([0-9]+M)?([0-9]+S)?)?");
			if(timeInterval.length() == 1 || !timeIntervalPattern.matcher(timeInterval).matches()) {
				throw new SdmxSemmanticException("Invalid time interval, pattern must be PnYnMnDTnHnMnS, where n=positive integer, and each section is optional after each n (example P5Y)");
			}
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			boolean returnVal = true;
			TextFormatBean that = (TextFormatBean) bean;
			if(!super.equivalent(textType, that.getTextType(), "Text Type", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(isSequence, that.getSequence(), "Is Sequence", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(isMultiLingual, that.getMultiLingual(), "Is Multilingual", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(minLength, that.getMinLength(), "Min Length", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(maxLength, that.getMaxLength(), "Max Length", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(minValue, that.getMinValue(), "Min Value", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(maxValue, that.getMaxValue(), "Max Value", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(startValue, that.getStartValue(), "Start Value", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(endValue, that.getEndValue(), "End Value", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(interval, that.getInterval(), "Interval", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(timeInterval, that.getTimeInterval(), "Time Interval", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(decimals, that.getDecimals(), "Decimals", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(pattern, that.getPattern(), "Pattern", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(startTime, that.getStartTime(), "Start Time", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(endTime, that.getEndTime(), "End Time", diff)) {
				returnVal =  false;
			}
			return returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public TEXT_TYPE getTextType() {
		return textType;
	}

	@Override
	public String getKey() {
		return null;
	}

	@Override
	public SdmxDate getStartTime() {
		return startTime;
	}

	@Override
	public SdmxDate getEndTime() {
		return endTime;
	}

	@Override
	public TERTIARY_BOOL getSequence() {
		return isSequence;
	}

	@Override
	public BigInteger getMinLength() {
		return minLength;
	}

	@Override
	public BigInteger getMaxLength() {
		return maxLength;
	}

	@Override
	public BigDecimal getMinValue() {
		return minValue;
	}

	@Override
	public BigDecimal getMaxValue() {
		return maxValue;
	}

	@Override
	public BigDecimal getStartValue() {
		return startValue;
	}

	@Override
	public BigDecimal getEndValue() {
		return endValue;
	}

	@Override
	public BigDecimal getInterval() {
		return interval;
	}

	@Override
	public String getTimeInterval() {
		return timeInterval;
	}

	@Override
	public BigInteger getDecimals() {
		return decimals;
	}

	@Override
	public String getPattern() {
		return pattern;
	}

	@Override
	public TERTIARY_BOOL getMultiLingual() {
		return isMultiLingual;
	}
	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}
	
	@Override
    public boolean hasRestrictions() {
		return (getDecimals() != null ||
				getEndTime() != null ||
				getEndValue() != null ||
				getInterval() != null ||
				getMaxLength() != null ||
				getMaxValue() != null ||
				getMinLength() != null ||
				getMinValue() != null ||
				getPattern() != null ||
				getStartTime() != null ||
				getStartValue() != null ||
				getTimeInterval() != null) ||
				getMultiLingual() == TERTIARY_BOOL.TRUE;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		if(textType != null) {
			sb.append(textType.getSdmx21Value());
			concat=": ";
		}
		if(isSequence != TERTIARY_BOOL.UNSET) {
			sb.append(concat+"Sequence="+isSequence.isTrue());
			concat=", ";
		}
		if(isMultiLingual != TERTIARY_BOOL.UNSET) {
			sb.append(concat+"Multilingual="+isMultiLingual.isTrue());
			concat=", ";
		}
		if(minLength != null) {
			sb.append(concat+"Min Length="+minLength);
			concat=", ";
		}
		if(maxLength != null) {
			sb.append(concat+"Max Length="+maxLength);
			concat=", ";
		}
		if(startValue != null) {
			sb.append(concat+"Start Value="+startValue);
			concat=", ";
		}
		if(endValue != null) {
			sb.append(concat+"End Value="+endValue);
			concat=", ";
		}
		if(minValue != null) {
			sb.append(concat+"Min Value="+minValue);
			concat=", ";
		}
		if(maxValue != null) {
			sb.append(concat+"Max Value="+maxValue);
			concat=", ";
		}
		if(interval != null) {
			sb.append(concat+"Interval="+interval);
			concat=", ";
		}
		if(timeInterval != null) {
			sb.append(concat+"Time Interval="+timeInterval);
			concat=", ";
		}
		if(decimals != null) {
			sb.append(concat+"Decimals="+decimals);
			concat=", ";
		}
		if(pattern != null) {
			sb.append(concat+"Pattern="+pattern);
			concat=", ";
		}
		if(startTime != null) {
			sb.append(concat+"Start Time="+startTime);
			concat=", ";
		}
		if(endTime != null) {
			sb.append(concat+"End Time="+endTime);
			concat=", ";
		}
		return sb.toString();
	}
}

