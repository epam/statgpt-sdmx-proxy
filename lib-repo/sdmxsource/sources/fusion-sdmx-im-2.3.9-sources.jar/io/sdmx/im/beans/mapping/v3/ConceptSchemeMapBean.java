package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ConceptSchemeMapMutableBean;

public class ConceptSchemeMapBean extends GenericItemSchemeMapBean<IConceptMapBean> implements IConceptSchemeMapBean {
	private static final long serialVersionUID = 12L;

	/**
	 * Stub constructor
	 */
	ConceptSchemeMapBean(IConceptSchemeMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConceptSchemeMapBean(IConceptSchemeMapMutableBean bean) {
		super(bean);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IConceptSchemeMapBean.class;
	}

	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CONCEPT;
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ConceptSchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ConceptSchemeMapMutableBean getMutableInstance() {
		return new ConceptSchemeMapMutableBean(this);
	}

	@Override
	protected IConceptMapBean buildItemMap(IItemMapMutableBean mutable) {
		return new ConceptMapBean(mutable, this);
	}

    @Override
    public ConceptSchemeMapBeanDeferred toDeferred() {
        return new ConceptSchemeMapBeanDeferred(this);
    }
    
    @Override
    public ConceptSchemeMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ConceptSchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
