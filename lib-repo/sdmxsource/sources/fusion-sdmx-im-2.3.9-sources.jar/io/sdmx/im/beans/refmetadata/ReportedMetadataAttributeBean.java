package io.sdmx.im.beans.refmetadata;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.im.beans.base.TextTypeBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class ReportedMetadataAttributeBean extends AnnotableBeanImpl implements IReportedMetadataAttributeBean {
	private static final long serialVersionUID = 1L;
	private String value;
	private String attributeId;
	private TextTypeBean structuredValue;
	private List<IReportedMetadataAttributeBean> attributes;
	private transient String fullId;

	protected ReportedMetadataAttributeBean(IReportedMetadataAttributeMutableBean bean, IReportedMetadataSetBean parent) {
		this(parent, bean);
	}
		
	private ReportedMetadataAttributeBean(SdmxStructureBean parent, IReportedMetadataAttributeMutableBean bean) {
		super(bean, parent);
		if(ObjectUtil.validString(bean.getValue())) {
			this.value = bean.getValue();
		}
		this.attributeId = StringUtil.manualIntern(bean.getId());
		if(bean.getStructuredValues() != null) {
			this.structuredValue = new TextTypeBeanImpl("structuredvalue", bean.getStructuredValues(), this);
		}
		if(ObjectUtil.validCollection(bean.getAttributes())) {
			this.attributes = new ArrayList<>(bean.getAttributes().size());
			for(IReportedMetadataAttributeMutableBean currentAttr : bean.getAttributes()) {
				this.attributes.add(new ReportedMetadataAttributeBean(this, currentAttr));
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(ObjectUtil.validString(value)) {
			if(structuredValue != null) {
				throw new SdmxSemmanticException("Metadata Attribute can not contain both structured text and simple values");
			}
		}  else {
			value = null;
		}
		if(attributes == null)  {
			this.attributes = Collections.emptyList();
		} else {
			this.attributes = Collections.unmodifiableList(attributes);
		}
	}	


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IReportedMetadataAttributeBean that = (IReportedMetadataAttributeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.getStructuredValue(), that.getStructuredValue(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getValue(), that.getValue(), "value", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(this.getAttributes(), composites);
		return composites;
	}
	
	@Override
	public String getId() {
		return this.attributeId;
	}

	@Override
	public String getFullId() {
		if(fullId == null) {
			StringBuilder sb = new StringBuilder();
			IReportedMetadataAttributeBean parentMa = this;
			IReportedMetadataAttributeBean ma;
			while(parentMa != null) {
				ma = parentMa;
				SdmxStructureBean parent = ma.getParent();
				sb.append(ma.getId());
				int index = 0;
				List<IReportedMetadataAttributeBean> siblings;
				if(parent instanceof IReportedMetadataAttributeBean) {
					parentMa = (IReportedMetadataAttributeBean) parent;
					siblings = ma.getAttributes();
				} else {
					IReportedMetadataSetBean metadataSet = (IReportedMetadataSetBean) parent;
					siblings = metadataSet.getAttributes();
					parentMa = null;
				}
				index = siblings.indexOf(ma);
				sb.append("["+index+"]");
			}
		}
		return fullId;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public TextTypeBean getStructuredValue() {
		return structuredValue;
	}

	@Override
	public List<IReportedMetadataAttributeBean> getAttributes() {
		return this.attributes;
	}
}
