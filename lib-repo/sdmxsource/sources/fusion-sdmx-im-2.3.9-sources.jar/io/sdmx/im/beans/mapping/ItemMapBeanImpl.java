package io.sdmx.im.beans.mapping;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ItemMapBeanImpl extends AnnotableBeanImpl implements ItemMapBean {
	private static final long serialVersionUID = 11L;

	private String sourceId;
	private String targetId;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ItemMapBeanImpl(ItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		this.sourceId = bean.getSourceId();
		this.targetId = bean.getTargetId();
		validate();
	}
	
	public ItemMapBeanImpl(String id, String target, SdmxStructureBean parent) {
		super(SDMX_STRUCTURE_TYPE.ITEM_MAP, parent);
		this.sourceId = id;
		this.targetId = target;
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ItemMapBean that = (ItemMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(sourceId, that.getSourceId(), "Source ", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetId, that.getTargetId(), "Target", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(this.sourceId)) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, "ItemMap", "Source Id");
		}
		if(!ObjectUtil.validString(this.targetId)) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, "ItemMap", "Target Id");
		}
//		sourceId = ValidationUtil.cleanAndValidateId(sourceId, true);
//		targetId = ValidationUtil.cleanAndValidateId(targetId, true);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS							 	 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getSourceId() {
		return sourceId;
	}

	@Override
	public String getTargetId() {
		return targetId;
	}

	@Override
	public String getKey() {
		return sourceId +"-"+targetId;
	}
}
