package io.sdmx.im.beans.transformation;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class RulesetSchemeBeanDeferred extends ItemSchemeBeanDeffered<IRulesetBean, IRulesetSchemeBean> implements IRulesetSchemeBean {
    private static final long serialVersionUID = 1L;

    public RulesetSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public RulesetSchemeBeanDeferred(IRulesetSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public IRulesetSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new RulesetSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected RulesetSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new RulesetSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IRulesetSchemeBean> getURN() {
        return (IURNMaintainable<IRulesetSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IRulesetSchemeBean.class;
    }
    
    @Override
    public IRulesetSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public String getVtlVersion() {
        return load().getVtlVersion();
    }

    @Override
    public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
        return load().getVtlMappingSchemeRef();
    }
}
