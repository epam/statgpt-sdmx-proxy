package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.im.beans.base.TimeRangeBeanImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class KeyValuesImpl extends SdmxStructureBeanImpl implements KeyValues, INoCrossReferencesBean {
	private static final long serialVersionUID = 3L;
	private String id;
	private Set<String> cascade = new HashSet<>();
//	private Set<String> cascadeExcludeRoot = new HashSet<>();
	private Map<String, SdmxPeriod> validity = Collections.emptyMap();
	private Set<String> values;
	private TimeRangeBean timeRangeBean;
	private boolean removePrefix;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public KeyValuesImpl(KeyValuesMutable mutable, SdmxStructureBean parent) {
		super(SDMX_STRUCTURE_TYPE.KEY_VALUES, parent);
		this.id = mutable.getId();
		if(mutable.getCascade() != null) {
			for (String each : mutable.getCascade()) {
				if(each != null) {
					this.cascade.add(StringUtil.manualIntern(each));
				}
			}
		}
//		if(mutable.getCascadeExcludeRoot() != null) {
//			for (String each : mutable.getCascadeExcludeRoot()) {
//				this.cascadeExcludeRoot.add(StringUtil.manualIntern(each));
//			}
//		}
		this.removePrefix = mutable.isRemovePrefix();
		if(mutable.getTimeRange() != null) {
			this.timeRangeBean = new TimeRangeBeanImpl(mutable.getTimeRange(), this);
		}
		values = Collections.emptySet();
		if(mutable.getKeyValues() != null) {
			values = new TreeSet<>();
			for(String value : mutable.getKeyValues()) {
				if(value != null) {
					values.add(value);
				}
			}
			Set<String> allValues;
			if(cascade.size() == 0) {
				allValues = values;
			} else {
				allValues = new HashSet<>(values);
				allValues.addAll(cascade);
			}
			int size = allValues.size();
			validity = new HashMap<>(size);
			for(String value : allValues) {
				value = StringUtil.manualIntern(value);
				String validFrom = mutable.getValidFrom(value);
				String validTo = mutable.getValidTo(value);
				SdmxPeriod period;
				if(ObjectUtil.validString(validFrom) || ObjectUtil.validString(validTo)) {
					period = new SdmxPeriodImpl(validFrom, validTo);
				}	 else {
					period = SdmxPeriodImpl.ALL_PERIODS;
				}
				validity.put(value, period);
			}
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(id)) {
			throw new SdmxSemmanticException("KeyValues requires an id");
		}
		this.cascade = Collections.unmodifiableSet(cascade);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			KeyValues that = (KeyValues) bean;
			boolean returnVal = true;
			if(!ObjectUtil.equivalentCollection(values, that.getValues())) {
			    returnVal = false;
                if (diff == null) {
                    return false;
                }
                calculateDiffs(values, that.getValues(), diff, id, that.getId());
			}
//			if(!super.equivalentCollection(this, this.values, that.getValues(), "Constrained Values", diff)) {
//				returnVal = false;
//			}
			if(!super.equivalentCollection(this, this.cascade, that.getCascadeValues(), "Cascade", diff)) {
				returnVal = false;
			}
			for(String val : that.getValues()) {
				SdmxPeriod period = this.getValidityPeriod(val);
				if(period != null) {
					if(!super.equivalent(period, that.getValidityPeriod(val), "Validity Period: "+val, diff)) {
						returnVal = false;
					}		
				}
			}
			for(String val : that.getCascadeExcludeRoot()) {
				SdmxPeriod period = this.getValidityPeriod(val);
				if(period != null) {
					if(!super.equivalent(period, that.getValidityPeriod(val), "Validity Period: "+val, diff)) {
						returnVal = false;
					}		
				}
			}
			if(!super.equivalent(this.id, that.getId(), "Component Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.removePrefix, that.isRemovePrefix(), "Remove Prefix", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(timeRangeBean, that.getTimeRange(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	private void calculateDiffs(Set<String> c1, Set<String> c2, DiffReport diff, String id1, String id2) {
        if (diff == null) {
            return;
        }

        if(c1 == null && c2 == null) {
            return;
        }
        if(c2 == null && c1 != null) {
            diff.addDiff(this, id1 + " has content but " + id2 + " does not", null, null);
            return;
        }
        if(c1 == null && c2 != null) {
            diff.addDiff(this, id2 + " has content but " + id1 + " does not", null, null);
            return;
        }

        // Both lists are not null
        // Determine items in source
        List<String> tmpList1 = new ArrayList<>(c1);
        List<String> tmpList2 = new ArrayList<>(c2);
        tmpList1.removeAll(tmpList2);
        for (String string : tmpList1) {
            diff.addDiff(this, "KeyValue '" + id1 + "'", null, string);
        }

        // Determine items in target
        tmpList1 = new ArrayList<>(c1);
        tmpList2 = new ArrayList<>(c2);
        tmpList2.removeAll(tmpList1);
        for (String string : tmpList2) {
            diff.addDiff(this, "KeyValue '" + id2 + "'", string, null);
        }
    }

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getId() {
		return id;
	}

	@Override
	public boolean isRemovePrefix() {
		return removePrefix;
	}

	@Override
	public SdmxPeriod getValidityPeriod(String value) {
		return validity.get(value);
	}

	@Override
	public Set<String> getValues() {
		return values;
	}

	@Override
	public Set<String> getCascadeValues() {
		return cascade;
	}
	
	@Override
	public Set<String> getCascadeExcludeRoot() {
		Set<String> cascade = new HashSet<>(getCascadeValues());
		cascade.removeAll(this.values);
		return cascade;
	}

	@Override
	public boolean isCascadeValue(String value) {
		return cascade.contains(value);
	}

	@Override
	public boolean isIncluded() {
		return getParent(ContentConstraintBean.class, false).getIncludedCubeRegion() == getParent(CubeRegionBean.class, false);
	}

	@Override
	public TimeRangeBean getTimeRange() {
		return timeRangeBean;
	}

	@Override
	public String getKey() {
		return id;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(timeRangeBean, composites);
		return composites;
	}
	
	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
}
