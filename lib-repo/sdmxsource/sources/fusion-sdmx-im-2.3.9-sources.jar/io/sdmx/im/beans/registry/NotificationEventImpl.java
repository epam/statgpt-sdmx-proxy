package io.sdmx.im.beans.registry;

import java.util.Date;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.registry.NotificationEvent;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;

public class NotificationEventImpl implements NotificationEvent {
	private Date eventTime;
	private String objectUrn;
	private String subscriptionUrn;
	private DATASET_ACTION action;
	private RegistrationBean registration;
	private SdmxBeans beans;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public Date getEventTime() {
		return eventTime;
	}

	@Override
	public String getObjectUrn() {
		return objectUrn;
	}

	@Override
	public String getSubscriptionUrn() {
		return subscriptionUrn;
	}

	@Override
	public DATASET_ACTION getAction() {
		return action;
	}

	@Override
	public SdmxBeans getBeans() {
		return beans;
	}

	@Override
	public RegistrationBean getRegistration() {
		return registration;
	}
}
