package io.sdmx.im.beans.base;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;

public class MetadataProviderSchemeBeanDeferred extends OrganisationSchemeBeanDeferred<IMetadataProviderBean, IMetadataProviderSchemeBean> implements IMetadataProviderSchemeBean {
    private static final long serialVersionUID = 1L;

    public MetadataProviderSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public MetadataProviderSchemeBeanDeferred(IMetadataProviderSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public IMetadataProviderSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataProviderSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected MetadataProviderSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProviderSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IMetadataProviderSchemeBean> getURN() {
        return (IURNMaintainable<IMetadataProviderSchemeBean>) super.getURN();
    }
    
    @Override
    public IMetadataProviderSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    protected Class<?> getConcreteInterface() {
        return IMetadataProviderSchemeBean.class;
    }
}
