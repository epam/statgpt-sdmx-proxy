package io.sdmx.im.beans.codelist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class CodelistInheritanceRuleBean extends SDMXBeanImpl implements ICodelistInheritanceRuleBean {
	private static final long serialVersionUID = 1L;
	private List<String> inclusiveInheritenceIds = Collections.emptyList();
	private Set<String> inclusiveInheritenceCascades = Collections.emptySet();
	private List<String> exclusiveInheritenceIds = Collections.emptyList();
	private Set<String> exclusiveInheritenceCascades = Collections.emptySet();
	private IDirectCrossReferenceBean<CodelistBean> codelistRef;
	private String prefix;
	
	public CodelistInheritanceRuleBean(ICodelistInheritanceRuleMutableBean mutableBean, CodelistBean parent) {
		super(mutableBean, parent);
		if(mutableBean.getInclusiveInheritenceIds() != null) {
			this.inclusiveInheritenceIds = new ArrayList<>(mutableBean.getInclusiveInheritenceIds());
		}
		if(mutableBean.getInclusiveInheritenceCascades() != null) {
			this.inclusiveInheritenceCascades = new HashSet<>(mutableBean.getInclusiveInheritenceCascades());
		}
		if(mutableBean.getExclusiveInheritenceIds() != null) {
			this.exclusiveInheritenceIds = new ArrayList<>(mutableBean.getExclusiveInheritenceIds());
		}
		if(mutableBean.getExclusiveInheritenceCascades() != null) {
			this.exclusiveInheritenceCascades = new HashSet<>(mutableBean.getExclusiveInheritenceCascades());
		}
		this.prefix = mutableBean.getPrefix();
		if(mutableBean.getCodelistRef() != null) {
			this.codelistRef = DirectCrossReferenceBean.build(parent, "codelist", mutableBean.getCodelistRef(), CodelistBean.class);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		this.inclusiveInheritenceIds = Collections.unmodifiableList(this.inclusiveInheritenceIds);
		this.exclusiveInheritenceIds = Collections.unmodifiableList(this.exclusiveInheritenceIds);
		this.inclusiveInheritenceCascades = Collections.unmodifiableSet(this.inclusiveInheritenceCascades);
		this.exclusiveInheritenceCascades = Collections.unmodifiableSet(this.exclusiveInheritenceCascades);

		if(codelistRef == null) {
			throw new SdmxSemmanticException("Codelist extension requires Codelist reference");
		}
	}

	@Override
	public String getKey() {
		return codelistRef.toString();
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		boolean returnVal = true;
		ICodelistInheritanceRuleBean that = (ICodelistInheritanceRuleBean) bean;
		if(!super.equivalentCollection(this, inclusiveInheritenceIds, that.getInclusiveInheritenceIds(), "Inclusive Inheritence Ids", diff)) {
			returnVal = false;
		}
		if(!super.equivalentCollection(this, inclusiveInheritenceCascades, that.getInclusiveInheritenceCascades(), "Inclusive Inheritence Cascades", diff)) {
			returnVal = false;
		}
		if(!super.equivalentCollection(this, exclusiveInheritenceIds, that.getExclusiveInheritenceIds(), "Exclusive Inheritence Ids", diff)) {
			returnVal = false;
		}
		if(!super.equivalentCollection(this, exclusiveInheritenceCascades, that.getExclusiveInheritenceCascades(), "Exclusive Inheritence Cascades", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(codelistRef, that.getCodelistRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.prefix, that.getPrefix(), "Codelist Inheritence Prefix", diff)) {
			returnVal = false;
		}
		return returnVal;
	}

	@Override
	public ICrossReferenceBean<CodelistBean> getCodelistRef() {
		return codelistRef;
	}

	@Override
	public String getPrefix() {
		return prefix;
	}

	@Override
	public List<String> getInclusiveInheritenceIds() {
		return inclusiveInheritenceIds;
	}

	@Override
	public Set<String> getInclusiveInheritenceCascades() {
		return inclusiveInheritenceCascades;
	}

	@Override
	public List<String> getExclusiveInheritenceIds() {
		return exclusiveInheritenceIds;
	}

	@Override
	public Set<String> getExclusiveInheritenceCascades() {
		return exclusiveInheritenceCascades;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.add(codelistRef);
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}
}
