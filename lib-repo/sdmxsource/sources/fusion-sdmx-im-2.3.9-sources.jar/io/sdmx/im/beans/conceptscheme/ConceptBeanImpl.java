package io.sdmx.im.beans.conceptscheme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.im.beans.base.RepresentationBeanImpl;
import io.sdmx.im.beans.items.ValidityPeriodItemBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ConceptBeanImpl extends ValidityPeriodItemBean implements ConceptBean {
	private static final long serialVersionUID = 12L;
	private String parentConcept;
	private String parentAgency;
	private IDirectCrossReferenceBean<ConceptBean> isoConceptReference;
	private RepresentationBean coreRepresentation;
	private transient List<ConceptBean> childConcepts = null;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConceptBeanImpl(ConceptSchemeBean parent, ConceptMutableBean bean, int position) {
		super(bean, parent, position, bean.getSdmxPeriod().orElse(null));
		if(bean.getCoreRepresentation() != null && (bean.getCoreRepresentation().getTextFormat() != null || bean.getCoreRepresentation().getRepresentation() != null)) {
			this.coreRepresentation = RepresentationBeanImpl.getInstance(bean.getCoreRepresentation(), this);
		}
		if(bean.getIsoConceptReference() != null) {
			this.isoConceptReference = DirectCrossReferenceBean.build(this, "isoconcept", bean.getIsoConceptReference(), ConceptBean.class);
		}
		this.parentConcept = bean.getParentConcept();
		this.parentAgency = bean.getParentAgency();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConceptBean that = (ConceptBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(parentConcept, that.getParentConcept(), "Parent Concept", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(parentAgency, that.getParentAgency(), "Parent Agency", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isoConceptReference, that.getIsoConceptReference(), "ISO Concept Reference", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(coreRepresentation, that.getRepresentation(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal((ValidityPeriodBean)that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected void validateId(boolean startWithIntAllowed) {
		//Not allowed to start with an integer
		super.validateId(false);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ConceptBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<ConceptBean> getURN() {
		return (IURNAbsolute<ConceptBean>)super.getURN();
	}
	
	@Override
	public boolean isStandAloneConcept() {
		return false;
	}

	@Override
	public RepresentationBean getRepresentation() {
		return coreRepresentation;
	}

	@Override
	public String getParentConcept() {
		return parentConcept;
	}

	@Override
	public String getParentAgency() {
		return parentAgency;
	}

	@Override
	public ICrossReferenceBean<ConceptBean> getIsoConceptReference() {
		return isoConceptReference;
	}
	
	@Override
	public List<ConceptBean> getItems() {
		if(childConcepts == null) {
			childConcepts = new ArrayList<>();
			ConceptSchemeBean parent = (ConceptSchemeBean)super.getMaintainableParent();
			for(ConceptBean concept : parent.getItems()) {
				if(this.getId().equals(concept.getParentConcept())) {
					childConcepts.add(concept);
				}
			}
			childConcepts = Collections.unmodifiableList(childConcepts);
		}
		return childConcepts;
	}
	
	@Override
	public boolean isHierarchyExplicit() {
		return false;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if (getIsoConceptReference() != null) {
			references.add(getIsoConceptReference());
		}
	}

	@Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(coreRepresentation, composites);
        return composites;
    }
	
	@Override
	public ConceptSchemeBean getMaintainableParent() {
		return (ConceptSchemeBean)super.getMaintainableParent();
	}
}