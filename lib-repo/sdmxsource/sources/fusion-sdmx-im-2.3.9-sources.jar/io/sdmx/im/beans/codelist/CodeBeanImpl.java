package io.sdmx.im.beans.codelist;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.im.beans.items.ValidityPeriodItemBean;

public class CodeBeanImpl extends ValidityPeriodItemBean implements CodeBean {
	private static final long serialVersionUID = 12L;
	private String parentCode;
	private boolean inherited;
	private transient List<CodeBean> childCodes;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CodeBeanImpl(CodelistBean parent, CodeMutableBean bean, int position) {
		super(bean, parent, position,  bean.getSdmxPeriod().orElse(null));
		this.parentCode = bean.getParentCode();
		this.inherited = parent.hasInherited() && bean.isInherited();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			CodeBean that = (CodeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(parentCode, that.getParentCode(), "Parent Id", diff)) {
				returnVal =  false;
			}
			//purposefully do not include inherited in this check as it allows the system to ask if a code from one codelist is the same as another without
			//taking this into account
			return super.deepEqualsInternal((ValidityPeriodBean)that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException{
		in.defaultReadObject();
		today = new Date();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return CodeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<CodeBean> getURN() {
		return (IURNAbsolute<CodeBean>) super.getURN();
	}
	
	@Override
	public String getParentCode() {
		return parentCode;
	}

	@Override
	public boolean isInherited() {
		return inherited;
	}

	@Override
	public List<CodeBean> getItems() {
		if(childCodes == null) {
			childCodes = new ArrayList<>();
			CodelistBean parent = (CodelistBean)super.getMaintainableParent();
			for(CodeBean concept : parent.getItems()) {
				if(this.getId().equals(concept.getParentCode())) {
					childCodes.add(concept);
				}
			}
			childCodes = Collections.unmodifiableList(childCodes);
		}
		return childCodes;
	}

	@Override
	public boolean isHierarchyExplicit() {
		return false;
	}

}
