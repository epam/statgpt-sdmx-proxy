package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemSchemeMapMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

/**
 * Where source and target can be represented by ItemMapBean
 */
public abstract class GenericItemSchemeMapBean<T extends IItemMapBean> extends ItemSchemeMapBean<T> {
	private static final long serialVersionUID = 1L;
	private List<T> items = new ArrayList<>();

	/**
	 * Stub constructor
	 */
	protected GenericItemSchemeMapBean(IItemSchemeMapBean<T> bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public GenericItemSchemeMapBean(IItemSchemeMapMutableBean<? extends IItemMapMutableBean> bean) {
		super(bean);
		if (bean.getItems() != null) {
			for (IItemMapMutableBean item : bean.getItems()) {
				items.add(buildItemMap(item));
			}
		}
		this.items = Collections.unmodifiableList(items);
	}

	@Override
	public List<T> getItems() {
		return items;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		super.getCrossReferences(references);
		items.forEach(item-> {
			URNBuilder sourceBuilder = URN.builder(getSourceRef().getReference().getURN());
			URNBuilder targetBuilder = URN.builder(getTargetRef().getReference().getURN());
			sourceBuilder.structure(getItemType());
			targetBuilder.structure(getItemType());
			if(item.isSourceAbsolute()) {
				sourceBuilder.identifableId(item.getSourceId());
				references.add(DirectCrossReferenceBean.build(this, "source", sourceBuilder.buildSingle()));
			}
			if(item.isTargetAbsolute()) {
				targetBuilder.identifableId(item.getTargetId());
				references.add(DirectCrossReferenceBean.build(this, "target", sourceBuilder.buildSingle()).build(this, targetBuilder.buildSingle()));
			}
		});
	}
	
	protected abstract T buildItemMap(IItemMapMutableBean mutable);
}
