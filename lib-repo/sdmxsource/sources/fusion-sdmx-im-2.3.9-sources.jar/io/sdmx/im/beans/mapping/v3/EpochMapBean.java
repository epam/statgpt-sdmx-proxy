package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * <p>A specialisation of {@link TimeComponentMapBean} used to describe a numerical representation of time, and how this maps to SDMX Time Periods.</p>
 * <br/>
 * <p>For example 1605719750 is 2020-11-18 if the Epoch is milliseconds and the base period is 1970 with output frequency as daily </p>
 */
public class EpochMapBean extends TimeComponentMapBean implements IEpochMapBean {
	private static final long serialVersionUID = 1L;
	private SdmxDate basePeriod;
	private EPOCH epochInterval;
	
	public EpochMapBean(IEpochMapMutableBean bean, IStructureMapBean parent) {
		super(bean, parent);
		if(bean.getBasePeriod() != null) {
			this.basePeriod = SdmxDateImpl.getSdmxDate(bean.getBasePeriod());
		}
		this.epochInterval = bean.getEpochInterval();
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(basePeriod == null) {
			throw new SdmxSemmanticException("Epoch Map missing base period");
		}
		if(epochInterval == null) {
			throw new SdmxSemmanticException("Epoch Map missing epoch interval");
		}
		if(!ObjectUtil.validOneString(getOutputFrequencyDimId(), getOutputFrequencyId())) {
			throw new SdmxSemmanticException("Output Frequency Id or Output Frequency Dimension is required");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IEpochMapBean that = (IEpochMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(basePeriod, that.getBasePeriod(), "Base Period", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(epochInterval, that.getEpochInterval(), "Epoch Interval", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public SdmxDate getBasePeriod() {
		return basePeriod;
	}
	
	@Override
	public String getKey() {
		return null;
	}

	@Override
	public EPOCH getEpochInterval() {
		return epochInterval;
	}
}
