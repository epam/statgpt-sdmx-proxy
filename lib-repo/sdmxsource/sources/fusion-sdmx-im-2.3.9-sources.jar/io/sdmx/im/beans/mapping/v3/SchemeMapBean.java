package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ISchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ISchemeMapMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public abstract class SchemeMapBean extends MaintainableBeanImpl implements ISchemeMapBean {
	private static final long serialVersionUID = 13L;

	protected IDirectCrossReferenceBean<? extends ItemSchemeBean> sourceRef;
	protected IDirectCrossReferenceBean<? extends ItemSchemeBean> targetRef;

	/**
	 * Stub constructor
	 */
	protected SchemeMapBean(ISchemeMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	SchemeMapBean(ISchemeMapMutableBean bean) {
		super(bean);
		if(bean.getSourceRef() != null) {
			this.sourceRef =  DirectCrossReferenceBean.build(this, "source", bean.getSourceRef(), ItemSchemeBean.class);
		}
		if(bean.getTargetRef() != null) {
			this.targetRef = DirectCrossReferenceBean.build(this, "target", bean.getTargetRef(), ItemSchemeBean.class);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(sourceRef == null) {
			throw new SdmxSemmanticException(getStructureType().getType() + " - Source Ref can not be null");
		}
		if(targetRef == null) {
			throw new SdmxSemmanticException(getStructureType().getType() + " - Target Ref can not be null");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected boolean deepEqualsInternal(NameableBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			SchemeMapBean that = (SchemeMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(sourceRef, that.getSourceRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetRef, that.getTargetRef(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public ICrossReferenceBean<? extends ItemSchemeBean> getSourceRef() {
		return sourceRef;
	}

	@Override
	public ICrossReferenceBean<? extends ItemSchemeBean> getTargetRef() {
		return targetRef;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(sourceRef != null) {
			references.add(sourceRef);
		}
		if(targetRef != null) {
			references.add(targetRef);
		}
	}
}


