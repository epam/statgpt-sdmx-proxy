package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;

public class ConceptSchemeMapBeanDeferred extends GenericItemSchemeMapBeanDeferred<IConceptMapBean, IConceptSchemeMapBean> implements IConceptSchemeMapBean {
    private static final long serialVersionUID = 1L;

    public ConceptSchemeMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ConceptSchemeMapBeanDeferred(IConceptSchemeMapBean maint) {
        super(maint);
    }
    
    @Override
    public IConceptSchemeMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ConceptSchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected ConceptSchemeMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ConceptSchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IConceptSchemeMapBean> getURN() {
        return (IURNMaintainable<IConceptSchemeMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IConceptSchemeMapBean.class;
    }

    @Override
    public IConceptSchemeMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
