package io.sdmx.im.beans.calculation;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleMutableBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.format.FusionMetadataStandard;
import io.sdmx.im.mutable.expression.ValidationSchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ValidationSchemeBeanImpl extends ItemSchemeBeanImpl<ValidationRuleBean> implements ValidationSchemeBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<DataflowBean> attachment;

	public ValidationSchemeBeanImpl(ValidationSchemeMutableBean bean) {
		super(bean);
		if(bean.getAttachment() != null) {
			attachment = DirectCrossReferenceBean.build(this, "attachment", bean.getAttachment(), DataflowBean.class);
		}
		try {
			if(bean.getItems() != null) {
				int i = 1;
				for(ValidationRuleMutableBean rule : bean.getItems()) {
					this.items.add(new ValidationRuleBeanImpl(rule, this, i));
					i++;
				}
			}
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	public ValidationSchemeBeanImpl(ValidationSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(attachment == null) {
			throw new SdmxSemmanticException("Validation Scheme missing reference to Dataflow/Provision Agreement");
		}
		if(attachment.getTargetReference() != SDMX_STRUCTURE_TYPE.DATAFLOW &&
				attachment.getTargetReference() != SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT) {
			throw new SdmxSemmanticException("Validation Scheme refernce should reference a Dataflow or Provision Agreement, it is referencing a "+attachment.getTargetReference());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ValidationSchemeBean that = (ValidationSchemeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(attachment, that.getAttachment(), "Dataflow Reference", diff)) {
				 returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, "Validation Rule", diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////CROSS REFERENCES		             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(getAttachment() != null) {
			references.add(getAttachment());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////OVERRIDE DEFAULT FORMAT			     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IMetadataStandard getDefaultStandard() {
		return FusionMetadataStandard.getInstance();
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return ValidationSchemeBean.class;
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ValidationSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}


	@Override
	public ValidationSchemeMutableBean getMutableInstance() {
		return new ValidationSchemeMutableBeanImpl(this);
	}

	@Override
	public ICrossReferenceBean<DataflowBean> getAttachment() {
		return attachment;
	}

    @Override
    public ValidationSchemeBeanDeferred toDeferred() {
        return new ValidationSchemeBeanDeferred(this);
    }
    
    @Override
    public ValidationSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ValidationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
