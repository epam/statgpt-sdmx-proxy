package io.sdmx.im.beans.datastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class DataflowBeanDeferred extends MaintainableBeanDeferred<DataflowBean> implements DataflowBean {
    private static final long serialVersionUID = 1L;

    public DataflowBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public DataflowBeanDeferred(DataflowBean maint) {
        super(maint);
    }
    
    @Override
    public DataflowBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new DataflowBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected DataflowBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new DataflowBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<DataflowBean> getURN() {
        return (IURNMaintainable<DataflowBean>) super.getURN();
    }

    @Override
    public DataflowMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return DataflowBean.class;
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public ICrossReferenceBean<DataStructureBean> getDataStructureRef() {
        return load().getDataStructureRef();
    }
}