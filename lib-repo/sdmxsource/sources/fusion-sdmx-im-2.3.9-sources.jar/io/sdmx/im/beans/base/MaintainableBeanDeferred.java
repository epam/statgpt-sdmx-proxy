package io.sdmx.im.beans.base;

import java.lang.ref.SoftReference;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.INoCrossReferencesMaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.mutable.base.MaintainableMutableBeanImpl;
import io.sdmx.im.serialiser.BeanSerialiserLoader;
import io.sdmx.utils.core.io.PathCleaner;

public abstract class MaintainableBeanDeferred<T extends MaintainableBean> extends MaintainableBeanImpl implements IMaintainableBeanDeferred<T> {
    private static final long serialVersionUID = 1L;
    private static PathCleaningSerialiser writer = new PathCleaningSerialiser();
    private IDeferredLoader<MaintainableBean> loader;
    private volatile SoftReference<T> deferred;
    private final IDeferredBeanDefinition deferredDefinition;
    private boolean isNoXS;
    
    protected MaintainableBeanDeferred(IDeferredBeanDefinition deferred, IDeferredLoader<MaintainableBean> loader) {
        super(buildMutable(deferred));
        this.deferredDefinition = deferred;
        this.loader = loader;
        setProperties(deferredDefinition);
    }
    
    /**
     * Takes a full {@link MaintainableBean} and creates a deferred definition, uses a standard serialiser to store the bean off heap
     * @param maint
     */
    protected MaintainableBeanDeferred(T maint) {
        super(buildMutable(maint.getDeferredDefinition()));
        this.deferredDefinition = maint.getDeferredDefinition();
        this.deferred = new SoftReference<T>(maint);
        writer.write(maint, this);
        this.loader = writer;
        setProperties(deferredDefinition);
    }
    
    private void setProperties(IDeferredBeanDefinition definition) {
        if(INoCrossReferencesMaintainableBean.class.isAssignableFrom(this.getClass())) {
            isNoXS = true;
        }
    }
    
    /**
     * Override the write method, creates the path and then registers the deferred bean as the
     * 'owner' of the path, when the deferred bean is garbage collected, the path is deleted from the file system
     */
    private static class PathCleaningSerialiser extends BeanSerialiserLoader {

        public void write(MaintainableBean deferrable, MaintainableBeanDeferred deferred) {
            Path p = getPath(deferrable);
            super.write(deferrable);
            PathCleaner.reigster(deferred, p); //Register so it can be removed
        }
    }
    
    private static MaintainableMutableBean buildMutable(IDeferredBeanDefinition deferred) {
        MaintainableMutableBean mutableBean = new DeferredMutableBean(deferred);
        mutableBean.setAgencyId(deferred.getUrn().getAgencyId());
        mutableBean.setId(deferred.getUrn().getMaintainableId());
        mutableBean.setVersion(deferred.getUrn().getVersion());
        if(deferred.getAnnotations() != null) {
            deferred.getAnnotations().forEach(e->mutableBean.addAnnotation(e));
        }
        mutableBean.setLinks(deferred.getLinks());
        deferred.getNames().forEach((k, v)->mutableBean.addName(k, v));
        deferred.getDescriptions().forEach((k, v)->mutableBean.addDescription(k, v));
        mutableBean.setStructureURL(deferred.getStructureURL());
        mutableBean.setServiceURL(deferred.getServiceURL());
        if(deferred.getValidityPeriod() != null) {
            if(deferred.getValidityPeriod().getStartPeriod() != null) {
                mutableBean.setStartDate(deferred.getValidityPeriod().getStartPeriod().getDate());
            }
            if(deferred.getValidityPeriod().getEndPeriod() != null) {
                mutableBean.setEndDate(deferred.getValidityPeriod().getEndPeriod().getDate());
            }
        }
        
        return mutableBean;
    }
    
    private static class DeferredMutableBean extends MaintainableMutableBeanImpl {

        private static final long serialVersionUID = 1L;

        public DeferredMutableBean(IDeferredBeanDefinition deferred) {
            super(SDMX_STRUCTURE_TYPE.getTypeByClass(deferred.getUrn().getStructureType().getClassType()));
        }

        @Override
        public MaintainableBean getImmutableInstance() {
            return null;
        }
    }
    
    @Override
    public String getChecksum() {
        return deferredDefinition.getChecksum();
    }
    
    @Override
    public boolean isCompatible(SDMX_SCHEMA schemaVersion) {
        return load().isCompatible(schemaVersion);
    }
    
    

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        this.deferred = null;//Clear deferred
        return this;
    }
    
    @Override
    public IMaintainableBeanDeferred<?> toDeferred(IDeferredLoader<MaintainableBean> loader) {
        if(this.loader == loader) {
            return this;
        }
        return copy(loader);
    }
    
    /**
     * Create a copy of itself with a new loader
     * @param loader
     * @return
     */
    protected abstract IMaintainableBeanDeferred<?> copy(IDeferredLoader<MaintainableBean> loader);

    @Override
    public IDeferredBeanDefinition getDeferredDefinition() {
        return this.deferredDefinition;
    }
    
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        return load().getComposites();
    }

    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
        if(!isNoXS) {
            load().getCrossReferences(references);
        }
    }
    
    @Override
    protected void buildCrossReferences() {
        if(isNoXS) {
            crossReferences = Collections.emptySet();
            crossReferencesFuzzy = Collections.emptySet();
        } else {
            super.buildCrossReferences();
        }
    }
    
    @Override
    public synchronized Set<String> getSupportedLanguages() {
        if(supportedLanguages == null) {
            //LAZY LOAD
            SortedSet<String> supportedLanguagesLocal = new TreeSet<>();
            for(TextTypeWrapper tt : getNames()) {
                supportedLanguagesLocal.add(tt.getLocale());
            }
            for(TextTypeWrapper tt : getDescriptions()) {
                supportedLanguagesLocal.add(tt.getLocale());
            }
            supportedLanguages = Collections.unmodifiableSortedSet(supportedLanguagesLocal);
        }
        return supportedLanguages;
    }

    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        //TODO Checksum
        return load().deepEquals(bean, includeFinalProperties, diff);
    }
    
    protected T load() {
        T returnBean = deferred == null ? null : deferred.get();
        if(returnBean == null) {
            returnBean = (T)loader.load(this);
            deferred = new SoftReference<T>(returnBean);
        }
        return returnBean;
    }
    
}
