package io.sdmx.im.beans.reference;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.query.RESTRegistrationQuery;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class RESTRegistrationQueryImpl implements RESTRegistrationQuery {
	private StructureReferenceBean structureReferenceBean;
	private SdmxDate updatedBeforeDate;
	private SdmxDate updatedAfterDate;
	
	private static final Set<String> supportedTypes;
	
	static {
		supportedTypes = new HashSet<>();
		addSupportedType(SDMX_STRUCTURE_TYPE.DATA_PROVIDER);
		addSupportedType(SDMX_STRUCTURE_TYPE.DSD);
		addSupportedType(SDMX_STRUCTURE_TYPE.DATAFLOW);
		addSupportedType(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
		addSupportedType(SDMX_STRUCTURE_TYPE.REGISTRATION);
	}
	
	private static void addSupportedType(SDMX_STRUCTURE_TYPE type) {
		supportedTypes.add(type.getUrnClass().toLowerCase());
	}
	
	/**
	 * Constructed from REST arguments
	 * @param queryString expects
	 * [provision|dataflow|datastructure|dataprovider]/agencyId/Id/Version/?startPeriod=2012&endPeriod=2013
	 * @param queryParameters
	 */
	public RESTRegistrationQueryImpl(String[] queryString, Map<String, String> queryParameters) {
		parserQueryString(queryString);
		parserQueryParameters(queryParameters);
	}

	public RESTRegistrationQueryImpl(StructureReferenceBean structureReferenceBean, SdmxDate updatedBeforeDate, SdmxDate updatedAfterDate) {
		this.structureReferenceBean = structureReferenceBean;
		this.updatedBeforeDate = updatedBeforeDate;
		this.updatedAfterDate = updatedAfterDate;
	}

	private void parserQueryString(String[] queryString) {
		if(queryString.length < 2) {
			//Query for All registrations
			structureReferenceBean = new StructureReferenceBeanImpl(null, null, null, SDMX_STRUCTURE_TYPE.REGISTRATION);
			return;
		}
		if(!supportedTypes.contains(queryString[1].toLowerCase())) {
			//Query for Registration by Id
			structureReferenceBean = new StructureReferenceBeanImpl(null, queryString[1], null, SDMX_STRUCTURE_TYPE.REGISTRATION);
			return;
		}
		
		SDMX_STRUCTURE_TYPE structureType = SDMX_STRUCTURE_TYPE.parseClass(queryString[1]);
		
		String agencyId = null;
		String id = null;
		String version = null;
		String identifiableId = null;
		
		if(queryString.length > 2) {
			agencyId = queryString[2];
		}
		if(queryString.length > 3) {
			if(structureType == SDMX_STRUCTURE_TYPE.DATA_PROVIDER) {
				identifiableId = queryString[3];
			} else {
				id = queryString[3];
			}
		}
		if(queryString.length > 4) {
			version = queryString[4];
		}
		if(queryString.length > 5) {
			throw new SdmxSemmanticException("Unexpected 5th argument '"+queryString[5]+"' ");
		}
		structureReferenceBean = new StructureReferenceBeanImpl(agencyId, id, version, structureType, identifiableId);
	}
	private void parserQueryParameters(Map<String, String> params) {
		if(params != null) {
			for(String key : params.keySet()) {
				if(key.equalsIgnoreCase("updatedBeforeDate")) {
					setUpdatedBeforeDate(params.get(key));
				} else if(key.equalsIgnoreCase("updatedAfterDate")) {
					setUpdatedAfterDate(params.get(key));
				}
			}
		}
	}
	private void setUpdatedBeforeDate(String updatedBeforeDate) {
		try {
			this.updatedBeforeDate = SdmxDateImpl.getSdmxDate(updatedBeforeDate);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Could not format 'updatedBeforeDate' value "+updatedBeforeDate+" as a date");
		}
	}

	private void setUpdatedAfterDate(String updatedAfterDate) {
		try {
			this.updatedAfterDate = SdmxDateImpl.getSdmxDate(updatedAfterDate);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Could not format 'updatedAfterDate' value "+updatedAfterDate+" as a date");
		}
	}
	@Override
	public StructureReferenceBean getReference() {
		return structureReferenceBean;
	}

	@Override
	public SdmxDate getUpdatedBefore() {
		return updatedBeforeDate;
	}

	@Override
	public SdmxDate getUpdatedAfter() {
		return updatedAfterDate;
	}
}
