package io.sdmx.im.beans.transformation;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.fusion.vtl.antlr.VtlParser;
import io.sdmx.fusion.vtl.util.VtlParserUtil;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;
import org.antlr.v4.runtime.CharStreams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static java.util.Objects.isNull;

public class RulesetBean extends ItemBeanImpl implements IRulesetBean {
	private static final long serialVersionUID = 1L;
	private String rulesetDefinition;
	private String rulesetType;
	private String rulesetScope;
	private List<IURN<?>> references = new ArrayList<>();
	
	public RulesetBean(IRulesetMutableBean bean, IRulesetSchemeBean parent, int position) {
		super(bean, parent, position);
		this.rulesetDefinition = bean.getRulesetDefinition();
		this.rulesetType = bean.getRulesetType();
		this.rulesetScope = bean.getRulesetScope();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(this.rulesetDefinition)) {
			throw new SdmxSemmanticException("Ruleset definition required for VTL Ruleset");
		}
		if(!ObjectUtil.validString(this.rulesetType)) {
			throw new SdmxSemmanticException("Ruleset Type required for VTL Ruleset");
		}
		if(!ObjectUtil.validString(this.rulesetScope)) {
			throw new SdmxSemmanticException("Ruleset Scope required for VTL Ruleset");
		}
		this.rulesetDefinition = rulesetDefinition.trim();
		this.rulesetType = rulesetType.trim();
		this.rulesetScope = rulesetScope.trim();
		this.references = Collections.unmodifiableList(extractReferencedArtifacts());
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IRulesetBean that = (IRulesetBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(rulesetDefinition, that.getRulesetDefinition(), "Ruleset Definition", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(rulesetType, that.getRulesetType(), "Ruleset Type", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(rulesetScope, that.getRulesetScope(), "Ruleset Scope", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IRulesetBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IRulesetBean> getURN() {
		return (IURNAbsolute<IRulesetBean>) super.getURN();
	}
	
	@Override
	public String getRulesetDefinition() {
		return rulesetDefinition;
	}

	@Override
	public String getRulesetType() {
		return rulesetType;
	}
	
	@Override
	public String getRulesetScope() {
		return rulesetScope;
	}

	@Override
	public List<IURN<?>> getReferencedArtifacts(){
		return references;
	}

	/**
	 * Extracts the (partial) URNs used in the VTL ruleset and creates a List of URNs
	 *
	 * @return List<IURN> of referenced artifacts
	 */
	private List<IURN<?>> extractReferencedArtifacts() {
		//TODO: Current implementation does not allow to map Codes in rules to codelists. Thus, codes are currently not extracted
		//TODO: Implement visitConstantExprComp in VTLVisitor
		IURN<?> urn = null;
		// Parse VTL ruleset and retrieve the VTL objects used in the ruleset definition
		VtlParser parser = VtlParserUtil.getVtlParser(CharStreams.fromString(rulesetDefinition));
		VtlParser.StartContext tree = parser.start();

		if (VtlParserUtil.getSyntaxErrors(parser).isEmpty()) {
			Map<String, String> vtlObjects = VtlParserUtil.parseVtlInput(parser);
			for (String object : vtlObjects.keySet()) {
				if (!isNull(object)) {
					if(Objects.equals(vtlObjects.get(object), "valuedomain")){
						urn = VtlParserUtil.extractSdmxElementFromVtlObject(object, SDMX_STRUCTURE_TYPE.CODE_LIST);
					}
					else {
						urn = VtlParserUtil.extractSdmxElementFromVtlObject(object, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
					}
					if (!isNull(urn)) {
						references.add(urn);
					}
				}
			}
		}
		return references;
	}
}
