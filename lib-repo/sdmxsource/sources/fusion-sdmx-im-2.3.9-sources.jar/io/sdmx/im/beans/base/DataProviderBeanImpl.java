package io.sdmx.im.beans.base;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MetricsBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;

public class DataProviderBeanImpl extends OrganisationBeanImpl implements DataProviderBean {
	private static final Logger LOG = LoggerFactory.getLogger(DataProviderBeanImpl.class);
	
	private static final long serialVersionUID = 52L;
	private transient boolean  metricsResolved = false;
	private transient boolean  hasMetrics = false;
	private transient Set<ICrossReferenceBean> linkedDataflowsWithData;
	private transient Integer seriesCount;
	private transient Date lastUpdated;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataProviderBeanImpl(DataProviderMutableBean bean, DataProviderSchemeBean parent) {
		super(bean, parent);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((DataProviderBean)bean, includeFinalProperties, diff);
		}
		return false;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DataProviderBean.class;
	}
	

	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		return Collections.emptyList();
	}

	@Override
	public DataProviderSchemeBean getMaintainableParent() {
		return (DataProviderSchemeBean)super.getMaintainableParent();
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////	

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        return new HashSet<>();
    }
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////METRICS				 				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////	
    
    /**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<DataProviderBean> getURN() {
		return (IURNAbsolute<DataProviderBean>) super.getURN();
	}
    
	@Override
	public boolean hasMetrics() {
		resolveMetrics();
		return hasMetrics;
	}


	@Override
	public Set<ICrossReferenceBean> getLinkedDataflowsWithData() {
		resolveMetrics();
		return linkedDataflowsWithData;
	}


	@Override
	public Integer getSeriesCount() {
		resolveMetrics();
		return seriesCount;
	}


	@Override
	public Date getLastUpdated() {
		resolveMetrics();
		return lastUpdated;
	}
	
	private void resolveMetrics() {
		if(metricsResolved) {
			return;
		}
		for(AnnotationBean annotation : getAnnotationsByType(MetricsBean.METRICS_ANNOTATION_TYPE)) {
			hasMetrics = true;
			if(!ObjectUtil.validCollection(annotation.getText())) {
				continue;
			}
			String annotationText = annotation.getText().get(0).getValue();
			linkedDataflowsWithData = new HashSet<>();
			try {
				if(annotation.getTitle() != null) {
					switch(annotation.getTitle()) {
					case MetricsBean.DATAFLOW_ANNOTATION_TITLE :
						String dataflowUrn = SDMX_STRUCTURE_TYPE.DATAFLOW.getUrnPrefix() + annotationText;
						linkedDataflowsWithData.add(CrossReferenceBean.build(this, dataflowUrn, DataflowBean.class));
						break;
					case MetricsBean.LAST_UPDATED_ANNOTATION_TITLE :
						this.lastUpdated = new Date(Long.parseLong(annotationText));
						break;
					case MetricsBean.SERIES_COUNT_ANNOTATION_TITLE :
						this.seriesCount = Integer.parseInt(annotationText);
						break;
					}
				}
			} catch(Throwable th) {
				LOG.error("Error processing metrics annotation:"+annotation.getTitle() + " with text:"+annotationText, th);
			}
		}
		metricsResolved = true;
	}
}
