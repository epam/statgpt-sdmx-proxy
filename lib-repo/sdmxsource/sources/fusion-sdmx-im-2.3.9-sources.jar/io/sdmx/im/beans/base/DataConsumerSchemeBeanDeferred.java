package io.sdmx.im.beans.base;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;

public class DataConsumerSchemeBeanDeferred extends OrganisationSchemeBeanDeferred<DataConsumerBean, DataConsumerSchemeBean> implements DataConsumerSchemeBean {
    private static final long serialVersionUID = 1L;

    public DataConsumerSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public DataConsumerSchemeBeanDeferred(DataConsumerSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public DataConsumerSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new DataConsumerSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected DataConsumerSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new DataConsumerSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<DataConsumerSchemeBean> getURN() {
        return (IURNMaintainable<DataConsumerSchemeBean>) super.getURN();
    }
    
    @Override
    public DataConsumerSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    protected Class<?> getConcreteInterface() {
        return DataConsumerSchemeBean.class;
    }
}
