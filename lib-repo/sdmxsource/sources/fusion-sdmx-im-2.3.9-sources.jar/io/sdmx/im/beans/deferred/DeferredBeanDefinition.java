package io.sdmx.im.beans.deferred;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.im.beans.base.AnnotationBeanImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class DeferredBeanDefinition implements IDeferredBeanDefinition {
    private final IURNMaintainable<?> urn;
    private final String checksum;
    private final List<AnnotationBean> annotations;
    private final List<ILinkBean> links;
    private final Map<String, String> names;
    private final Map<String, String> descriptions;
    private final Map<String, String> properties;
    private final SdmxPeriod validityPeriod;
    private final URL serviceURL;
    private final URL structureURL;

    private DeferredBeanDefinition(DefferedBeanBuilder builder) {
        this.urn = URN.builder(builder.urn).buildMaintainable();
        this.checksum = builder.checksum;
        this.names = Collections.unmodifiableMap(new TreeMap<>(builder.names));
        this.descriptions = Collections.unmodifiableMap(new TreeMap<>(builder.descriptions));
        if(!builder.annotations.isEmpty()) {
            List<AnnotationBean> annotations = new ArrayList<>(builder.annotations.size());
            builder.annotations.forEach(a-> {
                annotations.add(new AnnotationBeanImpl(a, null));
            });
            this.annotations = Collections.unmodifiableList(annotations);
        } else {
            this.annotations = Collections.emptyList();
        }
        this.links = builder.links;
        if(!builder.properties.isEmpty()) {
            this.properties = Collections.unmodifiableMap(new HashMap<>(builder.properties));
        } else {
            this.properties = Collections.emptyMap();
        }
        this.validityPeriod = builder.validityPeriod;
        try {
            this.structureURL = builder.structureURL == null ? null : URI.create(builder.structureURL).toURL();
        } catch(MalformedURLException e) {
            throw new SdmxSemmanticException("Invalid URL: " +builder.structureURL);
        }
        try {
            this.serviceURL = builder.serviceURL == null ? null : URI.create(builder.serviceURL).toURL();
        } catch(MalformedURLException e) {
            throw new SdmxSemmanticException("Invalid URL: " +builder.serviceURL);
        }
        validate();
    }

    private void validate() {
        if(this.urn == null) {
            throw new IllegalArgumentException("Unable to build Deffered Bean. URN missing");
        }
    }

    public static class DefferedBeanBuilder {
        private String urn;
        private String checksum;
        private Map<String, String> names = Collections.emptyMap();
        private Map<String, String> descriptions = Collections.emptyMap();
        private Map<String, String> properties = Collections.emptyMap();
        private List<AnnotationMutableBean> annotations = Collections.emptyList();
        private List<ILinkBean> links = Collections.emptyList();
        private SdmxPeriod validityPeriod;
        private String serviceURL;
        private String structureURL;

        public DefferedBeanBuilder(MaintainableBean maint) {
            if(maint == null) {
                return;
            }
            this.checksum = maint.getChecksum();
            urn(maint.getUrn());
            names(maint.getNames().stream().collect(Collectors.toMap(e->e.getLocale(), e->e.getValue())));
            descriptions(maint.getDescriptions().stream().collect(Collectors.toMap(e->e.getLocale(), e->e.getValue())));
            if(!maint.getAnnotations().isEmpty()) {
                //Dereference the original parent
                annotations = new ArrayList<>(maint.getAnnotations().size());
                for(AnnotationBean annotation : maint.getAnnotations()) {
                    //Create a copy as annotations have a reference to their parent
                    annotations.add(new AnnotationMutableBeanImpl(annotation, null));
                }
            }
            //Links do not have a reference to the parent SDMX Bean and are already in an immutable list
            links = maint.getLinks();
            validityPeriod = maint.getValidityPeriod();
            this.serviceURL = maint.getServiceURL() == null ? null : maint.getServiceURL().toString();
            this.structureURL = maint.getStructureURL() == null ? null :maint.getStructureURL().toString();
        }

        public DefferedBeanBuilder properties(Map<String, String> properties) {
            this.properties = properties;
            return this;
        }

        public DefferedBeanBuilder property(String key, String value) {
            if(properties.isEmpty()) {
                properties = new HashMap<>();
            }
            properties.put(key, value);
            return this;
        }

        public DefferedBeanBuilder property(String key, boolean value) {
            return property(key, value ? "true" : "false");
        }

        public DefferedBeanBuilder urn(String urn) {
            this.urn = urn;
            return this;
        }
        public DefferedBeanBuilder checksum(String checksum) {
            this.checksum = checksum;
            return this;
        }
        public DefferedBeanBuilder names(Map<String, String> names) {
            if(names == null) {
                names = Collections.emptyMap();
            }
            this.names = names;
            return this;
        }
        public DefferedBeanBuilder annotations(List<AnnotationMutableBean> beans) {
            this.annotations = beans;
            return this;
        }
        public DefferedBeanBuilder links(List<ILinkBean> beans) {
            this.links = beans;
            return this;
        }
        public DefferedBeanBuilder descriptions(Map<String, String> descriptions) {
            if(descriptions == null) {
                descriptions = Collections.emptyMap();
            }
            this.descriptions = descriptions;
            return this;
        }
        public DefferedBeanBuilder validityPeriod(SdmxPeriod period) {
            this.validityPeriod = period;
            return this;
        }
        public DefferedBeanBuilder structureURL(String structureUrl) {
            this.structureURL = structureUrl;
            return this;
        }
        public DefferedBeanBuilder serviceURL(String serviceUrl) {
            this.serviceURL = serviceUrl;
            return this;
        }
        public IDeferredBeanDefinition build() {
            return new DeferredBeanDefinition(this);
        }
    }

    public static DefferedBeanBuilder builder() {
        return builder(null);
    }
    public static DefferedBeanBuilder builder(MaintainableBean maint) {
        return new DefferedBeanBuilder(maint);
    }


    @Override
    public String getChecksum() {
        return checksum;
    }

    @Override
    public List<AnnotationBean> getAnnotations() {
        return annotations;
    }

    @Override
    public Map<String, String> getNames() {
        return names;
    }

    @Override
    public Map<String, String> getProperties() {
        return properties;
    }

    @Override
    public Map<String, String> getDescriptions() {
        return descriptions;
    }

    @Override
    public IURNMaintainable<?> getUrn() {
        return urn;
    }

    @Override
    public List<ILinkBean> getLinks() {
        return links;
    }

    @Override
    public URL getStructureURL() {
        return structureURL;
    }

    @Override
    public URL getServiceURL() {
        return serviceURL;
    }

    @Override
    public SdmxPeriod getValidityPeriod() {
        return validityPeriod;
    }
}
