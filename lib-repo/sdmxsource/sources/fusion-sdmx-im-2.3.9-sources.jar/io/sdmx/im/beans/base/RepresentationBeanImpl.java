package io.sdmx.im.beans.base;

import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public class RepresentationBeanImpl extends SdmxStructureBeanImpl implements RepresentationBean {
	private static final long serialVersionUID = -3;
	private IDirectCrossReferenceBean<EnumeratedListBean> representationRef;
	private TextFormatBean textFormat;
	private Integer minOccurs;
	private Integer maxOccurs;;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private RepresentationBeanImpl(RepresentationMutableBean bean, IdentifiableBean parent) {
		super(SDMX_STRUCTURE_TYPE.LOCAL_REPRESENTATION, parent);
		if(bean.getTextFormat() != null) {
			this.textFormat = TextFormatBeanImpl.getInstance(bean.getTextFormat(), this);
		}
		if(bean.getRepresentation() != null) {
			representationRef = DirectCrossReferenceBean.build(parent, "representation", URN.builder(bean.getRepresentation().getTargetUrn()).buildSingle(EnumeratedListBean.class));
		}

		if(bean.getMinOccurs() != null) {
			minOccurs = bean.getMinOccurs();
			if(minOccurs < 0) {
				minOccurs = null;
			}
		}
		if(bean.getMaxOccurs() != null) {
			maxOccurs = bean.getMaxOccurs();
			if(maxOccurs < 0) {
				maxOccurs = null;
			}
		}
		boolean ma = parent instanceof MetadataAttributeBean;
		
		if(ma == false && getTextFormat() == null && getRepresentation() == null && (minOccurs != null || maxOccurs != null)) {
			TextFormatMutableBean tf = new TextFormatMutableBeanImpl();
			tf.setTextType(TEXT_TYPE.STRING);
			this.textFormat = TextFormatBeanImpl.getInstance(tf, this);
		}
		validate();
	}

	public static RepresentationBean getInstance(RepresentationMutableBean bean, IdentifiableBean parent) {
		RepresentationBean repBean = new RepresentationBeanImpl(bean, parent);
		
		boolean ma = parent instanceof MetadataAttributeBean;
		if(repBean.getTextFormat() == null && repBean.getRepresentation() == null) {
			if(ma) {
				if((repBean.getMinOccurs() == null || repBean.getMinOccurs() == 0) && repBean.getMaxOccurs() == null) {
					return null;
				}
			} else {
				return null;
			}
		}
		return repBean;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			RepresentationBean that = (RepresentationBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(representationRef, that.getRepresentation(), "Representation", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(textFormat, that.getTextFormat(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(minOccurs, that.getMinOccurs(), "Min Occurs", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(maxOccurs, that.getMaxOccurs(), "Max Occurs", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION                           //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.minOccurs != null && this.minOccurs < 0) {
			throw new SdmxSemmanticException("Min occurs can not be less than 0");
		}
		if(this.maxOccurs != null && this.maxOccurs < 0) {
			throw new SdmxSemmanticException("Max occurs can not be less than 0");
		}
		if((this.maxOccurs != null &&  this.minOccurs != null) && (this.maxOccurs < this.minOccurs)) {
			throw new SdmxSemmanticException("Max occurs can not be less than min occurs");
		}
		if(this.representationRef != null && this.textFormat != null) {
			if(this.textFormat.getMultiLingual() == TERTIARY_BOOL.TRUE) {
				throw new SdmxSemmanticException("Representation can not refence both a "+this.representationRef.getTargetReference().getType()+" and have multilingual=true.  Multilingual is only valid for String or XHTML types");
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(textFormat, composites);
		return composites;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(representationRef != null) {
			references.add(representationRef);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public TextFormatBean getTextFormat() {
		return textFormat;
	}

	@Override
	public ICrossReferenceBean<? extends EnumeratedListBean> getRepresentation() {
		return representationRef;
	}

	@Override
	public Integer getMinOccurs() {
		return minOccurs;
	}

	@Override
	public Integer getMaxOccurs() {
		return maxOccurs;
	}

	@Override
	public String getKey() {
		return null;
	}
}
