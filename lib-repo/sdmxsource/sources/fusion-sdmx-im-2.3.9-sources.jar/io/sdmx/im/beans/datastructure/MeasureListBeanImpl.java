package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;

public class MeasureListBeanImpl extends IdentifiableBeanImpl implements MeasureListBean {
	private static final long serialVersionUID = 890296419939417244L;
	private PrimaryMeasureBean primaryMeasureBean;
	private List<MeasureDimensionBean> measures = new ArrayList<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MeasureListBeanImpl(MeasureListMutableBean measureList, MaintainableBean parent) {
		super(measureList, parent);
		if(measureList.getMeasures() != null) {
			for(MeasureMutableBean measure : measureList.getMeasures()) {
				MeasureDimensionBean measureDim;
				if(PrimaryMeasureBean.FIXED_ID.equals(measure.getId())) {
					primaryMeasureBean = new PrimaryMeasureBeanImpl(measure, this);
					measureDim = primaryMeasureBean;
				} else {
					measureDim = new MeasureDimensionBeanImpl(measure, this);
				}
				this.measures.add(measureDim);
			}
		}
		try {
			validateDimension();
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Error creating structure: " + this.toString());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			MeasureListBean that = (MeasureListBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(measures, that.getMeasures(), includeFinalProperties, "Measure", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validateDimension() {
		measures = Collections.unmodifiableList(measures);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return MeasureListBean.class;
	}
	
	@Override
	public String getId() {
		return FIXED_ID;
	}	

	@Override
	public PrimaryMeasureBean getPrimaryMeasure() {
		return primaryMeasureBean;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		for(MeasureDimensionBean measure : getMeasures()) {
			super.addToCompositeSet(measure, composites);
		}
		return composites;
	}

	@Override
	public List<MeasureDimensionBean> getMeasures() {
		if(measures == null) {
			return Collections.EMPTY_LIST;
		}
		return measures;
	}
}
