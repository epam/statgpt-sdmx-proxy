package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class RegistrationBeanDeferred extends MaintainableBeanDeferred<RegistrationBean> implements RegistrationBean {
    private static final long serialVersionUID = 1L;

    public RegistrationBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public RegistrationBeanDeferred(RegistrationBean maint) {
        super(maint);
    }
    
    @Override
    public RegistrationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new RegistrationBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected RegistrationBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new RegistrationBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<RegistrationBean> getURN() {
        return (IURNMaintainable<RegistrationBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return RegistrationBean.class;
    }

    @Override
    public RegistrationMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public boolean isIndexed() {
        return load().isIndexed();
    }

    @Override
    public TERTIARY_BOOL getIndexTimeSeries() {
        return load().getIndexTimeSeries();
    }

    @Override
    public TERTIARY_BOOL getIndexDataset() {
        return load().getIndexDataset();
    }

    @Override
    public TERTIARY_BOOL getIndexAttributes() {
        return load().getIndexAttributes();
    }

    @Override
    public TERTIARY_BOOL getIndexReportingPeriod() {
        return load().getIndexReportingPeriod();
    }

    @Override
    public SdmxDate getLastUpdated() {
        return load().getLastUpdated();
    }

    @Override
    public SdmxDate getValidFrom() {
        return load().getValidFrom();
    }

    @Override
    public SdmxDate getValidTo() {
        return load().getValidTo();
    }

    @Override
    public DataSourceBean getDataSource() {
        return load().getDataSource();
    }

    @Override
    public ICrossReferenceBean<ProvisionAgreementBean> getProvisionAgreementRef() {
        return load().getProvisionAgreementRef();
    }
}
