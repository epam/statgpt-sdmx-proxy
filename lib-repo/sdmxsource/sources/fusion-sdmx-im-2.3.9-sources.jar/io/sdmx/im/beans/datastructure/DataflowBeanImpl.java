package io.sdmx.im.beans.datastructure;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class DataflowBeanImpl extends MaintainableBeanImpl implements DataflowBean {
	private static final Logger LOG = LoggerFactory.getLogger(DataflowBeanImpl.class);
	private static final long serialVersionUID = 183L;
	private IDirectCrossReferenceBean<DataStructureBean> keyFamilyRef;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	DataflowBeanImpl(DataflowBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub DataflowBean Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataflowBeanImpl(DataflowMutableBean bean) {
		super(bean);
		LOG.debug("Building DataflowBean from Mutable Bean");
		if(bean.getDataStructureRef() != null) {
			this.keyFamilyRef = DirectCrossReferenceBean.build(this, "dsd", bean.getDataStructureRef(), DataStructureBean.class);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("DataflowBean Built " + this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			DataflowBean that = (DataflowBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(keyFamilyRef, that.getDataStructureRef(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!this.isExternalReference) {
			if(keyFamilyRef == null) {
				throw new SdmxSemmanticException("Dataflow must reference a Data Structure Definition");
			}
			if(keyFamilyRef.getTargetReference() != SDMX_STRUCTURE_TYPE.DSD) {
				throw new SdmxSemmanticException("Dataflow must reference a Data Structure Definition, provided reference was to a "+keyFamilyRef.getTargetReference().getType());
			}
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return DataflowBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<DataflowBean> getURN() {
		return (IURNMaintainable<DataflowBean>)super.getURN();
	}
	
	@Override
	public DataflowBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new DataflowBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public DataflowMutableBean getMutableInstance() {
		return new DataflowMutableBeanImpl(this);
	}
	
	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		List<ICrossReferenceBean<? extends ConstrainableBean>> returnList = new ArrayList<>(1);
		if(keyFamilyRef != null) {
			returnList.add(getDataStructureRef());
		}
		return returnList;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(keyFamilyRef != null) {
			references.add(keyFamilyRef);
		}
	}

	@Override
	public ICrossReferenceBean<DataStructureBean> getDataStructureRef() {
		return keyFamilyRef;
	}

    @Override
    public DataflowBeanDeferred toDeferred() {
        return new DataflowBeanDeferred(this);
    }
    
    @Override
    public DataflowBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new DataflowBeanDeferred(getDeferredDefinition(), loader);
    }
}
