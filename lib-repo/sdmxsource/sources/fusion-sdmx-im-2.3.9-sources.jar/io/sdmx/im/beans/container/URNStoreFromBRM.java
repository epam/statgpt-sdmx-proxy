package io.sdmx.im.beans.container;

import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;

/**
 * Gets the URNs from an underlying Bean Retreieval Manager
 */
public class URNStoreFromBRM implements IURNRetrievalManager   {
	private SdmxBeanRetrievalManager retrievalManager;

	public URNStoreFromBRM(SdmxBeanRetrievalManager retrievalManager) {
		this.retrievalManager = retrievalManager;
	}

	@Override
	public Set<IURNMaintainable<?>> find(IURN<?> urn) {
		return retrievalManager.getMaintainableBeans(urn.getMaintainableURN()).stream().map(e->e.getURN()).collect(Collectors.toSet());
	}
	
}
