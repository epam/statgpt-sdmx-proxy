package io.sdmx.im.beans.base;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;

public class DataProviderSchemeBeanDeferred extends OrganisationSchemeBeanDeferred<DataProviderBean, DataProviderSchemeBean> implements DataProviderSchemeBean {
    private static final long serialVersionUID = 1L;

    public DataProviderSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public DataProviderSchemeBeanDeferred(DataProviderSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public DataProviderSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new DataProviderSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected DataProviderSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new DataProviderSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<DataProviderSchemeBean> getURN() {
        return (IURNMaintainable<DataProviderSchemeBean>) super.getURN();
    }
    
    @Override
    public DataProviderSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    protected Class<?> getConcreteInterface() {
        return DataProviderSchemeBean.class;
    }
}
