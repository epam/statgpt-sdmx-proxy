package io.sdmx.im.beans.registry;

import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.DataSetReferenceMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class DataSetReferenceBeanImpl extends SdmxStructureBeanImpl implements DataSetReferenceBean {
	private static final long serialVersionUID = -209384883988082080L;
	private String datasetId;
	private IDirectCrossReferenceBean<DataProviderBean> dataProviderReference;


	public DataSetReferenceBeanImpl(DataSetReferenceMutableBean mutableBean, MetadataTargetKeyValuesBean parent) {
		super(mutableBean, parent);
		this.datasetId = mutableBean.getDatasetId();
		if(mutableBean.getDataProviderReference() != null) {
			this.dataProviderReference = DirectCrossReferenceBean.build(parent.getIdentifiableParent(), "dataprovider", mutableBean.getDataProviderReference(), DataProviderBean.class);
			try {
				validate();
			} catch(SdmxSemmanticException e) {
				throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(datasetId)) {
			throw new SdmxSemmanticException("Dataset Reference missing mandatory 'id' identifier");
		}
		if(dataProviderReference == null) {
			throw new SdmxSemmanticException("Dataset Reference missing mandatory 'data provider reference'");
		}
	}
	
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof DataSetReferenceBean) {
			DataSetReferenceBean that = (DataSetReferenceBean) bean;
			if(!ObjectUtil.equivalent(this.getDataProviderReference(), that.getDataProviderReference())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.getDatasetId(), that.getDatasetId())) {
				return false;
			}
		}
		return true;
	}
	
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(dataProviderReference != null) {
			references.add(dataProviderReference);
		}
	}
	@Override
	public String getDatasetId() {
		return datasetId;
	}

	@Override
	public ICrossReferenceBean<DataProviderBean> getDataProviderReference() {
		return dataProviderReference;
	}
	
	@Override
	public String getKey() {
		return datasetId;
	}
}
