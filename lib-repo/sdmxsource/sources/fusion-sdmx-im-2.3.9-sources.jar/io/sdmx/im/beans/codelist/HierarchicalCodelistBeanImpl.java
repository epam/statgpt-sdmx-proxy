package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistRefBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchicalCodelistMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

@Deprecated
public class HierarchicalCodelistBeanImpl extends MaintainableBeanImpl implements HierarchicalCodelistBean {
    private static final long serialVersionUID = 181L;
    private List<HierarchyBean> hierarchies = new ArrayList<>();
    private List<CodelistRefBean> codelistRef = new ArrayList<>();

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected HierarchicalCodelistBeanImpl(HierarchicalCodelistBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS             //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public HierarchicalCodelistBeanImpl(HierarchicalCodelistMutableBean bean) {
        super(bean);
        try {
            if(bean.getCodelistRef() != null) {
                for(CodelistRefMutableBean currentRef : bean.getCodelistRef()) {
                    codelistRef.add(new CodelistRefBeanImpl(currentRef, this));
                }
            }
            if(bean.getHierarchies() != null) {
                for(HierarchyMutableBean currentHierarchy : bean.getHierarchies()) {
                    hierarchies.add(new HierarchyBeanImpl(currentHierarchy));
                }
            }
        } catch(SdmxSemmanticException ex) {
            throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        } catch(Throwable th) {
            throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        }
        try {
            validate();
        } catch(SdmxSemmanticException ex) {
            throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        } catch(Throwable th) {
            throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS                          //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            HierarchicalCodelistBean that = (HierarchicalCodelistBean) bean;
            boolean returnVal = true;
            if(!super.equivalent(hierarchies, that.getHierarchies(), includeFinalProperties, "Hierarchy", diff)) {
                returnVal = false;
            }
            return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
        }
        return false;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        // Ensure codelist refs have unique aliases
        if(this.codelistRef != null) {
            Set<String> codelisAlias = new HashSet<>();
            for(CodelistRefBean currentRef : this.codelistRef) {
                if(ObjectUtil.validString(currentRef.getAlias())) {
                    if(codelisAlias.contains(currentRef.getAlias())) {
                        throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_ALIAS, currentRef.getAlias());
                    }
                    codelisAlias.add(currentRef.getAlias());
                }
            }
        }
        // Ensure hierarchies and their levels have unique URNs
        if(this.hierarchies != null) {
            Set<String> hierarchyUrns = new HashSet<>();
            for(HierarchyBean currentHierarhy : this.hierarchies) {
                try {
                    if(hierarchyUrns.contains(currentHierarhy.getUrn())) {
                        throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_URN, currentHierarhy);
                    }
                    hierarchyUrns.add(currentHierarhy.getUrn());
                } catch(SdmxSemmanticException ex) {
                    throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
                } catch(Throwable th) {
                    throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
                }
            }
        }
        this.hierarchies = Collections.unmodifiableList(hierarchies);
        this.codelistRef = Collections.unmodifiableList(codelistRef);
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS                              //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public HierarchicalCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new HierarchicalCodelistBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public HierarchicalCodelistMutableBean getMutableInstance() {
        return new HierarchicalCodelistMutableBeanImpl(this);
    }

    @Override
    public List<HierarchyBean> getHierarchies() {
        return hierarchies;
    }

    @Override
    public List<CodelistRefBean> getCodelistRef() {
        return codelistRef;
    }

    @Override
    public String getCodelistAlias(String codelistURN) {
        for(CodelistRefBean ref : codelistRef) {
            if(ref.getCodelistReference().getTargetUrn().equals(codelistURN)) {
                return ref.getAlias();
            }
        }
        return null;
    }

    @Override
    public HierarchicalCodelistBean cloneForDate(Date aDate) {
        HierarchicalCodelistMutableBean clone = this.getMutableInstance().stripItems(aDate);
        return clone.getImmutableInstance();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES               //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(hierarchies, composites);
        return composites;
    }

    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {}

    @Override
    protected Class<?> getConcreteInterface() {
        return HierarchicalCodelistBean.class;
    }
    
    @Override
    public HierarchicalCodelistBeanDeferred toDeferred() {
        return new HierarchicalCodelistBeanDeferred(this);
    }
    
    @Override
    public HierarchicalCodelistBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchicalCodelistBeanDeferred(getDeferredDefinition(), loader);
    }

}
