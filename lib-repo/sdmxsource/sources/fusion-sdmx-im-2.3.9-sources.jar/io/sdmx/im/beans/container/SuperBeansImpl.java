package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;

public class SuperBeansImpl implements SuperBeans{
	private Set<ConceptSchemeSuperBean> conceptSchemes = new HashSet<>();
	private Set<DataflowSuperBean> dataflows = new HashSet<>();
	private Set<HierarchySuperBean> hcls = new HashSet<>();
	private Set<DataStructureSuperBean> dataStructures = new HashSet<>();
	private Set<MetadataStructureSuperBean> msdSuperBean = new HashSet<>();
	private Set<ProvisionAgreementSuperBean> provisionAgreement = new HashSet<>();
	private Set<RegistrationSuperBean> registrations = new HashSet<>();

	public SuperBeansImpl() {
		syncSets();
	}
	
	public SuperBeansImpl(Collection<MaintainableSuperBean> allBeans) {
		if(allBeans != null) {
			for(MaintainableSuperBean currentBean : allBeans) {
				addMaintainable(currentBean);
 			}
		}
		syncSets();
	}
	
	public SuperBeansImpl(SuperBeans...beans) {
		for(SuperBeans currentBean : beans) {
			this.conceptSchemes.addAll(currentBean.getConceptSchemes());
			this.dataflows.addAll(currentBean.getDataflows());
			this.hcls.addAll(currentBean.getHierarchies());
			this.dataStructures.addAll(currentBean.getDataStructures());
			this.msdSuperBean.addAll(currentBean.getMetadataStructures());
			this.provisionAgreement.addAll(currentBean.getProvisions());
			this.registrations.addAll(currentBean.getRegistrations());
		}		
		syncSets();
	}
	
	private void syncSets() {
		conceptSchemes = Collections.synchronizedSet(conceptSchemes);
		dataflows = Collections.synchronizedSet(dataflows);
		hcls = Collections.synchronizedSet(hcls);
		dataStructures = Collections.synchronizedSet(dataStructures);
		msdSuperBean = Collections.synchronizedSet(msdSuperBean);
		provisionAgreement = Collections.synchronizedSet(provisionAgreement);
		registrations = Collections.synchronizedSet(registrations);
	}
	
	
	@Override
	public void merge(SuperBeans superBeans) {
		for(MaintainableSuperBean currentSb : superBeans.getAllMaintainables()) {
			addMaintainable(currentSb);
		}
	}

	@Override
	public void addMaintainable(MaintainableSuperBean bean) {
		switch(bean.getBuiltFrom().getStructureType()) {
		case CONCEPT_SCHEME : addConceptScheme((ConceptSchemeSuperBean)bean);
		break;
		case DATAFLOW : addDataflow((DataflowSuperBean)bean);
		break;
		case HIERARCHY : addHierarchy((HierarchySuperBean)bean);
		break;
		case DSD : addDataStructure((DataStructureSuperBean)bean);
		break;
		case MSD : addMetadataStructure((MetadataStructureSuperBean)bean);
		break;
		case PROVISION_AGREEMENT : addProvision((ProvisionAgreementSuperBean)bean);
		break;
		case REGISTRATION : addRegistration((RegistrationSuperBean)bean);
		break;
		default: throw new SdmxNotImplementedException("SuperBeansImpl.addMaintainable of type : " + bean.getBuiltFrom().getStructureType().getType());
		}
	}
	

	@Override
	public void removeMaintainable(MaintainableSuperBean bean) {
		switch(bean.getBuiltFrom().getStructureType()) {
		case CONCEPT_SCHEME : removeConceptScheme((ConceptSchemeSuperBean)bean);
		break;
		case DATAFLOW : removeDataflow((DataflowSuperBean)bean);
		break;
		case HIERARCHY : removeHierarchy((HierarchySuperBean)bean);
		break;
		case DSD : removeDataStructure((DataStructureSuperBean)bean);
		break;
		case MSD : removeMetadataStructure((MetadataStructureSuperBean)bean);
		break;
		case PROVISION_AGREEMENT : removeProvision((ProvisionAgreementSuperBean)bean);
		break;
		case REGISTRATION : removeRegistration((RegistrationSuperBean)bean);
		break;
		default: throw new SdmxNotImplementedException("SuperBeansImpl.removeMaintainable of type : " + bean.getBuiltFrom().getStructureType().getType());
		}
	}

	@Override
	public void addConceptScheme(ConceptSchemeSuperBean bean) {
		if(bean != null) {
			conceptSchemes.remove(bean);
			conceptSchemes.add(bean);
		}
	}

	@Override
	public void addDataflow(DataflowSuperBean bean) {
		if(bean != null) {
			dataflows.remove(bean);
			dataflows.add(bean);
		}
	}

	@Override
	public void addHierarchy(HierarchySuperBean bean) {
		if(bean != null) {
			hcls.remove(bean);
			hcls.add(bean);
		}
	}

	@Override
	public void addDataStructure(DataStructureSuperBean bean) {
		if(bean != null) {
			dataStructures.remove(bean);
			dataStructures.add(bean);
		}
	}
	
	@Override
	public void addMetadataStructure(MetadataStructureSuperBean bean) {
		if(bean != null) {
			msdSuperBean.remove(bean);
			msdSuperBean.add(bean);
		}
	}

	@Override
	public void addProvision(ProvisionAgreementSuperBean bean) {
		if(bean != null) {
			provisionAgreement.remove(bean);	
			provisionAgreement.add(bean);	
		}
	}
	
	@Override
	public void addRegistration(RegistrationSuperBean bean) {
		if(bean != null) {
			registrations.remove(bean);
			registrations.add(bean);	
		}
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemes() {
		return Collections.unmodifiableSet(conceptSchemes);
	}

	@Override
	public Set<DataflowSuperBean> getDataflows() {
		return Collections.unmodifiableSet(dataflows);
	}

	@Override
	public Set<HierarchySuperBean> getHierarchies() {
		return Collections.unmodifiableSet(hcls);
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructures() {
		return Collections.unmodifiableSet(dataStructures);
	}
	
	@Override
	public Set<MetadataStructureSuperBean> getMetadataStructures() {
		return Collections.unmodifiableSet(msdSuperBean);
	}

	@Override
	public Set<ProvisionAgreementSuperBean> getProvisions() {
		return Collections.unmodifiableSet(provisionAgreement);
	}

	@Override
	public Set<RegistrationSuperBean> getRegistrations() {
		return Collections.unmodifiableSet(registrations);
	}

	@Override
	public void removeConceptScheme(ConceptSchemeSuperBean bean) {
		conceptSchemes.remove(bean);
	}

	@Override
	public void removeDataflow(DataflowSuperBean bean) {
		dataflows.remove(bean);
	}

	@Override
	public void removeHierarchy(HierarchySuperBean bean) {
		hcls.remove(bean);
	}

	@Override
	public void removeDataStructure(DataStructureSuperBean bean) {
		dataStructures.remove(bean);
	}
	
	@Override
	public void removeMetadataStructure(MetadataStructureSuperBean bean) {
		msdSuperBean.remove(bean);
	}

	@Override
	public void removeProvision(ProvisionAgreementSuperBean bean) {
		provisionAgreement.remove(bean);
	}

	@Override
	public void removeRegistration(RegistrationSuperBean bean) {
		registrations.remove(bean);
	}

	@Override
	public Set<MaintainableSuperBean> getAllMaintainables() {
		Set<MaintainableSuperBean> returnSet = new HashSet<>();
		returnSet.addAll(this.conceptSchemes);
		returnSet.addAll(this.dataflows);
		returnSet.addAll(this.hcls);
		returnSet.addAll(this.msdSuperBean);
		returnSet.addAll(this.dataStructures);
		returnSet.addAll(this.provisionAgreement);
		returnSet.addAll(this.registrations);
		return returnSet;
	}
}
