package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class ContentConstraintBeanDeferred extends MaintainableBeanDeferred<ContentConstraintBean> implements ContentConstraintBean {
    private static final long serialVersionUID = 1L;
    private Boolean isDefiningActualDataPresent;
    private Boolean isCubeRegion;

    public ContentConstraintBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
        this.isDefiningActualDataPresent = bean.getBooleanProperty(ContentConstraintBeanImpl.PROP_IS_DEFINING_DATA);
        this.isCubeRegion = bean.getBooleanProperty(ContentConstraintBeanImpl.PROP_IS_CUBE_REGION);
    }
    
    public ContentConstraintBeanDeferred(ContentConstraintBean maint) {
        super(maint);
        this.isDefiningActualDataPresent = maint.isDefiningActualDataPresent();
        this.isCubeRegion = maint.isCubeRegion();
    }
    
    @Override
    public ContentConstraintBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ContentConstraintBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ContentConstraintBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ContentConstraintBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ContentConstraintBean> getURN() {
        return (IURNMaintainable<ContentConstraintBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ContentConstraintBean.class;
    }

    @Override
    public boolean isBusinessValidity() {
        return load().isBusinessValidity();
    }

    @Override
    public boolean isDefiningActualDataPresent() {
        return isDefiningActualDataPresent != null ? isDefiningActualDataPresent : load().isDefiningActualDataPresent();
    }

    @Override
    public boolean isCubeRegion() {
        return isCubeRegion != null ? isCubeRegion : load().isCubeRegion();
    }

    @Override
    public boolean isConstrainingComponent(String componentId) {
        return load().isConstrainingComponent(componentId);
    }

    @Override
    public MetadataTargetRegionBean getMetadataTargetRegion() {
        return load().getMetadataTargetRegion();
    }

    @Override
    public ConstraintAttachmentBean getConstraintAttachment() {
        return load().getConstraintAttachment();
    }

    @Override
    public ConstraintDataKeySetBean getIncludedSeriesKeys() {
        return load().getIncludedSeriesKeys();
    }

    @Override
    public ConstraintDataKeySetBean getExcludedSeriesKeys() {
        return load().getExcludedSeriesKeys();
    }

    @Override
    public CubeRegionBean getIncludedCubeRegion() {
        return load().getIncludedCubeRegion();
    }

    @Override
    public CubeRegionBean getExcludedCubeRegion() {
        return load().getExcludedCubeRegion();
    }

    @Override
    public boolean hasIncludedSeries() {
        return load().hasIncludedSeries();
    }

    @Override
    public boolean hasExcludedSeries() {
        return load().hasExcludedSeries();
    }

    @Override
    public boolean hasExcludedCubeRegion() {
        return load().hasExcludedCubeRegion();
    }

    @Override
    public boolean hasIncludedCubeRegion() {
        return load().hasIncludedCubeRegion();
    }

    @Override
    public Set<KeyValues> getRestrictedComponents() {
        return load().getRestrictedComponents();
    }

    @Override
    public ReferencePeriodBean getReferencePeriod() {
        return load().getReferencePeriod();
    }

    @Override
    public ReleaseCalendarBean getReleaseCalendar() {
        return load().getReleaseCalendar();
    }

    @Override
    public ContentConstraintMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
