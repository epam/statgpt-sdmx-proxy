package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TEXT_SEARCH;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexTextReference;

public class ComplexTextReferenceImpl implements ComplexTextReference {

	private String lang;
	private TEXT_SEARCH operator;
	private String searchParam;

	public ComplexTextReferenceImpl(String lang, TEXT_SEARCH operator, String searchParam) {
		this.lang = lang;
		
		if (operator == null) {
			this.operator = TEXT_SEARCH.EQUAL;
		} else {
			this.operator = operator;	
		}
		
		if (searchParam == null || searchParam.isEmpty() ) {
			throw new SdmxSemmanticException("Not provided text to search for. It should not be null or empty.");
		}
		
		this.searchParam = searchParam;
	}
	
	@Override
	public String getLanguage() {
		return lang;
	}

	@Override
	public TEXT_SEARCH getOperator() {
		return operator;
	}

	@Override
	public String getSearchParameter() {
		return searchParam;
	}

}
