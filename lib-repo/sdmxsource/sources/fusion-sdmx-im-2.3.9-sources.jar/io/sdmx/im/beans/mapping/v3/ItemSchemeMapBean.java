package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemSchemeMapMutableBean;

public abstract class ItemSchemeMapBean<T extends IItemMapBean> extends SchemeMapBean implements IItemSchemeMapBean<T> {
	private static final long serialVersionUID = 12L;

	/**
	 * Stub constructor
	 */
	protected ItemSchemeMapBean(IItemSchemeMapBean<T> bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ItemSchemeMapBean(IItemSchemeMapMutableBean bean) {
		super(bean);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if (bean == null) {
			return false;
		}
		if (bean.getStructureType() == this.getStructureType()) {
			ItemSchemeMapBean that = (ItemSchemeMapBean) bean;
			boolean returnVal = true;
			if (!super.equivalent(getItems(), that.getItems(), includeFinalProperties, getItemType().getType(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(getItems(), composites);
		return composites;
	}
	
	protected abstract SDMX_STRUCTURE_TYPE getItemType();
}
