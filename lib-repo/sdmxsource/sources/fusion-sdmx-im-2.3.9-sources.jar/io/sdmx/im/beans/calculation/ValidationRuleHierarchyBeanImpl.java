package io.sdmx.im.beans.calculation;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleHierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationRuleHierarchyMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ValidationRuleHierarchyBeanImpl extends SDMXBeanImpl implements ValidationRuleHierarchyBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<HierarchyBean> hierarchyReference;
	private IDirectCrossReferenceBean<DimensionBean> dimensionReference;
	
	public ValidationRuleHierarchyBeanImpl(ValidationRuleHierarchyMutableBean mutableBean, ValidationRuleBean parent) {
		super(mutableBean, parent);
		if(mutableBean.getDimensionReference() != null) {
			dimensionReference = DirectCrossReferenceBean.build(parent, "dimension", mutableBean.getDimensionReference(), DimensionBean.class);
		}
		if(mutableBean.getHierarchyReference() != null) {
			hierarchyReference = DirectCrossReferenceBean.build(parent, "hierarchy", mutableBean.getHierarchyReference(), HierarchyBean.class);
		}
		validate();
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(hierarchyReference == null) {
			throw new SdmxSemmanticException("Validation Rule Hierarchy missing hierarchyReference");
		}
		if(dimensionReference == null) {
			throw new SdmxSemmanticException("Validation Rule Hierarchy missing dimensionReference");
		}
		if(hierarchyReference.getTargetReference() != SDMX_STRUCTURE_TYPE.HIERARCHY) {
			throw new SdmxSemmanticException("Validation Rule reference must be to a Hierarchy, it is currently set to a "+hierarchyReference.getTargetReference() );
		}
		if(dimensionReference.getTargetReference() != SDMX_STRUCTURE_TYPE.DIMENSION) {
			throw new SdmxSemmanticException("Validation Rule reference must be to a Hierarchy, it is currently set to a "+dimensionReference.getTargetReference() );
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ValidationRuleHierarchyBean that = (ValidationRuleHierarchyBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(hierarchyReference, that.getHierarchyReference(), "Hierarchy Reference", diffReport)) {
				returnVal = false;
			}
			if(!super.equivalent(this.dimensionReference, that.getDimensionReference(), "Dimension Reference", diffReport)) {
				returnVal = false;
			}
			if(!super.deepEqualsInternal(that, includeFinalProperties, diffReport)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	

	@Override
	public ICrossReferenceBean<HierarchyBean> getHierarchyReference() {
		return hierarchyReference;
	}

	@Override
	public ICrossReferenceBean<DimensionBean> getDimensionReference() {
		return dimensionReference;
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}
	
	@Override
	public String getKey() {
		return null;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		 if(hierarchyReference != null) {
			 references.add(hierarchyReference);
		 }
		 if(dimensionReference != null) {
			 references.add(dimensionReference);
		 }
	}
}
