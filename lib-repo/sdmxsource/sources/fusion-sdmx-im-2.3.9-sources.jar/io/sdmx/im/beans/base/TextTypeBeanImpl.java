package io.sdmx.im.beans.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public class TextTypeBeanImpl extends SDMXBeanImpl implements TextTypeBean {
	private static final long serialVersionUID = 1L;
	private List<TextTypeWrapper> textTypes = new ArrayList<>();
	private String property;

	/**
	 * @param property - the property on the owning Bean, for example Name, Description
	 * @param mutableBean 
	 * @param parent
	 */
	public TextTypeBeanImpl(String property, TextTypeMutableBean mutableBean, SDMXBean parent) {
		super(mutableBean, parent);
		this.property = property;
		if(mutableBean.getText() != null) {
			for(TextTypeWrapperMutableBean mutable : mutableBean.getText()) {
				if(ObjectUtil.validString(mutable.getValue())) {
					textTypes.add(new TextTypeWrapperImpl(mutable, "Name", this));
				}
			}	
		}
		this.textTypes = Collections.unmodifiableList(textTypes);
		validate();
	}

	@Override
	public String getKey() {
		return null;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			TextTypeBean that = (TextTypeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.textTypes, that.getText(), includeFinalProperties, property, diffReport)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validCollection(textTypes)) {
			throw new SdmxSemmanticException("Missing text values for "+property);
		}
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}


	@Override
	public List<TextTypeWrapper> getText() {
		return textTypes;
	}

	@Override
	public String getTextForCurrentLanguage() {
		TextTypeWrapper wrapper = TextTypeUtil.getDefaultLocale(textTypes);
		if(wrapper != null) {
			return wrapper.getValue();
		}
		return null;
	}
}
