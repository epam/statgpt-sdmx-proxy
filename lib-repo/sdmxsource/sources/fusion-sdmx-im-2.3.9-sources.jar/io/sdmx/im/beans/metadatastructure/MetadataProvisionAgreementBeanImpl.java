package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataProvisionAgreementMutableBean;
import io.sdmx.utils.sdmx.xs.CrossRefrenceBeanBase;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class MetadataProvisionAgreementBeanImpl extends MaintainableBeanImpl implements MetadataProvisionAgreementBean {
    private static final Logger LOG = LoggerFactory.getLogger(MetadataProvisionAgreementBeanImpl.class);
    private static final long serialVersionUID = 184L;
    private IDirectCrossReferenceBean<MetadataFlowBean> metadataflowRef;
    private IDirectCrossReferenceBean<IMetadataProviderBean> metaDataProviderRef;
    private List<ICrossReferenceBeanBase> targets = Collections.emptyList();


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    MetadataProvisionAgreementBeanImpl(MetadataProvisionAgreementBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
        LOG.debug("Stub MetadataProvisionAgreementBean Built");
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public MetadataProvisionAgreementBeanImpl(IMetadataProvisionAgreementMutableBean bean) {
        super(bean);
        LOG.debug("Building MetadataProvisionAgreementBean from Mutable Bean");
        try {
            if(bean.getMetadataflowRef() != null) {
                this.metadataflowRef = DirectCrossReferenceBean.build(this, "metadataflow", bean.getMetadataflowRef(), MetadataFlowBean.class);
            }
            if(bean.getMetadataProviderRef() != null) {
                this.metaDataProviderRef = DirectCrossReferenceBean.build(this, "metadataprovider", bean.getMetadataProviderRef(), IMetadataProviderBean.class);
            }
            this.targets = new ArrayList<>();
            if(bean.getTargets() != null) {
                for(StructureReferenceBean currentTaget : bean.getTargets()) {
                    this.targets.add(CrossRefrenceBeanBase.build(this, "target", currentTaget));
                }
            }
        } catch(Throwable th) {
            throw new SdmxSemmanticException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
        }
        try {
            validate();
        } catch(SdmxSemmanticException e) {
            throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
        }
        if(LOG.isDebugEnabled()) {
            LOG.debug("ProvisionAgreementBean Built " + this.getUrn());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            MetadataProvisionAgreementBean that = (MetadataProvisionAgreementBean) bean;
            boolean returnVal = true;
            if(!super.equivalent(metadataflowRef, that.getMetadataflowRef(), diff)) {
                returnVal = false;
            }
            if(!super.equivalent(metaDataProviderRef, that.getMetadataProviderRef(), diff)) {
                returnVal = false;
            }
            if(!super.equivalentCollection(this, this.targets, that.getTargets(), "Target", diff)) {
                returnVal = false;
            }
            return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
        }
        return false;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        if(metaDataProviderRef == null) {
            throw new SdmxSemmanticException("The Metadata Provision Agreement is missing a reference to a metadata provider.");
        }
        if(!metaDataProviderRef.getReference().getVersion().toString().equals(DataProviderSchemeBean.FIXED_VERSION)) {
            throw new SdmxSemmanticException("Version 2.0 Data Provider Scheme is no longer supported.  Data Provider Scheme has a fixed version of 1.0 in SDMX 2.1");
        }
        if(metadataflowRef == null) {
            throw new SdmxSemmanticException("The Metadata Provision Agreement is missing a reference to a Metadataflow");
        }
        if(metaDataProviderRef.getTargetReference() != SDMX_STRUCTURE_TYPE.METADATA_PROVIDER) {
            throw new SdmxSemmanticException("Illegal reference to '"+metaDataProviderRef.getTargetReference()+"'. The Metadata Provision Agreement must reference a metadata provider.");
        }
        if(metadataflowRef.getTargetReference() != SDMX_STRUCTURE_TYPE.METADATA_FLOW) {
            throw new SdmxSemmanticException("Illegal reference to '"+metadataflowRef.getTargetReference()+"'. The Metadata Provision Agreement must reference a Metadataflow.");
        }
        this.targets = Collections.unmodifiableList(this.targets);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Class<?> getConcreteInterface() {
        return MetadataProvisionAgreementBean.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<MetadataProvisionAgreementBean> getURN() {
        return (IURNMaintainable<MetadataProvisionAgreementBean>)super.getURN();
    }

    @Override
    public ICrossReferenceBean<MetadataFlowBean> getMetadataflowRef() {
        return metadataflowRef;
    }

    @Override
    public ICrossReferenceBean<IMetadataProviderBean> getMetadataProviderRef() {
        return metaDataProviderRef;
    }

    @Override
    public List<ICrossReferenceBeanBase> getTargets() {
        return targets;
    }

    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
        if(metaDataProviderRef != null) {
            references.add(metaDataProviderRef);
        }
        if(metadataflowRef != null) {
            references.add(metadataflowRef);
        }
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        List<ICrossReferenceBean<? extends ConstrainableBean>> returnList = new ArrayList<>();
        returnList.add(getMetadataflowRef());
        returnList.add(getMetadataProviderRef());
        return returnList;
    }


    @Override
    public IMetadataProvisionAgreementMutableBean getMutableInstance() {
        return new MetadataProvisionAgreementMutableBean(this);
    }

    @Override
    public MetadataProvisionAgreementBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataProvisionAgreementBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public MetadataProvisionBeanDeferred toDeferred() {
        return new MetadataProvisionBeanDeferred(this);
    }
    
    @Override
    public MetadataProvisionBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProvisionBeanDeferred(getDeferredDefinition(), loader);
    }
}
