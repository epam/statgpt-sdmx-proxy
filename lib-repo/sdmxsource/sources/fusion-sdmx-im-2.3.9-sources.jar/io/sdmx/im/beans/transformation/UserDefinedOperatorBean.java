package io.sdmx.im.beans.transformation;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class UserDefinedOperatorBean extends ItemBeanImpl implements IUserDefinedOperatorBean {
	private static final long serialVersionUID = 1L;
	private String operatorDefinition;

	public UserDefinedOperatorBean(IUserDefinedOperatorMutableBean bean, IUserDefinedOperatorSchemeBean parent, int position) {
		super(bean, parent, position);
		this.operatorDefinition = bean.getOperatorDefinition();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(this.operatorDefinition)) {
			throw new SdmxSemmanticException("Operator Definition required for User Defined Operator");
		}
		this.operatorDefinition = this.operatorDefinition.trim();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IUserDefinedOperatorBean that = (IUserDefinedOperatorBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(operatorDefinition, that.getOperatorDefinition(), "Operator Definition", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IUserDefinedOperatorBean.class;
	}
	
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IUserDefinedOperatorBean> getURN() {
		return (IURNAbsolute<IUserDefinedOperatorBean>) super.getURN();
	}
	
	@Override
	public String getOperatorDefinition() {
		return operatorDefinition;
	}
}
