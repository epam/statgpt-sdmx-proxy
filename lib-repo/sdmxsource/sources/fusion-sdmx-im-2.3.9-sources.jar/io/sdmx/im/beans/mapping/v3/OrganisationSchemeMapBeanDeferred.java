package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;

public class OrganisationSchemeMapBeanDeferred extends GenericItemSchemeMapBeanDeferred<IOrganisationMapBean, IOrganisationSchemeMapBean> implements IOrganisationSchemeMapBean {
    private static final long serialVersionUID = 1L;

    public OrganisationSchemeMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public OrganisationSchemeMapBeanDeferred(IOrganisationSchemeMapBean maint) {
        super(maint);
    }
    
    @Override
    public IOrganisationSchemeMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new OrganisationSchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected OrganisationSchemeMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationSchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IOrganisationSchemeMapBean> getURN() {
        return (IURNMaintainable<IOrganisationSchemeMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IOrganisationSchemeMapBean.class;
    }

    @Override
    public IOrganisationSchemeMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
