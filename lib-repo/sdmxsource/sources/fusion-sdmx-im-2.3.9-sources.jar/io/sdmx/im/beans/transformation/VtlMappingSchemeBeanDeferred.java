package io.sdmx.im.beans.transformation;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class VtlMappingSchemeBeanDeferred extends ItemSchemeBeanDeffered<IVtlMappingBean, IVtlMappingSchemeBean> implements IVtlMappingSchemeBean {
    private static final long serialVersionUID = 1L;

    public VtlMappingSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public VtlMappingSchemeBeanDeferred(IVtlMappingSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public IVtlMappingSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new VtlMappingSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected VtlMappingSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new VtlMappingSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IVtlMappingSchemeBean> getURN() {
        return (IURNMaintainable<IVtlMappingSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IVtlMappingSchemeBean.class;
    }
    
    @Override
    public IVtlMappingSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

}
