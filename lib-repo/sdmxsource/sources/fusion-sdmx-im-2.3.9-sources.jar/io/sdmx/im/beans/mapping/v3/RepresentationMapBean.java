package io.sdmx.im.beans.mapping.v3;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapRefMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.utils.core.regex.RegexUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Represents a SDMX v3.0 representation map, where source and target can be one of the following:
 * <ul>
 *  <li>Codelist</li>
 *  <li>Valuelist</li>
 *  <li>Free Text</li>
 * </ul>
 * <p/>
 * The source and target can be mixed types allowing for Codelists to map to free text for example.
 * <p/>
 * <p>
 * There can be multiple source and targets
 * </p>
 * SDMX v2.1 and lower only supports Codelist to Codelist mapping (via a structure called the CodelistMap)
 */
public class RepresentationMapBean extends MaintainableBeanImpl implements IRepresentationMapBean {
	private static final long serialVersionUID = 2L;
	private List<IRepresentationMapRefBean> sourceRef = new ArrayList<>();
	private List<IRepresentationMapRefBean> targetRef = new ArrayList<>();
	private List<IMappedRelationshipBean> mappedValues = new ArrayList<>();

	/**
	 * Stub constructor
	 */
	RepresentationMapBean(IRepresentationMapBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public RepresentationMapBean(IRepresentationMapMutableBean bean) {
		super(bean);
		addRefs(bean.getSourceRef(), sourceRef);
		addRefs(bean.getTargetRef(), targetRef);

		if(bean.getMappedValues() != null) {
			int poisition = 0;
			for(IMappedRelationshipMutableBean mappeedRelationship : bean.getMappedValues()) {
				poisition++;
				this.mappedValues.add(new MappedRelationshipBean(mappeedRelationship, poisition, this));
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	private void addRefs(List<IRepresentationMapRefMutableBean> refList, List<IRepresentationMapRefBean> fromSource) {
		if(refList != null) {
			for(IRepresentationMapRefMutableBean xsRef : refList) {
				fromSource.add(new RepresentationMapRef(xsRef, this));
			}
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		//TODO Validate Mapped values with respect to selected text type

		//Validate mapped size
		int sourceSize = sourceRef.size();
		for(IMappedRelationshipBean mappedRelationship : mappedValues) {
			if(mappedRelationship.getSourceValue().size() != sourceSize) {
				throw new SdmxSemmanticException("Source Mapping expected "+sourceSize+" source item(s), "+mappedRelationship.getSourceValue().size()+" defined");
			}
		}
		this.sourceRef = Collections.unmodifiableList(sourceRef);
		this.targetRef = Collections.unmodifiableList(targetRef);
		this.mappedValues = Collections.unmodifiableList(mappedValues);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IRepresentationMapBean that = (IRepresentationMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(sourceRef, that.getSourceRef(), includeFinalProperties, Properties.SOURCE_REFERENCES.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetRef, that.getTargetRef(), includeFinalProperties, Properties.TARGET_REFERENCES.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.mappedValues, that.getMappedValues(),includeFinalProperties, Properties.MAPPED_VALUES.getProperty(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////REFERENCES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		for(IMappedRelationshipBean mappedRelationship : this.mappedValues) {
			int sourceIdx = 0;
			for(IMappedValueBean mappedValue : mappedRelationship.getSourceValue()) {
				IRepresentationMapRefBean mapRef = sourceRef.get(sourceIdx);
				ICrossReferenceBean<? extends EnumeratedListBean> xsRef = mapRef.getEnumerationRef();
				if(xsRef != null && xsRef.getMaintainableStructureType() == SDMX_STRUCTURE_TYPE.CODE_LIST  && mappedValue.getPattern() == null && mappedValue.getStartIndex() <=0 && mappedValue.getEndIndex() <=0) {
					IURNSingle<CodeBean> codeRef = URN.builder().toIdentifiable(xsRef.getReference(), SDMX_STRUCTURE_TYPE.CODE, mappedValue.getValue()).buildSingle(CodeBean.class);
					references.add(DirectCrossReferenceBean.build(mappedRelationship.getIdentifiableParent(), "source", codeRef));
				}
				//TODO references with patterns and or regex will need to be a fuzzy
				sourceIdx++;
			}
			int targetIdx = 0;
			for(String targetValue : mappedRelationship.getTargetValue()) {
				if(!RegexUtil.hasCaptureGroup(targetValue)) {
					IRepresentationMapRefBean mapRef = targetRef.get(targetIdx);
					ICrossReferenceBean<? extends EnumeratedListBean> xsRef = mapRef.getEnumerationRef();
					if(xsRef != null && xsRef.getMaintainableStructureType() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
						IURNSingle<CodeBean> codeRef = URN.builder().toIdentifiable(xsRef.getReference(), SDMX_STRUCTURE_TYPE.CODE, targetValue).buildSingle(CodeBean.class);
						references.add(DirectCrossReferenceBean.build(mappedRelationship.getIdentifiableParent(), "target", codeRef));
					}
				}
				targetIdx++;
			}
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(mappedValues, composites);
		super.addToCompositeSet(sourceRef, composites);
		super.addToCompositeSet(targetRef, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IRepresentationMapBean.class;
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new RepresentationMapBean(this, actualLocation, isServiceUrl, completeStub);
	}

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<IRepresentationMapBean> getURN() {
		return (IURNMaintainable<IRepresentationMapBean>) super.getURN();
	}
	
	@Override
	public IRepresentationMapMutableBean getMutableInstance() {
		return new RepresentationMapMutableBean(this);
	}

	@Override
	public List<IRepresentationMapRefBean> getSourceRef() {
		return sourceRef;
	}

	@Override
	public List<IRepresentationMapRefBean> getTargetRef() {
		return targetRef;
	}

	@Override
	public List<IMappedRelationshipBean> getMappedValues() {
		return mappedValues;
	}

    @Override
    public RepresentationMapBeanDeferred toDeferred() {
        return new RepresentationMapBeanDeferred(this);
    }
    
    @Override
    public RepresentationMapBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new RepresentationMapBeanDeferred(getDeferredDefinition(), loader);
    }
}
