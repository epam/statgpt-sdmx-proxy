package io.sdmx.im.beans.codelist;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.im.beans.base.NameableBeanImpl;
import io.sdmx.im.beans.base.TextFormatBeanImpl;

public class LevelBeanImpl extends NameableBeanImpl implements LevelBean {
	private static final long serialVersionUID = -444829506005430291L;
	private LevelBean childLevel;
	private TextFormatBean textFormatBean;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	public LevelBeanImpl(IdentifiableBean parent, LevelMutableBean levelMutable) {
		super(levelMutable, parent.getParent(HierarchyBeanImpl.class, true));
		if(levelMutable.getCodingFormat() != null) {
			this.textFormatBean = TextFormatBeanImpl.getInstance(levelMutable.getCodingFormat(), this);
		}
		if(levelMutable.getChildLevel() != null) {
			this.childLevel = new LevelBeanImpl(this, levelMutable.getChildLevel());
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			LevelBean that = (LevelBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(childLevel, that.getChildLevel(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(textFormatBean, that.getCodingFormat(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return LevelBean.class;
	}
	
	@Override
	public TextFormatBean getCodingFormat() {
		return textFormatBean;
	}

	@Override
	public LevelBean getChildLevel() {
		return childLevel;
	}

	@Override
	public boolean hasChild() {
		return childLevel != null;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(childLevel, composites);
        super.addToCompositeSet(textFormatBean, composites);
        return composites;
    }
}
