package io.sdmx.im.beans.container;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IMetadatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IMSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class MetadatasetStructures implements IMetadatasetStructures {
	private MetadataStructureDefinitionBean metadataStructure;
	private MetadataFlowBean metadataflow;
	private MetadataProvisionAgreementBean provisionAgreement;
	private IMetadataProviderBean metadataProvider;

	public MetadatasetStructures(MetadataStructureDefinitionBean dataStructure) {
		this.metadataStructure = dataStructure;
		validate();
	}

	public MetadatasetStructures(MetadataStructureDefinitionBean dataStructure, MetadataFlowBean dataflow, MetadataProvisionAgreementBean provisionAgreement, IMetadataProviderBean dataProvider) {
		this.metadataStructure = dataStructure;
		this.metadataflow = dataflow;
		this.provisionAgreement = provisionAgreement;
		this.metadataProvider = dataProvider;
		validate();
	}

	public MetadatasetStructures(IMSDRelatedBean maint, SdmxBeanRetrievalManager beanRetrievalManager) {
		switch(maint.getStructureType()) {
		case METADATA_PROVISION : 
			provisionAgreement = (MetadataProvisionAgreementBean) maint;
			resolveMetadataProvider(beanRetrievalManager);
			resolveDataflow(provisionAgreement.getMetadataflowRef().getReference(), beanRetrievalManager);
			break;
		case METADATA_FLOW :
			metadataflow = (MetadataFlowBean) maint;
			resolveMSD(metadataflow.getMetadataStructureRef().getReference(), beanRetrievalManager);
			break;
		case MSD :  
			metadataStructure = (MetadataStructureDefinitionBean) maint;
			break;
			default : 
				throw new SdmxSemmanticException(maint.getUrn());
		}
	}

	public MetadatasetStructures(IURNSingle<? extends ConstrainableBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		switch(sRef.getSdmxStructure()) {
		case METADATA_PROVISION : 
			resolveProvisionAgreement(sRef.toType(MetadataProvisionAgreementBean.class), beanRetrievalManager);
			break;
		case METADATA_FLOW :
			resolveDataflow(sRef.toType(MetadataFlowBean.class), beanRetrievalManager);
			break;
		case MSD :
			resolveMSD(sRef.toType(MetadataStructureDefinitionBean.class), beanRetrievalManager);
			break;
		default : 
			throw new IllegalArgumentException(sRef.toString());
		}
	}
	
	private void resolveProvisionAgreement(IURNSingle<MetadataProvisionAgreementBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		provisionAgreement = beanRetrievalManager.getBean(sRef);
		if(provisionAgreement == null) {
			throw new SdmxReferenceException(sRef);
		}
		resolveMetadataProvider(beanRetrievalManager);
		resolveDataflow(provisionAgreement.getMetadataflowRef().getReference(), beanRetrievalManager);
	}
	
	private void resolveMetadataProvider(SdmxBeanRetrievalManager beanRetrievalManager) {
		try {
			this.metadataProvider = beanRetrievalManager.getBean(provisionAgreement.getMetadataProviderRef().getReference());
		} catch(Throwable th) {
			//Unresolvable
		}
	}

	
	private void resolveDataflow(IURNSingle<MetadataFlowBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		metadataflow = beanRetrievalManager.getBean(sRef);
		if(metadataflow == null) {
			throw new SdmxReferenceException(sRef);
		}
		resolveMSD(metadataflow.getMetadataStructureRef().getReference(), beanRetrievalManager);
	}

	
	private void resolveMSD(IURNSingle<MetadataStructureDefinitionBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		metadataStructure = beanRetrievalManager.getBean(sRef);
		if(metadataStructure == null) {
			throw new SdmxReferenceException(sRef);
		}
	}

	private void validate() {
		if(this.metadataStructure == null) {
			throw new SdmxException("IDatasetStructures -> DataStructure can not be null");
		}
	}
	
	@Override
	public MetadataStructureDefinitionBean getMetadataStructure() {
		return metadataStructure;
	}

	@Override
	public MetadataFlowBean getMetadataflow() {
		return metadataflow;
	}

	@Override
	public MetadataProvisionAgreementBean getProvisionAgreement() {
		return provisionAgreement;
	}

	@Override
	public IMetadataProviderBean getDataProvider() {
		return metadataProvider;
	}

	@Override
	public String toString() {
		return metadataStructure.toString();
	}

	private int hashCode = -1;
	
	@Override
	public int hashCode() {
		if(hashCode == -1) {
			StringBuilder sb = new StringBuilder();
			appendIdent(metadataStructure, sb);
			appendIdent(metadataflow, sb);
			appendIdent(provisionAgreement, sb);
			appendIdent(metadataProvider, sb);
			hashCode = sb.toString().hashCode();
		}
		return hashCode;
	}
	
	private void appendIdent(IdentifiableBean ident, StringBuilder sb) {
		if(ident == null) {
			sb.append("-");
		} else {
			sb.append(ident.getUrn());
		}
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof MetadatasetStructures) {
			MetadatasetStructures that = (MetadatasetStructures) obj;
			if(!ObjectUtil.equivalent(this.metadataStructure, that.getMetadataStructure())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.metadataflow, that.getMetadataflow())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.provisionAgreement, that.getProvisionAgreement())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.metadataProvider, that.getDataProvider())) {
				return false;
			}
			return true;
		}
		return false;
	}
}
