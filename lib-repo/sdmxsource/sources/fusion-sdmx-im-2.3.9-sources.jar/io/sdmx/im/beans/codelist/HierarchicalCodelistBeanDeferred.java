package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Date;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistRefBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class HierarchicalCodelistBeanDeferred extends MaintainableBeanDeferred<HierarchicalCodelistBean> implements HierarchicalCodelistBean {
    private static final long serialVersionUID = 1L;

    public HierarchicalCodelistBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public HierarchicalCodelistBeanDeferred(HierarchicalCodelistBean codelist) {
        super(codelist);
    }
    
    @Override
    protected HierarchicalCodelistBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchicalCodelistBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    public HierarchicalCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new HierarchicalCodelistBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<CodelistBean> getURN() {
        return (IURNMaintainable<CodelistBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return CodelistBean.class;
    }

    @Override
    public List<HierarchyBean> getHierarchies() {
        return load().getHierarchies();
    }

    @Override
    public List<CodelistRefBean> getCodelistRef() {
        return load().getCodelistRef();
    }

    @Override
    public String getCodelistAlias(String codelistURN) {
        return load().getCodelistAlias(codelistURN);
    }

    @Override
    public HierarchicalCodelistMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public HierarchicalCodelistBean cloneForDate(Date aDate) {
        return load().cloneForDate(aDate);
    }

}
