package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.SDMXBeanUtil;

public abstract class SDMXBeanImpl implements SDMXBean {
	private static final long serialVersionUID = 13L;
	protected SDMX_STRUCTURE_TYPE structureType;
	protected SDMXBean parent;

	transient Set<SDMXBean> composites;
	transient Set<String> supportedLanguages;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected SDMXBeanImpl(SDMXBean bean) {
//		if (bean == null) {
//			throw new SdmxSemmanticException(ExceptionCode.JAVA_REQUIRED_OBJECT_NULL, "bean in constructor");
//		}
		if(bean != null) {
			this.parent = bean.getParent();
		}
	}
	
	protected SDMXBeanImpl(SDMX_STRUCTURE_TYPE structureType, SDMXBean bean) {
		this.parent = bean;
		this.structureType = structureType;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public SDMXBeanImpl(MutableBean mutableBean, SDMXBean parent) {
		if (mutableBean == null) {
			throw new SdmxSemmanticException(ExceptionCode.JAVA_REQUIRED_OBJECT_NULL, "bean in constructor");
		}
		this.parent = parent;
	}

	protected static TERTIARY_BOOL createTertiary(boolean isSet, boolean value) {
		return SDMXBeanUtil.createTertiary(isSet, value);
	}
	

	@Override
	public IdentifiableBean getIdentifiableParent() {
		SDMXBean currentParent = getParent();
		while(currentParent != null) {
			if(currentParent instanceof IdentifiableBean) {
				return (IdentifiableBean)currentParent;
			}
			currentParent = currentParent.getParent();
		}
		return null;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getStructureType() {
		return structureType;
	}

	@Override
	public SDMXBean getParent() {
		return parent;
	}

	@Override
	public String getStructureName() {
		if(getStructureType() == null) {
			return getClass().getName();
		}
		return getStructureType().getType();
	}

	protected boolean deepEqualsInternal(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean.getStructureName().equals(this.getStructureName())) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties) {
		if(this == bean) {
			//Early Out
			return true;
		}
		return this.deepEquals(bean, includeFinalProperties, null);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	protected boolean equivalent(Collection<? extends SDMXBean> list1, Collection<? extends SDMXBean> list2, boolean includeFinalProperties, String property, DiffReport diffReport) {
		Map<String, SDMXBean> sourceByKey = new HashMap<>();
		List<SDMXBean> keylessSource = new ArrayList<>();
		for(SDMXBean sourceBean : list1) {
			if(sourceBean.getKey() == null) {
				keylessSource.add(sourceBean);
			} else {
				sourceByKey.put(sourceBean.getKey(), sourceBean);
			}
		}

		Map<String, SDMXBean> targetByKey = new HashMap<>();
		List<SDMXBean> keylessTarget = new ArrayList<>();
		for(SDMXBean targetBean : list2) {
			if(targetBean.getKey() == null) {
				keylessTarget.add(targetBean);
			} else {
				targetByKey.put(targetBean.getKey(), targetBean);
			}
		}

		boolean returnVal = true;
		for(String key : sourceByKey.keySet()) {
			SDMXBean sourceBean = sourceByKey.get(key);
			SDMXBean targetBean = targetByKey.get(key);
			targetByKey.remove(key);
			if(targetBean == null) {
				if(diffReport == null) {
					return false;
				}
				returnVal = false;
				diffReport.addDiff(sourceBean, property, sourceBean, null);
			} else if(!sourceBean.deepEquals(targetBean, includeFinalProperties, diffReport)) {
				if(diffReport == null) {
					return false;
				}
				returnVal = false;
			}
		}
		//Loop left over targets, with no source
		for(String key : targetByKey.keySet()) {
			SDMXBean targetBean = targetByKey.get(key);
			if(diffReport == null) {
				return false;
			}
			returnVal = false;
			diffReport.addDiff(targetBean, property, null, targetBean);
		}

		for(int i = 0; i < keylessSource.size(); i++) {
			SDMXBean sourceBean = keylessSource.get(i);
			SDMXBean targetBean = keylessTarget.size() > i ? keylessTarget.get(i) : null;
			if(targetBean == null) {
				if(diffReport == null) {
					return false;
				}
				returnVal = false;
				diffReport.addDiff(sourceBean, property, sourceBean, null);
			} else if(!sourceBean.deepEquals(targetBean, includeFinalProperties, diffReport)) {
				if(diffReport == null) {
					return false;
				}
				returnVal = false;
			}
		}
		for(int i = keylessSource.size(); i < keylessTarget.size(); i++) {
			SDMXBean targetBean = keylessTarget.get(i);
			if(diffReport == null) {
				return false;
			}
			returnVal = false;
			diffReport.addDiff(targetBean, property, null, targetBean);
		}
		return returnVal;
	}
	
	/**
	 * For performance reasons convert URL to string (URL compare takes over 2 seconds)
	 * @param o1
	 * @param o2
	 * @param property
	 * @param diffReport
	 * @return
	 */
	protected boolean equivalent(URL o1, URL o2, String property, DiffReport diffReport) {
		String s1 = o1 == null ? null : o1.toString();
		String s2 = o2 == null ? null : o2.toString();
		return equivalent(s1, s2, property, diffReport);
	}


	protected boolean equivalent(Object o1, Object o2, String property, DiffReport diffReport) {
		if(!ObjectUtil.equivalent(o1, o2)) {
			if(diffReport != null) {
				diffReport.addDiff(this, property, o1, o2);
			}
			return  false;
		}
		return true;
	}

	protected boolean equivalentMap(SDMXBean bean, Map<? extends Object, ? extends Object> source, Map<? extends Object, ? extends Object> target, String property, DiffReport diffReport) {
		boolean equivalentCollection = equivalentCollection(bean, source.keySet(), target.keySet(), property, diffReport);
		if(!equivalentCollection && diffReport == null) {
			return false;
		}
		for(Object sourceKey : source.keySet()) {
			Object targetVal = target.get(sourceKey);
			if(targetVal != null) {
				Object sourceVal = source.get(sourceKey);
				if(!this.equivalent(sourceVal, targetVal, property, diffReport)) {
					equivalentCollection = false;
				}
			}
		}
		return equivalentCollection;
	}

	protected boolean equivalent(SDMXBean bean1, SDMXBean bean2, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean1 == null) {
			boolean equivalent = bean2 == null;
			if(equivalent == false && diffReport != null) {
				diffReport.addDiff(bean2, bean2.getStructureName(), bean1, bean2);
			}
			return equivalent;
		}
		if(bean2 == null) {
			boolean equivalent = bean1 == null;
			if(equivalent == false && diffReport != null) {
				diffReport.addDiff(bean1, bean1.getStructureName(), bean1, bean2);
			}
			return equivalent;
		}
		return bean1.deepEquals(bean2, includeFinalProperties, diffReport);
	}

	protected boolean equivalent(Collection<? extends ICrossReferenceBean<?>> sourceRef, Collection<? extends ICrossReferenceBean<?>> targetRef, DiffReport diffReport) {
		Map<String, ICrossReferenceBean<?>> sourceUrnMap = toMap(sourceRef);
		Map<String, ICrossReferenceBean<?>> targetUrnMap = toMap(targetRef);
		Set<String> sourceKeys = new HashSet<>(sourceUrnMap.keySet());
		sourceUrnMap.keySet().removeAll(targetUrnMap.keySet());
		targetUrnMap.keySet().removeAll(sourceKeys);
		boolean equivalent = sourceUrnMap.size() == 0 && targetUrnMap.size() == 0;
		if(diffReport != null) {
			for(String key : sourceUrnMap.keySet()) {
				ICrossReferenceBean<?> ref = sourceUrnMap.get(key);
				diffReport.addDiff(ref.getReferencedFrom().getParent(IdentifiableBean.class, true), ref.getReference().getStructureType().getUrnClass()+ " Reference", formatRef(ref), null);
			}
			for(String key : targetUrnMap.keySet()) {
				ICrossReferenceBean<?> ref = targetUrnMap.get(key);
				diffReport.addDiff(ref.getReferencedFrom().getParent(IdentifiableBean.class, true), ref.getReference().getStructureType().getUrnClass()+ " Reference", null, formatRef(ref));
			}
		}
		return equivalent;
	}

	/**
	 * Ensures the collection contains both the same content
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static boolean equivalentCollection(SDMXBean bean, Collection<?> c1, Collection<?> c2, String property, DiffReport diffReport) {
		boolean equivalent = true;
		if(ObjectUtil.validCollection(c1) && !ObjectUtil.validCollection(c2)) {
			equivalent = false;
			if(diffReport != null) {
				for(Object currentSource : c1) {
					diffReport.addDiff(bean, property, currentSource, null);
				}
			}
		} else if(!ObjectUtil.validCollection(c1) && ObjectUtil.validCollection(c2)) {
			equivalent = false;
			if(diffReport != null) {
				for(Object currentSource : c2) {
					diffReport.addDiff(bean, property, currentSource, null);
				}
			}
		} else {
			Set<Object> source = new HashSet<>(c1);
			Set<Object> target = new HashSet<>(c2);
			source.removeAll(target);
			target.removeAll(c1);
			equivalent = source.size() == 0 && target.size() == 0;
			if(diffReport != null) {
				for(Object currentSource : source) {
					diffReport.addDiff(bean, property, currentSource, null);
				}
				for(Object currentTarget : target) {
					diffReport.addDiff(bean, property, null, currentTarget);
				}
			}
		}
		return equivalent;
	}

	protected boolean sameOrder(List<? extends SDMXBean> list1, List<? extends SDMXBean> list2, String property, DiffReport diffReport) {
	    //iterate each in turn, and do a check on sourceBean.getKey().equals(target.getKey()))
        for (int i=0; i < list1.size(); i++) {
            if (!list1.get(i).equals(list2.get(i))) {
                if (diffReport == null) {
                    return false;
                } else {
                    // Only report a single element otherwise a long list may report an unmanageable number of differences
                    diffReport.addDiff(this, property + " Order", list1.get(i).getKey(), list2.get(i).getKey());
                    break;
                }
            }
        }
        return true;
	}

	private Map<String, ICrossReferenceBean<?>> toMap(Collection<? extends ICrossReferenceBean<?>> ref) {
		Map<String, ICrossReferenceBean<?>> returnMap = new HashMap<>();
		for(ICrossReferenceBean<?> xsRef : ref) {
			returnMap.put(xsRef.getReference().getURN(), xsRef);
		}
		return returnMap;
	}

	protected boolean equivalent(ICrossReferenceBean<?> sourceRef, ICrossReferenceBean<?> targetRef, DiffReport diffReport) {
		if(sourceRef == null && targetRef == null) {
			return true;
		}
		String structureRef = sourceRef != null ? sourceRef.getReference().getStructureType().getUrnClass() : targetRef.getReference().getStructureType().getUrnClass();
		structureRef = structureRef + " Reference";
		if(sourceRef == null) {
			if(diffReport != null) {
				diffReport.addDiff(targetRef.getReferencedFrom().getParent(IdentifiableBean.class, true), structureRef, sourceRef, formatRef(targetRef));
			}
			return false;
		}
		if(targetRef == null) {
			if(diffReport != null) {
				diffReport.addDiff(sourceRef.getReferencedFrom().getParent(IdentifiableBean.class, true), structureRef, formatRef(sourceRef), targetRef);
			}
			return false;
		}
		if(!targetRef.equals(sourceRef)) {
			if(diffReport != null) {
				diffReport.addDiff(sourceRef.getReferencedFrom().getParent(IdentifiableBean.class, true), structureRef, formatRef(sourceRef), formatRef(targetRef));
			}
			return false;
		}
		return true;
	}

	private String formatRef(ICrossReferenceBean<?> ref) {
		if(ref == null) {
			return null;
		}
		return ref.getReference().getShortURN();
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> T getParent(Class<T> type, boolean includeThisType) {
		if(includeThisType) {
			if(type.isAssignableFrom(this.getClass())) {
				return (T)this;
			}
		}
		if(parent != null) {
			if(type.isAssignableFrom(parent.getClass())) {
				T returnObj = (T)parent;
				return returnObj;
			} else {
				return parent.getParent(type, false);
			}
		}
		if(type.isAssignableFrom(this.getClass())) {
			return (T)this;
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> Set<T> getComposites(Class<T> type) {
		Set<T> returnSet = new HashSet<>();
		for(SDMXBean currentComposite : getComposites()) {
			if(type.isAssignableFrom(currentComposite.getClass())) {
				returnSet.add((T)currentComposite);
			}
		}
		return returnSet;
	}


	@Override
	public final Set<SDMXBean> getComposites() {
		if(composites == null) {
			this.composites = getCompositesInternal();
		}
		composites = Collections.unmodifiableSet(composites);
		return composites;
	}

	protected abstract Set<SDMXBean> getCompositesInternal();
	
	
	protected void addToCompositeSet(Collection<? extends SDMXBean> comp, Set<SDMXBean> compositesSet) {
		for(SDMXBean composite : comp) {
			addToCompositeSet(composite, compositesSet);
		}
	}

	protected void addToCompositeSet(SDMXBean composite, Set<SDMXBean> composites) {
		if (composite != null) {
			composites.add(composite);
		}

		//Add Bean's Composites
		if (composite != null) {
			Set<SDMXBean> getComposites = composite.getComposites();
			if (getComposites != null) {
				composites.addAll(getComposites);
			}
		}
	}

	@Override
	public synchronized Set<String> getSupportedLanguages() {
		if(supportedLanguages == null) {
			//LAZY LOAD
			SortedSet<String> supportedLanguagesLocal = new TreeSet<>();
			for(TextTypeWrapper tt : getComposites(TextTypeWrapper.class)) {
				supportedLanguagesLocal.add(tt.getLocale());
			}
			supportedLanguages = Collections.unmodifiableSortedSet(supportedLanguagesLocal);
		}
		return supportedLanguages;
	}

	@Override
	public String toString() {
		return this.getKey();
	}
}
