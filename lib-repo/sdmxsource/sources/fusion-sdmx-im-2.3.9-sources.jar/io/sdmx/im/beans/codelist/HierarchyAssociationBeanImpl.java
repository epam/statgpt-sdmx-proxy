package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyAssociationMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class HierarchyAssociationBeanImpl extends MaintainableBeanImpl implements HierarchyAssociationBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<HierarchyBean> hierarchyRef;
	private IDirectCrossReferenceBean<?> linkRef;
	private IDirectCrossReferenceBean<?> contextRef;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	HierarchyAssociationBeanImpl(HierarchyAssociationBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public HierarchyAssociationBeanImpl(HierarchyAssociationMutableBean bean) {
		super(bean);
		try {
			if(bean.getHierarchyRef() != null) {
				this.hierarchyRef = DirectCrossReferenceBean.build(this, "hierarchy", bean.getHierarchyRef(), HierarchyBean.class);
			}
			if(bean.getLinkedStructure() != null) {
				this.linkRef = DirectCrossReferenceBean.build(this, "structure", bean.getLinkedStructure(), IdentifiableBean.class);
			}
			if(bean.getContextStructure() != null) {
				this.contextRef = DirectCrossReferenceBean.build(this, "context", bean.getContextStructure(), IdentifiableBean.class);
			}
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(hierarchyRef == null) {
			throw new SdmxSemmanticException("Hierarchy Association is missing reference to Hierarchy");
		}
		if(hierarchyRef.getTargetReference() != SDMX_STRUCTURE_TYPE.HIERARCHY) {
			throw new SdmxSemmanticException("Hierarchy Reference must reference structure type: "+SDMX_STRUCTURE_TYPE.HIERARCHY.getUrnPrefix());
		}
		if(linkRef == null) {
			throw new SdmxSemmanticException("Hierarchy Association is missing reference to Maintainable");
		}
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			HierarchyAssociationBean that = (HierarchyAssociationBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(hierarchyRef, that.getHierarchyRef(), "Hierarchy Reference", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(linkRef, that.getLinkedStructureRef(), "Linked Structure", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(contextRef, that.getContextStructureRef(), "Context Structure", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return HierarchyAssociationBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<HierarchyAssociationBean> getURN() {
		return (IURNMaintainable<HierarchyAssociationBean>) super.getURN();
	}
	
	@Override
	public HierarchyAssociationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new HierarchyAssociationBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(hierarchyRef != null) {
			references.add(hierarchyRef);
		}
		if(linkRef != null) {
			references.add(linkRef);
		}
		if(contextRef != null) {
			references.add(contextRef);
		}
	}

	@Override
	public HierarchyAssociationMutableBean getMutableInstance() {
		return new HierarchyAssociationMutableBeanImpl(this);
	}

	@Override
	public ICrossReferenceBean<HierarchyBean> getHierarchyRef() {
		return hierarchyRef;
	}

	@Override
	public ICrossReferenceBean<?> getLinkedStructureRef() {
		return linkRef;
	}

	@Override
	public ICrossReferenceBean<?> getContextStructureRef() {
		return contextRef;
	}

    @Override
    public HierarchyAssociationBeanDeferred toDeferred() {
        return new HierarchyAssociationBeanDeferred(this);
    }
    
    @Override
    public HierarchyAssociationBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyAssociationBeanDeferred(getDeferredDefinition(), loader);
    }
}
