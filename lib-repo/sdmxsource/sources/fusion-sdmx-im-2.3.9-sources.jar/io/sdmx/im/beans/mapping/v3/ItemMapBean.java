package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

import java.util.regex.Pattern;

public abstract class ItemMapBean extends AnnotableBeanImpl implements IItemMapBean {
	private static final long serialVersionUID = 11L;

	private String sourceId;
	private String targetId;
	private Integer sourceStartIdx;
	private Integer sourceEndIdx;
	private boolean isRegEx;
	private SdmxPeriod validityPeriod;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ItemMapBean(IItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		this.sourceId = bean.getSourceId();
		this.targetId = bean.getTargetId();
		this.sourceStartIdx = bean.getSourceStartIdx();
		this.sourceEndIdx = bean.getSourceEndIdx();
		this.isRegEx = bean.isSourceRegEx();
		if (bean.getValidFrom() != null || bean.getValidTo() != null) {
			this.validityPeriod = new SdmxPeriodImpl(bean.getValidFrom(), bean.getValidTo());
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if (bean == null) {
			return false;
		}
		if (bean.getStructureType() == this.getStructureType()) {
			ItemMapBean that = (ItemMapBean) bean;
			boolean returnVal = true;
			if (!super.equivalent(sourceId, that.getSourceId(), "Source", diff)) {
				returnVal = false;
			}
			if (!super.equivalent(targetId, that.getTargetId(), "Target", diff)) {
				returnVal = false;
			}
			if (!super.equivalent(sourceStartIdx, that.getSourceStartIdx(), "Start Index", diff)) {
				returnVal = false;
			}
			if (!super.equivalent(sourceEndIdx, that.getSourceEndIdx(), "End Index", diff)) {
				returnVal = false;
			}
			if (!super.equivalent(isRegEx, that.isSourceRegEx(), "RegEx", diff)) {
				returnVal = false;
			}
			if (!super.equivalent(validityPeriod, that.getValidityPeriod(), "Validity Period", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if (!ObjectUtil.validString(this.sourceId)) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, "ItemMap", "Source Id");
		}
		if (!ObjectUtil.validString(this.targetId)) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, "ItemMap", "Target Id");
		}
		if (sourceStartIdx != null && sourceEndIdx != null && sourceStartIdx > sourceEndIdx) {
			throw new SdmxSemmanticException("Source Index can not be greater then end index");
		}
		if (sourceStartIdx != null && sourceStartIdx < 0) {
			throw new SdmxSemmanticException("Source Index can not less then 0");
		}
		if (sourceEndIdx != null && sourceEndIdx < 0) {
			throw new SdmxSemmanticException("End Index can not less then 0");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS							 	 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getSourceId() {
		return sourceId;
	}

	@Override
	public String getTargetId() {
		return targetId;
	}

	@Override
	public Integer getSourceStartIdx() {
		return sourceStartIdx;
	}

	@Override
	public Integer getSourceEndIdx() {
		return sourceEndIdx;
	}

	@Override
	public boolean isSourceRegEx() {
		return isRegEx;
	}

	@Override
	public SdmxPeriod getValidityPeriod() {
		return validityPeriod;
	}

	/**
	 * @return compiled pattern or null if source is not regex
	 */
	@Override
	public Pattern getSourcePattern() {
		if (isRegEx) {
			return Pattern.compile(sourceId);
		} else {
			return null;
		}
	}

	@Override
	public String getKey() {
		return sourceId + "-" + targetId;
	}
}
