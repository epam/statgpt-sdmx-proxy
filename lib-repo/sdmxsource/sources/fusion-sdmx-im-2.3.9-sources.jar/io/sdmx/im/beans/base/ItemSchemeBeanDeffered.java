package io.sdmx.im.beans.base;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;

public abstract class ItemSchemeBeanDeffered<T extends ItemBean, V extends ItemSchemeBean<T>> extends MaintainableBeanDeferred<V> implements ItemSchemeBean<T> {
    private static final long serialVersionUID = 1L;


    private boolean itemsHasValidityPeriod = false;
    private boolean isPartial = false;
    
    protected ItemSchemeBeanDeffered(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
        Boolean hasVP = bean.getBooleanProperty("VPItem");
        itemsHasValidityPeriod = hasVP == null ? false : hasVP;
        
        Boolean isPartial = bean.getBooleanProperty("Partial");
        isPartial = isPartial == null ? false : isPartial;
    }
    
    protected ItemSchemeBeanDeffered(V bean) {
        super(bean);
        itemsHasValidityPeriod = bean.itemsHasValidityPeriod();
        this.isPartial = bean.isPartial();
    }
    
    /**
     * Override from {@link IdentifiableBean} to give specific types in generics
     */
    @Override
    public IURNMaintainable<? extends ItemSchemeBean<T>> getURN() {
        return (IURNMaintainable<? extends ItemSchemeBean<T>>) super.getURN();
    }

    @Override
    public List<T> getItems() {
        return load().getItems();
    }

    @Override
    public List<T> getItems(Date date) {
        return load().getItems(date);
    }

    @Override
    public boolean isPartial() {
        return isPartial;
    }

    @Override
    public ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return load().filterItems(filterIds, isKeepSet);
    }

    @Override
    public ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet, ITEM_FILTER_ACTION action) {
        return load().filterItems(filterIds, isKeepSet, action);
    }

    @Override
    public T getItemById(String id) {
        return load().getItemById(id);
    }

    @Override
    public List<T> getAllItemsById(String id) {
        return load().getAllItemsById(id);
    }

    @Override
    public ItemSchemeBean<T> cloneForDate(Date date) {
        return load().cloneForDate(date);
    }

    @Override
    public List<T> getItemsValidForTodayAndClosestToToday() {
        return load().getItemsValidForTodayAndClosestToToday();
    }

    @Override
    public List<T> getInvalidItems(String id) {
        return load().getInvalidItems(id);
    }

    @Override
    public boolean itemsHasValidityPeriod() {
        return this.itemsHasValidityPeriod;
    }
}