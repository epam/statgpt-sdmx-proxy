package io.sdmx.im.beans;

import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.event.SdmxBeansEventXS;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

public class SdmxBeansEventXSImpl implements SdmxBeansEventXS {
	private SdmxBeansEvent event;
	private SdmxBeans xsUpdates;

	public SdmxBeansEventXSImpl(SdmxBeansEvent event, SdmxBeans xsUpdates) {
		this.event = event;
		this.xsUpdates = xsUpdates;
	}

	@Override
	public SdmxBeans getOldContainer() {
		return event.getOldContainer();
	}

	@Override
	public SdmxBeans getNewContainer() {
		return event.getNewContainer();
	}

	@Override
	public SdmxBeans getModification() {
		return event.getModification();
	}

	@Override
	public SdmxBeans getAdditions() {
		return event.getAdditions();
	}

	@Override
	public SdmxBeans getDeletions() {
		return event.getDeletions();
	}

	@Override
	public SdmxBeans getCrossReferenceUpdates() {
		return xsUpdates;
	}
}
