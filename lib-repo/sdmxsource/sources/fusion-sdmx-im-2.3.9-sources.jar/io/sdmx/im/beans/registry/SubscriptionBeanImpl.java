package io.sdmx.im.beans.registry;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.SubscriptionMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.registry.SubscriptionMutableBeanImpl;
import io.sdmx.utils.core.mail.EmailValidation;
import io.sdmx.utils.core.random.RandomUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public class SubscriptionBeanImpl extends MaintainableBeanImpl implements SubscriptionBean {
	private static final Logger LOG = LoggerFactory.getLogger(SubscriptionBeanImpl.class);
	
	private static final long serialVersionUID = 184L;
	
	private ICrossReferenceBean<? extends OrganisationBean> owner;
	private List<String> mailTo = new ArrayList<>();
	private List<String> HTTPPostTo = new ArrayList<>();
	private List<IURN<?>> references = new ArrayList<>();
	private SUBSCRIPTION_TYPE subscriptionType;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private SubscriptionBeanImpl(SubscriptionBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public SubscriptionBeanImpl(SubscriptionMutableBean mutableBean) {
		super(setIdentifiers(mutableBean));
		LOG.debug("Building Subscription from Mutable Bean");
		if(mutableBean.getOwner() != null) {
			this.owner = DirectCrossReferenceBean.build(this, "owner", URN.builder(mutableBean.getOwner().getTargetUrn()).buildSingle(OrganisationBean.class));
		}
		if(mutableBean.getMailTo() != null) {
			this.mailTo = new ArrayList<>(mutableBean.getMailTo());
		}
		if(mutableBean.getHTTPPostTo() != null) {
			this.HTTPPostTo = new ArrayList<>(mutableBean.getHTTPPostTo());
		}
		if(mutableBean.getReferences() != null) {
			for(StructureReferenceBean ref : mutableBean.getReferences()) {
				references.add(URN.builder(ref.getTargetUrn(true)).build());
			}
		}
		
		this.subscriptionType = mutableBean.getSubscriptionType();
		validate();
		if(LOG.isDebugEnabled()) {
			LOG.debug("subscription Built " + this.getUrn());
		}
	}
	/**
     * Sets missing identifiers as required
     */
    private static SubscriptionMutableBean setIdentifiers(SubscriptionMutableBean sub) {
        if(sub.getId() == null) {
            sub.setId(RandomUtil.randomString());
        }
        if(sub.getAgencyId() == null) {
            if(sub.getOwner() == null) {
                throw new SdmxSemmanticException("Registration missing provision agreement reference");
            }
            sub.setAgencyId(sub.getOwner().getAgencyId());
        }
        return sub;
    }
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION 							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(this.isFinal) {
			throw new SdmxSemmanticException("Subscription can not be made final");
		}
		if(!this.getVersion().toString().equals(DEFAULT_VERSION)) {
			throw new SdmxSemmanticException("Subscription can not have a version, other then the default version : " + DEFAULT_VERSION);
		}
		if(this.owner == null) {
			throw new SdmxSemmanticException("Subscription must have an owner which must be a data consumer - no owner provided");
		}
		if(owner.getTargetReference() != SDMX_STRUCTURE_TYPE.DATA_CONSUMER
				&& 	owner.getTargetReference() != SDMX_STRUCTURE_TYPE.DATA_PROVIDER
				&& 	owner.getTargetReference() != SDMX_STRUCTURE_TYPE.AGENCY) {
			throw new SdmxSemmanticException("Subscription must have an owner which must be an agency, data provider, or data consumer - " + owner.getTargetReference().getType() + " was provided");
		}
		if(mailTo.size() == 0 && HTTPPostTo.size() == 0) {
			throw new SdmxSemmanticException("Subscription must declare at least one HTTP POST to, or mail to address to send notifications to");
		}
		for(String currentEmail : mailTo) {
			if(!EmailValidation.validateEmail(currentEmail)) {
				throw new SdmxSemmanticException("'"+currentEmail + "' is not a valid email address");
			}
		}
		for(String currentHttp : HTTPPostTo) {
			try {
				new URL(currentHttp);
			} catch(MalformedURLException e) {
				throw new SdmxSemmanticException("'"+currentHttp + "' is not a valid URL");
			}
		}
		//FUNC Validate email addresses?
		//FUNC Validate POST addresses?
		if(references.size() == 0) {
			//Subscribe to ALL
			references.add(URN.ANY_MAINTINABLE);
		}
		if(this.subscriptionType == null) {
			throw new SdmxSemmanticException("Subscription type not declared");
		}

		super.validateAgencyId();
		this.references = Collections.unmodifiableList(references);
	}
	
	@Override
	protected void validateAgencyId() {
		//Do nothing yet, not yet fully built
	}
	
	
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		throw new SdmxNotImplementedException("deepEquals on subscription");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return SubscriptionBean.class;
	}
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<SubscriptionBean> getURN() {
		return (IURNMaintainable<SubscriptionBean>) super.getURN();
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(owner != null) {
			references.add(owner);
		}
	}

	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new SubscriptionBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public SubscriptionMutableBean getMutableInstance() {
		return new SubscriptionMutableBeanImpl(this);
	}

	@Override
	public ICrossReferenceBean getOwner() {
		return owner;
	}
	
	@Override
	public String getAgencyId() {
		if(owner.getTargetReference() == SDMX_STRUCTURE_TYPE.AGENCY) {
			if(owner.getReference().getAgencyId().equals(AgencySchemeBean.DEFAULT_SCHEME)) {
				return owner.getReference().getIdentifiableId();
			}
			String id = owner.getReference().getAgencyId();
			id += "."+owner.getReference().getFullIdentifiableId();
			return id;
		}
		return owner.getReference().getAgencyId();
	}

	@Override
	public List<String> getMailTo() {
		return new ArrayList<>(mailTo);
	}

	@Override
	public List<String> getHTTPPostTo() {
		return new ArrayList<>(HTTPPostTo);
	}
	@Override
	public List<IURN<?>> getReferences() {
		return references;
	}

	@Override
	public SUBSCRIPTION_TYPE getSubscriptionType() {
		return subscriptionType;
	}

	@Override
	public String getUrn() {
		return super.getUrn() + "." + owner.getReference().getIdentifiableId() + "." + owner.getTargetReference().getUrnClass();
	}

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        // TODO Auto-generated method stub
        return null;
    }
    
    @Override
    public IMaintainableBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return null;
    }
}
