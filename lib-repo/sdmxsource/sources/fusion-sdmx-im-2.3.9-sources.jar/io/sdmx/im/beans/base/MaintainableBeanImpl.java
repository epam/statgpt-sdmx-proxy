package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.UUID;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanFuzzy;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.diff.DiffReportImpl;
import io.sdmx.im.format.SDMXMetadataStandard;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public abstract class MaintainableBeanImpl extends VersionableBeanImpl implements MaintainableBean, Comparable<MaintainableBean> {
	private String internalId;
	private static final long serialVersionUID = 33L;
	private String checksum;

	protected boolean isFinal = false;
	protected boolean isExternalReference = false;
	protected boolean isStub = false;
	protected URL serviceURL;
	protected URL structureURL;

	private transient SortedSet<String> locales;
	private transient Map<String, IdentifiableBean> identifiablesById;

	transient boolean hasDynamicAnnotations = false;
	transient Set<IDirectCrossReferenceBean<?>> crossReferences;
	transient Set<ICrossReferenceBeanFuzzy> crossReferencesFuzzy;
	
	private IMaintainableProperties properties;
	

	@Override
	@SuppressWarnings("all")
	public final Set<IDirectCrossReferenceBean<?>> getCrossReferences() {
		if(crossReferences == null) {
			buildCrossReferences();
		}
		return crossReferences;
	}
	
	@Override
	public Set<ICrossReferenceBeanFuzzy> getCrossReferencesFuzzy() {
		if(crossReferencesFuzzy == null) {
			buildCrossReferences();
		}
		return crossReferencesFuzzy;
	}
	
	@Override
    public String getChecksum() {
//        if(checksum == null && SdmxSystem.getBeanSerialiser() != null) {
//            ChecksumOutputStream out = new ChecksumOutputStream(OutputStream.nullOutputStream());
//            SdmxSystem.getBeanSerialiser().write(this, out);
//            this.checksum = out.getChecksum();
//        }
	    if(checksum == null) {
	        checksum = UUID.randomUUID().toString();
	    }
        return checksum; //getAgencyId()+getId()+getVersion().toString();  //TODO
    }
	
	protected void buildCrossReferences() {
		Set<ICrossReferenceBeanBase> baseSet = new HashSet<>();
		getCrossReferences(baseSet);
		for(SDMXBean bean : getComposites()) {
			bean.getCrossReferences(baseSet);
		}
		Set<IDirectCrossReferenceBean<?>> singleSet = new HashSet<>(baseSet.size());
		Set<ICrossReferenceBeanFuzzy> fuzzySet = new HashSet<>();
		for(ICrossReferenceBeanBase xsRef : baseSet) {
			if(xsRef== null) continue;
			
			if(xsRef.isWildcardReference()) {
				fuzzySet.add((ICrossReferenceBeanFuzzy) xsRef);
			} else {
				singleSet.add((IDirectCrossReferenceBean) xsRef);
			}
		}
		crossReferences = Collections.unmodifiableSet(singleSet);
		crossReferencesFuzzy = Collections.unmodifiableSet(fuzzySet);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected MaintainableBeanImpl(MaintainableBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, completeStub);
		this.serviceURL = bean.getServiceURL();
		this.structureURL = bean.getStructureURL();
		this.isExternalReference = true;  //Stub Bean is Externally Referenced
		this.isStub = true;
		if(actualLocation == null) {
			throw new SdmxSemmanticException("Stub Beans require a URL defining the actual service to obtain the full Sdmx artefact from");
		}
		if(isServiceUrl) {
			this.serviceURL = actualLocation;
		} else {
			this.structureURL = actualLocation;
		}
		this.properties = MaintainableProperties.getInstance(bean.getAgencyId(), bean.getId(), bean.getVersion());

		this.isFinal = bean.isFinal();
		validateMaintainableAttributes();
		this.checksum = bean.getChecksum();
//		super.completeConstruction();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected MaintainableBeanImpl(MaintainableMutableBean bean) {
		super(bean, null);

		this.isFinal = bean.getFinalStructure();
		this.isExternalReference = bean.getExternalReference();
		this.properties = MaintainableProperties.getInstance(bean.getAgencyId(), super.getId(), super.getVersion());
		if(bean.isStub()) {
			this.isExternalReference = true;
		}
		if(bean.getServiceURL() != null) {
			setServiceURL(bean.getServiceURL());
		}
		if(bean.getStructureURL() != null) {
			setStructureURL(bean.getStructureURL());
		}
		validateMaintainableAttributes();
//		super.completeConstruction();
	}
	
	
//	 /**
//     * Sets the URN - allows an override to defer this action if required
//     */
//    protected void completeConstruction() {
//    	//Defer this
//    }
	/**
	 * Force upper case, otherwise database PK can fail in some environments with duplicate but different cases
	 */
	 @Override
    protected void setId(String id) {
		 if(id == null) {
			 super.setId(null);
		 } else {
			 super.setId(id.toUpperCase());
		 }
	 }

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	protected boolean deepEqualsInternal(MaintainableBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(includeFinalProperties) {
			/*if(!super.equivalent(this.validityPeriod, bean.getValidityPeriod(), "Validity Period", diff)) {
				returnVal =  false;
			}*/
			if(!super.equivalent(isExternalReference, bean.isExternalReference(), "Is External", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(serviceURL, bean.getServiceURL(), "Service URL", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(structureURL, bean.getStructureURL(), "Structure URL", diff)) {
				returnVal =  false;
			}
		}

		if(!super.equivalent(getAgencyId(), bean.getAgencyId(), "Agency Id", diff)) {
			returnVal =  false;
		}
		if(!super.equivalent(isFinal, bean.isFinal(), "Is Final", diff)) {
			returnVal =  false;
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}


	@Override
	public DiffReport diff(MaintainableBean target) {
		DiffReport diffReport = new DiffReportImpl(this, target);

		ThreadLocalUtil.storeOnThread("DIFF", Boolean.TRUE);
		try {
			//FR-3230 the diffReport may have mutated the target to make the agency id the same as the source
			deepEquals(diffReport.getTarget(), true, diffReport);
		} finally {
			ThreadLocalUtil.clearFromThread("DIFF");
		}
		return diffReport;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected void validateMaintainableAttributes() throws SdmxSemmanticException {
		validateAgencyId();
		
		if(this.isExternalReference) {
			if(this.structureURL == null  && this.serviceURL == null) {
				throw new SdmxSemmanticException(ExceptionCode.EXTERNAL_STRUCTURE_MISSING_URI, this.getUrn());
			}
		}
		if(ObjectUtil.validString(getId())) {
			if(getId().equals("ALL")) {
				throw new SdmxSemmanticException("ALL is a reserved word and can not be used for an id");
			}
		}
		this.internalId = UUID.randomUUID().toString();
		super.validateMaintainableAttributes();
	}

	protected void validateAgencyId() {
		if(!ObjectUtil.validString(this.getAgencyId())) {
			throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_MAINTAINABLE_MISSING_AGENCY, this.getStructureName());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	public IURNMaintainable<?> getURN() {
		return (IURNMaintainable<?>)super.getURN();
	}
	
	@Override
	public String getAgencyId() {
		return getMaintainableProperties().getAgencyId();
	}
	

    @Override
    public IMaintainableProperties getMaintainableProperties() {
        return properties;
    }

    @Override
    public IDeferredBeanDefinition getDeferredDefinition() {
        DefferedBeanBuilder builder = DeferredBeanDefinition.builder(this);
        populateDeferredBeanBuilder(builder);
        return builder.build();
    }
    
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
        //Override to store class specific properties
    }

	@Override
	public boolean isFixedVersion() {
		return false;
	}

	@Override
	public <T extends IdentifiableBean> T getCompositeById(Class<T> type, String qualifiedId) {
		if(this.identifiablesById == null) {
			Map<String, IdentifiableBean> identifiablesById = new HashMap<>();
			for(IdentifiableBean ident : this.getIdentifiableComposites()) {
				identifiablesById.put(ident.getFullIdPath(false), ident);
			}
			this.identifiablesById = identifiablesById;
		}
		IdentifiableBean ident = this.identifiablesById.get(qualifiedId);
		if(ident != null) {
			if(type.isAssignableFrom(ident.getClass())) {
				return (T)ident;
			}
		}
		return null;
	}

	@Override
	public IMetadataStandard getDefaultStandard() {
		return SDMXMetadataStandard.getInstance();
	}

	@Override
	public String getInternalId() {
		if(internalId == null) {
			//Just in case - this should never return null
			this.internalId = UUID.randomUUID().toString();
		}
		return internalId;
	}

	@Override
	public boolean isFinal() {
		return isFinal;
	}

	@Override
	public boolean isStub() {
		return isStub;
	}

	@Override
	public boolean isExternalReference() {
		return isExternalReference;
	}
	
	

	@Override
	public MaintainableBean addAnnotations(Map<IURNAbsolute<?>, Set<AnnotationMutableBean>> annotationsMap) {
		MaintainableMutableBean mutable = getMutableInstance();
		MaintainableBean copy = mutable.getImmutableInstance();
		for(IURNAbsolute<?> ref : annotationsMap.keySet()) {
			Set<AnnotationMutableBean> annotations = annotationsMap.get(ref);
			for (AnnotationMutableBean annotationMutableBean : annotations) {
				if(annotationMutableBean.isDynamic()){
					((MaintainableBeanImpl)copy).hasDynamicAnnotations = true;
					break;
				}
			}
			if(copy.getURN().equals(ref)) {
				((AnnotableBeanImpl) copy).addAnnotations(mutable, annotations);
			} else {
				for(IdentifiableBean identifiable : copy.getIdentifiableComposites()) {
					if(identifiable.getURN().equals(ref)) {
						((AnnotableBeanImpl)identifiable).addAnnotations(mutable, annotations);
						break;
					}
				}
			}
		}
		return copy;
	}

	@Override
	public MaintainableBean copyDynamicAnnotations(MaintainableBean maint) {
		if(!maint.hasDynamicAnnotations()){
			return this;
		}
		Map<IURNAbsolute<?>, Set<AnnotationMutableBean>> dynamicAnnotatiotns = new HashMap<>();

		IURNAbsolute<?> sRef = null;
		Set<AnnotationMutableBean> annSet = null;
		for(AnnotationBean annotation : maint.getAnnotations()) {
			if(annotation.isDynamic()) {
				if(sRef == null) {
					sRef = this.getURN();
					annSet = new HashSet<>();
					dynamicAnnotatiotns.put(sRef, annSet);
				}
				AnnotationMutableBean mutable = new AnnotationMutableBeanImpl(annotation, null);
				annSet.add(mutable);
			}
		}
		for(IdentifiableBean composite : maint.getIdentifiableComposites()) {
			sRef = null;
			annSet = null;
			for(AnnotationBean annotation : composite.getAnnotations()) {
				if(annotation.isDynamic()) {
					if(sRef == null) {
						sRef = composite.getURN();
						annSet = new HashSet<>();
						dynamicAnnotatiotns.put(sRef, annSet);
					}
					AnnotationMutableBean mutable = new AnnotationMutableBeanImpl(annotation, null);
					annSet.add(mutable);
				}
			}
		}
		if(dynamicAnnotatiotns.size() > 0) {
			return addAnnotations(dynamicAnnotatiotns);
		}
		return this;
	}


	private void setServiceURL(String serviceURLStr) {
		if(serviceURLStr == null) {
			this.serviceURL =  null;
			return;
		}
		try {
			this.serviceURL = new URL(serviceURLStr);
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Could not create attribute 'serviceURL' with value '"+serviceURLStr+"'");
		}
	}

	private void setStructureURL(String structureURLStr) {
		if(structureURLStr == null) {
			this.structureURL =  null;
			return;
		}
		try {
			this.structureURL = new URL(structureURLStr);
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Could not create attribute 'structureURL' with value '"+structureURLStr+"'");
		}
	}

	@Override
	public URL getServiceURL() {
		return serviceURL;
	}

	@Override
	public URL getStructureURL() {
		return structureURL;
	}


	@Override
	public SortedSet<String> getLocales() {
		if(locales != null) {
			return locales;
		}
		locales = new TreeSet<>();
		for(TextTypeWrapper tt : getComposites(TextTypeWrapper.class)) {
			locales.add(tt.getLocale());
		}
		locales = Collections.unmodifiableSortedSet(locales);
		return locales;
	}

	@Override
	public boolean hasDynamicAnnotations() {
		return this.hasDynamicAnnotations;
	}

	@Override
	public int compareTo(MaintainableBean versionableBean) {
		return this.version.isLater(versionableBean.getVersion()) ? +1 : -1;
	}

}
