package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorSchemeMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * Container for {@link UserDefinedOperatorBean}
 */
public class UserDefinedOperatorSchemeBean extends VtlSchemeBean<IUserDefinedOperatorBean> implements IUserDefinedOperatorSchemeBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<IVtlMappingSchemeBean> vtlMappingSchemeRef;
	private List<IDirectCrossReferenceBean<IRulesetSchemeBean>> rulesetSchemeRef = Collections.emptyList();
	
	UserDefinedOperatorSchemeBean(IUserDefinedOperatorSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.emptyList();
	}

	public UserDefinedOperatorSchemeBean(IUserDefinedOperatorSchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(IUserDefinedOperatorMutableBean item : bean.getItems()) {
				this.items.add(new UserDefinedOperatorBean(item, this, this.items.size()));
			}
		}
		if(bean.getVtlMappingSchemeRef() != null) {
			this.vtlMappingSchemeRef = DirectCrossReferenceBean.build(this, "vtlmappingscheme", bean.getVtlMappingSchemeRef(), IVtlMappingSchemeBean.class);
		}
		if(bean.getRulesetSchemeRef() != null) {
			rulesetSchemeRef = new ArrayList<>();
			for(StructureReferenceBean rulesetRef : bean.getRulesetSchemeRef()) {
				this.rulesetSchemeRef.add(DirectCrossReferenceBean.build(this, "ruleset", rulesetRef, IRulesetSchemeBean.class));
			}
			this.rulesetSchemeRef = Collections.unmodifiableList(this.rulesetSchemeRef);
		}
		
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 ///////////////////Bean///////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IUserDefinedOperatorSchemeBean that = (IUserDefinedOperatorSchemeBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(this.vtlMappingSchemeRef, that.getVtlMappingSchemeRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.rulesetSchemeRef, that.getRulesetSchemeRef(), diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME.getType(), diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IUserDefinedOperatorSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<IUserDefinedOperatorSchemeBean> getURN() {
		return (IURNMaintainable<IUserDefinedOperatorSchemeBean>) super.getURN();
	}
	
	@Override
	public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<IRulesetSchemeBean>> getRulesetSchemeRef() {
		return rulesetSchemeRef;
	}

	@Override
	public IUserDefinedOperatorSchemeMutableBean getMutableInstance() {
		return new UserDefinedOperatorSchemeMutableBean(this);
	}

	@Override
	public IUserDefinedOperatorSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new UserDefinedOperatorSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(this.getVtlMappingSchemeRef() != null) {
			references.add(this.getVtlMappingSchemeRef());
		}
		references.addAll(this.getRulesetSchemeRef());
	}

    @Override
    public UserDefinedOperatorSchemeBeanDeferred toDeferred() {
        return new UserDefinedOperatorSchemeBeanDeferred(this);
    }
    
    @Override
    public UserDefinedOperatorSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new UserDefinedOperatorSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
