package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.registry.MetadataConstraintMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class MetadataConstraintBean extends MaintainableBeanImpl implements IMetadataConstraintBean {
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(MetadataConstraintBean.class);

	private List<IDirectCrossReferenceBean<?>> attachments;
	private List<KeyValues> includedTarget;
	private List<KeyValues> excludedTarget;
	private ReleaseCalendarBean releaseCalendar;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// BUILD STUB FROM ITSELF			 	 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	MetadataConstraintBean(IMetadataConstraintBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub Metadata Constraint Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// BUILD FROM MUTABLE BEAN			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataConstraintBean(IMetadataConstraintMutableBean mutable) {
		super(mutable);
		LOG.debug("Building MetadataConstraintBean from MutableBean");

		if (mutable.getAttachments() != null) {
			attachments = new ArrayList<>();
			for (StructureReferenceBean reference : mutable.getAttachments()) {
				attachments.add(DirectCrossReferenceBean.build(this, "attachment", reference, IdentifiableBean.class));
			}
		}
		if (mutable.getIncludedTarget() != null) {
			includedTarget = new ArrayList<>();
			for (KeyValuesMutable keyValues : mutable.getIncludedTarget()) {
				includedTarget.add(new KeyValuesImpl(keyValues, this));
			}
		}
		if (mutable.getExcludedTarget() != null) {
			excludedTarget = new ArrayList<>();
			for (KeyValuesMutable keyValues : mutable.getExcludedTarget()) {
				excludedTarget.add(new KeyValuesImpl(keyValues, this));
			}
		}
		if (mutable.getReleaseCalendar() != null) {
			releaseCalendar = new ReleaseCalendarBeanImpl(mutable.getReleaseCalendar(), this);
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("MetadataConstraintBean Built " + getUrn());
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// VALIDATE							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		super.validateMaintainableAttributes();

		if (ObjectUtil.validCollection(attachments)) {
			attachments = Collections.unmodifiableList(attachments);
			SDMX_STRUCTURE_TYPE firstStructureType = attachments.get(0).getMaintainableStructureType();
			SDMX_STRUCTURE_TYPE structureType;

			if (firstStructureType == SDMX_STRUCTURE_TYPE.METADATA_PROVIDER && attachments.size() > 1) {
				throw new SdmxSemmanticException("Metadata Constraint cannot be attached to more than 1 Metadata Provider");
			}
			for (ICrossReferenceBean<?> attachment : attachments) {
				structureType = attachment.getMaintainableStructureType();
				if (structureType != SDMX_STRUCTURE_TYPE.METADATA_PROVIDER &&
						structureType != SDMX_STRUCTURE_TYPE.MSD &&
						structureType != SDMX_STRUCTURE_TYPE.METADATA_FLOW &&
						// structureType != SDMX_STRUCTURE_TYPE.METADATA_SET &&
						structureType != SDMX_STRUCTURE_TYPE.METADATA_PROVISION) {
					throw new SdmxSemmanticException(
							"Metadata Constraint can only be attached to the following structures: Metadata Provider, Metadata Structure, Metadata Flow, Metadata Provision Agreement");
				}
				if (structureType != firstStructureType) {
					throw new SdmxSemmanticException("Metadata Constraint can only be attached to structures of the same type");
				}
			}
		}

		if (includedTarget == null && excludedTarget == null) {
			throw new SdmxSemmanticException("Metadata Constraint must contain at least 1 Target Region");
		}
		if (includedTarget == null) {
			includedTarget = Collections.emptyList();
		} else {
			includedTarget = Collections.unmodifiableList(includedTarget);
		}
		if (excludedTarget == null) {
			excludedTarget = Collections.emptyList();
		} else {
			excludedTarget = Collections.unmodifiableList(excludedTarget);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// DEEP EQUALS						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if (bean == null) {
			return false;
		}

		if (bean.getStructureType() == getStructureType()) {
			MetadataConstraintBean that = (MetadataConstraintBean) bean;
			boolean returnVal = super.equivalent(attachments, that.getAttachments(), diff);

			for (int i = 0; i < includedTarget.size(); i++) {
				if (!super.equivalent(includedTarget.get(i), that.getIncludedTarget().get(i), includeFinalProperties, diff)) {
					returnVal = false;
				}
			}
			for (int i = 0; i < excludedTarget.size(); i++) {
				if (!super.equivalent(excludedTarget.get(i), that.getExcludedTarget().get(i), includeFinalProperties, diff)) {
					returnVal = false;
				}
			}
			if (!super.equivalent(releaseCalendar, that.getReleaseCalendar(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// COMPOSITES REFERENCES	       		 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(includedTarget, composites);
		super.addToCompositeSet(excludedTarget, composites);
		super.addToCompositeSet(releaseCalendar, composites);
		return composites;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.addAll(attachments);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	//////////// GET								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return IMetadataConstraintBean.class;
	}
	
	@Override
	public List<IDirectCrossReferenceBean<?>> getAttachments() {
		return attachments;
	}

	@Override
	public List<KeyValues> getIncludedTarget() {
		return includedTarget;
	}

	@Override
	public List<KeyValues> getExcludedTarget() {
		return excludedTarget;
	}

	@Override
	public ReleaseCalendarBean getReleaseCalendar() {
		return releaseCalendar;
	}

	@Override
	public IMetadataConstraintBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new MetadataConstraintBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IMetadataConstraintMutableBean getMutableInstance() {
		return new MetadataConstraintMutableBean(this);
	}

    @Override
    public MetadataConstraintBeanDeferred toDeferred() {
        return new MetadataConstraintBeanDeferred(this);
    }
    
    @Override
    public MetadataConstraintBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataConstraintBeanDeferred(getDeferredDefinition(), loader);
    }
}
