package io.sdmx.im.beans.builder;

import io.sdmx.api.sdmx.builder.IImmutableBeanBuilder;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Builds a Deferred maintainable bean (a maintainable bean where the contents are stored off heap)
 */
public class DeferredImmutableBeanBuilder implements IImmutableBeanBuilder {
    public static final DeferredImmutableBeanBuilder INSTANCE = new DeferredImmutableBeanBuilder();
    
    
    private DeferredImmutableBeanBuilder() {}

    @Override
    public MaintainableBean build(MaintainableMutableBean mutable) {
        MaintainableBean maint = mutable.getImmutableInstance();
        if(maint.getDeferredDefinition() != null) {
            return maint.toDeferred();
        }
        return maint;
    }

}
