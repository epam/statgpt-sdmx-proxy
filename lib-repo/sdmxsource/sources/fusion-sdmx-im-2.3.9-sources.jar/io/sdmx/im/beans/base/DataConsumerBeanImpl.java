package io.sdmx.im.beans.base;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;

public class DataConsumerBeanImpl extends OrganisationBeanImpl implements DataConsumerBean {
	private static final long serialVersionUID = 23L;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataConsumerBeanImpl(DataConsumerMutableBean bean, DataConsumerSchemeBean parent) {
		super(bean, parent);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((DataConsumerBean)bean, includeFinalProperties, diff);
		}
		return false;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DataConsumerBean.class;
	}
	
	@Override
	public DataConsumerSchemeBean getMaintainableParent() {
		return (DataConsumerSchemeBean)super.getMaintainableParent();
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<DataConsumerBean> getURN() {
		return (IURNAbsolute<DataConsumerBean>) super.getURN();
	}
}
