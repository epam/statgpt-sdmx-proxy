package io.sdmx.im.beans.base;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class LinkBean implements ILinkBean, Serializable {
	private static final long serialVersionUID = 1L;
	private String rel;
	private URI href;
	private URI uri;
	private IURN urn;
	private String type;
	private List<TextTypeWrapper> titles;

	public LinkBean(MaintainableBean bean) {
		rel = bean.getStructureType().getUrnClass().toLowerCase();
		if(bean.getStructureURL() != null) {
			try {
				this.href =  bean.getStructureURL().toURI();
				if(bean.getStructureURL() != null) {
					
				} else if(bean.getUri() != null) {
					this.uri = new URI(bean.getUri().toString());
				}
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
		}
		this.urn = URN.getInstance(bean.getUrn());
		this.titles = Collections.emptyList();
	}

	public LinkBean(String rel, URI href, URI uri, IURN<?> urn, String type, Map<String, String> locale2Title) {
		this.rel = rel;
		this.href = href;
		this.urn = urn;
		this.uri = uri;
		this.type = type;
		if(ObjectUtil.validMap(locale2Title)) {
			this.titles = new ArrayList<>(locale2Title.size());
			for(String locale : locale2Title.keySet()) {
				titles.add(new TextTypeWrapperImpl(locale, locale2Title.get(locale)));
			}
			this.titles = Collections.unmodifiableList(titles);
		} else {
			titles = Collections.emptyList();
		}
		validate();
	}
	
	public static LinkBuilder builder() {
	    return new LinkBuilder();
	}
	
	public static class LinkBuilder {
	    private String rel;
	    private String href;
	    private String uri;
	    private String urn;
	    private String type;
	    private Map<String, String> locale2Title = Collections.emptyMap();
	    
	    private LinkBuilder() {}
	    
	    public LinkBuilder rel(String rel) { this.rel = rel; return this; }
        public LinkBuilder href(String href) { this.href = href; return this; }
        public LinkBuilder uri(String uri) { this.uri = uri; return this; }
        public LinkBuilder urn(String urn) { this.urn = urn; return this; }
        public LinkBuilder type(String type) { this.type = type; return this; }
        public LinkBuilder title(String locale, String title) {
            if(locale2Title.isEmpty()) {
                locale2Title = new HashMap<>();
            }
            locale2Title.put(locale, title);
            return this;
        }
        
        public LinkBean build() {
            try {
                URI href = this.href == null ? null : new URI(this.href);
                URI uri = this.uri == null ? null : new URI(this.uri);
                IURN urn = this.urn == null ? null : URN.builder(this.urn).build();
                return new LinkBean(rel, href, uri, urn, type, locale2Title);
            } catch (URISyntaxException e) {
                throw new SdmxSyntaxException(e);
            }
        }
	}
	
	/**
	 * @param ident with the URN to contain
	 * @return link containing only a URN
	 */
	public static LinkBean urnLink(IdentifiableBean ident) {
		return urnLink(ident.getUrn());
	}
	
	/**
	 * @param urn to contain
	 * @return link containing only a URN
	 */
	public static LinkBean urnLink(String urn) {
		return urnLink(URN.getInstance(urn));
	}
	
	/**
	 * @param urn urn to contain
	 * @return link containing only a URN
	 */
	public static LinkBean urnLink(IURN urn) {
		return new LinkBean(null, null, null, urn, null, null);
	}

	private void validate() {
//		if(this.rel == null) {
//			throw new SdmxSemmanticException("Invalid link object - rel can not be null");
//		}
//		if(this.href == null) {
//			throw new SdmxSemmanticException("Invalid link object - url can not be null");
//		}
	}

	@Override
	public String getRel() {
		return rel;
	}

	@Override
	public URI getUri() {
		return uri;
	}
	
	@Override
	public URI getHRef() {
		return this.href;
	}

	@Override
	public IURN getUrn() {
		return urn;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public List<TextTypeWrapper> getTitles(boolean disableLocaleFilter) {
		if (disableLocaleFilter) {
			return titles;
		}
		List<TextTypeWrapper> copy =  new ArrayList<>(titles);
		return TextTypeUtil.optionalFilterOnTextType(copy);
	}

	@Override
	public String getTitle() {
		TextTypeWrapper ttw = TextTypeUtil.getDefaultLocale(titles);
		return (ttw == null)?null:ttw.getValue();
	}

	@Override
	public String getTitle(String locale) {
		for(TextTypeWrapper name : this.titles) {
			if(name.getLocale().equals(locale)) {
				return name.getValue();
			}
		}
		return null;
	}


	@Override
	public int hashCode() {
		StringBuilder hc = new StringBuilder();
		hc.append(rel);
		hc.append(uri);
		if(urn != null) {
			hc.append(urn.getURN());
		}
		if(type != null) {
			hc.append(type);
		}
		if(titles != null) {
			for(TextTypeWrapper tt : this.titles) {
				hc.append(tt.getLocale()+":"+tt.getValue());
			}
		}
		return hc.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof ILinkBean) {
			ILinkBean that = (ILinkBean) obj;
			if(!ObjectUtil.equivalent(this.getRel(), that.getRel())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.getType(), that.getType())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.getHRef(), that.getHRef())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.getUri(), that.getUri())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.getUrn(), that.getUrn())) {
				return false;
			}
			if(!ObjectUtil.equivalentCollection(this.getTitles(false), that.getTitles(false))) {
				return false;
			}
			return true;
		}
		return super.equals(obj);
	}

	@Override
	public String toString() {
		return rel +"="+ getHRef();
	}


}
