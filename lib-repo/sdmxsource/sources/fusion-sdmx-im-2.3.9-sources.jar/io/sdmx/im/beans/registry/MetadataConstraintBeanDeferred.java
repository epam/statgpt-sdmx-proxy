package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class MetadataConstraintBeanDeferred extends MaintainableBeanDeferred<IMetadataConstraintBean> implements IMetadataConstraintBean {
    private static final long serialVersionUID = 1L;

    public MetadataConstraintBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public MetadataConstraintBeanDeferred(IMetadataConstraintBean maint) {
        super(maint);
    }
    
    @Override
    public IMetadataConstraintBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataConstraintBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected MetadataConstraintBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataConstraintBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IMetadataConstraintBean> getURN() {
        return (IURNMaintainable<IMetadataConstraintBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IMetadataConstraintBean.class;
    }

    @Override
    public IMetadataConstraintMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<IDirectCrossReferenceBean<?>> getAttachments() {
        return load().getAttachments();
    }

    @Override
    public List<KeyValues> getIncludedTarget() {
        return load().getIncludedTarget();
    }

    @Override
    public List<KeyValues> getExcludedTarget() {
        return load().getExcludedTarget();
    }

    @Override
    public ReleaseCalendarBean getReleaseCalendar() {
        return load().getReleaseCalendar();
    }

}
