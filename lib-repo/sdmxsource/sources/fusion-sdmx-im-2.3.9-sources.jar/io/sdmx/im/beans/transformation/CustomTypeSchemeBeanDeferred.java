package io.sdmx.im.beans.transformation;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class CustomTypeSchemeBeanDeferred extends ItemSchemeBeanDeffered<ICustomTypeBean, ICustomTypeSchemeBean> implements ICustomTypeSchemeBean {
    private static final long serialVersionUID = 1L;

    public CustomTypeSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public CustomTypeSchemeBeanDeferred(ICustomTypeSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public ICustomTypeSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CustomTypeSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected CustomTypeSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new CustomTypeSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ICustomTypeSchemeBean> getURN() {
        return (IURNMaintainable<ICustomTypeSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ICustomTypeSchemeBean.class;
    }
    
    @Override
    public ICustomTypeSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public String getVtlVersion() {
        return load().getVtlVersion();
    }
}
