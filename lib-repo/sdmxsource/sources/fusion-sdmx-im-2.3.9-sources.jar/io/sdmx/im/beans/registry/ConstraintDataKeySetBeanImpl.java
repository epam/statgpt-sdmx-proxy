package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConstraintDataKeySetBeanImpl extends SdmxStructureBeanImpl implements ConstraintDataKeySetBean {
	private static final long serialVersionUID = 21L;
	private List<ConstrainedDataKeyBean> constrainedKeys = new ArrayList<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConstraintDataKeySetBeanImpl(ConstraintDataKeySetMutableBean mutable, boolean isIncluded, ConstraintBean parent) {
		super(SDMX_STRUCTURE_TYPE.CONSTRAINED_DATA_KEY_SET, parent);
		for (ConstrainedDataKeyMutableBean each : mutable.getConstrainedDataKeys()) {
			ConstrainedDataKeyBean cdk = new ConstrainedDataKeyBeanImpl(each, isIncluded, this);
			if(ObjectUtil.validCollection(cdk.getKeyValues())) {
				constrainedKeys.add(cdk);
			}
		}
		this.constrainedKeys = Collections.unmodifiableList(constrainedKeys);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() != this.getStructureType()) {
            return false;
        }

        // Compare the Data Keys
        ConstraintDataKeySetBean that = (ConstraintDataKeySetBean) bean;

        Set<String> thisConstrainedKeys = generateSetOfStrings(constrainedKeys);
        Set<String> thatConstrainedKeys = generateSetOfStrings(that.getConstrainedDataKeys());

        boolean isEqual = true;
        for (String string : thisConstrainedKeys) {
            if (thatConstrainedKeys.contains(string)) {
                thatConstrainedKeys.remove(string);
            } else {
                // Exists in "this" DataKeySet only
                if (diff == null) {
                    return false;
                } else {
                    diff.addDiff(this, "Data Key", string, null);
                    isEqual = false;
                }
            }
        }

        for (String string : thatConstrainedKeys) {
            // Exists in "that" DataKeySet only
            if (diff == null) {
                return false;
            } else {
                diff.addDiff(this, "Data Key", null, string);
                isEqual = false;
            }
        }

        return isEqual;
    }

	private Set<String> generateSetOfStrings(List<ConstrainedDataKeyBean> listDataKeys) {
	    Set<String> retList = new TreeSet<>();
	    if (listDataKeys == null) {
            return retList;
        }

	    for(ConstrainedDataKeyBean dataKey : listDataKeys) {
	        StringBuilder sb = new StringBuilder();
            String concat = "";
	        List<IConstrainedKeyValue> keyValues = dataKey.getKeyValues();
	        for (IConstrainedKeyValue kv : keyValues) {
	            sb.append(concat);
	            sb.append(kv.getConcept());
	            sb.append(":");
	            sb.append(kv.getCode());
	            sb.append(":");
	            sb.append(kv.isRemovePrefix());
                concat = ",";
            }

	        retList.add( sb.toString() );
	    }

        return retList;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<ConstrainedDataKeyBean> getConstrainedDataKeys() {
		return constrainedKeys;
	}

	@Override
	public String getKey() {
		return null;
	}

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(constrainedKeys, composites);
        return composites;
    }
}
