package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;

public class OrganisationMapBean extends ItemMapBean implements IOrganisationMapBean {
	private static final long serialVersionUID = 1L;

    public OrganisationMapBean(IItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
	}
}
