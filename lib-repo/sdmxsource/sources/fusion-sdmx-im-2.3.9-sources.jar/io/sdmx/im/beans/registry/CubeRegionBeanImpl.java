package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class CubeRegionBeanImpl extends SdmxStructureBeanImpl implements CubeRegionBean {
	private static final long serialVersionUID = -28040193675261130L;
	private List<KeyValues> keyValues = new ArrayList<>();
	private List<KeyValues> attributeValues = new ArrayList<>();
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM IMMUTABLE BEAN				 //////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CubeRegionBeanImpl(CubeRegionMutableBean mutable, ContentConstraintBean parent) {
		super(SDMX_STRUCTURE_TYPE.CUBE_REGION, parent);
		this.keyValues = new ArrayList<>();
		if (ObjectUtil.validCollection(mutable.getKeyValues())) {
			for(KeyValuesMutable kvMut : mutable.getKeyValues()) {
				if(ObjectUtil.validCollection(kvMut.getKeyValues()) || ObjectUtil.validCollection(kvMut.getCascade())) {
					this.keyValues.add(new KeyValuesImpl(kvMut, this));
				}
			}
		}
		this.attributeValues = new ArrayList<>();
		if (ObjectUtil.validCollection(mutable.getAttributeValues())) {
			for(KeyValuesMutable kvMut : mutable.getAttributeValues()) {
				if(ObjectUtil.validCollection(kvMut.getKeyValues()) || ObjectUtil.validCollection(kvMut.getCascade())) {
					this.attributeValues.add(new KeyValuesImpl(kvMut, this));
				}
			}
		}
		this.keyValues = Collections.unmodifiableList(this.keyValues);
		this.attributeValues = Collections.unmodifiableList(this.attributeValues);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			CubeRegionBean that = (CubeRegionBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(keyValues, that.getKeyValues(), includeFinalProperties,"Key Value",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(attributeValues, that.getAttributeValues(), includeFinalProperties, "Attribute Value",  diff)) {
				returnVal = false;
			}
	 		return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<KeyValues> getKeyValues() {
		return keyValues;
	}

	@Override
	public List<KeyValues> getAttributeValues() {
		return attributeValues;
	}
	
	@Override
	public String getKey() {
		return null;
	}

	@Override
	public Set<String> getCascadeValues(String componentId) {
		KeyValues kvs = getKeyValues(componentId);
		if(kvs == null) {
			return Collections.emptySet();
		}
		return kvs.getCascadeValues();
	}

	@Override
	public KeyValues getKeyValues(String componentId) {
		for(KeyValues kvs : keyValues) {
			if(kvs.getId().equals(componentId)) {
				return kvs;
			}
		}
		for(KeyValues kvs : attributeValues) {
			if(kvs.getId().equals(componentId)) {
				return kvs;
			}
		}
		return null;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(keyValues, composites);
        super.addToCompositeSet(attributeValues, composites);
        return composites;
    }
    
    @Override
    public String toString() {
    	String retValue = "";
    	if(!keyValues.isEmpty()) {
    		retValue += "key Values = " + keyValues.toString();
    	}
    	
    	if(!attributeValues.isEmpty()) {
    		retValue += " Attribute Values" + attributeValues.toString();
    	}
    	
    	return retValue;
    }
}
