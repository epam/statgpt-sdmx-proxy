package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.Collections;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.im.mutable.transformation.RulesetSchemeMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * A container of {@link RulesetBean}
 */
public class RulesetSchemeBean extends VtlSchemeBean<IRulesetBean> implements IRulesetSchemeBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<IVtlMappingSchemeBean> vtlMappingSchemeRef;

	RulesetSchemeBean(IRulesetSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.emptyList();
	}

	public RulesetSchemeBean(IRulesetSchemeMutableBean bean) {
		super(bean);
		if(bean.getVtlMappingSchemeRef() != null) {
			this.vtlMappingSchemeRef = DirectCrossReferenceBean.build(this, "vtlmappingscheme", bean.getVtlMappingSchemeRef(), IVtlMappingSchemeBean.class);
		}
		if(bean.getItems() != null) {
			for(IRulesetMutableBean item : bean.getItems()) {
				this.items.add(new RulesetBean(item, this, this.items.size()));
			}
		}
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		boolean returnVal = true;
		RulesetSchemeBean that = (RulesetSchemeBean) bean;
		if(!super.equivalent(this.vtlMappingSchemeRef, that.getVtlMappingSchemeRef(), diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal((IRulesetSchemeBean) bean, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME.getType(),  diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IRulesetSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<IRulesetSchemeBean> getURN() {
		return (IURNMaintainable<IRulesetSchemeBean>) super.getURN();
	}
	
	@Override
	public IRulesetSchemeMutableBean getMutableInstance() {
		return new RulesetSchemeMutableBean(this);
	}

	@Override
	public IRulesetSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new RulesetSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}
	
	@Override
	public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(vtlMappingSchemeRef != null) {
			references.add(vtlMappingSchemeRef);
		}
	}

    @Override
    public RulesetSchemeBeanDeferred toDeferred() {
        return new RulesetSchemeBeanDeferred(this);
    }
    
    @Override
    public RulesetSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new RulesetSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
