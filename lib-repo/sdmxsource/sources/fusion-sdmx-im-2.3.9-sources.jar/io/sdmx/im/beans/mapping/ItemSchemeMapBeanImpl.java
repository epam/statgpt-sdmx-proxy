package io.sdmx.im.beans.mapping;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;

@Deprecated
/**
 * @deprecated use mapping.v3
 */
public abstract class ItemSchemeMapBeanImpl<T extends ItemMapBean> extends SchemeMapBeanImpl implements ItemSchemeMapBean<T> {
	private static final long serialVersionUID = 12L;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ItemSchemeMapBeanImpl(ItemSchemeMapMutableBean bean, SDMX_STRUCTURE_TYPE structureType, IdentifiableBean parent) {
		super(bean, parent);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(NameableBean bean, boolean includeFinalProperties, String itemName, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ItemSchemeMapBean that = (ItemSchemeMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(getItems(), that.getItems(), includeFinalProperties, itemName, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(getItems(), composites);
		return composites;
	}
	
	protected abstract SDMX_STRUCTURE_TYPE getItemType();
}
