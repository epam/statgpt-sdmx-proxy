package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexAnnotationReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexNameableReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexTextReference;

public class ComplexNameableReferenceImpl implements ComplexNameableReference {

	private SDMX_STRUCTURE_TYPE structureType;
	private ComplexAnnotationReference annotationRef;
	private ComplexTextReference nameRef;
	private ComplexTextReference descriptionRef;

	public ComplexNameableReferenceImpl(SDMX_STRUCTURE_TYPE structureType,
			ComplexAnnotationReference annotationRef,
			ComplexTextReference nameRef,
			ComplexTextReference descriptionRef) {
		
		if ( structureType == null ) {
			throw new SdmxSemmanticException("Null structure type provided for reference in query.");
		}
		
		this.structureType = structureType;	
		if (annotationRef != null) {
			this.annotationRef = annotationRef;
		}
		if (nameRef != null) {
			this.nameRef = nameRef;	
		}
		if (descriptionRef != null) {
			this.descriptionRef = descriptionRef;
		}
	}
	
	@Override
	public SDMX_STRUCTURE_TYPE getReferencedStructureType() {
		return structureType;
	}

	@Override
	public ComplexAnnotationReference getAnnotationReference() {
		return annotationRef;
	}

	@Override
	public ComplexTextReference getNameReference() {
		return nameRef;
	}

	@Override
	public ComplexTextReference getDescriptionReference() {
		return descriptionRef;
	}

}
