package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class MetadataflowBeanDeferred extends MaintainableBeanDeferred<MetadataFlowBean> implements MetadataFlowBean {
    private static final long serialVersionUID = 1L;

    public MetadataflowBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public MetadataflowBeanDeferred(MetadataFlowBean maint) {
        super(maint);
    }
    
    @Override
    public MetadataFlowBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataflowBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected MetadataflowBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataflowBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<MetadataFlowBean> getURN() {
        return (IURNMaintainable<MetadataFlowBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return MetadataFlowBean.class;
    }

    @Override
    public MetadataFlowMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public List<ICrossReferenceBeanBase> getTargets() {
        return load().getTargets();
    }

    @Override
    public ICrossReferenceBean<MetadataStructureDefinitionBean> getMetadataStructureRef() {
        return load().getMetadataStructureRef();
    }
}
