package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class TransformationSchemeBeanDeferred extends ItemSchemeBeanDeffered<ITransformationBean, ITransformationSchemeBean> implements ITransformationSchemeBean {
    private static final long serialVersionUID = 1L;

    public TransformationSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public TransformationSchemeBeanDeferred(ITransformationSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public ITransformationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new TransformationSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected TransformationSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new TransformationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ITransformationSchemeBean> getURN() {
        return (IURNMaintainable<ITransformationSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ITransformationSchemeBean.class;
    }
    
    @Override
    public ITransformationSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public String getVtlVersion() {
        return load().getVtlVersion();
    }

    @Override
    public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
        return load().getVtlMappingSchemeRef();
    }

    @Override
    public ICrossReferenceBean<INamePersonalisationSchemeBean> getNamePersonalisationSchemeRef() {
        return load().getNamePersonalisationSchemeRef();
    }

    @Override
    public ICrossReferenceBean<ICustomTypeSchemeBean> getCustomTypeSchemeRef() {
        return load().getCustomTypeSchemeRef();
    }

    @Override
    public List<IDirectCrossReferenceBean<IRulesetSchemeBean>> getRulesetSchemeRef() {
        return load().getRulesetSchemeRef();
    }

    @Override
    public List<IDirectCrossReferenceBean<IUserDefinedOperatorSchemeBean>> getUserDefinedOperatorSchemeRef() {
        return load().getUserDefinedOperatorSchemeRef();
    }
}
