package io.sdmx.im.beans.reference.complex;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.COMPLEX_MAINTAINABLE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.COMPLEX_STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexStructureQueryMetadata;

public class ComplexStructureQueryMetadataImpl implements ComplexStructureQueryMetadata {

	private STRUCTURE_REFERENCE_DETAIL referenceDetail;
	private COMPLEX_STRUCTURE_QUERY_DETAIL queryDetail = COMPLEX_STRUCTURE_QUERY_DETAIL.FULL;
	private boolean returnMatchedartefact;
	private List<SDMX_STRUCTURE_TYPE> referenceSpecificStructures;
	private COMPLEX_MAINTAINABLE_QUERY_DETAIL referencesQueryDetail = COMPLEX_MAINTAINABLE_QUERY_DETAIL.FULL;

	public ComplexStructureQueryMetadataImpl(boolean returnMatchedartefact, COMPLEX_STRUCTURE_QUERY_DETAIL queryDetail, COMPLEX_MAINTAINABLE_QUERY_DETAIL referencesQueryDetail,
			STRUCTURE_REFERENCE_DETAIL referenceDetail, List<SDMX_STRUCTURE_TYPE> referenceSpecificStructures) {
		
		this.returnMatchedartefact = returnMatchedartefact;
		if (queryDetail != null) {
			this.queryDetail = queryDetail;
		}

		if (referencesQueryDetail != null)
		this.referencesQueryDetail = referencesQueryDetail;
		
		if (referenceDetail == null) {
			throw new SdmxSemmanticException("Reference Detail cannot be null.");
		}
		
		this.referenceDetail = referenceDetail;
		this.referenceSpecificStructures = referenceSpecificStructures;
		
	}
	
	@Override
	public boolean isReturnedMatchedArtefact() {
		return returnMatchedartefact;
	}

	@Override
	public COMPLEX_STRUCTURE_QUERY_DETAIL getStructureQueryDetail() {
		return queryDetail;
	}

	@Override
	public STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail() {
		return referenceDetail;
	}

	@Override
	public COMPLEX_MAINTAINABLE_QUERY_DETAIL getReferencesQueryDetail() {
		return referencesQueryDetail;
	}

	@Override
	public List<SDMX_STRUCTURE_TYPE> getReferenceSpecificStructures() {
		return referenceSpecificStructures;
	}

}
