package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class UserDefinedOperatorSchemeBeanDeferred extends ItemSchemeBeanDeffered<IUserDefinedOperatorBean, IUserDefinedOperatorSchemeBean> implements IUserDefinedOperatorSchemeBean {
    private static final long serialVersionUID = 1L;

    public UserDefinedOperatorSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public UserDefinedOperatorSchemeBeanDeferred(IUserDefinedOperatorSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public IUserDefinedOperatorSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new UserDefinedOperatorSchemeBean(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected UserDefinedOperatorSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new UserDefinedOperatorSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IUserDefinedOperatorSchemeBean> getURN() {
        return (IURNMaintainable<IUserDefinedOperatorSchemeBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IUserDefinedOperatorSchemeBean.class;
    }
    
    @Override
    public IUserDefinedOperatorSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public String getVtlVersion() {
        return load().getVtlVersion();
    }

    @Override
    public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
        return load().getVtlMappingSchemeRef();
    }

    @Override
    public List<IDirectCrossReferenceBean<IRulesetSchemeBean>> getRulesetSchemeRef() {
        return load().getRulesetSchemeRef();
    }

}
