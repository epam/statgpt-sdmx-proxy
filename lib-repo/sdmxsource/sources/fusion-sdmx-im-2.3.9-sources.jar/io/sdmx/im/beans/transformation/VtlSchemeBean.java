package io.sdmx.im.beans.transformation;

import java.net.URL;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;

public abstract class VtlSchemeBean<T extends ItemBean> extends ItemSchemeBeanImpl<T> implements IVtlSchemeBean<T> {
	private static final long serialVersionUID = 1L;
	private String vtlVersion;

	public VtlSchemeBean(ItemSchemeBean<T> bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public VtlSchemeBean(IVtlSchemeMutableBean<? extends ItemMutableBean> bean) {
		super(bean);
		this.vtlVersion = bean.getVtlVersion();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.isExternalReference && this.items.size() == 0) {
			this.isStub = true;
		}
		if(this.isStub()) {
			return;
		}
		if(this.vtlVersion == null) {
			throw new SdmxSemmanticException("VTL Scheme missing VTL Version");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(IVtlSchemeBean<T> that, boolean includeFinalProperties, String itemName, DiffReport diff) {
		boolean returnVal = true;
		if(!super.equivalent(this.vtlVersion, that.getVtlVersion(), "VTL Version", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, itemName, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getVtlVersion() {
		return vtlVersion;
	}
}
