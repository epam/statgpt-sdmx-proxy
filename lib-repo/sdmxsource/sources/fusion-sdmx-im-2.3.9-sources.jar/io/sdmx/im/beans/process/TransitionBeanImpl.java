package io.sdmx.im.beans.process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;

public class TransitionBeanImpl extends IdentifiableBeanImpl implements TransitionBean {
	private static final long serialVersionUID = 13L;
	private String targetStep;
	private List<TextTypeWrapper> condition = new ArrayList<>();
	private String localId;
	private transient ProcessStepBean processStep;  //Referenced from targetStep
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public TransitionBeanImpl(TransitionMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		this.targetStep = bean.getTargetStep();
		if(bean.getConditions() != null) {
			for(TextTypeWrapperMutableBean ttMut : bean.getConditions()) {
				if(ObjectUtil.validString(ttMut.getValue())) {
					condition.add(new TextTypeWrapperImpl(ttMut, "Condition", this));
				}
			}
		}
		this.localId = bean.getLocalId();
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			TransitionBean that = (TransitionBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(condition, that.getCondition(), includeFinalProperties, "Condition",  diff)) {
				returnVal = false;
			}
			//Note this uses ObjectUtil which will invoke the equals method and check the URN.  If we used deep equals we 
			//could end up in a recursive loop
			if(!super.equivalent(this.getTargetStep(), that.getTargetStep(), "Target Step", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(localId, that.getLocalId(), "Local Id", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(targetStep)) {
			throw new SdmxSemmanticException("Transition is missing mandatory 'Target Step'");
		}
		if(!ObjectUtil.validCollection(condition)) {
			throw new SdmxSemmanticException("The Transition '" + this.getId() + "' must have a Condition specified.");
		}
		this.condition = Collections.unmodifiableList(condition);
	}
	
	/**
	 * Method to be called after construction of Process, as a Transition may be referencing a Process Step that has not yet been built due to nesting
	 */
	protected void verifyProcessSteps() {
		ProcessBean parentProcess = (ProcessBean)getMaintainableParent();
		setTargetStep(parentProcess.getProcessSteps(), targetStep.split("\\."), 0);
	}
	
	/**
	 * Walks through Processes and sub processes to set the ProcessStepBean referenced from the targetStep
	 * @param processSteps
	 */
	private void setTargetStep(List<ProcessStepBean> processSteps, String[] targetStepSplit, int currentPosition) {
		for(ProcessStepBean currentProcessStep : processSteps) {
			if(currentProcessStep.getId().equals(targetStepSplit[currentPosition])) {
				int nextPos = currentPosition + 1;
				if(targetStepSplit.length > nextPos) {
					setTargetStep(currentProcessStep.getProcessSteps(), targetStepSplit, nextPos);
					return;
				} else {
					this.processStep = currentProcessStep;
					return;
				}
			}
		}
		throw new SdmxSemmanticException("Can not resolve reference to ProcessStep with reference '"+ this.targetStep+"'");
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return TransitionBean.class;
	}
	
	@Override
	public ProcessStepBean getTargetStep() {
		if(targetStep != null && processStep == null) {
			verifyProcessSteps();
		}
		return processStep;
	}

	@Override
	public List<TextTypeWrapper> getCondition() {
		return TextTypeUtil.optionalFilterOnTextType(condition);
	}
	
	@Override
	public List<TextTypeWrapper> getAllTextTypes() {
		List<TextTypeWrapper> returnList = super.getAllTextTypes();
		returnList.addAll(condition);
		return returnList;
	}

	@Override
	public String getLocalId() {
		return localId;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(condition, composites);
        return composites;
    }
}
