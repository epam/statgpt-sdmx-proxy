package io.sdmx.im.beans.calculation;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.calculation.ValidationSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class ValidationSchemeBeanDeferred extends ItemSchemeBeanDeffered<ValidationRuleBean, ValidationSchemeBean> implements ValidationSchemeBean {
    private static final long serialVersionUID = 1L;

    public ValidationSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ValidationSchemeBeanDeferred(ValidationSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public ValidationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ValidationSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ValidationSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ValidationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ValidationSchemeBean> getURN() {
        return (IURNMaintainable<ValidationSchemeBean>) super.getURN();
    }

    @Override
    public ValidationSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ValidationSchemeBean.class;
    }

    @Override
    public ICrossReferenceBean<DataflowBean> getAttachment() {
        return load().getAttachment();
    }
}