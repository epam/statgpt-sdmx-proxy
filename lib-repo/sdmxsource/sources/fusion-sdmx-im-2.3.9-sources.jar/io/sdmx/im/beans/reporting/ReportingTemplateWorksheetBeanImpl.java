package io.sdmx.im.beans.reporting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateColourBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateConditionalAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ReportingTemplateWorksheetBeanImpl extends IdentifiableBeanImpl implements ReportingTemplateWorksheetBean {
	private static final long serialVersionUID = 36L;
	private IDirectCrossReferenceBean<DataflowBean> dataflow;

	private String sliceBy;
	private List<String> tableCols;
	private List<String> tableRows;
	private Map<String, String> fixedAttributes;
	private Set<String> variableAttributes;
	private Set<String> worksheetAttributes;
	private Set<String> separateAttributes;
	private Set<String> variableDimensions;
	private Set<String> excludeDimensions;

	private Map<String, TEXT_DISPLAY> textDisplay  = new HashMap<>();
	private Map<String, IDirectCrossReferenceBean<HierarchyBean>> hierarchyReferences = new HashMap<>();
	private Set<String> implicitHierarchices;

	private ReportingTemplateColourBean reportingTemplateColour;
	private List<ReportingTemplateConditionalAttributeBean> conditionalAttributes;
	private Integer roundDecimals;
	private Integer colMaxWidth;

	public ReportingTemplateWorksheetBeanImpl(ReportingTemplateWorksheetMutableBean bean, ReportingTemplateBean parent) {
		super(bean, parent);
		if(bean.getDataflow() != null) {
			this.dataflow = DirectCrossReferenceBean.build(this, "dataflow", bean.getDataflow(), DataflowBean.class);
		}
		if(bean.getTableCols() != null) {
			this.tableCols = new ArrayList<>(bean.getTableCols());
		}
		if(bean.getTableRows() != null) {
			this.tableRows = new ArrayList<>(bean.getTableRows());
		}
		if(bean.getFixedAttributeValues() != null) {
			this.fixedAttributes = new HashMap<>(bean.getFixedAttributeValues());
		}
		if(bean.getVariableAttributes() != null) {
			this.variableAttributes = new HashSet<>(bean.getVariableAttributes());
		}
		if(bean.getVariableDimensions() != null) {
			this.variableDimensions = new HashSet<>(bean.getVariableDimensions());
		}
		if(bean.getWorksheetAttributes() != null) {
			this.worksheetAttributes = new HashSet<>(bean.getWorksheetAttributes());
		}
		if(bean.getSeparateAttributes() != null) {
			this.separateAttributes = new HashSet<>(bean.getSeparateAttributes());
		}
		this.sliceBy = bean.getSliceBy();
		if(bean.getTextDisplay() != null) {
			for(String key : bean.getTextDisplay().keySet()) {
				TEXT_DISPLAY value = bean.getTextDisplay().get(key);
				if(value != null) {
					this.textDisplay.put(key, value);
				}
			}
		}
		if(bean.getHierarhcyReferences() != null) {
			for(String hRef : bean.getHierarhcyReferences().keySet()) {
				this.hierarchyReferences.put(hRef, DirectCrossReferenceBean.build(this, "hierarchy", bean.getHierarhcyReferences().get(hRef), HierarchyBean.class));
			}
		}
		if(bean.getImplicitHierarchices() != null) {
			this.implicitHierarchices = new HashSet<>(bean.getImplicitHierarchices());
		}
		if(bean.getColourAttribute() != null) {
			this.reportingTemplateColour = new ReportingTemplateColourBeanImpl(bean.getColourAttribute(), this);
		}
		this.conditionalAttributes = new ArrayList<>();
		if(bean.getConditionalAttributes() != null) {
			for(ReportingTemplateConditionalAttributeMutableBean mutable : bean.getConditionalAttributes()) {
				ReportingTemplateConditionalAttributeBean conAttr = new ReportingTemplateConditionalAttributeBeanImpl(mutable, this);
				this.conditionalAttributes.add(conAttr);
			}
		}
		if(bean.getExcludeDimensions() != null) {
			this.excludeDimensions = new HashSet<>(bean.getExcludeDimensions());
		}
		this.roundDecimals = bean.getRoundDecimals();
		this.colMaxWidth = bean.getColMaxWidth();
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(dataflow == null) {
			throw new SdmxSemmanticException("Reporting Template Worksheet is missing a Dataflow Reference");
		}
		if(this.colMaxWidth != null && this.colMaxWidth < 0) {
			this.colMaxWidth = null;
		}
		if(tableCols == null) {
			tableCols = new ArrayList<>();
		}
		if(tableRows == null) {
			tableRows = new ArrayList<>();
		}
		if(fixedAttributes == null) {
			fixedAttributes = new HashMap<>();
		}
		if(variableAttributes == null) {
			variableAttributes = new HashSet<>();
		}
		if(worksheetAttributes == null) {
			worksheetAttributes = new HashSet<>();
		}
		if(separateAttributes == null) {
			separateAttributes = new HashSet<>();
		}
		if(excludeDimensions == null) {
			excludeDimensions = new HashSet<>();
		}
		if(hierarchyReferences == null) {
			hierarchyReferences = new HashMap<>();
		}
		if(implicitHierarchices == null) {
			implicitHierarchices = new HashSet<>();
		}
		if(variableDimensions == null) {
			variableDimensions = new HashSet<>();
		}
		if(tableCols.size() == 0 && tableRows.size() == 0) {
			throw new SdmxSemmanticException("Reporting Template Worksheet does not contain any table column or row details");
		}

		for(String separateAttr : separateAttributes) {
			if(worksheetAttributes.contains(separateAttr)) {
				throw new SdmxSemmanticException("Attribute '"+separateAttr+"' is assigned to both appear in a separate table and in the same worksheet");
			}
			if(variableAttributes.contains(separateAttr)) {
				throw new SdmxSemmanticException("Attribute '"+separateAttr+"' is assigned to both appear in a separate table and in the same table as the observations");
			}
			if(fixedAttributes.containsKey(separateAttr)) {
				throw new SdmxSemmanticException("Attribute '"+separateAttr+"' is assigned to both appear in a separate table and have a fixed value");
			}
		}

		for(String worksheetAttr : worksheetAttributes) {
			if(variableAttributes.contains(worksheetAttr)) {
				throw new SdmxSemmanticException("Attribute '"+worksheetAttr+"' is assigned to both appear in in the same worksheet as a seperate table, and in the same table as the observations");
			}
			if(fixedAttributes.containsKey(worksheetAttr)) {
				throw new SdmxSemmanticException("Attribute '"+worksheetAttr+"' is assigned to both appear in in the same worksheet as a seperate table, have a fixed value");
			}
		}

		for(String variableAttr : variableAttributes) {
			if(fixedAttributes.containsKey(variableAttr)) {
				throw new SdmxSemmanticException("Attribute '"+variableAttr+"' is assigned to both appear in in the same table as the observations, have a fixed value");
			}
		}

		this.textDisplay = Collections.unmodifiableMap(this.textDisplay);
		this.tableCols = Collections.unmodifiableList(tableCols);
		this.tableRows = Collections.unmodifiableList(tableRows);
		this.fixedAttributes = Collections.unmodifiableMap(fixedAttributes);
		this.variableAttributes = Collections.unmodifiableSet(variableAttributes);
		this.worksheetAttributes = Collections.unmodifiableSet(worksheetAttributes);
		this.separateAttributes = Collections.unmodifiableSet(separateAttributes);
		this.hierarchyReferences = Collections.unmodifiableMap(hierarchyReferences);
		this.implicitHierarchices = Collections.unmodifiableSet(implicitHierarchices);
		this.excludeDimensions = Collections.unmodifiableSet(excludeDimensions);
		this.conditionalAttributes = Collections.unmodifiableList(conditionalAttributes);
		this.variableDimensions = Collections.unmodifiableSet(variableDimensions);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ReportingTemplateWorksheetBean that = (ReportingTemplateWorksheetBean) bean;
			boolean returnVal = true;

			String prefix = "Worksheet " + this.getId() + ": ";

			if(!super.equivalent(this.dataflow, that.getDataflow(), prefix + "Dataflow Reference", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.reportingTemplateColour, that.getColourAttribute(), includeFinalProperties,  diff)) {
				returnVal = false;
			}

			// Compare Conditional Attributes
            List<ReportingTemplateConditionalAttributeBean> ca1 = this.getConditionalAttributes();
            List<ReportingTemplateConditionalAttributeBean> ca2 = that.getConditionalAttributes();
            if (ca1 == null && ca2 != null) {
                returnVal = false;
            } else if (ca1 != null && ca2 == null) {
                returnVal = false;
            } else if (ca1 != null && ca2 != null) {
                for (ReportingTemplateConditionalAttributeBean rtcAttrBean : ca1) {
                    String attrId = rtcAttrBean.getAttributeId();
                    boolean existsInThisOnly = true;
                    for (ReportingTemplateConditionalAttributeBean thatRtcAttrBean : ca2) {
                        if (attrId.equals(thatRtcAttrBean.getAttributeId())) {
                            existsInThisOnly = false;
                            if (!rtcAttrBean.deepEquals(thatRtcAttrBean, includeFinalProperties)) {
                                returnVal = false;
                            }
                        }
                    }
                    if (existsInThisOnly) {
                        if (diff != null) {
                            diff.addDiff(bean, "Attributes", attrId, null);
                        }
                        returnVal = false;
                    }
                }

                for (ReportingTemplateConditionalAttributeBean rtcAttrBean : ca2) {
                    String attrId = rtcAttrBean.getAttributeId();
                    boolean existsInThisOnly = true;
                    for (ReportingTemplateConditionalAttributeBean thatRtcAttrBean : ca1) {
                        if (attrId.equals(thatRtcAttrBean.getAttributeId())) {
                            existsInThisOnly = false;
                            if (!rtcAttrBean.deepEquals(thatRtcAttrBean, includeFinalProperties)) {
                                returnVal = false;
                            }
                        }
                    }
                    if (existsInThisOnly) {
                        if (diff != null) {
                            diff.addDiff(bean, "Attributes", null, attrId);
                        }
                        returnVal = false;
                    }
                }
            }



			if(!super.equivalent(this.sliceBy, that.getSliceBy(), prefix + "Slice By", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.tableRows, that.getTableRows(), prefix + "Table Rows", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.tableCols, that.getTableCols(), prefix + "Table Columns", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.variableAttributes, that.getVariableAttributes(), prefix + "Variable Attributes", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.variableDimensions, that.getVariableDimensions(), prefix + "Variable Dimensions", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.worksheetAttributes, that.getWorksheetAttributes(), prefix + "Worksheet Attributes", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.separateAttributes, that.getSeparateAttributes(), prefix + "Separate Attributes", diff)) {
				returnVal = false;
			}
			if(!super.equivalentMap(this, this.textDisplay, that.getTextDisplay(), prefix + "Text Display", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.implicitHierarchices, that.getImplicitHierarchices(), prefix + "Implicit Hierarchices", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.excludeDimensions, that.getExcludeDimensions(), prefix + "Exclude Dimensions", diff)) {
				return false;
			}
			if(!super.equivalentCollection(this, this.hierarchyReferences.keySet(), that.getHierarhcyReferences().keySet(), prefix + "Hierarchy Reference", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.roundDecimals, that.getRoundDecimals(), "Round Decimal Place", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.colMaxWidth, that.getColMaxWidth(), "Max Column Width", diff)) {
				returnVal = false;
			}
			for(String hierarchyReference : this.hierarchyReferences.keySet()) {
				if(that.getHierarhcyReferences().containsKey(hierarchyReference)) {
					if(!super.equivalent(this.getHierarhcyReferences().get(hierarchyReference), that.getHierarhcyReferences().get(hierarchyReference), diff)) {
						returnVal = false;
					}
				}
			}

			for(String fixedAttr : that.getFixedAttributes()) {
				if(!this.fixedAttributes.containsKey(fixedAttr)) {
					returnVal = false;
				} else if(!this.fixedAttributes.get(fixedAttr).equals(that.getFixedAttributeValue(fixedAttr))) {
					returnVal = false;
				}
			}
			for(String fixedAttr : this.fixedAttributes.keySet()) {
				if(!this.fixedAttributes.get(fixedAttr).equals(that.getFixedAttributeValue(fixedAttr))) {
					returnVal = false;
				}
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(reportingTemplateColour, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ReportingTemplateWorksheetBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<ReportingTemplateWorksheetBean> getURN() {
		return (IURNAbsolute<ReportingTemplateWorksheetBean>)super.getURN();
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(dataflow != null) {
			references.add(dataflow);
		}
		for(String hRef : hierarchyReferences.keySet()) {
			references.add(hierarchyReferences.get(hRef));
		}
	}

	@Override
	public ICrossReferenceBean<DataflowBean> getDataflow() {
		return dataflow;
	}

	@Override
	public String getSliceBy() {
		return sliceBy;
	}

	@Override
	public Integer getColMaxWidth() {
		return colMaxWidth;
	}

	@Override
	public List<String> getTableCols() {
		return tableCols;
	}

	@Override
	public List<String> getTableRows() {
		return tableRows;
	}

	@Override
	public Set<String> getFixedAttributes() {
		return fixedAttributes.keySet();
	}

	@Override
	public Map<String, String> getFixedAttributesMap() {
		return fixedAttributes;
	}

	@Override
	public String getFixedAttributeValue(String dimId) {
		return fixedAttributes.get(dimId);
	}

	@Override
	public Set<String> getExcludeDimensions() {
		return excludeDimensions;
	}

	@Override
	public Set<String> getVariableAttributes() {
		return variableAttributes;
	}

	@Override
	public Set<String> getVariableDimensions() {
		return variableDimensions;
	}

	@Override
	public Set<String> getWorksheetAttributes() {
		return worksheetAttributes;
	}

	@Override
	public Set<String> getSeparateAttributes() {
		return separateAttributes;
	}

	@Override
	public ReportingTemplateColourBean getColourAttribute() {
		return reportingTemplateColour;
	}

	@Override
	public TEXT_DISPLAY getTextDisplay(String componentId) {
		if(textDisplay.containsKey(componentId)) {
			return textDisplay.get(componentId);
		}
		return TEXT_DISPLAY.NAME;
	}

	@Override
	public Map<String, TEXT_DISPLAY> getTextDisplay() {
		return textDisplay;
	}

	@Override
	public Map<String, IDirectCrossReferenceBean<HierarchyBean>> getHierarhcyReferences() {
		return hierarchyReferences;
	}

	@Override
	public Set<String> getImplicitHierarchices() {
		return implicitHierarchices;
	}

	@Override
	public List<ReportingTemplateConditionalAttributeBean> getConditionalAttributes() {
		return conditionalAttributes;
	}

	@Override
	public Integer getRoundDecimals() {
		return roundDecimals;
	}
}
