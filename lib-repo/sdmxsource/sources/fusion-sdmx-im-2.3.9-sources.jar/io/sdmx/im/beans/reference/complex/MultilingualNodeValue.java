package io.sdmx.im.beans.reference.complex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;

public class MultilingualNodeValue implements IMultilingualNodeValue, Serializable {

	private static final long serialVersionUID = 1L;
    private List<TextTypeWrapper> texts = Collections.emptyList();
    
    public MultilingualNodeValue(List<TextTypeWrapper> texts){
    	if(texts != null) {
    		this.texts = Collections.unmodifiableList(new ArrayList<>(texts));
    	}
    }

    @Override
    public List<TextTypeWrapper> getTexts() {
        return texts;
    }

}
