package io.sdmx.im.beans.registry;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.registry.AllowedContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;

public class AllowedContentConstraint extends ContentConstraintBeanImpl implements AllowedContentConstraintBean {
	private static final long serialVersionUID = 1L;

	AllowedContentConstraint(ContentConstraintMutableBean mutable) {
		super(mutable);
	}

	private AllowedContentConstraint(AllowedContentConstraint bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		if (!completeStub) {
            // FR-4920: Return the attachment constraint in a stub
            this.constraintAttachment = bean.getConstraintAttachment();
        }
	}

	@Override
	public AllowedContentConstraint getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
	    return new AllowedContentConstraint(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public boolean isDefiningActualDataPresent() {
		return false;
	}

	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<AllowedContentConstraintBean> getURN() {
		return (IURNMaintainable<AllowedContentConstraintBean>) super.getURN();
	}
}
