package io.sdmx.im.beans.process;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class ProcessBeanDeferred extends MaintainableBeanDeferred<ProcessBean> implements ProcessBean {
    private static final long serialVersionUID = 1L;

    public ProcessBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ProcessBeanDeferred(ProcessBean maint) {
        super(maint);
    }
    
    @Override
    public ProcessBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ProcessBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ProcessBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ProcessBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ProcessBean> getURN() {
        return (IURNMaintainable<ProcessBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ProcessBean.class;
    }

    @Override
    public ProcessMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<ProcessStepBean> getProcessSteps() {
        return load().getProcessSteps();
    }
}
