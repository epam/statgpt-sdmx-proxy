package io.sdmx.im.beans.registry;

import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.utils.core.collection.KeyValueImpl;

public class ConstrainedKeyValue implements IConstrainedKeyValue {
	//Keep a weak hash map of previously created values for performance
	private static final Map<String, ConstrainedKeyValue> cache = new WeakHashMap<>();
	private int hashCode = -1;
	private static final long serialVersionUID = 2L;
	private boolean removePrefix;
	private KeyValue kv;

	private ConstrainedKeyValue(String concept, boolean removePrefix, String... code) {
		this.kv = KeyValueImpl.getInstance(concept, code);
		this.removePrefix = removePrefix;
	}

	public static ConstrainedKeyValue getInstance(String id, boolean removePrefix, String... value) {
		if(value != null && value.length > 1) {
			return new ConstrainedKeyValue(id, removePrefix, value);
		}
		if(value == null || value.length == 0) {
			return new ConstrainedKeyValue(id, removePrefix, value);
		}
		String key = id+":"+value[0]+":"+removePrefix;
		synchronized(cache) {
			ConstrainedKeyValue returnKv = cache.get(key);
			if(returnKv == null) {
				returnKv = new ConstrainedKeyValue(id, removePrefix, value);
				cache.put(key, returnKv);
			}
			return returnKv;
		}
	}

	@Override
	public String getCode() {
		return kv.getCode();
	}

	@Override
	public String getConcept() {
		return kv.getConcept();
	}

	@Override
	public List<String> getValues() {
		return kv.getValues();
	}

	@Override
	public boolean hasMultipleValues() {
		return kv.hasMultipleValues();
	}

	@Override
	public boolean isRemovePrefix() {
		return removePrefix;
	}
	
	@Override
	public String getShortCode() {
		return kv.getShortCode();
	}

	@Override
	public int compareTo(KeyValue that) {
		int rt = this.kv.compareTo(that);
		if(rt == 0) {
			boolean removePrefix = false;
			if(that instanceof ConstrainedKeyValue) {
				ConstrainedKeyValue ckv = (ConstrainedKeyValue)that;
				removePrefix = ckv.isRemovePrefix();
			}
			if(this.isRemovePrefix() && removePrefix) {
				return 1;
			}
			if(!this.isRemovePrefix() && removePrefix) {
				return -1;
			}
		}
		return rt;
	}	

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof ConstrainedKeyValue) {
			ConstrainedKeyValue that = (ConstrainedKeyValue)obj;
			if(!this.kv.equals(that.kv)) {
				return false;
			}
			return this.removePrefix == that.isRemovePrefix();
		}
		if(obj instanceof KeyValue) {
			if(this.removePrefix) {
				return false;
			}
			KeyValue that = (KeyValue)obj;
			return this.kv.equals(that);
		}
		return false;
	}

	@Override
	public int hashCode() {
		if(hashCode == -1) {
			if(!removePrefix) {
				this.hashCode = this.kv.hashCode();
			} else {
				hashCode = (getConcept() + getCode()+removePrefix).hashCode();
			}
				
		}
		return hashCode;
	}

	@Override
	public String toString() {
		return getConcept()+":"+getCode()+":"+removePrefix;
	}
}
