package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.im.beans.base.ComponentBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class AttributeBeanImpl extends ComponentBeanImpl implements AttributeBean {
	private static final long serialVersionUID = 2L;

	private ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel;
	
	private String attachmentGroup;
	private List<String> dimensionReference = Collections.emptyList();
	private List<String> measureReference = Collections.emptyList();
	private List<IDirectCrossReferenceBean<ConceptBean>> conceptRoles = new ArrayList<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public AttributeBeanImpl(AttributeMutableBean attribute, AttributeListBean parent) {
		super(attribute, parent);
		try {
			this.attachmentLevel = attribute.getAttachmentLevel();
			this.attachmentGroup = attribute.getAttachmentGroup();
			if(attribute.getDimensionReferences() != null) {
				this.dimensionReference = Collections.unmodifiableList(new ArrayList<>(attribute.getDimensionReferences()));
			}
			if(attribute.getMeasureReferences() != null) {
				this.measureReference = Collections.unmodifiableList(new ArrayList<>(attribute.getMeasureReferences()));
			}
			if(attribute.getConceptRoles() != null) {
				for(StructureReferenceBean currentConceptRole : attribute.getConceptRoles()) {
					this.conceptRoles.add(DirectCrossReferenceBean.build(this, "conceptrole", currentConceptRole, ConceptBean.class));
				}
			}
			this.conceptRoles = Collections.unmodifiableList(conceptRoles);
			validateAttributeAttributes();
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Error creating structure: " + this.toString());
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			AttributeBean that = (AttributeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(attachmentLevel, that.getAttachmentLevel(), "Attachment Level", diff)) {
				returnVal = false;
			} else {
				//Only do these if the attachement level is the same
				if(!super.equivalentCollection(this, dimensionReference, that.getDimensionReferences(), "Dimension Reference", diff)) {
					returnVal = false;
				}
				if(!super.equivalentCollection(this, measureReference, that.getMeasureReferences(), "Measure Reference", diff)) {
					returnVal = false;
				}
				if(!super.equivalentCollection(this, conceptRoles, that.getConceptRoles(), "Concept Role", diff)) {
					returnVal = false;
				}
				if(!super.equivalent(attachmentGroup, that.getAttachmentGroup(), "Attachment Group", diff)) {
					returnVal = false;
				}
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validateAttributeAttributes() throws SdmxSemmanticException {
		if(this.attachmentLevel == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ATTRIBUTE, this.structureType, "attachmentLevel");
		}
		DataStructureBean parentDSD = (DataStructureBean) this.getMaintainableParent();
		if(attachmentLevel == ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION) {
			if(!ObjectUtil.validCollection(dimensionReference)) {
				if(this.measureReference.size() == 0) {
					//Ensure that the primary measure reference is set if the dimension references are empty
					//Note - logic has been left as it was in v2.1
					this.measureReference = SdmxCollectionUtil.identifiablesIdList(parentDSD.getMeasures(), true);
				}
			} else {
				DimensionBean timeDimension = parentDSD.getTimeDimension();
				if (timeDimension == null && this.measureReference.size() == 0) {
					// This is not an observation attribute as it does not include the time dimension
					attachmentLevel = ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP;
				} else  if (timeDimension != null) {
					String timeDimensionId = timeDimension.getId();
					if(!dimensionReference.contains(timeDimensionId)) {
						// This is not an observation attribute as it does not include the time dimension
						attachmentLevel = ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP;
					}
				}
			}
		} else if(attachmentLevel == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
			//BUG FIX
			DataStructureBean dsd = (DataStructureBean)getMaintainableParent();
			for(DimensionBean currentDimension : dsd.getDimensions()) {
				if(this.dimensionReference.contains(currentDimension.getId())) {
					if(currentDimension.isTimeDimension()) {
						//REFERENCING THE TIME DIMENSION THEREFOR OBSERVATION LEVEL
						this.attachmentLevel = ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION;
						break;
					}
				}
			}
		}
		for(String dimRef : this.dimensionReference) {
		    if(parentDSD.getDimension(dimRef)==null) {
		        throw new SdmxSemmanticException("Attribute '"+getId()+"' has specified attachment to Dimension '"+dimRef+"' which does not exist in the Data Structure: " + parentDSD.getShortURN());
		    }
		}
		if(!ObjectUtil.validString(attachmentGroup) && attachmentLevel == ATTRIBUTE_ATTACHMENT_LEVEL.GROUP) {
			throw new SdmxSemmanticException("Attribute has specified attachment level specified as Group, but does not specifies the attachment groups. Either change the attachment level, or declare which group the attribute attaches to: " + getId());
		}
		if(ObjectUtil.validString(attachmentGroup) && attachmentLevel != ATTRIBUTE_ATTACHMENT_LEVEL.GROUP) {
			throw new SdmxSemmanticException("Attribute specifies an attachment group of '"+attachmentGroup+"', but the the attachment level is not set to GROUP, it is set to  '"+ attachmentLevel+"'.  Either remove the attribute's reference to the '"+attachmentGroup+"' or change the attribute's attachment level to GROUP");
		}
		if(attachmentLevel == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
			if(!ObjectUtil.validCollection(dimensionReference)) {
				throw new SdmxSemmanticException("Attribute specifies attachment level of 'Dimension Group' but does not specify any dimensions");
			}
			//Order the Dimension references
			List<String> orderedList = new ArrayList<>();
			for(DimensionBean currentDimension : getParent(DataStructureBean.class, false).getDimensionList().getDimensions()) {
				if(this.dimensionReference.contains(currentDimension.getId())) {
					orderedList.add(currentDimension.getId());
				}
			}
			this.dimensionReference = Collections.unmodifiableList(orderedList);
		}
		for(ICrossReferenceBean<ConceptBean> conceptRole : conceptRoles) {
			if(conceptRole.getTargetReference() != SDMX_STRUCTURE_TYPE.CONCEPT) {
				throw new SdmxSemmanticException("Illegal concept role '"+conceptRole.getTargetUrn()+"'.  Concept Role must reference a concept.");
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return AttributeBean.class;
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<AttributeBean> getURN() {
		return (IURNAbsolute<AttributeBean>)super.getURN();
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		super.getCrossReferences(references);
		references.addAll(this.conceptRoles);
	}

	@Override
	protected List<String> getParentIds(boolean includeDifferentTypes) {
		List<String> returnList = new ArrayList<>();
		returnList.add(this.getId());
		return returnList;
	}
	
	@Override
	public COMPONENT_TYPE getType() {
		return COMPONENT_TYPE.ATTRIBUTE;
	}
	
	@Override
	public String getAttachmentGroup() {
		return attachmentGroup;
	}

	@Override
	public List<String> getMeasureReferences() {
		return measureReference;
	}

	@Override
	public List<IDirectCrossReferenceBean<ConceptBean>> getConceptRoles() {
		return conceptRoles;
	}

	@Override
	public boolean isTimeFormat() {
		return this.getId().equals("TIME_FORMAT");
	}

	@Override
	public ATTRIBUTE_ATTACHMENT_LEVEL getAttachmentLevel() {
		return attachmentLevel;
	}

	@Override
	public List<String> getDimensionReferences() {
		return dimensionReference;
	}
	
}
