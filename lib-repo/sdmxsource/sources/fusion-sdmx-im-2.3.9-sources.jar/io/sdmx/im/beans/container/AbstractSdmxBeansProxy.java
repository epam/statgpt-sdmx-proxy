package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.util.Hierarchy;

/**
 * Proxies an SdmxBeans instance simply passing all requests to the proxy.
 * The purpose of this class is so sub-classes can easily add their own behaviour to a proxied SdmxBeans
 */
public class AbstractSdmxBeansProxy implements SdmxBeans {
	private static final long serialVersionUID = 1L;
	private SdmxBeans proxy;
	
	public AbstractSdmxBeansProxy(SdmxBeans beans) {
		if(beans == null) {
			throw new SdmxException("Missing required property SdmxBeans");
		}
		this.proxy = beans;
	}
	
	@Override
	public List<ILinkBean> getLinks() {
		return proxy.getLinks();
	}

	@Override
	public void addLink(ILinkBean link) {
		proxy.addLink(link);
	}

	@Override
	public String getId() {
		return proxy.getId();
	}

	@Override
	public DATASET_ACTION getAction() {
		return proxy.getAction();
	}

	@Override
	public void setAction(DATASET_ACTION action) {
		proxy.setAction(action);
	}

	@Override
	public HeaderBean getHeader() {
		return proxy.getHeader();
	}

	@Override
	public void setHeader(HeaderBean header) {
		proxy.setHeader(header);
	}

	@Override
	public Set<String> getAllLocales() {
		return proxy.getAllLocales();
	}

	@Override
	public SdmxBeans getReadOnlyCopy() {
		return proxy.getReadOnlyCopy();
	}

	@Override
	public void merge(SdmxBeans beans) {
		proxy.merge(beans);
	}

	@Override
	public void merge(SdmxBeans beans, boolean overwrite) {
		proxy.merge(beans, overwrite);
	}

	@Override
	public void clear() {
		proxy.clear();
	}

	@Override
	public void addIdentifiables(Collection<? extends IdentifiableBean> beans) {
		proxy.addIdentifiables(beans);
	}

	@Override
	public boolean addIdentifiable(IdentifiableBean bean) {
		return proxy.addIdentifiable(bean);
	}

	@Override
	public void removeMaintainable(MaintainableBean bean) {
		proxy.removeMaintainable(bean);
	}

	@Override
	public boolean hasStructuresOfType(SDMX_STRUCTURE_TYPE type) {
		return proxy.hasStructuresOfType(type);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(Class<T> structureType) {
		return proxy.getMaintainableBeans(structureType);
	}

	@Override
	public Hierarchy<AgencyBean> getAgencyHierarchy() {
		return proxy.getAgencyHierarchy();
	}

	@Override
	public Set<AgencyBean> getAgencies() {
		return proxy.getAgencies();
	}
	
	@Override
	public Set<MaintainableBean> getAllMaintainables(SDMX_STRUCTURE_TYPE... exclude) {
		return proxy.getAllMaintainables(exclude);
	}

	@Override
	public Set<MaintainableBean> getMaintainables(SDMX_STRUCTURE_TYPE structureType) {
		return proxy.getMaintainables(structureType);
	}

	@Override
	public SdmxBeans filterMaintainables(Predicate<? super MaintainableBean> predicate) {
		return proxy.filterMaintainables(predicate);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		return proxy.getMaintainableBeans(urn);
	}

	@Override
	public Set<IMaintainableStructureType<?>> getDistinctTypes() {
		return proxy.getDistinctTypes();
	}
}
