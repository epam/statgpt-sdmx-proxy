package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collections;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;

public abstract class OrganisationSchemeBeanImpl<T extends OrganisationBean> extends ItemSchemeBeanImpl<T> implements OrganisationSchemeBean<T> {
	private static final long serialVersionUID = -710153459216735610L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected OrganisationSchemeBeanImpl(ItemSchemeBean<T> bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		validateOrganisationSchemeAttributes();
		items = Collections.emptyList();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected OrganisationSchemeBeanImpl(ItemSchemeMutableBean<? extends ItemMutableBean> bean) {
		super(bean);
		validateOrganisationSchemeAttributes();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validateOrganisationSchemeAttributes() throws SdmxSemmanticException {
		if(isFinal()) {
			throw new SdmxSemmanticException("Organisation Schemes can not be set to final");
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<? extends OrganisationSchemeBean<T>>  getURN() {
		return (IURNMaintainable<? extends OrganisationSchemeBean<T>> ) super.getURN();
	}
	
	@Override
	public boolean isFixedVersion() {
		return true;
	}
}
