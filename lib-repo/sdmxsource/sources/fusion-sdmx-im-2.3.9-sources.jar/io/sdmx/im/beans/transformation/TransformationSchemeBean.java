package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.im.mutable.transformation.TransformationSchemeMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * Container for {@link TransformationBean}
 */
public class TransformationSchemeBean extends VtlSchemeBean<ITransformationBean> implements ITransformationSchemeBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<IVtlMappingSchemeBean> vtlMappingSchemeRef;
	private IDirectCrossReferenceBean<INamePersonalisationSchemeBean> namePersonalisationSchemeRef;
	private IDirectCrossReferenceBean<ICustomTypeSchemeBean> customTypeSchemeRef;
	private List<IDirectCrossReferenceBean<IRulesetSchemeBean>> rulesetSchemeRef = Collections.emptyList();
	private List<IDirectCrossReferenceBean<IUserDefinedOperatorSchemeBean>> userDefinedOperatorSchemeRef = Collections.emptyList();
	
	TransformationSchemeBean(ITransformationSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.emptyList();
	}

	public TransformationSchemeBean(ITransformationSchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(ITransformationMutableBean item : bean.getItems()) {
				this.items.add(new TransformationBean(item, this, this.items.size()));
			}
		}
		if(bean.getVtlMappingSchemeRef() != null) {
			this.vtlMappingSchemeRef = DirectCrossReferenceBean.build(this, "vtlmapping", bean.getVtlMappingSchemeRef(), IVtlMappingSchemeBean.class);
		}
		if(bean.getNamePersonalisationSchemeRef() != null) {
			this.namePersonalisationSchemeRef = DirectCrossReferenceBean.build(this, "namepersonalisationmapping",bean.getNamePersonalisationSchemeRef(), INamePersonalisationSchemeBean.class);
		}
		if(bean.getCustomTypeSchemeRef() != null) {
			this.customTypeSchemeRef = DirectCrossReferenceBean.build(this, "customtypemapping",bean.getCustomTypeSchemeRef(), ICustomTypeSchemeBean.class);
		}
		if(bean.getRulesetSchemeRef() != null) {
			this.rulesetSchemeRef = new ArrayList<>();
			for(StructureReferenceBean rulesetSchemeRef : bean.getRulesetSchemeRef()) {
				this.rulesetSchemeRef.add(DirectCrossReferenceBean.build(this, "ruleset", rulesetSchemeRef, IRulesetSchemeBean.class));
			}
			this.rulesetSchemeRef = Collections.unmodifiableList(this.rulesetSchemeRef);
		}
		if(bean.getUserDefinedOperatorSchemeRef() != null) {
			this.userDefinedOperatorSchemeRef = new ArrayList<>();
			for(StructureReferenceBean userDefinedOperator : bean.getUserDefinedOperatorSchemeRef()) {
				this.userDefinedOperatorSchemeRef.add(DirectCrossReferenceBean.build(this, "userdefinedoperator", userDefinedOperator, IUserDefinedOperatorSchemeBean.class));
			}
			this.userDefinedOperatorSchemeRef = Collections.unmodifiableList(this.userDefinedOperatorSchemeRef);
		}
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		ITransformationSchemeBean that = (ITransformationSchemeBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(this.vtlMappingSchemeRef, that.getVtlMappingSchemeRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.namePersonalisationSchemeRef, that.getNamePersonalisationSchemeRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.customTypeSchemeRef, that.getCustomTypeSchemeRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.rulesetSchemeRef, that.getRulesetSchemeRef(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.userDefinedOperatorSchemeRef, that.getUserDefinedOperatorSchemeRef(), diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION.getType(), diff) && returnVal;
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ITransformationSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ITransformationSchemeBean> getURN() {
		return (IURNMaintainable<ITransformationSchemeBean>) super.getURN();
	}
	
	@Override
	public ICrossReferenceBean<IVtlMappingSchemeBean> getVtlMappingSchemeRef() {
		return vtlMappingSchemeRef;
	}

	@Override
	public ICrossReferenceBean<INamePersonalisationSchemeBean> getNamePersonalisationSchemeRef() {
		return namePersonalisationSchemeRef;
	}

	@Override
	public ICrossReferenceBean<ICustomTypeSchemeBean> getCustomTypeSchemeRef() {
		return customTypeSchemeRef;
	}
	
	@Override
	public List<IDirectCrossReferenceBean<IRulesetSchemeBean>> getRulesetSchemeRef() {
		return rulesetSchemeRef;
	}
	
	@Override
	public List<IDirectCrossReferenceBean<IUserDefinedOperatorSchemeBean>> getUserDefinedOperatorSchemeRef() {
		return userDefinedOperatorSchemeRef;
	}

	@Override
	public ITransformationSchemeMutableBean getMutableInstance() {
		return new TransformationSchemeMutableBean(this);
	}

	@Override
	public ITransformationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new TransformationSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(this.getVtlMappingSchemeRef() != null) {
			references.add(this.getVtlMappingSchemeRef());
		}
		
		if(this.getNamePersonalisationSchemeRef() != null) {
			references.add(this.getNamePersonalisationSchemeRef());
		}
		
		if(this.getCustomTypeSchemeRef() != null) {
			references.add(this.getCustomTypeSchemeRef());
		}
		references.addAll(this.getRulesetSchemeRef());
		references.addAll(this.getUserDefinedOperatorSchemeRef());
	}

    @Override
    public TransformationSchemeBeanDeferred toDeferred() {
        return new TransformationSchemeBeanDeferred(this);
    }
    
    @Override
    public TransformationSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new TransformationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
