package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class ConstrainedDataKeyBeanImpl extends SdmxStructureBeanImpl implements ConstrainedDataKeyBean {
	private static final long serialVersionUID = 431189020748834418L;
	private List<IConstrainedKeyValue> keyValues = new ArrayList<>();
	private List<IConstrainedKeyValue> componentValues = new ArrayList<>();
	
	private boolean isIncluded;
	private SdmxPeriod validityPeriod;
	
	private transient Map<String, IConstrainedKeyValue> kvMap = null;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ConstrainedDataKeyBeanImpl(ConstrainedDataKeyMutableBean mutable, boolean isIncluded, ConstraintDataKeySetBean parent) {
		super(SDMX_STRUCTURE_TYPE.CONSTRAINED_DATA_KEY, parent);
		if(mutable.getKeyValues() != null) {
			for (IConstrainedKeyValue kv : mutable.getKeyValues()) {
				keyValues.add(kv);
			}
		}
		if(mutable.getComponentValues() != null) {
			for (IConstrainedKeyValue kv : mutable.getComponentValues()) {
				componentValues.add(kv);
			}
		}
		if(mutable.getValidFrom() != null || mutable.getValidTo() != null) {
			this.validityPeriod = new SdmxPeriodImpl(mutable.getValidFrom(), mutable.getValidTo());
		}
		this.isIncluded = isIncluded;
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConstrainedDataKeyBean that = (ConstrainedDataKeyBean) bean;
			boolean returnVal = true;
			
			if(!super.equivalentCollection(this, getKeyValues(), that.getKeyValues(), "KeyValues", diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, getComponentValues(), that.getComponentValues(), "ComponentValues", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.validityPeriod, that.getValidityPeriod(), "Validity Period", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<IConstrainedKeyValue> getKeyValues() {
		return keyValues;
	}
	
	@Override
	public IConstrainedKeyValue getKeyValue(String dimensionId) {
		if(kvMap == null) {
			Map<String, IConstrainedKeyValue> kvMap = new HashMap<>();
			for(IConstrainedKeyValue kv : keyValues) {
				kvMap.put(kv.getConcept(), kv);
			}
			this.kvMap = kvMap;
		}
		return this.kvMap.get(dimensionId);
	}
	
    @Override
	public String getKey() {
		return null;
	}

	@Override
	public boolean isIncluded() {
		return isIncluded;
	}
	
	@Override
	public List<IConstrainedKeyValue> getComponentValues() {
		return componentValues;
	}
	
	@Override
	public SdmxPeriod getValidityPeriod() {
		if(validityPeriod == null) {
			return SdmxPeriodImpl.ALL_PERIODS;
		}
		return validityPeriod;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		Set<String> kvIdSet = new HashSet<>();
		int count = 0;
		int countWildcard = 0;
		for(KeyValue kv : keyValues) {
			if(kvIdSet.contains(kv.getConcept())) {
				throw new SdmxSemmanticException("Constrained data key contains more then one value for dimension id: " + kv.getConcept());
			}
			kvIdSet.add(kv.getConcept());
			if(!kv.getCode().equals(ContentConstraintBean.WILDCARD_CODE)) {
				count++;
			} else {
				countWildcard++;
			}
 		}
		if(count == 1 && countWildcard > 0) {
			throw new SdmxSemmanticException("Can not define a datakey set with only one code.  Please use Cube Region instead to mark code for inclusion or exclusion");
		}
		this.keyValues = Collections.unmodifiableList(keyValues);
		this.componentValues = Collections.unmodifiableList(componentValues);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this) return true;
		// Can match another of same type
		if (!(obj instanceof ConstrainedDataKeyBean)) return false;
		ConstrainedDataKeyBean other = (ConstrainedDataKeyBean)obj;
		if (other.getKeyValues().size() != getKeyValues().size()) return false;
		for (KeyValue otherKV : other.getKeyValues()) {
			boolean found = false;
			for (KeyValue thisKV : getKeyValues()) {
				if (otherKV.equals(thisKV)) {
					found = true;
					break;
				}
			}
			if (!found) return false;
		}
		return true;
	}
	
	@Override
    public int hashCode() {
	    if(this.keyValues != null) {
            return Arrays.hashCode(keyValues.toArray());
        }
        return super.hashCode();
    }
}
