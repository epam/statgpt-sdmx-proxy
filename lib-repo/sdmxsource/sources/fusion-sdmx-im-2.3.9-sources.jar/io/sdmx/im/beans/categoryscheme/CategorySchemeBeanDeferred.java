package io.sdmx.im.beans.categoryscheme;

import java.net.URL;
import java.util.Date;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class CategorySchemeBeanDeferred extends ItemSchemeBeanDeffered<CategoryBean, CategorySchemeBean> implements CategorySchemeBean {
    
    private static final long serialVersionUID = 1L;
    private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

    public CategorySchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
        String validityPeriodType = bean.getProperties().get("VPType");
        if(validityPeriodType != null) {
            this.validityType = MAINT_VALIDITY_TYPE.getValidityType(validityPeriodType);
        }
    }
    
    public CategorySchemeBeanDeferred(CategorySchemeBean maint) {
        super(maint);
        this.validityType = maint.getValidityType();
    }
    
    @Override
    protected CategorySchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new CategorySchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    public CategorySchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CategorySchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<CategorySchemeBean> getURN() {
        return (IURNMaintainable<CategorySchemeBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return CategorySchemeBean.class;
    }
    
    @Override
    public CategorySchemeBean cloneForDate(Date date) {
        return (CategorySchemeBean)super.cloneForDate(date);
    }

    @Override
    public MAINT_VALIDITY_TYPE getValidityType() {
        return validityType;
    }

    @Override
    public CategoryBean getCategory(String... id) {
        return load().getCategory(id);
    }

    @Override
    public CategorySchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public boolean createdFromTimeRequest() {
        return load().createdFromTimeRequest();
    }
}
