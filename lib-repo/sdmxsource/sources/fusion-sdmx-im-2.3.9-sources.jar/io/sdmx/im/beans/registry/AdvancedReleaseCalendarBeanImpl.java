package io.sdmx.im.beans.registry;

import java.net.URL;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.AdvancedReleaseCalendarBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class AdvancedReleaseCalendarBeanImpl extends ContentConstraintBeanImpl implements AdvancedReleaseCalendarBean {
    private static final long serialVersionUID = 11L;
    private ReleaseCalendarBean releaseCalendarBean;

    public AdvancedReleaseCalendarBeanImpl(ContentConstraintMutableBean mutable) {
        super(mutable);
        super.structureType = SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR;
        if(mutable.getIncludedCubeRegion() != null &&
                (ObjectUtil.validCollection(mutable.getIncludedCubeRegion().getKeyValues()) ||
                        ObjectUtil.validCollection(mutable.getIncludedCubeRegion().getAttributeValues()))) {
            throw new SdmxNotImplementedException("Constraint with Release Calendar must not contain Cube Region restrictions");
        }
        if(mutable.getExcludedCubeRegion() != null &&
                (ObjectUtil.validCollection(mutable.getExcludedCubeRegion().getKeyValues()) ||
                        ObjectUtil.validCollection(mutable.getExcludedCubeRegion().getAttributeValues()))) {
            throw new SdmxNotImplementedException("Constraint with Release Calendar must not contain Cube Region restrictions");
        }

        if (mutable.getReferencePeriod() != null) {
            throw new SdmxNotImplementedException("Constraint with Release Calendar must not contain Reference Period restrictions");
        }
        if (mutable.getReleaseCalendar() != null) {
            this.releaseCalendarBean = new ReleaseCalendarBeanImpl(mutable.getReleaseCalendar(), this);
        }
        if (mutable.getMetadataTargetRegion() != null) {
            throw new SdmxNotImplementedException("Constraint with Release Calendar must not contain Metadat Target restrictions");
        }
        try {
            validate();
        } catch(SdmxSemmanticException e) {
            throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
        }
    }

    private AdvancedReleaseCalendarBeanImpl(AdvancedReleaseCalendarBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public AdvancedReleaseCalendarBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new AdvancedReleaseCalendarBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public ContentConstraintMutableBean getMutableInstance() {
        return new ContentConstraintMutableBeanImpl(this);
    }

    @Override
    public ReleaseCalendarBean getReleaseCalendar() {
        return releaseCalendarBean;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ContentConstraintBean.class;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATE								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() {
        if(getConstraintAttachment() == null) {
            throw new SdmxSemmanticException("Advance Release Calendar missing reference to Data Provider, Dataflow, or Provision Agreement");
        }
        for(ICrossReferenceBean cRef : getConstraintAttachment().getStructureReference()) {
            switch(cRef.getTargetReference()) {
            case DATA_PROVIDER :
            case DATAFLOW :
            case PROVISION_AGREEMENT :
                break;
            default : throw new SdmxNotImplementedException("Advance Release Calandar can only be created for a Data Provider, Dataflow, or Provision Agreement");
            }
        }
        if(releaseCalendarBean == null) {
            throw new SdmxException("Can not construct Advanced Release Calendar, no releaseCalendarBean set");
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            ContentConstraintBean that = (ContentConstraintBean) bean;
            boolean returnVal = true;
            if(!super.equivalent(releaseCalendarBean, that.getReleaseCalendar(), includeFinalProperties,  diff)) {
                returnVal = false;
            }
            return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
        }
        return false;
    }

    @Override
    /**
     * Not supported as it can not be easily rebuilt due to static constructor
     */
    public IDeferredBeanDefinition getDeferredDefinition() {
        return null;
    }
}
