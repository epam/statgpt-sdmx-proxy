package io.sdmx.im.beans.reporting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateConditionalAttributeMutableBean;
import io.sdmx.im.beans.base.ConditionalAttributeMappingBeanImpl;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReportingTemplateConditionalAttributeBeanImpl extends SDMXBeanImpl implements ReportingTemplateConditionalAttributeBean {
	private static final long serialVersionUID = 13L;
	private String attributeId;
	private List<ConditionalAttributeMappingBean> conditions;
	
	public ReportingTemplateConditionalAttributeBeanImpl(ReportingTemplateConditionalAttributeMutableBean mutable, ReportingTemplateWorksheetBean parent) {
		super(mutable, parent);
		this.attributeId = mutable.getAttributeId();
		this.conditions = new ArrayList<>();
		if(mutable.getConditions() != null) {
			for(ConditionalAttributeMappingBeanMutableBean conditon : mutable.getConditions()) {
				this.conditions.add(new ConditionalAttributeMappingBeanImpl(conditon, this));
			}
		}
		validate();
	}
	
	private void validate() {
		if(!ObjectUtil.validString(attributeId)) {
			throw new SdmxSemmanticException("Reporting Template Conditional Attribute requires an Attribute Id");
		}
		if(!ObjectUtil.validCollection(conditions)) {
			throw new SdmxSemmanticException("Reporting Template Conditional Attribute requires Attribute conditions");
		}
		Set<String> processedrules = new HashSet<>();
		for(ConditionalAttributeMappingBean condition : conditions) {
			String cr = condition.getCondition().getHumanReadable()+(condition.getConditionDetail() != null ? " " + condition.getConditionDetail() : "");
			if(processedrules.contains(cr)) {
				throw new SdmxSemmanticException("Duplicate Conditional Rule '"+cr+"'");
			}
			processedrules.add(cr);
		}
	}

	@Override
	public String getAttributeId() {
		return attributeId;
	}

	@Override
	public List<ConditionalAttributeMappingBean> getConditions() {
		return conditions;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ReportingTemplateConditionalAttributeBean that = (ReportingTemplateConditionalAttributeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.getConditions(), that.getConditions(), includeFinalProperties, "conditions", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getAttributeId(), that.getAttributeId(), "attribute id", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public String getKey() {
		return getAttributeId();
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>(conditions);
	}
}
