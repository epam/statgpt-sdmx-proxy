package io.sdmx.im.beans.registry;

import java.net.URL;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.registry.ActualContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;

public class ActualContentConstraint extends ContentConstraintBeanImpl implements ActualContentConstraintBean {
	private static final long serialVersionUID = 1L;

	ActualContentConstraint(ContentConstraintMutableBean mutable) {
		super(mutable);
	}

	private ActualContentConstraint(ActualContentConstraint bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ActualContentConstraint getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ActualContentConstraint(this, actualLocation, isServiceUrl, completeStub);
	}
	@Override
	public boolean isDefiningActualDataPresent() {
		return true;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<ActualContentConstraintBean> getURN() {
		return (IURNMaintainable<ActualContentConstraintBean>) super.getURN();
	}

}