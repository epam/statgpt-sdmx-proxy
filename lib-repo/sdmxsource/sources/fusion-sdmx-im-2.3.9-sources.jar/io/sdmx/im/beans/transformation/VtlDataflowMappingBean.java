package io.sdmx.im.beans.transformation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlDataflowMappingMutableBean;

public class VtlDataflowMappingBean extends VtlMappingBean<DataflowBean> implements IVtlDataflowMappingBean {
	private static final long serialVersionUID = 1L;
	
	private String fromMethod;
	private String toMethod;
	private List<String> fromSubSpace = Collections.emptyList();
	private List<String> toSubSpace = Collections.emptyList();

	public VtlDataflowMappingBean(IVtlDataflowMappingMutableBean bean, IVtlMappingSchemeBean parent, int position) {
		super(bean, DataflowBean.class, parent, position);
		this.fromMethod = bean.getFromMethod();
		this.toMethod = bean.getToMethod();
		
		if(bean.getFromSubSpace() != null) {
			this.fromSubSpace = Collections.unmodifiableList(new ArrayList<>(bean.getFromSubSpace()));
		}
		if(bean.getToSubSpace() != null) {
			this.toSubSpace = Collections.unmodifiableList(new ArrayList<>(bean.getToSubSpace()));
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IVtlDataflowMappingBean that = (IVtlDataflowMappingBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(fromSubSpace, that.getFromSubSpace(), "From Superspace", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(toSubSpace, that.getToSubSpace(), "To Subspace", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(fromMethod, that.getFromMethod(), "From Method", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(toMethod, that.getToMethod(), "To Method", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IVtlDataflowMappingBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IVtlDataflowMappingBean> getURN() {
		return (IURNAbsolute<IVtlDataflowMappingBean>) super.getURN(); 
	}
	
	@Override
	public String getFromMethod() {
		return fromMethod;
	}

	@Override
	public String getToMethod() {
		return toMethod;
	}

	@Override
	public List<String> getFromSubSpace() {
		return fromSubSpace;
	}

	@Override
	public List<String> getToSubSpace() {
		return toSubSpace;
	}
}
