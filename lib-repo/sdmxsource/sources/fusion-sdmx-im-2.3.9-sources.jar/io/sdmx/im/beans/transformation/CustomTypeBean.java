package io.sdmx.im.beans.transformation;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Details a custom type within a {@link CustomTypeSchemeBean}
 */
public class CustomTypeBean extends ItemBeanImpl implements ICustomTypeBean {
	private static final long serialVersionUID = 1L;
	private String vtlScalarType;
	private String dataType;
	private String outputFormat;
	private String nullValue;
	private String vtlLiteralFormat;
	
	public CustomTypeBean(ICustomTypeMutableBean bean, ICustomTypeSchemeBean parent, int position) {
		super(bean, parent, position);
		this.dataType = bean.getDataType();
		this.outputFormat = bean.getOutputFormat();
		this.nullValue = bean.getNullValue();
		this.vtlScalarType = bean.getVtlScalarType();
		this.vtlLiteralFormat = bean.getVtlLiteralFormat();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(this.vtlScalarType)) {
			throw new SdmxSemmanticException("VTL Scalar Type required for VTL Custom Type");
		}
		if(!ObjectUtil.validString(this.dataType)) {
			throw new SdmxSemmanticException("VTL Data Type required for VTL Custom Type");
		}
		vtlScalarType = this.vtlScalarType.trim();
		dataType = this.dataType.trim();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		ICustomTypeBean that = (ICustomTypeBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(vtlScalarType, that.getVtlScalarType(), "VTL Scalar Type", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(dataType, that.getDataType(), "Data Type", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(outputFormat, that.getOutputFormat(), "Output Format", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(nullValue, that.getNullValue(), "Null Value", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(vtlLiteralFormat, that.getVtlLiteralFormat(), "VTL Literal Format", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ICustomTypeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<ICustomTypeBean> getURN() {
		return (IURNAbsolute<ICustomTypeBean>) super.getURN();
	}
	
	@Override
	public String getVtlScalarType() {
		return vtlScalarType;
	}

	@Override
	public String getDataType() {
		return dataType;
	}

	@Override
	public String getOutputFormat() {
		return outputFormat;
	}

	@Override
	public String getNullValue() {
		return nullValue;
	}

	@Override
	public String getVtlLiteralFormat() {
		return vtlLiteralFormat;
	}
}
