package io.sdmx.im.beans.categoryscheme;

import java.net.URL;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class CategorySchemeBeanImpl extends ItemSchemeBeanImpl<CategoryBean> implements CategorySchemeBean {
	private static final long serialVersionUID = 183L;

	private boolean createdFromTimeRequest = false;
	private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

	@Override
	public boolean createdFromTimeRequest() {
		return createdFromTimeRequest;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected CategorySchemeBeanImpl(CategorySchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.validityType = bean.getValidityType();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CategorySchemeBeanImpl(CategorySchemeMutableBean categoryScheme) {
		super(categoryScheme);
		this.validityType = categoryScheme.getValidityType();
		if (categoryScheme.createdFromTimeRequest()) {
			this.createdFromTimeRequest = true;
		}
		try {
			if(categoryScheme.getItems() != null) {
				int i = 1;
				for(CategoryMutableBean currentcategory : categoryScheme.getItems()) {
					items.add(new CategoryBeanImpl(this, currentcategory, i));
					i++;
				}
			}
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	
	@Override
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
        super.populateDeferredBeanBuilder(builder);
        if(validityType != MAINT_VALIDITY_TYPE.STANDARD) {
            builder.property("VPType", validityType.toString());
        }
    }

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}

		MAINT_VALIDITY_TYPE beanValidityType = ((CategorySchemeBean)bean).getValidityType();
		if (beanValidityType != null) {
			boolean typeEquals = beanValidityType.equals(this.getValidityType());
			if (!typeEquals){
				return false;
			}
		}
		return super.deepEqualsInternal((CategorySchemeBean)bean, includeFinalProperties, "Category", diff);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		Set<String> urns = new HashSet<>();

		List<CategoryBean> theItems = getItems();
		checkItems(theItems, urns);
	}

	private void checkItems(List<CategoryBean> theItems, Set<String> urns) {
		if(theItems != null) {
			for(CategoryBean category : theItems) {
			    List<CategoryBean> subItems = category.getItems();
			    if (ObjectUtil.validCollection(subItems)) {
			        checkItems(subItems, urns);
			    }
				if(urns.contains(category.getUrn())) {
					throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_URN, category.getUrn());
				}
				urns.add(category.getUrn());
			}
		}
	}

	@Override
	protected void validateId(boolean startWithIntAllowed) {
		//Not allowed to start with an integer
		super.validateId(false);
	}
	
	// Explicitly overrides method in super-class: ItemSchemeBeanImpl
	@Override
	public CategorySchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		if(filterIds == null) {
			return this;
		}
		CategorySchemeMutableBean mutableScheme = getMutableInstance();

		Collection<String> removeSet = null;
		if(isKeepSet) {
			Set<String> itemsInScheme = new HashSet<>();
			for(CategoryBean item : getItems()) {
				addToSet(filterIds, itemsInScheme, item.getFullIdPath(false));
				if(item instanceof HierarchicalItemBean) {
					HierarchicalItemBean hItem = item;
					if(hItem.isHierarchyExplicit()) {
						populateFilterSet(hItem.getItems(), itemsInScheme, filterIds);
					}
				}
			}
			if(itemsInScheme.size() == 0) {
				return this;
			}
			removeSet = itemsInScheme;
		} else {
			removeSet = filterIds;
		}
		for(String currentRemoveId : removeSet) {
			mutableScheme.removeItem(currentRemoveId);
		}
		mutableScheme.setPartial(true);
		return  mutableScheme.getImmutableInstance();
	}
	
	@Override
	public CategorySchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet, ITEM_FILTER_ACTION action) {
		// Ignore the action and simply return the filtered items. By default this will include the parent,
		// so as if ITEM_FILTER_ACTION was set to KEEP_PARENT
		return filterItems(filterIds, isKeepSet);
	}
	
	private void populateFilterSet(List<HierarchicalItemBean> items, Set<String> itemsInScheme, Collection<String> filterIds) {
		for(HierarchicalItemBean item : items) {
			addToSet(filterIds, itemsInScheme, item.getFullIdPath(false));
			if(item.getItems().size() > -1 ) {
				populateFilterSet(item.getItems(), itemsInScheme, filterIds);
			}
		}
	}

	/**
	 * Adds the itemId to the itemsInScheme set if they do not appear in the filtersId set.
	 * <p/>
	 * This method should not add an id if it is the child of a filter id, example if a filter Id is 'A.B' then 'A.B.C' should not be added as it
	 * is a child.
	 *
	 * @param filterIds ids which should not be added
	 * @param itemsInScheme the set to add to
	 * @param itemId this is to add to the itemsInScheme Set
	 */
	protected void addToSet(Collection<String> filterIds, Set<String> itemsInScheme, String itemId) {
		for(String filterId : filterIds) {
			if(itemId.equals(filterId)) {
				//Do not Add
				return;
			}
			if(filterId.contains(".") && filterId.startsWith(itemId)) {
				//Do not add
				return;
			}
		}
		itemsInScheme.add(itemId);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return CategorySchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<CategorySchemeBean> getURN() {
		return (IURNMaintainable<CategorySchemeBean>)super.getURN();
	}
	
	
	@Override
	public CategorySchemeMutableBean getMutableInstance() {
		return new CategorySchemeMutableBeanImpl(this);
	}

	@Override
	public CategorySchemeBean cloneForDate(Date date) {
		return (CategorySchemeBean)super.cloneForDate(date);
	}

	@Override
	public CategoryBean getCategory(String... id) {
		return getCategory(getItems(), id, 0);
	}

	private CategoryBean getCategory(String id, List<CategoryBean> categories) {
		for(CategoryBean currentCategory : categories) {
			if(currentCategory.getId().equals(id)) {
				return currentCategory;
			}
		}
		return null;
	}

	private CategoryBean getCategory(List<CategoryBean> categories, String[] ids, int position) {
		String categoryId = ids[position];

		CategoryBean cat = getCategory(categoryId, categories);
		if(cat == null) {
			return null;
		}
		int newPos = ++position;
		if(ids.length > newPos) {
			return getCategory(cat.getItems(), ids, newPos);
		}
		return cat;
	}

	@Override
	public CategorySchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new CategorySchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public MAINT_VALIDITY_TYPE getValidityType() {
		return this.validityType;
	}

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        return new CategorySchemeBeanDeferred(this);
    }
    
    @Override
    public CategorySchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new CategorySchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
