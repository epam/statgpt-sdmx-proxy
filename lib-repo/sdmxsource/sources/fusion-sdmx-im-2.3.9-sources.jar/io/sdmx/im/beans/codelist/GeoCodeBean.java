package io.sdmx.im.beans.codelist;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class GeoCodeBean extends CodeBeanImpl implements IGeoGridCodeBean {
	private static final long serialVersionUID = 1L;

	private String geoCell;

	public GeoCodeBean(IGeoGridCodelistBean parent, IGeoGridCodeMutableBean bean, int position) {
		super(parent, bean, position);
		this.geoCell = bean.getGeoCell();
		
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof IGeoGridCodeBean) {
			IGeoGridCodeBean that = (IGeoGridCodeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(geoCell, that.getGeoCell(), "Geo Cell", diff)) {
				returnVal =  false;
			}
			return super.deepEquals(bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(this.geoCell)) {
			throw new SdmxSemmanticException("Geogrid Code is missing required Geo Cell");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getGeoCell() {
		return geoCell;
	}


}
