package io.sdmx.im.beans.categoryscheme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MetricsBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.im.beans.items.ValidityPeriodItemBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;

public class CategoryBeanImpl extends ValidityPeriodItemBean implements CategoryBean {
	private static final Logger LOG = LoggerFactory.getLogger(CategoryBeanImpl.class);
	private static final long serialVersionUID = 14L;
	private List<CategoryBean> categories = new ArrayList<>();
	
	private transient boolean  metricsResolved = false;
	private transient boolean  hasMetrics = false;
	private transient Set<ICrossReferenceBean> linkedDataflowsWithData;
	private transient Integer seriesCount;
	private transient Date lastUpdated;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CategoryBeanImpl(IdentifiableBean parent, CategoryMutableBean bean, int postition) {
		super(bean, parent, postition, bean.getSdmxPeriod().orElse(null));
		if(bean.getItems() != null) {
			int i = 1;
			for(CategoryMutableBean currentCat : bean.getItems()) {
				categories.add(new CategoryBeanImpl(this, currentCat, i));
				i++;
			}
		}
		categories = Collections.unmodifiableList(categories);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			CategoryBean that = (CategoryBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(categories, that.getItems(), includeFinalProperties, "Category", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal((ValidityPeriodBean)that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return CategoryBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<CategoryBean> getURN() {
		return (IURNAbsolute<CategoryBean>) super.getURN();
	}
	
	@Override
	public List<CategoryBean> getItems() {
		return categories;
	}
	
	@Override
	public boolean isHierarchyExplicit() {
		return true;
	}
	

	@Override
	public boolean hasMetrics() {
		resolveMetrics();
		return hasMetrics;
	}


	@Override
	public Set<ICrossReferenceBean> getLinkedDataflowsWithData() {
		resolveMetrics();
		return linkedDataflowsWithData;
	}


	@Override
	public Integer getSeriesCount() {
		resolveMetrics();
		return seriesCount;
	}


	@Override
	public Date getLastUpdated() {
		resolveMetrics();
		return lastUpdated;
	}
	
	private void resolveMetrics() {
		if(metricsResolved) {
			return;
		}
		for(AnnotationBean annotation : getAnnotationsByType(MetricsBean.METRICS_ANNOTATION_TYPE)) {
			hasMetrics = true;
			if(!ObjectUtil.validCollection(annotation.getText())) {
				continue;
			}
			String annotationText = annotation.getText().get(0).getValue();
			linkedDataflowsWithData = new HashSet<>();
			try {
				if(annotation.getTitle() != null) {
					switch(annotation.getTitle()) {
					case MetricsBean.DATAFLOW_ANNOTATION_TITLE :
						String dataflowUrn = SDMX_STRUCTURE_TYPE.DATAFLOW.getUrnPrefix() + annotationText;
						linkedDataflowsWithData.add(CrossReferenceBean.build(this, dataflowUrn, DataflowBean.class));
						break;
					case MetricsBean.LAST_UPDATED_ANNOTATION_TITLE :
						this.lastUpdated = new Date(Long.parseLong(annotationText));
						break;
					case MetricsBean.SERIES_COUNT_ANNOTATION_TITLE :
						this.seriesCount = Integer.parseInt(annotationText);
						break;
					}
				}
			} catch(Throwable th) {
				LOG.error("Error processing metrics annotation:"+annotation.getTitle() + " with text:"+annotationText, th);
			}
		}
		metricsResolved = true;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES                           //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public Set<SDMXBean> getCompositesInternal() {
	    Set<SDMXBean> composites = super.getCompositesInternal();
	    super.addToCompositeSet(categories, composites);
	    return composites;
	}

}
