package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;

public class CategorySchemeMapBeanDeferred extends GenericItemSchemeMapBeanDeferred<ICategoryMapBean, ICategorySchemeMapBean> implements ICategorySchemeMapBean {
    private static final long serialVersionUID = 1L;

    public CategorySchemeMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public CategorySchemeMapBeanDeferred(ICategorySchemeMapBean maint) {
        super(maint);
    }
    
    @Override
    public ICategorySchemeMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CategorySchemeMapBean(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected CategorySchemeMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new CategorySchemeMapBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ICategorySchemeMapBean> getURN() {
        return (IURNMaintainable<ICategorySchemeMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ICategorySchemeMapBean.class;
    }

    @Override
    public ICategorySchemeMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
