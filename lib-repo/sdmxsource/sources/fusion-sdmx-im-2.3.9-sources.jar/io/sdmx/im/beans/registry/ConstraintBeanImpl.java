package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class ConstraintBeanImpl extends MaintainableBeanImpl implements ConstraintBean {
	private static final long serialVersionUID = 183L;
	private ConstraintDataKeySetBean includedSeriesKeys;
	private ConstraintDataKeySetBean excludedSeriesKeys;


	protected ConstraintAttachmentBean constraintAttachment;

	public ConstraintBeanImpl(MaintainableBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public ConstraintBeanImpl(ConstraintMutableBean bean) {
		super(bean);
		if (bean.getIncludedSeriesKeys() != null &&
				bean.getIncludedSeriesKeys().getConstrainedDataKeys() != null &&
				bean.getIncludedSeriesKeys().getConstrainedDataKeys().size() > 0) {
			this.includedSeriesKeys = new ConstraintDataKeySetBeanImpl(bean.getIncludedSeriesKeys(), true, this);
		}
		if (bean.getExcludedSeriesKeys() != null &&
				bean.getExcludedSeriesKeys().getConstrainedDataKeys() != null &&
				bean.getExcludedSeriesKeys().getConstrainedDataKeys().size() > 0) {
			this.excludedSeriesKeys = new ConstraintDataKeySetBeanImpl(bean.getExcludedSeriesKeys(), false, this);
		}
		if (bean.getConstraintAttachment() != null) {
			this.constraintAttachment = new ConstraintAttachmentBeanImpl(bean.getConstraintAttachment(), this);
		}
		if(this.getMaintainableParent().isExternalReference()) {
			return;
		}
		validate();
	}

	protected boolean deepEqualsInternal(ConstraintBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ConstraintBean that = bean;
			boolean returnVal = true;
			if(!super.equivalent(includedSeriesKeys, that.getIncludedSeriesKeys(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(excludedSeriesKeys, that.getExcludedSeriesKeys(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(constraintAttachment, that.getConstraintAttachment(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	private void validate() {
		if(includedSeriesKeys != null && !ObjectUtil.validCollection(includedSeriesKeys.getConstrainedDataKeys())) {
			this.includedSeriesKeys = null;
		}
		if(excludedSeriesKeys != null && !ObjectUtil.validCollection(excludedSeriesKeys.getConstrainedDataKeys())) {
			this.excludedSeriesKeys = null;
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(includedSeriesKeys, composites);
		super.addToCompositeSet(excludedSeriesKeys, composites);
		super.addToCompositeSet(constraintAttachment, composites);
		return composites;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public ConstraintAttachmentBean getConstraintAttachment() {
		return constraintAttachment;
	}

	@Override
	public ConstraintDataKeySetBean getIncludedSeriesKeys() {
		return includedSeriesKeys;
	}

	@Override
	public ConstraintDataKeySetBean getExcludedSeriesKeys() {
		return excludedSeriesKeys;
	}
}
