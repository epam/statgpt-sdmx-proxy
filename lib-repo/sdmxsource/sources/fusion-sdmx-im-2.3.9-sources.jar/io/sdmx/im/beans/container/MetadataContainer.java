package io.sdmx.im.beans.container;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.IMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public abstract class MetadataContainer implements IMetadataContainer {
	private static final long serialVersionUID = 1L;
	private String id = UUID.randomUUID().toString();
	private DATASET_ACTION action = DATASET_ACTION.INFORMATION;  //If Header is not available
	private HeaderBean header;
	private List<ILinkBean> links = null;
	
	
	@Override
	public List<ILinkBean> getLinks() {
		if(links == null) {
			links = new ArrayList<>();
		}
		return this.links;
	}

	@Override
	public void addLink(ILinkBean link) {
		getLinks().add(link);
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public DATASET_ACTION getAction() {
		return action;
	}

	@Override
	public void setAction(DATASET_ACTION action) {
		this.action = action;
	}

	@Override
	public HeaderBean getHeader() {
		return header;
	}

	@Override
	public void setHeader(HeaderBean header) {
		this.header = header;
	}
	
	@Override
	public Set<String> getAllLocales() {
		Set<String> returnSet = new TreeSet<>();
		getAllMaintainables().stream().flatMap(b -> b.getSupportedLanguages().stream())
		.distinct()
		.forEach(locale -> {
			returnSet.add(locale);
		});
		return returnSet;
	}
	
	protected abstract Set<MaintainableBean> getAllMaintainables();

}
