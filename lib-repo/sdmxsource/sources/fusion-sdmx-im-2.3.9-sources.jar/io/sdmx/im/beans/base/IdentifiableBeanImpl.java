package io.sdmx.im.beans.base;

import java.lang.ref.SoftReference;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_URN;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.structure.ValidationUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.VersionRef;

public abstract class IdentifiableBeanImpl extends AnnotableBeanImpl implements IdentifiableBean {
    private static final long serialVersionUID = 19L;
    private String id;
    private List<ILinkBean> links;
    URI uri;
    private transient ISDMXStructureType<?, ?> stuctureClass;
    private transient SoftReference<IURNAbsolute<?>> iurn;
    private transient int hashCode = 0;  //leave as 0 as this is also the deserialised value

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected IdentifiableBeanImpl(IdentifiableBean bean, boolean completeStub) {
        super(bean, completeStub);
        this.id = bean.getId();
        this.uri = bean.getUri();
        this.links = bean.getLinks();
        validateIdentifiableAttributes();
//        completeConstruction();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEAN              //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected IdentifiableBeanImpl(IdentifiableMutableBean bean, SdmxStructureBean parent) {
        super(bean, parent);
        setId(bean.getId());
        setUri(bean.getUri());
        if(bean.getLinks() != null) {
        	for(ILinkBean link : bean.getLinks()) {
        		String rel = link.getRel();
        		if(!"self".equals(rel)) {
        			if(this.links == null) {
        				this.links = new ArrayList<>();
        			}
        			this.links.add(link);
        		}
        	}
        }
        validateIdentifiableAttributes();
//        completeConstruction();
    }
//
//    /**
//     * Sets the URN - allows an override to defer this action if required
//     */
//    protected void completeConstruction() {
//        this.urn = getUrn();
//    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected void validateIdentifiableAttributes() throws SdmxSemmanticException {
    	 //TODO URN will fail to build
    	//getURN();  //Ensure the URN can be built
        if(parent == null && !this.getStructureClass().isMaintainable()) {
            throw new SdmxSemmanticException(ExceptionCode.JAVA_REQUIRED_OBJECT_NULL, "parent");
        }
        if(links == null) {
        	links = Collections.emptyList();
        }
        validateId(true);
    }

    protected void validateId(boolean startWithIntAllowed) {
        if(!ObjectUtil.validString(this.getId())) {
            throw new SdmxSemmanticException(ExceptionCode.STRUCTURE_IDENTIFIABLE_MISSING_ID, this.getStructureName());
        }
        this.id = ValidationUtil.cleanAndValidateId(getId(), startWithIntAllowed);
        this.id = StringUtil.manualIntern(id);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS                          //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected boolean deepEqualsInternal(IdentifiableBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        boolean returnVal = true;
        if(!super.equivalent(id, bean.getId(), "Id", diff)) {
            returnVal = false;
        }
        if(includeFinalProperties) {
            //If we don't want to test the final properties, then the URI can be ignored, as this can change
            if(!super.equivalent(uri, bean.getUri(), "URI", diff)) {
                returnVal = false;
            }
        }
        if(!super.equivalentCollection(this, this.links, bean.getLinks(), "links", diff)) {
            returnVal = false;
        }
        if(!ThreadLocalUtil.contains("DIFF")) {
            if(!super.equivalent(getUrn(), bean.getUrn(), "URN", diff)) {
                returnVal = false;
            }
        }
        return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
    }

    /**
     * @return not null, the URN prefix for this structure, required to generate the URN
     */
    protected String getURNPrefix() {
    	return SDMX_URN.SDMX_NAMESPACE;
    }

	protected String getURNPackageName() {
		if(getStructureType().isIdentifiable()) {
			return getStructureType().getUrnPackage();
		}
		throw new RuntimeException("Non SDMX Structure Types must override getURNPackageName");
	}

	protected String getURNClassName() {
		if(getStructureType().isIdentifiable()) {
			return getStructureType().getUrnClass();
		}
		throw new RuntimeException("Non SDMX Structure Types must override getURNClassName");
	}
	
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS                              //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
	public String getStructureName() {
		return this.getStructureClass().toString();
	}

	@Override
	public IURNAbsolute<?> getURN() {
	    IURNAbsolute<?> urn = iurn != null ? iurn.get() : null;
    	if(urn == null) {
    	    urn = generateIURN();
    	    iurn = new SoftReference<IURNAbsolute<?>>(urn);
    	}
		return urn;
	}
	
	@Override
	public String getUrn() {
		return getURN().getURN();
	}

	protected IURNAbsolute<?> generateIURN() {
        List<String> parentIds = getParentIds(true);
        IMaintainableProperties maintProperties = getMaintainableParent().getMaintainableProperties();
        String ids[] = new String[parentIds.size()];
        parentIds.toArray(ids);
        
        
        return URN.builder().structure(getStructureClass()).
        			  				   maint(maintProperties).
        			  				   identifableId(ids).buildAbsolute();
    }
    
	@Override
	public ISDMXStructureType<?, ?> getStructureClass() {
		if(this.stuctureClass == null) {
			this.stuctureClass = StructureTypes.getAnyStructureType(getConcreteInterface());
		}
		return this.stuctureClass;
	}
	
	/**
	 * @param <T>
	 * @return the interface type that this class belongs to, i.e. DataflowBean.class or CodeBean.class
	 */
	protected abstract <T extends IdentifiableBean> Class<T> getConcreteInterface();

	@Override
    public String getId() {
        return id;
    }

    @Override
	public List<ILinkBean> getLinks() {
		return this.links;
	}

	protected void setId(String id) {
        this.id = StringUtil.manualIntern(id);
    }

    private void setUri(String uriStr) {
        if(uriStr == null) {
            this.uri = null;
            return;
        }
        try {
            this.uri = new URI(uriStr);
        } catch(Throwable th) {
            throw new SdmxSemmanticException("Could not create attribute 'uri' with value '"+uriStr+"'");
        }
    }

    @Override
    public URI getUri() {
        return uri;
    }

    @Override
    public String getKey() {
    	if(ThreadLocalUtil.contains("DIFF")) {
    		IURN<?> thisUrn = getURN();
    		IURN<?> wildcardVersion = URN.builder().urn(thisUrn).versionRef(VersionRef.ALL).build();
            return wildcardVersion.getURN();
        }
        return getUrn();
    }

    @Override
    public String getFullIdPath(boolean includeDifferentTypes) {
        if(!this.getStructureClass().isMaintainable()) {
            List<String> parentIds = getParentIds(includeDifferentTypes);
            String returnId = "";
            String concat = "";
            for(String currentId : parentIds) {
                returnId += concat + currentId;
                concat  = ".";
            }
            return returnId;
        }
        return null;
    }

//    @Override
//    public String getUrn() {
//        if(urn == null) {
//            urn = getUrn(false);
//        }
//        return urn;
//    }

//    private String getUrn(boolean ignoreVersion) {
//        List<String> parentIds = getParentIds(true);
//        MaintainableBean maintainableParent = getMaintainableParent();
//        String ids[] = new String[parentIds.size()];
//        parentIds.toArray(ids);
//        if(ignoreVersion) {
//            if(diffUrn == null) {
//                diffUrn = structureType.generateUrn(maintainableParent.getAgencyId(), maintainableParent.getId(), "1.0", ids);
//            }
//            return diffUrn;
//        }
//        urn = structureType.generateUrn(maintainableParent.getAgencyId(), maintainableParent.getId(), maintainableParent.getVersion(), ids);
//        return urn;
//    }

    /**
     * Returns a list of ids for each identifiable (non-maintainable parent), starting from the top level (index 0 of list) to this level (index 0+X)
     * @return
     */
    protected List<String> getParentIds(boolean includeDifferentTypes) {
        List<String> parentIds = new ArrayList<>();
        if(!this.getStructureClass().isMaintainable()) {
            parentIds.add(this.getId());
            IdentifiableBean currentParent= getIdentifiableParent();
            while(currentParent != null) {
                if(!includeDifferentTypes && this.getStructureClass() != currentParent.getStructureClass()) {
                    break;
                }
                if(!currentParent.getStructureClass().isMaintainable()) {
                    parentIds.add(currentParent.getId());
                    currentParent = currentParent.getIdentifiableParent();
                } else {
                    break;
                }
            }
        }
        Collections.reverse(parentIds);
        return parentIds;
    }

    @Override
    public List<TextTypeWrapper> getAllTextTypes() {
        List<TextTypeWrapper> returnList = new ArrayList<>();
        for(AnnotationBean annotation : getAnnotations()) {
            returnList.addAll(annotation.getText(true));
        }
        return returnList;
    }


    @Override
    public String getShortURN() {
        return getUrn().split("=")[1];
    }

    /**
     * This method should not be overriden, if you want to check if something is equal, other than checking just the URN, use deepEquals
     */
    @Override
    public final boolean equals(Object obj) {
        if(obj instanceof IdentifiableBean) {
            IdentifiableBean that = (IdentifiableBean)obj;
            return that.getUrn().equals(this.getUrn());
        }
        return false;
    }

    @Override
    public String toString() {
        try {
            return getUrn();
        } catch(Throwable th) {
            StringBuilder sb = new StringBuilder();
            sb.append("\nId: " + getId());
            return sb.toString();
        }
    }

    /**
     * as the equals method is final, overriding hashcode is also final
     */
    @Override
    public final int hashCode() {
        if(hashCode == 0) {
            hashCode = getUrn().hashCode();
        }
        return hashCode;
    }
}
