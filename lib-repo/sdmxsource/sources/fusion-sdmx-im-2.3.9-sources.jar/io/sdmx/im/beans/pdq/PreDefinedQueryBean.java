package io.sdmx.im.beans.pdq;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryBean;
import io.sdmx.api.sdmx.model.beans.pdq.IPreDefinedQueryComponentFilterBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryComponentFilterMutableBean;
import io.sdmx.api.sdmx.model.mutable.pdq.IPreDefinedQueryMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.format.FusionMetadataStandard;
import io.sdmx.im.mutable.pdq.PreDefinedQueryMutableBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class PreDefinedQueryBean extends MaintainableBeanImpl implements IPreDefinedQueryBean {
	private static final long serialVersionUID = 1L;
	private Set<IDirectCrossReferenceBean<DataflowBean>> dataflow = new HashSet<>();
	private List<IPreDefinedQueryComponentFilterBean> selections = new ArrayList<>();
	private Set<String> series = new HashSet<>();
	private Map<String, String> parameters = new TreeMap<>();
	private boolean isVirtualFlow;
	
	PreDefinedQueryBean(IPreDefinedQueryBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public PreDefinedQueryBean(IPreDefinedQueryMutableBean bean) {
		super(bean);
		this.isVirtualFlow = bean.isVirtualFlow();
		
		Set<IDirectCrossReferenceBean<DataflowBean>> sorted = new TreeSet<>(new Comparator<IDirectCrossReferenceBean<DataflowBean>>() {

			@Override
			public int compare(IDirectCrossReferenceBean<DataflowBean> arg0, IDirectCrossReferenceBean<DataflowBean> arg1) {
				return arg0.getTargetUrn().compareTo(arg1.getTargetUrn());
			}
		
		});
		this.dataflow = new LinkedHashSet<>(sorted);
		for(StructureReferenceBean xsRef : bean.getDataflow()) {
			this.dataflow.add(DirectCrossReferenceBean.build(this, "dataflow", xsRef, DataflowBean.class));
		}
		for(IPreDefinedQueryComponentFilterMutableBean filter : bean.getSelections()) {
			this.selections.add(new PreDefinedQueryComponentFilterBean(filter, this));
		}
		if(bean.getSeries() != null) {
			this.series = new HashSet<>(bean.getSeries());
		}
		if(bean.getParameters() != null) {
			this.parameters.putAll(bean.getParameters());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(this.dataflow.size() == 0) {
			throw new SdmxSemmanticException("Predefined Query must define at least 1 Dataflow");
		}
		if(this.selections.size() == 0 && series.size() == 0) {
			throw new SdmxSemmanticException("Predefined Query must define at least 1 Filter or Series selection");
		}
		this.dataflow = Collections.unmodifiableSet(this.dataflow);
		this.selections = Collections.unmodifiableList(this.selections);
		this.series = Collections.unmodifiableSet(this.series);
		this.parameters = Collections.unmodifiableMap(this.parameters);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IPreDefinedQueryBean.class;
	}
	
	@Override
	public IMetadataStandard getDefaultStandard() {
		return FusionMetadataStandard.getInstance();
	}

	@Override
	public IPreDefinedQueryBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new PreDefinedQueryBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IPreDefinedQueryMutableBean getMutableInstance() {
		return new PreDefinedQueryMutableBean(this);
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		boolean returnVal = true;
		IPreDefinedQueryBean that = (IPreDefinedQueryBean) bean;
		if(!super.equivalent(this.dataflow, that.getDataflow(), diff)) {
			returnVal = false;
		}
		if(!super.equivalent(this.isVirtualFlow, that.isVirtualFlow(), "virtual flow", diff)) {
			returnVal = false;
		}
		if(!super.equivalentCollection(this, this.selections, that.getSelections(), "filter selections", diff)) {
			returnVal = false;
		}
		if(!super.equivalentCollection(this, this.series, that.getSeries(), "series", diff)) {
			returnVal = false;
		}
		if(!super.equivalentMap(this, this.parameters, that.getParameters(), "parameters", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<IPreDefinedQueryBean> getURN() {
		return (IURNMaintainable<IPreDefinedQueryBean>)super.getURN();
	}
	
	@Override
	public Set<IDirectCrossReferenceBean<DataflowBean>> getDataflow() {
		return dataflow;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.addAll(dataflow);
	}

	@Override
	public boolean isVirtualFlow() {
		return isVirtualFlow;
	}

	@Override
	public List<IPreDefinedQueryComponentFilterBean> getSelections() {
		return selections;
	}

	@Override
	public Set<String> getSeries() {
		return series;
	}

	@Override
	public Map<String, String> getParameters() {
		return parameters;
	}

    @Override
    public PreDefinedQueryBeanDeferred toDeferred() {
        return new PreDefinedQueryBeanDeferred(this);
    }

    @Override
    public PreDefinedQueryBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new PreDefinedQueryBeanDeferred(getDeferredDefinition(), loader);
    }
}
