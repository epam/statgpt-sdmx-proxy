package io.sdmx.im.beans.conceptscheme;

import java.net.URL;
import java.util.Collection;
import java.util.Date;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class ConceptSchemeBeanDeferred extends ItemSchemeBeanDeffered<ConceptBean, ConceptSchemeBean> implements ConceptSchemeBean {
    private static final long serialVersionUID = 1L;
    private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

    public ConceptSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
        String validityPeriodType = bean.getProperties().get("VPType");
        if(validityPeriodType != null) {
            this.validityType = MAINT_VALIDITY_TYPE.getValidityType(validityPeriodType);
        }
    }
    
    public ConceptSchemeBeanDeferred(ConceptSchemeBean cs) {
        super(cs);
        this.validityType = cs.getValidityType();
    }
    
    @Override
    public ConceptSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ConceptSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected ConceptSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ConceptSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ConceptSchemeBean> getURN() {
        return (IURNMaintainable<ConceptSchemeBean>) super.getURN();
    }
    
    @Override
    public ConceptSchemeBean cloneForDate(Date date) {
        return (ConceptSchemeBean)super.cloneForDate(date);
    }

    @Override
    public ConceptSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
    
    @Override
    public ConceptSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return (ConceptSchemeBean)super.filterItems(filterIds, isKeepSet);
    }
    
    @Override
    public MAINT_VALIDITY_TYPE getValidityType() {
        return validityType;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ConceptSchemeBean.class;
    }

    @Override
    public boolean createdFromTimeRequest() {
        return load().createdFromTimeRequest();
    }
}
