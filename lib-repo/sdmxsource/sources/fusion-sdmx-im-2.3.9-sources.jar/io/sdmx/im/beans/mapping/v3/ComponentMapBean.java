package io.sdmx.im.beans.mapping.v3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * Maps one or more source components to one or more target components between two DSDs referenced by the {@link StructureMapBean}
 */
public class ComponentMapBean extends AnnotableBeanImpl implements IComponentMapBean {
	private static final long serialVersionUID = 1L;
	private List<String> sourceComponents = Collections.emptyList();
	private List<String> targetComponents = Collections.emptyList();
	private IDirectCrossReferenceBean<IRepresentationMapBean> representationMapRef;
	private String key;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ComponentMapBean(IComponentMapMutableBean bean, IStructureMapBean parent) {
		super(bean, parent);
		if(bean.getSourceComponents() != null) {
			this.sourceComponents = new ArrayList<>(bean.getSourceComponents());
		}
		if(bean.getTargetComponents() != null) {
			this.targetComponents = new ArrayList<>(bean.getTargetComponents());
		}
		if(bean.getRepresentationMapRef() != null) {
			representationMapRef = DirectCrossReferenceBean.build(parent,  "representationmap", bean.getRepresentationMapRef(), IRepresentationMapBean.class);
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validCollection(sourceComponents)) {
			throw new SdmxSemmanticException("Component Map missing source component");
		}

		if(!ObjectUtil.validCollection(targetComponents)) {
			throw new SdmxSemmanticException("Component Map missing target component");
		}
		if(representationMapRef != null && representationMapRef.getTargetReference() != SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP) {
			throw new SdmxSemmanticException("Component Map illegal reference '"+representationMapRef.getTargetUrn()+"'. Expecting a reference to a Representation Map");
		}
		
		sourceComponents = Collections.unmodifiableList(sourceComponents);
		targetComponents = Collections.unmodifiableList(targetComponents);
		
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(String concept : sourceComponents) {
			sb.append(concat+ concept);
			concat = ":";
		}
		sb.append("-");
		concat = "";
		for(String concept : targetComponents) {
			sb.append(concat + concept);
			concat = ":";
		}
		this.key = sb.toString();
	}
	
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ComponentMapBean that = (ComponentMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalentCollection(this, sourceComponents, that.getSourceComponents(), Properties.SOURCE_COMPONENTS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, targetComponents, that.getTargetComponents(), Properties.TARGET_COMPONENTS.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(representationMapRef, that.getRepresentationMapRef(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	

	@Override
	public String getKey() {
		return key;
	}
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(representationMapRef != null) {
			references.add(representationMapRef);
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<String> getSourceComponents() {
		return sourceComponents;
	}

	@Override
	public List<String> getTargetComponents() {
		return targetComponents;
	}

	@Override
	public ICrossReferenceBean<IRepresentationMapBean> getRepresentationMapRef() {
		return representationMapRef;
	}
	

}
