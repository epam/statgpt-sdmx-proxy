package io.sdmx.im.beans.mapping;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.CodeReferenceableBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.CategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ConceptSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.OrganisationSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RelatedStructuresBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;

public class StructureSetBeanImpl extends MaintainableBeanImpl implements StructureSetBean {
	private static final Logger LOG = LoggerFactory.getLogger(StructureSetBeanImpl.class);
	private static final long serialVersionUID = 181L;

	private RelatedStructuresBean relatedStructures;
	private List<StructureMapBean> structureMapList=new ArrayList<>();
	private List<CodelistMapBean> codelistMapList= new ArrayList<>();
	private List<CategorySchemeMapBean> categorySchemeMapList = new ArrayList<>();
	private List<ConceptSchemeMapBean> conceptSchemeMapList = new ArrayList<>();
	private List<OrganisationSchemeMapBean> organisationSchemeMapList = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	StructureSetBeanImpl(StructureSetBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub StructureSetBean Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public StructureSetBeanImpl(StructureSetMutableBean structureSet) {
		super(structureSet);
		LOG.debug("Building StructureSetBean from Mutable Bean");
		try {
			if(structureSet.getRelatedStructures() != null) {
				this.relatedStructures = new RelatedStructuresBeanImpl(structureSet.getRelatedStructures(), this);
			}

			if(structureSet.getCodelistMapList() != null) {
				for (CodelistMapMutableBean each : structureSet.getCodelistMapList()) {
					this.codelistMapList.add(new CodelistMapBeanImpl(each, this));
				}
			}
			if(structureSet.getStructureMapList() != null) {
				for (StructureMapMutableBean each : structureSet.getStructureMapList()) {
					this.structureMapList.add(new StructureMapBeanImpl(each, this));
				}
			}
			if(structureSet.getCategorySchemeMapList() != null) {
				for (CategorySchemeMapMutableBean each : structureSet.getCategorySchemeMapList()) {
					this.categorySchemeMapList.add(new CategorySchemeMapBeanImpl(each, this));
				}
			}
			if(structureSet.getConceptSchemeMapList() != null) {
				for (ConceptSchemeMapMutableBean each : structureSet.getConceptSchemeMapList()) {
					this.conceptSchemeMapList.add(new ConceptSchemeMapBeanImpl(each, this));
				}
			}
			if(structureSet.getOrganisationSchemeMapList() != null) {
				for (OrganisationSchemeMapMutableBean each : structureSet.getOrganisationSchemeMapList()) {
					this.organisationSchemeMapList.add(new OrganisationSchemeMapBeanImpl(each, this));
				}
			}
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		}

		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("StructureSetBean Built " + this.getUrn());
		}
	}
	
	@Override
	public String getUrn() {
		return getStructureType().generateUrn(getAgencyId(), getId(), getVersion().toString());
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			StructureSetBean that = (StructureSetBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(relatedStructures, that.getRelatedStructures(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(structureMapList, that.getStructureMapList(), includeFinalProperties, "Structure Map", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(codelistMapList, that.getCodelistMapList(), includeFinalProperties, "Codelist Map", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(categorySchemeMapList, that.getCategorySchemeMapList(), includeFinalProperties, "Category Scheme Map", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(conceptSchemeMapList, that.getConceptSchemeMapList(), includeFinalProperties, "Concept Scheme Map", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(organisationSchemeMapList, that.getOrganisationSchemeMapList(), includeFinalProperties, "Organisation Scheme Map", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		createUnModifiable();
	}

	private void createUnModifiable() {
		this.structureMapList = Collections.unmodifiableList(structureMapList);
		this.codelistMapList = Collections.unmodifiableList(codelistMapList);
		this.conceptSchemeMapList = Collections.unmodifiableList(conceptSchemeMapList);
		this.categorySchemeMapList = Collections.unmodifiableList(categorySchemeMapList);
		this.organisationSchemeMapList = Collections.unmodifiableList(organisationSchemeMapList);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return StructureSetBean.class;
	}
	
	@Override
	public StructureSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new StructureSetBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public StructureSetMutableBean getMutableInstance() {
		return new StructureSetMutableBeanImpl(this);
	}

	@Override
	public RelatedStructuresBean getRelatedStructures() {
		return relatedStructures;
	}

	@Override
	public List<StructureMapBean> getStructureMapList() {
		return structureMapList;
	}

	@Override
	public CodelistMapBean getCodelistMap(String id) {
		for(CodelistMapBean clMap : codelistMapList) {
			if(clMap.getId().equals(id)) {
				return clMap;
			}
		}
		return null;
	}

	@Override
	public List<CodelistMapBean> getCodelistMapList() {
		return codelistMapList;
	}

	@Override
	public List<CategorySchemeMapBean> getCategorySchemeMapList() {
		return categorySchemeMapList;
	}

	@Override
	public List<ConceptSchemeMapBean> getConceptSchemeMapList() {
		return conceptSchemeMapList;
	}

	@Override
	public List<OrganisationSchemeMapBean> getOrganisationSchemeMapList() {
		return organisationSchemeMapList;
	}

	@Override
	public StructureSetBean cloneForDate(Date aDate) {
		StructureSetMutableBean clone = this.getMutableInstance().stripItems(aDate);
		if (clone.getCodelistMapList().size() == 0) {
			throw new SdmxSemmanticException("CodelistMap has no CodeMaps when querying for date: " + aDate);
		}
		return clone.getImmutableInstance();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(relatedStructures, composites);
		super.addToCompositeSet(structureMapList, composites);
		super.addToCompositeSet(codelistMapList, composites);
		super.addToCompositeSet(categorySchemeMapList, composites);
		super.addToCompositeSet(conceptSchemeMapList, composites);
		super.addToCompositeSet(organisationSchemeMapList, composites);
		return composites;
	}

	@Override
	@Deprecated //double deprecated as the structure set is only preserved to provide the means to get a StructureMap
	public CodeReferenceableBean cloneItemWithCodeFilter(Set<String> codeUrnsToRemove, SdmxBeanRetrievalManager beanRet) {
		throw new SdmxNotImplementedException("Deprecated feature");
	}

    @Override
    public StructureSetBeanDeferred toDeferred() {
        return new StructureSetBeanDeferred(this);
    }

    @Override
    public IMaintainableBeanDeferred<?> toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new StructureSetBeanDeferred(getDeferredDefinition(), loader);
    }
}