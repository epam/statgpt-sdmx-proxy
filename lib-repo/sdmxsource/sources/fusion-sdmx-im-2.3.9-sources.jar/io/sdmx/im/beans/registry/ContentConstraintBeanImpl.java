package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ContentConstraintBeanImpl extends ConstraintBeanImpl implements ContentConstraintBean {
	private transient static final Logger LOG = LoggerFactory.getLogger(ContentConstraintBeanImpl.class);

	private static final long serialVersionUID = 184L;

	private CubeRegionBean includedCubeRegion;
	private CubeRegionBean excludedCubeRegion;

	private ReferencePeriodBean referencePeriodBean;
	private ReleaseCalendarBean releaseCalendarBean;
	private boolean isDefiningActualDataPresent = true;  //Default Value
	private boolean isCubeRegion;

	private MetadataTargetRegionBean metadataTargetRegionBean;
	
	
	private transient Set<KeyValues> restrictedComponents;
	
	static transient final String PROP_IS_DEFINING_DATA = "isDefiningData";
    static transient final String PROP_IS_CUBE_REGION = "isCubeRegion";

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	ContentConstraintBeanImpl(ContentConstraintBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		isDefiningActualDataPresent = bean.isDefiningActualDataPresent();
		isCubeRegion = bean.getIncludedCubeRegion() != null || bean.getExcludedCubeRegion() != null;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ContentConstraintBean getInstance(ContentConstraintMutableBean bean) {
		if(bean.getReleaseCalendar() != null) {
			return new AdvancedReleaseCalendarBeanImpl(bean);
		}
		if(bean.getIsDefiningActualDataPresent()) {
			return new ActualContentConstraint(bean);
		}
		return new AllowedContentConstraint(bean);
	}
	
	ContentConstraintBeanImpl(ContentConstraintMutableBean mutable) {
		super(mutable);
		if(mutable.getIncludedCubeRegion() != null &&
				(ObjectUtil.validCollection(mutable.getIncludedCubeRegion().getKeyValues()) ||
						ObjectUtil.validCollection(mutable.getIncludedCubeRegion().getAttributeValues()))) {
			this.includedCubeRegion = new CubeRegionBeanImpl(mutable.getIncludedCubeRegion(), this);
		}
		if(mutable.getExcludedCubeRegion() != null &&
				(ObjectUtil.validCollection(mutable.getExcludedCubeRegion().getKeyValues()) ||
						ObjectUtil.validCollection(mutable.getExcludedCubeRegion().getAttributeValues()))) {
			this.excludedCubeRegion = new CubeRegionBeanImpl(mutable.getExcludedCubeRegion(), this);
		}

		if (mutable.getReferencePeriod() != null) {
			this.referencePeriodBean = new ReferencePeriodBeanImpl(mutable.getReferencePeriod(), this);
		}
		if (mutable.getReleaseCalendar() != null) {
			this.releaseCalendarBean = new ReleaseCalendarBeanImpl(mutable.getReleaseCalendar(), this);
		}
		if (mutable.getMetadataTargetRegion() != null) {
			this.metadataTargetRegionBean = new MetadataTargetRegionBeanImpl(mutable.getMetadataTargetRegion(), this);
		}
		this.isDefiningActualDataPresent = mutable.getIsDefiningActualDataPresent();

		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	@Override
	public boolean isConstrainingComponent(String componentId) {
		if(hasIncludedCubeRegion()) {
			if(getIncludedCubeRegion().getKeyValues(componentId) != null) {
				return true;
			}
		}
		if(hasExcludedCubeRegion()) {
			if(getExcludedCubeRegion().getKeyValues(componentId) != null) {
				return true;
			}
		}
		if(hasIncludedSeries()) {
			for(ConstrainedDataKeyBean key : getIncludedSeriesKeys().getConstrainedDataKeys()) {
				if(key.getKeyValue(componentId) != null) {
					return true;
				}
			}
		}
		if(hasExcludedSeries()) {
			for(ConstrainedDataKeyBean key : getExcludedSeriesKeys().getConstrainedDataKeys()) {
				if(key.getKeyValue(componentId) != null) {
					return true;
				}
			}
		}
		return false;
	}
	
	@Override
	public boolean isBusinessValidity() {
		Set<AnnotationBean> annnotations = getAnnotationsByTitle("FR_TIME_VALIDITY");
		for(AnnotationBean currentAnnotation : annnotations) {
			if("TRANSACTION".equals(currentAnnotation.getType())) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public boolean isCubeRegion() {
		if(this.isStub()) {
			return isCubeRegion;
		}
		return getIncludedCubeRegion() != null || getExcludedCubeRegion() != null;
	}

	@Override
	public boolean hasIncludedSeries() {
		return getIncludedSeriesKeys() != null;
	}

	@Override
	public boolean hasExcludedSeries() {
		return getExcludedSeriesKeys() != null;
	}

	@Override
	public boolean hasExcludedCubeRegion() {
		return getExcludedCubeRegion() != null;
	}

	@Override
	public boolean hasIncludedCubeRegion() {
		return getIncludedCubeRegion() != null;
	}

	@Override
	public MetadataTargetRegionBean getMetadataTargetRegion() {
		return metadataTargetRegionBean;
	}


	@Override
	public Set<KeyValues> getRestrictedComponents() {
		if(restrictedComponents == null) {
			restrictedComponents = new HashSet<>();
			if(includedCubeRegion != null) {
				restrictedComponents.addAll(includedCubeRegion.getKeyValues());
				restrictedComponents.addAll(includedCubeRegion.getAttributeValues());
			}
			if(excludedCubeRegion != null) {
				restrictedComponents.addAll(excludedCubeRegion.getKeyValues());
				restrictedComponents.addAll(excludedCubeRegion.getAttributeValues());
			}
			restrictedComponents = Collections.unmodifiableSet(restrictedComponents);
		}
		return restrictedComponents;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ContentConstraintBean that = (ContentConstraintBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(getIncludedCubeRegion(), that.getIncludedCubeRegion(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(getExcludedCubeRegion(), that.getExcludedCubeRegion(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(referencePeriodBean, that.getReferencePeriod(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(releaseCalendarBean, that.getReleaseCalendar(), includeFinalProperties,  diff)) {
				returnVal = false;
			}
			if(isDefiningActualDataPresent != that.isDefiningActualDataPresent()) {
				if(diff != null) {
					diff.addDiff(this, "Constraint Type", isDefiningActualDataPresent ? "Actual" : "Allowed", that.isDefiningActualDataPresent() ? "Actual" : "Allowed");
				}
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if (isExternalReference) {
			return;
		}
		
		super.validateMaintainableAttributes();

		Map<String, Set<String>> includedCodesForKey = new HashMap<>();
		Set<String> wildcardedConcepts = new HashSet<>();

		
		if(getIncludedSeriesKeys() != null) {
			for(ConstrainedDataKeyBean cdkb : getIncludedSeriesKeys().getConstrainedDataKeys()) {
				for(KeyValue kv : cdkb.getKeyValues()) {
					if(kv.getCode().equals(ContentConstraintBean.WILDCARD_CODE)) {
						wildcardedConcepts.add(kv.getConcept());
						includedCodesForKey.remove(kv.getConcept());
					} else if(!wildcardedConcepts.contains(kv.getConcept())){
						Set<String> includedCodes = includedCodesForKey.get(kv.getConcept());
						if(includedCodes == null) {
							includedCodes = new HashSet<>();
							includedCodesForKey.put(kv.getConcept(), includedCodes);
						}
						includedCodes.add(kv.getCode());
					}
				}
			}
		}
		if(getIncludedCubeRegion() != null) {
			//Check we are not including any more / less then the series includes
			for(KeyValues kvs : getIncludedCubeRegion().getKeyValues()) {
				Set<String> allIncludes = includedCodesForKey.get(kvs.getId());
				if(allIncludes != null) {
					if(!allIncludes.containsAll(kvs.getValues()) || !kvs.getValues().containsAll(allIncludes)) {
						throw new SdmxSemmanticException("Constraint is in conflict with itself. The constraint defines valid series, this can not be further restricted by the cube region.  The " +
								"Cube Region has further restricted dimension '"+kvs.getId()+"' by not including all the codes defined by the keyset.");
					}
				}
				if(getExcludedCubeRegion() != null) {
					validateNoKeyValuesDuplicates(kvs, getExcludedCubeRegion().getKeyValues());
				}
			}
		}
		if(getExcludedCubeRegion() != null) {
			for(KeyValues kvs : getExcludedCubeRegion().getKeyValues()) {
				Set<String> allIncludes = includedCodesForKey.get(kvs.getId());
				if(allIncludes != null) {
					throw new SdmxSemmanticException("Constraint is in conflict with itself. The constraint defines valid series, the dimension  '"+kvs.getId()+"' can not be further restriced by the cube region to " +
							"exclude codes which are already marked for inclusion by the keyset");
				}
				if(getIncludedCubeRegion() != null) {
					validateNoKeyValuesDuplicates(kvs, getIncludedCubeRegion().getKeyValues());
				}
			}
		}

	}

	private void validateNoKeyValuesDuplicates(KeyValues kvs, List<KeyValues> kvsList) {
		for(KeyValues currentKvs : kvsList) {
			if(currentKvs.getId().equals(kvs.getId())) {
				for(String currentValue : currentKvs.getValues()) {
					if(kvs.getValues().contains(currentValue)) {
						throw new SdmxSemmanticException("CubeRegion contains a Key Value that is both included and excluded Id='"+kvs.getId()+"' Value='"+currentValue+"'");
					}
				}
			}
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ContentConstraintBean.class;
	}
	
	@Override
	public ContentConstraintBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ContentConstraintBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ContentConstraintMutableBean getMutableInstance() {
		return new ContentConstraintMutableBeanImpl(this);
	}

	@Override
	public CubeRegionBean getIncludedCubeRegion() {
		return includedCubeRegion;
	}

	@Override
	public CubeRegionBean getExcludedCubeRegion() {
		return excludedCubeRegion;
	}

	@Override
	public ReferencePeriodBean getReferencePeriod() {
		return referencePeriodBean;
	}

	@Override
	public ReleaseCalendarBean getReleaseCalendar() {
		return releaseCalendarBean;
	}

	@Override
	public boolean isDefiningActualDataPresent() {
		return isDefiningActualDataPresent;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(includedCubeRegion, composites);
        super.addToCompositeSet(excludedCubeRegion, composites);
        super.addToCompositeSet(referencePeriodBean, composites);
        super.addToCompositeSet(releaseCalendarBean, composites);
        super.addToCompositeSet(metadataTargetRegionBean, composites);
        return composites;
    }
    
    @Override
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
        builder.property(PROP_IS_DEFINING_DATA, isDefiningActualDataPresent());
        builder.property(PROP_IS_CUBE_REGION, isCubeRegion());
    }

    @Override
    public ContentConstraintBeanDeferred toDeferred() {
        return new ContentConstraintBeanDeferred(this);
    }
    
    @Override
    public ContentConstraintBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ContentConstraintBeanDeferred(getDeferredDefinition(), loader);
    }
}
