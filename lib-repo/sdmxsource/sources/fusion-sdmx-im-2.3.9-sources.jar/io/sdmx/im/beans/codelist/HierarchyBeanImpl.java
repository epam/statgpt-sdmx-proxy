package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class HierarchyBeanImpl extends MaintainableBeanImpl implements HierarchyBean {
	private static final long serialVersionUID = 14L;
	private List<HierarchicalCodeBean> codeRefs = new ArrayList<>();
	private LevelBean level;
	private boolean hasFormalLevels;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected HierarchyBeanImpl(HierarchyBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public HierarchyBeanImpl(HierarchyMutableBean hierarchy) {
		super(hierarchy);
		//LEVELS MUST BE SET BEFORE ANYTHING ELSE

		if(hierarchy.getChildLevel() != null) {
			this.level = new LevelBeanImpl(this, hierarchy.getChildLevel());
		}
		if(hierarchy.getHierarchicalCodeBeans() != null) {
			for(CodeRefMutableBean currentCoderef : hierarchy.getHierarchicalCodeBeans()) {
				codeRefs.add(new HierarchicalCodeBeanImpl(currentCoderef, this));
			}
		}
		this.hasFormalLevels = hierarchy.isFormalLevels();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			HierarchyBean that = (HierarchyBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(codeRefs, that.getHierarchicalCodeBeans(), includeFinalProperties, "Code Reference", diff)) {
				returnVal = false;
			}
			if (returnVal) {
				// Refs in the Hierarchy are the same but ensure the order is also the same
				returnVal = sameOrder(codeRefs, that.getHierarchicalCodeBeans(), "Hierarchical Code", diff);
			}
			if(!super.equivalent(level, that.getLevel(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(hasFormalLevels, that.hasFormalLevels(), "Has Formal Levels", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		codeRefs = Collections.unmodifiableList(codeRefs);
		if(hasFormalLevels) {
			validateHasLevel(codeRefs);
		}

		List<HierarchicalCodeBean> allCodeRefsFlat = getAllCodeRefsFlat(codeRefs);
		for (HierarchicalCodeBean childHcode : allCodeRefsFlat) {
			List<HierarchicalCodeBean> validityPeriodCodes = getValidityPeriods(childHcode, allCodeRefsFlat);
			SdmxDate thisValidFrom = childHcode.getValidFrom();
			SdmxDate thisValidTo = childHcode.getValidTo();
			if(thisValidFrom == null && thisValidTo == null){
				continue;
			}
			SdmxPeriod thisDatePeriod = new SdmxPeriodImpl(thisValidFrom, thisValidTo);
			for (HierarchicalCodeBean hierarchicalCodeBean : validityPeriodCodes) {
				SdmxDate validFrom = hierarchicalCodeBean.getValidFrom();
				SdmxDate validTo = hierarchicalCodeBean.getValidTo();
				if(validFrom == null && validTo == null){
					continue;
				}
				SdmxPeriod datePeriod = new SdmxPeriodImpl(validFrom, validTo);

				if(datePeriod.isInPeriod(thisDatePeriod)){
					throw new SdmxSemmanticException("The dates supplied overlaps with the validity period on this object");
				}

			}
		}
		for (HierarchicalCodeBean childHcode : allCodeRefsFlat) {
			SdmxStructureBean parent = childHcode.getParent();
			if(!(parent instanceof HierarchicalCodeBean)){
				continue;
			}
			do {
				SdmxDate thisValidFrom = childHcode.getValidFrom();
				SdmxDate thisValidTo = childHcode.getValidTo();
				if(thisValidFrom == null && thisValidTo == null){
					continue;
				}
				SdmxPeriod thisDatePeriod = new SdmxPeriodImpl(thisValidFrom, thisValidTo);
				List<HierarchicalCodeBean> validityPeriods = getValidityPeriods((HierarchicalCodeBean) parent, allCodeRefsFlat);
				validityPeriods.add((HierarchicalCodeBean) parent);
				for (HierarchicalCodeBean hierarchicalCodeBean : validityPeriods) {
					SdmxDate validFrom = hierarchicalCodeBean.getValidFrom();
					SdmxDate validTo = hierarchicalCodeBean.getValidTo();
					if(validFrom == null && validTo == null){
						continue;
					}
					SdmxPeriod datePeriod = new SdmxPeriodImpl(validFrom, validTo);

					if(!datePeriod.isFullyInPeriod(thisDatePeriod)){
						throw new SdmxSemmanticException("Validity period can not be wider than the parents validity period");
					}
				}
			}while((parent = parent.getParent()) != null && parent instanceof HierarchicalCodeBean);
		}
	}

	private List<HierarchicalCodeBean> getAllCodeRefsFlat(List<HierarchicalCodeBean> codeRefs){
		List<HierarchicalCodeBean> returnList = new ArrayList<>();
		for(HierarchicalCodeBean childHcode: codeRefs){
			returnList.add(childHcode);
			if(childHcode.hasChildren()){
				returnList.addAll(getAllCodeRefsFlat(childHcode.getCodeRefs()));
			}
		}

		return returnList;
	}

	private List<HierarchicalCodeBean> getValidityPeriods(HierarchicalCodeBean item, List<HierarchicalCodeBean> allItems){
		List<HierarchicalCodeBean> returnList = new ArrayList<>();
//		for (HierarchicalCodeBean childHcode : allItems) {
//			if(childHcode == item){
//				continue;
//			}
//			if(item.getLevelInHierarchy() != childHcode.getLevelInHierarchy()){
//				continue;
//			}
//			if(item.getParent() != childHcode.getParent()){
//				continue;
//			}
//			if(item.getCodeId().equals(childHcode.getCodeId())){
//				returnList.add(childHcode);
//			}
//		}
		return returnList;
	}

	private void validateHasLevel(List<HierarchicalCodeBean> codeRefs) {
		if(codeRefs != null) {
			for(HierarchicalCodeBean currentHCode : codeRefs) {
				validateHasLevel(currentHCode.getCodeRefs());
				if(currentHCode.getLevel(true) == null) {
					throw new SdmxSemmanticException("Hierarchy indicates formal levels, but Hierarchical Code '"+currentHCode.getUrn()+"' is missing a level reference and there is no default level for it's depth in the hierarchy");
				}
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return HierarchyBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<HierarchyBean> getURN() {
		return (IURNMaintainable<HierarchyBean>) super.getURN();
	}
	
    @Override
	public HierarchyBean cloneForDate(Date aDate) {
    	HierarchyMutableBean clone = this.getMutableInstance().stripItems(aDate);
        return clone.getImmutableInstance();
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new HierarchyBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public HierarchyMutableBean getMutableInstance() {
		return new HierarchyMutableBeanImpl(this);
	}

	@Override
	public List<HierarchicalCodeBean> getHierarchicalCodeBeans() {
		return codeRefs;
	}

	@Override
	public LevelBean getLevel() {
		return level;
	}

	@Override
	public LevelBean getLevelById(String levelId) {
		LevelBean currentLevel = level;
		while(currentLevel != null) {
			if(currentLevel.getFullIdPath(false).equals(levelId)) {
				return currentLevel;
			}
			currentLevel = currentLevel.getChildLevel();
		}
		currentLevel = level;
		while(currentLevel != null) {
			if(currentLevel.getId().equals(levelId)) {
				return currentLevel;
			}
			currentLevel = currentLevel.getChildLevel();
		}
		return null;
	}

	@Override
	public LevelBean getLevelAtPosition(int levelPos) {
		LevelBean currentLevel = level;
		for(int i = 1; i <= levelPos ; i++) {
			if(currentLevel == null) {
				return null;
			}
			if(i == levelPos) {
				return currentLevel;
			}
			currentLevel = currentLevel.getChildLevel();
		}
		return null;
	}

	@Override
	public boolean hasFormalLevels() {
		return hasFormalLevels;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(codeRefs, composites);
		super.addToCompositeSet(level, composites);
		return composites;
	}

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        return new HierarchyBeanDeferred(this);
    }
    
    @Override
    public HierarchyBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyBeanDeferred(getDeferredDefinition(), loader);
    }
}
