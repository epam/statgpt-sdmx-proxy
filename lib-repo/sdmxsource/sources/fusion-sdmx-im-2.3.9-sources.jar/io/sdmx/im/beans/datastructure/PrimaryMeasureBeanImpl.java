package io.sdmx.im.beans.datastructure;

import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;

public class PrimaryMeasureBeanImpl extends MeasureDimensionBeanImpl implements PrimaryMeasureBean {
	private static final long serialVersionUID = 13L;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public PrimaryMeasureBeanImpl(MeasureMutableBean bean, MeasureListBean parent) {
		super(bean, parent);
	}

	@Override
	public boolean isPrimaryMeasure() {
		return true;
	}

//	@Override
//	@SuppressWarnings("unchecked")
//	protected Class<?> getConcreteInterface() {
//		return PrimaryMeasureBean.class;
//	}
}
