package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class ProvisionAgreementBeanDeferred extends MaintainableBeanDeferred<ProvisionAgreementBean> implements ProvisionAgreementBean {
    private static final long serialVersionUID = 1L;

    public ProvisionAgreementBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ProvisionAgreementBeanDeferred(ProvisionAgreementBean maint) {
        super(maint);
    }
    
    @Override
    public ProvisionAgreementBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ProvisionAgreementBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected ProvisionAgreementBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ProvisionAgreementBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ProvisionAgreementBean> getURN() {
        return (IURNMaintainable<ProvisionAgreementBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ProvisionAgreementBean.class;
    }

    @Override
    public ProvisionAgreementMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public ICrossReferenceBean<DataflowBean> getStructureUseage() {
        return load().getStructureUseage();
    }

    @Override
    public ICrossReferenceBean<DataProviderBean> getDataproviderRef() {
        return load().getDataproviderRef();
    }
}
