package io.sdmx.im.beans.base;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;

public class OrganisationUnitSchemeBeanDeferred extends ItemSchemeBeanDeffered<OrganisationUnitBean, OrganisationUnitSchemeBean> implements OrganisationUnitSchemeBean {
    private static final long serialVersionUID = 1L;

    public OrganisationUnitSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public OrganisationUnitSchemeBeanDeferred(OrganisationUnitSchemeBean maint) {
        super(maint);
    }
    
    @Override
    public OrganisationUnitSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new OrganisationUnitSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected OrganisationUnitSchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationUnitSchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<OrganisationUnitSchemeBean> getURN() {
        return (IURNMaintainable<OrganisationUnitSchemeBean>) super.getURN();
    }
   
    @Override
    public OrganisationUnitSchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return OrganisationUnitSchemeBean.class;
    }
    
}
