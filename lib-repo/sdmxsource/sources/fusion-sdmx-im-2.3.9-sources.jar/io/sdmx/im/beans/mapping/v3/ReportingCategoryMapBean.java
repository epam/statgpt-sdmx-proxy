package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;

public class ReportingCategoryMapBean extends ItemMapBean implements IReportingCategoryMapBean {
	private static final long serialVersionUID = 1L;

    public ReportingCategoryMapBean(IItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
	}
}
