package io.sdmx.im.beans.reference;

import java.util.Map;

import io.sdmx.api.sdmx.constants.AVAILABILITY_MODE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.query.RESTAvailabilityQuery;

public class RESTAvailabilityQueryImpl extends RESTDataQueryImpl implements RESTAvailabilityQuery {
	private static final long serialVersionUID = 1L;
	private STRUCTURE_REFERENCE_DETAIL structureReferenceDetail;
	private SDMX_STRUCTURE_TYPE specificStructureReference;
	private AVAILABILITY_MODE mode;
	private String componentId;

	public RESTAvailabilityQueryImpl(String restString, Map<String, String> queryParameters) {
		super(restString, queryParameters);
		validate();
	}

    public RESTAvailabilityQueryImpl(String restString) {
		super(restString);
		validate();
	}

	public RESTAvailabilityQueryImpl(String[] queryString, Map<String, String> queryParameters) {
		super(queryString, queryParameters);
		validate();
	}

	private void validate() {
	    setStructureReferenceDetailIfUnset();
        setModeIfUnset();
	}

    private void setStructureReferenceDetailIfUnset() {
        if(structureReferenceDetail == null) {
            structureReferenceDetail = STRUCTURE_REFERENCE_DETAIL.NONE;
        }
    }

    private void setModeIfUnset() {
        if (this.mode == null) {
            this.mode = AVAILABILITY_MODE.EXACT;
        }
    }

	@Override
	public AVAILABILITY_MODE getMode() {
		return mode;
	}

	@Override
	public String[] getComponentIds() {
		return componentId == null ? null : componentId.split(",");
	}

	/**
	 * Override set provision ref, as this is the 4th argument in the availability query
	 */
	@Override
    protected void setProvisionRef(String provisionRef) {
		if("all".equals(provisionRef)) {
			this.componentId = null;
		} else {
			this.componentId = provisionRef;
		}
	}

	@Override
	void parserQueryParameter(String key, String value) {
		if(key.equalsIgnoreCase("references")) {
			structureReferenceDetail = STRUCTURE_REFERENCE_DETAIL.parseString(value);
			if(structureReferenceDetail == STRUCTURE_REFERENCE_DETAIL.SPECIFIC) {
				specificStructureReference = SDMX_STRUCTURE_TYPE.parseClass(value);
			}

		}  else if(key.equalsIgnoreCase("mode")) {
			if(value.equalsIgnoreCase("available")) {
				this.mode = AVAILABILITY_MODE.AVAILABLE;
			}
		} else {
			super.parserQueryParameter(key, value);
		}
	}

	@Override
	public STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail() {
		return structureReferenceDetail;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getSpecificStructureReference() {
		return specificStructureReference;
	}

}
