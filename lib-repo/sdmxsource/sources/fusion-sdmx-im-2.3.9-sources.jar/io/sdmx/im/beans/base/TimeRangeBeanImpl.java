package io.sdmx.im.beans.base;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;

public class TimeRangeBeanImpl extends SdmxStructureBeanImpl implements TimeRangeBean {

	private static final long serialVersionUID = -1105081442071478375L;

	private SdmxDate startDate;
	private SdmxDate endDate;
	private boolean isRange;
	private boolean isStartInclusive;
	private boolean isEndInclusive;
	
	private SdmxDate validFrom;
	private SdmxDate validTo;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public TimeRangeBeanImpl(TimeRangeMutableBean mutable, SdmxStructureBean parent) {
		super(SDMX_STRUCTURE_TYPE.TIME_RANGE, parent);
		if(mutable.getStartDate() != null) {
//			this.startDate = new SdmxDateImpl(mutable.getStartDate(), TIME_FORMAT.DATE_TIME);
			this.startDate = mutable.getStartDate();
		}
		if(mutable.getEndDate() != null) {
//			this.endDate = new SdmxDateImpl(mutable.getEndDate(), TIME_FORMAT.DATE_TIME);
			this.endDate = mutable.getEndDate();
		}
		this.isRange = mutable.isRange();
		this.isStartInclusive = mutable.isStartInclusive();
		this.isEndInclusive = mutable.isEndInclusive();
		if(mutable.getValidFrom() != null) {
			validFrom = mutable.getValidFrom();
		}
		if(mutable.getValidTo() != null) {
			validTo = mutable.getValidTo();
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			TimeRangeBean that = (TimeRangeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(startDate, that.getStartDate(), "Start Date", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(endDate, that.getEndDate(), "End Date", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isRange, that.isRange(), "Is Range", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isStartInclusive, that.isStartInclusive(), "Is Start Inclusive", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isEndInclusive, that.isEndInclusive(), "Is End Inclusive", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(validFrom, that.getValidFrom(), "Valid From", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(validTo, that.getValidTo(), "Valid To", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(startDate == null && endDate == null) {
			throw new SdmxSemmanticException("Time period must define at least one date");
		}
		if(isRange) {
			if(startDate == null || endDate == null) {
				throw new SdmxSemmanticException("Time period with a range requires both a start and end period");
			}
			if(startDate.isLater(endDate)) {
				throw new SdmxSemmanticException("Time range can not specify start period after end period");
			}
		} else {
			if(startDate != null && endDate != null) {
				throw new SdmxSemmanticException("Time period can not define both a before period and after period");
			}
		}
		if(validFrom.isLater(validTo)) {
			throw new SdmxSemmanticException("Time range Valid From cannot be after Valid To");
		}
	}
	
	@Override
	public boolean isRange() {
		return isRange;
	}

	@Override
	public SdmxDate getStartDate() {
		return startDate;
	}

	@Override
	public SdmxDate getEndDate() {
		return endDate;
	}

	@Override
	public boolean isStartInclusive() {
		return isStartInclusive;
	}

	@Override
	public boolean isEndInclusive() {
		return isEndInclusive;
	}

	@Override
	public SdmxDate getValidFrom() {
		return validFrom;
	}

	@Override
	public SdmxDate getValidTo() {
		return validTo;
	}

	@Override
	public String getKey() {
		return null;
	}
}
