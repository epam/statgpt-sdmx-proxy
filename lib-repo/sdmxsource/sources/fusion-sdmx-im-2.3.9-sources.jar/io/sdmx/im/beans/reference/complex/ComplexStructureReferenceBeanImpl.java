package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexAnnotationReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexIdentifiableReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexStructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexTextReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexVersionReference;

public class ComplexStructureReferenceBeanImpl extends ComplexNameableReferenceImpl
		implements ComplexStructureReferenceBean {

	private ComplexTextReference id;
	private ComplexTextReference agencyId;
	private ComplexVersionReference versionRef;
	private ComplexIdentifiableReferenceBean childRef;

	public ComplexStructureReferenceBeanImpl(ComplexTextReference agencyId, ComplexTextReference id, ComplexVersionReference versionRef, 
			SDMX_STRUCTURE_TYPE structureType,
			ComplexAnnotationReference annotationRef,
			ComplexTextReference nameRef,
			ComplexTextReference descriptionRef, 
			ComplexIdentifiableReferenceBean childRef
			) {
		super(structureType, annotationRef, nameRef, descriptionRef);
		
		this.id = id;
		this.agencyId = agencyId;
		this.versionRef = versionRef;
		//TODO childRef defaults && null check...
		this.childRef = childRef;
	}

	@Override
	public ComplexTextReference getId() {
		return id;
	}

	@Override
	public ComplexTextReference getAgencyId() {
		return agencyId;
	}

	@Override
	public ComplexVersionReference getVersionReference() {
		return versionRef;
	}

	@Override
	public ComplexIdentifiableReferenceBean getChildReference() {
		return childRef;
	}


}
