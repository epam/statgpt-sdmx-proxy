package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ProvisionAgreementBeanImpl extends MaintainableBeanImpl implements ProvisionAgreementBean {
    private static final Logger LOG = LoggerFactory.getLogger(ProvisionAgreementBeanImpl.class);
    private static final long serialVersionUID = 184L;
    private IDirectCrossReferenceBean<DataflowBean> structureUseage;
    private IDirectCrossReferenceBean<DataProviderBean> dataproviderRef;


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //////////// BUILD STUB FROM ITSELF              //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ProvisionAgreementBeanImpl(ProvisionAgreementBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
        LOG.debug("Stub Metadata Constraint Built");
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public ProvisionAgreementBeanImpl(ProvisionAgreementMutableBean provisionAgreementMutable) {
        super(provisionAgreementMutable);
        LOG.debug("Building ProvisionAgreementBean from Mutable Bean");
        try {
            if(provisionAgreementMutable.getStructureUsage() != null) {
                this.structureUseage = DirectCrossReferenceBean.build(this, "dataflow", provisionAgreementMutable.getStructureUsage(), DataflowBean.class);
            }
            if(provisionAgreementMutable.getDataproviderRef() != null) {
                this.dataproviderRef = DirectCrossReferenceBean.build(this, "dataprovider", provisionAgreementMutable.getDataproviderRef(), DataProviderBean.class);
            }
        } catch(Throwable th) {
            throw new SdmxSemmanticException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
        }
        try {
            validate();
        } catch(SdmxSemmanticException e) {
            throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
        }
        if(LOG.isDebugEnabled()) {
            LOG.debug("ProvisionAgreementBean Built " + this.getUrn());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            ProvisionAgreementBean that = (ProvisionAgreementBean) bean;
            boolean returnVal = true;
            if(!super.equivalent(structureUseage, that.getStructureUseage(), diff)) {
                returnVal = false;
            }
            if(!super.equivalent(dataproviderRef, that.getDataproviderRef(), diff)) {
                returnVal = false;
            }
            return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
        }
        return false;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        if(dataproviderRef == null) {
            throw new SdmxSemmanticException("The Provision Agreement is missing a reference to a data provider.");
        }
        if(!dataproviderRef.getReference().getVersion().toString().equals(DataProviderSchemeBean.FIXED_VERSION)) {
            throw new SdmxSemmanticException("Version 2.0 Data Provider Scheme is no longer supported.  Data Provider Scheme has a fixed version of 1.0 in SDMX 2.1");
        }
        if(structureUseage == null) {
            throw new SdmxSemmanticException("The Provision Agreement is missing a reference to a Dataflow");
        }
        if(structureUseage.getTargetReference() != SDMX_STRUCTURE_TYPE.DATAFLOW) {
            throw new SdmxSemmanticException("The Provision Agreement must reference a Dataflow.");
        }
        super.validateAgencyId();
        super.validateIdentifiableAttributes();
        super.validateNameableAttributes();
    }

    @Override
    protected void validateAgencyId() {
        //Do nothing yet, not yet fully built
    }

    @Override
    protected void validateNameableAttributes() throws SdmxSemmanticException {
        //Do nothing yet, not yet fully built
    }

    @Override
    protected void validateIdentifiableAttributes() throws SdmxSemmanticException {
        //Do nothing yet, not yet fully built
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ProvisionAgreementBean.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ProvisionAgreementBean> getURN() {
        return (IURNMaintainable<ProvisionAgreementBean>)super.getURN();
    }

    @Override
    public ICrossReferenceBean<DataflowBean> getStructureUseage() {
        return structureUseage;
    }

    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
        if(dataproviderRef != null) {
            references.add(dataproviderRef);
        }
        if(structureUseage != null) {
            references.add(structureUseage);
        }
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        List<ICrossReferenceBean<? extends ConstrainableBean>> returnList = new ArrayList<>();
        returnList.add(getStructureUseage());
        returnList.add(getDataproviderRef());
        return returnList;
    }

    @Override
    public ICrossReferenceBean<DataProviderBean> getDataproviderRef() {
        return dataproviderRef;
    }

    @Override
    public ProvisionAgreementMutableBean getMutableInstance() {
        return new ProvisionAgreementMutableBeanImpl(this);
    }

    @Override
    public ProvisionAgreementBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
       return new ProvisionAgreementBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public ProvisionAgreementBeanDeferred toDeferred() {
        return new ProvisionAgreementBeanDeferred(this);
    }
    
    @Override
    public ProvisionAgreementBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ProvisionAgreementBeanDeferred(getDeferredDefinition(), loader);
    }
}
