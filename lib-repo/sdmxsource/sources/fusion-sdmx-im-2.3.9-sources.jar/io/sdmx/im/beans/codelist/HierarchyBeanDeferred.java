package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Date;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class HierarchyBeanDeferred extends MaintainableBeanDeferred<HierarchyBean> implements HierarchyBean {
    private static final long serialVersionUID = 1L;

    public HierarchyBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public HierarchyBeanDeferred(HierarchyBean maint) {
        super(maint);
    }
    
    @Override
    public HierarchyBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new HierarchyBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected HierarchyBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<HierarchyBean> getURN() {
        return (IURNMaintainable<HierarchyBean>) super.getURN();
    }

    @Override
    public HierarchyBean cloneForDate(Date aDate) {
        return load().cloneForDate(aDate);
    }

    @Override
    public List<HierarchicalCodeBean> getHierarchicalCodeBeans() {
        return load().getHierarchicalCodeBeans();
    }

    @Override
    public LevelBean getLevel() {
        return load().getLevel();
    }

    @Override
    public LevelBean getLevelAtPosition(int levelPos) {
        return load().getLevelAtPosition(levelPos);
    }

    @Override
    public LevelBean getLevelById(String levelId) {
        return load().getLevelById(levelId);
    }

    @Override
    public boolean hasFormalLevels() {
        return load().hasFormalLevels();
    }

    @Override
    public HierarchyMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return HierarchyBean.class;
    }
}
