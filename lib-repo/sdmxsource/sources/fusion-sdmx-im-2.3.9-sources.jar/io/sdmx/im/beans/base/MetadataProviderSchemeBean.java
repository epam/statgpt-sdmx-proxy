package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;
import io.sdmx.im.mutable.base.MetadataProviderSchemeMutableBean;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class MetadataProviderSchemeBean extends OrganisationSchemeBeanImpl<IMetadataProviderBean> implements IMetadataProviderSchemeBean {
	private static final Logger LOG = LoggerFactory.getLogger(MetadataProviderSchemeBean.class);
	private static final long serialVersionUID = 168L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	MetadataProviderSchemeBean(IMetadataProviderSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub DataProviderSchemeBean Built");
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataProviderSchemeBean(IMetadataProviderSchemeMutableBean bean) {
		super(bean);
		LOG.debug("Building DataProviderSchemeBean from Mutable Bean");
		if(bean.getItems() != null) {
			for(IMetadataProviderMutableBean currrentBean : bean.getItems()) {
				this.items.add(new MetadataProviderBean(currrentBean, this));
			}
			items = Collections.unmodifiableList(items);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("MetadataProviderSchemeMutableBean Built " + this.getUrn());
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((IMetadataProviderSchemeBean)bean, includeFinalProperties, "Metadata Provider", diff);
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IMetadataProviderSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<IMetadataProviderSchemeBean> getURN() {
		return (IURNMaintainable<IMetadataProviderSchemeBean>) super.getURN();
	}
	
	@Override
	public ISdmxVersion getVersion() {
		return SdmxVersion.DEFAULT;
	}

	@Override
	public String getId() {
		return FIXED_ID;
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new MetadataProviderSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}
	
	@Override
	public IMetadataProviderSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return (IMetadataProviderSchemeBean)super.filterItems(filterIds, isKeepSet);
	}

	@Override
	public IMetadataProviderSchemeMutableBean getMutableInstance() {
		return new MetadataProviderSchemeMutableBean(this);
	}

    @Override
    public IMaintainableBeanDeferred<?> toDeferred() {
        return new MetadataProviderSchemeBeanDeferred(this);
    }
    
    @Override
    public MetadataProviderSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProviderSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
