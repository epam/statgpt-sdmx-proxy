package io.sdmx.im.beans.base;

import java.util.Collection;
import java.util.Date;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;

public abstract class OrganisationSchemeBeanDeferred<T extends OrganisationBean, V extends OrganisationSchemeBean<T>> extends ItemSchemeBeanDeffered<T, V> {
    private static final long serialVersionUID = 1L;

    protected OrganisationSchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    protected OrganisationSchemeBeanDeferred(V itemScheme) {
        super(itemScheme);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<? extends OrganisationSchemeBean<T>>  getURN() {
        return (IURNMaintainable<? extends OrganisationSchemeBean<T>> ) super.getURN();
    }
    
    @Override
    public V cloneForDate(Date date) {
        return (V)super.cloneForDate(date);
    }
    
    @Override
    public V filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return (V)super.filterItems(filterIds, isKeepSet);
    }
    
    @Override
    public boolean isFixedVersion() {
        return true;
    }

}
