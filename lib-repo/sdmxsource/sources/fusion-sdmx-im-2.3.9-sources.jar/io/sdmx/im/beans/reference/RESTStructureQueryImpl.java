package io.sdmx.im.beans.reference;

import java.io.Serializable;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.api.sdmx.model.query.StructureQueryMetadata;
import io.sdmx.utils.sdmx.xs.URN;

public class RESTStructureQueryImpl implements RESTStructureQuery, Serializable {
	private static final long serialVersionUID = 1L;

	private IURN<?> structureReference = URN.ANY_MAINTINABLE;
	private StructureQueryMetadata structureQueryMetadata;
	
	public RESTStructureQueryImpl(IURN<?> structureReference) {
		if(structureReference != null) {
			this.structureReference = structureReference;
		}
		this.structureQueryMetadata = new StructureQueryMetadataImpl(null, null, null);
	}
	
	public RESTStructureQueryImpl(IURN<?> structureReference, StructureQueryMetadata structureQueryMetadata) {
		this.structureReference = structureReference;
		this.structureQueryMetadata = structureQueryMetadata;
	}
	
	public RESTStructureQueryImpl(
			STRUCTURE_QUERY_DETAIL structureQueryDetail,
			STRUCTURE_REFERENCE_DETAIL structureReferenceDetail,
			SDMX_STRUCTURE_TYPE specificStructureReference,
			IURN<?> structureReference) {
		this(structureReference, new StructureQueryMetadataImpl(structureQueryDetail, structureReferenceDetail, specificStructureReference));
	}
	
	@Override
	public StructureQueryMetadata getStructureQueryMetadata() {
		return structureQueryMetadata;
	}

	@Override
	public IURN<?> getStructureReference() {
		return structureReference;
	}

	@Override
	public String toString() {
		return "ref: "+ this.structureReference +
			   " -detail: " + this.structureQueryMetadata.getStructureQueryDetail() +
			   " -references: " + this.structureReference +
			   " -specific: " + this.structureQueryMetadata.getSpecificStructureReference();
	}
}