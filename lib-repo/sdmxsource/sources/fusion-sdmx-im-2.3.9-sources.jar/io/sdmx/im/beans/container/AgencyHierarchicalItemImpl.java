package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.util.HierarchicalItem;
import io.sdmx.api.sdmx.model.util.HierarchyNode;

public class AgencyHierarchicalItemImpl implements HierarchicalItem<AgencyBean>, Comparable<HierarchicalItem<AgencyBean>> {
	private AgencyBean agency;
	private HierarchyNode<AgencyBean> parent;
	private SortedSet<HierarchicalItem<AgencyBean>> childAgencies = new TreeSet<>();
	
	public AgencyHierarchicalItemImpl(Set<AgencySchemeBean> agencySchemes, AgencyBean agency, HierarchyNode<AgencyBean> parent) {
		this.agency = agency;
		this.parent = parent;
		if(!agency.getFullId().equals(AgencyBean.DEFAULT_AGENCY)) {
			AgencySchemeBean childScheme = getAgencyScheme(agencySchemes, agency.getFullId());
			if(childScheme != null) {
				for(AgencyBean child : childScheme.getItems()) {
					this.childAgencies.add(new AgencyHierarchicalItemImpl(agencySchemes, child, this));
				}
			}
		}
		childAgencies = Collections.unmodifiableSortedSet(this.childAgencies);
	}
	
	@Override
	public AgencyBean getItem() {
		return agency;
	}

	@Override
	public HierarchyNode<AgencyBean> getParent() {
		return parent;
	}

	@Override
	public Collection<HierarchicalItem<AgencyBean>> getChildren() {
		return childAgencies;
	}

	private AgencySchemeBean getAgencyScheme(Set<AgencySchemeBean> agencySchemes, String acyId) {
		for(AgencySchemeBean acy : agencySchemes) {
			if(acy.getAgencyId().equals(acyId)) {
				return acy;
			}
		}
		return null;
	}
	@Override
	public int compareTo(HierarchicalItem<AgencyBean> o) {
		return this.getItem().getFullId().compareTo(o.getItem().getFullId());
	}
}
