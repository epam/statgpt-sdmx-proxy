package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class MetadataProvisionBeanDeferred extends MaintainableBeanDeferred<MetadataProvisionAgreementBean> implements MetadataProvisionAgreementBean {
    private static final long serialVersionUID = 1L;

    public MetadataProvisionBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public MetadataProvisionBeanDeferred(MetadataProvisionAgreementBean maint) {
        super(maint);
    }
    
    @Override
    public MetadataProvisionAgreementBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataProvisionAgreementBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected MetadataProvisionBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProvisionBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<MetadataProvisionAgreementBean> getURN() {
        return (IURNMaintainable<MetadataProvisionAgreementBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return MetadataProvisionAgreementBean.class;
    }

    @Override
    public IMetadataProvisionAgreementMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public List<ICrossReferenceBeanBase> getTargets() {
        return load().getTargets();
    }

    @Override
    public ICrossReferenceBean<MetadataFlowBean> getMetadataflowRef() {
        return load().getMetadataflowRef();
    }

    @Override
    public ICrossReferenceBean<IMetadataProviderBean> getMetadataProviderRef() {
        return load().getMetadataProviderRef();
    }
}
