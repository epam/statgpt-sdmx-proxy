package io.sdmx.im.beans.codelist;

import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistRefBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodelistBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

@Deprecated
public class CodelistRefBeanImpl extends SdmxStructureBeanImpl implements CodelistRefBean {
    private static final long serialVersionUID = 14L;
    private String alias;
    private CrossReferenceBean<CodelistBean> codelistReference;

    public CodelistRefBeanImpl(CodelistRefMutableBean bean, HierarchicalCodelistBean parent) {
        super(parent);
        this.alias = bean.getAlias();
        if(bean.getCodelistReference() != null) {
            this.codelistReference =  DirectCrossReferenceBean.build(parent, "codelistref", bean.getCodelistReference(), CodelistBean.class);
        }
        validate();
    }
    @Override
    public String getAlias() {
        return alias;
    }

    @Override
    public CrossReferenceBean<CodelistBean> getCodelistReference() {
        return codelistReference;
    }

    @Override
    public String getKey() {
        return getCodelistReference().getTargetUrn();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP VALIDATION                      //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            CodelistRefBean that = (CodelistRefBean) bean;
            if(!ObjectUtil.equivalent(alias, that.getAlias())) {
                return false;
            }
            if(!super.equivalent(codelistReference, that.getCodelistReference(), "Codelist Refernce", diff)) {
                return false;
            }
            return true;
        }
        return false;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        if(codelistReference == null) {
            throw new SdmxSemmanticException("HierarchicalCodelist, Codelist Reference Missing a Reference");
        }
        if(codelistReference.getTargetReference()!=SDMX_STRUCTURE_TYPE.CODE_LIST) {
            throw new SdmxSemmanticException("Referenced structure should be " + SDMX_STRUCTURE_TYPE.CODE_LIST.getType() + " but is declared as " + codelistReference.getTargetReference().getType());
        }
    }
    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
        references.add(codelistReference);
    }
}