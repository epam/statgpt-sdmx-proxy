package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodelistMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class GeoGridCodelistBean extends CodelistBeanImpl implements IGeoGridCodelistBean {
	private static final long serialVersionUID = 1L;
	
	private String gridDefinition;
	
	public GeoGridCodelistBean(IGeoGridCodelistBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public GeoGridCodelistBean(IGeoGridCodelistMutableBean codelist) {
		super(codelist);
		this.gridDefinition = codelist.getGridDefinition();
		try {
			validateGeoGridCl();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	
	@Override
    public IDeferredBeanDefinition getDeferredDefinition() {
	    return null;
	}

	@Override
	protected CodeBean createItem(CodeMutableBean codeMutable, int pos) {
		return new GeoCodeBean(this, (IGeoGridCodeMutableBean)codeMutable, pos);
	}

	@Override
	public IGeoGridCodelistBean removePrefix(String prefix) {
		IGeoGridCodelistMutableBean mutable = this.getMutableInstance();
		for(CodeMutableBean codeMutable : mutable.getItems()) {
			if(codeMutable.getId().startsWith(prefix)) {
				codeMutable.setId(codeMutable.getId().substring(prefix.length()));
			}
		}
		return mutable.getImmutableInstance();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof IGeoGridCodelistBean) {
			IGeoGridCodelistBean that = (IGeoGridCodelistBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(gridDefinition, that.getGridDefinition(), "Grid Definition", diff)) {
				returnVal =  false;
			}
			return super.deepEquals(bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validateGeoGridCl() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(this.gridDefinition)) {
			throw new SdmxSemmanticException("Geo Grid Codelist is missing required Grid Defintion");
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IGeoGridCodelistBean cloneForDate(Date date) {
		return (IGeoGridCodelistBean)super.cloneForDate(date);
	}

	@Override
	public IGeoGridCodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new GeoGridCodelistBean(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public IGeoGridCodeBean getItemById(String id) {
		return (IGeoGridCodeBean) super.getItemById(id);
	}

	@Override
	public IGeoGridCodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return  (IGeoGridCodelistBean) super.filterItems(filterIds, isKeepSet);
	}

	@Override
	public IGeoGridCodelistMutableBean getMutableInstance() {
		return new GeoGridCodelistMutableBean(this);
	}

	@Override
	public String getGridDefinition() {
		return gridDefinition;
	}
	
	@Override
	public boolean isGeoCodelist() {
		return true;
	}
}
