package io.sdmx.im.beans.base;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;

public class OrganisationUnitBeanImpl extends OrganisationBeanImpl implements OrganisationUnitBean {
	private static final long serialVersionUID = 23L;
	private String parentId;

	public OrganisationUnitBeanImpl(OrganisationUnitMutableBean bean, OrganisationUnitSchemeBean parent) {
		super(bean, parent);
		this.parentId = bean.getParentUnit();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			boolean returnVal = true;
			OrganisationUnitBean that = (OrganisationUnitBean) bean;
			if(!super.equivalent(parentId, that.getParentUnit(), "Parent Id", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal((OrganisationUnitBean)bean, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return OrganisationUnitBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<OrganisationUnitBean> getURN() {
		return (IURNAbsolute<OrganisationUnitBean>) super.getURN();
	}
	
	@Override
	public boolean hasParentUnit() {
		return getParentUnit() != null;
	}

	@Override
	public String getParentUnit() {
		return parentId;
	}
}
