package io.sdmx.im.beans.registry;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.im.beans.base.DataSourceBeanImpl;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.random.RandomUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class RegistrationBeanImpl extends MaintainableBeanImpl implements RegistrationBean {
    private static final Logger LOG = LoggerFactory.getLogger(RegistrationBeanImpl.class);
    private static final long serialVersionUID = 184L;
    private SdmxDate lastUpdated = new SdmxDateImpl(new Date(), TIME_FORMAT.DATE_TIME);
    private SdmxDate validFrom;
    private SdmxDate validTo;
    private DataSourceBean dataSource;
    private IDirectCrossReferenceBean<ProvisionAgreementBean> provisionAgreementRef;

    private TERTIARY_BOOL indexTimeSeries = TERTIARY_BOOL.UNSET;
    private TERTIARY_BOOL indexDataset = TERTIARY_BOOL.UNSET;
    private TERTIARY_BOOL indexAttributes = TERTIARY_BOOL.UNSET;
    private TERTIARY_BOOL indexReportingPeriod = TERTIARY_BOOL.UNSET;


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //////////// BUILD STUB FROM ITSELF              //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    RegistrationBeanImpl(RegistrationBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
        LOG.debug("Stub Metadata Constraint Built");
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public RegistrationBeanImpl(RegistrationMutableBean registrationMutable) {
        super(setIdentifiers(registrationMutable));
        LOG.debug("Building RegistrationBean from Mutable Bean");
        if(registrationMutable.getLastUpdated() != null) {
            lastUpdated = new SdmxDateImpl(registrationMutable.getLastUpdated(), TIME_FORMAT.DATE_TIME);
        }
        if(registrationMutable.getValidFrom() != null) {
            validFrom = new SdmxDateImpl(registrationMutable.getValidFrom(), TIME_FORMAT.DATE_TIME);
        }
        if(registrationMutable.getValidTo() != null) {
            validTo = new SdmxDateImpl(registrationMutable.getValidTo(), TIME_FORMAT.DATE_TIME);
        }
        if(registrationMutable.getProvisionAgreementRef() != null) {
            this.provisionAgreementRef = DirectCrossReferenceBean.build(this, "provisionagreement", registrationMutable.getProvisionAgreementRef(), ProvisionAgreementBean.class);
        }
        if(registrationMutable.getIndexAttributes() != null) {
            this.indexAttributes = registrationMutable.getIndexAttributes();
        }
        if(registrationMutable.getIndexDataset() != null) {
            this.indexDataset = registrationMutable.getIndexDataset();
        }
        if(registrationMutable.getIndexReportingPeriod() != null) {
            this.indexReportingPeriod = registrationMutable.getIndexReportingPeriod();
        }
        if(registrationMutable.getIndexTimeSeries() != null) {
            this.indexTimeSeries = registrationMutable.getIndexTimeSeries();
        }
        if(registrationMutable.getDataSource() != null) {
            this.dataSource = new DataSourceBeanImpl(registrationMutable.getDataSource(), this);
        }
        validate();
        if(LOG.isDebugEnabled()) {
            LOG.debug("RegistrationBean Built " + this.getUrn());
        }
    }

    /**
     * Sets missing identifiers as required
     */
    private static RegistrationMutableBean setIdentifiers(RegistrationMutableBean reg) {
        if(reg.getId() == null) {
            reg.setId(RandomUtil.randomString());
        }
        if(reg.getProvisionAgreementRef() == null) {
            throw new SdmxSemmanticException("Registration missing provision agreement reference");
        }
        reg.setAgencyId(reg.getProvisionAgreementRef().getAgencyId());
        return reg;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATE				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        if(provisionAgreementRef == null) {
            throw new SdmxSemmanticException("Registration must reference a provision agreement");
        }
        if(provisionAgreementRef.getTargetReference() != SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT) {
            throw new SdmxSemmanticException("Registration must reference a provision agreement, actual referenced structre supplied was " + provisionAgreementRef.getTargetReference().getType());
        }
        if(dataSource == null) {
            throw new SdmxSemmanticException("Registration must have a datasource");
        }

        if(this.lastUpdated == null) {
            this.lastUpdated = new SdmxDateImpl(new Date(), TIME_FORMAT.DATE_TIME);
        }
        super.validateId(true);
        super.validateAgencyId();
    }


    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        if(bean.getStructureType() == this.getStructureType()) {
            RegistrationBean that = (RegistrationBean) bean;
            boolean returnVal = true;
            if(!ObjectUtil.equivalent(this.lastUpdated, that.getLastUpdated())) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(validFrom, that.getValidFrom())) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(validTo, that.getValidTo())) {
                returnVal = false;
            }
            if(!super.equivalent(dataSource, that.getDataSource(), includeFinalProperties,  diff)) {
                returnVal = false;
            }
            if(!super.equivalent(provisionAgreementRef, that.getProvisionAgreementRef(), "Provision Agreement Reference", diff)) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(indexTimeSeries.isTrue(), that.getIndexTimeSeries().isTrue())) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(indexDataset.isTrue(), that.getIndexDataset().isTrue())) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(indexAttributes.isTrue(), that.getIndexAttributes().isTrue())) {
                returnVal = false;
            }
            if(!ObjectUtil.equivalent(indexReportingPeriod.isTrue(), that.getIndexReportingPeriod().isTrue())) {
                returnVal = false;
            }
            return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
        }
        return false;
    }



    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return RegistrationBean.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<RegistrationBean> getURN() {
        return (IURNMaintainable<RegistrationBean>)super.getURN();
    }


    @Override
    public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
        if(provisionAgreementRef != null) {
            references.add(provisionAgreementRef);
        }
    }

    @Override
    public boolean isIndexed() {
        return indexAttributes.isTrue() || indexDataset.isTrue() || indexReportingPeriod.isTrue() || indexTimeSeries.isTrue();
    }

    @Override
    public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return this;
    }

    @Override
    public RegistrationMutableBean getMutableInstance() {
        return new RegistrationMutableBeanImpl(this);
    }

    @Override
    public TERTIARY_BOOL getIndexTimeSeries() {
        return indexTimeSeries;
    }

    @Override
    public TERTIARY_BOOL getIndexDataset() {
        return indexDataset;
    }

    @Override
    public TERTIARY_BOOL getIndexAttributes() {
        return indexAttributes;
    }

    @Override
    public TERTIARY_BOOL getIndexReportingPeriod() {
        return indexReportingPeriod;
    }

    @Override
    public DataSourceBean getDataSource() {
        return dataSource;
    }

    @Override
    public SdmxDate getLastUpdated() {
        return lastUpdated;
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        List<ICrossReferenceBean<? extends ConstrainableBean>> returnList = new ArrayList<>();
        returnList.add(getProvisionAgreementRef());
        return returnList;
    }

    @Override
    public ICrossReferenceBean<ProvisionAgreementBean> getProvisionAgreementRef() {
        return provisionAgreementRef;
    }

    @Override
    public SdmxDate getValidFrom() {
        return validFrom;
    }

    @Override
    public SdmxDate getValidTo() {
        return validTo;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(dataSource, composites);
        return composites;
    }

    @Override
    public RegistrationBeanDeferred toDeferred() {
        return new RegistrationBeanDeferred(this);
    }
    
    @Override
    public RegistrationBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new RegistrationBeanDeferred(getDeferredDefinition(), loader);
    }
}
