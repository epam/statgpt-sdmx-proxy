package io.sdmx.im.beans.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;

public abstract class OrganisationBeanImpl extends ItemBeanImpl implements OrganisationBean {
	private static final long serialVersionUID = -277883131268394387L;
	private List<ContactBean> contacts = new ArrayList<>();


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public OrganisationBeanImpl(OrganisationMutableBean bean, ItemSchemeBean<?> parent) {
		super(bean, parent, 0);
		for(ContactMutableBean currentContact : bean.getContacts()) {
			this.contacts.add(new ContactBeanImpl(currentContact, this));
		}
		this.contacts = Collections.unmodifiableList(this.contacts);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(contacts, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<ContactBean> getContacts() {
		return contacts;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<? extends OrganisationBean> getURN() {
		return (IURNAbsolute<? extends OrganisationBean>) super.getURN();
	}

	protected boolean deepEqualsInternal(OrganisationBean bean, boolean includeFinalProperties, DiffReport diff) {
		boolean returnVal = true;
		if(!super.equivalent(this.contacts, bean.getContacts(), includeFinalProperties, "Contact", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}
}
