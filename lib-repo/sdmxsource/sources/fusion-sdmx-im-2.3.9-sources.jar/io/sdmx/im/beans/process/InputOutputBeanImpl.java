package io.sdmx.im.beans.process;

import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class InputOutputBeanImpl extends AnnotableBeanImpl implements InputOutputBean {
	private static final long serialVersionUID = -1497837570792187509L;
	private String localId;
	private IDirectCrossReferenceBean<?> structureReference;
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public InputOutputBeanImpl(IdentifiableBean parent, InputOutputMutableBean mutableBean) {
		super(mutableBean, parent);
		this.localId = mutableBean.getLocalId();
		if(mutableBean.getStructureReference() != null) {
			this.structureReference = DirectCrossReferenceBean.build(parent, "structure", mutableBean.getStructureReference(), IdentifiableBean.class);
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			InputOutputBean that = (InputOutputBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(structureReference, that.getStructureReference(), diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(localId, that.getLocalId(), "Local Id", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getLocalId() {
		return localId;
	}

	@Override
	public ICrossReferenceBean<?> getStructureReference() {
		return structureReference;
	}
	
	@Override
	public String getKey() {
		return getLocalId();
	}
	

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(structureReference != null) {
			references.add(structureReference);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALiDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(structureReference == null) {
			throw new SdmxSemmanticException("Input / Output bean, requires an Object Reference");
		}
	}
}
