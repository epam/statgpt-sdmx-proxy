package io.sdmx.im.beans.base;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;

public abstract class ItemBeanImpl extends NameableBeanImpl implements ItemBean{
	private static final long serialVersionUID = 25L;
	private int position;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ItemBeanImpl(ItemMutableBean bean, IdentifiableBean parent, int position) {
		super(bean, parent);
		this.position = position;
	}

	/**
	 * Returns the position of the item in the list of items
	 * @return
	 */
	@Override
	public int getPosition() {
		return position;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected boolean deepEqualsInternal(ItemBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(!super.equivalent(position, bean.getPosition(), "List Position", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<? extends ItemBean> getURN() {
		return (IURNAbsolute<? extends ItemBean>) super.getURN();
	}

}
