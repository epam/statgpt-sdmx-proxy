package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexVersionReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.TimeRange;

public class ComplexVersionReferenceImpl implements ComplexVersionReference {

	private TERTIARY_BOOL returnLatest = TERTIARY_BOOL.UNSET;
	private String version;
	private TimeRange validFrom;
	private TimeRange validTo;

	public ComplexVersionReferenceImpl(TERTIARY_BOOL returnLatest, String version, TimeRange validFrom, TimeRange validTo) {
		if (returnLatest != null) {
			this.returnLatest = returnLatest;
		}
		this.version = version;
		this.validFrom = validFrom;
		this.validTo = validTo;
	}
	
	@Override
	public TERTIARY_BOOL isReturnLatest() {
		return returnLatest;
	}

	@Override
	public String getVersion() {
		return version;
	}

	@Override
	public TimeRange getVersionValidFrom() {
		return validFrom;
	}

	@Override
	public TimeRange getVersionValidTo() {
		return validTo;
	}

}
