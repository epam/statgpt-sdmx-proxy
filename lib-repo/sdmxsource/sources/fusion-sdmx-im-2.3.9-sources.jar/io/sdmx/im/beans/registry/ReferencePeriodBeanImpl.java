package io.sdmx.im.beans.registry;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.im.mutable.registry.ReferencePeriodMutableBeanImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;

public class ReferencePeriodBeanImpl extends SdmxStructureBeanImpl implements ReferencePeriodBean {
	private static final long serialVersionUID = -274922269002910521L;
	private SdmxDate startTime;
	private SdmxDate endTime;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReferencePeriodBeanImpl(ReferencePeriodMutableBean mutable, ContentConstraintBean parent) {
		super(SDMX_STRUCTURE_TYPE.REFERENCE_PERIOD, parent);
		// These items are mandatory and thus should exist
		if(mutable.getStartTime() != null) {
			this.startTime = new SdmxDateImpl(mutable.getStartTime(), TIME_FORMAT.DATE_TIME);
		}
		if(mutable.getEndTime() != null) {
			this.endTime = new SdmxDateImpl(mutable.getEndTime(), TIME_FORMAT.DATE_TIME);
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(startTime == null) {
			throw new SdmxSemmanticException("ReferencePeriodBeanImpl - start time can not be null");
		}
		if(endTime == null) {
			throw new SdmxSemmanticException("ReferencePeriodBeanImpl - start time can not be null");
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ReferencePeriodBean that = (ReferencePeriodBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(startTime, that.getStartTime(), "start time", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(endTime, that.getEndTime(), "end time", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public SdmxDate getStartTime() {
		return startTime;
	}

	@Override
	public SdmxDate getEndTime() {
		return endTime;
	}

	@Override
	public String getKey() {
		String key = null;
		if(startTime != null) {
			key = startTime.getDateInSdmxFormat();
		} if(endTime != null) {
			if(key == null) {
				key = "";
			}
			key += "-"+endTime.getDateInSdmxFormat();
		}
		return key;
	}

	@Override
	public ReferencePeriodMutableBean createMutableBean() {
		return new ReferencePeriodMutableBeanImpl(this, null); 
	}
}
