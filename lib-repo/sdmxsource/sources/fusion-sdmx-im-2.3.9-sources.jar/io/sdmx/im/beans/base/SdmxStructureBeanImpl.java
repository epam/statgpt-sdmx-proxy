package io.sdmx.im.beans.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.mutable.base.MutableBean;
import io.sdmx.utils.sdmx.structure.SDMXBeanUtil;

public abstract class SdmxStructureBeanImpl extends SDMXBeanImpl implements SdmxStructureBean {
	private static final long serialVersionUID = 1L;
	protected SdmxStructureBean parent;

	transient Set<IdentifiableBean> identifiableComposites;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	protected SdmxStructureBeanImpl(SDMX_STRUCTURE_TYPE structureType, SdmxStructureBean parent) {
		super(structureType, parent);
		this.structureType = structureType;
		this.parent = parent;
	}

	protected SdmxStructureBeanImpl(SdmxStructureBean bean) {
		super(bean);
		this.structureType = bean.getStructureType();
		this.parent = bean.getParent();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public SdmxStructureBeanImpl(MutableBean mutableBean, SdmxStructureBean parent) {
		super(mutableBean, parent);
		this.structureType = mutableBean.getStructureType();
		this.parent = parent;
	}


	protected static TERTIARY_BOOL createTertiary(boolean isSet, boolean value) {
		return SDMXBeanUtil.createTertiary(isSet, value);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	@Override
	public SDMX_STRUCTURE_TYPE getStructureType() {
		return structureType;
	}

	@Override
	public SdmxStructureBean getParent() {
		return parent;
	}

	@Override
	public MaintainableBean getMaintainableParent() {
		if(this instanceof MaintainableBean) {
			return (MaintainableBean)this;
		}
		if(parent instanceof MaintainableBean) {
			return (MaintainableBean)parent;
		} 
		return parent.getMaintainableParent();
	}

	@Override
	public final Set<IdentifiableBean> getIdentifiableComposites() {
		if(identifiableComposites == null) {
			Set<IdentifiableBean> identifiableComposites = new HashSet<>();
			Map<String, IdentifiableBean> identifiableCompositeMap = new HashMap<>();
			for(SDMXBean currentComposite : getComposites()) {
				if(currentComposite instanceof IdentifiableBean) {
					IdentifiableBean ident = (IdentifiableBean) currentComposite;
					if(ident.getStructureClass().isMaintainable()) {
						continue;
					}
					identifiableComposites.add(ident);
					identifiableCompositeMap.put(ident.getUrn(), ident);
				}
			}
			this.identifiableComposites = Collections.unmodifiableSet(identifiableComposites);
		}
		return identifiableComposites;
	}
	

}
