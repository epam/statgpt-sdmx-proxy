package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.Collections;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlCodelistMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlConceptMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlDataflowMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.mutable.transformation.VtlMappingSchemeMutableBean;

/**
 * A container for {@link VtlMappingBean}
 */
public class VtlMappingSchemeBean extends ItemSchemeBeanImpl<IVtlMappingBean> implements IVtlMappingSchemeBean {
	private static final long serialVersionUID = 1L;

	VtlMappingSchemeBean(IVtlMappingSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.emptyList();
	}

	public VtlMappingSchemeBean(IVtlMappingSchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(IVtlMappingMutableBean item : bean.getItems()) {
				switch(item.getStructureType()) {
				case VTL_CODELIST_MAPPING :
					this.items.add(new VtlCodelistMappingBean((IVtlCodelistMappingMutableBean)item, this, this.items.size()));
					break;
				case VTL_CONCEPT_MAPPING :
					this.items.add(new VtlConceptMappingBean((IVtlConceptMappingMutableBean)item, this, this.items.size()));
					break;
				case VTL_DATAFLOW_MAPPING :
					this.items.add(new VtlDataflowMappingBean((IVtlDataflowMappingMutableBean)item, this, this.items.size()));
					break;
				default : throw new SdmxNotImplementedException("Mapping Type: "+item.getStructureType().getType());
				}
			}
		}
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IVtlMappingSchemeBean that = (IVtlMappingSchemeBean) bean;
		return super.deepEqualsInternal(that, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME.getType(),  diff);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return IVtlMappingSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<IVtlMappingSchemeBean> getURN() {
		return (IURNMaintainable<IVtlMappingSchemeBean>) super.getURN();
	}
	
	@Override
	public IVtlMappingSchemeMutableBean getMutableInstance() {
		return new VtlMappingSchemeMutableBean(this);
	}

	@Override
	public IVtlMappingSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new VtlMappingSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}

    @Override
    public VtlMappingSchemeBeanDeferred toDeferred() {
        return new VtlMappingSchemeBeanDeferred(this);
    }
    
    @Override
    public VtlMappingSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new VtlMappingSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
