package io.sdmx.im.beans.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetKeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.MetadataTargetRegionMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class MetadataTargetRegionBeanImpl extends SdmxStructureBeanImpl implements MetadataTargetRegionBean {
	private static final long serialVersionUID = 290802739173862424L;
	private boolean isInclude;
	private String report;
	private String metadataTarget;
	private List<MetadataTargetKeyValuesBean> key = new ArrayList<>();
	private List<KeyValues> attributes = new ArrayList<>();

	public MetadataTargetRegionBeanImpl(MetadataTargetRegionMutableBean mutableBean, ContentConstraintBean parent) {
		super(mutableBean, parent);
		this.isInclude = mutableBean.isInclude();
		this.report = mutableBean.getReport();
		this.metadataTarget = mutableBean.getMetadataTarget();
		if(mutableBean.getKey() != null) {
			for(MetadataTargetKeyValuesMutable currentMetadataTarget : mutableBean.getKey()) {
				this.key.add(new MetadataTargetKeyValuesBeanImpl(currentMetadataTarget, this));
			}
		}
		if(mutableBean.getAttributes() != null) {
			for(KeyValuesMutable currentKeyValue : mutableBean.getAttributes()) {
				this.attributes.add(new KeyValuesImpl(currentKeyValue, this));
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(report)) {
			throw new SdmxSemmanticException("Metadata Target Region missing mandatory 'report' identifier");
		}
		if(!ObjectUtil.validString(metadataTarget)) {
			throw new SdmxSemmanticException("Metadata Target Region missing mandatory 'metadata target' identifier");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			MetadataTargetRegionBean that = (MetadataTargetRegionBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.attributes, that.getAttributes(), includeFinalProperties, "Attribute", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.key, that.getTargetKeyValues(), includeFinalProperties, "Metadata Target", diff)) {
				returnVal = false;
			}
			if(!ObjectUtil.equivalent(this.metadataTarget, that.getMetadataTarget())) {
				returnVal = false;
			}
			if(!ObjectUtil.equivalent(this.report, that.getReport())) {
				returnVal = false;
			}
			if(this.isInclude != that.isInclude()) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}


	@Override
	public boolean isInclude() {
		return isInclude;
	}

	@Override
	public String getReport() {
		return report;
	}

	@Override
	public String getMetadataTarget() {
		return metadataTarget;
	}

	@Override
	public List<MetadataTargetKeyValuesBean> getTargetKeyValues() {
		return new ArrayList<>(key);
	}

	@Override
	public List<KeyValues> getAttributes() {
		return new ArrayList<>(attributes);
	}

	@Override
	public String getKey() {
		return null;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(key, composites);
        super.addToCompositeSet(attributes, composites);
        return composites;
    }
}
