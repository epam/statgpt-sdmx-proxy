package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexAnnotationReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexIdentifiableReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexTextReference;

public class ComplexIdentifiableReferenceBeanImpl extends
		ComplexNameableReferenceImpl implements
		ComplexIdentifiableReferenceBean {

	private ComplexTextReference id;
	private ComplexIdentifiableReferenceBean childReference;

	public ComplexIdentifiableReferenceBeanImpl(
			ComplexTextReference id,
			SDMX_STRUCTURE_TYPE structureType,
			ComplexAnnotationReference annotationRef,
			ComplexTextReference nameRef,
			ComplexTextReference descriptionRef,
			ComplexIdentifiableReferenceBean childReference) {
		
		super(structureType, annotationRef, nameRef, descriptionRef);
		
		this.id = id;
		this.childReference = childReference;
	}

	@Override
	public ComplexTextReference getId() {
		return id;
	}

	@Override
	public ComplexIdentifiableReferenceBean getChildReference() {
		return childReference;
	}

}
