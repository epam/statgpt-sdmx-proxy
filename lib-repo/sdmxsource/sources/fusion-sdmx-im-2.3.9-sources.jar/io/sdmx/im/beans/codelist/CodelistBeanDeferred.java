package io.sdmx.im.beans.codelist;

import java.net.URL;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanDeffered;

public class CodelistBeanDeferred extends ItemSchemeBeanDeffered<CodeBean, CodelistBean> implements CodelistBean {
    private static final long serialVersionUID = 1L;
    private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;
    private boolean isInherited;

    public CodelistBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
        String validityPeriodType = bean.getProperties().get("VPType");
        if(validityPeriodType != null) {
            this.validityType = MAINT_VALIDITY_TYPE.getValidityType(validityPeriodType);
        }
        Boolean isInherited = bean.getBooleanProperty("Inherited");
        if(isInherited != null) {
            this.isInherited = isInherited;
        }
    }
    
    public CodelistBeanDeferred(CodelistBean codelist) {
        super(codelist);
        this.validityType = codelist.getValidityType();
    }
    
    @Override
    protected CodelistBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new CodelistBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    public CodelistBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new CodelistBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<CodelistBean> getURN() {
        return (IURNMaintainable<CodelistBean>) super.getURN();
    }
    
    @Override
    public CodelistBean cloneForDate(Date date) {
        return (CodelistBean)super.cloneForDate(date);
    }

    @Override
    public CodelistMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
    
    @Override
    public CodelistBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return (CodelistBean)super.filterItems(filterIds, isKeepSet);
    }
    
    @Override
    public MAINT_VALIDITY_TYPE getValidityType() {
        return validityType;
    }

    @Override
    public int getCodeMinLength() {
        return load().getCodeMinLength();
    }

    @Override
    public int getCodeMaxLength() {
        return load().getCodeMaxLength();
    }

    @Override
    public CodelistBean removePrefix(String prefix) {
        return load().removePrefix(prefix);
    }

    @Override
    public boolean isGeoCodelist() {
        return false;
    }

    @Override
    public List<CodeBean> getRootCodes() {
        return load().getRootCodes();
    }

    @Override
    public List<CodeBean> getChildren(String id) {
        return load().getChildren(id);
    }

    @Override
    public boolean createdFromTimeRequest() {
        return load().createdFromTimeRequest();
    }

    @Override
    public boolean isInherited() {
        return isInherited;
    }

    @Override
    public boolean hasInherited() {
        return load().hasInherited();
    }

    @Override
    public List<ICodelistInheritanceRuleBean> getInheritedCodelists() {
        return load().getInheritedCodelists();
    }

    @Override
    public CodelistBean getRootCodelist() {
        return load().getRootCodelist();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return CodelistBean.class;
    }

}
