package io.sdmx.im.beans.mapping.v3;

import java.util.Collections;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;

/**
 * Defines the rule for a mapping from a single source value for example 
 * to map a value GBP, the value should simply be GBP.  However complex rules such as value must
 * start with GBP can be applied using value as GBP and an end index of 2 (0 indexed) which is interpreted as
 * the first three letters should be GBP.  The value may also be a regular expression used to pattern match.
 */
public class MappedValueBean extends SDMXBeanImpl implements IMappedValueBean {
	private static final long serialVersionUID = 1L;
	private String value;
	private boolean isRegEx;
	private int startIndex;
	private int endIndex;
	private transient Pattern pattern;

	public MappedValueBean(IMappedValueMutableBean createdFrom, IMappedRelationshipBean parent) {
		super(createdFrom, parent);
		this.value = createdFrom.getValue();
		this.isRegEx = createdFrom.isRegEx();
		if(createdFrom.getStartIndex() > 0) {
			this.startIndex = createdFrom.getStartIndex();
		}
		if(createdFrom.getEndIndex() > 0) {
			this.endIndex = createdFrom.getEndIndex();
		}
		
	}

	@Override
	public Pattern getPattern() {
		if(isRegEx && pattern== null) {
			pattern = Pattern.compile(value);
		}
		return pattern;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public boolean isRegEx() {
		return isRegEx;
	}

	@Override
	public int getStartIndex() {
		return startIndex;
	}

	@Override
	public int getEndIndex() {
		return endIndex;
	}

	@Override
	public String getKey() {
		return toString();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean == null) {
			if(diffReport != null) {
				diffReport.addDiff(this, "MappedValue", this.toString(), null);
			}
			return false;
		}
		return this.equals(bean, diffReport);
	}


	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return Collections.emptySet();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		return equals(this, null);
	}

	private boolean equals(Object obj, DiffReport diffReport) {
		boolean returnVal = true;
		if(obj instanceof MappedValueBean) {
			MappedValueBean mappedValue = (MappedValueBean) obj;
			if(!super.equivalent(isRegEx(), mappedValue.isRegEx(), Properties.REG_EX.getProperty(), diffReport)) {
				returnVal = false;
			}
			if(!super.equivalent(getStartIndex(), mappedValue.getStartIndex(), Properties.SUBSTRING_START_IDX.getProperty(), diffReport)) {
				returnVal = false;
			}
			if(!super.equivalent(getEndIndex(), mappedValue.getEndIndex(), Properties.SUBSTRING_END_IDX.getProperty(), diffReport)) {
				returnVal = false;
			}
			if(!super.equivalent(getValue(), mappedValue.getValue(), Properties.MAPPED_VALUE.getProperty(), diffReport)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		return this.getValue()+"+"+getStartIndex()+"+"+getEndIndex()+"+"+isRegEx;
	}
}
