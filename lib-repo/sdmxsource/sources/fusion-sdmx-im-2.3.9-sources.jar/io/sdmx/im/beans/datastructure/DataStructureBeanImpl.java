package io.sdmx.im.beans.datastructure;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class DataStructureBeanImpl extends MaintainableBeanImpl implements DataStructureBean {
	private static final Logger LOG = LoggerFactory.getLogger(DataStructureBeanImpl.class);
	private static final long serialVersionUID = 195L;
	private List<GroupBean> groups = new ArrayList<>();
	private DimensionListBean dimensionList;
	private AttributeListBean attributeList;
	private MeasureListBean measureList;
	private DimensionBean timeDimension;
	private IDirectCrossReferenceBean<MetadataStructureDefinitionBean> msdRef;

	private transient Map<String, ComponentBean> componentMap;
	private transient IMetadataStandard defaultStructureFormat;
	private transient List<String> dimensionIds;
	private transient Map<SDMX_SCHEMA, Boolean> compatibilityMap = new HashMap<>();

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	DataStructureBeanImpl(DataStructureBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub DataStructureBean Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataStructureBeanImpl(DataStructureMutableBean bean) {
		super(bean);
		LOG.debug("Building DataStructureBean from Mutable Bean");
		try {
			if(bean.getMeasureList() != null) {
				this.measureList = new MeasureListBeanImpl(bean.getMeasureList(), this);
				if(!ObjectUtil.validCollection(this.measureList.getMeasures())) {
					this.measureList = null;
				}
			}
			if(bean.getDimensionList() != null) {
				this.dimensionList = new DimensionListBeanImpl(bean.getDimensionList(), this);
			}
			if(bean.getAttributeList() != null) {
				this.attributeList = new AttributeListBeanImpl(bean.getAttributeList(), this);
			}
			if(bean.getGroups() != null) {
				for(GroupMutableBean mutable : bean.getGroups()) {
					this.groups.add(new GroupBeanImpl(mutable, this));
				}
			}
			if(bean.getMSDReference() != null) {
				this.msdRef = DirectCrossReferenceBean.build(this, "msd", bean.getMSDReference(), MetadataStructureDefinitionBean.class);
			}
			componentMap = null;  //ensure the map is set back to null in case it was created by components calling on parent methods during construction
			
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("DataStructureBean Built " + this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			DataStructureBean that = (DataStructureBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(groups, that.getGroups(), includeFinalProperties, "Group", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(dimensionList, that.getDimensionList(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(attributeList, that.getAttributeList(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(measureList, that.getMeasureList(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.msdRef, that.getMSDRef(), diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	private void validate() throws SdmxSemmanticException {
		for(DimensionBean dimension : getDimensions()) {
			if(dimension.isTimeDimension()) {
				timeDimension = dimension;
			}
		}
		if(this.msdRef != null) {
			if(this.msdRef.getMaintainableStructureType() != SDMX_STRUCTURE_TYPE.MSD) {
				throw new SdmxSemmanticException("MSD Reference can not reference a structure of type: "+this.msdRef.getMaintainableStructureType().getType());
			}
		}
		if(!isExternalReference) {
			Map<String, DimensionBean> dimensionMap = new HashMap<>();

			Set<String> conceptIds = new HashSet<>();
			Set<Integer> dimPos = new HashSet<>();

			//VALIDATE DIMENSIONS
			if(!ObjectUtil.validCollection(getDimensions())) {
				throw new SdmxSemmanticException("DSD must have at least one dimension");
			}
			for(DimensionBean dimension : getDimensions()) {
				if(dimension.getId().equals(PrimaryMeasureBean.FIXED_ID)) {
					throw new SdmxSemmanticException("Dimension can not have an Id of '"+PrimaryMeasureBean.FIXED_ID+"', this is reserved for the Primary Measure");
				}
				if(dimPos.contains(dimension.getPosition())) {
					throw new SdmxSemmanticException("Two dimensions can not share the same dimension position : " + dimension.getPosition());
				}
				dimPos.add(dimension.getPosition());
				String conceptId = dimension.getId();
				validateUniqueComponentBean(conceptIds, dimension);
				dimensionMap.put(conceptId, dimension);
			}

			//VALIDATE ONLY ONE FREQUENCY DIMENSION
			boolean foundFreq = false;
			for(DimensionBean dimension : getDimensions()) {
				if(dimension.isFrequencyDimension()) {
					if(foundFreq) {
						throw new SdmxSemmanticException("DataStructure can not have more then one frequency dimension");
					}
					foundFreq = true;
				}
			}

			//VALIDATE GROUPS
			Set<String> groupIds = new HashSet<>();
			if(groups != null) {
				for(GroupBean group : groups) {
					if(groupIds.contains(group.getId())) {
						throw new SdmxSemmanticException(ExceptionCode.KEY_FAMILY_DUPLICATE_GROUP_ID,  group.getId());
					}
					groupIds.add(group.getId());
				}
			}

			if(this.getMeasureList() != null) {
				for(MeasureDimensionBean measure : this.getMeasureList().getMeasures()) {
					validateUniqueComponentBean(conceptIds, measure);
				}
			}


			//VALIDATE ATTRIBUTES
			for(AttributeBean currentBean : getAttributes()) {
				if(currentBean.getId().equals(PrimaryMeasureBean.FIXED_ID)) {
					throw new SdmxSemmanticException("Attribute can not have an Id of '"+PrimaryMeasureBean.FIXED_ID+"', this is reserved for the Primary Measure");
				}
				if(currentBean.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
					throw new SdmxSemmanticException("Attribute can not have an Id of '"+DimensionBean.TIME_DIMENSION_FIXED_ID+"', this is reserved for the Time Dimension");
				}
				validateUniqueComponentBean(conceptIds, currentBean);
				if(currentBean.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.GROUP) {
					if(currentBean.getAttachmentGroup() == null) {
						throw new SdmxSemmanticException(ExceptionCode.KEY_FAMILY_GROUP_ATTRIBUTE_MISSING_GROUPID,  currentBean.toString());
					}
					if(!groupIds.contains(currentBean.getAttachmentGroup())) {
						throw new SdmxSemmanticException(ExceptionCode.REFERENCE_ERROR,  SDMX_STRUCTURE_TYPE.GROUP, SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE, currentBean.toString());
					}
				}
				for(String currentDimRef : currentBean.getDimensionReferences()) {
					if(!dimensionMap.containsKey(currentDimRef)) {
						throw new SdmxSemmanticException("Attribute relationship references Dimension '"+currentDimRef+"' which is not defined in the Data Structure '"+getId()+"'");
					}
				}
			}
		}
	}

	
	@Override
	/**
	 * Returns false if this data structure is not compatible with the target schema version.
	 * <p/>
	 * For SDMX Version 1.0 all dimensions had to be coded.
	 * <p/>
	 * For SDMX Version 1.0 and 2.0 each components had to reference a concept with a unique id
	 * <p/>
	 * For EDI ?
	 * 
	 * @param schemaVersion
	 * @return
	 */
	public boolean isCompatible(SDMX_SCHEMA schemaVersion) {
		Boolean isCompatible = this.compatibilityMap.get(schemaVersion);
		if(isCompatible == null) {
			isCompatible = checkCompatibility(schemaVersion);
			this.compatibilityMap.put(schemaVersion, isCompatible);
		}
		return isCompatible;
	}
	
	private boolean checkCompatibility(SDMX_SCHEMA schemaVersion) {
		switch(schemaVersion) {
		case VERSION_ONE:
			for(ComponentBean currentComponent : getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
				if(currentComponent.getRepresentation() == null || currentComponent.getRepresentation().getRepresentation() == null) {
					return false;
				}
			}
			//Intentionally no break, as version 2.0 compatibility checks also apply to version 1.0
		case VERSION_TWO :
			Set<String> componentIds = new HashSet<>();
			for(ComponentBean currentComponent : getComponents()) {
				if(currentComponent.getConceptRef().getTargetReference() == SDMX_STRUCTURE_TYPE.CONCEPT) {
					String conceptId = currentComponent.getConceptRef().getReference().getIdentifiableId();
					if(componentIds.contains(conceptId)) {
						return false;
					}
					componentIds.add(conceptId);
				}
			}
		case VERSION_TWO_POINT_ONE :
			if(isExternalReference == false) {
				if(this.getMeasures().size() != 1 || this.getMeasure(PrimaryMeasureBean.FIXED_ID) == null) {
					return false;
				} else {
					for(ICrossReferenceBean<?> xsRef : getCrossReferences()) {
						if(xsRef.getTargetReference() == SDMX_STRUCTURE_TYPE.VALUE_LIST) {
							return false;
						}
					}
				}
			}
			break;
		case VERSION_THREE :
			if(isExternalReference == false) {
				for(DimensionBean dim : this.getDimensionList().getDimensions()) {
					if(dim.getConceptScheme() != null) {
						return false;
					}
				}
			}
		default :
			break;
		}
		return true;
	}

	private void validateUniqueComponentBean(Set<String> conceptIds, ComponentBean componentBean) {
		String conceptId = componentBean.getId();
		if(conceptIds.contains(conceptId)) {
			throw new SdmxSemmanticException("Duplicate Data Structure Component Id : "+ conceptId);
		}
		conceptIds.add(conceptId);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return DataStructureBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<DataStructureBean> getURN() {
		return (IURNMaintainable<DataStructureBean>)super.getURN();
	}
	
	@Override
	/**
	 * Change the default format based on whether it is SDMX compatible or not
	 */
	public IMetadataStandard getDefaultStandard() {
		if(defaultStructureFormat == null) {
			defaultStructureFormat = super.getDefaultStandard();
		}
		return defaultStructureFormat;
	}

	@Override
	public DataStructureBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new DataStructureBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}


	@Override
	public List<String> getDimensionIds() {
		if(dimensionIds == null) {
			this.dimensionIds = Collections.unmodifiableList(SdmxCollectionUtil.identifiablesIdList(this.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)));
		}
		return dimensionIds;
	}

	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		return Collections.emptyList();
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(this.getMSDRef() != null) {
			references.add(this.getMSDRef());
		}
	}

	@Override
	public DataStructureMutableBean getMutableInstance() {
		return new DataStructureMutableBeanImpl(this);
	}

	@Override
	public DimensionListBean getDimensionList() {
		return dimensionList;
	}

	@Override
	public AttributeListBean getAttributeList() {
		return attributeList;
	}

	@Override
	public MeasureListBean getMeasureList() {
		return measureList;
	}
	
	@Override
	public ICrossReferenceBean<MetadataStructureDefinitionBean> getMSDRef() {
		return this.msdRef;
	}

	@Override
	public int getDimensionIndex(String id) {
		int i = 0;
		for(DimensionBean dim : getDimensionList().getDimensions()) {
			if(dim.getId().equals(id)) {
				return i;
			}
			i++;
		}
		return -1;
	}

	@Override
	public List<MeasureDimensionBean> getMeasures() {
		if(this.getMeasureList() != null) {
			return this.getMeasureList().getMeasures();
		}
		return Collections.emptyList();
	}

	@Override
	public List<ComponentBean> getComponents() {
		List<ComponentBean>  returnList = new ArrayList<>();
		returnList.addAll(getDimensionList().getDimensions());
		returnList.addAll(getAttributes());
		returnList.addAll(getMeasures());
		return returnList;
	}

	@Override
	public AttributeBean getAttribute(String id) {
		if(ObjectUtil.validString(id)) {
			ComponentBean dim = getComponent(id);
			if(dim == null || dim.getStructureType() != SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
				return null;
			}
			return (AttributeBean) dim;
		}
		return null;
	}

	@Override
	public MeasureDimensionBean getMeasure(String id) {
		if(ObjectUtil.validString(id)) {
			ComponentBean dim = getComponent(id);
			if(dim == null || dim.getType() != ComponentBean.COMPONENT_TYPE.MEASURE) {
				return null;
			}
			return (MeasureDimensionBean) dim;
		}
		return null;
	}


	@Override
	public List<AttributeBean> getSeriesAttributes(String crossSectionalConcept) {
		if(crossSectionalConcept == null) {
			return getDimensionGroupAttributes();
		}
		List<AttributeBean> returnList = new ArrayList<>();
		for(AttributeBean att : this.getDimensionGroupAttributes()) {
			if(!att.getDimensionReferences().contains(crossSectionalConcept)) {
				returnList.add(att);
			}
		}
		for(AttributeBean att : this.getObservationAttributes()) {
            if(ObjectUtil.validCollection(att.getDimensionReferences()) && !att.getDimensionReferences().contains(crossSectionalConcept)) {
                returnList.add(att);
            }
		}
		return returnList;
	}


	@Override
	public List<AttributeBean> getObservationAttributes(String crossSectionalConcept) {
		if(crossSectionalConcept == null) {
			return getObservationAttributes();
		}
		List<AttributeBean> returnList = new ArrayList<>();
		for(AttributeBean att : this.getDimensionGroupAttributes()) {
			if(att.getDimensionReferences().contains(crossSectionalConcept)) {
				returnList.add(att);
			}
		}
		returnList.addAll(getObservationAttributes());
		return returnList;
	}


	@Override
	public List<DimensionBean> getDimensions(SDMX_STRUCTURE_TYPE... includeTypes) {
		if(dimensionList != null) {
			List<DimensionBean> returnList = new ArrayList<>();
			for(DimensionBean dim : dimensionList.getDimensions()) {
				if(includeTypes != null && includeTypes.length > 0) {
					for(SDMX_STRUCTURE_TYPE currentType : includeTypes) {
						if(currentType == dim.getStructureType()) {
							returnList.add(dim);
							break;
						}
					}
				} else {
					returnList.add(dim);
				}
			}
			return returnList;
		}
		return new ArrayList<>();
	}

	@Override
	public DimensionBean getDimension(String conceptId) {
		ComponentBean dim = getComponent(conceptId);
		if(dim == null) {
			return null;
		}
		if(dim instanceof DimensionBean) {
			return (DimensionBean) dim;
		}
		return null;

	}

	@Override
	public DimensionBean getFrequencyDimension() {
		for(DimensionBean currentDimension : getDimensions()) {
			if(currentDimension.isFrequencyDimension()) {
				return currentDimension;
			}
		}
		return null;
	}

	@Override
	public boolean hasFrequencyDimension() {
		for(DimensionBean currentDimension : getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
			if(currentDimension.isFrequencyDimension()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public ComponentBean getComponent(String conceptId) {
		if(conceptId == null) {
			return null;
		}
		if(this.componentMap == null) {
			createComponentMap();
		}
		return this.componentMap.get(conceptId);
	}

	private void createComponentMap() {
		if(this.componentMap == null) {
			Map<String, ComponentBean> componentMap = new HashMap<>();
			for(ComponentBean comp : this.getComponents()) {
				componentMap.put(comp.getId(), comp);
			}
			this.componentMap = Collections.unmodifiableMap(componentMap);
		}
	}


	@Override
	public List<GroupBean> getGroups() {
		return new ArrayList<>(groups);
	}

	@Override
	public GroupBean getGroup(String groupId) {
		for(GroupBean currentGroup : groups) {
			if(currentGroup.getId().equals(groupId)) {
				return currentGroup;
			}
		}
		return null;
	}

	@Override
	public DimensionBean getTimeDimension() {
		return timeDimension;
	}

	@Override
	public PrimaryMeasureBean getPrimaryMeasure() {
		if(measureList != null) {
			return measureList.getPrimaryMeasure();
		}
		return null;
	}


	@Override
	public List<AttributeBean> getAttributes() {
		if(attributeList != null) {
			return attributeList.getAttributes();
		}
		return new ArrayList<>();
	}

	@Override
	public List<AttributeBean> getDatasetAttributes() {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
	}

	@Override
	public List<AttributeBean> getGroupAttributes(String groupId, boolean includeDimensionGroups) {
		GroupBean group = getGroup(groupId);
		if(group == null) {
			throw new IllegalArgumentException("Group not found on Data Structure '"+getUrn()+"' with id: " + groupId);
		}
		List<AttributeBean> allGroupAttributes =  getGroupAttributes();
		List<AttributeBean> returnList = new ArrayList<>();

		for(AttributeBean currentAttribute : allGroupAttributes) {
			if(currentAttribute.getAttachmentGroup() != null) {
				if(currentAttribute.getAttachmentGroup().equals(groupId)) {
					returnList.add(currentAttribute);
				}
			}
		}

		if(includeDimensionGroups) {
			for(AttributeBean cuAttributeBean : getDimensionGroupAttributes()) {
				List<String> attrDimRefs = cuAttributeBean.getDimensionReferences();
				List<String> grpDimRefs = group.getDimensionRefs();
				if(attrDimRefs.containsAll(grpDimRefs) && grpDimRefs.containsAll(attrDimRefs)) {
					returnList.add(cuAttributeBean);
				}
			}
		}
		return returnList;
	}

	@Override
	public List<AttributeBean> getGroupAttributes() {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP);
	}

	@Override
	public List<AttributeBean> getDimensionGroupAttributes() {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
	}

	@Override
	public List<AttributeBean> getObservationAttributes() {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
	}

	@Override
	public AttributeBean getGroupAttribute(String conceptId) {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP, conceptId);
	}

	@Override
	public AttributeBean getDimensionGroupAttribute(String conceptId) {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP, conceptId);
	}

	@Override
	public AttributeBean getObservationAttribute(String conceptId) {
		return getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION, conceptId);
	}

	private List<AttributeBean> getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL type) {
		List<AttributeBean> returnList = new ArrayList<>();
		for(AttributeBean currentAttribute : getAttributes()) {
			if(currentAttribute.getAttachmentLevel() == type) {
				returnList.add(currentAttribute);
			}
		}
		return returnList;
	}

	private AttributeBean getAttribute(ATTRIBUTE_ATTACHMENT_LEVEL type, String conceptId) {
		for(AttributeBean currentAttribute : getAttribute(type)) {
			if(currentAttribute.getId().equals(conceptId)) {
				return currentAttribute;
			}
		}
		return null;
	}

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				             //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(groups, composites);
        super.addToCompositeSet(dimensionList, composites);
        super.addToCompositeSet(attributeList, composites);
        super.addToCompositeSet(measureList, composites);
        return composites;
    }

    @Override
    public DataStructureBeanDeferred toDeferred() {
        return new DataStructureBeanDeferred(this);
    }
    
    @Override
    public DataStructureBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new DataStructureBeanDeferred(getDeferredDefinition(), loader);
    }
}