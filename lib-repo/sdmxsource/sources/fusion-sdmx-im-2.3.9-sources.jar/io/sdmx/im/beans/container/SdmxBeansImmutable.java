package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * An SdmxBeans implementation that prevents any modifications.
 */
public class SdmxBeansImmutable extends AbstractSdmxBeansProxy {
	public static final SdmxBeans EMPTY_BEANS = new SdmxBeansImmutable(new SdmxBeansImpl());
	private static final long serialVersionUID = 1L;
	
	public SdmxBeansImmutable(SdmxBeans beans) {
		super(beans);
	}
	
	private void throwException() {
		throw new SdmxException("SdmxBeansImmutable can not be modified");
	}
	
	@Override
	public List<ILinkBean> getLinks() {
		return Collections.unmodifiableList(super.getLinks());
	}

	@Override
	public void addLink(ILinkBean link) {
		throwException();
	}
	
	@Override
	public SdmxBeans getReadOnlyCopy() {
		return this;
	}

	@Override
	public void setAction(DATASET_ACTION action) {
		throwException();
	}

	@Override
	public void merge(SdmxBeans beans) {
		throwException();
	}

	@Override
	public void merge(SdmxBeans beans, boolean overwrite) {
		throwException();
	}

	@Override
	public void clear() {
		throwException();
	}

	@Override
	public void setHeader(HeaderBean header) {
		throwException();
	}

	@Override
	public void addIdentifiables(Collection<? extends IdentifiableBean> beans) {
		throwException();
	}

	@Override
	public boolean addIdentifiable(IdentifiableBean bean) {
		throwException();
		return false;
	}

	@Override
	public void removeMaintainable(MaintainableBean bean) {
		throwException();
	}

	@Override
	public SdmxBeans filterMaintainables(Predicate<? super MaintainableBean> predicate) {
		return new SdmxBeansImmutable(super.filterMaintainables(predicate));
	}
	
	@Override
	public String toString() {
		return this.getAllMaintainables().toString();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxBeansImmutable) {
			SdmxBeansImmutable that = (SdmxBeansImmutable) obj;
			Set<MaintainableBean> m1 = this.getAllMaintainables();
			Set<MaintainableBean> m2 = that.getAllMaintainables();
			return ObjectUtil.equivalentCollection(m1, m2);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}
}
