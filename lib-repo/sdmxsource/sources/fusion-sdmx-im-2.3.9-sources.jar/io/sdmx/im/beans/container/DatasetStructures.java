package io.sdmx.im.beans.container;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class DatasetStructures implements IDatasetStructures {
	private DataStructureBean dataStructure;
	private DataflowBean dataflow;
	private ProvisionAgreementBean provisionAgreement;
	private DataProviderBean dataProvider;

	public DatasetStructures(DataStructureBean dataStructure) {
		this.dataStructure = dataStructure;
		validate();
	}

	public DatasetStructures(DataStructureBean dataStructure, DataflowBean dataflow, ProvisionAgreementBean provisionAgreement, DataProviderBean dataProvider) {
		this.dataStructure = dataStructure;
		this.dataflow = dataflow;
		this.provisionAgreement = provisionAgreement;
		this.dataProvider = dataProvider;
		validate();
	}

	public DatasetStructures(ConstrainableBean maint, SdmxBeanRetrievalManager beanRetrievalManager) {
		switch(maint.getStructureType()) {
		case PROVISION_AGREEMENT : 
			provisionAgreement = (ProvisionAgreementBean) maint;
			dataProvider = beanRetrievalManager.getBean(provisionAgreement.getDataproviderRef().getReference());
			resolveDataflow(provisionAgreement.getStructureUseage().getReference(), beanRetrievalManager);
			break;
		case DATAFLOW :
			dataflow = (DataflowBean) maint;
			resolveDSD(dataflow.getDataStructureRef().getReference(), beanRetrievalManager);
			break;
		case DSD :  
			dataStructure = (DataStructureBean) maint;
			break;
			default : 
				throw new IllegalArgumentException(maint.getUrn());
		}
	}

	@Deprecated
	public DatasetStructures(StructureReferenceBean sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		this(URN.getInstanceSingle(ConstrainableBean.class, sRef.getTargetUrn()), beanRetrievalManager);
	}
	
	
	
	public DatasetStructures(IURNSingle<? extends ConstrainableBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		switch(sRef.getSdmxStructure()) {
		case PROVISION_AGREEMENT : 
			resolveProvisionAgreement(sRef, beanRetrievalManager);
			break;
		case DATAFLOW :
			resolveDataflow(sRef, beanRetrievalManager);
			break;
		case DSD :
			resolveDSD(sRef, beanRetrievalManager);
			break;
		default : 
			throw new IllegalArgumentException(sRef.toString());
		}
	}
	
	private void resolveProvisionAgreement(IURNSingle<? extends ConstrainableBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		provisionAgreement = beanRetrievalManager.getBean(sRef.toType(ProvisionAgreementBean.class));
		if(provisionAgreement == null) {
			throw new SdmxReferenceException(sRef);
		}
		try {
			this.dataProvider = beanRetrievalManager.getBean(provisionAgreement.getDataproviderRef().getReference());
		} catch(Throwable th) {
			//Unresolvable
		}
		resolveDataflow(provisionAgreement.getStructureUseage().getReference(), beanRetrievalManager);
	}

	
	private void resolveDataflow(IURNSingle<? extends ConstrainableBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		dataflow = beanRetrievalManager.getBean(sRef.toType(DataflowBean.class));
		if(dataflow == null) {
			throw new SdmxReferenceException(sRef);
		}
		resolveDSD(dataflow.getDataStructureRef().getReference(), beanRetrievalManager);
	}

	
	private void resolveDSD(IURNSingle<? extends ConstrainableBean> sRef, SdmxBeanRetrievalManager beanRetrievalManager) {
		dataStructure = beanRetrievalManager.getBean(sRef.toType(DataStructureBean.class));
		if(dataStructure == null) {
			throw new SdmxReferenceException(sRef);
		}
	}

	private void validate() {
		if(this.dataStructure == null) {
			throw new SdmxException("IDatasetStructures -> DataStructure can not be null");
		}
	}

	@Override
	public DataStructureBean getDataStructure() {
		return dataStructure;
	}

	@Override
	public DataflowBean getDataflow() {
		return dataflow;
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return provisionAgreement;
	}

	@Override
	public DataProviderBean getDataProvider() {
		return dataProvider;
	}

	@Override
	public String toString() {
		return dataStructure.toString();
	}

	private int hashCode = -1;
	
	@Override
	public int hashCode() {
		if(hashCode == -1) {
			StringBuilder sb = new StringBuilder();
			appendIdent(dataStructure, sb);
			appendIdent(dataflow, sb);
			appendIdent(provisionAgreement, sb);
			appendIdent(dataProvider, sb);
			hashCode = sb.toString().hashCode();
		}
		return hashCode;
	}
	
	private void appendIdent(IdentifiableBean ident, StringBuilder sb) {
		if(ident == null) {
			sb.append("-");
		}
		sb.append(ident.getUrn());
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof DatasetStructures) {
			DatasetStructures that = (DatasetStructures) obj;
			if(!ObjectUtil.equivalent(this.dataStructure, that.getDataStructure())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.dataflow, that.getDataflow())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.provisionAgreement, that.getProvisionAgreement())) {
				return false;
			}
			if(!ObjectUtil.equivalent(this.dataProvider, that.getDataProvider())) {
				return false;
			}
			return true;
		}
		return false;
	}



}
