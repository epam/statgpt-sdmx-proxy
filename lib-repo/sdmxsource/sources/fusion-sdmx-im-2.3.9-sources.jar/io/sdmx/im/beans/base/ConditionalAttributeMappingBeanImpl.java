package io.sdmx.im.beans.base;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.CONDITION;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ConditionalAttributeMappingBeanMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConditionalAttributeMappingBeanImpl extends SDMXBeanImpl implements ConditionalAttributeMappingBean {
	private static final long serialVersionUID = 13L;
	private String attributeValue;
	private CONDITION condition;
	private String conditionDetail;

	public ConditionalAttributeMappingBeanImpl(ConditionalAttributeMappingBeanMutableBean mutable, ReportingTemplateConditionalAttributeBean parent) {
		super(mutable, parent);
		this.attributeValue = mutable.getAttributeValue();
		this.condition = mutable.getCondition();
		this.conditionDetail = mutable.getConditionDetail();
		validate();
	}

	private void validate() {
		if(!ObjectUtil.validString(attributeValue)) {
			throw new SdmxSemmanticException("Report Template Attribute Condition must have an output attribute value");
		}
		if(condition == null) {
			throw new SdmxSemmanticException("Report Template Attribute Condition for '"+attributeValue+"' must have a Condition");
		}
		switch(condition) {
		case ATTRIBUTE_NOTPRESENT :
		case ATTRIBUTE_PRESENT :
			if(!ObjectUtil.validString(conditionDetail)) {
				throw new SdmxSemmanticException("Report Template Attribute Condition "+condition+" must also define the attribute id in the condition rule");
			}
			break;
		case ATTRIBUTE_VALUE :
			if(!ObjectUtil.validString(conditionDetail)) {
				throw new SdmxSemmanticException("Report Template Attribute Condition "+condition+" must also define the attribute id and value in the condition rule");
			}
			if(!conditionDetail.contains(".")) {
				throw new SdmxSemmanticException("A Report Template Attribute conditional on Attribute value must define the attribute id and value in the condition rule, in the syntax ATT_ID.ATT_VAL for example  OBS_VALUE.A");
			}
			break;
		case OBSERAVTION_VALUE :
			String err = "Report Template Attribute conditional on the Observation value must define the equlaity operator and observation value in the rule in the syntax EQUALITY.OBS_VAL for example gt.100 (greater than 100)";
			if(!ObjectUtil.validString(conditionDetail)) {
				throw new SdmxSemmanticException(err);
			}
			if(!conditionDetail.contains(".")) {
				throw new SdmxSemmanticException(err);
			}
			String[] split = conditionDetail.split("\\.");
			String eq = split[0];
			EQUALITY.fromString(eq);  //Try to parse equality
			break;
		default :
			conditionDetail = null;
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ConditionalAttributeMappingBean that = (ConditionalAttributeMappingBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.getAttributeValue(), that.getAttributeValue(), "attribute value", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getCondition(), that.getCondition(), "rule", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getConditionDetail(), that.getConditionDetail(), "rule detail", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>();
	}

	@Override
    public boolean equals(Object obj) {
        if(obj instanceof ConditionalAttributeMappingBean) {
            ConditionalAttributeMappingBean that = (ConditionalAttributeMappingBean)obj;

            if (!this.getAttributeValue().equals(that.getAttributeValue())) {
                return false;
            }

            if (!this.getCondition().equals(that.getCondition())) {
                return false;
            }

            if (this.getConditionDetail() != null) {
                if (!this.getConditionDetail().equals(that.getConditionDetail())) {
                    return false;
                }
            }

            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (this.getAttributeValue() + this.getCondition() + this.getConditionDetail()).hashCode();
    }

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public String getKey() {
		return getAttributeValue();
	}

	@Override
	public String getAttributeValue() {
		return attributeValue;
	}

	@Override
	public CONDITION getCondition() {
		return condition;
	}

	@Override
	public String getConditionDetail() {
		return conditionDetail;
	}

	@Override
	public String toString() {
		String detail = getConditionDetail() != null ? " "+ getConditionDetail() : "";
		return getAttributeValue() + " " + getCondition().getHumanReadable() +  detail;
	}

}
