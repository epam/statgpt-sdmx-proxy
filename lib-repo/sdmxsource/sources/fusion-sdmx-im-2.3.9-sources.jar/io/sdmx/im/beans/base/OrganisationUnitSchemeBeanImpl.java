package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class OrganisationUnitSchemeBeanImpl extends ItemSchemeBeanImpl<OrganisationUnitBean> implements OrganisationUnitSchemeBean {
	private static final Logger LOG = LoggerFactory.getLogger(OrganisationUnitSchemeBeanImpl.class);
	private static final long serialVersionUID = 148L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	OrganisationUnitSchemeBeanImpl(OrganisationUnitSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub OrganisationUnitSchemeBean Built");
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public OrganisationUnitSchemeBeanImpl(OrganisationUnitSchemeMutableBean bean) {
		super(bean);
		LOG.debug("Building OrganisationUnitSchemeBean from Mutable Bean");
		if(bean.getItems() != null) {
			for(OrganisationUnitMutableBean oumb : bean.getItems()) {
				items.add(new OrganisationUnitBeanImpl(oumb, this));
			}
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("OrganisationUnitSchemeBean Built " + this.getUrn());
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((OrganisationUnitSchemeBean)bean, includeFinalProperties, "Organisation Unit", diff);
		}
		return false;
	}
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		//CHECK FOR DUPLICATION OF URN & ILLEGAL PARENTING
		Map<OrganisationUnitBean, Set<OrganisationUnitBean>> parentChildMap = new HashMap<>();
		for(OrganisationUnitBean currentUnit : this.getItems()) {
			if(ObjectUtil.validString(currentUnit.getParentUnit())) {
				OrganisationUnitBean parentUnit = getUnit(currentUnit.getParentUnit());
				Set<OrganisationUnitBean> children;
				if(parentChildMap.containsKey(parentUnit)) {
					children = parentChildMap.get(parentUnit);
				} else {
					children = new HashSet<>();
					parentChildMap.put(parentUnit, children);
				}
				children.add(currentUnit);
				//Check that the parent code is not directly or indirectly a child of the code it is parenting
				recurseParentMap(parentChildMap.get(currentUnit), parentUnit, parentChildMap);
			}
		}
		if(items != null) {
			items = Collections.unmodifiableList(items);
		}
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<OrganisationUnitSchemeBean> getURN() {
		return (IURNMaintainable<OrganisationUnitSchemeBean>) super.getURN();
	}
	
	@Override
	public ISdmxVersion getVersion() {
		return SdmxVersion.DEFAULT;
	}
	
	@Override
	public boolean isFixedVersion() {
		return true;
	}

	private OrganisationUnitBean getUnit(String id) {
		for(OrganisationUnitBean organisationUnitBean : this.getItems()) {
			if(organisationUnitBean.getId().equals(id)) {
				return organisationUnitBean;
			}
		}
		throw new SdmxSemmanticException(ExceptionCode.CAN_NOT_RESOLVE_PARENT, id);
	}
	
	
	/**
	 * Recurses the map checking the children of each child, if one of the children is the parent code, then an exception is thrown
	 * @param children
	 * @param parentBean
	 * @param parentChildMap
	 */
	private void recurseParentMap(Set<OrganisationUnitBean> children, OrganisationUnitBean parentBean, Map<OrganisationUnitBean, Set<OrganisationUnitBean>> parentChildMap) {
		//If the child is also a parent
		if(children != null) {
			if(children.contains(parentBean)) {
				throw new SdmxSemmanticException(ExceptionCode.PARENT_RECURSIVE_LOOP, parentBean.getId());
			}
			for(OrganisationUnitBean currentChild : children) {
				recurseParentMap(parentChildMap.get(currentChild), parentBean, parentChildMap);
			}
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return OrganisationUnitSchemeBean.class;
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new OrganisationUnitSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}
	
	@Override
	public OrganisationUnitSchemeMutableBean getMutableInstance() {
		return new OrganisationUnitSchemeMutableBeanImpl(this);
	}

    @Override
    public OrganisationUnitSchemeBeanDeferred toDeferred() {
        return new OrganisationUnitSchemeBeanDeferred(this);
    }
    
    @Override
    public OrganisationUnitSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationUnitSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
