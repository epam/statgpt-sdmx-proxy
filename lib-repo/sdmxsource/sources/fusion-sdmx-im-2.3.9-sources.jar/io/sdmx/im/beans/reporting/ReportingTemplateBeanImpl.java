package io.sdmx.im.beans.reporting;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.format.FusionMetadataStandard;
import io.sdmx.im.mutable.reporting.ReportingTemplateMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReportingTemplateBeanImpl extends MaintainableBeanImpl implements ReportingTemplateBean {
	private static final Logger LOG = LoggerFactory.getLogger(ReportingTemplateBeanImpl.class);
	private static final long serialVersionUID = 11L;
	private List<ReportingTemplateWorksheetBean> worksheets = new ArrayList<>();
	private boolean includeFormulaCheckingSummary;
	private ReportTemplateInstructionSheetBean instructionSheet;

	ReportingTemplateBeanImpl(ReportingTemplateBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	public ReportingTemplateBeanImpl(ReportingTemplateMutableBean bean) {
		super(bean);
		if(bean.getWorksheets() != null) {
			for(ReportingTemplateWorksheetMutableBean worksheet : bean.getWorksheets()) {
				this.worksheets.add(new ReportingTemplateWorksheetBeanImpl(worksheet, this));
			}
		}
		this.includeFormulaCheckingSummary = bean.includeFormulaCheckingSummary();
		if(bean.getInstructionSheet() != null) {
			this.instructionSheet = new ReportTemplateInstructionSheetBeanImpl(bean.getInstructionSheet(), this);
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("DataStructureBean Built " + this.getUrn());
		}
	}

	@Override
	public ReportingTemplateBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ReportingTemplateBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public ReportingTemplateMutableBean getMutableInstance() {
		return new ReportingTemplateMutableBeanImpl(this);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validCollection(worksheets)) {
			throw new SdmxSemmanticException("Reporting Template does not have any worksheets");
		}
		this.worksheets = Collections.unmodifiableList(worksheets);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ReportingTemplateBean that = (ReportingTemplateBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.worksheets, that.getWorksheets(), includeFinalProperties, "Worksheet", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.includeFormulaCheckingSummary, that.includeFormulaCheckingSummary(), "Include Formula Check Summary", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.instructionSheet, that.getInstructionSheet(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(worksheets, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////OVERRIDE DEFAULT FORMAT			     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public IMetadataStandard getDefaultStandard() {
		return FusionMetadataStandard.getInstance();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ReportingTemplateBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<ReportingTemplateBean> getURN() {
		return (IURNMaintainable<ReportingTemplateBean>)super.getURN();
	}
	
	@Override
	public List<ReportingTemplateWorksheetBean> getWorksheets() {
		return worksheets;
	}

	@Override
	public ReportTemplateInstructionSheetBean getInstructionSheet() {
		return instructionSheet;
	}

	@Override
	public boolean includeFormulaCheckingSummary() {
		return includeFormulaCheckingSummary;
	}

    @Override
    public ReportingTemplateBeanDeferred toDeferred() {
        return new ReportingTemplateBeanDeferred(this);
    }
    
    @Override
    public ReportingTemplateBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTemplateBeanDeferred(getDeferredDefinition(), loader);
    }
}
