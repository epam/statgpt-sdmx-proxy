package io.sdmx.im.beans.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.MAPPING_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class CodelistMapBeanImpl extends ItemSchemeMapBeanImpl<CodeMapBean> implements CodelistMapBean {
	private static final long serialVersionUID = 11L;
	private List<CodeMapBean> codeMapBean = new ArrayList<>();
	
	//FR-2922 Support Partial Code Mapping using SubString and RegEx in mapping expressions
	private transient MAPPING_FUNCTION mappingfunction;
	private transient int substringStart;
	private transient int substringEnd;
	private transient Pattern regExPattern;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CodelistMapBeanImpl (CodelistMapMutableBean bean, StructureSetBean parent) {
		super(bean, SDMX_STRUCTURE_TYPE.CODE_LIST_MAP, parent);
		try {
			if(bean.getItems() != null) {
				for(ItemMapMutableBean item : bean.getItems()) {
					CodeMapMutableBean itemCode = ((CodeMapMutableBean)item);
					codeMapBean.add(new CodeMapBeanImpl(itemCode, this));
				}
			}
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(bean.getStructureType() == this.getStructureType()) {
			CodelistMapBean that = (CodelistMapBean) bean;
			return super.deepEqualsInternal(that, includeFinalProperties, "CodeMap", diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(this.sourceRef == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "Source");
		}
		if(this.targetRef == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "Target");
		}
		if(!ObjectUtil.validCollection(this.codeMapBean)) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "CodeMap");
		}
		this.codeMapBean = Collections.unmodifiableList(codeMapBean);
	}
	
	

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return CodelistMapBean.class;
	}
	
	@Override
	protected SDMX_STRUCTURE_TYPE getItemType() {
		return SDMX_STRUCTURE_TYPE.CODE;
	}

	@Override
	public List<CodeMapBean> getItems() {
		return codeMapBean == null ? new ArrayList<>() : codeMapBean;
	}
	
	@Override
	public MAPPING_FUNCTION getMappingFunction() {
		if(mappingfunction == null) {
			processMappingFunctionAnnotation();
		}
		return mappingfunction;
	}


	@Override
	public boolean hasMappingFunction() {
		if(mappingfunction == null) {
			processMappingFunctionAnnotation();
		}
		return mappingfunction != MAPPING_FUNCTION.NONE;
	}

	@Override
	public int getSubStringStart() {
		if(mappingfunction == null) {
			processMappingFunctionAnnotation();
		}
		return substringStart;
	}


	@Override
	public int getSubStringEnd() {
		if(mappingfunction == null) {
			processMappingFunctionAnnotation();
		}
		return substringEnd;
	}


	@Override
	public Pattern getRegExPattern() {
		if(mappingfunction == null) {
			processMappingFunctionAnnotation();
		}
		return regExPattern;
	}
	
	private AnnotationBean getMappingFunctionAnnotation() {
		for(AnnotationBean ann : this.getAnnotationsByType("FR_MAP_FUNCTION")) {
			return ann;
		}
		return null;
	}
	
	private void processMappingFunctionAnnotation() {
		AnnotationBean annotation = getMappingFunctionAnnotation();
		if(annotation == null) {
			mappingfunction = MAPPING_FUNCTION.NONE;
		} else {
			String title = annotation.getTitle();
			if(title == null) {
				mappingfunction = MAPPING_FUNCTION.NONE;
			} else if(title.startsWith("SUBSTRING")) {
				mappingfunction = MAPPING_FUNCTION.SUBSTRING;
				String[] split = title.split(",");
				if(split.length < 2) {
					mappingfunction = MAPPING_FUNCTION.NONE;
				} else {
					substringStart = Integer.parseInt(split[1]);
					if(split.length > 2) {
						substringEnd = Integer.parseInt(split[2]);
					} else {
						substringEnd = -1;
					}
				}
			} else if(title.startsWith("REGEX")) {
				mappingfunction = MAPPING_FUNCTION.REG_EX;
				String[] split = title.split(",", 2);
				if(split.length < 2) {
					mappingfunction = MAPPING_FUNCTION.NONE;
				} else {
					String pattern = split[1];
					try {
						regExPattern = Pattern.compile(pattern);
					} catch(PatternSyntaxException e) {
						throw new SdmxSemmanticException(e, "RegEx pattern '"+pattern+"' is not valid. " +e.getMessage());
					}
				}
			} else {
				mappingfunction = MAPPING_FUNCTION.NONE;
			}
		}
	}
}