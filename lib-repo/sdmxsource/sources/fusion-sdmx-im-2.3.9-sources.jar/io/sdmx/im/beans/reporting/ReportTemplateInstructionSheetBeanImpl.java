package io.sdmx.im.beans.reporting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionSheetMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportTemplateInstructionTextMutableBean;
import io.sdmx.im.beans.base.SDMXBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReportTemplateInstructionSheetBeanImpl extends SDMXBeanImpl implements ReportTemplateInstructionSheetBean {
	private static final long serialVersionUID = 1L;
	private String name;
	private String title;
	private List<ReportTemplateInstructionTextBean> instructions = new ArrayList<>();
	
	public ReportTemplateInstructionSheetBeanImpl(ReportTemplateInstructionSheetMutableBean mutableBean, ReportingTemplateBean parent) {
		super(mutableBean, parent);
		this.name = mutableBean.getName();
		this.title = mutableBean.getTitle();
		if(mutableBean.getInstructions() != null) {
			for(ReportTemplateInstructionTextMutableBean instructionText : mutableBean.getInstructions()) {
				instructions.add(new ReportTemplateInstructionTextBeanImpl(instructionText, this));
			}
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(name)) {
			throw new SdmxSemmanticException("Reporting Template Instruction sheet is missing a name");
		}
		if(!ObjectUtil.validCollection(instructions)) {
			throw new SdmxSemmanticException("Reporting Template Instruction sheet is missing instrution text");
		}
		this.instructions = Collections.unmodifiableList(instructions);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(this.getStructureType() == bean.getStructureType()) {
			ReportTemplateInstructionSheetBean that = (ReportTemplateInstructionSheetBean) bean;
			boolean returnVal = true;
			
			if(!super.equivalent(this.name, that.getName(), "Name", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.title, that.getTitle(), "Title",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.instructions, that.getInstructions(), includeFinalProperties, "Instruction Sheet", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		return new HashSet<>(instructions);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS				             //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public String getKey() {
		return name;
	}
	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public List<ReportTemplateInstructionTextBean> getInstructions() {
		return instructions;
	}


	
}
