package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class DataProviderSchemeBeanImpl extends OrganisationSchemeBeanImpl<DataProviderBean> implements DataProviderSchemeBean {
	private static final Logger LOG = LoggerFactory.getLogger(DataProviderSchemeBeanImpl.class);
	private static final long serialVersionUID = 168L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	DataProviderSchemeBeanImpl(DataProviderSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub DataProviderSchemeBean Built");
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataProviderSchemeBeanImpl(DataProviderSchemeMutableBean bean) {
		super(bean);
		LOG.debug("Building DataProviderSchemeBean from Mutable Bean");
		if(bean.getItems() != null) {
			for(DataProviderMutableBean currrentBean : bean.getItems()) {
				this.items.add(new DataProviderBeanImpl(currrentBean, this));
			}
			items = Collections.unmodifiableList(items);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("DataProviderSchemeBean Built " + this.getUrn());
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((DataProviderSchemeBean)bean, includeFinalProperties, "Data Provider", diff);
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DataProviderSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<DataProviderSchemeBean> getURN() {
		return (IURNMaintainable<DataProviderSchemeBean>) super.getURN();
	}
	
	@Override
	public ISdmxVersion getVersion() {
		return SdmxVersion.DEFAULT;
	}

	@Override
	public String getId() {
		return FIXED_ID;
	}
	
	@Override
	public DataProviderSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return (DataProviderSchemeBean)super.filterItems(filterIds, isKeepSet);
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new DataProviderSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public DataProviderSchemeMutableBean getMutableInstance() {
		return new DataProviderSchemeMutableBeanImpl(this);
	}

    @Override
    public DataProviderSchemeBeanDeferred toDeferred() {
        return new DataProviderSchemeBeanDeferred(this);
    }
    
    @Override
    public DataProviderSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new DataProviderSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
