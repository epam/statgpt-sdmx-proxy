package io.sdmx.im.beans.mapping;

import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.mapping.SchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;
import io.sdmx.im.beans.base.NameableBeanImpl;

public abstract class SchemeMapBeanImpl extends NameableBeanImpl implements SchemeMapBean {
	private static final long serialVersionUID = 13L;

	protected StructureReferenceBean sourceRef;
	protected StructureReferenceBean targetRef;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	SchemeMapBeanImpl(SchemeMapMutableBean bean, IdentifiableBean parent) {
		super(bean, parent);
		if(bean.getSourceRef() != null) {
			this.sourceRef = bean.getSourceRef();
		}
		if(bean.getTargetRef() != null) {
			this.targetRef = bean.getTargetRef();
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	
	@Override
	public String getUrn() {
		MaintainableBean parent = getMaintainableParent();
		return getStructureType().getUrnPrefix()+parent.getAgencyId()+":"+ parent.getId()+"("+ parent.getVersion().toString()+")."+ getId();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(sourceRef == null) {
			throw new SdmxSemmanticException(getStructureType().getType() + " - Source Ref can not be null");
		}
		if(targetRef == null) {
			throw new SdmxSemmanticException(getStructureType().getType() + " - Target Ref can not be null");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected boolean deepEqualsInternal(NameableBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			SchemeMapBean that = (SchemeMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(sourceRef, that.getSourceRef(), "source ref", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetRef, that.getTargetRef(), "target ref", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public StructureReferenceBean getSourceRef() {
		return sourceRef;
	}

	@Override
	public StructureReferenceBean getTargetRef() {
		return targetRef;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
	}
}


