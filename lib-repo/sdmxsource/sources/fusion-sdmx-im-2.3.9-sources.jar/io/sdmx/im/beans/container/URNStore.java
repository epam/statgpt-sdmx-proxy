package io.sdmx.im.beans.container;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNMultiple;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.structure.UrnUtil;

/**
 * Stores a collection of SDMX Maintainable URNs and provides an API for searching which URNs match search parameters
 */
public class URNStore implements IURNRetrievalManager, Cache, Listener<IStructureEvent>  {
	private Set<IURNMaintainable<?>> all = new HashSet<>();
	private Map<IMaintainableStructureType<?>, Set<IURNMaintainable<?>>> structureTypeIndex = new HashMap<>();
	private Map<String, Set<IURNMaintainable<?>>> agencyIndex = new HashMap<>();
	private Map<String, Set<IURNMaintainable<?>>> idIndex = new HashMap<>();
	private Map<ISdmxVersion, Set<IURNMaintainable<?>>> versionIndex = new HashMap<>();

	private Integer hashCode = null;

	public URNStore() {
		syncroniseSets();
	}
	
	@Override
	public void clearCache() {
		all = new HashSet<>();
		structureTypeIndex = new HashMap<>();
		agencyIndex = new HashMap<>();
		idIndex = new HashMap<>();
		versionIndex = new HashMap<>();
	}

	private void syncroniseSets() {
		all = Collections.synchronizedSet(all);
		structureTypeIndex = Collections.synchronizedMap(structureTypeIndex);
		agencyIndex = Collections.synchronizedMap(agencyIndex);
		idIndex = Collections.synchronizedMap(idIndex);
		versionIndex = Collections.synchronizedMap(versionIndex);
	}


	@Override
	public void invoke(IStructureEvent event) {
		event.getAdditions().getAllMaintainables().forEach(maint-> register(maint.getURN()));
		event.getModification().getAllMaintainables().forEach(maint-> register(maint.getURN()));
		event.getDeletions().getAllMaintainables().forEach(maint-> deregister(maint.getURN()));
	}



	/**
	 * Registers the URN - expects all parameters to be non-null and not a wildcard
	 * @param urn
	 */
	public void register(IURNMaintainable<?> urn) {
	    hashCode = null;
		all.add(urn);
		CollectionUtil.addToMappedSet(structureTypeIndex, urn.getStructureType(), urn);
		CollectionUtil.addToMappedSet(agencyIndex, urn.getAgencyId(), urn);
		CollectionUtil.addToMappedSet(idIndex, urn.getMaintainableId(), urn);
		CollectionUtil.addToMappedSet(versionIndex, urn.getAbsoluteVersion(), urn);
	}
	
	/**
	 * Removes the URN from the store
	 * @param urn
	 */
	public void deregister(IURNMaintainable<?> urn) {
		if(all.remove(urn)) {
			hashCode = null;
			
			agencyIndex.get(urn.getAgencyId()).remove(urn);
			idIndex.get(urn.getMaintainableId()).remove(urn);
			versionIndex.get(urn.getAbsoluteVersion()).remove(urn);
			
			
			IMaintainableStructureType<?> structureType = urn.getStructureType();
			structureTypeIndex.get(structureType).remove(urn);
			if(structureTypeIndex.get(structureType).size() == 0) {
				structureTypeIndex.remove(structureType);
			}
		}
	}
	
	public boolean containsType(IMaintainableStructureType<?> type) {
		return ObjectUtil.validCollection(structureTypeIndex.get(type));
	}
 	
	public Set<IMaintainableStructureType<?>> getDistinctTypes() {
		return Collections.unmodifiableSet(structureTypeIndex.keySet());
	}
	
	private Set<IURNMaintainable<?>> findByStructureTypes(Collection<IMaintainableStructureType> structureTypes) {
		Set<IURNMaintainable<?>> foundSet = new HashSet<>();
		for(IMaintainableStructureType concreteType : structureTypes) {
			Set<IURNMaintainable<?>> typeFound = structureTypeIndex.get(concreteType);
			if(typeFound != null) {
				foundSet.addAll(typeFound);
			}
		}
		return foundSet;
	}
	
	/**
	 * find matched URNs by a full or wildcard URN
	 * @param seachParameters
	 * @return
	 */
	public Set<IURNMaintainable<?>> find(IURN<?> urn) {
		IURN<? extends MaintainableBean> seachParameters = urn.getMaintainableURN();
		
		ISDMXStructureType<?, ?> target = seachParameters.getStructureType();
//		MaintainableSDMXStructureType.ANY
		if(target == null && seachParameters.getAgencyId() == null && seachParameters.getMaintainableId() == null && seachParameters.getVersion().isAll()) {
			return Collections.unmodifiableSet(all);
		}
		Set<IURNMaintainable<?>> foundSet = null;
		
		if(target != null) {
			IMaintainableStructureType<?> maintSt = target.getMaintainableStructureType();
			if(maintSt.isAbstract()) {
				foundSet = findByStructureTypes(StructureTypes.getConcreteMaintStructureTypes(maintSt));
			} else if(target.isAny()) {
				foundSet = findByStructureTypes(StructureTypes.getMaintStructureTypes());
			} else {
				foundSet = find(foundSet, structureTypeIndex.get(maintSt));
			}
		}
		if(urn.getReferenceType() == REFERENCE_TYPE.MULTIPLE) {
			filter(seachParameters.asMultiple(), foundSet);
		} else {
			if(seachParameters.getAgencyId() != null) {
				foundSet = find(foundSet, agencyIndex.get(seachParameters.getAgencyId()));
			}
			if(foundSet != null && foundSet.size() == 0) {
				return Collections.emptySet();
			}
			if(seachParameters.getMaintainableId() != null) {
				foundSet = find(foundSet, idIndex.get(seachParameters.getMaintainableId()));
			}
		}
		return processVersionParam(foundSet, seachParameters.getVersion());
	}
	
	private Set<IURNMaintainable<?>> filter(IURNMultiple<? extends MaintainableBean> multiFilter, Set<IURNMaintainable<?>> foundSet) {
		if(multiFilter.hasAgencyId()) {
			final Set<IURNMaintainable<?>> agencyMatches = new HashSet<>();
			multiFilter.getMutltiReference().getAgencyId().forEach(acyId -> {
				if(agencyIndex.containsKey(acyId)) {
					agencyMatches.addAll(agencyIndex.get(acyId));
				}
			});
			foundSet = find(foundSet, agencyMatches);
		}
		if(foundSet != null && foundSet.size() == 0) {
			return Collections.emptySet();
		}
		if(multiFilter.hasMaintainableId()) {
			final Set<IURNMaintainable<?>> maintMatches = new HashSet<>();
			multiFilter.getMutltiReference().getId().forEach(maintId -> {
				if(idIndex.containsKey(maintId)) {
					maintMatches.addAll(idIndex.get(maintId));
				}
			});
			foundSet = find(foundSet, maintMatches);
		}
		return foundSet;
	}
	
	private Set<IURNMaintainable<?>> processVersionParam(Set<IURNMaintainable<?>> foundSet, IVersionRef vRef) {
		if(foundSet != null && foundSet.size() == 0) {
			return Collections.emptySet();
		}
		if(vRef != null && !vRef.isAll()) {
			Set<IURNMaintainable<?>> matchedVersions = UrnUtil.filterByVersion(foundSet, vRef);
			if(matchedVersions.size() == 0) {
				return Collections.emptySet();
			}
			foundSet = find(foundSet, matchedVersions);
		}
		if(foundSet == null) {
			return Collections.emptySet();
		} 
		return Collections.unmodifiableSet(foundSet);
	}
	
	private Set<IURNMaintainable<?>> find(Set<IURNMaintainable<?>> foundSoFar, Set<IURNMaintainable<?>> foundNow) {
		if(foundNow == null) {
			return Collections.emptySet();
		}
		if(foundSoFar == null) {
			return new HashSet<>(foundNow);
		}
		foundSoFar.retainAll(foundNow);
		return foundSoFar;
	}
	
	
	@Override
	public int hashCode() {
		if(hashCode == null) {
			HashCodeBuilder builder = new HashCodeBuilder(7, 31);
			List<String> sortedList = new ArrayList<>(all.stream().map(e->e.getURN()).collect(Collectors.toList()));
			Collections.sort(sortedList);
			sortedList.forEach(urn -> builder.append(urn));
			hashCode = builder.hashCode();
		}
		return hashCode;
	}

	@Override
	/**
	 * Equal if this contains all the URNs of that
	 */
	public boolean equals(Object obj) {
		if(obj instanceof URNStore) {
			URNStore that = (URNStore) obj;
			Set<IURNMaintainable<?>> thatAll = that.all;
			return this.all.containsAll(thatAll) && this.all.size() == that.all.size();
		}
		return false;
	}
}
