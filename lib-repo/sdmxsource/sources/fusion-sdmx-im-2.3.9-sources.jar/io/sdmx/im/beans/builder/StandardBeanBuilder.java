package io.sdmx.im.beans.builder;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.builder.IImmutableBeanBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public class StandardBeanBuilder implements IBeansBuilder {
    private final IImmutableBeanBuilder beanBuilder;
    
    public static final StandardBeanBuilder INSTANCE = new StandardBeanBuilder(null);
    
    public StandardBeanBuilder(IImmutableBeanBuilder beanBuilder) {
        this.beanBuilder = beanBuilder != null ? beanBuilder : StandardImmutableBeanBuilder.INSTANCE;
    }



    @Override
    public void build(MaintainableMutableBean mutable, SdmxBeans beans) {
        MaintainableBean maint = beanBuilder.build(mutable);
        if(maint != null) {
            beans.addIdentifiable(maint);
        }
    }

}
