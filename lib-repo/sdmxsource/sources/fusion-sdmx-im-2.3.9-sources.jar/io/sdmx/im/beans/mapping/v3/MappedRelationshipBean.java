package io.sdmx.im.beans.mapping.v3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Defines a relationship between one or more source values (in combination) which are the equivalent to one or more
 * target values (in combination)
 */
public class MappedRelationshipBean extends AnnotableBeanImpl implements IMappedRelationshipBean {
	private static final long serialVersionUID = 3L;
	private SdmxPeriod validityPeriod = SdmxPeriodImpl.ALL_PERIODS;
	private List<IMappedValueBean> sourceValue = new ArrayList<>();
	private List<String> targetValue = new ArrayList<>();
	private int position;
	
	public MappedRelationshipBean(IMappedRelationshipMutableBean bean, int position, IRepresentationMapBean parent) {
		super(bean, parent);
		this.position = position;
		if(ObjectUtil.validString(bean.getValidFrom()) || ObjectUtil.validString(bean.getValidTo())) {
			validityPeriod = new SdmxPeriodImpl(bean.getValidFrom(), bean.getValidTo());
		}
		if(bean.getSourceValue() != null) {
			for(IMappedValueMutableBean mappedValue : bean.getSourceValue()) {
				if(mappedValue != null) {
					this.sourceValue.add(new MappedValueBean(mappedValue, this));
				}
			}
		}
		if(bean.getTargetValue() != null) {
			this.targetValue= new ArrayList<>(bean.getTargetValue());
		}
		validate();
	}

	@Override
	public String getKey() {
		return this.toString();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validCollection(sourceValue)) {
			throw new SdmxSemmanticException("Mapped relationship missing source value(s)");
		}
		//Target can be empty
		this.sourceValue = Collections.unmodifiableList(this.sourceValue);
		this.targetValue = Collections.unmodifiableList(this.targetValue);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IMappedRelationshipBean that = (IMappedRelationshipBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(validityPeriod, that.getValidityPeriod(), Properties.VALIDITY_PERIOD.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(sourceValue, that.getSourceValue(), includeFinalProperties, Properties.SOURCE_VALUE.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(targetValue, that.getTargetValue(), Properties.TARGET_VALUE.getProperty(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(position, that.getPosition(), "Position", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public SdmxPeriod getValidityPeriod() {
		return validityPeriod;
	}

	@Override
	public List<IMappedValueBean> getSourceValue() {
		return sourceValue;
	}
	
	@Override
	public List<String> getTargetValue() {
		return targetValue;
	}

	@Override
	public int getPosition() {
		return position;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(IMappedValueBean source : sourceValue) {
			sb.append(concat+source.toString());
			concat = ":";
		}
		concat = "=";
		for(String target : targetValue) {
			sb.append(concat+target);
			concat = ":";
		}
		return sb.toString();
	}
}
