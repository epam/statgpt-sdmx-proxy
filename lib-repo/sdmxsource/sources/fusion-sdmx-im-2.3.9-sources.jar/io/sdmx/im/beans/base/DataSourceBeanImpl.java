package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataSourceBeanImpl extends SdmxStructureBeanImpl implements DataSourceBean {
	private static final long serialVersionUID = 16L;
	private URL dataUrl;
	private URL wsdlUrl;
	private URL wadlUrl;
	private boolean isRestDatasource;
	private boolean isSimpleDatasource;
	private boolean isWebServiceDatasource;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataSourceBeanImpl(DataSourceMutableBean datasource, SdmxStructureBean parent) {
		super(datasource, parent);
		this.dataUrl = getUrl(datasource.getDataUrl());
		this.wsdlUrl = getUrl(datasource.getWSDLUrl());
		this.isRestDatasource = datasource.isRESTDatasource();
		this.isSimpleDatasource = datasource.isSimpleDatasource();
		this.isWebServiceDatasource = datasource.isWebServiceDatasource();
		validate();
	}

	public DataSourceBeanImpl(String simpleDatasoruce, SdmxStructureBean parent) {
		super(SDMX_STRUCTURE_TYPE.DATASOURCE, parent);
		isSimpleDatasource = true;
		dataUrl = getUrl(simpleDatasoruce);
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			DataSourceBean that = (DataSourceBean)bean;
			boolean returnVal = true;
			if(!super.equivalent(dataUrl, that.getDataUrl(), "Data URL", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(wsdlUrl, that.getWadlUrl(), "WSDL URL", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(wadlUrl, that.getWadlUrl(), "WADL URL", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isRestDatasource, that.isRESTDatasource(), "Is REST", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isSimpleDatasource, that.isSimpleDatasource(), "Is File", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(isWebServiceDatasource, that.isWebServiceDatasource(), "Is SOAP", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected void validate() throws SdmxSemmanticException {
		if(dataUrl == null) {
			throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ATTRIBUTE, "DataSource", "URL");
		}
		//HACK The schema does not allow a constraint to be attached to both a provision and a simple datasource, so here we are setting simple datasouce to false, so that 
		//the constraint will be attached to a provision and a queryable datasource - but the queryable datasource will have the following two attributes set
		//isWebServiceDatasource="false" isRESTDatasource="false"
		//This can be inferred by a system that the datasource is simple
		if(parent.getStructureType() != SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT_ATTACHMENT) {
			if(!isRestDatasource && !isWebServiceDatasource && !isSimpleDatasource) {
				throw new SdmxSemmanticException("Registration against a queryable source must either be a REST datasource or a web service datasource");
			}
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	

	private URL getUrl(String urlString) {
		try {
			if(ObjectUtil.validString(urlString)) {
				return new URL(urlString);
			}
		} catch(Throwable th) {
			throw new SdmxSemmanticException("Invalid URL '"+urlString+"'");
		}
		return null;
	}

	@Override
	public URL getDataUrl() {
		return dataUrl;
	}

	@Override
	public URL getWadlUrl() {
		return wadlUrl;
	}

	@Override
	public URL getWSDLUrl() {
		return wsdlUrl;
	}

	@Override
	public boolean isRESTDatasource() {
		return isRestDatasource;
	}

	@Override
	public boolean isSimpleDatasource() {
		return isSimpleDatasource;
	}

	@Override
	public boolean isWebServiceDatasource() {
		return isWebServiceDatasource;
	}
	
	@Override
	public String getKey() {
		return dataUrl.toString();
	}


	@Override
	public DataSourceMutableBean createMutableInstance() {
		return new DataSourceMutableBeanImpl(this, null); 
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////	
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        return new HashSet<>();
    }
}
