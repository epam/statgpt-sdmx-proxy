package io.sdmx.im.beans.transformation;

import static io.sdmx.fusion.vtl.constant.VtlConstants.END_OF_FILE_SYMBOL;
import static io.sdmx.fusion.vtl.constant.VtlConstants.NON_PERSISTENT_OPERATOR;
import static io.sdmx.fusion.vtl.constant.VtlConstants.PERSISTENT_OPERATOR;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.antlr.v4.runtime.CharStreams;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.fusion.vtl.antlr.VtlParser;
import io.sdmx.fusion.vtl.util.VtlParserUtil;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Describes the details of a single transformation in a {@link TransformationSchemeBean}
 */
public class TransformationBean extends ItemBeanImpl implements ITransformationBean {
	private static final long serialVersionUID = 1L;
	private boolean persistent;
	private String result;
	private String expression;
	private List<IURN<?>> references = new ArrayList<>();

	public TransformationBean(ITransformationMutableBean bean, ITransformationSchemeBean parent, int position) {
		super(bean, parent, position);
		this.persistent = bean.isPersistent();
		this.result = bean.getResult();
		this.expression = bean.getExpression();
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(this.result)) {
			throw new SdmxSemmanticException("Result required for VTL Transformation");
		}
		if(!ObjectUtil.validString(this.expression)) {
			throw new SdmxSemmanticException("Expression required for VTL Transformation");
		}
		this.result = result.trim();
		this.expression = expression.trim();
		this.references = Collections.unmodifiableList(extractReferencedArtifacts());
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		ITransformationBean that = (ITransformationBean) bean;
		boolean returnVal = true;
		if(!super.equivalent(persistent, that.isPersistent(), "Is Persistent", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(result, that.getResult(), "Result", diff)) {
			returnVal = false;
		}
		if(!super.equivalent(expression, that.getExpression(), "Expression", diff)) {
			returnVal = false;
		}
		return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ITransformationBean.class;
	}
	
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<ITransformationBean> getURN() {
		return (IURNAbsolute<ITransformationBean>) super.getURN();
	}
	
	@Override
	public boolean isPersistent() {
		return persistent;
	}

	@Override
	public String getResult() {
		return result;
	}

	@Override
	public String getExpression() {
		return expression;
	}

	@Override
	public List<IURN<?>> getReferencedArtifacts(){
		return references;
	}

	/**
	 * Extracts the (partial) URNs used in the VTL expression and creates a List of URNs
	 *
	 * @return List<IURN> of referenced artifacts
	 */
	private List<IURN<?>> extractReferencedArtifacts(){
		String vtlProgram = result + (isPersistent() ? PERSISTENT_OPERATOR : NON_PERSISTENT_OPERATOR) + expression + END_OF_FILE_SYMBOL;
		// Parse VTL program and retrieve the VTL objects used in the expressions
		VtlParser parser = VtlParserUtil.getVtlParser(CharStreams.fromString(vtlProgram));
		VtlParser.StartContext tree = parser.start();

		if(VtlParserUtil.getSyntaxErrors(parser).isEmpty()){
			Map<String,String> vtlObjects =VtlParserUtil.parseVtlInput(parser);
			for(String object : vtlObjects.keySet()){
				//VTL constants are skipped
				if(Objects.equals(vtlObjects.get(object), "ConstantExpr")){
					continue;
				}
				IURN<?> urn =  VtlParserUtil.extractSdmxElementFromVtlObject(object, SDMX_STRUCTURE_TYPE.DATAFLOW);
				if(!(urn.isType(DataflowBean.class)) && !(urn.isType(ComponentBean.class))){
					throw new SdmxSyntaxException("Only references to dataflows and dataflow components are allowed in a VTL transformation statement.");
				}
                references.add(urn);
			}
		}
		return references;
	}
}
