package io.sdmx.im.beans;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;

public class SdmxBeansEventImpl implements SdmxBeansEvent {
	private SdmxBeans newContainer;
	private SdmxBeans oldContainer;
	private SdmxBeans modified;
	private SdmxBeans added;
	private SdmxBeans delete;


	public SdmxBeansEventImpl(SdmxBeans oldBeans, SdmxBeans newBeans) {
		if(oldBeans == null) {
			oldBeans = new SdmxBeansImpl();
		}
		if(newBeans == null) {
			newBeans = new SdmxBeansImpl();
		}
		Map<String, MaintainableBean> oldMaints = getMaintainableMap(oldBeans);
		Map<String, MaintainableBean> newMaints = getMaintainableMap(newBeans);

		newContainer = newBeans;
		oldContainer = oldBeans;
		modified = new SdmxBeansImpl();
		added  = new SdmxBeansImpl();
		delete  = new SdmxBeansImpl();

		for(String newMaintUrn : newMaints.keySet()) {
			MaintainableBean oldMaint = oldMaints.get(newMaintUrn);
			MaintainableBean newMaint = newMaints.get(newMaintUrn);
			if(oldMaint == newMaint) {
				continue;
			}
			if(oldMaint != null && newMaint != null && newMaint.getInternalId().equals(oldMaint.getInternalId())) {
				continue;
			}
			if(oldMaint == null) {
				added.addIdentifiable(newMaint);
			} else if (newMaint != null && !newMaint.deepEquals(oldMaint, true)) {
				modified.addIdentifiable(newMaint);
			}
		}
		for(String oldMaintUrn : oldMaints.keySet()) {
			if(!newMaints.containsKey(oldMaintUrn)) {
				delete.addIdentifiable(oldMaints.get(oldMaintUrn));
			}
		}
		this.added = added.getReadOnlyCopy();
		this.modified = modified.getReadOnlyCopy();
		this.delete = delete.getReadOnlyCopy();
		this.newContainer = newContainer.getReadOnlyCopy();
		this.oldContainer = oldContainer.getReadOnlyCopy();
	}

	private Map<String, MaintainableBean> getMaintainableMap(SdmxBeans beans) {
		Map<String, MaintainableBean> returnMap = new HashMap<>();
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			returnMap.put(maint.getUrn(), maint);
		}
		return returnMap;
	}

	@Override
	public SdmxBeans getNewContainer() {
		return newContainer;
	}

	@Override
	public SdmxBeans getOldContainer() {
		return oldContainer;
	}

	@Override
	public SdmxBeans getModification() {
		return modified;
	}

	@Override
	public SdmxBeans getAdditions() {
		return added;
	}

	@Override
	public SdmxBeans getDeletions() {
		return delete;
	}
}
