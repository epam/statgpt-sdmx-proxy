package io.sdmx.im.beans.registry;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReleaseCalendarBeanImpl extends SdmxStructureBeanImpl implements ReleaseCalendarBean {
	private static final long serialVersionUID = 124421576642998552L;
	private String offset;
	private String periodicity;
	private String tolerance;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReleaseCalendarBeanImpl(ReleaseCalendarMutableBean mutable, MaintainableBeanImpl parent) {
		super(SDMX_STRUCTURE_TYPE.RELEASE_CALENDAR, parent);
		if (mutable != null) {
			this.offset = mutable.getOffset();
			this.periodicity = mutable.getPeriodicity();
			this.tolerance = mutable.getTolerance();
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(offset)) {
			throw new SdmxSemmanticException("Release Calendar missing Offset");
		}
		if(!ObjectUtil.validString(periodicity)) {
			throw new SdmxSemmanticException("Release Calendar missing Periodicity");
		}
		if(!ObjectUtil.validString(tolerance)) {
			throw new SdmxSemmanticException("Release Calendar missing Tolerance");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ReleaseCalendarBean that = (ReleaseCalendarBean) bean;
			boolean returnVal = true;
			
			if(!super.equivalent(offset, that.getOffset(), "offset", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(periodicity, that.getPeriodicity(), "periodicity", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(tolerance, that.getTolerance(), "tolerance", diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getPeriodicity() {
		return periodicity;
	}

	@Override
	public String getOffset() {
		return offset;
	}

	@Override
	public String getTolerance() {
		return tolerance;
	}

	@Override
	public String getKey() {
		return null;
	}

	@Override
	public ReleaseCalendarMutableBean createMutableBean() {
		return new ReleaseCalendarMutableBeanImpl(this, null);
	}
}
