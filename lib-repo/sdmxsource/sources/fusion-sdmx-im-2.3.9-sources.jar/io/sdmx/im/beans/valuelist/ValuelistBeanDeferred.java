package io.sdmx.im.beans.valuelist;

import java.net.URL;
import java.util.Collection;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class ValuelistBeanDeferred extends MaintainableBeanDeferred<ValueListBean> implements ValueListBean {
    private static final long serialVersionUID = 1L;

    public ValuelistBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ValuelistBeanDeferred(ValueListBean maint) {
        super(maint);
    }
    
    @Override
    public ValueListBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ValueListBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected ValuelistBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ValuelistBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<ValueListBean> getURN() {
        return (IURNMaintainable<ValueListBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return ValueListBean.class;
    }

    @Override
    public List<ValueItemBean> getChildren(String id) {
        return load().getChildren(id);
    }

    @Override
    public int getCodeMinLength() {
        return load().getCodeMinLength();
    }

    @Override
    public int getCodeMaxLength() {
        return load().getCodeMaxLength();
    }

    @Override
    public List<ValueItemBean> getItems() {
        return load().getItems();
    }

    @Override
    public boolean isPartial() {
        return load().isPartial();
    }

    @Override
    public ValueItemBean getItemById(String id) {
        return load().getItemById(id);
    }

    @Override
    public ValueListMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public ValueListBean filterItems(Collection<String> items, boolean keep) {
        return load().filterItems(items, keep);
    }
}
