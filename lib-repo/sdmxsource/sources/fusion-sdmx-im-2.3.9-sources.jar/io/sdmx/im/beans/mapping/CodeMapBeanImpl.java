package io.sdmx.im.beans.mapping;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.CodelistMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;

public class CodeMapBeanImpl extends ItemMapBeanImpl implements CodeMapBean {
	private static final long serialVersionUID = 1L;
	
	private SdmxPeriod validityPeriod;
	
	public CodeMapBeanImpl(CodeMapMutableBean item, ItemSchemeMapBean<CodeMapBean> parent) {
		super(item, parent);
		this.validityPeriod = item.getSdmxPeriod().orElse(null);
	}
	
	public CodeMapBeanImpl(String sourceId, String targetId, CodelistMapBean parent) {
		super(sourceId, targetId, parent);
		this.validityPeriod = null;
	}
	
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		boolean returnVal = true;
		if(bean.getStructureType() == this.getStructureType()) {
			ValidityPeriodBean that = (ValidityPeriodBean) bean;
			if(!super.equivalent(this.validityPeriod, that.getValidityPeriod(), "ValidityPeriod ", diff)) {
				returnVal = false;
			}
		}
		return super.deepEquals(bean, includeFinalProperties, diff) && returnVal;
	}
	

	@Override
	public SdmxPeriod getValidityPeriod() {
		return this.validityPeriod;
	}

	@Override
	public boolean hasValidityPeriod() {
		return this.validityPeriod != null;
	}
}
