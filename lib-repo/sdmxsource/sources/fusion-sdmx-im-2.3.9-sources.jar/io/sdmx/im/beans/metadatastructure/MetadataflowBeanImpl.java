package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.CrossRefrenceBeanBase;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class MetadataflowBeanImpl extends MaintainableBeanImpl implements MetadataFlowBean {
	private static final Logger LOG = LoggerFactory.getLogger(MetadataflowBeanImpl.class);
	private static final long serialVersionUID = 183L;
	private IDirectCrossReferenceBean<MetadataStructureDefinitionBean> metadataStructureRef;
	private List<ICrossReferenceBeanBase>  targets = Collections.emptyList();
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	MetadataflowBeanImpl(MetadataFlowBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub MetadataFlowBean Built");
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataflowBeanImpl(MetadataFlowMutableBean bean) {
		super(bean);
		LOG.debug("Building MetadataFlowBean from Mutable Bean");
		if(bean.getMetadataStructureRef() != null) {
			this.metadataStructureRef = DirectCrossReferenceBean.build(this, "msd", bean.getMetadataStructureRef(), MetadataStructureDefinitionBean.class);
		}
		this.targets = new ArrayList<>();
		if(bean.getTargets() != null) {
			for(StructureReferenceBean currentTaget : bean.getTargets()) {
//				IURN<?> target = URN.builder(currentTaget.getTargetUrn()).build();
//				if(target.getReferenceType().isSingle()) {
//
//				} else {
					this.targets.add(CrossRefrenceBeanBase.build(this, "target", currentTaget));
//				}
			}
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("MetadataFlowBean Built " + this.getUrn());
		}
		validate();
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(this.targets.size() == 0) {
			throw new SdmxSemmanticException("Metadata Flow needs to define at least 1 target");
		}
		this.targets = Collections.unmodifiableList(this.targets);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			MetadataFlowBean that = (MetadataFlowBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(metadataStructureRef, that.getMetadataStructureRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.targets, that.getTargets(), "Target", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return MetadataFlowBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<MetadataFlowBean> getURN() {
		return (IURNMaintainable<MetadataFlowBean>)super.getURN();
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(metadataStructureRef != null) {
			references.add(metadataStructureRef);
		}
		references.addAll(this.targets);
	}

	@Override
	public MetadataFlowBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new MetadataflowBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public MetadataFlowMutableBean getMutableInstance() {
		return new MetadataflowMutableBeanImpl(this);
	}
	
	@Override
	public List<ICrossReferenceBeanBase> getTargets() {
		return targets;
	}

	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		List<ICrossReferenceBean<? extends ConstrainableBean>> returnList = new ArrayList<>(1);
		if(this.metadataStructureRef != null) {
			returnList.add(this.metadataStructureRef);
		}
		return returnList;
	}

	@Override
	public ICrossReferenceBean<MetadataStructureDefinitionBean> getMetadataStructureRef() {
		return metadataStructureRef;
	}

    @Override
    public MetadataflowBeanDeferred toDeferred() {
        return new MetadataflowBeanDeferred(this);
    }
    
    @Override
    public MetadataflowBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataflowBeanDeferred(getDeferredDefinition(), loader);
    }
}
