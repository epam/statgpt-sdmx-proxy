package io.sdmx.im.beans.container;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.sdmx.model.superbeans.base.MaintainableSuperBean;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * Proxy to store SuperBeans for the current thread
 *
 */
public class ThreadLocalSuperBeansProxy implements SuperBeans {
	private static final String THREAD_KEY= "ThreadLocalSuperBeansProxy";
	
	/**
	 * @param createIfNull - if true, then this method will never return null SuperBeans will be added to the current thread if it did not exist
	 * @return SuperBenas container from the current thread, or null if none exist
	 */
	private SuperBeans getSuperBeansForThread(boolean createIfNull) {
		SuperBeans beans =  (SuperBeans)ThreadLocalUtil.retrieveFromThread(THREAD_KEY);
		if(beans == null && createIfNull) {
			beans = new SuperBeansImpl();
			ThreadLocalUtil.storeOnThread(THREAD_KEY, beans);
		}
		return beans;
	}
	
	/**
	 * If there are no super beans on the current thread, the container is removed
	 */
	private void sizeCheck() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null && superBeans.getAllMaintainables().size() == 0) {
			ThreadLocalUtil.clearFromThread(THREAD_KEY);
		}
	}
	
	
	@Override
	public void merge(SuperBeans superBeans) {
		getSuperBeansForThread(true).merge(superBeans);
	}

	@Override
	public void addMaintainable(MaintainableSuperBean bean) {
		getSuperBeansForThread(true).addMaintainable(bean);
	}

	@Override
	public void removeMaintainable(MaintainableSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeMaintainable(bean);
			sizeCheck();
		}
	}

	@Override
	public void addConceptScheme(ConceptSchemeSuperBean bean) {
		getSuperBeansForThread(true).addConceptScheme(bean);
	}

	@Override
	public void addDataflow(DataflowSuperBean bean) {
		getSuperBeansForThread(true).addDataflow(bean);
	}
	
	@Override
	public void addHierarchy(HierarchySuperBean bean) {
		getSuperBeansForThread(true).addHierarchy(bean);		
	}

	@Override
	public void addMetadataStructure(MetadataStructureSuperBean bean) {
		getSuperBeansForThread(true).addMetadataStructure(bean);
	}

	@Override
	public void addDataStructure(DataStructureSuperBean bean) {
		getSuperBeansForThread(true).addDataStructure(bean);
	}

	@Override
	public void addProvision(ProvisionAgreementSuperBean bean) {
		getSuperBeansForThread(true).addProvision(bean);
	}

	@Override
	public void addRegistration(RegistrationSuperBean bean) {
		getSuperBeansForThread(true).addRegistration(bean);
	}

	@Override
	public void removeConceptScheme(ConceptSchemeSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeConceptScheme(bean);
			sizeCheck();
		}
	}

	@Override
	public void removeDataflow(DataflowSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeDataflow(bean);
			sizeCheck();
		}
	}
	
	@Override
	public void removeHierarchy(HierarchySuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeHierarchy(bean);
			sizeCheck();
		}
	}

	@Override
	public void removeDataStructure(DataStructureSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeDataStructure(bean);
			sizeCheck();
		}
	}

	@Override
	public void removeMetadataStructure(MetadataStructureSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeMetadataStructure(bean);
			sizeCheck();
		}
	}

	@Override
	public void removeProvision(ProvisionAgreementSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeProvision(bean);
			sizeCheck();
		}
	}

	@Override
	public void removeRegistration(RegistrationSuperBean bean) {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			superBeans.removeRegistration(bean);
			sizeCheck();
		}
	}

	@Override
	public Set<DataflowSuperBean> getDataflows() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getDataflows();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemes() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getConceptSchemes();
		}
		return Collections.emptySet();
	}

	
	@Override
	public Set<HierarchySuperBean> getHierarchies() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getHierarchies();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructures() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getDataStructures();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<MetadataStructureSuperBean> getMetadataStructures() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getMetadataStructures();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<ProvisionAgreementSuperBean> getProvisions() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getProvisions();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<MaintainableSuperBean> getAllMaintainables() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getAllMaintainables();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<RegistrationSuperBean> getRegistrations() {
		SuperBeans superBeans = getSuperBeansForThread(false);
		if(superBeans != null) {
			return superBeans.getRegistrations();
		}
		return Collections.emptySet();
	}
}
