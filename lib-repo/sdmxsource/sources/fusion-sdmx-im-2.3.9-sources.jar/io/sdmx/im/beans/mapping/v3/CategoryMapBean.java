package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IItemMapMutableBean;

public class CategoryMapBean extends ItemMapBean implements ICategoryMapBean {
	private static final long serialVersionUID = 1L;

    public CategoryMapBean(IItemMapMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
	}
	
	
}
