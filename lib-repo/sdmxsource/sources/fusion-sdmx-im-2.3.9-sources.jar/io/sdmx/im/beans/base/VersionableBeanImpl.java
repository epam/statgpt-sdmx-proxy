package io.sdmx.im.beans.base;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.VersionableBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.VersionableMutableBean;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.core.version.VersionableUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public abstract class VersionableBeanImpl extends NameableBeanImpl implements VersionableBean {

	private static final long serialVersionUID = -3032682182008381504L;

	protected SdmxPeriod validityPeriod;

	protected ISdmxVersion version = SdmxVersion.DEFAULT;


	private void setValues(VersionableBean bean) {
		if (bean == null) {
			return;
		}
		this.version = bean.getVersion();
		this.validityPeriod = bean.getValidityPeriod();
	}

	private void setValues(VersionableMutableBean bean) {
		if (bean == null) {
			return;
		}
		this.version = SdmxVersion.getInstance(bean.getVersion());
		SdmxDate startDate = null;
		SdmxDate endDate = null;
		if (bean.getStartDate() != null) {
			startDate = new SdmxDateImpl(bean.getStartDate(), TIME_FORMAT.DATE_TIME);
		}
		if (bean.getEndDate() != null) {
			endDate = new SdmxDateImpl(bean.getEndDate(), TIME_FORMAT.DATE_TIME);
		}
		if (ObjectUtil.validOneObject(startDate, endDate)) {
			this.validityPeriod = new SdmxPeriodImpl(startDate, endDate);
		}
	}

	public VersionableBeanImpl(VersionableMutableBean bean, IdentifiableBean parent) {
		super(bean, parent);
		setValues(bean);
	}

	public VersionableBeanImpl(VersionableBean bean, boolean completeStub) {
		super(bean, completeStub);
		setValues(bean);
	}

	protected boolean deepEqualsInternal(VersionableBean bean, boolean includeFinalProperties, DiffReport diff) {
		if (bean == null) {
			return false;
		}
		boolean returnVal = true;
		if (includeFinalProperties) {
			if (!super.equivalent(this.validityPeriod, bean.getValidityPeriod(), "Validity Period", diff)) {
				returnVal = false;
			}
		}

		return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
	}

	protected void validateMaintainableAttributes() throws SdmxSemmanticException {
		if(version == null) {
			version = SdmxVersion.getInstance("1.0");
		}
	}

	@Override
	public SdmxPeriod getValidityPeriod() {
		return validityPeriod;
	}

	@Override
	public boolean hasValidityPeriod() {
		return validityPeriod != null;
	}

	@Override
	public ISdmxVersion getVersion() {
		return version;
	}
}
