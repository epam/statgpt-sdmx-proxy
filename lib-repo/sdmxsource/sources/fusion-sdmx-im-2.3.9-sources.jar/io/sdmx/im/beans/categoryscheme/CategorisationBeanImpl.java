package io.sdmx.im.beans.categoryscheme;

import java.net.URL;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class CategorisationBeanImpl extends MaintainableBeanImpl implements CategorisationBean {
	private static final long serialVersionUID = 138L;
	private IDirectCrossReferenceBean<CategoryBean> categoryReference;
	private IDirectCrossReferenceBean<?> structureReference;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	CategorisationBeanImpl(CategorisationBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN              //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public CategorisationBeanImpl(CategorisationMutableBean bean) {
		super(bean);
		try {
			if(bean.getCategoryReference() != null) {
				this.categoryReference = DirectCrossReferenceBean.build(this, "categoryref", bean.getCategoryReference(), CategoryBean.class);
			}
			if(bean.getStructureReference() != null) {
				this.structureReference = DirectCrossReferenceBean.build(this, "structureref", bean.getStructureReference(), IdentifiableBean.class);
			}
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			CategorisationBean that = (CategorisationBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(categoryReference, that.getCategoryReference(), "Category Reference", diff)) {
				returnVal =  false;
			}
			if(!super.equivalent(structureReference, that.getStructureReference(), "Structure Reference", diff)) {
				returnVal =  false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(!isExternalReference) {
			if(this.structureReference == null) {
				throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "StructureReference");
			}
			if(this.categoryReference == null) {
				throw new SdmxSemmanticException(ExceptionCode.BEAN_MISSING_REQUIRED_ELEMENT, this.structureType, "CategoryReference");
			}
		}
		super.validateId(true);
		super.validateNameableAttributes();
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(categoryReference != null) {
			references.add(categoryReference);
		}
		if(structureReference != null) {
			references.add(structureReference);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Class<?> getConcreteInterface() {
		return CategorisationBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<CategorisationBean> getURN() {
		return (IURNMaintainable<CategorisationBean>)super.getURN();
	}
	
	@Override
	public CategorisationBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new CategorisationBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public CategorisationMutableBean getMutableInstance() {
		return new CategorisationMutableBeanImpl(this);
	}

	@Override
	public ICrossReferenceBean<CategoryBean> getCategoryReference() {
		return categoryReference;
	}

	@Override
	public ICrossReferenceBean<?> getStructureReference() {
		return structureReference;
	}

    @Override
    public CategorisationBeanDeferred toDeferred() {
        return new CategorisationBeanDeferred(this);
    }
    
    @Override
    public CategorisationBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new CategorisationBeanDeferred(getDeferredDefinition(), loader);
    }
}
