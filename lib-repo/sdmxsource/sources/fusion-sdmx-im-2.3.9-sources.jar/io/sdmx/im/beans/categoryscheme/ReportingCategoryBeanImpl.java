package io.sdmx.im.beans.categoryscheme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.im.beans.base.ItemBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ReportingCategoryBeanImpl extends ItemBeanImpl implements ReportingCategoryBean {
	private static final long serialVersionUID = 14L;
	private List<ICrossReferenceBean<?>> structuralMetadata = new ArrayList<>();
	private List<ICrossReferenceBean<?>> provisioningMetadata = new ArrayList<>();
	private List<ReportingCategoryBean> reportingCategories = new ArrayList<>();
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ReportingCategoryBeanImpl(IdentifiableBean parent, ReportingCategoryMutableBean reportingCategory, int position) {
		super(reportingCategory, parent, position);
		
		if(reportingCategory.getProvisioningMetadata() != null) {
			for(StructureReferenceBean sRef : reportingCategory.getProvisioningMetadata()) {
				provisioningMetadata.add(DirectCrossReferenceBean.build(this, "provision", sRef.buildURNSingle()));
			}
		}
		
		if(reportingCategory.getStructuralMetadata() != null) {
			for(StructureReferenceBean sRef : reportingCategory.getStructuralMetadata()) {
				structuralMetadata.add(DirectCrossReferenceBean.build(this, "category", sRef.buildURNSingle()));
			}
		}
		
		if(reportingCategory.getItems() != null) {
			position = 1;
			for(ReportingCategoryMutableBean currentBean : reportingCategory.getItems()) {
				reportingCategories.add(new ReportingCategoryBeanImpl(this, currentBean, position));
				position++;
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ReportingCategoryBean that = (ReportingCategoryBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(structuralMetadata, that.getStructuralMetadata(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(provisioningMetadata, that.getProvisioningMetadata(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(reportingCategories, that.getItems(), includeFinalProperties, "Reporting Categories", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(ObjectUtil.validCollection(provisioningMetadata)  && ObjectUtil.validCollection(structuralMetadata)) {
			throw new SdmxSemmanticException("Reporting Category can not have both structural metadata and provisioning metadata");
		}
		//Validate StructuralMetadata is either pointing to a DSD or MSD, and only contains the same type
		for(ICrossReferenceBean<?> crossReference : structuralMetadata) {
			if(crossReference.getTargetReference() != SDMX_STRUCTURE_TYPE.DSD
					&& crossReference.getTargetReference() != SDMX_STRUCTURE_TYPE.MSD) {
				throw new SdmxSemmanticException("Reporting Category 'Structural Metadata' must either reference DSDs or MSDs, not " + crossReference.getTargetReference().getType());
			}
		}
		for(ICrossReferenceBean<?> crossReference : provisioningMetadata) {
			if(crossReference.getTargetReference() != SDMX_STRUCTURE_TYPE.DATAFLOW
					&& crossReference.getTargetReference() != SDMX_STRUCTURE_TYPE.METADATA_FLOW) {
				throw new SdmxSemmanticException("Reporting Category 'Provisioning Metadata' must either reference a Data Flow or Metadata Flow, not " + crossReference.getTargetReference().getType());
			}
		}
		this.reportingCategories = Collections.unmodifiableList(reportingCategories);
		this.provisioningMetadata = Collections.unmodifiableList(provisioningMetadata);
		this.structuralMetadata = Collections.unmodifiableList(structuralMetadata);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS  							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ReportingCategoryBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<ReportingCategoryBean> getURN() {
		return (IURNAbsolute<ReportingCategoryBean>)super.getURN();
	}
	
	@Override
	public List<ReportingCategoryBean> getItems() {
		return reportingCategories;
	}

	@Override
	public List<ICrossReferenceBean<?>> getStructuralMetadata() {
		return structuralMetadata;
	}

	@Override
	public List<ICrossReferenceBean<?>> getProvisioningMetadata() {
		return provisioningMetadata;
	}
	
	@Override
	public boolean isHierarchyExplicit() {
		return true;
	}
	
	
	
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES                           //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.addAll(getProvisioningMetadata());
		references.addAll(getStructuralMetadata());
	}

	@Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
    	super.addToCompositeSet(reportingCategories, composites);
    	return composites;
    }
}
