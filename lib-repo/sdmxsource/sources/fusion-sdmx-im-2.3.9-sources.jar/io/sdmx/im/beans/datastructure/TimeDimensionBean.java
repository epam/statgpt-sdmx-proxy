package io.sdmx.im.beans.datastructure;

import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.ITimeDimensionBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;

public class TimeDimensionBean extends DimensionBeanImpl implements ITimeDimensionBean {
	private static final long serialVersionUID = 1L;

	protected TimeDimensionBean(DimensionMutableBean bean, int position, DimensionListBean parent) {
		super(bean, position, parent);
	}
	
	@Override
	protected Class<?> getConcreteInterface() {
		return ITimeDimensionBean.class;
	}

}
