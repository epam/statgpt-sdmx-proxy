package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.util.HierarchicalItem;
import io.sdmx.api.sdmx.model.util.Hierarchy;

/**
 * Defines a hierarchy of agencies
 */
public class AgencyHierarchyImpl implements Hierarchy<AgencyBean> {
	private SortedSet<HierarchicalItem<AgencyBean>> childAgencies = new TreeSet<>();
	
	public AgencyHierarchyImpl(Set<AgencySchemeBean> agencySchemes) {
		for(AgencySchemeBean acySCh : agencySchemes) {
			if(acySCh.isDefaultScheme()) {
				for(AgencyBean child : acySCh.getItems()) {
					this.childAgencies.add(new AgencyHierarchicalItemImpl(agencySchemes, child, this));
				}
			}
		}
		childAgencies = Collections.unmodifiableSortedSet(this.childAgencies);
	}
	
	@Override
	public Collection<HierarchicalItem<AgencyBean>> getChildren() {
		return childAgencies;
	}
}
