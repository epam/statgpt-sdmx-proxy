package io.sdmx.im.beans.transformation;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlCodelistMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlCodelistMappingMutableBean;

public class VtlCodelistMappingBean extends VtlMappingBean<CodelistBean> implements IVtlCodelistMappingBean {
	private static final long serialVersionUID = 1L;

	public VtlCodelistMappingBean(IVtlCodelistMappingMutableBean bean, IVtlMappingSchemeBean parent, int position) {
		super(bean, CodelistBean.class, parent, position);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		IVtlCodelistMappingBean that = (IVtlCodelistMappingBean) bean;
		return super.deepEqualsInternal(that, includeFinalProperties, diff);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IVtlCodelistMappingBean.class;
	}
	
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IVtlCodelistMappingBean> getURN() {
		return (IURNAbsolute<IVtlCodelistMappingBean>) super.getURN();
	}
}
