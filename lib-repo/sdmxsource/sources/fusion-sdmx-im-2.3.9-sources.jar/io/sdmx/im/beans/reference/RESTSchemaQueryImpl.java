package io.sdmx.im.beans.reference;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.URN;

public class RESTSchemaQueryImpl implements RESTSchemaQuery {
	private static final Logger LOG = LoggerFactory.getLogger(RESTSchemaQueryImpl.class);
	private static final long serialVersionUID = 1L;
	
	private IURNSingle<? extends IDSDRelatedBean> reference;
	private String dimAtObs = DimensionBean.TIME_DIMENSION_FIXED_ID;
	
	private String context;
	private String agencyId;
	private String id;
	private String version = "~";
	
	private Date validFrom;
	private Date validTo;
	
	private SdmxDate asOf;
	
	private boolean prettyPrint;
	
	public RESTSchemaQueryImpl(IURNSingle<? extends IDSDRelatedBean> reference, String dimAtObs) {
		this.reference = reference;
		if(ObjectUtil.validString(dimAtObs)) {
			this.dimAtObs = dimAtObs;
		}
	}

	public RESTSchemaQueryImpl(Request request) {
		String path = request.getPath();
		if(path.startsWith("/")) {
			path = path.substring(1);
		}
		evaluate(path.split("/"), request.getParameters());
	}
	
	public RESTSchemaQueryImpl(String[] queryString, Map<String, String> queryParameters) {
		evaluate(queryString, queryParameters);
	}
	
	private void evaluate(String[] queryString, Map<String, String> queryParameters) {
		parseQueryString(queryString);
		parseQueryParameters(queryParameters);
		
		SDMX_STRUCTURE_TYPE referencedStructure = SDMX_STRUCTURE_TYPE.parseClass(context);
		reference = URN.builder().maint(MaintainableRef.getInstance(agencyId, id, version)).structure(referencedStructure).buildSingle(IDSDRelatedBean.class);
	}
	
	private void parseQueryString(String[] queryString) {
		if(queryString.length < 2) {
			throw new SdmxSemmanticException("Schema query expected to contain context as the second argument");
		}
		context = queryString[1];
		
		if(queryString.length < 3) {
			throw new SdmxSemmanticException("Schema query expected to contain Agency ID as the third argument");
		}
		agencyId = queryString[2];
		
		if(queryString.length < 4) {
			throw new SdmxSemmanticException("Schema query expected to contain Resource ID as the fourth argument");
		}
		id = queryString[3];
		
		if(queryString.length > 4) {
			version = queryString[4];
			if(version.equalsIgnoreCase("latest")) {
				version = "~";
			}
		}
		
		if(queryString.length > 5) {
			throw new SdmxSemmanticException("Schema query has unexpected sixth argument");
		}
	}
	
	/**
	 * parse the query parameters, do not error if a parameter is unknown
	 */
	private void parseQueryParameters(Map<String, String> params) {
		if(params != null) {
			for(String key : params.keySet()) {
				String value = params.get(key);
				if (!ObjectUtil.validString(value)) {
					continue;
				}
				if(key.equalsIgnoreCase("dimensionAtObservation")) {
					dimAtObs=value;
				}  else if(key.equalsIgnoreCase("validFrom")) {
					validFrom = SdmxDateImpl.getSdmxDate(value).getDate();
				} else if(key.equalsIgnoreCase("validTo")) {
					validTo = SdmxDateImpl.getSdmxDate(value).getDate();
				}  else if(key.equalsIgnoreCase("prettyPrint")) {
					prettyPrint = value.equalsIgnoreCase("true");
				} else if (key.equalsIgnoreCase("asOf")) {
					try {
						asOf = SdmxDateImpl.getSdmxDate(value, true);
					} catch (Exception e) {
						throw new SdmxSemmanticException("Invalid value for parameter 'asOf'. Value was: " + value);
					}
				}  else {
					LOG.debug("Unknown query parameter: " +key);
				}
			}
		}
	}
	
	

	@Override
    public IURNSingle<? extends IDSDRelatedBean> getReference() {
		return reference;
	}

	@Override
    public String getDimAtObs() {
		return dimAtObs;
	}


	@Override
    public Date getValidFrom() {
		return validFrom;
	}

	@Override
    public Date getValidTo() {
		return validTo;
	}
	
	@Override
	public SdmxDate getAsOf() {
		return asOf;
	}

	@Override
	public boolean prettyPrint() {
		return prettyPrint;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(reference.getStructureType().getUrnClass().toLowerCase()+"/");
		sb.append(reference.getAgencyId()+"/"+reference.getMaintainableId()+ "/"+reference.getVersion());
		String concat = "?";
		if(dimAtObs != null) {
			sb.append(concat + "dimensionAtObservation="+dimAtObs);
		}
		if(validFrom != null) {
			sb.append(concat + "validFrom="+DateUtil.formatDate(validFrom));
		}
		if(validTo != null)
			sb.append(concat + "validTo="+DateUtil.formatDate(validTo));{
		}
		return sb.toString();
	}
}
