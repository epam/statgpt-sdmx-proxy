package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.im.beans.base.ComponentBeanImpl;

public class MeasureDimensionBeanImpl extends ComponentBeanImpl implements MeasureDimensionBean {
	private static final long serialVersionUID = 1L;

	public MeasureDimensionBeanImpl(MeasureMutableBean bean, IdentifiableBean parent) {
		super(bean, parent);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return MeasureDimensionBean.class;
	}
	
	/**
	 * @return overridden to return the absolute type
	 */
	@Override
	public IURNAbsolute<MeasureDimensionBean> getURN() {
		return (IURNAbsolute<MeasureDimensionBean>) super.getURN();
	}
	
	@Override
	public COMPONENT_TYPE getType() {
		return COMPONENT_TYPE.MEASURE;
	}
	
	@Override
	protected List<String> getParentIds(boolean includeDifferentTypes) {
		List<String> returnList = new ArrayList<>();
		returnList.add(this.getId());
		return returnList;
	}

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((MeasureDimensionBean)bean, includeFinalProperties, diff);
		}
		return false;
	}

	@Override
	public boolean isPrimaryMeasure() {
		return false;
	}
	
}
