package io.sdmx.im.beans.mapping.v3;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;

public class ReportingTaxonomyMapBeanDeferred extends GenericItemSchemeMapBeanDeferred<IReportingCategoryMapBean, IReportingTaxonomyMapBean> implements IReportingTaxonomyMapBean {
    private static final long serialVersionUID = 1L;

    public ReportingTaxonomyMapBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public ReportingTaxonomyMapBeanDeferred(IReportingTaxonomyMapBean maint) {
        super(maint);
    }
    
    @Override
    public IReportingTaxonomyMapBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ReportingTaxonomyMapBean(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    protected ReportingTaxonomyMapBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTaxonomyMapBeanDeferred(getDeferredDefinition(), loader);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<IReportingTaxonomyMapBean> getURN() {
        return (IURNMaintainable<IReportingTaxonomyMapBean>) super.getURN();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return IReportingTaxonomyMapBean.class;
    }

    @Override
    public IReportingTaxonomyMapMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }
}
