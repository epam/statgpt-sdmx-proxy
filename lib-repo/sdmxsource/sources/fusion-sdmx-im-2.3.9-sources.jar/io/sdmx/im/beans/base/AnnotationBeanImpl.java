package io.sdmx.im.beans.base;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class AnnotationBeanImpl extends SDMXBeanImpl implements AnnotationBean {
	private static final long serialVersionUID = 12L;
	private String id;
	private String title;
	private String type;
	private URI uri;
	private List<TextTypeWrapper> text = new ArrayList<>();
	private boolean isDynamic;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public AnnotationBeanImpl(AnnotationMutableBean annotationMutable, SDMXBean parent) {
		super(annotationMutable, parent);
		this.id = annotationMutable.getId();
		this.title = annotationMutable.getTitle();
		this.type = annotationMutable.getType();
		if(annotationMutable.getText() != null) {
			for(TextTypeWrapperMutableBean mutable : annotationMutable.getText()) {
				if(ObjectUtil.validString(mutable.getValue())) {
					text.add(new TextTypeWrapperImpl(mutable, "Annotation Text", this));
				}
			}
		}
		this.isDynamic = annotationMutable.isDynamic();
		setURI(annotationMutable.getUri());
		try {
			validate();
		} catch(SdmxException ex) {
			throw new SdmxException(ex, "Annotation is not valid");
		} catch(Throwable th) {
			throw new SdmxException(th, "Annotation is not valid");
		}
	}

	private void setURI(String serviceURIStr) {
		if(serviceURIStr == null) {
			this.uri =  null;
			return;
		}
		try {
			this.uri = new URI(serviceURIStr);
		} catch(SdmxException ex) {
			throw new SdmxException(ex, "Could not create attribute 'annotationURL' with value '" + serviceURIStr + "'");
		} catch(Throwable th) {
			throw new SdmxException(th, "Could not create attribute 'annotationURL' with value '" + serviceURIStr + "'");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean == null) {
			if(diffReport != null) {
				diffReport.addDiff(this, "Annotation", this.toString(), null);
			}
			return false;
		}
		if(!includeFinalProperties) {
			//If we don't care about the final properties, then don't check this
			return true;
		}
		return this.equals(bean, diffReport);
	}


	private boolean equals(Object obj, DiffReport diffReport) {
		boolean returnVal = true;
		if(obj instanceof AnnotationBean) {
		    Locale locFilter = TextTypeUtil.getLocaleFilter();
            TextTypeUtil.clearLocaleFilter();
            try {
    			AnnotationBean annotation = (AnnotationBean) obj;
    			if(!super.equivalent(id, annotation.getId(), "Annotation Id", diffReport)) {
    				returnVal = false;
    			}
    			if(!super.equivalent(title, annotation.getTitle(), "Annotation Title", diffReport)) {
    				returnVal = false;
    			}
    			if(!super.equivalent(type, annotation.getType(), "Annotation Type", diffReport)) {
    				returnVal = false;
    			}
    			if(!super.equivalent(uri, annotation.getUri(), "Annotation URI", diffReport)) {
    				returnVal = false;
    			}
    			if(!super.equivalent(text, annotation.getText(true), true, "Annotation Text", diffReport)) {
    				returnVal = false;
    			}
            } finally {
                TextTypeUtil.setLocaleFilter(locFilter);
            }
            return returnVal;
		}
		return false;
	}


	@Override
	public int hashCode() {
		StringBuilder sb = new StringBuilder();
		sb.append(id+title+type);
		if(uri != null) {
			sb.append(uri.toString());
		}
		for(TextTypeWrapper tt : text) {
			sb.append(tt.getLocale() + ":"+ tt.getValue());
		}
		return sb.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this.equals(obj, null);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION 							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		TextTypeUtil.ensureNoDuplicates(text);
		this.text = Collections.unmodifiableList(text);
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = new HashSet<>();
		super.addToCompositeSet(text, composites);
		return composites;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////


	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public boolean isDynamic() {
		return isDynamic;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public URI getUri() {
		return uri;
	}

	@Override
	public String getKey() {
		return getId();
	}

	@Override
	public List<TextTypeWrapper> getText() {
		return getText(false);
	}

	@Override
	public List<TextTypeWrapper> getText(boolean disableLocaleFilter) {
		if(disableLocaleFilter) {
			return text;
		}
		return TextTypeUtil.optionalFilterOnTextType(text);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		if(ObjectUtil.validString(getId())) {
			sb.append(getId());
			concat = ";";
		} else if(ObjectUtil.validString(getTitle())) {
			sb.append(concat+getTitle());
			concat = ";";
		} else if(ObjectUtil.validString(getType())) {
			sb.append(concat+getType());
			concat = ";";
		} else if(getUri() != null) {
			sb.append(concat+getUri());
			concat = ";";
		} else if(ObjectUtil.validCollection(getText())) {
			sb.append(concat+getText().get(0).getValue());
		}
		return sb.toString();
	}
}
