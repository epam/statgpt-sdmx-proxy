package io.sdmx.im.beans.conceptscheme;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.im.beans.base.ItemSchemeBeanImpl;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConceptSchemeBeanImpl extends ItemSchemeBeanImpl<ConceptBean> implements ConceptSchemeBean {
    private static final Logger LOG = LoggerFactory.getLogger(ConceptSchemeBean.class);
    private static final long serialVersionUID = 183L;

    private boolean createdFromTimeRequest = false;
    private MAINT_VALIDITY_TYPE validityType = MAINT_VALIDITY_TYPE.STANDARD;

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ConceptSchemeBeanImpl(ConceptSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
        LOG.debug("Stub ConceptSchemeBean Built");
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public ConceptSchemeBeanImpl(ConceptSchemeMutableBean conceptScheme) {
        super(conceptScheme);
        if (conceptScheme.createdFromTimeRequest()) {
            this.createdFromTimeRequest = true;
        }
        this.validityType = conceptScheme.getValidityType();

        LOG.debug("Building ConceptSchemeBean from Mutable Bean");
        try {
            if(conceptScheme.getItems() != null) {
                int i = 1;
                for(ConceptMutableBean concept : conceptScheme.getItems()) {
                    this.items.add(new ConceptBeanImpl(this, concept, i));
                    i++;
                }
                setHasValidityPeriod();
            }
        } catch(SdmxSemmanticException ex) {
            throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        } catch(Throwable th) {
            throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
        }

        try {
            validate();
        } catch(SdmxSemmanticException e) {
            throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
        }
        if(LOG.isDebugEnabled()) {
            LOG.debug("ConceptSchemeBean Built " + this);
        }
    }
    
    @Override
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
        super.populateDeferredBeanBuilder(builder);
        if(validityType != MAINT_VALIDITY_TYPE.STANDARD) {
            builder.property("VPType", validityType.toString());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP VALIDATION						 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
        if(bean == null) {
            return false;
        }

        if (bean.getStructureType() != this.getStructureType()) {
            return false;
        }

        MAINT_VALIDITY_TYPE beanValidityType = ((ConceptSchemeBean)bean).getValidityType();
        if (beanValidityType != null) {
            boolean typeEquals = beanValidityType.equals(this.getValidityType());
            if (!typeEquals){
                return false;
            }
        }

        return super.deepEqualsInternal((ConceptSchemeBean)bean, includeFinalProperties, "Concept", diff);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////VALIDATION							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    private void validate() throws SdmxSemmanticException {
        Set<String> urns = new HashSet<>();

        if (this.hasValidityPeriod() && this.itemsHasValidityPeriod()) {
            throw new SdmxSemmanticException("Validity Period has been specified at both the maintainable level and the item level. This is not permitted.");
        }

        if(items != null) {
            Map<ConceptBean, Set<ConceptBean>> parentChildMap = new HashMap<>();

            for(ConceptBean concept : items) {
                if(urns.contains(concept.getUrn())) {
                    throw new SdmxSemmanticException(ExceptionCode.DUPLICATE_URN, concept.getUrn());
                }
                urns.add(concept.getUrn());
                if(isPartial() == false) {
                    try {
                        if(ObjectUtil.validString(concept.getParentConcept())) {
                            ConceptBean parent = getConceptBean(items, concept.getParentConcept());
                            Set<ConceptBean> children;
                            if(parentChildMap.containsKey(parent)) {
                                children = parentChildMap.get(parent);
                            } else {
                                children = new HashSet<>();
                                parentChildMap.put(parent, children);
                            }
                            children.add(concept);
                            //Check that the parent code is not directly or indirectly a child of the code it is parenting
                            recurseParentMap(parentChildMap.get(concept), parent, parentChildMap);
                        }
                    } catch(SdmxSemmanticException ex) {
                        throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
                    } catch(Throwable th) {
                        throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
                    }
                }
            }
            items = Collections.unmodifiableList(items);
        }
    }

    @Override
    protected void validateId(boolean startWithIntAllowed) {
        //Not allowed to start with an integer
        super.validateId(false);
    }

    /**
     * Recurses the map checking the children of each child, if one of the children is the parent code, then an excetpion is thrown
     * @param children
     * @param parent
     * @param parentChildMap
     */
    private void recurseParentMap(Set<ConceptBean> children, ConceptBean parent, Map<ConceptBean, Set<ConceptBean>> parentChildMap) {
        //If the child is also a parent
        if(children != null) {
            if(children.contains(parent)) {
                throw new SdmxSemmanticException(ExceptionCode.PARENT_RECURSIVE_LOOP, parent.getId());
            }
            for(ConceptBean currentChild : children) {
                recurseParentMap(parentChildMap.get(currentChild), parent, parentChildMap);
            }
        }
    }

    private ConceptBean getConceptBean(List<ConceptBean> concepts, String id) {
        for(ConceptBean currentBean : concepts) {
            if(currentBean.getId().equals(id)) {
                return currentBean;
            }
        }
        throw new SdmxSemmanticException(ExceptionCode.CAN_NOT_RESOLVE_PARENT, id);
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected Class<?> getConcreteInterface() {
        return ConceptSchemeBean.class;
    }

    @Override
    public boolean createdFromTimeRequest() {
        return createdFromTimeRequest;
    }

    /**
     * Override from {@link IdentifiableBean} to give specific types in generics
     */
    @Override
    public IURNMaintainable<ConceptSchemeBean> getURN() {
        return (IURNMaintainable<ConceptSchemeBean>) super.getURN();
    }
    
    @Override
    public ConceptSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new ConceptSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }

    @Override
    public ConceptSchemeBean cloneForDate(Date date) {
        return (ConceptSchemeBean)super.cloneForDate(date);
    }

    @Override
    public ConceptSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return (ConceptSchemeBean)super.filterItems(filterIds, isKeepSet);
    }

    @Override
    public ConceptSchemeMutableBean getMutableInstance() {
        return new ConceptSchemeMutableBeanImpl(this);
    }

    @Override
    public MAINT_VALIDITY_TYPE getValidityType() {
        return this.validityType;
    }

    @Override
    public ConceptSchemeBeanDeferred toDeferred() {
        return new ConceptSchemeBeanDeferred(this);
    }

    @Override
    public ConceptSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ConceptSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
