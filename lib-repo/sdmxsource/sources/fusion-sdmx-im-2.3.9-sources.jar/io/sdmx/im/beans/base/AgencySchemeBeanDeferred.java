package io.sdmx.im.beans.base;

import java.net.URL;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;

public class AgencySchemeBeanDeferred extends OrganisationSchemeBeanDeferred<AgencyBean, AgencySchemeBean> implements AgencySchemeBean {
    private static final long serialVersionUID = 1L;

    public AgencySchemeBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public AgencySchemeBeanDeferred(AgencySchemeBean maint) {
        super(maint);
    }
    
    @Override
    public AgencySchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new AgencySchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected AgencySchemeBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new AgencySchemeBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<AgencySchemeBean> getURN() {
        return (IURNMaintainable<AgencySchemeBean>) super.getURN();
    }
    
    @Override
    public AgencySchemeMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public boolean isDefaultScheme() {
        return this.getAgencyId().equals(DEFAULT_SCHEME);
    }

    @Override
    protected Class<?> getConcreteInterface() {
        return AgencySchemeBean.class;
    }
}
