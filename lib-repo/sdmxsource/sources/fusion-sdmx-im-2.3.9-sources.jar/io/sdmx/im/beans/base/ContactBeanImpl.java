package io.sdmx.im.beans.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;

public class ContactBeanImpl extends SDMXBeanImpl implements ContactBean {
	private static final long serialVersionUID = -178547853789992314L;
	private String id;
	private List<TextTypeWrapper> name = new ArrayList<>();
	private List<TextTypeWrapper> role = new ArrayList<>();
	private List<TextTypeWrapper> departments = new ArrayList<>();
	private List<String> email = new ArrayList<>();
	private List<String> fax = new ArrayList<>();
	private List<String> telephone = new ArrayList<>();
	private List<String> uri = new ArrayList<>();
	private List<String> x400 = new ArrayList<>();


	public ContactBeanImpl(ContactMutableBean mutableBean) {
		this(mutableBean, null);
	}
	
	public ContactBeanImpl(ContactMutableBean mutableBean, SDMXBean parent) {
		super(mutableBean, parent);
		this.id = mutableBean.getId();
		TextTypeUtil.runProcessWithNoLocaleFilter(()-> {
			copyTextTypes(name, mutableBean.getNames(), "Contact Name");
			copyTextTypes(role, mutableBean.getRoles(), "Contact Role");
			copyTextTypes(departments, mutableBean.getDepartments(), "Contact Department");
		});
		if(mutableBean.getEmail() != null) {
			this.email = new ArrayList<>(mutableBean.getEmail());
		}
		if(mutableBean.getTelephone() != null) {
			this.telephone = new ArrayList<>(mutableBean.getTelephone());
		}
		if(mutableBean.getFax() != null) {
			this.fax = new ArrayList<>(mutableBean.getFax());
		}
		if(mutableBean.getUri() != null) {
			this.uri = new ArrayList<>(mutableBean.getUri());
		}
		if(mutableBean.getX400() != null) {
			this.x400 = new ArrayList<>(mutableBean.getX400());
		}
		validate();
	}

	private void copyTextTypes(List<TextTypeWrapper> copyTo, List<TextTypeWrapperMutableBean> mutable, String property) {
		if(mutable != null) {
			for (TextTypeWrapperMutableBean currentTextType : mutable) {
				copyTo.add(new TextTypeWrapperImpl(currentTextType, property, this));
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ATTRIBUTES			   ////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ContactBeanImpl(List<TextTypeWrapper> name,
			List<TextTypeWrapper> role, List<TextTypeWrapper> departments,
			List<String> email, List<String> fax,
			List<String> telephone, List<String> uri, List<String> x400) {
		super(null);
		
		if(name != null) {
			this.name = new ArrayList<>(name);
		}
		if(role != null) {
			this.role = new ArrayList<>(role);
		}
		if(departments != null) {
			this.departments = new ArrayList<>(departments);
		}
		if(email != null) {
			this.email = new ArrayList<>(email);
		}
		if(fax != null) {
			this.fax = new ArrayList<>(fax);
		}
		if(telephone != null) {
			this.telephone = new ArrayList<>(telephone);
		}
		if(uri != null) {
			this.uri = new ArrayList<>(uri);
		}
		if(x400 != null) {
			this.x400 = new ArrayList<>(x400);
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATE			///////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(ObjectUtil.validString(id)) {
			this.id = ValidationUtil.cleanAndValidateId(getId(), true);
		}
		this.name = Collections.unmodifiableList(this.name);
		this.role = Collections.unmodifiableList(this.role);
		this.departments = Collections.unmodifiableList(this.departments);
		this.email = Collections.unmodifiableList(this.email);
		this.fax = Collections.unmodifiableList(this.fax);
		this.telephone = Collections.unmodifiableList(this.telephone);
		this.uri = Collections.unmodifiableList(this.uri);
		this.x400 = Collections.unmodifiableList(this.x400);
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////
	//////////GETTTERS			//////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getId() {
		return id;
	}
	
	

	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diffReport) {
		if(bean instanceof ContactBean) {
			ContactBean contact = (ContactBean)bean;
			boolean returnValue = true;
			if(!super.equivalent(contact.getDepartments(), this.departments, includeFinalProperties, "Contact", diffReport)) {
				returnValue = false;
			}
			if(!super.equivalent(contact.getName(), this.name, includeFinalProperties, "Name", diffReport)) {
				returnValue = false;
			}
			if(!super.equivalent(contact.getRole(), this.role, includeFinalProperties, "Role", diffReport)) {
				returnValue = false;
			}
			if(!super.equivalent(contact.getEmail(), this.email, "Email", diffReport)) {
				returnValue = false;
			}
			if(!ObjectUtil.equivalent(contact.getFax(), this.fax)) {
				returnValue = false;
			}
			if(!ObjectUtil.equivalent(contact.getUri(), this.uri)) {
				returnValue = false;
			}
			if(!ObjectUtil.equivalent(contact.getX400(), this.x400)) {
				returnValue = false;
			}
			if(!ObjectUtil.equivalent(contact.getTelephone(), this.telephone)) {
				returnValue = false;
			}
			return returnValue;
		}
		return false;
	}

	@Override
	public List<String> getEmail() {
		return email;
	}

	@Override
	public List<TextTypeWrapper> getName() {
		return TextTypeUtil.optionalFilterOnTextType(name);
	}

	@Override
	public List<TextTypeWrapper> getRole() {
		return TextTypeUtil.optionalFilterOnTextType(role);
	}

	@Override
	public List<TextTypeWrapper> getDepartments() {
		return TextTypeUtil.optionalFilterOnTextType(departments);
	}

	@Override
	public List<String> getFax() {
		return fax;
	}

	@Override
	public List<String> getTelephone() {
		return telephone;
	}

	@Override
	public List<String> getUri() {
		return uri;
	}
	
	@Override
	public String getKey() {
		return getId();
	}

	@Override
	public List<String> getX400() {
		return x400;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////	

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = new HashSet<>();
	    super.addToCompositeSet(name, composites);
	    super.addToCompositeSet(role, composites);
	    super.addToCompositeSet(departments, composites);
	    return composites;
	}
}
