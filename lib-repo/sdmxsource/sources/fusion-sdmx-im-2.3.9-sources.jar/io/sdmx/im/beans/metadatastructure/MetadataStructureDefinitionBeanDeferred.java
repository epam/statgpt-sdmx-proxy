package io.sdmx.im.beans.metadatastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class MetadataStructureDefinitionBeanDeferred extends MaintainableBeanDeferred<MetadataStructureDefinitionBean> implements MetadataStructureDefinitionBean {
    private static final long serialVersionUID = 1L;

    public MetadataStructureDefinitionBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public MetadataStructureDefinitionBeanDeferred(MetadataStructureDefinitionBean maint) {
        super(maint);
    }
    
    @Override
    public MetadataStructureDefinitionBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new MetadataStructureDefinitionBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected MetadataStructureDefinitionBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new MetadataStructureDefinitionBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<MetadataStructureDefinitionBean> getURN() {
        return (IURNMaintainable<MetadataStructureDefinitionBean>) super.getURN();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return MetadataStructureDefinitionBean.class;
    }

    @Override
    public MetadataStructureDefinitionMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    public List<MetadataAttributeBean> getMetadataAttributes() {
        return load().getMetadataAttributes();
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }
}
