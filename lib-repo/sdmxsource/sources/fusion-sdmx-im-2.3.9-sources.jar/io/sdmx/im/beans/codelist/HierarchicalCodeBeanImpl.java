package io.sdmx.im.beans.codelist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

/**
 * CodeRefBean represents a Codelist item in a HierarchicalCodelistBean, named from the 2.0 SDMX Schema (in 2.1 it is called a HierarchicalCode).
 * It can have child CodeRefBeans.
 */
public class HierarchicalCodeBeanImpl extends IdentifiableBeanImpl implements HierarchicalCodeBean {
	private static transient final Logger log = LoggerFactory.getLogger(HierarchicalCodeBeanImpl.class);
	private static final long serialVersionUID = 31L;
	private List<HierarchicalCodeBean> codeRefs = new ArrayList<>();
	private IDirectCrossReferenceBean<CodeBean> codeReference;
	private SdmxDate validFrom;
	private SdmxDate validTo;
	private String levelRef;
	private transient LevelBean level;
	private SdmxPeriod validityPeriod;
	private String version;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public HierarchicalCodeBeanImpl(CodeRefMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		try {
			if(ObjectUtil.validString(bean.getLevelReference())) {
				this.levelRef = bean.getLevelReference();
			}
			if(bean.getCodeReference() != null) {
				this.codeReference = DirectCrossReferenceBean.build(this, "code", bean.getCodeReference(), CodeBean.class);
			}
			if(bean.getValidFrom() != null) {
				this.validFrom = new SdmxDateImpl(bean.getValidFrom(), TIME_FORMAT.DATE_TIME);
			}
			if(bean.getValidTo() != null) {
				this.validTo = new SdmxDateImpl(bean.getValidTo(), TIME_FORMAT.DATE_TIME);
			}

			if(bean.getCodeRefs() != null) {
				for(CodeRefMutableBean currentCodeRef : bean.getCodeRefs()) {
					this.codeRefs.add(new HierarchicalCodeBeanImpl(currentCodeRef, this));
				}
			}

			this.validityPeriod = bean.getSdmxPeriod().orElse(null);
			this.version = bean.getVersion();
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Error creating structure: " + this.toString());
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		// Each hierarchy's coderef must have an AliasRef with CodeId, OR a URN alone.
		if(codeReference != null) {
			if(codeReference.getTargetReference() != SDMX_STRUCTURE_TYPE.CODE) {
				throw new SdmxSemmanticException(ExceptionCode.REFERENCE_ERROR_UNEXPECTED_STRUCTURE, SDMX_STRUCTURE_TYPE.CODE.getType(), codeReference.getTargetReference().getType());
			}
		} else {
			throw new SdmxSemmanticException(ExceptionCode.CODE_REF_MISSING_CODE_REFERENCE, this.toString());
		}
		if(validFrom != null && validTo != null) {
			if(validFrom.isLater(validTo)) {
				throw new SdmxSemmanticException("Hierarchical Code Error - Valid from can not be after valid to");
			}
		}
		if(ObjectUtil.validString(levelRef)) {
			if(levelRef.contains(".")) {
				String[] split = levelRef.split("\\.");
				levelRef = split[split.length-1];
			}
			HierarchyBean heirarchy = getParent(HierarchyBean.class, false);
			if(heirarchy.getLevel() != null) {
				level = heirarchy.getLevelById(levelRef);
				if(level == null) {
					log.warn("Hierarchical Code Error - Could not find level with id '"+levelRef+"'");
				}
			}

		} else {
			HierarchyBean hierarchy = getParent(HierarchyBean.class, false);
			if(hierarchy.hasFormalLevels()) {
				int depthOfHierarchy = getLevelInHierarchy();
				level = hierarchy.getLevelAtPosition(depthOfHierarchy);
				if(level == null) {
					throw new SdmxSemmanticException("Hierarchical Code Error - Hierarchy states that there are formal levels, but there is no level defined for a hierarchy of depth '"+depthOfHierarchy+"'");
				}
			}
		}

		this.codeRefs = Collections.unmodifiableList(codeRefs);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			HierarchicalCodeBean that = (HierarchicalCodeBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(codeRefs, that.getCodeRefs(), includeFinalProperties, "Hierarchical Code", diff)) {
				returnVal = false;
			}
			if (returnVal) {
			    // The CodeReferences have passed the equivalence check, so ensure that their order is the same
			    returnVal = sameOrder(codeRefs, that.getCodeRefs(), "Hierarchical Code", diff);
            }
			if(!super.equivalent(codeReference, that.getCodeReference(), "Code Reference", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(validFrom, that.getValidFrom(), "Valid From", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(validTo, that.getValidTo(), "Valid To", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(version, that.getVersion(), "Version", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(getLevel(true), that.getLevel(true),"Level", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(getLevelInHierarchy(), that.getLevelInHierarchy(),"Level in Hierarchy", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(codeReference != null) {
			references.add(codeReference);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return HierarchicalCodeBean.class;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNAbsolute<HierarchicalCodeBean> getURN() {
		return (IURNAbsolute<HierarchicalCodeBean>)super.getURN();
	}
	
	@Override
	public List<HierarchicalCodeBean> getCodeRefs() {
		return codeRefs;
	}

	@Override
	public int getLevelInHierarchy() {
		return getFullIdPath(false).split("\\.").length;
	}

	@Override
	public boolean hasChildren() {
		return ObjectUtil.validCollection(codeRefs);
	}

	@Override
	public LevelBean getLevel(boolean acceptDefault) {
		if(!ObjectUtil.validString(levelRef)) {
			if(!acceptDefault) {
				return null;
			}
			if(level == null) {
				HierarchyBean hb =  getParent(HierarchyBean.class, false);
				level = hb.getLevelAtPosition(getLevelInHierarchy());
			}
		}
		return level;
	}

	@Override
	public ICrossReferenceBean<CodeBean> getCodeReference() {
		return codeReference;
	}

	@Override
	public SdmxDate getValidFrom() {
		return validFrom;
	}

	@Override
	public SdmxDate getValidTo() {
		return validTo;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(codeRefs, composites);
		return composites;
	}

	@Override
	public SdmxPeriod getValidityPeriod() {
		return this.validityPeriod;
	}

	@Override
	public boolean hasValidityPeriod() {
		return this.validityPeriod != null;
	}

	@Override
	public String getVersion() {
		return this.version;
	}
}
