package io.sdmx.im.beans.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.im.beans.base.AnnotableBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ComputationBeanImpl extends AnnotableBeanImpl implements ComputationBean {
	private static final long serialVersionUID = 2467028947066566585L;
	private String localId;
	private String softwarePackage;
	private String softwareLanguage;
	private String softwareVersion;
	private List<TextTypeWrapper> description = new ArrayList<>();
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ComputationBeanImpl(IdentifiableBean parent, ComputationMutableBean mutableBean) {
		super(mutableBean, parent);
		this.localId = mutableBean.getLocalId();
		this.softwareLanguage = mutableBean.getSoftwareLanguage();
		this.softwarePackage = mutableBean.getSoftwarePackage();
		this.softwareVersion = mutableBean.getSoftwareVersion();
		if(mutableBean.getDescriptions() != null) {
			for(TextTypeWrapperMutableBean currentTT : mutableBean.getDescriptions()) {
				if(ObjectUtil.validString(currentTT.getValue())) {
					description.add(new TextTypeWrapperImpl(currentTT, "Description", this));
				}
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException ex) {
			throw new SdmxSemmanticException(ex, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		} catch(Throwable th) {
			throw new SdmxException(th, ExceptionCode.BEAN_STRUCTURE_CONSTRUCTION_ERROR, this);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ComputationBean that = (ComputationBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(description, that.getDescription(), includeFinalProperties, "Description", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(localId, that.getLocalId(), "Local Id", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(softwarePackage, that.getSoftwarePackage(), "Software Package", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(softwareLanguage, that.getSoftwareLanguage(), "Software Language", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(softwareVersion, that.getSoftwareVersion(), "Software Version", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getLocalId() {
		return localId;
	}

	@Override
	public String getSoftwarePackage() {
		return softwarePackage;
	}

	@Override
	public String getSoftwareLanguage() {
		return softwareLanguage;
	}

	@Override
	public String getSoftwareVersion() {
		return softwareVersion;
	}
	
	@Override
	public String getKey() {
		return getLocalId();
	}

	@Override
	public List<TextTypeWrapper> getDescription() {
		return new ArrayList<>(description);
	}

	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(this.description == null) {
			throw new SdmxSemmanticException("Computation missing mandatory field 'description'");
		}
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(description, composites);
        return composites;
    }
}
