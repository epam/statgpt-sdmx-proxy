package io.sdmx.im.beans.refmetadata;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanImpl;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataSetMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.CrossRefrenceBeanBase;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class ReportedMetadataSetBean extends MaintainableBeanImpl implements IReportedMetadataSetBean {
	private static final long serialVersionUID = 1L;
	private IDirectCrossReferenceBean<? extends IMetadataTargetIdentifier> reportedAgainst;
	private List<ICrossReferenceBeanBase> targets;
	private List<IReportedMetadataAttributeBean> attributes;
	
	/**
	 * Stub constructor
	 */
	ReportedMetadataSetBean(IReportedMetadataSetBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.targets = Collections.emptyList();
		this.attributes = Collections.emptyList();
	}
	
	public ReportedMetadataSetBean(IReportedMetadataSetMutableBean bean) {
		super(bean);
		
		if(bean.getStructure() != null) {
			this.reportedAgainst = DirectCrossReferenceBean.build(this, "structure", bean.getStructure(), IMetadataTargetIdentifier.class);
		}
		if(bean.getTargets() != null) {
			this.targets = new ArrayList<>(bean.getTargets().size());
			for(StructureReferenceBean target : bean.getTargets()) {
				if(target != null) {
					this.targets.add(CrossRefrenceBeanBase.build(this, "target", target));
				}
			}
		}
		if(bean.getAttributes() != null) {
			this.attributes = new ArrayList<>(bean.getAttributes().size());
			for(IReportedMetadataAttributeMutableBean mAttr : bean.getAttributes()) {
				if(mAttr != null) {
					this.attributes.add(new ReportedMetadataAttributeBean(mAttr, this));
				}
			}
		}
		validate();
	}

	@Override
	protected Class<?> getConcreteInterface() {
		return IReportedMetadataSetBean.class;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		if(this.reportedAgainst == null) {
			throw new SdmxSemmanticException("Metadata Set must be reported against a metadata provision or metadata flow");
		}
		if(this.reportedAgainst.getTargetReference() != SDMX_STRUCTURE_TYPE.METADATA_PROVISION &&
				this.reportedAgainst.getTargetReference() != SDMX_STRUCTURE_TYPE.METADATA_FLOW) {
			throw new SdmxSemmanticException("Metadata Set must be reported against a metadata provision or metadata flow");
		}
		if(!ObjectUtil.validCollection(this.targets)) {
			throw new SdmxSemmanticException("Metadata Set must have at least 1 target");
		}
		if(!ObjectUtil.validCollection(attributes)) {
			throw new SdmxSemmanticException("Metadata Set must have at least 1 reported attribute");
		}
		
		this.targets = Collections.unmodifiableList(this.targets);
		this.attributes = Collections.unmodifiableList(this.attributes);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			IReportedMetadataSetBean that = (IReportedMetadataSetBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(this.getAttributes(), that.getAttributes(), includeFinalProperties, "", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(this.getStructure(), that.getStructure(), diff)) {
				returnVal = false;
			}
			if(!super.equivalentCollection(this, this.targets, that.getTargets(), "Target", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	@Override
	public IReportedMetadataSetBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new ReportedMetadataSetBean(this, actualLocation, isServiceUrl, completeStub);
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////COMPOSITES		                     //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected Set<SDMXBean> getCompositesInternal() {
		Set<SDMXBean> composites = super.getCompositesInternal();
		super.addToCompositeSet(this.getAttributes(), composites);
		return composites;
	}
	
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		if(reportedAgainst != null) {
			references.add(reportedAgainst);
		}
		references.addAll(targets);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public IURNMaintainable<IReportedMetadataSetBean> getURN() {
		return (IURNMaintainable<IReportedMetadataSetBean>)super.getURN();
	}

	@Override
	public ICrossReferenceBean<? extends IMetadataTargetIdentifier> getStructure() {
		return reportedAgainst;
	}

	@Override
	public List<ICrossReferenceBeanBase> getTargets() {
		return targets;
	}

	@Override
	public List<IReportedMetadataAttributeBean> getAttributes() {
		return attributes;
	}
	
	@Override
	public IReportedMetadataSetMutableBean getMutableInstance() {
		return new ReportedMetadataSetMutableBean(this);
	}

    @Override
    public ReportedMetadataSetBeanDeferred toDeferred() {
        return new ReportedMetadataSetBeanDeferred(this);
    }
    
    @Override
    public ReportedMetadataSetBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new ReportedMetadataSetBeanDeferred(getDeferredDefinition(), loader);
    }
}
