package io.sdmx.im.beans.reference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.METADATA_QUERY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.query.IRESTMetadataQuery;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

public class RESTMetadataQuery implements IRESTMetadataQuery {
    private METADATA_QUERY_TYPE queryType;
    private STRUCTURE_QUERY_DETAIL structureQueryDetail = STRUCTURE_QUERY_DETAIL.FULL;
    private List<String> additionalPathParameters = Collections.emptyList();

    private IURN<?> urn;
    private SdmxDate asOf;

    public RESTMetadataQuery(Request request) {
        Map<String, String> parameters = request.getParameters();
        String path = request.getPath();
        init(path, parameters);
    }

    public RESTMetadataQuery(String path, Map<String, String> parameters) {
        init(path, parameters);
    }

    @Override
    public IURN<?> getURN() {
        return urn;
    }

    @Override
    public SdmxDate getAsOf() {
        return asOf;
    }

    private void init(String path, Map<String, String> parameters) {
        if(parameters == null) {
            parameters = Collections.emptyMap();
        }
        if(!path.startsWith("/")) {
            path = "/" + path;
        }
        String[] pathParts = path.split("/");
        int metadataStart = getMetadataPart(pathParts);
        if(metadataStart < 0) {
            throw new SdmxSemmanticException("Can not construct metadata query, path '"+path+"' does not include 'metadata' part");
        }

        metadataStart++;
        URNBuilder urnBuilder = URN.builder();
        if(pathParts.length > metadataStart) {
            queryType =  METADATA_QUERY_TYPE.parseType(pathParts[metadataStart]);
        } else {
            throw new SdmxSemmanticException("Missing Path Parameter: structure, metadataflow, or metadataset");
        }
        IMaintainableStructureType structureType = null;
        if(queryType == METADATA_QUERY_TYPE.BY_STRUCTURE) {
            metadataStart++;
            if(pathParts.length > metadataStart) {
                String structureResource = pathParts[metadataStart];
                structureType = StructureTypes.byRESTResource(structureResource);
                urnBuilder.structure(structureType);  //TOOD this should be modified for custom structures
            }
        } else if(queryType == METADATA_QUERY_TYPE.BY_METADATASET) {
            urnBuilder.structure(SDMX_STRUCTURE_TYPE.METADATA_SET);
        } else {
            urnBuilder.structure(SDMX_STRUCTURE_TYPE.METADATA_FLOW);
        }
        String identifiableId = null;
        metadataStart++;
        if(pathParts.length > metadataStart) {
            urnBuilder.agencyId(pathParts[metadataStart]);
            metadataStart++;
        }
        if(pathParts.length > metadataStart) {
            String pathPart = pathParts[metadataStart];
            if(structureType != null && structureType.hasFixedId()) {
                identifiableId = pathPart;
            } else {
                urnBuilder.maintId(pathPart);
            }
            metadataStart++;
        }
        if(pathParts.length > metadataStart) {
            urnBuilder.version(pathParts[metadataStart]);
            metadataStart++;
        }
        boolean canHaveSubId = queryType == METADATA_QUERY_TYPE.BY_STRUCTURE;
        if(pathParts.length > metadataStart && canHaveSubId) {
            identifiableId = pathParts[metadataStart];
            metadataStart++;
        }
        if(identifiableId != null) {
            //The next path parameter is be the identifiable ID of the structure
            List<ISDMXStructureType> childTypes = StructureTypes.getChildTypes(structureType);
            ISDMXStructureType concreteType = null;
            if(childTypes != null) {
                for(ISDMXStructureType st : childTypes) {
                    if(!st.isAbstract()) {
                        concreteType = st;
                        break;
                    }
                }
            }
            if(concreteType != null) {
                urnBuilder.structure(concreteType);
                urnBuilder.identifableId(identifiableId);
                metadataStart++;
            }
            canHaveSubId = false;
        }
        if(pathParts.length > metadataStart) {
            additionalPathParameters = new ArrayList<>(pathParts.length - metadataStart);
            for(int i=metadataStart; i < pathParts.length; i++) {
                additionalPathParameters.add(pathParts[i]);
            }
            additionalPathParameters = Collections.unmodifiableList(additionalPathParameters);
        }
        this.urn = urnBuilder.build();

        String detail = parameters.get("detail");
        if(detail != null) {
            this.structureQueryDetail = STRUCTURE_QUERY_DETAIL.parseString(detail);
        }
        String asOf = parameters.get("asOf");
        if(asOf != null) {
            this.asOf = SdmxDateImpl.getSdmxDate(asOf);
        }
    }

    private int getMetadataPart(String[] pathParts) {
        int metadataStart = -1;
        for(String pathPart : pathParts) {
            metadataStart++;
            if(pathPart.equals("metadata")) {
                return metadataStart;
            }
        }
        return -1;
    }

    @Override
    public STRUCTURE_QUERY_DETAIL getStructureQueryDetail() {
        return structureQueryDetail;
    }

    @Override
    public List<String> getAdditionalPathParameters() {
        return additionalPathParameters;
    }

    @Override
    public METADATA_QUERY_TYPE getQueryType() {
        return queryType;
    }
}
