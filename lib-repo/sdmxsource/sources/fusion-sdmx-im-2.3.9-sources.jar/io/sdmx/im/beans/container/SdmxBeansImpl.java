package io.sdmx.im.beans.container;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.util.Hierarchy;
import io.sdmx.im.beans.upgrade.UpgradeToV3StructureMap;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxBeansImpl extends MetadataContainer implements SdmxBeans {
	private static final long serialVersionUID = 5981995104378086631L;
	
	private Hierarchy<AgencyBean> agencyHierarchy;
	private Map<IURNMaintainable<?>, MaintainableBean> urn2Maint;
	private URNStore urnStore;
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	////////////CONSTRUCTORS   						//////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////
	public SdmxBeansImpl() {
		clear();  //call clear to set up maps and urnstore
	}

	public SdmxBeansImpl(DATASET_ACTION action) {
		this();
		setAction(action);
	}

	public SdmxBeansImpl(HeaderBean header) {
		this();
		setHeader(header);
	}

	public SdmxBeansImpl(HeaderBean header, DATASET_ACTION action) {
		this();
		setHeader(header);
		setAction(action);
	}

	public SdmxBeansImpl(HeaderBean header, Collection<? extends MaintainableBean> maintainables) {
		this();
		setHeader(header);
		if(maintainables != null) {
			for(MaintainableBean currentMaintainable : maintainables) {
				addIdentifiable(currentMaintainable);
			}
		}
	}

	public SdmxBeansImpl(SdmxBeans...beans) {
		this();
		for(SdmxBeans currentBean : beans) {
			merge(currentBean);
		}
	}

	/**
	 * Create Beans container from zero or more MaintainableBeans
	 * @param maintainableBeans
	 */
	public SdmxBeansImpl(MaintainableBean... maintainableBeans) {
		this();
		if(maintainableBeans != null) {
			for(MaintainableBean currentMaint : maintainableBeans) {
				this.addIdentifiable(currentMaint);
			}
		}
	}

	/**
	 * Create Beans container from zero or more MaintainableBeans
	 * @param maintainableBeans
	 */
	public SdmxBeansImpl(Collection<? extends MaintainableBean> maintainableBeans) {
		this();
		if(maintainableBeans != null) {
			for(MaintainableBean currentMaint : maintainableBeans) {
				this.addIdentifiable(currentMaint);
			}
		}
	}

	
	
	@Override
	public <T extends IdentifiableBean> T getBean(IURNSingle<T> sRef) {
		if(sRef == null) {
			return null;
		}
		if(sRef.getReferenceType() == REFERENCE_TYPE.ABSOLUTE && sRef.isMaintainableReference()) {
			return (T) urn2Maint.get(sRef);
		}
		return SdmxBeans.super.getBean(sRef);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		Set<IURNMaintainable<?>> urns = urnStore.find(urn);
		Set<T> returnSet = new HashSet<>(urns.size());
		for(IURNMaintainable<?> foundUrn : urns) {
			MaintainableBean maint = urn2Maint.get(foundUrn);
			if(maint != null) {
				returnSet.add((T)maint);
			}
		}
		return returnSet;
	}
	
	@Override
	public Set<IMaintainableStructureType<?>> getDistinctTypes() {
		return urnStore.getDistinctTypes();
	}

	@Override
	public SdmxBeans getReadOnlyCopy() {
		return new SdmxBeansImmutable(this);
	}

	@Override
	public void merge(SdmxBeans beans) {
		merge(beans, true);
	}

	@Override
	public void merge(SdmxBeans beans, boolean overwrite) {
		if(beans.getHeader() != null) {
			setHeader(beans.getHeader());
		}
		if(beans.getAction() != null) {
			 setAction(beans.getAction());
		}
		beans.getAllMaintainables().forEach(e->addIdentifiable(e, overwrite));
	}

	@Override
	public void clear() {
		urn2Maint = Collections.synchronizedMap(new HashMap<>());
		urnStore = new URNStore();
	}

	@Override
	public void addIdentifiables(Collection<? extends IdentifiableBean> beans) {
		beans.forEach(e->  {
			addIdentifiable(e, true);
		});
	}
	
	@Override
	public boolean addIdentifiable(IdentifiableBean bean) {
		return addIdentifiable(bean, true);
	}
	
	private boolean addIdentifiable(IdentifiableBean bean, boolean overwrite) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == SDMX_STRUCTURE_TYPE.STRUCTURE_SET) {
			UpgradeToV3StructureMap.build((StructureSetBean)bean, this);
			return false;
		} 
		MaintainableBean maint = bean.getMaintainableParent();
		boolean exists = urn2Maint.containsKey(maint.getURN());
		if(exists && !overwrite) {
			return false;
		}
		urn2Maint.put(maint.getURN(), maint);  //always add so it overwrites if required
		if(!exists) {
			urnStore.register(bean.getMaintainableParent().getURN());
		}
		return exists;
	}

	@Override
	public void removeMaintainable(MaintainableBean bean) {
		urn2Maint.remove(bean.getURN());
		urnStore.deregister(bean.getURN());
	}

	@Override
	public boolean hasStructuresOfType(SDMX_STRUCTURE_TYPE type) {
		return urnStore.containsType(StructureTypes.getSdmxMaintinableType(type));
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(Class<T> structureType) {
		return this.getMaintainableBeans(URN.build(structureType));
	}

	@Override
	public Hierarchy<AgencyBean> getAgencyHierarchy() {
		if(agencyHierarchy == null) {
			this.agencyHierarchy = new AgencyHierarchyImpl(getAgenciesSchemes());
		}
		return agencyHierarchy;
	}

	@Override
	public Set<AgencyBean> getAgencies() {
		Set<AgencyBean> returnSet = new HashSet<>();
		for(AgencySchemeBean acyScheme : getMaintainableBeans(AgencySchemeBean.class)) {
			returnSet.addAll(acyScheme.getItems());
		}
		return returnSet;
	}

	@Override
	public Set<MaintainableBean> getAllMaintainables(SDMX_STRUCTURE_TYPE... exclude) {
		Collection<MaintainableBean> allValues = this.urn2Maint.values();
		
		if(exclude == null || exclude.length == 0) {
			return new HashSet<>(allValues);
		}
		Set<MaintainableBean> returnSet = new HashSet<>();
		allValues.stream().filter(e-> 
		{
			for(SDMX_STRUCTURE_TYPE ex : exclude) {
				if(ex != null && e.getStructureType() == ex) {
					return false;
				}
			}
			return true;
		}).forEach(returnSet::add);
		return returnSet;
	}

	@Override
	public Set<MaintainableBean> getMaintainables(SDMX_STRUCTURE_TYPE structureType) {
		return this.getMaintainableBeans(URN.builder().structure(structureType).build(MaintainableBean.class));
	}

	@Override
	public SdmxBeans filterMaintainables(Predicate<? super MaintainableBean> predicate) {
		SdmxBeans retBeans = new SdmxBeansImpl();
		this.urn2Maint.values().stream().filter(predicate).forEach(retBeans::addIdentifiable);
		return retBeans;
	}

	@Override
	protected Set<MaintainableBean> getAllMaintainables() {
		return new HashSet<>(this.urn2Maint.values());
	}
	
	
	
	@Override
	public int hashCode() {
		return urnStore.hashCode();
	}

	@Override
	/**
	 * Equal if this contains all the URNs of that
	 */
	public boolean equals(Object obj) {
		if(obj instanceof SdmxBeansImpl) {
			SdmxBeansImpl that = (SdmxBeansImpl) obj;
			return urnStore.equals(that.urnStore);
		}
		return false;
	}
	
}
