package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.reference.complex.TimeRange;

public class TimeRangeImpl implements TimeRange {

	private boolean range;
	private SdmxDate startDate;
	private SdmxDate endDate;
	private boolean startInclusive = true;
	private boolean endInclusive = true;

	public TimeRangeImpl(boolean range, SdmxDate startDate, SdmxDate endDate, boolean startInclusive, boolean endInclusive) {
		this.range = range;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startInclusive = startInclusive;
		this.endInclusive = endInclusive;
		
		if (startDate == null && endDate == null) {
			throw new SdmxSemmanticException("When setting range, cannot have both start/end periods null.");
		}

		if (isRange()) {
			if (startDate == null || endDate == null) {
				throw new SdmxSemmanticException("When range is defined then both start/end periods should be set.");
			}
		} else {
			if (startDate != null && endDate != null) {
				throw new SdmxSemmanticException("When it is not a range then not both start/end periods can be set.");
			}
		}
	}
	
	@Override
	public boolean isRange() {
		return range;
	}

	@Override
	public SdmxDate getStartDate() {
		return startDate;
	}

	@Override
	public SdmxDate getEndDate() {
		return endDate;
	}

	@Override
	public boolean isStartInclusive() {
		return startInclusive;
	}

	@Override
	public boolean isEndInclusive() {
		return endInclusive;
	}

}
