package io.sdmx.im.beans.mapping.v3;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.utils.core.object.StringUtil;

/**
 *  <p>A specialisation of {@link TimeComponentMapBean} used to describe a string representation of time, and how this maps to SDMX Time Periods.</p>
 *  <br/>  
 *  <p>Describes the patterns for each supported time representation e.g. 2002 31 12 could be expressed as YYYY DD MM<p/>
 */
public class TimePatternMapBean extends TimeComponentMapBean implements ITimePatternMapBean {
	private static final long serialVersionUID = 1L;
	private String pattern;
	private String locale;

	public TimePatternMapBean(ITimePatternMapMutableBean bean, IStructureMapBean parent) {
		super(bean, parent);
		this.pattern = bean.getPattern();
		this.locale = bean.getLocale();
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(pattern != null) {
			this.pattern = pattern.trim();
		}
		if(pattern == null || pattern.length() == 0) {
			throw new SdmxSemmanticException("Time Pattern Map requires Pattern");
		}
		if(locale == null) {
			this.locale = StringUtil.manualIntern("en");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ITimePatternMapBean that = (ITimePatternMapBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(pattern, that.getPattern(), "Pattern", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(locale, that.getLocale(), "Locale", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getKey() {
		return null;
	}

	@Override
	public String getPattern() {
		return pattern;
	}

	@Override
	public String getLocale() {
		return locale;
	}
}
