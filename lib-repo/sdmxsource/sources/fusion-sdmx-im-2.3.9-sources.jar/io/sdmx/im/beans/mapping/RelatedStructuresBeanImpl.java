package io.sdmx.im.beans.mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.SdmxStructureBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.mapping.RelatedStructuresBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.mapping.RelatedStructuresMutableBean;
import io.sdmx.im.beans.base.SdmxStructureBeanImpl;
import io.sdmx.utils.sdmx.xs.DirectCrossReferenceBean;

public class RelatedStructuresBeanImpl extends SdmxStructureBeanImpl implements RelatedStructuresBean {
	private static final long serialVersionUID = 14L;
	private List<IDirectCrossReferenceBean<DataStructureBean>> keyFamilyRef = new ArrayList<>();
	private List<IDirectCrossReferenceBean<MetadataStructureDefinitionBean>> metadataStructureRef = new ArrayList<>();
	private List<IDirectCrossReferenceBean<ConceptSchemeBean>> conceptSchemeRef = new ArrayList<>();
	private List<IDirectCrossReferenceBean<CategorySchemeBean>> categorySchemeRef = new ArrayList<>();
	private List<IDirectCrossReferenceBean<OrganisationSchemeBean>> orgSchemeRef = new ArrayList<>();
	private List<IDirectCrossReferenceBean<HierarchyBean>> hierCodelistRef = new ArrayList<>();
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public RelatedStructuresBeanImpl(RelatedStructuresMutableBean bean, SdmxStructureBean parent) {
		super(bean, parent);
		keyFamilyRef = createCrossReferenceList("dsd", bean.getDataStructureRef(), DataStructureBean.class);
		metadataStructureRef = createCrossReferenceList("msd", bean.getMetadataStructureRef(), MetadataStructureDefinitionBean.class);
		conceptSchemeRef = createCrossReferenceList("conceptscheme", bean.getConceptSchemeRef(), ConceptSchemeBean.class);
		categorySchemeRef = createCrossReferenceList("categoryscheme", bean.getCategorySchemeRef(), CategorySchemeBean.class);
		orgSchemeRef = createCrossReferenceList("orgscheme", bean.getOrgSchemeRef(), OrganisationSchemeBean.class);
		hierCodelistRef = createCrossReferenceList("codelist", bean.getHierCodelistRef(), HierarchyBean.class);
		
	}
	
	private <T extends MaintainableBean> List<IDirectCrossReferenceBean<T>> createCrossReferenceList(String refType, List<StructureReferenceBean> structureReferences, Class<T> identifiable) {
		List<IDirectCrossReferenceBean<T>> retrurnList = new ArrayList<>();
		if(structureReferences != null) {
			for(StructureReferenceBean currentStructureReference : structureReferences) {
				retrurnList.add(DirectCrossReferenceBean.build(getParent().getIdentifiableParent(), refType, currentStructureReference, identifiable));
			}
		}
		return Collections.unmodifiableList(retrurnList);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			RelatedStructuresBean that = (RelatedStructuresBean) bean;
			boolean returnVal = true;
			
			if(!super.equivalent(keyFamilyRef, that.getDataStructureRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(metadataStructureRef, that.getMetadataStructureRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(conceptSchemeRef, that.getConceptSchemeRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(categorySchemeRef, that.getCategorySchemeRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(orgSchemeRef, that.getOrgSchemeRef(), diff)) {
				returnVal = false;
			}
			if(!super.equivalent(hierCodelistRef, that.getHierCodelistRef(), diff)) {
				returnVal = false;
			}
			return returnVal;
		}
		return false;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void getCrossReferences(Set<ICrossReferenceBeanBase> references) {
		references.addAll(keyFamilyRef);
		references.addAll(metadataStructureRef);
		references.addAll(conceptSchemeRef);
		references.addAll(categorySchemeRef);
		references.addAll(orgSchemeRef);
		references.addAll(hierCodelistRef);
	}

	@Override
	public List<IDirectCrossReferenceBean<DataStructureBean>> getDataStructureRef() {
		return keyFamilyRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<MetadataStructureDefinitionBean>> getMetadataStructureRef() {
		return metadataStructureRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<ConceptSchemeBean>> getConceptSchemeRef() {
		return conceptSchemeRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<CategorySchemeBean>> getCategorySchemeRef() {
		return categorySchemeRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<OrganisationSchemeBean>> getOrgSchemeRef() {
		return orgSchemeRef;
	}

	@Override
	public List<IDirectCrossReferenceBean<HierarchyBean>> getHierCodelistRef() {
		return hierCodelistRef;
	}

	@Override
	public String getKey() {
		return null;
	}
}
