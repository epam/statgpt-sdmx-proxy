package io.sdmx.im.beans.base;

import java.net.URL;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class DataConsumerSchemeBeanImpl extends OrganisationSchemeBeanImpl<DataConsumerBean> implements DataConsumerSchemeBean {
	private static final Logger LOG = LoggerFactory.getLogger(DataConsumerSchemeBeanImpl.class);
	private static final long serialVersionUID = 184L;


	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	DataConsumerSchemeBeanImpl(DataConsumerSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		LOG.debug("Stub DataConsumerSchemeBean Built");
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public DataConsumerSchemeBeanImpl(DataConsumerSchemeMutableBean bean) {
		super(bean);
		LOG.debug("Building DataConsumerSchemeBean from Mutable Bean");
		if(bean.getItems() != null) {
			for(DataConsumerMutableBean item : bean.getItems()) {
				this.items.add(new DataConsumerBeanImpl(item, this));
			}
			items = Collections.unmodifiableList(items);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("DataConsumerSchemeBean Built " + this.getUrn());
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((DataConsumerSchemeBean)bean, includeFinalProperties, "Data Consumer", diff);
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return DataConsumerSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<DataConsumerSchemeBean> getURN() {
		return (IURNMaintainable<DataConsumerSchemeBean>) super.getURN();
	}
	
	@Override
	public ISdmxVersion getVersion() {
		return SdmxVersion.DEFAULT;
	}

	@Override
	public String getId() {
		return FIXED_ID;
	}
	
	@Override
	public MaintainableBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new DataConsumerSchemeBeanImpl(this, actualLocation, isServiceUrl, completeStub);
	}

	@Override
	public DataConsumerSchemeMutableBean getMutableInstance() {
		return new DataConsumerSchemeMutableBeanImpl(this);
	}
	
	@Override
	public DataConsumerSchemeBean filterItems(Collection<String> filterIds, boolean isKeepSet) {
		return (DataConsumerSchemeBean)super.filterItems(filterIds, isKeepSet);
	}

    @Override
    public DataConsumerSchemeBeanDeferred toDeferred() {
        return new DataConsumerSchemeBeanDeferred(this);
    }

    @Override
    public DataConsumerSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new DataConsumerSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
