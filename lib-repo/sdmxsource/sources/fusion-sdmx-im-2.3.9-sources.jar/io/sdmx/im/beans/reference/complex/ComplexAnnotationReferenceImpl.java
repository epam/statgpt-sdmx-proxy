package io.sdmx.im.beans.reference.complex;

import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexAnnotationReference;
import io.sdmx.api.sdmx.model.beans.reference.complex.ComplexTextReference;

public class ComplexAnnotationReferenceImpl implements
		ComplexAnnotationReference {

	private ComplexTextReference typeRef;
	private ComplexTextReference titleRef;
	private ComplexTextReference textRef;

	public ComplexAnnotationReferenceImpl(ComplexTextReference typeRef, ComplexTextReference titleRef, ComplexTextReference textRef) {
		this.typeRef = typeRef;
		this.titleRef = titleRef;
		this.textRef = textRef;
	}
	
	@Override
	public ComplexTextReference getTypeReference() {
		return typeRef;
	}

	@Override
	public ComplexTextReference getTitleReference() {
		return titleRef;
	}

	@Override
	public ComplexTextReference getTextReference() {
		return textRef;
	}

}
