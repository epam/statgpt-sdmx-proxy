package io.sdmx.im.beans.transformation;

import java.net.URL;
import java.util.Collections;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.im.mutable.transformation.NamePersonalisationSchemeMutableBean;

/**
 * Container for {@link NamePersonalisationBean}
 */
public class NamePersonalisationSchemeBean extends VtlSchemeBean<INamePersonalisationBean>  implements INamePersonalisationSchemeBean {
	private static final long serialVersionUID = 1L;

	NamePersonalisationSchemeBean(INamePersonalisationSchemeBean bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		super(bean, actualLocation, isServiceUrl, completeStub);
		this.items = Collections.unmodifiableList(this.items);
	}

	public NamePersonalisationSchemeBean(INamePersonalisationSchemeMutableBean bean) {
		super(bean);
		if(bean.getItems() != null) {
			for(INamePersonalisationMutableBean item : bean.getItems()) {
				this.items.add(new NamePersonalisationBean(item, this, this.items.size()));
			}
		}
		this.items = Collections.unmodifiableList(this.items);
		validateUniqueItemIds();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}

		if (bean.getStructureType() != this.getStructureType()) {
			return false;
		}
		return super.deepEqualsInternal((INamePersonalisationSchemeBean)bean, includeFinalProperties, SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION.getType(), diff);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return INamePersonalisationSchemeBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNMaintainable<INamePersonalisationSchemeBean> getURN() {
		return (IURNMaintainable<INamePersonalisationSchemeBean>) super.getURN();
	}
	
	@Override
	public INamePersonalisationSchemeMutableBean getMutableInstance() {
		return new NamePersonalisationSchemeMutableBean(this);
	}

	@Override
	public INamePersonalisationSchemeBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
		return new NamePersonalisationSchemeBean(this, actualLocation, isServiceUrl, completeStub);
	}

    @Override
    public NamePersonalisationSchemeBeanDeferred toDeferred() {
        return new NamePersonalisationSchemeBeanDeferred(this);
    }
    
    @Override
    public NamePersonalisationSchemeBeanDeferred toDeferred(IDeferredLoader<MaintainableBean> loader) {
        return new NamePersonalisationSchemeBeanDeferred(getDeferredDefinition(), loader);
    }
}
