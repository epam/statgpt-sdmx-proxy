package io.sdmx.im.beans.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.im.beans.base.NameableBeanImpl;

public class ProcessStepBeanImpl extends NameableBeanImpl implements ProcessStepBean {
	private static final long serialVersionUID = 11L;
	
	private static final Logger LOG = LoggerFactory.getLogger(ProcessStepBeanImpl.class);
	
	private List<InputOutputBean> input = new ArrayList<>();
	private List<InputOutputBean> output = new ArrayList<>();
	private List<TransitionBean> transitions = new ArrayList<>();
	private List<ProcessStepBean> processSteps = new ArrayList<>();
	private ComputationBean computation;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public ProcessStepBeanImpl (IdentifiableBean parent, ProcessStepMutableBean processBean) {
		super(processBean, parent);
		if(processBean.getInput() != null) {
			for(InputOutputMutableBean currentIo : processBean.getInput()) {
				this.input.add(new InputOutputBeanImpl(this, currentIo));				
			}
		}
		if(processBean.getOutput() != null) {
			for(InputOutputMutableBean currentIo : processBean.getOutput()) {
				this.output.add(new InputOutputBeanImpl(this, currentIo));				
			}
		}
		if(processBean.getComputation() != null) {
			computation = new ComputationBeanImpl(this, processBean.getComputation());
		}
		if(processBean.getTransitions() != null) {
			for(TransitionMutableBean mutable : processBean.getTransitions()) {
				transitions.add(new TransitionBeanImpl(mutable, this));
			}
		}
		if(processBean.getProcessSteps() != null) {
			for(ProcessStepMutableBean mutable : processBean.getProcessSteps()) {
				processSteps.add(new ProcessStepBeanImpl(this, mutable));
			}
		}
		try {
			validate();
		} catch(SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, ExceptionCode.FAIL_VALIDATION, this);
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			ProcessStepBean that = (ProcessStepBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(input, that.getInput(), includeFinalProperties, "Input", diff)) {
				returnVal = false;
			}
			if(!super.equivalent(output, that.getOutput(), includeFinalProperties, "Output",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(transitions, that.getTransitions(), includeFinalProperties, "Transition",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(processSteps, that.getProcessSteps(), includeFinalProperties, "Process Step",  diff)) {
				returnVal = false;
			}
			if(!super.equivalent(computation, that.getComputation(), includeFinalProperties, diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() throws SdmxSemmanticException {
		//NO VALIDATION REQUIRED
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return ProcessStepBean.class;
	}
	
	@Override
	public ComputationBean getComputation() {
		return computation;
	}

	
	@Override
	public List<TextTypeWrapper> getAllTextTypes() {
		List<TextTypeWrapper> allTextTypes = super.getAllTextTypes();
		if(computation != null) {
			allTextTypes.addAll(computation.getDescription());
		}
		return allTextTypes;
	}


	@Override
	public List<InputOutputBean> getInput() {
		return new ArrayList<>(input);
	}

	@Override
	public List<InputOutputBean> getOutput() {
		return new ArrayList<>(output);
	}

	@Override
	public List<TransitionBean> getTransitions() {
		return new ArrayList<>(transitions);
	}
	
	@Override
	public List<ProcessStepBean> getProcessSteps() {
		return new ArrayList<>(processSteps);
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES		                     //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(input, composites);
        super.addToCompositeSet(output, composites);
        super.addToCompositeSet(transitions, composites);
        super.addToCompositeSet(processSteps, composites);
        super.addToCompositeSet(computation, composites);
        return composites;
    }
}
