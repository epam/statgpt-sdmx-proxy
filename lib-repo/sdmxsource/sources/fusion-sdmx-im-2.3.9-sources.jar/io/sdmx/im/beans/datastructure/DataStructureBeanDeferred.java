package io.sdmx.im.beans.datastructure;

import java.net.URL;
import java.util.List;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.im.beans.base.MaintainableBeanDeferred;

public class DataStructureBeanDeferred extends MaintainableBeanDeferred<DataStructureBean> implements DataStructureBean {
    private static final long serialVersionUID = 1L;

    public DataStructureBeanDeferred(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        super(bean, loader);
    }
    
    public DataStructureBeanDeferred(DataStructureBean maint) {
        super(maint);
    }
    
    @Override
    public DataStructureBean getStub(URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        return new DataStructureBeanImpl(this, actualLocation, isServiceUrl, completeStub);
    }
    
    @Override
    protected DataStructureBeanDeferred copy(IDeferredLoader<MaintainableBean> loader) {
        return new DataStructureBeanDeferred(getDeferredDefinition(), loader);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IURNMaintainable<DataStructureBean> getURN() {
        return (IURNMaintainable<DataStructureBean>) super.getURN();
    }

    @Override
    public DataStructureMutableBean getMutableInstance() {
        return load().getMutableInstance();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Class<?> getConcreteInterface() {
        return DataStructureBean.class;
    }

    @Override
    public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
        return load().getCrossReferencedConstrainables();
    }

    @Override
    public List<String> getDimensionIds() {
        return load().getDimensionIds();
    }

    @Override
    public DimensionListBean getDimensionList() {
        return load().getDimensionList();
    }

    @Override
    public AttributeListBean getAttributeList() {
        return load().getAttributeList();
    }

    @Override
    public MeasureListBean getMeasureList() {
        return load().getMeasureList();
    }

    @Override
    public List<MeasureDimensionBean> getMeasures() {
        return load().getMeasures();
    }

    @Override
    public MeasureDimensionBean getMeasure(String id) {
        return load().getMeasure(id);
    }

    @Override
    public List<DimensionBean> getDimensions(SDMX_STRUCTURE_TYPE... include) {
        return load().getDimensions(include);
    }

    @Override
    public DimensionBean getFrequencyDimension() {
        return load().getFrequencyDimension();
    }

    @Override
    public ICrossReferenceBean<MetadataStructureDefinitionBean> getMSDRef() {
        return load().getMSDRef();
    }

    @Override
    public boolean hasFrequencyDimension() {
        return load().hasFrequencyDimension();
    }

    @Override
    public DimensionBean getDimension(String id) {
        return load().getDimension(id);
    }

    @Override
    public int getDimensionIndex(String id) {
        return load().getDimensionIndex(id);
    }

    @Override
    public ComponentBean getComponent(String id) {
        return load().getComponent(id);
    }

    @Override
    public List<ComponentBean> getComponents() {
        return load().getComponents();
    }

    @Override
    public List<GroupBean> getGroups() {
        return load().getGroups();
    }

    @Override
    public GroupBean getGroup(String groupId) {
        return load().getGroup(groupId);
    }

    @Override
    public DimensionBean getTimeDimension() {
        return load().getTimeDimension();
    }

    @Override
    public PrimaryMeasureBean getPrimaryMeasure() {
        return load().getPrimaryMeasure();
    }

    @Override
    public List<AttributeBean> getAttributes() {
        return load().getAttributes();
    }

    @Override
    public List<AttributeBean> getDatasetAttributes() {
        return load().getDatasetAttributes();
    }

    @Override
    public List<AttributeBean> getGroupAttributes() {
        return load().getGroupAttributes();
    }

    @Override
    public List<AttributeBean> getGroupAttributes(String groupId, boolean includeDimensionGroups) {
        return load().getGroupAttributes(groupId, includeDimensionGroups);
    }

    @Override
    public List<AttributeBean> getDimensionGroupAttributes() {
        return load().getDimensionGroupAttributes();
    }

    @Override
    public List<AttributeBean> getSeriesAttributes(String crossSectionalConcept) {
        return load().getSeriesAttributes(crossSectionalConcept);
    }

    @Override
    public List<AttributeBean> getObservationAttributes() {
        return load().getObservationAttributes();
    }

    @Override
    public List<AttributeBean> getObservationAttributes(String crossSectionalConcept) {
        return load().getObservationAttributes(crossSectionalConcept);
    }

    @Override
    public AttributeBean getAttribute(String id) {
        return load().getAttribute(id);
    }

    @Override
    public AttributeBean getGroupAttribute(String id) {
        return load().getGroupAttribute(id);
    }

    @Override
    public AttributeBean getDimensionGroupAttribute(String id) {
        return load().getDimensionGroupAttribute(id);
    }

    @Override
    public AttributeBean getObservationAttribute(String id) {
        return load().getObservationAttribute(id);
    }
}