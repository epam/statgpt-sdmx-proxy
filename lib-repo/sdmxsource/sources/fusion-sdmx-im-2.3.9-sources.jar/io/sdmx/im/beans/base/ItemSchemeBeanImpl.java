package io.sdmx.im.beans.base;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.model.beans.base.HierarchicalItemBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.im.beans.deferred.DeferredBeanDefinition.DefferedBeanBuilder;
import io.sdmx.im.beans.items.ValidityPeriodItemBean;
import io.sdmx.utils.core.date.SdmxDateImpl;

public abstract class ItemSchemeBeanImpl<T extends ItemBean> extends MaintainableBeanImpl implements ItemSchemeBean<T> {
    private static final long serialVersionUID = -71053499216735610L;
    private boolean isPartial;
    protected List<T> items = new ArrayList<>();

    private List<T> empty = Collections.unmodifiableList(new ArrayList<T>());

    private boolean itemsHasValidityPeriod = false;

    private transient Map<String, List<T>> invalidItems;
    private transient List<T> itemsValidForTodayAndClosestToToday;
    private transient Date today = new Date();
    private transient Map<String, T> itemByIdMap;


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM ITSELF, CREATES STUB BEAN //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected ItemSchemeBeanImpl(ItemSchemeBean<T> bean, URL actualLocation, boolean isServiceUrl, boolean completeStub) {
        super(bean, actualLocation, isServiceUrl, completeStub);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @SuppressWarnings({ "rawtypes"})
    protected ItemSchemeBeanImpl(ItemSchemeMutableBean bean) {
        super(bean);
        this.isPartial = bean.isPartial();
    }

    @Override
    protected void populateDeferredBeanBuilder(DefferedBeanBuilder builder) {
       if(itemsHasValidityPeriod) {
           builder.property("VPItem", true);
       }
       if(isPartial()) {
           builder.property("Partial", isPartial());
       }
    }


    protected void validateUniqueItemIds() {
        if(items != null) {
            if(isPartial() == false) {
                //CHECK FOR DUPLICATION OF URN & ILLEGAL PARENTING
                Set<String> ids = new HashSet<>();
                for(T item: items) {
                    if(ids.contains(item.getId())) {
                        String errorMsg = item.getStructureType().getType() +" '" + item.getUrn() + "' has been specified twice in the "+this.getStructureType().getType();
                        throw new SdmxSemmanticException(errorMsg);
                    }
                    ids.add(item.getId());
                }
            }
        }
    }

    protected void setHasValidityPeriod(){
        List<T> localItems = this.items;
        boolean isPeriodBean = false;
        if(!localItems.isEmpty()){
            isPeriodBean = localItems.get(0) instanceof ValidityPeriodItemBean;
        }
        if(!isPeriodBean){
            itemsHasValidityPeriod = false;
            return;
        }
        for (T localItem : localItems) {
            ValidityPeriodItemBean newLocalItemCast = (ValidityPeriodItemBean)localItem;
            if(newLocalItemCast.hasValidityPeriod()){
                itemsHasValidityPeriod = true;
                return;
            }
        }
    }

    /**
     * Get all the items that are: <br />
     * <ul>
     * 	<li>Valid today</li>
     * 	<li>Have no validity period</li>
     * 	<li>If not valid today, the nearest valid item from the past</li>
     *  <li>If none in the past, the nearest in the future.</li>
     * </ul>
     * @return
     */
    protected void processLatestAndClosestItemsToDate() {
        // If there are no items at all or they are of the wrong type, early out
        List<T> allItems = this.getItems();
        if (allItems.isEmpty() || (!(allItems.get(0) instanceof ValidityPeriodItemBean))) {
            itemsValidForTodayAndClosestToToday = empty;
            return;
        }

        SdmxDate sdmxDateToday = new SdmxDateImpl(today, TIME_FORMAT.DATE_TIME);
        List<T> returnList = new ArrayList<>();
        Set<String> processedIds = new HashSet<>();

        // DEV-1937
        // Construct a Map of item ID to all other items that have the same ID
        // This is for Item Validity.  Since calling "allItemsForId" repeatedly for every item in the list
        // for performance reasons, do this only once and save it in a Map
        Map<String, List<T>> allItemsForId = new HashMap<>();
        for (T item : allItems) {
            String itemId = item.getId();
            List<T> aList = allItemsForId.get(itemId);
            if (aList == null) {
                aList=new ArrayList<>();
            }
            aList.add(item);
            allItemsForId.put(itemId, aList);
        }

        for (T item : allItems) {
            if (processedIds.contains(item.getId())) {
                continue;
            }

            ValidityPeriodItemBean vpi = (ValidityPeriodItemBean)item;
            if (!vpi.hasValidityPeriod()) {
                processedIds.add(item.getId());
                returnList.add(item);
                continue;
            }

            T nearestCode = obtainNearestCode(vpi, processedIds, sdmxDateToday, allItemsForId);
            if (nearestCode == null) {
                continue;
            }

            // Add the nearest code
            processedIds.add(nearestCode.getId());
            returnList.add(nearestCode);
        }
        itemsValidForTodayAndClosestToToday = Collections.unmodifiableList(returnList);
    }

    /**
     * Returns the nearest code. Items in the past are returned as priority over items in the future.
     * @param item
     * @param processedIds
     * @param aDate
     * @param allItemsForId
     * @return
     */
    private T obtainNearestCode(ValidityPeriodItemBean item, Set<String> processedIds, SdmxDate aDate, Map<String, List<T>> allItemsForId) {
        T nearestCode = null;
        //List<T> otherTimePeriods = this.getAllItemsById(item.getId());
        List<T> otherTimePeriods = allItemsForId.get(item.getId());

        boolean earlierExists = false;
        for (T validityPeriodItemBean : otherTimePeriods) {

            ValidityPeriodItemBean validityItem = (ValidityPeriodItemBean)validityPeriodItemBean;
            SdmxPeriod currentItemVP = validityItem.getValidityPeriod();

            if (currentItemVP.isInPeriod(aDate.getDate())) {
                // Since the item has a match for today, this MUST be the nearest code.
                processedIds.add(item.getId());
                nearestCode = validityPeriodItemBean;
                break;
            }

            // Evaluate past items first
            SdmxDate itemStartDate = item.getValidityPeriod().getStartPeriod();
            if (!(currentItemVP.getStartPeriod() != null && currentItemVP.getStartPeriod().isLater(aDate))) {
                if (itemStartDate != null && currentItemVP.getStartPeriod() != null) {
                    if (nearestCode == null) {
                        nearestCode = validityPeriodItemBean;
                        earlierExists = true;
                        continue;
                    }
                    if (currentItemVP.getStartPeriod().isLater(((ValidityPeriodItemBean)nearestCode).getValidityPeriod().getStartPeriod())) {
                        nearestCode = validityPeriodItemBean;
                        earlierExists = true;
                        continue;
                    }
                } else {
                    // DEV-2154 - need to determine the "most recent" entry that does not match today's date
                    // The item startPeriod is null. If the end period is earlier than today this could be a nearest date
                    if (currentItemVP.getEndPeriod().isEarlier(aDate)) {
                        if (nearestCode == null) {
                            nearestCode = validityPeriodItemBean;
                            earlierExists = true;
                            continue;
                        } else {
                            if (currentItemVP.getEndPeriod().isLater( ((ValidityPeriodItemBean)nearestCode).getValidityPeriod().getEndPeriod())) {
                                nearestCode = validityPeriodItemBean;
                                earlierExists = true;
                                continue;
                            }
                        }
                    }
                }
            }

            if (earlierExists) {
                continue;
            }


            // The future dates
            if (itemStartDate != null) {
                if (nearestCode == null) {
                    nearestCode = validityPeriodItemBean;
                    continue;
                }
                if (currentItemVP.getStartPeriod().getDate().before( ((ValidityPeriodItemBean)nearestCode).getValidityPeriod().getStartPeriod().getDate())) {
                    nearestCode = validityPeriodItemBean;
                }
            }
        }

        if (nearestCode == null) {
            SdmxPeriod currentItemPeriod = item.getValidityPeriod();
            if (currentItemPeriod.hasStartPeriod() && currentItemPeriod.getStartPeriod().isLater(aDate)) {
                return null;
            }

            nearestCode = (T)item;
        }

        return nearestCode;
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException{
        in.defaultReadObject();
        today = new Date();
    }

    @Override
    public List<T> getInvalidItems(String id) {
        if (this.invalidItems == null) {
            populateInvalidItems();
        }

        List<T> returnVal = this.invalidItems.get(id);
        if (returnVal != null) {
            return returnVal;
        }
        return new ArrayList<>();
    }

    @Override
    public List<T> getItemsValidForTodayAndClosestToToday() {
        if (this.itemsValidForTodayAndClosestToToday == null) {
            processLatestAndClosestItemsToDate();
        }
        return this.itemsValidForTodayAndClosestToToday;
    }

    private void populateInvalidItems(){
        List<T> localItems = this.items;
        Map<String, List<T>> invalidCodes = new HashMap<>();
        for (T item: localItems){
            if (!(item instanceof ValidityPeriodItemBean)) {
                continue;
            }
            ValidityPeriodItemBean vpi = (ValidityPeriodItemBean)item;
            if (!vpi.hasValidityPeriod()) {
                continue;
            }

            SdmxPeriod itemValidityPeriod = vpi.getValidityPeriod();
            if (itemValidityPeriod == null) {
                continue;
            }

            if (itemValidityPeriod.isInPeriod(today)) {
                continue;
            }

            String itemId = item.getId();
            if (invalidCodes.containsKey(itemId)){
                invalidCodes.get(itemId).add(item);
            } else {
                invalidCodes.put(itemId, Stream.of(item).collect(Collectors.toList()));
            }
        }
        this.invalidItems = invalidCodes;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////DEEP EQUALS							 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    protected boolean deepEqualsInternal(ItemSchemeBean<T> bean, boolean includeFinalProperties, String itemName, DiffReport diff) {
        if(bean == null) {
            return false;
        }
        boolean returnVal = true;
        if(!super.equivalent(getItems(), bean.getItems(), includeFinalProperties, itemName, diff)) {
            returnVal = false;
        }
        if(!super.equivalent(isPartial, bean.isPartial(), "Is Partial", diff)) {
            returnVal = false;
        }
        return super.deepEqualsInternal(bean, includeFinalProperties, diff) && returnVal;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public Set<SDMXBean> getCompositesInternal() {
        Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(items, composites);
        return composites;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////GETTERS								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Override from {@link IdentifiableBean} to give specific types in generics
     */
    @Override
    public IURNMaintainable<? extends ItemSchemeBean<T>> getURN() {
        return (IURNMaintainable<? extends ItemSchemeBean<T>>) super.getURN();
    }


    @Override
    public boolean isPartial() {
        return isPartial;
    }

    private List<T> getItemsInternal(Date date){
        if(items == null) {
            items = new ArrayList<>();
            items = Collections.unmodifiableList(items);
        }
        if(!itemsHasValidityPeriod || items.size() == 0){
            return items;
        }
        if(!(items.get(0) instanceof ValidityPeriodItemBean)){
            return items;
        }
        if(date == null){
            date = new Date();
        }
        List<T> retList = new ArrayList<>();
        for(T item: items){
            ValidityPeriodItemBean castItem = (ValidityPeriodItemBean) item;
            if(castItem.hasValidityPeriod()){
                SdmxPeriod validityPeriod = castItem.getValidityPeriod();
                if(validityPeriod.isInPeriod(date)){
                    retList.add(item);
                }
            }else{
                retList.add(item);
            }
        }
        return retList;
    }

    @Override
    public boolean itemsHasValidityPeriod() {
        return this.itemsHasValidityPeriod;
    }

    @Override
    public List<T> getItems(Date date) {
        return getItemsInternal(date);
    }

    @Override
    public List<T> getItems() {
        if(items == null) {
            items = Collections.emptyList();
        }
        return items;
    }


    @Override
    public T getItemById(String id) {
        if(itemByIdMap == null) {
            Map<String, T> itemByIdMap = new HashMap<>();
            for(T currentItem: items) {
                itemByIdMap.put(currentItem.getId(), currentItem);
            }
            this.itemByIdMap = itemByIdMap;
        }
        return itemByIdMap.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public ItemSchemeBean<T> cloneForDate(Date date) {
        if(this.itemsHasValidityPeriod()) {
            boolean cloneRequired = false;
            for (T item: this.items) {
                ValidityPeriodBean itemCast = (ValidityPeriodBean) item;
                if (itemCast.hasValidityPeriod()) {
                    SdmxPeriod itemSdmxPeriod = itemCast.getValidityPeriod();
                    if (!itemSdmxPeriod.isInPeriod(date)) {
                        cloneRequired = true;
                    }
                }
            }
            if(cloneRequired) {
                ItemSchemeMutableBean<?> clone = this.getMutableInstance().stripItems(date);
                return (ItemSchemeBean<T>) clone.getImmutableInstance();
            }
        }
        return this;
    }

    @Override
    public List<T> getAllItemsById(String id) {
        List<T> toReturn = new ArrayList<>();
        for (T item : this.items) {
            if(item.getId().equals(id)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////FILTER								 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet) {
        return filterItems(filterIds, isKeepSet, ITEM_FILTER_ACTION.NO_ACTION);
    }

    @Override
    public ItemSchemeBean<T> filterItems(Collection<String> filterIds, boolean isKeepSet, ITEM_FILTER_ACTION action) {
        if(filterIds == null) {
            return this;
        }
        ItemSchemeMutableBean<ItemMutableBean> mutableScheme = (ItemSchemeMutableBean<ItemMutableBean>) getMutableInstance();
        mutableScheme.createPartialList(new HashSet<>(filterIds), isKeepSet, action);
        return (ItemSchemeBean<T>) mutableScheme.getImmutableInstance();
    }

    private void populateFilterSet(List<HierarchicalItemBean> items, Set<String> itemsInScheme, Collection<String> filterIds) {
        for(HierarchicalItemBean item : items) {
            addToSet(filterIds, itemsInScheme, item.getFullIdPath(false));
            if(item.getItems().size() > -1 ) {
                populateFilterSet(item.getItems(), itemsInScheme, filterIds);
            }
        }
    }

    /**
     * Adds the itemId to the itemsInScheme set if they do not appear in the filtersId set.
     * <p/>
     * This method should not add an id if it is the child of a filter id, example if a filter Id is 'A.B' then 'A.B.C' should not be added as it
     * is a child.
     *
     * @param filterIds ids which should not be added
     * @param itemsInScheme the set to add to
     * @param itemId this is to add to the itemsInScheme Set
     */
    private void addToSet(Collection<String> filterIds, Set<String> itemsInScheme, String itemId) {
        for(String filterId : filterIds) {
            if(itemId.equals(filterId)) {
                //Do not Add
                return;
            }
            if(filterId.contains(".") && filterId.startsWith(itemId)) {
                //Do not add
                return;
            }
        }
        itemsInScheme.add(itemId);
    }
}
