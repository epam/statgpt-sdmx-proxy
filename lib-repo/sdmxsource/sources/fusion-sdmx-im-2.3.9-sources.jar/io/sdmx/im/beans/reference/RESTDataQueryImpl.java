package io.sdmx.im.beans.reference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.query.RESTDataQuery;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

public class RESTDataQueryImpl implements RESTDataQuery {
	private static final long serialVersionUID = -2;
	private static final String ALL = "all";
	private IURN<DataflowBean> flowRef;
	private IURNSingle<DataProviderBean> providerRef;
	private IURNSingle<ProvisionAgreementBean> provisionRef;
	private SdmxDate startPeriod;
	private SdmxDate endPeriod;
	private SdmxDate updatedAfter;
	private Integer firstNObs;
	private Integer lastNObs;
	private Integer offset;
	private Integer max;
	private boolean includeHistory;
	private DATA_QUERY_DETAIL queryDetail = DATA_QUERY_DETAIL.FULL;
	private String dimensionAtObservation;
	private String datasetId;
	private List<Set<String>> queryList=new ArrayList<>();
	private Map<String, String> additionalQueryParmeters = new HashMap<>();
	private String expression;

	@Override
	public String getRestQuery() {
		return toString(false);
	}

	@Override
	public String getExpression() {
		return expression;
	}

	@Override
	public String getDatasetId() {
		return datasetId;
	}

	/**
	 * Constructs a data query off a full or partial REST URL - the URL must start before the Data segment and be complete, example input:
	 * /data/IMF,PGI,1.0/156.BCA.BOP.L_B.Q?detail=full
	 * @param restString
	 */
	public RESTDataQueryImpl(String restString) {
		this(restString, new HashMap<>());
	}

	/**
	 * Constructs a data query off a full or partial REST URL - the URL must start before the Data segment and be complete, example input:
	 * /data/IMF,PGI,1.0/156.BCA.BOP.L_B.Q?detail=full
	 * @param restString
	 */
	public RESTDataQueryImpl(String restString, Map<String, String> queryParameters) {
		if (restString == null) {
			throw new IllegalArgumentException("Expected 'path' should not be null");
		}
		int dataIndex = restString.indexOf("data/");
		if(dataIndex < 0) {
			throw new IllegalArgumentException("Data query expected to start with 'data/'");
		}
		String queryString = restString.substring(dataIndex);

		//Parse any additional parameters
		if(queryString.indexOf("?") > 0) {
			String params = queryString.substring(queryString.indexOf("?")+1);
			if(params.length() > 0) {
				queryString = queryString.substring(0,queryString.indexOf("?"));

				for(String currentParam : params.split("&")) {
					String[] param = currentParam.split("=");
					if (param.length < 2) {
						throw new SdmxSemmanticException("Incomplete assignment in data query. Parameter at fault: " + param[0]);
					}
					queryParameters.put(param[0], param[1]);
				}
			} else {
				//Strip the ?
				queryString = queryString.substring(0, queryString.length()-1);
			}
		}

		parserQueryString(queryString.split("/"));
		parserQueryParameters(queryParameters);
	}

	/**
	 *
	 * @param queryString ["data", flow ref, query, provider]  for example ["data","BIS,EER,1.0","A.B.C"]
	 * where only the flow reference is required (null first entry,followed by flow ref)
	 * @param queryParameters
	 */
	public RESTDataQueryImpl(String[] queryString,
			Map<String, String> queryParameters) {
		parserQueryString(queryString);
		parserQueryParameters(queryParameters);
	}

	private void parserQueryString(String[] queryString) {
		if(queryString.length < 2) {
			throw new SdmxSemmanticException("Data query expected to contain Flow as the second argument");
		}
		setFlowRef(queryString[1]);

		if(queryString.length < 3) {
			setKey(ALL);
		} else {
			setKey(queryString[2]);
		}
		if(queryString.length > 3) {
			setProvider(queryString[3]);
		}
		if(queryString.length > 4) {
			setProvisionRef(queryString[4]);
		}
		if(queryString.length > 5 && ObjectUtil.validString(queryString[5])) {
			throw new SdmxSemmanticException("Data query expected unexpected 5th path parameter: "+ queryString[5]);
		}

	}

	@Override
	public String getParamValue(String param) {
		return additionalQueryParmeters.get(param);
	}

	@Override
	public IURNSingle<ProvisionAgreementBean> getProvisionRef() {
		return provisionRef;
	}

	@Override
	public IURN<DataflowBean> getFlowRef() {
		return flowRef;
	}

	@Override
	public IURNSingle<DataProviderBean> getProviderRef() {
		return providerRef;
	}

	@Override
	public boolean includeHistory() {
		return includeHistory;
	}

	@Override
	public SdmxDate getStartPeriod() {
		return startPeriod;
	}

	@Override
	public SdmxDate getEndPeriod() {
		return endPeriod;
	}

	@Override
	public SdmxDate getUpdatedAfter() {
		return updatedAfter;
	}

	@Override
	public Integer getLastNObservations() {
		return lastNObs;
	}

	@Override
	public Integer getFirstNObservations() {
		return firstNObs;
	}

	@Override
	public DATA_QUERY_DETAIL getQueryDetail() {
		return queryDetail;
	}

	@Override
	public String getDimensionAtObservation() {
		return dimensionAtObservation;
	}

	@Override
	public List<Set<String>> getQueryList() {
		return queryList;
	}
	
	@Override
	public Integer getOffset() {
		return offset;
	}

	@Override
	public Integer getMax() {
		return max;
	}

	private void setFlowRef(String flowRef) {
		if(!flowRef.equalsIgnoreCase(ALL)) {
			this.flowRef = parseMaintainableRef(flowRef, SDMX_STRUCTURE_TYPE.DATAFLOW).build(DataflowBean.class);
		} else {
//			this.flowRef = URN.builder().structure(DataflowBean.class).buildSingle(DataflowBean.class);
		}
	}

	protected void setProvisionRef(String provisionRef) {
		if(!provisionRef.equalsIgnoreCase(ALL)) {
			this.provisionRef = parseMaintainableRef(provisionRef, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT).buildSingle(ProvisionAgreementBean.class);
		}
	}

	private void setProvider(String provider) {
		if(!provider.equalsIgnoreCase(ALL)) {
			this.providerRef = parseProviderRef(provider);
		}
	}

	private IURNSingle<DataProviderBean> parseProviderRef(String str) {
		String split[] = str.split(",");
		if(split.length > 2) {
			throw new SdmxSemmanticException("Unexpected number of data provider reference arguments (, separated) for reference: "+str +" - expecting a maximum of two arguments (Agency Id, Id)");
		}

		URNBuilder urnBuilder = URN.builder();
		urnBuilder.maintId(DataProviderSchemeBean.FIXED_ID);
		urnBuilder.version(DataProviderSchemeBean.FIXED_VERSION);
		urnBuilder.structure(SDMX_STRUCTURE_TYPE.DATA_PROVIDER);
		if(split.length == 2) {
			urnBuilder.agencyId(split[0]);
			urnBuilder.identifableId(split[1]);
		} else {
			urnBuilder.identifableId(split[0]);
		}
		return urnBuilder.buildSingle(DataProviderBean.class);
	}

	private URNBuilder parseMaintainableRef(String str, SDMX_STRUCTURE_TYPE structureType) {
		String split[] = str.split(",");
		URNBuilder urnBuilder = URN.builder();
		if(split.length > 3) {
			throw new SdmxSemmanticException("Unexpected number of reference arguments (, separated) for reference: "+str +" - expecting a maximum of three arguments (Agency Id, Id, and Version)");
		}
		if(split.length > 2 && split[2].equalsIgnoreCase(ALL)) {
			split[2] = null;
		}
		if(split.length > 1 && split[1].equalsIgnoreCase(ALL)) {
			split[1] = null;
		}
		if(split.length > 0 && split[0].equalsIgnoreCase(ALL)) {
			split[0] = null;
		}
		urnBuilder.structure(structureType);
		if(split.length == 1) {
			urnBuilder.maintId(split[0]);
		} else {
			urnBuilder.agencyId(split[0]);
			urnBuilder.maintId(split[1]);
			if(split.length > 2) {
				urnBuilder.version(split[2]);
			}
		}
		return urnBuilder;
	}

	private void setKey(String key) {
		if(!key.equalsIgnoreCase(ALL)) {
			String[] split = key.split("\\.", Integer.MAX_VALUE);
			for(String currentKey : split) {
				Set<String> selectionsList = new HashSet<>();
				queryList.add(selectionsList);
				for(String currentSelection : currentKey.split("\\+")) {
					if(ObjectUtil.validString(currentSelection)) {
						selectionsList.add(currentSelection);
					}
				}
			}
		}
	}

	private void setDetail(String detail) {
		if(detail != null) {
			queryDetail = DATA_QUERY_DETAIL.parseString(detail);
		}
	}

	private void setStartPeriod(String startPeriod) {
		try {
			this.startPeriod = SdmxDateImpl.getSdmxDate(startPeriod);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Could not format 'startPeriod' value "+startPeriod+" as a date");
		}
	}

	private void setEndPeriod(String endPeriod) {
		try {
			this.endPeriod = SdmxDateImpl.getSdmxDate(endPeriod, false);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Could not format 'endPeriod' value "+endPeriod+" as a date");
		}
	}

	private void setUpdatedAfterDate(String updatedAfter) {
		try {
			this.updatedAfter = SdmxDateImpl.getSdmxDate(updatedAfter);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Could not format 'updatedAfter' value "+updatedAfter+" as a date");
		}
	}

	private void setLastXObs(String maxObs) {
		try {
			this.lastNObs = Integer.parseInt(maxObs);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Query parameter 'lastNObservations' expects an Integer, was given: " + maxObs);
		}
	}

	private void setFirstXObs(String maxObs) {
		try {
			this.firstNObs = Integer.parseInt(maxObs);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Query parameter 'firstNObservations' expects an Integer, was given: " + maxObs);
		}
	}
	
	private void setOffset(String offset) {
		try {
			this.offset = Integer.parseInt(offset);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Query parameter 'offset' expects an Integer, was given: " + offset);
		}
	}
	
	private void setMax(String max) {
		try {
			this.max = Integer.parseInt(max);
		} catch(NumberFormatException e) {
			throw new SdmxSemmanticException("Query parameter 'max' expects an Integer, was given: " + max);
		}
	}


	private void setDimensionAtObservation(String dimatObs) {
		this.dimensionAtObservation = dimatObs;
	}

	private void parserQueryParameters(Map<String, String> params) {
		if(params != null) {
			for(String key : params.keySet()) {
				String value = params.get(key);
				if(value != null) {
					parserQueryParameter(key, value);
				}
			}
		}
		additionalQueryParmeters = Collections.unmodifiableMap(additionalQueryParmeters);
	}

	void parserQueryParameter(String key, String value) {
		if(key.equalsIgnoreCase("startPeriod")) {
			setStartPeriod(value);
		} else if(key.equalsIgnoreCase("endPeriod")) {
			setEndPeriod(value);
		} else if(key.equalsIgnoreCase("updatedAfter")) {
			setUpdatedAfterDate(value);
		} else if(key.equalsIgnoreCase("firstNObservations")) {
			setFirstXObs(value);
		} else if(key.equalsIgnoreCase("lastNObservations")) {
			setLastXObs(value);
		} else if(key.equalsIgnoreCase("dimensionAtObservation")) {
			setDimensionAtObservation(value);
		} else if(key.equalsIgnoreCase("detail")) {
			setDetail(value);
		} else if(key.equalsIgnoreCase("includeHistory")) {
			includeHistory = Boolean.valueOf(value);
		// DEV-1246: datasetId is now considered an "additional query parameter"
//		} else if(key.equalsIgnoreCase("datasetId")) {
//			datasetId = value;
		} else if(key.equalsIgnoreCase("expression")) {
			expression = value;
		} else if(key.equalsIgnoreCase("offset")) {
			setOffset(value);
		} else if(key.equalsIgnoreCase("max")) {
			setMax(value);
		} else {
			additionalQueryParmeters.put(key, value);
		}
	}

	@Override
	public Map<String, String> getAdditionalQueryParmeters() {
		return additionalQueryParmeters;
	}

	@Override
	public String toString() {
		return toString(true);
	}

	private String toString(boolean includeExtendedParameters) {
		StringBuilder sb = new StringBuilder();

		sb.append("data/");
		if(flowRef == null) {
			sb.append(ALL);
		} else {
			String flowAgency = flowRef.getAgencyId() == null ? ALL : flowRef.getAgencyId();
			String flowId = flowRef.getMaintainableId() == null ? ALL : flowRef.getMaintainableId();
			String flowVersion = flowRef.getVersion() == null ? "latest" : flowRef.getVersion().toString();
			sb.append(flowAgency + "," + flowId +"," + flowVersion);
		}
		sb.append("/");
		String concat = "";
		if(!ObjectUtil.validCollection(queryList)) {
			sb.append(ALL);
		} else {
			for(Set<String> currentQuery : queryList) {
				sb.append(concat);
				concat = "";
				for(String code : currentQuery) {
					sb.append(concat);
					sb.append(code);
					concat = "+";
				}
				concat = ".";
			}
		}
		sb.append("/");
		if(providerRef == null) {
			sb.append(ALL);
		} else {
			String provAgency = providerRef.getAgencyId() == null ? ALL : providerRef.getAgencyId();
			String provId = providerRef.getIdentifiableId() == null ? ALL : providerRef.getIdentifiableId();
			sb.append(provAgency + "," + provId);
		}
		if(provisionRef != null) {
			String flowAgency = provisionRef.getAgencyId() == null ? ALL : provisionRef.getAgencyId();
			String flowId = provisionRef.getMaintainableId() == null ? ALL : provisionRef.getMaintainableId();
			String flowVersion = provisionRef.getVersion() == null ? "latest" : provisionRef.getVersion().toString();
			sb.append(flowAgency + "," + flowId +"," + flowVersion);
		}
		concat = "?";
		if(startPeriod != null) {
			sb.append(concat+"startPeriod="+startPeriod.getDateInSdmxFormat());
			concat = "&";
		}
		if(endPeriod != null) {
			sb.append(concat+"endPeriod="+endPeriod.getDateInSdmxFormat());
			concat = "&";
		}
		if(updatedAfter != null) {
			sb.append(concat+"updatedAfter="+updatedAfter.getDateInSdmxFormat());
			concat = "&";
		}
		if(firstNObs != null) {
			sb.append(concat+"firstNObservations="+firstNObs);
			concat = "&";
		}
		if(lastNObs != null) {
			sb.append(concat+"lastNObservations="+lastNObs);
			concat = "&";
		}
		if(queryDetail != null) {
			sb.append(concat+"detail="+queryDetail.getRestParam());
			concat = "&";
		}
		if(ObjectUtil.validString(dimensionAtObservation)) {
			sb.append(concat+"dimensionAtObservation="+dimensionAtObservation);
			concat = "&";
		}
		if(includeExtendedParameters) {
			if(max != null) {
				sb.append(concat+"max="+max);
				concat = "&";
			}
			if(offset != null) {
				sb.append(concat+"offset="+offset);
				concat = "&";
			}
			if(expression != null) {
				sb.append(concat+"expression="+this.expression);
				concat = "&";
			}
			if(getAdditionalQueryParmeters() != null) {
				for(String additionalParam : getAdditionalQueryParmeters().keySet()) {
					sb.append(concat+additionalParam+"="+getAdditionalQueryParmeters().get(additionalParam));
					concat = "&";
				}
			}
		}
		return sb.toString();
	}

}
