package io.sdmx.im.beans.reference;

import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class MaintainableProperties implements IMaintainableProperties {
	private static final long serialVersionUID = 1L;
    private String agencyId;
	private String id;
	private ISdmxVersion version;
	
	public static MaintainableProperties getInstance(IMaintainableRef mRef) {
		return new MaintainableProperties(mRef.getAgencyId(), mRef.getMaintainableId(), SdmxVersion.getInstance(mRef.getVersion().toString()));
	}
	
	public static MaintainableProperties getInstance(String agencyId, String id, String version) {
		return new MaintainableProperties(agencyId, id, SdmxVersion.getInstance(version));
	}
	
	public static MaintainableProperties getInstance(String agencyId, String id, ISdmxVersion version) {
		return new MaintainableProperties(agencyId, id, version);
	}
	
	private MaintainableProperties(String agencyId, String id, ISdmxVersion version) {
		this.agencyId = StringUtil.manualIntern(agencyId);
		this.id = StringUtil.manualIntern(id);
		this.version = version;
	}

	@Override
	public String getAgencyId() {
		return agencyId;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public ISdmxVersion getVersion() {
		return version;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof IMaintainableProperties) {
			IMaintainableProperties that = (IMaintainableProperties) obj;
			return ObjectUtil.equivalent(this.agencyId, that.getAgencyId()) &&
					ObjectUtil.equivalent(this.id, that.getId()) &&
					ObjectUtil.equivalent(this.version, that.getVersion());
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		return agencyId+":"+id+"("+version.toString()+")";
	}

	
	
}
