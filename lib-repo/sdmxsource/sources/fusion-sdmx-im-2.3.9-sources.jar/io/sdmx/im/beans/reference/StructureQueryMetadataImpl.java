package io.sdmx.im.beans.reference;

import java.util.Map;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.model.query.StructureQueryMetadata;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class StructureQueryMetadataImpl implements StructureQueryMetadata {
	private static final long serialVersionUID = 4511749640571382502L;
	private STRUCTURE_QUERY_DETAIL structureQueryDetail  = STRUCTURE_QUERY_DETAIL.FULL;
	private STRUCTURE_REFERENCE_DETAIL structureReferenceDetail = STRUCTURE_REFERENCE_DETAIL.NONE;
	private SDMX_STRUCTURE_TYPE specificStructureReference;
	private SdmxPeriod dateFromTo;
	private SdmxDate asOf;
	private String validOn;

	public StructureQueryMetadataImpl(
			STRUCTURE_QUERY_DETAIL structureQueryDetail,
			STRUCTURE_REFERENCE_DETAIL structureReferenceDetail,
			SDMX_STRUCTURE_TYPE specificStructureReference) {
		if(structureQueryDetail != null) {
			this.structureQueryDetail = structureQueryDetail;
		}
		if(structureReferenceDetail != null) {
			this.structureReferenceDetail = structureReferenceDetail;
		}
		if(specificStructureReference != null) {
			this.specificStructureReference = specificStructureReference;
		}
	}

	public StructureQueryMetadataImpl(String[] queryString, Map<String, String> queryParameters) {
		parserQueryString(queryString);
		parserQueryParameters(queryParameters);
	}

	private void parserQueryString(String[] queryString) {
		if(queryString == null) {
		}
	}

	private void parserQueryParameters(Map<String, String> params) {
		if(params != null) {
			SdmxDate validFrom = null;
			SdmxDate validTo = null;
			for(String key : params.keySet()) {
				String value = params.get(key);
				if(key.equalsIgnoreCase("detail")) {
					try {
						structureQueryDetail = STRUCTURE_QUERY_DETAIL.parseString(value);
					} catch(SdmxSemmanticException e) {
						throw new SdmxSemmanticException(e, "Unable to parse value for key '"+ key + "'.");
					}
				} else if (key.equalsIgnoreCase("references")) {
					try {
						structureReferenceDetail = STRUCTURE_REFERENCE_DETAIL.parseString(value);
						if(structureReferenceDetail == STRUCTURE_REFERENCE_DETAIL.SPECIFIC) {
							if(value.equalsIgnoreCase("organisationscheme")) {
								specificStructureReference = SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME;
							} else {
								specificStructureReference = SDMX_STRUCTURE_TYPE.parseClass(value);
							}
						}
					} catch(SdmxSemmanticException e) {
						throw new SdmxSemmanticException(e, "Unable to parse value for key '"+ key + "'.");
					}
				} else if(key.equalsIgnoreCase("validfrom") || key.equalsIgnoreCase("validto")){
					if(key.equalsIgnoreCase("validfrom")) {
						validFrom = SdmxDateImpl.getSdmxDate(value);
					}
					if(key.equalsIgnoreCase("validto")) {
						validTo = SdmxDateImpl.getSdmxDate(value);
					}
				} else if (key.equals("validOn")) {
					if (value != null) {
						if (value.trim().equals("")) {
							value = null;
						} else {
							try {
								SdmxDateImpl.getSdmxDate(value);
							} catch (Exception e) {
								throw new SdmxSemmanticException("Invalid value for parameter 'validOn'. Value was: " + value);
							}
						}
					}
					validOn = value;
				}  else if (key.equalsIgnoreCase("asOf")) {
					if (value != null) {
						if (value.trim().equals("")) {
							value = null;
						} else {
							try {
								asOf = SdmxDateImpl.getSdmxDate(value, true);
							} catch (Exception e) {
								throw new SdmxSemmanticException("Invalid value for parameter 'asOf'. Value was: " + value);
							}
						}
					}
					
				} else {
					//throw new SdmxSemmanticException("Unknown query parameter : " + key);
				}
			}
			if(validFrom == null && validTo == null) { // we do not want to set 2 nulls on the SdmxPeriod
				return;
			}
			this.dateFromTo = new SdmxPeriodImpl(validFrom, validTo);
		}
	}

	@Override
	public STRUCTURE_QUERY_DETAIL getStructureQueryDetail() {
		return structureQueryDetail;
	}

	@Override
	public STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail() {
		return structureReferenceDetail;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getSpecificStructureReference() {
		return specificStructureReference;
	}
	
	@Override
	public SdmxDate getAsOf() {
		return asOf;
	}

	@Override
	public SdmxPeriod getValidFromTo() {
		return this.dateFromTo;
	}

	@Override
	public String getValidOn() {
		return this.validOn;
	}

}
