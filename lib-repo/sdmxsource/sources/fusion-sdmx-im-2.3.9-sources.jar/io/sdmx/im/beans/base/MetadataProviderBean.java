package io.sdmx.im.beans.base;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;

public class MetadataProviderBean extends OrganisationBeanImpl implements IMetadataProviderBean {
	private static final long serialVersionUID = 1L;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEAN				 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public MetadataProviderBean(IMetadataProviderMutableBean bean, IMetadataProviderSchemeBean parent) {
		super(bean, parent);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP VALIDATION						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean.getStructureType() == this.getStructureType()) {
			return super.deepEqualsInternal((IMetadataProviderBean)bean, includeFinalProperties, diff);
		}
		return false;
	}

	@Override
	public List<ICrossReferenceBean<? extends ConstrainableBean>> getCrossReferencedConstrainables() {
		return null;
	}

	@Override
	public IMetadataProviderSchemeBean getMaintainableParent() {
		return (IMetadataProviderSchemeBean)super.getMaintainableParent();
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 			 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return IMetadataProviderBean.class;
	}
	
	/**
	 * Override from {@link IdentifiableBean} to give specific types in generics
	 */
	@Override
	public IURNAbsolute<IMetadataProviderBean> getURN() {
		return (IURNAbsolute<IMetadataProviderBean>) super.getURN();
	}
	
    @Override
    protected Set<SDMXBean> getCompositesInternal() {
        return new HashSet<>();
    }
}
