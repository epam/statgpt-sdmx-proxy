package io.sdmx.im.beans.datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.im.beans.base.IdentifiableBeanImpl;

public class AttributeListBeanImpl extends IdentifiableBeanImpl implements AttributeListBean {
	private static final long serialVersionUID = -8089384199182589066L;
	private List<AttributeBean> attributes = new ArrayList<>();
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM MUTABLE BEANS 			 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public AttributeListBeanImpl(AttributeListMutableBean bean, DataStructureBean parent) {
		super(bean, parent);
		if(bean.getAttributes() != null) {
			for(AttributeMutableBean currentAttribute : bean.getAttributes()) {
				this.attributes.add(new AttributeBeanImpl(currentAttribute, this));
			}
		}
		this.attributes = Collections.unmodifiableList(attributes);
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////DEEP EQUALS							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean deepEquals(SDMXBean bean, boolean includeFinalProperties, DiffReport diff) {
		if(bean == null) {
			return false;
		}
		if(bean instanceof AttributeListBean) {
			AttributeListBean that = (AttributeListBean) bean;
			boolean returnVal = true;
			if(!super.equivalent(attributes, that.getAttributes(), includeFinalProperties, "Attributes", diff)) {
				returnVal = false;
			}
			return super.deepEqualsInternal(that, includeFinalProperties, diff) && returnVal;
		}
		return false;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS								 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////	
	@Override
	@SuppressWarnings("unchecked")
	protected Class<?> getConcreteInterface() {
		return AttributeListBean.class;
	}
	
	@Override
	public String getId() {
		return FIXED_ID;
	}	
	
	@Override
	protected String getURNPackageName() {
		return AttributeListBean.URN_PACKAGE;
	}

	@Override
	protected String getURNClassName() {
		return AttributeListBean.URN_CLASS;
	}
	
	@Override
	public List<AttributeBean> getAttributes() {
		return attributes;
	}
	
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////COMPOSITES				 //////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected Set<SDMXBean> getCompositesInternal() {
    	Set<SDMXBean> composites = super.getCompositesInternal();
        super.addToCompositeSet(attributes, composites);
        return composites;
    }
}
