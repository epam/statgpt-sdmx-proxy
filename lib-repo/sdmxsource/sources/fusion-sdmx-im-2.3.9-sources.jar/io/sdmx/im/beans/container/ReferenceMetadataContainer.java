package io.sdmx.im.beans.container;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;

public class ReferenceMetadataContainer extends MetadataContainer implements IReferenceMetadataContainer {
	private static final long serialVersionUID = 1L;
	private Set<IReportedMetadataSetBean> set;
	
	@Override
	public Set<IReportedMetadataSetBean> getReferenceMetadata() {
		if(set == null) {
			return Collections.emptySet();
		}
		return set;
	}

	@Override
	public void addReferenceMetadata(IReportedMetadataSetBean metadataSet) {
		if(set == null) {
			set = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
		}
		set.add(metadataSet);
	}

	@Override
	protected Set<MaintainableBean> getAllMaintainables() {
		return (Set) getReferenceMetadata();
	}

}
