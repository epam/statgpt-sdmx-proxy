package io.sdmx.im.beans.builder;

import io.sdmx.api.sdmx.builder.IImmutableBeanBuilder;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

/**
 * Standard implementation of the mutable to immutable, using the getImmutableInstance method on the bean
 */
public class StandardImmutableBeanBuilder implements IImmutableBeanBuilder {
    public static final StandardImmutableBeanBuilder INSTANCE = new StandardImmutableBeanBuilder();
    
    
    private StandardImmutableBeanBuilder() {}

    @Override
    public MaintainableBean build(MaintainableMutableBean mutable) {
        return mutable.getImmutableInstance();
    }

}
