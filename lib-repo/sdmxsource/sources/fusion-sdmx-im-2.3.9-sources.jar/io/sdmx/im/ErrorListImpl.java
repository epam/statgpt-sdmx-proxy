package io.sdmx.im;


import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.error.ErrorList;
import io.sdmx.utils.core.object.ObjectUtil;

public class ErrorListImpl implements ErrorList {
	private List<String> errorMessages;
	private boolean isWarning;
	
	public ErrorListImpl(List<String> errorMessages, boolean isWarning) {
		if(!ObjectUtil.validCollection(errorMessages)) {
			throw new IllegalArgumentException("ErrorListImpl requires error message to be provided");
		}
		this.errorMessages = errorMessages;
		this.isWarning = isWarning;
	}

	@Override
	public List<String> getErrorMessage() {
		return new ArrayList<>(errorMessages);
	}

	@Override
	public boolean isWarning() {
		return isWarning;
	}
}
