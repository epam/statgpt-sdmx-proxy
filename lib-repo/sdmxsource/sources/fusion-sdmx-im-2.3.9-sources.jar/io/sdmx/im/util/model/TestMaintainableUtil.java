package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.AdvancedReleaseCalendarBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.beans.registry.AdvancedReleaseCalendarBeanImpl;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingCategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodelistMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ComponentMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.im.mutable.process.InputOutputMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessStepMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateWorksheetMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Used to generate beans
 */
public class TestMaintainableUtil {
	
	
	public static AdvancedReleaseCalendarBean generateAdvancedReleaseCalendar() {
		return generateAdvancedReleaseCalendar(null, null, null);
	}
	
	public static AdvancedReleaseCalendarBean generateAdvancedReleaseCalendar(String agency, String id, String version) {
		ContentConstraintMutableBean mutable = getContentConstraintMutableBean(agency, id, version);
		ReleaseCalendarMutableBean relesaeCalendar = new ReleaseCalendarMutableBeanImpl();
		relesaeCalendar.setPeriodicity("P1Y");
		relesaeCalendar.setOffset("P1M");
		relesaeCalendar.setTolerance("P1D");
		mutable.setReleaseCalendar(relesaeCalendar);
		return new AdvancedReleaseCalendarBeanImpl(mutable);
	}
	
	public static ContentConstraintBean generateContentConstraint() {
		return generateContentConstraint(false, null, null, null);
	}
	public static ContentConstraintBean generateContentConstraint(boolean isDefiningDataPresent, String agency, String id, String version) {
		ContentConstraintMutableBean mutable = getContentConstraintMutableBean(agency, id, version);
		mutable.setIsDefiningActualDataPresent(isDefiningDataPresent);
		mutable.setIncludedCubeRegion(getCubeRegionMutableBean());
		return mutable.getImmutableInstance();
	}
	
	/**
	 * @param toConstrain
	 * @param dimCodes e.g "FREQ:A,B,C"
	 * @return
	 */
	public static ContentConstraintBean generateContentConstraint(ConstrainableBean toConstrain, boolean isIncludeCube, String... dimCodes) {
		ContentConstraintMutableBean mutable = getContentConstraintMutableBean(null, null, null);
		CubeRegionMutableBean cubeReg = new CubeRegionMutableBeanImpl();
		for(String currentDimCodes : dimCodes) {
			String[] dimToCodes = currentDimCodes.split(":");
			String[] codes = dimToCodes[1].split(",");
			cubeReg.addKeyValues(getKvs(dimToCodes[0], Arrays.asList(codes)));
		}
		if(isIncludeCube) {
			mutable.setIncludedCubeRegion(cubeReg);
		} else {
			mutable.setExcludedCubeRegion(cubeReg);
		}
		return mutable.getImmutableInstance();
	}
	
	public static CategorisationBean generateCategorisation() {
		return generateCategorisation(null, null, null);
	}
	public static CategorisationBean generateCategorisation(String agency, String id, String version) {
		CategorisationMutableBean mutable = new CategorisationMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		mutable.setStructureReference(getRef(SDMX_STRUCTURE_TYPE.DATAFLOW, "DF1"));
		mutable.setCategoryReference(getRef(SDMX_STRUCTURE_TYPE.CATEGORY, "CS", "C1"));
		return mutable.getImmutableInstance();
	}
	
	/**
	 * @param items
	 * @return agencyshcme with agencies id ITEM[x]
	 */
	public static AgencySchemeBean generateAgencyScheme(int items) {
		return generateAgencyScheme(items, null);
	}
	public static AgencySchemeBean generateAgencyScheme(int items, String agency) {
		AgencySchemeMutableBean mutable = new AgencySchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, AgencySchemeBean.FIXED_ID, AgencySchemeBean.FIXED_VERSION);
		for(int i=0; i < items; i++) {
			AgencyMutableBean acy = new AgencyMutableBeanImpl();
			setNameableProperties(acy, "ITEM", i);
			mutable.addItem(acy);
		}
		return mutable.getImmutableInstance();
	}
	
	public static DataProviderSchemeBean generateDataProviderScheme(int items) {
		return generateDataProviderScheme(items, null);
	}
	public static DataProviderSchemeBean generateDataProviderScheme(int items, String agency) {
		DataProviderSchemeMutableBean mutable = new DataProviderSchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, DataProviderSchemeBean.FIXED_ID, DataProviderSchemeBean.FIXED_VERSION);
		for(int i=0; i < items; i++) {
			DataProviderMutableBean item = new DataProviderMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	public static DataConsumerSchemeBean generateDataConsumerScheme(int items) {
		return generateDataConsumerScheme(items, null);
	}
	public static DataConsumerSchemeBean generateDataConsumerScheme(int items, String agency) {
		DataConsumerSchemeMutableBean mutable = new DataConsumerSchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, DataConsumerSchemeBean.FIXED_ID, DataConsumerSchemeBean.FIXED_VERSION);
		for(int i=0; i < items; i++) {
			DataConsumerMutableBean item = new DataConsumerMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	public static OrganisationUnitSchemeBean generateOrganisationUnitScheme(int items) {
		return generateOrganisationUnitScheme(items, null, null, null);
	}
	public static OrganisationUnitSchemeBean generateOrganisationUnitScheme(int items, String agency, String id, String version) {
		OrganisationUnitSchemeMutableBean mutable = new OrganisationUnitSchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		for(int i=0; i < items; i++) {
			OrganisationUnitMutableBean item = new OrganisationUnitMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	public static CategorySchemeBean generateCategoryScheme(int items) {
		return generateCategoryScheme(items, null, null, null);
	}
	public static CategorySchemeBean generateCategoryScheme(int items, String agency, String id, String version) {
		CategorySchemeMutableBean mutable = new CategorySchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		for(int i=0; i < items; i++) {
			CategoryMutableBean item = new CategoryMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	/**
	 * Generates a codelist, code Ids are:
	 * ITEM[x] where x starts from 1
	 * @param items
	 * @return
	 */
	public static CodelistBean generateCodelist(int items) {
		return generateCodelist(items, null, null, null);
	}
	public static CodelistBean generateCodelist(int items, String agency, String id, String version) {
		CodelistMutableBean mutable = new CodelistMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		if(id != null) {
			mutable.setId(id);
		}
		for(int i=0; i < items; i++) {
			CodeMutableBean item = new CodeMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	public static ConceptSchemeBean generateConceptScheme(int items) {
		return generateConceptScheme(items, null, null, null);
	}
	public static ConceptSchemeBean generateConceptScheme(int items, String agency, String id, String version) {
		ConceptSchemeMutableBean mutable = new ConceptSchemeMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		for(int i=0; i < items; i++) {
			ConceptMutableBean item = new ConceptMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	

	/**
	 * Generates a DSD with NON Coded Dimensions and Measures
	 * @param dimensions - number of dimensions to create with IDs of D[x] with x starting at 1: e.g D1, D2
	 * @param seriesAttributes - number of seriesAttributes to create with IDs of SA[x] with x starting at 1: e.g SA1, SA2
	 * @param time - if true a Time Dimension is created
	 * @param pm - if true a Primary Measure is created
	 * @param obsAttributes - number of obsAttributes to create with IDs of OA[x] with x starting at 1: e.g OA1, OA2
	 * @param additionalMeasures - Number of additional Measures with IDs of M[x] with x starting at 1: e.g M1, M2
	 * @return
	 */
	public static DataStructureBean generateDSD(int dimensions, int seriesAttributes, boolean time, boolean pm, int obsAttributes, int additionalMeasures) {
		return generateDSD(dimensions, seriesAttributes, time, pm, obsAttributes, additionalMeasures, null, null, null);
	}
	public static DataStructureBean generateDSD(int dimensions, int seriesAttributes, boolean time, boolean pm, int obsAttributes, int additionalMeasures, String agency, String id, String version) {
		DataStructureMutableBean dsdMutable = new DataStructureMutableBeanImpl();
		dsdMutable.setAgencyId(agency == null ? "TEST" : agency);
		dsdMutable.setId(id == null ? "TEST" : id);
		dsdMutable.setVersion(version == null ? "1.0" : version);
		dsdMutable.addName("en", "TEST");
		for(int i =0; i < dimensions; i++) {
			dsdMutable.addDimension(createDimension((i+1)));
		}
		for(int i=0; i < seriesAttributes; i++) {
			dsdMutable.addAttribute(createAttribute(dsdMutable, (i+1), ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP));
		
		}
		for(int i=0; i < obsAttributes; i++) {
			dsdMutable.addAttribute(createAttribute(dsdMutable, (i+1), ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION));
		}
		for(int i =0; i < additionalMeasures; i++) {
			dsdMutable.addMeasure(createMeasure((i+1)));
		}
		if(pm) {
			dsdMutable.setPrimaryMeasure(new PrimaryMeasureMutableBeanImpl());
			dsdMutable.getPrimaryMeasure().setConceptRef(createConceptReference("OBS_VALUE"));
		}
		if(time) {
			DimensionMutableBean dim = new DimensionMutableBeanImpl();
			dim.setId("TIME_PERIOD");
			dim.setTimeDimension(true);
			dim.setConceptRef(createConceptReference("T"));
			dsdMutable.addDimension(dim);
		}
		DataStructureBean dsd = dsdMutable.getImmutableInstance();
		
		return dsd;
	}
	
	public static DataflowBean generateDataflow() {
		return generateDataflow(null, null, null);
	}
	public static DataflowBean generateDataflow(String agency, String id, String version) {
		DataflowMutableBean mutable = new DataflowMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		mutable.setDataStructureRef(getRef(SDMX_STRUCTURE_TYPE.DSD, "DSD"));
		return mutable.getImmutableInstance();
	}
	
	public static ProcessBean generateProcess(int processSteps, int inputs, int outputs) {
		return generateProcess(processSteps, inputs, outputs, null, null, null);
	}
	public static ProcessBean generateProcess(int processSteps, int inputs, int outputs, String agency, String id, String version) {
		ProcessMutableBean mutable = new ProcessMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		
		for(int i=0; i < processSteps; i++) {
			ProcessStepMutableBean processStep = new ProcessStepMutableBeanImpl();
			setNameableProperties(processStep, "PS", i);
			for(int j=0; j < inputs; j++) {
				processStep.addInput(getInputOutput(j));
			}
			for(int j=0; j < outputs; j++) {
				processStep.addOutput(getInputOutput(j));
			}
			mutable.addProcessStep(processStep);
		}
		return mutable.getImmutableInstance();
	}
	
	private static InputOutputMutableBean getInputOutput(int idx) {
		InputOutputMutableBean io = new InputOutputMutableBeanImpl();
		io.setLocalId("IO"+idx);
		io.setStructureReference(getRef(SDMX_STRUCTURE_TYPE.CODE, "CL", "CODE"+idx));
		return io;
	}
	
	public static ProvisionAgreementBean generateProvisionAgreement() {
		return generateProvisionAgreement(null, null, null);
	}
	public static ProvisionAgreementBean generateProvisionAgreement(String agency, String id, String version) {
		ProvisionAgreementMutableBean mutable = new ProvisionAgreementMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		mutable.setDataproviderRef(getRef(SDMX_STRUCTURE_TYPE.DATA_PROVIDER, "DATA_PROVIDERS", "DP1"));
		mutable.setStructureUsage(getRef(SDMX_STRUCTURE_TYPE.DATAFLOW, "FLOW"));
		return mutable.getImmutableInstance();
	}
	
	public static RegistrationBean generateRegistration() {
		return generateRegistration(null, null, null);
	}
	public static RegistrationBean generateRegistration(String agency, String id, String version) {
		RegistrationMutableBean mutable = new RegistrationMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		mutable.setProvisionAgreementRef(getRef(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, "PA"));
		DataSourceMutableBean dataSource = new DataSourceMutableBeanImpl();
		dataSource.setDataUrl("http://www.google.com");
		dataSource.setRESTDatasource(true);
		mutable.setDataSource(dataSource);
		
		return mutable.getImmutableInstance();
	}
	
	public static ReportingTaxonomyBean generateReportingTaxonomy(int items) {
		return generateReportingTaxonomy(items, null, null, null);
	}
	public static ReportingTaxonomyBean generateReportingTaxonomy(int items, String agency, String id, String version) {
		ReportingTaxonomyMutableBean mutable = new ReportingTaxonomyMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		for(int i=0; i < items; i++) {
			ReportingCategoryMutableBean item = new ReportingCategoryMutableBeanImpl();
			setNameableProperties(item, "ITEM", i);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
	
	public static StructureSetBean generateStructureSet(int structureMaps, int codelistMaps) {
		return generateStructureSet(structureMaps, codelistMaps, null, null, null);
	}
	public static StructureSetBean generateStructureSet(int structureMaps, int codelistMaps, String agency, String id, String version) {
		StructureSetMutableBean mutable = new StructureSetMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		
		for(int i=0; i < structureMaps; i++) {
			StructureMapMutableBean structureMap = new StructureMapMutableBeanImpl();
			structureMap.setSourceRef(getRef(SDMX_STRUCTURE_TYPE.DATAFLOW, "DF_SOURCE"+i));
			structureMap.setTargetRef(getRef(SDMX_STRUCTURE_TYPE.DATAFLOW, "DF_TARGET"+i));
			setNameableProperties(structureMap, "SM", i);
			ComponentMapMutableBean compMap = new ComponentMapMutableBeanImpl();
			compMap.addMapConceptRef("D_SOURCE"+i);
			compMap.addMapTargetConceptRef("D_TARGET"+i);
			structureMap.addComponent(compMap);
			mutable.addStructureMap(structureMap);
		}
		
		for(int i=0; i < codelistMaps; i++) {
			CodelistMapMutableBean clMap = new CodelistMapMutableBeanImpl();
			setNameableProperties(clMap, "CL_MAP", i);
			clMap.setSourceRef(getRef(SDMX_STRUCTURE_TYPE.CODE_LIST, "CL_SOURCE"+i));
			clMap.setTargetRef(getRef(SDMX_STRUCTURE_TYPE.CODE_LIST, "CL_TARGET"+i));
			
			for(int j=0; j < codelistMaps; j++) {
				CodeMapMutableBean codeMap = new CodeMapMutableBeanImpl();
				codeMap.setSourceId("C_SOURCE"+j);
				codeMap.setTargetId("C_TARGET"+j);
				clMap.addItem(codeMap);
			}
			
			mutable.addCodelistMap(clMap);
		}
		
		return mutable.getImmutableInstance();
	}
	
	public static IRepresentationMapBean generateRepresentationMap(String agency, String id, String version) {
		IRepresentationMapMutableBean mutable = new RepresentationMapMutableBean();
		setMaintainableProperties(mutable, agency, id, version);
		mutable.addSourceRef(getRef(SDMX_STRUCTURE_TYPE.CODE_LIST, "CL_SOURCE"));
		mutable.addTargetRef(getRef(SDMX_STRUCTURE_TYPE.CODE_LIST, "CL_TARGET"));
		mutable.addMappedRelationship().addTargetValue("OUT_A").addSourceValue().setValue("IN_A");
		mutable.addMappedRelationship().addTargetValue("OUT_B").addSourceValue().setValue("IN_B");
		mutable.addMappedRelationship().addTargetValue("OUT_C").addSourceValue().setValue("IN_C");
		return mutable.getImmutableInstance();
	}

	public static ReportingTemplateBean generateReportingTemplate() {
		return generateReportingTemplate(null, null, null, null);
	}
	
	/**
	 * Creates a Reporting Template with a single worksheet and some rows and columns.
	 * Since a Reporting Template refers to a Dataflow, a reference to a valid Dataflow must be provided.
	 * 
	 * @param agency The agency of the ReportingTemplate
	 * @param id The id of the ReportingTemplate
	 * @param version The version of the ReportingTemplate
	 * @param dfRef The reference to the Dataflow
	 * @return the ReportingTemplate
	 */
	public static ReportingTemplateBean generateReportingTemplate(String agency, String id, String version, StructureReferenceBean dfRef) {
		ReportingTemplateMutableBean mutable = new ReportingTemplateMutableBeanImpl();
		setMaintainableProperties(mutable, agency, id, version);
		
		ReportingTemplateWorksheetMutableBean worksheet1 = new ReportingTemplateWorksheetMutableBeanImpl();
		String worksheetId = "BIS_CBS_Worksheet1";
		worksheet1.setId(worksheetId);
		worksheet1.setDataflow(dfRef);
		
		List<String> rows = Arrays.asList("L_REP_CTY", "L_INSTR", "CURR_TYPE_BOOK", "L_CP_SECTOR");
		worksheet1.setTableRows(rows);
		
		List<String> cols = Arrays.asList("L_MEASURE", "CBS_BANK_TYPE", "CBS_BASIS", "L_CP_COUNTRY");
		worksheet1.setTableCols(cols);
		
		List<ReportingTemplateWorksheetMutableBean> worksheets = new ArrayList<>();
		worksheets.add(worksheet1);
		mutable.setWorksheets(worksheets);
		
		return mutable.getImmutableInstance();
	}
	
	private static CubeRegionMutableBean getCubeRegionMutableBean() {
		CubeRegionMutableBean cubeReg = new CubeRegionMutableBeanImpl();
		cubeReg.addKeyValues(getKvs("EXR_TYPE", Arrays.asList("NRP0", "ERU1", "ERC0", "SP00")));
		cubeReg.addKeyValues(getKvs("EXR_SUFFIX", Arrays.asList("P","A","R","S","T","E")));
		cubeReg.addKeyValues(getKvs("FREQ", Arrays.asList("A","Q","M")));
		cubeReg.addKeyValues(getKvs("CURRENCY", Arrays.asList("_T","EUR","USD")));
		cubeReg.addKeyValues(getKvs("CURRENCY_DENOM", Arrays.asList("_T","EUR","USD")));
		return cubeReg;
	}
	
	private static ContentConstraintMutableBean getContentConstraintMutableBean(String agency, String id, String version) {
		ContentConstraintMutableBean mutable = new ContentConstraintMutableBeanImpl();
		mutable.setIsDefiningActualDataPresent(false);
		setMaintainableProperties(mutable, agency, id, version);
		setConstraintAttachment(mutable);
		return mutable;
	}
	
	private static void setConstraintAttachment(ConstraintMutableBean mutable) {
		ConstraintAttachmentMutableBean attachment = new ContentConstraintAttachmentMutableBeanImpl();
		StructureReferenceBean strucRef = new StructureReferenceBeanImpl("urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=ECB:EXR(1.0)");
		attachment.addStructureReference(strucRef);
		mutable.setConstraintAttachment(attachment);
	}

	private static KeyValuesMutable getKvs(String id, List<String> values) {
		KeyValuesMutable kv = new KeyValuesMutableImpl();
		kv.setId(id);
		kv.setKeyValues(values);
		return kv;
	}


	public static void setMaintainableProperties(MaintainableMutableBean mutable, IMaintainableProperties ref) {
		mutable.setAgencyId(ref.getAgencyId());
		mutable.setId(ref.getId());
		mutable.setVersion(ref.getVersion().toString());
		if(ref.getId() != null) {
			mutable.addName("en", ref.getId());
		}
	}

	public static void setMaintainableProperties(MaintainableMutableBean mutable, String agency, String id, String version) {
		mutable.setAgencyId("TEST");
		mutable.setId("TEST");
		mutable.addName("en", "TEST");
		if(agency != null) {
			mutable.setAgencyId(agency);
		}
		if(id != null) {
			mutable.setId(id);
		}
		if(version != null) {
			mutable.setVersion(version);
		}
	}
	
	public static void setNameableProperties(NameableMutableBean nameable, String id, String name) {
		nameable.setId(id);
		nameable.addName("en", name);
	}
	private static void setNameableProperties(NameableMutableBean nameable, String idPrefix, int idx) {
		idx++;
		nameable.setId(idPrefix+idx);
		nameable.addName("en", idPrefix+idx);
	}
	
	public static StructureReferenceBean getRef(SDMX_STRUCTURE_TYPE type, String maintId, String... identifableId) {
		return new StructureReferenceBeanImpl("TEST", maintId, "1.0", type, identifableId);
	}
	


	
	private static DimensionMutableBean createDimension(int num) {
		DimensionMutableBean dim = new DimensionMutableBeanImpl();
		dim.setId("D"+num);
		dim.setConceptRef(createConceptReference("D"+num));
		return dim;
	}
	
	public static AttributeMutableBean createAttribute(DataStructureMutableBean dsdMutable, int num, ATTRIBUTE_ATTACHMENT_LEVEL attach) {
		AttributeMutableBean attr = new AttributeMutableBeanImpl();
		attr.setAttachmentLevel(attach);
		String prefix = "A";
		switch(attach) {
		case DATA_SET:
			prefix = "DA";
			break;
		case DIMENSION_GROUP:
			prefix = "SA";
			for(DimensionMutableBean dim : dsdMutable.getDimensions()) {
				attr.addDimensionReferences(dim.getId());
			}
			break;
		case GROUP:
			prefix = "GA";
			break;
		case OBSERVATION:
			prefix = "OA";
			break;
		default:
			break;
			
		}
		attr.setId(prefix+num);
		attr.setConceptRef(createConceptReference("A"+num));
		attr.setMandatory(false);
		return attr;
	}

	private static MeasureMutableBean createMeasure(int num) {
		MeasureMutableBean measure = new MeasureMutableBeanImpl();
		measure.setId("M"+num);
		measure.setConceptRef(createConceptReference("M"+num));
		return measure;
	}
	
	public static StructureReferenceBean createConceptReference(String id) {
		return new StructureReferenceBeanImpl("TEST", "CS", "1.0", SDMX_STRUCTURE_TYPE.CONCEPT, id);
	}
	
	public static DataStructureBean createValueListReference(DataStructureBean dsd, String component, String valueListId) {
		//Modify to use a value list, and the default format changes
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
		rep.setRepresentation(new StructureReferenceBeanImpl("TEST", valueListId, "1.0", SDMX_STRUCTURE_TYPE.VALUE_LIST));
		dsdMutable.getComponentById(component).setRepresentation(rep);
		return dsdMutable.getImmutableInstance();
	}
	
	public static DataStructureBean createCodelistListReference(DataStructureBean dsd, String component, String valueListId) {
		//Modify to use a value list, and the default format changes
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
		rep.setRepresentation(new StructureReferenceBeanImpl("TEST", valueListId, "1.0", SDMX_STRUCTURE_TYPE.CODE_LIST));
		dsdMutable.getComponentById(component).setRepresentation(rep);
		return dsdMutable.getImmutableInstance();
	}
	
	public static MaintainableBean addName(MaintainableBean maint, String locale, String name) {
		MaintainableMutableBean mutable = maint.getMutableInstance();
		mutable.addName(locale, name);
		return mutable.getImmutableInstance();
	}
	
	public static MaintainableBean addDescription(MaintainableBean maint, String locale, String name) {
		MaintainableMutableBean mutable = maint.getMutableInstance();
		mutable.addDescription(locale, name);
		return mutable.getImmutableInstance();
	}
	
	public static MaintainableBean addAnnotation(MaintainableBean maint, String title, String type, String url) {
		MaintainableMutableBean mutable = maint.getMutableInstance();
		mutable.addAnnotation(title, type, url);
		return mutable.getImmutableInstance();
	}
	
}
