package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataAttributeMutableBean;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataSetMutableBean;
import io.sdmx.utils.sdmx.structure.AgencyUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestMetadataSetUtil {

	
	/**
	 * Creates a version 1.0 metadata set with the following properties set
	 * @param agency agencyID
	 * @param id metadata set ID
	 * @param structure target structure (Metadata Provision or Metadataflow)
	 * @param target linked structure (wildcard or full reference)
	 * @param attributes one or more attributes with the syntax ID:Text1;Text2 or ID:en=Text;fr=Text where the ID can contain a '.' to indicate child of another attribute, i.e PARENT:text, PARENT.CHILD:text
	 * 			if no text is supplied, a presentational node will be built
	 * @return
	 */
	public static IReportedMetadataSetBean createMetadataSet(String agency, 
													String id, 
													IURN structure, 
													List<StructureReferenceBean> target, 
													String... attributes) {
		
		IReportedMetadataSetMutableBean mutable = new ReportedMetadataSetMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, "1.0.0");
		if(structure != null) {
			mutable.setStructure(new StructureReferenceBeanImpl(structure));
		}
		if(target != null) {
			mutable.setTargets(target);
		}
		
		if(attributes != null) {
			//SDMX key is for the root attributes
			List<IReportedMetadataAttributeMutableBean> rootAttributes = new ArrayList<>();
			Map<String, IReportedMetadataAttributeMutableBean> attributeMap = new HashMap<>();
			
			for(String attribute : attributes) {
				String[] idTextSplit = attribute.split(":", 2);
				String fullId = idTextSplit[0];
				String text = idTextSplit.length == 1 ? null : idTextSplit[1];
				
				String[] parentChild = AgencyUtil.splitAgencyId(fullId); //reuse the logic for splitting an agency
				
				IReportedMetadataAttributeMutableBean attr = new ReportedMetadataAttributeMutableBean();
				attr.setId(parentChild[1]);
				attributeMap.put(fullId, attr);
				
				String parentId = parentChild[0];
				if(parentId.equals("SDMX")) {
					rootAttributes.add(attr);
				} else {
					IReportedMetadataAttributeMutableBean parent = attributeMap.get(parentId);
					if(parent == null) {
						throw new SdmxSemmanticException("Parent metadata attribute '"+parentId+"' does not exit");
					}
					parent.addAttribute(attr);
				}
				
				if(text != null) {
					for(String textValue : text.split(";")) {
						if(textValue.contains("=")) {
							String[] localeTextSplit = textValue.split("=", 2);
							attr.addStructuredValue(localeTextSplit[0], localeTextSplit[1]);
						} else {
							attr.setValue(textValue);
						}
					}
				}
			}
			mutable.setAttributes(rootAttributes);
		}
		
		return mutable.getImmutableInstance();
		
	}
	
}
