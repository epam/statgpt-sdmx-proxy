package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.im.util.model.TestRegistrationUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestRegistrationInstances {

	
	public static RegistrationBean getSimpleURL() {
		StructureReferenceBean pRef = new StructureReferenceBeanImpl("ECB", "EXR", "1.0", SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
		return TestRegistrationUtil.generateRegistration(pRef, "https://demo.metadatatechnology.com/FusionRegistry/ws/public/sdmxapi/rest/data/ECB,EXR,1.0/A.RON...", true);
	}
	
	public static RegistrationBean getSimpleURL(String id) {
		RegistrationBean reg = getSimpleURL();
		return TestRegistrationUtil.changeId(reg, id);
	}
	
	public static RegistrationBean getRESTURL() {
		StructureReferenceBean pRef = new StructureReferenceBeanImpl("ECB", "EXR", "1.0", SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT);
		return TestRegistrationUtil.generateRegistration(pRef, "https://demo.metadatatechnology.com/FusionRegistry/ws/public/sdmxapi/rest", false);
	}
	
	public static RegistrationBean getRESTURL(String id) {
		RegistrationBean reg = getRESTURL();
		return TestRegistrationUtil.changeId(reg, id);
	}
}
