package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.im.mutable.transformation.RulesetSchemeMutableBean;

public class TestRulesetSchemeUtil {

	public static IRulesetSchemeMutableBean create(String agencyId, String id, String version, String vtlVersion) {
		IRulesetSchemeMutableBean mutable = new RulesetSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.setVtlVersion(vtlVersion);
		mutable.addName("en", id+ " Name");
		return mutable;
	}
	
	

	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static IRulesetSchemeMutableBean createComplete(String agencyId, String id, String version, String vtlVersion) {
		IRulesetSchemeMutableBean mutable = TestRulesetSchemeUtil.create(agencyId, id, version, vtlVersion);

		mutable.addRuleSet("RS1", "rd1", "rt1", "rs1").addName("en", "R1");
		mutable.addRuleSet("RS2", "rd2", "rt2", "rs2").addName("en", "R2");
		mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl("SDMX", "VMS", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
		return mutable;
	}
}
