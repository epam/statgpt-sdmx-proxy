package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.im.util.model.TestAgencySchemeUtil;
import io.sdmx.utils.core.collection.CollectionUtil;

public class TestAgencySchemeInstances {

	/**
	 * Builds a SDMX scheme with the sponsor organisations present, no contact details or descriptions)
	 * @return
	 */
	public static AgencySchemeBean getSDMXScheme() {
		AgencySchemeBean acy = TestAgencySchemeUtil.generateAgencyScheme("SDMX", "BIS", "ECB", "ESTAT", "IMF", "OECD", "UN", "WB");
		AgencySchemeMutableBean mutable = acy.getMutableInstance();
		mutable.getItemById("BIS").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "Bank for International Settlements")));
		mutable.getItemById("ECB").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "European Central Bank")));
		mutable.getItemById("ESTAT").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "Eurostat")));
		mutable.getItemById("IMF").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "International Monetary Fund")));
		mutable.getItemById("OECD").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "Organisation for Economic Co-operation and Development")));
		mutable.getItemById("UN").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "United Nations")));
		mutable.getItemById("WB").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "World Bank")));
		return mutable.getImmutableInstance();
	}
	
	
	/**
	 * Builds a sub-agency scheme with department info: HR, IT, STATISTICS, MANAGEMENT
	 * 
	 * Contact details are added
	 * 
	 * @return
	 */
	public static AgencySchemeBean getSubScheme(String parentAgency) {
		AgencySchemeBean acySch = TestAgencySchemeUtil.generateAgencyScheme(parentAgency, "HR", "IT", "STATISTICS", "MANAGEMENT");
		AgencySchemeMutableBean mutable = acySch.getMutableInstance();
		
		ContactMutableBean contact = new ContactMutableBeanImpl();
		contact.addEmail("hr@gmail.com");
		contact.addName(TextTypeWrapperMutableBeanImpl.getInstance("en", "Alexie Plexie"));
		contact.addDepartment(TextTypeWrapperMutableBeanImpl.getInstance("en", "HR"));
		contact.addDepartment(TextTypeWrapperMutableBeanImpl.getInstance("fr", "Le HR"));
		
		contact.addRole(TextTypeWrapperMutableBeanImpl.getInstance("en", "Human Reources"));
		contact.addRole(TextTypeWrapperMutableBeanImpl.getInstance("fr", "Reources Le Human"));
		contact.addFax("+44 123 333444");
		contact.addTelephone("+44 1234 888777");
		contact.addTelephone("01234 412345");
		
		TestAgencySchemeUtil.addContactDetails(mutable, contact, "HR");
		
		mutable.getItemById("IT").addDescription("en", "In the basement");
		return mutable.getImmutableInstance();
	}
	
}
