package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Used to generate test {@link IRepresentationMapBean} for test purposes
 */
public class TestRepresentationMapUtil {

	public static IRepresentationMapMutableBean generateMap(IMaintainableProperties props, int sources, int targets) {
		return generateMap(StructureReferenceBeanImpl.fromProperties(props, SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP), sources, targets, null);
	}
	
	public static IRepresentationMapMutableBean generateMap(IMaintainableProperties props, int sources, int targets, Boolean isCodelist) {
		return generateMap(StructureReferenceBeanImpl.fromProperties(props, SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP), sources, targets, isCodelist);
	}
	
	public static IRepresentationMapMutableBean generateMap(StructureReferenceBean ref, int sources, int targets) {
		return generateMap(ref, sources, targets, null);
	}
	/**
	 * Generates a structure map with the agencyid, id and verison from the {@link MaintainableRefBean}
	 * @param ref
	 * @param sources the number of source mappings (free text) that will be added
	 * @param sources the number of target mappings (free text) that will be added
	 * @param isCodelist null if no reference, true for codelist reference, false for valuelist reference
	 * @return
	 */
	public static IRepresentationMapMutableBean generateMap(StructureReferenceBean ref, int sources, int targets, Boolean isCodelist) {
		IRepresentationMapMutableBean mutableMap = new RepresentationMapMutableBean();
		mutableMap.setAgencyId(ref.getAgencyId());
		mutableMap.setId(ref.getMaintainableId());
		mutableMap.setVersion(ref.getVersion().toString());
		mutableMap.addName("en", "Test: "+ref.getMaintainableId());
		SDMX_STRUCTURE_TYPE st = isCodelist == null ? null : isCodelist ? SDMX_STRUCTURE_TYPE.CODE_LIST : SDMX_STRUCTURE_TYPE.VALUE_LIST;
		for(int i =0; i < sources; i++) {
			StructureReferenceBean sourceRef = st == null ? null : new StructureReferenceBeanImpl("ACY", "S"+i, "1.0", st);
			mutableMap.addSourceRef(sourceRef);
		}
		for(int i =0; i < targets; i++) {
			StructureReferenceBean targetRef = st == null ? null : new StructureReferenceBeanImpl("ACY", "T"+i, "1.0", st);
			mutableMap.addTargetRef(targetRef);
		}
		return mutableMap;
	}

	/**
	 * Single source to single target
	 * @param sourceId
	 * @param targetId
	 * @return
	 */
	public static IRepresentationMapMutableBean generateMap(String acy, String id, String version) {
		IRepresentationMapMutableBean mutableMap = new RepresentationMapMutableBean();
		mutableMap.setAgencyId(acy);
		mutableMap.setId(id);
		mutableMap.setVersion(version);
		mutableMap.addName("en", "Test: "+id);
		return mutableMap;
	}

	/**
	 * Adds a reference to a source codelist or value list
	 * @param acy
	 * @param id
	 * @param version
	 * @param isCodelist is true the source is a codelist otherwise it is a value list
	 */
	public static void addSource(IRepresentationMapMutableBean mutableMap, String acy, String id, String version, boolean isCodelist) {
		mutableMap.addSourceRef(new StructureReferenceBeanImpl(acy, id, version, isCodelist ? SDMX_STRUCTURE_TYPE.CODE_LIST : SDMX_STRUCTURE_TYPE.VALUE_LIST));
	}

	/**
	 * Adds a reference to a target codelist or value list
	 * @param acy
	 * @param id
	 * @param version
	 * @param isCodelist is true the source is a codelist otherwise it is a value list
	 */
	public static void addTarget(IRepresentationMapMutableBean mutableMap, String acy, String id, String version, boolean isCodelist) {
		mutableMap.addTargetRef(new StructureReferenceBeanImpl(acy, id, version, isCodelist ? SDMX_STRUCTURE_TYPE.CODE_LIST : SDMX_STRUCTURE_TYPE.VALUE_LIST));
	}

	/**
	 *  Creates a mapping from the source value to the target
	 * @param mutableMap
	 * @param values - a list of values to map starting with the source value(s) and then target value(s) e.g. if there are 2 source values in the mapping and one target then values
	 * could look like:  "SOURCE1", "SOURCE2", "MAPPED_OUTPUT"
	 * @return
	 */
	public static IMappedRelationshipMutableBean mapValues(IRepresentationMapMutableBean mutableMap, String... values) {
		int sources = mutableMap.getSourceRef().size();
		
		IMappedRelationshipMutableBean mappedRelationship = mutableMap.addMappedRelationship();
		int i =0;
		for(String value : values) {
			if(i < sources) {
				mappedRelationship.addSourceValue().setValue(value).setRegEx(value.startsWith("^"));
			} else {
				mappedRelationship.addTargetValue(value);
			}
			i++;
		}
//		mappedRelationship.addTargetValue(target).addSourceValue().setValue(source).setRegEx(source.startsWith("^"));
		return mappedRelationship;
	}
	
	/**
	 *   Creates a mapping from the source value to the targets
	 * @param mutableMap
	 * @param source if it starts with a ^ the mapped source will say it is a regex
	 * @param target
	 * @return
	 */
	public static IMappedRelationshipMutableBean mapValuesMultiTarget(IRepresentationMapMutableBean mutableMap, String source, String... target) {
		IMappedRelationshipMutableBean mappedRelationship = mutableMap.addMappedRelationship();
		for(String currentTarget : target) {
			mappedRelationship.addTargetValue(currentTarget);
		}
		mappedRelationship.addSourceValue().setValue(source).setRegEx(source.startsWith("^"));
		return mappedRelationship;
	}
	
	/**
	 * Creates a mapping from the source values to the target
	 * @param mutableMap
	 * @param target
	 * @param source
	 * @return
	 */
	public static IMappedRelationshipMutableBean mapValuesMultiSource(IRepresentationMapMutableBean mutableMap, String target,  String... source) {
		IMappedRelationshipMutableBean mappedRelationship = mutableMap.addMappedRelationship();
		for(String currentSource : source) {
			mappedRelationship.addSourceValue().setValue(currentSource).setRegEx(currentSource.startsWith("^"));
		}
		mappedRelationship.addTargetValue(target);
		return mappedRelationship;
	}
}
