package io.sdmx.im.util.model.testinstances;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.util.model.TestDSDUtil;
import io.sdmx.im.util.model.TestDataProviderSchemeUtil;
import io.sdmx.im.util.model.TestDataProvisionUtil;
import io.sdmx.im.util.model.TestDataflowUtil;

public class TestDataProvisionInstances {


	public static ProvisionAgreementBean getEXRProvision(String providerId) {
		return TestDataProvisionUtil.generateProvision("ACY", providerId, new StructureReferenceBeanImpl("ECB", "DF_EXR", "1.0.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
	}
	

	/**
	 * Generates a provision with all references built and added to the beans container
	 * 
	 * @param providerId Id of the data provider 
	 * @param flowRef agency, id, version of dataflow
	 * @param time has time dimenison
	 * @param pm has primary measure
	 * @param dimensionIds dimension ids, postfix with :CL or :VL for codelist/valuelist reference or any valid TEXT_TYPE, e.g. DimId:INTEGER, CL:REF_AREA, CL:FREQ, CL:DATA_PROVIDER, CL:INDICATOR will create codelists with specific codes
	 * all other codelists/valuelists will be generated combination of characters @see TestDSDInstances.geoCodes and TestDSDInstances.getCodes
	 * @return
	 */
	public static SdmxBeans getProvisionWithDescendants(String providerId, IMaintainableRef flowRef, boolean time, boolean pm, String...dimensionIds) {

		DataStructureBean dsd = TestDSDUtil.generateDSD(MaintainableProperties.getInstance(flowRef), time, pm, dimensionIds);
		SdmxBeans beans = TestDSDInstances.generateReferences(dsd, true);

		ProvisionAgreementBean prov = TestDataProvisionUtil.generateProvision(flowRef.getAgencyId(), providerId, 
				new StructureReferenceBeanImpl(flowRef.getAgencyId(), flowRef.getMaintainableId(), flowRef.getVersion().toString(), SDMX_STRUCTURE_TYPE.DATAFLOW));
		
		DataProviderSchemeBean dps = TestDataProviderSchemeUtil.generateDataProviderScheme(prov.getDataproviderRef().getReference().getAgencyId(), prov.getDataproviderRef().getReference().getIdentifiableId());
		beans.addIdentifiable(dps);
		
		beans.addIdentifiable(TestDataflowUtil.generateDataflow(dsd.asReference()));
		beans.addIdentifiable(prov);
		return beans;
	}
	
}
