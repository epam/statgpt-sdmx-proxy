package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.im.util.model.TestCategorySchemeUtil;

public class TestCategorySchemeInstances {

	
	public static CategorySchemeBean generateFlatScheme() {
		return TestCategorySchemeUtil.generateCategoryScheme("ECB", "FLAT_CS", "1.0.1", "INTEREST_RATES", "EXCHANGE_RATES");
	}


	public static CategorySchemeBean generateHierarchicalScheme() {
		return TestCategorySchemeUtil.generateCategoryScheme("SDMX", "STAT_SUBJECT_MATTER", "1.0.1", 
				"DEMO_SOCIAL_STAT Demographic and social statistics", 
				"DEMO_SOCIAL_STAT.LABOUR Labour",
				"DEMO_SOCIAL_STAT.HEALTH Health",
				"DEMO_SOCIAL_STAT.INCOME_CONSUMP Income and consumption",
				"ECO_STAT Economic statistics",
				"MACROECO_STAT Macroeconomic statistics",
				"ECO_STAT.ECO_ACCOUNTS Economic accounts",
				"ECO_STAT.SECTORAL_STAT Sectoral statistics",
				"ECO_STAT.SECTORAL_STAT.AGRI_FOREST_FISH Agriculture, forestry, fisheries",
				"ECO_STAT.SECTORAL_STAT.ENERGY Energy");
	}


}
