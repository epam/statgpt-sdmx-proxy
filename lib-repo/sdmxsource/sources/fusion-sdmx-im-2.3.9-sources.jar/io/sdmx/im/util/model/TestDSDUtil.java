package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.MeasureSuperBean;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.im.superbeans.base.AttributeSuperBeanImpl;
import io.sdmx.im.superbeans.conceptscheme.ConceptSchemeSuperBeanImpl;
import io.sdmx.im.superbeans.datastructure.DataStructureSuperBeanImpl;
import io.sdmx.im.superbeans.datastructure.DimensionSuperBeanImpl;
import io.sdmx.im.superbeans.datastructure.MeasureSuperBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Used to create test Data Structures
 */
public class TestDSDUtil {

	public static DataStructureBean generateDSD(boolean time, boolean pm, String...dimensionIds) {
		return generateDSD(CollectionUtil.toList(dimensionIds), null, time, pm, null, null, null, null, null);
	}

	/**
	 * Generates a time series DSD (Time Dimension included by default) with a primary measure (OBS_VALUE)
	 * @param id
	 * @param dimensionIds
	 * @return
	 */
	public static DataStructureBean generateDSD(String id, String...dimensionIds) {
		return generateDSD(CollectionUtil.toList(dimensionIds), null, true, true, null, null, null, id, null);
	}

	public static DataStructureBean generateDSD(IMaintainableProperties mRef, boolean time, boolean pm, String...dimensionIds) {
		DataStructureBean dsd = generateDSD(CollectionUtil.toList(dimensionIds), null, time, pm, null, null, null, null, null);
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		TestMaintainableUtil.setMaintainableProperties(dsdMutable, mRef);
		return dsdMutable.getImmutableInstance();
	}
	
	
	public static DataStructureBean addDimension(DataStructureBean dsd, String conceptId, String clAcy, String clId, String clVersion, boolean isCodelist) {
		SDMX_STRUCTURE_TYPE st = isCodelist ? SDMX_STRUCTURE_TYPE.CODE_LIST : SDMX_STRUCTURE_TYPE.VALUE_LIST;
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		StructureReferenceBean clRef = new StructureReferenceBeanImpl(clAcy, clId, clVersion, st);
		dsdMutable.addDimension(createConceptReference(conceptId), clRef);
		return dsdMutable.getImmutableInstance();
	}
	
	public static DataStructureSuperBean generateDSDS(List<String> dimensions,
			   List<String>  seriesAttributes,
			   boolean time,
			   boolean pm,
			   List<String> obsAttributes,
			   List<String> additionalMeasures,
			   Map<String, EnumeratedListBean> representations,
			   String agency, String id, String version) {
		return generateDSDSb(dimensions, null, seriesAttributes, time, pm, obsAttributes, additionalMeasures, representations, agency, id, version);
	}
	
	public static DataStructureSuperBean generateDSDSb(List<String> dimensions,
			   List<String> dsAttributes,
			   List<String> seriesAttributes,
			   boolean time,
			   boolean pm,
			   List<String> obsAttributes,
			   List<String> additionalMeasures,
			   Map<String, EnumeratedListBean> representations,
			   String agency, String id, String version) {
		ConceptSchemeSuperBean csSb = generateConceptScheme(dimensions, dsAttributes, seriesAttributes, time, pm, obsAttributes, additionalMeasures, agency, id, version);
		DataStructureBean dsd = generateDSD(dimensions, dsAttributes, seriesAttributes, time, pm, obsAttributes, additionalMeasures, agency, id, SdmxVersion.getInstance(version));
		List<DimensionSuperBean> dimensionSuperBeans = new ArrayList<>();
		List<AttributeSuperBean> attributes = new ArrayList<>();
		List<MeasureSuperBean> measures = new ArrayList<>();
		for(DimensionBean dim : dsd.getDimensionList().getDimensions()) {
			DimensionSuperBean dSb = new DimensionSuperBeanImpl(dim, representations.get(dim.getId()), csSb.getItemById(dim.getId()));
			dimensionSuperBeans.add(dSb);
		}
		for(AttributeBean attr : dsd.getAttributes()) {
			attributes.add(new AttributeSuperBeanImpl(attr, representations.get(attr.getId()), csSb.getItemById(attr.getId())));
		}
		for(MeasureDimensionBean meas : dsd.getMeasures()) {
			measures.add(new MeasureSuperBeanImpl(meas, representations.get(meas.getId()), csSb.getItemById(meas.getId())));
		}
		return new DataStructureSuperBeanImpl(dsd, dimensionSuperBeans, attributes, measures);
	}
	
	public static ConceptSchemeSuperBean generateConceptScheme(List<String> dimensions, List<String> dsAttributes, List<String> seriesAttributes, boolean time, boolean pm, List<String> obsAttributes, List<String> additionalMeasures, String agency, String id, String version) {
		List<String> allComponents = new ArrayList<>();
		if(dimensions != null) {
			allComponents.addAll(dimensions);
		}
		if(dsAttributes != null) {
			allComponents.addAll(dsAttributes);
		}
		if(seriesAttributes != null) {
			allComponents.addAll(seriesAttributes);
		}
		if(obsAttributes != null) {
			allComponents.addAll(obsAttributes);
		}
		if(additionalMeasures != null) {
			allComponents.addAll(additionalMeasures);
		}
		if(time) {
			allComponents.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
		if(pm) {
			allComponents.add(PrimaryMeasureBean.FIXED_ID);
		}
		String[] conceptIds = CollectionUtil.toArray(allComponents);
		ConceptSchemeBean cs = TestConceptUtil.generateConceptSchemeWithProps(agency, id, version, "-name", conceptIds);
		return new ConceptSchemeSuperBeanImpl(cs, Collections.emptyMap());
	}
	
	public static DataStructureBean generateDSD(List<String> dimensions, List<String>  seriesAttributes, boolean time, boolean pm, List<String> obsAttributes, List<String> additionalMeasures, IMaintainableProperties dsdRef) {
		return generateDSD(dimensions, null, seriesAttributes, time, pm, obsAttributes, additionalMeasures, dsdRef.getAgencyId(), dsdRef.getId(), dsdRef.getVersion());
		
	}
	
	public static DataStructureBean generateDSD(List<String> dimensions, List<String> seriesAttributes, boolean time, boolean pm, List<String> obsAttributes, List<String> additionalMeasures, String agency, String id, ISdmxVersion version) {
		return generateDSD(dimensions, null, seriesAttributes, time, pm, obsAttributes, additionalMeasures, agency, id, version);
	}
	
	public static DataStructureBean generateDSD(List<String> dimensions, List<String> dsAttributes, List<String> seriesAttributes, boolean time, boolean pm, List<String> obsAttributes, List<String> additionalMeasures, String agency, String id, ISdmxVersion version) {
		DataStructureMutableBean dsdMutable = new DataStructureMutableBeanImpl();
		dsdMutable.setAgencyId(agency == null ? "TEST" : agency);
		dsdMutable.setId(id == null ? "TEST" : id);
		dsdMutable.setVersion(version == null ? SdmxVersion.DEFAULT : version);
		dsdMutable.addName("en", "TEST");
		if(dimensions != null) {
			for(String dimId : dimensions) {
				dsdMutable.addDimension(createDimension((dimId)));
			}
		}
		if(dsAttributes != null) {
			for(String attrId : dsAttributes) {
				createAttribute(dsdMutable, attrId, ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
			}
		}
		if(seriesAttributes != null) {
			for(String attrId : seriesAttributes) {
				createAttribute(dsdMutable, attrId, ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
			}
		}
		if(obsAttributes != null) {
			for(String attrId : obsAttributes) {
				createAttribute(dsdMutable, attrId, ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
			}
		}
		if(additionalMeasures != null) {
			for(String measureId : additionalMeasures) {
				dsdMutable.addMeasure(createMeasure(measureId));
			}
		}
		if(pm) {
			dsdMutable.setPrimaryMeasure(new PrimaryMeasureMutableBeanImpl());
			dsdMutable.getPrimaryMeasure().setConceptRef(createConceptReference("OBS_VALUE"));
		}
		if(time) {
			DimensionMutableBean dim = new DimensionMutableBeanImpl();
			dim.setId("TIME_PERIOD");
			dim.setTimeDimension(true);
			dim.setConceptRef(createConceptReference("T"));
			dsdMutable.addDimension(dim);
		}
		DataStructureBean dsd = dsdMutable.getImmutableInstance();

		return dsd;
	}

	private static DimensionMutableBean createDimension(String id) {
		DimensionMutableBean dim = new DimensionMutableBeanImpl();
		setComponentRepresentation(id, dim);
		dim.setConceptRef(createConceptReference(id));
		return dim;
	}
	
	private static void setComponentRepresentation(String id, ComponentMutableBean comp) {
		String[] idSplit = id.split(":");
		comp.setId(idSplit[0]);
		if(idSplit.length > 1) {
			if(idSplit[1].equals("CL")) {  //Codelist
				comp.setEnumeration(new StructureReferenceBeanImpl("ACY", "CL_"+idSplit[0], "1.0", SDMX_STRUCTURE_TYPE.CODE_LIST));
			} else if(idSplit[1].equals("VL")) {  //Valuelist
				comp.setEnumeration(new StructureReferenceBeanImpl("ACY", "VL_"+idSplit[0], "1.0", SDMX_STRUCTURE_TYPE.VALUE_LIST));
			}  else  {
				comp.setTextType(TEXT_TYPE.valueOf(idSplit[1]));
			}
		}
	}
	
	public static DataStructureBean createAttribute(DataStructureBean dsd, String id, ATTRIBUTE_ATTACHMENT_LEVEL attach) {
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		createAttribute(dsdMutable, id, attach);
		return dsdMutable.getImmutableInstance();
	}
	
	/**
	 * @param dsd
	 * @param id
	 * @param attachments Dimension Ids and/or Measure ids
	 * @return
	 */
	public static DataStructureBean createAttribute(DataStructureBean dsd, String id, String... attachments) {
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		AttributeMutableBean attr = createAttribute(dsdMutable, id, null);
		for(String attach : attachments) {
			if(dsd.getDimension(attach)!= null) {
				attr.addDimensionReferences(attach);
				if(attr.getAttachmentLevel() == null) {
					attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
				}
			} else if(dsd.getMeasure(attach)!= null) {
				attr.addMeasureReference(attach);
				attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
			}
		}
		return dsdMutable.getImmutableInstance();
	}

	public static AttributeMutableBean createAttribute(DataStructureMutableBean dsdMutable, String id, ATTRIBUTE_ATTACHMENT_LEVEL attach) {
		AttributeMutableBean attr = new AttributeMutableBeanImpl();
		attr.setAttachmentLevel(attach);
		if(attach == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
			for(DimensionMutableBean dim : dsdMutable.getDimensions()) {
				if(!dim.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
					attr.addDimensionReferences(dim.getId());
				}
			}
		} else if(attach == ATTRIBUTE_ATTACHMENT_LEVEL.GROUP && ObjectUtil.validCollection(dsdMutable.getGroups())) {
			attr.setAttachmentGroup(dsdMutable.getGroups().get(0).getId());
		}
		setComponentRepresentation(id, attr);
		attr.setConceptRef(createConceptReference(id));
		attr.setMandatory(false);
		dsdMutable.addAttribute(attr);
		return attr;
	}
	
	public static DataStructureBean createGroup(DataStructureBean dsd, String id, String...dimensionAndAttributeIds) {
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		GroupMutableBean group = new GroupMutableBeanImpl();
		group.setId(id);
		for(String dimId : dimensionAndAttributeIds) {
			if(dsd.getDimension(dimId) != null) {
				group.addDimensionRef(dimId);
			} else {
				createAttribute(dsdMutable, dimId, ATTRIBUTE_ATTACHMENT_LEVEL.GROUP).setAttachmentGroup(id);
			}
		}
		dsdMutable.addGroup(group);
		return dsdMutable.getImmutableInstance();
	}
	
	public static GroupMutableBean createGroup(DataStructureMutableBean dsdMutable, String id, String...dimensions) {
		GroupMutableBean group = new GroupMutableBeanImpl();
		group.setId(id);
		for(String dimId : dimensions) {
			group.addDimensionRef(dimId);
		}
		dsdMutable.addGroup(group);
		return group;
	}
	
	public static DataStructureBean createMeasure(DataStructureBean dsd, String id) {
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		dsdMutable.addMeasure(createMeasure(id));
		return dsdMutable.getImmutableInstance();
	}
	
	public static MeasureMutableBean createMeasure(String id) {
		MeasureMutableBean measure = new MeasureMutableBeanImpl();
		measure.setId(id);
		measure.setConceptRef(createConceptReference(id));
		return measure;
	}

	public static MeasureMutableBean createMeasure(DataStructureMutableBean dsdMutable, String id) {
		MeasureMutableBean measure = createMeasure(id);
		dsdMutable.addMeasure(measure);
		return measure;
	}

	public static StructureReferenceBean createConceptReference(String id) {
		String[] idSplit = id.split(":");
		id = idSplit[0];
		return new StructureReferenceBeanImpl("TEST", "CS", "1.0", SDMX_STRUCTURE_TYPE.CONCEPT, id);
	}

}
