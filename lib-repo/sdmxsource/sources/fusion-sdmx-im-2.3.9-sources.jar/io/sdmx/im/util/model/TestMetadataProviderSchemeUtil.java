package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.im.mutable.base.MetadataProviderSchemeMutableBean;

public class TestMetadataProviderSchemeUtil {

	public static IMetadataProviderSchemeBean generateMetadataProviderScheme(String agencyId, String...providerIds) {
		MetadataProviderSchemeMutableBean mutable = new MetadataProviderSchemeMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, IMetadataProviderSchemeBean.FIXED_ID, IMetadataProviderSchemeBean.FIXED_VERSION);
		for(String providerId : providerIds) {
			mutable.createItem(providerId, providerId);
		}
		return mutable.getImmutableInstance();
	}
	
}
