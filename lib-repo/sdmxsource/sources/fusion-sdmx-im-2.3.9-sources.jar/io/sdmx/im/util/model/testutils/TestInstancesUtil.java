package io.sdmx.im.util.model.testutils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.util.model.TestAgencySchemeUtil;
import io.sdmx.im.util.model.TestCodelistUtil;
import io.sdmx.im.util.model.TestConceptUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestInstancesUtil {

	public static SdmxBeans generateReferencedStructures(DataStructureBean dsd) {
		SdmxBeans beans = new SdmxBeansImpl();
		
		
		beans.addIdentifiable(dsd);
		
		//Auto Generate agency, codelist and concept dependencies
		Set<String> agencies = new HashSet<>();

		Map<String, Set<String>> conceptAndCodelistReferences = new HashMap<>(); //map of codelist/concet scheme URN to a set of codes/concept ids
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			agencies.add(maint.getAgencyId());
			for(ICrossReferenceBean<?> xsRef : maint.getCrossReferences()) {
				agencies.add(xsRef.getReference().getAgencyId());
				String maintUrn = xsRef.getReference().getMaintainableURN().getURN();
				
				switch(xsRef.getTargetReference()) {
				case CONCEPT_SCHEME :
				case CODE_LIST :
					if(conceptAndCodelistReferences != null) {
						conceptAndCodelistReferences.put(maintUrn, null);
					}
					break;
				case CONCEPT :
				case CODE :
					CollectionUtil.addToMappedSet(conceptAndCodelistReferences, maintUrn, xsRef.getReference().getIdentifiableId());
					break;
				}
			}
		}
		
		for(String urn : conceptAndCodelistReferences.keySet()) {
			StructureReferenceBean sRef = new StructureReferenceBeanImpl(urn);
			String[] childIds = CollectionUtil.toArray(conceptAndCodelistReferences.get(urn));

			switch(sRef.getTargetReference()) {
			case CONCEPT_SCHEME :
				beans.addIdentifiable(
							TestConceptUtil.generateConceptSchemeWithProps(sRef.getAgencyId(), sRef.getMaintainableId(), sRef.getVersion().toString(), "name", childIds)
						);
				break;
			case CODE_LIST :
				beans.addIdentifiable(
						TestCodelistUtil.generateCodelist(sRef.getAgencyId(), sRef.getMaintainableId(), sRef.getVersion().toString(), childIds)
					);
			break;
			
			}
		}
		AgencySchemeBean acy = TestAgencySchemeUtil.generateAgencyScheme("SDMX", CollectionUtil.toArray(agencies));
		beans.addIdentifiable(acy);
		
		return beans;
	}
}
