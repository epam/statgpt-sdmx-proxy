package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestMetadataflowUtil {

	

	/**
	 * Generates a Metadataflow with the same agency, id, version as the DSD that it references
	 * @param msdRef
	 * @param targets - 1 or more targets
	 * @return
	 */
	public static MetadataFlowBean generateMetaDataflow(String agency, String id, String version, StructureReferenceBean... targets) {
		MetadataFlowMutableBean mutable = new MetadataflowMutableBeanImpl();
		StructureReferenceBean msdRef = new StructureReferenceBeanImpl(agency, id, version, SDMX_STRUCTURE_TYPE.MSD);
		mutable.setMetadataStructureRef(msdRef);
		if(targets != null) {
			for(StructureReferenceBean target : targets) {
				mutable.addTarget(target);
			}
		}
		TestMaintainableUtil.setMaintainableProperties(mutable, MaintainableProperties.getInstance(agency, id, version));
		return mutable.getImmutableInstance();
	}
	
}
