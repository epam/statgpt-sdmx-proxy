package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.im.util.model.TestAgencySchemeUtil;
import io.sdmx.im.util.model.TestDataProviderSchemeUtil;
import io.sdmx.utils.core.collection.CollectionUtil;

public class TestDataProviderSchemeInstances {
	/**
	 * Builds a SDMX scheme with the sponsor organisations present, no contact details or descriptions)
	 * @return
	 */
	public static DataProviderSchemeBean getDPScheme() {
		DataProviderSchemeBean acy = TestDataProviderSchemeUtil.generateDataProviderScheme("SDMX", "BIS", "ECB");
		DataProviderSchemeMutableBean mutable = acy.getMutableInstance();
		mutable.getItemById("BIS").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "Bank for International Settlements")));
		mutable.getItemById("ECB").setNames(CollectionUtil.getImmutableList(TextTypeWrapperMutableBeanImpl.getInstance("en", "European Central Bank")));
		return mutable.getImmutableInstance();
	}
	
	
	/**
	 * Builds a sub-agency scheme with department info: HR, IT, STATISTICS, MANAGEMENT
	 * 
	 * Contact details are added
	 * 
	 * @return
	 */
	public static DataProviderSchemeBean getSubScheme(String parentAgency) {
		DataProviderSchemeBean acySch = TestDataProviderSchemeUtil.generateDataProviderScheme(parentAgency, "HR", "IT", "STATISTICS", "MANAGEMENT");
		DataProviderSchemeMutableBean mutable = acySch.getMutableInstance();
		
		ContactMutableBean contact = new ContactMutableBeanImpl();
		contact.addEmail("hr@gmail.com");
		contact.addName(TextTypeWrapperMutableBeanImpl.getInstance("en", "Alexie Plexie"));
		contact.addDepartment(TextTypeWrapperMutableBeanImpl.getInstance("en", "HR"));
		contact.addDepartment(TextTypeWrapperMutableBeanImpl.getInstance("fr", "Le HR"));
		
		contact.addRole(TextTypeWrapperMutableBeanImpl.getInstance("en", "Human Reources"));
		contact.addRole(TextTypeWrapperMutableBeanImpl.getInstance("fr", "Reources Le Human"));
		contact.addFax("+44 123 333444");
		contact.addTelephone("+44 1234 888777");
		contact.addTelephone("01234 412345");
		
		TestAgencySchemeUtil.addContactDetails(mutable, contact, "HR");
		
		mutable.getItemById("IT").addDescription("en", "In the basement");
		return mutable.getImmutableInstance();
	}
	
}
