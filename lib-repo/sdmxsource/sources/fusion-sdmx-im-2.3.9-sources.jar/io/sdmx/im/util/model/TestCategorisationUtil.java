package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;

public class TestCategorisationUtil {

	public static CategorisationBean generateCategorisation(String catId, SDMX_STRUCTURE_TYPE toRef, String toId) {
		CategorisationMutableBean mutable = new CategorisationMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, "ACY", catId.replaceAll("\\.", "_")+"2"+toId.replaceAll("\\.", "_"), "1.0.0");
		
		String maintId = toId;
		String[] identId = null;
		if(toId.contains(".")) {
			String[] split = toId.split("\\.");
			maintId = split[0];
			identId = toId.substring(toId.indexOf(".")+1).split("\\.");
		}
		mutable.setStructureReference(TestMaintainableUtil.getRef(toRef, maintId, identId));
		mutable.setCategoryReference(TestMaintainableUtil.getRef(SDMX_STRUCTURE_TYPE.CATEGORY, "CS", catId.split("\\.")));
		return mutable.getImmutableInstance();
	}
}
