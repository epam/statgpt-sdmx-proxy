package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestHCLUtil {

	/**
	 * If maintainable properties and codelist reference deos not matter
	 * @param codes code ids, create a hierarchy by using the dot separator, i.e. EUR, EUR.FR, EUR.DE
	 * @return
	 */
	public static HierarchyBean generateHCL(String...codes) {
		return generateHCL(MaintainableRef.getInstance("ACY", "HCY", "1.0"), MaintainableRef.getInstance("SDMX", "CL_REF", "1.0"), codes);
	}

	/**
	 * If maintainable properties and codelist reference deos not matter
	 * @param codes code ids, create a hierarchy by using the dot separator, i.e. EUR, EUR.FR, EUR.DE
	 * @return
	 */
	public static HierarchyBean addLevels(HierarchyBean h1, boolean formalLevels, String...levelNames) {
		HierarchyMutableBean h1Mut = h1.getMutableInstance();
		LevelMutableBean level = null;
		int i = 0;
		for(String levelName : levelNames) {
			i++;
			LevelMutableBean currentLevel = new LevelMutableBeanImpl();
			currentLevel.setId("L"+i);
			currentLevel.addName("en", levelName);
			if(level == null) {
				level = currentLevel;
				h1Mut.setChildLevel(level);
			} else {
				level.setChildLevel(currentLevel);
				level = currentLevel;
			}
		}
		h1Mut.setFormalLevels(formalLevels);
		return h1Mut.getImmutableInstance();
	}
	
	
	public static HierarchyBean addStartEndPeiord(HierarchyBean hierarchy, SdmxPeriod[] periods, String... codeRefs) {
		if(periods.length != codeRefs.length) {
			throw new IllegalArgumentException("period array size must match code refs array size");
		}
		HierarchyMutableBean mutable = hierarchy.getMutableInstance();
		
		Map<String, CodeRefMutableBean> codeRefMap = new HashMap<>();
		
		populateHCodeMap(mutable.getHierarchicalCodeBeans(), codeRefMap, null);

		int i=0;
		for(String codeRef : codeRefs) {
			CodeRefMutableBean refBean = codeRefMap.get(codeRef);
			if(refBean == null) {
				throw new IllegalArgumentException("Hierarchical Code not found: " +codeRef);
			}
			SdmxPeriod period = periods[i];
			if(period.hasStartPeriod()) {
				refBean.setStartDate(period.getStartPeriod().getDate());
			}
			if(period.hasEndPeriod()) {
				refBean.setEndDate(period.getEndPeriod().getDate());
			}
			i++;
		}
		
		return mutable.getImmutableInstance();		
	}	
	
	private static void populateHCodeMap(List<CodeRefMutableBean> codeRefs, Map<String, CodeRefMutableBean> map, String parentId) {
		if(codeRefs == null) {
			return;
		}
		for(CodeRefMutableBean currentRef : codeRefs) {
			String qualifiedId = parentId == null ? currentRef.getId() : parentId + "."+currentRef.getId();
			map.put(qualifiedId, currentRef);
			populateHCodeMap(currentRef.getCodeRefs(), map, qualifiedId);
		}
	}

	public static HierarchyBean generateHCL(IMaintainableRef identifiers, 
			IMaintainableRef codelistRefs,
			String...codes) {
		List<IMaintainableRef> clRefs = new ArrayList<>();
		clRefs.add(codelistRefs);
		return generateHCL(identifiers, clRefs, codes);
	}

	/**
	 * 
	 * @param identifiers
	 * @param codelistRefs - codelists that are referenced, they are given the alias CL1, CL2, CL[x]
	 * @param codes in a hierarchy using dot separator, the colon separator is to reference the code id from the codelist alias,
	 * if there is only one codelist reference and there is no colon separator, the code being referenced is assumed to be the same ID
	 * as the hierarchical code id
	 * e.g. A, A.B1, CL1=A.B2:B, A.B1.C1, A.B2, 
	 * 
	 * The codes must be in order of hierarchy, i.e. do not do A.B followed by A
	 * @return
	 */
	public static HierarchyBean generateHCL(IMaintainableRef identifiers, 
			List<IMaintainableRef> codelistRefs,
			String...codes) {
	
		HierarchyMutableBean hierarchy = new HierarchyMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(hierarchy, MaintainableProperties.getInstance(identifiers));

		int i=0;
		Map<String, StructureReferenceBean> clRefMap = new HashMap<>();
		for(IMaintainableRef clMRef : codelistRefs) {
			i++;
			StructureReferenceBean sRef = new StructureReferenceBeanImpl(clMRef, SDMX_STRUCTURE_TYPE.CODE_LIST);
			String alias = "CL"+i;
			clRefMap.put(alias, sRef);
		}
		if(hierarchy.getId() == null) {
			hierarchy.setId("H1");
		}
		if(!ObjectUtil.validCollection(hierarchy.getNames())) {
			hierarchy.addName("en", "H1");
		}
		Map<String, CodeRefMutableBean>  codeRefMap = new HashMap<>();
		for(String code : codes) {
			CodeRefMutableBean codeRef = new CodeRefMutableBeanImpl();
			String[] splitEquals = code.split("=");
			String hCodeIdFull = splitEquals.length == 1 ? splitEquals[0] : splitEquals[1];
			String[] hCodeIdSplit = hCodeIdFull.split(":");

			String hCodeId = hCodeIdSplit[0];
			hCodeId = hCodeId.contains(".") ? hCodeId.substring(hCodeId.lastIndexOf(".")+1) : hCodeId;
			String codeId = hCodeIdSplit.length > 1 ? hCodeIdSplit[1]  : hCodeId;
			String codelistRef = splitEquals.length == 1  ?  "CL1" : code.split("=")[0];
			StructureReferenceBean clRef = clRefMap.get(codelistRef);
			codeRef.setCodeReference(new StructureReferenceBeanImpl(clRef.getMaintainableReference(), SDMX_STRUCTURE_TYPE.CODE, codeId));
			codeRef.setId(hCodeId);
			
			if(!code.contains(".")) {
				hierarchy.addHierarchicalCodeBean(codeRef);
			} else {
				String parentId = code.substring(0, code.lastIndexOf("."));
				CodeRefMutableBean parent = codeRefMap.get(parentId);
				if(parent == null) {
					throw new IllegalArgumentException("Parent code not found: "+parentId);
				}
				parent.addCodeRef(codeRef);
			}
			codeRefMap.put(code, codeRef);
			
		}
		return hierarchy.getImmutableInstance();
	}
}
