package io.sdmx.im.util.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.im.mutable.process.ComputationMutableBeanImpl;
import io.sdmx.im.mutable.process.InputOutputMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessStepMutableBeanImpl;
import io.sdmx.im.mutable.process.TransitionMutableBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;

public class TestProcessUtil {

	/**
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param processSteps Ids, hierarchy using period "P1", "P1.P2", "P1.P2.P3", name using space separator "P1 process 1", "P2 process 2"
	 * @return
	 */
	public static ProcessBean getProcess(String agencyId, String id, String version, String... processSteps) {
		ProcessMutableBean mutable = new ProcessMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, id, version);
		
		Map<String, ProcessStepMutableBean> idToStep = new HashMap<>();
		Map<String, List<ProcessStepMutableBean>> parentIdToSteps = new HashMap<>();
		if(processSteps != null) {
			for(String processStep : processSteps) {
				String[] split = processStep.split(" ", 2);
				String fullId = split[0];
				String processId = split[0];
				String processName = split.length > 1 ? split[1] : processId;
				String parentId = null;
				if(processId.contains(".")) {
					parentId = processId.substring(0, processId.lastIndexOf("."));
					processId = processId.substring(processId.lastIndexOf(".")+1);
				}
				ProcessStepMutableBean process = new ProcessStepMutableBeanImpl();
				process.setId(processId);
				process.addName("en", processName);
				if(parentId == null) {
					mutable.addProcessStep(process);
				} else {
					CollectionUtil.addToMappedList(parentIdToSteps, parentId, process);
				}
				idToStep.put(fullId, process);
			}
		}
		for(String parentId : parentIdToSteps.keySet()) {
			idToStep.get(parentId).setProcessSteps(parentIdToSteps.get(parentId));
		}
		return mutable.getImmutableInstance();
	}
	
	public static ProcessBean addInputOutput(ProcessBean process, String processId, String localId, StructureReferenceBean ref, boolean isInput) {
		ProcessMutableBean mutable = process.getMutableInstance();
		ProcessStepMutableBean step = getProcessStep(mutable, processId);
		
		InputOutputMutableBean io = new InputOutputMutableBeanImpl();
		io.setLocalId(localId);
		io.setStructureReference(ref);
		
		if(isInput) {
			step.addInput(io);
		} else {
			step.addOutput(io);
		}
		
		return mutable.getImmutableInstance();
	}
	
	/**
	 * @param process
	 * @param processId
	 * @param localId
	 * @param softwarePackage
	 * @param softwareLanguage
	 * @param softwareVersion
	 * @param description  label, default to en, to add a locale prefix with locale:description, e.g. en:My Description
	 * @return
	 */
	public static ProcessBean addComputation(ProcessBean process, String processId, String localId, String softwarePackage, String softwareLanguage,  String softwareVersion, String...description) {
		ProcessMutableBean mutable = process.getMutableInstance();
		ProcessStepMutableBean step = getProcessStep(mutable, processId);
		
		ComputationMutableBean comp = new ComputationMutableBeanImpl();
		comp.setLocalId(localId);
		comp.setSoftwarePackage(softwarePackage);
		comp.setSoftwareLanguage(softwareLanguage);
		comp.setSoftwareVersion(softwareVersion);
		if(description != null) {
			for(String currentDesc : description) {
				String[] split = currentDesc.split(":", 2);
				String locale = split.length > 1 ? split [0] : "en";
				String desc = split.length > 1 ? split[1] : split[0];
				comp.addDescriptions(TextTypeWrapperMutableBeanImpl.getInstance(locale, desc));
				
			}
		}
		step.setComputation(comp);
		return mutable.getImmutableInstance();
	}
	
	public static ProcessBean addTransition(ProcessBean process, String processId, String localId, String id, String targetStep, String...condition) {
		ProcessMutableBean mutable = process.getMutableInstance();
		ProcessStepMutableBean step = getProcessStep(mutable, processId);
		
		TransitionMutableBean transition = new TransitionMutableBeanImpl();
		transition.setId(id);
		transition.setLocalId(localId);
		transition.setTargetStep(targetStep);
		
		if(condition != null) {
			for(String currentDesc : condition) {
				String[] split = currentDesc.split(":", 2);
				String locale = split.length > 1 ? split [0] : "en";
				String desc = split.length > 1 ? split[1] : split[0];
				transition.addCondition(TextTypeWrapperMutableBeanImpl.getInstance(locale, desc));
			}
		}

		step.addTransition(transition);
		return mutable.getImmutableInstance();
	}
	
	public static ProcessStepMutableBean getProcessStep(ProcessMutableBean process, String processId) {
		String[] split = processId.split("\\.");
		return getProcessStep(process.getProcessSteps(), split, 0);
	}
	
	private static ProcessStepMutableBean getProcessStep(List<ProcessStepMutableBean> processes, String[] processId, int depth) {
		
		String procId = processId[depth];
		int nextDepth = depth + 1;
		for(ProcessStepMutableBean step : processes) {
			if(step.getId().equals(procId)) {
				if(nextDepth < processId.length) {
					return getProcessStep(step.getProcessSteps(), processId, nextDepth);
				} 
				return step;
			}
		}
		throw new IllegalArgumentException("Process Step not found: "+procId);
	}
}
