package io.sdmx.im.util.model;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IConceptSchemeMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ConceptMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ConceptSchemeMapMutableBean;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestConceptSchemeMapUtil {

	public static IConceptSchemeMapMutableBean generateSchemeMap(
			String agency, String id, String version,
			IMaintainableRef source,
			IMaintainableRef target,
			Map<String, String> source2target) {

		IConceptSchemeMapMutableBean mutableMap = new ConceptSchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		mutableMap.setSourceRef(new StructureReferenceBeanImpl(source, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME));
		mutableMap.setTargetRef(new StructureReferenceBeanImpl(target, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME));
		SdmxPeriod validity = new SdmxPeriodImpl("1959", "2029");

		for (String sourceId : source2target.keySet()) {
			addConceptMap(mutableMap, sourceId, source2target.get(sourceId), validity, 100, 200, false);
		}
		return mutableMap;
	}

	public static IConceptSchemeMapMutableBean generateSchemeMapFromBeans(
			String agency, String id, String version,
			ConceptSchemeBean source,
			ConceptSchemeBean target,
			IConceptMapMutableBean... conceptMaps) {

		IConceptSchemeMapMutableBean mutableMap = new ConceptSchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		addSchemes(mutableMap, source, target);

		for (IConceptMapMutableBean conceptMap : conceptMaps) {
			mutableMap.addItem(conceptMap);
		}
		return mutableMap;
	}

	public static void addConceptMap(
			IConceptSchemeMapMutableBean mutableMap,
			String sourceId,
			String targetId,
			SdmxPeriod validity,
			Integer startIdx,
			Integer endIdx,
			boolean isRegEx) {

		String startPeriod = ValidityPeriodUtil.getStartPeriod(validity);
		String endPeriod = ValidityPeriodUtil.getEndPeriod(validity);

		IConceptMapMutableBean conceptMap = new ConceptMapMutableBean()
				.setSourceId(sourceId)
				.setTargetId(targetId)
				.setSourceStartIdx(startIdx)
				.setSourceEndIdx(endIdx)
				.setValidFrom(startPeriod)
				.setValidTo(endPeriod)
				.setSourceRegEx(isRegEx);

		mutableMap.addItem(conceptMap);
	}

	public static void addSchemes(
			IConceptSchemeMapMutableBean mutableConceptSchemeMap,
			ConceptSchemeBean sourceConceptScheme,
			ConceptSchemeBean targetConceptScheme) {

		mutableConceptSchemeMap.setSourceRef(sourceConceptScheme.asReference());
		mutableConceptSchemeMap.setTargetRef(targetConceptScheme.asReference());
	}
}
