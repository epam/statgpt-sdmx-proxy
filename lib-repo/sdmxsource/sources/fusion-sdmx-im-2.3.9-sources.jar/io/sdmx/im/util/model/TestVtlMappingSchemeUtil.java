package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.mutable.transformation.IVtlDataflowMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.im.mutable.transformation.VtlMappingSchemeMutableBean;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

public class TestVtlMappingSchemeUtil {

	public static IVtlMappingSchemeMutableBean create(String agencyId, String id, String version) {
		IVtlMappingSchemeMutableBean mutable = new VtlMappingSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.addName("en", id+ " Name");
		return mutable;
	}
	
	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static IVtlMappingSchemeMutableBean createComplete(String agencyId, String id, String version) {
		IVtlMappingSchemeMutableBean mutable = TestVtlMappingSchemeUtil.create(agencyId, id, version);
		
		mutable.addCodelistMapping("CLM1", "alias1", MaintainableRef.getInstance("ACY1", "CL1", "1.0")).addName("en", "N1");
		mutable.addCodelistMapping("CLM2", "alias2", MaintainableRef.getInstance("ACY1", "CL2", "1.0")).addName("en", "N1");
		
		mutable.addConceptMapping("CM1", "alias5", MaintainableRef.getInstance("ACY1", "CS1", "1.0"), "C1").addName("en", "N1");
		mutable.addConceptMapping("CM2", "alias6", MaintainableRef.getInstance("ACY1", "CS2", "1.0"), "C2").addName("en", "N1");
		
		IVtlDataflowMappingMutableBean df1 = mutable.addDataflowMapping("DFM1", "alias7", MaintainableRef.getInstance("ACY1", "DF1", "1.0"));
		df1.addName("en", "N1");
		df1.setFromMethod("FromMethod");
		df1.setToMethod("ToMethod");
		df1.setFromSubSpace(CollectionUtil.toList("D1", "D2", "D3"));
		df1.setToSubSpace(CollectionUtil.toList("D1x", "D2x", "D3x"));
		
		mutable.addDataflowMapping("DF2", "alias8",  MaintainableRef.getInstance("ACY1", "DF2", "1.0")).addName("en", "N2");
		return mutable;
	}
	
}
