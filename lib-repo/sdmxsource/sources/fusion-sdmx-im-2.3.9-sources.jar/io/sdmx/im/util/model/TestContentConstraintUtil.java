package io.sdmx.im.util.model;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestContentConstraintUtil {

	
	public static ContentConstraintMutableBean create(String agencyId, String id, String version, IURNSingle<?> attachment) {
		return create(agencyId, id, version, false, attachment);
	}
	
	public static ContentConstraintMutableBean create(String agencyId, String id, String version, boolean isDefiningActualData, IURNSingle<?>... attach) {
		ContentConstraintMutableBean mutable = new ContentConstraintMutableBeanImpl();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.addName("en", id+ " Name");
		mutable.setIsDefiningActualDataPresent(isDefiningActualData);
		if(attach != null) {
			ConstraintAttachmentMutableBean cAttach = new ContentConstraintAttachmentMutableBeanImpl();
			for(IURNSingle<?> currentAttach : attach) {
				cAttach.addStructureReference(new StructureReferenceBeanImpl(currentAttach));
			}
			mutable.setConstraintAttachment(cAttach);
		}
		return mutable;
	}

	public static ContentConstraintMutableBean create(String agencyId, String id, String version) {
		ContentConstraintMutableBean mutable = new ContentConstraintMutableBeanImpl();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.addName("en", id+ " Name");
		return mutable;
	}


	/**
	 * Creates a maintainable which has ....
	 * @param agencyId
	 * @param id
	 * @param version
	 * @return
	 */
	public static ContentConstraintMutableBean createComplete(String agencyId, String id, String version) {
		ContentConstraintMutableBean mutable = TestContentConstraintUtil.create(agencyId, id, version);

		//        mutable.addRuleSet("RS1", "rd1", "rt1", "rs1").addName("en", "R1");
		//        mutable.addRuleSet("RS2", "rd2", "rt2", "rs2").addName("en", "R2");
		//        mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl("SDMX", "VMS", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
		return mutable;
	}
	
	public static ContentConstraintBean addCubeRegion(ContentConstraintBean bean, boolean includeMode, Map<String, List<String>> data) {
		ContentConstraintMutableBean mutable = bean.getMutableInstance();
		addCubeRegion(mutable, includeMode, data);
		return mutable.getImmutableInstance();
	}

	public static CubeRegionMutableBean addCubeRegion(ContentConstraintMutableBean mutable, boolean includeMode, Map<String, List<String>> data) {
		CubeRegionMutableBean cubeRegion;
		if (includeMode) {
			cubeRegion = mutable.getIncludedCubeRegion();
			if (cubeRegion == null) {
				cubeRegion = new CubeRegionMutableBeanImpl();
				mutable.setIncludedCubeRegion(cubeRegion);
			}
		} else {
			cubeRegion = mutable.getExcludedCubeRegion();
			if (cubeRegion == null) {
				cubeRegion = new CubeRegionMutableBeanImpl();
				mutable.setExcludedCubeRegion(cubeRegion);
			}
		}

		for (String key : data.keySet()) {
			KeyValuesMutable keyValues = new KeyValuesMutableImpl();
			keyValues.setId(key);
			keyValues.setKeyValues(data.get(key));
			cubeRegion.addKeyValues(keyValues);
		}
		return cubeRegion;
	}

	public static ContentConstraintBean addKeyset(ContentConstraintBean bean, boolean includeMode,  String...constrainedKeys) {
		ContentConstraintMutableBean mutable = bean.getMutableInstance();
		addKeyset(mutable, includeMode, constrainedKeys);
		return mutable.getImmutableInstance();
	}

	
	/**
	 * If the dimension ID is prefixed with % then the remove prefix boolean will be set to true
	 * @param mutable
	 * @param includeMode
	 * @param constrainedKeys syntax for each String "FREQ:A,REF_AREA:UK,INDICATOR:ABC;ATTRID"
	 */
	public static ConstraintDataKeySetMutableBean addKeyset(ContentConstraintMutableBean mutable, boolean includeMode, String...constrainedKeys) {
		ConstraintDataKeySetMutableBean keyset = new ConstraintDataKeySetMutableBeanImpl();
		
		for(String currentKey : constrainedKeys) {
			ConstrainedDataKeyMutableBean cds = new ConstrainedDataKeyMutableBeanImpl();
			keyset.addConstrainedDataKey(cds);
			String[] dimAndAtt = currentKey.split(";");
			
			for(String currentKv : dimAndAtt[0].split(",")) {
				cds.addKeyValue(getConstrainedKeyValue(currentKv));
			}
			if(dimAndAtt.length > 1) {
				for(String currentKv : dimAndAtt[1].split(",")) {
					cds.addComponentValues(getConstrainedKeyValue(currentKv));
				}
			}
		}
		if (includeMode) {
			mutable.setIncludedSeriesKeys(keyset);
		} else {
			mutable.setExcludedSeriesKeys(keyset);
		}
		return keyset;
	}
	
	/**
	 * Syntax [%][DIMID]:[CODEID] example 
	 * %FREQ:A 	(remove prefix=true) 
	 * FREQ:A 	(remove prefix=false)
	 * @param currentKv
	 * @return
	 */
	private static ConstrainedKeyValue getConstrainedKeyValue(String currentKv) {
		String[] kv = currentKv.split(":");
		String dimId = kv[0].trim();
		boolean removePrefix = false;
		if(dimId.startsWith("%")) {
			dimId = dimId.substring(1);
			removePrefix = true;
		}
		return ConstrainedKeyValue.getInstance(dimId, removePrefix, kv[1]);
	}
}
