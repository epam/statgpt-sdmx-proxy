package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;

public class TestRegistrationUtil {

	/**
	 * @param pRef provision reference
	 * @param dataUrl
	 * @param isSimple
	 * @return a registration whose Id, Agency, and version are the same as the provision reference
	 */
	public static RegistrationBean generateRegistration(StructureReferenceBean pRef, String dataUrl, boolean isSimple) {
		RegistrationMutableBean mutable = new RegistrationMutableBeanImpl();
		DataSourceMutableBean ds = new DataSourceMutableBeanImpl();
		ds.setDataUrl(dataUrl);
		if(isSimple) {
			ds.setSimpleDatasource(true);
		} else {
			ds.setRESTDatasource(true);
		}
		mutable.setDataSource(ds);
		mutable.setAgencyId(pRef.getAgencyId());
		mutable.setId(pRef.getMaintainableId());
		mutable.setVersion("1.0");
		mutable.addName("en", "Test Registration");
		mutable.setProvisionAgreementRef(pRef);
		return mutable.getImmutableInstance();
	}
	
	public static RegistrationBean changeId(RegistrationBean reg, String newId) {
		RegistrationMutableBean mutable = reg.getMutableInstance();
		mutable.setId(newId);
		reg = mutable.getImmutableInstance();
		return reg;
	}
}
