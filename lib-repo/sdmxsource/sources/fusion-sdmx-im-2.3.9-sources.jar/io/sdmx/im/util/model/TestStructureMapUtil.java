package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Used to generate test StructureMaps for test purposes
 */
public class TestStructureMapUtil {
	public static final IMaintainableProperties SOURCE_DSD_REF = MaintainableProperties.getInstance("SOURCE_ACY", "SOURCE_DSD", "1.0");
	public static final IMaintainableProperties TARGET_DSD_REF = MaintainableProperties.getInstance("TARGET_ACY", "TARGET_DSD", "1.0");
	public static final IMaintainableProperties SOURCE_FLOW_REF = MaintainableProperties.getInstance("SOURCE_ACY", "SOURCE_FLOW", "1.0");
	public static final IMaintainableProperties TARGET_FLOW_REF = MaintainableProperties.getInstance("TARGET_ACY", "TARGET_FLOW", "1.0");

	/**
	 * @param isDSDSource true if the source is a DSD false for a Dataflow
	 * @return
	 */
	public static IStructureMapMutableBean generateMap(boolean isDSDSource) {
		IStructureMapMutableBean mutableMap = new StructureMapMutableBean();
		mutableMap.setAgencyId("ACY");
		mutableMap.setId("ID");
		mutableMap.addName("en", "Test");
		if(isDSDSource) {
			mutableMap.setSourceRef(StructureReferenceBeanImpl.fromProperties(SOURCE_DSD_REF, SDMX_STRUCTURE_TYPE.DSD));
			mutableMap.setTargetRef(StructureReferenceBeanImpl.fromProperties(TARGET_DSD_REF, SDMX_STRUCTURE_TYPE.DSD));
		} else {
			mutableMap.setSourceRef(StructureReferenceBeanImpl.fromProperties(SOURCE_FLOW_REF, SDMX_STRUCTURE_TYPE.DATAFLOW));
			mutableMap.setTargetRef(StructureReferenceBeanImpl.fromProperties(TARGET_FLOW_REF, SDMX_STRUCTURE_TYPE.DATAFLOW));
		}
		return mutableMap;
	}

	/**
	 * Adds a component map
	 */
	public static StructureReferenceBean addComponentMap(IStructureMapMutableBean mutableMap, String source, String target, boolean includeRepMap) {
		return addComponentMap(mutableMap, source, target, includeRepMap, false);
	}
	
	/**
	 * Adds a component map
	 * @param mutableMap
	 * @param source
	 * @param target
	 * @param includeRepMap if true, a link to a representation map will be created
	 * @param isRequired
	 * @return representationMap reference if includeRepMap is true
	 */
	public static StructureReferenceBean addComponentMap(IStructureMapMutableBean mutableMap, String source, String target, boolean includeRepMap, boolean isRequired) {
		IComponentMapMutableBean compMap = mutableMap.addComponentMap();
		compMap.addSourceComponent(source).addTargetComponent(target);
		if(includeRepMap) {
			return addRepresentationMap(compMap);
		}
		return null;
	}

	/**
	 * Adds a component map with more then one source
	 * @param mutableMap
	 * @param target
	 * @param includeRepMap if true, a link to a representation map will be created
	 * @return representationMap reference if includeRepMap is true
	 * @param source array of sources
	 */
	public static StructureReferenceBean addMultiSourceComponentMap(IStructureMapMutableBean mutableMap, String target, boolean includeRepMap, String... source) {
		IComponentMapMutableBean compMap = mutableMap.addComponentMap();
		compMap.addTargetComponent(target);
		for(String currentSource : source) {
			compMap.addSourceComponent(currentSource);
		}
		if(includeRepMap) {
			return addRepresentationMap(compMap);
		}
		return null;
	}
	
	/**
	 * Adds a component map with more then one source
	 * @param mutableMap
	 * @param target
	 * @param includeRepMap if true, a link to a representation map will be created
	 * @return representationMap reference if includeRepMap is true
	 * @param source array of sources
	 */
	public static StructureReferenceBean addMultiTargetComponentMap(IStructureMapMutableBean mutableMap, String source, boolean includeRepMap, String... targets) {
		IComponentMapMutableBean compMap = mutableMap.addComponentMap();
		compMap.addSourceComponent(source);
		for(String currentTarget: targets) {
			compMap.addTargetComponent(currentTarget);
		}
		if(includeRepMap) {
			return addRepresentationMap(compMap);
		}
		return null;
	}

	private static StructureReferenceBean addRepresentationMap(IComponentMapMutableBean compMap) {
		StringBuilder repMapIdSb = new StringBuilder();
		String concat = "";
		for(String source : compMap.getSourceComponents()) {
			repMapIdSb.append(concat + source);
			concat = "_";
		}
		for(String target : compMap.getTargetComponents()) {
			repMapIdSb.append(concat + target);
		}
		String repMapId = repMapIdSb.toString();
		StructureReferenceBean repMaRef = new StructureReferenceBeanImpl("ACY", repMapId, "1.0", SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP);
		compMap.setRepresentationMapRef(repMaRef);
		return repMaRef;
	}

}
