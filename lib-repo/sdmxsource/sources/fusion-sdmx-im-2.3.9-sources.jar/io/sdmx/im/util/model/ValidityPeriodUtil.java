package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidityPeriodBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.validityperiod.ValidityPeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class ValidityPeriodUtil {

	/**
	 * Determines whether the supplied concept has any Annotations which determine if this Scheme needs to
	 * have ValidityPeriods applied to it. If there are, then these Annotations are processed and then removed.
	 * @param aConcept
	 */
	public static void processValidityAnnotations(ValidityPeriodMutableBean bean){
		if(bean instanceof CodelistMutableBean) {
			processValidityAnnotations((CodelistMutableBean)bean);
		} else {
			Set<AnnotationMutableBean> validityAnnotations = ((AnnotableMutableBean) bean).getAnnotationsByType(ValidityPeriodBean.VALIDITY_PERIOD);
			if (validityAnnotations.isEmpty()) {
				return;
			}
			
			for (AnnotationMutableBean annotationMutableBean : validityAnnotations) {
				setValidityDates(bean, annotationMutableBean);
			}
			
			((AnnotableMutableBean) bean).removeAnnotationsByType(ValidityPeriodBean.VALIDITY_PERIOD);
		}
	}

	private static class CompareValidityPeriods implements Comparator<AnnotationMutableBean>{

		@Override
		public int compare(AnnotationMutableBean o1, AnnotationMutableBean o2) {
			String thisTitle = o1.getTitle();
			String thatTitle = o2.getTitle();


			String[] thisTitleSplit = thisTitle.split("/");
			String thisStartDate = thisTitleSplit[0];
			String thisEndDate = (thisTitleSplit.length == 1 ? null: thisTitleSplit[1]);

			String[] thatTitleSplit = thatTitle.split("/");
			String thatStartDate = thatTitleSplit[0];
			String thatEndDate = (thatTitleSplit.length == 1 ? null: thatTitleSplit[1]);

			String thisLowest = getLowest(thisStartDate, thisEndDate);

			String thatLowest = getLowest(thatStartDate, thatEndDate);

			return thisLowest.compareTo(thatLowest);
		}

		private static String getLowest(String startDate, String endDate){
			if(ObjectUtil.validString(startDate) && !ObjectUtil.validString(endDate)){
				return startDate;
			}
			if(!ObjectUtil.validString(startDate) && ObjectUtil.validString(endDate)){
				return endDate;
			}
			int res = startDate.compareTo(endDate);
			return  res < 0 ? startDate : endDate;
		}

	}

	/**
	 * Given a Codelist processes the Validity Annotations on that Codelist, setting Validity Periods on the items.
	 * @param aCodelist
	 */
	public static void processValidityAnnotations(CodelistMutableBean aCodelist) {
		boolean hasItemValidity = false;
		List<CodeMutableBean> retItems = new ArrayList<>();
		for (CodeMutableBean aCode : aCodelist.getItems()) {
			Set<AnnotationMutableBean> validityAnnotations = aCode.getAnnotationsByType(ValidityPeriodBean.VALIDITY_PERIOD);
			if (validityAnnotations.size() == 0) {
				retItems.add(aCode);
				continue;
			}
			hasItemValidity = true;
			if (validityAnnotations.size() == 1) {
				// Only add the annotation to this item
				AnnotationMutableBean anAnnotation = validityAnnotations.iterator().next();
				aCode.removeAnnotationsByType(ValidityPeriodBean.VALIDITY_PERIOD);
				setValidityDates(aCode, anAnnotation);
				setCodelistValues(aCode, anAnnotation);
				retItems.add(aCode);
				continue;
			}
			List<AnnotationMutableBean> sortedList = new ArrayList<>(validityAnnotations);

			Collections.sort(sortedList, new CompareValidityPeriods());
			for (AnnotationMutableBean anAnnotation : sortedList) {
				// Create an item for each - Codelists can have multiple items with the same ID.
				CodeMutableBean codeClone = (CodeMutableBean)aCode.deepClone();
				codeClone.removeAnnotationsByType(ValidityPeriodBean.VALIDITY_PERIOD);
				setValidityDates(codeClone, anAnnotation);
				setCodelistValues(codeClone, anAnnotation);
				retItems.add(codeClone);
			}
		}

		Set<AnnotationMutableBean> annotationsByType = aCodelist.getAnnotationsByType(ValidityPeriodBean.VALIDITY_TYPE);
		for (AnnotationMutableBean anAnnotation : annotationsByType) {
			String title = anAnnotation.getTitle();
			aCodelist.setValidityType(MAINT_VALIDITY_TYPE.getValidityType(title));
		}
		aCodelist.removeAnnotationsByType(ValidityPeriodBean.VALIDITY_TYPE);

		aCodelist.setItems(retItems);
		if (hasItemValidity) {
			if (aCodelist.getValidityType() == null || aCodelist.getValidityType() == MAINT_VALIDITY_TYPE.STANDARD) {
				aCodelist.setValidityType(MAINT_VALIDITY_TYPE.ITEM_VALIDITY);
			}
		}
	}

	private static void setCodelistValues(CodeMutableBean codeClone, AnnotationMutableBean annotationMutableBean) {
		// TODO - this is hard-coded to get the first entry
		List<TextTypeWrapperMutableBean> list = annotationMutableBean.getText();
		if (ObjectUtil.validCollection(list)) {
			for (TextTypeWrapperMutableBean text : list) {
				String value = text.getValue();
				String locale = text.getLocale();
				if (ObjectUtil.validString(value)) {
					// The format of this string is the following:
					//   N: is always present and the first 2 characters
					//   D: will always be the start of the second line if present
					if (value.length() < 2 || !value.substring(0,2).equals("N:")) {
						if(!value.substring(0,2).equals("N:")){ // no name, but this is valid if another locale has a name
							List<TextTypeWrapperMutableBean> otherNames = list.stream().filter(tt -> tt.getValue().substring(0,2).equals("N:")).collect(Collectors.toList());
							if(!ObjectUtil.validCollection(otherNames)){
								throw new IllegalArgumentException("There are no names on any of the locales provided, there must be at least one name per item/locale combonation");
							}
						}else{
							throw new IllegalArgumentException("The name / description was not specified correctly!");
						}
					}

					String name = null;
					String desc = null;

					// TODO - improve this!  Could use a split instead...

					String first2Chars = value.substring(0, 2);
					if(first2Chars.equals("D:")){
						name = null;
						desc = value.substring(2);
					}else if(first2Chars.equals("N:")){
						int loc = value.indexOf("\n");
						int modifier = 3;
						if (loc == -1) {
							loc = value.indexOf("\r\n");
							modifier = 4;
						}
						if (loc == -1) {
							name = value.substring(2);
							desc = null;
						} else {
							name = value.substring(2, loc);
							desc = value.substring(loc+modifier);
						}
					}
					if(ObjectUtil.validString(name)){
						codeClone.addName(locale, name);
					}else{
						codeClone.removeName(locale);
					}
					if (ObjectUtil.validString(desc)) {
						codeClone.addDescription(locale, desc);
					}else{
						codeClone.removeDescription(locale);
					}

				}
			}
		}

		if (ObjectUtil.validString( annotationMutableBean.getUri() )) {
			codeClone.setParentCode( annotationMutableBean.getUri() );
		}

	}

	private static void setValidityDates(ValidityPeriodMutableBean anItem, AnnotationMutableBean anAnnotation) {
		String title = anAnnotation.getTitle();
		if (!ObjectUtil.validString(title)) {
			throw new IllegalArgumentException("Validity Period Annotation does not have a title. This is not permitted.");
		}
		if (title.indexOf('/') == -1) {
			// Throw error - there MUST be at least one semi-colon
			throw new IllegalArgumentException("The specified Validity period is not of the correct format. "
					+ "The two dates should be in ISO-8601 format and separated by a Forward Slash.");
		}
		String[] titleSplit = title.split("/");
		String startDate = titleSplit[0];
		String endDate = (titleSplit.length == 1 ? null: titleSplit[1]);

		if (ObjectUtil.validString(startDate)) {
			anItem.setStartDate( DateUtil.formatDate(startDate, true) );
		}

		if (ObjectUtil.validString(endDate)) {
			// JIRA: FRCE-61
			// The following code addresses an odd issue noticed in DateUtil.
			// If the cellVaLue includes a Time (e.g. 2001-12-31T14:00:00) if startOfPeriod is true the time does not change.
			// However if startOFPeriod is false then the time is moved to 23:59:59 even though the user specified a time..
			// We do NOT want to move to the END of the time period if the user has specified a time, only if the user hasn't specified a time.
			// So the workaround is that if the cell contains a Time, pretend that it is the start of period, so that the time does not change.
			boolean isStartOfPeriod = false;
			if (endDate.contains("T") && endDate.charAt(endDate.length()-1) != 'T') {
				isStartOfPeriod = true;
			}
			anItem.setEndDate( DateUtil.formatDate(endDate, isStartOfPeriod) );
		}
	}
	
	/**
	 * Given an SdmxPeriod, returns the Start Period (if there is one) formatted to the form: YYYY-MM-DDTHH:mm:SS.
	 * Otherwise returns null
	 * @param validity
	 * @return either null or a String
	 */
	public static String getStartPeriod(SdmxPeriod validity) {
		if (validity == null || validity.getStartPeriod() == null) {
			return null;
		}
		return DateUtil.formatDate(validity.getStartPeriod().getDate());
	}
	
	/**
	 * Given an SdmxPeriod, returns the End Period (if there is one) formatted to the form: YYYY-MM-DDTHH:mm:SS.
	 * Otherwise returns null
	 * @param validity
	 * @return either null or a String
	 */
	public static String getEndPeriod(SdmxPeriod validity) {
		if (validity == null || validity.getEndPeriod() == null) {
			return null;
		}
		return DateUtil.formatDate(validity.getEndPeriod().getDate());
	}
}
