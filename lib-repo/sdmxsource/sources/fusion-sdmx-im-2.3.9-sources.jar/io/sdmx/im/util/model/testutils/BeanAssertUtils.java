package io.sdmx.im.util.model.testutils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.im.diff.DiffReportImpl;
import io.sdmx.utils.core.io.SerializeUtil;
import io.sdmx.utils.core.object.AssertUtil;

public class BeanAssertUtils {

	public static void runTests(MaintainableBean bean) {
		assertMutable(bean);
		assertDeepEquals(bean);
		assertComposites(bean);
		assertReferences(bean);
		assertSerialize(bean);
	}
	
	private static void assertSerialize(MaintainableBean bean) {
		ByteArrayOutputStream bos = SerializeUtil.serializeAsByteArray(bean, false);
		InputStream is = new ByteArrayInputStream(bos.toByteArray());
		MaintainableBean deser = SerializeUtil.deSerialize(is, false);
		assertDeepEquals(bean, deser);
	}
	
	private static void assertMutable(MaintainableBean bean) {
		assertDeepEquals(bean, bean.getMutableInstance().getImmutableInstance());
	}
	
	private static void assertReferences(MaintainableBean bean) {
		Set<IDirectCrossReferenceBean<?>> xsRef = bean.getCrossReferences();
		AssertUtil.notNull(xsRef, "Cross References");
		for(ICrossReferenceBeanBase ref : xsRef) {
			AssertUtil.notNull(ref, "Cross Reference");
		}
	}
	
	private static void assertComposites(MaintainableBean bean) {
		Set<SDMXBean> composite = bean.getComposites();
		AssertUtil.notNull(composite, "Composite References");
		for(SDMXBean comp : composite) {
			AssertUtil.notNull(comp, "Composite Reference");
		}
	}
	
	
	private static void assertDeepEquals(MaintainableBean table) {
		assertDeepEquals(table, table.getMutableInstance().getImmutableInstance());
	}
	
	private static void assertDeepEquals(MaintainableBean t1, MaintainableBean t2) {
		DiffReport diff = new DiffReportImpl(t1, t2);
		AssertUtil.boolMatch(true, t1.deepEquals(t2, false, diff), "DeepEquals without final properties: ");
		AssertUtil.boolMatch(true, t1.deepEquals(t2, true, diff), "DeepEquals with final properties: ");
	}
}
