package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.im.mutable.transformation.NamePersonalisationSchemeMutableBean;

public class TestNamePersonalisationSchemeUtil {

	public static INamePersonalisationSchemeMutableBean create(String agencyId, String id, String version, String vtlVersion) {
		INamePersonalisationSchemeMutableBean mutable = new NamePersonalisationSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.setVtlVersion(vtlVersion);
		mutable.addName("en", id+ " Name");
		return mutable;
	}
	

	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static INamePersonalisationSchemeMutableBean createComplete(String agencyId, String id, String version, String vtlVersion) {
		INamePersonalisationSchemeMutableBean mutable = TestNamePersonalisationSchemeUtil.create(agencyId, id, version, vtlVersion);
		mutable.addINamePersonalisation("NP1", "va1", "dn1", "pn1").addName("en", "N1");
		mutable.addINamePersonalisation("NP2", "va2", "dn2", "pn2").addName("en", "N2");
		return mutable;
	}
	
}
