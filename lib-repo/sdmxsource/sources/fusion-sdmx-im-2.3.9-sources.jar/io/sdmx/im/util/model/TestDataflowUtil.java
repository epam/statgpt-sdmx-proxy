package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.im.superbeans.datastructure.DataflowSuperBeanImpl;
import io.sdmx.im.util.model.testinstances.TestDSDInstances;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestDataflowUtil {

	/**
	 * Generates a Dataflow with the same agency, id, version as the DSD that it references
	 * @param dsdRef
	 * @return
	 */
	public static DataflowSuperBean generateDataflowSuperBean(boolean includeDsAttributes, boolean includeCodedSeriesAttributes, boolean includeCodedObsAttributes) {
		DataStructureSuperBean dsdSb = TestDSDInstances.getSuperBean(includeDsAttributes, includeCodedSeriesAttributes, includeCodedObsAttributes);
		return new DataflowSuperBeanImpl(generateDataflow(dsdSb.getBuiltFrom().asReference()), dsdSb);
	}

	/**
	 * Generates a Dataflow with the same agency, id, version as the DSD that it references
	 * @param dsdRef
	 * @return
	 */
	public static DataflowBean generateDataflow(StructureReferenceBean ref) {
		return generateDataflow(MaintainableProperties.getInstance(ref.getAgencyId(), ref.getMaintainableId(), ref.getVersion().toString()));
	}
	
	public static DataflowBean generateDataflow(IMaintainableProperties ref) {
		DataflowMutableBean mutable = new DataflowMutableBeanImpl();
		mutable.setDataStructureRef(StructureReferenceBeanImpl.fromProperties(ref, SDMX_STRUCTURE_TYPE.DSD));
		TestMaintainableUtil.setMaintainableProperties(mutable, ref);
		return mutable.getImmutableInstance();
	}
	
	public static DataflowBean generateDataflow(IMaintainableProperties ref, DataStructureBean dsd) {
		DataflowMutableBean mutable = new DataflowMutableBeanImpl();
		mutable.setDataStructureRef(dsd.asReference());
		TestMaintainableUtil.setMaintainableProperties(mutable, ref);
		return mutable.getImmutableInstance();
	}
}
