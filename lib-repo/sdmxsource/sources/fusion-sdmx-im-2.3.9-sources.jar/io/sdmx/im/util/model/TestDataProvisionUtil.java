package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;

public class TestDataProvisionUtil {
	
	
	/**
	 * Generates a metadata provision  of version 1.0.0  and id flowId_providerId
	 * @param agencyId provision agency
	 * @param flowId id of metadata flow, same agency as provision
	 * @param providerId provider id, same agency as provision
	 * @return
	 */
	public static ProvisionAgreementBean generateProvision(String agencyId, String providerId, StructureReferenceBean flowRef) {
		ProvisionAgreementMutableBean pa = new ProvisionAgreementMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(pa, agencyId, flowRef.getMaintainableId()+"_"+providerId, "1.0.0");
		pa.setStructureUsage(flowRef);
		pa.setDataproviderRef(new StructureReferenceBeanImpl(agencyId, "DataProviders", "1.0", SDMX_STRUCTURE_TYPE.DATA_PROVIDER, providerId));
		return pa.getImmutableInstance();
	}
	
	public static ProvisionAgreementBean generateProvision(String agencyId, DataflowBean flow, DataProviderBean provider) {
		ProvisionAgreementMutableBean pa = new ProvisionAgreementMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(pa, agencyId, flow.getId()+"_"+provider.getId(), "1.0.0");
		pa.setStructureUsage(flow.asReference());
		pa.setDataproviderRef(provider.asReference());
		return pa.getImmutableInstance();
	}
	
}
