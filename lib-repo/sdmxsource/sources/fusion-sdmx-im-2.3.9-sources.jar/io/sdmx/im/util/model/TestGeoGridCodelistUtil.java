package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodelistMutableBean;

public class TestGeoGridCodelistUtil {
	
	
	/**
	 * 
	 * @param agency
	 * @param id
	 * @param version
	 * @param gridDefinition
	 * @param geoCodes  id:geocell pair
	 * @return
	 */
	public static IGeoGridCodelistBean generateCodelist(String agency, String id, String version, 
			String gridDefinition, String...geoCodes) {
		GeoGridCodelistMutableBean mutable = new GeoGridCodelistMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String codeId : geoCodes) {
			addCode(mutable, codeId);
		}
		mutable.setGridDefinition(gridDefinition);
		return mutable.getImmutableInstance();
	}

	/**
	 * @param mutable
	 * @param codeId codeid:geocell pair
	 * @return
	 */
	private static IGeoGridCodeMutableBean addCode(GeoGridCodelistMutableBean mutable, String codeId) {
		IGeoGridCodeMutableBean item = new GeoGridCodeMutableBean();
		String[] idSplit = codeId.split(":");
		codeId = idSplit[0];
		item.setGeoCell(idSplit[1]);
		String[] split = codeId.split(" ", 2);
		String codeName = split.length > 1 ? split[1] : codeId+"-name";
		TestMaintainableUtil.setNameableProperties(item, split[0], codeName);
		mutable.addItem(item);
		return item;
	}
}
