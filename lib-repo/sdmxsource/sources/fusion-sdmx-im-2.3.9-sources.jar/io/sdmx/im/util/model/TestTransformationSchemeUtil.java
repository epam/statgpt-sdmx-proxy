package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.im.mutable.transformation.TransformationSchemeMutableBean;

public class TestTransformationSchemeUtil {


	public static ITransformationSchemeMutableBean create(String agencyId, String id, String version, String vtlVersion) {
		ITransformationSchemeMutableBean mutable = new TransformationSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.setVtlVersion(vtlVersion);
		mutable.addName("en", id+ " Name");
		return mutable;
	}
	
	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static ITransformationSchemeMutableBean createComplete(String agencyId, String id, String version, String vtlVersion) {
		ITransformationSchemeMutableBean mutable = TestTransformationSchemeUtil.create(agencyId, id, version, vtlVersion);
		mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl("SDMX", "VMS", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
		mutable.setNamePersonalisationSchemeRef(new StructureReferenceBeanImpl("SDMX", "NPS", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME));
		mutable.setCustomTypeSchemeRef(new StructureReferenceBeanImpl("SDMX", "CTR", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME));
		mutable.addRulesetSchemeRef(new StructureReferenceBeanImpl("SDMX", "RS1", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
		mutable.addRulesetSchemeRef(new StructureReferenceBeanImpl("SDMX", "RS2", "2.0.0", SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
		mutable.addUserDefinedOperatorSchemeRef(new StructureReferenceBeanImpl("SDMX", "UDO1", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME));
		mutable.addUserDefinedOperatorSchemeRef(new StructureReferenceBeanImpl("SDMX", "UDO2", "2.0.0", SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME));
		mutable.addTransformation("T1", true, "r1", "e1").addName("en", "N1");
		mutable.addTransformation("T2", false, "r2", "e2").addName("en", "N2");
		return mutable;
	}
}
