package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;

public class TestDataProviderSchemeUtil {

	public static DataProviderSchemeBean generateDataProviderScheme(String agencyId, String...providerIds) {
		DataProviderSchemeMutableBean mutable = new DataProviderSchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, DataProviderSchemeBean.FIXED_ID, DataProviderSchemeBean.FIXED_VERSION);
		for(String providerId : providerIds) {
			mutable.createItem(providerId, providerId);
		}
		return mutable.getImmutableInstance();
	}
	
}
