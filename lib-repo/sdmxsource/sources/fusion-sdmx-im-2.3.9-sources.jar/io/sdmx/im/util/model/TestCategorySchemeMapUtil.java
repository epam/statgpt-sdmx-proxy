package io.sdmx.im.util.model;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ICategorySchemeMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.CategoryMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.CategorySchemeMapMutableBean;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Used to generate test {@link ICategorySchemeMapBean} for test purposes
 */
public class TestCategorySchemeMapUtil {

	public static ICategorySchemeMapMutableBean generateSchemeMap(
			String agency, String id, String version,
			IMaintainableRef source,
			IMaintainableRef target,
			Map<String, String> source2target) {

		ICategorySchemeMapMutableBean mutableMap = new CategorySchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		mutableMap.setSourceRef(new StructureReferenceBeanImpl(source, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME));
		mutableMap.setTargetRef(new StructureReferenceBeanImpl(target, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME));
		SdmxPeriod validity = new SdmxPeriodImpl("1959", "2029");

		for (String sourceId : source2target.keySet()) {
			addCategoryMap(mutableMap, sourceId, source2target.get(sourceId), validity, 100, 200, false);
		}
		return mutableMap;
	}

	public static ICategorySchemeMapMutableBean generateSchemeMapFromBeans(
			String agency, String id, String version,
			CategorySchemeBean source,
			CategorySchemeBean target,
			ICategoryMapMutableBean... categoryMaps) {

		ICategorySchemeMapMutableBean mutableMap = new CategorySchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		addSchemes(mutableMap, source, target);

		for (ICategoryMapMutableBean categoryMap : categoryMaps) {
			mutableMap.addItem(categoryMap);
		}
		return mutableMap;
	}

	public static void addCategoryMap(
			ICategorySchemeMapMutableBean mutableMap,
			String sourceId,
			String targetId,
			SdmxPeriod validity,
			Integer startIdx,
			Integer endIdx,
			boolean isRegEx) {

		String startPeriod = ValidityPeriodUtil.getStartPeriod(validity);
		String endPeriod = ValidityPeriodUtil.getEndPeriod(validity);

		ICategoryMapMutableBean categoryMap = new CategoryMapMutableBean()
				.setSourceId(sourceId)
				.setTargetId(targetId)
				.setSourceStartIdx(startIdx)
				.setSourceEndIdx(endIdx)
				.setValidFrom(startPeriod)
				.setValidTo(endPeriod)
				.setSourceRegEx(isRegEx);

		mutableMap.addItem(categoryMap);
	}

	public static void addSchemes(
			ICategorySchemeMapMutableBean mutableCategorySchemeMap,
			CategorySchemeBean sourceCategoryScheme,
			CategorySchemeBean targetCategoryScheme) {

		mutableCategorySchemeMap.setSourceRef(sourceCategoryScheme.asReference());
		mutableCategorySchemeMap.setTargetRef(targetCategoryScheme.asReference());
	}
}
