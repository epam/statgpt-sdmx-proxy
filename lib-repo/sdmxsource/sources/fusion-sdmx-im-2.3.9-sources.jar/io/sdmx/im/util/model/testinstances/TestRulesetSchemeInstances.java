package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.im.util.model.TestRulesetSchemeUtil;

public class TestRulesetSchemeInstances {

    public static IRulesetSchemeBean getComplete() {
        return TestRulesetSchemeUtil.createComplete("SDMX", "RULESETS", "1.0", "1.0").getImmutableInstance();
    }
}
