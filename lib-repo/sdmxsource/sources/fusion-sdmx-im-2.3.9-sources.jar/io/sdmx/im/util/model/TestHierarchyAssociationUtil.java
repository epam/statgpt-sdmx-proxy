package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.im.mutable.codelist.HierarchyAssociationMutableBeanImpl;

public class TestHierarchyAssociationUtil {

	
	public static HierarchyAssociationBean generateHierarchyAssociation(SDMX_STRUCTURE_TYPE targetMaint) {
		return generateHierarchyAssociation("HIERARCHY", targetMaint);
	}
	
	public static HierarchyAssociationBean generateHierarchyAssociation(String hierarhcyId, SDMX_STRUCTURE_TYPE targetMaint) {
		String hierarchyAccociationRef = new StructureReferenceBeanImpl("ACY", hierarhcyId, "1.0", SDMX_STRUCTURE_TYPE.HIERARCHY).getTargetUrn();
		String maintRef = new StructureReferenceBeanImpl("ACY", "M1", "1.0", targetMaint).getTargetUrn();
		return TestHierarchyAssociationUtil.generateHierarchyAssociation("ACY", "TEST", "1.0", hierarchyAccociationRef, maintRef, null);
	}

	public static HierarchyAssociationBean generateHierarchyAssociation(String id, String hierarchyAssociationRef, String maintRef) {
		return generateHierarchyAssociation("ACY", id, "1.0", hierarchyAssociationRef, maintRef, null);
	}

	public static HierarchyAssociationBean generateHierarchyAssociation(String agency, String id, String version, String hierarchyAssociationRef, String maintRef, String context) {
		HierarchyAssociationMutableBean mutable = new HierarchyAssociationMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		if(hierarchyAssociationRef != null) {
			mutable.setHierarchyRef(new StructureReferenceBeanImpl(hierarchyAssociationRef));
		}
		if(maintRef != null) {
			mutable.setLinkedStructure(new StructureReferenceBeanImpl(maintRef));
		}
		if(context != null) {
			mutable.setContextStructure(new StructureReferenceBeanImpl(context));
		}
		return mutable.getImmutableInstance();
	}
}
