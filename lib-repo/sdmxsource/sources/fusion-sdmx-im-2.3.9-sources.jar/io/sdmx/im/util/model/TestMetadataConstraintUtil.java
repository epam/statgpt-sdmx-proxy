package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.IMetadataConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.MetadataConstraintMutableBean;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;

public class TestMetadataConstraintUtil {

	public static IMetadataConstraintMutableBean generateExcluded(String agency, String id, String version) {
		// excludedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		component1.setTimeRange(generateTimeRange("2004-04-04", "2006-06-06"));

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		addComponentValue(component2, "value-1", "2004-04-04", "2005-05-05", false);
		addComponentValue(component2, "value-2", "2005-05-05", "2006-06-06", false);
		addComponentValue(component2, "cascade-1", "2007-07-07", "2008-08-08", true);
		addComponentValue(component2, "cascade-2", "2009-09-09", "2010-10-10", true);
		component2.setRemovePrefix(false);

		List<KeyValuesMutable> excludedTarget = new ArrayList<>();
		excludedTarget.add(component1);
		excludedTarget.add(component2);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setExcludedTarget(excludedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateIncluded(String agency, String id, String version) {
		// includedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		component1.setTimeRange(generateTimeRange("2004-04-04", "2006-06-06"));

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		addComponentValue(component2, "value-1", "2004-04-04", "2005-05-05", false);
		addComponentValue(component2, "value-2", "2005-05-05", "2006-06-06", false);
		addComponentValue(component2, "cascade-1", "2007-07-07", "2008-08-08", true);
		addComponentValue(component2, "cascade-2", "2009-09-09", "2010-10-10", true);
		component2.setRemovePrefix(false);

		List<KeyValuesMutable> includedTarget = new ArrayList<>();
		includedTarget.add(component1);
		includedTarget.add(component2);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setIncludedTarget(includedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateIncludedWithTimeRange(String agency, String id, String version) {
		// includedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		component1.setTimeRange(generateTimeRange("2002-02-02", "2003-03-03"));

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		component2.setTimeRange(generateTimeRange("2004-04-04", "2006-06-06"));

		List<KeyValuesMutable> includedTarget = new ArrayList<>();
		includedTarget.add(component1);
		includedTarget.add(component2);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setIncludedTarget(includedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateIncludedWithValues(String agency, String id, String version) {
		// includedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		addComponentValue(component1, "value-1", "2004-04-04", "2005-05-05", false);
		addComponentValue(component1, "value-2", "2005-05-05", "2006-06-06", false);
		component1.setRemovePrefix(false);

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		addComponentValue(component2, "cascade-1", "2007-07-07", "2008-08-08", true);
		addComponentValue(component2, "cascade-2", "2009-09-09", "2010-10-10", true);
		component2.setRemovePrefix(true);

		List<KeyValuesMutable> includedTarget = new ArrayList<>();
		includedTarget.add(component1);
		includedTarget.add(component2);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setIncludedTarget(includedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateMixed(String agency, String id, String version) {
		// includedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		component1.setTimeRange(generateTimeRange("2002-02-02", "2003-03-03"));

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		addComponentValue(component2, "value-1", "2004-04-04", "2005-05-05", false);
		addComponentValue(component2, "value-2", "2005-05-05", "2006-06-06", false);
		addComponentValue(component2, "cascade-1", "2007-07-07", "2008-08-08", true);
		addComponentValue(component2, "cascade-2", "2009-09-09", "2010-10-10", true);
		component2.setRemovePrefix(false);

		List<KeyValuesMutable> includedTarget = new ArrayList<>();
		includedTarget.add(component1);
		includedTarget.add(component2);

		// excludedTarget
		KeyValuesMutable component3 = new KeyValuesMutableImpl().setId("COMPONENT_3");
		component3.setTimeRange(generateTimeRange("2004-04-04", "2006-06-06"));

		KeyValuesMutable component4 = new KeyValuesMutableImpl().setId("COMPONENT_4");
		addComponentValue(component4, "value-3", "2004-04-04", "2005-05-05", false);
		addComponentValue(component4, "value-4", "2005-05-05", "2006-06-06", false);
		addComponentValue(component4, "cascade-3", "2007-07-07", "2008-08-08", true);
		addComponentValue(component4, "cascade-4", "2009-09-09", "2010-10-10", true);
		component4.setRemovePrefix(false);

		List<KeyValuesMutable> excludedTarget = new ArrayList<>();
		excludedTarget.add(component3);
		excludedTarget.add(component4);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setIncludedTarget(includedTarget)
				.setExcludedTarget(excludedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateWithAttachments(
			String agency, String id, String version, List<StructureReferenceBean> attachments) {

		// excludedTarget
		KeyValuesMutable component1 = new KeyValuesMutableImpl().setId("COMPONENT_1");
		component1.setTimeRange(generateTimeRange("2004-04-04", "2006-06-06"));

		KeyValuesMutable component2 = new KeyValuesMutableImpl().setId("COMPONENT_2");
		addComponentValue(component2, "value-1", "2004-04-04", "2005-05-05", false);
		addComponentValue(component2, "value-2", "2005-05-05", "2006-06-06", false);
		addComponentValue(component2, "cascade-1", "2007-07-07", "2008-08-08", true);
		addComponentValue(component2, "cascade-2", "2009-09-09", "2010-10-10", true);
		component2.setRemovePrefix(false);

		List<KeyValuesMutable> excludedTarget = new ArrayList<>();
		excludedTarget.add(component1);
		excludedTarget.add(component2);

		// metadataConstraint
		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(attachments)
				.setExcludedTarget(excludedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static IMetadataConstraintMutableBean generateWithTargets(
			String agency, String id, String version,
			List<KeyValuesMutable> includedTarget, List<KeyValuesMutable> excludedTarget) {

		IMetadataConstraintMutableBean metadataConstraintMutable = new MetadataConstraintMutableBean();
		TestMaintainableUtil.setMaintainableProperties(metadataConstraintMutable, agency, id, version);
		metadataConstraintMutable
				.setAttachments(generateProvisionAttachments())
				.setIncludedTarget(includedTarget)
				.setExcludedTarget(excludedTarget)
				.setReleaseCalendar(generateReleaseCalendar());
		return metadataConstraintMutable;
	}

	public static TimeRangeMutableBean generateTimeRange(String startDate, String endDate) {
		TimeRangeMutableBean timeRange = new TimeRangeMutableBeanImpl();
		timeRange.setStartDate(SdmxDateImpl.getSdmxDate(startDate));
		timeRange.setEndDate(SdmxDateImpl.getSdmxDate(endDate));
		timeRange.setIsStartInclusive(false);
		timeRange.setIsEndInclusive(true);
		timeRange.setIsRange(true);
		timeRange.setValidFrom(SdmxDateImpl.getSdmxDate("2010-10-10"));
		timeRange.setValidTo(SdmxDateImpl.getSdmxDate("2011-11-11"));
		return timeRange;
	}

	public static ReleaseCalendarMutableBean generateReleaseCalendar() {
		ReleaseCalendarMutableBean releaseCalendar = new ReleaseCalendarMutableBeanImpl();
		releaseCalendar.setOffset("P5D");
		releaseCalendar.setPeriodicity("P1M1D");
		releaseCalendar.setTolerance("P1D");
		return releaseCalendar;
	}

	private static List<StructureReferenceBean> generateProvisionAttachments() {
		List<StructureReferenceBean> attachments = new ArrayList<>();
		MetadataProvisionAgreementBean metadataProvision1 = TestMetadataProvisionUtil.generateProvision(
				"AGENCY", "FLOW1", "PROVIDER1");
		MetadataProvisionAgreementBean metadataProvision2 = TestMetadataProvisionUtil.generateProvision(
				"AGENCY", "FLOW2", "PROVIDER2");
		attachments.add(metadataProvision1.asReference());
		attachments.add(metadataProvision2.asReference());
		return attachments;
	}

	private static void addComponentValue(KeyValuesMutable component, String value, String validFrom, String validTo, boolean isCascade) {
		if (isCascade) {
			component.addCascade(value);
		} else {
			component.addValue(value);
		}
		component.setValidity(value, validFrom, validTo);
	}
}
