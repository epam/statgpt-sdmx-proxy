package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;

public class TestDataConsumerSchemeUtil {

	public static DataConsumerSchemeBean generateDataProviderScheme(String agencyId, String...providerIds) {
		DataConsumerSchemeMutableBean mutable = new DataConsumerSchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, DataConsumerSchemeBean.FIXED_ID, DataConsumerSchemeBean.FIXED_VERSION);
		for(String providerId : providerIds) {
			mutable.createItem(providerId, providerId);
		}
		return mutable.getImmutableInstance();
	}
	
}
