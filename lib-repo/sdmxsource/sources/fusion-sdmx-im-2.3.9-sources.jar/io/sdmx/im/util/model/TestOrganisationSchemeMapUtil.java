package io.sdmx.im.util.model;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IOrganisationSchemeMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.OrganisationMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.OrganisationSchemeMapMutableBean;
import io.sdmx.utils.core.date.SdmxPeriodImpl;

public class TestOrganisationSchemeMapUtil {

	public static IOrganisationSchemeMapMutableBean generateSchemeMap(
			String agency, String id, String version,
			StructureReferenceBean source,
			StructureReferenceBean target,
			Map<String, String> source2target) {

		IOrganisationSchemeMapMutableBean mutableMap = new OrganisationSchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		mutableMap.setSourceRef(source);
		mutableMap.setTargetRef(target);
		SdmxPeriod validity = new SdmxPeriodImpl("1959", "2029");

		for (String sourceId : source2target.keySet()) {
			addOrganisationMap(mutableMap, sourceId, source2target.get(sourceId), validity, 100, 200, false);
		}
		return mutableMap;
	}

	public static IOrganisationSchemeMapMutableBean generateSchemeMapFromBeans(
			String agency, String id, String version,
			ItemSchemeBean source,
			ItemSchemeBean target,
			IOrganisationMapMutableBean... organisationMaps) {

		IOrganisationSchemeMapMutableBean mutableMap = new OrganisationSchemeMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		addSchemes(mutableMap, source, target);

		for (IOrganisationMapMutableBean organisationMap : organisationMaps) {
			mutableMap.addItem(organisationMap);
		}
		return mutableMap;
	}

	public static void addOrganisationMap(
			IOrganisationSchemeMapMutableBean mutableMap,
			String sourceId,
			String targetId,
			SdmxPeriod validity,
			Integer startIdx,
			Integer endIdx,
			boolean isRegEx) {

		String startPeriod = ValidityPeriodUtil.getStartPeriod(validity);
		String endPeriod = ValidityPeriodUtil.getEndPeriod(validity);

		IOrganisationMapMutableBean organisationMap = new OrganisationMapMutableBean()
				.setSourceId(sourceId)
				.setTargetId(targetId)
				.setSourceStartIdx(startIdx)
				.setSourceEndIdx(endIdx)
				.setValidFrom(startPeriod)
				.setValidTo(endPeriod)
				.setSourceRegEx(isRegEx);

		mutableMap.addItem(organisationMap);
	}

	public static void addSchemes(
			IOrganisationSchemeMapMutableBean mutableOrganisationSchemeMap,
			ItemSchemeBean sourceOrganisationScheme,
			ItemSchemeBean targetOrganisationScheme) {

		mutableOrganisationSchemeMap.setSourceRef(sourceOrganisationScheme.asReference());
		mutableOrganisationSchemeMap.setTargetRef(targetOrganisationScheme.asReference());
	}
}