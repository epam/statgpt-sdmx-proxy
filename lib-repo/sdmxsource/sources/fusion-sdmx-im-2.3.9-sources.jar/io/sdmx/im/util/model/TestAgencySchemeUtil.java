package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;

public class TestAgencySchemeUtil {

	public static AgencySchemeBean generateAgencyScheme(String agencyId, String...agenciesIds) {
		AgencySchemeMutableBean mutable = new AgencySchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, AgencySchemeBean.FIXED_ID, AgencySchemeBean.FIXED_VERSION);
		for(String providerId : agenciesIds) {
			mutable.createItem(providerId, providerId);
		}
		return mutable.getImmutableInstance();
	}
	
	public static void addContactDetails(OrganisationSchemeMutableBean<? extends OrganisationMutableBean> mutable, ContactMutableBean contact, String agencyId) {
		OrganisationMutableBean org = mutable.getItemById(agencyId);
		org.addContact(contact);
	}
}
