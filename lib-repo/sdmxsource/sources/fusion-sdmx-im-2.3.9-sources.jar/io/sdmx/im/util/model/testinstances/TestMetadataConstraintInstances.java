package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.registry.IMetadataConstraintBean;
import io.sdmx.im.util.model.TestMetadataConstraintUtil;

public class TestMetadataConstraintInstances {

	public static IMetadataConstraintBean getExcluded() {
		return TestMetadataConstraintUtil.generateExcluded("AGENCY2", "MDC_EXC", "1.0").getImmutableInstance();
	}

	public static IMetadataConstraintBean getIncluded() {
		return TestMetadataConstraintUtil.generateIncluded("AGENCY1", "MDC_INC", "1.0").getImmutableInstance();
	}

	public static IMetadataConstraintBean getIncludedWithTimeRange() {
		return TestMetadataConstraintUtil.generateIncludedWithTimeRange("AGENCY4", "MDC_ITR", "1.0").getImmutableInstance();
	}

	public static IMetadataConstraintBean getIncludedWithValues() {
		return TestMetadataConstraintUtil.generateIncludedWithValues("AGENCY5", "MDC_IVL", "1.0").getImmutableInstance();
	}

	public static IMetadataConstraintBean getMixed() {
		return TestMetadataConstraintUtil.generateMixed("AGENCY3", "MDC_MIX", "1.0").getImmutableInstance();
	}
}
