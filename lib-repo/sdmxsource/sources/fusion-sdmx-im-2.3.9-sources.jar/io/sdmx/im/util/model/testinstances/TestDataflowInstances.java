package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.im.util.model.TestMaintainableUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestDataflowInstances {

    
    /**
     * EER_D (daily) against the EER DSD
     * @return
     */
    public static DataflowBean createTwoPartVersion() {
        DataflowMutableBean mutable = new DataflowMutableBeanImpl();
        mutable.setDataStructureRef(new StructureReferenceBeanImpl("BIS", "EER", "1.0", SDMX_STRUCTURE_TYPE.DSD));
        TestMaintainableUtil.setMaintainableProperties(mutable, MaintainableProperties.getInstance("BIS", "EER_D", "1.0"));
        return mutable.getImmutableInstance();
    }
    
}
