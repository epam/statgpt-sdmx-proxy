package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.im.util.model.TestVtlMappingSchemeUtil;

public class TestVTLMappingSchemeInstances {

    public static IVtlMappingSchemeBean getComplete() {
        return TestVtlMappingSchemeUtil.createComplete("SDMX", "VTL_MAPPING", "1.0").getImmutableInstance();
    }
}
