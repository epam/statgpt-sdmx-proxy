package io.sdmx.im.util.model;

import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingCategoryMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IReportingTaxonomyMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ReportingCategoryMapMutableBean;
import io.sdmx.im.mutable.mapping.v3.ReportingTaxonomyMapMutableBean;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestReportingTaxonomyMapUtil {

	public static IReportingTaxonomyMapMutableBean generateSchemeMap(
			String agency, String id, String version,
			IMaintainableRef source,
			IMaintainableRef target,
			Map<String, String> source2target) {

		IReportingTaxonomyMapMutableBean mutableMap = new ReportingTaxonomyMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		mutableMap.setSourceRef(new StructureReferenceBeanImpl(source, SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY));
		mutableMap.setTargetRef(new StructureReferenceBeanImpl(target, SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY));
		SdmxPeriod validity = new SdmxPeriodImpl("1959", "2029");

		for (String sourceId : source2target.keySet()) {
			addReportingCategoryMap(mutableMap, sourceId, source2target.get(sourceId), validity, 100, 200, false);
		}
		return mutableMap;
	}

	public static IReportingTaxonomyMapMutableBean generateSchemeMapFromBeans(
			String agency, String id, String version,
			ReportingTaxonomyBean source,
			ReportingTaxonomyBean target,
			IReportingCategoryMapMutableBean... reportingCategoryMaps) {

		IReportingTaxonomyMapMutableBean mutableMap = new ReportingTaxonomyMapMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutableMap, agency, id, version);
		addSchemes(mutableMap, source, target);

		for (IReportingCategoryMapMutableBean reportingCategoryMap : reportingCategoryMaps) {
			mutableMap.addItem(reportingCategoryMap);
		}
		return mutableMap;
	}

	public static void addReportingCategoryMap(
			IReportingTaxonomyMapMutableBean mutableMap,
			String sourceId,
			String targetId,
			SdmxPeriod validity,
			Integer startIdx,
			Integer endIdx,
			boolean isRegEx) {

		String startPeriod = ValidityPeriodUtil.getStartPeriod(validity);
		String endPeriod = ValidityPeriodUtil.getEndPeriod(validity);

		IReportingCategoryMapMutableBean reportingCategoryMap = new ReportingCategoryMapMutableBean()
				.setSourceId(sourceId)
				.setTargetId(targetId)
				.setSourceStartIdx(startIdx)
				.setSourceEndIdx(endIdx)
				.setValidFrom(startPeriod)
				.setValidTo(endPeriod)
				.setSourceRegEx(isRegEx);

		mutableMap.addItem(reportingCategoryMap);
	}

	public static void addSchemes(
			IReportingTaxonomyMapMutableBean mutableReportingTaxonomyMap,
			ReportingTaxonomyBean sourceReportingTaxonomy,
			ReportingTaxonomyBean targetReportingTaxonomy) {

		mutableReportingTaxonomyMap.setSourceRef(sourceReportingTaxonomy.asReference());
		mutableReportingTaxonomyMap.setTargetRef(targetReportingTaxonomy.asReference());
	}
}
