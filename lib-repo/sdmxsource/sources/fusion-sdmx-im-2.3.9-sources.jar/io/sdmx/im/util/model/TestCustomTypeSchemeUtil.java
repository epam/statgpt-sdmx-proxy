package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.im.mutable.transformation.CustomTypeSchemeMutableBean;

public class TestCustomTypeSchemeUtil {

	public static ICustomTypeSchemeMutableBean create(String agencyId, String id, String version, String vtlVersion) {
		ICustomTypeSchemeMutableBean mutable = new CustomTypeSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.setVtlVersion(vtlVersion);
		mutable.addName("en", id + " Name");
		return mutable;
	}

	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 *
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static ICustomTypeSchemeMutableBean createComplete(String agencyId, String id, String version, String vtlVersion) {
		ICustomTypeSchemeMutableBean mutable = TestCustomTypeSchemeUtil.create(agencyId, id, version, vtlVersion);
		mutable.addCustomType("CT1", "CT1 Name", "scaler", "data", "of", "nv", "lf");  // full
		mutable.addCustomType("CT2", "CT2 Name", "scaler2", "data2", null, null, null);  // minimal
		return mutable;
	}
}
