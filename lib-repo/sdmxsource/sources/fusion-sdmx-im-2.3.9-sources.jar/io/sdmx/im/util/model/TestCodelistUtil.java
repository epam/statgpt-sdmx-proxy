package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class TestCodelistUtil {
	public static CodelistBean generateCodelist(String agency, String id, String version, String...codes) {
		CodelistMutableBean mutable = new CodelistMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String codeId : codes) {
			addCode(mutable, codeId);
		}
		return mutable.getImmutableInstance();
	}

	/**
	 * Mutates the codelist so that it extends the other codelists passed in
	 * @param codelist to mutate and return
	 * @param toExtend the codelist definition will be updated to extend these codelists
	 * @return
	 */
	public static CodelistBean extendCodelists(CodelistBean codelist, CodelistBean...toExtend) {
		return extendCodelists(codelist, false, toExtend);
	}
	
	/**
	 * Mutates the codelist so that it extends the other codelists passed in
	 * @param codelist to mutate and return
	 * @param semver if true, the inheritance reference will point to the latest minor version, starting from the minor version of the toExtend codelist
	 * @param toExtend the codelist definition will be updated to extend these codelists
	 * @return
	 */
	public static CodelistBean extendCodelists(CodelistBean codelist, boolean semver, CodelistBean...toExtend) {
		if(toExtend == null) {
			return codelist;
		}
		CodelistMutableBean mutable = codelist.getMutableInstance();
		for(CodelistBean cl : toExtend) {
			ICodelistInheritanceRuleMutableBean rule1 = new CodelistInheritanceRuleMutableBean();
			rule1.setCodelistRef(cl.asReference());
			if(semver) {
				ISdmxVersion v = cl.getVersion();
				String semVer = v.getMajor() + "." + v.getMinor() + "+.0";
				rule1.getCodelistRef().setVersion(semVer);
			}
			mutable.addInheritenceRules(rule1);
		}
		return mutable.getImmutableInstance();
	}

	public static CodelistBean addCodeWithValidityPeriod(CodelistBean codelist, String codeId, String validFrom, String validTo) {
		CodelistMutableBean mutable = codelist.getMutableInstance();
		CodeMutableBean aCode = addCode(mutable, codeId);

		if (ObjectUtil.validString(validFrom)) {
			aCode.setStartDate( new SdmxDateImpl(validFrom, true).getDate() );
		}
		if (ObjectUtil.validString(validTo)) {
			aCode.setEndDate( new SdmxDateImpl(validTo, false).getDate() );
		}
		return mutable.getImmutableInstance();
	}

	private static CodeMutableBean addCode(CodelistMutableBean mutable, String codeId) {
		CodeMutableBean item = new CodeMutableBeanImpl();
		codeId = codeId.trim();

		String[] splitOnDot = codeId.split("\\.", 2);
		codeId = splitOnDot[splitOnDot.length-1];
		if(splitOnDot.length > 1) {
			item.setParentCode(splitOnDot[0]);
		}
		String[] split = codeId.split(" ", 2);

		String codeName = split.length > 1 ? split[1] : codeId+"-name";
		TestMaintainableUtil.setNameableProperties(item, split[0], codeName);
		mutable.addItem(item);
		return item;
	}
}
