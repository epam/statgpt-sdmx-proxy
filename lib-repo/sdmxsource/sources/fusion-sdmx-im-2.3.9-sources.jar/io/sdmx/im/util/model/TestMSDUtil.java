package io.sdmx.im.util.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataAttributeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataStructureDefinitionMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Create MSDs for test purposes
 */
public class TestMSDUtil {

	public static MetadataStructureDefinitionBean generateMetadataStructure(int attributes) {
		return generateMetadataStructure(attributes, null, null, null);
	}
	
	public static MetadataStructureDefinitionBean generateMetadataStructure(boolean coded, String...attributes) {
		MetadataStructureDefinitionMutableBean mutable = new MetadataStructureDefinitionMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, "ACY", "MSD", "1.0.0");
		addAttributes(mutable, 0, 1, coded, null, attributes);
		return mutable.getImmutableInstance();
	}
	
	public static MetadataStructureDefinitionBean generateMetadataStructure(int attributes, String agency, String id, String version) {
		MetadataStructureDefinitionMutableBean mutable = new MetadataStructureDefinitionMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		
		String[] attributeIds = new String[attributes];
		for(int i=0; i < attributes; i++) {
			attributeIds[i] = "MA"+i;
		}
		return addAttributes(mutable, 0, 1, true, null, attributeIds);
	}

	public static MetadataStructureDefinitionBean generateMetadataStructureWithTextFormatAttributes(boolean coded, String...attributes) {
		MetadataStructureDefinitionMutableBean mutable = new MetadataStructureDefinitionMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, "ACY", "MSD", "1.0.0");
		TextFormatMutableBean tf = new TextFormatMutableBeanImpl();
		tf.setTextType(TEXT_TYPE.STRING);
		addAttributes(mutable, 0, 1, coded, tf, attributes);
		return mutable.getImmutableInstance();
	}
	
	/**
	 * adds metadata attributes to the MSD -
	 * @param attributeId
	 * @return
	 */
	public static MetadataStructureDefinitionBean addAttributes(MetadataStructureDefinitionBean msd, boolean coded, String... attributeId) {
		return addAttributes(msd.getMutableInstance(), 0, 1, coded, null, attributeId);
	}
	
	/**
	 * adds metadata attributes to the MSD -
	 * @param mutable to add them to
	 * @param attributeId list of ids, a hierarchy can be created using the period separator CONTACT, CONTACT.FIRST_NAME, CONTACT.LAST_NAME
	 * @return
	 */
	public static MetadataStructureDefinitionBean addAttributes(MetadataStructureDefinitionMutableBean mutable,
																int minOccurs,
																int maxOccurs,
																boolean coded,
																TextFormatMutableBean textFormat,
																String... attributeIds) {
		if(attributeIds != null) {
			Map<String, List<MetadataAttributeMutableBean>> attMap = new HashMap<>();
			
			//ID ot he actual attribute, i.e ADDRESS.FIRST_LINE = attribute
			Map<String, MetadataAttributeMutableBean> parentIdToAttributeMap = new HashMap<>();
			populateAttributeMap(attMap, parentIdToAttributeMap, null, mutable.getMetadataAttributes());
			
			for(String fullQalifiedId : attributeIds) {
				String parentId = fullQalifiedId.contains(".") ? fullQalifiedId.substring(0, fullQalifiedId.lastIndexOf(".")) : null;
				String id = fullQalifiedId.contains(".") ? fullQalifiedId.substring(fullQalifiedId.lastIndexOf(".")+1) : fullQalifiedId;
				
				List<MetadataAttributeMutableBean> l = attMap.get(parentId);
				if(l == null) {
					l = new ArrayList<>();
					attMap.put(parentId, l);
				}
				MetadataAttributeMutableBean attMutable = new MetadataAttributeMutableBeanImpl();
				parentIdToAttributeMap.put(fullQalifiedId, attMutable);
				attMutable.setId(id);
				SDMX_STRUCTURE_TYPE st = SDMX_STRUCTURE_TYPE.CONCEPT;
				StructureReferenceBean conceptRef = new StructureReferenceBeanImpl("SDMX", "MSD_CONCEPTS", "1.0", st , id);
				attMutable.setConceptRef(conceptRef);
				if(minOccurs < 0 && maxOccurs < 0) {
					attMutable.setPresentational(TERTIARY_BOOL.TRUE);
				} else {
					attMutable.setMinOccurs(minOccurs);
					attMutable.setMaxOccurs(maxOccurs);
				}
				l.add(attMutable);
				
				RepresentationMutableBean representation = attMutable.getRepresentation();
				if(representation == null) {
					representation = new RepresentationMutableBeanImpl();
					attMutable.setRepresentation(representation);
				}
				representation.setTextFormat(textFormat);
				if(coded) {
					representation.setRepresentation(new StructureReferenceBeanImpl("SDMX", "CL_"+id, "1.0", SDMX_STRUCTURE_TYPE.CODE_LIST));
				}
			}
			//Tie all parents to children
			for(String attParent : attMap.keySet()) {
				if(attParent != null) {
					MetadataAttributeMutableBean att = parentIdToAttributeMap.get(attParent);
					att.setMetadataAttributes(attMap.get(attParent));
				}
			}
			mutable.setMetadataAttributes(attMap.get(null));
		}

		
		return mutable.getImmutableInstance();
	}
	
	private static void populateAttributeMap(Map<String, List<MetadataAttributeMutableBean>> attMap,
											 Map<String, MetadataAttributeMutableBean> parentIdToAttributeMap,
											 String parentId, List<MetadataAttributeMutableBean> metadataAttributes) {
		if(metadataAttributes != null) {
			attMap.put(parentId, metadataAttributes);
			for(MetadataAttributeMutableBean att : metadataAttributes) {
				String nextParentId = parentId == null ? att.getId() : parentId + "." + att.getId();
				parentIdToAttributeMap.put(nextParentId, att);
				if(ObjectUtil.validCollection(att.getMetadataAttributes())) {
					populateAttributeMap(attMap, parentIdToAttributeMap, nextParentId, att.getMetadataAttributes());
				}
			}
		}
	}
	
}
