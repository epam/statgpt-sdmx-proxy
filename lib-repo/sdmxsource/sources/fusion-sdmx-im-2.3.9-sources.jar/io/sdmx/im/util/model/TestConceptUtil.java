package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Generates test concept schemes
 */
public class TestConceptUtil {

	public static ConceptSchemeBean generateConceptScheme(String... concepts) {
		return generateConceptSchemeWithProps(null, null, null, "-Name", concepts);
	}
	
	/**
	 * @param agency concept scheme agency
	 * @param id concept scheme id
	 * @param version concept scheme version
	 * @param namePostfix added onto the end of each id (e.g Concept FREQ with postfix -NAME would have a name of FREQ-NAME)
	 * @param concepts array of concept ids to create in the concept scheme
	 * @return
	 */
	public static ConceptSchemeBean generateConceptSchemeWithProps(String agency, String id, String version, String namePostfix, String...concepts) {
		ConceptSchemeMutableBean mutable = new ConceptSchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String conceptId : concepts) {
		    addConcept(mutable, conceptId, namePostfix);
		}
		return mutable.getImmutableInstance();
	}
	
	public static void addConcept(ConceptSchemeMutableBean csMut, String conceptId, String namePostfix) {
	    if(conceptId == null) {
	        return;
	    }
        ConceptMutableBean item = new ConceptMutableBeanImpl();
        
        conceptId = conceptId.trim();
        
        String[] splitOnDot = conceptId.split("\\.", 2);
        conceptId = splitOnDot[splitOnDot.length-1];
        if(splitOnDot.length > 1) {
            item.setParentConcept(splitOnDot[0]);
        }
        String[] split = conceptId.split(" ", 2);
        conceptId = split[0];
        String conceptName = split.length > 1 ? split[1] : conceptId+namePostfix;
        
        TestMaintainableUtil.setNameableProperties(item, conceptId, conceptName);
        csMut.addItem(item);
	}
	
	public static ConceptSchemeBean linkConceptToCodelist(ConceptSchemeBean cs, String conceptId, IMaintainableRef ref) {
	    ConceptSchemeMutableBean csMut = cs.getMutableInstance();
		linkConceptToCodelist(csMut, conceptId, ref);
		return csMut.getImmutableInstance();
	}
	
	public static void linkConceptToCodelist(ConceptSchemeMutableBean csMut, String conceptId, IMaintainableRef ref) {
        ConceptMutableBean concept = csMut.getItemById(conceptId);
        if(concept == null) {
            throw new RuntimeException("Concept not found:" + concept);
        }
        RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
        rep.setRepresentation(new StructureReferenceBeanImpl(ref, SDMX_STRUCTURE_TYPE.CODE_LIST));
        concept.setCoreRepresentation(rep);
    }

	public static ConceptSchemeBean generateConceptSchemeWithTextFormat(String[] concepts, String ...conceptToApplyTextFormat) {
		ConceptSchemeBean conceptScheme = TestConceptUtil.generateConceptScheme(concepts);
	
		ConceptSchemeMutableBean mutable = conceptScheme.getMutableInstance();

		for (String conceptId : conceptToApplyTextFormat) {
			ConceptMutableBean anItem = mutable.getItemById(conceptId);
			TextFormatMutableBean tf = new TextFormatMutableBeanImpl();
			tf.setPattern("[A-Z0-9]{1,255}");
			tf.setTextType(TEXT_TYPE.STRING);
			tf.setMultiLingual(TERTIARY_BOOL.TRUE);
			RepresentationMutableBean rep = new RepresentationMutableBeanImpl();
			rep.setTextFormat(tf);
			anItem.setCoreRepresentation(rep);
		}
	
		return mutable.getImmutableInstance();
	}
}
