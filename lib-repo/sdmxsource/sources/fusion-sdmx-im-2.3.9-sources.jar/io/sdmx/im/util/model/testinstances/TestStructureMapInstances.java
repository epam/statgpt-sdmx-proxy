package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.util.model.TestStructureMapUtil;

public class TestStructureMapInstances {

	/**
	 * @return maps COUNTRY to REF_AREA
	 */
	public static IStructureMapBean getSingleCompoentMap(String mapId, boolean includeRepMap) {
		IStructureMapMutableBean mapMutable = TestStructureMapUtil.generateMap(false);
		mapMutable.setId(mapId);
		TestStructureMapUtil.addComponentMap(mapMutable, "COUNTRY", "REF_AREA", true, false);
		return mapMutable.getImmutableInstance();
	}

	/**
	 * @return maps SEIES_CODE from the source to multiple targets (individually)
	 */
	public static IStructureMapBean getOne2ManySeriesCodeMap(String mapId, boolean includeRepMap) {
		IStructureMapMutableBean mapMutable = TestStructureMapUtil.generateMap(false);
		mapMutable.setId(mapId);
		TestStructureMapUtil.addComponentMap(mapMutable, "SERIES_CODE", "FREQ", includeRepMap, false);
		TestStructureMapUtil.addComponentMap(mapMutable, "SERIES_CODE", "REF_AREA", includeRepMap, false);
		TestStructureMapUtil.addComponentMap(mapMutable, "SERIES_CODE", "INDICATOR", includeRepMap, false);
		TestStructureMapUtil.addComponentMap(mapMutable, "SERIES_CODE", "DOMAIN", includeRepMap, false);

		return mapMutable.getImmutableInstance();
	}

	/**
	 * @return maps SEIES_CODE from the source to multiple targets in one rule
	 */
	public static IStructureMapBean getMultiTargetMapping(String mapId, boolean includeRepMap) {
		IStructureMapMutableBean mapMutable = TestStructureMapUtil.generateMap(false);
		mapMutable.setId(mapId);
		TestStructureMapUtil.addMultiTargetComponentMap(mapMutable, "SERIES_CODE", includeRepMap, "FREQ", "REF_AREA", "INDICATOR", "DOMAIN");
		return mapMutable.getImmutableInstance();
	}

	/**
	 * @return map with fixed source and fixed target
	 */
	public static IStructureMapBean getFixedValueMap(String mapId) {
		IStructureMapMutableBean smap = TestStructureMapUtil.generateMap(false).
				addFixedInput("REF_AREA", "UK").
				addFixedOutput("FREQ", "A");
		TestStructureMapUtil.addComponentMap(smap, "OBS_VALUE", "OBS_VALUE", false, false);
		return smap.getImmutableInstance();
	}
	
	
	/**
	 * @return map with epoch mapping (UNIX_TIME to TIME_PERIOD) output frequency is A
	 */
	public static IStructureMapBean getEpochMapOutputFreqId(String mapId) {
		IStructureMapMutableBean map = TestStructureMapUtil.generateMap(false);
		map.
		addEpochMap().
		setBasePeriod("1970").
		setEpochInterval(EPOCH.MILLISECOND).
		setSourceComponent("UNIX_TIME").
		setTargetComponent("TIME_PERIOD").
		setOutputFrequencyId("A");
		return map.getImmutableInstance();
	}
	
	/**
	 * @return map with epoch mapping (UNIX_TIME to TIME_PERIOD) - output the frequency based on the FREQ Dim
	 */
	public static IStructureMapBean getEpochMapOutputFreqDim(String mapId) {
		IStructureMapMutableBean map = TestStructureMapUtil.generateMap(false);
		map.
		addEpochMap().
		setBasePeriod("1970").
		setEpochInterval(EPOCH.MILLISECOND).
		setSourceComponent("UNIX_TIME").
		setTargetComponent("TIME_PERIOD").
		 setOutputFrequencyDimId("FREQ");
		return map.getImmutableInstance();
	}

	/**
	 * @return time pattern mapping, DD/MM/yyyy  and yy using the common output freq of A, and DD MM mapping to M
	 */
	public static IStructureMapBean getTimPatternMapping(String mapId) {
		IStructureMapMutableBean map = TestStructureMapUtil.generateMap(false);
		map.addTimePatternMap().setPattern("DD/MM/yyyy").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyId("A");
		map.addTimePatternMap().setPattern("yy").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyId("A");
		map.addTimePatternMap().setPattern("DD MM").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyId("M");
		return map.getImmutableInstance();
	}

	/**
	 * @return time pattern mapping, DD/MM/yyyy  and yy using the common output freq of A, and DD MM mapping to M
	 */
	public static IStructureMapBean getTimePatternMappingResolvePeriod(String mapId) {
		IStructureMapMutableBean map = TestStructureMapUtil.generateMap(false);
		map.addTimePatternMap().setPattern("DD/MM/yyyy").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyId("A").setPeriodResolution(PERIOD_POSITION.START_PERIOD);
		map.addTimePatternMap().setPattern("yy").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyDimId("FREQ").setPeriodResolution(PERIOD_POSITION.MID_PERIOD);
		map.addTimePatternMap().setPattern("DD MM").setSourceComponent("D1").setTargetComponent("TIME_PERIOD").setOutputFrequencyId("M").setPeriodResolution(PERIOD_POSITION.END_PERIOD);
		return map.getImmutableInstance();
	}

}
