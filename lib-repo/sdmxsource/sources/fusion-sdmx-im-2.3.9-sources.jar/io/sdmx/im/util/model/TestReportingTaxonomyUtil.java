package io.sdmx.im.util.model;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.im.mutable.categoryscheme.ReportingCategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;

public class TestReportingTaxonomyUtil {
	/**
	 * @param agency     category scheme agency
	 * @param id         category scheme id
	 * @param version    category scheme version
	 * @param categories array of code  ids, if an id contains a whitespace, then everything after the whitespace is the name, if there is no name
	 *                   then the name is the combination of id-name
	 * @return
	 */
	public static ReportingTaxonomyBean generateCategoryScheme(String agency, String id, String version, String... categories) {
		ReportingTaxonomyMutableBean mutable = new ReportingTaxonomyMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for (String catId : categories) {
			addCategory(mutable, catId);
		}
		return mutable.getImmutableInstance();
	}

	/**
	 * @param rt
	 * @param categoryId
	 * @param provisioningMetadata reference to a Dataflow or Metadataflow
	 * @return
	 */
	public static ReportingTaxonomyBean addProvisioningMetadata(ReportingTaxonomyBean rt, String categoryId, StructureReferenceBean provisioningMetadata) {
		ReportingTaxonomyMutableBean mutable = rt.getMutableInstance();
		ReportingCategoryMutableBean item = getReportingCategory(mutable, categoryId);
		item.addProvisioningMetadata(provisioningMetadata);
		return mutable.getImmutableInstance();
	}

	/**
	 * @param rt
	 * @param categoryId
	 * @param structuralMetadata reference to DSD or MSD
	 * @return
	 */
	public static ReportingTaxonomyBean addStructuralMetadata(ReportingTaxonomyBean rt, String categoryId, StructureReferenceBean structuralMetadata) {
		ReportingTaxonomyMutableBean mutable = rt.getMutableInstance();
		ReportingCategoryMutableBean item = getReportingCategory(mutable, categoryId);
		item.addStructuralMetadata(structuralMetadata);
		return mutable.getImmutableInstance();
	}

	public static ReportingCategoryMutableBean getReportingCategory(ReportingTaxonomyMutableBean rt, String itemId) {
		String[] split = itemId.split("\\.");
		return getReportingCategory(rt.getItems(), split, 0);
	}

	private static ReportingCategoryMutableBean getReportingCategory(List<ReportingCategoryMutableBean> items, String[] itemId, int depth) {

		String procId = itemId[depth];
		int nextDepth = depth + 1;
		for (ReportingCategoryMutableBean step : items) {
			if (step.getId().equals(procId)) {
				if (nextDepth < itemId.length) {
					return getReportingCategory(step.getItems(), itemId, nextDepth);
				}
				return step;
			}
		}
		throw new IllegalArgumentException("Process Step not found: " + procId);
	}

	private static ReportingCategoryMutableBean addCategory(ReportingTaxonomyMutableBean mutable, String catId) {
		ReportingCategoryMutableBean item = new ReportingCategoryMutableBeanImpl();

		String[] split = catId.split(" ", 2);

		String hCodeId = split[0];
		hCodeId = hCodeId.contains(".") ? hCodeId.substring(hCodeId.lastIndexOf(".") + 1) : hCodeId;

		String catName = split.length > 1 ? split[1] : hCodeId + "-name";

		TestMaintainableUtil.setNameableProperties(item, hCodeId, catName);

		if (!catId.contains(".")) {
			mutable.addItem(item);
		} else {
			String parentId = catId.substring(0, catId.lastIndexOf("."));

			List<ReportingCategoryMutableBean> cats = mutable.getItems();
			ReportingCategoryMutableBean parent = null;
			for (String currentParentId : parentId.split("\\.")) {
				for (ReportingCategoryMutableBean possibleParent : cats) {
					if (possibleParent.getId().equals(currentParentId)) {
						parent = possibleParent;
						cats = parent.getItems();
						break;
					}
				}
			}
			if (parent != null) {
				parent.addItem(item);
			}
		}
		return item;
	}
}
