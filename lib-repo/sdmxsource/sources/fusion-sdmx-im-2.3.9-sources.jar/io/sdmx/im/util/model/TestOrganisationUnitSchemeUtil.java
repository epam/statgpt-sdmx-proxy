package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;

public class TestOrganisationUnitSchemeUtil {

	public static OrganisationUnitSchemeBean generateOrganisationUnitScheme(String agencyId, String id, String version, String...unitIds) {
		OrganisationUnitSchemeMutableBean mutable = new OrganisationUnitSchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agencyId, id, version);
		for(String unitId : unitIds) {
			String name = unitId.contains(" ") ? unitId.split(" ", 2)[1] : unitId;
			unitId = unitId.contains(" ") ? unitId.split(" ", 2)[0] : unitId;
			
			String parentId = null;
			if(unitId.contains(".")) {
				String[] split = unitId.split("\\.");
				parentId = split[0];
				unitId = split[1];
			}
			OrganisationUnitMutableBean unitBean = mutable.createItem(unitId, name);
			unitBean.setParentUnit(parentId);
		}
		return mutable.getImmutableInstance();
	}
	
}
