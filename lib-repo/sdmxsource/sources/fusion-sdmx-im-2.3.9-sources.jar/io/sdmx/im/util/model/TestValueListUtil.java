package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;

public class TestValueListUtil {
	
	
	public static ValueListBean generateValuelist(String agency, String id, String version, String...values) {
		ValueListMutableBean mutable = new ValueListMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String codeId : values) {
			ValueItemMutableBean item = new ValueItemMutableBeanImpl();
			String[] split = codeId.split(" ", 2);
			String codeName = codeId.length() > 1 ? split[1] : codeId+"-name";
			item.addName("en", codeName);
			item.setId(split[0]);
			mutable.addItem(item);
		}
		return mutable.getImmutableInstance();
	}
}
