package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.im.mutable.metadatastructure.MetadataProvisionAgreementMutableBean;

public class TestMetadataProvisionUtil {
	
	
	/**
	 * Generates a metadata provision  of version 1.0.0  and id flowId_providerId
	 * @param agencyId provision agency
	 * @param flowId id of metadata flow, same agency as provision
	 * @param providerId provider id, same agency as provision
	 * @return
	 */
	public static MetadataProvisionAgreementBean generateProvision(String agencyId, String flowId, String providerId, StructureReferenceBean... targets) {
		IMetadataProvisionAgreementMutableBean pa = new MetadataProvisionAgreementMutableBean();
		TestMaintainableUtil.setMaintainableProperties(pa, agencyId, flowId+"_"+providerId, "1.0.0");
		pa.setMetadataflowRef(new StructureReferenceBeanImpl(agencyId, flowId, "1.0.0", SDMX_STRUCTURE_TYPE.METADATA_FLOW));
		pa.setMetadataProviderRef(new StructureReferenceBeanImpl(agencyId, "METADATA_PROVIDERS", "1.0", SDMX_STRUCTURE_TYPE.METADATA_PROVIDER, providerId));
		if(targets != null) {
			for(StructureReferenceBean target : targets) {
				pa.addTarget(target);
			}
		}
		return pa.getImmutableInstance();
	}
	
}
