package io.sdmx.im.util.model;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;

public class TestCategorySchemeUtil {
	/**
	 * @param agency category scheme agency
	 * @param id category scheme id
	 * @param version category scheme version
	 * @param categories array of code  ids, if an id contains a whitespace, then everything after the whitespace is the name, if there is no name
	 * then the name is the combination of id-name
	 * @return
	 */
	public static CategorySchemeBean generateCategoryScheme(String agency, String id, String version, String...categories) {
		CategorySchemeMutableBean mutable = new CategorySchemeMutableBeanImpl();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String catId : categories) {
			addCategory(mutable, catId);
		}
		return mutable.getImmutableInstance();
	}
	
	private static void addCategory(CategorySchemeMutableBean mutable, String catId) {
		CategoryMutableBean item = new CategoryMutableBeanImpl();
		String[] split = catId.split(" ", 2);
		
		String hCodeId = split[0];
		hCodeId = hCodeId.contains(".") ? hCodeId.substring(hCodeId.lastIndexOf(".")+1) : hCodeId;
		
		String catName = split.length > 1 ? split[1] : hCodeId+"-name";

		TestMaintainableUtil.setNameableProperties(item, hCodeId, catName);
		
		if(!catId.contains(".")) {
			mutable.addItem(item);
		} else {
			String parentId = catId.substring(0, catId.lastIndexOf("."));
			
			List<CategoryMutableBean> cats = mutable.getItems();
			CategoryMutableBean parent = null;
			for(String currentParentId : parentId.split("\\.")) {
				for(CategoryMutableBean possibleParent : cats) {
					if(possibleParent.getId().equals(currentParentId)) {
						parent = possibleParent;
						cats = parent.getItems();
						break;
					}
				}
			}
			if (parent != null) {
				parent.addItem(item);
			}
		}
	}
}
