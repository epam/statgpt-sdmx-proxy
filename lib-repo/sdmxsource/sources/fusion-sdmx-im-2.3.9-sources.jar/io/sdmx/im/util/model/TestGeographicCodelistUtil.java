package io.sdmx.im.util.model;

import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.im.mutable.codelist.GeoFeatureSetCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeographicCodelistMutableBean;

public class TestGeographicCodelistUtil {
	
	
	/**
	 * 
	 * @param agency
	 * @param id
	 * @param version
	 * @param gridDefinition
	 * @param geoCodes  id:featureset pair
	 * @return
	 */
	public static IGeographicCodelistBean generateCodelist(String agency, String id, String version, String...geoCodes) {
		IGeographicCodelistMutableBean mutable = new GeographicCodelistMutableBean();
		TestMaintainableUtil.setMaintainableProperties(mutable, agency, id, version);
		for(String codeId : geoCodes) {
			addCode(mutable, codeId);
		}
		return mutable.getImmutableInstance();
	}

	/**
	 * @param mutable
	 * @param codeId codeid:geocell pair
	 * @return
	 */
	private static IGeoFeatureSetCodeMutableBean addCode(IGeographicCodelistMutableBean mutable, String codeId) {
		IGeoFeatureSetCodeMutableBean item = new GeoFeatureSetCodeMutableBean();
		
		
		String[] idSplit = codeId.split(":");
		
		codeId = idSplit[0];
		String[] splitOnDot = codeId.split("\\.", 2);
		codeId = splitOnDot[splitOnDot.length-1];
		if(splitOnDot.length > 1) {
			item.setParentCode(splitOnDot[0]);
		}
		
		item.setGeoFeatureSet(idSplit[1]);
		String[] split = codeId.split(" ", 2);
		String codeName = split.length > 1 ? split[1] : codeId+"-name";
		TestMaintainableUtil.setNameableProperties(item, split[0], codeName);
		mutable.addItem(item);
		return item;
	}
}
