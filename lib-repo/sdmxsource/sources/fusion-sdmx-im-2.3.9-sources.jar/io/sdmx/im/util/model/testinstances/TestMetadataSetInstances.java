package io.sdmx.im.util.model.testinstances;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.im.util.model.TestMetadataSetUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class TestMetadataSetInstances {
	
	public static IReportedMetadataSetBean getDataflowReportAgainstProvision() {
		IURN urn = URN.getInstance("urn:sdmx:org.sdmx.infomodel.registry.MetadataProvisionAgreement=ACY:MDF_DP3(1.0.0)");
		return TestMetadataSetInstances.getDataQualityReport(urn, new StructureReferenceBeanImpl("IMF", "BOP", "1.0.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
	}

	/**
	 * @param urn metadata provision or metadataflow reported against
	 * @param targets 1 or more targets this report is for
	 * @return
	 */
	public static IReportedMetadataSetBean getDataQualityReport(IURN urn, StructureReferenceBean... targets) {
		return getDataQualityReport("TEST", urn, targets);
	}
	
	/**
     * @param urn metadata provision or metadataflow reported against
     * @param targets 1 or more targets this report is for
     * @return
     */
    public static IReportedMetadataSetBean getDataQualityReport(String agencyId, IURN urn, StructureReferenceBean... targets) {
        return TestMetadataSetUtil.createMetadataSet(agencyId, "DQAF", urn, CollectionUtil.getImmutableList(targets),
                
                "QUALITY",
                "QUALITY.LEGAL:en=The responsibility for collecting, processing, and",
                "QUALITY.RESOURCE:en=Staff, facilities, computing resources, and financing",
                "QUALITY.RELEVANCE:en=The relevance and practical utility of existing statistics",
                "INTEGRITY",
                "INTEGRITY.INST:en=Statistics are produced on an impartial basis",
                "INTEGRITY.TRANSPARENCY:en=The terms and conditions under which statistics are collected, processed, and disseminated are available to the public.",
                "INTEGRITY.ETHICAL:en=Guidelines for staff behavior are in place and are well known to the staff",
                "METHODOLOGY",
                "METHODOLOGY.SCOPE:en=The scope is broadly consistent with internationally accepted standards, guidelines or good practices",
                "METHODOLOGY.CLASSIFICATION:en=systems used are broadly consistent with internationally accepted standard",
                "METHODOLOGY.BASIS:en=Market prices are used to value flows and stocks.",
                "METHODOLOGY.SOURCE:IMF");
    }
	
}
