package io.sdmx.im.util.model;

import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorSchemeMutableBean;

public class TestUserDefinedOperatorSchemeUtil {

	public static IUserDefinedOperatorSchemeMutableBean create(String agencyId, String id, String version, String vtlVersion) {
		IUserDefinedOperatorSchemeMutableBean mutable = new UserDefinedOperatorSchemeMutableBean();
		mutable.setAgencyId(agencyId);
		mutable.setId(id);
		mutable.setVersion(version);
		mutable.setVtlVersion(vtlVersion);
		mutable.addName("en", id+ " Name");
		return mutable;
	}
	
	/**
	 * Creates a maintainable which has all transformation bean specific properties set
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param vtlVersion
	 * @return
	 */
	public static IUserDefinedOperatorSchemeMutableBean createComplete(String agencyId, String id, String version, String vtlVersion) {
		IUserDefinedOperatorSchemeMutableBean mutable = TestUserDefinedOperatorSchemeUtil.create(agencyId, id, version, vtlVersion);

		mutable.addUserDefinedOperator("OP1", "operator1").addName("en", "N1");
		mutable.addUserDefinedOperator("OP2", "operator2").addName("en", "N2");
		
		mutable.setVtlMappingSchemeRef(new StructureReferenceBeanImpl("SDMX", "VMS", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
		mutable.addRulesetSchemeRef(new StructureReferenceBeanImpl("SDMX", "RS1", "1.0.0", SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
		mutable.addRulesetSchemeRef(new StructureReferenceBeanImpl("SDMX", "RS2", "2.0.0", SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
		return mutable;
	}
	
}
