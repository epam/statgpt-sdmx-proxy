package io.sdmx.im.changecontrol;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class MaintainableMutableBeanWrapper {
    private MaintainableMutableBean maint;
    private String oldId;
    private String oldAgencyId;
    private String oldVersion;
    
    public MaintainableMutableBeanWrapper(MaintainableMutableBean maint) {
        this.maint = maint;
    }
    
    public MaintainableMutableBean getMaintainableMutableBean() {
        return maint;
    }
    
    public void setOldId(String oldId) {
        this.oldId = oldId;
    }
    
    public void setOldAgencyId(String oldAgencyId) {
        this.oldAgencyId = oldAgencyId;
    }
    
    public void setOldVersion(String oldVersion) {
        this.oldVersion = oldVersion;
    }
    
    /**
     * Returns the previous structure reference for the maintainable, this can be used to determine if the maintainable has
     * had its agency id, id or version changed
     * 
     * returns null if the previous structure reference does not exist, or if it is the same as this reference
     * 
     * @return
     */
    public IURNMaintainable<?> obtainOldReference() {
        // A new reference should be created IF there is an OLD value different from a new value.
        // Remember old values can be null.
        
        if (ObjectUtil.validString(this.oldId) && (!maint.getId().equals(this.oldId)) ||
            ObjectUtil.validString(this.oldAgencyId) && (!maint.getAgencyId().equals(this.oldAgencyId)) ||
            ObjectUtil.validString(this.oldVersion) && (!maint.getVersion().equals(this.oldVersion))) {
        
            String id = ObjectUtil.validString(this.oldId) ? this.oldId : maint.getId();
            String agencyId = ObjectUtil.validString(this.oldAgencyId) ? this.oldAgencyId : maint.getAgencyId();
            String version = ObjectUtil.validString(this.oldVersion) ? this.oldVersion: maint.getVersion();
            return URN.builder().agencyId(agencyId).maintId(id).version(version).structure(maint.getStructureType()).buildMaintainable();
        }
        return null;
    }
}
