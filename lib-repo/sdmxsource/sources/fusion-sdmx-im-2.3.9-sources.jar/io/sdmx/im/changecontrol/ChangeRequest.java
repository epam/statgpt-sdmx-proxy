package io.sdmx.im.changecontrol;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public class ChangeRequest {

    private Map<IURNMaintainable<?>, IMaintainableProperties> mapOfMaints;   // Original to New
    
    public ChangeRequest() {
        mapOfMaints = new HashMap<>();
    }
    
    public void addMaintainable(IURNMaintainable<?> existingObject, IMaintainableProperties newObject) {
    	if(!existingObject.getAbsoluteVersion().isTwoPart()) {
    		return;
    	}
    	if(!newObject.getVersion().isTwoPart()) {
    		return;
    	}
        mapOfMaints.put(existingObject, newObject);
    }

    public Map<IURNMaintainable<?>, IMaintainableProperties> getModifiedMaintainables() {
        return mapOfMaints;
    }
}