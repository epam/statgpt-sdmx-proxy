package io.sdmx.im.changecontrol;

import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public class ChangeRequestHelper {
	
    public static void determineChanges(MaintainableMutableBeanWrapper mmbWrapper) {
    	IURNMaintainable<?> sRef = mmbWrapper.obtainOldReference();
        if (sRef != null) {
            ChangeRequest cr = (ChangeRequest)ThreadLocalUtil.retrieveFromThread("CHANGE_REQUEST");
            if(cr != null) {
                MaintainableMutableBean maint = mmbWrapper.getMaintainableMutableBean();
                IMaintainableProperties mRef = MaintainableProperties.getInstance(
                        maint.getAgencyId(),
                        maint.getId(),
                        maint.getVersion());
                
                cr.addMaintainable(sRef, mRef);
            }
        }
    }
    
}
