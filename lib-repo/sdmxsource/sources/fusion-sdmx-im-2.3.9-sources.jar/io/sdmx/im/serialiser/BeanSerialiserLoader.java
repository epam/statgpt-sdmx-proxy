package io.sdmx.im.serialiser;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.IDeferred;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanWriter;
import io.sdmx.utils.core.io.PathUtil;

/**
 * Stores beans as serialised files on the file system, and loads them back in from the file system on demand
 */
public class BeanSerialiserLoader implements IDeferredBeanWriter {
    private static final Logger LOG = LoggerFactory.getLogger(BeanSerialiserLoader.class);

    private final Path rootFolder;

    public static BeanSerialiserLoader INSTANCE = new BeanSerialiserLoader();

    protected BeanSerialiserLoader() {
        this(new File(System.getProperty("java.io.tmpdir")).toPath());
    }

    public BeanSerialiserLoader(Path rootFolder) {
        this.rootFolder = rootFolder;
    }

    @Override
    public void write(MaintainableBean deferrable) {
        Path p = getPath(deferrable);
        try (ObjectOutputStream oos =
                new ObjectOutputStream(PathUtil.getOutputStream(p, false))) {
            oos.writeObject(deferrable);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public MaintainableBean load(IDeferred<MaintainableBean> deferred) {
        return deserialise((IMaintainableBeanDeferred)deferred);
    }

    public void close(MaintainableBean maint) {
        Path p = getPath(maint);

        if(p != null) {
            PathUtil.deleteFile(p);
        }
    }

    private MaintainableBean deserialise(MaintainableBean deferred) {
        Path p = getPath(deferred);
        
        if(!Files.exists(p)) {
            return null;
        }
        LOG.debug("deserialise: " +deferred.getUrn());
        try {
            try (ObjectInputStream ois =
                    new ObjectInputStream(new BufferedInputStream(PathUtil.toStream(getPath(deferred))))) {
                return (MaintainableBean) ois.readObject();
            }
        } catch(IOException e) {
            try {
                Files.deleteIfExists(p);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected Path getPath(MaintainableBean maint) {
        return rootFolder.resolve(maint.getChecksum());
    }
}
