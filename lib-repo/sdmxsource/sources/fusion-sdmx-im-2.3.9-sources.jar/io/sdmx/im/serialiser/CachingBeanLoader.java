package io.sdmx.im.serialiser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.IDeferred;
import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanWriter;

/**
 * Proxies a {@link IDeferredLoader} which holds the original source of the bean, this class then provides
 * a caching layer on top by writing a serialised copy of the bean to the file system. When the bean is re-requested
 * this cache layer will first check the file system for a fast deseialisation.
 */
public class CachingBeanLoader implements IDeferredLoader<MaintainableBean> {
    private static final Logger LOG = LoggerFactory.getLogger(CachingBeanLoader.class);
    
    private IDeferredLoader<MaintainableBean> proxy;
    private IDeferredBeanWriter writer;

    public CachingBeanLoader(IDeferredLoader<MaintainableBean> proxy, IDeferredBeanWriter writer) {
        this.proxy = proxy;
        this.writer = writer;
        
    }
    @Override
    public MaintainableBean load(IDeferred<MaintainableBean> deferred) {
        MaintainableBean toReturn = writer.load(deferred);
        if(toReturn == null) {
            toReturn = proxy.load(deferred);
            serialise(toReturn);
        }
        return toReturn;

    }

    private void serialise(MaintainableBean maint) {
        writer.write(maint);
    }

}
