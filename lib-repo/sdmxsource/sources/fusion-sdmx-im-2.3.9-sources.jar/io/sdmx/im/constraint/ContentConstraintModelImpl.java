package io.sdmx.im.constraint;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.PeriodContents;
import io.sdmx.api.date.PeriodsContainer;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorTranslatorToList;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.im.superbeans.SuperBeansUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.PeriodSetContents;
import io.sdmx.utils.core.date.PeriodsContainerImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.reflection.AbstractObjectProxy;
import io.sdmx.utils.core.regex.RegexUtil;

/**
 * Builds a picture of what is valid, and what is invalid with regards to ContentConstraintBean
 */
public class ContentConstraintModelImpl implements ContentConstraintModel {
	private ContentConstraintBean constraintBean;
	
	private SdmxPeriod sdmxPeriod;
	private Map<String, Set<String>> filterConceptValues;
	private Map<String, Set<String>> onlyAllowConceptValues;

	private Set<ConstrainedDataKeyBean> allowedSeries = new HashSet<>();

	//For non-enumerated components which include wildcarded rules
	private Map<String, Set<Pattern>> filterConceptTextValues;
	private Map<String, Set<Pattern>> onlyAllowConceptTextValues;

	private Set<String> includeSeries; //Fully qualified series
	private Set<String> excludeSeries; //Fully qualified series

	private Set<Pattern> includeWildcardSeries; //A list of patterns for inclusion
	private Set<Pattern> excludeWildcardSeries; //A list of patterns for exclusion

	private boolean acceptNothing;
	private boolean allowWildcardSeriesMatch;  //If true then the input series A:*:C will return true against the series constraint A:B:C

	private DataStructureSuperBean dataStructureBean;  //FR-3736 - only report a constraint error if it is a valid code in the first place
	private Map<String, String> removePrefixes;  //Store the prefixes which have been removed for this constraint (discriminated union)


	//A local cache of what has been constrained
	private Map<KeyValue, Boolean> constrainedCache = new WeakHashMap<>();

	/**
	 * A map of key value (i.e FREQ:A) to other valid key values i.e. REF_AREA:UK, REF_AREA:DE, INDICATOR:A
	 */
	private Map<KeyValue, Set<KeyValue>> validRows; 
	private Map<KeyValue, Set<KeyValue>> inValidRows;
	

	private Set<String> seriesSubStrings;

	/**
	 * Builds one or more constraint models, broken down by time period (cube region codes in a constraint have independent time periods)
	 * @param constraintBean
	 * @param dataStructureBean
	 * @param allowWildcardSeriesMatch
	 * @return
	 */
	public static Set<ContentConstraintModel> build(ContentConstraintBean constraintBean, DataStructureSuperBean dataStructureBean, boolean allowWildcardSeriesMatch) {
		ConstraintPrefixCleaned cleanConstraint = new ConstraintPrefixCleaned(constraintBean, dataStructureBean);
		constraintBean = cleanConstraint.getCleaned();

		dataStructureBean = SuperBeansUtil.removeCodeIdPrefixes(dataStructureBean, cleanConstraint.getRemovePrefixes());
		Set<ContentConstraintModel> returnSet = new HashSet<>();

		//Build Container for Key Values (Cube Constraints)
		if(constraintBean.getExcludedCubeRegion() != null || constraintBean.getIncludedCubeRegion() != null) {
			constructCubeConstraintModels(cleanConstraint, dataStructureBean, returnSet);
		}
		if(constraintBean.getExcludedSeriesKeys() != null || constraintBean.getIncludedSeriesKeys() != null) {
			constructSeriesConstraintModels(cleanConstraint, dataStructureBean, returnSet, allowWildcardSeriesMatch);
		}
		return returnSet;
	}

	private static void constructCubeConstraintModels(ConstraintPrefixCleaned cleanConstraint, DataStructureSuperBean dataStructureBean, Set<ContentConstraintModel> returnSet) {
		ContentConstraintBean constraintBean = cleanConstraint.getCleaned();
		PeriodsContainer<Map<KeyValues, Set<String>>> container = PeriodsContainerImpl.getMapContainer(true);

		if(constraintBean.getExcludedCubeRegion() != null) {
			addKeyValuesToContainer(container, constraintBean.getExcludedCubeRegion().getKeyValues());
			addKeyValuesToContainer(container, constraintBean.getExcludedCubeRegion().getAttributeValues());
		}

		if(constraintBean.getIncludedCubeRegion() != null) {
			addKeyValuesToContainer(container, constraintBean.getIncludedCubeRegion().getKeyValues());
			addKeyValuesToContainer(container, constraintBean.getIncludedCubeRegion().getAttributeValues());
		}


		for(SdmxPeriod currentPeriod : container.getPeriods()) {
			Map<KeyValues, Set<String>> periodContents = container.getContents(currentPeriod);
			returnSet.add(new ContentConstraintModelImpl(cleanConstraint, periodContents, dataStructureBean, currentPeriod));
		}
	}

	private static void constructSeriesConstraintModels(ConstraintPrefixCleaned cleanConstraint, DataStructureSuperBean dataStructureBean, Set<ContentConstraintModel> returnSet, boolean allowWildcardSeriesMatch) {
		//Build Container for Series Constraints
		ContentConstraintBean constraintBean = cleanConstraint.getCleaned();
		PeriodContents<Set<ConstrainedDataKeyBean>> seriesContents = new PeriodSetContents<>();
		PeriodsContainer<Set<ConstrainedDataKeyBean>> seriesContainer = new PeriodsContainerImpl<>(seriesContents);
		if(constraintBean.getExcludedSeriesKeys() != null) {
			addSeriesKeysToContainer(seriesContainer, constraintBean.getExcludedSeriesKeys().getConstrainedDataKeys());
		}
		if(constraintBean.getIncludedSeriesKeys() != null) {
			addSeriesKeysToContainer(seriesContainer, constraintBean.getIncludedSeriesKeys().getConstrainedDataKeys());
		}
		for(SdmxPeriod currentPeriod : seriesContainer.getPeriods()) {
			Set<ConstrainedDataKeyBean> keyValues = seriesContainer.getContents(currentPeriod);
			returnSet.add(new ContentConstraintModelImpl(cleanConstraint, keyValues, dataStructureBean, allowWildcardSeriesMatch, currentPeriod));
		}
	}

	private static void addKeyValuesToContainer(PeriodsContainer<Map<KeyValues, Set<String>>> container, List<KeyValues> keyValues) {
		Map<SdmxPeriod, Map<KeyValues, Set<String>>> kvsForPeriod = new HashMap<>();

		for(KeyValues kvs : keyValues) {
			addValuesForPeriodToMap(kvs, kvsForPeriod, kvs.getValues());
			addValuesForPeriodToMap(kvs, kvsForPeriod, kvs.getCascadeExcludeRoot());
		}
		for(SdmxPeriod period : kvsForPeriod.keySet()) {
			container.addContents(kvsForPeriod.get(period), period);
		}
	}

	private static void addValuesForPeriodToMap(KeyValues kvs, Map<SdmxPeriod, Map<KeyValues, Set<String>>> kvsForPeriod , Set<String> values) {
		for(String value : values) {
			SdmxPeriod period = kvs.getValidityPeriod(value);
			Map<KeyValues, Set<String>> map = kvsForPeriod.get(period);
			if(map == null) {
				map = new HashMap<>();
				kvsForPeriod.put(period, map);
			}
			CollectionUtil.addToMappedSet(map, kvs, value);
		}
	}

	private static void addSeriesKeysToContainer(PeriodsContainer<Set<ConstrainedDataKeyBean>> container, List<ConstrainedDataKeyBean> keyValues) {
		//TODO Wait for the SDMX 3.0 model to be confirmed (where is the period being defined) and then complete this method
		for(ConstrainedDataKeyBean kvs : keyValues) {
			Set<ConstrainedDataKeyBean> contents = new HashSet<>(1);
			contents.add(kvs);
			container.addContents(contents, SdmxPeriodImpl.ALL_PERIODS);
		}
	}

	private ContentConstraintModelImpl(ConstraintPrefixCleaned constraintBean, Map<KeyValues, Set<String>> codesForPeriod, DataStructureSuperBean dsd, SdmxPeriod validityPeriod) {
		createCubeFilterMaps(dsd, codesForPeriod);
		postSetUpFilterConcepts();
		sdmxPeriod = validityPeriod;
		this.dataStructureBean = dsd;
		this.constraintBean = constraintBean.getOrigninal();
		this.removePrefixes = constraintBean.getRemovePrefixes();
	}

	private ContentConstraintModelImpl(ConstraintPrefixCleaned constraintBean, Set<ConstrainedDataKeyBean> seriesValues, DataStructureSuperBean dsd, boolean allowWildcardSeriesMatch, SdmxPeriod validityPeriod) {
		this.allowWildcardSeriesMatch = allowWildcardSeriesMatch;
		createSeriesFilterMaps(dsd, seriesValues);
		postSetUpFilterConcepts();
		sdmxPeriod = validityPeriod;
		this.dataStructureBean = dsd;
		this.constraintBean = constraintBean.getOrigninal();
		this.removePrefixes = constraintBean.getRemovePrefixes();
		
		for(ConstrainedDataKeyBean currentKey : seriesValues) {
			if(currentKey.isIncluded()) {
				allowedSeries.add(currentKey);
			}
		}
	}
	
	@Override
	public ContentConstraintBean getBuiltFrom() {
		return this.constraintBean;
	}

	@Override
	public Map<String, String> getRemovePrefixes() {
		return this.removePrefixes;
	}

	@Override
	public SdmxPeriod getValidityPeriod() {
		return sdmxPeriod;
	}

	@Override
	public boolean hasValidityPeriod() {
		return sdmxPeriod != null && !sdmxPeriod.isAllPeriods();
	}

	@Override
	public boolean isBusinessValidity() {
		return false;   //TODO Reimplement this //constraint.isBusinessValidity();
	}


	@Override
	public Set<String> getValidValues(String dimId) {
		if (onlyAllowConceptValues == null) {
			return null;
		}

		Set<String> validValues = onlyAllowConceptValues.get(dimId);
		if(validValues != null) {
			return Collections.unmodifiableSet(validValues);
		}
		return null;
	}

	@Override
	public Set<String> getExcludedValues(String dimId) {
		if (filterConceptValues == null) {
			return null;
		}

		Set<String> filterValues = filterConceptValues.get(dimId);
		if(filterValues != null) {
			return Collections.unmodifiableSet(filterValues);
		}
		return null;
	}

	@Override
	public boolean isConstrainingDimensionValues(String dimId) {
		if(filterConceptValues != null && filterConceptValues.containsKey(dimId)) {
			return true;
		}
		if(onlyAllowConceptValues != null && onlyAllowConceptValues.containsKey(dimId)) {
			return true;
		}
		return false;
	}

	/**
	 * Creates a partial Codelist for the Component [dimId] based on the constraint model, if there are no constraints on this codelist
	 * then there will be no changes made
	 */
	@Override
	public EnumeratedListBean createPartialCodelist(String dimId, EnumeratedListBean<? extends EnumeratedItemBean> codelist) {
		if(!isConstrainingDimensionValues(dimId)) {
			return codelist;
		}

		Set<String> keepSet = new HashSet<>();
		for(EnumeratedItemBean enumItem : codelist.getItems()) {
			if(!isConstrainedCode(dimId, enumItem.getId())) {
				keepSet.add(enumItem.getId());
			}
		}
		return codelist.filterItems(keepSet, true);
	}

	@Override
	public void filterDimensionValues(String dimId, Set<String> dimensionValues) {
		if(dimensionValues == null) {
			return;
		}
		if(filterConceptValues != null && filterConceptValues.containsKey(dimId)) {
			dimensionValues.removeAll(filterConceptValues.get(dimId));
		}
		if(onlyAllowConceptValues != null && onlyAllowConceptValues.containsKey(dimId)) {
			Set<String> keepCodes =  onlyAllowConceptValues.get(dimId);
			dimensionValues.retainAll(keepCodes);
		}
	}

	@Override
	public boolean isValidObservation(Observation obs) {
		return !ObjectUtil.validCollection(validateObservation(obs));
	}

	@Override
	public void validateObservation(Observation obs, DataValidationEngineErrorHandler eh) {
		if(acceptNothing) {
			FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_NO_OBS_FOR_DATASET);
			eh.reportError(fe, (KeyValue)null);
		}
		verifyKeyValue(obs.getSeriesKey(), obs.getAttributes(), false, eh);
		if(obs.getDimensionId() != null) {
			//FR-5047 Allow Cube Region Constraints to restrict on the Time Series
			if (isConstrainedCode(obs.getDimensionId(), obs.getDimensionValue())) {
				String dimId = obs.getDimensionId();
				FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_DISALLOWED_VALUE, dimId, dimId, obs.getDimensionValue());
				eh.reportError(fe, KeyValueImpl.getInstance(dimId, obs.getDimensionValue()));
			}
		}
	}
	
	@Override
	public List<String> validateObservation(Observation obs) {
		ErrorTranslatorToList ehToList = new ErrorTranslatorToList();
		validateObservation(obs, ehToList);
		return ehToList.getErrorMessages();
	}

	@Override
	public boolean isValidKey(Keyable key) {
		return !ObjectUtil.validCollection(validateKey(key));
	}



	@Override
	public List<String> validateKey(Keyable key) {
		ErrorTranslatorToList ehToList = new ErrorTranslatorToList();
		validateKey(key, ehToList);
		return ehToList.getErrorMessages();
	}

	@Override
	public void validateKey(Keyable key, DataValidationEngineErrorHandler eh) {
		if(acceptNothing) {
			FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_NO_SERIES_FOR_DATASET);
			eh.reportError(fe, (KeyValue) null);
		}
		//2. Check if each individual key value is okay to write
		verifyKeyValue(key, key.getAttributes(), false, eh);

		if(verifyKeyValue(key, key.getKey(), true, eh)) {
			//Only perform series validation if no errors were detected already in the key
			if(includeSeries != null || excludeSeries != null || validRows != null || inValidRows != null) {
				if(!isValidShortCode(key.getShortCode())) {
					if(key.isSeries()) {
						FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_SERIES_CONTAINS_RESTRICTED_VALUES);
						eh.reportError(fe, (KeyValue)null);
					} else {
						FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_GROUP_CONTAINS_RESTRICTED_VALUES, key.getGroupName());
						eh.reportError(fe, (KeyValue)null);
					}
				}
			}
		}
	}
	
//	public void validateKeyOLD(Keyable key, DataValidationEngineErrorHandler eh) {
//		if(acceptNothing) {
//			FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_NO_SERIES_FOR_DATASET);
//			eh.reportError(fe, null);
//		}
//		//2. Check if each individual key value is okay to write
//		verifyKeyValue(key, key.getAttributes(), false, eh);
//
//		if(verifyKeyValue(key, key.getKey(), true, eh)) {
//			//Only perform series validation if no errors were detected already in the key
//			if(includeSeries != null || excludeSeries != null || includeWildcardSeries != null || excludeWildcardSeries != null) {
//				if(!isValidShortCode(key.getShortCode())) {
//					if(key.isSeries()) {
//						FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_SERIES_CONTAINS_RESTRICTED_VALUES);
//						eh.reportError(fe, null);
//					} else {
//						FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_GROUP_CONTAINS_RESTRICTED_VALUES, key.getGroupName());
//						eh.reportError(fe, null);
//					}
//				}
//			}
//		}
//	}

	/**
	 * Returns true if the KeyValue(s) are included (or not excluded) by the ContentConstraint.
	 * @param keyValues
	 * @return
	 */
	private boolean verifyKeyValue(Keyable key, Collection<KeyValue> keyValues, boolean isSeries, DataValidationEngineErrorHandler eh) {
		boolean returnValue = true;
		if(filterConceptValues != null || onlyAllowConceptValues != null || filterConceptTextValues != null || onlyAllowConceptTextValues != null) {
			for(KeyValue kv : keyValues) {
				if(!verifyKeyValue(key, kv, isSeries, eh)) {
					returnValue = false;
				}
			}
		}
		return returnValue;
	}

	/**
	 *
	 * @param key
	 * @param kv
	 * @param isSeries true if this is validating a series key value, false if it's an attribute value
	 * @return true if it is valid
	 */
	private boolean verifyKeyValue(Keyable key, KeyValue kv, boolean isSeries, DataValidationEngineErrorHandler eh) {
		if(isConstrainedKeyValue(kv)) {
			String component = isSeries ? "Dimension" : "Attribute";
			FusionError fe = new FusionErrorImpl(DataErrorCode.CONSTRAINT_DISALLOWED_VALUE, component, kv.getConcept(), kv.getCode());
			eh.reportError(fe, kv);
			return false;
		}
		return true;
	}

	/**
	 *
	 * @param key
	 * @param kv
	 */
	@Override
	public boolean isConstrainedKeyValue(KeyValue kv) {
		Boolean isConstrained = constrainedCache.get(kv);
		if(isConstrained != null) {
			return isConstrained;
		}
		isConstrained = isConstrainedCodeInternal(kv.getConcept(), kv.getCode());
		constrainedCache.put(kv, isConstrained);
		return isConstrained;
	}

	@Override
	public boolean isConstrainedCode(String concept, String code) {
		return isConstrainedKeyValue(KeyValueImpl.getInstance(concept, code));
	}

	private boolean isConstrainedCodeInternal(String concept, String code) {
		//FR-3736 We only want to report codes that have been constrained, not those that are not in the underlying codelist
		ComponentSuperBean component = dataStructureBean.getComponentById(concept);
		if(component == null) {
			return false;
		}
		EnumeratedListBean<EnumeratedItemBean> codelist = component.getCodelist(true);
		if(codelist != null) {
			if(codelist.getItemById(code) == null) {
				return false;
			}
		}

		Set<String> filterValues = null;
		Set<String> keepValues = null;
		if(filterConceptValues != null) {
			filterValues = filterConceptValues.get(concept);
		}
		if(onlyAllowConceptValues != null) {
			keepValues = onlyAllowConceptValues.get(concept);
		}

		boolean filterValBaseOnExclude =  filterValues != null && filterValues.contains(code);
		boolean filterValBaseOnInclude =  keepValues != null && !keepValues.contains(code);

		if(filterValBaseOnExclude || filterValBaseOnInclude) {
			return true;
		}
		Set<Pattern> filterValuesPattern = null;
		Set<Pattern> keepValuesPattern = null;
		if(filterConceptTextValues != null) {
			filterValuesPattern = filterConceptTextValues.get(concept);
		}
		if(onlyAllowConceptTextValues != null) {
			keepValuesPattern = onlyAllowConceptTextValues.get(concept);
		}
		if(filterValuesPattern != null) {
			for(Pattern p : filterValuesPattern) {
				if(p.matcher(code).matches()) {
					return true;
				}
			}
		}
		if(keepValuesPattern != null) {
			for(Pattern p : keepValuesPattern) {
				if(p.matcher(code).matches()) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidShortCode(String shortCode) {
		return isValidShortCodeInternal(shortCode);
	}

//	private boolean isValidShortCodeInternal(String shortCode) {
//		//3. Check against allowed series (wildcarded)
//		if(excludeSeries != null) {
//			if(explictMatchCheck(excludeSeries, shortCode)) {
//				return false;
//			}
//		}
//		if(includeSeries != null) {
//			if(explictMatchCheck(includeSeries, shortCode)) {
//				return true;
//			}
//		}
//		if(inValidRows != null) {
//			if(isRowMatch(shortCode, inValidRows)) {
//				return false;
//			}
//			return true;
//		}
//		if(validRows != null) {
//			if(isRowMatch(shortCode, validRows)) {
//				return true;
//			}
//			return false;
//		}
//		//Nothing matched - if any included rules were in place return false, if only excluded rules were in place return true
//		if(includeSeries != null || validRows != null) {
//			return false;
//		}
//		return true;
//	}
	
//	@Override
//	public boolean isExplicitlyExcludedShortCode(String shortCode) {
//		if(excludeSeries != null) {
//			if(explictMatchCheck(excludeSeries, shortCode)) {
//				return true;
//			}
//		}
//		if(inValidRows != null) {
//			if(isRowMatch(shortCode, inValidRows)) {
//				return true;
//			}
//		}
//		return false;
//	}
	
//	private boolean explictMatchCheck(Set<String> explictSeries, String shortCode) {
//		if(SeriesUtil.hasWildcards(shortCode)) {
//			Pattern p = SeriesUtil.wildcardSeriesToPattern(shortCode);
//			for(String currentTest : explictSeries) {
//				if(p.matcher(currentTest).matches()) {
//					return true;
//				}
//			}
//			return false;
//		} 
//		return explictSeries.contains(shortCode);
//	}
//	
//	/**
//	 * @param shortCode
//	 * @param validRows a map of a dimension value pair to all the other possible values that are valid for it across all other dimensions
//	 * @return
//	 */
//	private boolean isRowMatch(String shortCode, Map<KeyValue, Set<KeyValue>> validRows) {
//		String[] keySplit = SeriesUtil.splitKey(shortCode);
//		int idx = 0;
//		
//		Set<KeyValue> validValues = null;
//		for(String dim : this.dataStructureBean.getBuiltFrom().getDimensionIds()) {
//			String value = keySplit[idx];
//			idx++;
//			if(value.length() == 0 || value.equals("*")) {
//				if(!this.allowWildcardSeriesMatch) {
//					return false;
//				}
//				continue;
//			}
//			KeyValue kv = KeyValueImpl.getInstance(dim, value);
//			if(validValues != null) {
//				Set<KeyValue> nextSet = null;
//				if(validValues.contains(kv)) {
//					nextSet = getValidKeyValues(validRows, kv);
//				} else {
//					kv = KeyValueImpl.getInstance(dim, "*");
//					if(validValues.contains(kv)) {
//						nextSet = getValidKeyValues(validRows, kv);
//					}
//				}
//				if(nextSet == null) {
//					return false;
//				}
//				nextSet.retainAll(validValues);
//				validValues = nextSet;
//			} else {
//				validValues = getValidKeyValues(validRows, kv);
//				if(validValues == null) {
//					return false;
//				}
//			}
//			
//			if(idx >= keySplit.length) {
//				break;
//			}
//		}
//		return validValues != null && validValues.size() > 0;
//	}
	
//	private Set<KeyValue> getValidKeyValues(Map<KeyValue, Set<KeyValue>> validRows, KeyValue kv) {
//		Set<KeyValue> explicit = validRows.get(kv);
//		Set<KeyValue> wildcard = !kv.getCode().equals("*") ? validRows.get(KeyValueImpl.getInstance(kv.getConcept(), "*")) : null;
//		if(wildcard == null) {
//			return explicit;
//		}
//		if(explicit == null) {
//			return wildcard;
//		}
//		//merge
//		Set<KeyValue> returnSet = new HashSet<>(explicit.size() + wildcard.size());
//		returnSet.addAll(explicit);
//		returnSet.addAll(wildcard);
//		return returnSet;
//	}
	
	private boolean isValidShortCodeInternal(String shortCode) {
		//3. Check against allowed series (wildcarded)
		if(isExplicitlyExcludedShortCode(shortCode)) {
			return false;
		}
		if(includeSeries == null && includeWildcardSeries == null ) {
			//No include rules, and it was not excluded
			return true;
		}
		
		if(includeSeries != null) {
			shortCode = SeriesUtil.removeExplitWildcard(shortCode);
			if(includeSeries.contains(shortCode)) {
				return true;
			}
			if(SeriesUtil.hasWildcards(shortCode)) {
				if(shortCode.contains("+")) {
					Pattern p = SeriesUtil.wildcardSeriesToPattern(shortCode);
					for(String currentTest : includeSeries) {
						if(p.matcher(currentTest).matches()) {
							return true;
						}
					}
					return false;
				}
				//This could be a group key -
				//This used to create a regex pattern, but DEV-1288 showed this to be very slow
				//now the code creates collapsed keys when the short code contains wildcards
				
				String[] keySplit = SeriesUtil.splitKey(shortCode);
				boolean[] includeArray = new boolean[keySplit.length];
				StringBuilder wildcardKey = new StringBuilder();
				int excludeCount = 0;
				for(int i=0; i < keySplit.length; i++) {
					includeArray[i] = keySplit[i].length() > 0;
					if(!includeArray[i]) {
						wildcardKey.append(":"+i);
						excludeCount++;
						keySplit[i] = "";
					}
				}
				
				int[] collapseDimensions = new int[excludeCount];
				int idx = 0;
				for(int i=0; i < keySplit.length; i++) {
					if(!includeArray[i]) {
						collapseDimensions[idx] = i;
						idx++;
					}
				}
				
				String wildcardKeyStr = wildcardKey.toString();
				if(seriesSubStrings == null) {
					seriesSubStrings = new HashSet<>();
				}
				if(seriesSubStrings.contains(wildcardKeyStr)) {
					return false;
				} 
				
				seriesSubStrings.add(wildcardKeyStr);
				Set<String> newIncludeSeries = new HashSet<>(includeSeries);
				for(String currentKey : includeSeries) {
					String collapsed = SeriesUtil.collapseKey(currentKey, collapseDimensions);
					newIncludeSeries.add(collapsed);
				}
				this.includeSeries = newIncludeSeries;
				//Re-check
				if(includeSeries.contains(shortCode)) {
					return true;
				}
			}  
		}
		if(includeWildcardSeries != null) {
			for(Pattern included : includeWildcardSeries) {
				if(included.matcher(shortCode).matches()) {
					return true;
				}
			}
		}
		return false;
	}
	@Override
	public boolean isExplicitlyExcludedShortCode(String shortCode) {
		//3. Check against allowed series (wildcarded)
		if(excludeSeries != null || excludeWildcardSeries != null) {
			if(excludeSeries != null) {
				if(SeriesUtil.hasWildcards(shortCode)) {
					Pattern p = SeriesUtil.wildcardSeriesToPattern(shortCode);
					for(String currentTest : includeSeries) {
						if(p.matcher(currentTest).matches()) {
							return true;
						}
					}
				} else if(excludeSeries.contains(shortCode)) {
					return true;
				}
			}
			if(allowWildcardSeriesMatch == true) {
				shortCode = SeriesUtil.toWildCardSeries(shortCode);
			}
			if(excludeWildcardSeries != null) {
				for(Pattern included : excludeWildcardSeries) {
					if(included.matcher(shortCode).matches()) {
						return true;
					}
				}
			}
		}
		return false;
	}

	@Override
	public String[][] getAllowableSeries() {
		if(!ObjectUtil.validCollection(allowedSeries)) {
			return new String[][]{};
		}

		List<String> dimensions = new ArrayList<>();
		for(DimensionSuperBean dim : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			dimensions.add(dim.getId());
		}
		String[][] returnArray =  new String[allowedSeries.size()][];

		int i=0;
		for(ConstrainedDataKeyBean constrainedKey : allowedSeries) {
			int j=0;
			String[] key = new String[dimensions.size()];
			for(String dimId : dimensions) {
				KeyValue kv = constrainedKey.getKeyValue(dimId);
				key[j] = kv == null || kv.getCode().equals("*") ? null : kv.getCode();
				j++;
			}
			returnArray[i] = key;
			i++;
		}
		return returnArray;
	}

	
//	/**
//	 * Builds the explicit keys and wildcard rows for the constraint
//	 * @param keys
//	 * @param dimensions
//	 * @param conceptMap
//	 * @param fullKey
//	 * @param patterns
//	 * @param allowWildcardSeriesMatch
//	 */
//	private void processConstrainedKeys(Collection<ConstrainedDataKeyBean> keys,
//			List<String> dimensions,
//			Map<String, Set<String>> conceptMap,
//			Set<String> fullKey,
//			Map<KeyValue, Set<KeyValue>> validRows,
//			boolean allowWildcardSeriesMatch) {
//		Set<String> wildcardedDimensions = new HashSet<>();
//		for(ConstrainedDataKeyBean currentKey : keys) {
//			boolean haswildcard = false;
//			Set<KeyValue> kvSet = new HashSet<>(dimensions.size());
//			for(String dim : dimensions) {
//				KeyValue kv = currentKey.getKeyValue(dim);
//				if(kv == null || !ObjectUtil.validString(kv.getCode())) {
//					kv = KeyValueImpl.getInstance(dim, "*");
//					haswildcard = true;
//					kvSet.add(kv);
//					wildcardedDimensions.add(dim);
//				} else if(kv.getCode().contains("+")) {
//					//TODO what if it start or ends with a plus?
//					haswildcard = true;
//					String[] splitOnPlus = kv.getCode().split("\\+");
//					for(String code : splitOnPlus) {
//						kvSet.add(KeyValueImpl.getInstance(dim, code));
//					}
//				} else if(kv.getCode().equals("*")) {
//					haswildcard = true;
//					kvSet.add(kv);
//					wildcardedDimensions.add(dim);
//				} else {
//					kvSet.add(kv);
//				}
//			}
//			if(!haswildcard) {
//				StringBuilder sb = new StringBuilder();
//				String concat = "";
//				for(String dim : dimensions) {
//					KeyValue kv = currentKey.getKeyValue(dim);
//					sb.append(concat + kv.getCode());
//					concat = ":";
//				}
//				String asString = sb.toString();
//				fullKey.add(asString);
//			} else {
//				Map<String, Set<KeyValue>> byConcept = new HashMap<>(dimensions.size());
//				for(KeyValue kv : kvSet) {
//					CollectionUtil.addToMappedSet(byConcept, kv.getConcept(), kv);
//				}
//				for(KeyValue kv : kvSet) {
//					String dimId = kv.getConcept();
//					Set<KeyValue> toRemove = byConcept.get(dimId);
//					Set<KeyValue> setCopy = new HashSet<>(kvSet);
//					setCopy.removeAll(toRemove);
//					setCopy.add(kv);
//					Set<KeyValue> currentValid =  validRows.get(kv);
//					if(currentValid == null) {
//						validRows.put(kv, setCopy);
//					} else {
//						currentValid.addAll(setCopy);
//					}
//				}
//			}
//			if (conceptMap != null) {
//				for(String wildcardedDim : wildcardedDimensions) {
//					conceptMap.remove(wildcardedDim);
//				}
//				for(KeyValue kv : kvSet) {
//					if(!wildcardedDimensions.contains(kv.getConcept())) {
//						CollectionUtil.addToMappedSet(conceptMap, kv.getConcept(), kv.getCode());
//					}
//				}
//			}
//		}
//	}

	 private void processConstrainedKeys(Collection<ConstrainedDataKeyBean> keys,
	            List<String> dimensions,
	            Map<String, Set<String>> conceptMap,
	            Set<String> fullKey,
	            Set<Pattern> patterns,
	            boolean allowWildcardSeriesMatch) {
	        Set<String> wildcardedDimensions = new HashSet<>();
	        for(ConstrainedDataKeyBean currentKey : keys) {
	        	boolean hasWildcard = false;
	        	boolean requiredExpand = false;
	        	
	            StringBuilder sb = new StringBuilder();
	            String concat = "";
	            for(String dim : dimensions) {
	                KeyValue kv = currentKey.getKeyValue(dim);
	                String append = "*";
	                String value = kv == null ? null : kv.getCode();
	                if(!ObjectUtil.validString(value) || value.equals("*")) {
	                	hasWildcard = true;
	                    wildcardedDimensions.add(dim);
	                } else {
	                    if(value.length() > 1 && value.contains("+") && !value.startsWith("+") && !value.endsWith("+")) {
	                    	requiredExpand = true;
	                    }
	                    append = kv.getCode();
	                    if(conceptMap != null) {
	                    	Set<String> onlyAllow = conceptMap.get(dim);
	                        if(onlyAllow == null) {
	                            onlyAllow = new HashSet<>();
	                            conceptMap.put(dim, onlyAllow);
	                        }
	                        for(String splitVal : value.split("\\+")) {
	                        	onlyAllow.add(splitVal);
	                        }
	                    }
	                }
	                sb.append(concat+append);
	                concat = ":";
	            }
	            String sk = sb.toString();
	            if(hasWildcard) {
	            	 patterns.add(SeriesUtil.wildcardSeriesToPattern(sk, allowWildcardSeriesMatch));
	            } else if(requiredExpand) {
	            	fullKey.addAll(SeriesUtil.expandSeries(sk)); 
	            } else {
	            	fullKey.add(sk);
	            }
	        }
	        if (conceptMap != null) {
	            for(String wildcardedDim : wildcardedDimensions) {
	                conceptMap.remove(wildcardedDim);
	            }
	        }
	    }

	private void createSeriesFilterMaps(DataStructureSuperBean dsd, Collection<ConstrainedDataKeyBean> seriesFilters) {
		Set<ConstrainedDataKeyBean> includeFilters = seriesFilters.stream().filter(e->e.isIncluded()).collect(Collectors.toSet());
		Set<ConstrainedDataKeyBean> excludeFilters = seriesFilters.stream().filter(e->e.isIncluded() == false).collect(Collectors.toSet());

		//1. Key Set Constraints
		filterConceptValues = new HashMap<>();
		onlyAllowConceptValues = new HashMap<>();
		List<String> dimensions = new ArrayList<>();
		for(DimensionSuperBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			dimensions.add(dim.getId());
		}
		if(ObjectUtil.validCollection(includeFilters)) {
			includeSeries = new HashSet<>();
			validRows = new HashMap<>();
			includeWildcardSeries = new HashSet<>();
		//	processConstrainedKeys(includeFilters, dimensions, onlyAllowConceptValues, includeSeries, validRows, allowWildcardSeriesMatch);
			processConstrainedKeys(includeFilters, dimensions, onlyAllowConceptValues, includeSeries, includeWildcardSeries, allowWildcardSeriesMatch);
			if(includeSeries.size() == 0) {
				includeSeries = null;
			}
			if(includeWildcardSeries.size() == 0) {
				includeWildcardSeries = null;
			}
//			if(validRows.size() == 0) {
//				validRows = null;
//			}
		}
		if(ObjectUtil.validCollection(excludeFilters)) {
			excludeSeries = new HashSet<>();
			inValidRows = new HashMap<>();
			excludeWildcardSeries = new HashSet<>();
			//FR-633 Reporting Template - universe of series miscalculation when including a excluded series constraint with wildcarded - pass false into allowWildcardedSeriesMatch
			//processConstrainedKeys(excludeFilters, dimensions, null, excludeSeries, inValidRows, false);
			processConstrainedKeys(excludeFilters, dimensions, null, excludeSeries, excludeWildcardSeries, false);
			if(excludeSeries.size() == 0) {
				excludeSeries = null;
			}
			if(excludeWildcardSeries.size() == 0) {
				excludeWildcardSeries = null;
			}
//			if(inValidRows.size() == 0) {
//				inValidRows = null;
//			}
		}
		
		if(filterConceptValues.size() == 0) {
			filterConceptValues = null;
		}
		if(onlyAllowConceptValues.size() == 0) {
			onlyAllowConceptValues = null;
		}
	}

	private void createCubeFilterMaps(DataStructureSuperBean dsd, Map<KeyValues, Set<String>> codesForPeriod) {
		Set<KeyValues> includeFilters = codesForPeriod.keySet().stream().filter(e->e.isIncluded()).map(e-> proxyKeyValues(e, codesForPeriod.get(e))).collect(Collectors.toSet());
		Set<KeyValues> excludeFilters = codesForPeriod.keySet().stream().filter(e->e.isIncluded() == false).map(e-> proxyKeyValues(e, codesForPeriod.get(e))).collect(Collectors.toSet());

		//2. Cube Region Constraints
		if(ObjectUtil.validCollection(excludeFilters)) {
			int size = excludeFilters.size();
			filterConceptValues = new HashMap<>(size);
			filterConceptTextValues = new HashMap<>(size);
			addKeysToConstraint(dsd, excludeFilters, false);
			if(filterConceptValues.size() == 0) {
				filterConceptValues = null;
			}
			if(filterConceptTextValues.size() == 0) {
				filterConceptTextValues = null;
			}
		}
		if(ObjectUtil.validCollection(includeFilters)) {
			int size = includeFilters.size();
			onlyAllowConceptValues = new HashMap<>(size);
			onlyAllowConceptTextValues = new HashMap<>(size);
			addKeysToConstraint(dsd, includeFilters, true);
			if(onlyAllowConceptValues.size() == 0) {
				onlyAllowConceptValues = null;
			}
			if(onlyAllowConceptTextValues.size() == 0) {
				onlyAllowConceptTextValues = null;
			}
		}
	}

	private KeyValues proxyKeyValues(KeyValues kvs, Set<String> validValues) {
		KeyValues proxy = (KeyValues) Proxy.newProxyInstance(
				KeyValuesProxy.class.getClassLoader(), new Class[] { KeyValues.class },  new KeyValuesProxy(kvs, validValues));

		return proxy;
	}

	private class KeyValuesProxy extends AbstractObjectProxy {
		private Set<String> values;
		private Set<String> cascade;
		private Set<String> cascadeEx;

		public KeyValuesProxy(KeyValues target,  Set<String> validValues) {
			super(target);
			values = new HashSet<>(target.getValues());
			cascade = new HashSet<>(target.getCascadeValues());
			cascadeEx = new HashSet<>(target.getCascadeExcludeRoot());

			values.retainAll(validValues);
			cascade.retainAll(validValues);
			cascadeEx.retainAll(validValues);
		}


		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			if(method.getName().equals("getValues")) {
				return values;
			}
			if(method.getName().equals("getCascadeValues")) {
				return cascade;
			}
			if(method.getName().equals("getCascadeExcludeRoot")) {
				return cascadeEx;
			}
			return super.invoke(proxy, method, args);
		}
	}

	private void postSetUpFilterConcepts() {
		if(filterConceptValues != null && filterConceptValues.isEmpty() == false && onlyAllowConceptValues != null && onlyAllowConceptValues.isEmpty() == false) {
			for(String dim : filterConceptValues.keySet()) {
				if(onlyAllowConceptValues.containsKey(dim)) {
					if(filterConceptValues.get(dim).containsAll(onlyAllowConceptValues.get(dim))) {
						filterConceptValues.get(dim).removeAll(onlyAllowConceptValues.get(dim));
						onlyAllowConceptValues.remove(dim);
					} else if(onlyAllowConceptValues.get(dim).containsAll(filterConceptValues.get(dim))) {
						onlyAllowConceptValues.get(dim).removeAll(filterConceptValues.get(dim));
						filterConceptValues.remove(dim);
					}
				}
			}
		}
	}

	private void addKeysToConstraint(DataStructureSuperBean dsd, Collection<KeyValues> kvs, boolean isInclude) {
		Map<String, Set<String>> keyValuesSet;
		Map<String, Set<Pattern>> keyValuesPatternSet;

		if(isInclude) {
			keyValuesSet = onlyAllowConceptValues;
			keyValuesPatternSet = onlyAllowConceptTextValues;
		} else {
			keyValuesSet = filterConceptValues;
			keyValuesPatternSet = filterConceptTextValues;
		}
		for(KeyValues currentKeyValues : kvs) {
			String compId = currentKeyValues.getId();
			ComponentSuperBean comp = dsd.getComponentById(currentKeyValues.getId());
			if (comp == null) {
                continue;
            }
			EnumeratedListBean<EnumeratedItemBean> cl = comp.getCodelist(true);

			for(String constrainedValue : currentKeyValues.getValues()) {
				if(constrainedValue.contains("%")) {
					Pattern p = RegexUtil.wildcardToRegEx(constrainedValue, "%");
					//If this is an enumerated list, add everything that matches the pattern
					if(cl != null) {
						if(keyValuesSet.get(compId) == null) {
							keyValuesSet.put(compId, new HashSet<>(currentKeyValues.getValues().size()));
						}
						for(EnumeratedItemBean item : cl.getItems()) {
							if(p.matcher(item.getId()).matches()) {
								CollectionUtil.addToMappedSet(keyValuesSet, compId, item.getId());
							}
						}
					} else {
						//Otherwise add to the pattern set for a non-enumerated list
						CollectionUtil.addToMappedSet(keyValuesPatternSet, compId, p);
					}

				} else {
					CollectionUtil.addToMappedSet(keyValuesSet, compId, constrainedValue);
				}
			}
			//Cascade
			if(cl != null) {
				Set<String> currentAllowValues = keyValuesSet.get(compId);
				for(String currentCascde : currentKeyValues.getCascadeValues()) {
					EnumeratedItemBean code = cl.getItemById(currentCascde);
					if(code != null) {
						if(currentAllowValues == null) {
							currentAllowValues = new HashSet<>();
							keyValuesSet.put(compId, currentAllowValues);
						}
						cascade(cl, cl.getChildren(code.getId()), currentAllowValues);
					}
				}
			}
		}
	}

	private void cascade(EnumeratedListBean<EnumeratedItemBean> cl, List<EnumeratedItemBean> children, Set<String> currentAllowValues) {
		if(children != null && currentAllowValues != null) {
			for(EnumeratedItemBean child : children) {
				currentAllowValues.add(child.getId());
				cascade(cl, cl.getChildren(child.getId()), currentAllowValues);
			}
		}
	}

}
