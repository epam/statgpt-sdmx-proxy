package io.sdmx.im.constraint;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedDataStructure;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Defines a Data Structure, optionally in the context of another structure, along with any constrained (partial) codelists and allowable series
 */
public class ConstrainedDataStructureImpl implements ConstrainedDataStructure {
    private static final Logger LOG = LoggerFactory.getLogger(ConstrainedDataStructureImpl.class);

	private ConstrainableBean constrainable;
	private DataStructureSuperBean dataStructure;
	private Map<String, EnumeratedListBean<EnumeratedItemBean>> codelistBean = new HashMap<>();
	private Set<String> allowableSeries;
	
	public ConstrainedDataStructureImpl(ConstrainableBean constrainable,
										DataStructureSuperBean dsd, 
										Map<String, Collection<String>> restrictedCodes, 
										Set<String> allowableSeries) {
		this.constrainable = constrainable;
		this.dataStructure = dsd;
		if(allowableSeries != null) {
			this.allowableSeries = Collections.unmodifiableSet(allowableSeries);
		}
		for(ComponentSuperBean comp : dsd.getComponents()) {
			EnumeratedListBean<EnumeratedItemBean> codelist = comp.getCodelist(true);
			if(codelist != null) {
				if(restrictedCodes != null && restrictedCodes.containsKey(comp.getId())) {
					Collection<String> allowedCodes = restrictedCodes.get(comp.getId());
					codelist = codelist.filterItems(allowedCodes, true);
					LOG.debug("Partial codelist created now has '"+codelist.getItems().size()+"' codes");
				}
				codelistBean.put(comp.getId(), codelist);
			}
		}
	}

	@Override
	public DataStructureSuperBean getDataStructure() {
		return dataStructure;
	}
	
	@Override
	public ConstrainableBean getConstrainable() {
		return constrainable;
	}

	@Override
	public EnumeratedListBean<EnumeratedItemBean> getCodelistForComponent(String componentId) {
		return codelistBean.get(componentId);
	}

	@Override
	public Set<String> getAllowableSeries() {
		return allowableSeries;
	}
}
