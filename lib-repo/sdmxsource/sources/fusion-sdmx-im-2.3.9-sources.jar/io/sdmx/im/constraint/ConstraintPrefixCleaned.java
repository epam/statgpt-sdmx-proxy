package io.sdmx.im.constraint;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;

public class ConstraintPrefixCleaned {
	private ContentConstraintBean origninal;
	private ContentConstraintBean cleaned;
	private Map<String, String> removePrefixes;

	public ConstraintPrefixCleaned(ContentConstraintBean constraint, DataStructureSuperBean dataStructureBean) {
		this.origninal = constraint;
		this.cleaned = removePrefixIfRequired(constraint, dataStructureBean);
		if(this.removePrefixes == null) {
			this.removePrefixes = Collections.emptyMap();			
		} else {
			this.removePrefixes = Collections.unmodifiableMap(this.removePrefixes);
		}
	}

	public Map<String, String> getRemovePrefixes() {
		return removePrefixes;
	}

	public ContentConstraintBean getOrigninal() {
		return origninal;
	}

	public ContentConstraintBean getCleaned() {
		return cleaned;
	}

	/**
	 * This will remove the prefix from any constraint rules if it has been asked to, and if the underlying codelist uses codelist extension and has the prefix
	 * as part of the extension definition
	 * @param constraint
	 * @return
	 */
	private ContentConstraintBean removePrefixIfRequired(ContentConstraintBean constraint, DataStructureSuperBean dataStructureBean) {
		Set<String> removePrefixComponents = null;
		removePrefixComponents = populateRemovePrefix(constraint.getIncludedCubeRegion(), removePrefixComponents);
		removePrefixComponents = populateRemovePrefix(constraint.getExcludedCubeRegion(), removePrefixComponents);
		removePrefixComponents = populateRemovePrefix(constraint.getIncludedSeriesKeys(), removePrefixComponents);
		removePrefixComponents = populateRemovePrefix(constraint.getExcludedSeriesKeys(), removePrefixComponents);

		if(removePrefixComponents == null) {
			return constraint;
		}
		removePrefixes = new HashMap<>();
		ContentConstraintMutableBean constraintMut = constraint.getMutableInstance();
		removePrefix(constraintMut.getIncludedCubeRegion(), removePrefixComponents, dataStructureBean);
		removePrefix(constraintMut.getExcludedCubeRegion(), removePrefixComponents, dataStructureBean);
		removePrefix(constraintMut.getIncludedSeriesKeys(), removePrefixComponents, dataStructureBean);
		removePrefix(constraintMut.getExcludedSeriesKeys(), removePrefixComponents, dataStructureBean);


		return constraintMut.getImmutableInstance();
	}

	private Set<String> populateRemovePrefix(ConstraintDataKeySetBean cks, Set<String> removePrefixComponents) {
		if(cks != null) {
			for(ConstrainedDataKeyBean kvs : cks.getConstrainedDataKeys()) {
				for(IConstrainedKeyValue kv : kvs.getKeyValues()) {
					if(kv.isRemovePrefix()) {
						removePrefixComponents = addRemovePrefixToSet(removePrefixComponents, kv.getConcept());
					}
				}
			}
		}
		return removePrefixComponents;
	}

	private Set<String> populateRemovePrefix(CubeRegionBean cube, Set<String> removePrefixComponents) {
		if(cube != null) {
			removePrefixComponents =  populateRemovePrefix(cube.getKeyValues(), removePrefixComponents);
			removePrefixComponents =  populateRemovePrefix(cube.getAttributeValues(), removePrefixComponents);
		}
		return removePrefixComponents;
	}

	private Set<String> populateRemovePrefix(List<KeyValues> keyValues, Set<String> removePrefixComponents) {
		for(KeyValues kvs : keyValues) {
			if(kvs.isRemovePrefix()) {
				removePrefixComponents = addRemovePrefixToSet(removePrefixComponents, kvs.getId());
			}
		}
		return removePrefixComponents;
	}


	private void removePrefix(ConstraintDataKeySetMutableBean cks, Set<String> removePrefixComponents, DataStructureSuperBean dataStructureBean) {
		if(cks != null) {
			for(ConstrainedDataKeyMutableBean kvs : cks.getConstrainedDataKeys()) {
				List<IConstrainedKeyValue> replaceList = new ArrayList<>();
				for(IConstrainedKeyValue kv : kvs.getKeyValues()) {
					if(kv.isRemovePrefix()) {
						String code = removePrefix(dataStructureBean, kv.getConcept(), kv.getCode());
						kv = ConstrainedKeyValue.getInstance(kv.getConcept(), false, code);
						replaceList.add(kv);
					}
					kvs.setKeyValues(replaceList);
				}
			}
		}
	}

	private String removePrefix(DataStructureSuperBean dataStructureBean, String compId, String constrainedValues) {
		String prefix = determinePrefix(dataStructureBean, compId, constrainedValues);
		if(prefix == null || !constrainedValues.startsWith(prefix)) {
			return constrainedValues;
		}
		return constrainedValues.substring(prefix.length());
	}

	private String determinePrefix(DataStructureSuperBean dataStructureBean, String compId, String... constrainedValues) {
		String prefix = removePrefixes.get(compId);
		if(prefix != null) {
			return prefix;
		}
		ComponentSuperBean<ComponentBean> comp = dataStructureBean.getComponentById(compId);
		if(comp != null) {
			EnumeratedListBean list = comp.getCodelist(true);
			if(list instanceof CodelistBean) {
				CodelistBean cl = (CodelistBean)list;
				if(cl.getRootCodelist() != null) {
					for(ICodelistInheritanceRuleBean rule : cl.getRootCodelist().getInheritedCodelists()) {
						prefix = rule.getPrefix();
						if(prefix != null) {
							for(String val : constrainedValues) {
								if(val.startsWith(prefix)) {
									removePrefixes.put(compId, prefix);
									return prefix; 
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	private void removePrefix(CubeRegionMutableBean cube, Set<String> removePrefixComponents, DataStructureSuperBean dataStructureBean) {
		if(cube != null) {
			removePrefix(cube.getKeyValues(), removePrefixComponents, dataStructureBean);
			removePrefix(cube.getAttributeValues(), removePrefixComponents, dataStructureBean);
		}
	}

	private void removePrefix(List<KeyValuesMutable> keyValues, Set<String> removePrefixComponents, DataStructureSuperBean dataStructureBean) {
		for(KeyValuesMutable kvs : keyValues) {
			if(kvs.isRemovePrefix()) {
				List<String> keys = new ArrayList<>();
				List<String> cascde = new ArrayList<>();
				for(String value : kvs.getKeyValues()) {
					keys.add(removePrefix(dataStructureBean, kvs.getId(), value));
				}
				for(String value : kvs.getCascade()) {
					cascde.add(removePrefix(dataStructureBean, kvs.getId(), value));
				}
				kvs.setKeyValues(keys);
				kvs.setCascade(cascde);
				kvs.setRemovePrefix(false);
			}
		}
	}

	private Set<String> addRemovePrefixToSet(Set<String> removePrefixSet, String str) {
		if(removePrefixSet == null) {
			removePrefixSet = new HashSet<>();
		}
		removePrefixSet.add(str);
		return removePrefixSet;
	}
}
