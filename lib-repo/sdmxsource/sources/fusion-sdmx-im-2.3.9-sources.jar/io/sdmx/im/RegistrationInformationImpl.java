package io.sdmx.im;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;

public class RegistrationInformationImpl implements RegistrationInformation {
	private DATASET_ACTION action;
	private RegistrationBean registrationBean;
	
	public RegistrationInformationImpl(DATASET_ACTION action, RegistrationBean registrationBean) {
		this.action = action;
		this.registrationBean = registrationBean;
	}

	@Override
	public DATASET_ACTION getRegistrationAction() {
		return action;
	}

	@Override
	public RegistrationBean getRegistration() {
		return registrationBean;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof RegistrationInformationImpl) {
			return obj.toString().equals(this.toString());
		}
		return false;
	}

	@Override
	public String toString() {
		return action  + " " + registrationBean.getUrn();
	}
}
