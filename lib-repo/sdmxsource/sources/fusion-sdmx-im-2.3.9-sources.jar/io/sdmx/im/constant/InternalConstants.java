package io.sdmx.im.constant;

/**
 * Constants used by the system 
 */
public class InternalConstants {
	
	// States that a Structure Set has been upgraded from SDMX 2.1 to SDMX 3
	public static final String STRUCTURE_SET_UPGRADE = "FR_STRUCTURE_SET_AUTO_UPGRADE";
	
}
