package io.sdmx.im.constant;

import io.sdmx.api.application.IVersion;
import io.sdmx.utils.core.version.Version;

/**
 * Version of the Information Model
 */
public enum SDMX_IM {
	V1_0("1.0"),
	V2_0("2.0"),
	V2_1("2.1"),
	V3_0("3.0");
	
	private IVersion version;

	private SDMX_IM(String version) {
		this.version = Version.getInstance(version);
	}

	public IVersion getVersion() {
		return version;
	}
	
	/**
	 * @param that to check against
	 * @return true if this version is higher then the 'that' passed in - a suffixed version is a lower version then a non suffixed version
	 * if both versions contain a suffix and have the same version, the suffix is compared one character at a time
	 */
	public boolean isHigher(SDMX_IM that) {
		return this.version.isHigher(that.getVersion());
	}
}
