package io.sdmx.im.data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

public class ObservationProxy extends AttributableProxy implements Observation {
	private Observation proxy;
	private Keyable key;
	
	public ObservationProxy(Observation proxy) {
		super(proxy);
		this.proxy = proxy;
	}

	public ObservationProxy(Observation proxy, Attributable attProxy, Keyable key) {
		super(attProxy);
		this.proxy = proxy;
		this.key = key;
	}

	
	public ObservationProxy(Observation proxy, Attributable attProxy) {
		super(attProxy);
		this.proxy = proxy;
	}
	
	protected Observation getProxy() {
		return proxy;
	}

	@Override
	public int compareTo(Observation arg0) {
		return proxy.compareTo(arg0);
	}

	@Override
	public Keyable getSeriesKey() {
		if(key != null) {
			return key;
		}
		return proxy.getSeriesKey();
	}

	@Override
	public String getShortCode() {
		if(key != null) {
			return getSeriesKey().getShortCode()+ (getDimensionValue() != null ? ":"+getDimensionValue() : "");
		}
		return proxy.getShortCode();
	}

	@Override
	public KeyValue getMeasure(String measure) {
		return proxy.getMeasure(measure);
	}

	@Override
	public String getMeasureCode(String measure) {
		return proxy.getMeasureCode(measure);
	}

	@Override
	public List<KeyValue> getMeasures() {
		return proxy.getMeasures();
	}

	@Override
	public List<String> getMeasureValues(String measure) {
		return proxy.getMeasureValues(measure);
	}

	@Override
	public Map<String, KeyValue> getMeasureMap(){
		return proxy.getMeasureMap();
	}
	
	@Override
	public Map<String, List<BigDecimal>> getNumericalMeasureValues() {
		return proxy.getNumericalMeasureValues();
	}

	@Override
	public String getDimensionId() {
		return proxy.getDimensionId();
	}

	@Override
	public String getDimensionValue() {
		return proxy.getDimensionValue();
	}
	
	@Override
	public SdmxDate getSdmxObsTime() {
		return proxy.getSdmxObsTime();
	}

	@Override
	public IMultilingualKeyValue getMultilingualMeasure(String concept){
		return proxy.getMultilingualMeasure(concept);
	}

	@Override
	public List<IMultilingualKeyValue> getMultilingualMeasures(){
		return proxy.getMultilingualMeasures();
	}

}
