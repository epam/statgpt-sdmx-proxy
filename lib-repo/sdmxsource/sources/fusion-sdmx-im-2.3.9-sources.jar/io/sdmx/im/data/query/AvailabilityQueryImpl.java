package io.sdmx.im.data.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.constants.AVAILABILITY_MODE;
import io.sdmx.api.sdmx.constants.METRICS;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.data.query.AvailabilityQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.query.RESTAvailabilityQuery;
import io.sdmx.utils.core.object.ObjectUtil;

public class AvailabilityQueryImpl implements AvailabilityQuery {
	private io.sdmx.api.sdmx.model.data.query.BaseDataQuery dataQuery;
	private STRUCTURE_REFERENCE_DETAIL structureReferenceDetail;
	private SDMX_STRUCTURE_TYPE specificStructureReference;
	private AVAILABILITY_MODE mode = AVAILABILITY_MODE.EXACT;
	private METRICS metrics = METRICS.NONE;
	private List<SDMX_STRUCTURE_TYPE> specificMetrics = new ArrayList<>();
				
	private Set<String> componentIds = Collections.emptySet();
	
	public AvailabilityQueryImpl(RESTAvailabilityQuery query, DataQuery dataQuery) {
		this.dataQuery = dataQuery;
		this.structureReferenceDetail = query.getStructureReferenceDetail();
		this.specificStructureReference = query.getSpecificStructureReference();
		this.mode = query.getMode();
		setComponentIds(query.getComponentIds());
		
		String includeMetrics = query.getParamValue("includeMetrics");
		if(ObjectUtil.validString(includeMetrics)) {
			if("true".equalsIgnoreCase(includeMetrics)) {	
				metrics = METRICS.INCLUDE;
			} else if("only".equalsIgnoreCase(includeMetrics)) {
				metrics = METRICS.INCLUDE_ONLY;
			} else {
				String[] metricsToInclude = includeMetrics.split(",");
				metrics = METRICS.INCLUDE;
				for(String metric : metricsToInclude) {
					 if("only".equalsIgnoreCase(metric)) {
						 metrics = METRICS.INCLUDE_ONLY;
					 } else {
						 specificMetrics.add(SDMX_STRUCTURE_TYPE.parseClass(metric));
					 }
				}
			}
		}
		specificMetrics = Collections.unmodifiableList(specificMetrics);
	}
	
	public AvailabilityQueryImpl(io.sdmx.api.sdmx.model.data.query.BaseDataQuery dataQuery, 
								STRUCTURE_REFERENCE_DETAIL structureReferenceDetail, 
								SDMX_STRUCTURE_TYPE specificStructureReference, 
								AVAILABILITY_MODE mode, 
								METRICS metrics,
								List<SDMX_STRUCTURE_TYPE> specificMetrics,
								String... componentId) {
		this.dataQuery = dataQuery;
		this.structureReferenceDetail = structureReferenceDetail;
		this.specificStructureReference = specificStructureReference;
		if(mode != null) {
			this.mode = mode;
		}
		if(metrics != null) {
			this.metrics = metrics;
		}
		this.specificMetrics = specificMetrics;
		if(this.specificMetrics == null) {
			this.specificMetrics = Collections.emptyList();
		} else {
			this.specificMetrics = Collections.unmodifiableList(specificMetrics);
		}
		setComponentIds(componentId);
	}

	/**
	 * Change the underlying data query, keep other parameters the same
	 * @param dataQuery
	 * @param query
	 */
	public AvailabilityQueryImpl(io.sdmx.api.sdmx.model.data.query.BaseDataQuery dataQuery, AvailabilityQuery query) {
		this.dataQuery = dataQuery;
		if(query != null) {
			this.structureReferenceDetail = query.getStructureReferenceDetail();
			this.specificStructureReference = query.getSpecificStructureReference();
			this.mode = query.getMode();
			this.componentIds = query.getComponentIds();
		}
	}

	public AvailabilityQueryImpl(RESTAvailabilityQuery availabilityQuery, SdmxBeanRetrievalManager sdmxBeanRetrievalManager) {
		this.dataQuery = new DataQueryImpl(availabilityQuery, sdmxBeanRetrievalManager);
		this.mode = availabilityQuery.getMode();
		setComponentIds(availabilityQuery.getComponentIds());
		this.structureReferenceDetail = availabilityQuery.getStructureReferenceDetail();
		this.specificStructureReference = availabilityQuery.getSpecificStructureReference();
	}
	
	private void setComponentIds(String...componentIds) {
		if(componentIds != null && componentIds.length > 0) {
			this.componentIds = new HashSet<>(componentIds.length);
			for(String compId : componentIds) {
				if(ObjectUtil.validString(compId)) {
					this.componentIds.add(compId);
				}
			}
			this.componentIds = Collections.unmodifiableSet(this.componentIds);
		}
	}
	
	@Override
	public METRICS includeMetrics() {
		return metrics;
	}

	@Override
	public List<SDMX_STRUCTURE_TYPE> getSpecificMetrics() {
		return specificMetrics;
	}

	@Override
	public AVAILABILITY_MODE getMode() {
		return mode;
	}

	@Override
	public Set<String> getComponentIds() {
		return componentIds;
	}

	@Override
	public STRUCTURE_REFERENCE_DETAIL getStructureReferenceDetail() {
		return structureReferenceDetail;
	}

	@Override
	public SDMX_STRUCTURE_TYPE getSpecificStructureReference() {
		return specificStructureReference;
	}

	@Override
	public io.sdmx.api.sdmx.model.data.query.BaseDataQuery getDataQuery() {
		return dataQuery;
	}
}
