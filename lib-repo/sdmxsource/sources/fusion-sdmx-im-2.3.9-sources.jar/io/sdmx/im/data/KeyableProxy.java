package io.sdmx.im.data;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.Keyable;

public class KeyableProxy extends AttributableProxy implements Keyable {
	private Keyable proxy;

	public KeyableProxy(Keyable proxy) {
		super(proxy);
		this.proxy = proxy;
	}
	
	public KeyableProxy(Keyable proxy, Attributable attProxy) {
		super(attProxy);
		this.proxy = proxy;
	}

	@Override
	public DataStructureBean getDataStructure() {
		return proxy.getDataStructure();
	}

	@Override
	public DataflowBean getDataflow() {
		return proxy.getDataflow();
	}

	@Override
	public String getShortCode() {
		return proxy.getShortCode();
	}

	@Override
	public String createShortCode(String ignoreDimension) {
		return proxy.createShortCode(ignoreDimension);
	}

	@Override
	public List<KeyValue> getKey() {
		return proxy.getKey();
	}

	@Override
	public KeyValue getKeyValue(String dimensionId) {
		return proxy.getKeyValue(dimensionId);
	}

	@Override
	public String getReportedValue(String dimensionId) {
		return proxy.getReportedValue(dimensionId);
	}

	@Override
	public boolean isSeries() {
		return proxy.isSeries();
	}

	@Override
	public String getGroupName() {
		return proxy.getGroupName();
	}
	
}
