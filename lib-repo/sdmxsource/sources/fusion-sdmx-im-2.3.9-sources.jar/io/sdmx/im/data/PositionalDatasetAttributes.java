package io.sdmx.im.data;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;

public class PositionalDatasetAttributes extends AttributableProxy implements IDatasetAttributes {
	private IDataPosition position;

	public PositionalDatasetAttributes(IDatasetAttributes proxy, IDataPosition position) {
		super(proxy);
		this.position = position;
	}
	
	@Override
	public IDataPosition getPosition() {
		return position;
	}
}
