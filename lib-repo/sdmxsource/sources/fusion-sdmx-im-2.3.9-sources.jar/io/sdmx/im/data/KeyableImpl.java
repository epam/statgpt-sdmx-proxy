package io.sdmx.im.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.object.StringUtil;

public class KeyableImpl extends AbstractAttributable implements Keyable {
	private DataStructureBean dataStructure;
	private DataflowBean dataflowBean;
	private List<KeyValue> key = Collections.emptyList();
	private Map<String, KeyValue> keyMap = null;
	private String groupName;
	private String uniqueId; //Generated on equals/hashcode
	private String shortCode;
	
	public static KeyBuilder builder(DataStructureBean dsd) {
		return new KeyBuilder(dsd);
	}
	
	public static class KeyBuilder extends AttributableBuilder<Keyable> {
		private DataStructureBean dataStructure;
		private DataflowBean dataflowBean;
		private String group;
		private List<KeyValue> key = Collections.emptyList();
		
		public KeyBuilder(DataStructureBean dataStructure) {
			this.dataStructure = dataStructure;
		}
		
		public KeyBuilder dataflow(DataflowBean flow) {
			this.dataflowBean = flow;
			return this;
		}
		
		public KeyBuilder group(String group) {
			this.group = group;
			return this;
		}
		public KeyBuilder clearKey() {
			key = Collections.emptyList();
			return this;
		}
		/**
		 * Adds a single key value to the series/group key
		 * @param kv
		 * @return
		 */
		public KeyBuilder key(KeyValue  kv) {
			if(this.key.isEmpty()) {
				this.key = new ArrayList<>();
			}
			this.key.add(kv);
			return this;
		}
		
		public KeyBuilder key(List<KeyValue>  key) {
			if(key == null) {
				key = Collections.emptyList();
			}
			this.key = key;
			return this;
		}

		@Override
		public Keyable build() {
			return new KeyableImpl(this);
		}
	}
	
	private KeyableImpl(KeyBuilder builder) {
		super(builder);
		setProperties(builder.dataflowBean, builder.dataStructure, builder.group, builder.key);
	}
	


	@Deprecated
	/**
	 * @deprecated use KeyableImpl.build
	 */
	public KeyableImpl(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key, List<KeyValue> attributes, List<AnnotationBean> annotationBeans) {
		super(attributes, annotationBeans);
		setProperties(dataflowBean, dsd, groupId, key);
	}

	@Deprecated
	/**
	 * @deprecated use KeyableImpl.build
	 */
	public KeyableImpl(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		super(attributes, annotationBeans);
		setProperties(dataflowBean, dsd, groupId, key);
	}

	@Deprecated
	/**
	 * @deprecated use KeyableImpl.build
	 */
	public KeyableImpl(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, List<AnnotationBean> annotationBeans){
		super(attributes, complexAttributes, annotationBeans);
		setProperties(dataflowBean, dsd, groupId, key);
	}

	private void setProperties(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key) {
		this.dataStructure = dsd;
		this.dataflowBean = dataflowBean;
		if(key == null) {
			this.key = Collections.emptyList();
		} else {
			//Ensure order of key
			key = new ArrayList<>(key); //Create copy to ensure immtuablity
			this.key = Collections.unmodifiableList(key);
		}
		if(ObjectUtil.validString(groupId)) {
			this.groupName = groupId;
		}
	}
		
	
	/**
	 * Builds a Keyable from a short code such as A:B:C.  The short code can contain missing entries A::B::X
	 * @param dataflowBean (optional)
	 * @param dsd (required)
	 * @param shortCode (required)
	 * @return
	 */
	public static Keyable buildFromShortCode(DataflowBean dataflowBean, DataStructureBean dsd, String shortCode) {
		return buildFromShortCode(dataflowBean, dsd, shortCode, null);
	}
	
	/**
	 * Builds a Keyable from a short code such as A:B:C.  The short code can contain missing entries A::B::X
	 * @param dataflowBean (optional)
	 * @param dsd (required)
	 * @param shortCode (required)
	 * @return
	 */
	public static Keyable buildFromShortCode(DataflowBean dataflowBean, DataStructureBean dsd, String shortCode, List<KeyValue> attributes) {
		if(!ObjectUtil.validString(shortCode)) {
			throw new SdmxException("KeyableImpl.buildFromShortCode - shortCode required");
		}
		String[] split = shortCode.split(SeriesUtil.KEY_DELIMITER);
		List<DimensionBean> dimensions = dsd.getDimensionList().getDimensions();
		List<KeyValue> key = new ArrayList<>();
		for(int i = 0; i < dimensions.size(); i++) {
			String dimId = dimensions.get(i).getId();
			if(split.length > i && split[i].length() > 0) {
				key.add(KeyValueImpl.getInstance(dimId, split[i]));
			}
		}
		return seriesKey(dataflowBean, dsd, key, attributes);
	}
		
	public static Keyable seriesKey(DataflowBean dataflowBean, DataStructureBean dsd, List<KeyValue> key, List<KeyValue> attributes, List<AnnotationBean> annotations) {
		return builder(dsd).dataflow(dataflowBean).key(key).attributes(attributes).annotations(annotations).build();
	}
	
	public static Keyable seriesKey(DataflowBean dataflowBean, DataStructureBean dsd, List<KeyValue> key, List<KeyValue> attributes, AnnotationBean...annotations) {
		return builder(dsd).dataflow(dataflowBean).key(key).attributes(attributes).annotations(annotations).build();
	}

	public static Keyable seriesKey(DataflowBean dataflowBean, DataStructureBean dsd, List<KeyValue> key, List<KeyValue> attributes, List<IMultilingualKeyValue> attributesMultiLingual, AnnotationBean...annotations) {
		return builder(dsd).dataflow(dataflowBean).key(key).attributes(attributes).attributesMultilingual(attributesMultiLingual).annotations(annotations).build();
	}

	public static Keyable groupKey(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key, List<KeyValue> attributes, AnnotationBean...annotations) {
		return builder(dsd).dataflow(dataflowBean).group(groupId).key(key).attributes(attributes).annotations(annotations).build();
	}

	public static Keyable groupKey(DataflowBean dataflowBean, DataStructureBean dsd, String groupId, List<KeyValue> key, List<KeyValue> attributes, List<IMultilingualKeyValue> attributesMultiLingual, AnnotationBean...annotations) {
		return builder(dsd).dataflow(dataflowBean).group(groupId).key(key).attributes(attributes).attributesMultilingual(attributesMultiLingual).annotations(annotations).build();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return dataStructure;
	}

	@Override
	public DataflowBean getDataflow() {
		return dataflowBean;
	}

	@Override
	public String getShortCode() {
		if(shortCode == null) {
			generateUniqueId();
		}
		return shortCode;
	}

	/**
	 * Creates a short code for the key but missing out the dimension which matched the ignoreDimension id
	 * @param key series key
	 * @param ignoreDimension do not include the value for this dimension in the short code
	 * @return
	 */
	@Override
	public String createShortCode(String ignoreDimension) {
		if(ignoreDimension == null) {
			return getShortCode();
		}
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(DimensionBean dim : dataStructure.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
			String value;
			if(dim.getId().equals(ignoreDimension)) {
				value = "*";
			} else {
				value = getReportedValue(dim.getId());
				if(value == null) {
					if(dim.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
						continue;
					}
					value = "";
				}
			}
			sb.append(concat +value);
			concat = SeriesUtil.KEY_DELIMITER;
		}
		return sb.toString();
	}

	@Override
	public KeyValue getKeyValue(String dimensionId) {
		if(keyMap == null) {
			this.keyMap = this.key.stream().collect(Collectors.toMap(e->e.getConcept(), e->e));
		}
		return keyMap.get(dimensionId);
	}

	@Override
	public String getReportedValue(String dimensionId) {
		KeyValue kv = getKeyValue(dimensionId);
		if(kv == null) {
			return null;
		}
		return kv.getCode();
	}

	@Override
	public List<KeyValue> getKey() {
		return key;
	}

	@Override
	public boolean isSeries() {
		return groupName == null;
	}

	@Override
	public String getGroupName() {
		return groupName;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) return true;
		if(obj instanceof KeyableImpl) {
			if(uniqueId == null) {
				generateUniqueId();
			}
			KeyableImpl that = (KeyableImpl)obj;
			if(that.uniqueId == null) {
				that.generateUniqueId();
			}
			return this.uniqueId.equals(that.uniqueId);
		}
		return false;
	}

	@Override
	public int hashCode() {
		if(uniqueId == null) {
			generateUniqueId();
		}
		return uniqueId.hashCode();
	}

	private void generateUniqueId() {
		shortCode = "";
		String concat ="";
		StringBuilder shortCodeSb = new StringBuilder();

		for(DimensionBean dim : dataStructure.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
			String key = getReportedValue(dim.getId());
			if(key == null) {
				if(dim.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
					continue;
				}
				key = "";
			}
			shortCodeSb.append(concat +key);
			concat = SeriesUtil.KEY_DELIMITER;
		}
		shortCode = shortCodeSb.toString();
		
		StringBuilder sb = new StringBuilder(shortCode);
		for(KeyValue kv : getKey()) {
			if(dataStructure.getDimension(kv.getConcept()) == null) {
				sb.append(kv.getConcept()+concat+kv.getCode());
			}
		}

		for(KeyValue kv : getAttributes()) {
			String codeVal = kv.getCode();
			if(codeVal == null && kv.getValues() != null) {
				codeVal =  CollectionUtil.collectionToString(kv.getValues(), ";", "-");
			}
			sb.append(kv.getConcept()+concat+codeVal);
		}
		if(groupName!= null) {
			sb.append(groupName);
		}
		uniqueId = sb.toString();
		shortCode = StringUtil.manualIntern(shortCode);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if(groupName != null) {
			sb.append("group "+groupName+" ");
		} else {
			sb.append("series ");
		}
		String concat = "";
		for(KeyValue kv : key) {
			sb.append(concat);
			sb.append(kv.getConcept());
			sb.append(SeriesUtil.KEY_DELIMITER);
			sb.append(kv.getCode());
			concat = ",";
		}
		return sb.toString();
	}


}
