package io.sdmx.im.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.MeasureUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class ObservationImpl extends AbstractAttributable implements Observation {
	private static final Logger LOG = LoggerFactory.getLogger(ObservationImpl.class);

	private int hashCode = -1;
	private Keyable seriesKey;
	private String dimensionId;
	private String dimensionValue;
	private SdmxDate sdmxDate;
	private List<KeyValue> measures = new ArrayList<>();
	private Map<String, KeyValue> measuresMap = Collections.emptyMap();
	private Map<String, List<BigDecimal>> parsed;
	private List<IMultilingualKeyValue> multilingualMeasures = Collections.emptyList();
	private Map<String, IMultilingualKeyValue> multilingualMeasureMap = Collections.emptyMap();
	
	public static ObsBuilder builder(Keyable seriesKey) {
		return new ObsBuilder(seriesKey);
	}
	
	public static class ObsBuilder extends AttributableBuilder<Observation> {
		private Keyable seriesKey;
		private String dimensionId;
		private String dimensionValue;
		private List<KeyValue> measures = Collections.emptyList();
		private List<IMultilingualKeyValue> multilingualMeasures = Collections.emptyList();
		
		public ObsBuilder(Keyable seriesKey) {
			this.seriesKey = seriesKey;
		}
		
		public ObsBuilder time(String value) {
			dim(DimensionBean.TIME_DIMENSION_FIXED_ID, value);
			return this;
		}
		
		public ObsBuilder dim(String id, String value) {
			this.dimensionId = id;
			this.dimensionValue = value;
			return this;
		}
		public ObsBuilder primaryMeasure(String measure) {
		    if(this.measures.size() == 0) {
				measures = new ArrayList<>(1);
			}
			measures.add(KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, measure));
			return this;
		}
		
		public ObsBuilder measure(KeyValue  measure) {
			if(this.measures.size() == 0) {
				this.measures = new ArrayList<>();
			}
			this.measures.add(measure);
			return this;
		}
		
		public ObsBuilder measures(List<KeyValue>  measures) {
			if(measures == null) {
				measures = Collections.emptyList();
			}
			this.measures = measures;
			return this;
		}
		
		public ObsBuilder measuresMultilingual(List<IMultilingualKeyValue>  measures) {
			if(measures == null) {
				measures = Collections.emptyList();
			}
			this.multilingualMeasures = measures;
			return this;
		}
		
		public ObsBuilder addMeasureMultilingual(IMultilingualKeyValue  measure) {
			if(this.multilingualMeasures.size() == 0) {
				this.multilingualMeasures = new ArrayList<>();
			}
			this.multilingualMeasures.add(measure);
			return this;
		}

		@Override
        public Observation build() {
			return new ObservationImpl(this);
		}
	}
	
	private ObservationImpl(ObsBuilder builder) {
		super(builder);
		setComplexMeasures(builder.multilingualMeasures);
		setProperties(builder.seriesKey, builder.dimensionId, builder.dimensionValue, builder.measures);
	}
	
	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures, List<KeyValue> attributes, List<AnnotationBean> annotations) {
		super(attributes, annotations);
		setProperties(seriesKey, dimensionId, dimensionValue, measures);
	}
	
	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<AnnotationBean> annotations) {
		super(attributes, annotations);
		setProperties(seriesKey, dimensionId, dimensionValue, primaryMeasure, measures);
	}

	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> measures, List<KeyValue> attributes, List<AnnotationBean> annotations) {
		super(attributes, annotations);
		setProperties(seriesKey, dimensionId, dimensionValue, measures);
	}

	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, List<AnnotationBean> annotations) {
		super(attributes, complexAttributes, annotations);
		setComplexMeasures(complexMeasures);
		setProperties(seriesKey, dimensionId, dimensionValue, measures);
	}

	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, List<AnnotationBean> annotations) {
		super(attributes, complexAttributes, annotations);
		setComplexMeasures(complexMeasures);
		setProperties(seriesKey, dimensionId, dimensionValue, primaryMeasure);
	}


	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	private ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		super(attributes, annotationBeans);
		setProperties(seriesKey, dimensionId, dimensionValue, measures);
	}

	private ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, AnnotationBean...annotationBeans) {
		super(attributes, complexAttributes, annotationBeans);
		setProperties(seriesKey, dimensionId, dimensionValue, measures);
	}


	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	private ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, AnnotationBean...annotationBean) {
		super(attributes, complexAttributes, annotationBean);
		setProperties(seriesKey, dimensionId, dimensionValue, primaryMeasure, measures);
	}


	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	private ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<KeyValue> measures, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, AnnotationBean...annotationBean) {
		super(attributes, complexAttributes, annotationBean);
		setComplexMeasures(complexMeasures);
		setProperties(seriesKey, dimensionId, dimensionValue, primaryMeasure, measures);
	}


	@Deprecated
	/**
	 * @deprecated use ObservationImpl.build
	 */
	public ObservationImpl(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, AnnotationBean... annotationBeans) {
		super(attributes, annotationBeans);
		setProperties(seriesKey, dimensionId, dimensionValue, primaryMeasure);
	}

	private void setProperties(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue measure) {
		this.seriesKey = seriesKey;
		this.dimensionId = dimensionId;
		this.dimensionValue = dimensionValue;
		this.measures = new ArrayList<>(1);
		this.measures.add(measure);
		this.measures = Collections.unmodifiableList(this.measures);
		this.measuresMap = new LinkedHashMap<>(measures.size());
		this.measuresMap.put(measure.getConcept(), measure);
		this.measuresMap = Collections.unmodifiableMap(measuresMap);

	}

	private void setProperties(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures) {
		this.seriesKey = seriesKey;
		this.dimensionId = dimensionId;
		this.dimensionValue = dimensionValue;
		if(ObjectUtil.validCollection(measures)) {
			this.measures = new ArrayList<>(measures.size());
			this.measures.addAll(measures);
			this.measuresMap = new LinkedHashMap<>(measures.size());
			for(KeyValue currentKv : measures) {
				this.measuresMap.put(currentKv.getConcept(), currentKv);
			}
			this.measures = Collections.unmodifiableList(this.measures);
		}
	}

	private void setProperties(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> measureList) {
		this.seriesKey = seriesKey;
		this.dimensionId = dimensionId;
		this.dimensionValue = dimensionValue;
		if(primaryMeasure == null) {
			this.measuresMap = new HashMap<String, KeyValue>();
		} else {
			this.measures = new ArrayList<>();
			this.measures.add(primaryMeasure);
			this.measuresMap = new LinkedHashMap<>();
			this.measuresMap.put(primaryMeasure.getConcept(), primaryMeasure);
		}

		if(measureList != null) {
			for (KeyValue kv : measureList) {
				this.measures.add(kv);
				this.measuresMap.put(kv.getConcept(), kv);
			}
		}
		this.measuresMap = Collections.unmodifiableMap(measuresMap);
	}

	private void setComplexMeasures(List<IMultilingualKeyValue> complexMeasures){
		if(complexMeasures != null && complexMeasures.size() > 0) {
			this.multilingualMeasures = new ArrayList<>(complexMeasures.size());
			this.multilingualMeasures.addAll(complexMeasures);
			this.multilingualMeasureMap = new HashMap<>(complexMeasures.size());
			for (IMultilingualKeyValue currentKv : complexMeasures) {
				multilingualMeasureMap.put(currentKv.getConcept(), currentKv);
			}
			this.multilingualMeasures = Collections.unmodifiableList(this.multilingualMeasures);
		}
	}
	
	/**
	 * Creates an Observation for Time-Series data
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return instance with one OBS_VALUE measure
	 */
	public static Observation timeSeries(Keyable seriesKey, String obsTime, String obsValue, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, DimensionBean.TIME_DIMENSION_FIXED_ID, obsTime, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, annotationBeans);
	}

	/**
	 * Creates an Observation for Time-Series data
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param complexAttributes
	 * @param annotationBeans
	 * @return instance with one OBS_VALUE measure
	 */
	public static Observation timeSeries(Keyable seriesKey, String obsTime, String obsValue, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, DimensionBean.TIME_DIMENSION_FIXED_ID, obsTime, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, complexAttributes, annotationBeans);
	}
	
	/**
	 * Creates an Obsevation where the single measure is the specified concept
	 * @param seriesKey
	 * @param obsTime
	 * @param obsConcept
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return
	 */
	public static Observation singleMeasure(Keyable seriesKey, String obsTime, String obsConcept, String obsValue, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		KeyValue primaryMeasure = KeyValueImpl.getInstance(obsConcept, obsValue);
		return new ObservationImpl(seriesKey, DimensionBean.TIME_DIMENSION_FIXED_ID, obsTime, primaryMeasure, attributes, annotationBeans);
	}
	
	/**
	 * 
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return instance with one OBS_VALUE measure
	 */
	public static Observation multipleMeasureTimeSeries(Keyable seriesKey, String obsTime, List<KeyValue> measures, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, DimensionBean.TIME_DIMENSION_FIXED_ID, obsTime, measures, attributes, annotationBeans);
	}

	public static Observation multipleMeasureTimeSeries(Keyable seriesKey, String obsTime, List<KeyValue> measures, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, DimensionBean.TIME_DIMENSION_FIXED_ID, obsTime, null, attributes, measures, complexAttributes, complexMeasures, annotationBeans);
	}
	
	/**
	 * 
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return instance with one OBS_VALUE measure
	 */
	public static Observation crossSection(Keyable seriesKey, String  dimensionId, String dimensionValue, String obsValue, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, annotationBeans);
	}

	public static Observation crossSection(Keyable seriesKey, String  dimensionId, String dimensionValue, String obsValue, List<KeyValue> attributes, List<KeyValue> measures, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, measures, complexAttributes, complexMeasures, annotationBeans);
	}
	
	/**
	 * Multimeasure cross sectional
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return instance with one multiple measure
	 */
	public static Observation multipleMeasureCrossSection(Keyable seriesKey, String dimensionId, String dimensionValue,List<KeyValue> measures, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, measures, attributes, annotationBeans);
	}

	public static Observation multipleMeasureCrossSection(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<IMultilingualKeyValue> multilingualAttributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, primaryMeasure, attributes, multilingualAttributes, annotationBeans);
	}

	public static Observation multipleMeasureCrossSection(Keyable seriesKey, String dimensionId, String dimensionValue, KeyValue primaryMeasure, List<KeyValue> attributes, List<KeyValue> measures, List<IMultilingualKeyValue> multilingualAttributes, List<IMultilingualKeyValue> multilingualMeasures, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, primaryMeasure, attributes, measures, multilingualAttributes, multilingualMeasures, annotationBeans);
	}
	
	public static Observation multipleMeasureCrossSection(Keyable seriesKey, String dimensionId, String dimensionValue, List<KeyValue> measures, List<KeyValue> attributes, List<IMultilingualKeyValue> multilingualAttributes, List<IMultilingualKeyValue> multilingualMeasures, List<AnnotationBean> annotationBeans) {
		return new ObservationImpl(seriesKey, dimensionId, dimensionValue, measures, attributes, multilingualAttributes, multilingualMeasures, annotationBeans);
	}
	
	/**
	 * 
	 * @param seriesKey
	 * @param obsTime
	 * @param obsValue
	 * @param attributes
	 * @param annotationBeans
	 * @return instance with one OBS_VALUE measure
	 */
	public static Observation multipleMeasure(Keyable seriesKey, List<KeyValue> measures, List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, null, null, measures, attributes, annotationBeans);
	}

	public static Observation multipleMeasure(Keyable seriesKey, List<KeyValue> measures, List<KeyValue> attributes, List<IMultilingualKeyValue> complexAttributes, List<IMultilingualKeyValue> complexMeasures, AnnotationBean...annotationBeans) {
		return new ObservationImpl(seriesKey, null, null, null, attributes, measures, complexAttributes, complexMeasures, annotationBeans);
	}
	

	@Override
	public Map<String, List<BigDecimal>> getNumericalMeasureValues() {
		if(parsed == null) {
			parsed = Collections.unmodifiableMap(MeasureUtil.toBigDecimal(measures));
		}
		return parsed;
	}
	
	@Override
	public String getShortCode() {
		return getSeriesKey().getShortCode()+ (getDimensionValue() != null ? ":"+getDimensionValue() : "");
	}

	@Override
	public Keyable getSeriesKey() {
		return seriesKey;
	}

	@Override
	public String getDimensionId() {
		return dimensionId;
	}

	@Override
	public String getDimensionValue() {
		return dimensionValue;
	}
	@Override
	public KeyValue getMeasure(String concept) {
		if (measuresMap.containsKey(concept)){
			return measuresMap.get(concept);
		}
		return null;
	}

	@Override
	public String getMeasureCode(String concept){
		KeyValue measureValue = getMeasure(concept);
		return measureValue == null? null:measureValue.getCode();
	}

	@Override
	public List<KeyValue> getMeasures() {
		return measures;
	}

	@Override
	public List<String> getMeasureValues(String concept) {
		if(measuresMap.containsKey(concept)){
			KeyValue measure = measuresMap.get(concept);
			if(measure.hasMultipleValues()){
				return measure.getValues();
			}else{
				return Collections.singletonList(measure.getCode());
			}
		}
		return null;
	}

	@Override
	public Map<String, KeyValue> getMeasureMap(){
		return measuresMap;
	}

	@Override
	public SdmxDate getSdmxObsTime() {
		if(sdmxDate == null) {
			if(dimensionValue == null || !DimensionBean.TIME_DIMENSION_FIXED_ID.equals(dimensionId) || dimensionValue.equals("")) {
				return null;
			}
			sdmxDate = SdmxDateImpl.getSdmxDate(dimensionValue);
		}
		return sdmxDate;
	}

	@Override
	public int hashCode() {
		if(hashCode == -1) {
			hashCode = new HashCodeBuilder(7, 31).append(this.dimensionId)
					.append(this.dimensionValue)
					.append(this.measuresMap)
					.append(this.sdmxDate)
					.append(this.seriesKey)
					.append(this.getAttributes())
					.append(this.getAnnotations())
					.build();
		}
		return hashCode;
	}

	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    if(!super.equals(obj) ) {
	    	return false;
	    }
	    if(obj instanceof Observation) {
	    	Observation that = (Observation) obj;
	    	if(!ObjectUtil.equivalentMap(that.getMeasures().stream().collect(Collectors.toMap(e->e.getConcept(), e->e)),
					this.getMeasures().stream().collect(Collectors.toMap(e->e.getConcept(), e->e)))) {
	    		return false;
	    	}
	    	if(!ObjectUtil.equivalent(that.getDimensionId(), this.getDimensionId())) {
	    		return false;
	    	}
	    	if(!ObjectUtil.equivalent(that.getDimensionValue(), this.getDimensionValue())) {
	    		return false;
	    	}
	    	return true;
	    }
		return false;
	}

	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(getShortCode());
		String concat = "";
		sb.append(super.toString());
		for(KeyValue kv : getMeasures()) {
			if(kv.hasMultipleValues()){
				sb.append(concat+kv.getConcept()+":"+String.join(";", kv.getValues()));
				concat =";";
			}
			else {
				sb.append(concat + kv.getConcept() + ":" + kv.getCode());
				concat = ",";
			}
		}
		return sb.toString();
	}

	@Override
	public int compareTo(Observation o) {
		if(o == this) {
			return 0;
		}
		if(this.dimensionValue == null) {
			if(o.getDimensionValue() == null) {
				return 0;
			}
			return -1;
		}
		if(o.getDimensionValue() == null) {
			return 1;
		}
		int returnValue = -1;
		if(this.hasObsTime()) {
			if(this.getDimensionValue().length() == o.getDimensionValue().length()) {
				returnValue = this.getDimensionValue().compareTo(o.getDimensionValue());
			} else {
				try {
					returnValue = this.getSdmxObsTime().compareTo(o.getSdmxObsTime());
				} catch (Exception e) {
					// Occurs if either of the observations were not valid dates.
					// If this.obs is valid, return -1.
					// If o.obs is valid, return 1
					// Else they are both invalid so return 0
					try {
						this.getSdmxObsTime();
						return -1;
					} catch (Exception e1) {
						try {
							o.getSdmxObsTime();
							return 1;
						} catch (Exception e2) {
							return 0;
						}
					}
				}
			}
		} else {
			returnValue = this.getDimensionValue().compareTo(o.getDimensionValue());
		}

		if(returnValue == 0) {
			//Compare the measures
			//TreeSet<String> measureIds = new TreeSet<>(o.getMeasureValues().keySet());
			//measureIds.addAll(this.getMeasureValues().keySet());
			for(KeyValue measure : this.getMeasures()) {
				KeyValue v1 = this.getMeasure(measure.getConcept());
				KeyValue v2 = o.getMeasure(measure.getConcept());
				if(ObjectUtil.equivalent(v1, v2)) {
					continue;
				}
				if(v1 == null)  {
					return -1;
				}
				if(v2 == null)  {
					return 1;
				}
				return v1.compareTo(v2);
			}
		}
		return returnValue;
	}

	@Override
	public IMultilingualKeyValue getMultilingualMeasure(String concept){
		return multilingualMeasureMap.get(concept);
	}

	@Override
	public List<IMultilingualKeyValue> getMultilingualMeasures(){
		return multilingualMeasures;
	}

}
