package io.sdmx.im.data.query;

import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.COMPOMNENT_TYPE;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class DataQueryDimensionSelectionImpl implements DataQuerySelection {
	private static final long serialVersionUID = -7578131456147153451L;
	private String concept;
	private Set<String> values = new TreeSet<>();
	private COMPOMNENT_TYPE componentType = COMPOMNENT_TYPE.DIMENSION;
	private MATCH_FUNCTION matchFunction = MATCH_FUNCTION.EQUALS;
	
	public DataQueryDimensionSelectionImpl(DataStructureBean dsd, String concept, MATCH_FUNCTION matchFunction, String... value) {
		if(!ObjectUtil.validString(concept)) {
			throw new SdmxSemmanticException(ExceptionCode.QUERY_SELECTION_MISSING_CONCEPT);
		}
		this.concept = StringUtil.manualIntern(concept);
		setDataStructure(dsd);
		if(value == null || value.length == 0) {
			return;
		}
		for(String currentValue : value) {
			values.add(StringUtil.manualIntern(currentValue));
		}
		if(matchFunction != null) {
			this.matchFunction = matchFunction;
		}
	}
	
	public DataQueryDimensionSelectionImpl(DataStructureBean dsd, String concept, MATCH_FUNCTION matchFunction, Set<String> values) {
		if(!ObjectUtil.validString(concept)) {
			throw new SdmxSemmanticException(ExceptionCode.QUERY_SELECTION_MISSING_CONCEPT);
		}
		this.concept = StringUtil.manualIntern(concept);
		setDataStructure(dsd);
		if(ObjectUtil.validCollection(values)) {
			for(String currentValue : values) {
				String val = StringUtil.manualIntern(currentValue);
				this.values.add(val);
			}
		}
		if(matchFunction != null) {
			this.matchFunction = matchFunction;
		}
	}
	
	private void setDataStructure(DataStructureBean dsd) {
		if(dsd != null) {
			ComponentBean component = dsd.getComponent(concept);
			if(component != null) {
				switch(component.getStructureType()) {
				case DIMENSION :
				this.componentType = COMPOMNENT_TYPE.DIMENSION;
				break;
				case DATA_ATTRIBUTE :
					AttributeBean attribute = (AttributeBean) component;
					switch(attribute.getAttachmentLevel()) {
					case DATA_SET :
						this.componentType = COMPOMNENT_TYPE.DATASET_ATTRIBUTE;
						break;
					case DIMENSION_GROUP :
						this.componentType = COMPOMNENT_TYPE.SERIES_ATTRIBUTE;
						break;
					case OBSERVATION :
						this.componentType = COMPOMNENT_TYPE.OBS_ATTRIBUTE;
						break;
					}
				}
			}
		}
	}
	
	@Override
	public MATCH_FUNCTION getMatchFunction() {
		return matchFunction;
	}

	@Override
	public boolean isExcluded() {
		return matchFunction == MATCH_FUNCTION.NOT_EQUALS;
	}

	@Override
	public COMPOMNENT_TYPE getComponentType() {
		return componentType;
	}

	@Override
	public void addSelectionValue(String... values) {
		if(values != null) {
			for(String value : values) {
				if(value != null) {
					this.values.add(StringUtil.manualIntern(value));
				}
			}
		}
	}

	@Override
	public String getComponentId() {
		return concept;
	}
	
	@Override
	public String getValue() {
		if(values.size() > 1) {
			throw new IllegalArgumentException("More then one value exists for this selection");
		}
		return (String)values.toArray()[0];
	}
	
	@Override
	public Set<String> getValues() {
		return values;
	}
	
	@Override
	public boolean hasMultipleValues() {
		return values.size() > 1;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DataQuerySelection) {
			DataQuerySelection that = (DataQuerySelection)obj;
			if(this.getComponentId().equals(that.getComponentId())) {
				if(this.isExcluded() == that.isExcluded()) {
					if(this.getValues().containsAll(that.getValues())) {
						if(that.getValues().containsAll(this.getValues())) {
							return true;
						}
					}				
				}
			}
		}
		return false;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("");
		sb.append(matchFunction.getFunction()+":");
		sb.append(concept);
		sb.append(" = ");
		String concat = "";
		for(String currentValue : values) {
			sb.append(concat);
			sb.append(currentValue);
			concat = ",";
		}
		return sb.toString();
	}
}
