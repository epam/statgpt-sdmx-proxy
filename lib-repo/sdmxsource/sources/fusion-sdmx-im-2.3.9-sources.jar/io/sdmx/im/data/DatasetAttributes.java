package io.sdmx.im.data;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;

public class DatasetAttributes extends AbstractAttributable implements IDatasetAttributes {
	public static final DatasetAttributes EMPTY_ATTRIBUTES = new DatasetAttributes(null);
	
	
	public DatasetAttributes(List<KeyValue> attributes, AnnotationBean... annotationBeans) {
		super(attributes, annotationBeans);
	}
	
	private DatasetAttributes(DatasetAttributesBuilder builder) {
		super(builder);
	}

	public static DatasetAttributesBuilder builder() {
		return new DatasetAttributesBuilder();
	}

	public static class DatasetAttributesBuilder extends AttributableBuilder<IDatasetAttributes> {

		public DatasetAttributes build() {
			if(position == null &&
				attributes.isEmpty() && 
				multilingualAttributes.isEmpty() && 
				annotations.isEmpty()) {
				return EMPTY_ATTRIBUTES;
			}
			return new DatasetAttributes(this);
		}
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) return true;
		
		if(obj instanceof IDatasetAttributes) {
			return super.equals(obj);
		}
		return false;
	}
	
}
