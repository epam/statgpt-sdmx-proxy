package io.sdmx.im.data;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.Keyable;

/**
 * Overlays positional information on top of a Keyable
 */
public class PositionalKey extends KeyableProxy {
	private IDataPosition position;
	
	public PositionalKey(Keyable proxy, IDataPosition position) {
		super(proxy);
		this.position = position;
	}

	@Override
	public IDataPosition getPosition() {
		return position;
	}
	
}
