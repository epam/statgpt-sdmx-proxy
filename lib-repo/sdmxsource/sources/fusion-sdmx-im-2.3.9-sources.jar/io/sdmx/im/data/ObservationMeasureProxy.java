package io.sdmx.im.data;

import java.math.BigDecimal;
import java.util.*;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.object.MeasureUtil;

/**
 * Proxy on an observation to change the measure values
 */
public class ObservationMeasureProxy extends ObservationProxy {
	private List<KeyValue> measures;
	private Map<String, List<BigDecimal>> parsed;
	
	public ObservationMeasureProxy(Observation proxy, List<KeyValue> measures) {
		super(proxy);
		this.measures = Collections.unmodifiableList(measures);
	}

	public List<KeyValue> getMeasures() {
		return measures;
	}

	public KeyValue getMeasure(String concept) {
		for (KeyValue measure: measures){
			if (Objects.equals(measure.getConcept(), concept)){
				return measure;
			}
		}
		return null;
	}

	public String getMeasureCode(String concept){
		KeyValue measureValue = getMeasure(concept);
		return measureValue == null? null:measureValue.getCode();
	}

	@Override
	public Map<String, List<BigDecimal>> getNumericalMeasureValues() {
		if(parsed == null) {
			parsed = Collections.unmodifiableMap(MeasureUtil.toBigDecimal(measures));
		}
		return parsed;
	}
	
}
