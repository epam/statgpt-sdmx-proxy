package io.sdmx.im.data;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.data.FooterMessage;

public class FooterMessageImpl implements FooterMessage {
	private String code;
	private SEVERITY severity;
	private List<TextTypeWrapper> textType;
	
	
	public FooterMessageImpl(String code, SEVERITY severity, TextTypeWrapper textType) {
		this.code = code;
		this.severity = severity;
		if(code == null) {
			throw new IllegalArgumentException("FooterMessage - Code is mandatory");
		}
		if(textType == null) {
			throw new IllegalArgumentException("FooterMessage - At least one text is required");
		}
		this.textType = new ArrayList<>();
		this.textType.add(textType);
	}
	
	public FooterMessageImpl(String code, SEVERITY severity, List<TextTypeWrapper> textType) {
		this.code = code;
		this.severity = severity;
		this.textType = textType;
		if(code == null) {
			throw new IllegalArgumentException("FooterMessage - Code is mandatory");
		}
		if(textType == null || textType.size() == 0) {
			throw new IllegalArgumentException("FooterMessage - At least one text is required");
		}
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public SEVERITY getSeverity() {
		return severity;
	}

	@Override
	public List<TextTypeWrapper> getFooterText() {
		return textType;
	}

}
