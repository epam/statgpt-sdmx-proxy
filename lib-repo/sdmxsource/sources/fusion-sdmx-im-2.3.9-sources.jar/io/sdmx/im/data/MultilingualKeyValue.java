package io.sdmx.im.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;

public class MultilingualKeyValue implements IMultilingualKeyValue {
    private static final long serialVersionUID = 1L;
    private String concept;
    private List<IMultilingualNodeValue> multilingualNodeValues = Collections.emptyList();

    public static IMultilingualKeyValue getInstance(String concept, List<IMultilingualNodeValue> multilingualNodeValues) {
    	return new MultilingualKeyValue(concept, multilingualNodeValues);
    }

    public MultilingualKeyValue(String concept, List<IMultilingualNodeValue> multilingualNodeValues){
    	this.concept = concept;
    	if(multilingualNodeValues != null) {
    		this.multilingualNodeValues = Collections.unmodifiableList(new ArrayList<>(multilingualNodeValues));
    	}
    }

    @Override
    public List<IMultilingualNodeValue> getMultilingualNodeValues() {
        return multilingualNodeValues;
    }

    @Override
    public String getConcept() {
        return concept;
    }

    @Override
	public int hashCode() {
        return (concept).hashCode();
    }
    
    @Override
	public boolean equals(Object obj) {
    	if (obj instanceof MultilingualKeyValue) {
    		MultilingualKeyValue that = (MultilingualKeyValue)obj;
			return that.toString().equals(this.toString());
		}
		return false;
	}

    @Override
	public String toString() {
        return concept;
    }

    @Override
    public int compareTo(IMultilingualKeyValue compareTo) {
        return concept.compareTo(compareTo.getConcept());
    }
}
