package io.sdmx.im.data;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Overlays positional information on top of an Observation
 */
public class PositionalObservation extends ObservationProxy {
	private IDataPosition position;
	
	public PositionalObservation(Observation proxy, IDataPosition position) {
		super(proxy);
		this.position = position;
	}

	@Override
	public IDataPosition getPosition() {
		return position;
	}
}
