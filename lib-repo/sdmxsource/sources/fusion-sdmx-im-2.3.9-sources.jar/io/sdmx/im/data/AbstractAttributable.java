package io.sdmx.im.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.utils.core.collection.KeyValueUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class AbstractAttributable implements Attributable {
	private List<AnnotationBean>  annotations = Collections.emptyList();
	private List<KeyValue> attributes = Collections.emptyList();
	private List<IMultilingualKeyValue> multilingualAttributes = Collections.emptyList();
	private Map<String, KeyValue> attributeMap = Collections.emptyMap();
	private Map<String, IMultilingualKeyValue> multilingualAttributeMap = Collections.emptyMap();
	private IDataPosition position;
	
	/**
	 * Used to create an instance without having a large constructor
	 */
	public static abstract class AttributableBuilder<T> {
		protected List<AnnotationBean>  annotations = Collections.emptyList();
		protected List<KeyValue> attributes = Collections.emptyList();
		protected List<IMultilingualKeyValue> multilingualAttributes = Collections.emptyList();
		protected IDataPosition position;
		
		public AttributableBuilder<T> annotations(List<AnnotationBean> annotations) {
			this.annotations = annotations;
			return this;
		}
		public AttributableBuilder<T> annotations(AnnotationBean... annotations) {
			if(annotations != null) {
				this.annotations = new ArrayList<>();
				for(AnnotationBean annotation : annotations) {
					if(annotation != null) {
						this.annotations.add(annotation);
					}
				}
			}
			return this;
		}
		public AttributableBuilder<T> addAttribute(KeyValue attribute) {
			if(attribute == null) {
				return this;
			}
			if(!ObjectUtil.validCollection(this.attributes)) {
				this.attributes = new ArrayList<>();
			}
			this.attributes.add(attribute);
			return this;
		}
		public AttributableBuilder<T> attributes(List<KeyValue> attributes) {
			this.attributes = attributes == null ? Collections.emptyList() : attributes;
			return this;
		}
		public AttributableBuilder<T> addAttributeMultilingual(IMultilingualKeyValue attribute) {
			if(attribute == null) {
				return this;
			}
			if(!ObjectUtil.validCollection(this.multilingualAttributes)) {
				this.multilingualAttributes = new ArrayList<>();
			}
			this.multilingualAttributes.add(attribute);
			return this;
		}
		public AttributableBuilder<T> attributesMultilingual(List<IMultilingualKeyValue> attributes) {
			this.multilingualAttributes = attributes == null ? Collections.emptyList() : attributes;
			return this;
		}
		public AttributableBuilder<T> position(IDataPosition position) {
			this.position = position;
			return this;
		}
		
		public abstract T build();
	}
	
	protected AbstractAttributable(AttributableBuilder builder) {
		if(builder == null) return;
		if(ObjectUtil.validCollection(builder.annotations)) {
			this.annotations = Collections.unmodifiableList(new ArrayList<AnnotationBean>(builder.annotations));
		}
		if(ObjectUtil.validCollection(builder.attributes)) {
			this.attributes = Collections.unmodifiableList(new ArrayList<KeyValue>(builder.attributes));
		}
		if(ObjectUtil.validCollection(builder.multilingualAttributes)) {
			this.multilingualAttributes = Collections.unmodifiableList(new ArrayList<IMultilingualKeyValue>(builder.multilingualAttributes));
		}
		if(builder.position != null) {
			this.position = builder.position;
		}
		createMaps();
	}
	
	private AbstractAttributable(List<KeyValue> attributes) {
		this.attributes = attributes;
		createMaps();
	}
	
	public AbstractAttributable(List<KeyValue> attributes, AnnotationBean...annotationBeans) {
		this.attributes = attributes;
		createMaps(annotationBeans);
	}
	
	public AbstractAttributable(List<KeyValue> attributes, List<AnnotationBean> annotations) {
		this.attributes = attributes;
		this.annotations = annotations;
		createMaps();
	}
	public AbstractAttributable(List<KeyValue> attributes, List<IMultilingualKeyValue> multilingualAttributes, List<AnnotationBean> annotations) {
		this(attributes);
		this.multilingualAttributes = multilingualAttributes;
		this.annotations = annotations;
		createMaps();
	}

	public AbstractAttributable(List<KeyValue> attributes, List<IMultilingualKeyValue> multilingualAttributes, AnnotationBean...annotationBeans){
		this(attributes);
		this.multilingualAttributes = multilingualAttributes;
		createMaps(annotationBeans);
	}
	
	private void createMaps(AnnotationBean...annotationBeans) {
		if(ObjectUtil.validCollection(multilingualAttributes)) {
			this.multilingualAttributes = new ArrayList<>(multilingualAttributes);
			this.multilingualAttributeMap = new HashMap<>(multilingualAttributes.size());
			for (IMultilingualKeyValue currentKv : multilingualAttributes) {
				multilingualAttributeMap.put(currentKv.getConcept(), currentKv);
			}
			this.multilingualAttributes = Collections.unmodifiableList(this.multilingualAttributes);
		} else {
			this.multilingualAttributes = Collections.emptyList();
		}
		
		if(ObjectUtil.validCollection(attributes)) {
			this.attributes = new ArrayList<>(attributes);
			this.attributeMap = new HashMap<>(attributes.size());
			for(KeyValue currentKv : attributes) {
				attributeMap.put(currentKv.getConcept(), currentKv);
			}
			this.attributes = Collections.unmodifiableList(this.attributes);
		} else {
			this.attributes = Collections.emptyList();
		}
		if(annotationBeans != null && annotationBeans.length > 0) {
			List<AnnotationBean> anno = new ArrayList<>(annotationBeans.length);
			for(AnnotationBean currentAnnotation : annotationBeans) {
				if(currentAnnotation != null) {
					anno.add(currentAnnotation);
				}
			}
			this.annotations = Collections.unmodifiableList(anno);
		} else if(ObjectUtil.validCollection(annotations)) {
			this.annotations = new ArrayList<>(annotations);
			this.annotations = Collections.unmodifiableList(annotations);
		} else {
			this.annotations = Collections.emptyList();
		}
	}

	@Override
	public List<AnnotationBean> getAnnotations() {
		return annotations;
	}
	
	@Override
	public List<KeyValue> getAttributes() {
		return attributes;
	}

	@Override
	public KeyValue getAttribute(String concept) {
		return attributeMap.get(concept);
	}

	@Override
	public IMultilingualKeyValue getMultilingualAttribute(String concept){
		return multilingualAttributeMap.get(concept);
	}

	@Override
	public List<IMultilingualKeyValue> getMultilingualAttributes(){
		return multilingualAttributes;
	}
	
	@Override
	public IDataPosition getPosition() {
		return position;
	}

	@Override
	public boolean hasAnnotations() {
		return ObjectUtil.validCollection(annotations);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		//TODO This does not take into account multilingual key values, it seems only required for unit tests and
		//would probably be better served to externlise the equality checks between two Obs/Series/etc via an external utility method
		
		if(obj == this) return true;
		
		if(obj instanceof Attributable) {
			Attributable that = (Attributable) obj;
			if(!ObjectUtil.equivalentMap(that.getAttributes().stream().collect(Collectors.toMap(e->e.getConcept(), e->e)), attributeMap)) {
				return false;
			}
			if(!ObjectUtil.equivalentMap(that.getMultilingualAttributes().stream().collect(Collectors.toMap(e->e.getConcept(), e->e)), multilingualAttributeMap)) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getAnnotations(), this.getAnnotations())) {
	    		return false;
	    	}
			return true;
			//Same Attributes
			
		}
		return false;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(KeyValue kv : getAttributes()) {
			sb.append(concat+ KeyValueUtil.getValueString(kv));
			concat = ",";
		}
		return sb.toString();
	}
}
