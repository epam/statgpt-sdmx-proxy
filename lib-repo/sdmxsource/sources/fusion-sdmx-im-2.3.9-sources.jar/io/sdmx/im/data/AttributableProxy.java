package io.sdmx.im.data;

import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDataPosition;

public abstract class AttributableProxy implements Attributable {
	private Attributable proxy;
	
	public AttributableProxy(Attributable proxy) {
		this.proxy = proxy;
	}

	@Override
	public List<KeyValue> getAttributes() {
		return proxy.getAttributes();
	}

	@Override
	public KeyValue getAttribute(String concept) {
		return proxy.getAttribute(concept);
	}

	@Override
	public IMultilingualKeyValue getMultilingualAttribute(String concept){
		return proxy.getMultilingualAttribute(concept);
	}
	@Override
	public List<IMultilingualKeyValue> getMultilingualAttributes() {
		return proxy.getMultilingualAttributes();
	}

	@Override
	public boolean hasAnnotations() {
		return proxy.hasAnnotations();
	}

	@Override
	public List<AnnotationBean> getAnnotations() {
		return proxy.getAnnotations();
	}

	@Override
	public String getAttributeValue(String concept) {
		return proxy.getAttributeValue(concept);
	}
	
	@Override
	public IDataPosition getPosition() {
		return proxy.getPosition();
	}
	
	@Override
	public String toString() {
		return proxy.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return proxy.equals(obj);
	}

	@Override
	public int hashCode() {
		return proxy.hashCode();
	}
}
