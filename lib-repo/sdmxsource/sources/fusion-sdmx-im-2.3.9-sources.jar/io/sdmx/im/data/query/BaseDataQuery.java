package io.sdmx.im.data.query;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Base Data query for both simple and complex queries
 */
public abstract class BaseDataQuery implements io.sdmx.api.sdmx.model.data.query.BaseDataQuery {
	private static final long serialVersionUID = 1L;
	private Set<DataProviderBean> dataProviders = new HashSet<>();
	protected String dimensionAtObservation;
	protected Set<ProvisionAgreementBean> provisionAgreement = new HashSet<>();
	protected Map<String, String> extraParameters = new HashMap<>();
	protected Set<String> excludeAttributes = new HashSet<>();
	protected Integer firstNObs;
	protected Integer lastNObs;
	protected Integer maxSeries;
	protected Integer maxObs;
	protected DataflowBean dataflowBean;
	protected DataStructureBean dataStructureBean;
	protected SdmxDate lastUpdated;
	protected DATA_QUERY_DETAIL dataQueryDetail = DATA_QUERY_DETAIL.FULL;
	private SdmxDate dateFrom;
	private SdmxDate dateTo;
	protected transient String hash;

	@Override
	public void setDataProvider(DataProviderBean dataProvider) {
		this.hash = null;
		dataProviders = new HashSet<>();
		if(dataProvider != null) {
			dataProviders.add(dataProvider);
		}
	}
	
	

	@Override
	public Set<String> getExcludeAttributes() {
		return Collections.unmodifiableSet(excludeAttributes);
	}



	@Override
	public void addExcludeAttribute(String attrId) {
		this.excludeAttributes.add(attrId);
		hash = null;
	}



	@Override
	public Set<DataProviderBean> getDataProvider() {
		return new HashSet<>(dataProviders);
	}

	public void addDataProvider(DataProviderBean dataProvider) {
		if(dataProvider != null) {
			dataProviders.add(dataProvider);
		}
	}
	
	@Override
	public boolean hasObservationRestrictions() {
		return hasDateRestrictions() || firstNObs != null || lastNObs != null;
	}



	@Override
	public void clearDateFrom() {
		this.dateFrom = null;
		this.hash = null;
	}



	@Override
	public void clearDateTo() {
		this.dateTo = null;
		this.hash = null;
	}



	@Override
	public boolean hasDateRestrictions() {
		return dateFrom != null || dateTo != null;
	}

	@Override
	public SdmxDate getStartPeriod() {
		return dateFrom;
	}

	@Override
	public SdmxDate getEndPeriod() {
		return dateTo;
	}

	@Override
	public Integer getMaxObservations() {
		return maxObs;
	}

	@Override
	public Integer getMaxSeries() {
		return maxSeries;
	}

	@Override
	public void setMaxObservations(Integer max) {
		this.maxObs = max;
	}

	@Override
	public void setMaxSeries(Integer max) {
		this.maxSeries = max;
	}

	@Override
	public void setDateFrom(String date) {
		hash = null;
		this.dateFrom = null;
		if(ObjectUtil.validString(date)) {
			setDateFrom(SdmxDateImpl.getSdmxDate(date));
		}
	}

	@Override
	public void setDateTo(String date) {
		hash = null;
		this.dateTo = null;
		if(ObjectUtil.validString(date)) {
			setDateTo(SdmxDateImpl.getSdmxDate(date, false));
		}
	}

	@Override
	public void setDateFrom(Date date) {
		hash = null;
		if(date == null) {
			this.dateFrom = null;
		} else {
			setDateFrom(new SdmxDateImpl(date, TIME_FORMAT.DATE));
		}
	}

	@Override
	public void setDateFrom(SdmxDate date) {
		hash = null;
		if(date != null) {
			if(!date.isStartPeriod()) {
				date = SdmxDateImpl.getSdmxDate(date.getDateInSdmxFormat());  //convert to start of period
			}
		}
		this.dateFrom = date;
	}

	@Override
	public void setDateTo(Date date) {
		hash = null;
		if(date == null) {
			this.dateTo = null;
		} else {
			setDateTo(new SdmxDateImpl(date, TIME_FORMAT.DATE, false));
		}
	}

	@Override
	public void setDateTo(SdmxDate date) {
		hash = null;
		this.dateTo= date;
	}

	@Override
	public SdmxPeriod getQueryPeriod() {
		if(dateFrom != null || dateTo != null) {
			return new SdmxPeriodImpl(dateFrom, dateTo);
		}
		return null;
	}

	protected void validateQuery() {
		if(dataflowBean == null) {
			throw new SdmxSemmanticException("Can not create DataQuery, Dataflow is required");
		}
		if(dataStructureBean == null) {
			throw new SdmxSemmanticException("Can not create DataQuery, DataStructure is required");
		}
		validateDimensionAtObservation();
	}

	/**
	 * If no dimension at observation is set, then the following rules apply in the order specified:
	 * <ol>
	 *  <li>Set to Time Dimension (if it exists)</li>
	 *  <li>Set to the first Measure Dimension (if one exists)</li>
	 *  <li>Set to AllDimensions</li>
	 * </ol>
	 *
	 * If the dimension at observation is set, then it is validated to exist
	 */
	private void validateDimensionAtObservation() {
		if(dimensionAtObservation == null) {
			if(dataStructureBean.getTimeDimension() != null) {
				dimensionAtObservation = dataStructureBean.getTimeDimension().getId();
			} else if(dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).size() > 0){
				dimensionAtObservation = dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).get(0).getId();
			} else {
				dimensionAtObservation = "AllDimensions";
			}
		} else if(!dimensionAtObservation.equals("AllDimensions")){
			DimensionBean dimension = dataStructureBean.getDimension(dimensionAtObservation);
			if (dimension==null) {
				StringBuilder sb = new StringBuilder();
				sb.append("AllDimensions");
				for(DimensionBean dim : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
					sb.append(System.getProperty("line.separator"));
					sb.append(dim.getId());
				}
				throw new SdmxSemmanticException("Can not create DataQuery, The dimension at observation '"+dimensionAtObservation+"' is not included in the Dimension list of the DSD.  Allowed values are "+ sb.toString());
			}
		}
	}


	@Override
	public DataStructureBean getDataStructure() {
		return dataStructureBean;
	}

	@Override
	public DATA_QUERY_DETAIL getDataQueryDetail() {
		return dataQueryDetail;
	}

	@Override
	public SdmxDate getLastUpdatedDate() {
		return lastUpdated;
	}

	@Override
	public Integer getLastNObservations() {
		return lastNObs;
	}

	@Override
	public Integer getFirstNObservations() {
		return firstNObs;
	}

	@Override
	public DataflowBean getDataflow() {
		return dataflowBean;
	}

	@Override
	public Set<ProvisionAgreementBean> getProvisionAgreements() {
		return provisionAgreement;
	}

	@Override
	public void addProvisionAgreement(ProvisionAgreementBean provision) {
		this.hash = null;
		if(provision != null) {
			provisionAgreement.add(provision);
		}
	}

	@Override
	public void clearProvisionAgreements() {
		this.hash = null;
		provisionAgreement = new HashSet<>();
	}

	@Override
	public Set<String> getParameters() {
		return new TreeSet<>(extraParameters.keySet());
	}

	@Override
	public String getParameter(String parameter) {
		if(parameter == null) {
			return null;
		}
		return extraParameters.get(parameter.toLowerCase());
	}

	@Override
	public String addParameter(String paramName, String paramValue) {
		this.hash = null;
		if(paramName == null) {
			return null;
		}
		paramName = paramName.toLowerCase();
		return extraParameters.put(paramName, paramValue);
	}

	@Override
	public void setFirstNObs(Integer firstNObs) {
		this.hash = null;
		if(firstNObs != null && firstNObs > 0) {
			this.firstNObs = firstNObs;
		} else {
			this.firstNObs = null;
		}
	}

	@Override
	public void setLastNObs(Integer lastNObs) {
		this.hash = null;
		if(lastNObs != null && lastNObs > 0) {
			this.lastNObs = lastNObs;
		} else {
			this.lastNObs = null;
		}
	}

	@Override
	public void setLastUpdated(SdmxDate lastUpdated) {
		this.hash = null;
		this.lastUpdated = lastUpdated;
	}

	@Override
	public void setDataQueryDetail(DATA_QUERY_DETAIL dataQueryDetail) {
		this.hash = null;
		this.dataQueryDetail = dataQueryDetail;
	}
}
