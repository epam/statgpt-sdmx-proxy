package io.sdmx.im.data.query;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.api.sdmx.model.query.RESTDataQuery;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.sdmx.structure.DataQueryUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;
import io.sdmx.utils.sdmx.xs.VersionRef;

public class DataQueryImpl extends BaseDataQuery implements DataQuery {
	private static final long serialVersionUID = 1L;

	private boolean includeHistory;
	private String datasetId;
	private String expression;
	private Map<String, Map<MATCH_FUNCTION, DataQuerySelection>> selectionForConcept = new TreeMap<>();
	private int offset = 0;
	private int max = -1;
	private Set<String> series = new TreeSet<>();  //ordered set to create consistent hash, and ensure unit tests are in a predictable order
	
	/**
	 * Copy Constructor
	 * @param dataQuery
	 * @param dataQueryDetail
	 */
	public DataQueryImpl(DataQuery dataQuery, DATA_QUERY_DETAIL dataQueryDetail) {
		this(dataQuery.getDataStructure(), dataQuery.getDataflow(), null, dataQueryDetail);
		this.includeHistory = dataQuery.includeHistory();
		this.datasetId = dataQuery.getDatasetId();
		this.expression = dataQuery.getExpression();
		this.dimensionAtObservation = dataQuery.dimensionAtObservation();
		this.extraParameters = new HashMap<>();
		this.firstNObs = dataQuery.getFirstNObservations();
		this.lastNObs = dataQuery.getLastNObservations();
		this.maxSeries = dataQuery.getMaxSeries();
		this.series = dataQuery.getSeries();
		this.maxObs = dataQuery.getMaxObservations();
		this.dataflowBean = dataQuery.getDataflow();
		this.dataStructureBean = dataQuery.getDataStructure();
		this.lastUpdated = dataQuery.getLastUpdatedDate();
		this.dataQueryDetail = dataQueryDetail;
		
		for(DataQuerySelection selection : dataQuery.getSelections()) {
			addDataQuerySelections(selection.getComponentId(), selection.getMatchFunction(), CollectionUtil.toArray(selection.getValues()));
		}
	}

	public static DataQuery buildEmptyQuery(DataStructureBean dataStructureBean, DataflowBean dataflowBean, DATA_QUERY_DETAIL dataQueryDetail) {
		return new DataQueryImpl(dataStructureBean, dataflowBean, dataQueryDetail);
	}

	public static DataQuery buildEmptyQuery(DataStructureBean dataStructureBean, DataflowBean dataflowBean, String datasetid, DATA_QUERY_DETAIL dataQueryDetail) {
		return new DataQueryImpl(dataStructureBean, dataflowBean, datasetid, dataQueryDetail);
	}
	

	/**
	 * Build from a REST query and a bean retrieval manager
	 * @param restDataQuery
	 * @param retrievalManager
	 */
	public DataQueryImpl(RESTDataQuery restDataQuery, SdmxBeanRetrievalManager retrievalManager) {
		if(restDataQuery.getProviderRef() != null) {
			DataProviderBean provider = retrievalManager.getBean(restDataQuery.getProviderRef());
			if(provider == null) {
				throw new SdmxNoResultsException("Data provider does not exist. "+restDataQuery.getProviderRef());
			}
			addDataProvider(provider);
		}
		if(restDataQuery.getProvisionRef() != null) {
			addProvisionAgreement(retrievalManager.getBean(restDataQuery.getProvisionRef()));
		}

		if(ObjectUtil.validString(restDataQuery.getDimensionAtObservation())) {
			this.dimensionAtObservation = restDataQuery.getDimensionAtObservation();
		}
		IURN<DataflowBean> flowRefPossibleWildcard = restDataQuery.getFlowRef();
		
		IURNSingle<DataflowBean> flowRef = resolveToSingleInstance(flowRefPossibleWildcard, retrievalManager);
		if(!ObjectUtil.validString(flowRef.getMaintainableId())) {
			throw new SdmxSemmanticException("Can not process query '"+restDataQuery.getRestQuery()+"' missing Dataflow Id");
		}

		this.dataflowBean = retrievalManager.getBean(flowRef);
		if(dataflowBean == null) {
			throw new SdmxNoResultsException("No Dataflow exists for query : " + restDataQuery.getFlowRef());
		}

		this.dataStructureBean = retrievalManager.getBean(dataflowBean.getDataStructureRef().getReference());
		if(dataStructureBean == null) {
			throw new SdmxSemmanticException("DSD could not be found for query : " + dataflowBean.getDataStructureRef());
		}
		setQueryParameters(restDataQuery);

		validateQuery();
	}
	
	private IURNSingle<DataflowBean> resolveToSingleInstance(IURN<DataflowBean> urn, SdmxBeanRetrievalManager retrievalManager) {
		if(!urn.hasAgencyId() || urn.getVersion().isAll()) {
			//Determine the value
			String agencyIdResolved = null;
			
			for(DataflowBean df : retrievalManager.getMaintainableBeans(urn)) {
				if(!urn.hasAgencyId()) {
					if(agencyIdResolved != null && !df.getAgencyId().equals(agencyIdResolved)) {
						throw new SdmxSemmanticException("Multiple Dataflows exist with Id: "+urn.getMaintainableId());
					} 
					agencyIdResolved = df.getAgencyId();
				}
			}
			//Unable to resolve agency, Dataflow does not exist
			if(!urn.hasAgencyId() && agencyIdResolved == null) {
				throw new SdmxNoResultsException("No Data for Dataflow");
			}
			
			//If we have got here then the version must have been resolved if it was missing
			
			URNBuilder urnBuilder = URN.builder(urn);
			if(agencyIdResolved != null) {
				urnBuilder.agencyId(agencyIdResolved);
			} 
			if(urn.getVersion().isAll()) {
				urnBuilder.versionRef(VersionRef.LATEST_ANY);
			}
			return urnBuilder.buildSingle(DataflowBean.class);
		}
		return urn.asSingle();
	}
	
	private DataQueryImpl(DataStructureBean dataStructureBean, DataflowBean dataflowBean, DATA_QUERY_DETAIL dataQueryDetail) {
		this(dataStructureBean, dataflowBean, null, dataQueryDetail);
	}

	private DataQueryImpl(DataStructureBean dataStructureBean, DataflowBean dataflowBean, String datasetId, DATA_QUERY_DETAIL dataQueryDetail) {
		this.dataStructureBean = dataStructureBean;
		this.dataQueryDetail = dataQueryDetail;
		this.dataflowBean = dataflowBean;
		this.datasetId = datasetId;
		validateQuery();
	}

	/**
	 * Full Constructor - only used in test
	 * @param dataStructureBean (required)
	 * @param lastUpdated
	 * @param dataQueryDetail
	 * @param firstNObs
	 * @param lastNObs
	 * @param dataProviders
	 * @param dataflowBean  (required)
	 * @param dimensionAtObservation
	 * @param selections
	 * @param dateFrom
	 * @param dateTo
	 */
	public DataQueryImpl(DataStructureBean dataStructureBean,
			SdmxDate lastUpdated,
			DATA_QUERY_DETAIL dataQueryDetail,
			Integer firstNObs,
			Integer lastNObs,
			Set<DataProviderBean> dataProviders,
			DataflowBean dataflowBean,
			String dimensionAtObservation,
			Set<DataQuerySelection> selections,
			Date dateFrom, Date dateTo) {
		this.dataStructureBean = dataStructureBean;
		if(dataProviders != null) {
			for(DataProviderBean dp : dataProviders) {
				super.addDataProvider(dp);
			}
		}
		SdmxDate sdmxDateFrom = null;
		if(dateFrom != null) {
			sdmxDateFrom = new SdmxDateImpl(dateFrom, TIME_FORMAT.DATE);
		}
		SdmxDate sdmxDateTo = null;
		if(dateTo != null) {
			sdmxDateTo = new SdmxDateImpl(dateTo, TIME_FORMAT.DATE);
		}
		setSelections(selections);
		this.setDateFrom(sdmxDateFrom);
		this.setDateTo(sdmxDateTo);
		this.dataflowBean = dataflowBean;
		this.lastUpdated = lastUpdated;
		this.dataQueryDetail = dataQueryDetail;
		this.dimensionAtObservation = dimensionAtObservation;
		this.firstNObs = firstNObs;
		this.lastNObs = lastNObs;
		validateQuery();
	}

	public DataQueryImpl(DataStructureBean dataStructureBean,
			SdmxDate lastUpdated,
			DATA_QUERY_DETAIL dataQueryDetail,
			Integer maxObs,
			boolean orderAsc,
			Set<DataProviderBean> dataProviders,
			DataflowBean dataflowBean,
			String dimensionAtObservation,
			Set<DataQuerySelection> selections,
			Date dateFrom, Date dateTo) {
		this.dataStructureBean = dataStructureBean;
		this.lastUpdated = lastUpdated;
		if(dataQueryDetail != null) {
			this.dataQueryDetail = dataQueryDetail;
		}
		if(orderAsc) {
			this.firstNObs = maxObs;
		} else {
			this.lastNObs = maxObs;
		}
		if(dataProviders != null) {
			for(DataProviderBean dp : dataProviders) {
				super.addDataProvider(dp);
			}
		}
		this.dataflowBean = dataflowBean;
		this.dimensionAtObservation = dimensionAtObservation;
		SdmxDate sdmxDateFrom = null;
		if(dateFrom != null) {
			sdmxDateFrom = new SdmxDateImpl(dateFrom, TIME_FORMAT.DATE);
		}
		SdmxDate sdmxDateTo = null;
		if(dateTo != null) {
			sdmxDateTo = new SdmxDateImpl(dateTo, TIME_FORMAT.DATE);
		}
		setSelections(selections);
		this.setDateFrom(sdmxDateFrom);
		super.setDateTo(sdmxDateTo);
		validateQuery();
	}

	
	@Override
	public Map<MATCH_FUNCTION, DataQuerySelection> getSelectionsForConcept(String componentId) {
		Map<MATCH_FUNCTION, DataQuerySelection> selections = selectionForConcept.get(componentId);
		if(selections == null) {
			return Collections.emptyMap();
		}
		return selections;
	}

	@Override
	public boolean hasSelectionForConcept(String componentId) {
		return selectionForConcept.containsKey(componentId);
	}

	@Override
	public Set<DataQuerySelection> getSelections() {
		Set<DataQuerySelection> selections = new LinkedHashSet<>();
		for(String dimId : selectionForConcept.keySet()) {
			selections.addAll(selectionForConcept.get(dimId).values());
		}
		return selections;
	}


	@Override
	public String getHash() {
		if(hash == null) {
			hash = DataQueryUtil.genereateHash(this);
		}
		return hash;
	}

	@Override
	public void addQuerySelection(String conceptId, String selection, MATCH_FUNCTION matchFunction) {
		hash = null;
		addDataQuerySelections(conceptId, matchFunction, selection);
	}

	@Override
	public void addQuerySelections(String conceptId, Set<String> selections, MATCH_FUNCTION matchFunction) {
		hash = null;
		addDataQuerySelections(conceptId, matchFunction, CollectionUtil.toArray(selections));
	}
	
	private void addDataQuerySelections(String conceptId, MATCH_FUNCTION matchFunction, String...values) {
		Map<MATCH_FUNCTION, DataQuerySelection> map = selectionForConcept.get(conceptId);
		if(map == null) {
			map = new TreeMap<>();
			selectionForConcept.put(conceptId, map);
		}
		DataQuerySelection dqs = map.get(matchFunction);
		if(dqs == null) {
			map.put(matchFunction, new DataQueryDimensionSelectionImpl(dataStructureBean, conceptId, matchFunction, values));
		} else {
			dqs.addSelectionValue(values);
		}
	}

	@Override
	public void clearQuerySelections(String coneptId) {
		selectionForConcept.remove(coneptId);
	}
	
	
	@Override
	public Set<String> getSeries() {
		return Collections.unmodifiableSet(this.series);
	}

	@Override
	public void addSeriesSelection(String... series) {
		if(series != null) {
			int dimSize = super.dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION).size();
			
			this.hash = null;
			
			for(String seriesArg : series) {
				for(String currentSeries : seriesArg.split(",")) {
					if(currentSeries.contains(".")) {
						currentSeries = currentSeries.replaceAll("\\.", ":");
					}
					String[] keySplit = SeriesUtil.splitKey(currentSeries);
					int serSize = keySplit.length;
					if(serSize < dimSize) {
						StringBuilder sb = new StringBuilder(currentSeries);
						while(serSize < dimSize) {
							sb.append(":");
							serSize++;
						}
						currentSeries = sb.toString();
					}
					this.series.addAll(SeriesUtil.expandSeries(currentSeries));
				}
			}
		}
	}

	@Override
	public void removeSeriesSelection(String... series) {
		if(series != null) {
			this.hash = null;
			for(String currentSeries : series) {
				this.series.remove(currentSeries);
			}
		}
	}

	@Override
	public void clearSeriesSelections() {
		if(this.series.size() > 0) {
			this.hash = null;
			this.series = new TreeSet<>();
		}
	}

	/**
	 * Sets the query parameters based on the REST query.  This sets query parameters from the dimension selections and Matrix Parameters.
	 * It only sets query parameters from the Matrix parameters if the Component exists on the DSD.  This method does not alter the Dataflow or DSD
	 * used by the DataQuery, just the dimension and time filters of the query.
	 * @param restDataQuery
	 */
	@Override
	public void setQueryParameters(RESTDataQuery restDataQuery) {
		this.lastUpdated = restDataQuery.getUpdatedAfter();
		this.datasetId = restDataQuery.getDatasetId();
		if(restDataQuery.getQueryDetail() != null) {
			this.dataQueryDetail = restDataQuery.getQueryDetail();
		}
		this.includeHistory = restDataQuery.includeHistory();
		this.firstNObs = restDataQuery.getFirstNObservations();
		this.lastNObs = restDataQuery.getLastNObservations();
		this.expression = restDataQuery.getExpression();
		if(restDataQuery.getMax() != null) {
			this.max = restDataQuery.getMax();
		}
		if(restDataQuery.getOffset() != null) {
			this.offset = restDataQuery.getOffset();
		}
		

		Map<String, String> queryParams = restDataQuery.getAdditionalQueryParmeters();
		for(String paramName : queryParams.keySet()) {
			addParameter(paramName, queryParams.get(paramName));
		}

		if(restDataQuery.getQueryList().size() > 0) {
			int i = 0;
			for(DimensionBean dimension : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
				if(restDataQuery.getQueryList().size() <= i) {
					break;
					//throw new SdmxSemmanticException("Not enough key values in query, expecting "+dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).size()+" got "+restDataQuery.getQueryList().size());
				}
				Set<String> queriesForDimension  = restDataQuery.getQueryList().get(i);
				if(queriesForDimension != null && queriesForDimension.size() > 0) {
					addQuerySelections(dimension.getId(), queriesForDimension, MATCH_FUNCTION.EQUALS);
				}
				i++;
			}
		}
		super.setDateFrom(restDataQuery.getStartPeriod());
		super.setDateTo(restDataQuery.getEndPeriod());
	}

	private Integer parseInt(String str) {
		if(!ObjectUtil.validString(str)) {
			return null;
		}
		try {
			return Integer.valueOf(str);
		} catch(Throwable th) {
			throw new SdmxSemmanticException("Query Parameter has value of '"+str+"' which is not of expected type int");
		}
	}




	@Override
	public String addParameter(String paramName, String paramValue) {
		if(paramName.equalsIgnoreCase("serieslimit")) {
			this.maxSeries = parseInt(paramValue);
			return null;

		}
		if(paramName.equalsIgnoreCase("obslimit")) {
		    this.maxObs = parseInt(paramValue);
			return null;
		}
		return super.addParameter(paramName, paramValue);
	}

	@Override
	public String getExpression() {
		return expression;
	}


	@Override
	public boolean includeHistory() {
		return includeHistory;
	}

	public DataQuery setIncludeHistory(boolean includeHistory) {
        this.includeHistory = includeHistory;
        this.hash = null;
        return this;
    }

    @Override
	public String getDatasetId() {
		return datasetId;
	}

	@Override
	public int getOffset() {
		if(offset < 0) {
			return 0;
		}
		return offset;
	}

	@Override
	public void setOffset(int offset) {
		this.offset = offset;
		 this.hash = null;
	}

	@Override
	public int getLimit() {
		return max;
	}

	@Override
	public void setLimit(int limit) {
		this.max = limit;
		this.hash = null;
	}

	@Override
	public String dimensionAtObservation() {
		return dimensionAtObservation;
	}

	@Override
	public void setDimensionAtObservation(String dimAtObs) {
		this.dimensionAtObservation = dimAtObs;
		this.hash = null;
	}

	@Override
	public boolean hasSelections() {
		return this.selectionForConcept.size() > 0 || getQueryPeriod() != null || ObjectUtil.validCollection(getSeries());
	}

	private void setSelections(Set<DataQuerySelection> selections) {
		selectionForConcept = new TreeMap<>();
		if(selections != null) {
			for(DataQuerySelection sel : selections) {
				addQuerySelections(sel.getComponentId(), sel.getValues(), sel.getMatchFunction());
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String newLine = System.getProperty("line.separator");
		if(dataStructureBean != null) {
			sb.append(newLine+"Data Structure : " + dataStructureBean.getUrn());
		}
		if(dataflowBean != null) {
			sb.append(newLine+"Dataflow : " + dataflowBean.getUrn());
		}
		if(getDataProvider() != null) {
			for(DataProviderBean dataProvider : getDataProvider()) {
				sb.append(newLine+"Data Provider  : " + dataProvider.getUrn());
			}
		}

		//ADD SELECTION INFORMATION
		if(hasSelections()) {
			String concat = "";
			sb.append("(");
			for(DataQuerySelection dqs : getSelections()) {
				sb.append(concat + dqs.getComponentId());
				if(dqs.isExcluded()) {
					sb.append(" != ");
				} else {
					sb.append(" = " );
				}
				sb.append("(" );
				concat = "";
				for(String val : dqs.getValues()) {
					sb.append(concat + val);
					concat = " OR ";
				}
				sb.append(")");
				concat = " AND ";
			}
			SdmxPeriod period = getQueryPeriod();

			if(period != null) {
				if(period.getStartPeriod() != null) {
					sb.append(concat + " Date >= " + period.getStartPeriod().getDateInSdmxFormat());
					concat = " AND ";
				}
				if(period.getEndPeriod() != null) {
					sb.append(concat + " Date <= " + period.getEndPeriod().getDateInSdmxFormat());
					concat = " AND ";
				}
			}
			sb.append(")");
		}

		return sb.toString();
	}

}
