package io.sdmx.im.error;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.http.HTTP_STATUS;
import io.sdmx.api.sdmx.model.error.ISdmxError;

public class SdmxError implements ISdmxError {
	private HTTP_STATUS httpCode;
	private int sdmxCode;
	private List<String> errorMessages;
	
	public SdmxError(HTTP_STATUS httpCode, int sdmxCode, List<String> errorMessages) {
		this.httpCode = httpCode;
		this.sdmxCode = sdmxCode;
		if(errorMessages == null) {
			this.errorMessages = Collections.emptyList();
		} else {
			this.errorMessages = Collections.unmodifiableList(errorMessages);
		}
	}

	@Override
	public HTTP_STATUS getHttpCode() {
		return httpCode;
	}
	

	@Override
	public SDMX_ERROR_CODE getSdmxErrorCode() {
		return SDMX_ERROR_CODE.parseClientCode(getSDMXCode());
	}

	@Override
	public int getSDMXCode() {
		return sdmxCode;
	}

	@Override
	public List<String> getErrorMessage() {
		return errorMessages;
	}
}
