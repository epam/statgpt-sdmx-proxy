package io.sdmx.im.availability;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.availability.IAvailabilityInfo;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.utils.core.collection.CollectionUtil;

public class AvailabilityInfo implements IAvailabilityInfo {
	private Set<DataProviderBean> dataProviders;
	private IDatasetStructures structures;
	private Map<String, Set<String>> validKeys;
	private long seriesCount;
    private long obsCount;
	
	public AvailabilityInfo(IDatasetStructures structures,
	                        Set<DataProviderBean> dataProviders,
	                        Map<String, Set<String>> validKeys,
	                        long seriesCount,
	                        long obsCount) {
		this.dataProviders = dataProviders == null ? Collections.emptySet() : dataProviders;
		this.structures = structures;
		this.validKeys = validKeys == null ? Collections.emptyMap() : CollectionUtil.getImmutableMapOfSets(validKeys);
		this.seriesCount = seriesCount;
        this.obsCount = obsCount;
	}

	@Override
	public Set<DataProviderBean> getDataProviders() {
		return dataProviders;
	}

	@Override
    public IDatasetStructures getStructures() {
        return structures;
    }
	
	@Override
    public Map<String, Set<String>> getValidValues() {
        return validKeys;
    }
	
	@Override
	public long getSeriesCount() {
		return seriesCount;
	}
	
	@Override
    public long getObsCount() {
        return obsCount;
    }
}
