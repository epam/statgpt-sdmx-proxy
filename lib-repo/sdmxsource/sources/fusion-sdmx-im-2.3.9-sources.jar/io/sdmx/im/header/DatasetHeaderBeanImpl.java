
package io.sdmx.im.header;

import java.util.Date;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.utils.core.object.ObjectUtil;


public class DatasetHeaderBeanImpl implements DatasetHeaderBean {
    private IURNAbsolute<DataProviderBean> dataProviderRef;
    private DatasetStructureReferenceBean datasetStructureReferenceBean;
    private String datasetId;
    private Date reportingBeginDate;
    private Date reportingEndDate;
    private Date validFrom;
    private Date validTo;
    private DATASET_ACTION action = DATASET_ACTION.INFORMATION;
    private int publicationYear = -1;
    private String publicationPeriod;
    
	/**
     * Minimal Constructor
     * @param datasetId
     * @param action
     * @param datasetStructureReferenceBean
     */
    public DatasetHeaderBeanImpl(String datasetId, DATASET_ACTION action, DatasetStructureReferenceBean datasetStructureReferenceBean) {
        this.datasetId = datasetId;
        if(action != null) {
            this.action = action;
        }
        this.datasetStructureReferenceBean = datasetStructureReferenceBean;
    }

    public DatasetHeaderBeanImpl(String datasetId, DATASET_ACTION action, DatasetStructureReferenceBean datasetStructureReferenceBean, IURNAbsolute<DataProviderBean> dataProviderRef,
            Date reportingBeginDate, Date reportingEndDate, Date validFrom, Date validTo, int publicationYear, String publicationPeriod, String reportingYearStartDate) {
        this.dataProviderRef = dataProviderRef;
        this.datasetStructureReferenceBean = datasetStructureReferenceBean;
        this.datasetId = datasetId;
        this.reportingBeginDate = reportingBeginDate;
        this.reportingEndDate = reportingEndDate;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.action = action;
        this.publicationYear = publicationYear;
        this.publicationPeriod = publicationPeriod;
    }



    @Override
    public DatasetHeaderBean modifyDataStructureReference(DatasetStructureReferenceBean datasetStructureReferenceBean) {
        return new DatasetHeaderBeanImpl(getDatasetId(),
                getAction(),
                datasetStructureReferenceBean,
                getDataProviderReference(),
                getReportingBeginDate(),
                getReportingEndDate(),
                getValidFrom(),
                getValidTo(),
                getPublicationYear(),
                getPublicationPeriod(), null);  //TODO reportingYearStartDate
    }

    @Override
    public boolean isTimeSeries() {
        if(datasetStructureReferenceBean == null) {
            return true;
        }
        return datasetStructureReferenceBean.isTimeSeries();
    }

    @Override
    public DatasetStructureReferenceBean getDataStructureReference() {
        return datasetStructureReferenceBean;
    }

    @Override
    public DATASET_ACTION getAction() {
        return action;
    }

    @Override
	public DatasetHeaderBean setAction(DATASET_ACTION action) {
    	this.action = action;
		return this;
	}

    
    @Override
    public IURNAbsolute<DataProviderBean> getDataProviderReference() {
        return dataProviderRef;
    }


    @Override
    public String getDatasetId() {
        return datasetId;
    }

    @Override
    public Date getReportingBeginDate() {
        return reportingBeginDate;
    }

    @Override
    public Date getReportingEndDate() {
        return reportingEndDate;
    }

    @Override
    public Date getValidFrom() {
        return validFrom;
    }

    @Override
    public Date getValidTo() {
        return validTo;
    }

    @Override
    public int getPublicationYear() {
        return publicationYear;
    }

    @Override
    public String getPublicationPeriod() {
        return publicationPeriod;
    }

    public void setDataProviderRef(IURNAbsolute<DataProviderBean> dataProviderRef) {
        this.dataProviderRef = dataProviderRef;
    }

    public void setDatasetStructureReferenceBean(DatasetStructureReferenceBean datasetStructureReferenceBean) {
        this.datasetStructureReferenceBean = datasetStructureReferenceBean;
    }

    public void setDatasetId(String datasetId) {
        this.datasetId = datasetId;
    }

    public void setReportingBeginDate(Date reportingBeginDate) {
        this.reportingBeginDate = reportingBeginDate;
    }

    public void setReportingEndDate(Date reportingEndDate) {
        this.reportingEndDate = reportingEndDate;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public void setPublicationPeriod(String publicationPeriod) {
        this.publicationPeriod = publicationPeriod;
    }
    
    @Override
	public boolean equals(Object obj) {
    	if(obj instanceof DatasetHeaderBean) {
    		DatasetHeaderBean that = (DatasetHeaderBean) obj;
    		if(!ObjectUtil.equivalent(this.datasetId, that.getDatasetId())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getDataProviderReference(), that.getDataProviderReference())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getDataStructureReference(), that.getDataStructureReference())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getReportingBeginDate(), that.getReportingBeginDate())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getReportingEndDate(), that.getReportingEndDate())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getValidFrom(), that.getValidFrom())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getValidTo(), that.getValidTo())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getAction(), that.getAction())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getPublicationPeriod(), that.getPublicationPeriod())) {
    			return false;
    		}
    		if(!ObjectUtil.equivalent(this.getPublicationYear(), that.getPublicationYear())) {
    			return false;
    		}
    		return true;
    	}
		return super.equals(obj);
	}
    
	@Override
	public int hashCode() {
		return new HashCodeBuilder(7, 31).append(this.dataProviderRef)
				.append(this.dataProviderRef)
				.append(this.datasetStructureReferenceBean)
				.append(this.reportingBeginDate)
				.append(this.reportingEndDate)
				.append(this.validFrom)
				.append(this.validTo)
				.append(this.action)
				.append(this.publicationYear)
				.append(this.publicationPeriod)
				.build();
	}
}
