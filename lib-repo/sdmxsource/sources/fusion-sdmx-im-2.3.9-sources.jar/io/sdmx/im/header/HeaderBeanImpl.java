package io.sdmx.im.header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.random.RandomUtil;
import io.sdmx.utils.sdmx.structure.HeaderUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;

public class HeaderBeanImpl implements HeaderBean, Serializable {
	private static final long serialVersionUID = -1069998895797472200L;

	private Map<String, String> additionalAttributes = new HashMap<>();

	private IURNSingle<DataProviderBean> dataProviderReference;
	private DATASET_ACTION datasetAction;
	private String id;
	private String datasetId;
	private Date embargoDate;
	private Date extracted;
	private Date prepared;
	private Date reportingBegin;
	private Date reportingEnd;
	private List<TextTypeWrapper> name = new ArrayList<>();
	private List<TextTypeWrapper> source = new ArrayList<>();
	private List<PartyBean> receiver = new ArrayList<>();
	private List<DatasetStructureReferenceBean> structureReferences = new ArrayList<>();
	private PartyBean sender;
	private boolean test;

	public HeaderBeanImpl(String senderId) {
		this(HeaderUtil.generateIREF(), senderId);
	}

	public HeaderBeanImpl(String id, String senderId) {
		if (id == null) {
			throw new IllegalArgumentException("The ID may not be null");
		}
		if (Character.isDigit(id.charAt(0))) {
			throw new IllegalArgumentException("An ID may not start with a digit!");
		}

		this.id = id;
		if(senderId != null) {
			this.sender = new PartyBeanImpl(null, senderId, null, null);
		}
		this.prepared = new Date();
	}
			
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ATTRIBUTES			   ////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Minimal Constructor
	 * @param id
	 * @param datasetId
	 * @param prepared
	 * @param receiver
	 * @param sender
	 */
	public HeaderBeanImpl(String id, Date prepared, Date reportingBegin, Date reportingEnd, List<PartyBean> receiver, PartyBean sender, boolean isTest) {
		this(null, null, null, null, id, null, null, null, prepared, reportingBegin, reportingEnd, null, null, receiver, sender, isTest);
	}
	public HeaderBeanImpl(Map<String, String> additionalAttributes,
					  List<DatasetStructureReferenceBean> structures,
					  IURNSingle<DataProviderBean> dataProviderReference,
					  DATASET_ACTION datasetAction, String id, String datasetId,
					  Date embargoDate, Date extracted, Date prepared,
					  Date reportingBegin, Date reportingEnd, List<TextTypeWrapper> name,
					  List<TextTypeWrapper> source, List<PartyBean> receiver, PartyBean sender, boolean test) {
		if(additionalAttributes != null) {
			this.additionalAttributes = new HashMap<>(additionalAttributes);
		}
		if(structures != null) {
			this.structureReferences = new ArrayList<>(structures);
		}
		this.dataProviderReference = dataProviderReference;
		this.datasetAction = datasetAction;
		this.id = id;
		this.datasetId = datasetId;
		if(embargoDate != null) {
			this.embargoDate = new Date(embargoDate.getTime());
		}
		if(extracted != null) {
			this.extracted = new Date(extracted.getTime());
		}
		if(prepared != null) {
			this.prepared = new Date(prepared.getTime());
		}
		if(reportingBegin != null) {
			this.reportingBegin = new Date(reportingBegin.getTime());
		}
		if(reportingEnd != null) {
			this.reportingEnd = new Date(reportingEnd.getTime());
		}
		if(name != null) {
			this.name = new ArrayList<>(name);
		}
		if(source != null) {
			this.source = new ArrayList<>(source);
		}
		if(receiver != null) {
			this.receiver = new ArrayList<>(receiver);
		}
		this.sender = sender;
		this.test = test;
		validate();
	}
	
	/**
	 * Copies the values from the merged in header, overwrites any values in this header, lists are overwritten if they exist in both this header and the merged in header
	 * @param header
	 */
	public void merge(HeaderBean header) {
		if(header == null) {
			return;
		}
		if(header.getAdditionalAttributes() != null) {
			this.additionalAttributes = header.getAdditionalAttributes();
		}
		if(header.getStructures() != null) {
			this.structureReferences = header.getStructures();
		}
		if(header.getAction() != null) {
			this.datasetAction = header.getAction();
		}
		if(header.getDataProviderReference() != null) {
			this.dataProviderReference = header.getDataProviderReference();
		}
		if(header.getId() != null) {
			this.id = header.getId();
		}
		if(header.getDatasetId() != null) {
			this.datasetId = header.getDatasetId();
		}
		if(header.getEmbargoDate() != null) {
			this.embargoDate = header.getEmbargoDate();
		}
		if(header.getExtracted() != null) {
			this.extracted = header.getExtracted();
		}
		if(header.getPrepared() != null) {
			this.prepared = header.getPrepared();
		}
		if(header.getReportingBegin() != null) {
			this.reportingBegin = header.getReportingBegin();
		}
		if(header.getReportingEnd() != null) {
			this.reportingEnd = header.getReportingEnd();
		}
		if(header.getName() != null) {
			this.name = header.getName();
		}
		if(header.getSource() != null) {
			this.source = header.getSource();
		}
		if(header.getReceiver() != null) {
			this.receiver = header.getReceiver();
		}
		if(header.getSender() != null) {
			this.sender = header.getSender();
		}
		this.test = header.isTest();
		
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////VALIDATION 						///////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void validate() {
		if(!ObjectUtil.validString(id)) {
			id = RandomUtil.generateRandomString();
		}
		this.id = ValidationUtil.cleanAndValidateId(getId(), true);
		this.datasetId = 	ValidationUtil.cleanAndValidateId(getDatasetId(), true);
		if(prepared == null) {
			prepared = new Date();
		}
		if(sender == null) {
			if(!ObjectUtil.validString(id)) {
				throw new SdmxSemmanticException("Header missing sender");
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS 						///////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public IURNSingle<DataProviderBean> getDataProviderReference() {
		return dataProviderReference;
	}

	@Override
	public DatasetStructureReferenceBean getStructureById(String structureId) {
		for(DatasetStructureReferenceBean currentStructure : structureReferences) {
			if(currentStructure.getId().equals(structureId)) {
				return currentStructure;
			}
		}
		return null;
	}



	@Override
	public void setId(String id) {
		this.id = id;
		validate();
	}

	@Override
	public void setSender(PartyBean party) {
		this.sender = party;
		validate();
	}

	@Override
	public void setTest(boolean test) {
		this.test = test;
	}

	@Override
	public void addStructure(DatasetStructureReferenceBean ref) {
		structureReferences.add(ref);
	}

	@Override
	public List<DatasetStructureReferenceBean> getStructures() {
		return new ArrayList<>(structureReferences);
	}


	@Override
	public DATASET_ACTION getAction() {
		return datasetAction;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getDatasetId() {
		return datasetId;
	}

	@Override
	public Date getEmbargoDate() {
		if(embargoDate != null) {
			return new Date(embargoDate.getTime());
		}
		return null;
	}

	@Override
	public void setEmbargoDate(Date aDate) {
		this.embargoDate = aDate;
	}

	@Override
	public Date getExtracted() {
		if(extracted != null) {
			return new Date(extracted.getTime());
		}
		return null;
	}

	@Override
	public void setExtracted(Date extracted) {
		this.extracted = extracted;
	}

	@Override
	public List<TextTypeWrapper> getName() {
		return new ArrayList<>(name);
	}

	@Override
	public Date getPrepared() {
		if(prepared != null) {
			return new Date(prepared.getTime());
		}
		return null;
	}
	
	public void setPrepared(Date prepared) {
		this.prepared = prepared;
	}

	@Override
	public List<PartyBean> getReceiver() {
		return new ArrayList<>(receiver);
	}

	@Override
	public Date getReportingBegin() {
		return reportingBegin;
	}


	@Override
	public void setReportingBegin(Date date) {
		this.reportingBegin = date;
	}

	@Override
	public Date getReportingEnd() {
		return reportingEnd;
	}

	@Override
	public void setReportingEnd(Date date) {
		this.reportingEnd = date;
	}

	@Override
	public List<TextTypeWrapper> getSource() {
		return new ArrayList<>(source);
	}

	@Override
	public PartyBean getSender() {
		return sender;
	}

	@Override
	public boolean isTest() {
		return test;
	}

	@Override
	public Map<String, String> getAdditionalAttributes() {
		return new HashMap<>(additionalAttributes);
	}

	@Override
	public boolean hasAdditionalAttribute(String headerField) {
		return additionalAttributes.containsKey(headerField);
	}

	@Override
	public String getAdditionalAttribute(String headerField) {
		return additionalAttributes.get(headerField);
	}

	@Override
	public void setDataProviderReference(IURNSingle<DataProviderBean> dataProvider) {
		this.dataProviderReference = dataProvider;
	}

	@Override
	public void setAction(DATASET_ACTION action) {
		this.datasetAction = action;
	}

	@Override
	public void setDatasetId(String datasetId) {
		this.datasetId = datasetId;
	}

	@Override
	public void addName(TextTypeWrapper name) {
		this.name.add(name);
	}

	@Override
	public void addReceiver(PartyBean recevier) {
		this.receiver.add(recevier);
	}

	@Override
	public void setReceiver(PartyBean receiver) {
		this.receiver = new ArrayList<>();
		addReceiver(receiver);
	}

	@Override
	public void addSource(TextTypeWrapper source) {
		this.source.add(source);
	}
}
