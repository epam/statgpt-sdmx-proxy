
package io.sdmx.im.header;

import java.io.Serializable;
import java.util.UUID;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.utils.core.object.ObjectUtil;


public class DatasetStructureReferenceBeanImpl implements DatasetStructureReferenceBean, Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	private IURNSingle<? extends IDSDRelatedBean> structureReference;
	private String serviceURL;
	private String structureURL;
	private String dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;

	/**
	 * Minimal Constructor
	 * @param structureReference
	 */
	public DatasetStructureReferenceBeanImpl(IURNSingle<? extends IDSDRelatedBean> structureReference) {
		this.structureReference = structureReference;
		validate();
	}

	public DatasetStructureReferenceBeanImpl(String id, 
			IURNSingle<? extends IDSDRelatedBean> structureReference, 
			String serviceURL, 
			String structureURL, 
			String dimensionAtObservation) {
		this.id = id;
		this.structureReference = structureReference;
		this.serviceURL = serviceURL;
		this.structureURL = structureURL;
		if(ObjectUtil.validString(dimensionAtObservation)) {
			this.dimensionAtObservation = dimensionAtObservation;
		}
		validate();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////GETTERS							///////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public String getId() {
		return id;
	}
	@Override
	public String getServiceURL() {
		return serviceURL;
	}

	@Override
	public String getStructureURL() {
		return structureURL;
	}

	@Override
	public String getDimensionAtObservation() {
		return dimensionAtObservation;
	}

	@Override
	public IURNSingle<? extends IDSDRelatedBean> getStructureReference() {
		return structureReference;
	}

	@Override
	public boolean isTimeSeries() {
		return dimensionAtObservation.equals(DimensionBean.TIME_DIMENSION_FIXED_ID);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////
	//////////VALIDATE						/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	public void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(id)) {
			this.id = UUID.randomUUID().toString();
		}
		if(structureReference == null) {
			throw new SdmxSemmanticException("Header 'Structure' missing Structure Reference");
		}
		if(dimensionAtObservation == null) {
			dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DatasetStructureReferenceBean) {
			DatasetStructureReferenceBean that = (DatasetStructureReferenceBean) obj;
			if(!ObjectUtil.equivalent(that.getStructureReference(), structureReference)) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getServiceURL(), serviceURL)) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getStructureURL(), structureURL)) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getDimensionAtObservation(), dimensionAtObservation)) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getId(), id)) {
				return false;
			}
			return true;
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(7, 31).append(this.id)
				.append(this.structureReference)
				.append(this.serviceURL)
				.append(this.structureURL)
				.append(this.dimensionAtObservation)
				.build();
	}
}
