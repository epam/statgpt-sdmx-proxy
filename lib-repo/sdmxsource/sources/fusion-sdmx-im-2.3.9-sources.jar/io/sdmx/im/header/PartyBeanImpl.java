package io.sdmx.im.header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.sdmx.structure.ValidationUtil;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class PartyBeanImpl implements PartyBean, Serializable {
	private static final long serialVersionUID = -4454791463810290878L;

	private List<TextTypeWrapper> name = new ArrayList<>();
	private String id;
	private List<ContactBean> contacts = new ArrayList<>();
	private String timeZone;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////BUILD FROM ATTRIBUTES			   ////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public PartyBeanImpl(List<TextTypeWrapper> name, String id, List<ContactBean> contacts, String timeZone) {
		if(name != null) {
			this.name = new ArrayList<>(name);
		}
		this.id = id;
		if(contacts != null) {
			this.contacts = new ArrayList<>(contacts);
		}
		this.timeZone = timeZone;
		validate();
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////
	//////////VALIDATE						/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	public void validate() throws SdmxSemmanticException {
		if(!ObjectUtil.validString(id)) {
			throw new SdmxSemmanticException("Party missing mandatory id");
		}
		this.id = ValidationUtil.cleanAndValidateId(getId(), true);
		
		if(timeZone != null) {
			Pattern idPattern = Pattern.compile("(\\+|\\-)(14:00|((0[0-9]|1[0-3]):[0-5][0-9]))");
			if(!idPattern.matcher(timeZone).matches()) {
				throw new SdmxSemmanticException("Time zone '"+timeZone+"' is in an invalid format. please ensure the format matches the patttern (\\+|\\-)(14:00|((0[0-9]|1[0-3]):[0-5][0-9]) example +12:30");
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////
	//////////GETTERS						/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<TextTypeWrapper> getName() {
		return new ArrayList<>(name);
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public List<ContactBean> getContacts() {
		return new ArrayList<>(contacts);
	}

	@Override
	public String getTimeZone() {
		return timeZone;
	}
}
