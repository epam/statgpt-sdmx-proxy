package io.sdmx.im.event;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.event.IMetadataEvent;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;

public class MetadataEvent implements IMetadataEvent {
	private IReferenceMetadataContainer added = new ReferenceMetadataContainer();
	private IReferenceMetadataContainer edited = new ReferenceMetadataContainer();
	private Set<IURNMaintainable<IReportedMetadataSetBean>> deleted = new HashSet<>();;
	
	public MetadataEvent() {}

	public MetadataEvent(Set<IURNMaintainable<IReportedMetadataSetBean>> deleted) {
		if(deleted != null) {
			this.deleted = deleted;
		}
	}
	
	@Override
	public IReferenceMetadataContainer getAdded() {
		return added;
	}

	@Override
	public IReferenceMetadataContainer getEdit() {
		return edited;
	}

	@Override
	public Set<IURNMaintainable<IReportedMetadataSetBean>> getDeleted() {
		return Collections.unmodifiableSet(deleted);
	}

}
