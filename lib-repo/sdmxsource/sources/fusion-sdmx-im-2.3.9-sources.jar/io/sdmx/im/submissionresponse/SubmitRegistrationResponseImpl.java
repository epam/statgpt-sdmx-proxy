
package io.sdmx.im.submissionresponse;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.submissionresponse.SubmitRegistrationResponse;

public class SubmitRegistrationResponseImpl  implements SubmitRegistrationResponse {
	private RegistrationBean registration;
	private ErrorList errors;
	
	
	public SubmitRegistrationResponseImpl(RegistrationBean registration, ErrorList errors) {
		this.registration = registration;
		this.errors = errors;
	}

	@Override
	public RegistrationBean getRegistration() {
		return registration;
	}

	@Override
	public boolean isError() {
		return errors != null;
	}

	@Override
	public ErrorList getErrorList() {
		return errors;
	}
}
