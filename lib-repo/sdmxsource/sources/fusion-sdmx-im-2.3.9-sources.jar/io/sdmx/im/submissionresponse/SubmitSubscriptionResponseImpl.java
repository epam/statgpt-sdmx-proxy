
package io.sdmx.im.submissionresponse;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.submissionresponse.SubmitSubscriptionResponse;

public class SubmitSubscriptionResponseImpl extends SubmitStructureResponseImpl implements SubmitSubscriptionResponse {
	private String subscriberId;
	
	public SubmitSubscriptionResponseImpl(StructureReferenceBean structureReferenceBean, 
										 ErrorList errorList,
										 String subscriberId) {
		super(structureReferenceBean, errorList, null);
		this.subscriberId = subscriberId;
	}

	@Override
	public String getSubscriberAssignedId() {
		return subscriberId;
	}
}
