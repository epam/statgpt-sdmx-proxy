
package io.sdmx.im.submissionresponse;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.submissionresponse.SubmitStructureResponse;

public class SubmitStructureResponseImpl implements SubmitStructureResponse {
	private StructureReferenceBean structureReferenceBean;
	private ErrorList errorList;
	private DATASET_ACTION actionType;
	
	public SubmitStructureResponseImpl(StructureReferenceBean structureReferenceBean, ErrorList errorList, DATASET_ACTION actionType) {
		this.structureReferenceBean = structureReferenceBean;
		this.errorList = errorList;
		this.actionType = actionType;
		if(structureReferenceBean !=null && structureReferenceBean.getTargetUrn() == null) {
			throw new IllegalArgumentException("SubmitStructureResponseImpl expects a complete StructureReferenceBean");
		}
		if(!isError()) {
			if(structureReferenceBean ==null) {
				throw new IllegalArgumentException("Successful SubmitStructureResponse expects a StructureReferenceBean");
			}
		}
	}
	
	@Override
	public boolean isError() {
		return errorList != null && !errorList.isWarning();
	}

	@Override
	public StructureReferenceBean getStructureReference() {
		return structureReferenceBean;
	}

	@Override
	public ErrorList getErrorList() {
		return errorList;
	}

	@Override
	public DATASET_ACTION getActionType() {
		return actionType;
	}
}
