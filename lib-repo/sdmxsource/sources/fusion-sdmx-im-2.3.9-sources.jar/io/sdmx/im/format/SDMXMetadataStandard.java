package io.sdmx.im.format;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SDMXMetadataStandard implements IMetadataStandard, IFusionSingleton {
	private static SDMXMetadataStandard INSTANCE;

	private SDMXMetadataStandard() {}

	public static SDMXMetadataStandard getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SDMXMetadataStandard();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	public String getId() {
		return "SDMX";
	}

}
