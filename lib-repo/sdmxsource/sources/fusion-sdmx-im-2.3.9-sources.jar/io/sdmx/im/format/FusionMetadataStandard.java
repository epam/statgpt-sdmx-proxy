package io.sdmx.im.format;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Represents metadata which does not conform to SDMX or any other standard, in which case it is assigned to the Fusion
 * Metadata which means 'bespoke to Fusion software'
 */
public class FusionMetadataStandard implements IMetadataStandard, IFusionSingleton {
	private static FusionMetadataStandard INSTANCE;

	private FusionMetadataStandard() {}

	public static FusionMetadataStandard getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new FusionMetadataStandard();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	@Override
	public String getId() {
		return "FUSION";
	}

}
