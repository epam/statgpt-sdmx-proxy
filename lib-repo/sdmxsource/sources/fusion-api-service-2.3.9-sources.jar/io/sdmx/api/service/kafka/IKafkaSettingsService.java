package io.sdmx.api.service.kafka;

import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public interface IKafkaSettingsService {
	
	JSONObject getEmailErrorSubscriber() throws JSONException;
	
	void saveEmailErrorSubscriber(String email);
	
	void deleteEmailErrorSubscriber();
	/**
	 * Returns the transaction history for the structure producer in the format
	 * <pre>
	 * [
	 *   {
	 *   	"Tx" : "1",
	 *   	"StartTime" : 123123,
	 *   	"EndTime" : 55555,
	 *   	"Messages" : 2,
	 *   	"Size" : 1234,
	 *   	"Status" : 1,
	 *   }
	 * ]
	 * </pre>
	 *
	 * @return
	 */
	JSONArray getTransactions(String producerId, Integer lastN);

	/**
	 * Posts an action for the kafka producer:
	 * START_NO_ACTION,
	 * START_LAST_TX,
	 * START_FULL_FLUSH
	 * STOP
	 */
	void updateProducerStatus(String jsonPost);

	/**
	 * Returns true if the producer is running
	 */
	boolean getProducerStatus(String producerId);

	/**
	 * Posts JSON connection for a service
	 * <pre>
	 * {
	 * 	connection.key : value
	 * }
	 * </pre>
	 *
	 * @return
	 */
	void setKafkaConnection(JSONObject connJSON);

	/**
	 * Posts JSON connection for a service
	 * @return
	 */
	void deleteKafkaConnection();

	/**
	 * returns JSON connection for the requested service type
	 * <pre>
	 * {
	 * 	key : value
	 * }
	 * </pre>
	 *
	 * If the object does not exists, writes and empty object
	 * <pre>
	 * { }
	 * </pre>
	 * @return
	 */
	JSONObject getKafkaConnection();


	/**
	 * returns a description of each setting along with default value
	 * <pre>
	 * {
	 *   key : {
	 *   	"description" : ""
	 *   }
	 * }
	 * </pre>
	 *
	 * If the object does not exists, writes and empty object
	 * <pre>
	 * { }
	 * </pre>
	 * @return
	 * @throws JSONException
	 */
	JSONObject getKafkaConnectionSettings() throws JSONException;

	/**
	 * Sends a series of test messages to the given topic to produce the following report:
	 * @param topic can be any topic,
	 * 
	 * {
	 * 	"Topic" : "TopicName",
	 *  "TestStart" : 12345,
	 *  "TestEnd"  : 12345
	 *  "SucessMessages" : 2
	 *  "FailedMessages" : 0,
	 *  "MaxBytes" : 31200,
	 *  "Messages" : [
	 *    {
	 *      "SizeBytes" : 123,
	 *      "DurationMs"  : 50
	 *      "Success"     : false,
	 *      "Error"       : "Message"  //optional
	 *    }
	 *  ]
	 * }
	 * 
	 */
	void generateTestMessage(String topic, int maxMessages, int maxBytes, OutputStream out);


	/**
	 * Writes all the topic configurations including topics which are not configured
	 * (yet) to talk to a kafka queue
	 *
	 * <pre>
	 *  {
	 *    Producer: "structure",
	 *    Topic: "structure.topic",
	 *    Format: "application/vnd.sdmx.json",
	 *  }
	 *  </pre>
	 * @return
	 */
	void getProducer(String producerId, OutputStream out);

	/**
	 * Posts JSON connection for a service
	 * <pre>
	 * {
	 *     Producer: "structure",
	 *     Topic: "structure.topic",
	 *     Format: "application/vnd.sdmx.json",
	 *     Properties : [
	 *     	{
	 *         "Key" : "exclude",
	 *         "Value" : "codelist"
	 *      }
	 *     ]
	 * }
	 * </pre>
	 *
	 * @return
	 */
	void setProducer(String producerId, JSONObject json);

	/**
	 * Deletes a topic configuration
	 */
	void deleteProducer(String producerId);

	/**
	 * Returns JSON of the Registry Startup Action
	 * @throws JSONException
	 */
	JSONObject getRegistryStartupAction() throws JSONException;

	/**
	 * Sets the Registry Startup Action
	 * @param startupAction
	 */
	void saveRegistryStartupAction(String startupAction);
	
	
}
