package io.sdmx.api.service.change;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import org.codehaus.jettison.json.JSONObject;

/**
 * Allows the re-identification of Maintainable structures. Identity is specified by Agency, ID and version.
 */
public interface IReIndentifactionService {

	/**
	 * Given a JSON object which contains a source Reference and target reference (both URNs), modify the source structure so that it becomes that specified by the target.
	 * This does not support the modification of structure type.
	 * The expected JSON is of the format:
	 * {
     *    "srcRef": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=TEST_ACY_1:DF_1(1.0)",
     *    "tgtRef": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=TEST_ACY_2:DF_5(9.9)",
     * }
	 * @param jsonPost must contain the srcRef and tgtRef
	 * @return the SDMXBeans that were modified
	 */
	SdmxBeans reIdentifyMaintainable(JSONObject jsonObject);

}
