package io.sdmx.api.service.audit;

import org.codehaus.jettison.json.JSONArray;

public interface IErrorSubscriptionService {

	/**
	 * Gets subscriptions by the given filter
	 * @param email optional 
	 * @param service optional 
	 * @param category optional 
	 * @return array of subscriptions in the format
	 * <pre>
	 * 	[
	 *   {
	 *     "Email" : "blah",
	 *     "Service" : "blah",
	 *     "Category" : "blah",
	 * 
	 *   }
	 *  ]
	 * </pre>
	 */
	JSONArray getSubscriptions(String email, String service, String category);

	/**
	 * Subscribe to be notified on errors that match the service and category
	 * @param email - to be notified
	 * @param service - optional, the error service to subscribe to errors for, or all services if not provided
	 * @param category - optional, the error category to subscribe to errors for, or all categories if not provided
	 */
	void subscribe(String email, String service, String category);
	
	/**
	 * Unsubscribe to errors that match the service and category
	 * @param email - subscribed email
	 * @param service - optional, the error service to unsubscribe from, or all services if not provided
	 * @param category - optional, the error category to unsubscribe from, or all categories if not provided
	 */
	void unsubscribe(String email, String service, String category);

}
