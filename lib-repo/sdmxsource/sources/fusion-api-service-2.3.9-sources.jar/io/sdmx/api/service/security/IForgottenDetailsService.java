package io.sdmx.api.service.security;

public interface IForgottenDetailsService {
	
	void emailResetPassword(String productName, String username, String redirectURL);
	
	void emailResetPasswordGivenEmail(String productName, String email, String redirectURL);
	
	void emailUsername(String productName, String email);
	
	void resetPassword(String verificationGuid, String newPassword, String passwordConfirm);
}
