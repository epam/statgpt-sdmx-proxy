package io.sdmx.api.service.data;

import java.io.OutputStream;
import java.util.Map;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;

public interface IDataMappingService {

	/**
	 * Writes a JSON report of source to mapped row for the data input 
	 * 
	 * @param rdl contains the dataset
	 * @param mapRef a reference to the structure map to use
	 * @param isSource if true maps from the source DSD otherwise uses the target
	 * @param out the output stream to write the data to
	 */
	void explainMap(ReadableDataLocation rdl, IURNSingle<IStructureMapBean> mapRef, boolean isSource, OutputStream out, boolean isValidating);


		
	/**
	 * Writes a JSON report of which series mapped and which did not map based on the input data and structure map
	 * @param mapRef reference to the structure map to use
	 * @param isSource if true maps from the source DSD otherwise uses the target
	 * @param componentValues the component values which are input into the mapping
	 * @param out stream to write the report to
	 */
	void explainMap(IURNSingle<IStructureMapBean> mapRef, boolean isSource, String[] key, Map<String, String> componentValues, OutputStream out);
	
}
