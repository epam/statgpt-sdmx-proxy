package io.sdmx.api.service.metadata;

import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.IURN;

public interface IReferenceMetadataService {

	void save(Request request);
	
	
	void delete(IURN urn);
	
}
