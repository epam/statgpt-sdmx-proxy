package io.sdmx.api.service.security;

import java.io.OutputStream;

public interface IUserDetailsService {

	
	/**
	 * Simple user details
	 * {
	  		"username": "root",
			"name": "root",
			"authenticated": true
	 * }
	 */
	void writeCurrentUserDetailsShort(OutputStream out);
	
	
	 /**
	  *  writes full user details:
		  {
	  		{
				"isRoot": true,
				"isAdmin": true,
				"name": "root",
				"username": "root",
				"email": "root@fusionregistry.org",
				"modifyStatus": "loggedInWithModifyPermissions",
				"domains": [
					{
						"alias": "ROOT",
						"uri": "ROOT"
					}
				],
					"dataConsumers": [],
					"dataProviders": [],
					"roles": [],
					"agencies": [
					"urn:sdmx:org.sdmx.infomodel.base.Agency=SECURITY_ADMIN"
				]
			}
		 * }
		 * 
		 * @return
		 */
	void writeCurrentUserDetailsFull(OutputStream out);
	
	
	/**
	 * @return an array of provision agreement URNs ["urn1", "urn2", "urn3", ...] that the user can report data for
	 */
	void writeCurrentUserProvisions(OutputStream out);
	
}
