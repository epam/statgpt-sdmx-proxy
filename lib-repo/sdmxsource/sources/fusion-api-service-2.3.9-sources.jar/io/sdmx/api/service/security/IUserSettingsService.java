package io.sdmx.api.service.security;

/**
 * Manages the storage of user settings
 */
public interface IUserSettingsService {

	/**
	 * Stores a setting for the currently authenticated user
	 * @param name - setting name 
	 * @param value - setting value
	 */
	void storeSetting(String name, String value);
	
	
}
