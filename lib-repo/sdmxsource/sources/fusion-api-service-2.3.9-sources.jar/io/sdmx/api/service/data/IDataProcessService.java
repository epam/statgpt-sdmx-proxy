package io.sdmx.api.service.data;

import java.io.OutputStream;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import org.codehaus.jettison.json.JSONObject;

/**
 * Runs data processes such as validation, transformation, mapping, aggregation, dynamic attributes and so on
 */
public interface IDataProcessService {
	
	/**
	 * @param rdl the loaded data
	 * @return token - that can be used to process the data
	 */
	String loadData(ReadableDataLocation rdl);

	/**
	 * Runs the process as described by the description, in the format:
	 * <pre>
	 * {
	 *    "DataURL" : "https://"  //only required if data is null
	 *    "Structure" : "urn"     //metadata to read the data, only required if overriding the structure reference from the dataset
	 *    "ProcessSteps" : [
	 *      {
	 *      	"ProcessId"  : "VALIDATE"  //Id of a registered process
	 *      	"StepId"     : "STEP1"     //Unique Id for the step
	 *      	"Metrics"    : true        //true to capture metrics for the process
	 *      	"Properties" : {}  		   //optional map of properties specific to the process
	 *      }
	 *    ]
	 * }
	 * </pre>
	 * 
	 * @param dataToken - references the loaded dataset
	 * @param processDescription describes the processes to run on the data
	 * @return token to track the process
	 */
	String runProcess(String dataToken, JSONObject processDescription);
	
	/**
	 * Writes the status of the process to the output stream, includes more information about any steps
	 * where metrics were requested:
	 * <pre>
	 * {
	 *   "ProcessToken" : "abcd",
	 *   "StartTime"    : 123456,
	 *   "EndTime"      : null,
	 *   "Status"       : 1      //0=running,1=success,2=error
	 *   "Steps"        : {
	 *   	"Step1" : {
	 *   	 	"StartTime"    : 123456,
	 *   	 	"EndTime"      : null,
	 *   		"Series" 	   : 12,
	 *   		"Rows"		   : 132
	 *    	}
	 *   }
	 * }
	 * </pre>
	 * @param token process token as returned by runProcess
	 * @param out stream to write to 
	 */
	void writeProcessStatus(String token, OutputStream out);
	
	/**
	 * Writes the data as output by running a process step
	 * 
	 * @param token process token as returned by runProcess
	 * @param processStep process step that contains the data
	 * @param saveAs - optional, if provided the response content type will be application/octet-stream, the content-disposition will be attachment; filename=[saveAs] if the saveAs ends in .zip the output will be compressed
	 * @param request client request
	 * @param response client response
	 */
	void writeDataset(String token, String processStep, String saveAs, Request request, IResponse response);
	
}
