package io.sdmx.api.service.audit;

import io.sdmx.api.error.IErrorNotifier;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

public interface IErrorService {

	
	/**
	 * @param post
	 * @return an array of {@link IErrorNotifier} notifiers in the format:
	 * <pre>
	 *  {
	 *  	"Id" : "id",
	 *  	"Name" : "name",
	 *  	"Description" : "desc"
	 *  }
	 * </pre>
	 * 
	 */
	public JSONArray getErrorNotifiers();

	/**
	 * 
	 * @param post
	 * @return error categories for the service with the given id, in the format:
	 * <pre>
	 *  {
	 *  	"Id" : "id",
	 *  	"Service" : "service",
	 *  	"Name" : "name",
	 *  	"Description" : "desc"
	 *  }
	 * </pre>
	 */
	public JSONArray getErrorCategories(String errorNotifierId);
	
	/**
	 * Returns all the error categories:
	 * 
	 * @param post
	 * @return all possible error categories for all error notifiers in the format:
	 * <pre>
	 *  {
	 *  	"Id" : "id",
	 *  	"Service" : "service",
	 *  	"Name" : "name",
	 *  	"Description" : "desc"
	 *  }
	 * </pre>
	 */
	JSONArray getCategories();
	
	
	/**
	 * Searches for error reports that match the filters
	 * 
	 * @param errorNotifierId optional
	 * @param categoryId optional
	 * @param auditId optional
	 * @param from optional
	 * @param to optional
	 * @param asStub optional
	 * @param limit optional
	 * @param offset optional
	 * @return all the error reports that match the query criteria
	 * @see getErrorReport for description of JSON - stub is everything up to and including Description
	 */
	JSONArray getErrorReports(String errorNotifierId,
								String categoryId,
								String auditId,
								String from,
								String to,
								boolean asStub,
								Integer limit,
								Integer offset); 

	/**
	 * returns the full error report with the given id
	 * @return
	 * <pre>
	 * 	UID			: uid
	 *  Status		: 403
	 *  Service		: Login
	 *  Category 	: "LoginError"
	 *  Time	 	: 123456789
	 *  Description : "login error"
	 *  Properties : {
	 *  	"PropId" : "PropValue"
	 *  }
	 *  AuditId : "aid",
	 *  ProductProperties : {
	 *  	"URL" : "url",
	 *  	"Name" : "name",
	 *  	"Version" : "version"
	 *  },
	 *  Exception : [
	 *  	{
	 *  		"Message" : "error",
	 *  		"Type" 	  : "NullPointer"
	 *  	}...
	 *  ],
	 *  Stack : [
	 *  	{
	 *  		"Class" : "JavaClassName",
	 *  		"Line"	: 32,
	 *  		"Method" : doSomething
	 *  	}...
	 *  ]
	 *  }
	 * </pre>
	 * 
	 */
	JSONObject getErrorReport(String id);
	
}
