package io.sdmx.api.service.fusionxl;

import java.io.OutputStream;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.data.DataFormat;

public interface IExcelPluginServiceActivator {
	
	//AUTHENITCATION RELATED OPERATIONS
	/**
	 * Forces Excel to show an authenticate form
	 */
	public boolean getAuth(OutputStream out);
	
	
	//DATA RELATED OPERATIONS

	/**
	 * Loads a dataset, either writing the UID to the outptu stream (if a DSD is required) or
	 * writes the data to the output stream
	 * @param rdl
	 * @param out
	 */
	void loadData(ReadableDataLocation rdl, OutputStream out);

	/**
	 * Provides more details for a previoulsy loaded dataset
	 * @param uid
	 * @param flowRef
	 * @param out
	 */
	void provideDataDetails(String uid, String flowRef,  String providerRef, OutputStream out);
	
	/**
	 * Writes the Provision Agreements
	 *
	 * Format is:  "urn", "ID", "Name"
	 * @param out
	 */
	void writeProvisions(String flowRef, String providerRef, OutputStream out);

	/**
	 * Writes out the data providers, that have at least one provision agreement in a menu for the currently authenticated Data Provider (or Admin User)
	 *
	 * @param out
	 */
	void writeDataProviders(OutputStream out);
	

	/**
	 * Writes out the dataflows in a menu, grouped by agency
	 *
	 * @param out
	 */
	void writeDataflows(String providerRef, OutputStream out);
	
	/**
	 * Writes an excel document set out for a Data Structure Definition
	 * 
     * @param dateFrom optional in ISO8601 format if both this and dateTo provided this must resolve to a time period before dateTo
     * @param dateTo  optional in ISO8601 format if both this and dateFrom provided this must resolve to a time period after dateFrom
	 * @param tf
	 * @param flowRef
	 * @param includeData if true will include any existing data in the output template
	 * @param fixedValues
	 * @param attributesToExclude
	 * @param out
	 */
    void writeExcelDataTemplate(String dateFrom, 
    							String dateTo, 
    							String tf, 
    							String flowRef, 
    							Boolean includeData, 
    							Map<String, String> fixedValues, 
    							Set<String> attributesToExclude,
    							OutputStream out);
	

	/**
	 * <p>Describes a Data Set, in terms of the dimensions, attributes, and representation</p>  
	 * 
	 * <p>Writes CSV formatted as:</p>
	 * 
	 * <pre>
	 * "METADATA"
	 * "DS_M", "DATASET_TITLE"
	 * "DS_C", "DATASET_CONTACT"
	 * "DIM", "FREQ", "SERIES", "REF_AREA"
	 * "SER_M",
	 * "SER_C",
	 * "OBS_M"
	 * "OBS_C",
	 * "REPRESNTATION"
	 * "FREQ", "A - Annual", "M - Monthly",
	 * "OBS_PRE_BREAK", "_INTEGER"
	 * </pre>
	 * 
     * @param dateFrom optional in ISO8601 format if both this and dateTo provided this must resolve to a time period before dateTo
     * @param dateTo  optional in ISO8601 format if both this and dateFrom provided this must resolve to a time period after dateFrom
     * @param timeFormat a valid {@link TIME_FORMAT} ID
     * @param flowRef
     * @param providerRef
     * @param fixedValues
     * @param attributesToExclude
     * @param codeLimit
     * @param out
     */
	void writeDatasetDetails(String dateFrom, 
							 String dateTo, 
							 String timeFormat, 
							 String flowRef, 
							 String providerRef,  
							 Map<String, String> fixedValues, 
							 Set<String> attributesToExclude, 
							 int codeLimit,
							 OutputStream out);


	/**
	 * Writes a codelist's codes to the output stream, only the codes which match the filter term are included
	 *
	 * Example:
	 * "A - Annual", "M - Monthly"
	 *
	 * @param ref codelist URN
	 * @param componentId
	 * @param filterTerm
	 * @param out
	 * @param codeLimit
	 */
	void writeFilteredCodelist(String ref, String componentId, String filterTerm, OutputStream out, int codeLimit);
	

	/**
	 * Exports a dataset, in the given format to the output stream
	 * 
	 * @param rdl
	 * @param flowRef urn
	 * @param senderId
	 * @param exportFormat
	 * @param attachmentStructure - nullable, if provided this informs the writer that creates the dataset the highest level of structure the dataset should be linked to
	 * this is either a Provision Agreement, Dataflow, or Data Structure
	 * @param out
	 */
	void exportData(ReadableDataLocation rdl, String flowRef,  String senderId, DataFormat exportFormat, SDMX_STRUCTURE_TYPE attachmentStructure, OutputStream out);
	
	/**
	 * Validates a dataset, writing the response to the output stream
	 * 
	 * @param rdl
	 * @param sRef urn of dataflow/provision
	 * @param out
	 */
	void validateData(ReadableDataLocation rdl, String sRef, OutputStream out);
	
	
	
	//STRUCTURE RELATED OPERATIONS
	
	/**
	 * Writes the supported structures as a menu in the following format (ClassName:Human Name)
	 * @return
	 */
	public void getSupportedStructures(OutputStream out);
	/**
	 * Writes the agencies to the output stream, in the format "SDMX:SDMX", "ECB:European Central Bank"
	 * @return
	 */
	public void getAgenciesStructures(OutputStream out);

	/**
	 * Writes the locales that have labels for the given structure in the format: "en","fr"
	 *
	 * @param type
	 */
	public void getLocales(IURNMaintainable<?> sRef, OutputStream out);

	/**
	 * Writes the cross references for a structure to the output stream in the format
	 *
	 * "1", "Dataflow", "ECB", "FlowID", "Flow Version", "Dataflow Name"
	 * "2", "Provision Agreement", "ECB", "ProvID", "Prov Version", "Prov Name"
	 */
	public void getCrossReferences(IURNMaintainable<?> sRef, OutputStream out);

	/**
	 *
	 * Writes the structures that exist for the given agency of 'structure type' as CSV in the following format
	 * "urn","My Codelist"
	 * "urn","My Codelist 2"
	 *
	 * @param agencyId
	 * @param structureType
	 * @param httpResponse
	 * @return
	 */
	public void getMaintainableOptions(String agencyId, SDMX_STRUCTURE_TYPE type, OutputStream out);

	/**
	 * Posts a request for a structure to be created, includes all the mandatory parameters of: agency,id,version, and name
	 *
	 * Responds in CSV with ObjectType,AgencyId,Id,Version
	 *
	 * @param postMsg JSON in the format
	 *  {
	 *   StructureType:"Codelist",
	 *   AgencyId:"SDMX",
	 *   Id:"CL_FREQ",
	 *   Version:"1.0",
	 *   Name:"Frequency Codelist"
	 *  }
	 *
	 * @param postMsg
	 * @param req
	 * @param httpResponse
	 * @return
	 */
	public void createStructure(JSONObject postMsg, OutputStream out);

	/**
	 * Performs a search and returns the results to the output stream in the following format
	 * <p/>
	 * StructureType, agencyId, Id, Version, Name
	 *
	 * @param queryString
	 * @param httpResponse
	 * @return
	 */
	public void search(String queryString, OutputStream out);

	public void save(final String postMsg, SdmxBeans beans, OutputStream out);

	public void deleteStructure(IURNMaintainable<?> sRef, OutputStream out);

	/**
	 * Writes CSV used to build the structure menu as a hierarchy (structure type,agency id, structures)
	 */
	public void getStructureMenu(OutputStream out);

	/**
	 * Writes the Lookup Structure Menu (DSD by Concept/DSD By Codelist/Dataflow by DSD)
	 *
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 1"<br/>
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 2"<br/>
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 3"<br/>
	 * @param out
	 */
	public void getLookupMenu(OutputStream out);

	/**
	 *  Writes the history of a structure to the output stream in the format: id, date, user, action.
	 *  e.g.
     *
     * 12, 2002-01-01T20:32:23, user1  Append
     * 13, 2002-02-01T20:32:23, user1, Delete
     * 14, 2002-03-01T20:32:23, user1, Append
     *
	 * @param type
	 * @param agencyId
	 * @param id
	 * @param version
	 * @param out
	 */
	public void getStructureHistory(Integer txId, String type, String agencyId, String id, String version, OutputStream out);
}
