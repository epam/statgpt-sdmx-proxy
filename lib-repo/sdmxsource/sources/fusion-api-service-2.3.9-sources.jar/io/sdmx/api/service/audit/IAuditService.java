package io.sdmx.api.service.audit;

import java.io.OutputStream;

import org.codehaus.jettison.json.JSONObject;

public interface IAuditService  {
	
	/**
	 * Finds all the log events for the audit id
	 * @param auditId the id of the audit event to find the logs for
	 * @param includeChildren if true then the log files for child audit events will also be included
	 * @param includeAncestor if true then the log files for ancestor audit events will also be included
	 * @param out
	 */
	void writeAuditLogs(String auditId, Boolean includeChildren, Boolean includeAncestor, OutputStream out);
	
	
	/**
	 * Writes the audit with the given ID and any associated audits if children/ancestors is requested
	 * @param auditId
	 * @param includeChildren
	 * @param includeAncestor
	 * @param out
	 */
	void writeAudits(String auditId, Boolean includeChildren, Boolean includeAncestor, OutputStream out);
	
	/**
	 * Writes the audits that match the query criteria
	 * @param query contains filters for audits
	 * @param out
	 */
	void writeAudits(JSONObject query, OutputStream out);
}
