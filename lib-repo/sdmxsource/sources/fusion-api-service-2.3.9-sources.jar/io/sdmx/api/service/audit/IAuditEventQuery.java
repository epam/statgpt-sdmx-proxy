package io.sdmx.api.service.audit;

import java.util.Map;

public interface IAuditEventQuery {
	
	/**
	 * @return true to order by time ascending, false to order by time descending
	 */
	boolean orderAsc();
	
	/**
	 * @return true to return only the persisted audit events, false to return only the non persisted events, and null
	 * to return both
	 */
	Boolean getPersisted();

	/**
	 * @return max results
	 */
	Integer getMaxResults();
	
	/**
	 * @return max duration
	 */
	Integer getMaxDuration();

	
	/**
	 * @return min duration
	 */
	Integer getMinDuration();

	/**
	 * @return max results
	 */
	Integer getOffset();

	/**
	 * @return map of property key to property value or an empty map to indicate no filters
	 * @see IFusionProcess
	 */
	Map<String, String> getPropertyValues();

	/**
	 * @return the status of the outcome, or null to i all
	 */
	Integer getStatus();

	/**
	 * Include child processes
	 * @return
	 */
	boolean isIncludeChildren();

	/**
	 * Include Ancestor Process
	 * @return
	 */
	boolean isIncludeAncestor();

	/**
	 * @return the audit process to return or null to indicate all types
	 */
	String getProcessId();
	
	/**
	 * @return the audit event type or null to indicate all types
	 */
	String getEventType();
	

	/**
	 * @return the parent audit id or null to indicate no parent
	 */
	String getParentId();

	/**
	 * @return optional start period for audits to lie between
	 */
	Long getStartPeriod();

	/**
	 * @return optional end period for audits to lie between
	 */
	Long getEndPeriod();

	/**
	 * @return username of user who initiated the request, or null to indicate no filter
	 */
	String getUsername();
	
	/**
	 * @return IP of user who initiated the request, or null to indicate no filter
	 */
	String getIP();

	/**
	 * @return the software version the query is against, or null to indicate no filter
	 */
	String getSoftwareVersion();
}
