package io.sdmx.api.service.data;

import java.io.OutputStream;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;

public interface IAsyncDataService {
	
	/**
	 * Loads a dataset, and returns a UID which can be used in future calls to obtain the Dataset details
	 * @param req
	 * @return uid
	 */
	String performDataLoad(Request req);
	
	/**
	 * writes information about the dataset (load status, content, validity) identified with the given UID, example response JSON
	 * {
	 * 	Status : [LOADING_STATUS]
	 *  DatasetDetails : {  		//optional
	 *    seriesCount : num
	 *    obsCount : num
	 *  }
	 *  Error : error				//optional
	 * }
	 * @param uid
	 * @param out
	 */
	void writeLoadStatus(String uid, OutputStream out);
	
	/**
	 * Asynchronous request to re-validate a previously validated Dataset (stored against a uid), against the structure with the given URN, the loadStatus can be found by calling the load status method
	 *
	 * @param json
	 * Expects a JSON message containing the UID and the Structure URN to use for each dataset, example:
	 * {
	 *   UID  : "uid",
	 *   SRef : ["urn1", "urn2", urn3"]
	 * }
	 * @param out
	 */
	void revalidate(JSONObject json, OutputStream out);
	
	/**
	 * Maps a previously loaded Dataset (defined by the UID) -
	 *
	 * @param json
	 * Expects a JSON message containing the UID and the Structure URN to use for each dataset, example:
	 * {
	 *   UID  : "uid",
	 *   IDX : 0,
	 *   Map : "urn"
	 * }
	 */
	void map(JSONObject json);
	
	/**
	 * Downloads a previously loaded dataset (defined by the UID) in the requested format, optionally mapped
	 * @param uid
	 * @param format
	 * @param resolveCodes
	 * @param delimiter
	 * @param keyDelimiter
	 * @param xAxis
	 * @param senderId
	 * @param datasetIndex
	 * @param map
	 * @param isZip
	 * @param includeUnmappedData
	 * @param includeUnmappedReport
	 * @param includeMetrics
	 * @param request
	 * @param response
	 * @param skipValidation
	 */
	public void getData(
			String uid,
			String format,
			Boolean resolveCodes,
			String delimiter,
			String keyDelimiter,
			Boolean xAxis,
			String senderId,
			Integer datasetIndex,
			String map,
			Boolean isZip,
			Boolean includeUnmappedData,
			Boolean includeUnmappedReport,
			Boolean includeMetrics,
			Request request, IResponse response,
			Boolean skipValidation);
}
