package io.sdmx.api.service.structure;

import java.io.OutputStream;

public interface IJsonServiceActivator {

	/**
	 * Returns a list of periods for the Codelist (referenced by the component with the given id) where the applied constraints differ
	 *
	 * @param urn to a DSD, Dataflow, Provision Agreement, Data Provider
	 * @param componentId Id of Dimension or Attribute
	 * @param out
	 * @return JSON Array
	 * [
	 *   {
	 *    startPeriod : 1234471,
	 *    endPeriod : 122334471,
	 *   },...
	 * ]
	 *
	 */
	public void getConstraintPeriods(String urn, String componentId, OutputStream out);

	/**
	 * Returns a JSON array of constrained frequencies or an empty array (meaning do not constrain frequencies).
	 * @param rtUrn
	 * @param dpUrn
	 * @param out
	 * @return a List of codes to restrict to or empty array
	 */
	public void getConstrainedFrequencies(String rtUrn, String dpUrn, OutputStream out);

	/**
	 * Returns the Codelist as constrained when viewed against the DSD/Dataflow/Provision with the given URN and Component (Dimension or Attribute) with the given Id.
	 *
	 * @param urn to a DSD, Dataflow, Provision Agreement, Data Provider
	 * @param componentId Id of Dimension or Attribute
	 * @param validFrom
     * @param validTo
     * @param out
	 * @return
	 */
	public void getConstrainedCodelist(String urn, String componentId, Long validFrom, Long validTo, OutputStream out);

	/**
	 * Returns a JSON Map mapping a Data Structure Component Id to a Fixed Code Id based on constraints restricting allowable data
	 *
	 * @param urn to a DSD, Dataflow, Provision Agreement, Data Provider
	 * @param validFrom the reporting period from, this is optional
	 * @param validTo the reporting period to, this is optional
	 * @param out
	 * @return
	 */
	public void getConstrainedCodelist(String urn, Long validFrom, Long validTo, OutputStream out);

	/**
	 * Saves the JSON in the postMessage
	 * @param postMessage
	 * @param out
	 */
	public void save(final String postMessage, OutputStream out);

	/**
	 * Writes the Dataflows which have allowable series constraints associated with them into the outputstream
	 * @param out
	 * @return
	 */
	public void getDataflowsWithAllowableConstraints(OutputStream out);

	/**
	 * Deletes the structure with the given URN
	 * @param urn maintainable
	 * @param forceDeleteOfReferencing if true deletes all structures that reference this structure
	 * @param out
	 * @return a boolean stating whether the delete succeeded or not. A delete could fail if "force" is false and there are cross-references
	 */
	public boolean delete(String urn[], boolean forceDeleteOfReferencing, OutputStream out);

	/**
	 * Deletes the structures specified in the urnArray
	 * @param urnArray
	 */
	public void deleteStructures(String urnArray);

	/**
	 * Returns all the structures maintained by the Agency, and structures that also use those structures that may be owned by other agencies
	 *
	 * @param agency
	 * @param out
	 * @return
	 */
	public void getAgencyContents(String agency, OutputStream out);

	/**
	 * Deletes the data provider specified in the JSON
	 * @param json
	 */
	public void deleteDataProvider(String json);

	/**
     * Deletes the data consumer specified in the JSON
     * @param json
     */
	public void deleteDataConsumer(String json);

	/**
	 * Deletes an Agency, optionally reassigning the structure to another agency, or deleting all structures for the Agency
	 * @param sourceAgencyId
	 * @param targetAgencyId - optional, if provided then the agencies structures will be reassigned, if not then they will be deleted
	 * @return
	 */
	public void deleteAgencyMoveStructures(String sourceAgencyId, String targetAgencyId);

	/**
	 * Obtains the corss references for the URN and writes the output to the OutputStream
	 * @param urn
	 * @param out
	 */
	public void findCrossRefs(String urn, OutputStream out);

}
