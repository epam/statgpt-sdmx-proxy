package io.sdmx.api.service.data;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;

public interface IDataTransformationService {

	void transformData(Request request, IResponse response);
	
	
}
