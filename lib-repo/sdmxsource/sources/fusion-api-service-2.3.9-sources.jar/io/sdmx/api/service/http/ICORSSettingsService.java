package io.sdmx.api.service.http;

import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;

public interface ICORSSettingsService {

	void replaceSettings(JSONArray jsonPost);
	
	void writeSettings(OutputStream out);
}
