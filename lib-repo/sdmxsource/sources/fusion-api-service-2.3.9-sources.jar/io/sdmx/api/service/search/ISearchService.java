package io.sdmx.api.service.search;

import java.io.OutputStream;

public interface ISearchService {

	
	void writeAutoCompleteSuggestions(String searchTerm, int maxSuggestions, OutputStream out);
	

	void writeSearchResults(String searchTerm, OutputStream out);
	
}
