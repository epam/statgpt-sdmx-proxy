package io.sdmx.api.service.data;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;

public interface IDataValidationService {

	void validateData(Request request, IResponse response);
	
}
