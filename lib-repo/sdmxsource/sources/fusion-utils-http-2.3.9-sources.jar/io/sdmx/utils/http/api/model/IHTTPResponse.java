package io.sdmx.utils.http.api.model;

import java.util.List;
import java.util.Map;

public interface IHTTPResponse {

	/**
	 * @return response headers
	 */
	Map<String, List<String>> getResponseHeaders();
	
	/**
	 * @return response status
	 */
	int getStatus();

	/**
	 * @return true if the request resulted in an error
	 */
	boolean isError();
}
