package io.sdmx.utils.http.api.model;

/**
 * Bearer Token - compatible with OpenIdConnect and OAuth2
 */
public interface IBearerAuthentication extends IAuthentication {

	/**
	 * @return not null - bearer token to be used on the Authorization HTTP Header
	 */
	String getToken();
	
}
