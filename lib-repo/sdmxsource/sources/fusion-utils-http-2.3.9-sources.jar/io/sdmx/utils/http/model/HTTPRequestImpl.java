package io.sdmx.utils.http.model;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.utils.http.api.model.IHTTPRequest;
import io.sdmx.utils.http.broker.RestMessageBroker;

public class HTTPRequestImpl implements IHTTPRequest {
	private HTTP_METHOD httpMethod;
	private Object payload;
	private String accept;
	private int readTimeout = RestMessageBroker.getReadTimeout();
	private int connectTimeout = RestMessageBroker.getConnectTimeout();
	private Map<String, String> headerParams = new HashMap<>();
	
	public HTTPRequestImpl(Object payload) {
		this(payload, null);
	}
	
	public HTTPRequestImpl(Object payload, HTTP_METHOD httpMethod) {
		this.payload = payload;
		this.httpMethod = httpMethod;
		if(this.httpMethod == null) {
			this.httpMethod = payload == null ? HTTP_METHOD.GET : HTTP_METHOD.POST;
		}
	}
	
	@Override
	public HTTP_METHOD getMethod() {
		return httpMethod;
	}

	@Override
	public IHTTPRequest addHeaderParam(String key, String value) {
		headerParams.put(key, value);
		return this;
	}

	@Override
	public IHTTPRequest setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
		return this;
	}

	@Override
	public IHTTPRequest setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
		return this;
	}

	@Override
	public IHTTPRequest setAccept(String accept) {
		this.accept = accept;
		return this;
	}

	@Override
	public Object getPayload() {
		return payload;
	}

	@Override
	public String getAccept() {
		return accept;
	}

	@Override
	public int getReadTimeout() {
		return readTimeout;
	}

	@Override
	public int getConnectTimeout() {
		return connectTimeout;
	}

	@Override
	public Map<String, String> getHeaderParameters() {
		return headerParams;
	}

}
