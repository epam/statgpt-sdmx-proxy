package io.sdmx.utils.http.api.engine;

import java.io.OutputStream;

import io.sdmx.utils.http.api.model.IRESTRequest;
import io.sdmx.utils.http.model.JSONObjectResponse;
import io.sdmx.utils.http.model.RESTResponse;

/**
 * Used to GET and POST to REST web services
 */
public interface IHTTPQueryEngine {

	/**
	 * Sends the HTTP get or post request to the destination, writes the response to the output stream
	 * <p/>
	 * Note: If the server returns an error code (403, 500, etc) this will not result in an exception being thrown from this method, the response status will be included in the returned object, and any error
	 * text written to the stream will be copied to the output stream
	 * 
	 * @return information about the HTTP response including HTTP status and HTTP Headers
	 **/
	RESTResponse sendMessage(IRESTRequest request, OutputStream out);
	
	/**
	 * Sends the HTTP get or post request to the destination, writes the response to the output stream
	 * <p/>
	 * Note: If the server returns an error code (403, 500, etc) this will not result in an exception being thrown from this method, the response status will be included in the returned object, and any error
	 * text written to the stream will be copied to the output stream
	 * 
	 * @return information about the HTTP response including HTTP status and HTTP Headers
	 **/
	JSONObjectResponse getJson(IRESTRequest request);
}
