package io.sdmx.utils.http.api.model;

public interface IRESTRequest extends IHTTPRequest {

	/**
	 * @return URL to send request to
	 */
	String getUrl();

	/**
	 * @return optional authentication header to use
	 */
	IAuthentication getAuthentication();

}
