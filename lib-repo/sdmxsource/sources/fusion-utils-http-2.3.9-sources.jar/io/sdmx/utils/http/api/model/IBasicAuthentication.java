package io.sdmx.utils.http.api.model;

/**
 * Wrapper around username and password which can be used to genereate the authentication HTTP Header
 */
public interface IBasicAuthentication extends IAuthentication {

	/**
	 * @return username
	 */
	String getUsername();
	
	/**
	 * @return password
	 */
	String getPasword();
	
}
