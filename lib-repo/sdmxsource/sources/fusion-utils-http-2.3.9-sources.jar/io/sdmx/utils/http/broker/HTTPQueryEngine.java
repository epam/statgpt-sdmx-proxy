package io.sdmx.utils.http.broker;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxServiceUnavailableException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.http.api.engine.IHTTPQueryEngine;
import io.sdmx.utils.http.api.model.IHTTPRequest;
import io.sdmx.utils.http.api.model.IRESTRequest;
import io.sdmx.utils.http.model.JSONObjectResponse;
import io.sdmx.utils.http.model.RESTResponse;

public class HTTPQueryEngine implements IHTTPQueryEngine {
	private final Logger LOG = LoggerFactory.getLogger(HTTPQueryEngine.class);

	private int defaultConnectTimeout = RestMessageBroker.getConnectTimeout();
	private int defaultResponseTimeout = RestMessageBroker.getReadTimeout();
	
	
	public int getConnectTimeout() {
		return defaultConnectTimeout;
	}

	public int getReadTimeout() {
		return defaultResponseTimeout;
	}
	private String username;
	private String password;
	private String userAgent;
	
	// By default, accessing an HTTPS URL using the URL class results in an exception if the server's certificate
	// chain cannot be validated has not previously been installed in the truststore.
	// If you want to disable the validation of certificates for testing purposes, override the
	// default trust manager with one that trusts all certificates.
	{

		// Install the all-trusting Trust Manager
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, getTrustAllCerts(), new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Setup the Verifier to trust everything
			HttpsURLConnection.setDefaultHostnameVerifier( new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession ssls) {
					return true;
				}
			});

		} catch (Exception e) {
			System.out.println(e);
		}

		// Now that the SSLContext has been set up to be all-trusting,
		// you can access an HTTPS URL without having the certificate in the truststore
	}
	
	private TrustManager[] getTrustAllCerts() {
		return new TrustManager[]{
				new X509TrustManager() {
					@Override
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					@Override
					public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
					}

					@Override
					public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException{
					}
				}
		};
	}

	
	/**
	 * Sends the HTTP get or post request to the destination, writes the response to the output stream
	 * <p/>
	 * Note: If the server returns an error code (403, 500, etc) this will not result in an exception being thrown from this method, the response status will be included in the returned object, and any error
	 * text written to the stream will be copied to the output stream
	 * 
	 * @return information about the HTTP response including HTTP status and HTTP Headers
	 **/
	@Override
	public RESTResponse sendMessage(IRESTRequest request, OutputStream out) {
		if(LOG.isTraceEnabled()) {
			LOG.trace("Send message to destination : " + request.getUrl());
			LOG.trace("Payload of message : " + request.getPayload());
		}
		URLConnection urlc = getConnection(request);
		try {
			return getResponse(urlc, out, request.getPayload());
		} finally {
			closeConnection(urlc);
		}
	}
	
	/**
	 * Sends the HTTP get or post request to the destination, writes the response to the output stream
	 * <p/>
	 * Note: If the server returns an error code (403, 500, etc) this will not result in an exception being thrown from this method, the response status will be included in the returned object, and any error
	 * text written to the stream will be copied to the output stream
	 * 
	 * @return information about the HTTP response including HTTP status and HTTP Headers
	 **/
	@Override
    public JSONObjectResponse getJson(IRESTRequest request) {
		if(LOG.isTraceEnabled()) {
			LOG.trace("Send message to destination : " + request.getUrl());
			LOG.trace("Payload of message : " + request.getPayload());
		}
		URLConnection urlc = getConnection(request);
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			RESTResponse response = getResponse(urlc, bos, request.getPayload());
			try {
				return new JSONObjectResponse(response, new JSONObject(new String(bos.toByteArray())));
			} catch (JSONException e) {
				return new JSONObjectResponse(response, bos.toByteArray());
			}
		} finally {
			closeConnection(urlc);
		}
	}

	private URLConnection getConnection(IRESTRequest request)  {
		URL url;
		String destination = request.getUrl();
		try {
			url = new URL(destination);
		} catch (MalformedURLException e) {
			throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, destination);
		}
		// Make connection, use post mode, and send query
		URLConnection urlc = null;
		try {
			urlc = url.openConnection();
		} catch (IOException e) {
			closeConnection(urlc);
			throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, destination);
		}
		try {
			setupConnection(request, urlc);
		} catch (RuntimeException e) {
			closeConnection(urlc);
			throw e;
		}
		return urlc;
	}
	
	private void closeConnection(URLConnection connection) {
		if(connection != null && connection instanceof HttpURLConnection) {
			((HttpURLConnection)connection).disconnect();
		}
	}

	private void setupConnection(IRESTRequest request, URLConnection urlc)  {
		String destination = request.getUrl();
		Map<String, String> params = request.getHeaderParameters();
		
		urlc.setDoOutput(true);
		urlc.setAllowUserInteraction(false);
		for(String param : params.keySet()) {
			urlc.addRequestProperty(param, params.get(param));
		}
		if(!params.containsKey("Content-Type")) {
			urlc.addRequestProperty("Content-Type", "application/text");
		}
		urlc.addRequestProperty("Accept-Encoding", "gzip");
		if (ObjectUtil.validString(userAgent)) {
			urlc.setRequestProperty("User-Agent", userAgent);
		}

		if(destination.toLowerCase().startsWith("http")) {
			HttpURLConnection httpConn = (HttpURLConnection) urlc;
			httpConn.setInstanceFollowRedirects(true);
			try {
				httpConn.setRequestMethod(request.getMethod().getMethod());
			} catch (ProtocolException e) {
				e.printStackTrace();
			}
		}
		
		//Authorization
		if(request.getAuthentication() != null && request.getAuthentication().getAuthorizationHeader() != null) {
			urlc.addRequestProperty("Authorization", request.getAuthentication().getAuthorizationHeader());
		} else if(ThreadLocalUtil.contains("Authorization") && !params.containsKey("Authorization")) {
			Object secureKey = ThreadLocalUtil.retrieveFromThread("Authorization");
			if(secureKey != null) {
				urlc.addRequestProperty("Authorization", (String)secureKey);
			}
		} else if(this.username != null && this.password != null) {
			String secureKey = AuthorizationUtil.createAuthorizationHeader(this.username, this.password);
			urlc.addRequestProperty("Authorization", secureKey);
		} else if(destination.startsWith("https") && ThreadLocalUtil.contains("P12Certificate")) {
			HttpsURLConnection httpsConn = (HttpsURLConnection) urlc;
			byte[] certificateBytes = (byte[]) ThreadLocalUtil.retrieveFromThread("P12Certificate");
			String keyStoreType = (String) ThreadLocalUtil.retrieveFromThread("P12CertificateType");
			if(!ObjectUtil.validString(keyStoreType)) {
				keyStoreType = "PKCS12";
			}
			String keyStorePassword = (String) ThreadLocalUtil.retrieveFromThread("P12CertificatePassword");
			
			char[] password = keyStorePassword.toCharArray();
			
			try {
				KeyStore clientStore = KeyStore.getInstance(keyStoreType);
				clientStore.load(new ByteArrayInputStream(certificateBytes), password);
				KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
				kmf.init(clientStore, password);
				KeyManager[] kms = kmf.getKeyManagers();
				SSLContext sslContext = SSLContext.getInstance("TLS");
				sslContext.init(kms, getTrustAllCerts(), new SecureRandom());
//				HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
				httpsConn.setSSLSocketFactory(sslContext.getSocketFactory());
			} catch (Throwable e) {
				throw new SdmxException(e, "Error while trying to attach Certificate to request: " +destination);
			}
		}
		
		
		if(ThreadLocalUtil.contains("X-Forwarded-For") && !params.containsKey("X-Forwarded-For")) {
			Object ipaddr = ThreadLocalUtil.retrieveFromThread("X-Forwarded-For");
			urlc.addRequestProperty("X-Forwarded-For",(String)ipaddr);
		}

		if (request.getAccept() != null) {
			urlc.addRequestProperty("Accept", request.getAccept());
		} else {
			urlc.addRequestProperty("Accept", "*/*;q=1");
		}
		
		urlc.setConnectTimeout(request.getConnectTimeout());
		urlc.setReadTimeout(request.getReadTimeout());
	}
	
	private RESTResponse getResponse(URLConnection urlc, OutputStream out, Object payload) {
		try {
			try {
				if(payload != null) {
					if(payload instanceof IHTTPRequest) {
						payload = ((IHTTPRequest)payload).getPayload();
					}
					if(payload instanceof ReadableDataLocation && urlc instanceof HttpURLConnection) {
                        ReadableDataLocation rdl = (ReadableDataLocation)payload;
                        ((HttpURLConnection)urlc).setFixedLengthStreamingMode(rdl.getSize());
					}
					//Send Payload
					PrintStream ps = new PrintStream(urlc.getOutputStream());
					if (payload instanceof ByteArrayOutputStream) {
						ps.write(((ByteArrayOutputStream)payload).toByteArray());
					} else if(payload instanceof ReadableDataLocation) {
						ReadableDataLocation rdl = (ReadableDataLocation)payload;
						StreamUtil.copyStream(rdl.getInputStream(), ps);
						rdl.close();
					} else if(payload instanceof InputStream) {
						StreamUtil.copyStream((InputStream)payload, ps);
					} else {
						ps.print(payload);
					}
					ps.close();
				}
				return getRestResponse(urlc, out);
			} catch(IOException e) {
				throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, e.getMessage());
			}
		} finally {
			StreamUtil.closeStream(out);
		}
	}

	private RESTResponse getRestResponse(URLConnection urlc, OutputStream out) {
		InputStream stream = null;
		int responseStatus = 200;
		HttpURLConnection httpConnection = null;
		if(urlc instanceof HttpURLConnection) {
             httpConnection = ((HttpURLConnection) urlc);
        }
		try {
			stream = urlc.getInputStream();
			responseStatus = httpConnection.getResponseCode();
		}  catch(ConnectException c) {
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, urlc.getURL());
		}  catch(SocketException c) {
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, urlc.getURL());
		} catch(SocketTimeoutException c) {
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_SOCKET_TIMEOUT, (urlc.getReadTimeout()/1000));
		} catch (IOException e) {
			if(urlc instanceof HttpURLConnection) {
				try {
					responseStatus = httpConnection.getResponseCode();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				stream = httpConnection.getErrorStream();
			}
		}
		if(responseStatus != 304 && stream != null) {
            if(urlc.getContentEncoding() != null && urlc.getContentEncoding().equals("gzip")) {
                LOG.debug("Response received as GZIP");
                GZIPInputStream gZipInputStream;
                try {
                    gZipInputStream = new GZIPInputStream(stream);
                    StreamUtil.copyStream(gZipInputStream, out);
                } catch (EOFException e) {
                    //Empty Input Stream
                } catch (IOException e) {
                    throw new SdmxException(e, "I/O Exception while trying to unzip stream retrieved from service:" +urlc.getURL());
                }
            } else {
                LOG.debug("Response received not compressed");
                StreamUtil.copyStream(stream, out);
            }
        }
		return new RESTResponse(responseStatus, urlc.getHeaderFields());
	}

	/**
	 * Sets response timeout in Seconds
	 * @param responseTimeout
	 */
	public void setResponseTimeout(int responseTimeout) {
		defaultResponseTimeout = responseTimeout*1000;
	}
	/**
	 * Sets connect timeout in Seconds
	 * @param responseTimeout
	 */
	public void setConnectTimeout(int responseTimeout) {
		defaultConnectTimeout = responseTimeout*1000;
	}
	
	public void setUserAgent(String value) {
		userAgent = value;
	}
	
	public String getUserAgent() {
		return userAgent;
	}
	
	public void storeGlobalAuthorization(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public void clearGlobalAuthorization() {
		username = null;
		password = null;
	}
}