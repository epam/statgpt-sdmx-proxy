package io.sdmx.utils.http.model;

import java.io.OutputStream;

/**
 * Represents a request to a particular destination and includes Header information such as repsonseType
 */
public class Header {
	private Object payload;
	private OutputStream out;
	private String destination;
	
	private String responseFormat;
    private String responseVersion;

	public Header(Object payload, OutputStream out, String destination, String responseFormat, String responseVersion) {
    	this.payload = payload;
    	this.out = out;
    	this.responseFormat = responseFormat;
    	this.responseVersion = responseVersion;
    	this.destination = destination;
    }
    
    public Object getPayload() {
		return payload;
	}

	public OutputStream getOut() {
		return out;
	}

	public String getDestination() {
		return destination;
	}
	
	/**
	 * Returns a string representation of the Accept format as defined in the document:
	 * SDMX Guidelines for the use of Web Services.
	 * @return a string
	 */
	public String getAcceptFormat() {
		// The format to return is the following:
		//    application/vnd.sdmx.[format]+xml;version=[version]
	    return "application/vnd.sdmx." + responseFormat +"+xml;version=" + responseVersion;
	}
    
    
}
