package io.sdmx.utils.http.model;

import io.sdmx.utils.http.api.model.IBearerAuthentication;
import io.sdmx.utils.http.api.model.IToken;

public class BearerAuthentication implements IBearerAuthentication {
	private IToken token;
	
	
	public BearerAuthentication(IToken token) {
		this.token = token;
	}

	@Override
	public String getAuthorizationHeader() {
		return "Bearer "+this.getToken();
	}
	
	@Override
	public void invalidate() {
		token.invalidateToken();
	}

	@Override
	public String getToken() {
		return this.token.getToken();
	}
	
	@Override
	public boolean isValid() {
		return this.token != null && this.token.getToken() != null;
	}
	@Override
	public String toString() {
		return getAuthorizationHeader();
	}
}
