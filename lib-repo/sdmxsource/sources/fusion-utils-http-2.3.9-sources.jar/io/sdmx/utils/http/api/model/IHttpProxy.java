package io.sdmx.utils.http.api.model;

/**
 * An object that represents an HTTP Proxy
 */
public interface IHttpProxy {

    public String getDomain();
    
    public String getProxyUrl();

    public Integer getProxyPort();
    
    public String getProxyUser();

    public String getProxyPassword();

    public String getDecryptedPassword();
}
