package io.sdmx.utils.http.model;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.codehaus.jettison.json.JSONObject;

/**
 * represents a JSON Object being returned from a REST web service
 */
public class JSONObjectResponse  {
	private RESTResponse restResponse;
	private JSONObject json;
	private byte[] errorResponse;

	/**
	 * When the response is not a 200 status and not a JSONObject, the byte[] returned from the server is stored
	 * @param restResponse
	 * @param errorResponse
	 */
	public JSONObjectResponse(RESTResponse restResponse, byte[] errorResponse) {
		this.restResponse = restResponse;
		this.errorResponse = errorResponse;
	}
	
	public JSONObjectResponse(RESTResponse restResponse, JSONObject json) {
		this.restResponse = restResponse;
		this.json = json;
	}

	public RESTResponse getRestResponse() {
		return restResponse;
	}

	public JSONObject getJson() {
		return json;
	}

	public byte[] getErrorResponse() {
		return errorResponse;
	}

	/**
	 * Builds the class from the JSON Object 
	 * @param claz expected to have a a single argument constructor which takes a JSONObject
	 * @return
	 */
	public <T> T build(Class<T> claz) {
		for(Constructor constructor : claz.getConstructors()) {
			if(constructor.getParameterCount() == 1) {
				if(constructor.getParameters()[0].getType().isAssignableFrom(JSONObject.class)) {
					try {
						return (T) constructor.newInstance(json);
					} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
						throw new RuntimeException(e);
					}
				}
			}
		}
		throw new IllegalArgumentException("Class '"+claz.getCanonicalName()+"' must have a constructor which accepts JSONObject or JSONArray");
	}
}
