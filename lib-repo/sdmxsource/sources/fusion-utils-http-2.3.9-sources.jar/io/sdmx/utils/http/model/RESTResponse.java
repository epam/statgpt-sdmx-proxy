package io.sdmx.utils.http.model;

import java.util.List;
import java.util.Map;

import io.sdmx.utils.http.api.model.IHTTPResponse;

public class RESTResponse implements IHTTPResponse {
	private int status;
	private Map<String, List<String>> responseHeaders;

	public RESTResponse(int status, Map<String, List<String>> responseHeaders) {
		this.status = status;
		this.responseHeaders = responseHeaders;
	}

	public int getStatus() {
		return status;
	}

	@Override
	public Map<String, List<String>> getResponseHeaders() {
		return responseHeaders;
	}

	@Override
	public boolean isError() {
		return status != 200;
	}
	
}
