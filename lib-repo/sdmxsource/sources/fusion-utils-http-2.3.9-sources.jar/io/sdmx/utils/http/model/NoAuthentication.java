package io.sdmx.utils.http.model;

import io.sdmx.utils.http.api.model.IAuthentication;

/**
 * Represents a user with no authentication information
 */
public class NoAuthentication implements IAuthentication {
	public static final NoAuthentication INSTANCE = new NoAuthentication();
	
	private NoAuthentication() {}

	@Override
	public String getAuthorizationHeader() {
		return null;
	}
	
	@Override
	public void invalidate() {}

	@Override
	public boolean isValid() {
		return true;
	}

	@Override
	public String toString() {
		return "No Authorization";
	}
}
