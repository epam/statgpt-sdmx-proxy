package io.sdmx.utils.http.api.model;

/**
 * Represents a token - which may change over time due to security reasons (i.e. open id connect token)
 */
public interface IToken {

	/**
	 * @return the token, this may change over time - null if the token is no longer valid
	 */
	 String getToken();
	 
	 /**
	  * Invalidates the token
	  */
	 void invalidateToken(); 
	 
}
