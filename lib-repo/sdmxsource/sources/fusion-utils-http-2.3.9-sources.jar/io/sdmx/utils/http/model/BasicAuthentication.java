package io.sdmx.utils.http.model;

import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.http.api.model.IBasicAuthentication;

public class BasicAuthentication implements IBasicAuthentication {
	private String username;
	private String password;
	private String authHeader;

	public BasicAuthentication(String username, String password) {
		if(username == null) {
			throw new IllegalArgumentException("username required");
		}
		if(password == null) {
			throw new IllegalArgumentException("password required");
		}
		this.username = username;
		this.password = password;
		this.authHeader = AuthorizationUtil.createAuthorizationHeader(username, password);;
	}

	
	
	@Override
	public void invalidate() {
		this.username = null;
		this.password = null;
		this.authHeader = null;
	}

	@Override
	public boolean isValid() {
		return this.username != null && this.password != null;
	}
	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public String getPasword() {
		return password;
	}
	
	@Override
	public String getAuthorizationHeader() {
		return authHeader;
	}
	
	@Override
	public String toString() {
		return getAuthorizationHeader();
	}
}
