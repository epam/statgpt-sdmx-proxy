package io.sdmx.utils.http.api.model;

import java.util.Map;

import io.sdmx.api.http.HTTP_METHOD;

/**
 * Represents a request to be sent to a web service via the RESTMessageBroker
 *
 */
public interface IHTTPRequest {
	
	/**
	 * @return not null - GET, POST, DELETE
	 */
	HTTP_METHOD getMethod();
	
	/**
	 * Returns the payload of the request, this could be:
	 * <ul>
	 *  <li>null - indicating the request is a GET</li>
	 *  <li>ByteArrayOutputStream</li>
	 *  <li>ReadableDataLocation</li>
	 *  <li>String (or if other Object the toString will be used)</li>
	 * </ul>
	 * @return
	 */
	Object getPayload();
	
	/**
	 * Returns the accept header, or null if all are accepted
	 * @return
	 */
	String getAccept();
	
	/**
	 * Returns the read timeout time in milliseconds, defaults to 120000
	 * @return
	 */
	int getReadTimeout();
	
	/**
	 * Returns the connection timeout time in milliseconds, defaults to 120000
	 * @return
	 */
	int getConnectTimeout();
	
	/**
	 * Returns a map of header parameters
	 * @return
	 */
	Map<String, String> getHeaderParameters();
	
	/**
	 * Adds a header parameter to the request
	 * @param key
	 * @param value
	 */
	IHTTPRequest addHeaderParam(String key, String value);
	
	/**
	 * Sets the accept header
	 * @param accept
	 * @return
	 */
	IHTTPRequest setAccept(String accept);
	
	IHTTPRequest setReadTimeout(int readTimeout);

	IHTTPRequest setConnectTimeout(int connectTimeout);
}
