package io.sdmx.utils.http.model;

import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.utils.http.api.model.IAuthentication;
import io.sdmx.utils.http.api.model.IRESTRequest;


public class RESTRequest extends HTTPRequestImpl implements IRESTRequest {
	private String url;
	private IAuthentication authentication = NoAuthentication.INSTANCE;

	public RESTRequest(Object payload, String url) {
		this(payload, url, null);
	}
	
	public RESTRequest(Object payload, String url, HTTP_METHOD method) {
		super(payload, method);
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public RESTRequest setAuthentication(IAuthentication auth) {
		if(auth != null) {
			this.authentication = auth;
		} else {
			authentication = NoAuthentication.INSTANCE;
		}
		return this;
	}

	@Override
	public IAuthentication getAuthentication() {
		return authentication;
	}
}
