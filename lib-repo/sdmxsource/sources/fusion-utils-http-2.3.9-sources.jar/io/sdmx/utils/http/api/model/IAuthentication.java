package io.sdmx.utils.http.api.model;

/**
 * Authenication details (e.g. a token, or a username/password) 
 */
public interface IAuthentication {

	/**
	 * @return the string value to use in an HTTP Authorization header - returns null if this does not support the authorization header as a means to transmist the authentication
	 * information
	 */
	String getAuthorizationHeader();
	
	/**
	 *@return true if this authentication method is still valid (i.e. it could expire)
	 */
	boolean isValid();
	
	/**
	 * Clears any authentication credentials - 
	 */
	void invalidate();
}
