package io.sdmx.utils.spring;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.Resource;

import io.sdmx.utils.core.object.ObjectUtil;

public class FusionPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer implements InitializingBean {
	private static final Logger LOG = LoggerFactory.getLogger(FusionPropertyPlaceholderConfigurer.class);
	private String environmentVariableName;
	private Resource[] locations;

	public FusionPropertyPlaceholderConfigurer(String environmentVariableName) {
		this.environmentVariableName = environmentVariableName;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		// If the user has specified a value for th then ensure that it exists
		String value = System.getProperty(environmentVariableName);
		if (ObjectUtil.validString(value)) {
			LOG.info("Property " + environmentVariableName + " has been specified as " + value);
			final String errorMessage = "Fatal Error: Application Terminated! Cause: An environment value was specified for the property: " + environmentVariableName;

			// Test to see if the file already exists
			File f = null;
			try {
				f = new File(new URI(value));
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
			if(f == null) {
				throw new RuntimeException(errorMessage + " does not exist and can not be created");
			}
			if (f.exists()) {
				// Ensure it's not a directory
				if (f.isDirectory()) {
					throw new RuntimeException(errorMessage + ". However this value is a directory. Specified value: " + value);
				}
			} else {
				File parentDir = f.getParentFile();
				if (!parentDir.exists()) {
					boolean createDirs = parentDir.mkdirs();
					if (!createDirs) {
						throw new RuntimeException(errorMessage + ". However this location does not exist and can not be created! Specified value: " + value);
					}
				}

				boolean createNewFile;
				try {
					createNewFile = f.createNewFile();
				} catch (Exception e) {
					e.printStackTrace();
					throw new RuntimeException(errorMessage + ". However this file can not be created. Specified value: " + value, e);
				}
				if (!createNewFile) {
					throw new RuntimeException(errorMessage + ". However this file can not be created. Specified value: " + value);
				}
			}
		}
		super.setLocations(locations);
	}
	
	public Properties getProperties() {
		try {
			return super.mergeProperties();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void setLocations(Resource... locations) {
		this.locations = locations;
	}
}