package io.sdmx.utils.spring;

import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import jakarta.servlet.ServletContext;

@Service
public class SpringBeanFactory implements ServletContextAware {
	private static ServletContext context;


	public static Object getBean(String name) {
		if(context == null) {
			return SpringBeanFactoryForTesting.getBean(name);
		}
		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(context);
		return wac.getBean(name);
	}


	@Override
	public void setServletContext(ServletContext servletContext) {
		context = servletContext;
	}
	
}
