package io.sdmx.utils.spring;

import java.util.Collection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.context.ApplicationContext;

import io.sdmx.api.application.IFusionContainer;
import io.sdmx.api.application.ISingletonContainer;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SpringBeansContainer implements ISingletonContainer, IFusionContainer  {
	private final ApplicationContext CTX;
	private long startupTime;
	
	public SpringBeansContainer(ApplicationContext ctx) {
		this.CTX = ctx;
		SingletonStore.setContainer(this);
		SingletonStore.checkFutures();
		FusionBeanStore.setContainer(this);
		this.startupTime = System.currentTimeMillis();
	}
	
	@Override
	public <T> Collection<T> getBeansOfType(Class<T> type) {
		return CTX.getBeansOfType(type).values();
	}

	@Override
	public <T> T getSingleton(Class<T> type) throws BeansException {
		try {
			return CTX.getBean(type);
		} catch(NoUniqueBeanDefinitionException e) {
			throw new RuntimeException(e.getMessage());
		} catch(Throwable th) {
			return null;
		}
	}

	@Override
	public <T> T getSingleton(Class<T> type, String name) {
		try {
			return CTX.getBean(name, type);
		} catch(Throwable th) {
			return null;
		}
	}

	@Override
	public long getStartupTime() {
		return startupTime;
	}

}
