package io.sdmx.utils.spring;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringBeanFactoryForTesting implements ApplicationContextAware {
	private static ApplicationContext context;
	
	public static Object getBean(String name) {
		return context.getBean(name);
	}
	
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		SpringBeanFactoryForTesting.context = context;		
	}

	
}
