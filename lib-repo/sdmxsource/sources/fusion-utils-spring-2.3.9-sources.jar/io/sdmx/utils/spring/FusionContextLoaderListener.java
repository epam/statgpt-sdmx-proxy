package io.sdmx.utils.spring;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

import io.sdmx.api.application.ApplicationShutdownAware;
import io.sdmx.api.application.ApplicationStarter;
import io.sdmx.api.security.ISecurityContextHolder;
import io.sdmx.utils.core.application.FusionBeanStore;
import jakarta.servlet.ServletContextEvent;

public class FusionContextLoaderListener extends ContextLoaderListener {
    private static final Logger LOG = LoggerFactory.getLogger(FusionContextLoaderListener.class);
	private SpringBeansContainer container;
	
	@Override
	public void contextInitialized(ServletContextEvent event) {
		try {
			super.contextInitialized(event);
			ApplicationContext appContext = getCurrentWebApplicationContext();
			//Register spring bean container with the Fusion Sington and Bean store framework
			container = new SpringBeansContainer(appContext);
			LOG.info("Spring Context Initialized, ApplicationStarter to start ApplicationStartupAware Beans");
			
			ISecurityContextHolder ctxHolder = appContext.getBean(ISecurityContextHolder.class);
			if(ctxHolder != null) {
				ctxHolder.runAsRoot(()-> {
					appContext.getBean(ApplicationStarter.class).startApplication(FusionBeanStore.getInstance());
				});
			} else {
				appContext.getBean(ApplicationStarter.class).startApplication(FusionBeanStore.getInstance());
			}
			
			LOG.info("ApplicationStartupAware Beans Initialized");
		} catch(Throwable th) {
			LOG.error("Error Starting Web Application: ", th);
			LOG.warn("Shutting Down Server");
			throw th;
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		// Manually de-register JDBC driver, which prevents Tomcat 7 from complaining
		// about memory leaks with respect to this class
        Enumeration<Driver> drivers = DriverManager.getDrivers();
        while (drivers.hasMoreElements()) {
            Driver driver = drivers.nextElement();
            try {
                DriverManager.deregisterDriver(driver);
                LOG.info("deregistering jdbc driver: " + driver);
            } catch (SQLException e) {
                LOG.error("Error deregistering driver: " + driver);
                LOG.error("SQLException", e);
            }
        }

        
        // Debug sleep for 1 second
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		    Thread.currentThread().interrupt();
		}
		
		
		// Attempt to shut-down any running Threads
		WebApplicationContext wac = getCurrentWebApplicationContext();
		if(wac != null) {
			Map<String, ApplicationShutdownAware> shutdownMap = wac.getBeansOfType(ApplicationShutdownAware.class);
			if(shutdownMap != null) {
				for(ApplicationShutdownAware shutdownApp : shutdownMap.values()) {
					try {
						shutdownApp.shutdown();
					} catch(Throwable th) {
						System.out.println("SHUTDOWN ERROR");
						th.printStackTrace();
					}
				}
			}
		}
		super.contextDestroyed(event);

		// Display all remaining Threads
		/*
		ThreadGroup rootGroup = Thread.currentThread( ).getThreadGroup( );
		ThreadGroup parentGroup;
		while ( ( parentGroup = rootGroup.getParent() ) != null ) {
		    rootGroup = parentGroup;
		}

		Thread[] threads = new Thread[ rootGroup.activeCount() ];
		while ( rootGroup.enumerate( threads, true ) == threads.length ) {
		    threads = new Thread[ threads.length * 2 ];
		}
		
		System.out.println("------------------------------");
		for (Thread thread : threads) {
			if (thread.getName().startsWith("Thread")) {
				System.out.println(thread.getId());
				System.out.println(thread.getName());
				System.out.println(
						Arrays.toString(thread.getStackTrace()) );
				System.out.println("------------------------------");
			}
		}
		*/
	}
}
