package io.sdmx.utils.spring;

import java.util.concurrent.Executor;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.AbstractApplicationEventMulticaster;
import org.springframework.core.ResolvableType;
import org.springframework.core.task.SyncTaskExecutor;

public class FusionApplicationEventMulticaster extends AbstractApplicationEventMulticaster {
	private SyncTaskExecutor taskExecutor = new SyncTaskExecutor();

	/**
	 * Return the current TaskExecutor for this multicaster.
	 */
	protected Executor getTaskExecutor() {
		return taskExecutor;
	}

	@Override
	public void multicastEvent(final ApplicationEvent event) {
		this.multicastEvent(event, null);
	}

	@Override
	public void multicastEvent(ApplicationEvent event, ResolvableType eventType) {
		if(eventType == null) {
			eventType = ResolvableType.forClass(event.getClass());
		}
		for (final ApplicationListener listener : getApplicationListeners(event, eventType)) {
			listener.onApplicationEvent(event);
		}

	}
}
