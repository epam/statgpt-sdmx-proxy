package io.sdmx.utils.spring;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.ServletContextAware;

import io.sdmx.api.application.ApplicationStarter;
import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.application.IFusionContainer;
import io.sdmx.api.application.UpgradeManager;
import io.sdmx.api.cache.Cache;
import io.sdmx.api.dao.settings.FusionProductSettings;
import io.sdmx.api.dao.settings.FusionProductSettingsDao;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.plugin.IBeanRetreivalAware;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SystemSecurity;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.plugin.PluginUtil;
import io.sdmx.utils.core.version.VersionableUtil;
import jakarta.servlet.ServletContext;

public class ApplicationStarterImpl implements ApplicationStarter, ServletContextAware  {
    private static final Logger LOG = LoggerFactory.getLogger(ApplicationStarterImpl.class);

	@Autowired(required = false)
	private FusionProductInformationRetrievalManager fusionProductInformationRetrievalManager;

	@Autowired(required = false)
	private FusionProductSettingsDao<FusionProductSettings> productSettingsDao;

	@Autowired(required = false)
	private UpgradeManager upgradeManager;
	
	private SdmxBeanRetrievalManager beanRetrievalManager;

	private int startupCount = 0;

	private long startupTime = 0L;

	private static final String VERSION_TOKEN = "$VERSION$";

	Map<IFusionContainer, Boolean> isStartedMap = new HashMap<>();

	private ServletContext servletContext;

	private String pluginPackageToScan;
	
	public ApplicationStarterImpl(SdmxBeanRetrievalManager beanRetrievalManager) {
		this(beanRetrievalManager, null);
	}
	
	public ApplicationStarterImpl(SdmxBeanRetrievalManager beanRetrievalManager, String pluginPackage) {
		this.beanRetrievalManager = ObjectUtil.assertNotNull(beanRetrievalManager);
		this.pluginPackageToScan = pluginPackage;
	}

	@Override
	public void startApplication(IFusionContainer applicationContext) {
		SystemSecurity.setApplicationStarted(false);
		isStartedMap.put(applicationContext, false);
		if(startupCount > 0) {
			Collection<Cache> cache = applicationContext.getBeansOfType(Cache.class);
			for (Cache c : cache) {
				c.clearCache();
			}
		}
		startupCount++;

		Collection<ApplicationStartupAware> startupMap = FusionBeanStore.getBeans(ApplicationStartupAware.class);

		List<ApplicationStartupAware> started = new ArrayList<>();

		if(pluginPackageToScan != null) {
			PluginUtil.loadPlugins(pluginPackageToScan);
		}
		
		// FR-1495: Preserve the value from the database since it will be updated before being evaluated!
		String versionFromDatabase = null;
		if (productSettingsDao == null) {
			LOG.warn("Unable to obtain FusionProductSettingsDao");
		} else {
			FusionProductSettings fps = productSettingsDao.findByName("installed.version");
			if (fps != null) {
				versionFromDatabase = fps.getValue();
			}
		}

		if(fusionProductInformationRetrievalManager != null && fusionProductInformationRetrievalManager.getFusionProductInformation() != null) {
			String url = fusionProductInformationRetrievalManager.getFusionProductInformation().getApplicationURL();
			if(ObjectUtil.validString(url)) {
				try {
					URL urlObj = new URL(url);
					if(urlObj.getProtocol().equals("https")) {
						this.servletContext.getSessionCookieConfig().setSecure(true);
					}else {
						this.servletContext.getSessionCookieConfig().setSecure(false);
					}
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}catch (IllegalStateException e) {

				}
			}
		}

		if(beanRetrievalManager != null) {
			Collection<IBeanRetreivalAware> beanRetrievalAware = applicationContext.getBeansOfType(IBeanRetreivalAware.class);
			if(beanRetrievalAware != null) {
				for(IBeanRetreivalAware bra : beanRetrievalAware) {
					bra.setBeanRetreivalManager(beanRetrievalManager);
				}
			}
		}


		boolean requiresStartupChecks = true;
		while(requiresStartupChecks) {
			requiresStartupChecks = false;
			for(ApplicationStartupAware currentAsw : startupMap) {
				if(!isStarted(currentAsw, started)) {
					LOG.debug("Checking ApplicationStartupAware " + currentAsw.getClass());
					if(!hasUnstartedDependencies(currentAsw, startupMap, started)) {
						LOG.info("Starting "+ currentAsw.getClass());
						try {
							startupRequest(currentAsw);
							LOG.info("Startup complete for :  "+ currentAsw.getClass());
						} catch(Throwable th) {
							startupFailed(currentAsw, th);
						}
						started.add(currentAsw);
					} else {
						requiresStartupChecks = true;
						LOG.info("Postpone startup until dependencies started");
					}
				}
			}
		}
		upgradeChecks(versionFromDatabase);
		isStartedMap.put(applicationContext, Boolean.TRUE);
		if(isStarted()) {
			SystemSecurity.setApplicationStarted(true);
			this.startupTime = applicationContext.getStartupTime();
		}
	}

	protected void startupRequest(ApplicationStartupAware currentAsw) {
		currentAsw.applicationStarted();
	}
	
	protected void startupFailed(ApplicationStartupAware currentAsw, Throwable th) {
		LOG.error("Startup Failed for Class:"+currentAsw.getClass(), th);
		this.startupTime = 0L;
	}

	private void upgradeChecks(String dbVersion) {
	    if (fusionProductInformationRetrievalManager == null) {
	        LOG.warn("Since there is no fusionProductInformationRetrievalManager cannot check for upgrades");
	        return;
	    }
		FusionProductInformation fusionProductInformation = fusionProductInformationRetrievalManager.getFusionProductInformation();

		if(fusionProductInformation == null) {
			LOG.warn("FusionVersionManager can not obtain FusionProductInformation");
			return;
		}
		if(productSettingsDao == null) {
			LOG.warn("FusionVersionManager can not obtain FusionProductSettingsDao");
			return;
		}
		String applicationVersion = fusionProductInformation.getProductDetails().getVersion();
		String productName = fusionProductInformation.getProductDetails().getProduct();
		LOG.info("Checking " + productName + " Application version = " + applicationVersion);
		if (!ObjectUtil.validString(applicationVersion)) {
			LOG.warn("There is no Product Version information. Unable to perform upgrade checks.");
			// Cannot obtain the application version, so exit;
			return;
		}
		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
		SdmxException.disableExceptionTrace(true);
        try {
            if (applicationVersion.equals(VERSION_TOKEN) || (!VersionableUtil.validVersion(applicationVersion))) {
                LOG.warn(productName + "Version deemed invalid. Value is: " + applicationVersion);
                return;
            }
        } finally {
            SdmxException.disableExceptionTrace(wasDisabled);
        }

		if (dbVersion == null) {
			FusionProductSettings fps = productSettingsDao.findByName("installed.version");
			if (fps != null) {
				dbVersion = fps.getValue();
			}
		}

		if (dbVersion == null) {
			LOG.info("Checking " + productName + " - Unable to obtain value from database");
			return; // No need to perform upgrade checks since the previous version is unknown
		}

		LOG.info("Checking " + productName + " Version: Database version = " + dbVersion);
		if (dbVersion.equals(applicationVersion)) {
			// The database version is equal to the application version. Do not perform upgrades.
			return;
		}

		try {
			if (VersionableUtil.isHigherVersion(dbVersion, applicationVersion)) {
				// The database version is greater than the application version. Do not perform upgrades.
				return;
			}
		} catch (SdmxSemmanticException e) {
			return;
		}

		if (upgradeManager == null) {
			LOG.info("No Upgrade Manager, so unable to perform upgrade checks.");
			return;
		}

		LOG.info("Performing Upgrade Checks");
		upgradeManager.performUpgrade(applicationVersion, dbVersion);
	}

	@Override
	public boolean isStarted() {
		if(isStartedMap.size() == 0) {
			return false;
		}
		for(IFusionContainer ctx : isStartedMap.keySet()) {
			if(isStartedMap.get(ctx) == false) {
				return false;
			}
		}
		return true;
	}

	@Override
	public Long getApplicationStartupTime() {
		return startupTime;
	}

	private boolean isStarted(ApplicationStartupAware awa, List<ApplicationStartupAware> awas) {
		for(ApplicationStartupAware currentAsw : awas) {
			if(currentAsw == awa) {
				return true;
			}
		}
		return false;
	}

	private boolean hasUnstartedDependencies(ApplicationStartupAware asw,
			Collection<ApplicationStartupAware> allAwas,
			List<ApplicationStartupAware> startedAwas) {
		if(asw.getDependsOn() != null) {
			for(Class<ApplicationStartupAware> currentDependancyCheck : asw.getDependsOn()) {
				if(requiresStart(currentDependancyCheck, allAwas, startedAwas)) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean requiresStart(Class<ApplicationStartupAware> awa,
			Collection<ApplicationStartupAware> allAwas,
			List<ApplicationStartupAware> startedAwas) {
		for(ApplicationStartupAware currentAsw : allAwas) {
			if(awa.isAssignableFrom(currentAsw.getClass())) {
				if(!isStarted(currentAsw, startedAwas)) {
					LOG.debug("Unstarted Dependency found :  " + currentAsw);
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}
}