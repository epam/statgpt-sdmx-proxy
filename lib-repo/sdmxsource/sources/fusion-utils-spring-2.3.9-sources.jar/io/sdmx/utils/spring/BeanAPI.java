package io.sdmx.utils.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * The bean API is used to retrieve a bean factory which can be used to create java objects.
 */
public class BeanAPI implements ApplicationContextAware {
	private static BeanFactory factory;	

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		factory = applicationContext;
	}	
	
	public static Object getBean(String beanName) {
		Object bean = factory.getBean(beanName);
		if(bean == null) {
			throw new IllegalArgumentException("Bean could not be found : " + beanName);
		}
		return bean;
	}
}
