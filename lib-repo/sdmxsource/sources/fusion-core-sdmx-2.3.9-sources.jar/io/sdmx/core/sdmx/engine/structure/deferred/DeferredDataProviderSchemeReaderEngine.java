package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.base.DataProviderSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link DataProviderSchemeBeanDeferred}
 */
public class DeferredDataProviderSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<DataProviderSchemeBean> {
    private static DeferredDataProviderSchemeReaderEngine INSTANCE;
    
    private DeferredDataProviderSchemeReaderEngine() {
        super(DataProviderSchemeBean.class);
    }
    
    public static DeferredDataProviderSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredDataProviderSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<DataProviderSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new DataProviderSchemeBeanDeferred(bean, loader);
    }

}
