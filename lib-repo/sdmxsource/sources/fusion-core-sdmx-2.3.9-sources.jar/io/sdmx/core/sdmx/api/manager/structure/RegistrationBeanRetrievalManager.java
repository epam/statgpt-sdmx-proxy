
package io.sdmx.core.sdmx.api.manager.structure;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;


/**
 * Manages the retrieval of registrations by using simple structures that directly reference a registration
 * @author Matt Nelson
 *
 */
public interface RegistrationBeanRetrievalManager {

	/**
	 * Returns all the registrations.  Returns an empty set if no registrations exist.
	 * @return
	 */
	Set<RegistrationBean> getAllRegistrations();

	/**
	 * @param ref
	 * @return registartion by absolute reference
	 */
	RegistrationBean getRegistration(IURNSingle<RegistrationBean> ref);
	
	/**
	 * Returns all the registrations against the structure references
	 * <p/>
	 * The structure reference can either be referencing a Provision structure, a Data or MetdataFlow, or a DataProvider.
	 * 
	 * @return
	 */
	Set<RegistrationBean> getRegistrationsByDataProvider(IURN<DataProviderBean> providerRef);
	
	
	/**
	 * Returns all the registrations against the structure references
	 * <p/>
	 * The structure reference can either be referencing a Provision structure, a Data or MetdataFlow, or a DataProvider.
	 * 
	 * @return
	 */
	Set<RegistrationBean> getRegistrations(IURN<? extends IDSDRelatedBean> structureRef);
	
	
	
}
