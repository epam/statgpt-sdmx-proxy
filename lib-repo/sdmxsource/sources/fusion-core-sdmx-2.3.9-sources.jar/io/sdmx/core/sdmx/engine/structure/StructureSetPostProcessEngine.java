package io.sdmx.core.sdmx.engine.structure;

import java.util.Set;

import io.sdmx.core.sdmx.api.engine.structure.IStructureReadPostProcessEngine;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.MultipleBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.constant.InternalConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * For any Structure Sets that were generated from SDMX 2.1 (identified by an annotation) add mappings for: OBS_VALUE -> OBS_VALUE
 * and TIME_PERIOD -> TIME_PERIOD if there are not already present mappings for these values.
 * Also remove the annotation.
 */
public class StructureSetPostProcessEngine implements IStructureReadPostProcessEngine {

	private static final Logger LOG = LoggerFactory.getLogger(StructureSetPostProcessEngine.class);
	
	private SdmxBeanRetrievalManager beanRetrievalManager;

	public StructureSetPostProcessEngine(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	@Override
	public void postProcess(SdmxBeans beans) {
		LOG.debug("Invoked postProcess");
		
		Set<IStructureMapBean> structureMaps = beans.getStructureMaps();
		if (structureMaps.isEmpty()) {
			return;
		}
		
		SdmxBeanRetrievalManager localRetrievalManager = null;
		for (IStructureMapBean aStructureMap : structureMaps) {
			if (aStructureMap.hasAnnotationType(InternalConstants.STRUCTURE_SET_UPGRADE)) {
				if (localRetrievalManager == null) {
					localRetrievalManager = createLocalRetrievalManager(beans);
				}
				
				// Need to check to see if we need to add an OBS_VALUE and TIME_PERIOD mapping
				IStructureMapMutableBean mutableMap = aStructureMap.getMutableInstance();
				checkStructureMap(mutableMap, beans, localRetrievalManager);

				// Remove the annotation.
				mutableMap.removeAnnotationsByType(InternalConstants.STRUCTURE_SET_UPGRADE);

				// Update the beans object
				beans.addIdentifiable(mutableMap.getImmutableInstance());
			}
		}
	}
	
	private SdmxBeanRetrievalManager createLocalRetrievalManager(SdmxBeans beans) {
		SdmxBeanRetrievalManager inMemoryRetrievalManager = new InMemoryRetrievalManager(beans);
		if(beanRetrievalManager == null) {
			return inMemoryRetrievalManager;
		}

		// There are other beans to cross-reference and also a beans object passed in, so wrap both in a MultipleBeanRetrievalManager
		return new MultipleBeanRetrievalManager(beanRetrievalManager, inMemoryRetrievalManager);
	}
	
	/**
	 * Check the specified structure map adding additional mappings if required
	 * @param mutableMap
	 * @param beans
	 */
	private void checkStructureMap(IStructureMapMutableBean mutableMap, SdmxBeans beans, SdmxBeanRetrievalManager retMan) {
		// Determine if the target DSD has TIME_PERIOD and OBS_VALUE
		DatasetStructures structures = new DatasetStructures(mutableMap.getTargetRef(), retMan);
		DataStructureBean refDsd = structures.getDataStructure();
		boolean targetDsdHasTimePeriod = refDsd.getTimeDimension() != null;
		boolean targetDsdHasObsValue = refDsd.getPrimaryMeasure() != null;
		
		if (!targetDsdHasObsValue && !targetDsdHasTimePeriod) {
			// No mappings to add - early out
			return;
		}

		// Walk the Structure Set mappings seeing if there is an existing mapping for OBS_VALUE or TIME_PERIOD
		boolean hasObsValueMapping = false;
		boolean hasTimePeriodMapping = false;
		for(IComponentMapMutableBean compMap : mutableMap.getComponentMaps()) {
			// SDMX 2.1 could only map a single source to a single target
			if (compMap.getSourceComponents().size() == 1 && compMap.getTargetComponents().size() ==1) {
				if (PrimaryMeasureBean.FIXED_ID.equals( compMap.getSourceComponents().get(0) ) || PrimaryMeasureBean.FIXED_ID.equals( compMap.getTargetComponents().get(0) )) {
					hasObsValueMapping = true;
				} else if (DimensionBean.TIME_DIMENSION_FIXED_ID.equals( compMap.getSourceComponents().get(0) ) || DimensionBean.TIME_DIMENSION_FIXED_ID.equals( compMap.getTargetComponents().get(0) )) {
					hasTimePeriodMapping = true;
				}
			}
		}
		
		// Add any necessary mappings
		if(targetDsdHasObsValue && !hasObsValueMapping) {
			LOG.info("Added mapping for: " + PrimaryMeasureBean.FIXED_ID);
			mutableMap.addComponentMap().addSourceComponent(PrimaryMeasureBean.FIXED_ID).addTargetComponent(PrimaryMeasureBean.FIXED_ID);
		}
		if(targetDsdHasTimePeriod && !hasTimePeriodMapping) {
			LOG.info("Added mapping for: " + DimensionBean.TIME_DIMENSION_FIXED_ID);
			mutableMap.addComponentMap().addSourceComponent(DimensionBean.TIME_DIMENSION_FIXED_ID).addTargetComponent(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}
	}

}
