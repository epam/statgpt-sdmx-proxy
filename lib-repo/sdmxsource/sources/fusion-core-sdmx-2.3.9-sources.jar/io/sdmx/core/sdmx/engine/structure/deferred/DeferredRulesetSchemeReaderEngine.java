package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.im.beans.transformation.RulesetSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * DeferredRulesetSchemeReaderEngine
 * DeferredRulesetSchemeReaderEngine
 * 
 * Converts {@link IDeferredBeanDefinition} into {@link RulesetSchemeBeanDeferred}
 */
public class DeferredRulesetSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<IRulesetSchemeBean> {
    private static DeferredRulesetSchemeReaderEngine INSTANCE;
    
    private DeferredRulesetSchemeReaderEngine() {
        super(IRulesetSchemeBean.class);
    }
    
    public static DeferredRulesetSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredRulesetSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IRulesetSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new RulesetSchemeBeanDeferred(bean, loader);
    }

}
