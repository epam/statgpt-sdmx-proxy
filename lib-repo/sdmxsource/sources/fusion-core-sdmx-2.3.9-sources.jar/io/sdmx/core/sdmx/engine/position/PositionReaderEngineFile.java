package io.sdmx.core.sdmx.engine.position;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDataPosition.POSITION_TYPE;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;
import io.sdmx.core.sdmx.model.data.FilePosition;
import io.sdmx.utils.core.application.FusionBeanStore;

public class PositionReaderEngineFile extends AbstractPositionReaderEngineFile implements IPositionReaderEngine {
	
	public static void registerInstance() {
		if (FusionBeanStore.getBeans(PositionReaderEngineFile.class).isEmpty()) {
			FusionBeanStore.registerInstance(new PositionReaderEngineFile());
		}
	}
	
	private PositionReaderEngineFile() {
		super(POSITION_TYPE.FILE);
	}

	@Override
	protected IDataPosition parsePositionalInformation(String[] split) {
		return new FilePosition(asLong(split, 1), asLong(split, 2));
	}
	
}
