package io.sdmx.core.sdmx.manager.structure;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.manager.structure.IStructureTimeTravelManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;

/**
 * Does not support structure type
 */
public class StructureTimeTravelManagerUnsupported implements IStructureTimeTravelManager {
	private IStructureEnvironment environment;
	
	public StructureTimeTravelManagerUnsupported(IStructureEnvironment environment) {
		this.environment = environment;
	}



	@Override
	public IStructureEnvironment getEnvironment(SdmxDate asOf) {
		if(asOf != null) {
			throw new SdmxNotImplementedException("asOf not implemented");
		}
		return environment;
	}
	
}
