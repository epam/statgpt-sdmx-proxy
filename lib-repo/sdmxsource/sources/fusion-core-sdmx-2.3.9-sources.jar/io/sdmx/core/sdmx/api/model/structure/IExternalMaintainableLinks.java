package io.sdmx.core.sdmx.api.model.structure;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;

/**
 * Links that are not maintained on the maintainable bean, but attached after be another process, for example reference metadata
 */
public interface IExternalMaintainableLinks {

	/**
	 * @return the maintainable that these links are for
	 */
	IURNMaintainable<?> getMaintainableURN();
	
	/**
	 * @return set of linked identifiables
	 */
	Set<IURNAbsolute<?>> getLinkedIdentifiable();
	
	/**
	 * @param identifableUrn
	 * @return all links for an identifiable, or an empty set if none exist
	 */
	Set<ILinkBean> getLinks(IURNAbsolute<?> identifableUrn);
	
}
