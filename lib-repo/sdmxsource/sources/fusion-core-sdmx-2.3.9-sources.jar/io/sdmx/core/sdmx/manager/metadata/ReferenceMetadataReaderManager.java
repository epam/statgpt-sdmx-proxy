package io.sdmx.core.sdmx.manager.metadata;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataReaderFactory;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataValidationEngine;
import io.sdmx.core.sdmx.api.manager.metadata.IReferenceMetadataReaderManager;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.sdmx.comparator.PriorityFactoryComparator;

public class ReferenceMetadataReaderManager implements IReferenceMetadataReaderManager, IFusionSingleton {
	private static ReferenceMetadataReaderManager INSTANCE;

	private static final Logger LOG = LoggerFactory.getLogger(ReferenceMetadataReaderManager.class);

	private Set<IMetadataReaderFactory> factories = null;
	private Set<IMetadataValidationEngine> validationEngines;

	public static ReferenceMetadataReaderManager getInstance() {
		if(INSTANCE == null) {
			INSTANCE = SingletonStore.getSingleton(ReferenceMetadataReaderManager.class, false);
			if(INSTANCE == null) {
				INSTANCE = new ReferenceMetadataReaderManager();
				SingletonStore.registerInstance(INSTANCE);
			}
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	/**
	 * Default constructor
	 */
	private ReferenceMetadataReaderManager() {}

	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) throws SdmxSemmanticException {
		IReferenceMetadataContainer mds = null;
		for(IMetadataReaderFactory currentFactory : getReaderFactory()) {
			mds = currentFactory.parse(rdl);
			if(mds != null) {
				LOG.trace("Build Metadata Set Complete");
				break;
			}
		}
		if(mds != null) {
			for(IMetadataValidationEngine validationEngine : getValidationEngines()) {
				validationEngine.validate(mds);
			}
			return mds;
		} else {
			throw new UnrecognisedFormatException(rdl.getInputStream());
		}
	}

	private Collection<IMetadataReaderFactory> getReaderFactory()  {
		if(factories != null) {
			return factories;
		}
		Set<IMetadataReaderFactory> factories = new TreeSet<>(PriorityFactoryComparator.INSTANCE);
		synchronized(this) {
			Collection<IMetadataReaderFactory> allBeans = FusionBeanStore.getBeans(IMetadataReaderFactory.class);
			if(allBeans != null) {
				for (IMetadataReaderFactory structureReaderFactory : allBeans) {
					factories.add(structureReaderFactory);
				}
			}
		}
		this.factories = factories;
		return factories;
	}

	private Collection<IMetadataValidationEngine> getValidationEngines()  {
		if(validationEngines != null) {
			return validationEngines;
		}
		Set<IMetadataValidationEngine> validationEngines = new HashSet<>();
		synchronized(this) {
			Collection<IMetadataValidationEngine> allBeans = FusionBeanStore.getBeans(IMetadataValidationEngine.class);
			if(allBeans != null) {
				for (IMetadataValidationEngine structureReaderFactory : allBeans) {
					validationEngines.add(structureReaderFactory);
				}
			}
		}
		this.validationEngines = validationEngines;
		return validationEngines;
	}

}
