package io.sdmx.core.sdmx.manager.structure;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.manager.structure.IAgencyRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.util.Hierarchy;
import io.sdmx.im.beans.container.AgencyHierarchyImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class AgencyRetrievalManager implements IAgencyRetrievalManager {
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public AgencyRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public Set<AgencyBean> getAgencies() {
		return getAgencySchemes().
				stream().map(e->e.getItems()).
				flatMap(List::stream).
				collect(Collectors.toSet());
	}

	@Override
	public Hierarchy<AgencyBean> getAgencyHierarchy() {
		return new AgencyHierarchyImpl(getAgencySchemes());
	}
	
	private Set<AgencySchemeBean> getAgencySchemes() {
		return beanRetrievalManager.getMaintainableBeans(URN.build(AgencySchemeBean.class));
	}

}
