package io.sdmx.core.sdmx.api.engine.data;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

/**
 * Reads data conforming to an SDMX DSD one row at a time
 * 
 * @deprecated use {@link DataReaderEngine}
 */
@Deprecated
public interface IFlatDataReaderEngine {
	
	HeaderBean readHeader();
	
	DatasetHeaderBean readDatasetHeader();

	/**
	 * @return true if there is another row of data to read
	 */
	default boolean moveNextRow() {
		return moveNextRow(null);
	}
	
	default public FormatDetails getDataFormat() {
		return null;
	}
	
	/**
	 * @param exHandler to capture any errors when reading the row
	 * @return true if there is another row of data to read
	 */
	boolean moveNextRow(DataReaderExceptionHandler exHandler);
	
	/**
	 * @return current row of data, an initial call to moveNextRow must be made in order to read the first row of data
	 */
	IDataRow getCurrentRow();

	/**
	 * Resets the reader to its initial state
	 */
	void reset();
	
	/**
	 * Closes the reader
	 */
	void close();
	
	/**
	 * @return a copy of this data reader engine, the copy is another iterator over the same source data
	 */
	IFlatDataReaderEngine createCopy();
	
	
}
