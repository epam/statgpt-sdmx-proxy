package io.sdmx.core.sdmx.api.engine.data;

/**
 * A data writer which is used to store data in a temporary location before it is read back in again
 */
public interface ITemporaryFlatDataWriterEngine extends IFlatDataWriterEngine {

	/**
	 * @return data reader to read data back in
	 */
	IFlatDataReaderEngine getDataReaderEngine();
	
	/**
	 * Removes all resources associated with the temporary store
	 */
	void removeResources();
	
}
