package io.sdmx.core.sdmx.model.type;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

/**
 * Serialization for String supporting null values.
 *
 * Note: nullable objects cannot be used  as keys or values of a MVMap,
 *       only as a component of other types.
 */
public class DT_String extends BasicDataType<String> {
  private static final DT_String INSTANCE = new DT_String();
  private static final String empty = "";

  private DT_String() {
  }

  public static DT_String getInstance() {
    return INSTANCE;
  }

  @Override
  public int compare(String a, String b) {
    return a.compareTo(b);
  }

  @Override
  public int getMemory(String s) {
    return (s == null) ? 1 : 24 + 2 * s.length(); // from StringDataType
  }

  // encode length to avoid having a long varint when s is null
  private void writeLength(WriteBuffer buf, String s) {
    buf.putVarInt(s == null ? 0 : s.length() + 1);
  }

  // decode length according to encoding performed at write time
  private Integer readLength(ByteBuffer buf) {
    int len = DataUtils.readVarInt(buf);

    return (len == 0) ? null : len - 1;
  }

  @Override
  public void write(WriteBuffer buf, String s) {
    writeLength(buf, s);

    if (s != null)
      buf.putStringData(s, s.length());
  }

  @Override
  public String read(ByteBuffer buf) {
    Integer len = readLength(buf);

    return (len == null) ? null
         : (len == 0) ? empty
         : DataUtils.readString(buf, len);
  }

  @Override
  public String[] createStorage(int size) {
    return new String[size];
  }
}
