
package io.sdmx.core.sdmx.format;

import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.utils.core.object.ObjectUtil;

public abstract class SdmxDataFormat implements DataFormat {
	private static final long serialVersionUID = 1L;
	private DATA_TYPE dataType;
	
	public SdmxDataFormat(DATA_TYPE dataType) {
		if(dataType == null) {
			throw new IllegalArgumentException("Data Type can not be null for SdmxDataFormat");
		}
		this.dataType = dataType;
	}

	public DATA_TYPE getSdmxDataFormat() {
		return dataType;
	}

	@Override
	public String toString() {
		return getSdmxDataFormat().toString();
	}

	@Override
	public int hashCode() {
		return getFormatDetails().getAcceptHeaders()[0].hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxDataFormat) {
			SdmxDataFormat that = (SdmxDataFormat)obj;
			if(this.getSdmxDataFormat() != that.getSdmxDataFormat()) {
				return false;
			}
			String acceptHeader1 = that.getFormatDetails().getAcceptHeaders().length > 0 ? that.getFormatDetails().getAcceptHeaders()[0] : null;
			String acceptHeader2 = that.getFormatDetails().getAcceptHeaders().length > 0 ? that.getFormatDetails().getAcceptHeaders()[0] : null;
			return ObjectUtil.equivalent(acceptHeader1, acceptHeader2);
		}
		return false;
	}

}
