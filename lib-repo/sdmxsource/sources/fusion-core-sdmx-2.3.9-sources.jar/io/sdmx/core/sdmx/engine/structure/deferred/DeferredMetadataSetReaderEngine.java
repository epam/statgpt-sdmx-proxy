package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.im.beans.refmetadata.ReportedMetadataSetBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ReportedMetadataSetBeanDeferred}
 */
public class DeferredMetadataSetReaderEngine extends AbstractDeferredStructureReaderEngine<IReportedMetadataSetBean> {
    private static DeferredMetadataSetReaderEngine INSTANCE;
    
    private DeferredMetadataSetReaderEngine() {
        super(IReportedMetadataSetBean.class);
    }
    
    public static DeferredMetadataSetReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredMetadataSetReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IReportedMetadataSetBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ReportedMetadataSetBeanDeferred(bean, loader);
    }

}
