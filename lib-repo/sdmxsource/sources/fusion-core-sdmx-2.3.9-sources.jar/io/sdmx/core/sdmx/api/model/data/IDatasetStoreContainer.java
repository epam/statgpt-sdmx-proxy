package io.sdmx.core.sdmx.api.model.data;

import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * represents a collection of datasets which is either in or very close to memory
 * 
 * Contains 0 to many {@link IDatasetStore}
 */
public interface IDatasetStoreContainer {
	
	/**
	 * @return datset header
	 */
	HeaderBean getHeader();

	/**
	 * @return number of datasets
	 */
	int getDatasetSize();
	
	/**
	 * @param index zero indexed
	 * @return dataset at the given index
	 */
	IDatasetStore getDataset(int index);
	
	/**
	 * closes the store
	 * @param removeResources if true all resources for this store are deleted
	 */
	void close(boolean removeResources);
	
}
