package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.categoryscheme.CategorisationBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link CategorisationBeanDeferred}
 */
public class DeferredCategorisationReaderEngine extends AbstractDeferredStructureReaderEngine<CategorisationBean> {
    private static DeferredCategorisationReaderEngine INSTANCE;
    
    private DeferredCategorisationReaderEngine() {
        super(CategorisationBean.class);
    }
    
    public static DeferredCategorisationReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredCategorisationReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<CategorisationBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new CategorisationBeanDeferred(bean, loader);
    }

}
