package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.error.IStructureValidationError;
import io.sdmx.api.sdmx.model.beans.base.IURN;

public class StructureValidationError implements IStructureValidationError {

	private IURN urn;
	private List<String> errorList;

	public StructureValidationError(IURN urn, List<String> errorList) {
		if (urn == null) {
			throw new IllegalArgumentException("Specified urn may not be null");
		}
		if (errorList == null) {
			errorList = new ArrayList<>();
		}
		this.urn = urn;
		this.errorList = errorList;
	}
	
	@Override
	public IURN getUrn() {
		return urn;
	}

	@Override
	public List<String> getErrors() {
		return errorList;
	}

}
