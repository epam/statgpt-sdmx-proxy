package io.sdmx.core.sdmx.engine.position;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDataPosition.POSITION_TYPE;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;
import io.sdmx.core.sdmx.model.data.CsvFilePosition;
import io.sdmx.utils.core.application.FusionBeanStore;

public class PositionReaderEngineCSV extends AbstractPositionReaderEngineFile implements IPositionReaderEngine {
	
	public static void registerInstance() {
		if (FusionBeanStore.getBeans(PositionReaderEngineCSV.class).isEmpty()) {
			FusionBeanStore.registerInstance(new PositionReaderEngineCSV());
		}
	}
	
	private PositionReaderEngineCSV() {
		super(POSITION_TYPE.CSV);
	}

	@Override
	protected IDataPosition parsePositionalInformation(String[] split) {
		long offset = asLong(split, 1);
		long bytes  = asLong(split, 2);
		DELIMITER delimiter = DELIMITER.parseDelimiter(split[3]);
		int cols = split.length - 4;
		List<Integer> columns = new ArrayList<>();
		for(int i=4, pos = 0; pos < cols; i++, pos++) {
			columns.add(asInteger(split, i));
		}
		return new CsvFilePosition(offset, bytes, delimiter, columns);
	}
	
}
