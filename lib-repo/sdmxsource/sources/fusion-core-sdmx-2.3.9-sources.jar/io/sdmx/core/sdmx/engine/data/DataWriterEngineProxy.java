package io.sdmx.core.sdmx.engine.data;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.process.IProcess;
import io.sdmx.api.process.IProcessArgResponse;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public abstract class DataWriterEngineProxy implements ISeriesObsDataWriterEngine {
	private ISeriesObsDataWriterEngine proxy;
	private IProcessArgResponse<Observation, Boolean> beforeObs;
	private IProcess afterObs;

	private Keyable lastKey;
	private Observation lastObs;
	
	private boolean isClosed;
	
	protected DataWriterEngineProxy() {}
	
	public DataWriterEngineProxy(ISeriesObsDataWriterEngine dwe) {
		this.proxy = dwe;
		if(dwe == null) {
			throw new SdmxException("DataWriterEngine can not be null");
		}
	}
	
	/**
	 * If set, will be called before each observation write call is passed to the proxy DataWriterEngine
	 * if this call returns false, the Observation and subsequent observation attributes will not be passed to the proxy
	 * @param beforeObs
	 */
	protected void setBeforeObs(IProcessArgResponse<Observation, Boolean> beforeObs) {
		this.beforeObs = beforeObs;
	}

	/**
	 * If set, will be called after each observation write call is passed to the proxy DataWriterEngine
	 * @param afterObs
	 */
	protected void setAfterObs(IProcess afterObs) {
		this.afterObs = afterObs;
	}

	protected void setProxy(ISeriesObsDataWriterEngine proxy) {
		this.proxy = proxy;
	}

	protected ISeriesObsDataWriterEngine getProxy() {
		return proxy;
	}

	@Override
	public void writeHeader(HeaderBean header) {
		if(proxy != null) {
			proxy.writeHeader(header);
		}
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if(proxy != null) {
			proxy.startDataset(structures, header, datasetAttributes, annotations);
		}
	}

	@Override
	public void writeKey(Keyable key) {
		if(proxy != null) {
			proxy.writeKey(key);
		}
		this.lastKey = key;
	}


	@Override
	public void writeObservation(Observation obs) {
		if(beforeObs != null) {
			if(beforeObs.runProcess(obs) == Boolean.FALSE) {
				return;
			}
		}
		if(proxy != null) {
			proxy.writeObservation(obs);
		}
		this.lastObs = obs;
		if(afterObs != null) {
			afterObs.runProcess();
		}
	}
	
	
	protected Keyable getLastKey() {
		return lastKey;
	}

	protected Observation getLastObs() {
		return lastObs;
	}

	@Override
	public void close(FooterMessage... footer) {
	    if(isClosed) {
	        return;
	    }
	    isClosed = true;
		if(proxy != null) {
			proxy.close(footer);
		}
	}
}
