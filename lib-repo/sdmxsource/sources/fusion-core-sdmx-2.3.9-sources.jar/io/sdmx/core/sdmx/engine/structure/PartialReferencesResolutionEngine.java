package io.sdmx.core.sdmx.engine.structure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.core.sdmx.api.engine.structure.IPartialReferencesResolutionEngine;
import io.sdmx.core.sdmx.api.manager.structure.MaintainableCrossReferenceRetrieverEngine;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.constraint.ContentConstraintModelImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class PartialReferencesResolutionEngine implements IPartialReferencesResolutionEngine {
	private static final Logger LOG = LoggerFactory.getLogger(PartialReferencesResolutionEngine.class);

	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private MaintainableCrossReferenceRetrieverEngine crossReferenceRetrieverEngine;
	
	public PartialReferencesResolutionEngine(SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
			MaintainableCrossReferenceRetrieverEngine crossReferenceRetrieverEngine) {
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.crossReferenceRetrieverEngine = crossReferenceRetrieverEngine;
	}

	private Set<ICrossReferenceBean<?>> getReferences(SdmxBeans beans, SdmxBeanRetrievalManager brm) {
		Set<ICrossReferenceBean<?>> references = new HashSet<>();
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			references.addAll(crossReferenceRetrieverEngine.getCrossReferences(brm, maint));
		}
		return references;
	}
	
	@Override
	public void makePartial(SdmxBeans queryResponse, SdmxBeans referencedStructures, SdmxBeanRetrievalManager brm) {
		//If the bean appears on both the query and the references, remove it from the references
		for(MaintainableBean maint : queryResponse.getAllMaintainables()) {
			referencedStructures.removeMaintainable(maint);
		}
		SdmxBeans mergedSet = new SdmxBeansImpl(queryResponse, referencedStructures);

		Set<ICrossReferenceBean<?>> allReferences = getReferences(mergedSet, brm);
		
		Map<SDMX_STRUCTURE_TYPE, Set<ICrossReferenceBean<?>>> referencesByType = new HashMap<>();
		for(MaintainableBean maint : mergedSet.getAllMaintainables()) {
			for(ICrossReferenceBean<?> xsRef : crossReferenceRetrieverEngine.getCrossReferences(brm, maint)) {
				SDMX_STRUCTURE_TYPE targetStructure = xsRef.getTargetReference();
				if(!targetStructure.isMaintainable()) {
					Set<ICrossReferenceBean<?>> references = referencesByType.get(targetStructure);
					if(references == null) {
						references = new HashSet<>();
						referencesByType.put(targetStructure, references);
					}
					references.add(xsRef);
				}
			}
		}

		//1. Find out all the partial lists based on the contents of everything in the response
		//   The maps are maintainable URN to a set of Item Ids to keep
		//i.e if an Agency is referenced by a reference, it should be used in the filter
		//    if a DSD is part of the query response or the reference, it should be used to filter Concepts
		Map<String, Set<String>> organisationUnitsToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT));
		Map<String, Set<String>> codesToFilter = getCodesToFilter(mergedSet, referencesByType.get(SDMX_STRUCTURE_TYPE.CODE));
		Map<String, Set<String>> conceptsToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.CONCEPT));
		Map<String, Set<String>> categoriesToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.CATEGORY));
		Map<String, Set<String>> reportingTaxonomiesToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.REPORTING_CATEGORY));

		
		createPartialItemSchemes(referencedStructures, referencedStructures.getOrganisationUnitSchemes(), organisationUnitsToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getCategorySchemes(), categoriesToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getCodelists(), codesToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getConceptSchemes(), conceptsToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getReportingTaxonomys(), reportingTaxonomiesToFilter);
		
		
		//Remove any referenced structure that is no longer has a cross reference against it - for example if a concept referenced a codelist, but the concept was removed
		//due to a partial list creation, then the codelist should also be removed

		Set<ICrossReferenceBean<?>> remainingReferences = getReferences(referencedStructures, brm);
		remainingReferences.addAll(getReferences(queryResponse, brm));
		
		Set<String> allMaintUrns = allReferences.stream().map(e -> e.getReference().getMaintainableURN().getURN()).collect(Collectors.toSet());
		Set<String> remainingMaintUrns = remainingReferences.stream().map(e -> e.getReference().getMaintainableURN().getURN()).collect(Collectors.toSet());
		allMaintUrns.removeAll(remainingMaintUrns);
		
		Set<String> removedMaintainableUrns = allMaintUrns;
		
		//Remove items that were reference and are no longer referenced
		if(removedMaintainableUrns.size() > 0) {
			for(MaintainableBean maint : referencedStructures.getAllMaintainables(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME)) {
				if(removedMaintainableUrns.contains(maint.getUrn())) {
					referencedStructures.removeMaintainable(maint);
					removedMaintainableUrns.remove(maint.getUrn());
					if(removedMaintainableUrns.size() == 0) {
						break;
					}
				}
			}
		}
		
		mergedSet = new SdmxBeansImpl(queryResponse, referencedStructures);  //create an updated merged set and repreocess lower level construts
		Map<String, Set<String>> agenciesToFilter = getAgenciesToFilter(mergedSet);
		Map<String, Set<String>> dataConsumersToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.DATA_CONSUMER));
		Map<String, Set<String>> dataProvidersToFilter = referencesToFilterMap(referencesByType.get(SDMX_STRUCTURE_TYPE.DATA_PROVIDER));
		createPartialItemSchemes(referencedStructures, referencedStructures.getAgenciesSchemes(), agenciesToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getDataConsumerSchemes(), dataConsumersToFilter);
		createPartialItemSchemes(referencedStructures, referencedStructures.getDataProviderSchemes(), dataProvidersToFilter);
	}

	/**
	 * Converts a set of cross references to a map of Maintainable URN to Item Id
	 * @param references
	 * @return
	 */
	private Map<String, Set<String>> referencesToFilterMap(Set<ICrossReferenceBean<?>> references) {
		Map<String, Set<String>> conceptsToFilter = new HashMap<>();
		if(references != null) {
			for(ICrossReferenceBean<?> xsRef : references) {
				String conceptSchemeUrn = xsRef.getReference().getMaintainableURN().getURN();
				String concept = xsRef.getReference().getFullIdentifiableId();

				Set<String> set = conceptsToFilter.get(conceptSchemeUrn);
				if (set == null) {
					set = new HashSet<>();
					conceptsToFilter.put(conceptSchemeUrn, set);
				}
				set.add(concept);
			}
		}
		return conceptsToFilter;
	}

	private Map<String, Set<String>> getCodesToFilter(SdmxBeans beans, Set<ICrossReferenceBean<?>> references) {
		
		//Handles Hierarchical Codelists, Categorisations, Codelist Maps
		Map<String, Set<String>> codesToFilter = referencesToFilterMap(references);
		
		//The remainder of this method handles Constraints
		
		Map<String, String> dsdRef = new HashMap<>();  //a map of provision/dataflow URN to Data Structure URN
		Map<String, Set<ContentConstraintBean>> constraintsForStructure = new HashMap<>();
		for(ContentConstraintBean constraint : beans.getContentConstraintBeans()) {
			if(constraint.getConstraintAttachment() == null) {
				continue;
			}
			//TODO Needs to turn into an absolute reference
			for(ICrossReferenceBean<?> xsRef : constraint.getConstraintAttachment().getStructureReference()) {
				String urn = xsRef.getTargetUrn();
				Set<ContentConstraintBean> constraintsForURN = constraintsForStructure.get(urn);
				if(constraintsForURN == null) {
					constraintsForURN = new HashSet<>();
					constraintsForStructure.put(urn, constraintsForURN);
				}
				constraintsForURN.add(constraint);
			}
		}

		for(DataflowBean currentFlow : beans.getDataflows()) {
			dsdRef.put(currentFlow.getUrn(), currentFlow.getDataStructureRef().getTargetUrn());
		}
		Map<String, Set<String>> providerToProvion = new HashMap<>();  //a map of dsd URN to structures which use it
		for(ProvisionAgreementBean currentProv : beans.getProvisionAgreements()) {
			String dsdUrn = dsdRef.get(currentProv.getStructureUseage().getTargetUrn());
			if(dsdUrn != null) {
				dsdRef.put(currentProv.getUrn(), dsdUrn);
				String providerUrn = currentProv.getDataproviderRef().getTargetUrn();
				Set<String> provs = providerToProvion.get(providerUrn);
				if(provs == null) {
					provs = new HashSet<String>();
					providerToProvion.put(providerUrn, provs);
				}
				provs.add(currentProv.getUrn());
			}
		}
		Map<String, Set<String>> dsdToStr = new HashMap<>();  //a map of dsd URN to structures which use it
		for(DataStructureBean currentDsd : beans.getDataStructures()) {
			dsdRef.put(currentDsd.getUrn(), currentDsd.getUrn());
		}
		for(String targetStructure : dsdRef.keySet()) {
			String dsdUrn = dsdRef.get(targetStructure);
			Set<String> targetStructures = dsdToStr.get(dsdUrn);
			if(targetStructures == null) {
				targetStructures = new HashSet<>();
				dsdToStr.put(dsdUrn, targetStructures);
			}
			targetStructures.add(targetStructure);
		}
		//Add Data Providers into the mix
		for(DataProviderSchemeBean dps : beans.getDataProviderSchemes()) {
			for(DataProviderBean provider : dps.getItems()) {
				Set<String> provisions = providerToProvion.get(provider.getUrn());
				if(provisions != null) {
					for(String provisionUrn : provisions) {
						String dsdUrn = dsdRef.get(provisionUrn);
						Set<String> targetStructures = dsdToStr.get(dsdUrn);
						if(targetStructures == null) {
							targetStructures = new HashSet<>();
							dsdToStr.put(dsdUrn, targetStructures);
						}
						targetStructures.add(provider.getUrn());
					}
				}
			}
		}
		for(String dsdUrn : dsdToStr.keySet()) {
			Set<ContentConstraintBean> constraintsForDSD = new HashSet<>();
			for(String dsdUsage : dsdToStr.get(dsdUrn)) {
				if(constraintsForStructure.containsKey(dsdUsage)) {
					constraintsForDSD.addAll(constraintsForStructure.get(dsdUsage));
				}
			}
			DataStructureSuperBean dsdSuperBean = superBeanRetrievalManager.getDataStructureSuperBean(URN.builder(dsdUrn).buildSingle(DataStructureBean.class));
			if(dsdSuperBean != null) {
				List<String> componentIds = new ArrayList<>();
				Map<String, Set<String>> itemsToFilter = new HashMap<>();
				for(ComponentSuperBean<?> compSb : dsdSuperBean.getComponents()) {
					EnumeratedListBean<?> enumeration = compSb.getCodelist(true);
					if(enumeration != null) {
						componentIds.add(compSb.getId());
					}
				}
				//Create filtered set of valid values per component (union of sets)
				for(ContentConstraintBean currentConstraint : constraintsForDSD) {
					for(ContentConstraintModel model : ContentConstraintModelImpl.build(currentConstraint, dsdSuperBean, false)) {
						for(String compId : componentIds) {
							Set<String> validValues = model.getValidValues(compId);
							if(validValues != null) {
								if(!itemsToFilter.containsKey(compId)) {
									itemsToFilter.put(compId, new HashSet<>(validValues));
								} else {
									itemsToFilter.get(compId).addAll(validValues);
								}
							}
							Set<String> excludedValues = model.getExcludedValues(compId);
							if(excludedValues != null) {
								if(!itemsToFilter.containsKey(compId)) {
									itemsToFilter.put(compId, new HashSet<>(excludedValues));
								} else {
									itemsToFilter.get(compId).addAll(excludedValues);
								}
							}
						}
					}
				}
				//Copy the Component Values into the valid values for the codelist (union of sets)
				for(String compId : itemsToFilter.keySet()) {
					EnumeratedListBean<?> enumeration = dsdSuperBean.getComponentById(compId).getCodelist(true);
					String enumUrn = enumeration.getUrn();
					if(codesToFilter.containsKey(enumUrn)) {
						codesToFilter.get(enumUrn).addAll(itemsToFilter.get(compId));
					} else {
						codesToFilter.put(enumUrn, itemsToFilter.get(compId));
					}
				}
			}
		}
		return codesToFilter;
	}
	
	private Map<String, Set<String>> getAgenciesToFilter(SdmxBeans beans) {
		// Create a List of all Agency IDs
		Set<String> agenciesList = new HashSet<>();
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			agenciesList.add(maint.getAgencyId());
		}

		// Convert the List of agencies to a Map - AgencyScheme to Set Agency IDs
		Map<String, Set<String>> agenciesToFilter = new HashMap<>();
		String agencyPrefix = SDMX_STRUCTURE_TYPE.AGENCY_SCHEME.getUrnPrefix();
		
		for (String anAgency : agenciesList) {
			String urn = agencyPrefix;
			String agencyId;
			if (anAgency.contains(".")) {
				int lastDot = anAgency.lastIndexOf(".");
				String schemeAgency = anAgency.substring(0, lastDot);
				urn += schemeAgency+":AGENCIES(1.0)"; //anAgency.substring(0, lastDot);
				agencyId = anAgency.substring(lastDot+1);
			} else {
				urn += "SDMX:AGENCIES(1.0)";
				agencyId = anAgency;
			}
			Set<String> set = agenciesToFilter.get(urn);
			if (set == null) {
				set = new HashSet<>();
				agenciesToFilter.put(urn, set);
			}
			set.add(agencyId);
		}
		return agenciesToFilter;
	}


	///////////////////////////////////////////////////////////////
	/////////// MAKE PARTIAL LISTS ////////////////////////////////
	///////////////////////////////////////////////////////////////
	private void createPartialItemSchemes(SdmxBeans referencedBeans, Set<? extends ItemSchemeBean> itemSchemes, Map<String, Set<String>> itemsToKeep) {
		if(itemsToKeep.size() == 0) {
			return;
		}
		// Make agencies partial
		for (ItemSchemeBean itemScheme : itemSchemes) {
			Set<String> items = itemsToKeep.get(itemScheme.getUrn());
			if (items != null) {
				referencedBeans.addIdentifiable(itemScheme.filterItems(items, true, ITEM_FILTER_ACTION.KEEP_PARENT));
				if(LOG.isDebugEnabled()) {
					LOG.debug("Partial AgencyScheme created now has '"+itemScheme.getItems().size()+"' agencies");
				}
			}
		}
	}

}
