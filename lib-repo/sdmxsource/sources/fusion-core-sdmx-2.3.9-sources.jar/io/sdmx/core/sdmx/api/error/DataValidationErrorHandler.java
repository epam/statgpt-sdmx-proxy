package io.sdmx.core.sdmx.api.error;

import io.sdmx.api.sdmx.exception.ErrorLimitException;

/**
 * Can be used to handle data specific errors reported by the DataValidationManager
 */
public interface DataValidationErrorHandler {
	
	/**
	 * Handles an Error resulting from a DataValidationEngine or reading a dataset
	 * 
	 * @throws ErrorLimitException - if a limit is hit
	 */
	void handleError(DataError err) throws ErrorLimitException;
	
}
