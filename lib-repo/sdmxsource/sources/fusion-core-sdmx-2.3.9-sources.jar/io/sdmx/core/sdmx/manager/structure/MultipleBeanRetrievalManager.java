package io.sdmx.core.sdmx.manager.structure;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;


/**
 * Checks the first bean retrieval manager, if not exist, checks the second and so on
 */
public class MultipleBeanRetrievalManager implements SdmxBeanRetrievalManager {
	private List<SdmxBeanRetrievalManager> retrievalManagers = new ArrayList<>();
	
	
	public MultipleBeanRetrievalManager(ISdmxBeanRestRetrievalManager... managers) {
		for(ISdmxBeanRestRetrievalManager manager : managers) {
			if(manager != null) {
				this.retrievalManagers.add(new SdmxRestToBeanRetrievalManager(manager));
			}
		}
	}
	
	public MultipleBeanRetrievalManager(SdmxBeanRetrievalManager... managers) {
		for(SdmxBeanRetrievalManager manager : managers) {
			if(manager != null) {
				this.retrievalManagers.add(manager);
			}
		}
	}
	
	@Override
    public <T extends IdentifiableBean> T getBean(IURNSingle<T> sRef) {
	    T returnBean = null;
		for(SdmxBeanRetrievalManager currentManager : retrievalManagers) {
			T bean = currentManager.getBean(sRef);
			if(bean != null) {
			    if(sRef.getReferenceType() == REFERENCE_TYPE.ABSOLUTE) {
			        return bean;
			    } else if(returnBean == null || bean.getMaintainableParent().getVersion().isLater(returnBean.getMaintainableParent().getVersion())) {
			        //if the URN is a semantic reference, then it will always be the later version that wins (there is no way to reference an
			        //earlier version in the URN syntax)
			        returnBean = bean;
			    }
			}
		}
		return returnBean;
	}
	
	

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		Set<T> returnSet = new HashSet<>();
		for(SdmxBeanRetrievalManager currentManager : retrievalManagers) {
			returnSet.addAll(currentManager.getMaintainableBeans(urn));
			
			//If the query was for a specific bean, and it was already found, then return it
			if(returnSet.size() > 0 && !urn.isWildcard()) {
				return returnSet;
			}
		}
		return returnSet;
	}
}