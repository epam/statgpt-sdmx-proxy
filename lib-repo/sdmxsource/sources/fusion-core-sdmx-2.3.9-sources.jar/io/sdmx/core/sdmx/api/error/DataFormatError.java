package io.sdmx.core.sdmx.api.error;

import io.sdmx.api.error.FusionError;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;

/**
 * This error is reported by data readers and represents an error message specific to the data format being read, for example:
 * Illegal XML Header Element TestX
 */
public interface DataFormatError {

	/**
	 * Returns the error message
	 * @return
	 */
	String getMessage();
	
	/**
	 * Returns the FusionError object for this error. May be null
	 * @return
	 */
	FusionError getFusionError();


	/**
	 * Returns the error type for this error
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	Enum getErrorType();

	/**
	 * @return at what position (Dataset, Series, etc.) that the error occurred.
	 */
	ERROR_POSITION getErrorPosition();
}
