
package io.sdmx.core.sdmx.api.manager.structure;

import java.net.URL;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;


/**
 * Gives the ability to retrieve the structure, or the service URL for the application, allowing beans to be built as a stub
 *
 */
public interface ServiceRetrievalManager {

	/**
	 * Returns the URL to obtain structures from, this will be either a service URL
	 * @return
	 */
	ArtefactURL getStructureOrServiceURL(MaintainableBean maint);

	/**
	 * Creates a stub bean from the given maintainable artefact. A stub contains only identifier information (id, agency, version) and a name
	 * @param maint
	 * @param completeStub provides description, annotations and isFinal information, in addition to the already existing identification information and name.
	 * @return
	 */
	MaintainableBean createStub(MaintainableBean maint, boolean completeStub);

	/**
     * Create a stub, add the additional query parameters to the URL
     * @param maint
     * @param completeStub
     * @param queryParameters to include in the URL to retrieve the structure
     * @return
     */
    MaintainableBean createStub(MaintainableBean maint, boolean completeStub, Map<String, String> queryParameters);

	/**
	 * The artefact URL contains the url to resolve the artefact, and a boolean defining if it is a service URL or a structure URL
	 *
	 */
	public class ArtefactURL {
		private URL url;
		private boolean serviceUrl;

		public ArtefactURL(URL url, boolean serviceUrl) {
			super();
			this.url = url;
			this.serviceUrl = serviceUrl;
		}

		public URL getUrl() {
			return url;
		}

		public boolean isSserviceUrl() {
			return serviceUrl;
		}
	}
}
