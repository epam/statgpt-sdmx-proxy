package io.sdmx.core.sdmx.test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import io.sdmx.api.process.IProcessArgResponse;
import io.sdmx.api.process.IProcessWithResponse;
import io.sdmx.core.sdmx.engine.data.DataWriterAssertionProxy;
import io.sdmx.core.sdmx.engine.data.InMemoryDataWriterEngine;
import io.sdmx.core.sdmx.engine.data.DatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.engine.data.RollupDataWriterEngine;
import io.sdmx.core.sdmx.model.data.InMemoryDataset;
import io.sdmx.core.sdmx.model.data.InMemoryDatasetContainer;
import io.sdmx.utils.sdmx.data.SimpleDataWriter;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.util.model.TestDSDUtil;

/**
 * To used by implementations of the DataWriterEngine and DataReadEngine to ensure the implementation
 * of the interface is correct
 */
public class DataWriterAsserter {
	
	private static interface DataWriterTest {
		
		void writeData(SimpleDataWriter dwe);
		
	}
	
	/**
	 * Writes time series data to the data writer, the writer will proxy an in memory data writer, which is then used to check the written output
	 * 
	 * @param dwe
	 * @param expected each array is a row which has a series key, series attributes, obs dimenison, obs value, and obs attributes - in that order
	 * new String[] {"A:UK:IND1", "Title 1", "COL1", "2008", "1.1", "N", "F"}
	 * 
	 * @return
	 */
	public static void writeTimeSeriesData(IProcessArgResponse<ISeriesObsDataWriterEngine, ISeriesObsDataWriterEngine> proxyGetter, String[]...expectedResults) {
		InMemoryDataWriterEngine proxy = new InMemoryDataWriterEngine();
		ISeriesObsDataWriterEngine dwe = proxyGetter.runProcess(proxy);
		
		writeTimeSeriesData(dwe, null);
		InMemoryDatasetContainer actualDs = proxy.getDatasetContainer();
		List<String[]> obs = new ArrayList<>(expectedResults.length);
		for(String[] result : expectedResults) {
			obs.add(result);
		}
		InMemoryDataset writtenDataset = actualDs.getDatasets().get(0);
		InMemoryDataset expectedDs = new InMemoryDataset(writtenDataset.getHeader(), writtenDataset.getStructures(), DimensionBean.TIME_DIMENSION_FIXED_ID, obs);
		
		DataReaderEngine actualReader = new DatasetStoreDataReaderEngine(actualDs);
		DataReaderEngine expectedReader = new DatasetStoreDataReaderEngine(new InMemoryDatasetContainer(actualDs.getHeader(), expectedDs));
		DataReaderEqualityUtil.assertEquals(actualReader, expectedReader);
	}
	
	public static InMemoryDatasetContainer writeTimeSeriesData(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeObs("2007", "1.0", "A", "F");
			writer.writeObs("2008", "1.1", "N", "F");
			writer.writeObs("2009", "1.2", "A", "C");
			writer.writeObs("2012", "1.6", "A", "C");
			writer.writeSeries("A:DE:IND1");  //No Obs
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeObs("2007", null, "M");
			writer.writeObs("2008", "11.1", "E", "P");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
			writer.writeObs("2009", "111.1");
			writer.writeObs("2010", "111.2", null, "C");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	public static InMemoryDatasetContainer writeDatasetAttributesOnly(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeDatasetAttributes("By Hand");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	
	public static InMemoryDatasetContainer writeGroupAttributesOnly(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeGroup("Sibling", ":UK:IND1", "GA1");
			writer.writeGroup("Sibling", ":UK:IND2", "GA1");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	public static InMemoryDatasetContainer writeDatasetAttirbutes(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeDatasetAttributes("By Hand");
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeSeries("A:DE:IND1");  //No Obs
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	public static InMemoryDatasetContainer writeTimeSeriesDataSeriesOnly(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeSeries("A:DE:IND1");  //No Obs
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	
	/**
	 * Writes time series data to the data writer, the writer will proxy an in memory data writer, which is then used to check the written output
	 * 
	 * @param dwe
	 * @param expected each array is a row which has a series key, series attributes, obs dimenison, obs value, and obs attributes - in that order
	 * new String[] {"A:UK:IND1", "Title 1", "COL1", "2008", "1.1", "N", "F"}
	 * 
	 * @return
	 */
	public static void writeTimeSeriesDataWithGroups(IProcessArgResponse<ISeriesObsDataWriterEngine, ISeriesObsDataWriterEngine> proxyGetter, String[]...expectedResults) {
		InMemoryDataWriterEngine proxy = new InMemoryDataWriterEngine();
		ISeriesObsDataWriterEngine dwe = proxyGetter.runProcess(proxy);
		
		writeTimeSeriesDataWithGroups(dwe, null);
		InMemoryDatasetContainer actualDs = proxy.getDatasetContainer();
		List<String[]> obs = new ArrayList<>(expectedResults.length);
		for(String[] result : expectedResults) {
			obs.add(result);
		}
		InMemoryDataset writtenDataset = actualDs.getDatasets().get(0);
		InMemoryDataset expectedDs = new InMemoryDataset(writtenDataset.getHeader(), writtenDataset.getStructures(), DimensionBean.TIME_DIMENSION_FIXED_ID, obs);
		
		DataReaderEngine actualReader = new DatasetStoreDataReaderEngine(actualDs);
		DataReaderEngine expectedReader = new DatasetStoreDataReaderEngine(new InMemoryDatasetContainer(actualDs.getHeader(), expectedDs));
		DataReaderEqualityUtil.assertEquals(actualReader, expectedReader);
	}
	
	/**
	 * 
	 * @param dwe
	 * @param readerChecker
	 * @return
	 */
	public static InMemoryDatasetContainer writeTimeSeriesDataWithGroups(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		return runTest((writer)-> {
			writer.writeGroup("Sibling", ":UK:IND1", "GA1");
			writer.writeGroup("Sibling", ":UK:IND2", "GA2");
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeObs("2007", "1.0", "A", "F");
			writer.writeObs("2008", "1.1", "N", "F");
			writer.writeObs("2009", "1.2", "A", "C");
			writer.writeObs("2012", "1.6", "A", "C");
			writer.writeSeries("A:DE:IND1");  //No Obs
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeObs("2007", null, "M");
			writer.writeObs("2008", "11.1", "E", "P");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
			writer.writeObs("2009", "111.1");
			writer.writeObs("2010", "111.2", null, "C");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, true);
	}
	
	/**
	 * @return DSD used in writeTimeSeriesData tests
	 */
	public static DataStructureBean getTimeSeriesDataDSD() {
		return createTestDSD(true, true);
	}
	
	/**
	 * Writes time series data with no primary measure, instead it has a measure for BIRTHS, DEATHS, MARRIAGES
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeTimeSeriesMultiMeasureData(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeObs("2007", "1.0", "2.0", "3.0", "A", "F");
			writer.writeObs("2008", "1.1", "2.1", "3.1", "A", "F");
			writer.writeObs("2009", "1.2", "2.2", "3.2", "A", "C");
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeObs("2007", null, null, null, "M");
			writer.writeObs("2008", "11.1", "22.1", "33.1", "E", "P");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
			writer.writeObs("2009", "111.1", "222.1", "333.1");
			writer.writeObs("2010", "111.2", null, "333.1", null, "C");
		}, readerChecker, dwe, DimensionBean.TIME_DIMENSION_FIXED_ID, true, false, "BIRTHS", "DEATHS", "MARRIAGES");
	}
	
	/**
	 * Data with multiple measure values, no dimension at observation
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeFlatMultiMeasureData(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeObs(null, "1.0", "2.0", "3.0", "A", "F");
			writer.writeObs(null, "1.1", "2.1", "3.1", "A", "F");
			writer.writeObs(null, "1.2", "2.2", "3.2", "A", "C");
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeObs(null, null, null, "M");
			writer.writeObs(null, "11.1", "22.1", "33.1", "E", "P");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
			writer.writeObs(null, "111.1", "222.1", "333.1");
			writer.writeObs(null, "111.2", null, "333.1", null, "C");
		}, readerChecker, dwe, null, false, false, "BIRTHS", "DEATHS", "MARRIAGES");
	}
	
	/**
	 * Data with multiple values for a series attribute (TIME_FORMAT) and obs attribute (OBS STATUS)
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeMultiValueAttributes(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "A;B");
			writer.writeObs(null, "1.0", "2.0", "3.0", "A;N;O", "F");
			writer.writeObs(null, "1.1", "2.1", "3.1", "A", "F");
		}, readerChecker, dwe, null, false, false, "BIRTHS", "DEATHS", "MARRIAGES");
	}

	/**
	 * Data with multilingual values for a series attribute (TITLE) and obs attribute (OBS STATUS)
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeMultilingualValueAttributes(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "en:Some English Text;fr:Quelques textes en anglais", "A;B");
			writer.writeObs(null, "1.0", "2.0", "3.0", "en:A;fr:N;de:O", "F");
			writer.writeObs(null, "1.1", "2.1", "3.1", "A", "F");
		}, readerChecker, dwe, null, false, false, "BIRTHS", "DEATHS", "MARRIAGES");
	}
	
	

	/**
	 * Data with one primary measure values, no dimension at observation
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeFlatPrimaryMeasureData(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A:UK:IND1", "Title 1", "COL1");
			writer.writeObs(null, "1.0", "A", "F");
			writer.writeObs(null, "1.1", "A", "F");
			writer.writeObs(null, "1.2", "A", "C");
			writer.writeSeries("A:FR:IND1", "Title 2", "COL1");
			writer.writeObs(null, null, null, "M");
			writer.writeObs(null, "11.1", "E", "P");
			writer.writeSeries("A:UK:IND2", "Title 3", "COL1");
			writer.writeObs(null, "111.1");
			writer.writeObs(null, "111.2", null, "C");
		}, readerChecker, dwe, null, false, true);
	}
	
	/**
	 * Data with one primary measure values, no time dimension, REF_AREA at the observation level
	 * @param dwe
	 * @param writeDatasetAttributes
	 * @param writeSeriesAttributes
	 * @param writeObsAttributes
	 */
	public static void writeCrossSectionalPrimaryMeasureData(ISeriesObsDataWriterEngine dwe, IProcessWithResponse<DataReaderEngine> readerChecker) {
		runTest((writer)-> {
			writer.writeSeries("A::IND1");
			writer.writeObs("UK", "1.0", "Title 1", "COL1", "A", "F");
			writer.writeObs("FR", "1.1", "A", "F");
			writer.writeObs("DE", "1.2", "A", "C");
			writer.writeSeries("A::IND2");
			writer.writeObs("UK", "1.0", "Title 1", null, "A", null);
			writer.writeObs("FR", "1.1", "Title 1", null, null, "F");
			writer.writeObs("DE", "1.2", "Title 1", null, "A", "C");
		}, readerChecker, dwe, "REF_AREA", false, true);
	}
	
	private static InMemoryDatasetContainer runTest(DataWriterTest p, IProcessWithResponse<DataReaderEngine> readerChecker, ISeriesObsDataWriterEngine dwe, String dimAtObs, boolean time, boolean pm, String...measures) {
		DataStructureBean dsd = createTestDSD(time, pm, measures);
		DataWriterAssertionProxy dewProxy = new DataWriterAssertionProxy(dwe);
		SimpleDataWriter writer = new SimpleDataWriter(new RollupDataWriterEngine(dewProxy), dimAtObs);
		DatasetStructureReferenceBean dsStructure = new DatasetStructureReferenceBeanImpl(dsd.getId(), dsd.getURN(), null, null, dimAtObs);
		DatasetHeaderBean header = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.APPEND, dsStructure);
		writer.startDataset(null, null, dsd, header);
		p.writeData(writer);
		writer.close();
		if(readerChecker != null) {
			DataReaderEngine dre = readerChecker.runProcess();
			if(dre != null) {
				dewProxy.assertReader(dre);
			}
		}
		return dewProxy.getDatasetContainer();
	}
	
	/**
	 * @param time if true will include a TIME_PERIOD Dimension
	 * @param pm if true will include an OBS_VALUE Primary Measure
	 * @param obsAttributes
	 * @return
	 */
	public static DataStructureBean createTestDSD(boolean time, boolean pm, String...measures) {
		DataStructureBean dsd = TestDSDUtil.generateDSD(time, pm, "FREQ", "REF_AREA", "INDICATOR");
		DataStructureMutableBean dsdMutable = dsd.getMutableInstance();
		TestDSDUtil.createAttribute(dsdMutable, "METHOD", ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
		TestDSDUtil.createAttribute(dsdMutable, "TITLE", ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
		TestDSDUtil.createAttribute(dsdMutable, "TIME_FORMAT", ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP).setMaxOccurs(3);
		if(measures != null || pm) {
			TestDSDUtil.createAttribute(dsdMutable, "OBS_STATUS", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION).setMaxOccurs(3);
			TestDSDUtil.createAttribute(dsdMutable, "OBS_CONF", ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
		}
		TestDSDUtil.createAttribute(dsdMutable, "SIBLING_ATTR", ATTRIBUTE_ATTACHMENT_LEVEL.GROUP).setAttachmentGroup("Sibling");
		TestDSDUtil.createGroup(dsdMutable, "Sibling", "REF_AREA", "INDICATOR");
		
		if(measures != null) {
			for(String measure : measures) {
				TestDSDUtil.createMeasure(dsdMutable, measure);
			}
		}
		return dsdMutable.getImmutableInstance();
	}
}
