package io.sdmx.core.sdmx.api.engine.structure;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.io.IDeferredObjectReaderManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;

/**
 * Converts {@link IDeferredBeanDefinition} into a {@link IMaintainableBeanDeferred}
 * @param <T>
 * @see IDeferredObjectReaderManager
 */
public interface IDeferredStructureReaderEngine<T extends MaintainableBean> {

    /**
     * @param deferred
     * @return the deferred instance of the {@link MaintainableBean}
     */
    IMaintainableBeanDeferred<T> read(IDeferredBeanDefinition deferred, IDeferredLoader<MaintainableBean> loader);
    
    /**
     * @return the type of bean this engine can read
     */
    IMaintainableStructureType<T> getSupportedType();
    
}
