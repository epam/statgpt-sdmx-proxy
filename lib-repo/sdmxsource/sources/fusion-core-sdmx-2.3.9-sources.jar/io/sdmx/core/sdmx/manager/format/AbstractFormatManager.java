package io.sdmx.core.sdmx.manager.format;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IInformationFormatManager;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.format.FormatManager;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.format.VNDHeader;
import io.sdmx.utils.core.object.ObjectUtil;

public class AbstractFormatManager<T extends InformationFormat> implements FormatManager<T> {
	private IInformationFormatManager informationFormatManager;
	private Class<T> classType;
	private T defaultFormat;
	protected String vndPrefix = "application/vnd.";
	private Set<String> supportOnlyFormats;
	private Map<String, FormatDetails> supportedVndHeaders;
	
	public AbstractFormatManager(IInformationFormatManager informationFormatManager, Class<T> classType) {
		this.informationFormatManager = informationFormatManager;
		this.classType = classType;
		SingletonStore.registerInstance(this);
	}
	
	protected void setDefaultFormat(T defaultFormat) {
		this.defaultFormat = defaultFormat;
		if(defaultFormat != null) {
			this.informationFormatManager.addDefaultFormat(classType, defaultFormat);
		}
	}
	
	protected IInformationFormatManager getInformationFormatManager() {
		return informationFormatManager;
	}

	/**
	 * @param <T>
	 * @param request
	 * @param classType
	 * @return the format being requested of the given type
	 */
	@Override
	public T getFormat(Request request) {
		return getFormat(request, true);
	}
	
	/**
	 * @param request the Request to determine the format from
	 * @param includeDefaultFormats whether any of the Default Formats that are have been set in this class should be used when determining the output format.
	 * @return the format being requested of the given type. May return null.
	 */
	@Override
	public T getFormat(Request request, boolean includeDefaultFormats) {
		T format = informationFormatManager.getFormat(request, classType, includeDefaultFormats);
		checkSupported(format);
		return format;
	}
	
	/**
	 * @param vndHeader
	 * @return the format being requested or null if the factory is unable to determine the format
	 */
	public T getFormat(Request request, IVNDHeader vndHeader)  {
		T format = informationFormatManager.getFormat(request, vndHeader, classType);
		checkSupported(format);
		return format;
	}
	
	@Override
	public T getDefaultFormat() {
		return defaultFormat;
	}


	@Override
	public T getFormat(String vndHeader) {
		if(vndPrefix != null && !vndHeader.startsWith(vndPrefix)) {
			return null;
		}
		return getFormat(new VNDHeader(vndHeader));
	}


	@Override
	public T getFormat(IVNDHeader vndHeader) {
		T format = informationFormatManager.getFormat(null, vndHeader, classType);
		checkSupported(format);
		return format;
	}
	

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		if(supportedVndHeaders == null) {
			Map<String, FormatDetails> formats = this.getInformationFormatManager().getSupportedFormats(null);
			Map<String, FormatDetails> vndMap = Collections.emptyMap();
			if(formats != null) {
				vndMap = new HashMap<>(formats.size());
				for(String vndHeader : formats.keySet()) {
					if(this.supportOnlyFormats != null && !this.supportOnlyFormats.contains(vndHeader)) {
						continue;
					}
					vndMap.put(vndHeader, formats.get(vndHeader));
				}
			}
			supportedVndHeaders = Collections.unmodifiableMap(vndMap);
		}
		return supportedVndHeaders;
	}
	
	


	@Override
	public void setSupportOnlyFormats(Set<String> supportOnlyFormats) {
		this.supportOnlyFormats = supportOnlyFormats;
		if(supportOnlyFormats != null && supportOnlyFormats.size() == 0) {
			supportOnlyFormats = null;
		}
	}
	

	protected void checkSupported(T format) {
		if(format == null) {
			return;
		}
		if(format.getFormatDetails().getAcceptHeaders() != null && format.getFormatDetails().getAcceptHeaders().length > 0) {
			if(ObjectUtil.validCollection(supportOnlyFormats)) {
				boolean supported = false;
				for(String header : format.getFormatDetails().getAcceptHeaders()) {
					if(header != null) {
						if(supportOnlyFormats.contains(header)) {
							supported = true;
							break;
						} else if(supportOnlyFormats.contains(header.split(";")[0])) {
							supported = true;
							break;
						}
					}
				}
				if(!supported) {
					throw new SdmxNotAcceptableException("Format is not supported:" + CollectionUtil.join(", ", "", format.getFormatDetails().getAcceptHeaders()));
				}
			}
		}
	}

	
}
