package io.sdmx.core.sdmx.model.type;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

/**
 * Serialization for List<T> using BasicDataType<T>.
 */
public class DT_Set<T> extends BasicDataType<Set<T>> {
  private final BasicDataType<T> elemDT;

  public DT_Set(BasicDataType<T> elemDT) {
    this.elemDT = elemDT;
  }

  @Override
  public int getMemory(Set<T> list) {
    int size = 2; // average varInt size ?

    if (list != null)
      for (T t: list)
        size += elemDT.getMemory(t);

    return size;
  }

  // encode size to avoid having a long varint when list is null
  private void writeSize(WriteBuffer buf, Set<T> list) {
    buf.putVarInt(list == null ? 0 : list.size() + 1);
  }

  // decode size according to encoding performed at write time
  private Integer readSize(ByteBuffer buf) {
    int x = DataUtils.readVarInt(buf);

    return (x == 0) ? null : x - 1;
  }

  @Override
  public void write(WriteBuffer buf, Set<T> list) {
    writeSize(buf, list);

    if (list != null)
      for (T t: list)
        elemDT.write(buf, t);
  }

  @Override
  public Set<T> read(ByteBuffer buf) {
    Integer size = readSize(buf);
    List<T> list;

    if (size == null)
      return null;
    else if (size == 0)
      list = Collections.emptyList();
    else {
      list = new ArrayList<T>(size);

      for (int i = 0; i < size; i++) {
        @SuppressWarnings("unchecked")
        T t = elemDT.read(buf);

        list.add(t);
      }
    }
    return new HashSet<>(list);
  }

  @Override
  public Set<T>[] createStorage(int size) {
    @SuppressWarnings({"unchecked", "rawtypes"})
    Set<T>[] array = new Set[size];

    return array;
  }
}
