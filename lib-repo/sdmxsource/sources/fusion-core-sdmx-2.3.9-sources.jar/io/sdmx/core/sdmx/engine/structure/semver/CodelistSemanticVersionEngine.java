package io.sdmx.core.sdmx.engine.structure.semver;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.SEMVER_PART;
import io.sdmx.api.sdmx.engine.ISemanticVersionEngine;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;

public class CodelistSemanticVersionEngine implements ISemanticVersionEngine<CodelistBean>, IFusionSingleton {

    private static CodelistSemanticVersionEngine INSTANCE;

    public static CodelistSemanticVersionEngine registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }

    public static CodelistSemanticVersionEngine getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new CodelistSemanticVersionEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public SEMVER_PART determineMinVersionChange(MaintainableBean from, MaintainableBean to) {
        CodelistBean maintFrom = (CodelistBean) from;
        CodelistBean maintTo = (CodelistBean) to;

        return determineMinVersionChange(maintFrom, maintTo);
    }

    private SEMVER_PART determineMinVersionChange(CodelistBean from, CodelistBean to) {
        Map<String, ICodelistInheritanceRuleBean> fromMap = inheritanceRuleMap(from);
        Map<String, ICodelistInheritanceRuleBean> toMap = inheritanceRuleMap(to);

        SEMVER_PART versionChange = null;
        //The new map has at least everything in the from map
        if(toMap.keySet().containsAll(fromMap.keySet())) {
            //Loop the fromMap as we know the to map has everything
            for(String fromKey : fromMap.keySet()) {
                //Modify a CodelistExtension's prefix   Major   Changing the prefix removes all the codes with the old prefix and adds new codes with the new prefix.
                SEMVER_PART vChange = determineMinVersionChange(fromMap.get(fromKey), toMap.get(fromKey));
                if(vChange == null) {
                    continue;
                }
                if(vChange == SEMVER_PART.MAJOR) {
                    return vChange;
                }
                versionChange = vChange;
            }
        } else {
            //the to map has removed a inheritance rule, or at least changed the Agency or ID of the reference
            return SEMVER_PART.MAJOR;
        }

        /** Adding a meaningful CodelistExtension will add codes to the Codelist resulting in a minor change. **/
        if(!fromMap.keySet().containsAll(toMap.keySet())) {
            //the to map has added an inheritance rule
            return SEMVER_PART.MINOR;
        }

        return versionChange;
    }

    private SEMVER_PART determineMinVersionChange(ICodelistInheritanceRuleBean from, ICodelistInheritanceRuleBean to) {
        if(!ObjectUtil.equivalent(from.getPrefix(), to.getPrefix())) {
            return SEMVER_PART.MAJOR;
        }

        /*
         * If the set of codes extending the Codelist doesn't change then this would be a patch.
         * If the original set of codes is a proper subset of the new set of codes extending the Codelist then this would be a minor change.
         * If codes are removed from the set of codes extending the Codelist then this would be a major change.
         */
        if(!to.getInclusiveInheritenceIds().containsAll(from.getInclusiveInheritenceIds())) {
            //The to set has at least one less code, this is a major change
            return SEMVER_PART.MAJOR;
        }
        if(!to.getInclusiveInheritenceCascades().containsAll(from.getInclusiveInheritenceCascades())) {
            //The to set no longer cascades, which means it could be loosing codes - major change
            return SEMVER_PART.MAJOR;
        }
        if(from.getExclusiveInheritenceIds().size() > to.getExclusiveInheritenceIds().size()) {
            //At least one more code is excluded, resulting in removed codes, major change
            return SEMVER_PART.MAJOR;
        }
        if(from.getExclusiveInheritenceCascades().size() > to.getExclusiveInheritenceCascades().size()) {
            //At least one more code is excluded, resulting in removed codes, major change
            return SEMVER_PART.MAJOR;
        }
        //UK, FR, DE  -> UK, DE
        Set<String> fromExIds = new HashSet<>(from.getExclusiveInheritenceIds());
        Set<String> toExIds = new HashSet<>(to.getExclusiveInheritenceIds());

        if(!fromExIds.containsAll(toExIds)) {
            return SEMVER_PART.MAJOR;  //at least one more code has been excluded
        }

        if(!to.getExclusiveInheritenceIds().containsAll(from.getInclusiveInheritenceIds())) {
            //the exclude sets are the same size, but different content, meaning a new code is removed that was not before, major change
            return SEMVER_PART.MAJOR;
        }

        if(!toExIds.containsAll(fromExIds)) {
            return SEMVER_PART.MINOR;  //at least one more code has been included (by not excluding)
        }
        if(from.getExclusiveInheritenceIds().size() != to.getExclusiveInheritenceIds().size()) {
            //At least one more code is excluded, resulting in removed codes, major change
            return SEMVER_PART.MINOR;
        }
        if(from.getInclusiveInheritenceIds().size() != to.getInclusiveInheritenceIds().size()) {
            //A proper subset, as all codes in the to set exist in the from set, but the to set has more
            return SEMVER_PART.MINOR;
        }
        if(from.getInclusiveInheritenceCascades().size() != to.getInclusiveInheritenceCascades().size()) {
            //At least one more code is included from the cascade
            return SEMVER_PART.MINOR;
        }
        return null;
    }

    private Map<String, ICodelistInheritanceRuleBean> inheritanceRuleMap(CodelistBean cl) {
        return cl.getInheritedCodelists().stream().collect(
                Collectors.toMap(e->e.getCodelistRef().getReference().getAgencyId() +"_"+ e.getCodelistRef().getReference().getMaintainableId(), e->e));
    }

    @Override
    public IMaintainableStructureType<CodelistBean> getSupportedStructure() {
        return StructureTypes.getMaintStructureType(CodelistBean.class);
    }

}
