package io.sdmx.core.sdmx.model.type;

import java.util.HashMap;
import java.util.Collections;
import java.util.Map;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

/**
 * Serialization for Map<K, V>.
 */
public class DT_Map<K, V> extends BasicDataType<Map<K, V>> {
  private final BasicDataType<K> keyDT;
  private final BasicDataType<V> valDT;

  public DT_Map(BasicDataType<K> keyDT, BasicDataType<V> valDT) {
    this.keyDT = keyDT;
    this.valDT = valDT;
  }

  @Override
  public int getMemory(Map<K, V> map) {
    int size = 2; // average varInt size ?

    if (map != null)
      for (Map.Entry<K, V> entry: map.entrySet())
        size += keyDT.getMemory(entry.getKey()) +
                valDT.getMemory(entry.getValue());

    return size;
  }

  // encode size to avoid having a long varint when map is null
  private void writeSize(WriteBuffer buf, Map<K, V> map) {
    buf.putVarInt(map == null ? 0 : map.size() + 1);
  }

  // decode size according to encoding performed at write time
  private Integer readSize(ByteBuffer buf) {
    int x = DataUtils.readVarInt(buf);

    return (x == 0) ? null : x - 1;
  }

  @Override
  public void write(WriteBuffer buf, Map<K, V> map) {
    writeSize(buf, map);

    if (map != null)
      for (Map.Entry<K, V> entry: map.entrySet()) {
        keyDT.write(buf, entry.getKey());
        valDT.write(buf, entry.getValue());
      }
  }

  @Override
  public Map<K, V> read(ByteBuffer buf) {
    Integer size = readSize(buf);
    Map<K, V> map;

    if (size == null)
      map = null;
    else if (size == 0)
      map = Collections.emptyMap();
    else {
      map = new HashMap<K, V>(size);

      for (int i = 0; i < size; i++) {
        K key = keyDT.read(buf);
        V val = valDT.read(buf);

        map.put(key, val);
      }
    }

    return map;
  }

  @Override
  public Map<K, V>[] createStorage(int size) {
    @SuppressWarnings({"unchecked", "rawtypes"})
    Map<K, V>[] map = new Map[size];

    return map;
  }
}
