package io.sdmx.core.sdmx.manager.metadata;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.sdmx.manager.output.IMetadataWriterManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataWriterFactory;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.sdmx.comparator.PriorityFactoryComparator;

public class ReferenceMetadataWriterManager implements IMetadataWriterManager, IFusionSingleton {
	private Set<IMetadataWriterFactory> factories = null;
	private static ReferenceMetadataWriterManager INSTANCE;
	
	public static ReferenceMetadataWriterManager getInstance() {
		if(INSTANCE == null) {
			INSTANCE = SingletonStore.getSingleton(ReferenceMetadataWriterManager.class, false);
			if(INSTANCE == null) {
				INSTANCE = new ReferenceMetadataWriterManager();
				SingletonStore.registerInstance(INSTANCE);
			}
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public void write(MaintainableBean maint, IMetadataFormat format, OutputStream out) throws SdmxNotImplementedException {
		if(maint instanceof IReportedMetadataSetBean) {
			IReportedMetadataSetBean set = (IReportedMetadataSetBean) maint;
			IReferenceMetadataContainer container = new ReferenceMetadataContainer();
			container.addReferenceMetadata(set);
			write(container, format, out);
		} else {
			throw new IllegalArgumentException("Unsupported type: "+maint.getClass().getCanonicalName());
		}
	}

	@Override
	public void write(IReferenceMetadataContainer container, IMetadataFormat format, OutputStream out) throws SdmxSemmanticException, UnrecognisedFormatException {
		for(IMetadataWriterFactory currentFactory : getWriterFactory()) {
			IMetadataWriterEngine engine = currentFactory.getMetadataWriterEngine(format);
			if(engine != null) {
				engine.write(container, out);
				StreamUtil.closeStream(out);
				return;
			}
		}
		throw new SdmxNotAcceptableException("Unsupported output format");
	}

	private Collection<IMetadataWriterFactory> getWriterFactory() throws IllegalArgumentException {
		if(factories != null) {
			return factories;
		}
		synchronized(this) {
			TreeSet<IMetadataWriterFactory> localFactories = new TreeSet<>(PriorityFactoryComparator.INSTANCE);
			Collection<IMetadataWriterFactory> allBeans = FusionBeanStore.getBeans(IMetadataWriterFactory.class);
			for (IMetadataWriterFactory structureWriterFactory : allBeans) {
				localFactories.add(structureWriterFactory);
			}
			this.factories = localFactories;
		}
		return factories;
	}

}
