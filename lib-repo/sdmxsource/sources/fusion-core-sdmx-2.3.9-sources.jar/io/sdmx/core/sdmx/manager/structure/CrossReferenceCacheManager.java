package io.sdmx.core.sdmx.manager.structure;

import java.io.OutputStream;
import java.util.List;
import java.util.Set;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.manager.output.IStructureReferenceWriterManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ICrossReferenceLookupTableRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IMaintainableReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;

public class CrossReferenceCacheManager implements CrossReferencedRetrievalManager,
												   CrossReferencingRetrievalManager,
												   IMaintainableReferenceRetreivalManager,
												   IURNReferenceRetreivalManager,
												   IStructureReferenceWriterManager,
												   Listener<IStructureEvent>,
												   Cache {
	
	private ICrossReferenceLookupTableRetrievalManager crossReferenceLookupTableRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private IURNRetrievalManager urnRetrievalManager;
	
	private LocalCache cache;
	
	
	public CrossReferenceCacheManager(ICrossReferenceLookupTableRetrievalManager crossReferenceLookupTableRetrievalManager,
									  SdmxBeanRetrievalManager beanRetrievalManager,
									  IURNRetrievalManager urnRetrievalManager) {
		this.crossReferenceLookupTableRetrievalManager = crossReferenceLookupTableRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
		this.urnRetrievalManager = urnRetrievalManager;
	}
	

	private class LocalCache {
		//Built from looupTable
		private InMemoryURNReferenceRetreivalManager inMemoryURNReferenceRetrievalManager;
		private CrossReferenceRetrievalMananger readOnlyXsRetrievalManager;
		private InMemoryMaintainableReferenceRetreivalManager readOnlyMaintRefRetrievalManager;
		
		public LocalCache() {
			ICrossReferenceLookupTable lookupTable = crossReferenceLookupTableRetrievalManager.getCrossReferenceLookupTable();
	 		this.inMemoryURNReferenceRetrievalManager = new InMemoryURNReferenceRetreivalManager(lookupTable);
			this.readOnlyXsRetrievalManager = new CrossReferenceRetrievalMananger(urnRetrievalManager, beanRetrievalManager, inMemoryURNReferenceRetrievalManager);
			this.readOnlyMaintRefRetrievalManager = new InMemoryMaintainableReferenceRetreivalManager(lookupTable);
		}
	}


	@Override
	public void invoke(IStructureEvent obj) {
		cache = null;
	}

	@Override
	public void clearCache() {
		cache = null;
	}
	
	private LocalCache getCache() {
		LocalCache cache = this.cache;
		if(cache != null) {
			return cache;
		}
		synchronized(this) {
			cache = this.cache;  //check again, it may have been built by another thread
			if(cache == null) {
				cache = new LocalCache();
			}
			this.cache = cache;
		}
		return cache;
	}
	
	

	@Override
	public void writeReferences(IURNAbsolute<?> target, STRUCTURE_REFERENCE_DETAIL detail, OutputStream out,
			InformationFormat format) {
		getCache().inMemoryURNReferenceRetrievalManager.writeReferences(target, detail, out, format);
	}

	@Override
	public Set<IURNMaintainable<?>> whoReferencesMe(IURNAbsolute<?> target, boolean includeIndirect, boolean includeWeak) {
		return getCache().inMemoryURNReferenceRetrievalManager.whoReferencesMe(target, includeIndirect, includeWeak);
	}

	@Override
	public Set<IURNMaintainable<?>> whoDoIReference(IURNAbsolute<?> source, boolean includeIndirect, boolean includeWeak) {
		return getCache().inMemoryURNReferenceRetrievalManager.whoDoIReference(source, includeIndirect, includeWeak);
	}

	@Override
	public List<IMaintainableReferences<?>> getReferencedBy(IURNMaintainable<?> urn) {
		return getCache().readOnlyMaintRefRetrievalManager.getReferencedBy(urn);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURN<?> sourceStructureURN, boolean includeIndirectReferences, Class<T> structures) {
		return getCache().readOnlyXsRetrievalManager.getCrossReferencingStructures(sourceStructureURN, includeIndirectReferences, structures);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencedStructures(IURN<?> sourceStructureURN,	boolean includeIndirectReferences, boolean fullTreeResolution, Class<T> structuresOfType) {
		return getCache().readOnlyXsRetrievalManager.getCrossReferencedStructures(sourceStructureURN, includeIndirectReferences, fullTreeResolution, structuresOfType);
	}
	
}
