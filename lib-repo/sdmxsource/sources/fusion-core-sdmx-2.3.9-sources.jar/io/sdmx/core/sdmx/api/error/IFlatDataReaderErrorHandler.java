package io.sdmx.core.sdmx.api.error;

import io.sdmx.api.error.FusionError;
import io.sdmx.core.sdmx.api.model.data.IDataRow;

public interface IFlatDataReaderErrorHandler {

	/**
	 * @param errorRow The row that was in error, null if the error is not specific to any row
	 * @param errorComponent the component that caused the error, null if the error is not specific to a component
	 * @param error the error code and message
	 */
	void handleError(IDataRow errorRow, String errorComponent, FusionError error);
	
}
