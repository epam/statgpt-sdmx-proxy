package io.sdmx.core.sdmx.api.error;

import java.util.List;

import io.sdmx.api.collection.KeyValue;

/**
 * Defines an error that are reported from validating a Series or Observation in a dataset
 */
public interface DataError {
	static final String UNKNOWN_ERROR_CATEGORY = "Unknown";  //A category to represent error where the category is not known, a high level catch statement for example 
	
	enum ERROR_POSITION {
		OBSERVATION("Observation"),
		SERIES("Series"),
		GROUP("Group"),
		DATASET("Dataset");

		private String name;
		
		private ERROR_POSITION(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
	}

	/**
	 * Returns the dataset that threw the errror (1 indexed)
	 * @return
	 */
	int getDataset();
	
	/**
	 * Returns the error message, for example calculation result for 'TOTAL=EUR+DE+FR+UK' does not match expected value 
	 * @return
	 */
	String getMessage();
	
	/**
     * Returns the error code which will be of the format XXX-YYY
     * @return
     */
    String getErrorCode();
	
	/**
	 * Returns the series (or group) short code - this is optional, if missing then this error is at the level of the dataset (most likely dataset attribute errors)
	 * @return
	 */
	List<String> getShortCode();
	
	/**
	 * @return if applicable will return the component that was in error (Dim Id/Attribute id)
	 */
	KeyValue getComponent();
	
	/**
	 * @return
	 */
	ERROR_POSITION getErrorPosition();
	
	/**
	 * Returns the error category that this error belongs to, for example:
	 * MandatoryAttribute
	 * Representation
	 * XMLMissingHeader
	 * 
	 * @return
	 */
	String getErrorCategory();
	
}
