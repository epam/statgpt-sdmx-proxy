package io.sdmx.core.sdmx.engine.data;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.data.IDatasetStoreDataReaderEngine;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;

/**
 * Reads data from a {@link IDatasetStoreContainer}
 */
public class DatasetStoreDataReaderEngine implements IDatasetStoreDataReaderEngine {
	private static final Logger LOG =
			LoggerFactory.getLogger(DatasetStoreDataReaderEngine.class);

	private IDatasetStoreContainer storage;
	private int dsPos = -1;
	private int keyPos = -1;
	private int obsPos = -1;
	private IDatasetStore currentDataset;
	private Keyable currentKey;
	private Iterator<Observation> obsIterator;
	private Observation currentObs;

	/**
	 * Constructor for plain retrieval from an existing storage file.
	 */
	public DatasetStoreDataReaderEngine(IDatasetStoreContainer storage) {
		this.storage = storage;
		reset();
	}
	
	@Override
	public IDatasetStoreContainer getDatasetContainer() {
		return storage;
	}

	private IDatasetStore getCurrentDataset() {
		if (currentDataset == null && !moveNextDataset())
			return null;

		return currentDataset;
	}

	@Override
	public boolean moveNextDataset() {
		int nextDatasetIndex = dsPos + 1;
		currentDataset = null;

		if (nextDatasetIndex < storage.getDatasetSize()) {
			currentDataset = storage.getDataset(nextDatasetIndex);
			resetKeyable();
			dsPos = nextDatasetIndex;
		}
		return currentDataset != null;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return null; // FIXME: what about keeping track of the original format?
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return getCurrentDataset().getStructures().getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return getCurrentDataset().getStructures().getDataflow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return getCurrentDataset().getStructures().getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return dsPos;
	}

	@Override
	public int getKeyablePosition() {
		return keyPos;
	}

	@Override
	public int getObsPosition() {
		return obsPos;
	}


	@Override
	public HeaderBean getHeader() {
		return storage.getHeader();
	}

	@Override
	public DataReaderEngine createCopy() {
		//TODO what is the copy is closed - need to copy the storeage
		return new DatasetStoreDataReaderEngine(this.storage);
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return getCurrentDataset().getHeader();
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return getCurrentDataset().getDatasetAttributes();
	}

	@Override
	public Keyable getCurrentKey() {
		return currentKey;
	}

	@Override
	public Observation getCurrentObservation() {
		return this.currentObs ;
	}

	@Override
	public boolean moveNextObservation() {
		this.currentObs = null;
		boolean hasNext = true;
		if(this.obsIterator == null || !this.obsIterator.hasNext()) {
			hasNext = false;
		} else {
			obsPos++;
			this.currentObs = obsIterator.next();
		}
		LOG.trace("moveNextObservation - hasNext: {}, curOIndex: {}",
				hasNext, obsPos);

		return hasNext;
	}


	@Override
	public boolean moveNextKeyable() {
		this.currentKey = null;
		resetObservation();
		int nextKey = keyPos+1;
		boolean hasNext = true;
		if(getCurrentDataset().getKeySize() <= nextKey) {
			hasNext = false;
		} else {
			keyPos = nextKey;
			this.currentKey = getCurrentDataset().getKeyable(keyPos);
			if(this.currentKey != null) {
				this.obsIterator = getCurrentDataset().getObs(keyPos);
			} else {
				hasNext = false;
			}
		}
		LOG.trace("moveNextKeyable - hasNext: {}, curKIndex: {}",
				hasNext, keyPos);
		return hasNext;
	}

	@Override
	public List<FooterMessage> close() {
		if (storage != null)
			storage.close(true);

		return Collections.emptyList();
	}
	
	@Override
	public void reset() {
		resetDataset();
	}
	
	private void resetDataset() {
		currentDataset = null;
		dsPos = -1;
		resetKeyable();
	}

	private void resetKeyable() {
		keyPos = -1;
		currentKey = null;
		resetObservation();
	}

	private void resetObservation() {
		obsPos = -1;
		this.obsIterator = null;
		currentObs = null;
	}
}
