package io.sdmx.core.sdmx.api.manager.structure;

import java.io.OutputStream;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;

/**
 * Writes a transaction in the given format
 */
public interface IStructureTransactionWriterManager {


	/**
	 * Writes the transaction in the given format
	 * @param transactionalBeansEvent
	 * @param format
	 */
	void writeTransaction(ITransactionalBeansEvent transactionalBeansEvent, InformationFormat format, OutputStream out);

}
