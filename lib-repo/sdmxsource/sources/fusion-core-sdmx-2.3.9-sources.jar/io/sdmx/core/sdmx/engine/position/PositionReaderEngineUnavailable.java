package io.sdmx.core.sdmx.engine.position;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDataPosition.POSITION_TYPE;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;
import io.sdmx.core.sdmx.model.data.UnavailableFilePosition;
import io.sdmx.utils.core.application.FusionBeanStore;

public class PositionReaderEngineUnavailable extends AbstractPositionReaderEngineFile implements IPositionReaderEngine {
	
	public static void registerInstance() {
		if (FusionBeanStore.getBeans(PositionReaderEngineUnavailable.class).isEmpty()) {
			FusionBeanStore.registerInstance(new PositionReaderEngineUnavailable());
		}
	}
	
	private PositionReaderEngineUnavailable() {
		super(POSITION_TYPE.UNAVAILABLE);
	}

	@Override
	protected IDataPosition parsePositionalInformation(String[] split) {
		return new UnavailableFilePosition();
	}
	
}
