package io.sdmx.core.sdmx.factory;

import java.util.Map;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.core.sdmx.format.StructureSchemaFormat;
import io.sdmx.api.sdmx.factory.ISchemaFormatFactory;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class SdmxStructureSchemaFormatFactory implements ISchemaFormatFactory, IFusionSingleton {
	private static SdmxStructureSchemaFormatFactory INSTANCE;

	private StructureFormatManager structureFormatManager;
	private final int priority = 5;

	//Private constructor - lazy load instance
	private SdmxStructureSchemaFormatFactory() {
		SingletonStore.registerInterest(StructureFormatManager.class, (instance)-> {
			structureFormatManager = instance;
		});
	}

	public static SdmxStructureSchemaFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxStructureSchemaFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxStructureSchemaFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}
	
	

	@Override
	public Class<SchemaFormat> getFormatClass() {
		return SchemaFormat.class;
	}

	@Override
	/**
	 * Treats it as a structure response format if the request contains the 
	 * query parameter ?structure=true as well as a format parameter 
	 */
	public SchemaFormat getFormat(String format, Request request) {
		String structure = request.getParameter("structure");
		if(format != null && "true".equalsIgnoreCase(structure)) {
			StructureFormat sf = structureFormatManager.getFormat(request);
			if(sf != null) {
				return new StructureSchemaFormat(sf);
			}
			throw new SdmxNotAcceptableException("Unsupported format: " +format);
		}
		return null;
	}

	@Override
	/**
	 * Supports
	 * application/vnd.sdmx.structure[anything]
	 */
	public SchemaFormat getFormat(Request request, IVNDHeader vnd) {
		StructureFormat format = structureFormatManager.getFormat(vnd);
		if(format != null) {
			return new StructureSchemaFormat(format);
		}
		return null;
	}
	
	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return structureFormatManager.getSupportedFormats();
	}

	@Override
	public int getPriority() {
		return priority;
	}
}
