package io.sdmx.core.sdmx.api.engine.structure;

import java.io.OutputStream;

import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;


/**
 * Writes transaction events to the output stream
 */
public interface IStructureTransactionWriterEngine {

	/**
	 * @param event not null, written to output stream
	 * @param out closed on completion
	 */
	void writeTransaction(ITransactionalBeansEvent event, OutputStream out);
	
}
