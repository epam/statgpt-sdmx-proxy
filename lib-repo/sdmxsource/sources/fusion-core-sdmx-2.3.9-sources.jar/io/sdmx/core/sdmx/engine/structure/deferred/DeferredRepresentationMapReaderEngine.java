package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.im.beans.mapping.v3.RepresentationMapBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link RepresentationMapBeanDeferred}
 */
public class DeferredRepresentationMapReaderEngine extends AbstractDeferredStructureReaderEngine<IRepresentationMapBean> {
    private static DeferredRepresentationMapReaderEngine INSTANCE;
    
    private DeferredRepresentationMapReaderEngine() {
        super(IRepresentationMapBean.class);
    }
    
    public static DeferredRepresentationMapReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredRepresentationMapReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IRepresentationMapBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new RepresentationMapBeanDeferred(bean, loader);
    }

}
