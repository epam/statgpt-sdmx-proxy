package io.sdmx.core.sdmx.error;

import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.api.sdmx.engine.DataErrorReporter;

/**
 * Describes an error category which could result from a within a dataset, as defined
 * by the DataReaderFactory (example BAD XML) or a ValidaitonEngine, for example MissingMandatoryAttributes
 * DataReaderFactory
 */
public class DataErrorCategory implements Comparable<DataErrorCategory> {
    private String id;
    private String name;
    private String description;
    private int minLevel;

    public DataErrorCategory(DataReaderFactory fac, @SuppressWarnings("rawtypes") Enum e, String name, String description) {
        this(fac, e, name, description, 0);
    }

    public DataErrorCategory(DataReaderFactory fac, @SuppressWarnings("rawtypes") Enum e, String name, String description, int minLevel) {
        this.id = fac.getId()+"."+e.toString();
        this.name = name;
        this.description = description;
        this.minLevel = minLevel;
    }

    public DataErrorCategory(DataErrorReporter fac, String name, int minLevel) {
        this.id = fac.getId();
        this.name = name;
        this.description = fac.getDescription();
        this.minLevel = minLevel;
    }

    /**
     * The unique identifier for this error, this is either the Id of the DataValidatorFactory e.g. MandatoryAttribute
     * or as a result of the DataReaderFactory and error type, for example SDMX.MISSING_SENDER_ID
     * @return
     */
    public String getId() {
        return id;
    }

    public String getMajorCategory() {
        return id.split("\\.")[0];
    }

    public String getSubCategory() {
        String[] split =id.split("\\.");
        if(split.length > 1) {
        	return split[1];
        }
        return null;
    }   
    
    public String getName() {
        return name;
    }
    
    public String getDescription() {
		return description;
	}

	public int getMinLevel() {
        return minLevel;
    }

	
	@Override
	public int compareTo(DataErrorCategory o) {
		return this.getId().compareTo(o.getId());
	}

	@Override
	public int hashCode() {
		return getId().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DataErrorCategory) {
			DataErrorCategory that = (DataErrorCategory)obj;
			return that.getId().equals(this.getId());
		}
		return false;
	}

	@Override
	public String toString() {
		return getId();
	}
}

