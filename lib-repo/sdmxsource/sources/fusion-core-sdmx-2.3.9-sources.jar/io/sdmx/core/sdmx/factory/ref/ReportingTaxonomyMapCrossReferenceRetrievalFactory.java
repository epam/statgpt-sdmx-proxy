package io.sdmx.core.sdmx.factory.ref;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingCategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IReportingTaxonomyMapBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ReportingTaxonomyMapCrossReferenceRetrievalFactory
		extends ItemSchemeMapCrossReferenceRetrievalFactory<IReportingTaxonomyMapBean, IReportingCategoryMapBean, ReportingTaxonomyBean, ReportingCategoryBean> {

	private static ReportingTaxonomyMapCrossReferenceRetrievalFactory INSTANCE;

	public static ReportingTaxonomyMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static ReportingTaxonomyMapCrossReferenceRetrievalFactory getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new ReportingTaxonomyMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	
	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return IReportingTaxonomyMapBean.class;
	}

	@Override
	protected Class<ReportingTaxonomyBean> getItemSchemeClass(IReportingTaxonomyMapBean itemSchemeMap) {
		return ReportingTaxonomyBean.class;
	}
}
