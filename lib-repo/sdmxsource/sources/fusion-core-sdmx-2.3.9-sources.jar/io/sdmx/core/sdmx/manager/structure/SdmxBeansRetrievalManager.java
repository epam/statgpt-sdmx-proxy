package io.sdmx.core.sdmx.manager.structure;

import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansRetreivalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.im.beans.container.SdmxBeansImmutable;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.util.container.SdmxBeansUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxBeansRetrievalManager implements SdmxBeansRetreivalManager, Listener<IStructureEvent> {
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private SdmxBeans beansContainer;
	
	
	public SdmxBeansRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public void invoke(IStructureEvent event) {
		SdmxBeansUtil.mergeChanges(event, beansContainer);
	}

	@Override
	public SdmxBeans getSdmxBeans() {
		if(beansContainer == null) {
			beansContainer = new SdmxBeansImpl(beanRetrievalManager.getMaintainableBeans(URN.ANY_MAINTINABLE));
		}
		return new SdmxBeansImmutable(beansContainer);
	}
}
