package io.sdmx.core.sdmx.engine.metadata;

import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IMetadatasetStructures;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.metadatastructure.IMetadataTargetIdentifier;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataValidationEngine;
import io.sdmx.im.beans.container.MetadatasetStructures;

public abstract class AbstractMetadataValidationEngine implements IMetadataValidationEngine {
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public AbstractMetadataValidationEngine(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public void validate(IReferenceMetadataContainer metadata) {
		for(IReportedMetadataSetBean mds : metadata.getReferenceMetadata()) {
			IMetadataTargetIdentifier maint = beanRetrievalManager.getBean(mds.getStructure().getReference());
			if(maint == null) {
				throw new CrossReferenceException(mds.getStructure());
			}
			IMetadatasetStructures mdsStructures = new MetadatasetStructures(maint, beanRetrievalManager);
			validate(mds, mdsStructures);
		}
	}
	
	
	/**
	 * Validate the Metadata Set
	 * @param mds the metadata set to validate
	 * @param mdsStructures the structures to which the metadata set should conform
	 */
	protected abstract void validate(IReportedMetadataSetBean mds, IMetadatasetStructures mdsStructures);


	public SdmxBeanRetrievalManager getBeanRetrievalManager() {
		return beanRetrievalManager;
	}

	
	
}
