package io.sdmx.core.sdmx.api.manager.data;

import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;

/**
 * Responsible for allocating a DataWriterEngine for the storage of temporary data, and allocating a corresponding
 * DataReaderEngine which can be used to read the data that was written
 */
public interface ITemporaryDataManager {

	/**
	 * Returns a {@link DataWriterEngine} that can be used to write data to for temporary purposes
	 */
	ITemporaryDataWriterEngine getDataWriterEngine();
	

	/**
	 * A Data Reader engine that is capable of re-reading the written data back in
	 * @param writer
	 * @return
	 */
	DataReaderEngine getDataReaderEngine(ITemporaryDataWriterEngine writer);
	
	/**
	 * Close resources associated with writer
	 * @param writer
	 */
	void close(ITemporaryDataWriterEngine writer);

}
