package io.sdmx.core.sdmx.api.engine.data;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;

/**
 * A specialised DataReaderEngine which is reading its data from a {@link IDatasetStoreContainer}
 */
public interface IDatasetStoreDataReaderEngine extends DataReaderEngine {

	/**
	 * @return the datasets which this reader engine is reading from
	 */
	IDatasetStoreContainer getDatasetContainer();
	
}
