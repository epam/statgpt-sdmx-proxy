package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.model.error.ICaculationError;

public class CaculationError implements ICaculationError {
	private String shortCode; 
	private String expression; 
	private String equality;
	private String resolvedValues; 
	private Double expectedValue; 
	private Double reportedValue;
	private List<String> inputCodeIds;
	
	private Throwable th;
	
	public CaculationError(String shortCode, String expression, String equality, List<String> inputCodeIds, String resolvedValues, Double expectedValue, Double reportedValue, Throwable th) {
		this.shortCode = shortCode;
		this.equality = equality;
		this.expression = expression;
		this.resolvedValues = resolvedValues;
		this.expectedValue = expectedValue;
		this.reportedValue = reportedValue;
		inputCodeIds = new ArrayList<>(inputCodeIds);
		Collections.sort(inputCodeIds);
		this.inputCodeIds = Collections.unmodifiableList(inputCodeIds);
		this.th = th;
	}
	
	public List<String> getInputCodeIds() {
		return inputCodeIds;
	}

	public String getShortCode() {
		return shortCode;
	}
	
	public String getEquality() {
		return equality;
	}

	public String getExpression() {
		return expression;
	}

	public String getResolvedValues() {
		return resolvedValues;
	}

	public Double getExpectedValue() {
		return expectedValue;
	}

	public Double getReportedValue() {
		return reportedValue;
	}

	public Throwable getException() {
		return th;
	}

	@Override
	public String toString() {
		return "Reported value '"+reportedValue+"' breaks validation rule: '"+expression+"'. Calculated output '"+expectedValue+"' using resolved values: '"+resolvedValues+"' for key: '"+shortCode+"'";
	}
	
	
}
