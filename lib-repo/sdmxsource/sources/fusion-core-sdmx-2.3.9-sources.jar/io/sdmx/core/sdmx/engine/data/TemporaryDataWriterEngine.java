package io.sdmx.core.sdmx.engine.data;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class TemporaryDataWriterEngine extends DataWriterEngineProxy implements ITemporaryDataWriterEngine {
	private SdmxBeans beans = new SdmxBeansImpl();
	private ReadableDataLocation rdl;
	private HeaderBean headerBean;
	private List<DatasetHeaderBean> datasetHeaders = new ArrayList<>(3);
	private List<IDatasetStructures> structures= new ArrayList<>(3);
	private SdmxBeanRetrievalManager brm;
	
	private int keyWritten = 0;
	private int obsWritten = 0;
	private boolean dataWritten = false;
	
	public TemporaryDataWriterEngine(ISeriesObsDataWriterEngine dwe, ReadableDataLocation rdl) {
		this(dwe, rdl, null);
	}
	
	public TemporaryDataWriterEngine(ISeriesObsDataWriterEngine dwe, ReadableDataLocation rdl, SdmxBeanRetrievalManager brm) {
		super(dwe);
		this.rdl = rdl;
		this.brm = brm;
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		super.startDataset(structures, header, datasetAttributes, annotations);
		datasetHeaders.add(header);
		this.structures.add(structures);
		this.dataWritten = datasetAttributes != null && 
								(ObjectUtil.validCollection(datasetAttributes.getAttributes()) || 
								ObjectUtil.validCollection(datasetAttributes.getMultilingualAttributes()));
		
		if(structures.getProvisionAgreement() != null) {
			beans.addIdentifiable(structures.getProvisionAgreement());
			if(structures.getDataProvider() == null && brm != null) {
				try {
					DataProviderBean dp = brm.getBean(structures.getProvisionAgreement().getDataproviderRef().getReference());
					beans.addIdentifiable(dp);
				} catch(Throwable th) {}
			}
			
		}
		if(structures.getDataflow() != null) {
			beans.addIdentifiable(structures.getDataflow());
		}
		beans.addIdentifiable(structures.getDataStructure());
	}
	
	public ISeriesObsDataWriterEngine getDataWriter() {
		return super.getProxy();
	}
	
	@Override
	public List<IDatasetStructures> getStructures() {
		return structures;
	}

	@Override
	public HeaderBean getHeader() {
		return this.headerBean;
	}
	
	@Override
	public void writeHeader(HeaderBean header) {
		super.writeHeader(header);
		this.headerBean = header;
	}
	
	@Override
	public List<DatasetHeaderBean> getDatasetHeaders() {
		return datasetHeaders;
	}
	
	@Override
	public boolean dataWritten() {
		return this.dataWritten;
	}

	@Override
	public void writeKey(Keyable key) {
		super.writeKey(key);
		keyWritten++;
		dataWritten = true;
	}

	@Override
	public void writeObservation(Observation obs) {
		super.writeObservation(obs);
		obsWritten++;
		dataWritten = true;
	}
	
	@Override
	public int getKeyWritten() {
		return keyWritten;
	}

	@Override
	public int getObsWritten() {
		return obsWritten;
	}

	@Override
	public SdmxBeans getWrittenStructures() {
		return beans;
	}

	@Override
	public ReadableDataLocation getReadableDataLocation() {
		return rdl;
	}
}
