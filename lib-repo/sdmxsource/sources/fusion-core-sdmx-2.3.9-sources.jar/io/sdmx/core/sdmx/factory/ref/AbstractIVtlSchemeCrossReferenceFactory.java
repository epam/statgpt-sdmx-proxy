package io.sdmx.core.sdmx.factory.ref;

import static java.util.Objects.isNull;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.VersionRef;

/**
 * Processes URNs which may be fully populated (agency, id, version and possibly an identiable ID) or it may
 * contain wildcards.  The only mandatory property is the id, all other properties can be a wildcard.
 * In the case that only the ID is present, the system tries to determine if this is intended as a cross reference
 * or not, as it could be that the VTL statement was referencing a variable created by another VTL statement.  This
 * is determined by filling in the gaps, where version is set to latest and agency ID is set to the agencyId of the 
 * VTL maintainable structure.  In other wildcard cases, where ID is provided with another property such as version or agency
 * Id, the reference is assumed to be a cross reference and the gaps are filled using the same logic as described earlier.
 * 
 */
public abstract class AbstractIVtlSchemeCrossReferenceFactory<T extends IVtlSchemeBean<? extends ItemBean>> 
implements CrossReferenceRetrievalFactory, IFusionSingleton {


	protected void addReferences(T schemeBean, 
			SdmxBeanRetrievalManager retrievalManager,
			List<IURN<?>> referencedArtifacts, 
			Set<ICrossReferenceBean<?>> returnReferences) {
		for (IURN<?> urn : referencedArtifacts) {
			String urnAgency = isNull(urn.getAgencyId()) ? schemeBean.getAgencyId() : urn.getAgencyId();
			IURNSingle<?> toRegister = null;
			if(urn.getReferenceType() == IURN.REFERENCE_TYPE.WILDCARD) {
				if(urn.getVersion().isAll() && isNull(urn.getAgencyId())) {
					//The only value present is a matinainable ID, we don't know if the
					//VTL was defining a cross reference or
					//if it was referencing a variable - we can only know if it was intended to be a
					//cross reference if a structure exists with this ID for the agency that owns this VTL structure

					//modify the URN to fill in the agency and version details
					//Reference is to either a maintainable (i.e Codelist) or an identifiable (i.e Code) use ? in generics
					IURNSingle<?> refUrn = URN.builder(urn).agencyId(urnAgency).versionRef(VersionRef.LATEST).buildSingle();

					//Does the maintainable object exist
					if(retrievalManager.getBean(refUrn.getMaintainableURN()) != null) {
						toRegister = refUrn;  //the reference (to Codelist or Concept) with the agency and version is valid
					}
				} else if(urn.getAgencyId() == null) {
					//only the agency was missing, just set to latest
					toRegister = URN.builder(urn).agencyId(urnAgency).buildSingle();
				} else if(urn.getVersion().isAll()) {
					//only the agency was missing, set to agency that owns the VTL structure
					toRegister = URN.builder(urn).versionRef(VersionRef.LATEST).buildSingle();
				}

			} else {
				toRegister = urn.asSingle(); //no wildcard, therefore it is referencing a single structure
			}
			if(toRegister != null) {
				returnReferences.add(CrossReferenceBean.build(schemeBean, toRegister));
			}
		}
	}

}
