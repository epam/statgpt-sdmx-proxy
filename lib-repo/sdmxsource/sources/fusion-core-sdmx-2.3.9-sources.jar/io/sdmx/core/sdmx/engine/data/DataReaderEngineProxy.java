package io.sdmx.core.sdmx.engine.data;

import java.util.List;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * Passes all calls to the proxy
 */
public class DataReaderEngineProxy implements DataReaderEngine {
	private DataReaderEngine proxy = EmptyDataReaderEngine.getInstance();

	public DataReaderEngineProxy(DataReaderEngine proxy) {
		if(proxy != null) {
			this.proxy = proxy;
		}
	}

	public DataReaderEngine getProxy() {
		return proxy;
	}
	
	public void setProxy(DataReaderEngine proxy) {
		if(proxy == null) {
			proxy = EmptyDataReaderEngine.getInstance();
		}
		this.proxy = proxy;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return proxy.getFormatDetails();
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return proxy.getProvisionAgreement();
	}

	@Override
	public DataflowBean getDataFlow() {
		return proxy.getDataFlow();
	}

	@Override
	public DataStructureBean getDataStructure() {
		return proxy.getDataStructure();
	}

	@Override
	public int getDatasetPosition() {
		return proxy.getDatasetPosition();
	}

	@Override
	public int getKeyablePosition() {
		return proxy.getKeyablePosition();
	}

	@Override
	public int getObsPosition() {
		return proxy.getObsPosition();
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		return proxy.moveNextDataset();
	}

	@Override
	public void reset() {
		proxy.reset();
	}

	@Override
	public HeaderBean getHeader() {
		return proxy.getHeader();
	}

	@Override
	public DataReaderEngine createCopy() {
		return proxy.createCopy();
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return proxy.getCurrentDatasetHeaderBean();
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return proxy.getDatasetAttributes();
	}

	@Override
	public Keyable getCurrentKey() {
		return proxy.getCurrentKey();
	}

	@Override
	public Observation getCurrentObservation() {
		return proxy.getCurrentObservation();
	}

	@Override
	public boolean moveNextObservation() {
		return proxy.moveNextObservation();
	}

	@Override
	public boolean moveNextKeyable() {
		return proxy.moveNextKeyable();
	}

	@Override
	public List<FooterMessage> close() {
		return proxy.close();
	}

}
