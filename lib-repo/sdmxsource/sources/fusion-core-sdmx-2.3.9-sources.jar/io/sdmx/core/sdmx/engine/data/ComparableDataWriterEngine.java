package io.sdmx.core.sdmx.engine.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Stores the written data so it can be compared
 */
public class ComparableDataWriterEngine implements ISeriesObsDataWriterEngine {
	private Map<String, Keyable> keys = new TreeMap<>();
	private Map<String, Observation> obs = new TreeMap<>();
	private String id;
	
	private Date reportingBegin;
	private Date reportingEnd;
	private String senderId;
	
	public void cleanUp() {
		keys = new TreeMap<>();
		obs = new TreeMap<>();
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {}

	@Override
	public void close(FooterMessage... footer) {}

	@Override
	public void writeHeader(HeaderBean header) {
		if(header != null) {
			reportingBegin = header.getReportingBegin();
			reportingEnd = header.getReportingEnd();
			if(header.getSender() != null) {
				senderId = header.getSender().getId();
			}
		}
	}

	public ComparableDataWriterEngine(String id) {
		this.id = id;
	}

	@Override
	public void writeKey(Keyable key) {
		keys.put(key.getShortCode(), key);
	}

	@Override
	public void writeObservation(Observation obs) {
		this.obs.put(obs.getShortCode(), obs);
	}
	
	public Date getReportingBegin() {
		return reportingBegin;
	}

	public Date getReportingEnd() {
		return reportingEnd;
	}

	public Collection<Keyable> getKeys() {
		return keys.values();
	}
	

	public List<String> compare(ComparableDataWriterEngine that) {
		List<String> differences = new ArrayList<>();
		compareKeys(keys, that.keys, differences, that.id);
		compareKeys(obs, that.obs, differences, that.id);
		
		if(!ObjectUtil.equivalent(reportingBegin, that.reportingBegin)) {
			differences.add("Reporting Begin Periods Differ '"+reportingBegin+"' and '"+that.reportingBegin+"'");
		}
		if(!ObjectUtil.equivalent(reportingEnd, that.reportingEnd)) {
			differences.add("Reporting End Periods Differ '"+reportingEnd+"' and '"+that.reportingEnd+"'");
		}
		if(!ObjectUtil.equivalent(reportingEnd, that.reportingEnd)) {
			differences.add("Sender Id Differs '"+senderId+"' and '"+that.senderId+"'");
		}
		return differences;
	}
	
	private void compareKeys(Map<String, ? extends Attributable> thisA, Map<String, ? extends  Attributable> thatA, List<String> differences, String thatId) {
		//Compare Keys
		Set<String> allKeys = new HashSet<>(thatA.keySet());
		allKeys.addAll(new HashSet<String>(thisA.keySet()));

		for(String currentSeriesKey : allKeys) {
			Attributable k1 = thisA.get(currentSeriesKey);
			Attributable k2 = thatA.get(currentSeriesKey);
			if(k1 == null) {
				differences.add(id + " missing : "+currentSeriesKey);
			} else if(k2 == null) {
				differences.add(thatId + " missing : "+currentSeriesKey);
			} else {
				compareAttributes(differences, currentSeriesKey, thatId, k1, k2);
			}
		}
	}
	
	private void compareAttributes(List<String> differences, String shortCode, String thatId, Attributable thisA, Attributable thatA) {
		if(thisA instanceof Observation) {
			Observation thisObs = (Observation) thisA;
			Observation thatObs = (Observation) thatA;
			
			for(String measure : thisObs.getMeasureMap().keySet()) {
				KeyValue thisValue = thisObs.getMeasure(measure);
				KeyValue thatValue = thatObs.getMeasure(measure);
				if(!ObjectUtil.equivalent(thisValue, thatValue)) {
					if(thatValue == null) {
						differences.add(thatId + " '"+shortCode+"' missing measure: "+measure);
					} else {
						differences.add(thatId + " '"+shortCode+"'  measure "+measure +" reporting "+thatValue+" "+id+" reporting"+thisValue);;
					}
				}
			}
			for(String measure : thatObs.getMeasureMap().keySet()) {
				if(!thatObs.getMeasureMap().containsKey(measure)) {
					differences.add(id + " '"+shortCode+"' missing measure: "+measure);
				}
			}
			
		}
		
		Map<String, String> thisAttr = thisA.getAttributes().stream().collect(Collectors.toMap(e -> e.getConcept(), e -> e.getCode()));
		Map<String, String> thatAttr = thatA.getAttributes().stream().collect(Collectors.toMap(e -> e.getConcept(), e -> e.getCode()));

		Set<String> allKeys = new HashSet<>(thisAttr.keySet());
		allKeys.addAll(new HashSet<String>(thatAttr.keySet()));

		for(String attrId : allKeys) {
			if(!thisAttr.containsKey(attrId)) {
				differences.add(id + " '"+shortCode+"' missing attribute : "+attrId);
			} else if(!thatAttr.containsKey(attrId)) {
				differences.add(thatId + " '"+shortCode+"' missing attribute : "+attrId);
			} else if(!thisAttr.get(attrId).equals(thatAttr.get(attrId))) {
				differences.add("attributes for '"+shortCode+"."+attrId+"' differ '"+thisAttr.get(attrId)+"' vs '"+thatAttr.get(attrId)+"' ");
			}
		}
	}
}
