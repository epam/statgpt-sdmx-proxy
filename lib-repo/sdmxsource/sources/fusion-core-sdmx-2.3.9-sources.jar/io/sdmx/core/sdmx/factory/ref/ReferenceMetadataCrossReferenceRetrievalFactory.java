package io.sdmx.core.sdmx.factory.ref;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ReferenceMetadataCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory, IFusionSingleton {
	private static ReferenceMetadataCrossReferenceRetrievalFactory INSTANCE;


	public static ReferenceMetadataCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ReferenceMetadataCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
	public Class<IReportedMetadataSetBean> getSupportedType() {
		return IReportedMetadataSetBean.class;
	}

	public static ReferenceMetadataCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		IReportedMetadataSetBean metadataSet = (IReportedMetadataSetBean)maintBean;
		
		
		return Collections.emptySet();
	}
	
	
}
