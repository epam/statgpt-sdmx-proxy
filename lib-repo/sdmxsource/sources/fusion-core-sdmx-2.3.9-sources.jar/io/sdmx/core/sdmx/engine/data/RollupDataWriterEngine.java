package io.sdmx.core.sdmx.engine.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.DATA_POSITION;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Rolls up to the ISeriesObsDataWriterEngine
 *
 */
public final class RollupDataWriterEngine implements DataWriterEngine {
	private ISeriesObsDataWriterEngine seriesObsDataWriterEngine;

	private DataflowBean flow;
	private ProvisionAgreementBean prov;
	private DataStructureBean dsd;
	private boolean isClosed = false;
	private boolean isError = false;

	private String groupName;
	private List<KeyValue> key;
	//	private List<KeyValue> attributes;
	private List<KeyValue> obsValues; //measure ID to value
	private Keyable currentKey;

	private boolean flushDatasetRequired;
	private boolean flushKeyRequired;
	private boolean flushObsRequired;

	private DATA_POSITION currentPosition = DATA_POSITION.DATASET;


	private String obsDimId;
	private String obsDimValue;
	private String dimensionAtObservation;

	private AnnotationBean[] currentAnnotations;

	private Map<String, String> attributes = new HashMap<>();

	private List<IMultilingualKeyValue> complexAttributes;
	private Map<String, Set<String>> multiValueComponentVues = new HashMap<>();

	public RollupDataWriterEngine(ISeriesObsDataWriterEngine seriesObsDataWriterEngine) {
		ObjectUtil.assertNotNull("ISeriesObsDataWriterEngine can not be null", seriesObsDataWriterEngine);
		this.seriesObsDataWriterEngine = seriesObsDataWriterEngine;
		clearCurrentKeys();
	}

	@Override
	public void writeHeader(HeaderBean header) {
		checkClosed();
		seriesObsDataWriterEngine.writeHeader(header);
	}

	private  DatasetHeaderBean datasetHeader;

	@Override
	public void startDataset(ProvisionAgreementBean prov, DataflowBean flow, DataStructureBean dsd, DatasetHeaderBean header, AnnotationBean... annotations) {
		checkClosed();
		flushDataset();
		flushKey();
		flushObs();
		clearCurrentKeys();

		this.currentAnnotations = annotations;
		this.datasetHeader = header;
		flushDatasetRequired = true;

		this.flow = flow;
		this.dsd = dsd;
		this.prov = prov;
		currentPosition = DATA_POSITION.DATASET;
		if(header != null && header.getDataStructureReference() != null) {
			this.dimensionAtObservation = header.getDataStructureReference().getDimensionAtObservation();
		}
		if(!ObjectUtil.validString(dimensionAtObservation)) {
			this.dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
		}
	}

	private void flushDataset() {
		if(flushDatasetRequired) {
			DatasetStructures structures = new DatasetStructures(dsd, flow, prov, null);
			seriesObsDataWriterEngine.startDataset(structures, datasetHeader, buildDatasetAttributes(), currentAnnotations);
			attributes = new HashMap<>();
			complexAttributes = new ArrayList<>();
			multiValueComponentVues = new HashMap<>();
			currentAnnotations = null;
			flushDatasetRequired = false;
		}
	}

	private IDatasetAttributes buildDatasetAttributes() {
		return buildAttributable(DatasetAttributes.builder());
	}

	/**
	 * Populates the builder from attributes stored and builds the final Attributable instance
	 * @param builder
	 */
	private <T extends Attributable> T buildAttributable(AttributableBuilder<T> builder) {
		builder.attributes(buildAttributes());
		builder.attributesMultilingual(complexAttributes);
		builder.annotations(currentAnnotations);
		return builder.build();
	}

	/**
	 * Creates a Keyable (currentKey) and converts it to the mapped key, writing the new key to the writer
	 */
	private void flushKey() {
		if(flushKeyRequired) {
			this.currentKey = buildAttributable(KeyableImpl.builder(dsd).dataflow(flow).group(groupName).key(key));
			seriesObsDataWriterEngine.writeKey(currentKey);
			clearCurrentKeys();
		}
	}



	private void flushObs() {
		if(flushObsRequired) {
			Observation obs = buildAttributable(ObservationImpl.builder(currentKey).dim(obsDimId, obsDimValue).measures(obsValues));
			seriesObsDataWriterEngine.writeObservation(obs);
			clearCurrentKeys();
		}
	}

	@Override
	public void startGroup(String groupId, AnnotationBean... annotations) {
		checkClosed();
		flushDataset();
		flushKey();
		flushObs();
		currentPosition = DATA_POSITION.GROUP;
		this.groupName = groupId;
		this.currentAnnotations = annotations;
	}

	@Override
	public void writeGroupKeyValue(String id, String value) {
		checkClosed();
		currentPosition = DATA_POSITION.GROUP_KEY_ATTRIBUTE;
		flushKeyRequired = true;
		key.add(KeyValueImpl.getInstance(id, value));
	}

	@Override
	public void startSeries(AnnotationBean... annotations) {
		checkClosed();
		currentPosition = DATA_POSITION.SERIES_KEY;
		flushDataset();
		flushKey();
		flushObs();
		this.currentAnnotations = annotations;
	}

	@Override
	public void writeSeriesKeyValue(String id, String value) {
		checkClosed();
		flushDataset();
		currentPosition = DATA_POSITION.SERIES_KEY;
		if(!flushKeyRequired) {
			flushObs();
		}
		flushKeyRequired = true;
		key.add(KeyValueImpl.getInstance(id, value));
	}


	@Override
	public void writeAttributeValue(String id, String... values) {
		checkClosed();
		if(currentPosition == DATA_POSITION.SERIES_KEY) {
			currentPosition = DATA_POSITION.SERIES_KEY_ATTRIBUTE;
		} else if(currentPosition == DATA_POSITION.OBSERVATION) {
			currentPosition = DATA_POSITION.OBSERVATION_ATTRIBUTE;
		} else if(currentPosition == DATA_POSITION.GROUP_KEY) {
			currentPosition = DATA_POSITION.GROUP_KEY_ATTRIBUTE;
		} else if(currentPosition == DATA_POSITION.DATASET) {
			currentPosition = DATA_POSITION.DATASET_ATTRIBUTE;
		}
		for(String value: values) {
			if (attributes == null) {
				attributes = new HashMap<>();
			}
			if (multiValueComponentVues != null && multiValueComponentVues.containsKey(id)) {
				multiValueComponentVues.get(id).add(value);
			} else {
				if (attributes.containsKey(id)) {
					//multivalue
					if (multiValueComponentVues == null) {
						multiValueComponentVues = new HashMap<>();
					}
					CollectionUtil.addToMappedSet(multiValueComponentVues, id, attributes.get(id));
					CollectionUtil.addToMappedSet(multiValueComponentVues, id, value);
					attributes.remove(id);
				} else {
					attributes.put(id, value);
				}
			}
		}

	}

	@Override
	public void writeMultilingualAttributeValue(IMultilingualKeyValue complexAttribute) {
		if (currentPosition != null) {
			switch (currentPosition) {
			case SERIES_KEY:
				currentPosition = DATA_POSITION.SERIES_KEY_ATTRIBUTE;
				break;
			case OBSERVATION:
				currentPosition = DATA_POSITION.OBSERVATION_ATTRIBUTE;
				break;
			case GROUP_KEY:
				currentPosition = DATA_POSITION.GROUP_KEY_ATTRIBUTE;
				break;
			case DATASET:
				currentPosition = DATA_POSITION.DATASET_ATTRIBUTE;
				break;
			default:
				break;
			}
		}
		if(complexAttributes == null) {
			complexAttributes = new ArrayList<>();
		}
		complexAttributes.add(complexAttribute);
	}

	private List<KeyValue> buildAttributes() {
		int length = attributes != null ? attributes.size() : 0;
		if(multiValueComponentVues != null) {
			length += multiValueComponentVues.size();
		}
		if(length == 0) {
			return Collections.emptyList();
		}
		List<KeyValue> returnAttributes = new ArrayList<>(length);
		if(attributes != null) {
			for(String key : attributes.keySet()) {
				returnAttributes.add(KeyValueImpl.getInstance(key, attributes.get(key)));
			}
		}
		if(multiValueComponentVues != null) {
			for(String key : multiValueComponentVues.keySet()) {
				String[] values = CollectionUtil.toArray(multiValueComponentVues.get(key));
				returnAttributes.add(KeyValueImpl.getInstance(key, values));
			}
		}
		return returnAttributes;
	}


	@Override
	public void writeObservation(String dimensionId, String dimensionValue, List<KeyValue> measures, AnnotationBean... annotations) {
		checkClosed();
		flushDataset();
		currentPosition = DATA_POSITION.OBSERVATION;
		flushKey();
		flushObs();
		this.obsDimId = dimensionId;
		this.obsDimValue = dimensionValue;
		this.obsValues = measures;
		this.currentAnnotations = annotations;
		flushObsRequired = true;
	}

	/**
	 * Informs the writer that there was an error, the exception handler may attempt to close this writer, which may not be
	 * desireable in some cases
	 */
	public void terminateWriter() {
		this.isError = true;
	}

	/**
	 * This writer has terminated with an error
	 * @return
	 */
	public boolean isError() {
		return isError;
	}

	public boolean isClosed() {
		return isClosed;
	}

	@Override
	public void close(FooterMessage... footer) {
		if(isClosed || isError) {
			return;
		}
		isClosed = true;
		flushDataset();
		flushKey();
		flushObs();
		seriesObsDataWriterEngine.close(footer);
	}


	protected void clearCurrentKeys() {
		key = new ArrayList<>();
		attributes = null;
		multiValueComponentVues = null;
		groupName = null;
		obsValues = null;
		flushDatasetRequired = false;
		flushObsRequired = false;
		flushKeyRequired = false;
		currentAnnotations = null;
	}

	private void checkClosed() {
		if (isClosed) {
			throw new RuntimeException("Data Writer has already been closed and can not have any more information written to it!");
		}
	}

	enum DATA_TYPE_REPRESENTATION {
		FLAT,
		TIME_SERIES,
		CROSS_SECTIONAL;

		public static DATA_TYPE_REPRESENTATION getDataType(String dimensionAtObservation) {
			if (dimensionAtObservation.equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				return DATA_TYPE_REPRESENTATION.TIME_SERIES;
			}

			if (dimensionAtObservation.equals(DatasetStructureReferenceBean.ALL_DIMENSIONS)) {
				return FLAT;
			}
			return DATA_TYPE_REPRESENTATION.CROSS_SECTIONAL;
		}
	}
}