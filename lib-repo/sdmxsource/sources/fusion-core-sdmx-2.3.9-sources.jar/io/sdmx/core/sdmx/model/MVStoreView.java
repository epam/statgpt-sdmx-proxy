package io.sdmx.core.sdmx.model;

/**
 * Interface defining the methods needed to retrieve data from an instance of
 * MVStoreDatasetStorage according to some defined view.
 */
@Deprecated //see new model
public interface MVStoreView {

//  /**
//   * Return a copy of this view
//   */
//  MVStoreView getCopy();
//
//  /**
//   * Return the dataset count
//   */
//  int getDatasetCount();
//
//  /**
//   * Return the global header
//   */
//  HeaderBean getHeader();
//
//  /**
//   * Return the header for the dataset with the given index
//   */
//  DatasetHeaderBean getDatasetHeader(int dsIndex);
//
//  /**
//   * Return the dataset action for the dataset with the given index
//   */
//  default DATASET_ACTION getDatasetAction(int dsIndex) {
//    DatasetHeaderBean dsHeader = getDatasetHeader(dsIndex);
//    DATASET_ACTION action = (dsHeader == null) ? null : dsHeader.getAction();
//
//    if (action == null) {
//      HeaderBean header = getHeader();
//
//      action = (header == null) ? null : header.getAction();
//    }
//
//    return action;
//  }
//
//  /**
//   * Return the provision agreement for the dataset with the given index
//   */
//  ProvisionAgreementBean getProvisionAgreement(int dsIndex);
//
//  /**
//   * Return the dataflow for the dataset with the given index
//   */
//  DataflowBean getDataflow(int dsIndex);
//
//  /**
//   * Return the datastructure for the dataset with the given index
//   */
//  DataStructureBean getDataStructure(int dsIndex);
//
//  /**
//   * Return the attributes for the dataset with the given index
//   */
//  List<KeyValue> getDatasetAttributes(int dsIndex);
//
//  /**
//   * Return an iterator on keyables for the dataset with the given index
//   */
//  Iterator<Integer> getKeyableIterator(int dsIndex);
//
//  /**
//   * Return the keyable with the given indexes
//   */
//  Keyable getKeyable(int dsIndex, Integer kIndex);
//
//  /**
//   * Return an iterator on observations for the keyable with the given index
//   */
//  Iterator<ObsPos> getObservationIterator(int dsIndex, Integer kIndex);
//
//  /**
//   * Return the observation for the given index
//   */
//  Observation getObservation(int dsIndex, ObsPos obsPos);
}
