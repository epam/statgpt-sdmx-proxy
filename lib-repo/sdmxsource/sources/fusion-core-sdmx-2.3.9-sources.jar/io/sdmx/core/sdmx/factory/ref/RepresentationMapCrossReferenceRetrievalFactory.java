package io.sdmx.core.sdmx.factory.ref;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.regex.RegexUtil;
import io.sdmx.utils.sdmx.xs.WeakReferenceBean;

public class RepresentationMapCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory, IFusionSingleton {
	private static RepresentationMapCrossReferenceRetrievalFactory INSTANCE;


	public static RepresentationMapCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new RepresentationMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return IRepresentationMapBean.class;
	}

	public static RepresentationMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		IRepresentationMapBean representationMap = (IRepresentationMapBean)maintBean;
		
		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();
		List<IRepresentationMapRefBean> fromRef = representationMap.getSourceRef();
		
		List<CodelistBean> referencedCodelists = new ArrayList<>();
		
		boolean hasCodelist = false;
		for(IRepresentationMapRefBean ref : fromRef) {
			CodelistBean codelist = null;
			if(ref.hasEnumerationRef() && ref.getEnumerationRef().getTargetReference() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
				codelist = retrievalManager.getBean(ref.getEnumerationRef().getReference().toType(CodelistBean.class));
			}
			if(!hasCodelist) {
				hasCodelist = codelist != null;
			}
			referencedCodelists.add(codelist);
		}
		// DEV-2294: Even though there are no source codelists, still need to check the targets
		/*
		if(!hasCodelist) {
			return returnReferences;
		}
		*/
		
		for(IMappedRelationshipBean mappedValue : representationMap.getMappedValues()) {
			int i=0;
			for(IMappedValueBean source : mappedValue.getSourceValue()) {
				if(source.isRegEx() || source.getStartIndex() > 0 || source.getEndIndex() > 0) {
					CodelistBean cl = referencedCodelists.get(i);
					if(cl != null) {
						IdentifiableBean parent = source.getIdentifiableParent();
						int startIdx = source.getStartIndex();
						int endIdx = source.getEndIndex();
						for(CodeBean code : cl.getItems()) {
							String codeId = code.getId();
							if(startIdx > 0 || endIdx > 0) {
								if(endIdx > 0) {
									//Remember start index is either set, or defaulted to 0
									int end = codeId.length() < endIdx ? codeId.length() : endIdx;
									codeId = codeId.substring(startIdx, end);
								} else {
									//we know start index is greater then 0, but end index is not
									codeId = codeId.substring(startIdx);
								}
							}
							if(source.isRegEx()) {
								Pattern p = source.getPattern();
								if(p.matcher(codeId).matches()) {
									returnReferences.add(new WeakReferenceBean<>(parent, false, code.getURN()));
								}
							} else if(source.getValue().equals(codeId)){
								returnReferences.add(new WeakReferenceBean<>(parent, false, code.getURN()));
							}
						}
					} else {
						// DEV-2294: Weak references may also need to be added for coded targets
						for(IRepresentationMapRefBean ref : representationMap.getTargetRef()) {
							CodelistBean codelist = null;
							if(ref.hasEnumerationRef() && ref.getEnumerationRef().getTargetReference() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
								codelist = retrievalManager.getBean(ref.getEnumerationRef().getReference().toType(CodelistBean.class));
							}
							if (codelist != null) {
								analyseCodelistAddingWeakReferences(codelist, returnReferences, source, mappedValue);
							}
						}
					}
				}
				i++;
			}
		}
		return returnReferences;
	}

	/**
	 * The target is a codelist so check to see if it has any Capture Groups which could cause further weak references to be added to the set of returnReferences
	 * If the target is coded and contains a capture group:
	 * - Create a new RegEx based on the input of those capture groups
	 *   e.g. if the output Regex was:  \1_X_\2
	 *   this could become:       ([A-Z])_X_([0-9{3}])
     * - Run the new Regex against the coded list
	 * - Any codes that match need to be added as weak references
	 * @param codelist
	 * @param returnReferences
	 * @param source
	 * @param mappedValue
	 */
	private void analyseCodelistAddingWeakReferences(CodelistBean codelist, Set<ICrossReferenceBean<?>> returnReferences, IMappedValueBean source, IMappedRelationshipBean mappedValue) {
		List<String> targetValue = mappedValue.getTargetValue();
		for (String val : targetValue) {
			// Split the Source RegEx into component Parts
			List<String> groupList = RegexUtil.obtainGroups(source.getValue());
			if (groupList.isEmpty()) {
				continue;
			}
			
			// Replace the groups in the target RegEx
			val = RegexUtil.replaceCaptureGroups(val, CollectionUtil.toArray(groupList));
			
			// Apply the new RegEx against each of the codes in the target codelist and add references to those it matches
			Pattern p = Pattern.compile(val);
			for(CodeBean code:  codelist.getItems()) {
				Matcher matcher = p.matcher(code.getId());
				if (matcher.matches()) {
					returnReferences.add(new WeakReferenceBean(source.getIdentifiableParent(), false, code.getURN()));
				}
			}
		}
	}
}
