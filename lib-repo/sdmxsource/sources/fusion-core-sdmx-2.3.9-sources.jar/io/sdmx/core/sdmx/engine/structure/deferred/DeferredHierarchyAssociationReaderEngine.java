package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.codelist.HierarchyAssociationBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link HierarchyAssociationBeanDeferred}
 */
public class DeferredHierarchyAssociationReaderEngine extends AbstractDeferredStructureReaderEngine<HierarchyAssociationBean> {
    private static DeferredHierarchyAssociationReaderEngine INSTANCE;
    
    private DeferredHierarchyAssociationReaderEngine() {
        super(HierarchyAssociationBean.class);
    }
    
    public static DeferredHierarchyAssociationReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredHierarchyAssociationReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<HierarchyAssociationBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyAssociationBeanDeferred(bean, loader);
    }

}
