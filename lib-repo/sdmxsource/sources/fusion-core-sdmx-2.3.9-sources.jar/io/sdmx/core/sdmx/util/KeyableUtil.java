package io.sdmx.core.sdmx.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.data.Keyable;

public class KeyableUtil {

	
	 /**
	  * Return the list of group keys generated from the given keyable dimension
	  * values
	  */
	 public static List<String> getGroupKeys(Keyable keyable) {
		 DataStructureBean dsb = keyable.getDataStructure();
		 List<GroupBean> dsGroups = dsb.getGroups();
		 List<String> dsDims = dsb.getDimensionIds();
		 String key = keyable.getShortCode();
		 String[] dimVals = key.split(":");
		 List<String> out = new ArrayList<>();

		 if (keyable.isSeries()) { // a match for each group
			 for (GroupBean gb: dsGroups)
				 out.add(buildKey(dimVals, gb.getDimensionRefs(), dsDims));
		 } else if (dsGroups.size() > 1) { // some groups might not match
			 String kGroupId = keyable.getGroupName();
			 GroupBean kgb = dsb.getGroup(kGroupId);
			 List<String> kgbDims = kgb.getDimensionRefs();

			 for (GroupBean gb: dsGroups)
				 if (!kGroupId.equals(gb.getId())) {
					 List<String> gbDims = gb.getDimensionRefs();

					 if (kgbDims.containsAll(gbDims)) {
						 out.add(buildKey(dimVals, gbDims, dsDims));
					 }
				 }
		 }

		 return out;
	 }
	 

	 /**
	  * Build the group key obtained using dimension values from dimVals for the
	  * subset of dimensions given by gbDims (dsDims is the full set of
	  * dimensions for the data structure).
	  */
	 private static String buildKey(String[] dimVals,
			 List<String> gbDims,
			 List<String> dsDims) {
		 StringBuffer sb = new StringBuffer();
		 int i = 0;

		 for (String dimId: dsDims) {
			 if (i > 0)
				 sb.append(":");

			 if (gbDims.contains(dimId))
				 sb.append(dimVals[i]);

			 i++;
		 }

		 return sb.toString();
	 }

	 
}
