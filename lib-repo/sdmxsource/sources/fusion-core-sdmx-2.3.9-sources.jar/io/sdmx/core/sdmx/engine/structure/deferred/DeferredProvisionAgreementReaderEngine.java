package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.im.beans.registry.ProvisionAgreementBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ProvisionAgreementBeanDeferred}
 */
public class DeferredProvisionAgreementReaderEngine extends AbstractDeferredStructureReaderEngine<ProvisionAgreementBean> {
    private static DeferredProvisionAgreementReaderEngine INSTANCE;
    
    private DeferredProvisionAgreementReaderEngine() {
        super(ProvisionAgreementBean.class);
    }
    
    public static DeferredProvisionAgreementReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredProvisionAgreementReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ProvisionAgreementBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ProvisionAgreementBeanDeferred(bean, loader);
    }

}
