package io.sdmx.core.sdmx.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.core.sdmx.model.CrossReferenceLookupTable;
import io.sdmx.utils.core.regex.RegexUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;

public class XsRefUtil {

	/**
	 * @param removeMaintUrns a set of maintainable URNs to remove
	 * @return A copy with the maintainables removed
	 */
	public static ICrossReferenceLookupTable removeMaintainables(ICrossReferenceLookupTable existingTable, Set<IURNMaintainable<?>> removeMaintUrns) {
		Set<IMaintainableReferences> maintDirectReferences = existingTable.getMaintDirectReferences();
		Set<IMaintainableReferences> maintIndirectReferences = existingTable.getMaintIndirectReferences();
		Set<IMaintainableReferences> copyToDirectReferences = new HashSet<>(maintDirectReferences.size());
		Set<IMaintainableReferences> copyToIndirectReferences = new HashSet<>(maintIndirectReferences.size());
		
		copy(maintDirectReferences, copyToDirectReferences, removeMaintUrns);
		copy(maintIndirectReferences, copyToIndirectReferences, removeMaintUrns);
		
		return new CrossReferenceLookupTable(copyToDirectReferences, copyToIndirectReferences);
	}
	
	private static void copy(Set<IMaintainableReferences> source, Set<IMaintainableReferences> target, Set<IURNMaintainable<?>> ignoreUrns) {
		for(IMaintainableReferences mRef : source) {
			if(!ignoreUrns.contains(mRef.getMaintURN())) {
				target.add(mRef);
			}
		}
	}
	/**
	 * Concept references (Measure Dimension) or Code References (normal Dimension)
	 *
	 * @param refFrom
	 * @param returnReferences
	 * @param representationRef
	 * @param codeIds
	 */
	public static void addRepresentationReferences(MaintainableBean refFrom, 
												   Set<ICrossReferenceBean<?>> returnReferences,  
												   ICrossReferenceBean<?> representationRef, 
												   Collection<String> codeIds,
												   SdmxBeanRetrievalManager retrievalManager) {
		IURNSingle<?> repUrn = representationRef.getReference();
		ISDMXStructureType<?,?> refType;
		
		ISDMXStructureType<?, ?> referencedStructureType = repUrn.getStructureType();
		if(referencedStructureType == StructureTypes.getMaintStructureType(ConceptSchemeBean.class)) {
			refType = StructureTypes.getAnyStructureType(ConceptBean.class);
		} else if(referencedStructureType == StructureTypes.getMaintStructureType(CodelistBean.class)) {
			refType = StructureTypes.getAnyStructureType(CodeBean.class);
		}  else if(referencedStructureType == StructureTypes.getMaintStructureType(ValueListBean.class)) {
			//value list does not reference the item as it is not identifiable
			IndirectReferenceBean<?> vlRef = IndirectReferenceBean.weakReference(refFrom, repUrn);
			returnReferences.add(vlRef);
			return;
		} else {
			throw new SdmxNotImplementedException("Constraint constraining: "+repUrn.getStructureType().getUrnClass());
		}
		
		//Codelist or Concept Scheme
		ItemSchemeBean<?> itemScheme = null;
		for(String codeId : codeIds) {
			if(!codeId.contains("%")) {
				IndirectReferenceBean<?> codeRef = IndirectReferenceBean.strongReference(refFrom, repUrn, refType, codeId);  //TODO would his be a fuzzy ref?
				returnReferences.add(codeRef);
			} else if(retrievalManager != null) {
				if(itemScheme == null) {
					itemScheme = retrievalManager.getBean(repUrn.toType(ItemSchemeBean.class));
				}
				if(itemScheme != null) {
					Pattern p = RegexUtil.wildcardToRegEx(codeId, "%");
					for(ItemBean item : itemScheme.getItems()) {
						if(p.matcher(item.getId()).matches()) {
							IndirectReferenceBean<?> codeRef = IndirectReferenceBean.weakReference(refFrom, repUrn, refType, item.getId());
							returnReferences.add(codeRef);
						}
 					}
				}
			}
		}
	}
	
	public static <T extends MaintainableBean> T getMaintainableBean(SdmxBeanRetrievalManager retrievalManager, Class<T> structureType, ICrossReferenceBean<?> ref) {
		T structure = retrievalManager.getBean(ref.getReference().toType(structureType));
		if(structure == null) {
			throw new CrossReferenceException(ref);
		}
		return structure;
	}
}
