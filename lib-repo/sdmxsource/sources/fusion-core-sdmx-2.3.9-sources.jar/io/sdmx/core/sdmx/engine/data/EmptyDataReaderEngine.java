package io.sdmx.core.sdmx.engine.data;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.im.data.DatasetAttributes;

public class EmptyDataReaderEngine implements DataReaderEngine {
	private static final EmptyDataReaderEngine INSTANCE = new EmptyDataReaderEngine();
	
	public static EmptyDataReaderEngine getInstance() {
		return INSTANCE;
	}

	protected EmptyDataReaderEngine() {}

	@Override
	public FormatDetails getFormatDetails() {
		return null;
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return null;
	}

	@Override
	public DataflowBean getDataFlow() {
		return null;
	}

	@Override
	public DataStructureBean getDataStructure() {
		return null;
	}

	@Override
	public int getDatasetPosition() {
		return -1;
	}

	@Override
	public int getKeyablePosition() {
		return -1;
	}

	@Override
	public int getObsPosition() {
		return -1;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		return false;
	}

	@Override
	public void reset() {}

	@Override
	public HeaderBean getHeader() {
		return null;
	}

	@Override
	public DataReaderEngine createCopy() {
		return null;
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return null;
	}

	@Override
	public IDatasetAttributes getDatasetAttributes() {
		return DatasetAttributes.EMPTY_ATTRIBUTES;
	}

	@Override
	public Keyable getCurrentKey() {
		return null;
	}

	@Override
	public Observation getCurrentObservation() {
		return null;
	}

	@Override
	public boolean moveNextObservation() {
		return false;
	}

	@Override
	public boolean moveNextKeyable() {
		return false;
	}

	@Override
	public List<FooterMessage> close() {
		return Collections.emptyList();
	}
}
