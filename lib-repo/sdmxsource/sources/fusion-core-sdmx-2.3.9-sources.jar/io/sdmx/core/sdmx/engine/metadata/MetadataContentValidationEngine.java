package io.sdmx.core.sdmx.engine.metadata;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.exception.ExceptionHandler;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IMetadatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.util.TextFormatValidationUtil;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * Validates the content of a metadata set to ensure it conforms to the MSD
 */
public class MetadataContentValidationEngine extends AbstractMetadataValidationEngine {
	
	public MetadataContentValidationEngine(SdmxBeanRetrievalManager beanRetrievalManager) {
		super(beanRetrievalManager);
	}

	@Override
	protected void validate(IReportedMetadataSetBean mds, IMetadatasetStructures mdsStructures) {
		MetadataStructureDefinitionBean msd = mdsStructures.getMetadataStructure();
		MetadataReportExHandler exHandler = new MetadataReportExHandler();
		validateAtttributes(exHandler, null, null, msd, mds.getAttributes(), msd.getMetadataAttributes());
	}
	
	private void validateAtttributes(MetadataReportExHandler exHandler, 
									 String parentId, 
									 Map<String, ConceptSchemeBean> concpetSchemes,
									 MetadataStructureDefinitionBean msd, 
									 List<IReportedMetadataAttributeBean> reportedAttributes, 
									 List<MetadataAttributeBean> attributeDefinitions) {
		Map<String, List<IReportedMetadataAttributeBean>> reportedAttributeById = new HashMap<>();
		
		for(IReportedMetadataAttributeBean ma : reportedAttributes) {
			CollectionUtil.addToMappedList(reportedAttributeById, ma.getId(), ma);
		}
		
		Map<String, MetadataAttributeBean> attributeDefinitionsById = attributeDefinitions.stream().collect(Collectors.toMap(e-> e.getId(), e->e));
		
		//Check Min occurs
		for(MetadataAttributeBean attrDef : attributeDefinitions) {
			int minOccurs = attrDef.getMinOccurs();
			if(minOccurs > 0) {
				List<IReportedMetadataAttributeBean> reportedAttributes4Id = reportedAttributeById.get(attrDef.getId());
				int reportedTimes = reportedAttributes4Id == null ? 0 :  reportedAttributes4Id.size();
				if(reportedTimes < minOccurs) {
					throw new SdmxSemmanticException("Metadata Attribute '"+attrDef.getFullIdPath(false)+"' exected to be reported a minimum of "+minOccurs+" time(s).  Attribute reported "+reportedTimes+" times");
				}
			}
		}
		
		for(String attrId : reportedAttributeById.keySet()) {
			String fullId = parentId == null ? attrId : parentId+"."+attrId;
			MetadataAttributeBean attrDef = attributeDefinitionsById.get(attrId);
			if(attrDef == null) {
				throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'.  Attribute is not defined in Metadata Structure '"+msd.getShortURN()+"'");
			}
			
			List<IReportedMetadataAttributeBean> reportedAttributes4Id = reportedAttributeById.get(attrId);
			if(reportedAttributes4Id.size() > attrDef.getMaxOccurs()) {
				throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'. Attribute can not be reported more then "+attrDef.getMaxOccurs()+" times");
			}
			
			for(IReportedMetadataAttributeBean reportedAttr : reportedAttributes4Id) {
				exHandler.fullId = fullId;
				validate(exHandler, concpetSchemes, msd, reportedAttr, attrDef);
				if(reportedAttr.getAttributes().size() > 0) {
					validateAtttributes(exHandler, fullId, concpetSchemes, msd, reportedAttr.getAttributes(), attrDef.getMetadataAttributes());
				}
			}
		}
	}
	
	private void validate(	MetadataReportExHandler exHandler, 
							Map<String, ConceptSchemeBean> concpetSchemes,
							MetadataStructureDefinitionBean msd, 
							IReportedMetadataAttributeBean reportedAttribute,
							MetadataAttributeBean attrDef) {
		String fullId = exHandler.fullId;
		if(attrDef.getPresentational() == TERTIARY_BOOL.TRUE) {
			if(!reportedAttribute.isPresentational()) {
				throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'. Attribute is presentational and should not report any text");
			}
			return;
		}
		
		String simpleValue = reportedAttribute.getValue();
		TextTypeBean structuredValue = reportedAttribute.getStructuredValue();
		if(simpleValue == null && structuredValue == null) {
			throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'. Attribute is not presentational and should report some content");
		}
		TextFormatBean tf = attrDef.getTextFormat();
		ICrossReferenceBean<? extends EnumeratedListBean> representationRef = attrDef.getEnumeratedRepresentation();
		if(tf == null && representationRef == null) {
			if(concpetSchemes == null) {
				concpetSchemes = new HashMap<>();
			}
			ConceptBean concept = getConcept(attrDef, concpetSchemes);
			tf = concept.getTextFormat();
			representationRef = concept.getEnumeratedRepresentation();
		}
		if(tf != null) {
			if(simpleValue != null) {
				TextFormatValidationUtil.validateTextFormat(tf, attrDef, simpleValue, exHandler);
			} else if(structuredValue != null) {
				if(tf.getMultiLingual() != TERTIARY_BOOL.TRUE) {
					throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'.  Attribute is not defined as supporting multilingual text in Metadata Structure '"+msd.getShortURN()+"'");
				}
				for(TextTypeWrapper tt : structuredValue.getText()) {
					TextFormatValidationUtil.validateTextFormat(tf, attrDef, tt.getValue(), exHandler);
				}
			} 
		}
		if(representationRef != null) {
			EnumeratedListBean<?> enumList = getBeanRetrievalManager().getBean(representationRef.getReference());
			if(enumList == null) {
				throw new CrossReferenceException(representationRef);
			}
			if(simpleValue != null) {
				if(enumList.getItemById(simpleValue) == null) {
					throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'.  Value '"+simpleValue+"' is not defined in "+enumList.getStructureType().getType()+" "+enumList.getShortURN());
				}
			} else {
				//structuredValue is not null, as previous check simpleValue and structureValue are not both null
				throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'. Expecting a Simple Value which corresponds to item in "+enumList.getStructureType().getType()+" "+enumList.getShortURN());
			}
		}
	}
	
	private ConceptBean getConcept(MetadataAttributeBean attrDef, Map<String, ConceptSchemeBean> concpetSchemes) {
		//Get From Concept
		//Check the Concept
		ICrossReferenceBean<ConceptBean> conceptRef = attrDef.getConceptRef();
		String conceptSchemeURN = conceptRef.getReference().getMaintainableURN().getURN();
		ConceptSchemeBean cs = concpetSchemes != null ? concpetSchemes.get(conceptSchemeURN) : null;
		ConceptBean concept = null;
		if(cs == null) {
			concept = getBeanRetrievalManager().getBean(conceptRef.getReference());
			if(concept == null) {
				throw new CrossReferenceException(conceptRef);
			}
			if(concpetSchemes == null) {
				concpetSchemes = new HashMap<>();
			}
			concpetSchemes.put(conceptSchemeURN, concept.getMaintainableParent());
		} else {
			concept = cs.getItemById(attrDef.getConceptRef().getReference().getFullIdentifiableId());
		}
		if(concept == null) {
			throw new CrossReferenceException(conceptRef);
		}
		return concept;
	}
 	
	private class MetadataReportExHandler implements ExceptionHandler {
		private String fullId;


		@Override
		public void handleException(Throwable ex) throws ErrorLimitException {
			throw new SdmxSemmanticException("Illegal Metadata Attribute '"+fullId+"'. "+ ex.getMessage());
		}
		
	}
 }
