package io.sdmx.core.sdmx.api.factory.data;

import io.sdmx.api.format.IFormatFactory;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.data.DataFormat;

/**
 * Each DataFormatFactory is responsible for returning a DataFormat based on a Request, if it understands what the request
 * is asking for, this factory  returns null if the request is asking for a data format not supported by this factory
 */
public interface DataFormatFactory extends IFormatFactory<DataFormat> {
	
	/**
	 * Returns the data format if it understands the contents of the source data, otherwise returns null
	 * @param sourceData
	 * @return DataFormat or null if this factory does not understand the format of the source data
	 */
	DataFormat getDataFormat(ReadableDataLocation sourceData);
	
	
}
