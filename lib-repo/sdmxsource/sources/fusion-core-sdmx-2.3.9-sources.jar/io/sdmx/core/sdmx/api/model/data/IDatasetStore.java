package io.sdmx.core.sdmx.api.model.data;

import java.util.Iterator;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;

/**
 * Represents a store of for a given dataset which is either in memory or very close to memory such that information can be
 * accessed by position
 * 
 * In this interface the dataset can be thought of more as a file of data where the position of the information is preserved, as opposed to a database
 * which is more useful to get information by query filters. 
 */
public interface IDatasetStore {
	
	/**
	 * @return the dataset header
	 */
	DatasetHeaderBean getHeader();
	
	/**
	 * @return not null - structures for this dataset
	 */
	IDatasetStructures getStructures();
	
	/**
	 * @return not null, immutable list of dataset annotations
	 */
	IDatasetAttributes getDatasetAttributes();

	/**
	 * @return not null, immutable list of dataset annotations
	 */
	List<AnnotationBean> getDatasetAnnotations();
	
	/**
	 * @return the keyable at the given position, zero indexed
	 */
	Keyable getKeyable(Integer kPos);
	/**
	 * @param keyIdx
	 * @return not null, immutable list of observations for the given key index
	 */
	Iterator<Observation> getObs(int keyIdx);
	
	/**
	 * @return number of keys stored
	 */
	int getKeySize();

	/**
	 * @return number of obs for the key
	 */
	int getObsSize(int keyIdx);
	
	/**
	 * Writes the dataset attributes to this store - overwrites any previously stored
	 * @param datasetAttributes
	 */
	void writeDatasetAttributes(IDatasetAttributes datasetAttributes);
	
	/**
	 * Writes a key into this store
	 * @param keyable
	 */
	void writeKey(Keyable keyable);
	
	/**
	 * Writes the observation for the current key
	 * @param keyable
	 * @throws IllegalArgumentException if the current key was not written, or the key for the obs does not match the current key
	 */
	void writeObs(Observation obs);
	
	/**
	 * Writes the dataset annotations to this store - overwrites any previously stored
	 * @param datasetAttributes
	 */
	void writeDatasetAnnotations(List<AnnotationBean> datasetAttributes);

	
}
