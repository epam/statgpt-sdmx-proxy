package io.sdmx.core.sdmx.factory.ref;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IConceptSchemeMapBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ConceptSchemeMapCrossReferenceRetrievalFactory
		extends ItemSchemeMapCrossReferenceRetrievalFactory<IConceptSchemeMapBean, IConceptMapBean, ConceptSchemeBean, ConceptBean> {

	private static ConceptSchemeMapCrossReferenceRetrievalFactory INSTANCE;

	public static ConceptSchemeMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static ConceptSchemeMapCrossReferenceRetrievalFactory getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new ConceptSchemeMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return IConceptSchemeMapBean.class;
	}

	@Override
	protected Class<ConceptSchemeBean> getItemSchemeClass(IConceptSchemeMapBean itemSchemeMap) {
		return ConceptSchemeBean.class;
	}
}
