package io.sdmx.core.sdmx.engine.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Proxies a DataWriterEngine and prevents empty series (where there is only a series key, but no series attributes or observations) from being written.
 * Note that if the message has an action of "delete" then this proxy will output an empty series.
 */
public class PreventEmptySeriesDataWriterProxy implements DataWriterEngine {
	private DataWriterEngine proxy;
	private Map<String, String> currentKeyValues;
	private boolean alwaysOutput;
	
	public PreventEmptySeriesDataWriterProxy(DataWriterEngine proxy) {
		this.proxy = proxy;
		this.alwaysOutput = false;
		this.currentKeyValues = new HashMap<>();
	}

	@Override
	public void writeHeader(HeaderBean header) {
		this.proxy.writeHeader(header);
	}

	@Override
	public void startDataset(ProvisionAgreementBean provision, DataflowBean dataflow, DataStructureBean dataStructureBean, DatasetHeaderBean header, AnnotationBean... annotations) {
		if (header !=null && header.getAction() == DATASET_ACTION.DELETE) {
			alwaysOutput = true;
		}
		this.currentKeyValues = new HashMap<>();
		this.proxy.startDataset(provision, dataflow, dataStructureBean, header, annotations);
	}

	@Override
	public void startGroup(String groupId, AnnotationBean... annotations) {
		this.proxy.startGroup(groupId, annotations);
	}

	@Override
	public void writeGroupKeyValue(String id, String value) {
		this.proxy.writeGroupKeyValue(id, value);
	}

	@Override
	public void startSeries(AnnotationBean... annotations) {
		if (!alwaysOutput) {
			this.currentKeyValues = new HashMap<>();
		}
		this.proxy.startSeries(annotations);
	}

	@Override
	public void writeSeriesKeyValue(String id, String value) {
		if (alwaysOutput) {
			this.proxy.writeSeriesKeyValue(id, value);
		} else {
			this.currentKeyValues.put(id, value);
		}
	}

	@Override
	public void writeAttributeValue(String id, String... value) {
		flushCurrentKey();
		this.proxy.writeAttributeValue(id, value);
	}

	@Override
	public void writeMultilingualAttributeValue(IMultilingualKeyValue compKeyValue) {
		flushCurrentKey();
		this.proxy.writeMultilingualAttributeValue(compKeyValue);
	}

	@Override
	public void writeObservation(String dimensionId, String dimensionValue, List<KeyValue> measures, AnnotationBean... annotations) {
		flushCurrentKey();
		this.proxy.writeObservation(dimensionId, dimensionValue, measures, annotations);
	}
	
	private void flushCurrentKey() {
		if (ObjectUtil.validMap(currentKeyValues)) {
			currentKeyValues.forEach((k, v) -> proxy.writeSeriesKeyValue(k, v));
			currentKeyValues = null;
		}
	}

	@Override
	public void close(FooterMessage... footer) {
		currentKeyValues = null;
		this.proxy.close(footer);
	}

}
