package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.base.DataConsumerSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link DataConsumerSchemeBeanDeferred}
 */
public class DeferredDataConsumerSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<DataConsumerSchemeBean> {
    private static DeferredDataConsumerSchemeReaderEngine INSTANCE;
    
    private DeferredDataConsumerSchemeReaderEngine() {
        super(DataConsumerSchemeBean.class);
    }
    
    public static DeferredDataConsumerSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredDataConsumerSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<DataConsumerSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new DataConsumerSchemeBeanDeferred(bean, loader);
    }

}
