package io.sdmx.core.sdmx.model.data;

import java.util.Objects;

public class ObsKey {
  private final Integer keyablePosition;
  private final String dimensionValue;

  public ObsKey(Integer keyablePosition, String dimensionValue) {
    this.keyablePosition = keyablePosition;
    this.dimensionValue = dimensionValue;
  }

  public Integer getKeyablePosition() {
    return keyablePosition;
  }

  public String getDimensionValue() {
    return dimensionValue;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;

    if ((obj != null) && (getClass() == obj.getClass())) {
      ObsKey other = (ObsKey)obj;

      if (Objects.equals(getKeyablePosition(),
                         other.getKeyablePosition()) &&
          Objects.equals(getDimensionValue(),
                         other.getDimensionValue()))
        return true;
    }

    return false;
  }

  @Override
  public int hashCode() {
    return Objects.hash(getKeyablePosition(),
                        getDimensionValue());
  }

  @Override
  public String toString() {
    return "(" + keyablePosition +  ", " + dimensionValue + ")";
  }
}
