package io.sdmx.core.sdmx.engine.structure;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.api.manager.structure.MaintainableCrossReferenceRetrieverEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.WeakReferenceBean;

/**
 * Uses CrossReferenceRetrievalFactory implementations which are registered with the FusionBeanStore in order to resolve
 * all Indirect References from MaintainableBeans which have them.  This implementation provides a cache by the SdmxBeanRetrievalManager that is used in a resolution.
 */
public class MaintainableCrossReferenceRetrieverEngineImpl implements MaintainableCrossReferenceRetrieverEngine, Cache, IStructureEventListener {
	private static final Logger LOG = LoggerFactory.getLogger(MaintainableCrossReferenceRetrieverEngineImpl.class);

	private Map<SdmxBeanRetrievalManager, XSRefCache> cache = new WeakHashMap<>();

	private Map<IMaintainableStructureType<?>, CrossReferenceRetrievalFactory> factoryMap;
	
	/**
	 * Maintainable URNs which are references by one or more structures that can indirectly reference other structures
	 * We need to know, for example, if a constraint references a Code in a Codelist - and the DSD is changed to use a new Codelist
	 * that the constraint reference to the original Code is not longer valid (i.e. the ID may stay the same, but the codelist version may
	 * have changes).
	 */
	private Map<String, Set<String>> cacheInvalidationDependencies = new HashMap<>();
	boolean useCache = false;

	public MaintainableCrossReferenceRetrieverEngineImpl() {}
	
	public void setUseCache(boolean useCache) {
		this.useCache = useCache;
	}

	private CrossReferenceRetrievalFactory getFactory(MaintainableBean maint) {
		if(maint == null) {
			return null;
		}
		if(this.factoryMap == null) {
			populateFactoryMap();
		}
		return factoryMap.get(maint.getStructureClass());
	}
	
	private void populateFactoryMap() {
		Collection<CrossReferenceRetrievalFactory> factories =  FusionBeanStore.getBeans(CrossReferenceRetrievalFactory.class);
		Map<IMaintainableStructureType<?>, CrossReferenceRetrievalFactory> map = new HashMap<>(factories.size());
		for(CrossReferenceRetrievalFactory factory : factories) {
			IMaintainableStructureType<?> factoryStructure = StructureTypes.getMaintStructureType(factory.getSupportedType());
			map.put(factoryStructure, factory);
		}
		this.factoryMap = map;
	}

	@Override
	public void clearCache() {
		cache = new HashMap<>();
		cacheInvalidationDependencies = new HashMap<>();
	}

	private class XSRefCache {
		Map<String, Set<ICrossReferenceBean<?>>> crossReferenceCache = new HashMap<>();
	}
	
	@Override
	public void notifyStructureEvent(IStructureEvent event) {
		Set<String> modified = event.getModification().getAllMaintainables().stream().map(e->e.getUrn()).collect(Collectors.toSet());
		Set<String> deleted = event.getDeletions().getAllMaintainables().stream().map(e->e.getUrn()).collect(Collectors.toSet());
		modified.addAll(deleted);
		clearCache(modified);
	}

	private void clearCache(Set<String> updatedUrns) {
		Set<String> toExclude = new HashSet<>(updatedUrns);
		for(String updatedUrn : updatedUrns) {
			Set<String> cachedUrns = cacheInvalidationDependencies.get(updatedUrn);
			if(cachedUrns != null) {
				toExclude.addAll(cachedUrns);
			}
		}
		for(XSRefCache currentCache : cache.values()) {
			Map<String, Set<ICrossReferenceBean<?>>> updatedCrossReferenceCache = new HashMap<>();
			for(String urn : currentCache.crossReferenceCache.keySet()) {
				if(!toExclude.contains(urn)) {
					updatedCrossReferenceCache.put(urn, currentCache.crossReferenceCache.get(urn));
				}
			}
			currentCache.crossReferenceCache = updatedCrossReferenceCache;
		}
	}

	@Override
	public Set<ICrossReferenceBean<?>> getCrossReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintainable) {
		if (maintainable == null) {
			return null;
		}
		
		Set<ICrossReferenceBean<?>>  resolvedFuzzy = new HashSet<>();
		maintainable.getCrossReferencesFuzzy().forEach(fuzzyXS -> {
			IURN<?> ref = fuzzyXS.getReference();
			IURN<? extends MaintainableBean> maintRef = ref.getMaintainableURN();
			
			retrievalManager.getMaintainableBeans(maintRef).forEach(maint -> {
				if(ref.isMaintainableReference()) {
					resolvedFuzzy.add(new WeakReferenceBean<>(fuzzyXS.getReferencedFrom(), false, maint.getURN()));
				} else {
					maint.filter(ref).forEach(ident -> {
						resolvedFuzzy.add(new WeakReferenceBean<>(fuzzyXS.getReferencedFrom(), false, ident.getURN()));
					});
				}
			});
		});
		
		CrossReferenceRetrievalFactory factory = getFactory(maintainable);
		if(factory == null) {
			if(resolvedFuzzy.size() > 0) {
				resolvedFuzzy.addAll(maintainable.getCrossReferences());
				return resolvedFuzzy;
			}
			return new HashSet<>(maintainable.getCrossReferences());
		}
		
		XSRefCache refCache = null;
		if(useCache) {
			refCache = cache.get(retrievalManager);
			if(refCache != null) {
				Set<ICrossReferenceBean<?>> xsRefs = refCache.crossReferenceCache.get(maintainable.getUrn());
				if(xsRefs != null) {
					return xsRefs;
				}
			} else {
				refCache = new XSRefCache();
				cache.put(retrievalManager, refCache);
			}
		}
		
		Set<? extends ICrossReferenceBean<?>> directReferences = new HashSet<>(maintainable.getCrossReferences());
		Set<? extends ICrossReferenceBean<?>> indirectReferences;
		try {
			indirectReferences = factory.getIndirectReferences(retrievalManager, maintainable);
		} catch(SdmxReferenceException e) {
			//Unable to determine the indirect references because the direct references could not be resolved
			//just return the direct references and let that fail the reference checks
			return new HashSet<>(directReferences);
		}
		
		Set<ICrossReferenceBean<?>> crossReferences = new HashSet<>(indirectReferences.size() + directReferences.size());
		crossReferences.addAll(indirectReferences);
		crossReferences.addAll(directReferences);
		if(resolvedFuzzy.size() > 0) {
			crossReferences.addAll(resolvedFuzzy);
		}
		crossReferences = Collections.unmodifiableSet(crossReferences);

		if(refCache != null) {
			refCache.crossReferenceCache.put(maintainable.getUrn(), crossReferences);
			for(ICrossReferenceBean<?> ref : crossReferences) {
				String maintUrn = ref.getReference().getMaintainableURN().getURN();
				CollectionUtil.addToMappedSet(cacheInvalidationDependencies, maintUrn, maintainable.getUrn());
			}
		}
		return crossReferences;
	}

}
