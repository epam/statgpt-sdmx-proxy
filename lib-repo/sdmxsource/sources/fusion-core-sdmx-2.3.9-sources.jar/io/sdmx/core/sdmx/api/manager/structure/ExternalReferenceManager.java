package io.sdmx.core.sdmx.api.manager.structure;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Manages the retrieval of externally referenced structures.  These are determined by the isExternal attribute of a maintainable artifact being set 
 * to true, and the URI attribute containing the URI of the full artifact. 
 * <p/>
 */
public interface ExternalReferenceManager {
	/**
	 * Resolves external references, where the 'externalReference' attribute is set to 'true'.  
	 * The external reference locations are expected to be given by a URI, and the URI is expected to point to the 
	 * location of a valid SDMX document containing the referenced structure.
	 * <p/>
	 * External references can be of a different version to those that created the input StructureBeans.
	 * 
	 * @param structures containing structures which may have the external reference attribute set to `true`
	 * @param isSubstitute if set to true, this will substitute the external reference beans for the real beans
	 * @param isLenient if set to true, this will add error notations if errors occur
	 * @return a StructureBeans containing only the externally referenced beans
	 * @throw SdmxException if the external file does not pass schema or business logic validation
	 * @throw ReferenceException if the external file does not contain the referenced structure
	 */
	SdmxBeans resolveExternalReferences(SdmxBeans structures, boolean isSubstitute, boolean isLenient) throws SdmxException, CrossReferenceException;
}
