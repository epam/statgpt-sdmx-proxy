package io.sdmx.core.sdmx.error;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.exception.ExceptionHandler;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;


/**
 * Converts the handled exception to report to a ExceptionHandler
 */
public class ErrorTranslatorToExceptionHandler implements DataValidationEngineErrorHandler {
	private ExceptionHandler exHandler;
	
	public ErrorTranslatorToExceptionHandler(ExceptionHandler exHandler) {
		this.exHandler = exHandler;
	}

    @Override
    public void reportError(FusionError fe, KeyValue component) {
        this.exHandler.handleException(new SdmxSemmanticException(fe.getErrorMessage()));
    }

    @Override
    public void reportError(FusionError fe, IMultilingualKeyValue component) {
        this.exHandler.handleException(new SdmxSemmanticException(fe.getErrorMessage()));
    }
}
