package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SEMVER_PART;
import io.sdmx.api.sdmx.engine.ISemanticVersionEngine;
import io.sdmx.api.sdmx.manager.structure.ISemanticVersionManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IDirectCrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.VersionRef;

public class SemanticVersionManager implements ISemanticVersionManager {
    private static final Logger LOG = LoggerFactory.getLogger(SemanticVersionManager.class);

    private SdmxBeanRetrievalManager retrievalManager;
    private Map<IMaintainableStructureType<?>, ISemanticVersionEngine<?>> stMap;

    public SemanticVersionManager(SdmxBeanRetrievalManager retrievalManager) {
        this.retrievalManager = retrievalManager;
    }

    @Override
    public ISdmxVersion determineMinVersionChange(MaintainableBean maint) {
        LOG.debug("determine minimum version change from:"+maint.getUrn());
        ISdmxVersion version = maint.getVersion();

        //get the latest version of this major release
        IVersionRef vRef = VersionRef.getLatestMinorReference(version.getMajor(), 0);

        IURNSingle<? extends MaintainableBean> latestMinorRef = URN.builder(maint.getURN()).versionRef(vRef).buildSingle(maint.getMaintainableClass().getMaintainableType());
        LOG.debug("Get latest:"+latestMinorRef);
        MaintainableBean latestMinor = this.retrievalManager.getBean(latestMinorRef);
        if(latestMinor == null) {
            //try latest from previous major
            if(version.getMajor() > 1) {
                
            }
            return SdmxVersion.getInstance(version.getMajor(), 0, 0);
        }
        return determineMinVersionChange(latestMinor, maint);
    }

    @Override
    public ISdmxVersion determineMinVersionChange(MaintainableBean from, MaintainableBean to) {
        SEMVER_PART changeLevel = detemineChangeLevel(from, to);
        return upgradeVersion(from.getVersion(), changeLevel);
    }

    private SEMVER_PART detemineChangeLevel(MaintainableBean from, MaintainableBean to) {
        SEMVER_PART upgradePart = SEMVER_PART.PATCH;
        ISemanticVersionEngine<?> engine = getSemverEngine(from.getMaintainableClass());
        upgradePart = processGenericSemverRules(from, to);
        if(upgradePart == SEMVER_PART.MAJOR) {
            return upgradePart;
        }
        if(engine != null) {
            SEMVER_PART engineOutcome = engine.determineMinVersionChange(from, to);
            if(engineOutcome != null && upgradePart.isHigher(engineOutcome)) {
                return engineOutcome;
            }
        }
        return upgradePart;
    }

    /**
     * As the minimum version change is patch, this is returned in all situations unless there is a higher
     * version change
     * @param from
     * @param to
     * @return
     */
    private SEMVER_PART processGenericSemverRules(MaintainableBean from, MaintainableBean to) {
        //deletion of any identifiable is a major change
        Set<String> fromIdentifiables = from.getIdentifiableComposites()
                .stream()
                .map(e->e.getStructureClass().getUrnClass()+e.getFullIdPath(false))
                .collect(Collectors.toSet());
        Set<String> toIdentifiables = to.getIdentifiableComposites()
                .stream()
                .map(e->e.getStructureClass().getUrnClass()+e.getFullIdPath(false))
                .collect(Collectors.toSet());
        if(!toIdentifiables.containsAll(fromIdentifiables)) {
            return SEMVER_PART.MAJOR;
        }
        if(toIdentifiables.size() != fromIdentifiables.size()) {
            //adding a new identifiable is a minor change
            return SEMVER_PART.MINOR;
        }
        SEMVER_PART defaultPart = SEMVER_PART.PATCH;
        //process cross references rules
        if(!from.getCrossReferences().containsAll(to.getCrossReferences()) || from.getCrossReferences().size() != to.getCrossReferences().size()) {
            //Cross reference change
            Map<String, List<IURNSingle<?>>> sourceXSByProperty = new HashMap<>();
            for(IDirectCrossReferenceBean<?> xs : from.getCrossReferences()) {
                CollectionUtil.addToMappedList(sourceXSByProperty, xs.getProperty(), xs.getReference());
            }
            Map<String, List<IURNSingle<?>>> targetXSByProperty = new HashMap<>();
            for(IDirectCrossReferenceBean<?> xs : to.getCrossReferences()) {
                CollectionUtil.addToMappedList(targetXSByProperty, xs.getProperty(), xs.getReference());
            }
            Set<String> combinedSet = new HashSet<>(sourceXSByProperty.keySet());
            combinedSet.addAll(targetXSByProperty.keySet());
            
            for(String key : combinedSet) {
                List<IURNSingle<?>> fromRefs = sourceXSByProperty.get(key);
                List<IURNSingle<?>> toRefs = targetXSByProperty.get(key);
                if(fromRefs == null) {
                    fromRefs = Collections.emptyList();
                }
                if(toRefs == null) {
                    toRefs = Collections.emptyList();
                }
                //Removal of a cross reference e.g. Codelist now inherits from one less CL
                if(toRefs.size() < fromRefs.size()) {
                    return SEMVER_PART.MAJOR;
                }
                //Addition of a cross reference for this property e.g. Codelist now inherits from another CL
                if(fromRefs.size() < toRefs.size()) {
                    defaultPart = SEMVER_PART.MINOR;
                }
                
                if(!fromRefs.isEmpty() && !toRefs.isEmpty()) {
                    IURNSingle<?> ref1 = fromRefs.get(0);
                    IURNSingle<?> ref2 = toRefs.get(0);
                    if(!ref1.getAgencyId().equals(ref2.getAgencyId()) || !ref1.getMaintainableId().equals(ref2.getMaintainableId())) {
                        return SEMVER_PART.MAJOR;
                    }
                    if(!ref1.getVersion().toString().equals(ref2.getVersion().toString())) {
                        IVersionRef fromVRef = ref1.getVersion();
                        IVersionRef toVRef = ref1.getVersion();
                        if(fromVRef.isAbsolute()) {
                            ISdmxVersion fromV = ref1.getVersion().getMinVersion();
                            if(toVRef.isAbsolute()) {
                                ISdmxVersion toV = ref1.getVersion().getMinVersion();
                                //Static to Static
                                if(toV.getMajor() != fromV.getMajor()) {
                                    //major version parts changed
                                    return SEMVER_PART.MAJOR;
                                }
                                if(toV.getMinor() != toV.getMinor()) {
                                    //minor version parts changed
                                    return SEMVER_PART.MAJOR;
                                }
                            } else {
                                //static reference to semver
                                //TODO
                            }
                        } else {
                            if(toVRef.isAbsolute()) {
                                //semver to static
                                ISdmxVersion toV = ref1.getVersion().getMinVersion();
                                //TODO
                            } else {
                                //semver to semver
                                //TODO
                            }
                        }
                    }
                }
            }
        }
        return defaultPart;
    }

    private ISdmxVersion upgradeVersion(ISdmxVersion version, SEMVER_PART part) {
        switch(part) {
        case MAJOR:
            return SdmxVersion.getInstance(version.getMajor()+1, 0, 0);
        case MINOR:
            return SdmxVersion.getInstance(version.getMajor(), version.getMinor()+1, 0);
        case PATCH:
        default:
            return SdmxVersion.getInstance(version.getMajor(), version.getMinor(), version.getPatch()+1);
        }
    }

    private ISemanticVersionEngine<?> getSemverEngine(IMaintainableStructureType<?> st) {
        if(stMap == null) {
            Map<IMaintainableStructureType<?>, ISemanticVersionEngine<?>> stMap = new HashMap<>();
            for(ISemanticVersionEngine<?> engine : FusionBeanStore.getBeans(ISemanticVersionEngine.class)) {
                stMap.put(engine.getSupportedStructure(), engine);
            }
            this.stMap = stMap;
        }
        return stMap.get(st);
    }
}
