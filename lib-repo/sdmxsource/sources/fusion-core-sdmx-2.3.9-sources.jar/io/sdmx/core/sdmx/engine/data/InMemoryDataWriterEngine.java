package io.sdmx.core.sdmx.engine.data;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.model.data.InMemoryDatasetContainer;

public class InMemoryDataWriterEngine implements ISeriesObsDataWriterEngine {
	private InMemoryDatasetContainer datasetContainer;
	
	@Override
	public void writeHeader(HeaderBean header) {
		datasetContainer = new InMemoryDatasetContainer(header);
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if(datasetContainer == null) {
			datasetContainer = new InMemoryDatasetContainer(null);
		}
		datasetContainer.startDataset(structures, header, datasetAttributes, annotations);
	}
	

	public InMemoryDatasetContainer getDatasetContainer() {
		return datasetContainer;
	}

	@Override
	public void writeKey(Keyable key) {
		datasetContainer.writeKey(key);
	}

	@Override
	public void writeObservation(Observation obs) {
		datasetContainer.writeObs(obs);
	}

	@Override
	public void close(FooterMessage... footer) {}
	
}
