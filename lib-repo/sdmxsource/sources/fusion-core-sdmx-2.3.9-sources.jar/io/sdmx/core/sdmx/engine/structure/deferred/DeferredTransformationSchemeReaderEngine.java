package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.im.beans.transformation.TransformationSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link TransformationSchemeBeanDeferred}
 */
public class DeferredTransformationSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<ITransformationSchemeBean> {
    private static DeferredTransformationSchemeReaderEngine INSTANCE;
    
    private DeferredTransformationSchemeReaderEngine() {
        super(ITransformationSchemeBean.class);
    }
    
    public static DeferredTransformationSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredTransformationSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ITransformationSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new TransformationSchemeBeanDeferred(bean, loader);
    }

}
