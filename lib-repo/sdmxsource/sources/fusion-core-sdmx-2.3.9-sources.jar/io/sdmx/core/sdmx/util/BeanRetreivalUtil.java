package io.sdmx.core.sdmx.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.VersionRef;

public class BeanRetreivalUtil {
	
	
	public static <T extends MaintainableBean> T getMaintainableBean(SdmxBeanRetrievalManager brm, Class<T> type, IMaintainableRef ref) {
		IURNSingle<T> urn = URN.builder().maint(ref).buildSingle(type);
		return brm.getBean(urn);
	}

	/**
	 * Obtains a set of MaintainableBeans of type T that match the reference parameters in the MaintainableRef argument.  
	 * <p/>
	 * An empty Set will be returned if there are no matches to the query
	 * 
	 * @param structureType identifies the structure type
	 * @param ref contains the identifiers of the structures to returns, can include widcarded values (null indicates a wildcard).  
	 * @return
	 */
	public static <T extends MaintainableBean> Set<T> getMaintainableBeans(SdmxBeanRetrievalManager brm, Class<T> structureType, IMaintainableRef ref) {
		IURN<T> urn = URN.builder().maint(ref).build(structureType);
		return brm.getMaintainableBeans(urn);
	}
	
	/**
	 * Obtains a set of all MaintainableBeans of type T 
	 * <p/>
	 * An empty Set will be returned if there are no matches to the query
	 * 
	 * @param structureType identifies the structure of type to return, if argument is null or Maintainable.class then all maintainables will be returned
	 * @return
	 */
	public static <T extends MaintainableBean> Set<T> getMaintainableBeans(SdmxBeanRetrievalManager brm, Class<T> structureType) {
		IURN<T> urn = URN.builder().build(structureType);
		return brm.getMaintainableBeans(urn);
	}
	
//	/**
//	 * Obtains a MaintainableBean identified by the URN.  
//	 * 
//	 * @param <T> class to return
//	 * @param structureType return type
//	 * @param sRef a reference to one maintainable by absolute or semantic URN
//	 * @return matched maintainable, or null if no match could be found
//	 */
//	<T extends MaintainableBean> T getBean(Class<T> structureType, IURNSingle<?> sRef);
	
	


	public static AgencyBean getAgency(SdmxBeanRetrievalManager brm, String id) {
		AgencySchemeBean acySch = null;
		
		String agencyId = id;
		String agencyParentId = AgencySchemeBean.DEFAULT_SCHEME;
		if(id.contains(".")) {
			//Sub Agency, get parent Scheme
			int lastDotIdx = id.lastIndexOf(".");
			agencyParentId = id.substring(0, lastDotIdx);
			agencyId = id.substring(lastDotIdx+1);
		}
		acySch = brm.getBean(URN.builder().agencyId(agencyParentId).buildAbsolute(AgencySchemeBean.class));
		if(acySch != null) {
			for(AgencyBean acy : acySch.getItems()) {
				if(acy.getId().equals(agencyId)) {
					return acy;
				}
			}
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends MaintainableBean>  T getLatest(T maint, SdmxBeanRetrievalManager brm) {
		IURNSingle<T> semvar = (IURNSingle<T>) URN.builder(maint.getUrn()).versionRef(VersionRef.LATEST).buildSingle();
		return brm.getBean(semvar);
	}

	@SuppressWarnings("unchecked")
	public static <T extends MaintainableBean> T getMaintainableBean(ISdmxBeanRestRetrievalManager brm, Class<T> structureType, IMaintainableRef ref) {
		return (T)unpack(brm.getMaintainables(new RESTStructureQueryImpl(toRef(structureType, ref))));
	}
	
	public static <T extends MaintainableBean> T getMaintainableBean(ISdmxBeanRestRetrievalManager brm, IURNSingle<T> sRef) {
		return (T)unpack(brm.getMaintainables(new RESTStructureQueryImpl(sRef)));
	}
	
	public static MaintainableBean getMaintainableBean(ISdmxBeanRestRetrievalManager brm, IURN<?> sRef) {
		return extractFromSet(getMaintainableBeans(brm, sRef));
	}

	public static Set<MaintainableBean> getMaintainableBeans(ISdmxBeanRestRetrievalManager brm, IURN<?> sRef) {
		return brm.getMaintainables(new RESTStructureQueryImpl(sRef)).getAllMaintainables();
	}

	@SuppressWarnings("unchecked")
	public static <T extends MaintainableBean> Set<T> getMaintainableBeans(ISdmxBeanRestRetrievalManager brm, Class<T> structureType) {
		return (Set<T>)brm.getMaintainables(new RESTStructureQueryImpl(toRef(structureType, null))).getAllMaintainables();
	}

	@SuppressWarnings("unchecked")
	public static <T extends MaintainableBean> Set<T> getMaintainableBeans(ISdmxBeanRestRetrievalManager brm, Class<T> structureType, IMaintainableRef ref) {
		return (Set<T>)brm.getMaintainables(new RESTStructureQueryImpl(toRef(structureType, ref))).getAllMaintainables();
	}

	@SuppressWarnings("unchecked")
	public static <T extends MaintainableBean> Set<T> getMaintainableBeans(ISdmxBeanRestRetrievalManager brm, Class<T> structureType, IMultiMaintainableRef ref) {
		return  (Set<T>)brm.getMaintainables(new RESTStructureQueryImpl(URN.builder().maint(ref).build(structureType))).getAllMaintainables();
	}
	
	private static <T extends MaintainableBean> IURN<?> toRef(Class<T> structureType, IMaintainableRef ref) {
		return URN.builder().structure(structureType).maint(ref).build(structureType);
	}
	
	public static <T extends IdentifiableBean> Set<T> getIdentifiables(ISdmxBeanRestRetrievalManager brm, Class<T> structureType) {
		SDMX_STRUCTURE_TYPE type = SDMX_STRUCTURE_TYPE.getTypeByClass(structureType);
		if(type.isMaintainable()) {
			return (Set<T>)getMaintainableBeans(brm, type.getMaintainableInterface());
		}
		SDMX_STRUCTURE_TYPE maintainableType = type.getMaintainableStructureType();
			
		Set<T> returnSet = new HashSet<>();
		for(MaintainableBean maint : getMaintainableBeans(brm, maintainableType.getMaintainableInterface())) {
			for(IdentifiableBean ident : maint.getIdentifiableComposites()) {
				if(ident.getClass() == structureType) {
					returnSet.add((T)ident);
				}
			}
		}
		return returnSet;
	}

	public static AgencyBean getAgency(ISdmxBeanRestRetrievalManager brm, String id) {
		AgencySchemeBean acySch = null;
		
		String agencyId = id;
		String agencyParentId = AgencySchemeBean.DEFAULT_SCHEME;
		if(id.contains(".")) {
			//Sub Agency, get parent Scheme
			int lastDotIdx = id.lastIndexOf(".");
			agencyParentId = id.substring(0, lastDotIdx);
			agencyId = id.substring(lastDotIdx+1);
		}
		acySch = getMaintainableBean(brm, URN.builder().agencyId(agencyParentId).buildSingle(AgencySchemeBean.class));
		if(acySch != null) {
			for(AgencyBean acy : acySch.getItems()) {
				if(acy.getId().equals(agencyId)) {
					return acy;
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getIdentifiableBean(ISdmxBeanRestRetrievalManager brm, ICrossReferenceBean<?> crossRef, Class<T> structureType) throws CrossReferenceException {
		IdentifiableBean bean = getIdentifiableBean(brm, crossRef.getReference());
		if(structureType.isAssignableFrom(bean.getClass())) {
			return (T)bean;
		}
		throw new CrossReferenceException(crossRef);
	}
	
//	public static IdentifiableBean getIdentifiableBean(ISdmxBeanRestRetrievalManager brm, IURNSingle<? extends IdentifiableBean> ref) {
//		try { 
//			IdentifiableBean identifiableBean = getIdentifiableBean(brm, crossReferenceBean.getTargetUrn());
//			if(identifiableBean != null) {
//				return identifiableBean;
//			}
//		} catch(CrossReferenceException e) { }
//		//Catch all
//		throw new CrossReferenceException(crossReferenceBean);
//	}

	
//	public static Set<? extends IdentifiableBean> getIdentifiableBeans(ISdmxBeanRestRetrievalManager brm, IURN<?> sRef) {
//		if(sRef.isMaintainableReference()) {
//			return getMaintainableBeans(brm, sRef);
//		}
//		
//		Set<IdentifiableBean> idents = new HashSet<>();
//		for(MaintainableBean currentMaint : getMaintainableBeans(brm, sRef.getMaintainableURN().getStructureClass(), sRef)) {
//			Set<IdentifiableBean> matches = sRef.getMatches(currentMaint);
//			if(matches != null) {
//				idents.addAll(matches);
//			}
//		}
//		return idents;
//	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getIdentifiableBean(ISdmxBeanRestRetrievalManager brm, IURNSingle<? extends IdentifiableBean> sRef, Class<T> structureType) throws CrossReferenceException {
		IdentifiableBean bean = getIdentifiableBean(brm, sRef);
		if(bean == null) {
			return null;
		}
		
		if(structureType.isAssignableFrom(bean.getClass())) {
			return (T)bean;
		}
		throw new SdmxReferenceException(sRef);
	}

    public static IdentifiableBean getIdentifiableBean(ISdmxBeanRestRetrievalManager brm, IURN<?> sRef) {
		MaintainableBean maint = getMaintainableBean(brm, sRef);
		if(maint == null) {
			return null;
		}
		if(sRef.isMaintainableReference()) {
			return maint;
		}
		for(IdentifiableBean currentIdent : maint.getIdentifiableComposites()) {
			if(sRef.isMatch(currentIdent)) {
				return currentIdent;
			}
		}
		return null;
	}
	
	@SuppressWarnings("incomplete-switch")
	/**
	 * Returns the constrained structures, which are either directly or indirectly referenced by this constraint.  Example
	 * if a constraint is constraining a Data Provider, which in turn has a Provision Agreement, then this method will return
	 * the Data Provider, Provision Agreement, Dataflow, and Data Structure Definition
	 * @param constraint
	 * @return
	 */
	public static SdmxBeans getConstrainedStructures(ConstraintBean constraint, SdmxBeanRetrievalManager beanRetrievalManager) {
		SdmxBeans returnBeans = new SdmxBeansImpl();
		if(constraint.getConstraintAttachment() != null) {
			for(ICrossReferenceBean crossRef : constraint.getConstraintAttachment().getStructureReference()) {
				switch(crossRef.getTargetReference()) {
				case PROVISION_AGREEMENT :
				case DATAFLOW :
				case DSD :
					addConstrainedStructures(crossRef, returnBeans, beanRetrievalManager);
					break;
				case DATA_PROVIDER :
					IURNSingle<DataProviderSchemeBean> dpsUrn = crossRef.getReference().getMaintainableURN().toType(DataProviderSchemeBean.class);
					DataProviderSchemeBean dps = beanRetrievalManager.getBean(dpsUrn);
					returnBeans.addIdentifiable(dps);
					//Important:
					//It is important to get this from the BeanRetrievalManager and not the ProvisionRetrievalManager
					//As the ProvisionRetrievalManager relies on CrossReferecnce retrieval, which may not have been built yet (as
					//This class is responsible for aiding the building of cross references
					for(ProvisionAgreementBean currentProv : beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class))) {
						if(currentProv.getDataproviderRef().getTargetUrn().equals(crossRef.getTargetUrn())) {
							returnBeans.addIdentifiable(currentProv);
							addConstrainedStructures(currentProv.getStructureUseage(), returnBeans, beanRetrievalManager);
						}
					}
					break;
				}
			}
		}
		return returnBeans;
	}

	private static void addConstrainedStructures(ICrossReferenceBean crossRef, SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager) {
		switch(crossRef.getTargetReference()) {
		case PROVISION_AGREEMENT :
			ProvisionAgreementBean prov = getMaintainableBean(beanRetrievalManager, ProvisionAgreementBean.class, crossRef);
			crossRef = prov.getStructureUseage();  //Drop through to the next switch statement
			beans.addIdentifiable(prov);
		case DATAFLOW :
			DataflowBean flow =getMaintainableBean(beanRetrievalManager, DataflowBean.class, crossRef);
			crossRef = flow.getDataStructureRef();  //Drop through to the next switch statement
			beans.addIdentifiable(flow);
		case DSD :
			DataStructureBean dsd = getMaintainableBean(beanRetrievalManager, DataStructureBean.class, crossRef);
			beans.addIdentifiable(dsd);
		}
	}

	/**
	 * 
	 * @param retrievalManager 
	 * @param ref - Provision, Dataflow, or DSD reference
	 * @return a map of Component to a Codelist or Valuelist reference where the Component is enumerated or the Concept used by the Component is enumerated
	 */
	public static Map<ComponentBean, ICrossReferenceBean<? extends EnumeratedListBean>> getEnumeratedRepMap(SdmxBeanRetrievalManager retrievalManager, StructureReferenceBean ref) {
		IDatasetStructures dsStructures = new DatasetStructures(ref, retrievalManager);
		return getEnumeratedRepMap(retrievalManager, dsStructures.getDataStructure());
	}
	
	/**
	 * 
	 * @param retrievalManager 
	 * @param ref - Provision, Dataflow, or DSD reference
	 * @return a map of Component to a Codelist or Valuelist reference where the Component is enumerated or the Concept used by the Component is enumerated
	 */
	public static Map<ComponentBean, ICrossReferenceBean<? extends EnumeratedListBean>> getEnumeratedRepMap(SdmxBeanRetrievalManager retrievalManager, DataStructureBean dsd) {
		List<ComponentBean> components = dsd.getComponents();
		Map<ComponentBean, ConceptBean> concepts = getConcepts(retrievalManager, dsd);
		Map<ComponentBean, ICrossReferenceBean<? extends EnumeratedListBean>> returnMap = new HashMap(components.size());
		
		for(ComponentBean comp : components) {
			if(comp.hasCodedRepresentation()) {
				returnMap.put(comp, comp.getEnumeratedRepresentation());
			} else {
				ConceptBean concept = concepts.get(comp);
				if(concept != null) {
					if(concept.hasCodedRepresentation()) {
						returnMap.put(comp, concept.getEnumeratedRepresentation());
					}
				}
			}
		}
		return returnMap;
	}
	
	/**
	 * 
	 * @param retrievalManager 
	 * @param dsd
	 * 
	 * @return a map of Component to the Concept it uses
	 */
	public static Map<ComponentBean, ConceptBean> getConcepts(SdmxBeanRetrievalManager retrievalManager, DataStructureBean dsd) {
		List<ComponentBean> components = dsd.getComponents();
		Map<ComponentBean, ConceptBean> returnMap = new HashMap(components.size());
		
		Map<String, ConceptSchemeBean> csMap = new HashMap<>(3);
		for(ComponentBean comp : components) {
			ICrossReferenceBean<ConceptBean> conceptRef = comp.getConceptRef();
			String csUrn = conceptRef.getReference().getMaintainableURN().getURN();
			ConceptSchemeBean cs = csMap.get(csUrn);
			ConceptBean concept = null;
			if(cs == null) {
				concept = retrievalManager.getBean(conceptRef.getReference());
				if(concept != null) {
					csMap.put(csUrn, concept.getMaintainableParent());
				}
			} else {
				concept = cs.getItemById(conceptRef.getReference().getFullIdentifiableId());
			}
			if(concept != null) {
				returnMap.put(comp, concept);
			}
		}
		return returnMap;
	}
	
	private static <T extends MaintainableBean> T getMaintainableBean(SdmxBeanRetrievalManager retrievalManager, Class<T> structureType, ICrossReferenceBean ref) {
		IURNSingle<T> urn = ref.getReference().toType(structureType);
		T structure = retrievalManager.getBean(urn);
		if(structure == null) {
			throw new CrossReferenceException(ref);
		}
		return structure;
	}

	private static MaintainableBean unpack(SdmxBeans beans) {
		return extractFromSet(beans.getAllMaintainables());
	}
	
	/*
	 * If the set is of size 1, then returns the element in the set.
	 * Returns null if the set is null or of size 0.
	 * @throws SdmxException if the set contains more then 1 element
	 */
	private static <T extends MaintainableBean> T extractFromSet(Set<T> set) {
		if(!ObjectUtil.validCollection(set)) {
			return null;
		}
		if(set.size() == 1) {
			return (T)set.toArray()[0];
		}
		throw new SdmxException("Did not expect more then 1 structure from query, got "+set.size()+" structures.");
	}
}
