package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataErrorImpl implements DataError {
	private int dataset;
	private ERROR_POSITION position  = ERROR_POSITION.DATASET;
	private String message;
	private String errorCode;
	private KeyValue component;
	private String errorCategory;
	private List<String> shortCodes= new ArrayList<>();

	private DataErrorImpl() {}  //For static constructors

	/**
	 * For unknown categories
	 * @param th
	 */
	public DataErrorImpl(int dataset, Throwable th) {
		this.dataset = dataset;
		this.message = ErrorUtil.getErrorMessage(th);
		this.errorCategory = DataError.UNKNOWN_ERROR_CATEGORY;
		validate();
	}

	public static DataError fromKeyShortCode(String errorCategory, int dataset, FusionError fe, KeyValue component, String shortCode) {
	    DataErrorImpl returnError = new DataErrorImpl();  //Use private constructor, every other constructor makes the short codes unmodifiable
        returnError.errorCategory = errorCategory;
        returnError.dataset = dataset;
        returnError.message = fe.getErrorMessage();
        returnError.errorCode = fe.getErrorCode();
        returnError.component = component;
        returnError.shortCodes.add(shortCode);
        returnError.position = ERROR_POSITION.SERIES;
        returnError.errorCategory = errorCategory;
        returnError.validate();
        return returnError;
	}

	// TODO: Only used by test classes - remove this constructor
	public static DataError fromKeyShortCode(String errorCategory, int dataset, String message, KeyValue component, String shortCode) {
		DataErrorImpl returnError = new DataErrorImpl();  //Use private constructor, every other constructor makes the short codes unmodifiable
		returnError.errorCategory = errorCategory;
		returnError.dataset = dataset;
		returnError.message = message;
		returnError.component = component;
		returnError.shortCodes.add(shortCode);
		returnError.position = ERROR_POSITION.SERIES;
		returnError.errorCategory = errorCategory;
		returnError.validate();
		return returnError;
	}

	// TODO: Only used by test classes - remove this constructor
	public static DataError fromObsShortCode(String errorCategory, int dataset, String message, KeyValue component, String... shortCode) {
		DataErrorImpl returnError = new DataErrorImpl();  //Use private constructor, every other constructor makes the short codes unmodifiable
		returnError.errorCategory = errorCategory;
		returnError.dataset = dataset;
		returnError.message = message;
		returnError.component = component;
		for(String currentObs : shortCode) {
			returnError.shortCodes.add(currentObs);
		}
		returnError.position = ERROR_POSITION.OBSERVATION;
		returnError.errorCategory = errorCategory;
		returnError.validate();
		return returnError;
	}

	public static DataError fromObsShortCode(String errorCategory, int dataset, FusionError fe, KeyValue component, String... shortCode) {
        DataErrorImpl returnError = new DataErrorImpl();  //Use private constructor, every other constructor makes the short codes unmodifiable
        returnError.errorCategory = errorCategory;
        returnError.dataset = dataset;
        returnError.message = fe.getErrorMessage();
        returnError.errorCode = fe.getErrorCode();
        returnError.component = component;
        for(String currentObs : shortCode) {
            returnError.shortCodes.add(currentObs);
        }
        returnError.position = ERROR_POSITION.OBSERVATION;
        returnError.errorCategory = errorCategory;
        returnError.validate();
        return returnError;
    }

	/**
     * Represents an Error at the level of the dataset, as oppose to key or observation
	 * @param errorCategory
	 * @param dataset
	 * @param fe
	 * @param component
	 */
    public DataErrorImpl(String errorCategory, int dataset, FusionError fe, KeyValue component) {
        this.message = fe.getErrorMessage();
        this.errorCode = fe.getErrorCode();
        this.dataset = dataset;
        this.component = component;
        this.errorCategory = errorCategory;
        this.validate();
    }

	public DataErrorImpl(String errorCategory, int dataset, FusionError fe, KeyValue component, Keyable key) {
        this.message = fe.getErrorMessage();
        this.errorCode = fe.getErrorCode();
        this.errorCategory = errorCategory;
        this.component = component;
        if(key != null) {
            this.shortCodes.add(key.getShortCode());
            if(key.isSeries()) {
                this.position = ERROR_POSITION.SERIES;
            } else {
                this.position = ERROR_POSITION.GROUP;
            }
        }
        this.dataset = dataset;
        validate();
    }

	public DataErrorImpl(String errorCategory, int dataset, FusionError fe, IMultilingualKeyValue component, Keyable key) {
		this.message = fe.getErrorMessage();
		this.errorCode = fe.getErrorCode();
		this.errorCategory = errorCategory;
		//this.component = component;
		if(key != null) {
			this.shortCodes.add(key.getShortCode());
			if(key.isSeries()) {
				this.position = ERROR_POSITION.SERIES;
			} else {
				this.position = ERROR_POSITION.GROUP;
			}
		}
		this.dataset = dataset;
		validate();
	}

	/**
     * Represents an Error at the level of the Observation
     * @param dataset
     * @param message
     * @param obs
     */
    public DataErrorImpl(String errorCategory, int dataset, FusionError fe, KeyValue component, Observation obs) {
        this.message = fe.getErrorMessage();
        this.errorCode = fe.getErrorCode();
        this.errorCategory = errorCategory;
        this.component = component;
        if(obs != null) {
            this.shortCodes.add(obs.getShortCode());
            this.position = ERROR_POSITION.OBSERVATION;
        }
        this.dataset = dataset;
        validate();
    }


	@Override
	public int getDataset() {
		return dataset;
	}

	@Override
	public KeyValue getComponent() {
		return component;
	}

	@Override
	public String getMessage() {
		return message;
	}

	@Override
    public String getErrorCode() {
        return errorCode;
    }

	@Override
	public List<String> getShortCode() {
		return shortCodes;
	}

	@Override
	public ERROR_POSITION getErrorPosition() {
		return position;
	}

	@Override
    public String getErrorCategory() {
		return errorCategory;
	}

	/**
	 * Ensures the DataError is valid and makes listes sorted (for comparison) and immutable
	 */
	private void validate() {
		Collections.sort(shortCodes);
		shortCodes = Collections.unmodifiableList(shortCodes);  //Sort and FIX
		if(dataset < 0) {
			dataset = 0;
		}
		if(!ObjectUtil.validString(message)) {
			message = "No error message provided";
		}
		if(!ObjectUtil.validString(errorCategory)) {
			errorCategory = "Unknown";
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		String concat = "";
		sb.append("C="+errorCategory+",P="+position+",DS="+dataset+",K=");
		for(String shortCode : shortCodes) {
			sb.append(concat + shortCode);
			concat = ",";
		}
		sb.append(",Comp="+component+",M="+message);
		return sb.toString();
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DataError) {
			DataError that = (DataError) obj;
			if(that.getDataset() != this.getDataset()) {
				return false;
			}
			if(that.getErrorPosition() != this.getErrorPosition()) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getErrorCategory(), this.getErrorCategory())) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getMessage(), this.getMessage())) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getComponent(), this.getComponent())) {
				return false;
			}
			if(!ObjectUtil.equivalentCollection(that.getShortCode(), this.getShortCode())) {
				return false;
			}
			return true;
		}
		return false;
	}
}
