package io.sdmx.core.sdmx.manager.structure;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ICrossReferenceLookupTableRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.manager.structure.MaintainableCrossReferenceRetrieverEngine;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.engine.structure.CrossReferenceResolverEngineImpl;
import io.sdmx.core.sdmx.engine.structure.MaintainableCrossReferenceRetrieverEngineImpl;
import io.sdmx.core.sdmx.model.CrossReferenceLookupTable;
import io.sdmx.core.sdmx.model.ref.MaintainableReferences;
import io.sdmx.core.sdmx.model.ref.ReferenceResolution;
import io.sdmx.core.sdmx.util.XsRefUtil;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.container.URNStoreFromBRM;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.Lockable;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class InMemoryCrossReferenceControl extends Lockable implements CrossReferencedRetrievalManager,
																	   CrossReferencingRetrievalManager,
																	   ICrossReferenceLookupTableRetrievalManager,
																	   Cache  {

	private CrossReferenceResolverEngine resolverEngine;
	private SdmxBeanRetrievalManager retrievalManager;
	
	private CrossReferenceRetrievalMananger readOnly;
	private ICrossReferenceLookupTable lookupTable = CrossReferenceLookupTable.EMPTY_TABLE;  //what was used to build the InMemoryReadOnlyXSControl
	
	private IURNReferenceRetreivalManager urnIurnReferenceRetreivalManager;
	private boolean includeWeakReferences = false;
	
	
	public InMemoryCrossReferenceControl() {
		this.resolverEngine = SingletonStore.getSingleton(CrossReferenceResolverEngine.class, false);
		setUp();
	}

	public InMemoryCrossReferenceControl(SdmxBeans beans, SdmxBeanRetrievalManager retrievalManager) {  //TODO do we need both on the constructor?
		this.retrievalManager = retrievalManager;
		this.resolverEngine = SingletonStore.getSingleton(CrossReferenceResolverEngine.class, false);
		setUp();
		this.updateMaps(beans, false, false);
	}
	
	public InMemoryCrossReferenceControl(SdmxBeanRetrievalManager retrievalManager,
			boolean syncRegistrations,
			boolean syncOnStarup) {
		this.retrievalManager = retrievalManager;
		this.resolverEngine = SingletonStore.getSingleton(CrossReferenceResolverEngine.class);
		setUp();
		
		if(syncOnStarup) {
			SdmxBeans beans = getAllBeansFromBRM(syncRegistrations);
			updateMaps(beans,  false, false);
		}
	}
	
	public void includeWeakReferences(boolean bool) {
	    this.includeWeakReferences = bool;
	}
	
	private void setUp() {
		if(this.resolverEngine == null) {
			this.resolverEngine = new CrossReferenceResolverEngineImpl();
		}
		createReadOnly();
	}

	@Override
	public void clearCache() {
		lookupTable = CrossReferenceLookupTable.EMPTY_TABLE;
	}

	@Override
	public ICrossReferenceLookupTable getCrossReferenceLookupTable() {
		return this.lookupTable;
	}

	/**
	 * Performs a full replace of the references with the new container
	 * @param beans
	 * @param retMan
	 */
	public IReferenceResolution resync(boolean lienient) {
		this.clearCache();

		SdmxBeans beans = getAllBeansFromBRM(true);
		IReferenceResolution resolution = this.updateMaps(beans, lienient, false);
		return resolution;
	}
	
	private SdmxBeans getAllBeansFromBRM(boolean includeRegistrations) {
		//The ANY type is explicitly set not to include registrations in the retrieval manager (not sure why)
		SdmxBeans beans = new SdmxBeansImpl(retrievalManager.getMaintainableBeans(URN.build(MaintainableBean.class)));
		if(includeRegistrations) {
			beans.addIdentifiables(retrievalManager.getMaintainableBeans(URN.build(RegistrationBean.class)));
		}
		return beans;
	}

	/**
	 * Updates the cross references based on the new SdmxBeans container. Updates the retrieval manager as well
	 *
	 * <strong>Note</strong> this only works if beans are added, not modified or deleted
	 *
	 * @param beans
	 * @param retMan can be provided to obtain required references
	 * @param lenient - if true, will not throw exceptions for missing references, but instead return them via the API
	 * @param brm - optional, if the bean retrieval manager has changed then it can be updated for this even
	 * @return a map of missing references if lenient is true and missing references exist, otherwise will return null
	 */
	public IReferenceResolution update(SdmxBeansEvent beansEvent, boolean lenient, SdmxBeanRetrievalManager brm) {
		SdmxBeans oldBeans = beansEvent.getOldContainer();
		SdmxBeans toSync = new SdmxBeansImpl(beansEvent.getAdditions());

		Set<MaintainableBean> modifiedMaintainables = beansEvent.getModification().getAllMaintainables();
		if(modifiedMaintainables.size() > 0) {
			Map<String, MaintainableBean> previousMaintainables = SdmxCollectionUtil.maintCollectionToMap(oldBeans.getAllMaintainables());
			for(MaintainableBean modified : beansEvent.getModification().getAllMaintainables()) {
				MaintainableBean oldMaint = previousMaintainables.get(modified.getUrn());
				if(oldMaint==null || oldMaint == modified){
					//NPE defence, should not happen
					//Also defends against the system saying there was a change when the bean retreival manager says there was not, assume changed an re-calculate the references
					toSync.addIdentifiable(modified);
				} else {
				    boolean excludeWeakReferences = !includeWeakReferences ;
					MaintainableCrossReferenceRetrieverEngine xsResolver = SingletonStore.getSingleton(MaintainableCrossReferenceRetrieverEngine.class, false);
					if(xsResolver == null) xsResolver = new MaintainableCrossReferenceRetrieverEngineImpl();
					Set<ICrossReferenceBean<?>> xsRefPrev = xsResolver.getCrossReferences(this.retrievalManager, oldMaint, excludeWeakReferences, false);
					
					SdmxBeanRetrievalManager newBrm = brm == null ? this.retrievalManager : brm;
					Set<ICrossReferenceBean<?>> xsRefNew =  xsResolver.getCrossReferences(newBrm, modified, excludeWeakReferences, false);
					if(!ObjectUtil.equivalentSet(xsRefPrev, xsRefNew)) {
						toSync.addIdentifiable(modified);
					}
				}
			}
		}

		//1. Process Deletions
		this.lookupTable = deleteMaintainables(beansEvent.getDeletions().getAllMaintainables());

		if(brm != null) {
			this.retrievalManager = brm;
		}
		if(toSync.isEmpty()) {
			createReadOnly();
		}
		//2. Process Additions and Updates
		IReferenceResolution resolution = updateMaps(toSync, lenient, true);
		return resolution;
	}
	

	private ICrossReferenceLookupTable deleteMaintainables(Set<MaintainableBean> maints) {
		if(maints.isEmpty()) {
			return lookupTable;
		}
		return  XsRefUtil.removeMaintainables(lookupTable, SdmxCollectionUtil.urnsMaint(maints));
	}

	/**
	 * Performs a full replace of the references with the new container
	 * @param beans
	 * @param retMan
	 * @param lenient - if true, will not throw exceptions for missing references, but instead return them via the API
	 * @return a map of missing references if lenient is true and missing references exist, otherwise will return null
	 */
	private IReferenceResolution updateMaps(SdmxBeans beans, boolean lienient, boolean isUpdate) {
		if(this.retrievalManager == null) {
			this.retrievalManager = beans;
		}
		Set<MaintainableBean> modifiedMaintainables = beans.getAllMaintainables();
		//1. what beans have actually changed since the last sync
		if(modifiedMaintainables.isEmpty()) {
			//Nothing to update
			return new ReferenceResolution();
		}

		Set<IMaintainableReferences> maintDirectReferences = lookupTable.getMaintDirectReferences();
		Set<IMaintainableReferences> maintIndirectReferences = lookupTable.getMaintIndirectReferences();
		Set<IMaintainableReferences> copyToDirectReferences = new HashSet<>(maintDirectReferences.size() == 0 ? 30 : maintDirectReferences.size());
		Set<IMaintainableReferences> copyToIndirectReferences = new HashSet<>(maintIndirectReferences.size() == 0 ? 30 : maintIndirectReferences.size());
		
		IReferenceResolution resolution = populateMaps(beans,
				isUpdate ? 1 : 0,
				copyToDirectReferences,
				copyToIndirectReferences,
				lienient);
		
		final Set<IURNMaintainable<?>> ignoreDirectUrns = new HashSet<>();
		copyToDirectReferences.forEach(e-> {
			ignoreDirectUrns.add(e.getMaintURN());
		});
		copy(maintDirectReferences, copyToDirectReferences, ignoreDirectUrns);

		final Set<IURNMaintainable<?>> ignoreIndirectUrns = new HashSet<>();
		copyToIndirectReferences.forEach(e-> {
			ignoreIndirectUrns.add(e.getMaintURN());
		});
		copy(maintIndirectReferences, copyToIndirectReferences, ignoreIndirectUrns);

		//2. rebuild referencing maps
		this.lookupTable = new CrossReferenceLookupTable(copyToDirectReferences, copyToIndirectReferences);
		
		createReadOnly();
		
		return resolution;
	}
	
	private void createReadOnly() {
		urnIurnReferenceRetreivalManager = new InMemoryURNReferenceRetreivalManager(lookupTable);
		IURNRetrievalManager urnIurnRetrievalManager = new URNStoreFromBRM(retrievalManager);
		this.readOnly = new CrossReferenceRetrievalMananger(urnIurnRetrievalManager, retrievalManager, urnIurnReferenceRetreivalManager);
	}
	
	public IURNReferenceRetreivalManager getUrnReferenceRetreivalManager() {
		return urnIurnReferenceRetreivalManager;
	}

	private void copy(Set<IMaintainableReferences> source, Set<IMaintainableReferences> target, Set<IURNMaintainable<?>> ignoreUrns) {
		for(IMaintainableReferences mRef : source) {
			if(!ignoreUrns.contains(mRef.getMaintURN())) {
				target.add(mRef);
			}
		}
	}
	
	private IReferenceResolution populateMaps(SdmxBeans beans,
			int levelsDeep,
			Set<IMaintainableReferences> maintDirectReferences,
			Set<IMaintainableReferences> maintIndirectReferences,
			boolean lenient) {
		//NOTE The FR-1600 fix caused issue FR-2623 so has been removed
		//FR-1600 this needs to be here so this can be set to null
		//resolver.setMaintainableCrossReferenceRetrieverEngine(null);
		IReferenceResolution resolution = resolverEngine.resolveReferences(beans, true, includeWeakReferences, levelsDeep,  retrievalManager);
		populateMaps(RESOLUTION_TYPE.DIRECT, resolution, maintDirectReferences);
		populateMaps(RESOLUTION_TYPE.INDIRECT, resolution, maintIndirectReferences);
		if(!lenient && resolution.hasMissingReferences()) {
			for(IdentifiableBean missingRefFrom : resolution.getMissingReferences()) {
				for(ICrossReferenceBean<?> missingRefTo : resolution.getMissingReferences(missingRefFrom)) {
					throw new CrossReferenceException(missingRefTo);
				}
			}
		}
		return resolution;
	}

	private void populateMaps(IReferenceResolution.RESOLUTION_TYPE refType,
			IReferenceResolution resolution,
			Set<IMaintainableReferences> maintReferences) {
		//a map of maintainable URN to a set of Identifiable Compsites for that maintainable which are involved in referencing something else
		Map<IURNMaintainable<?>, Set<IdentifiableBean>> maintRefs = new HashMap<>();
		
		for(IdentifiableBean currentKey : resolution.getReferences(refType)) {
			CollectionUtil.addToMappedSet(maintRefs, currentKey.getMaintainableParent().getURN(), currentKey);
		}

		for(IURNMaintainable<?> maintURN : maintRefs.keySet()) {
			Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> identifiableReferences = new HashMap<>();
			
			//Loop through the Identifiable Composites of the Maintainables (may also include the Maintainable itself)
			for(IdentifiableBean identComposite : maintRefs.get(maintURN)) {
				Set<ICrossReferenceBeanResolved<?>> referencedIdentifiables = resolution.getReferences(identComposite, refType);
				identifiableReferences.put(identComposite.getURN(), referencedIdentifiables);
			}
			maintReferences.add(new MaintainableReferences(maintURN, identifiableReferences));
		}
	}

	
	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURN<?> sourceStructureURN,
																			 boolean includeIndirectReferences,
																			 Class<T> structures) {
		return readOnly.getCrossReferencingStructures(sourceStructureURN, includeIndirectReferences, structures);
	}
	
	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencedStructures(IURN<?> sourceStructureURN,
																			boolean includeIndirectReferences,
																			boolean fullTreeResolution,
																			Class<T> structuresOfType) {
		return readOnly.getCrossReferencedStructures(sourceStructureURN, includeIndirectReferences, fullTreeResolution, structuresOfType);
	}
	
	public void setRetrievalManager(SdmxBeanRetrievalManager retrievalManager) {
		this.retrievalManager = retrievalManager;
	}
}
