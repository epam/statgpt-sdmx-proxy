package io.sdmx.core.sdmx.api.factory.metadata;

import io.sdmx.api.format.IFormatFactory;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;

/**
 * Returns an IMetadataFormat based on analysing the headers/parameters of a request to determine what is required
 */
public interface IMetadataFormatFactory extends IFormatFactory<IMetadataFormat> {

}
