package io.sdmx.core.sdmx.manager.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.notification.Notifier;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.manager.structure.proxy.SdmxBeanRetrievalManagerProxy;

public class CachingSdmxBeanRetrievalManager extends SdmxBeanRetrievalManagerProxy implements Cache, Listener<IStructureEvent>, Notifier<IStructureEvent> {
    private static final Logger LOG = LoggerFactory.getLogger(CachingSdmxBeanRetrievalManager.class);

    private LocalCache cache = new LocalCache();
	
	private List<Listener<IStructureEvent>> listeners = new ArrayList<>();
	
	private class LocalCache {
		private Map<IURN<?>, Set<IURNMaintainable<?>>> search2Result = new HashMap<>();
		private Map<IURNMaintainable<?>, MaintainableBean> urn2Maint = new HashMap<>();
		private Map<IURNSingle<?>, MaintainableBean> urnSingle2Maint = new HashMap<>();
	}

	public CachingSdmxBeanRetrievalManager(SdmxBeanRetrievalManager proxy) {
		super(proxy);
	}

	@Override
	public void clearCache() {
		cache = new LocalCache();
	}

	@Override
	public void invoke(IStructureEvent obj) {
		clearCache();
		listeners.forEach(e-> {
			e.invoke(obj);
		});
	}
	
	@Override
	public void addListener(Listener<IStructureEvent> listener) {
		if(listener != null) {
			listeners.add(listener);
		}
	}

	@Override
	public void removeListener(Listener<IStructureEvent> listener) {
		listeners.remove(listener);
	}

	@Override
	public <T extends IdentifiableBean> T getBean(IURNSingle<T> sRef) {
		LocalCache cache = this.cache;  //take a copy of the current cache, in case it changes underneath us
		IURNSingle<? extends MaintainableBean>  maintRef = sRef.getMaintainableURN();
		MaintainableBean maint = cache.urnSingle2Maint.get(maintRef);
		
		//Find and Cache
		if(maint == null) {
			T ident = super.getBean(sRef);
			if(ident != null) {
				cache.urnSingle2Maint.putIfAbsent(maintRef, ident.getMaintainableParent());
			}
			return ident;
		}
		
		//Get From Cache
		if(sRef.isMaintainableReference()) {
			return (T)maint;
		}
		
		return (T)maint.getIdentifiableComposite(sRef);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		LocalCache cache = this.cache;  //take a copy of the current cache, in case it changes underneath us
		if(urn.getReferenceType() == REFERENCE_TYPE.ABSOLUTE) {
			MaintainableBean maint = cache.urn2Maint.get(urn);
			if(maint != null) {
				return Set.of((T)maint);
			}
		}
 		Set<IURNMaintainable<?>> result = cache.search2Result.get(urn);
		if(result == null) {
			Set<T> resultMaints = super.getMaintainableBeans(urn);
			result = resultMaints.stream().map(e->e.getURN()).collect(Collectors.toSet());
			resultMaints  = (resultMaints == null || resultMaints.isEmpty()) ? Collections.emptySet() : Collections.unmodifiableSet(resultMaints);
			
			cache.search2Result.put(urn, resultMaints.stream().map(e->e.getURN()).collect(Collectors.toSet()));
			if(resultMaints.isEmpty()) {
				cache.search2Result.put(urn, Collections.emptySet());  //TODO, do we want to record all failures forever?
			}
					
			resultMaints.forEach(maint -> { cache.urn2Maint.put(maint.getURN(), maint); } );
			return resultMaints;
		}
		Set<T> returnSet = new HashSet<>();
		result.forEach(resultUrn -> {
			MaintainableBean maint = cache.urn2Maint.get(resultUrn);
			if(maint == null) {
			    maint = getBean(resultUrn);
			}
			if(maint != null) {
				returnSet.add((T)maint);
			} else {
			    LOG.error("Missing maintainable in result set: "+resultUrn);
			}
		} );
		return returnSet;
	}

	
	
}
