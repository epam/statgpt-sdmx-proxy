package io.sdmx.core.sdmx.factory.ref;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Factory to retrieve cross-references for SDMX artifacts that are used in a VTL ruleset scheme.
 */
public class VtlRulesetSchemeCrossReferenceRetrievalFactory extends AbstractIVtlSchemeCrossReferenceFactory<IRulesetSchemeBean> {
    private static VtlRulesetSchemeCrossReferenceRetrievalFactory INSTANCE;
    
    /**
     * Get instance of VtlRulesetSchemeCrossReferenceRetrievalFactory.
     * @return instance of VtlRulesetSchemeCrossReferenceRetrievalFactory
     */
    public static VtlRulesetSchemeCrossReferenceRetrievalFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new VtlRulesetSchemeCrossReferenceRetrievalFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    /**
     * registers a instance of VtlRulesetSchemeCrossReferenceRetrievalFactory in the FusionBeanStore
     * @return instance of VtlRulesetSchemeCrossReferenceRetrievalFactory
     */
    public static VtlRulesetSchemeCrossReferenceRetrievalFactory registerInstance() {
        FusionBeanStore.registerInstance(getInstance());
        return getInstance();
    }

	public Class<? extends MaintainableBean> getSupportedType() {
		return IRulesetSchemeBean.class;
	}

	/**
     * Extracts the SDMX artifacts from a VTL ruleset scheme and detects indirect cross-references
     * @param retrievalManager - to help find indirect cross-references
     * @param maintBean - to obtain all cross-references for
     * @return mutable set of cross-references for artifacts used in the VTL ruleset scheme in addition
     * to those which are obtained from the maintBean.getCrossReferences() method
     */
    @Override
    public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
        IRulesetSchemeBean vtlRulesetSchemeBean = (IRulesetSchemeBean) maintBean;
        Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();
        for (IRulesetBean ruleset : vtlRulesetSchemeBean.getItems()) {
            List<IURN<?>> referencedArtifacts = ruleset.getReferencedArtifacts();
            addReferences(vtlRulesetSchemeBean, retrievalManager, referencedArtifacts, returnReferences);
        }
        return returnReferences;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
}
