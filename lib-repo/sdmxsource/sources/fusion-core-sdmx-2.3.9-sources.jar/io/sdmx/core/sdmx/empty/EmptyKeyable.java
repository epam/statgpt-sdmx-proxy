package io.sdmx.core.sdmx.empty;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.data.Keyable;

public class EmptyKeyable extends EmptyAttributable implements Keyable {

	@Override
	public DataStructureBean getDataStructure() {
		return null;
	}

	@Override
	public DataflowBean getDataflow() {
		return null;
	}

	@Override
	public String getShortCode() {
		return null;
	}

	@Override
	public String createShortCode(String ignoreDimension) {
		return null;
	}

	@Override
	public List<KeyValue> getKey() {
		return Collections.emptyList();
	}

	@Override
	public KeyValue getKeyValue(String dimensionId) {
		return null;
	}

	@Override
	public String getReportedValue(String dimensionId) {
		return null;
	}

	@Override
	public boolean isSeries() {
		return false;
	}

	@Override
	public String getGroupName() {
		return null;
	}
	
}
