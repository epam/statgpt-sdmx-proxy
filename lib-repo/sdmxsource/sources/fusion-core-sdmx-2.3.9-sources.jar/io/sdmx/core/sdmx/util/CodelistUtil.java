package io.sdmx.core.sdmx.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.CombinedCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.diff.Diff;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.diff.ModificationAction;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.regex.RegexUtil;

public class CodelistUtil {
	private static final Logger LOG = LoggerFactory.getLogger(CodelistUtil.class);

	/**
	 * 
	 * @param codelistA
	 * @param codelistB
	 * @return true if both codelists are not null and they both contain the same Items IDs
	 */
	public static boolean hasSameItems(CodelistBean codelistA, CodelistBean codelistB) {
		if(codelistA != null && codelistB != null &&
				codelistA.getItems().size() == codelistB.getItems().size() &&
				codelistA.getItems().containsAll(codelistB.getItems())) {
			return true;
		}
		return false;
	}
	
	/**
	 * @param codelist
	 * @param clURN
	 * @return true if the Codelist passed in extends a Codelist with the given URN
	 */
	public static boolean doesExtend(CodelistBean codelist, IURNMaintainable<CodelistBean> clURN) {
		for(ICodelistInheritanceRuleBean irBean : codelist.getInheritedCodelists()) {
			if(irBean.getCodelistRef().getReference().isMatch(clURN)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param rootCodelist
	 * @param brm
	 * @return
	 */
	public static CodelistBean buildInherited(CodelistBean rootCodelist, SdmxBeanRetrievalManager brm) {
		if(!rootCodelist.hasInherited()) {
			return rootCodelist;
		}
		LOG.debug("buildInherited codelist : "+rootCodelist.getUrn());
		Map<IURNSingle<CodelistBean>, CodelistBean> extendedCodelists = getInheritedCodelists(rootCodelist, brm);
		Map<IURNSingle<CodelistBean>, ICodelistInheritanceRuleBean> ruleMap = rootCodelist.getInheritedCodelists().stream().collect(Collectors.toMap(e->e.getCodelistRef().getReference(), e ->e));

		//Code Id to Mutable - if duplicates, the last List put in the map wins IF the last in differs from what was there before, preserve order
		//Why is it a code Id to a list?  because of item validity the same code can exist in one codelist with different validity periods
		Map<String, List<CodeMutableBean>> codeWithItemValidity = new HashMap<>();  //this is the exception, not the norm, but needs to take into account
		Map<String, CodeMutableBean> codes = new LinkedHashMap<>();

		//Inherited Codelists which have been adapted based on rules such as strip code prefix
		List<CodelistBean> extendedCodelistPostProcess = new ArrayList<>(extendedCodelists.size());

		for(IURNSingle<CodelistBean> clRef : extendedCodelists.keySet()) {
			CodelistBean currentExtendedCodelist = extendedCodelists.get(clRef);
			if(currentExtendedCodelist != null) {
				LOG.debug("exetends codelist : "+currentExtendedCodelist.getUrn());
				CodelistMutableBean currentCodelistMutable = currentExtendedCodelist.getMutableInstance();
				ICodelistInheritanceRuleBean rule = ruleMap.get(clRef);
				InclusionRules inclusive = null;
				InclusionRules exclusive = null;
				if(rule != null) {
					if(rule.getPrefix() != null) {
						String prefix = rule.getPrefix();
						//Mutate codelist to add prefix to all codes
						for(CodeMutableBean currentItem : currentCodelistMutable.getItems()) {
							currentItem.setId(prefix+currentItem.getId());
							if(currentItem.getParentCode() != null) {
								currentItem.setParentCode(prefix+currentItem.getParentCode());
							}
						}
						currentExtendedCodelist = currentCodelistMutable.getImmutableInstance();
					}
					if(rule.getInclusiveInheritenceIds().size() > 0) {
						inclusive = new InclusionRules(rule.getInclusiveInheritenceIds(), rule.getInclusiveInheritenceCascades(), true);
					}
					if(rule.getExclusiveInheritenceIds().size() > 0) {
						exclusive = new InclusionRules(rule.getExclusiveInheritenceIds(), rule.getExclusiveInheritenceCascades(), false);
					}
					currentCodelistMutable.getItems().forEach(inheritedCode -> {
						inheritedCode.setInherited(true);
					});
					addToMap(codes, codeWithItemValidity, currentCodelistMutable, inclusive, exclusive);
				}
				extendedCodelistPostProcess.add(currentExtendedCodelist);
			}
		}
		ListPositionAgnosticDiffReport diffReport = new ListPositionAgnosticDiffReport();
		//For the root codelist, only keep Codes that are not the same as ones inherited
		Set<String> rootCodes2Remove = new HashSet<>();
		outer:
			for(CodeBean rootCode : rootCodelist.getItems()) {
				if(codes.containsKey(rootCode.getId())) {
					//get the extended version 
					for(int i=extendedCodelistPostProcess.size() -1; i >=0; i--) {
						CodelistBean cl = extendedCodelistPostProcess.get(i);
						CodeBean code = cl.getItemById(rootCode.getId());
						if(code != null) {
							diffReport.isSame = true;
							code.deepEquals(rootCode, true, diffReport);  //Use this diff report which will ignore list position changes
							if(diffReport.isSame) {
								rootCodes2Remove.add(rootCode.getId());
								continue outer;  //Code is the same, keep inherited code
							}
							codes.remove(rootCode.getId());
							break;  //Code is different, keep root code
						}
					}
				}
			}
		CodelistMutableBean rootCodelistMutable = rootCodelist.getMutableInstance();
		List<CodeMutableBean> rootCodesCurrentList = rootCodelistMutable.getItems();
		List<CodeMutableBean> newList = new ArrayList<>(codes.size());

		//Ensure parents exist, otherwise set them to null
		for(String codeId : codes.keySet()) {
			CodeMutableBean code = codes.get(codeId);
			if(code != null) {
				if(code.getParentCode() != null && !codes.containsKey(code.getParentCode())) {
					code.setParentCode(null);
				}
				newList.add(code);
			} else if(codeWithItemValidity.containsKey(codeId)) {
				for(CodeMutableBean itemValidityCode : codeWithItemValidity.get(codeId)) {
					if(itemValidityCode.getParentCode() != null && !codes.containsKey(itemValidityCode.getParentCode())) {
						itemValidityCode.setParentCode(null);
					}
					newList.add(itemValidityCode);
				}
			}
		}
		

		//Add the root codes last
		rootCodesCurrentList.forEach(code-> {
			if(!rootCodes2Remove.contains(code.getId())) {
				code.setInherited(false);
				newList.add(code);
			}
		});

		rootCodelistMutable.setItems(newList);
		rootCodelistMutable.setInherited(true);
		return rootCodelistMutable.getImmutableInstance();
	}

	/**
	 * Due to item validity the same code id may appear twice in the same codelist, so we want to only
	 * @param codeMap
	 * @param codelist
	 */
	private static void addToMap(Map<String, CodeMutableBean> codeMap, Map<String, List<CodeMutableBean>> codeWithItemValidity, CodelistMutableBean codelist, InclusionRules inclusive, InclusionRules exclusive) {
		Map<String, List<CodeMutableBean>> localCodes = new HashMap<>();
		Map<String, CodeMutableBean> localCodeMap = new HashMap<>();
		Map<String, String> parentMap =  Collections.emptyMap();
		if(inclusive != null || exclusive != null) { 
			boolean parentMapRequired = (inclusive != null && inclusive.hasCascadeRule()) || (exclusive != null && exclusive.hasCascadeRule());
			if(parentMapRequired) {
				parentMap  = createInheritenceMap(codelist);
			}
		}
		for(CodeMutableBean code : codelist.getItems()) {
			if(inclusive != null && !inclusive.includeCode(parentMap, code.getId())) {
				continue;
			}
			if(exclusive != null && !exclusive.includeCode(parentMap, code.getId())) {
				continue;
			}
			if(localCodeMap.containsKey(code.getId())) {
				CodeMutableBean existing = localCodeMap.get(code.getId());
				if(existing != null) {
					localCodeMap.put(code.getId(), null);
					List<CodeMutableBean> cLlist = new ArrayList<>(3);
					cLlist.add(existing);
					localCodes.put(code.getId(), cLlist);
				}
				localCodes.get(code.getId()).add(code);
			} else {
				localCodeMap.put(code.getId(), code);
			}
		}
		codeMap.putAll(localCodeMap);
		codeWithItemValidity.putAll(localCodes);
	}

	/**
	 * @param cl
	 * @return not null, map of code id to child code ids
	 */
	private static Map<String, String> createInheritenceMap(CodelistMutableBean cl) {
		Map<String, String> returnMap = new HashMap<>();
		for(CodeMutableBean code : cl.getItems()) {
			if(code.getParentCode() != null) {
				returnMap.put(code.getId(), code.getParentCode());
			}
		}
		return returnMap;
	}

	private static class InclusionRules {
		private Set<String> codeIds = new HashSet<>();
		private Set<Pattern> codePatterns = new HashSet<>();
		private Set<String> casecadeCodeId = new HashSet<>();
		private boolean isIncludeRule;

		public InclusionRules(List<String> inheritFrom, Set<String> casecadeFrom, boolean isIncludeRule) {
			for(String currentInheritFrom : inheritFrom) {
				if(currentInheritFrom.contains("%")) {
					this.codePatterns.add(RegexUtil.wildcardToRegEx(currentInheritFrom, "%"));
				} else {
					this.codeIds.add(currentInheritFrom);
				}
			}
			this.casecadeCodeId = casecadeFrom;
			this.isIncludeRule = isIncludeRule;
		}

		/**
		 * @return true if there is at least one rule which relies on knowing the parentage of a code
		 */
		private boolean hasCascadeRule() {
			return !casecadeCodeId.isEmpty();
		}

		/**
		 * @param parentMap
		 * @param codeId
		 * @return the isincludeRule value to decide if this code is included or excluded - if no match, then returns the opposite of isIncludeRule (e.g. if the rule sets up which codes to include
		 * explicitly and there is no match, then exclude the code, if the rule is defining which codes to exclude explicitly then include)
		 */
		private boolean includeCode(Map<String, String> parentMap, String codeId) {
			if(codeIds.contains(codeId) || isCascadeFrom(parentMap, codeId)) {
				return isIncludeRule;
			}
			for(Pattern p : codePatterns) {
				if(p.matcher(codeId).matches()) {
					return isIncludeRule;
				}
			}
			return !isIncludeRule;
		}

		/**
		 * @param parentMap
		 * @param codeId
		 * @return true if this code is the child of another code which is in the cascade rule
		 */
		private boolean isCascadeFrom(Map<String, String> parentMap, String codeId) {
			if(!ObjectUtil.validCollection(casecadeCodeId)) {
				return false;
			}
			String parent = parentMap.get(codeId);
			while(parent != null) {
				if(casecadeCodeId.contains(parent)) {
					return true;
				}
				parent = parentMap.get(parent);
			}
			return false;
		}
	}

	/**
	 * @param codelist to get the inherited Codelists for
	 * @param brm used to resolve any inherited Codelist references
	 * @return a list of all the Codelists that this Codelist inherits from, including any ancestors (if the inherited Codelist itself contains inheritance)
	 */
	public static Map<IURNSingle<CodelistBean>, CodelistBean> getInheritedCodelists(CodelistBean codelist, SdmxBeanRetrievalManager brm) {
		List<ICrossReferenceBean<CodelistBean>> codelistReferences = getCodelistReferences(codelist);
		Map<IURNSingle<CodelistBean>, CodelistBean>  returnMap = new LinkedHashMap<>();
		if(codelistReferences.size() > 0) {
			for(ICrossReferenceBean<CodelistBean> xsRef : codelistReferences) {
				
				CodelistBean extendedCodelist = brm.getBean(xsRef.getReference());
				if(extendedCodelist instanceof CombinedCodelistBean) {
					extendedCodelist = ((CombinedCodelistBean)extendedCodelist).getRootCodelist();
				}

				returnMap.putAll(getInheritedCodelists(extendedCodelist, brm)); //Recurse up tree
				if(extendedCodelist != null) {
					returnMap.put(xsRef.getReference(), extendedCodelist);
				} else {
					LOG.warn("could not find inherited codelist: "+xsRef.getTargetUrn());
				}
			}
		}
		return returnMap;
	}

	/**
	 * @param codelist
	 * @return not null, immutable list of cross references that this codelist inherits from, or an empty list if there are none
	 */
	public static List<ICrossReferenceBean<CodelistBean>> getCodelistReferences(CodelistBean codelist) {
		List<ICrossReferenceBean<CodelistBean>> returnList = new ArrayList<>();
		if(codelist != null && ObjectUtil.validCollection(codelist.getInheritedCodelists())) {
			for(ICodelistInheritanceRuleBean inheritenceRule : codelist.getInheritedCodelists()) {
				returnList.add(inheritenceRule.getCodelistRef());
			}
		}
		return Collections.unmodifiableList(returnList);
	}
	
	private static class ListPositionAgnosticDiffReport implements DiffReport {
		private boolean isSame = true;

		@Override
		public MaintainableBean getSource() {
			return null;
		}

		@Override
		public MaintainableBean getTarget() {
			return null;
		}

		@Override
		public void addDiff(SDMXBean source, String property, Object sourceVal, Object targetVal) {
			if("URN".equals(property)) {
				//Ignore
			} else if("List Position".equals(property)) {
				//Ignore
			} else {
				isSame = false;
			}
		}

		@Override
		public SortedSet<Diff> getdifferences(ModificationAction modificationType) {
			return Collections.emptySortedSet();
		}

		@Override
		public Set<Diff> getDifferences() {
			return Collections.emptySortedSet();
		}
	}
}
