package io.sdmx.core.sdmx.util;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;

public class StructureReferenceBeanUtil {

	/**
	 * @param sourceTarget to check against
	 * @param subsetTarget to check if it is a subset
	 * @return true if the subsetTarget is the same, or a subset of the sourceTarget
	 * 
	 */
	public static boolean isSubset(ICrossReferenceBeanBase sourceTarget, ICrossReferenceBeanBase subsetTarget) {
	    IURN<?> sourceUrn = sourceTarget.getReference();
	    IURN<?> subsetUrn = subsetTarget.getReference();
		if(!sourceUrn.isMatch(subsetUrn)) {
		    return false;
		}
		//Check the subsetTarget does not contain wildcards that are not in the source target
		if(!subsetUrn.hasAgencyId() && sourceUrn.hasAgencyId()) {
		    return false;
		}
		if(!subsetUrn.hasMaintainableId() && sourceUrn.hasMaintainableId()) {
            return false;
        }
		if(!subsetUrn.hasIdentifiableId() && sourceUrn.hasIdentifiableId()) {
            return false;
        }
		if(subsetUrn.getVersion().isAll() && !subsetUrn.getVersion().isAll()) {
            return false;
        }
		return true;
	}
	
}
