package io.sdmx.core.sdmx.factory.ref;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IDataStructureComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.util.BeanRetreivalUtil;
import io.sdmx.core.sdmx.util.XsRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;

public class StructureMapCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory, IFusionSingleton {
	private static StructureMapCrossReferenceRetrievalFactory INSTANCE;


	public static StructureMapCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
	public Class<IStructureMapBean> getSupportedType() {
		return IStructureMapBean.class;
	}

	public static StructureMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager,
															 MaintainableBean maintBean) {
		IStructureMapBean structureMap = (IStructureMapBean)maintBean;
		
		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();
		ICrossReferenceBean<?> fromRef = structureMap.getSourceRef();
		ICrossReferenceBean<?> toRef =  structureMap.getTargetRef();

		boolean isDataflowRef = fromRef.getReference().getStructureType() == StructureTypes.getMaintStructureType(DataflowBean.class);
		if(isDataflowRef) {
			// Obtain the DSD from the Dataflow
			DataflowBean flowFrom = XsRefUtil.getMaintainableBean(retrievalManager, DataflowBean.class, fromRef);
			DataflowBean flowTo = XsRefUtil.getMaintainableBean(retrievalManager, DataflowBean.class, toRef);
			Objects.requireNonNull(flowFrom, "The 'from' Dataflow was unable to be obtained! Reference: " + fromRef);
			Objects.requireNonNull(flowTo, "The 'to' Dataflow was unable to be obtained! Reference: " + toRef);

			fromRef = flowFrom.getDataStructureRef();
			toRef = flowTo.getDataStructureRef();
		}

		DataStructureBean dsdFrom = BeanRetreivalUtil.getMaintainableBean(retrievalManager, DataStructureBean.class, fromRef.getReference());
		DataStructureBean dsdTo = BeanRetreivalUtil.getMaintainableBean(retrievalManager, DataStructureBean.class, toRef.getReference());

		Set<IComponentMapBean> componentMaps = structureMap.getComposites(IComponentMapBean.class);


		for(String componentId : structureMap.getFixedInputs().keySet()) {
			String compValue = structureMap.getFixedInputs().get(componentId);
			ComponentBean componentFrom = addComponentReference(maintBean, isDataflowRef, dsdFrom, componentId, returnReferences);
			addComponentReferences(structureMap, componentFrom, compValue, returnReferences);
		}
		for(String componentId : structureMap.getFixedOutputs().keySet()) {
			String compValue = structureMap.getFixedOutputs().get(componentId);
			ComponentBean componentFrom = addComponentReference(maintBean, isDataflowRef, dsdTo, componentId, returnReferences);
			addComponentReferences(structureMap, componentFrom, compValue, returnReferences);
		}
		
		
		for(IComponentMapBean currentMap : componentMaps) {
			for(String componentId : currentMap.getSourceComponents()) {
				if(!componentId.equals("ALL")) {
					addComponentReference(maintBean, isDataflowRef, dsdFrom, componentId, returnReferences);
				}
			}

			for(String componentId : currentMap.getTargetComponents()) {
				if(!componentId.equals("ALL")) {
					addComponentReference(maintBean, isDataflowRef, dsdTo, componentId, returnReferences);
				}
			}
		}
		return returnReferences;
	}
	
	private ComponentBean addComponentReference(MaintainableBean refFrom, boolean isDataflowRef, DataStructureBean dsd, String componentId, Set<ICrossReferenceBean<?>> returnReferences) {
		ComponentBean component = dsd.getComponent(componentId);
		IURNAbsolute<? extends ComponentBean> urn = null;
		if(component == null) {
			urn =  dsd.getURN().toIdentifiable(IDataStructureComponentBean.class, componentId);
		} else {
			urn = component.getURN();
		}
		IndirectReferenceBean<?> ref = isDataflowRef ? new IndirectReferenceBean<>(refFrom, urn) : new OverrideIndirectReferenceBean<>(refFrom, urn);
		returnReferences.add(ref);
		return component;
	}
	
	
	/**
	 * This is actually not indirect, but could only be discovered by going via this factory because the ref was either to a Dimension or Attribute which is unknown
	 * until the DSD is obtained
	 */
	private class OverrideIndirectReferenceBean<T extends ComponentBean> extends IndirectReferenceBean<T> {
		private static final long serialVersionUID = 1L;

		public OverrideIndirectReferenceBean(IdentifiableBean referencedFrom, IURNAbsolute<T> urn) {
			super(referencedFrom, urn);
		}

		@Override
		public boolean isIndirectReference() {
			return false;
		}
	}
	
	private void addComponentReferences(MaintainableBean refFrom, ComponentBean component, String compValue, Set<ICrossReferenceBean<?>> returnReferences) {
		if(component == null || component.getRepresentation() == null || component.getRepresentation().getRepresentation() == null) {
			return;
		}
		ICrossReferenceBean<? extends EnumeratedListBean> representationRef = component.getRepresentation().getRepresentation();
		if(representationRef != null) {
			Set<String> codeIds = new HashSet<>();
			codeIds.add(compValue);
			XsRefUtil.addRepresentationReferences(refFrom, returnReferences, representationRef, codeIds, null);
		}
	}
}
