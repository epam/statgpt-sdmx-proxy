package io.sdmx.core.sdmx.empty;

import java.util.List;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public class EmptyDataWriterEngine implements DataWriterEngine {
	public static final EmptyDataWriterEngine INSTANCE = new EmptyDataWriterEngine();

	@Override
	public void writeHeader(HeaderBean header) {}

	@Override
	public void startDataset(ProvisionAgreementBean prov, DataflowBean flow, DataStructureBean dsd, DatasetHeaderBean header, AnnotationBean... annotations) {}

	@Override
	public void startGroup(String groupId, AnnotationBean... annotations) {}

	@Override
	public void writeGroupKeyValue(String id, String value) {}

	@Override
	public void startSeries(AnnotationBean... annotations) {}

	@Override
	public void writeSeriesKeyValue(String id, String value) {}

	@Override
	public void writeAttributeValue(String id, String... value) {}


	@Override
	public void writeMultilingualAttributeValue(IMultilingualKeyValue compKeyValue) {

	}

	@Override
	public void writeObservation(String dimensionId, String dimensionValue, List<KeyValue> measures, AnnotationBean... annotations) {}

	@Override
	public void close(FooterMessage... footer) {}
}
