package io.sdmx.core.sdmx.model;

@Deprecated
public class MVStoreReadableDataLocation { // extends AbstractReadableDataLocation {
	/*
	private static final Logger LOG =
			LoggerFactory.getLogger(MVStoreReadableDataLocation.class);
	private static final long serialVersionUID = 0L;

	private final MVStoreDatasetStorage storage;

	public MVStoreReadableDataLocation(MVStoreDatasetStorage storage) {
		this.storage = storage;
	}

	@Override
	public MVStoreReadableDataLocation copy() {
		return new MVStoreReadableDataLocation(storage);
	}

	@Override
	protected void closeInternal() {
		File file = storage.getFile();

		if (file != null) {
			file.delete();
		}
	}

	@Override
	public boolean isClosed() {
		return isClosed;
	}

	@Override
	public String getName() {
		return storage.getFile().getName();
	}

	@Override
	public FILE_FORMAT getFormat() {
		LOG.error("MVStoreReadableDataLocation.getFormat() was called");
		//throw new RuntimeException("No InputStream available");

		return null; // FIXME: maybe get it from storage?
	}

	@Override
	public InputStream getInputStream() {
		LOG.error("MVStoreReadableDataLocation.getInputStream() was called");
		//throw new RuntimeException("No InputStream available");

		return null; // FIXME: maybe get it from storage?
	}

	@Override
	protected InputStream getStreamInternal() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}
	
*/
}
