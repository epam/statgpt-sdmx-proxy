package io.sdmx.core.sdmx.api.engine.structure;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Creates partial lists to conform to the detail=referencepartial specification
 * <p/>
 * <b><u>AgencyScheme</u></b><br/>	
 *   Only the agencies maintaining the returned structures should be included in the returned agency scheme(s)
 * <p/>
 * <b><u>CategoryScheme</u></b><br/>	
 *  Only the categories referenced by the returned categorisations or structure sets should be included in the returned category scheme(s)
 * 
 * <p/>
 * <b><u>Codelist</u></b><br/>	
 *  Only the codes referenced by the returned categorisations, constraints, hierarchies or structure sets should be included in the returned codelist(s)
 * 
 * <p/>
 * <b><u>ConceptScheme</u></b><br/>	
 *  Only the concepts referenced by the returned categorisations, data structure definitions, metadata structure definitions or structure sets should be included in the returned concept scheme(s)
 * 
 * <p/>
 * <b><u>DataConsumerScheme</u></b><br/>	
 *  Only the data consumers referenced by the returned categorisations, metadata structure definitions or structure sets should be included in the returned data consumer scheme(s)
 * 
 * <p/>
 * <b><u>DataProviderScheme</u></b><br/>	
 *  Only the data providers referenced by the returned categorisations, constraints, provision agreements, metadata structure definitions or structure sets should be included in the returned data provider scheme(s)
 * 
 * <p/>
 * <b><u>HierarchicalCodelist</u></b><br/>	
 *  Only the hierarchies referenced by the returned categorisations or structure sets should be included in the returned hierarchical codelist(s)
 * 
 * <p/>
 * <b><u>OrganisationUnitScheme</u></b><br/>	
 *  Only the organisation units referenced by the returned categorisations, constraints, metadata structure definitions or structure sets in the returned organisation unit scheme(s)
 * 
 * <p/>
 * <b><u>ReportingTaxonomy</u></b><br/>	
 *  Only the taxonomies referenced by the returned categorisations or structure sets should be included in the reporting taxonomy
 *
 */
public interface IPartialReferencesResolutionEngine {

	/**
	 * Updates the beans in the referencedStructures to make partial lists based on the rules as described above, if any partial lists result in the removal of
	 * references, then these will be analysed as it can result in referenced structures being removed if nothing else reference it
	 * 
	 * @param queryResponse
	 * @param referencedStructures
	 * @return SdmxBeans containing all the refernece structures, some of which are made partial due to the rules as described on this class
	 */
	void makePartial(SdmxBeans queryResponse, SdmxBeans referencedStructures, SdmxBeanRetrievalManager brm);
	
}
