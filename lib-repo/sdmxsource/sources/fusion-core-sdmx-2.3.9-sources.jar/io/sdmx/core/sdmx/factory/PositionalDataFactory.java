package io.sdmx.core.sdmx.factory;

import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;
import io.sdmx.core.sdmx.engine.position.NullPositionReaderEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts positional strings from {@link IDataPosition} to an {@link IDataPosition}
 * 
 * To use this class, ensure the {@link FusionBeanStore} has {@link IPositionReaderEngine} instances registered with it
 */
public class PositionalDataFactory implements Cache {
	private static PositionalDataFactory INSTANCE;
	private Map<String, IPositionReaderEngine> readerMap = null;
	
	public static PositionalDataFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new PositionalDataFactory();
		}
		return INSTANCE;
	}
	
	/**
	 * @param asString
	 * @return data position or null if the position is not supported by any reader
	 */
	public IDataPosition getPosition(String asString) {
		if(asString == null) {
			return null;
		}
		String startsWith = asString.split(":", 2)[0];
		return getReaderEngine(startsWith).string2Position(asString);
		
	}
	
	/**
	 * @param prefix
	 * @return not null
	 */
	private IPositionReaderEngine getReaderEngine(String prefix) {
		if(readerMap == null) {
			this.readerMap = FusionBeanStore.getBeans(IPositionReaderEngine.class).stream().collect(Collectors.toMap(e->e.getPositionPrefix(), e->e));
		}
		IPositionReaderEngine reader = readerMap.get(prefix);
		return reader == null ? NullPositionReaderEngine.INSTANCE : reader;
	}

	@Override
	public void clearCache() {
		readerMap = null;
	}
	
}
