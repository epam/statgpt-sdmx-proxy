package io.sdmx.core.sdmx.factory.ref;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategoryMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ICategorySchemeMapBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class CategorySchemeMapCrossReferenceRetrievalFactory
		extends ItemSchemeMapCrossReferenceRetrievalFactory<ICategorySchemeMapBean, ICategoryMapBean, CategorySchemeBean, CategoryBean> {

	private static CategorySchemeMapCrossReferenceRetrievalFactory INSTANCE;

	public static CategorySchemeMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static CategorySchemeMapCrossReferenceRetrievalFactory getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new CategorySchemeMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return ICategorySchemeMapBean.class;
	}
	
	@Override
	protected Class<CategorySchemeBean> getItemSchemeClass(ICategorySchemeMapBean itemSchemeMap) {
		return CategorySchemeBean.class;
	}
}
