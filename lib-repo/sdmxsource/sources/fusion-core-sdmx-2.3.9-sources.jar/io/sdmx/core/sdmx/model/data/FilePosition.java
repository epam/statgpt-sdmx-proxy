package io.sdmx.core.sdmx.model.data;

import io.sdmx.api.sdmx.model.data.IFilePosition;

public class FilePosition extends AbstractDataPosition implements IFilePosition {
	private long offset;
	private long bytes;
	
	public FilePosition(long offset, long bytes) {
		this.offset = offset;
		this.bytes = bytes;
	}

	@Override
	public long getOffset() {
		return offset;
	}

	@Override
	public long getBytes() {
		return bytes;
	}
	
	@Override
	protected void buildPositionalString(StringBuilder sb) {
		sb.append(offset+":"+bytes);
	}

	@Override
	public POSITION_TYPE getPositionType() {
		return POSITION_TYPE.FILE;
	}
	
}
