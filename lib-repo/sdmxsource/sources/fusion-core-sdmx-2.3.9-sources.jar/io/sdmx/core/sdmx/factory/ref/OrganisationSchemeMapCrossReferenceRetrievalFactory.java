package io.sdmx.core.sdmx.factory.ref;

import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class OrganisationSchemeMapCrossReferenceRetrievalFactory
		extends ItemSchemeMapCrossReferenceRetrievalFactory<IOrganisationSchemeMapBean, IOrganisationMapBean, OrganisationSchemeBean<OrganisationBean>, OrganisationBean> {

	private static OrganisationSchemeMapCrossReferenceRetrievalFactory INSTANCE;

	public static OrganisationSchemeMapCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static OrganisationSchemeMapCrossReferenceRetrievalFactory getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new OrganisationSchemeMapCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return IOrganisationSchemeMapBean.class;
	}

	@Override
	protected Class getItemSchemeClass(IOrganisationSchemeMapBean itemSchemeMap) {
		Class<? extends ItemSchemeBean> organisationClass = itemSchemeMap.getSourceRef().getReference().getStructureClass();
		if (organisationClass == AgencySchemeBean.class) {
			return AgencySchemeBean.class;
		} else if (organisationClass == DataProviderSchemeBean.class) {
			return DataProviderSchemeBean.class;
		} else if (organisationClass == DataConsumerSchemeBean.class) {
			return DataConsumerSchemeBean.class;
		} else if (organisationClass == OrganisationUnitSchemeBean.class) {
			return OrganisationUnitSchemeBean.class;
		}
		return null;
	}
}
