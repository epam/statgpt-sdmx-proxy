package io.sdmx.core.sdmx.api.factory.metadata;

import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;

public interface IMetadataValidationEngine {

	/**
	 * Validates reference metadata
	 * @param metadata
	 */
	void validate(IReferenceMetadataContainer metadata);
	
}
