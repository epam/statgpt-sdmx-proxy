package io.sdmx.core.sdmx.engine.structure;

import java.net.URL;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_CROSS_REFERENCES;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_EXTERNAL_SETTING;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.ExternalReferenceManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.model.ref.StructureParseConfiguration;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.logging.LoggingUtil;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;

public class ExternalReferenceManagerImpl implements ExternalReferenceManager {
	private static final Logger LOG = LoggerFactory.getLogger(ExternalReferenceManagerImpl.class);
	private static final ResolutionSettings retriervalSettings = new ResolutionSettings(RESOLVE_EXTERNAL_SETTING.DO_NOT_RESOLVE, RESOLVE_CROSS_REFERENCES.DO_NOT_RESOLVE, 0);
	
	private StructureReaderManager structureParsingManager;
	

	public ExternalReferenceManagerImpl() {
		//To prevent circular reference this is not passed in on the constructor
		SingletonStore.registerInterest(StructureReaderManager.class, (spm) -> {
			this.structureParsingManager = spm;
		});
	}

	
	@Override
	public SdmxBeans resolveExternalReferences(SdmxBeans structures, boolean isSubstitute, boolean isLenient) throws SdmxException, CrossReferenceException {
		LOG.debug("Check for External References, Substitute=" +isSubstitute+ " Lenient="+isLenient);
		SdmxBeans returnBeans = new SdmxBeansImpl();
		if(structures == null) {
			return returnBeans;
		}
		
		resolveBeans(structures.getAllMaintainables(), returnBeans, isLenient);
		
		LOG.debug("Number of External References=" +returnBeans.getAllMaintainables().size());
		if(isSubstitute) {
			structures.merge(returnBeans);
		}
		return returnBeans;
	}
	
	private void resolveBeans(Set<? extends MaintainableBean> maintinableBeans, SdmxBeans returnBeans, boolean isLenient) {
		for(MaintainableBean currentBean : maintinableBeans) {
			if(currentBean.isExternalReference() && currentBean.isStub()) {
				SdmxBeans retrievedStructures = resolve(currentBean, isLenient);
				//CHECK THERE WAS SOMETHING RETURNED
				if(retrievedStructures != null) {
					MaintainableBean resolvedReference = MaintainableUtil.resolveReference(retrievedStructures.getAllMaintainables(), currentBean.getURN());
					if(resolvedReference == null) {
						LOG.warn("External Reference "+currentBean.getStructureURL()+" does not contain structure: " + currentBean.getUrn());
						addException(currentBean, isLenient);	
					} else {
						//GET THE CODELIST AND ADD IT
						returnBeans.addIdentifiable(resolvedReference);
					}
				} else {
					LOG.warn("Can not resolve external reference for structure "+currentBean.getUrn()+", URL does not contain SDMX structures: "+currentBean.getStructureURL());
				}
			}
		}
	}
		
	private SdmxBeans resolve(MaintainableBean maintBean, boolean isLenient) {
		try {
			URL urlLocation = maintBean.getStructureURL();
			if(urlLocation == null) {
				LOG.warn("Can not resolve external reference for structure "+maintBean.getUrn()+" Structure URL is not set ");
				addException(maintBean, isLenient);	
			} else {
				ReadableDataLocation dataLocation =  FusionSystem.getRdlFactory().getReadableDataLocation(urlLocation);
				return structureParsingManager.parseStructures(dataLocation, StructureParseConfiguration.build().resolution(retriervalSettings));		
			}
		} catch(CrossReferenceException refEx) {
			if(isLenient) {
				addException(maintBean, refEx.getMessage());	
			} else {
				throw refEx;
			}
		} catch(Throwable th) {
			if(isLenient) {
				addException(maintBean, th.getMessage());	
			} else {
				throw new RuntimeException(th);
			}
		}
		return null;
	}
	
	private void addException(MaintainableBean maintBean, boolean isLenient) {
		if(isLenient) {
			if(maintBean.getStructureURL() == null) {
				addException(maintBean, "External location not set");
			} else {
				addException(maintBean, "External location `" + maintBean.getStructureURL().toString()+ "` does not contain structure : " + maintBean.getUrn());
			}
		} else {
			if(maintBean.getStructureURL() == null) {
				throw new SdmxSemmanticException(ExceptionCode.EXTERNAL_STRUCTURE_NOT_FOUND_AT_URI, maintBean.getUrn(),  "NOT SET");
			}
			throw new SdmxSemmanticException(ExceptionCode.EXTERNAL_STRUCTURE_NOT_FOUND_AT_URI, maintBean.getUrn(),  maintBean.getStructureURL().toString());
		}		
	}
			
	private void addException(MaintainableBean maintBean, String message) {
		LoggingUtil.error(LOG, message);
	}

	//Spring controlled
	public void setStructureParsingManager(StructureReaderManager structureParsingManager) {
		this.structureParsingManager = structureParsingManager;
	}
}
