package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.sdmx.exception.CalculationErrorHandler;
import io.sdmx.api.sdmx.model.error.ICaculationError;

public class CalculationErrorHandlerImpl implements CalculationErrorHandler {
	
	private List<ICaculationError> calculationErrors = new ArrayList<>();
	
	@Override
	public void reportError(ICaculationError error) {
		this.calculationErrors.add(error);
	}

	public List<ICaculationError> getCalculationErrors() {
		return Collections.unmodifiableList(calculationErrors);
	}
}
