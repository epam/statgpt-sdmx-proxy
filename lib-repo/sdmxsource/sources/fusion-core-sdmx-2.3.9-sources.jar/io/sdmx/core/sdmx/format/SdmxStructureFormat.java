package io.sdmx.core.sdmx.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;

/**
 */
public class SdmxStructureFormat implements StructureFormat {
	private static final long serialVersionUID = -8780344285791826634L;
	private STRUCTURE_OUTPUT_FORMAT structureFormat;
	private FormatDetails details;
	private boolean lenient;
	private boolean prettyPrint;

	public SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT structureFormat) {
		this(structureFormat, false, false);
	}

	public SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT structureFormat, boolean lenient, boolean prettyPrint) {
		if(structureFormat == null) {
			throw new IllegalArgumentException("STRUCTURE_OUTPUT_FORMAT can not be null");
		}
		this.structureFormat = structureFormat;
		this.lenient = lenient;
		String mimeType = structureFormat == STRUCTURE_OUTPUT_FORMAT.EDI ? "text/plain" : "application/xml";

		String acceptHeader = null;
		this.prettyPrint = prettyPrint;
		switch(structureFormat) {
			case EDI :
			acceptHeader = "application/vnd.sdmx.structure+edi";
			break;
			case SDMX_V1_STRUCTURE_DOCUMENT :
			acceptHeader = "application/vnd.sdmx.structure+xml;version=1.0";
			break;
			case SDMX_V2_STRUCTURE_DOCUMENT :
			acceptHeader = "application/vnd.sdmx.structure+xml;version=2.0";
			break;
			case SDMX_V21_STRUCTURE_DOCUMENT :
			acceptHeader = "application/vnd.sdmx.structure+xml;version=2.1";
			break;
			case SDMX_V3_STRUCTURE_DOCUMENT:
				acceptHeader = "application/vnd.sdmx.structure+xml;version=3.0";
			break;
		}
		details = new FormatDetailsImpl(toString(), getFileExtension(), mimeType, false, acceptHeader);
		this.prettyPrint = prettyPrint;
	}

	@Override
	public STRUCTURE_OUTPUT_FORMAT getSdmxOutputFormat() {
		return structureFormat;
	}


	public boolean isLenient() {
		return lenient;
	}

	public boolean isPrettyPrint() {
		return this.prettyPrint;
	}

	@Override
	public String toString() {
		return structureFormat.toString();
	}

	@Override
	public FormatDetails getFormatDetails() {
		return details;
	}

	private String getFileExtension() {
		return structureFormat.getDefaultFileExtension();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxStructureFormat) {
			SdmxStructureFormat that = (SdmxStructureFormat)obj;
			return (that.getSdmxOutputFormat() == this.getSdmxOutputFormat() && that.lenient == this.lenient && that.prettyPrint == this.prettyPrint);

		}
		return false;
	}

	@Override
	public int hashCode() {
		return new String (this.getSdmxOutputFormat().toString() + this.lenient + this.prettyPrint).hashCode();
	}

	@Override
	public String getWebServiceFormat() {
		switch (this.structureFormat) {
		case SDMX_V1_STRUCTURE_DOCUMENT: {
			return "sdmx-1.0";
		}
		case SDMX_V2_STRUCTURE_DOCUMENT: {
			return "sdmx-2.0";
		}
		case SDMX_V21_STRUCTURE_DOCUMENT: {
			return "sdmx-2.1";
		}
		case SDMX_V3_STRUCTURE_DOCUMENT: {
			return "sdmx-3.0";
		}
		case EDI: {
			return "sdmx-edi";
		}
		case JSON: {
			return "sdmx-json&version=1.0.0";
		}
		default:
			break;
		}
		return null;
	}
}
