package io.sdmx.core.sdmx.api.engine.metadata;

import java.io.OutputStream;

import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;

/**
 * Writes reference metadata in a specific format (implementation specific)
 */
public interface IMetadataWriterEngine {

	/**
	 * Write the reference metadata container to the output stream
	 * @param container required - information to write
	 * @param out required - to write to
	 */
	void write(IReferenceMetadataContainer container, OutputStream out);
	
}
