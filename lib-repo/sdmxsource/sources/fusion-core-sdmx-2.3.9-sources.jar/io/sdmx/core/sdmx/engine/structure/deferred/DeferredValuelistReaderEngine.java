package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.im.beans.valuelist.ValuelistBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ValuelistBeanDeferred}
 */
public class DeferredValuelistReaderEngine extends AbstractDeferredStructureReaderEngine<ValueListBean> {
    private static DeferredValuelistReaderEngine INSTANCE;
    
    private DeferredValuelistReaderEngine() {
        super(ValueListBean.class);
    }
    
    public static DeferredValuelistReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredValuelistReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ValueListBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ValuelistBeanDeferred(bean, loader);
    }

}
