package io.sdmx.core.sdmx.empty;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

public class EmptySeriesObsDataWriterEngine implements ISeriesObsDataWriterEngine  {
	public static final EmptySeriesObsDataWriterEngine INSTANCE = new EmptySeriesObsDataWriterEngine();

	@Override
	public void writeHeader(HeaderBean header) {}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes,AnnotationBean... annotations) {}

	@Override
	public void writeKey(Keyable key) {}

	@Override
	public void writeObservation(Observation obs) {}

	@Override
	public void close(FooterMessage... footer) {}
	
}
