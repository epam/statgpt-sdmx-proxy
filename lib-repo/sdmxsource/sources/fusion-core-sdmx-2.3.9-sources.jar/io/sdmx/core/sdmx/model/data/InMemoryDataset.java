package io.sdmx.core.sdmx.model.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.im.beans.datastructure.DataStructureDetails;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.object.SeriesUtil;

/**
 * In memory container for data written via the DataWriterEngine interface
 * NOTE: multivalued and multilingual measures are not supported
 */
public class InMemoryDataset implements IDatasetStore {
	private DatasetHeaderBean dsHeader;
	private IDatasetStructures structures;
	private List<AnnotationBean> annotations = Collections.emptyList();
	private IDatasetAttributes dsAttributes = DatasetAttributes.EMPTY_ATTRIBUTES;
	private LinkedHashMap<Keyable, List<Observation>> writtenObs = new LinkedHashMap<>();
	private List<Observation> currentObs = null;
	private List<Keyable> keys = null;
	
	
	/**
	 * Constructor from an list of string arrays which describe the series obs
	 * @param rows in format  SERIESKEY..SERATT1..SERATTX...XS VAL->MEASURE1->MEASUREX..OBSATT1->OBSATTX
	 * example  ["A:UK", "Births and Deaths UK", "2008", "123", "124", "A", "F"]
	 * where DSD has ["FREQ, "REF_AREA", "SERIES_TITLE", "TIME_PERIOD", "BIRTHS", "DEATHS", "OBS_STATUS", "OBS_CONF"] 
	 */
	public InMemoryDataset(DatasetHeaderBean dsHeader, IDatasetStructures structures, String dimensionAtObservation, List<String[]> rows) {
		this.dsHeader = dsHeader;
		DataStructureDetails dsdDetails = DataStructureDetails.getInstance(structures.getDataStructure(), dimensionAtObservation);
		
		//Build Key
		List<String> dimIds = dsdDetails.getDimensions();
		List<String> seriesAttIds = dsdDetails.getSeriesAttributes();
		List<String> measures = dsdDetails.getMeasures();
		List<String> obsAttIds = dsdDetails.getObsAttributes();
    	List<Observation> obsList = null;
		String lastShortCode = "";	
		Keyable series = null;
		rowLoop:
		for(String[] row : rows) {
			List<KeyValue> key = new ArrayList<>(dimIds.size());
			List<KeyValue> attributes = new ArrayList<>(seriesAttIds.size());
			String shortCode = row[0];
			if(!lastShortCode.equals(shortCode)) {
				//process key
				lastShortCode = shortCode;
				String[] seriesKey = SeriesUtil.splitKey(shortCode);
				for(int i=0; i < dimIds.size(); i++) {
					key.add(KeyValueImpl.getInstance(dimIds.get(i), seriesKey[i]));
				}
				for(int i=0; i < seriesAttIds.size(); i++) {
					int idx = i+1;//Add the series key column on
					if(row.length <= idx) {
						break;
					}
					if(row[idx] != null) {
						attributes.add(KeyValueImpl.getInstance(seriesAttIds.get(i), row[idx]));
					}
				}
				series = KeyableImpl.seriesKey(structures.getDataflow(), structures.getDataStructure(), key, attributes);
				obsList = new ArrayList<>();
				writtenObs.put(series, obsList);
			} 
			int idx = 1 + seriesAttIds.size();  //starting index
			if((idx) >= row.length) {
				//Series only
				continue rowLoop;
			}
			String obsDimVal = null;
			if(dimensionAtObservation != null) {
				obsDimVal = row[idx];
				idx++;
			}
			List<KeyValue> measureValues = new ArrayList<>(measures.size());
			for(int i=0; i < measures.size(); i++,idx++) {
				if(row.length <= idx) {
					break;
				}
				if(row[idx] != null) {
					measureValues.add(KeyValueImpl.getInstance(measures.get(i), row[idx]));
				}
			}
			List<KeyValue> obsAttributes = new ArrayList<>(obsAttIds.size());
			for(int i=0; i < obsAttIds.size(); i++,idx++) {
				if(row.length <= idx) {
					break;
				}
				if(row[idx] != null) {
					obsAttributes.add(KeyValueImpl.getInstance(obsAttIds.get(i), row[idx]));
				}
			}
			obsList.add(ObservationImpl.multipleMeasureCrossSection(series, dimensionAtObservation, obsDimVal, measureValues, obsAttributes));
		}
	}

	public InMemoryDataset(DatasetHeaderBean dsHeader, IDatasetStructures structures) {
		this.dsHeader = dsHeader;
		this.structures = structures;
	}
	
	public void writeDatasetAttributes(IDatasetAttributes datasetAttributes) {
		if(datasetAttributes != null) {
			this.dsAttributes = datasetAttributes;
		}
	}
	
	public void writeKey(Keyable key) {
		currentObs = new ArrayList<>();
		writtenObs.put(key, currentObs);
		keys = null;
	}

	public void writeObs(Observation obs) {
		currentObs.add(obs);
	}

	public IDatasetStructures getStructures() {
		return structures;
	}
	
	public IDatasetAttributes getDatasetAttributes() {
		return dsAttributes;
	}

	/**
	 * @return sorted set of keys (in order written)
	 */
	public List<Keyable> getKeys() {
		if(this.keys == null) {
			this.keys = new ArrayList<>(this.writtenObs.keySet());
		}
		return this.keys;
	}
	
	public List<Observation> getObs(Keyable key) {
		return this.writtenObs.get(key);	
	}

	@Override
	public DatasetHeaderBean getHeader() {
		return dsHeader;
	}

	@Override
	public List<AnnotationBean> getDatasetAnnotations() {
		return annotations;
	}

	@Override
	public Keyable getKeyable(Integer kPos) {
		if(this.getKeys().size() <= kPos) {
			return null;
		}
		return this.getKeys().get(kPos);
	}

	@Override
	public Iterator<Observation> getObs(int keyIdx) {
		Keyable key = getKeyable(keyIdx);
		if(key != null) {
			List<Observation> obs = this.writtenObs.get(key);
			if(obs != null) {
				return obs.iterator();
			}
		}
		return Collections.emptyIterator();
	}

	@Override
	public int getObsSize(int keyIdx) {
		Keyable key = getKeyable(keyIdx);
		if(key != null) {
			List<Observation> obs = this.writtenObs.get(key);
			if(obs != null) {
				return obs.size();
			}
		}
		return 0;
	}

	@Override
	public int getKeySize() {
		return this.getKeys() == null ? 0 : this.getKeys().size();
	}

	@Override
	public void writeDatasetAnnotations(List<AnnotationBean> annotations) {
		this.annotations = annotations;
	}
	
	
}
