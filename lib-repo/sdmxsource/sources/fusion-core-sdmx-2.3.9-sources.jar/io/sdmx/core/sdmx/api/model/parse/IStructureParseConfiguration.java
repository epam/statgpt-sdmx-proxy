package io.sdmx.core.sdmx.api.model.parse;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;

public interface IStructureParseConfiguration {

	/**
	 * If true the structure parser will call upon additional validators (IStructureParsePostValidationEngine) to ensure the validity of the structures
	 * @param action - the action in the beans message
	 * @return
	 */
	boolean performPostProcessValidation(DATASET_ACTION action);
	
	/**
	 * @return optional optional settings for structure resolution
	 */
	ResolutionSettings getResolutionSettings();
	
	/**
	 * @return optional, used to override the default behaviour of converting a {@link MaintainableMutableBean} to a {@link MaintainableBean}
	 */
	IBeansBuilder getBeanBuilder();
	
	/**
	 * @return optional  will be used to resolve any references if resolution settings are supplied or if post process validation is needed
	 */
	SdmxBeanRetrievalManager getRetrievalManager();
	
}
