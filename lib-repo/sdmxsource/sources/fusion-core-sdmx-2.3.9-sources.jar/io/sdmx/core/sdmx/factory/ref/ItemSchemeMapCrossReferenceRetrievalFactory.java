package io.sdmx.core.sdmx.factory.ref;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.utils.sdmx.xs.WeakReferenceBean;

public abstract class ItemSchemeMapCrossReferenceRetrievalFactory
		<T extends IItemSchemeMapBean<M>, M extends IItemMapBean, S extends ItemSchemeBean<I>, I extends ItemBean>
		implements CrossReferenceRetrievalFactory, IFusionSingleton {

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		T itemSchemeMap = (T) maintBean;
		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();
		S sourceItemScheme = retrievalManager.getBean(itemSchemeMap.getSourceRef().getReference().toType(getItemSchemeClass(itemSchemeMap)));

		for (M itemMap : itemSchemeMap.getItems()) {
			Pattern pattern = itemMap.isSourceRegEx() ? itemMap.getSourcePattern() : null;
			int startIdx = itemMap.getSourceStartIdx();
			int endIdx = itemMap.getSourceEndIdx();
			if (itemMap.isSourceRegEx() || startIdx > 0 || endIdx > 0) {
				if (sourceItemScheme != null) {
					IdentifiableBean parent = itemMap.getIdentifiableParent();
					for (I item : sourceItemScheme.getItems()) {

						String itemId = item.getId();
						if (startIdx > 0 || endIdx > 0) {
							if (endIdx > 0) {
								// remember start index is either set, or defaulted to 0
								int end = Math.min(itemId.length(), endIdx);
								itemId = itemId.substring(startIdx, end);
							} else {
								// we know start index is greater than 0, but end index is not
								itemId = itemId.substring(startIdx);
							}
						}
						if (itemMap.isSourceRegEx()) {
							if (pattern.matcher(itemId).matches()) {
								returnReferences.add(new WeakReferenceBean<>(parent, false, item.getURN()));
							}
						} else if (itemMap.getSourceId().equals(itemId)) {
							returnReferences.add(new WeakReferenceBean<>(parent, false, item.getURN()));
						}
					}
				}
			}
		}
		return returnReferences;
	}

	protected abstract Class<S> getItemSchemeClass(T itemSchemeMap);
}
