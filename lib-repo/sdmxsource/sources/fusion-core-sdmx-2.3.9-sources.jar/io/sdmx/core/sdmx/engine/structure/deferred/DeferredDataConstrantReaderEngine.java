package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.im.beans.registry.ContentConstraintBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ContentConstraintBeanDeferred}
 */
public class DeferredDataConstrantReaderEngine extends AbstractDeferredStructureReaderEngine<ContentConstraintBean> {
    private static DeferredDataConstrantReaderEngine INSTANCE;
    
    private DeferredDataConstrantReaderEngine() {
        super(ContentConstraintBean.class);
    }
    
    public static DeferredDataConstrantReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredDataConstrantReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ContentConstraintBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ContentConstraintBeanDeferred(bean, loader);
    }

}
