package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.im.beans.transformation.NamePersonalisationSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link NamePersonalisationSchemeBeanDeferred}
 */
public class DeferredNamePersonalisationSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<INamePersonalisationSchemeBean> {
    private static DeferredNamePersonalisationSchemeReaderEngine INSTANCE;
    
    private DeferredNamePersonalisationSchemeReaderEngine() {
        super(INamePersonalisationSchemeBean.class);
    }
    
    public static DeferredNamePersonalisationSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredNamePersonalisationSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<INamePersonalisationSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new NamePersonalisationSchemeBeanDeferred(bean, loader);
    }

}
