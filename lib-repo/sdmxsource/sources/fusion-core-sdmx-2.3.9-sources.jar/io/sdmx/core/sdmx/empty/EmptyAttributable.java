package io.sdmx.core.sdmx.empty;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.IDataPosition;

public class EmptyAttributable implements Attributable {
	public static final EmptyAttributable INSTANCE = new EmptyAttributable();

	@Override
	public IDataPosition getPosition() {
		return null;
	}

	@Override
	public List<KeyValue> getAttributes() {
		return Collections.emptyList();
	}

	@Override
	public KeyValue getAttribute(String concept) {
		return null;
	}

	@Override
	public List<IMultilingualKeyValue> getMultilingualAttributes() {
		return Collections.emptyList();
	}

	@Override
	public IMultilingualKeyValue getMultilingualAttribute(String concept){
		return null;
	}

	@Override
	public boolean hasAnnotations() {

		return false;
	}

	@Override
	public List<AnnotationBean> getAnnotations() {

		return Collections.emptyList();
	}

}
