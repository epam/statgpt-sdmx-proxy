package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.im.beans.metadatastructure.MetadataStructureDefinitionBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link MetadataStructureDefinitionBeanDeferred}
 */
public class DeferredMetadataStructureReaderEngine extends AbstractDeferredStructureReaderEngine<MetadataStructureDefinitionBean> {
    private static DeferredMetadataStructureReaderEngine INSTANCE;
    
    private DeferredMetadataStructureReaderEngine() {
        super(MetadataStructureDefinitionBean.class);
    }
    
    public static DeferredMetadataStructureReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredMetadataStructureReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<MetadataStructureDefinitionBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new MetadataStructureDefinitionBeanDeferred(bean, loader);
    }

}
