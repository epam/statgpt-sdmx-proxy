
package io.sdmx.core.sdmx.api.manager.structure;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.core.sdmx.api.model.parse.IStructureParseConfiguration;

/**
 * Parses an input stream of information as a SDMX structure stream, the implementation will attempt to read and understand what is in the stream
 * in order to correctly parse the information - as such the supports formats are
 * 
 */
public interface StructureReaderManager {
	
	
	/**
	 * Parses an input stream of structures
	 *
	 * @param rdl the document to be parsed.
	 * @return {@link SdmxBeans} containing the structures from the stream (and optionally resolved structures based on the config)
	 */
	SdmxBeans parseStructures(ReadableDataLocation rdl) throws SdmxSyntaxException, CrossReferenceException, SdmxSemmanticException;

	/**
	 * Parses an input stream of structures
	 * @param rdl the stream to read
	 * @param config optional configuration
	 * @return {@link SdmxBeans} containing the structures from the stream (and optionally resolved structures based on the config)
	 */
	SdmxBeans parseStructures(ReadableDataLocation rdl, IStructureParseConfiguration config) throws SdmxSyntaxException, CrossReferenceException, SdmxSemmanticException;


}
