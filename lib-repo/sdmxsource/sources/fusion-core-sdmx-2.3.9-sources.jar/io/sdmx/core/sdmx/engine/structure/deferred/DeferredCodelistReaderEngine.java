package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.codelist.CodelistBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link CodelistBeanDeferred}
 */
public class DeferredCodelistReaderEngine extends AbstractDeferredStructureReaderEngine<CodelistBean> {
    private static DeferredCodelistReaderEngine INSTANCE;
    
    private DeferredCodelistReaderEngine() {
        super(CodelistBean.class);
    }
    
    public static DeferredCodelistReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredCodelistReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<CodelistBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new CodelistBeanDeferred(bean, loader);  //TODO Geo Codelists
    }

}
