package io.sdmx.core.sdmx.api.factory.structure;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.factory.PriorityFactory;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 *  Parses a stream of information to build SdmxBeans
 */
public interface StructureReaderFactory extends PriorityFactory, IPluggable {

	/**
	 * Parses the ReadableDataLocation to build the SdmxBeans, returns null if the structure format can not be determined from
	 * the information provided in the ReadableDataLocation (or from the underlying data)
	 * @param rdl
	 * @return
	 */
	SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder b);
	

}
