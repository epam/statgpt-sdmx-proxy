package io.sdmx.core.sdmx.model.ref;

import java.util.Map;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.core.sdmx.util.BeanRetreivalUtil;
import io.sdmx.im.beans.container.DatasetStructures;

/**
 * Encapsulates DSD references
 */
public class DataStructureReferences {
	private DataStructureBean dsd;
	private Map<ComponentBean, ICrossReferenceBean<? extends EnumeratedListBean>> enumerationReferences;
	
	public DataStructureReferences(SdmxBeanRetrievalManager retrievalManager, ICrossReferenceBean<? extends ConstrainableBean> sRef) {
		this(retrievalManager, new DatasetStructures(sRef.getReference(), retrievalManager).getDataStructure());
	}
	
	public DataStructureReferences(SdmxBeanRetrievalManager retrievalManager, DataStructureBean dsd) {
		this.enumerationReferences = BeanRetreivalUtil.getEnumeratedRepMap(retrievalManager, dsd);
		this.dsd = dsd;
	}

	public DataStructureBean getDsd() {
		return dsd;
	}

	public Map<ComponentBean, ICrossReferenceBean<? extends EnumeratedListBean>> getEnumerationReferences() {
		return enumerationReferences;
	}
	
}
