package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.im.beans.process.ProcessBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ProcessBeanDeferred}
 */
public class DeferredProcessReaderEngine extends AbstractDeferredStructureReaderEngine<ProcessBean> {
    private static DeferredProcessReaderEngine INSTANCE;
    
    private DeferredProcessReaderEngine() {
        super(ProcessBean.class);
    }
    
    public static DeferredProcessReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredProcessReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ProcessBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ProcessBeanDeferred(bean, loader);
    }

}
