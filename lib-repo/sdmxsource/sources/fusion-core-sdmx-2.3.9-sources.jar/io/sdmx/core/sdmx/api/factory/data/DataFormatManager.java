package io.sdmx.core.sdmx.api.factory.data;

import java.util.Set;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.manager.format.FormatManager;
import io.sdmx.api.sdmx.model.data.DataFormat;

public interface DataFormatManager extends FormatManager<DataFormat> {
	
	/**
	 * Determines the data format from a stream of data
	 * @param request
	 * @return
	 */
	DataFormat getDataFormat(ReadableDataLocation rdl);
	
	/**
	 * Sets the formats to support by their application/vnd headers
	 * 
	 * A default set is given below
	 * 	application/vnd.sdmx.genericdata+xml;version=1.0
		application/vnd.sdmx.genericdata+xml;version=2.0
		application/vnd.sdmx.genericdata+xml;version=2.1
		application/vnd.sdmx.generictimeseriesdata+xml;version=2.1
		application/vnd.sdmx.structurespecificdata+xml;version=1.0
		application/vnd.sdmx.structurespecificdata+xml;version=2.0
		application/vnd.sdmx.structurespecificdata+xml;version=2.1
		application/vnd.sdmx.structurespecifictimeseriesdata+xml;version=2.1
		application/vnd.sdmx.edi
		application/vnd.sdmx.json
		application/vnd.sdmx.data+json
		application/vnd.rdf+turtle
		application/vnd.rdf+json
		application/vnd.rdf+xml
		application/vnd.fusionxl
		application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
		application/vnd.datapoint
		application/vnd.csv
		application/vnd.csv-sdmx
		application/vnd.sdmx.data+csv;version=1.0.0
		application/vnd.csv-ts
		application/vnd.csv+,+:+true+true  //paramertised CSV

	 * @param supportOnlyFormats
	 */
	@Override
	void setSupportOnlyFormats(Set<String> supportOnlyFormats);
}
