package io.sdmx.core.sdmx.manager.structure;

import java.util.Set;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.sdmx.builder.SuperBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;
import io.sdmx.core.sdmx.builder.superbeans.SuperBeansBuilderImpl;
import io.sdmx.im.beans.container.SuperBeansImpl;
import io.sdmx.utils.sdmx.structure.SuperBeanRefUtil;

public class InMemorySdmxSuperBeanRetrievalManager implements SdmxSuperBeanRetrievalManager, Cache {
	protected SuperBeans superBeans;
	private SuperBeansBuilder superBeansBuilder = SuperBeansBuilderImpl.getInstance();
	
	/**
	 * Minimal constructor
	 * @param superBeans
	 */
	public InMemorySdmxSuperBeanRetrievalManager() {
		this(null);
	}
	
	/**
	 * @param superBeans
	 */
	public InMemorySdmxSuperBeanRetrievalManager(SuperBeans superBeans) {
		this.superBeans = superBeans;
		if(this.superBeans == null) {
			this.superBeans = new SuperBeansImpl();
		}
		if(superBeansBuilder == null) {
			superBeansBuilder = SuperBeansBuilderImpl.getInstance();
		}
	}
	
	/**
	 * Creates new super beans for the passed in beans container.
	 * @param beans
	 */
	public void addNewSuperBeans(SdmxBeans beans, SdmxBeanRetrievalManager retrievalManager) {
		superBeans = superBeansBuilder.build(beans, superBeans, retrievalManager);
	}
	
	/**
	 * Replaces super beans in this container
	 * @param beans
	 */
	public void replaceSuperBeans(SdmxBeans beans, SdmxBeanRetrievalManager retrievalManager) {
		superBeans = superBeansBuilder.build(beans, new SuperBeansImpl(), retrievalManager);
	}
	
	@Override
	public void clearCache() {
		this.superBeans = new SuperBeansImpl();
	}

	/**
	 * Returns a copy if the underlying super beans container
	 * @return
	 */
	public SuperBeans getSuperBeans() {
		SuperBeans reutrnBeans = new SuperBeansImpl(superBeans.getAllMaintainables());
		return reutrnBeans;
	}

	@Override
	public ConceptSchemeSuperBean getConceptSchemeSuperBean(IURNSingle<ConceptSchemeBean> ref) {
		return (ConceptSchemeSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getConceptSchemes(), ref);
	}

	@Override
	public DataflowSuperBean getDataflowSuperBean(IURNSingle<DataflowBean> ref) {
		return (DataflowSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getDataflows(), ref);
	}

	@Override
	public HierarchySuperBean getHierarchicCodeListSuperBean(IURNSingle<HierarchyBean> ref) {
		return (HierarchySuperBean)SuperBeanRefUtil.resolveReference(superBeans.getHierarchies(), ref);
	}

	@Override
	public DataStructureSuperBean getDataStructureSuperBean(IURNSingle<DataStructureBean> ref) {
		return (DataStructureSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getDataStructures(), ref);
	}

	@Override
	public MetadataStructureSuperBean getMetadataStructureSuperBean(IURNSingle<MetadataStructureDefinitionBean> ref) {
		return (MetadataStructureSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getMetadataStructures(), ref);
	}

	@Override
	public ProvisionAgreementSuperBean getProvisionAgreementSuperBean(IURNSingle<ProvisionAgreementBean> ref) {
		return (ProvisionAgreementSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getProvisions(), ref);
	}
	
	@Override
	public RegistrationSuperBean getRegistrationSuperBean(IURNSingle<RegistrationBean> ref) {
		return (RegistrationSuperBean)SuperBeanRefUtil.resolveReference(superBeans.getRegistrations(), ref);
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemeSuperBeans(IURN<ConceptSchemeBean> ref) {
		return new SuperBeanRefUtil<ConceptSchemeSuperBean>().resolveReferences(superBeans.getConceptSchemes(), ref);
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructureSuperBeans(IURN<DataStructureBean> ref) {
		return new SuperBeanRefUtil<DataStructureSuperBean>().resolveReferences(superBeans.getDataStructures(), ref);
	}
	
}
