package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.codelist.HierarchyBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link HierarchyBeanDeferred}
 */
public class DeferredHierarchyReaderEngine extends AbstractDeferredStructureReaderEngine<HierarchyBean> {
    private static DeferredHierarchyReaderEngine INSTANCE;
    
    private DeferredHierarchyReaderEngine() {
        super(HierarchyBean.class);
    }
    
    public static DeferredHierarchyReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredHierarchyReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<HierarchyBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new HierarchyBeanDeferred(bean, loader);
    }

}
