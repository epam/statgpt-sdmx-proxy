package io.sdmx.core.sdmx.api.manager.structure;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.im.beans.container.DatasetStructures;

/**
 *  Responsible for obtaining a collection of structures required to process a dataset
 */
public interface IDatasetStructuresRetrievalManager {

	/**
	 * Returns the {@link DatasetStructures} used to read the dataset
	 * @param sRef a reference to either a provision, dataflow, or dsd
	 * @return the dataset structures which includes the structure from the reference and the child structures (i.e if the
	 * sRef is to a Provision, then the Dataflow, DSD , and Data Provider will also be included in the response)
	 */
	IDatasetStructures getDatasetStructures(IURNSingle<? extends IDSDRelatedBean> sRef);
	
}
