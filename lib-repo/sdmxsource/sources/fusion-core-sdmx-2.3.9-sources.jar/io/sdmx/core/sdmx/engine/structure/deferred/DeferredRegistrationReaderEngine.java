package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.im.beans.registry.RegistrationBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link RegistrationBeanDeferred}
 */
public class DeferredRegistrationReaderEngine extends AbstractDeferredStructureReaderEngine<RegistrationBean> {
    private static DeferredRegistrationReaderEngine INSTANCE;
    
    private DeferredRegistrationReaderEngine() {
        super(RegistrationBean.class);
    }
    
    public static DeferredRegistrationReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredRegistrationReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<RegistrationBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new RegistrationBeanDeferred(bean, loader);
    }

}
