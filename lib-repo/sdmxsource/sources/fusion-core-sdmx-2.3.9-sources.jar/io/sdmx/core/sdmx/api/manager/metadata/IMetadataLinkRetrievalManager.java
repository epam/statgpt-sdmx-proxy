package io.sdmx.core.sdmx.api.manager.metadata;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;

public interface IMetadataLinkRetrievalManager {

	/**
	 * @param maint
	 * @return links for the maintainable
	 */
	IExternalMaintainableLinks getLinks(MaintainableBean maint);
	
}
