package io.sdmx.core.sdmx.api.error;

import io.sdmx.api.sdmx.exception.ErrorLimitException;

/**
 * Extends ExceptionHandler by making the handled exception specific to data reading
 */
public interface DataReaderExceptionHandler { 
	/**
	 * Handles the exception
	 * @param ex
	 * @throws ErrorLimitException if a limit is hit
	 */
	void handleException(DataFormatError ex) throws ErrorLimitException;

	/**
	 * Sets the dataset that is being validated
	 * @param dsIndex
	 */
	void setDataset(int dsIndex);
}
