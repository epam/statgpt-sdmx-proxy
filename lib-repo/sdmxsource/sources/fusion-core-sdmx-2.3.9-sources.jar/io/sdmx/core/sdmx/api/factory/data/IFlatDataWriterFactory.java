package io.sdmx.core.sdmx.api.factory.data;

import java.io.OutputStream;

import io.sdmx.core.sdmx.api.engine.data.IFlatDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * Can return a data reader if it understands the given data format
 */
public interface IFlatDataWriterFactory {

	/**
	 * Obtains a data writer engine for the given data type
	 * @param dataFormat used to describe the format to write the data in (and potentially contain extra information in the implementation)
	 * @param out the output stream to write to (can be null if this is not required, i.e the DataFormat may contain a writer)
	 * @return null if this factory is not capable of creating a data writer engine in the requested format
	 */
	IFlatDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery);
}
