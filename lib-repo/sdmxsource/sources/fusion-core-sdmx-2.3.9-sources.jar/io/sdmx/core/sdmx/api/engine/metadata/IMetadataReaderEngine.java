package io.sdmx.core.sdmx.api.engine.metadata;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;

public interface IMetadataReaderEngine {

	/**
	 * Parses the metadata set in the RDL into the Reference Metadat
	 * @param rdl
	 * @return
	 */
	IReferenceMetadataContainer parse(ReadableDataLocation rdl);
	
}
