package io.sdmx.core.sdmx.model.data;

import io.sdmx.api.sdmx.model.data.IDataPosition;

/**
 * Implements equals, hashcode, and tostring
 */
public abstract class AbstractDataPosition implements IDataPosition {
	private String asString;
	
	@Override
	public int hashCode() {
		return toPositionalString().hashCode();
	}

	@Override
	/**
	 * Two objects are equal if they are both IDataPosition with the same positional string
	 */
	public boolean equals(Object obj) {
		if(obj instanceof IDataPosition) {
			IDataPosition that = (IDataPosition) obj;
			return toPositionalString().equals(that.toPositionalString());
		}
		return super.equals(obj);
	}

	@Override
	public String toPositionalString() {
		if(asString == null) {
			StringBuilder sb = new StringBuilder(getPositionType().getPositionalPrefix()+":"); 
			buildPositionalString(sb);
			this.asString = sb.toString();
		}
		return asString;
	}
	
	@Override
	public String toString() {
		return toPositionalString();
	}

	/**
	 * Build the positional string, which is then cached on this instance
	 * @param sb to append to
	 * @return
	 */
	protected abstract void buildPositionalString(StringBuilder sb);
	
}
