package io.sdmx.core.sdmx.error;

import io.sdmx.api.exception.SdmxSemmanticException;

/**
 * Thrown by the data reader engine when it encounters a part of the dataset which is semantically
 * invalid.  The error may be recoverable, in which case the semantic exception does not effect the dataset,
 * or it may be unrecoverable, in which case the data reader will cease to be able to read any more data
 *
 */
public class DataReadException extends SdmxSemmanticException {
    private static final long serialVersionUID = 1L;
    private final int datasetPos;
    private final int keyPos;
    private final int observationPos;
    private final boolean recoverable;
    private final SEVERITY severity;
    private final TYPE type;

    public enum SEVERITY {
        LOW,
        MEDIUM,
        HIGH
    }

    // IMPORTANT NOTE
    // Do not think about correcting the spellings in the TYPE enum until you have read
    // JIRA issue FR-2026. These values are used in the client side and stored in the database
    public enum TYPE {
        ADDED_HEADER_ELEMNET,
        HEADER_ELEMENT_ORDER,
        HEADER_ELEMENT_DUPLICATE,
        MISSING_HEADER_ELEMENT,
        INVALID_HEADER_CONTENT,
        INVALID_ID_SYNTAX,
        CASE_SENSITVE,
        INVALID_DATE,
        INVALID_SENDER_RECIEVER,
        INVALILD_ACTION,
        DUPLICATE,
        INCORRECT_ROOT_NODE,
        ADDED_ATTRIBUTE,
        ADDED_ELEMNET,
        NAMESPACE,
        MISSING_XML_ATTRIBUTE,
        STRUCUTRE_REF_INCONSISTENT_WITH_HEADER,
        UNRECOVERABLE_ERROR,
        DATES_OUT_OF_SEQUENCE,
        INCONSISTENT_DATASET_ATTR,
        EDI_PROCESSING_ERROR,
        JSON_ATTRIBUTES_INDEX_OUT_OF_BOUNDS
    }

    public DataReadException(String errorMessage,
                             int datasetPos,
                             int keyPos,
                             int observationPos,
                             boolean recoverable,
                             SEVERITY severity,
                             TYPE type) {
        this(null, errorMessage, datasetPos, keyPos, observationPos, recoverable, severity, type);
    }

    public DataReadException(Throwable th,
                             String errorMessage,
                             int datasetPos,
                             int keyPos,
                             int observationPos,
                             boolean recoverable,
                             SEVERITY severity,
                             TYPE type) {
        super(th, errorMessage);
        this.datasetPos = datasetPos;
        this.keyPos = keyPos;
        this.observationPos = observationPos;
        this.recoverable = recoverable;
        this.severity = severity;
        this.type = type;
    }

    public SEVERITY getSeverity() {
        return severity;
    }

    public TYPE getType() {
        return type;
    }

    public int getDatasetPos() {
        return datasetPos;
    }

    public int getKeyPos() {
        return keyPos;
    }

    public int getObservationPos() {
        return observationPos;
    }

    public boolean isRecoverable() {
        return recoverable;
    }
}