package io.sdmx.core.sdmx.manager.schema;

import io.sdmx.api.sdmx.manager.schema.ISchemaFormatManager;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.core.sdmx.manager.format.AbstractFormatManager;
import io.sdmx.core.sdmx.manager.format.InformationFormatManager;

/**
 * High level manager which delegates question of response format to individal ISchemaFormatFactory
 */
public class SchemaFormatManager extends AbstractFormatManager<SchemaFormat> implements ISchemaFormatManager {
	
	public SchemaFormatManager(InformationFormatManager informationFormatManager) {
		super(informationFormatManager, SchemaFormat.class);
	}

}
