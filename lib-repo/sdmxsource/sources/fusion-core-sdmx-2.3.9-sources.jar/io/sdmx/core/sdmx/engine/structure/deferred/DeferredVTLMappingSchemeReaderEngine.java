package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.im.beans.transformation.VtlMappingSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link VtlMappingSchemeBeanDeferred}
 */
public class DeferredVTLMappingSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<IVtlMappingSchemeBean> {
    private static DeferredVTLMappingSchemeReaderEngine INSTANCE;
    
    private DeferredVTLMappingSchemeReaderEngine() {
        super(IVtlMappingSchemeBean.class);
    }
    
    public static DeferredVTLMappingSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredVTLMappingSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IVtlMappingSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new VtlMappingSchemeBeanDeferred(bean, loader);
    }

}
