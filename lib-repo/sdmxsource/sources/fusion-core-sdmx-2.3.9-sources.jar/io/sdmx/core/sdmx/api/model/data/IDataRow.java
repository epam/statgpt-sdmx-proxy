package io.sdmx.core.sdmx.api.model.data;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;

/**
 * Contains information about a row of data
 */
public interface IDataRow {
	
	default boolean seriesMatch(IDataRow row) {
		return this.getShortCode().equals(row.getShortCode());
	}
	
	/**
	 * Modify a single value, keep the short code and partial key if no dimension values were modified
	 * @param key the key in the map to modify
	 * @param value the new value, if null then the key will be removed from the map
	 * @return
	 */
	IDataRow modifyValue(String key, String value);
	
	/**
	 * @param newData new component id, to component value, in the case the value is null it will be eliminated from the rowdata
	 * @return a new row, where only the values passed in are modified
	 */
	IDataRow modifyValues(Map<String, String> newData);
	
	
	IDataRow modifyValues(Map<String, String> newData, Map<String, Set<String>> multiValueData, Map<String, Set<String>> multilingualValueData);
	
	/**
	 * @return true if one or more Dimensions (excluding the time dimension) are missing, which could be interpreted as a group or a row of attributes applicable to the full dataset
	 */
	boolean isPartialKey();
	
	/**
	 * @return a concatenation (colon separator) of the dimension values, in DSD specified order (excluding TIME_PERIOD)
	 */
	String getShortCode();
	
	/**
	 * @return includes TIME_PERIOD in the short code if there is one
	 */
	String getRowCode();

	/**
	 * Returns a dot concatenation of the dimension values, including the TIME_PERIOD, in DSD specified order.
	 * @return the String representing the row
	 */
	String getRowCodeAllDimensionsWithWildcard();
	
	/**
	 * @param compId
	 * @return reported value for the component
	 */
	default String getReportedValue(String compId) {
		return getRowData().get(compId);
	}
	
	/**
	 * @return an immutable map, the data for the row, component id to component value
	 */
	Map<String, String> getRowData();
	
	/**
	 * @param compId
	 * @return reported value for the component
	 */
	default Set<String> getReportedValues(String compId) {
		return getMultiValueData().get(compId);
	}

	default Set<String> getReportedMultilingualValues(String compId){
		return getMultilingualValueData().get(compId);
	}
	
	/**
	 * @return an immutable map of data that contains multiple values for one component id - if none exist, an empty map is returned
	 */
	Map<String, Set<String>> getMultiValueData();

	/**
	 * @return an immutable map of data that contains multiple multilingual values for one component id - if none exist, an empty map is returned
	 */
	Map<String, Set<String>> getMultilingualValueData();

	/**
	 * @return all locales used for multilingual data in a row
	 */
	Set<String> getLocales();
	
	/**
	 * @return the data structure to which this row conforms to, as well as optional links to Dataflow, Provision, and DataProivder, this will not be null
	 */
	IDatasetStructures getDatasetStructures();
}
