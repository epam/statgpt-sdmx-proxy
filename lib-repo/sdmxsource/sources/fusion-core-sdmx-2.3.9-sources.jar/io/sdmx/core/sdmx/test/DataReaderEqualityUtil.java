package io.sdmx.core.sdmx.test;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.utils.core.object.ObjectUtil;

public class DataReaderEqualityUtil {

	/**
	 * Asserts the contents of both readers are the same
	 * @param dre1
	 * @param dre2
	 */
	public static void assertEquals(DataReaderEngine dre1, DataReaderEngine dre2) {
		while(dre1.moveNextDataset()) {
			ObjectUtil.assertTrue(dre2.moveNextDataset());
			ObjectUtil.assertEquals("Headers are not Equal", dre1.getHeader(), dre2.getHeader());
			ObjectUtil.assertEquals("Dataset Attributes are not Equal", dre1.getDatasetAttributes(), dre2.getDatasetAttributes());
			ObjectUtil.assertEquals("Dataset Attributes are not Equal", dre1.getCurrentDatasetHeaderBean(), dre2.getCurrentDatasetHeaderBean());
			while(dre1.moveNextKeyable()) {
				ObjectUtil.assertTrue(dre2.moveNextKeyable());
				ObjectUtil.assertEquals("Keys are not Equal -> " + dre1.getCurrentKey().getShortCode() + " and "+dre2.getCurrentKey().getShortCode(), dre1.getCurrentKey(), dre2.getCurrentKey());
				while(dre1.moveNextObservation()) {
					ObjectUtil.assertTrue(dre2.moveNextObservation());
					ObjectUtil.assertEquals("Obs are not Equal", dre1.getCurrentObservation(), dre2.getCurrentObservation());
				}
				ObjectUtil.assertFalse("Unexpected Observation", dre2.moveNextObservation());
				ObjectUtil.assertEquals("Obs Count is not Equal", dre1.getKeyablePosition(), dre2.getKeyablePosition());
			}
			ObjectUtil.assertFalse("Unexpected key", dre2.moveNextKeyable());
			ObjectUtil.assertEquals("Key Count is not Equal", dre1.getKeyablePosition(), dre2.getKeyablePosition());
		}
		ObjectUtil.assertFalse("Unexpected Dataset", dre2.moveNextDataset());
		ObjectUtil.assertEquals("Dataset Count is not Equal", dre1.getDatasetPosition(), dre2.getDatasetPosition());
	}
}
