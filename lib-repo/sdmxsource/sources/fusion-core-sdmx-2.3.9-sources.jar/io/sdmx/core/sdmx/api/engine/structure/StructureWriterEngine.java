package io.sdmx.core.sdmx.api.engine.structure;

import java.io.OutputStream;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;

/**
 * Classes that support this interface can write one or many structures.
 * <p/>
 * The location and format that the structures are written to and in, are implementation dependent.
 */
public interface StructureWriterEngine {

	/**
	 * Writes the beans to the output location in the format specified by the implementation
	 * @param beans
	 * @param additionalLinks optional additional links, the map key is an identifiable
	 * @param schemaVersion
	 */
	void writeStructures(SdmxBeans beans,
	                     Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks,
	                     OutputStream out);
	
	/**
	 * Writes the bean out to the output location in the format specified by the implementation
	 * @param beans
	 * @param schemaVersion
	 */
	void writeStructure(MaintainableBean bean,
	                    IExternalMaintainableLinks additionalLinks,
	                    OutputStream out);

	/**
	 * Returns true if the given structure type is a supported output format for this factory
	 * @param structureType
	 * @return
	 */
	boolean isSupportedType(MaintainableBean structure);
	
	/**
	 * Returns an immutable Set of supported structure type for this factory
	 * @return
	 */
	Set<SDMX_STRUCTURE_TYPE> getSupportedTypes();
	
}
