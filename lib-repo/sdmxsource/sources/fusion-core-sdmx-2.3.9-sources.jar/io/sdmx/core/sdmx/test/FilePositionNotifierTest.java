package io.sdmx.core.sdmx.test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.IPositionAwareDataReaderEngine;
import io.sdmx.api.sdmx.model.data.IDataPosition.POSITION_TYPE;
import io.sdmx.api.sdmx.model.data.IFilePosition;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.engine.data.PositionAwareDataReaderEngine;
import io.sdmx.utils.core.io.PathUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

/**
 * Wraps a Path, FilePositionNotifier and DataReaderEngine for unit tests
 *
 * This class moves the DataReaderEngine to the next dataset, key, or obs and asserts the file position notification
 * pulls back the same string from the file that the user expects to see
 */
public class FilePositionNotifierTest {
	private Path file;
	private IPositionAwareDataReaderEngine<IFilePosition> dre;

	public FilePositionNotifierTest(Path file, DataReaderEngine dre) {
		this.dre = new PositionAwareDataReaderEngine<>(dre);
		this.file = file;
	}

	/**
	 * Move to the next dataset, check the position against the asserted snippet
	 * @param assertSnippet e.g. <Dataset> or null to assert no position notified
	 * note all tabs and carriage returns whitespace will be ignored in the compare
	 */
	public void assertNextDataset(String assertSnippet) {
		ObjectUtil.assertTrue(dre.moveNextDataset());
		runPositionCompare(file, dre.getPosition(), assertSnippet);
	}
	
	/**
	 * Move to the next dataset, check there are no Dataset Attributes
	 */
	public void assertNextDatasetNoAttributes() {
		ObjectUtil.assertTrue(dre.moveNextDataset());
		if (!dre.getPosition().getPositionType().equals(POSITION_TYPE.UNAVAILABLE)) {
		    throw new IllegalArgumentException("Position type is unavailable");
		}
	}
	
	public void assertDatasetAttributes(String assertSnippet, IFilePosition position) {
		runPositionCompare(file, position, assertSnippet);
	}

	/**
	 * Move to the next key (group or series), check the position against the asserted snippet
	 * @param assertSnippet e.g. <Series attr1="abc"> or null to assert no position notified
	 * note all tabs and carriage returns whitespace will be ignored in the compare
	 */
	public Keyable assertNextKey(String assertSnippet) {
		ObjectUtil.assertTrue(dre.moveNextKeyable());
		runPositionCompare(file, dre.getPosition(), assertSnippet);
		return dre.getCurrentKey();
	}

	/**
	 * Move to the next observation, check the position against the asserted snippet
	 * @param assertSnippet e.g. <Obs attr1="abc"> or null to assert no position notified
	 * note all tabs and carriage returns whitespace will be ignored in the compare
	 */
	public Observation assertNextObs(String assertSnippet) {
		ObjectUtil.assertTrue(dre.moveNextObservation());
		runPositionCompare(file, dre.getPosition(), assertSnippet);
		return dre.getCurrentObservation();
	}

	public void assertNoMoreDatasets() {
		if (dre.moveNextDataset()) {
		    throw new IllegalArgumentException("Expected no more datasets");
		}
	}

	public void assertNoMoreKeys() {
		if (dre.moveNextKeyable()) {
		    throw new IllegalArgumentException("Expected no more Keys");
		}
	}

	public void assertNoMoreObs() {
		if (dre.moveNextObservation()) {
		    throw new IllegalArgumentException("Expected no more observations");
		}
	}
	
	public DataReaderEngine getDataReaderEngine() {
		return dre;
	}

	private void runPositionCompare(Path filePath, IFilePosition position, String assertString)  {
		if(assertString == null) {
			ObjectUtil.assertNull(position);
		} else {
			try  {
				byte[] bytes = PathUtil.getContentsFromOffset(filePath, position.getOffset(), position.getBytes());
				String actual = new String(bytes, StandardCharsets.UTF_8);
				actual= actual.replace("\t", "");
				actual = StringUtil.removeLineBreaks(actual);

				assertString = assertString.replace("\t", "");
				assertString = StringUtil.removeLineBreaks(assertString);

				if(!assertString.equals(actual)) {
					System.out.println("assert =" +assertString);
					System.out.println("actual =" +actual);
					ObjectUtil.assertEquals(assertString, actual);
				}
			} catch(Exception e) {
				System.out.println("IFilePosition: " + position);
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Ensure that the next Observation exists, but is reporting an "Unavailable" position
	 * @return the next observation
	 */
	public Observation assertNextObsIsUnavailable() {
		ObjectUtil.assertTrue(dre.moveNextObservation());
		IFilePosition position = dre.getPosition();
		ObjectUtil.assertTrue(position.getPositionType().equals(POSITION_TYPE.UNAVAILABLE));
		ObjectUtil.assertTrue(position.getOffset() == -1);
		ObjectUtil.assertTrue(position.getBytes() == -1);
		return dre.getCurrentObservation();
	}
}
