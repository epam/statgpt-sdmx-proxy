package io.sdmx.core.sdmx.model.type;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;


/**
 * Serialization for Integer supporting non-nullable values.
 *
 * Note: nullable objects cannot be used  as keys or values of a MVMap,
 *       only as a component of other types.
 */
public class DT_Integer extends BasicDataType<Integer> {
  private static final DT_Integer NULLABLE_INSTANCE = new DT_Integer(true);
  private static final DT_Integer GENERIC_INSTANCE = new DT_Integer(false);

  private final boolean nullable;

  private DT_Integer(boolean nullable) {
    this.nullable = nullable;
  }

  public static DT_Integer getInstance(boolean nullable) {
    return nullable ? NULLABLE_INSTANCE : GENERIC_INSTANCE;
  }

  @Override
  public int compare(Integer a, Integer b) {
    return a.compareTo(b);
  }

  @Override
  public int getMemory(Integer obj) {
    return 24;
  }

  // encode length to avoid having a long varint when s is null
  private void writeLength(WriteBuffer buf, String s) {
    buf.putVarInt(s == null ? 0 : s.length() + 1);
  }

  // decode length according to encoding performed at write time
  private Integer readLength(ByteBuffer buf) {
    int len = DataUtils.readVarInt(buf);

    return (len == 0) ? null : len - 1;
  }

  @Override
  public void write(WriteBuffer buf, Integer i) {
    if (nullable && (i == null))
      buf.putVarInt(0);
    else {
      if (nullable)
        buf.putVarInt(1);

      buf.putVarInt(i);
    }
  }

  @Override
  public Integer read(ByteBuffer buf) {
    Integer i = DataUtils.readVarInt(buf);

    if (nullable)
      i = (i == 0) ? null : DataUtils.readVarInt(buf);

    return i;
  }

  @Override
  public Integer[] createStorage(int size) {
    return new Integer[size];
  }
}
