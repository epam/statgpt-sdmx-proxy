package io.sdmx.core.sdmx.engine.metadata;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IMetadatasetStructures;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.util.StructureReferenceBeanUtil;

/**
 * Validates the links in a metadata set to ensure it is linking to structure(s) that are allowed
 */
public class MetadataLinkValidationEngine extends AbstractMetadataValidationEngine {

	public MetadataLinkValidationEngine(SdmxBeanRetrievalManager beanRetrievalManager) {
		super(beanRetrievalManager);
	}

	@Override
	protected void validate(IReportedMetadataSetBean mds, IMetadatasetStructures mdsStructures) {
		validateAgainstRefs(mds, mdsStructures.getMetadataflow().getTargets());
		if(mdsStructures.getProvisionAgreement() != null) {
			validateAgainstRefs(mds, mdsStructures.getProvisionAgreement().getTargets());
		}
	}

	private void validateAgainstRefs(IReportedMetadataSetBean mds, List<ICrossReferenceBeanBase> allowedRefs) {
		if(allowedRefs.size() == 0) {  //unrestricted
			return;
		}
		for(ICrossReferenceBeanBase targetRef : mds.getTargets()) {
			if(!isValidateTarget(targetRef, allowedRefs)) {
				throw new SdmxSemmanticException("Metadata Set '"+mds.getShortURN()+"' contains illegal Target '"+targetRef.getReference().getURN()+"'");
			}
		}
	}

	private boolean isValidateTarget(ICrossReferenceBeanBase targetRef, List<ICrossReferenceBeanBase> allowedRefs) {
		for(ICrossReferenceBeanBase ref : allowedRefs) {
			if(StructureReferenceBeanUtil.isSubset(ref, targetRef)) {
				return true;
			}
		}
		return false;
	}
}
