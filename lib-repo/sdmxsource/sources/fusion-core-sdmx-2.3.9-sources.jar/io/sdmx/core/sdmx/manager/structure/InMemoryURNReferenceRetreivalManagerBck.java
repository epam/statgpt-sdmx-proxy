package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.utils.core.collection.CollectionUtil;

public class InMemoryURNReferenceRetreivalManagerBck implements IURNReferenceRetreivalManager {

	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> references;  			    //Identifiable URN to Maintainable URN
	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> indirectReferences;		    //Identifiable URN to Maintainable URN

	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencesWeak;  			//Identifiable URN to Maintainable URN
	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> indirectReferencesWeak;		//Identifiable URN to Maintainable URN

	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> indirectReferencing;		    //Identifiable URN to Maintainable URN
	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencing; 			    //Identifiable URN to Maintainable URN

	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> indirectReferencingWeak;		//Identifiable URN to Maintainable URN
	private Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencingWeak; 			//Identifiable URN to Maintainable URN

	
	private Map<IURNMaintainable<?>, Set<IURNAbsolute<?>>> maintainableComposites = new HashMap<>();
	
	public InMemoryURNReferenceRetreivalManagerBck(ICrossReferenceLookupTable lookupTable) {
		int referencesCount = lookupTable.getMaintDirectReferences().size();
		this.references = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();  
		this.referencing = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();
		this.referencesWeak = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();
		this.referencingWeak = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();

		int indirectReferencesCount = lookupTable.getMaintIndirectReferences().size();
		this.indirectReferences = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();  
		this.indirectReferencing = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();
		this.indirectReferencesWeak = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();
		this.indirectReferencingWeak = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();
		
		populateReferencesMaps(lookupTable.getMaintDirectReferences(), this.references, this.referencing, this.referencesWeak, this.referencingWeak);
		populateReferencesMaps(lookupTable.getMaintIndirectReferences(), this.indirectReferences, this.indirectReferencing, this.indirectReferencesWeak, this.indirectReferencingWeak);
		
		
		
		//make immutable
		references = CollectionUtil.getImmutableMapOfSets(references);
		referencing = CollectionUtil.getImmutableMapOfSets(referencing);
		indirectReferences = CollectionUtil.getImmutableMapOfSets(indirectReferences);
		indirectReferencing = CollectionUtil.getImmutableMapOfSets(indirectReferencing);
	}
	
	private void populateReferencesMaps(Set<IMaintainableReferences> mReferences, 
										Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencesMap,  
										Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencingMap,  
										Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencesWeakMap,  
										Map<IURNAbsolute<?>, Set<IURNMaintainable<?>>> referencingWeakMap) {
		for(IMaintainableReferences<?> mRef : mReferences) {
			Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>>  references = mRef.getReferences();
			
			Set<IURNAbsolute<?>> identComposites = references.keySet();
			if(maintainableComposites.containsKey(mRef.getMaintURN())) {
				Set<IURNAbsolute<?>> mutableSet = new HashSet<>(maintainableComposites.get(mRef.getMaintURN()));
				mutableSet.addAll(identComposites);
				maintainableComposites.put(mRef.getMaintURN(), Collections.unmodifiableSet(mutableSet));
			} else {
				maintainableComposites.put(mRef.getMaintURN(), identComposites);
			}
			
			for(IURNAbsolute<?> identURNFrom : identComposites) {
				IURNMaintainable<?> maintURNFrom = identURNFrom.getMaintainableURN();
				for(ICrossReferenceBeanResolved<?> identURNTo : references.get(identURNFrom)) {
					IURNMaintainable<?> maintURNTo = identURNTo.getReference().getMaintainableURN(); 
					
					if(identURNTo.isWeakReference()) {
						CollectionUtil.addToMappedSet(referencesWeakMap, identURNFrom, maintURNTo);
						CollectionUtil.addToMappedSet(referencingWeakMap, identURNTo.getReference(), maintURNFrom);
					} else {
						CollectionUtil.addToMappedSet(referencesMap, identURNFrom, maintURNTo);
						CollectionUtil.addToMappedSet(referencingMap, identURNTo.getReference(), maintURNFrom);
					}
				}
			}
		}
	}
	
	@Override
	public Set<IURNMaintainable<?>> whoReferencesMe(IURNAbsolute<?> target, boolean includeIndirect, boolean includeWeak) {
		if(target.isMaintainableReference()) {
			Set<IURNMaintainable<?>> returnSet = new HashSet<>();
			Set<IURNAbsolute<?>> identComposites = maintainableComposites.get(target);
			if(identComposites != null) {
				for(IURNAbsolute<?> identTarget : identComposites) {
					Set<IURNMaintainable<?>> refs = whoReferencesMeIdent(identTarget, includeIndirect, includeWeak);
					if(refs != null) {
						returnSet.addAll(refs);
					}
				}
			}
			return Collections.unmodifiableSet(returnSet);
		} 
		return whoReferencesMeIdent(target, includeIndirect, includeWeak);
		
	}
	
	private Set<IURNMaintainable<?>> whoReferencesMeIdent(IURNAbsolute<?> target, boolean includeIndirect, boolean includeWeak) {
		Set<IURNMaintainable<?>> returnReferences = referencing.get(target);
		
		if(includeWeak || includeIndirect) {
			returnReferences = returnReferences == null ? new HashSet<>() : new HashSet<>(returnReferences);
			if(includeWeak) {
				mergeSet(returnReferences, referencingWeak.get(target));
			}
			if(includeIndirect) {
				mergeSet(returnReferences, indirectReferencing.get(target));
				if(includeWeak) {
					mergeSet(returnReferences, indirectReferencing.get(target));
				}
			}
			returnReferences = Collections.unmodifiableSet(returnReferences);
		}
		return returnReferences;
	}
	
	@Override
	public Set<IURNMaintainable<?>> whoDoIReference(IURNAbsolute<?> source, boolean includeIndirect, boolean includeWeak) {
		if(source.isMaintainableReference()) {
			Set<IURNMaintainable<?>> returnSet = new HashSet<>();
			Set<IURNAbsolute<?>> identComposites = maintainableComposites.get(source);
			if(identComposites != null) {
				for(IURNAbsolute<?> identTarget : identComposites) {
					Set<IURNMaintainable<?>> refs = whoDoIReferenceIdent(identTarget, includeIndirect, includeWeak);
					if(refs != null) {
						returnSet.addAll(refs);
					}
				}
			}
			return Collections.unmodifiableSet(returnSet);
		} 
		return whoDoIReferenceIdent(source, includeIndirect, includeWeak);
	}

	private Set<IURNMaintainable<?>> whoDoIReferenceIdent(IURNAbsolute<?> source, boolean includeIndirect, boolean includeWeak) {
		Set<IURNMaintainable<?>> returnReferences = references.get(source);
		
		if(includeWeak || includeIndirect) {
			returnReferences = returnReferences == null ? new HashSet<>() : new HashSet<>(returnReferences);
			if(includeWeak) {
				mergeSet(returnReferences, referencesWeak.get(source));
			}
			if(includeIndirect) {
				mergeSet(returnReferences, indirectReferences.get(source));
				if(includeWeak) {
					mergeSet(returnReferences, indirectReferencesWeak.get(source));
				}
			}
			returnReferences = Collections.unmodifiableSet(returnReferences);
		}
		return returnReferences;
		
		
	}
	
	private void mergeSet(Set<IURNMaintainable<?>> addTo, Set<IURNMaintainable<?>> add) {
		if(add != null) {
			addTo.addAll(add);
		}
	}

}
