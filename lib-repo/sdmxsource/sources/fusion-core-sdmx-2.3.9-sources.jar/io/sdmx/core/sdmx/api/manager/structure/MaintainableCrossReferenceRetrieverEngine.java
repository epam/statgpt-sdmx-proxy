
package io.sdmx.core.sdmx.api.manager.structure;

import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * Given a maintainable structure, this will return a set of all the CrossReferenceBean structures that it uses to reference
 * other structures - the purpose of this is to include not only direct references, but indirect cross references which are not availble on the 
 * MaintainableBean API
 */
public interface MaintainableCrossReferenceRetrieverEngine {

	/**
	 * Returns the set of cross referenced structures from this maintainable
	 * @param maintainable
	 * @see ICrossReferenceBean.isIndirectReference
	 * @return
	 */
	Set<ICrossReferenceBean<?>> getCrossReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintainable);
	
	
	default Set<ICrossReferenceBean<?>> getCrossReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintainable, boolean excludeWeakReferences, boolean excludeIndirectReferences) {
		if(excludeIndirectReferences && excludeWeakReferences) {
			return Collections.emptySet();
		}
		Set<ICrossReferenceBean<?>> refs = getCrossReferences(retrievalManager, maintainable);
		if(excludeWeakReferences) {
			refs = refs.stream().filter(e -> e.isWeakReference()==false).collect(Collectors.toSet());
		}
		if(excludeIndirectReferences) {
			refs = refs.stream().filter(e -> e.isIndirectReference()==false).collect(Collectors.toSet());
		}
		return refs;
	}
}
