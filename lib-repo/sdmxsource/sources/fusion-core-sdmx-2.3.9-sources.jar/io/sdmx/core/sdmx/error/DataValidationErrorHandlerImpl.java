package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorLimitException;

/**
 * Catches all the errors and stores them, there is no limit
 */
public class DataValidationErrorHandlerImpl implements DataValidationErrorHandler {
	private Set<DataError> errors = new LinkedHashSet<>();
	private Set<String> ignoreCategories;
	
	
	public DataValidationErrorHandlerImpl() {}
	

	public DataValidationErrorHandlerImpl(Set<String> ignoreCategories) {
		this.ignoreCategories = Collections.unmodifiableSet(ignoreCategories);
	}

	@Override
	public void handleError(DataError err) throws ErrorLimitException {
		if(ignoreCategories != null && ignoreCategories.contains(err.getErrorCategory())) {
			return;
		}
		errors.add(err);
	}

	public List<DataError> getErrors() {
		return new ArrayList<DataError>(errors);
	}

	public int getErrorCount() {
		return errors.size();
	}
	
	public boolean hasErrors() {
		return getErrorCount() > 0;
	}
}
