package io.sdmx.core.sdmx.model.data;

import io.sdmx.api.sdmx.model.data.IFilePosition;

/**
 * Represents a FilePosition where the offset and byte length are for some reason unavailable.
 * An example of this is in an EDI delete message. The observations are not present and so when asking for the next observation, this class will be
 * returned as the position.
 */
public class UnavailableFilePosition extends AbstractDataPosition implements IFilePosition {
	
	public UnavailableFilePosition() {
	}

	@Override
	public long getOffset() {
		return -1;
	}

	@Override
	public long getBytes() {
		return -1;
	}
	
	@Override
	protected void buildPositionalString(StringBuilder sb) {
		// Intentionally no operation here
	}

	@Override
	public POSITION_TYPE getPositionType() {
		return POSITION_TYPE.UNAVAILABLE;
	}

}
