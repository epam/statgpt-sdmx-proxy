package io.sdmx.core.sdmx.model.ref;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;
import io.sdmx.utils.sdmx.xs.ResolvedCrossReferenceBean;

/**
 * Holds a set of references of 'reference from' to a set of 'reference to' broken down by either a direct reference (i.e a Dimension references a Concept)
 * and in direct references (i.e a Constraint refers to Codes but the reference is not direct, i.e the Constraint object does not have a CrossRefernece object to the Code)
 */
public class ReferenceResolution implements IReferenceResolution {
	private Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> directReferences = new HashMap<>();
	private Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> indirectReferences = new HashMap<>();
	private Map<IdentifiableBean, Set<ICrossReferenceBean<?>>> missingRefs = new HashMap<>();
	
	private Set<ICrossReferenceBeanResolved<?>> allReferences = new HashSet<>();

	@Override
	public Set<ICrossReferenceBeanResolved<?>> getResolvedReferences() {
		return Collections.unmodifiableSet(allReferences);
	}

	public void storeMissingRef(ICrossReferenceBean<?> missingReference) {
		IdentifiableBean refFromIdentifiable  = getIdentifiable(missingReference.getReferencedFrom());
		Set<ICrossReferenceBean<?>> refList;
		if(missingRefs.containsKey(refFromIdentifiable)) {
			refList = missingRefs.get(refFromIdentifiable);
		} else {
			refList = new HashSet<>();
			missingRefs.put(refFromIdentifiable, refList);
		}
		refList.add(missingReference);
	}
	
	public void storeRef(ICrossReferenceBeanResolved<?> crossReferenceBeanResolved) {
		allReferences.add(crossReferenceBeanResolved);
		
		ICrossReferenceBean<?> baseReference = crossReferenceBeanResolved.getBaseReference();
		Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>>  map = baseReference.isIndirectReference() ? indirectReferences : directReferences;
		IdentifiableBean refFromIdentifiable  = getIdentifiable(baseReference.getReferencedFrom());
		Set<ICrossReferenceBeanResolved<?>> refList;
		if(map.containsKey(refFromIdentifiable)) {
			refList = map.get(refFromIdentifiable);
		} else {
			refList = new HashSet<>();
			map.put(refFromIdentifiable, refList);
		}
		refList.add(crossReferenceBeanResolved);
		
	}
	
	public void storeAgencyRef(MaintainableBean maint, AgencyBean reference) {
		CrossReferenceBean<AgencyBean> acyRef = CrossReferenceBean.build(maint, reference.getURN());
		ICrossReferenceBeanResolved<AgencyBean> resolved = ResolvedCrossReferenceBean.build(acyRef, reference);
		storeRef(resolved);
	}


//	public void storeRef(SDMXBean referencedFrom, IdentifiableBean reference, boolean isIndirectReference) {
//		Map<IdentifiableBean, Set<IdentifiableBean>>  map = isIndirectReference ? indirectReferences : directReferences;
//		IdentifiableBean refFromIdentifiable  = getIdentifiable(referencedFrom);
//		Set<IdentifiableBean> refList;
//		if(map.containsKey(refFromIdentifiable)) {
//			refList = map.get(refFromIdentifiable);
//		} else {
//			refList = new HashSet<>();
//			map.put(refFromIdentifiable, refList);
//		}
//		refList.add(reference);
//	}

	/**
	 * Merge the direct references, indirect references, and missing references into this ReferenceResolution
	 * @param referenceResolution
	 */
	public void merge(ReferenceResolution referenceResolution) {
		populateIdentifiableMap(referenceResolution.directReferences, directReferences);
		populateIdentifiableMap(referenceResolution.indirectReferences, indirectReferences);
		CollectionUtil.mergeMap(referenceResolution.missingRefs, missingRefs);
	}
	
	public void throwMissingReferenceException() {
		for(IdentifiableBean missingRefFrom : getMissingReferences()) {
			for(ICrossReferenceBean<?> missingRefTo : getMissingReferences(missingRefFrom)) {
				throw new CrossReferenceException(missingRefTo);
			}
		}
	}
	
	
	@Override
	public boolean hasMissingReferences() {
		return this.missingRefs.size() > 0;
	}


	@Override
	public Set<IdentifiableBean> getMissingReferences() {
		return missingRefs.keySet();
	}
	
	@Override
	public Set<ICrossReferenceBean<?>> getMissingReferences(IdentifiableBean identifiable) {
		return missingRefs.get(identifiable);
	}

	@Override
	public Map<IdentifiableBean, Set<ICrossReferenceBean<?>>> getMissingReferencesMap() {
		return missingRefs;
	}

	@Override
	public Set<IdentifiableBean> getReferences(RESOLUTION_TYPE refType) {
		switch(refType) {
		case BOTH:
			Set<IdentifiableBean> returnRefs = new HashSet<>(getDirectReferences());
			returnRefs.addAll(getIndirectReferences());
			return returnRefs;
		case DIRECT:  return getDirectReferences();
		case INDIRECT: return getIndirectReferences();
		}
		return Collections.emptySet();
	}

	@Override
	public Set<ICrossReferenceBeanResolved<?>> getReferences(IdentifiableBean identifiable, RESOLUTION_TYPE refType) {
		switch(refType) {
		case BOTH:
			Set<ICrossReferenceBeanResolved<?>> returnRefs = new HashSet<>(getDirectReferences(identifiable));
			returnRefs.addAll(getIndirectReferences(identifiable));
			return returnRefs;
		case DIRECT:  return getDirectReferences(identifiable);
		case INDIRECT: return getIndirectReferences(identifiable);
		}
		return Collections.emptySet();
	}
	

	private Set<IdentifiableBean> getDirectReferences() {
		return directReferences.keySet();
	}

	private Set<ICrossReferenceBeanResolved<?>> getDirectReferences(IdentifiableBean identifiable) {
		Set<ICrossReferenceBeanResolved<?>> returnSet = directReferences.get(identifiable);
		if(returnSet == null) {
			return Collections.emptySet();
		}
		return returnSet;
	}

	private Set<IdentifiableBean> getIndirectReferences() {
		return indirectReferences.keySet();
	}

	private Set<ICrossReferenceBeanResolved<?>> getIndirectReferences(IdentifiableBean identifiable) {
		Set<ICrossReferenceBeanResolved<?>> returnSet = indirectReferences.get(identifiable);
		if(returnSet == null) {
			return Collections.emptySet();
		}
		return returnSet;
	}

	/**
	 * @param includeIndirect if true,indirect references are also included
	 * @return maintainable to a set of identifiables that it references
	 */
	@Override
	public Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> getIdentifiableReferenceMap(RESOLUTION_TYPE refType) {
		Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> maintRefMap;
		switch(refType) {
		case DIRECT:
			maintRefMap = new HashMap<>(directReferences.size());
			populateIdentifiableMap(directReferences, maintRefMap);
		case INDIRECT:
			maintRefMap = new HashMap<>(indirectReferences.size());
			populateIdentifiableMap(directReferences, maintRefMap);
			break;
		case BOTH:
		default:
			maintRefMap = new HashMap<>(indirectReferences.size()+directReferences.size());
			populateIdentifiableMap(indirectReferences, maintRefMap);
			populateIdentifiableMap(directReferences, maintRefMap);
			break;
		}
		return maintRefMap;
	}

	/**
	 * @param includeIndirect if true,indirect references are also included
	 * @return maintainable to a set of identifiables that it references
	 */
	@Override
	public Map<MaintainableBean, Set<ICrossReferenceBeanResolved<?>>> getMaintainableReferenceMap(boolean includeIndirect) {
		Map<MaintainableBean, Set<ICrossReferenceBeanResolved<?>>> maintRefMap = new HashMap<>();
		mergeMap(directReferences, maintRefMap);
		if(includeIndirect) {
			mergeMap(indirectReferences, maintRefMap);
		}
		return maintRefMap;
	}

	@Override
	public SdmxBeans getAllBeans(RESOLUTION_TYPE refType) {
		SdmxBeans returnBeans = new SdmxBeansImpl();
		returnBeans.addIdentifiables(getAllReferenced(refType).stream().map(e -> e.getResolvedBean().getMaintainableParent()).collect(Collectors.toList()));
		return returnBeans;
	}

	@Override
	public Set<ICrossReferenceBeanResolved<?>> getAllReferenced(RESOLUTION_TYPE refType) {
		Set<ICrossReferenceBeanResolved<?>> returnSet = new HashSet<>();
		switch(refType) {
		case BOTH:
			for(IdentifiableBean refFrom : getDirectReferences()) {
				returnSet.addAll(getDirectReferences(refFrom));
			}
			for(IdentifiableBean refFrom : getIndirectReferences()) {
				returnSet.addAll(getIndirectReferences(refFrom));
			}
			break;
		case DIRECT:
			for(IdentifiableBean refFrom : getDirectReferences()) {
				returnSet.addAll(getDirectReferences(refFrom));
			}
			break;
		case INDIRECT:
			for(IdentifiableBean refFrom : getIndirectReferences()) {
				returnSet.addAll(getIndirectReferences(refFrom));
			}
			break;
		}
		return returnSet;
	}

	/**
	 * @param includeIndirect if true,indirect referneces are also included
	 * @return maintainable to a set of identifiables that it references
	 */
	private void populateIdentifiableMap(Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> fromMap, Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> toMap) {
		for(IdentifiableBean ident : fromMap.keySet()) {
			Set<ICrossReferenceBeanResolved<?>> refs = toMap.get(ident);
			if(refs == null) {
				refs = new HashSet<>();
				toMap.put(ident, refs);
			}
			refs.addAll(fromMap.get(ident));
		}
	}


	private IdentifiableBean getIdentifiable(SDMXBean referencedFrom) {
		return referencedFrom.getParent(IdentifiableBean.class, true);
	}

	/**
	 * @param includeIndirect if true,indirect references are also included
	 * @return maintainable to a set of identifiables that it references
	 */
	private void mergeMap(Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> fromMap, Map<MaintainableBean, Set<ICrossReferenceBeanResolved<?>>> toMap) {
		for(IdentifiableBean ident : fromMap.keySet()) {
			MaintainableBean maint = ident.getMaintainableParent();
			Set<ICrossReferenceBeanResolved<?>> refs = toMap.get(maint);
			if(refs == null) {
				refs = new HashSet<>();
				toMap.put(maint, refs);
			}
			refs.addAll(fromMap.get(ident));
		}
	}
}
