package io.sdmx.core.sdmx.api.factory.structure;

import io.sdmx.api.format.IFormatFactory;
import io.sdmx.api.sdmx.model.format.StructureFormat;

public interface StructureFormatFactory extends IFormatFactory<StructureFormat> {

	
}
