package io.sdmx.core.sdmx.manager.structure;

import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.model.beans.ITransactionalBeansEvent;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.IStructureTransactionWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.IStructureTransactionWriterFactory;
import io.sdmx.core.sdmx.api.manager.structure.IStructureTransactionWriterManager;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class StructureTransactionWriterManager implements IStructureTransactionWriterManager, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(StructureTransactionWriterManager.class);
	private static StructureTransactionWriterManager INSTANCE;

	private Set<IStructureTransactionWriterFactory> factories = null;
	
	public static StructureTransactionWriterManager getInstance() {
		if(INSTANCE == null) {
			INSTANCE = SingletonStore.getSingleton(StructureTransactionWriterManager.class, false);
			if(INSTANCE == null) {
				INSTANCE = new StructureTransactionWriterManager();
				SingletonStore.registerInstance(INSTANCE);
			}
		}
		return INSTANCE;
	}

	private StructureTransactionWriterManager() {}



	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
	
	@Override
	public void writeTransaction(ITransactionalBeansEvent transactionalBeansEvent, InformationFormat format, OutputStream out) {
		if(LOG.isDebugEnabled()) {
			LOG.debug("Write Transaction" +transactionalBeansEvent.getTransactionId());
			LOG.debug("Format" +format.toString());
		}
		getStructureWritingEngine(format).writeTransaction(transactionalBeansEvent, out);
	}

	
	private IStructureTransactionWriterEngine getStructureWritingEngine(InformationFormat outputFormat) {
		for(IStructureTransactionWriterFactory factory : getStructureWriterFactory()) {
			IStructureTransactionWriterEngine engine = factory.getStructureWriterEngine(outputFormat);
			if(engine != null) {
				return engine;
			}
		}
		throw new SdmxNotImplementedException("Could not write structure transaction out in format: " +outputFormat.getFormatDetails().getFormatAsString());
	}

	private Collection<IStructureTransactionWriterFactory> getStructureWriterFactory() throws IllegalArgumentException {
		if(factories != null) {
			return factories;
		}
		synchronized(this) {
			Set<IStructureTransactionWriterFactory> localFactories = new HashSet<>();
			Collection<IStructureTransactionWriterFactory> allBeans = FusionBeanStore.getBeans(IStructureTransactionWriterFactory.class);
			for (IStructureTransactionWriterFactory structureWriterFactory : allBeans) {
				localFactories.add(structureWriterFactory);
			}
			this.factories = localFactories;
		}
		return factories;
	}
		
}
