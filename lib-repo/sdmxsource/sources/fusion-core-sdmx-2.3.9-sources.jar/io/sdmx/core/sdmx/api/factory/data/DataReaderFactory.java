package io.sdmx.core.sdmx.api.factory.data;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.core.sdmx.error.DataReaderErrorTranslator;

/**
 * Creates DataReaderEngine from Source data, DataStructure (or BeanRetrievalManager used to get DataStructure(s)) and optionally some additional information (if not SDMX/EDI)
 */
public interface DataReaderFactory extends IPluggable {

	/**
	 * Converts a DataValidationErrorHandler to something the data reader engine can use
	 * @param exceptionHandler
	 * @return
	 */
	default DataReaderExceptionHandler getDataReaderExceptionHandler(DataValidationErrorHandler exceptionHandler) {
		if(exceptionHandler == null) {
			return null;
		}
 		return new DataReaderErrorTranslator(exceptionHandler, getId());
	}

	/**
	 * Obtains a DataReaderEngine that is capable of reading the data which is exposed via the ReadableDataLocation
	 *
	 * @param sourceData - giving access to an InputStream of the data
	 * @param dsd - describes the data in terms of the dimensionality
	 * @param dataflowBean (optional) provides further information about the data
	 * @param provisionAgreement (optional)  provides further information about who is reporting the data
	 * @return {@link DataReaderEngine} or null if the given sourceData could not be read
	 * @throws IllegalArgumentException if ReadableDataLocation or DataStructureBean is null, also if additioanlInformation is not of the expected type
	 */
	DataReaderEngine getDataReaderEngine(DataFormat format,
										 ReadableDataLocation sourceData,
										 DataStructureBean dsd,
										 DataflowBean dataflowBean,
										 ProvisionAgreementBean provisionAgreement,
										 DataValidationErrorHandler exceptionHandler);

	/**
	 * Obtains a DataReaderEngine that is capable of reading the data which is exposed via the ReadableDataLocation
	 *
	 * @param sourceData - giving access to an InputStream of the data
	 * @param retrievalManager - used to obtain the DataStructure(s) that describe the data
	 * @param exceptionHandler - the DataReaderEngine will use this to report {@link SdmxSemmanticException} in the dataset, which make the dataset
	 * invalid with regards to the specification, but do not prevent the dataset from being read.  If no errorHandler is provided, then the error will simply
	 * be thrown by the DataReaderEngine on data read.
	 * @return {@link DataReaderEngine} or null if the given sourceData could not be read
	 * @throws IllegalArgumentException if ReadableDataLocation or DataStructureBean is null, also if additioanlInformation is not of the expected type
	 */
	DataReaderEngine getDataReaderEngine(DataFormat format,
										 ReadableDataLocation sourceData,
										 SdmxBeanRetrievalManager retrievalManager,
										 DataValidationErrorHandler exceptionHandler);


	/**
	 * @return the class name of any factory that this factory want to be checked before
	 */
	String getOverride();

	/**
	 * Returns a list of the specific errors that can be thrown by a DataReaderFactory. Returns an empty list if there are none.
	 * @return a list
	 */
	List<DataErrorCategory> getThrowableErrors();

	/**
	 * @return a unique ID of this Data Reader Factory
	 */
	String getId();

	/**
     * @return the name of this Data Reader Factory - used in display purposes
     */
    String getName();

    /**
     * DataFormatFactories have a priority which by default is 5 and a lower number is considered a higher priority.
     * When the DataFormatFactories are put into an order, the priorities are taken into account
     * @return the priority value
     */
    public default int getPriority() {
        return 5;
    }
}