package io.sdmx.core.sdmx.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.exception.DataErrorCode;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.exception.ExceptionHandler;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.core.sdmx.error.ErrorTranslatorToExceptionHandler;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.error.FusionErrorImpl;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public class TextFormatValidationUtil {

	private static final Set<String> EDI_LENIENT_EXEMPTION_VALUES = new HashSet<>(Arrays.asList("OBS_CONF", "OBS_PRE_BREAK", "OBS_STATUS", "PRE_BREAK_VALUE", "CONF_STATUS"));
	
	public static void validateTextFormat(TextFormatBean textFormat,  ComponentBean component, String value, ExceptionHandler exHandler) {
		validateTextFormat(textFormat, component, value, new ErrorTranslatorToExceptionHandler(exHandler));
	}


	public static void validateTextFormat(TextFormatBean textFormat, ComponentBean component, String value, DataValidationEngineErrorHandler eh) {
		if(textFormat == null || value == null) {
			return;
		}
		String componentId = component != null ? component.getId() : null;

		// FMR-769: This class should not really have knowledge that the user has specified
		// 'edi leniency' so ThreadLocalUtil is used to disable the validation until this class
		// is refactored to provide better architecture around validation
		if (ThreadLocalUtil.contains(ThreadLocalUtil.APPLY_EDI_LENIENCE) && componentId != null) {
			// If EDI Leniency is enabled, then do not check the Observation Value or the Observation Attributes: OBS_CONF, OBS_PRE_BREAK and OBS_STATUS
			if (component instanceof PrimaryMeasureBean && "OBS_VALUE".equals(componentId)) {
				return;
			}
			if (component instanceof AttributeBean && ((AttributeBean) component).getAttachmentLevel().equals(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION) &&
				EDI_LENIENT_EXEMPTION_VALUES.contains(componentId)) {
				return;
			}
		};

		if(textFormat.getTextType() != null) {
			boolean success = validateTextType(componentId, textFormat.getTextType(), value, eh);
			if (!success) {
				// No point continuing since it will generate "duplicate" errors
				return;
			}
		}
		if(textFormat.getPattern() != null) {
			if(!Pattern.compile(textFormat.getPattern()).matcher(value).matches()) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_NOT_MATCH_PATTERN, value, component.getId(), textFormat.getPattern().toString());
				eh.reportError(fe, getKv(value, component.getId()));
			}
		}
		boolean isValidNumber = true;
		if(textFormat.getDecimals() != null) {
			try {
				Double valAsDouble = Double.parseDouble(value);
				int num = getNumberOfDecimalPlace(valAsDouble);
				if(num > textFormat.getDecimals().intValue()) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_EXCEEDS_MAX_DECIMAL_PLACES, value, component.getId(), textFormat.getDecimals().toString());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			} catch(NumberFormatException e) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_NOT_NUMERICAL, value, component.getId());
				eh.reportError(fe, getKv(value, component.getId()));
				isValidNumber = false;
			}
		}
		if(textFormat.getMinLength() != null) {
			if(value.length() < textFormat.getMinLength().intValue()) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_SHORTER_THAN_MINIMUM_ALLOWED, value, component.getId(), textFormat.getMinLength().toString());
				eh.reportError(fe, getKv(value, component.getId()));
			}
		}
		if(textFormat.getMaxLength() != null) {
			if(value.length() > textFormat.getMaxLength().intValue()) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_GREATER_THAN_MAXIMUM_ALLOWED, value, component.getId(), textFormat.getMaxLength().toString());
				eh.reportError(fe, getKv(value, component.getId()));
			}
		}
		if(textFormat.getStartValue() != null) {
			BigDecimal valueAsDecimal = parseBigDecimal(componentId, value, eh);
			if(valueAsDecimal != null) {
				if(valueAsDecimal.compareTo(textFormat.getStartValue()) < 0) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_LESS_THAN_SPECIFIED_START_VALUE, value, component.getId(), textFormat.getStartValue().toPlainString());
					eh.reportError(fe, getKv(value, component.getId()));
				}
				if(textFormat.getInterval() != null) {
					if(valueAsDecimal.subtract(textFormat.getStartValue()).remainder(textFormat.getInterval()).compareTo(BigDecimal.ZERO) != 0) {
						FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_NOT_FIT_ALLOWED_ITERVALS, value, component.getId(), textFormat.getStartValue().toPlainString(), textFormat.getInterval().toPlainString());
						eh.reportError(fe, getKv(value, component.getId()));
					}
				}
			}
		}
		if (isValidNumber) {
			if(textFormat.getEndValue() != null) {
				BigDecimal valueAsDecimal = parseBigDecimal(componentId, value, eh);
				if(valueAsDecimal != null && valueAsDecimal.compareTo(textFormat.getEndValue()) > 0) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_GREATER_THAN_SPECIFIED_END_VALUE, value, component.getId(), textFormat.getEndValue().toPlainString());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			}
			if(textFormat.getMinValue() != null) {
				BigDecimal valueAsDecimal = parseBigDecimal(componentId, value, eh);
				if(valueAsDecimal != null && valueAsDecimal.compareTo(textFormat.getMinValue()) < 0) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_LESS_THAN_SPECIFIED_MIN_VALUE, value, component.getId(), textFormat.getMinValue().toPlainString());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			}
			if(textFormat.getMaxValue() != null) {
				BigDecimal valueAsDecimal = parseBigDecimal(componentId, value, eh);
				if(valueAsDecimal != null && valueAsDecimal.compareTo(textFormat.getMaxValue()) > 0) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_GREATER_THAN_SPECIFIED_MAX_VALUE, value, component.getId(), textFormat.getMaxValue().toPlainString());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			}
		}
		if(textFormat.getStartTime() != null) {
			try {
				Date dte = DateUtil.formatDate(value, true);
				if(dte.before(textFormat.getStartTime().getDate())) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_BEFORE_ALLOWED_START_TIME, value, component.getId(), textFormat.getStartTime().getDateInSdmxFormat());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			} catch(NumberFormatException e) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_FOR_COMPONENT_NOT_EXPECTED_TYPE, value, component.getId(), "Date");
				eh.reportError(fe, getKv(value, component.getId()));
			}
		}
		if(textFormat.getEndTime() != null) {
			try {
				Date dte = DateUtil.formatDate(value, true);
				if(dte.after(textFormat.getEndTime().getDate())) {
					FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_AFTER_ALLOWED_END_TIME, value, component.getId(), textFormat.getStartTime().getDateInSdmxFormat());
					eh.reportError(fe, getKv(value, component.getId()));
				}
			} catch(NumberFormatException e) {
				FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_FOR_COMPONENT_NOT_EXPECTED_TYPE, value, component.getId(), "Date");
				eh.reportError(fe, getKv(value, component.getId()));
			}
		}
	}

	public static boolean validateTextType(TEXT_TYPE textType, String value, ExceptionHandler exHandler) {
		return validateTextType(null, textType, value, new ErrorTranslatorToExceptionHandler(exHandler));
	}

	private static boolean validateTextType(String componentId, TEXT_TYPE textType, String value, DataValidationEngineErrorHandler eh) {
		switch(textType) {
		case DOUBLE :
			try {
				Double.parseDouble(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Double");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case BIG_INTEGER :
			try {
				new BigInteger(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Big Integer");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case INTEGER :
			try {
				new Integer(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Integer");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case LONG :
			try {
				new Long(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Long");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;

		case SHORT :
			try {
				new Short(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Short");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case DECIMAL :
			try {
				new BigDecimal(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Decimal");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case FLOAT :
			try {
				new Float(value);
			} catch(NumberFormatException e) {
				FusionError fe = generateErrorMessage(value, componentId, "Float");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case BOOLEAN :
			if(!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
				FusionError fe = generateErrorMessage(value, componentId, "Boolean");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case STANDARD_TIME_PERIOD :
			try {
				DateUtil.getTimeFormatOfDate(value);
			} catch(Throwable e) {
				FusionError fe = generateErrorMessage(value, componentId, "Date");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case DATE_TIME :
			try {
				TIME_FORMAT tf = DateUtil.getTimeFormatOfDate(value);
				if(tf != TIME_FORMAT.DATE_TIME) {
					FusionError fe = generateErrorMessage(value, componentId, "Date Time");
					eh.reportError(fe, getKv(value, componentId));
				}
			} catch(Throwable e) {
				FusionError fe = generateErrorMessage(value, componentId, "Date Time");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case GREGORIAN_YEAR :
			try {
				if(value.length() != 4) {
					FusionError fe = generateErrorMessage(value, componentId, "Year", ", expected year length of 4");
					eh.reportError(fe, getKv(value, componentId));
					return false;
				}
				new Integer(value);
			} catch(Throwable e) {
				FusionError fe = generateErrorMessage(value, componentId, "Year");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case TIME :
			//HH:MM:SS
			if (!DateUtil.date_TimePattern.matcher(value).matches()){
				FusionError fe = generateErrorMessage(value, componentId, "Time");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
			//		case IDENTIFIABLE_REFERENCE :
			//			try {
			//				SDMX_STRUCTURE_TYPE targetStructure = UrnUtil.getIdentifiableType(value);
			//				UrnUtil.validateURN(value, targetStructure);
			//			} catch(Throwable e) {
			//				FusionError fe = generateErrorMessage(value, componentId, "Identifiable Reference", " a valid URN is expected");
			//                eh.reportError(fe, getKv(value, componentId));
			//				return false;
			//			}
			//			break;
		case URI :
			try {
				new URI(value);
			} catch(URISyntaxException e) {
				FusionError fe = generateErrorMessage(value, componentId, "URI");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
			//TODO Validate all of these, or document why/if they do not need validation
		case ALPHA:
			break;
		case ALPHA_NUMERIC:
			break;
		case BASIC_TIME_PERIOD:
			break;
		case COUNT:
			break;
		case DAY:
			//YYYY-MM-DD
			try {
				TIME_FORMAT tf = DateUtil.getTimeFormatOfDate(value);
				if(tf != TIME_FORMAT.DATE) {
					FusionError fe = generateErrorMessage(value, componentId, "Date");
					eh.reportError(fe, getKv(value, componentId));
				}
			} catch(Throwable e) {
				FusionError fe = generateErrorMessage(value, componentId, "Date");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case DURATION:
			break;
		case EXCLUSIVE_VALUE_RANGE:
			break;
		case GREGORIAN_DAY:
			break;
		case GREGORIAN_TIME_PERIOD:
			break;
		case INCLUSIVE_VALUE_RANGE:
			break;
		case INCREMENTAL:
			break;
		case MONTH:
			//--MM
			if (!DateUtil.date_MonthPattern.matcher(value).matches()){
				FusionError fe = generateErrorMessage(value, componentId, "Month");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case MONTH_DAY:
			//--MM-DD
			if (!DateUtil.date_MonthDayPattern.matcher(value).matches()){
				FusionError fe = generateErrorMessage(value, componentId, "Month-Day");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case NUMERIC:
			break;
		case OBSERVATIONAL_TIME_PERIOD:
			//ANY SDMX TIME FORMAT
			try {
				DateUtil.getTimeFormatOfDate(value);
			} catch(Throwable e) {
				FusionError fe = generateErrorMessage(value, componentId, "Observational Time Period");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		case REPORTING_DAY:
			break;
		case REPORTING_MONTH:
			break;
		case REPORTING_QUARTER:
			break;
		case REPORTING_SEMESTER:
			break;
		case REPORTING_TIME_PERIOD:
			break;
		case REPORTING_TRIMESTER:
			break;
		case REPORTING_WEEK:
			break;
		case REPORTING_YEAR:
			break;
		case STRING:
			break;
		case XHTML:
			break;
		case GREGORIAN_YEAR_MONTH:
			//YYYY-MM
			if (!DateUtil.date_YearMonthPattern.matcher(value).matches()){
				FusionError fe = generateErrorMessage(value, componentId, "Year-Month");
				eh.reportError(fe, getKv(value, componentId));
				return false;
			}
			break;
		default:
			break;
		}
		return true;
	}
	

    /**
	 * Turn string into BigDecimal, to try and process it against other rules
	 * @param value
	 * @return
	 */
	private static BigDecimal parseBigDecimal(String componentId, String value, DataValidationEngineErrorHandler eh) {
		try {
			return new BigDecimal(value);
		} catch(NumberFormatException e) {
		    FusionError fe = new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_NOT_NUMERICAL, value, componentId);
		    eh.reportError(fe, KeyValueImpl.getInstance(componentId, value));
			return null;
		}
	}

	private static int getNumberOfDecimalPlace(double value) {
		//For whole numbers like 0
		if (Math.round(value) == value) return 0;
		final String s = Double.toString(value);
		String[] split  = s.split("E"); //Split on exponent

		final int index = split[0].indexOf('.');
		if (index < 0) {
			return 0;
		}
		int decimalCount = split[0].length() - 1 - index;
		if(split.length > 1) {
			return decimalCount - Integer.parseInt(split[1]);
		}
		return decimalCount;
	}

	/**
	 * Generates a common error message used in many places in this class
	 * @param value The value being reported
	 * @param componentId The optional componentId - may be null
	 * @param type a String stating what type this is (e.g. Double, Integer)
	 * @return the error string
	 */

	private static FusionError generateErrorMessage(String value, String componentId, String type) {
		return generateErrorMessage(value, componentId, type, null);
	}

	private static FusionError generateErrorMessage(String value, String componentId, String type, String extraOptional) {
		if (extraOptional == null) {
			extraOptional = "";
		}

		if (componentId != null) {
			return new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_FOR_COMPONENT_NOT_EXPECTED_TYPE, value, componentId, type, extraOptional);
		}
		return new FusionErrorImpl(DataErrorCode.REPORTED_VALUE_NOT_EXPECTED_TYPE, value, type, extraOptional);
	}

	
	private static KeyValue getKv(String code, String concept) {
		return KeyValueImpl.getInstance(concept, code);
	}
}
