package io.sdmx.core.sdmx.engine.metadata;

import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.manager.structure.IStructureParsePostValidationEngine;
import io.sdmx.core.sdmx.util.StructureReferenceBeanUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * validates the metadata provision does not restrict the targets in a way which is contradictory with the metadataflow
 */
public class MetadataProvisionValidationEngine implements IStructureParsePostValidationEngine, IFusionSingleton {
    private static MetadataProvisionValidationEngine INSTANCE;

	public static MetadataProvisionValidationEngine registerInstance() {
        if(INSTANCE == null) {
            INSTANCE = new MetadataProvisionValidationEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public SDMX_STRUCTURE_TYPE getStructureType() {
		return SDMX_STRUCTURE_TYPE.METADATA_PROVISION;
	}

	@Override
	public void validateMaintainble(MaintainableBean maint, SdmxBeanRetrievalManager brm) {
		MetadataProvisionAgreementBean mProv = (MetadataProvisionAgreementBean) maint;
		MetadataFlowBean flow = brm.getBean(mProv.getMetadataflowRef().getReference());
		if(flow == null) {
			throw new CrossReferenceException(mProv.getMetadataflowRef());
		}
		List<ICrossReferenceBeanBase> provTargets = mProv.getTargets();
		List<ICrossReferenceBeanBase> flowTargets = flow.getTargets();
		
		for(ICrossReferenceBeanBase provTarget : provTargets) {
			if(!(isValidTarget(provTarget, flowTargets))) {
				throw new SdmxSemmanticException("Target '"+provTarget.getReference().getURN()+"' is not a valid restriction as the Metadataflow disallows this");
			}
 		}
	}
	
	/**
	 * In order to be valid, the provision target must be the same, or more restrictive on the flow targets
	 * @param provTarget
	 * @param flowTargets
	 * @return
	 */
	private boolean isValidTarget(ICrossReferenceBeanBase provTarget, List<ICrossReferenceBeanBase> flowTargets) {
		if(flowTargets.size() == 0) {
			return true;
		}
		for(ICrossReferenceBeanBase flowTarget : flowTargets) {
			if(StructureReferenceBeanUtil.isSubset(flowTarget, provTarget)) {
				return true;
			}
		}
		return false;
	}
}
