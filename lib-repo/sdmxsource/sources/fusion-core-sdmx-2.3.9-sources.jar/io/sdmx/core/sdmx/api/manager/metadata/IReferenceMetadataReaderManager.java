package io.sdmx.core.sdmx.api.manager.metadata;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;

public interface IReferenceMetadataReaderManager {

	/**
	 * reads a stream of data to return a metadata set
	 * @param rdl
	 * @return metadata set
	 * @throws SdmxSemmanticException if the built metadata set has errors
	 * @throws UnrecognisedFormatException if the stream can not be read by any registered readers
	 */
	IReferenceMetadataContainer parse(ReadableDataLocation rdl) throws SdmxSemmanticException, UnrecognisedFormatException;
	
}
