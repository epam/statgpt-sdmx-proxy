
package io.sdmx.core.sdmx.api.factory.data;

import java.io.OutputStream;

import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * A DataWriterFactory operates as a plugin to a manager which can request a DataWriterEngine, to which the implementation will
 * respond with an appropriate DataWriterEngine if it is able, otherwise it will return null
 */
public interface ISeriesDataWriterFactory extends IPluggable {

	/**
	 * Obtains a data writer engine for the given data type
	 * @param dataFormat used to describe the format to write the data in (and potentially contain extra information in the implementation)
	 * @param out the output stream to write to (can be null if this is not required, i.e the DataFormat may contain a writer)
	 * @return null if this factory is not capable of creating a data writer engine in the requested format
	 */
	ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery);
}
