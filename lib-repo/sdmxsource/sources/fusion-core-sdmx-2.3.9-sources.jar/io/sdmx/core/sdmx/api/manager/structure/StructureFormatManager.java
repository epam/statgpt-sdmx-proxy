package io.sdmx.core.sdmx.api.manager.structure;

import io.sdmx.api.sdmx.manager.format.FormatManager;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.format.StructureFormat;

public interface StructureFormatManager extends FormatManager<StructureFormat> {
	
	/**
	 * @param standard
	 * @return default structure format for the standard
	 */
	StructureFormat getDefaultFormat(IMetadataStandard standard);


}
