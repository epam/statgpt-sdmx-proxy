package io.sdmx.core.sdmx.api.model.xs;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;

/**
 * Describes the outcome of resolving references and is broken down into:
 * <ol>
 *  <li>Direct References - those are are CrossReferenceBean of the parent Bean e.g a Dimension references a Concept</li>
 *  <li>Indirect References - those where the CrossReferenceBean is dynamically created and not part of the Bean - e.g a Constraint references a CodeBean but not via a CrossReferenceBean which it owns</li>
 *  <li>Missing References - those references which could not be resolved</li>
 */
public interface IReferenceResolution {
	
	enum RESOLUTION_TYPE {
		DIRECT,
		INDIRECT,
		BOTH
	}

	default public Set<IdentifiableBean> toIdentifiableSet(Set<ICrossReferenceBeanResolved<?>> resolvedXS) {
		return resolvedXS.stream().map(e->e.getResolvedBean()).collect(Collectors.toSet());
	}
	
	/**
	 * @return not null, immutable set of all references in this resolution as a resolved set of ICrossReferenceBeanAbsolute
	 */
	Set<ICrossReferenceBeanResolved<?>> getResolvedReferences();
	
	/**
	 * @param includeIndirect if true contains both direct and indirect references
	 * @return a SdmxBeans container with all the referenced structures included
	 */
	SdmxBeans getAllBeans(RESOLUTION_TYPE refType);

	/**
	 * Returns a set of Identifiables that reference other identifiables
	 * @param isDirect if true returns direct references, otherwise returns indirect references
	 * @return
	 */
	Set<IdentifiableBean> getReferences(RESOLUTION_TYPE refType);
	
	/**
	 * @param identifiable
	 * @param isDirect
	 * @return set of identifiables that are referenced by the identifiable passed in
	 */
	Set<ICrossReferenceBeanResolved<?>> getReferences(IdentifiableBean identifiable, RESOLUTION_TYPE refType);

	/**
	 * @param identifiable
	 * @param refType direct, indirect or both
	 * @return set of identifiables that referenced by one or more structures
	 */
	Set<ICrossReferenceBeanResolved<?>> getAllReferenced(RESOLUTION_TYPE refType);
		
	
	Map<IdentifiableBean, Set<ICrossReferenceBeanResolved<?>>> getIdentifiableReferenceMap(RESOLUTION_TYPE refType);
	
	Map<MaintainableBean, Set<ICrossReferenceBeanResolved<?>>> getMaintainableReferenceMap(boolean includeIndirect);
	
	boolean hasMissingReferences();
	
	/**
	 * @return a set of Identifiables who have one or more references that could not be resolved
	 */
	Set<IdentifiableBean> getMissingReferences();
	
	/**
	 * @param identifiable
	 * @return the Cross references that could not be resolved for the given identifiable
	 */
	Set<ICrossReferenceBean<?>> getMissingReferences(IdentifiableBean identifiable);
	
	/**
	 * @return the map  of Identifiables with missing references to a set of the reference that could not be resolved for the identifiable
	 */
	Map<IdentifiableBean, Set<ICrossReferenceBean<?>>> getMissingReferencesMap();
	
}
