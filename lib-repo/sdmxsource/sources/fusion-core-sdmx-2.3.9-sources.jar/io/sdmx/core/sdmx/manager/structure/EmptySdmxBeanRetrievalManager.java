package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class EmptySdmxBeanRetrievalManager implements SdmxBeanRetrievalManager {
	public static EmptySdmxBeanRetrievalManager INSTANCE = new EmptySdmxBeanRetrievalManager();
	
	
	private EmptySdmxBeanRetrievalManager() {}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		return Collections.emptySet();
	}

}
