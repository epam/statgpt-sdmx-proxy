package io.sdmx.core.sdmx.factory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IFormatFactory;
import io.sdmx.api.format.IGenericInformationFormat;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.format.GenericFormatCSV;
import io.sdmx.utils.core.format.GenericFormatJSON;
import io.sdmx.utils.core.format.GenericFormatXLSX;

public class GenericFormatFactory implements IFormatFactory<IGenericInformationFormat>, IFusionSingleton {
	private static GenericFormatFactory INSTANCE;
	private Map<String, IGenericInformationFormat> vndMap = new HashMap<>();
	private Map<String, IGenericInformationFormat> formatMap = new HashMap<>();
	
	public static GenericFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new GenericFormatFactory();
		}
		return INSTANCE;
	}
	
	public GenericFormatFactory() {
		FusionBeanStore.registerInstance(this);
		addFormat(GenericFormatCSV.getInstance());
		addFormat(GenericFormatJSON.getInstance());
		addFormat(GenericFormatXLSX.getInstance());
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		Map<String, FormatDetails> returnMap = new HashMap<>();
		for(String vnd : vndMap.keySet()) {
			IGenericInformationFormat format = vndMap.get(vnd);
			returnMap.put(vnd, format.getFormatDetails());
		}
		return Collections.unmodifiableMap(returnMap);
	}

	public void addFormat(IGenericInformationFormat format) {
		formatMap.put(format.getFormatDetails().getFileExtension(), format);
		vndMap.put(format.getFormatDetails().getMimeType(), format);
	}

	@Override
	public Class<IGenericInformationFormat> getFormatClass() {
		return IGenericInformationFormat.class;
	}

	@Override
	public IGenericInformationFormat getFormat(String format, Request request) {
		if(format != null) {
			return formatMap.get(format);
		}
		return null;
	}
	
	@Override
	public IGenericInformationFormat getFormat(Request request, IVNDHeader vndHeader) {
		return vndMap.get(vndHeader.getOriginalVND());
	}
}
