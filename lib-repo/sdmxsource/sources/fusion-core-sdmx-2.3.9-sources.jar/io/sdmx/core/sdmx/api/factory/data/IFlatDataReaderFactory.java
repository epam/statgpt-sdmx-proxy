package io.sdmx.core.sdmx.api.factory.data;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.api.engine.data.IFlatDataReaderEngine;
import io.sdmx.core.sdmx.api.manager.structure.IDatasetStructuresRetrievalManager;

/**
 * Can return a data reader if it understands the given data format
 */
public interface IFlatDataReaderFactory {

	/**
	 * @param format - data format being read
	 * @param sourceData - the data to read
	 * @param retrievalManager - used to obtain structures required by the data reader
	 * @return {@link IFlatDataReaderEngine} that can read the data, or null if this factory does not support reading the given data format
	 */
	 IFlatDataReaderEngine getDataReaderEngine(DataFormat format, ReadableDataLocation sourceData, IDatasetStructuresRetrievalManager retrievalManager);
}
