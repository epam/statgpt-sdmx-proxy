package io.sdmx.core.sdmx.model.data;

import java.util.Objects;

public class ObsPos {
  private final Integer keyablePosition;
  private final Integer observationPosition;

  public ObsPos(Integer keyablePosition, Integer observationPosition) {
    this.keyablePosition = keyablePosition;
    this.observationPosition = observationPosition;
  }

  public Integer getKeyablePosition() {
    return keyablePosition;
  }

  public Integer getObservationPosition() {
    return observationPosition;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;

    if ((obj != null) && (getClass() == obj.getClass())) {
      ObsPos other = (ObsPos)obj;

      if (Objects.equals(getKeyablePosition(),
                         other.getKeyablePosition()) &&
          Objects.equals(getObservationPosition(),
                         other.getObservationPosition()))
        return true;
    }

    return false;
  }

  @Override
  public int hashCode() {
    return Objects.hash(getKeyablePosition(),
                        getObservationPosition());
  }

  @Override
  public String toString() {
    return "(" + keyablePosition +  ", " + observationPosition + ")";
  }
}
