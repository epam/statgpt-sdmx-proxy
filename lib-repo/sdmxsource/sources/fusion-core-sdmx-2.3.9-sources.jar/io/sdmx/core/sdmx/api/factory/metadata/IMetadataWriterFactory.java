package io.sdmx.core.sdmx.api.factory.metadata;

import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.factory.PriorityFactory;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;

/**
 * A IMetadataWriterFactory operates as a plugin to a Manager which can request a IReferenceMetadataWriterEngine, to which the implementation will
 * respond with an appropriate IReferenceMetadataWriterEngine if it is able, otherwise it will return null
 */
public interface IMetadataWriterFactory extends PriorityFactory, IPluggable {

	/**
	 * Obtains an IReferenceMetadataWriterEngine engine for the given output format
	 * @param outputFormat an implementation of the IMetadataFormat to describe the output format for the structures (required)
	 * @return null if this factory is not capable of creating a metadata writer engine in the requested format
	 * @throws IllegalArgumentException if the outputFormat is null
	 */
	IMetadataWriterEngine getMetadataWriterEngine(IMetadataFormat outputFormat);
	
}
