package io.sdmx.core.sdmx.manager.metadata;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.serialiser.IBeanSerialiser;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.utils.core.io.InMemoryReadableDataLocation;

/**
 * Writes and reads reference metadata from a specific format for object serialisation
 */
public class StructuralMetadataSerialiserManager implements IBeanSerialiser {
	private StructureWriterEngine structureWriterEngine;
	private StructureReaderManager structureReaderManager;
	private String id;

	public StructuralMetadataSerialiserManager(String id, StructureWriterEngine structureWriterEngine,
											   StructureReaderManager structureReaderManager) {
		this.id = id;
		this.structureWriterEngine = structureWriterEngine;
		this.structureReaderManager = structureReaderManager;
	}
	
	@Override
	public String getId() {
		return id;
	}

	@Override
	public void write(MaintainableBean object, OutputStream out) {
		structureWriterEngine.writeStructure(object, null, out);
		try {
			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public MaintainableBean read(InputStream stream) {
		SdmxBeans container = structureReaderManager.parseStructures(new InMemoryReadableDataLocation(stream));
		if(container == null) {
			return null;
		}
		for(MaintainableBean maint : container.getAllMaintainables()) {
			return maint;
		}
		return null;
	}
}
