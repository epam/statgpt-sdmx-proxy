package io.sdmx.core.sdmx.model.data;

import java.util.Collections;
import java.util.List;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.sdmx.model.data.ICsvFilePosition;

public class CsvFilePosition extends FilePosition implements ICsvFilePosition {
	private final List<Integer> columns;
	private DELIMITER delimiter;

	public CsvFilePosition(long offset, long bytes, DELIMITER delimiter, List<Integer> columns) {
		super(offset, bytes);
		this.columns = columns == null ? Collections.emptyList() : Collections.unmodifiableList(columns);
		this.delimiter = delimiter;
	}

	@Override
	public POSITION_TYPE getPositionType() {
		return POSITION_TYPE.CSV;
	}

	@Override
	public DELIMITER getDelimiter() {
		return delimiter;
	}

	@Override
	protected void buildPositionalString(StringBuilder sb) {
		sb.append(getOffset()+":"+getBytes()+":"+delimiter.getDelimiter());
		for(Integer colPos : columns) {
			sb.append(":"+colPos);
		}
	}

	@Override
	public List<Integer> getColumns() {
		return columns;
	}
}
