package io.sdmx.core.sdmx.api.error;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

/**
 * Used to report errors to an upstream process
 */
public interface DataValidationErrorReporter  {

	/**
	 * Reports an error against the observation
	 * @param fe
     * @param component
     * @param obs
     */
	void reportError(FusionError fe, KeyValue component, Observation obs);

	/**
	 * Reports an error against one or more observations using the short code
	 * @param fe the error message and code, for example 'reported value Total does not match expression TOTAL=UK+FR+DE'
	 * @param component
	 * @param obsShortCode example A:UK:M:2008  this can be an array, for example if this is a calculation expression then there will be many input observations to the error
	 * @see Observation.getShortCode()
	 */
	void reportObsError(FusionError fe, KeyValue component, String... obsShortCode);

	/**
	 * Reports an error against the series or group key
	 * @param message
	 * @param component
	 * @param key
	 */
    void reportError(FusionError fe, KeyValue component, Keyable key);
	void reportError(FusionError fe, IMultilingualKeyValue component, Keyable key);

	/**
	 * Report an error against the dataset attribute
	 * @param message
	 * @param attribute
	 */
	void reportDatasetAttributeError(FusionError fe, KeyValue attribute);

}

