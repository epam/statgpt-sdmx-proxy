package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.error.IStructureValidationError;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorLimitException;

public class StructureValidationErrorHandler implements IStructureValidationErrorHandler {

	private List<IStructureValidationError> errors = new ArrayList<>();
	
	@Override
	public void handleError(IStructureValidationError err) throws ErrorLimitException {
		errors.add(err);
	}

	@Override
	public List<IStructureValidationError> getErrors() {
		return errors;
	}

}
