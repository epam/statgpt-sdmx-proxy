package io.sdmx.core.sdmx.api.manager.metadata;

import io.sdmx.api.sdmx.manager.format.FormatManager;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;

public interface IMetadataFormatManager extends FormatManager<IMetadataFormat> {

}
