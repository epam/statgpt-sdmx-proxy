package io.sdmx.core.sdmx.error;

import io.sdmx.api.error.FusionError;
import io.sdmx.core.sdmx.api.error.DataFormatError;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.utils.core.error.FusionErrorImpl;

public class DataFormatErrorImpl implements DataFormatError {
	private FusionError fe;
	private Enum errorType;
    private ERROR_POSITION errorPosition;

	public DataFormatErrorImpl(String message, Enum errorType) {
		this(message, errorType, ERROR_POSITION.DATASET);
	}

	public DataFormatErrorImpl(String message, Enum errorType, ERROR_POSITION errorPosition) {
	    this(new FusionErrorImpl(message), errorType, errorPosition);
    }

	public DataFormatErrorImpl(FusionError fe, Enum errorType) {
	    this(fe, errorType, ERROR_POSITION.DATASET);
    }

	public DataFormatErrorImpl(FusionError fe, Enum errorType, ERROR_POSITION errorPosition) {
        this.fe = fe;
        this.errorType = errorType;
        this.errorPosition = errorPosition;
    }

	@Override
	public FusionError getFusionError() {
	    return fe;
	}

	@Override
	public String getMessage() {
		return fe.getErrorMessage();
	}

	@Override
	public Enum getErrorType() {
		return errorType;
	}

    @Override
    public ERROR_POSITION getErrorPosition() {
        return this.errorPosition;
    }
}
