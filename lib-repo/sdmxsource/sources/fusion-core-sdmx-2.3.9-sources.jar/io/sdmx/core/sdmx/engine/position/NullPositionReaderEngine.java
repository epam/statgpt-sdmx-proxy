package io.sdmx.core.sdmx.engine.position;

import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;

/**
 * returns a null position from any string
 */
public class NullPositionReaderEngine implements IPositionReaderEngine {
	public static final IPositionReaderEngine INSTANCE = new NullPositionReaderEngine();
	
	private NullPositionReaderEngine() {}
			
	@Override
	public IDataPosition string2Position(String asString) {
		return null;
	}

	@Override
	public String getPositionPrefix() {
		return null;
	}


}
