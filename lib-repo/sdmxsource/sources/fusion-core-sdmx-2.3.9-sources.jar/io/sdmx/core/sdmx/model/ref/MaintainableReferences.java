package io.sdmx.core.sdmx.model.ref;

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * This represents all the cross referenced Identifiable structures from a single Maintainable structure
 */
public class MaintainableReferences implements Serializable, IMaintainableReferences {
	private static final long serialVersionUID = 1L;
	private IURNMaintainable<?> maintURN;
	private Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> references;
	
	/**
	 * @param maintURN the Maintainable structure who has the references 
	 * @param references a map of URN from within the Maintainable structure to a Set of Identifiable URNs which it refers to e.g. if the maintainable is a 
	 * DSD references may include a Dimension URN to a Concept URN and a Codelist URN
	 */
	public MaintainableReferences(IURNMaintainable<?> maintURN, Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> references) {
		this.maintURN = maintURN;
		this.references = Collections.unmodifiableMap(CollectionUtil.copyMap(references));
	}

	@Override
	public IURNMaintainable<?> getMaintURN() {
		return maintURN;
	}


	@Override
	public Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> getReferences() {
		return references;
	}

	@Override
	public String toString() {
		return maintURN.toString();
	}
}
