package io.sdmx.core.sdmx.api.engine.data;

import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;

/**
 * A data writer which is used to store data in a temporary location before it is read back in again
 */
public interface ITemporaryDataWriterEngine extends ISeriesObsDataWriterEngine {

	/**
	 * @return a container for all the structures that were used to write the data
	 */
	SdmxBeans getWrittenStructures();
	
	/**
	 * @return the header to apply to the writer 
	 */
	HeaderBean getHeader();
	
	/**
	 * @return dataset headers written to the writer
	 */
	List<DatasetHeaderBean> getDatasetHeaders();
	
	/**
	 * @return structures per dataset
	 */
	List<IDatasetStructures> getStructures();
	
	/**
	 * @return access to the stream of data that was written
	 */
	ReadableDataLocation getReadableDataLocation();

	/**
	 * @return true if there were any dataset attributes, series, or observation written
	 */
	boolean dataWritten();
	
	/**
	 * @return number of keys written to tmp location
	 */
	int getKeyWritten();

	/**
	 * @return number of observation written to tmp location
	 */
	int getObsWritten();
	
}
