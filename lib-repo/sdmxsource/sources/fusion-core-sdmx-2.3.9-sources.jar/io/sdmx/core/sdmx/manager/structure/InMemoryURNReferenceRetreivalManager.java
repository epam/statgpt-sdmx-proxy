package io.sdmx.core.sdmx.manager.structure;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerator;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.output.IStructureReferenceWriterManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.json.JSON_COMPATIBLE_FORMAT;
import io.sdmx.utils.json.JsonWriterUtil;
import io.sdmx.utils.sdmx.comparator.URNComparator;

public class InMemoryURNReferenceRetreivalManager implements IURNReferenceRetreivalManager, IStructureReferenceWriterManager {

	private Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> references;  			    //Identifiable URN to Maintainable URN
	private Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>> referencing;  			    //Identifiable URN to Maintainable URN
	
	public InMemoryURNReferenceRetreivalManager(ICrossReferenceLookupTable lookupTable) {
		int referencesCount = lookupTable.getMaintDirectReferences().size() + lookupTable.getMaintIndirectReferences().size();
		this.references = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();
		this.referencing = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();
		
		populateReferencesMaps(lookupTable.getMaintDirectReferences());
		populateReferencesMaps(lookupTable.getMaintIndirectReferences());
		
		//make immutable
		references = CollectionUtil.getImmutableMapOfSets(references);
		referencing = CollectionUtil.getImmutableMapOfSets(referencing);
	}
	
	@Override
	/**
	 * This is a hack for now, it should be in its own manager
	 */
	public void writeReferences(IURNAbsolute<?> target,
			STRUCTURE_REFERENCE_DETAIL detail,
			OutputStream out,
			InformationFormat format) {
		Set<ICrossReferenceBeanResolved<?>> resolved = new TreeSet<>((a, b)-> {
			int r = URNComparator.INSTANCE.compare(a.getReferencedFromURN(), b.getReferencedFromURN());
			if(r == 0) r = URNComparator.INSTANCE.compare(a.getReference(), b.getReference());
			if(r == 0) r = a.isIndirectReference() ?  b.isIndirectReference() ? 0 : -1 : 1;
			if(r == 0) r = a.isWeakReference() ?  b.isWeakReference() ? 0 : -1 : 1;
			return r;
		});
		switch(detail) {
		case ALL:
			resolved.addAll(references.get(target));
			resolved.addAll(referencing.get(target));
			break;
		case ANCESTORS:
			break;
		case CHILDREN:
			if(references.containsKey(target)) {
				resolved.addAll(references.get(target));
			}
			break;
		case DESCENDANTS:
			break;
		case NONE:
			break;
		case PARENTS:
			if(referencing.containsKey(target)) {
				resolved.addAll(referencing.get(target));
			}
			break;
		case PARENTS_SIBLINGS:
			break;
		case SPECIFIC:
			break;
		default:
			break;
		}
		
		try {
			try(JsonGenerator jsonGenerator = JsonWriterUtil.createJsonWriter(out, JSON_COMPATIBLE_FORMAT.JSON)) {
				jsonGenerator.writeStartArray();
				resolved.forEach(e-> {
					try {
						jsonGenerator.writeStartObject();
						jsonGenerator.writeStringField("source", e.getReferencedFromURN().toString());
						jsonGenerator.writeStringField("target", e.getBaseReference().getTargetUrn());
						if(!e.getBaseReference().getTargetUrn().equals(e.getReference().getURN())) {
							jsonGenerator.writeStringField("resolved", e.getReferencedFromURN().toString());
						}
						if(e.isWeakReference()) jsonGenerator.writeBooleanField("weak", e.isWeakReference());
						if(e.isIndirectReference()) jsonGenerator.writeBooleanField("indirect", e.isIndirectReference());
						jsonGenerator.writeEndObject();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				});
				jsonGenerator.writeEndArray();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void populateReferencesMaps(Set<IMaintainableReferences> mReferences) {
		for(IMaintainableReferences<?> mRef : mReferences) {
			Map<IURNAbsolute<?>, Set<ICrossReferenceBeanResolved<?>>>  references = mRef.getReferences();

			for(IURNAbsolute<?> identURNFrom : references.keySet()) {
				IURNMaintainable<?> maintURNFrom = identURNFrom.getMaintainableURN();
				
				for(ICrossReferenceBeanResolved<?> refTo : references.get(identURNFrom)) {
					CollectionUtil.addToMappedSet(this.references, maintURNFrom, refTo);
					CollectionUtil.addToMappedSet(this.references, identURNFrom, refTo);
					
					
					if(!refTo.getReference().isMaintainableReference()) {
						CollectionUtil.addToMappedSet(this.referencing, refTo.getReference().getMaintainableURN(), refTo);
					}
					CollectionUtil.addToMappedSet(this.referencing, refTo.getReference(), refTo);
				}
			}
		}
	}
	
	@Override
	public Set<IURNMaintainable<?>> whoReferencesMe(IURNAbsolute<?> target, boolean includeIndirect, boolean includeWeak) {
		Collection<ICrossReferenceBeanResolved<?>> returnReferences = referencing.get(target);
		if(returnReferences == null) {
			return Collections.emptySet();
		}
		if(!includeWeak) {
			returnReferences = returnReferences.stream().filter(e->e.isWeakReference()==false).collect(Collectors.toList());
		}
		if(!includeIndirect) {
			returnReferences = returnReferences.stream().filter(e->e.isIndirectReference()==false).collect(Collectors.toList());
		}
		return returnReferences.stream().map(e->e.getReferencedFromURN().getMaintainableURN()).collect(Collectors.toSet());
	}
	
	@Override
	public Set<IURNMaintainable<?>> whoDoIReference(IURNAbsolute<?> source, boolean includeIndirect, boolean includeWeak) {
		Collection<ICrossReferenceBeanResolved<?>> returnReferences = references.get(source);
		if(returnReferences == null) {
			return Collections.emptySet();
		}
		if(!includeWeak) {
			returnReferences = returnReferences.stream().filter(e->e.isWeakReference()==false).collect(Collectors.toList());
		}
		if(!includeIndirect) {
			returnReferences = returnReferences.stream().filter(e->e.isIndirectReference()==false).collect(Collectors.toList());
		}
		return returnReferences.stream().map(e->e.getResolvedBean().getMaintainableParent().getURN()).collect(Collectors.toSet());
	}



}
