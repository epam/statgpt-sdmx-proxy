package io.sdmx.core.sdmx.model.structure;

import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.core.sdmx.manager.structure.ConstraintRetrievalManagerImpl;
import io.sdmx.core.sdmx.manager.structure.SdmxBeanRestRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.SdmxSuperBeanRetrievalManagerImpl;
import io.sdmx.im.beans.container.URNStoreFromBRM;

public class StructureEnvironment implements IStructureEnvironment {
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private CrossReferencingRetrievalManager crossReferenceManager;
	private CrossReferencedRetrievalManager crossReferencedManager;
	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private ISdmxBeanRestRetrievalManager restBeanRetrievalManager;
	private ConstraintRetrievalManager constraintRetrievalManager;
	private IURNRetrievalManager urnRetrievalManager;
	private IURNReferenceRetreivalManager urnReferenceRetrievalManager;
	
	public StructureEnvironment(
			SdmxBeanRetrievalManager beanRetrievalManager,
			CrossReferencingRetrievalManager crossReferenceManager,
			CrossReferencedRetrievalManager crossReferencedManager) {
		this(beanRetrievalManager, crossReferenceManager, crossReferencedManager, null, null, null, null);
	}
	
	public StructureEnvironment(
			SdmxBeanRetrievalManager beanRetrievalManager,
			CrossReferencingRetrievalManager crossReferenceManager,
			CrossReferencedRetrievalManager crossReferencedManager,
			SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			IURNRetrievalManager urnRetrievalManager,
			IURNReferenceRetreivalManager urnReferenceRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.crossReferenceManager = crossReferenceManager;
		this.crossReferencedManager = crossReferencedManager;
		this.urnRetrievalManager = urnRetrievalManager;
		this.urnReferenceRetrievalManager = urnReferenceRetrievalManager;
		this.restBeanRetrievalManager = new SdmxBeanRestRetrievalManager(this);

		if(urnRetrievalManager == null) {
			this.urnRetrievalManager = new URNStoreFromBRM(beanRetrievalManager);
		}
		if(urnReferenceRetrievalManager == null) {
		   this.urnReferenceRetrievalManager = new IURNReferenceRetreivalManager() {
            
            @Override
            public Set<IURNMaintainable<?>> whoReferencesMe(IURNAbsolute<?> target, boolean includeIndirect, boolean includeWeak) {
                return crossReferenceManager.getCrossReferencingStructures(target, includeIndirect).stream().map(e->e.getURN()).collect(Collectors.toSet());
            }
            
            @Override
            public Set<IURNMaintainable<?>> whoDoIReference(IURNAbsolute<?> source, boolean includeIndirect,
                    boolean includeWeak) {
                return crossReferencedManager.getCrossReferencedStructures(source, includeIndirect).stream().map(e->e.getURN()).collect(Collectors.toSet());
            }
        };
		}
		
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		if(superBeanRetrievalManager == null) {
			this.superBeanRetrievalManager = new SdmxSuperBeanRetrievalManagerImpl(beanRetrievalManager);
		}
		
		this.constraintRetrievalManager = constraintRetrievalManager;
		if(constraintRetrievalManager == null) {
			this.constraintRetrievalManager = ConstraintRetrievalManagerImpl.getInstance(restBeanRetrievalManager);
		}
	}
	
	@Override
	public SdmxBeanRetrievalManager getBeanRetrievalManager() {
		return beanRetrievalManager;
	}

	@Override
	public SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager() {
		return superBeanRetrievalManager;
	}
	

	@Override
	public IURNRetrievalManager getURNRetrievalManager() {
		return urnRetrievalManager;
	}
	
	@Override
	public IURNReferenceRetreivalManager getURNReferenceRetreivalManager() {
		return urnReferenceRetrievalManager;
	}

	@Override
	public CrossReferencingRetrievalManager getAncestorRetrievalManager() {
		return crossReferenceManager;
	}

	@Override
	public CrossReferencedRetrievalManager getDescendantRetrievalManager() {
		return crossReferencedManager;
	}

	@Override
	public ISdmxBeanRestRetrievalManager getRestBeanRetrievalManager() {
		return restBeanRetrievalManager;
	}

	@Override
	public ConstraintRetrievalManager getConstraintRetrievalManager() {
		return constraintRetrievalManager;
	}
}
