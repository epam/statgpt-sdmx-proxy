package io.sdmx.core.sdmx.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.api.sdmx.manager.schema.ISchemaFormatManager;
import io.sdmx.core.sdmx.engine.metadata.MetadataProvisionValidationEngine;
import io.sdmx.core.sdmx.engine.position.PositionReaderEngineCSV;
import io.sdmx.core.sdmx.engine.position.PositionReaderEngineFile;
import io.sdmx.core.sdmx.engine.position.PositionReaderEngineUnavailable;
import io.sdmx.core.sdmx.factory.GenericFormatFactory;
import io.sdmx.core.sdmx.factory.SdmxStructureSchemaFormatFactory;
import io.sdmx.core.sdmx.factory.ref.CategorySchemeMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.ConceptSchemeMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.ContentConstraintCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.OrganisationSchemeMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.ReferenceMetadataCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.ReportingTaxonomyMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.RepresentationMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.StructureMapCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.ValidationSchemeCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.VtlRulesetSchemeCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.factory.ref.VtlTransformationSchemeCrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.manager.format.InformationFormatManager;
import io.sdmx.core.sdmx.manager.metadata.ReferenceMetadataReaderManager;
import io.sdmx.core.sdmx.manager.metadata.ReferenceMetadataWriterManager;
import io.sdmx.core.sdmx.manager.schema.SchemaFormatManager;
import io.sdmx.core.sdmx.manager.structure.StructureTransactionWriterManager;
import io.sdmx.utils.core.application.SingletonStore;

public class CoreSDMXModule implements IFusionModule {

	public static void register() {
		if (SingletonStore.getSingleton(ISchemaFormatManager.class) == null) {
			SingletonStore.registerInstance(new SchemaFormatManager(InformationFormatManager.getInstance()));
		}
		SdmxStructureSchemaFormatFactory.registerInstance();
		GenericFormatFactory.getInstance();  // Registers the instance

		// Indirect References
		CategorySchemeMapCrossReferenceRetrievalFactory.registerInstance();
		ConceptSchemeMapCrossReferenceRetrievalFactory.registerInstance();
		ContentConstraintCrossReferenceRetrievalFactory.registerInstance();
		OrganisationSchemeMapCrossReferenceRetrievalFactory.registerInstance();
		ReportingTaxonomyMapCrossReferenceRetrievalFactory.registerInstance();
		RepresentationMapCrossReferenceRetrievalFactory.registerInstance();
		StructureMapCrossReferenceRetrievalFactory.registerInstance();
		ValidationSchemeCrossReferenceRetrievalFactory.registerInstance();
		ReferenceMetadataCrossReferenceRetrievalFactory.registerInstance();
		VtlTransformationSchemeCrossReferenceRetrievalFactory.registerInstance();
		VtlRulesetSchemeCrossReferenceRetrievalFactory.registerInstance();

		MetadataProvisionValidationEngine.registerInstance();

		// Reference Metadata
		ReferenceMetadataReaderManager.getInstance();
		ReferenceMetadataWriterManager.getInstance();
		
		StructureTransactionWriterManager.getInstance();
		
		//Positional Data
		PositionReaderEngineFile.registerInstance();
		PositionReaderEngineCSV.registerInstance();
		PositionReaderEngineUnavailable.registerInstance();
		
		DeferredModule.register();
		SemverModule.register();
	}

}
