package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataFormatError;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorLimitException;

/*
 * Translates an error from reading a specific dataset format to a more abstract DataError which can come as a result of reading any data
 */
public class DataReaderErrorTranslator implements DataReaderExceptionHandler {
	private DataValidationErrorHandler handler;
	private String errorCategory;
	private int dsIndex = 0;

	public DataReaderErrorTranslator(DataValidationErrorHandler handler, String errorCategory) {
		this.handler = handler;
		this.errorCategory = errorCategory;
	}

	@Override
	public void handleException(DataFormatError ex) throws ErrorLimitException {
		handler.handleError(new DataError() {

			@Override
			public List<String> getShortCode() {
				return new ArrayList<>();
			}

			@Override
			public KeyValue getComponent() {
				return null;
			}

			@Override
			public String getMessage() {
				return ex.getMessage();
			}

			public String getErrorCode() {
				if (ex.getFusionError() == null) {
					return null;
				}
				return ex.getFusionError().getErrorCode();
			}

			@Override
			public ERROR_POSITION getErrorPosition() {
				if (ex.getErrorPosition() == null) {
					return ERROR_POSITION.DATASET;
				}
				return ex.getErrorPosition();
			}

			@Override
			public String getErrorCategory() {
				return errorCategory+"."+ex.getErrorType().toString();
			}

			@Override
			public int getDataset() {
				return dsIndex;
			}

			@Override
			public int hashCode() {
				return toString().hashCode();
			}

			@Override
			public boolean equals(Object obj) {
				if(obj instanceof DataError) {
					DataError that = (DataError) obj;
					return that.toString().equals(this.toString());
				}
				return false;
			}

			@Override
			public String toString() {
				StringBuilder sb = new StringBuilder();
				sb.append("C="+errorCategory+",P="+getErrorPosition()+",DS="+getDataset()+",M="+getMessage());
				return sb.toString();
			}
		});
	}

	@Override
	public void setDataset(int dsIndex) {
		this.dsIndex = dsIndex;
	}
}
