package io.sdmx.core.sdmx.manager.structure;

import java.util.Set;

import io.sdmx.api.sdmx.builder.SuperBeansBuilder;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.builder.superbeans.SuperBeansBuilderImpl;
import io.sdmx.core.sdmx.engine.structure.CrossReferenceResolverEngineImpl;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.SuperBeanRefUtil;

/**
 * This implementation of the SdmxSuperBeanRetrievalManager wraps a SdmxBeanRetrievalManager to gather the information required to build SuperBeans.
 */
public class SdmxSuperBeanRetrievalManagerImpl implements SdmxSuperBeanRetrievalManager {
	
	private SuperBeansBuilder superBeanBuilder = SuperBeansBuilderImpl.getInstance();
	
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private CrossReferenceResolverEngine xsRetreival = new CrossReferenceResolverEngineImpl();
	
	public SdmxSuperBeanRetrievalManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	/**
	 * Returns a set of super beans that match the structure reference.
	 * @param sRef
	 * @param resolveCrossReferences
	 * @return
	 */
	private SuperBeans getSuperBeans(IURN<? extends MaintainableBean> sRef) {
		SdmxBeans sdmxBeans = new SdmxBeansImpl(beanRetrievalManager.getMaintainableBeans(sRef));
		sdmxBeans.merge(xsRetreival.resolveReferences(sdmxBeans, true, false,  -1, beanRetrievalManager).getAllBeans(RESOLUTION_TYPE.BOTH));
		return superBeanBuilder.build(sdmxBeans);
	}
	
	@Override
	public ConceptSchemeSuperBean getConceptSchemeSuperBean(IURNSingle<ConceptSchemeBean> ref) {
		Set<ConceptSchemeSuperBean> beans = getConceptSchemeSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (ConceptSchemeSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemeSuperBeans(IURN<ConceptSchemeBean> ref) {
		return getSuperBeans(ref).getConceptSchemes();
	}

	@Override
	public DataflowSuperBean getDataflowSuperBean(IURNSingle<DataflowBean> ref) {
		Set<DataflowSuperBean> beans = getDataflowSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (DataflowSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	private Set<DataflowSuperBean> getDataflowSuperBeans(IURN<DataflowBean> ref) {
		return getSuperBeans(ref).getDataflows();
	}

	@Override
	public HierarchySuperBean getHierarchicCodeListSuperBean(IURNSingle<HierarchyBean> ref) {
		Set<HierarchySuperBean> beans = getHierarchicCodeListSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (HierarchySuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	private Set<HierarchySuperBean> getHierarchicCodeListSuperBeans(IURN<HierarchyBean> ref) {
		return getSuperBeans(ref).getHierarchies();
	}

	@Override
	public DataStructureSuperBean getDataStructureSuperBean(IURNSingle<DataStructureBean> ref) {
		Set<DataStructureSuperBean> beans = getDataStructureSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (DataStructureSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructureSuperBeans(IURN<DataStructureBean> ref) {
		return getSuperBeans(ref).getDataStructures();
	}
	
	@Override
	public MetadataStructureSuperBean getMetadataStructureSuperBean(IURNSingle<MetadataStructureDefinitionBean> ref) {
		Set<MetadataStructureSuperBean> beans = getMetadataStructureSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (MetadataStructureSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	private Set<MetadataStructureSuperBean> getMetadataStructureSuperBeans(IURN<MetadataStructureDefinitionBean> ref) {
		return getSuperBeans(ref).getMetadataStructures();
	}

	@Override
	public ProvisionAgreementSuperBean getProvisionAgreementSuperBean(IURNSingle<ProvisionAgreementBean> ref) {
		Set<ProvisionAgreementSuperBean> beans = getProvisionAgreementSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (ProvisionAgreementSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	private Set<ProvisionAgreementSuperBean> getProvisionAgreementSuperBeans(IURN<ProvisionAgreementBean> ref) {
		return getSuperBeans(ref).getProvisions();
	}
	
	@Override
	public RegistrationSuperBean getRegistrationSuperBean(IURNSingle<RegistrationBean> ref) {
		Set<RegistrationSuperBean> beans = getRegistrationSuperBeans(ref);
		if(!ObjectUtil.validCollection(beans)) {
			return null;
		}
		return (RegistrationSuperBean)SuperBeanRefUtil.resolveReference(beans, ref);
	}

	private Set<RegistrationSuperBean> getRegistrationSuperBeans(IURN<RegistrationBean> ref) {
		return getSuperBeans(ref).getRegistrations();
	}
	
	
}