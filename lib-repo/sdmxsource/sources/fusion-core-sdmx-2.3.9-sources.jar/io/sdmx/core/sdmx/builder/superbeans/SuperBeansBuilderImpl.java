package io.sdmx.core.sdmx.builder.superbeans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.builder.SuperBeansBuilder;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.MultipleBeanRetrievalManager;
import io.sdmx.im.beans.container.SuperBeansImpl;
import io.sdmx.im.superbeans.builder.ConceptSchemeSuperBeanBuilder;
import io.sdmx.im.superbeans.builder.DataStructureSuperBeanBuilder;
import io.sdmx.im.superbeans.builder.DataflowSuperBeanBuilder;
import io.sdmx.im.superbeans.builder.HierarchicalCodelistSuperBeanBuilder;
import io.sdmx.im.superbeans.builder.ProvisionSuperBeanBuilder;
import io.sdmx.im.superbeans.builder.RegistrationSuperBeanBuilder;
import io.sdmx.im.superbeans.metadata.MetadataStructureSuperBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SuperBeansBuilderImpl implements SuperBeansBuilder, IFusionSingleton {
	private static final  Logger LOG = LoggerFactory.getLogger(SuperBeansBuilderImpl.class);

	private static SuperBeansBuilderImpl INSTANCE;

	public static SuperBeansBuilderImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SuperBeansBuilderImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private SuperBeansBuilderImpl() {}

	@Override
	public SuperBeans build(SdmxBeans buildFrom) throws SdmxException {
		return this.build(buildFrom, null, new InMemoryRetrievalManager(buildFrom));
	}

	public SuperBeans build(SdmxBeans buildFrom, CrossReferenceExceptionHandler xsExHandler) throws SdmxException {
		return this.build(buildFrom, null, new InMemoryRetrievalManager(buildFrom), null, xsExHandler);
	}
	
	@Override
	public SuperBeans build(SdmxBeans buildFrom, SuperBeans existingBeans, 
			SdmxBeanRetrievalManager retrievalManager, 
			SuperBeansBuildErrorHander errorHandler,
			CrossReferenceExceptionHandler xsExHandler) {
		if(xsExHandler == null) {
			xsExHandler = new CrossReferenceExceptionHandler() {
				
				@Override
				public void handleError(CrossReferenceException ex) {
					throw ex;
				}
			};
		}
		LOG.debug("Build Superbeans: Create LocalRetrievalManager");

		retrievalManager = new MultipleBeanRetrievalManager(new InMemoryRetrievalManager(buildFrom), retrievalManager);
		if(existingBeans == null) {
			existingBeans = new SuperBeansImpl();
		}
		//Note: Order IS Important, as lower level structures must be built before higher level structrues
		for(ConceptSchemeBean currentBean : buildFrom.getConceptSchemes()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addConceptScheme(ConceptSchemeSuperBeanBuilder.getInstance().build(currentBean, retrievalManager, existingBeans, xsExHandler));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}

		for(DataStructureBean currentBean : buildFrom.getDataStructures()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addDataStructure(DataStructureSuperBeanBuilder.getInstance().build(currentBean, retrievalManager, existingBeans, xsExHandler));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		for(DataflowBean currentBean : buildFrom.getDataflows()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addDataflow(DataflowSuperBeanBuilder.getInstance().build(currentBean, retrievalManager, existingBeans, xsExHandler));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		for(HierarchyBean currentBean : buildFrom.getHierarchies()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addHierarchy(HierarchicalCodelistSuperBeanBuilder.getInstance().build(currentBean, retrievalManager));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		for(MetadataStructureDefinitionBean currentBean : buildFrom.getMetadataStructures()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addMetadataStructure(new MetadataStructureSuperBeanImpl(retrievalManager, existingBeans, currentBean));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		for(ProvisionAgreementBean currentBean : buildFrom.getProvisionAgreements()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addProvision(ProvisionSuperBeanBuilder.getInstance().build(currentBean, retrievalManager, existingBeans, xsExHandler));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		for(RegistrationBean currentBean : buildFrom.getRegistrations()) {
			LOG.debug("Build SuperBean: " + currentBean.getUrn());
			try {
				existingBeans.addRegistration(RegistrationSuperBeanBuilder.getInstance().build(currentBean, retrievalManager, existingBeans, xsExHandler));
			} catch(Throwable th) {
				if(errorHandler != null) {
					errorHandler.handleError(currentBean, th);
				} else {
					throw th;
				}
			}
		}
		return existingBeans;
	}
}
