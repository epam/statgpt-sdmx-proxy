package io.sdmx.core.sdmx.api.error;

import java.util.List;
import java.util.Map;

public interface IDataErrorContainer {


	/**
	 * Returns all the data errors as an immutable map or error type to Errors
	 * @return
	 */
	Map<String, List<DataError>> getDataErrors();
	
	/**
	 * @return true if getDataErrors has errors
	 */
	boolean hasErrors();
	
}
