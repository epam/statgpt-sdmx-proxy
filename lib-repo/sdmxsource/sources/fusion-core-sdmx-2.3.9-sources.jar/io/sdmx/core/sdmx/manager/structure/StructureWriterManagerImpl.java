package io.sdmx.core.sdmx.manager.structure;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.StructureWriterFactory;
import io.sdmx.core.sdmx.api.manager.metadata.IMetadataLinkRetrievalManager;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.container.SdmxBeansSorted;
import io.sdmx.im.format.SDMXMetadataStandard;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.io.UncloseableOutputStream;
import io.sdmx.utils.sdmx.comparator.PriorityFactoryComparator;

public class StructureWriterManagerImpl implements StructureWriterManager {
	private static final Logger LOG = LoggerFactory.getLogger(StructureWriterManagerImpl.class);

	private Set<StructureWriterFactory> factories = null;
	private Map<IMetadataStandard, StructureFormat> defaultOutput = new HashMap<>();
	private IMetadataLinkRetrievalManager linkRetrievalManager;

	public StructureWriterManagerImpl() {
		this(null);
	}

	public StructureWriterManagerImpl(IMetadataLinkRetrievalManager linkRetrievalManager) {
		defaultOutput.put(SDMXMetadataStandard.getInstance(), new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V3_STRUCTURE_DOCUMENT));
		this.linkRetrievalManager = linkRetrievalManager;
	}

	/**
	 * Defines the default output format for the standard
	 * @param standard
	 * @param format
	 */
	@Override
	public void setDefaultOutput(IMetadataStandard standard, StructureFormat format) {
		defaultOutput.put(standard, format);
	}

	
	@Override
	public StructureFormat writeStructures(SdmxBeans sdmxBeans, StructureFormat outputFormat, OutputStream out) {
		SdmxBeans beans = SdmxBeansSorted.getInstance(sdmxBeans);
		Set<MaintainableBean> maintainables = beans.getAllMaintainables();
		if(maintainables.size() == 0) {
			return outputFormat;
		}
		IMetadataStandard standard = null;
		if(outputFormat == null) {
			for(MaintainableBean maint : beans.getAllMaintainables()) {
				IMetadataStandard ms = maint.getDefaultStandard();
				if(standard == null) {
					standard = ms;
				}
				if(!standard.equals(ms)) {
					throw new SdmxNotAcceptableException("Can not write structures, no output format specified and multiple supported");
				}
			}
			outputFormat = defaultOutput.get(standard);
		}
		LOG.debug("Write Structures as " + outputFormat);
		try {
			StructureWriterEngine swe = getStructureWritingEngine(outputFormat);
			boolean isSupported = false;

			Set<StructureFormat> defaultFormats= new HashSet<>();

			SdmxBeans toWrite = SdmxBeansSorted.getInstance(new SdmxBeansImpl(beans.getHeader(), beans.getAction()));
			for(ILinkBean link : beans.getLinks()) {
				toWrite.addLink(link);
			}
			
			for(MaintainableBean maint : maintainables) {
				if(swe.isSupportedType(maint)) {
					toWrite.addIdentifiable(maint);
					isSupported = true;
				} else {
					StructureFormat format = defaultOutput.get(maint.getDefaultStandard());
					if(format != null) {
						defaultFormats.add(format);
					}
				}
			}

			if(isSupported == false && defaultFormats.size() == 1) {
				StructureFormat defaultFormat = (StructureFormat) defaultFormats.toArray()[0];
				LOG.info("Requested format '"+outputFormat+"' is not supported by maintainables to be written, use default format of '"+defaultFormat+"'");
				if(defaultFormat == outputFormat) {
					throw new SdmxNotAcceptableException("Unsupported format for structure(s): "+defaultFormat.getFormatDetails().getFormatAsString());
				}
				return writeStructures(beans, defaultFormat, out);
			}
			
			Map<IURNMaintainable<?>, IExternalMaintainableLinks> externalLinks;
			if(this.linkRetrievalManager != null) {
				externalLinks = new HashMap<>();
				for(MaintainableBean maint : maintainables) {
					IExternalMaintainableLinks maintLinks = this.linkRetrievalManager.getLinks(maint);
					if(maintLinks != null && maintLinks.getLinkedIdentifiable().size() > 0) {
						externalLinks.put(maint.getURN(), maintLinks);
					}
				}
			} else {
				externalLinks = Collections.emptyMap();
			}
			swe.writeStructures(toWrite, externalLinks, out);
			return outputFormat;
		} finally {
			StreamUtil.closeStream(out);
		}
	}

	@Override
	public boolean isSupported(MaintainableBean maint, StructureFormat format) {
		try {
			StructureWriterEngine swe = getStructureWritingEngine(format);
			if(swe.isSupportedType(maint)) {
				return true;
			}
		} catch(Throwable th) {
			LOG.error("StructureWriterManagerImpl.getSupported threw error", th);
		}
		return false;
	}


	@Override
	public StructureFormat getSupported(SdmxBeans beans, StructureFormat outputFormat) {
		try {
			StructureWriterEngine swe = getStructureWritingEngine(outputFormat);
			Set<StructureFormat> defaultFormats= new HashSet<>();
			for(MaintainableBean maint : beans.getAllMaintainables()) {
				if(swe.isSupportedType(maint)) {
					return outputFormat;
				}
				StructureFormat format = defaultOutput.get(maint.getDefaultStandard());
				if(format != null) {
					defaultFormats.add(format);
				}
			}
			if(defaultFormats.size() == 1) {
				StructureFormat defaultFormat = (StructureFormat) defaultFormats.toArray()[0];
				swe = getStructureWritingEngine(defaultFormat);
				return defaultFormat;
			}
		} catch(Throwable th) {
			//Do nothing
		}
		return null;
	}

	@Override
	public void write(MaintainableBean maint, StructureFormat format, OutputStream out)	throws SdmxNotImplementedException {
		writeStructure(maint, null, format, out);
	}

	@Override
	public StructureFormat writeStructure(MaintainableBean maint, HeaderBean header, StructureFormat outputFormat, OutputStream out) {
		if(header != null) {
			SdmxBeans beans = new SdmxBeansImpl(header);
			beans.addIdentifiable(maint);
			return writeStructures(beans, outputFormat, out);
		}
		if(outputFormat == null) {
			StructureFormat format = defaultOutput.get(maint.getDefaultStandard());
			if(format != null) {
				outputFormat = format;
			}
			LOG.debug("Write Structure '"+maint+"' format not supplied, used default " + outputFormat);
		} else {
			LOG.debug("Write Structure '"+maint+"' as " + outputFormat);
		}
		try {
			if(out != null) {
				out = new UncloseableOutputStream(out);
			}
			StructureWriterEngine swe = getStructureWritingEngine(outputFormat);
			if(!swe.isSupportedType(maint)) {
				if(defaultOutput.get(maint.getDefaultStandard()) == outputFormat) {
					//Strange one here, as the bean's default format is not supported by the writer
					throw new SdmxNotAcceptableException("Could not write structures out in format: " + outputFormat.getFormatDetails().getFormatAsString());
				}
				StructureFormat defaultFormat = defaultOutput.get(maint.getDefaultStandard());
				LOG.info("Requested format '"+outputFormat+"' is not supported by maintainable type '"+maint.getStructureType()+"' use default format of '"+defaultFormat+"'");
				swe = getStructureWritingEngine(defaultFormat);
				outputFormat = defaultFormat;
			}
			IExternalMaintainableLinks links = null;
			if(this.linkRetrievalManager != null) {
				links = this.linkRetrievalManager.getLinks(maint);
			}
			swe.writeStructure(maint, links, out);
			return outputFormat;
		} finally {
			StreamUtil.closeStream(out);
		}
	}

	private StructureWriterEngine getStructureWritingEngine(StructureFormat outputFormat) {
		for(StructureWriterFactory factory : getStructureWriterFactory()) {
			StructureWriterEngine engine = factory.getStructureWriterEngine(outputFormat);
			if(engine != null) {
				//&& factory.isSupportedType(maint.getStructureType())
				return engine;
			}
		}
		throw new SdmxNotAcceptableException("Could not write structures out in format: " + outputFormat.getFormatDetails().getFormatAsString());
	}

	private Collection<StructureWriterFactory> getStructureWriterFactory() throws IllegalArgumentException {
		if(factories != null) {
			return factories;
		}
		synchronized(this) {
			TreeSet<StructureWriterFactory> localFactories = new TreeSet<>(PriorityFactoryComparator.INSTANCE);
			Collection<StructureWriterFactory> allBeans = FusionBeanStore.getBeans(StructureWriterFactory.class);
			for (StructureWriterFactory structureWriterFactory : allBeans) {
				localFactories.add(structureWriterFactory);
			}
			this.factories = localFactories;
		}
		return factories;
	}

}
