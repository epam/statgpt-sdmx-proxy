package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.categoryscheme.ReportingTaxonomyBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ReportingTaxonomyBeanDeferred}
 */
public class DeferredReportingTaxonomyReaderEngine extends AbstractDeferredStructureReaderEngine<ReportingTaxonomyBean> {
    private static DeferredReportingTaxonomyReaderEngine INSTANCE;
    
    private DeferredReportingTaxonomyReaderEngine() {
        super(ReportingTaxonomyBean.class);
    }
    
    public static DeferredReportingTaxonomyReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredReportingTaxonomyReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ReportingTaxonomyBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTaxonomyBeanDeferred(bean, loader);
    }

}
