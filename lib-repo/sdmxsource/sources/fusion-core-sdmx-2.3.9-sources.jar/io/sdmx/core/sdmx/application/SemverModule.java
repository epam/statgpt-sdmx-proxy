package io.sdmx.core.sdmx.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.core.sdmx.engine.structure.semver.CodelistSemanticVersionEngine;

public class SemverModule implements IFusionModule {

    public static void register() {
        CodelistSemanticVersionEngine.registerInstance();
    }

}
