package io.sdmx.core.sdmx.model;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * A lookup table of what structures reference what structures
 */
public class CrossReferenceLookupTable implements ICrossReferenceLookupTable {
	private static final long serialVersionUID = 1L;
	public static final CrossReferenceLookupTable EMPTY_TABLE = new CrossReferenceLookupTable(Collections.emptySet(), Collections.emptySet());

	private Set<IMaintainableReferences> maintDirectReferences = Collections.emptySet();
	private Set<IMaintainableReferences> maintIndirectReferences = Collections.emptySet();

	public CrossReferenceLookupTable(Set<IMaintainableReferences> directReferences, Set<IMaintainableReferences> indirectReferences) {
		this.maintDirectReferences = CollectionUtil.copyToImmutable(directReferences);
		this.maintIndirectReferences = CollectionUtil.copyToImmutable(indirectReferences);
	}
	
	public Set<IMaintainableReferences> getMaintDirectReferences() {
		return maintDirectReferences;
	}

	public Set<IMaintainableReferences> getMaintIndirectReferences() {
		return maintIndirectReferences;
	}

}
