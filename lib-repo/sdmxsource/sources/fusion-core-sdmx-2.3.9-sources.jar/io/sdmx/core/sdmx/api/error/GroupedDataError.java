package io.sdmx.core.sdmx.api.error;

import java.util.List;

public interface GroupedDataError {
	/**
	 * Returns the error message, for example calculation result for 'TOTAL=EUR+DE+FR+UK' does not match expected value 
	 * @return
	 */
	String getMessage();
	
	/**
	 * Returns the series (or group) short code
	 * @return
	 */
	List<String> getSeriesShortCode();
	
	/**
	 * Returns the affected observations, (this is the series short code concatenated with the obs key, example A:UK:M:2008 - where 2008 is the observation time).
	 * @return
	 */
	List<String> getObsShortCodes();
	
}
