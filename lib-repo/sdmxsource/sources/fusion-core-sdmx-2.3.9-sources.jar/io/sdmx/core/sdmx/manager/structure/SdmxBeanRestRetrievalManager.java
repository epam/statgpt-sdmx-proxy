package io.sdmx.core.sdmx.manager.structure;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IStructureTimeTravelManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.engine.structure.IPartialReferencesResolutionEngine;
import io.sdmx.core.sdmx.api.manager.structure.ExternalReferenceRetrievalManager;
import io.sdmx.core.sdmx.api.manager.structure.ServiceRetrievalManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.engine.structure.CrossReferenceResolverEngineImpl;
import io.sdmx.core.sdmx.model.structure.StructureEnvironment;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxBeanRestRetrievalManager implements ISdmxBeanRestRetrievalManager {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxBeanRestRetrievalManager.class);

	private HeaderRetrievalManager headerRetrievalManager;
	protected ServiceRetrievalManager serviceRetrievalManager;
	private ExternalReferenceRetrievalManager externalReferenceRetrievalManager;
	private IPartialReferencesResolutionEngine partialReferencesResolutionEngine;  //Used to create partial lists

	private IStructureTimeTravelManager structureTimeTravelManager;
	
	private CrossReferenceResolverEngine crossReferenceResolverEngine = new CrossReferenceResolverEngineImpl();
	
	
	public SdmxBeanRestRetrievalManager(ReadableDataLocation seed, StructureReaderManager structureReaderManager) {
		InMemoryRetrievalManager brm = new InMemoryRetrievalManager(seed, structureReaderManager);
		InMemoryCrossReferenceControl xsControl = new InMemoryCrossReferenceControl(brm.getBeans(), brm);
		this.structureTimeTravelManager = new StructureTimeTravelManagerUnsupported(new StructureEnvironment(brm, xsControl, xsControl));
		setRerviceRetrievalManager();
	}
	
	/**
	 * Minimal constructor - cross reference resolution built on construction, partial lists, stubs, external reference resolution not supported
	 * @param brm
	 */
	public SdmxBeanRestRetrievalManager(IStructureEnvironment liveEnvironment) {
		this.structureTimeTravelManager = new StructureTimeTravelManagerUnsupported(liveEnvironment);
		setRerviceRetrievalManager();
	}
	
	/**
	 * Minimal constructor - cross reference resolution built on construction, partial lists, stubs, external reference resolution not supported
	 * @param brm
	 */
	public SdmxBeanRestRetrievalManager(SdmxBeanRetrievalManager brm) {
		InMemoryCrossReferenceControl xsControl = new InMemoryCrossReferenceControl(brm, true, true);
		this.structureTimeTravelManager = new StructureTimeTravelManagerUnsupported(new StructureEnvironment(brm, xsControl, xsControl));
		setRerviceRetrievalManager();
	}
	
	/**
	 * Register interest on the beans container so it sets when ready
	 */
	private void setRerviceRetrievalManager() {
		SingletonStore.registerInterest(ServiceRetrievalManager.class, bean-> {
			this.serviceRetrievalManager = bean;
		});
	}
	
	public SdmxBeanRestRetrievalManager(
			IStructureEnvironment liveEnvironment,
			HeaderRetrievalManager headerRetrievalManager,
			ServiceRetrievalManager serviceRetrievalManager,
			ExternalReferenceRetrievalManager externalReferenceRetrievalManager,
			IPartialReferencesResolutionEngine partialReferencesResolutionEngine) {
		this.structureTimeTravelManager = new StructureTimeTravelManagerUnsupported(liveEnvironment);
		this.headerRetrievalManager = headerRetrievalManager;
		this.serviceRetrievalManager = serviceRetrievalManager;
		this.externalReferenceRetrievalManager = externalReferenceRetrievalManager;
		this.partialReferencesResolutionEngine = partialReferencesResolutionEngine;
	}

	public SdmxBeanRestRetrievalManager(
			IStructureTimeTravelManager structureTimeTravelManager,
			HeaderRetrievalManager headerRetrievalManager,
			ServiceRetrievalManager serviceRetrievalManager,
			ExternalReferenceRetrievalManager externalReferenceRetrievalManager,
			IPartialReferencesResolutionEngine partialReferencesResolutionEngine) {
		this.structureTimeTravelManager = structureTimeTravelManager;
		this.headerRetrievalManager = headerRetrievalManager;
		this.serviceRetrievalManager = serviceRetrievalManager;
		this.externalReferenceRetrievalManager = externalReferenceRetrievalManager;
		this.partialReferencesResolutionEngine = partialReferencesResolutionEngine;
	}

	@Override
	public SdmxBeans getMaintainables(RESTStructureQuery restQuery) {
		LOG.debug("Query for maintainables: "+restQuery);
		IStructureEnvironment enviroment = getStructureEnvironment(restQuery);

		STRUCTURE_QUERY_DETAIL detail = restQuery.getStructureQueryMetadata().getStructureQueryDetail();
		boolean isAllStubs =  detail == STRUCTURE_QUERY_DETAIL.ALL_STUBS || detail == STRUCTURE_QUERY_DETAIL.ALL_COMPLETE_STUBS;
		boolean isRefStubs = isAllStubs || detail == STRUCTURE_QUERY_DETAIL.REFERENCED_STUBS || detail == STRUCTURE_QUERY_DETAIL.REFERENCED_COMPLETE_STUBS;
		boolean isCompleteStubs = detail == STRUCTURE_QUERY_DETAIL.REFERENCED_COMPLETE_STUBS || detail == STRUCTURE_QUERY_DETAIL.ALL_COMPLETE_STUBS;
		boolean isReferencePartial =  detail == STRUCTURE_QUERY_DETAIL.REFERENCE_PARTIAL || detail == STRUCTURE_QUERY_DETAIL.PARTIAL_RAW;
		boolean isRaw = detail == STRUCTURE_QUERY_DETAIL.RAW || detail == STRUCTURE_QUERY_DETAIL.PARTIAL_RAW;
		
		IURN<?> urnRef = restQuery.getStructureReference();
		
		SdmxPeriod dateFromTo = restQuery.getStructureQueryMetadata().getValidFromTo();
		IURN<MaintainableBean> maintUrn = null;
		if(urnRef == URN.ANY || urnRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.ANY) {
			maintUrn = URN.builder().agencyId(urnRef.getAgencyId()).maintId(urnRef.getMaintainableId()).versionRef(urnRef.getVersion()).build(MaintainableBean.class);
		} else if(!urnRef.isMaintainableReference()) {
			maintUrn = urnRef.getMaintainableURN().toType(MaintainableBean.class);
		} else {
			maintUrn = urnRef.toType(MaintainableBean.class);
		}
		Set<MaintainableBean> queryResultMaintainables = enviroment.getBeanRetrievalManager().getMaintainableBeans(maintUrn);

		// Optionally filter (remove) Maintainables that don't fall within valid from/to
		if(dateFromTo != null) {
			queryResultMaintainables = processValidFromTo(queryResultMaintainables, dateFromTo);
		}

		Set<MaintainableBean> resolvedStubs = new HashSet<>();
		if(externalReferenceRetrievalManager != null && !isAllStubs) {
			for(MaintainableBean currentMaint : queryResultMaintainables) {
				if(currentMaint.isExternalReference()) {
					currentMaint = externalReferenceRetrievalManager.resolveFullStructure(currentMaint);
					resolvedStubs.add(currentMaint);
				}
			}
		}
		resolvedStubs.addAll(queryResultMaintainables);
		queryResultMaintainables = resolvedStubs;

		//Is this query for a identifiable child of the maintainable?  i.e if it is not referencing a maintainable, then it must be a child identifiable
		//Create partial lists of the query result maintainables
		if(!urnRef.isMaintainableReference()) {
			Set<MaintainableBean> partialBeans = new HashSet<>();
			String identifiableId = urnRef.getFullIdentifiableId();
			Set<String> identSet = new HashSet<>();
			if(identifiableId != null) {
				if (identifiableId.indexOf("+") > -1) {
					for(String currentIdentifiableId : identifiableId.split("\\+")) {
						identSet.add(currentIdentifiableId);
					}
				} else {
					for(String currentIdentifiableId : identifiableId.split(",")) {
						identSet.add(currentIdentifiableId);
					}
				}
				for(MaintainableBean maint : queryResultMaintainables) {
					if(maint instanceof ItemSchemeBean) {
						ItemSchemeBean isBean = ((ItemSchemeBean)maint).filterItems(identSet, true);
						if(isBean.getItems().size() > 0) {
							partialBeans.add(isBean);
						}
					}
				}
				queryResultMaintainables = partialBeans;
			}
		}

		LOG.debug("Returned "+queryResultMaintainables.size() + " results");

		HeaderBean header = null;
		if(headerRetrievalManager != null) {
			header = headerRetrievalManager.getHeader();
		}
		SdmxBeans referencedBeans = new SdmxBeansImpl(header);
		SdmxBeans referenceMerge = new SdmxBeansImpl();

		switch(restQuery.getStructureQueryMetadata().getStructureReferenceDetail()) {
		case NONE :
			LOG.debug("Reference detail NONE");
			break;
		case ANCESTORS :
			LOG.debug("Reference detail ANCESTORS");
			resolveAncestors(queryResultMaintainables, referencedBeans, enviroment);
			break;
		case PARENTS :
			LOG.debug("Reference detail PARENTS");
			resolveParents(queryResultMaintainables, referencedBeans, enviroment);
			break;
		case PARENTS_SIBLINGS :
			LOG.debug("Reference detail PARENTS_SIBLINGS");
			resolveParents(queryResultMaintainables, referencedBeans, enviroment);
			resolveChildren(referencedBeans.getAllMaintainables(), referenceMerge, enviroment);
			referencedBeans.merge(referenceMerge);
			break;
		case CHILDREN :
			LOG.debug("Reference detail CHILDREN");
			resolveChildren(queryResultMaintainables, referencedBeans, enviroment);
			break;
		case DESCENDANTS :
			LOG.debug("Reference detail DESCENDANTS");
			resolveDescendants(queryResultMaintainables, referencedBeans, enviroment);
			break;
		case ALL :
			LOG.debug("Reference detail ALL");
			//Combination of Parents and Siblins and Descendants
			//1. Parents and siblings
			resolveParents(queryResultMaintainables, referencedBeans, enviroment);
			resolveChildren(referencedBeans.getAllMaintainables(), referenceMerge, enviroment);
			//2. Descendants
			SdmxBeans descendants = new SdmxBeansImpl();
			resolveDescendants(queryResultMaintainables, descendants, enviroment);
			referencedBeans.merge(descendants);
			referencedBeans.merge(referenceMerge);
			break;
		case SPECIFIC :
			LOG.debug("Reference detail Children");
			resolveSpecific(queryResultMaintainables, referencedBeans, restQuery.getStructureQueryMetadata().getSpecificStructureReference(), enviroment);
			break;
		}

		if(isRaw) {
			Set<CodelistBean> queryResultCodelist = null;
			for(MaintainableBean maint : queryResultMaintainables) {
				if(maint.getStructureType() == SDMX_STRUCTURE_TYPE.CODE_LIST) {
					CodelistBean cl = (CodelistBean) maint;
					if(cl.isInherited()) {
						queryResultCodelist = queryResultCodelist != null ? queryResultCodelist : new HashSet<>();
						queryResultCodelist.add(cl.getRootCodelist());
					}
				}
			}
			if(queryResultCodelist != null) {
				queryResultMaintainables.removeAll(queryResultCodelist);
				queryResultMaintainables.addAll(queryResultCodelist);
			}
			referencedBeans.getCodelists().forEach(e-> {
				if(e.isInherited()) {
					referencedBeans.addIdentifiable(e.getRootCodelist());
				}
			});
		}
		
		if(isRefStubs && serviceRetrievalManager != null) {
			for (MaintainableBean maint : referencedBeans.getAllMaintainables()) {
				referencedBeans.addIdentifiable(serviceRetrievalManager.createStub(maint, isCompleteStubs));
			}
		}

		if (isReferencePartial && partialReferencesResolutionEngine != null) {
			partialReferencesResolutionEngine.makePartial(new SdmxBeansImpl(queryResultMaintainables), referencedBeans, enviroment.getBeanRetrievalManager());
		}

		if(isAllStubs && serviceRetrievalManager != null) {
			for (MaintainableBean maint : queryResultMaintainables) {
				referencedBeans.addIdentifiable(serviceRetrievalManager.createStub(maint, isCompleteStubs));
			}
		} else {
			referencedBeans.addIdentifiables(queryResultMaintainables);
		}
		// If "validOn" has been set, mutate the 'ref' object
		String dateOn = restQuery.getStructureQueryMetadata().getValidOn();
		if(dateOn != null) {
			Date date = SdmxDateImpl.getSdmxDate(dateOn).getDate();
			for(CodelistBean cl : referencedBeans.getCodelists()) {
				CodelistBean cloned = cl.cloneForDate(date);
				if(cloned != cl) {
					referencedBeans.addIdentifiable(cloned);
				}
			}
			for(ConceptSchemeBean cl : referencedBeans.getConceptSchemes()) {
				ConceptSchemeBean cloned = cl.cloneForDate(date);
				if(cloned != cl) {
					referencedBeans.addIdentifiable(cloned);
				}
			}
			for(CategorySchemeBean cl : referencedBeans.getCategorySchemes()) {
				CategorySchemeBean cloned = cl.cloneForDate(date);
				if(cloned != cl) {
					referencedBeans.addIdentifiable(cloned);
				}
			}
		}


		LOG.debug("Result Size : " +referencedBeans.getAllMaintainables().size());
		return referencedBeans;
	}

//	private Set<CodelistBean> makeRaw(Set<CodelistBean> codelists, RESTStructureQuery restQuery, SdmxBeans referencedBeans, IStructureEnvironment enviroment) {
//		Set<CodelistBean> toReplace = null;
//		for(CodelistBean cl : codelists) {
//			toReplace = toReplace != null ? toReplace : new HashSet<>(codelists.size());
//			if(cl.isInherited()) {
//				toReplace.add(cl.getRootCodelist());
//				switch(restQuery.getStructureQueryMetadata().getStructureReferenceDetail()) {
//				case SPECIFIC:
//					if(restQuery.getStructureQueryMetadata().getSpecificStructureReference() != SDMX_STRUCTURE_TYPE.CODE_LIST) {
//						break;
//					}
//				case ALL:
//				case CHILDREN:
//					determineInheritanceReferences(cl.getRootCodelist(), referencedBeans, toReplace, false, enviroment);
//					break;
//				case DESCENDANTS:
//					determineInheritanceReferences(cl.getRootCodelist(), referencedBeans, toReplace, true, enviroment);
//					break;
//				default:
//					break;
//
//				}
//			}
//		}
//		return toReplace;
//	}

	/**
	 * Determines the codelist inheritance rules and populates the supplied SdmxBeans (which references) and Set of Maintainables (with items that are needed to be replaced
	 * later on in the processing).
	 * @param aCodelist the codelist to analyse
	 * @param referencedBeans a beans container which further codelist beans may be placed into (if they are not raw)
	 * @param toReplace a Set of maintainable beans which are kept separate from the "referencedBeans" so that
	 * @param resolveFurtherChildRefs a boolean stating whether to resolve child references further down the tree
	 */
	private void determineInheritanceReferences(CodelistBean aCodelist, SdmxBeans referencedBeans, Set<CodelistBean> toReplace, boolean resolveFurtherChildRefs, IStructureEnvironment enviroment) {
		for(ICodelistInheritanceRuleBean rule : aCodelist.getInheritedCodelists()) {
			CodelistBean refCodelist = enviroment.getBeanRetrievalManager().getBean(rule.getCodelistRef().getReference());
			CodelistBean rootCodelist = refCodelist.getRootCodelist();
			if (rootCodelist != null) {
				// By adding it to "toReplace" it will then output as raw
				toReplace.add(rootCodelist);
				if (resolveFurtherChildRefs && ObjectUtil.validCollection(rootCodelist.getInheritedCodelists())) {
					determineInheritanceReferences(rootCodelist, referencedBeans, toReplace, true, enviroment);
				}
			} else {
				referencedBeans.addIdentifiable(refCodelist);
			}
		}
	}

	/**
	 * return the beans of the beans that contain validityPeriods and they are within the suupplied validityPeriod of the query
	 * @param queryResultMaintainables
	 * @param dateFromTo
	 * @return
	 */
	private Set<MaintainableBean> processValidFromTo(Set<? extends MaintainableBean> queryResultMaintainables, SdmxPeriod dateFromTo) {
		Set<MaintainableBean> returnSet = new HashSet<>();
		for (MaintainableBean maint : queryResultMaintainables) {
			SdmxPeriod validityPeriodMaint = maint.getValidityPeriod();
			if(dateFromTo.isInPeriod(validityPeriodMaint)) {
				returnSet.add(maint);
			}
		}
		return returnSet;
	}

	private void resolveSpecific(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, SDMX_STRUCTURE_TYPE specificType, IStructureEnvironment enviroment) {
		if(LOG.isDebugEnabled()) {
			LOG.debug("Resolving Child Structures");
		}
		CrossReferencedRetrievalManager descendantRM = enviroment.getDescendantRetrievalManager();
		CrossReferencingRetrievalManager ancestorRM = enviroment.getAncestorRetrievalManager();
		for(MaintainableBean currentMaintainable : resolveFor) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Resolving Children of " + currentMaintainable.getUrn());
			}
			//TODO why false on include indirect?
			referencedBeans.addIdentifiables(descendantRM.getCrossReferencedStructures(currentMaintainable.getURN(), false, specificType));
			if(ancestorRM != null) {
				referencedBeans.addIdentifiables(ancestorRM.getCrossReferencingStructures(currentMaintainable.getURN(), false, specificType));
			}
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug(referencedBeans.getAllMaintainables().size() + " children found");
		}
	}

	private void resolveDescendants(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, IStructureEnvironment enviroment) {
		resolveDownTree(resolveFor, referencedBeans, enviroment, true);
	}

	private void resolveChildren(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, IStructureEnvironment enviroment) {
		resolveDownTree(resolveFor, referencedBeans, enviroment, false);
	}
	
	private void resolveDownTree(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, IStructureEnvironment enviroment, boolean fullTree) {
		String resolveType = fullTree ? "descendants" : "children";
		if(LOG.isDebugEnabled()) {
			LOG.debug("Resolving "+resolveType);
		}
		CrossReferencedRetrievalManager descendantRM = enviroment.getDescendantRetrievalManager();
		for(MaintainableBean currentMaintainable : resolveFor) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Resolving "+resolveType+" of " + currentMaintainable.getUrn());
			}
			Set<MaintainableBean> children;
			if(currentMaintainable.isPartial()) {
				IReferenceResolution refResolution = crossReferenceResolverEngine.resolveReferences(currentMaintainable, fullTree, true, fullTree ? -1 : 1, enviroment.getBeanRetrievalManager());
				children = refResolution.getAllBeans(RESOLUTION_TYPE.BOTH).getAllMaintainables();
			} else {
				children = descendantRM.getCrossReferencedStructures(currentMaintainable.getURN(), true, fullTree, MaintainableBean.class);
			}
			

			referencedBeans.addIdentifiables(children);
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug(referencedBeans.getAllMaintainables().size() + " " + resolveType + " found");
		}
	}


	private void resolveParents(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, IStructureEnvironment enviroment) {
		if(LOG.isDebugEnabled()) {
			LOG.debug("Resolving Parents Structures");
		}

		CrossReferencingRetrievalManager ancestorRM = enviroment.getAncestorRetrievalManager();
		if(ancestorRM == null) {
			throw new SdmxNotImplementedException("Resolve parents not supported");
		}
		for(MaintainableBean currentMaintainable : resolveFor) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Resolving Parents of " + currentMaintainable.getUrn());
			}
			referencedBeans.addIdentifiables(ancestorRM.getCrossReferencingStructures(currentMaintainable, false));
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug(referencedBeans.getAllMaintainables().size() + " parents found");
		}
	}
	
	private void resolveAncestors(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans, IStructureEnvironment enviroment) {
		if(LOG.isDebugEnabled()) {
			LOG.debug("Resolving Ancestor Structures");
		}
		CrossReferencingRetrievalManager ancestorRM = enviroment.getAncestorRetrievalManager();
		if(ancestorRM == null) {
			throw new SdmxNotImplementedException("Resolve ancestors not supported");
		}
		for(MaintainableBean currentMaintainable : resolveFor) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Resolving Parents of " + currentMaintainable.getUrn());
			}
			referencedBeans.addIdentifiables(ancestorRM.getAllAncestors(currentMaintainable.getURN()));
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug(referencedBeans.getAllMaintainables().size() + " ancestors found");
		}
	}

	/**
	 * @return the structure environment for the query
	 */
	protected IStructureEnvironment getStructureEnvironment(RESTStructureQuery restQuery) {
		SdmxDate asOf = restQuery.getStructureQueryMetadata().getAsOf();
		return structureTimeTravelManager.getEnvironment(asOf);
	}
}
