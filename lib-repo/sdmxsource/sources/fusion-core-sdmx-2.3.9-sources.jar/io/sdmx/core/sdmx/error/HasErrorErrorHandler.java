package io.sdmx.core.sdmx.error;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;

public class HasErrorErrorHandler implements DataValidationEngineErrorHandler, DataValidationErrorReporter {
	private boolean hasError;

	public boolean hasError() {
		return hasError;
	}
	
	public void resetState() {
		this.hasError = false;
	}

	@Override
	public void reportError(FusionError fe, KeyValue component, Observation obs) {
		hasError = true;
	}

	@Override
	public void reportObsError(FusionError fe, KeyValue component, String... obsShortCode) {
		hasError = true;
	}

	@Override
	public void reportError(FusionError fe, KeyValue component, Keyable obs) {
		hasError = true;
	}

	@Override
	public void reportError(FusionError fe, IMultilingualKeyValue component, Keyable key) {
		hasError = true;
	}

	@Override
	public void reportDatasetAttributeError(FusionError fe, KeyValue attribute) {
		hasError = true;
	}
	
	@Override
	public void reportError(FusionError fe, KeyValue component) {
		hasError = true;
	}

	@Override
	public void reportError(FusionError fe, IMultilingualKeyValue component) {
		hasError = true;
	}

}
