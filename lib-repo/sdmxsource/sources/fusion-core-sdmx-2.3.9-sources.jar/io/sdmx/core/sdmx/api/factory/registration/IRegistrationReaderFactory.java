package io.sdmx.core.sdmx.api.factory.registration;

import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;

public interface IRegistrationReaderFactory {

	/**
	 * reads the registrations from the stream if it can, if the stream is in a format not supported by this factory then 
	 * null or an empty list will be returned
	 * @param rdl
	 * @return
	 */
	List<RegistrationInformation> readRegistrations(ReadableDataLocation rdl);
	
}
