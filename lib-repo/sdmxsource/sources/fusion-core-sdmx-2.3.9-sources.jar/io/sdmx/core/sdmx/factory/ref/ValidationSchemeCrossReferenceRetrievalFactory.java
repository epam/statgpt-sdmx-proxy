package io.sdmx.core.sdmx.factory.ref;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.builder.IDimensionValidationExpressionBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.data.calculation.IDimensionValidationExpression;
import io.sdmx.api.sdmx.model.data.calculation.ValidationExpression;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public class ValidationSchemeCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory, IFusionSingleton {
	private static ValidationSchemeCrossReferenceRetrievalFactory INSTANCE;
	private IDimensionValidationExpressionBuilder dimensionValidationExpressionBuilder;

	
	public ValidationSchemeCrossReferenceRetrievalFactory() {
		SingletonStore.registerInterest(IDimensionValidationExpressionBuilder.class, (instance)-> {
			this.dimensionValidationExpressionBuilder = instance;
		});
	}

	public static ValidationSchemeCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ValidationSchemeCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return ValidationSchemeBean.class;
	}

	public static ValidationSchemeCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		ValidationSchemeBean validationSchemeBean = (ValidationSchemeBean) maintBean;
		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();

		DataflowBean flow = retrievalManager.getBean(validationSchemeBean.getAttachment().getReference());
		if(flow != null && dimensionValidationExpressionBuilder != null) {
			Set<IDimensionValidationExpression> validationExpressions = dimensionValidationExpressionBuilder.buildRules(validationSchemeBean);

			DataStructureBean dsd = retrievalManager.getBean(flow.getDataStructureRef().getReference());
			if(dsd != null) {
				for(IDimensionValidationExpression vEx : validationExpressions) {
					ValidationRuleBean valRule = vEx.getRule();
					List<DimensionBean> dimensions = dsd.getDimensionList().getDimensions();
					if(dimensions.size() <= vEx.getDimensionIndex()) {
//						//TODO This should be a validation failure
//						throw new SdmxSemmanticException("Error with validation rule '"+valRule.getUrn()+"' expression '"+valRule.getExpression()+"' exceeds number of dimensions in Data Structure ''");
						continue;
					}
					DimensionBean dim = dimensions.get(vEx.getDimensionIndex());
					if(!addCrossReferences(returnReferences, dim.getRepresentation(), vEx, valRule)) {
						ConceptBean concept = retrievalManager.getBean(dim.getConceptRef().getReference());
						addCrossReferences(returnReferences, concept.getRepresentation(), vEx, valRule);
					}
				}
			}
		}
		return returnReferences;
	}

	private boolean addCrossReferences(Set<ICrossReferenceBean<?>> crossReferences, RepresentationBean representation, ValidationExpression vEx, ValidationRuleBean rule) {
		if(representation != null && representation.getRepresentation() != null) {
			IURNSingle<? extends EnumeratedListBean> repRef = representation.getRepresentation().getReference();
			for(String codeId : vEx.getInputCodes()) {
				IURNSingle<CodeBean> codeRef = URN.builder().toIdentifiable(repRef, SDMX_STRUCTURE_TYPE.CODE, codeId).buildSingle(CodeBean.class);
				crossReferences.add(new IndirectReferenceBean<CodeBean>(rule, codeRef));
			}
			return true;
		}
		return false;
	}
}
