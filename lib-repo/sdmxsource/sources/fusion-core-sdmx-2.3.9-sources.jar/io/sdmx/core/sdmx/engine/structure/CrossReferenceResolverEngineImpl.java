package io.sdmx.core.sdmx.engine.structure;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.manager.structure.MaintainableCrossReferenceRetrieverEngine;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.manager.structure.MultipleBeanRetrievalManager;
import io.sdmx.core.sdmx.model.ref.ReferenceResolution;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.sdmx.structure.AgencyUtil;
import io.sdmx.utils.sdmx.xs.CrossReferenceBean;
import io.sdmx.utils.sdmx.xs.ResolvedCrossReferenceBean;
import io.sdmx.utils.sdmx.xs.URN;

public class CrossReferenceResolverEngineImpl implements CrossReferenceResolverEngine {
	private static final Logger LOG = LoggerFactory.getLogger(CrossReferenceResolverEngineImpl.class);
	private SdmxBeanRetrievalManager retrievalManager;
	
	/**
	 * Default Constructor
	 */
	public CrossReferenceResolverEngineImpl() {}
	
	/**
	 * Constructor which includes a permanent SdmxBeanRetrievalManager for resolution
	 */
	public CrossReferenceResolverEngineImpl(SdmxBeanRetrievalManager retrievalManager) {
		this.retrievalManager = retrievalManager;
	}

	private class IdentifiableCache {
	    Map<String, IdentifiableBean> fullId2Identifiable = new HashMap<>();
	    
	    public IdentifiableCache(MaintainableBean maint) {
	        fullId2Identifiable = maint.getIdentifiableComposites().stream().collect(Collectors.toMap(e->e.getFullIdPath(false), e->e));
	    }
	    
	    public IdentifiableBean getIdentifiable(IURNSingle urn) {
	        return fullId2Identifiable.get(urn.getFullIdentifiableId());
	    }
	}

	/**
	 * A Transitory contained of pre fetched structures to help with performance of reference resolution
	 *
	 */
	private class ReferenceCache {
		/**
		 * all Identifiables that are referenced
		 */
		private Map<String, MaintainableBean> allReferencedMaintainables = new HashMap<>();
		private Map<MaintainableBean, IdentifiableCache> identCache = new HashMap<>();
		private Map<String, AgencyBean> agencyMap = new HashMap<>();

		private SdmxBeanRetrievalManager retrievalManager;
		
		private SdmxBeans beans;

		public ReferenceCache(SdmxBeans beans, SdmxBeanRetrievalManager retrievalManager) {
			this.retrievalManager = retrievalManager;
			for(AgencyBean agency : beans.getAgencies()) {
				agencyMap.put(agency.getFullId(), agency);
			}
			for(MaintainableBean maint : beans.getAllMaintainables()) {
				allReferencedMaintainables.put(maint.getUrn(), maint);
			}
			this.beans = beans;
		}

		private IdentifiableBean resolveCrossReference(ICrossReferenceBean<?> crossReference) {
			//1. Try local Maps
		    IURNSingle<?> targetURN = crossReference.getReference();
			String maintUrn = targetURN.getMaintainableURN().getURN();
			MaintainableBean maint = null;
			boolean isSemVerRef = !targetURN.getVersion().isAbsolute();
			if(isSemVerRef) {
				maint = beans.getBean(targetURN.getMaintainableURN());
			}
			if(maint == null) {
			    maint = allReferencedMaintainables.get(maintUrn);
			}
			if(maint != null) {
				if(targetURN.isMaintainableReference()) {
					return maint;
				} else {
				    IdentifiableCache cache = identCache.get(maint);
		            if(cache == null) {
		                cache = new IdentifiableCache(maint);
		                identCache.put(maint, cache);
		            }
		            return cache.getIdentifiable(targetURN);
				}
			}

			IdentifiableBean identifiableBean = null;
			if(retrievalManager != null) {
				if(LOG.isDebugEnabled()) {
					LOG.debug("IdentifiableBean '"+crossReference+"' not found locally, check IdentifiableRetrievalManager");
				}
				boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
				try {
					SdmxException.disableExceptionTrace(true);
					identifiableBean = retrievalManager.getBean(crossReference.getReference());
				} catch(Throwable th) {
					th.printStackTrace();
				}finally {
					SdmxException.disableExceptionTrace(wasDisabled);
				}
			}
			if(identifiableBean == null) {
				return null;
			}
			addMaintainableToMap(identifiableBean, crossReference);
			return identifiableBean;
		}

		private AgencyBean resolveAgencyBean(MaintainableBean maint) {
			String agencyId = maint.getAgencyId();
			AgencyBean agency = agencyMap.get(agencyId);
			if(agency != null) {
				return agency;
			}
			if(retrievalManager != null) {
				agency = resolveAgency(agencyId, retrievalManager);
			}
			if(agency == null) {
				return null;
			}
			
			agencyMap.put(agency.getId(), agency);
			return agency;
		}

		private void addMaintainableToMap(IdentifiableBean ident, ICrossReferenceBean<?> crossReference) {
			MaintainableBean maint = ident.getMaintainableParent();
			allReferencedMaintainables.put(maint.getUrn(), maint);
			if(crossReference.getReference().getReferenceType() == REFERENCE_TYPE.SEMANTIC) {
			    allReferencedMaintainables.put(crossReference.getReference().getMaintainableURN().getURN(), maint);
			}
		}
	}




	@Override
	public Set<MaintainableBean> removeBrokenReferences(SdmxBeans beans,  boolean includeAgencyReferences, SdmxBeanRetrievalManager beanRetrievalManager) {
		IReferenceResolution resolution = this.resolveReferences(beans, includeAgencyReferences, false, -1, null);
		Set<MaintainableBean> removedMaintainables = new HashSet<>();

		for(IdentifiableBean ident : resolution.getMissingReferences()) {
			MaintainableBean maint = ident.getMaintainableParent();
			if(removedMaintainables.add(maint)) {
				beans.removeMaintainable(maint);
			}
		}
		return removedMaintainables;
	}

	@Override
	public IReferenceResolution resolveReferences(MaintainableBean bean,
			boolean resolveAgencies,
			boolean includeWeakReferences,
			int numberLevelsDeep,
			SdmxBeanRetrievalManager retrievalManager) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(bean);
		return resolveReferences(beans, resolveAgencies, includeWeakReferences, numberLevelsDeep, retrievalManager);
	}

	@Override
	public IReferenceResolution resolveReferences(SdmxBeans beans,
			boolean resolveAgencies,
			boolean includeWeakReferences,
			int numberLevelsDeep,
			SdmxBeanRetrievalManager retrievalManager) {
		int numberBeansLast = 0;
		int numberReferencesLast = 0;

		int numberBeansCurrent = -1;
		int numberReferencesCurrent = -1;

		int currentLevel = 1;
		Set<MaintainableBean> processedMaintainableBeans = new HashSet<>(beans.getAllMaintainables());
		ReferenceResolution returnResolution = null;
		SdmxBeans toProcessBeans = new SdmxBeansImpl(beans);
		
		if(retrievalManager == null) {
			retrievalManager = this.retrievalManager;
		} else if(this.retrievalManager != null && this.retrievalManager != retrievalManager) {
			retrievalManager = new MultipleBeanRetrievalManager(retrievalManager, this.retrievalManager);
		}
		
		ReferenceCache cache = new ReferenceCache(toProcessBeans, retrievalManager);
		do {
			numberBeansLast = numberBeansCurrent;
			numberReferencesLast = numberReferencesCurrent;
			if(LOG.isDebugEnabled()) {
				LOG.debug("numberBeansLast= "+numberBeansLast);
				LOG.debug("numberReferencesLast= "+numberReferencesLast);
			}

			ReferenceResolution currentMap = resolveReferencesInternal(toProcessBeans, cache, resolveAgencies, includeWeakReferences, retrievalManager);
			toProcessBeans = new SdmxBeansImpl();

			for(IdentifiableBean referencedFrom : currentMap.getReferences(RESOLUTION_TYPE.BOTH)) {
				for(ICrossReferenceBeanResolved<?> resolvedRef : currentMap.getReferences(referencedFrom, RESOLUTION_TYPE.BOTH)) {
					MaintainableBean maint = resolvedRef.getResolvedBean().getMaintainableParent();
					if(!processedMaintainableBeans.contains(maint)) {
						toProcessBeans.addIdentifiable(maint);
					}
				}
			}
			if(returnResolution == null) {
				returnResolution = currentMap;
			} else {
				returnResolution.merge(currentMap);
			}
			if(currentLevel == numberLevelsDeep) {
				break;
			}
			currentLevel++;
		} while(toProcessBeans.getAllMaintainables().size() > 0);
		return returnResolution;
	}


	/**
	 * @param beans
	 * @param cache
	 * @param resolveAgencies
	 * @param beanRetrievalManager - in order to obtain references that are not in the supplied beans
	 * @return
	 */
	private ReferenceResolution resolveReferencesInternal(SdmxBeans beans, ReferenceCache cache, boolean resolveAgencies,
			boolean includeWeakReferences, SdmxBeanRetrievalManager beanRetrievalManager) {
		ReferenceResolution resolution = new ReferenceResolution();
		//Add all the top level beans to the maintainables list

		//LOOP THROUGH ALL THE BEANS AND RESOLVE ALL THE REFERENCES
		if(resolveAgencies) {
			resolveAgencies(beans, resolution, cache);
		}
		Set<MaintainableBean> loopSet = new HashSet<>();
		loopSet.addAll(beans.getAllMaintainables());
		SdmxBeanRetrievalManager localRetreivalmanager = beans;
		SdmxBeanRetrievalManager retrievalManager = beanRetrievalManager == null ? localRetreivalmanager : new MultipleBeanRetrievalManager(localRetreivalmanager, beanRetrievalManager);

		for(MaintainableBean currentMaintainable : loopSet) {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Resolving References For : " + currentMaintainable.getUrn());
			}
			Set<ICrossReferenceBean<?>> crossReferences;
			try {
				MaintainableCrossReferenceRetrieverEngine xsResolver = new MaintainableCrossReferenceRetrieverEngineImpl();
				crossReferences = xsResolver.getCrossReferences(retrievalManager, currentMaintainable, includeWeakReferences==false, false);
			} catch(CrossReferenceException e) {
				crossReferences = new HashSet<>(currentMaintainable.getCrossReferences());
				crossReferences.add(e.getCrossReference()); //The missing cross reference
			} catch(Throwable th) {
				//TODO Report this to a higher level
				LOG.error("Cross Reference resolution failure", th);
				crossReferences = new HashSet<>(currentMaintainable.getCrossReferences());
			}
			LOG.debug("Number of References : " + crossReferences.size());
			int i =0;
			for(ICrossReferenceBean<?> crossReference : crossReferences) {
				i++;
				if(LOG.isDebugEnabled()) {
					LOG.debug("Resolving Reference "+i+": " + crossReference.toString() + " - referenced from -" + crossReference.getReferencedFrom().getStructureType());
				}
				try {
					IdentifiableBean referenced = cache.resolveCrossReference(crossReference);
					if(referenced != null) {
						ICrossReferenceBeanResolved<?> crossRefResolved = ResolvedCrossReferenceBean.build(crossReference, referenced);
						resolution.storeRef(crossRefResolved);
					} else {
						handleMissingReference(crossReference, resolution);
					}
				} catch(CrossReferenceException e) {
					handleMissingReference(e, resolution);
				}
			}
		}
		return resolution;
	}

	private void resolveAgencies(SdmxBeans beans, ReferenceResolution resolution, ReferenceCache cache) {
		for(MaintainableBean currentBean : beans.getAllMaintainables()) {
			try {
				if(currentBean.getStructureType() == SDMX_STRUCTURE_TYPE.AGENCY_SCHEME && currentBean.getAgencyId().equals(AgencySchemeBean.DEFAULT_SCHEME)) {
					//Default Agency Scheme
					continue;
				}
				AgencyBean acy = cache.resolveAgencyBean(currentBean);
				if(acy != null) {
					resolution.storeAgencyRef(currentBean, acy);
				} else {
					handleMissingReference(CrossReferenceBean.build(currentBean, AgencyUtil.toRef(currentBean)), resolution);
				}
			} catch(CrossReferenceException e) {
				handleMissingReference(e, resolution);
			}
		}
	}

	private void handleMissingReference(CrossReferenceException e, ReferenceResolution resolution) {
		if(e.getCrossReference() != null) {
			handleMissingReference(e.getCrossReference(), resolution);
		}
	}

	private void handleMissingReference(ICrossReferenceBean<?> crossReference, ReferenceResolution resolution) {
		if(crossReference != null) {
			resolution.storeMissingRef(crossReference);
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////AGENCY REFERENCES                                            ///////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private AgencyBean resolveAgency(String agencyId, SdmxBeanRetrievalManager beanRetrievalManager) {
		String[] split = agencyId.split("\\.");
		String parentAgencyId = AgencySchemeBean.DEFAULT_SCHEME;
		String targetAgencyId = agencyId;
		if(split.length > 1) {
			targetAgencyId = split[split.length-1];
			split[split.length-1] = null;
			String concat = "";
			parentAgencyId = "";
			for(String currentSplit : split) {
				if(currentSplit != null) {
					parentAgencyId += concat + currentSplit;
				}
				concat = ".";
			}
		}
		try {
			return beanRetrievalManager.getBean(URN.builder().agencyId(parentAgencyId).identifableId(targetAgencyId).structure(AgencyBean.class).buildAbsolute(AgencyBean.class));
		} catch(Throwable th) {
			th.printStackTrace();
			return null;
		}
	}
}
