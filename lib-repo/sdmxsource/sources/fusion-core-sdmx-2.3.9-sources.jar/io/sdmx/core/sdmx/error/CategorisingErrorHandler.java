package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.error.IDataErrorContainer;
import io.sdmx.api.sdmx.exception.ErrorLimitException;

public class CategorisingErrorHandler implements DataValidationErrorHandler, IDataErrorContainer {
	
	//Dataset Index to the Reported Errors
	private Map<Integer, ReportedErrors> reportedErrors = new HashMap<>();
	private int datasetIndex = 0;
	private ReportedErrors currentErrors = null;
	
	public Set<Integer> getDatasetsWithErrors() {
		return new HashSet<>(reportedErrors.keySet());
	}
	

	@Override
	public void handleError(DataError err) throws ErrorLimitException {
		getReportedErrors().handleDataError(err);
	}
	
	
	
	@Override
	public Map<String, List<DataError>> getDataErrors() {
		Map<String, List<DataError>> returnMap = new HashMap<>();
		for(Integer dsIdx : reportedErrors.keySet()) {
			ReportedErrors errors = reportedErrors.get(dsIdx);
			if(errors != null) {
				Map<String, List<DataError>> categorisedErrors = errors.getCategorisedErrors();
				for(String category : categorisedErrors.keySet()) {
					List<DataError> exitingErrors = returnMap.get(category);
					if(exitingErrors == null) {
						exitingErrors = new ArrayList<>();
						returnMap.put(category, exitingErrors);
					}
					exitingErrors.addAll(categorisedErrors.get(category));
				}
			}
		}
		return returnMap;
	}
	
	@Override
	public boolean hasErrors() {
		return reportedErrors.size() > 0;
	}


	/**
	 * Returns the errors for the current dataset, or creates it if it does not exist
	 * @return
	 */
	private ReportedErrors getReportedErrors() {
		if(currentErrors == null) {
			currentErrors = new ReportedErrors();
			reportedErrors.put(datasetIndex, currentErrors);
		} 
		return currentErrors;
	}

	/**
	 * Returns a copy of error category to a set of errors
	 * @return
	 */
	public ReportedErrors getErrors(int dataset) {
		return reportedErrors.get(dataset);
	}
}