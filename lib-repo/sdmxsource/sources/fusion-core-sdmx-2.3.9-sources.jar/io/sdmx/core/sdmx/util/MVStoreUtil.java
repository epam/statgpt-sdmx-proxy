package io.sdmx.core.sdmx.util;

import java.io.File;

import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.h2.mvstore.type.BasicDataType;

import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;
import io.sdmx.core.sdmx.model.mvstore.MVStoreWrap;

/**
 * Utility methods for MVStore
 */
public class MVStoreUtil {
	private static final String NULL_TAG = "__NULL_TAG__";

	public static IMVStore getStore() {
		return getStore(null);
	}
	
	public static IMVStore getStore(File file) {
		return new MVStoreWrap(file);
	}

	public static <M extends MVMap<K, V>, K, V>  MVMap<K,V> openMap(String name, int index, BasicDataType<K> key, BasicDataType<V> value, IMVStore db) {
		return openMap(name, index, key, value, db.getStore());
	}
	
	public static <M extends MVMap<K, V>, K, V>  MVMap<K,V> openMap(String name, int index, BasicDataType<K> key, BasicDataType<V> value, MVStore db) {
		MVMap.Builder<K, V> builder1 = new MVMap.Builder<>();
		builder1.keyType(key);
		builder1.valueType(value);
		
		String mapName = getMapName(name, index);
		return db.openMap(mapName, builder1);
	}

	private static String getMapName(String prefix, int index) {
		return String.format("%s_%06d", prefix, index);
	}

	@SuppressWarnings("unchecked")
	/**
	 * @param <T>
	 * @param obj
	 * @return if the object is the null tag, returns null, otherwise casts to the given object
	 */
	public static <T> T nullOrCast(Object obj) {
		return (T)(NULL_TAG.equals(obj) ? null : obj);
	}

	/**
	 * @param <T>
	 * @param obj
	 * @return the object if not null, otherwise the null tag
	 */
	public static Object nullOrObject(Object obj) {
		return (obj == null) ? NULL_TAG : obj;
	}
}
