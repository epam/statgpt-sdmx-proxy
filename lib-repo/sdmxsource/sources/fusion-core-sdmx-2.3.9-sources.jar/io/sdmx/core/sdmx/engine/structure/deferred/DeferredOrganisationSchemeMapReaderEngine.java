package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IOrganisationSchemeMapBean;
import io.sdmx.im.beans.mapping.v3.OrganisationSchemeMapBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link OrganisationSchemeMapBeanDeferred}
 */
public class DeferredOrganisationSchemeMapReaderEngine extends AbstractDeferredStructureReaderEngine<IOrganisationSchemeMapBean> {
    private static DeferredOrganisationSchemeMapReaderEngine INSTANCE;
    
    private DeferredOrganisationSchemeMapReaderEngine() {
        super(IOrganisationSchemeMapBean.class);
    }
    
    public static DeferredOrganisationSchemeMapReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredOrganisationSchemeMapReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IOrganisationSchemeMapBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationSchemeMapBeanDeferred(bean, loader);
    }

}
