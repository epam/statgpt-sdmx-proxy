package io.sdmx.core.sdmx.format;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;

/**
 * Format for schema output when the output is a structure document
 */
public class StructureSchemaFormat implements SchemaFormat {
	private static final long serialVersionUID = 1L;
	private StructureFormat structureFormat;
	
	public StructureSchemaFormat(StructureFormat structureFormat) {
		this.structureFormat = structureFormat;
		if(structureFormat == null) {
			throw new SdmxException("StructureSchemaFormat requires a StructureFormat");
		}
	}

	@Override
	public FormatDetails getFormatDetails() {
		return structureFormat.getFormatDetails();
	}

	public StructureFormat getStructureFormat() {
		return structureFormat;
	}
	
	@Override
	public int hashCode() {
		return structureFormat.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof StructureSchemaFormat) {
			StructureSchemaFormat that = (StructureSchemaFormat) obj;
			return that.getStructureFormat() == structureFormat;
		}
		return false;
	}

	@Override
	public String toString() {
		return "SchemaFormat:"+structureFormat.getWebServiceFormat();
	}
}
