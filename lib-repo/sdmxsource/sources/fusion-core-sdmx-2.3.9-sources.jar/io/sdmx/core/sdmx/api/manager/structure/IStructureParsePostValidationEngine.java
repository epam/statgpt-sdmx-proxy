package io.sdmx.core.sdmx.api.manager.structure;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Performs validation of the Maintainable that can not be achieved in the construction of the bean (generally because it requires additional structures)
 * 
 * Note: This is not responsible for verifying all cross references exist but it can report cross reference errors if it can not perform its checks due to missing structures required for the checks to be performed
 */
public interface IStructureParsePostValidationEngine {
	
	/**
	 * @return the supported structure type for this engine
	 */
	SDMX_STRUCTURE_TYPE getStructureType();

	/**
	 * @param maint to verify
	 * @param brm to retrieve any additional references 
	 */
	void validateMaintainble(MaintainableBean maint, SdmxBeanRetrievalManager brm);
	
}
