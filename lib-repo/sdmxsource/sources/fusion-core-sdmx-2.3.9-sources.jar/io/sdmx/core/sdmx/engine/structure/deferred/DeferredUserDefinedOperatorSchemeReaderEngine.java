package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.im.beans.transformation.UserDefinedOperatorSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link UserDefinedOperatorSchemeBeanDeferred}
 */
public class DeferredUserDefinedOperatorSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<IUserDefinedOperatorSchemeBean> {
    private static DeferredUserDefinedOperatorSchemeReaderEngine INSTANCE;
    
    private DeferredUserDefinedOperatorSchemeReaderEngine() {
        super(IUserDefinedOperatorSchemeBean.class);
    }
    
    public static DeferredUserDefinedOperatorSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredUserDefinedOperatorSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IUserDefinedOperatorSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new UserDefinedOperatorSchemeBeanDeferred(bean, loader);
    }

}
