package io.sdmx.core.sdmx.api.engine.data;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.data.IDataPosition;

public interface IPositionReaderEngine {

	/**
	 * @param asString
	 * @return the data position as a string
	 * @throws SdmxSemmanticException if the prefix of the string does not match the supported prefix
	 */
	IDataPosition string2Position(String asString);
	
	/**
	 * @return the prefix in the {@link IDataPosition} position key i.e. fip would be the prefix for IFilePosition
	 */
	String getPositionPrefix();
}
