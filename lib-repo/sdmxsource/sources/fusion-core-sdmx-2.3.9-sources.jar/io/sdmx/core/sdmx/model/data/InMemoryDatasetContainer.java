package io.sdmx.core.sdmx.model.data;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.model.data.IDatasetStore;
import io.sdmx.core.sdmx.api.model.data.IDatasetStoreContainer;

public class InMemoryDatasetContainer implements IDatasetStoreContainer {
	private HeaderBean header;
	private List<InMemoryDataset> datasets = new ArrayList<>();
	private InMemoryDataset currentDataset = null;

	public InMemoryDatasetContainer(HeaderBean header, InMemoryDataset... datasets) {
		this.header = header;
		if(datasets != null) {
			for(InMemoryDataset ds : datasets) {
				this.datasets.add(ds);
			}
		}
	}

	public InMemoryDatasetContainer(HeaderBean header) {
		this.header = header;
	}
	
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		currentDataset = new InMemoryDataset(header, structures);
		if(datasetAttributes != null) {
			currentDataset.writeDatasetAttributes(datasetAttributes);
		}
		this.datasets.add(currentDataset);
	}
	
	public HeaderBean getHeader() {
		return header;
	}
	
	@Override
	public int getDatasetSize() {
		return datasets.size();
	}

	@Override
	public IDatasetStore getDataset(int index) {
		if(datasets.size() <= index) {
			return null;
		}
		return datasets.get(index);
	}

	@Override
	public void close(boolean removeResources) {
		if(removeResources) {
			header = null;
			datasets = new ArrayList<>();
			currentDataset = null;
		}
	}

	public List<InMemoryDataset> getDatasets() {
		return datasets;
	}
	

	public void writeKey(Keyable key) {
		currentDataset.writeKey(key);
	}

	public void writeObs(Observation obs) {
		currentDataset.writeObs(obs);
	}
	
}
