package io.sdmx.core.sdmx.api.engine.structure;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * After structures have been read, any instances of this interface may mutate or change the structures  
 */
public interface IStructureReadPostProcessEngine {

	/**
	 * Process the beans
	 * @param SdmxBeans the beans to potentially modify
	 */
	void postProcess(SdmxBeans beans);
}
