package io.sdmx.core.sdmx.factory.ref;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Factory to retrieve cross-references for SDMX artifacts that are used in a VTL transformation scheme.
 */
public class VtlTransformationSchemeCrossReferenceRetrievalFactory extends AbstractIVtlSchemeCrossReferenceFactory<ITransformationSchemeBean> {
	private static VtlTransformationSchemeCrossReferenceRetrievalFactory INSTANCE;

	/**
	 * Get instance of VtlTransformationSchemeCrossReferenceRetrievalFactory.
	 * @return instance of VtlTransformationSchemeCrossReferenceRetrievalFactory
	 */
	public static VtlTransformationSchemeCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new VtlTransformationSchemeCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	/**
	 * registers a instance of VtlTransformationSchemeCrossReferenceRetrievalFactory in the FusionBeanStore
	 * @return instance of VtlTransformationSchemeCrossReferenceRetrievalFactory
	 */
	public static VtlTransformationSchemeCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return ITransformationSchemeBean.class;
	}
	
    public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
    	ITransformationSchemeBean vtlSchemeBean = (ITransformationSchemeBean) maintBean;
        Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();
        for (ITransformationBean transformation : vtlSchemeBean.getItems()) {
            List<IURN<?>> referencedArtifacts = transformation.getReferencedArtifacts();
            addReferences(vtlSchemeBean, retrievalManager, referencedArtifacts, returnReferences);
        }
        return returnReferences;
    }

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}
}
