package io.sdmx.core.sdmx.api.factory.structure;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.plugin.IPluggable;
import io.sdmx.core.sdmx.api.engine.structure.IStructureTransactionWriterEngine;
import io.sdmx.core.sdmx.api.manager.structure.IStructureTransactionWriterManager;

/**
 * Used in the plugin framework, allowing the {@link IStructureTransactionWriterManager} to ask if this factory can write
 * in the given format
 */
public interface IStructureTransactionWriterFactory extends IPluggable {
	
	/**
	 * @param format to request for the writer in
	 * @return IStructureTransactionWriterEngine implementation if the format is supported by the factory, null if it is not 
	 */
	IStructureTransactionWriterEngine getStructureWriterEngine(InformationFormat format);
	
}
