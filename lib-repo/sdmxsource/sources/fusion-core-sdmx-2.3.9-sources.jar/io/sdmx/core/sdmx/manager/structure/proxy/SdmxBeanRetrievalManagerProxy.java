package io.sdmx.core.sdmx.manager.structure.proxy;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.manager.structure.EmptySdmxBeanRetrievalManager;

public class SdmxBeanRetrievalManagerProxy implements SdmxBeanRetrievalManager {
	private SdmxBeanRetrievalManager proxy;
	
	public SdmxBeanRetrievalManagerProxy() {
		proxy = EmptySdmxBeanRetrievalManager.INSTANCE;
	}


	public SdmxBeanRetrievalManagerProxy(SdmxBeanRetrievalManager proxy) {
		if(proxy == null) {
			proxy = EmptySdmxBeanRetrievalManager.INSTANCE;
		}
		this.proxy = proxy;
	}

	protected SdmxBeanRetrievalManager getProxy() {
		return proxy;
	}

	public void setProxy(SdmxBeanRetrievalManager proxy) {
		this.proxy = proxy;
	}
	
	
	@Override
	public <T extends IdentifiableBean> T getBean(IURNSingle<T> sRef) {
		SdmxBeanRetrievalManager proxy = getProxy();
		T obj = proxy == null ? null : proxy.getBean(sRef);
		return obj;
	}



	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		SdmxBeanRetrievalManager proxy = getProxy();
		Set<T> returnSet = proxy == null ? Collections.emptySet() : getProxy().getMaintainableBeans(urn);
		return returnSet;
	}
	
//	private CombinedCodelistBean buildInheritedCodelist(MaintainableBean maint) {
//		//TODO what if the query is for a specific Code in the Codelist the proxy would have already 
//		//returned null on the getBean API
//	}

}
