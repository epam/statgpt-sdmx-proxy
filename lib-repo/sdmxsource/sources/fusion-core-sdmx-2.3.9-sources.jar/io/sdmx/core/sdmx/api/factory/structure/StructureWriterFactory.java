package io.sdmx.core.sdmx.api.factory.structure;

import io.sdmx.api.plugin.IPluggable;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.api.sdmx.factory.PriorityFactory;
import io.sdmx.api.sdmx.model.format.StructureFormat;

/**
 * A StructureWriterFactory operates as a plugin to a Manager which can request a StructureWritingEngine, to which the implementation will
 * respond with an appropriate StructureWritingEngine if it is able, otherwise it will return null
 */
public interface StructureWriterFactory extends PriorityFactory, IPluggable {

	/**
	 * Obtains a StructureWritingEngine engine for the given output format
	 * @param outputFormat an implementation of the StructureFormat to describe the output format for the structures (required)
	 * @return null if this factory is not capable of creating a data writer engine in the requested format
	 * @throws IllegalArgumentException if the outputFormat is null
	 */
	StructureWriterEngine getStructureWriterEngine(StructureFormat outputFormat);
	
}
