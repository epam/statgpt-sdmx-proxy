package io.sdmx.core.sdmx.error;

import io.sdmx.api.error.FusionError;

public enum DataValidationErrorCode implements FusionError {

    MISSING_MANDATORY_ATTR                      ("201-051", "Missing mandatory attribute ''{0}''"),
    MISSING_MANDATORY_MEASURE                   ("201-052", "Missing mandatory measure value ''{0}''"),

    MULTIPLE_OBS_VALUES_MISSING                 ("201-101", "Multiple observation values missing from reported time range ''{0}'' to ''{1}''"),
    MISSING_OBS_FOR_TIME_PERIOD                 ("201-102", "Missing Observation for Time Period: ''{0}''"),

    OBS_STATUS_OBS_VALUE_ILLEGAL                ("201-130", "Observation value has been specified but OBS_STATUS enforces that this is not valid. OBS_STATUS: {0}"),
    OBS_STATUS_OBS_VALUE_MISSING                ("201-131", "Observation value has not been specified but OBS_STATUS enforces that a value must be specified. OBS_STATUS: {0}"),
    OBS_PRE_BREAK_VALUE_MISSING                 ("201-132", "OBS_STATUS is set to 'TIME_SERIES_BREAK' which mandates that a 'PRE_BREAK' value should be specified, but it is missing"),
    OBS_PRE_BREAK_VALUE_PRESENT                 ("201-133", "OBS_STATUS is not set to 'TIME_SERIES_BREAK' but a 'PRE_BREAK' value is present. This is not allowed. OBS_STATUS: {0}"),

    FAILED_CALCULATION_NO_OUTPUT                ("201-160", "Failed calculation ''{0}'' for Dimension ''{1}''. Output could not be calculated."),
    FAILED_CALCULATION_NO_OUTPUT_DUE_TO_ERROR   ("201-161", "Failed calculation ''{0}'' for Dimension ''{1}''. Output could not be calculated due to error ''{2}''. Inputs to the calculation are ''{3}''."),
    FAILED_CALCULATION_WITH_CALCULATION_RESULT  ("201-162", "Failed calculation ''{0}'' for Dimension ''{1}''. Calculation result {2}. Inputs to the calculation are ''{3}''."),
    FAILED_CALCULATION_WITH_REPORTED_VALUE      ("201-163", "Failed calculation ''{0}'' for Dimension ''{1}''. Reported Value {2}. Inputs to the calculation are ''{3}''."),

    DUPLICATE_VALUE_REPORTED                    ("201-230", "Duplicate value reported {0}. Reported values are: ''{1}'' and ''{2}''"),
    CONTRADICTORY_VALUE_REPORTED                ("201-231", "Contradictory ''{0}'' value reported. Both ''{1}'' and ''{2}'' have been reported in the same dataset for series ''{3}''");

    private String errorCode;
    private String errorMessage;

    private DataValidationErrorCode(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getErrorMessage() {
        return errorMessage;
    }

}
