package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.im.beans.metadatastructure.MetadataflowBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link MetadataflowBeanDeferred}
 */
public class DeferredMetadataflowReaderEngine extends AbstractDeferredStructureReaderEngine<MetadataFlowBean> {
    private static DeferredMetadataflowReaderEngine INSTANCE;
    
    private DeferredMetadataflowReaderEngine() {
        super(MetadataFlowBean.class);
    }
    
    public static DeferredMetadataflowReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredMetadataflowReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<MetadataFlowBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new MetadataflowBeanDeferred(bean, loader);
    }

}
