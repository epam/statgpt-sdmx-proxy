package io.sdmx.core.sdmx.model;

/**
 * States how the MVStore should treat duplicate observations 
 */
public enum MVDuplicateBehaviour {
	USE_FIRST_VALUE("useFirst"),
	USE_LAST_VALUE("useLast"),
	PRESERVE_DUPLICATES("preserve");

    private String asString;
	
    private MVDuplicateBehaviour(String val) {
		this.asString = val;
	}

	private String getPropertyName() {
		return asString;
	}
    
    public static MVDuplicateBehaviour fromString(String val) {
		for(MVDuplicateBehaviour behaviour : MVDuplicateBehaviour.values()) {
			if(behaviour.getPropertyName().equalsIgnoreCase(val)) {
				return behaviour;
			}
		}
		throw new IllegalArgumentException("Could not resolve value '"+val+"' to an MVDUplicateBehaviour");
    }
	
}
