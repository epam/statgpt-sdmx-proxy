package io.sdmx.core.sdmx.manager.structure;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.ApplicationStarter;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_CROSS_REFERENCES;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_EXTERNAL_SETTING;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.engine.structure.IStructureReadPostProcessEngine;
import io.sdmx.core.sdmx.api.factory.structure.StructureReaderFactory;
import io.sdmx.core.sdmx.api.manager.structure.ExternalReferenceManager;
import io.sdmx.core.sdmx.api.manager.structure.IStructureParsePostValidationEngine;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.api.model.parse.IStructureParseConfiguration;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.engine.structure.CrossReferenceResolverEngineImpl;
import io.sdmx.core.sdmx.model.ref.StructureParseConfiguration;
import io.sdmx.im.beans.builder.V3BeansBuilder;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.comparator.PriorityFactoryComparator;

public class StructureReaderManagerImpl implements StructureReaderManager, IFusionSingleton {
    private static final Logger LOG = LoggerFactory.getLogger(StructureReaderManagerImpl.class);

	private ExternalReferenceManager externalReferenceManager;
	private CrossReferenceResolverEngine resolverEngine;
	
	private SdmxBeanRetrievalManager beanRetrievalManager; //Used for post validation, if required
	
	private Map<SDMX_STRUCTURE_TYPE, IStructureParsePostValidationEngine> externalValidators;
	
	private Set<StructureReaderFactory> factories = null;
	
	//the default bean builder will upgrade to the SDMX v3 model
	private IBeansBuilder DEFAULT_BEAN_BUILDER = V3BeansBuilder.DEFAULT_INSTANCE;
	
	/**
	 * Default constructor
	 */
	public StructureReaderManagerImpl() {}
	
	public StructureReaderManagerImpl(IBeansBuilder defaultBeanBuilder) {
	    if(defaultBeanBuilder != null) {
	        DEFAULT_BEAN_BUILDER = defaultBeanBuilder;
	    }
	}

	/**
	 * @param externalReferenceManager optional - for resolving external references
	 * @param resolverEngine - optional - to support resolution settings if required
	 * @param beanRetrievalManager - optional - to support post parse validation
	 */
	public StructureReaderManagerImpl(ExternalReferenceManager externalReferenceManager, CrossReferenceResolverEngine resolverEngine, SdmxBeanRetrievalManager beanRetrievalManager) {
		this.externalReferenceManager = externalReferenceManager;
		this.resolverEngine = resolverEngine;
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public void destroyInstance() {
	    factories = null;
	}

	@Override
	public SdmxBeans parseStructures(ReadableDataLocation dataLocation) throws SdmxException, CrossReferenceException {
		return parseStructures(dataLocation, null);
	}

	@Override
	public SdmxBeans parseStructures(ReadableDataLocation rdl, IStructureParseConfiguration config) throws SdmxSyntaxException, CrossReferenceException, SdmxSemmanticException {
		if(LOG.isDebugEnabled()) {
			LOG.debug("Parse structures");
		}
		try {
			if(config == null) {
				config = StructureParseConfiguration.DEFAULT_INSTANCE;
			}
			SdmxBeans beans = getSdmxBeans(rdl, config);
			beans = buildReturnBeans(beans, config.getResolutionSettings(), config.getRetrievalManager());
			DATASET_ACTION action = beans.getAction() == null ? DATASET_ACTION.APPEND : beans.getAction();
			if(config.performPostProcessValidation(action)) {
				SdmxBeanRetrievalManager baseBRM = config.getRetrievalManager() == null ? this.beanRetrievalManager : config.getRetrievalManager();
				SdmxBeanRetrievalManager submittedBeans = new InMemoryRetrievalManager(beans);
				SdmxBeanRetrievalManager retrievalManagerWrapper = (baseBRM == null || beans.getAction() == DATASET_ACTION.FULL_REPLACE) ? submittedBeans : new MultipleBeanRetrievalManager(submittedBeans, baseBRM);
				for(MaintainableBean maint : beans.getAllMaintainables()) {
					performValidation(maint, retrievalManagerWrapper);
				}
			}
			return beans;
		} finally {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Parse structures Complete");
			}
		}
	}
	
	/**
	 * Offers validation to any external validators
	 * @param maint to validate
	 * @param retrievalManager combining the underlying store with the beans in the submission
	 */
	private void performValidation(MaintainableBean maint, SdmxBeanRetrievalManager retrievalManager) {
		if(externalValidators == null) {
			Map<SDMX_STRUCTURE_TYPE, IStructureParsePostValidationEngine> externalValidators = new HashMap<>();
			for(IStructureParsePostValidationEngine engine : FusionBeanStore.getBeans(IStructureParsePostValidationEngine.class)) {
				externalValidators.put(engine.getStructureType(), engine);
			}
			this.externalValidators = externalValidators;
		}
		IStructureParsePostValidationEngine engine = externalValidators.get(maint.getStructureType());
		if(engine != null) {
			LOG.debug("Post validation: "+maint.getUrn());
			engine.validateMaintainble(maint, retrievalManager);
		}
	}

	private SdmxBeans buildReturnBeans(SdmxBeans beans, ResolutionSettings settings, SdmxBeanRetrievalManager retrievalManager) {
		if(settings == null) {
			settings =  new ResolutionSettings(RESOLVE_EXTERNAL_SETTING.DO_NOT_RESOLVE, RESOLVE_CROSS_REFERENCES.DO_NOT_RESOLVE);
		}
		if(settings.isResolveExternalReferences() && externalReferenceManager != null) {
			externalReferenceManager.resolveExternalReferences(beans, settings.isSubstituteExternal(), settings.isLenient());
		}
		if(settings.isResolveCrossReferences()) {
			if(resolverEngine == null) {
				resolverEngine = new CrossReferenceResolverEngineImpl();
			}
			IReferenceResolution resolution = resolverEngine.resolveReferences(beans, settings.isResolveAgencyReferences(), false, settings.getResolutionDepth(), retrievalManager);
			if(resolution.hasMissingReferences()) {
				for(IdentifiableBean missingRefFrom : resolution.getMissingReferences()) {
					for(ICrossReferenceBean<?> missingRefTo : resolution.getMissingReferences(missingRefFrom)) {
						throw new CrossReferenceException(missingRefTo);
					}
				}
			}
			beans.merge(resolution.getAllBeans(RESOLUTION_TYPE.BOTH));
		}
		if(LOG.isDebugEnabled()) {
			LOG.debug("Post-Process Beans");
		}
		
		try {
			FusionBeanStore.getBeans(IStructureReadPostProcessEngine.class).forEach(ppe -> ppe.postProcess(beans));
		} catch(Throwable th) {
			LOG.error("Error in post-processor: ", th);
			throw new RuntimeException(th);
		}
		
		return beans;
	}

	private SdmxBeans getSdmxBeans(ReadableDataLocation sourceData, IStructureParseConfiguration config) {
	    if (ZipUtil.isAZip(sourceData)) {
	        List<ReadableDataLocation> items = ZipUtil.unzipFiles(sourceData);
	        SdmxBeans retBeans = new SdmxBeansImpl();
	        for (ReadableDataLocation anRdl : items) {
	        	try {
	        		SdmxBeans beans = obtainBeansFromFactories(anRdl, config);
	        		Map<String, MaintainableBean> maintMap = SdmxCollectionUtil.maintCollectionToMap(retBeans.getAllMaintainables());
	        		if(maintMap.isEmpty()) {
	        		    retBeans.merge(beans);
	        		} else {
	        		    beans.getAllMaintainables().forEach(m-> {
	        		        MaintainableBean existing = maintMap.get(m.getUrn());
	        		        if(existing != null && !existing.deepEquals(m, true)) {
	        		            throw new SdmxSemmanticException("Duplicate and contradictory structure: "+existing.getUrn());
	        		        }
	        		        retBeans.addIdentifiable(m);
	        		    });
	        		}
	        		
	        	} finally {
	        		anRdl.close();
	        	}
            }
	        return retBeans;
	    }
	    return obtainBeansFromFactories(sourceData, config);
	}

    private SdmxBeans obtainBeansFromFactories(ReadableDataLocation sourceData, IStructureParseConfiguration config) {
        IBeansBuilder beanBuilder = config != null ? config.getBeanBuilder() : null;
        if(beanBuilder == null) {
            //If there is no custom bean builder, use the default behaviour of calling the build method on the interface
            beanBuilder = DEFAULT_BEAN_BUILDER;
        }
        for(StructureReaderFactory currentFactory : getStructureReaderFactory()) {
            SdmxBeans beans = currentFactory.getSdmxBeans(sourceData, beanBuilder);
            if(beans != null) {
                if(LOG.isDebugEnabled()) {
        			LOG.debug("Build Beans Complete");
        		}
                return beans;
            }
        }
        throw new UnrecognisedFormatException(sourceData.getInputStream());
    }

	private Collection<StructureReaderFactory> getStructureReaderFactory()  {
		if(this.factories != null) {
			return this.factories;
		}
		Set<StructureReaderFactory> localFactories = new TreeSet<>(PriorityFactoryComparator.INSTANCE);
		synchronized(this) {
			Collection<StructureReaderFactory> allBeans = FusionBeanStore.getBeans(StructureReaderFactory.class);
			if(allBeans != null) {
				for (StructureReaderFactory structureReaderFactory : allBeans) {
					localFactories.add(structureReaderFactory);
				}
			}
		}
		ApplicationStarter applicationStarter = SingletonStore.getSingleton(ApplicationStarter.class, false);
		if(applicationStarter == null || applicationStarter.isStarted()) {
			this.factories = localFactories;
		}
		return localFactories;
	}
}
