package io.sdmx.core.sdmx.engine.data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.constants.DIMENSION_AT_OBSERVATION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.error.DataFormatErrorImpl;
import io.sdmx.core.sdmx.error.DataReadException;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;


public abstract class AbstractDataReaderEngine implements DataReaderEngine, Serializable {
	private static final long serialVersionUID = 3424676029992787805L;

	private int datasetIndex = -1;
	private int keyableIndex = -1;
	private int obsIndex = -1;

	protected DataReaderExceptionHandler exceptionHandler;

	//A set of exceptions that have already been handled by the exception handler
	protected Set<String> handledExceptions = new HashSet<>();

	protected boolean hasNext=true;    //End of File
	protected boolean hasNextObs=true; //End of Obs for current Key
	protected boolean hasNextDataset=true; //End of Dataset

	protected DatasetHeaderBean datasetHeaderBean;
	protected DataStructureBean currentDsd;
	protected DataflowBean currentDataflow;
	protected ProvisionAgreementBean currentProvisionAgreement;

	protected String measureDimension;
	protected boolean hasTimeDimension;

	protected ProvisionAgreementBean defaultProvisionAgreement;
	protected DataflowBean defaultDataflow;
	protected DataStructureBean defaultDsd;
	protected SdmxBeanRetrievalManager beanRetrieval;
	protected Observation currentObs;
	protected Keyable currentKey;
	protected IDatasetAttributes currentDatasetAttributes;

	protected HeaderBean headerBean;

	protected DATASET_POSITION datasetPosition;
	protected LAST_CALL lastCall;

	protected enum LAST_CALL {
		HAS_NEXT_DATASET,
		HAS_NEXT_OBS,
		HAS_NEXT_SERIES,
		NEXT_OBS,
		NEXT_SERIES;
	}

	private Boolean isTimeSeries = null;
	/**
	 * Empty constructor for implementations that can supply their own DSD at runtime
	 */
	public AbstractDataReaderEngine() {}

	/**
	 * Creates a reader engine based on: the data location; the location of available data structures that
	 * can be used to retrieve DSDs; and the default DSD to use.
	 * Either a defaultDsd or a beanRetrieval argument must be provided.
	 * @param dataLocation the location of the data
	 * @param beanRetrieval provides the ability to retrieve DSDs for the Datasets this reader engine is reading.
	 * This can be null if there is only one relevant DSD, in which case the defaultDsd should be provided
	 * @param defaultDsd the default DSD to use if the beanRetrieval parameter is null, or if the beanRetrieval does not return the DSD for the given dataset
	 * @param defaultDataflow
	 * @param defaultProvisionAgreement
	 * @param exceptionHandler Used to handle any exceptions that are thrown whilst reading the data file.
	 */
	public AbstractDataReaderEngine(SdmxBeanRetrievalManager beanRetrieval,
									DataStructureBean defaultDsd,
									DataflowBean defaultDataflow,
									ProvisionAgreementBean defaultProvisionAgreement,
									DataReaderExceptionHandler exceptionHandler) {
		this.beanRetrieval = beanRetrieval;
		this.defaultDsd = defaultDsd;
		this.defaultDataflow = defaultDataflow;
		this.defaultProvisionAgreement = defaultProvisionAgreement;
		this.exceptionHandler = exceptionHandler;
		if(defaultDsd == null && beanRetrieval == null) {
			throw new IllegalArgumentException("DataReaderEngine expects a DataStructureBean or SdmxBeanRetrievalManager to be able to interpret the dataset");
		}
		if(defaultDataflow != null && defaultDsd != null && !defaultDataflow.getDataStructureRef().isMatch(defaultDsd)) {
			throw new IllegalArgumentException("Can not create DataReaderEngine since the Default Dataflow '"+defaultDataflow+"' does not reference Default Data Structure '"+defaultDsd+"' ");
		}
		if(defaultProvisionAgreement != null && defaultDataflow != null && !defaultProvisionAgreement.getStructureUseage().isMatch(defaultDataflow)) {
			throw new IllegalArgumentException("Can not create DataReaderEngine since the Default Provision '"+defaultProvisionAgreement+"' does not reference Default DataFlow '"+defaultDataflow+"' ");
		}
	}

	protected void handleException(String errorMessage, boolean recoverable, SEVERITY severity, TYPE type) {
		handleException(errorMessage, recoverable, severity, type, ERROR_POSITION.DATASET);
	}

	protected void handleException(String errorMessage, boolean recoverable, SEVERITY severity, TYPE type, ERROR_POSITION errorPosition) {
		if(exceptionHandler == null) {
			if(!recoverable) {
				throw new DataReadException(errorMessage, datasetIndex, keyableIndex, obsIndex,  recoverable, severity, type);
			}
		} else {
			String key = this.datasetIndex+":"+this.keyableIndex+":"+this.obsIndex;
			if(!handledExceptions.contains(key)) {
				boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
				SdmxException.disableExceptionTrace(true);
				try {
					//String prefix = "Error reading dataset '" + ( (this.datasetIndex < 1) ? 1 : this.datasetIndex ) +"': ";
					String prefix = "";
					exceptionHandler.handleException(new DataFormatErrorImpl(prefix + errorMessage, type, errorPosition));
				} finally {
					SdmxException.disableExceptionTrace(wasDisabled);
				}
				if(!recoverable) {
					throw new DataReadException(errorMessage, datasetIndex, keyableIndex, obsIndex,  recoverable, severity, type);
				}
			}
		}
	}

	@Override
	public HeaderBean getHeader() {
		return headerBean;
	}

	@Override
	public int getDatasetPosition() {
		return datasetIndex;
	}

	@Override
	public DatasetHeaderBean getCurrentDatasetHeaderBean() {
		return datasetHeaderBean;
	}

	@Override
	public DataflowBean getDataFlow() {
		return currentDataflow;
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreement() {
		return currentProvisionAgreement;
	}

	@Override
	public boolean moveNextDataset() {
		if(lastCall != LAST_CALL.HAS_NEXT_DATASET && datasetPosition != DATASET_POSITION.DATASET)  {
			//If the reader has already read ahead to discover there was another dataset, then do not nullify the dsd, dataflow, and headers, as this would have been read from the new dataset
			currentDsd = null;
			currentDataflow = null;
			currentProvisionAgreement = null;
			datasetHeaderBean = null;
		}
		if(datasetPosition == DATASET_POSITION.DATASET && currentDsd == null) {
			determineCurrentDataStructure();
		}
		currentKey = null;
		hasNextObs = true;
		isTimeSeries = null;
		obsIndex = -1;
		keyableIndex = -1;

		boolean moveSuccessful = moveNextDatasetInternal();
		if(moveSuccessful) {
			datasetIndex++;
			if(currentDsd == null) {
				determineCurrentDataStructure();
			}
			this.currentDatasetAttributes = lazyLoadDatasetAttributes();
		}
		return moveSuccessful;
	}

	@Override
	public DataStructureBean getDataStructure() {
		return currentDsd;
	}


	/**
	 * Sets the current Provision, which in turn sets the current DataFlow & DSD
	 * @param provisionAgreementBean
	 */
	private void setCurrentProvision(ProvisionAgreementBean provisionAgreementBean) {
		this.currentProvisionAgreement = provisionAgreementBean;

		//If the current Dataset header does not reference a Provision then amend it
		if(getCurrentDatasetHeaderBean() == null) {
			datasetHeaderBean = new DatasetHeaderBeanImpl(obtainDataSetId(provisionAgreementBean), DATASET_ACTION.INFORMATION,  new DatasetStructureReferenceBeanImpl(currentProvisionAgreement.getURN()));
		} else if(getCurrentDatasetHeaderBean().getDataStructureReference() == null) {
			DatasetStructureReferenceBean dsRefBean = new DatasetStructureReferenceBeanImpl(currentProvisionAgreement.getURN());
			datasetHeaderBean = getCurrentDatasetHeaderBean().modifyDataStructureReference(dsRefBean);
		}
		if(currentDataflow == null) {
			if(defaultDataflow != null) {
				setCurrentDataflow(defaultDataflow);
			} else if(beanRetrieval != null) {
				setCurrentDataflow(beanRetrieval.getBean(currentProvisionAgreement.getStructureUseage().getReference()));
			}
		}
		ammendDimenisonAtObservation();
	}


	/**
	 * Sets the current DataFlow, which in turn sets the current data structure
	 * @param currentDataflow
	 */
	private void setCurrentDataflow(DataflowBean currentDataflow) {
		//Do not set the current flow if it does not reference the current DSD
		if(getDataStructure() != null && !currentDataflow.getDataStructureRef().isMatch(getDataStructure())) {
			return;
		}

		this.currentDataflow = currentDataflow;
		//If the current dataset header does not reference a Dataflow then amend it
		if(getCurrentDatasetHeaderBean() == null) {
			datasetHeaderBean = new DatasetHeaderBeanImpl(obtainDataSetId(currentDataflow), DATASET_ACTION.INFORMATION,  new DatasetStructureReferenceBeanImpl(currentDataflow.getURN()));
		} else if(getCurrentDatasetHeaderBean().getDataStructureReference() == null) {
			DatasetStructureReferenceBean dsRefBean = new DatasetStructureReferenceBeanImpl(currentDataflow.getURN());
			datasetHeaderBean = getCurrentDatasetHeaderBean().modifyDataStructureReference(dsRefBean);
		}
		if(getDataStructure() == null) {
			IURNSingle<DataStructureBean> dsdUrn = currentDataflow.getDataStructureRef().getReference();
			if(defaultDsd != null && dsdUrn.isMatch(defaultDsd)) {
				setCurrentDsd(defaultDsd);
			} else if(beanRetrieval != null) {
				setCurrentDsd(beanRetrieval.getBean(dsdUrn));
			}
		}
		ammendDimenisonAtObservation();
	}

	/**
	 * Allows for sub-classes to dictate their own DataSetId if required, but by default returns a random ID
	 * @return a string
	 */
	protected String obtainDataSetId(MaintainableBean aMaint) {
		return MaintainableUtil.generateRandomId();
	}

	protected void setCurrentDsd(DataStructureBean currentDsd) {
		this.currentDsd = currentDsd;

		if(datasetHeaderBean == null) {
			datasetHeaderBean = new DatasetHeaderBeanImpl(UUID.randomUUID().toString(), DATASET_ACTION.INFORMATION, new DatasetStructureReferenceBeanImpl(currentDsd.getURN()));
		} else if(getCurrentDatasetHeaderBean().getDataStructureReference() == null) {
			//If the current dataset header does not reference a DSD then amend it
			DatasetStructureReferenceBean dsRefBean = new DatasetStructureReferenceBeanImpl(currentDsd.getURN());
			datasetHeaderBean = getCurrentDatasetHeaderBean().modifyDataStructureReference(dsRefBean);
		}
		if(this.currentDsd != null) {
			List<DimensionBean> measureDim = this.currentDsd.getDimensions(SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
			if(ObjectUtil.validCollection(measureDim)) {
				this.measureDimension = measureDim.get(0).getId();
			}
			this.hasTimeDimension = this.currentDsd.getTimeDimension() != null;
		}
		ammendDimenisonAtObservation();
	}
	
	/**
	 * Ensures that the dataset header has AllDimensions as the Dimension At Observation if there is no Time Dimension on 
	 * the DSD
	 */
	private void ammendDimenisonAtObservation() {
		if(this.hasTimeDimension == false && datasetHeaderBean != null && this.currentDsd != null) {
			DatasetStructureReferenceBean dsRefBean = getCurrentDatasetHeaderBean().getDataStructureReference();
			if(dsRefBean.getDimensionAtObservation().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				dsRefBean = new DatasetStructureReferenceBeanImpl(dsRefBean.getId(), 
						dsRefBean.getStructureReference(), 
						dsRefBean.getServiceURL(), 
						dsRefBean.getStructureURL(), 
						DatasetStructureReferenceBean.ALL_DIMENSIONS);	
				datasetHeaderBean = getCurrentDatasetHeaderBean().modifyDataStructureReference(dsRefBean);
			}
		}
	}

	protected void setCurrentStructure(IURNSingle<? extends IDSDRelatedBean> sRef) {
		MaintainableBean maint = null;
		if(beanRetrieval == null) {
			MaintainableBean defaultMaint = null;
			switch(sRef.getSdmxStructure()) {
				case PROVISION_AGREEMENT :
					defaultMaint = defaultProvisionAgreement;
					break;
				case DATAFLOW :
					defaultMaint = defaultDataflow;
					break;
				case DSD :
					defaultMaint = defaultDsd;
					break;
			}
			if(defaultMaint != null && defaultMaint.getUrn().equals(sRef.getURN())) {
				maint = defaultMaint;
			}
		} else {
			maint = beanRetrieval.getBean(sRef);
		}
		if(maint == null) {
			return;
		}
		switch(maint.getStructureType()) {
			case DSD : setCurrentDsd((DataStructureBean)maint);
				break;
			case DATAFLOW : setCurrentDataflow((DataflowBean)maint);
				break;
			case PROVISION_AGREEMENT : setCurrentProvision((ProvisionAgreementBean)maint);
				break;
		}
	}


	/**
	 * Sets the currentDsd variable based on the data header for the current dataset that is being read
	 */
	private void determineCurrentDataStructure() {
		//1. Set the current DSD to null before trying to resolve it
		currentDsd = null;
		currentDataflow = null;
		currentProvisionAgreement = null;

		DatasetStructureReferenceBean dsStructRef = null;
		if(getCurrentDatasetHeaderBean() != null) {
			dsStructRef = getCurrentDatasetHeaderBean().getDataStructureReference();
			if(dsStructRef == null && getCurrentDatasetHeaderBean() != null && getHeader().getStructures().size() == 1) {
				dsStructRef = getHeader().getStructures().get(0);
			}
		}

		if(dsStructRef == null && headerBean != null) {
			if(ObjectUtil.validCollection(headerBean.getStructures())) {
				dsStructRef = headerBean.getStructures().get(0);
			}
		}
		IURNSingle<? extends IDSDRelatedBean> sRef = null;
		if(dsStructRef != null && dsStructRef.getStructureReference() != null) {
			sRef = dsStructRef.getStructureReference();
			setCurrentStructure(sRef);

			if(getDataStructure() == null) {
				MaintainableBean toCheck = null;
				switch(sRef.getSdmxStructure()) {
					case DSD :
						toCheck = defaultDsd;
						break;
					case DATAFLOW :
						toCheck = defaultDataflow;
						break;
					case PROVISION_AGREEMENT :
						toCheck = defaultProvisionAgreement;
						break;
					default : throw new SdmxNotImplementedException("Can not read Dataset which references a structure of type: " + sRef.getSdmxStructure());
				}
//				if(toCheck != null && !sRef.hasMatch(toCheck)) {
//					throw new SdmxSemmanticException("Can not read Dataset with " + toCheck.getStructureType().getType() + " '" +
//				      toCheck.getUrn().split("=")[1] + "'.  This does not match the following structure specified in the dataset header: '" + sRef + "'");
//				}
			}

		}
		/**
		 * Apply and default structure
		 */
		applyDefaults();
		if(getDataStructure() == null) {
			throw new DataSetStructureReferenceException(sRef);
		}
	}

	private void applyDefaults() {
		if(currentProvisionAgreement == null && defaultProvisionAgreement != null) {
			setCurrentProvision(defaultProvisionAgreement);
		}
		if(currentDataflow == null && defaultDataflow != null) {
			if(currentProvisionAgreement == null ||
					currentProvisionAgreement.getStructureUseage().isMatch(defaultDataflow)) {
				setCurrentDataflow(defaultDataflow);
			}
		}
		if(getDataStructure() == null && defaultDsd != null) {
			if(currentDataflow == null ||
					currentDataflow.getDataStructureRef().isMatch(defaultDsd)) {
				setCurrentDsd(defaultDsd);
			}
		}
	}

	@Override
	public final boolean moveNextKeyable() {
		//If the dataset has not been read, then read it!
		if(datasetIndex == -1) {
			if(!moveNextDataset()) {
				return false;
			}
		}
		currentKey = null; //Set the current key to null, this is so when the user reads the observation it can generate it on demand

		//If there is no more information left at all, then we return false
		if(!hasNext) {
			return false;
		}
		hasNextObs = true;
		obsIndex = -1;
		keyableIndex++;

		boolean bool =  moveNextKeyableInternal();
		if(!bool) {
			keyableIndex--;
		}
		return bool;
	}

	@Override
	public final boolean moveNextObservation() {
		currentObs = null;  //Set the current observation to null, this is so when the user reads the observation it can generate it on demand

		//If we are at the end of the file, or the observations for the key, then return false, there is no point in processing anything
		if(!hasNext && !hasNextObs) {
			return false;
		}
		obsIndex++;

		if(currentKey == null) {
			getCurrentKey();
		}
		if(currentKey == null) {
			return false;  //if there is no key, then do not try to move to the next obs
		}
		if (!currentKey.isSeries()) {
			return false;
		}
		hasNextObs = moveNextObservationInternal();
		if(!hasNextObs) {
			obsIndex--;
		}
		return hasNextObs;
	}

	@Override
	public final Observation getCurrentObservation() {
		if(currentObs != null) {
			return currentObs;
		}
		if(obsIndex < 0) {
			return null;
		}
		currentObs = lazyLoadObservation();
		return currentObs;
	}

	@Override
	public final Keyable getCurrentKey() {
		if(currentKey != null) {
			return currentKey;
		}
		if(keyableIndex < 0) {
			return null;
		}
		currentKey = lazyLoadKey();
		return currentKey;
	}

	
	@Override
	/**
	 * Dataset Attributes are loaded on moveNextDataset
	 */
	public final IDatasetAttributes getDatasetAttributes() {
		if(currentDatasetAttributes == null) {
			return DatasetAttributes.EMPTY_ATTRIBUTES;
		}
		return currentDatasetAttributes;
	}
	

	abstract protected Observation lazyLoadObservation();

	abstract protected Keyable lazyLoadKey();

	/**
	 * @return
	 */
	abstract protected IDatasetAttributes lazyLoadDatasetAttributes();
	
	/**
	 * Moves the reader to the next dataset, sets the datasetHeaderBean based on the dataset attributes
	 * @return
	 */
	abstract protected boolean moveNextDatasetInternal();

	abstract protected boolean moveNextKeyableInternal();

	abstract protected boolean moveNextObservationInternal();


	@Override
	public int getKeyablePosition() {
		return keyableIndex;
	}

	@Override
	public int getObsPosition() {
		return obsIndex;
	}

	public boolean isTimeSeries() {
		//Performance enhancement
		if(isTimeSeries != null) {
			return isTimeSeries;
		}
		if(currentDsd.getTimeDimension() == null) {
			isTimeSeries = false;
		} else {
			isTimeSeries = getCrossSectionConcept().equals(DIMENSION_AT_OBSERVATION.TIME.getVal()) || getCrossSectionConcept().equals(DIMENSION_AT_OBSERVATION.ALL.getVal());
		}
		return isTimeSeries;
	}

	public String getCrossSectionConcept() {
		if(getCurrentDatasetHeaderBean() == null) {
			return DimensionBean.TIME_DIMENSION_FIXED_ID;
		}
		return getCurrentDatasetHeaderBean().getDataStructureReference().getDimensionAtObservation();
	}

	@Override
	public void reset() {
		hasNext = true;
		keyableIndex = -1;
		datasetIndex = -1;
		obsIndex = -1;
		currentObs = null;
		currentKey = null;
		datasetPosition = null;
	}
}
