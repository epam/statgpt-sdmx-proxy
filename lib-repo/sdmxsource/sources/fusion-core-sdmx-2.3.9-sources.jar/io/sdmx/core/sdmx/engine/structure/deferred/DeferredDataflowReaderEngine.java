package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.datastructure.DataflowBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link DataflowBeanDeferred}
 */
public class DeferredDataflowReaderEngine extends AbstractDeferredStructureReaderEngine<DataflowBean> {
    private static DeferredDataflowReaderEngine INSTANCE;
    
    private DeferredDataflowReaderEngine() {
        super(DataflowBean.class);
    }
    
    public static DeferredDataflowReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredDataflowReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<DataflowBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new DataflowBeanDeferred(bean, loader);
    }

}
