package io.sdmx.core.sdmx.manager.structure;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansRetreivalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * The local retrieval manager provides interfaces to retrieve structures off an in memory storage of the SdmxBeans.
 * <p/>
 * This class is able to updated its cache as if it were a local storage with the interface methods provided by the StructurePersistenceManager.
 */
public class InMemoryRetrievalManager implements SdmxBeanRetrievalManager,
											     SdmxBeansRetreivalManager,
											     StructurePersistenceManager,
											     Listener<ReadableDataLocation> {
	private static final Logger LOG = LoggerFactory.getLogger(InMemoryRetrievalManager.class);
	
	protected SdmxBeans beans = new SdmxBeansImpl();

	private SdmxBeans readOnlyBeans;  //only required when a call is made to get all SdmxBeans

	private StructureReaderManager structureReaderManager = SingletonStore.getSingleton(StructureReaderManager.class, false);
	
	/**
	 * Default constructor
	 */
	public InMemoryRetrievalManager() {	}
	
	/**
	 * Create an in memory retrieval manager using a URI as a seed, the URI may reference a file (local or external on the web) or be a SDMX REST query
	 * @param seed
	 */
	public InMemoryRetrievalManager(ReadableDataLocation seed, StructureReaderManager structureReaderManager) {
		this.structureReaderManager = structureReaderManager;
		invoke(seed);
	}
	
	public InMemoryRetrievalManager(SdmxBeans beans) {
		this.beans = beans;
		if(this.beans == null) {
			this.beans = new SdmxBeansImpl();
		}
	}
	 
	@Override
	public void invoke(ReadableDataLocation seed) {
		beans = new SdmxBeansImpl();
		if(seed != null) {
			
			if(structureReaderManager == null) {
				structureReaderManager = new StructureReaderManagerImpl();
			}
			try {
				saveStructures(structureReaderManager.parseStructures(seed));
			} finally {
				seed.close();
			}
		}
	}

	
	@Override
	public void saveStructure(MaintainableBean maintainable) {
		readOnlyBeans = null;
		LOG.info("saveStructure:" + maintainable.getUrn());
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		saveStructures(beans);
	}

	@Override
	public void deleteStructure(MaintainableBean maintainable) {
		readOnlyBeans = null;
		LOG.info("deleteStructure:" + maintainable.getUrn());
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		deleteStructures(beans);
	}

	@Override
	public void saveStructures(SdmxBeans beans, IStructureValidationErrorHandler errorHandler) {
		readOnlyBeans = null;
		if(LOG.isDebugEnabled()) {
			LOG.debug("saveStructures:" + beans.toString());
		}
		this.beans.merge(beans);
	}

	@Override
	public void deleteStructures(SdmxBeans beans) {
		readOnlyBeans = null;
		if(LOG.isDebugEnabled()) {
			LOG.debug("deleteStructures:" + beans.toString());
		}
		for(MaintainableBean currentMaint : beans.getAllMaintainables()) {
			this.beans.removeMaintainable(currentMaint);
		}
	}
	
	@Override
	public SdmxBeans getSdmxBeans() {
		return getBeans();
	}

	/**
	 * Returns a read only copy of the beans for this retrieval manager
	 * @return
	 * @deprecated use getSdmxBeans
	 */
	@Deprecated
	public SdmxBeans getBeans() {
		if(readOnlyBeans == null) {
			readOnlyBeans = beans.getReadOnlyCopy();
		}
		return readOnlyBeans;
	}
	
	@Override
	public <T extends IdentifiableBean> T getBean(IURNSingle<T> sRef) {
		return beans.getBean(sRef);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		return beans.getMaintainableBeans(urn);
	}

}