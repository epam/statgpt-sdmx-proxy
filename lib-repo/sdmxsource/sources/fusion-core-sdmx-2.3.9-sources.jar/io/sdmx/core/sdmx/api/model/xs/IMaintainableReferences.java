package io.sdmx.core.sdmx.api.model.xs;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;

/**
 * References resolved for a Single Maintainable
 */
public interface IMaintainableReferences {

	/**
	 * @return not null, the {@link MaintainableBean} that the referneces are for
	 */
	MaintainableBean getMaintainable();
	
	/**
	 * @return the cross references for the maintainable, this may include both direct and indirect references
	 */
	Set<ICrossReferenceBean<?>> getCrossReferences();
	
	/**
	 * @return indirect references that could not be resolved due to a missing structure, i.e. a reference from a Constraint to a Component FREQ would be deemed unresolveable if the DSD does not contain a Component with ID FREQ
	 */
	Set<IURNAbsolute<?>> getUnresolvableReferences();
}
