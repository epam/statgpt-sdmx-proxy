package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.im.beans.metadatastructure.MetadataProvisionBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link MetadataProvisionBeanDeferred}
 */
public class DeferredMetadataProvisionReaderEngine extends AbstractDeferredStructureReaderEngine<MetadataProvisionAgreementBean> {
    private static DeferredMetadataProvisionReaderEngine INSTANCE;
    
    private DeferredMetadataProvisionReaderEngine() {
        super(MetadataProvisionAgreementBean.class);
    }
    
    public static DeferredMetadataProvisionReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredMetadataProvisionReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<MetadataProvisionAgreementBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProvisionBeanDeferred(bean, loader);
    }

}
