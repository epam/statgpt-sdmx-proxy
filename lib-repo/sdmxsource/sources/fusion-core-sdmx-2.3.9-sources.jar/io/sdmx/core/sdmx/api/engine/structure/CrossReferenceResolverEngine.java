package io.sdmx.core.sdmx.api.engine.structure;

import java.util.Set;

import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;


/**
 * The purpose of the CrossReferenceResolverEngine is to resolve cross references for beans, either MaintainableBeans,
 * beans within a SdmxBeans container, ProvisionBeans, and RegistrationBeans.
 */
public interface CrossReferenceResolverEngine {
	
	/**
	 * Removes Maintainable beans from the beans container that reference an Identifiable which is not included in the container or resolveable from the 
	 * identifiableRetrievalManager if this is provided
	 * 
	 * @param beans beans to check and remove maintainables from 
	 * @param includeAgencyReferences if true then will also check the agency of the maintainable exists 
	 * @param beanRetrievalManager - this can be used to resolve references, but can be null if not required
	 * @return a set of maintainables removed form the container, or an empty set if none were removed
	 */
	Set<MaintainableBean> removeBrokenReferences(SdmxBeans beans, boolean includeAgencyReferences, SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Resolves all references and returns a Map containing all the input beans and the beans that are cross referenced,
	 * the Map's keyset contains the Identifiable that is the referencer and the Map's value collection contains the referenced artifacts.
	 * 
	 * @param beans - the SdmxBeans container, containing all the beans to check references for 
	 * @param includeIndirectReferences  if false do not include CrossReferences which do not directly reference the structure
	 * @param resolveAgencies - if true the resolver engine will also attempt to resolve referenced agencies
	 * @param includeWeakReferences - if true WeakCrossReferences will be included
	 * @param numberLevelsDeep - the number of times to recurse down the reference stack.  An example is a dataflow directly references a DSD (numberLevelsDeep=1), the DSD
	 * may in turn reference a Codelist (numberLevelsDeep=2).  The numberLevelsDeep argument can be a positive integer specifying how deeply to resolve the
	 * references, an argument of 0 (zero) implies there is no limit, and the resolver engine will continue recursing until it has found every directly and indirectly referenced
	 * artifact.  Note that there is no risk of infinite recursion in calling this.  
	 * @param retrievalManager - Used to resolve the structure references.  Can be null, if supplied this is used to resolve any references that do not exist in the supplied beans 
	 * @return IReferenceResolution
	 * @throws CrossReferenceException - if any of the references could not be resolved
	 * @see ICrossReferenceBean.isIndirectReference
	 */
	IReferenceResolution resolveReferences(SdmxBeans beans, 
										  boolean resolveAgencies,
										  boolean includeWeakReferences,
									      int numberLevelsDeep,
									      SdmxBeanRetrievalManager identifiableRetrievalManager) throws CrossReferenceException;
	
	/**
	 * Returns a set of IdentifiableBeans that the MaintainableBean cross references
	 * 
	 * @param beans - the bean to return cross references for 
	 * @param includeIndirectReferences  if false do not include CrossReferences which do not directly reference the structure
	 * @param resolveAgencies - if true will also resolve the agencies
	 * @param includeWeakReferences - if true WeakCrossReferences will be included
	 * @param numberLevelsDeep - the number of times to recurse down the reference stack.  An example is a dataflow directly references a DSD (numberLevelsDeep=1), the DSD
	 * may in turn reference a Codelist (numberLevelsDeep=2).  The numberLevelsDeep argument can be a positive integer specifying how deeply to resolve the
	 * references, an argument of 0 (zero) implies there is no limit, and the resolver engine will continue recursing until it has found every directly and indirectly referenced
	 * artifact.  Note that there is no risk of infinite recursion in calling this.  
	 * @param retrievalManager - Used to resolve the structure references.  Can be null, if supplied this is used to resolve any references that do not exist in the supplied beans 
	 * @throws CrossReferenceException - if any of the references could not be resolved
	 * @see ICrossReferenceBean.isIndirectReference
	 */
	IReferenceResolution resolveReferences(MaintainableBean bean, 
										  boolean resolveAgencies, 
										  boolean includeWeakReferences,
										  int numberLevelsDeep,
										  SdmxBeanRetrievalManager identifiableRetrievalManager) throws CrossReferenceException;
	

}
