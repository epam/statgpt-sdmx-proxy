package io.sdmx.core.sdmx.model.type;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import java.nio.ByteBuffer;

import org.h2.mvstore.DataUtils;
import org.h2.mvstore.WriteBuffer;
import org.h2.mvstore.type.BasicDataType;

/**
 * Serialization for List<T> using BasicDataType<U>.
 */
public class DT_List<T extends U, U> extends BasicDataType<List<T>> {
  private final BasicDataType<U> elemDT;

  public DT_List(BasicDataType<U> elemDT) {
    this.elemDT = elemDT;
  }

  @Override
  public int getMemory(List<T> list) {
    int size = 2; // average varInt size ?

    if (list != null)
      for (T t: list)
        size += elemDT.getMemory((U)t);

    return size;
  }

  // encode size to avoid having a long varint when list is null
  private void writeSize(WriteBuffer buf, List<T> list) {
    buf.putVarInt(list == null ? 0 : list.size() + 1);
  }

  // decode size according to encoding performed at write time
  private Integer readSize(ByteBuffer buf) {
    int x = DataUtils.readVarInt(buf);

    return (x == 0) ? null : x - 1;
  }

  @Override
  public void write(WriteBuffer buf, List<T> list) {
    writeSize(buf, list);

    if (list != null)
      for (T t: list)
        elemDT.write(buf, (U)t);
  }

  @Override
  public List<T> read(ByteBuffer buf) {
    Integer size = readSize(buf);
    List<T> list;

    if (size == null)
      list = null;
    else if (size == 0)
      list = Collections.emptyList();
    else {
      list = new ArrayList<T>(size);

      for (int i = 0; i < size; i++) {
        @SuppressWarnings("unchecked")
        T t = (T)elemDT.read(buf);

        list.add(t);
      }
    }

    return list;
  }

  @Override
  public List<T>[] createStorage(int size) {
    @SuppressWarnings({"unchecked", "rawtypes"})
    List<T>[] array = new List[size];

    return array;
  }
}
