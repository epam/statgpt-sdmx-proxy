package io.sdmx.core.sdmx.engine.data;

import java.util.List;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.IPositionAwareDataReaderEngine;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDataPosition;

public class PositionAwareDataReaderEngine<T extends IDataPosition> extends DataReaderEngineProxy implements IPositionAwareDataReaderEngine<T> {
//	private POSITION_TYPE posType;
	private READER_POSITION readerPosition = READER_POSITION.BEGIN;
	
	
	public PositionAwareDataReaderEngine(DataReaderEngine proxy) {
		super(proxy);
	}

//	@Override
//	public POSITION_TYPE getPositionType() {
//		if(posType == null) {
//			
//		}
//		return null;
//	}

	@Override
	public READER_POSITION getCurrentPosition() {
		return readerPosition;
	}

	@Override
	public boolean moveNextDataset() throws DataSetStructureReferenceException {
		if(super.moveNextDataset()) {
			readerPosition = READER_POSITION.START_DATASET;
			return true;
		}
		readerPosition = READER_POSITION.END;
		return false;
	}

	@Override
	public boolean moveNextObservation() {
		if(super.moveNextObservation()) {
			readerPosition = READER_POSITION.OBS;
			return true;
		}
		readerPosition = READER_POSITION.END_OBS;
		return false;
	}

	@Override
	public boolean moveNextKeyable() {
		if(super.moveNextKeyable()) {
			readerPosition = READER_POSITION.KEY;
			return true;
		}
		readerPosition = READER_POSITION.END_KEY;
		return false;
	}

	@Override
	public void reset() {
		super.reset();
		readerPosition = READER_POSITION.BEGIN;
	}

	@Override
	public List<FooterMessage> close() {
		try {
			return super.close();
		} finally {
			readerPosition = READER_POSITION.END;
		}
	}
	
	
	
	
	
	
}
