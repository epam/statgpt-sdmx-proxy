package io.sdmx.core.sdmx.engine.position;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.data.IDataPosition;
import io.sdmx.api.sdmx.model.data.IDataPosition.POSITION_TYPE;
import io.sdmx.core.sdmx.api.engine.data.IPositionReaderEngine;
import io.sdmx.utils.core.object.NumberUtils;

public abstract class AbstractPositionReaderEngineFile implements IPositionReaderEngine {
	private POSITION_TYPE positionType;
	
	public AbstractPositionReaderEngineFile(POSITION_TYPE positionType) {
		this.positionType = positionType;
	}

	@Override
	public IDataPosition string2Position(String asString) {
		String[] split = asString.split(":");
		if(!split[0].equals(getPositionPrefix())) {
			throw new IllegalArgumentException("Can not read data position information '"+asString+"' using this engine which expects prefix of '"+getPositionPrefix()+"' ");
		}
		try {
			return parsePositionalInformation(split);
		} catch(Throwable th) {
			throw new SdmxSemmanticException(th, "Could not read data position information from string '"+asString+"'");
		}
	}
	
	protected abstract IDataPosition parsePositionalInformation(String[] split);
	
	protected Integer asInteger(String[] split, int idx) {
		String expectedInt = split[idx];
		if(!NumberUtils.isInteger(expectedInt, false)) {
			throw new IllegalArgumentException("Error parsing part '"+(idx+1)+"' of poistion '"+expectedInt+"' expected data type of integer");
		}
		return Integer.parseInt(expectedInt);
	}
	
	protected Long asLong(String[] split, int idx) {
		String expectedLong = split[idx];
		if(!NumberUtils.isInteger(expectedLong, true)) {
			throw new IllegalArgumentException("Error parsing part '"+(idx+1)+"' of poistion '"+expectedLong+"' expected data type of long");
		}
		return Long.parseLong(expectedLong);
	}

	@Override
	public String getPositionPrefix() {
		return positionType.getPositionalPrefix();
	}
}