package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.datastructure.DataStructureBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link DataStructureBeanDeferred}
 */
public class DeferredDataStructureReaderEngine extends AbstractDeferredStructureReaderEngine<DataStructureBean> {
    private static DeferredDataStructureReaderEngine INSTANCE;
    
    private DeferredDataStructureReaderEngine() {
        super(DataStructureBean.class);
    }
    
    public static DeferredDataStructureReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredDataStructureReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<DataStructureBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new DataStructureBeanDeferred(bean, loader);
    }

}
