package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.IMaintainableReferenceRetreivalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.utils.core.collection.CollectionUtil;

public class InMemoryMaintainableReferenceRetreivalManager implements IMaintainableReferenceRetreivalManager {
	private Map<IURNMaintainable<?>, List<IMaintainableReferences<?>>> references = Collections.emptyMap();
	
	public InMemoryMaintainableReferenceRetreivalManager(ICrossReferenceLookupTable lookupTable) {
		if(lookupTable != null) {
			int mapSize = lookupTable.getMaintDirectReferences().size() + lookupTable.getMaintIndirectReferences().size();
			references = new HashMap<>(mapSize);
			addReferences(lookupTable.getMaintDirectReferences());
			addReferences(lookupTable.getMaintIndirectReferences());
		}
	}
	
	private void addReferences(Set<IMaintainableReferences> references) {
		references.forEach(e -> {
			CollectionUtil.addToMappedList(this.references, e.getMaintURN(), e);
		});
	}
	
	@Override
	public List<IMaintainableReferences<?>> getReferencedBy(IURNMaintainable<?> urn) {
		List<IMaintainableReferences<?>> refBy = references.get(urn);
		return refBy == null ? Collections.emptyList() : Collections.unmodifiableList(refBy);
	}
}
