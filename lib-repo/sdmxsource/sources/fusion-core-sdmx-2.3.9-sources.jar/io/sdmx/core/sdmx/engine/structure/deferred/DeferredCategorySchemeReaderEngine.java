package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.categoryscheme.CategorySchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link CategorySchemeBeanDeferred}
 */
public class DeferredCategorySchemeReaderEngine extends AbstractDeferredStructureReaderEngine<CategorySchemeBean> {
    private static DeferredCategorySchemeReaderEngine INSTANCE;
    
    private DeferredCategorySchemeReaderEngine() {
        super(CategorySchemeBean.class);
    }
    
    public static DeferredCategorySchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredCategorySchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<CategorySchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new CategorySchemeBeanDeferred(bean, loader);
    }

}
