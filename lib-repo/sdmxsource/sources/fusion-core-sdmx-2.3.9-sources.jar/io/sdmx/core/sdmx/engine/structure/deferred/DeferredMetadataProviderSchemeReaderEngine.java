package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.base.MetadataProviderSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link MetadataProviderSchemeBeanDeferred}
 */
public class DeferredMetadataProviderSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<IMetadataProviderSchemeBean> {
    private static DeferredMetadataProviderSchemeReaderEngine INSTANCE;
    
    private DeferredMetadataProviderSchemeReaderEngine() {
        super(IMetadataProviderSchemeBean.class);
    }
    
    public static DeferredMetadataProviderSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredMetadataProviderSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IMetadataProviderSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new MetadataProviderSchemeBeanDeferred(bean, loader);
    }

}
