package io.sdmx.core.sdmx.model.ref;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.core.sdmx.api.model.parse.IStructureParseConfiguration;

public class StructureParseConfiguration implements IStructureParseConfiguration {
    private boolean immutable;
    private ResolutionSettings resolutionSettings;
    private SdmxBeanRetrievalManager retrievalManager;
    private Map<DATASET_ACTION, Boolean> validateMap = new HashMap<>();
    private IBeansBuilder beansBuilder;

    /**
     * Default instance does not require resolution settings and does not provide a bean retreival manager
     */
    public static StructureParseConfiguration DEFAULT_INSTANCE = new StructureParseConfiguration(true);

    public static StructureParseConfiguration build() {
        return new StructureParseConfiguration();
    }

    public StructureParseConfiguration() {
        this(false);
    }

    private  StructureParseConfiguration(boolean immutable) {
        this.immutable = immutable;
    }

    @Override
    public IBeansBuilder getBeanBuilder() {
        return beansBuilder;
    }
    public StructureParseConfiguration beansBuilder(IBeansBuilder beansBuilder) {
        if(immutable) {
            throw new SdmxException("Can not modify default StructureParseConfiguration");
        }
        this.beansBuilder = beansBuilder;
        return this;
    }

    public StructureParseConfiguration resolution(ResolutionSettings resolutionSettings) {
        if(immutable) {
            throw new SdmxException("Can not modify default StructureParseConfiguration");
        }
        this.resolutionSettings = resolutionSettings;
        return this;
    }

    public StructureParseConfiguration retrievalManager(SdmxBeanRetrievalManager retrievalManager) {
        if(immutable) {
            throw new SdmxException("Can not modify default StructureParseConfiguration");
        }
        this.retrievalManager = retrievalManager;
        return this;
    }

    public StructureParseConfiguration validate(boolean validate) {
        if(immutable) {
            throw new SdmxException("Can not modify default StructureParseConfiguration");
        }
        for(DATASET_ACTION action : DATASET_ACTION.values()) {
            validateMap.put(action, validate);
        }
        return this;
    }

    public StructureParseConfiguration validate(DATASET_ACTION action, boolean validate) {
        if(immutable) {
            throw new SdmxException("Can not modify default StructureParseConfiguration");
        }
        validateMap.put(action, validate);
        return this;
    }

    @Override
    public ResolutionSettings getResolutionSettings() {
        return resolutionSettings;
    }

    @Override
    public SdmxBeanRetrievalManager getRetrievalManager() {
        return retrievalManager;
    }


    @Override
    public boolean performPostProcessValidation(DATASET_ACTION action) {
        if(validateMap.containsKey(action)) {
            return validateMap.get(action) == Boolean.TRUE;
        }
        return false;
    }

}
