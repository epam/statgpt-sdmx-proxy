package io.sdmx.core.sdmx.factory.ref;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.xs.CrossReferenceRetrievalFactory;
import io.sdmx.core.sdmx.model.ref.DataStructureReferences;
import io.sdmx.core.sdmx.util.BeanRetreivalUtil;
import io.sdmx.core.sdmx.util.XsRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;

public class ContentConstraintCrossReferenceRetrievalFactory implements CrossReferenceRetrievalFactory, IFusionSingleton {
	private static ContentConstraintCrossReferenceRetrievalFactory INSTANCE;
	
	
	public static ContentConstraintCrossReferenceRetrievalFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ContentConstraintCrossReferenceRetrievalFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public Class<? extends MaintainableBean> getSupportedType() {
		return ContentConstraintBean.class;
	}

	public static ContentConstraintCrossReferenceRetrievalFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, MaintainableBean maintBean) {
		ContentConstraintBean constraintBean = (ContentConstraintBean) maintBean;
		Set<ICrossReferenceBean<?>> returnReferences = new HashSet<>();

		Map<String, ICrossReferenceBean<?>> componentEnumMap = new HashMap<>();
		Map<String, Set<ComponentBean>> componentMap = new HashMap<>();
		SdmxBeans referencedBeans = BeanRetreivalUtil.getConstrainedStructures(constraintBean, retrievalManager);
		
		for(DataStructureBean dsd : referencedBeans.getDataStructures()) {
			DataStructureReferences dsdRefs = new DataStructureReferences(retrievalManager, dsd);
			for(ComponentBean comp : dsd.getComponents()) {
				CollectionUtil.addToMappedSet(componentMap, comp.getId(), comp);
			}
			for(ComponentBean comp : dsdRefs.getEnumerationReferences().keySet()) {
				ICrossReferenceBean<?> xsRef = dsdRefs.getEnumerationReferences().get(comp);
				if(xsRef != null) {
					IndirectReferenceBean<?> idrRef = new IndirectReferenceBean<>(constraintBean, xsRef.getReference());
					componentEnumMap.put(comp.getId(), idrRef);
				}
			}
		}
		if(componentEnumMap.size() == 0) {
			return returnReferences;
		}
		addCrossReferencesForCubeRegion(constraintBean, componentMap, returnReferences, componentEnumMap, constraintBean.getIncludedCubeRegion(), retrievalManager);
		addCrossReferencesForCubeRegion(constraintBean, componentMap, returnReferences, componentEnumMap, constraintBean.getExcludedCubeRegion(), retrievalManager);
		addCrossReferencesForConstraintKey(constraintBean, componentMap, returnReferences, componentEnumMap, constraintBean.getIncludedSeriesKeys(), retrievalManager);
		addCrossReferencesForConstraintKey(constraintBean, componentMap, returnReferences, componentEnumMap, constraintBean.getExcludedSeriesKeys(), retrievalManager);

		return returnReferences;
	}
	
	private void addCrossReferencesForCubeRegion(ContentConstraintBean constraintBean, Map<String, Set<ComponentBean>> componentMap,
			Set<ICrossReferenceBean<?>> returnReferences,
			Map<String, ICrossReferenceBean<?>> componentEnumMap,
			CubeRegionBean cubeRegionBean,
			SdmxBeanRetrievalManager retrievalManager) {
		if(cubeRegionBean == null) {
			return;
		}
		addCrossReferencesForCubeRegion(constraintBean, componentMap, returnReferences, componentEnumMap, cubeRegionBean.getKeyValues(), retrievalManager);
		addCrossReferencesForCubeRegion(constraintBean, componentMap, returnReferences, componentEnumMap, cubeRegionBean.getAttributeValues(), retrievalManager);
	}

	private void addCrossReferencesForCubeRegion(ContentConstraintBean constraintBean,
			Map<String, Set<ComponentBean>> componentMap,
			Set<ICrossReferenceBean<?>> returnReferences,
			Map<String, ICrossReferenceBean<?>> componentEnumMap,
			List<KeyValues> keyValues,
			SdmxBeanRetrievalManager retrievalManager) {
		for(KeyValues kvs : keyValues) {
			addComponentRef(constraintBean, returnReferences, componentMap, componentEnumMap, kvs.getId(), kvs.getValues(), retrievalManager);
		}
	}
	
	private void addCrossReferencesForConstraintKey(ContentConstraintBean constraintBean,
			Map<String, Set<ComponentBean>> componentMap,
			Set<ICrossReferenceBean<?>> returnReferences,
			Map<String, ICrossReferenceBean<?>> componentEnumMap,
			ConstraintDataKeySetBean constraintDataKey,
			SdmxBeanRetrievalManager retrievalManager) {
		if(constraintDataKey == null) {
			return;
		}

		Map<String, Set<String>> componentCodeMap = new HashMap<>();
		for(ConstrainedDataKeyBean cdk : constraintDataKey.getConstrainedDataKeys()) {
			for(KeyValue kv : cdk.getKeyValues()) {
				Set<String> componentCodes = componentCodeMap.get(kv.getConcept());
				if(componentCodes == null) {
					componentCodes = new HashSet<>();
					componentCodeMap.put(kv.getConcept(), componentCodes);
				}
				for(String codeId : kv.getCode().split("\\+")) {
					componentCodes.add(codeId);
				}
			}
		}
		
		for(String currentComponentId : componentCodeMap.keySet()) {
			addComponentRef(constraintBean, returnReferences, componentMap, componentEnumMap, currentComponentId, componentCodeMap.get(currentComponentId), retrievalManager);
		}
	}
	
	private void addComponentRef(ConstraintBean constraintBean,  
								 Set<ICrossReferenceBean<?>> returnReferences, 
								 Map<String, Set<ComponentBean>> componentMap,
								 Map<String, ICrossReferenceBean<?>> componentEnumMap, 
								 String compId,
								 Set<String> codeVals,
								 SdmxBeanRetrievalManager retrievalManager) {
		Set<ComponentBean> comps = componentMap.get(compId);
		if(comps != null) {
			for(ComponentBean comp : comps) {
				IndirectReferenceBean<?> compRef = new IndirectReferenceBean<>(constraintBean, comp.getURN());
				returnReferences.add(compRef);
			}
		}
		if(codeVals != null) {
			ICrossReferenceBean<?> representationRef =  componentEnumMap.get(compId); 
			if(representationRef == null) {
				return;
			}
			XsRefUtil.addRepresentationReferences(constraintBean, returnReferences, representationRef, codeVals, retrievalManager);
		}
	}
}
