package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.im.beans.mapping.v3.StructureMapBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link StructureMapBeanDeferred}
 */
public class DeferredStructureMapReaderEngine extends AbstractDeferredStructureReaderEngine<IStructureMapBean> {
    private static DeferredStructureMapReaderEngine INSTANCE;
    
    private DeferredStructureMapReaderEngine() {
        super(IStructureMapBean.class);
    }
    
    public static DeferredStructureMapReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredStructureMapReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<IStructureMapBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new StructureMapBeanDeferred(bean, loader);
    }

}
