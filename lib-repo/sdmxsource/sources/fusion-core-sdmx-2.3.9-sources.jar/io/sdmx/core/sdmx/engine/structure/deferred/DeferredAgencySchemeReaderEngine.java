package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.base.AgencySchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link AgencySchemeBeanDeferred}
 */
public class DeferredAgencySchemeReaderEngine extends AbstractDeferredStructureReaderEngine<AgencySchemeBean> {
    private static DeferredAgencySchemeReaderEngine INSTANCE;
    
    private DeferredAgencySchemeReaderEngine() {
        super(AgencySchemeBean.class);
    }
    
    public static DeferredAgencySchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredAgencySchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<AgencySchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new AgencySchemeBeanDeferred(bean, loader);
    }

}
