package io.sdmx.core.sdmx.model.mvstore;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.h2.mvstore.MVStore;

import io.sdmx.core.sdmx.api.model.mvstore.IMVStore;

public class MVStoreWrap implements IMVStore {
	private MVStore mvStore;
	private File file;
	
	public MVStoreWrap(File file) {
		if(file == null) {
			try {
				file = Files.createTempFile("sdmxdb", ".mvs").toFile();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		this.file = file;
		mvStore = new MVStore.Builder()
				.fileName(file.getPath())
				.autoCommitDisabled()
				.compress()     // fast compression
				// .compressHigh() // high compression
				.open();
	}
	
	@Override
	public MVStore getStore() {
		return this.mvStore;
	}


	@Override
	public void close() {
		mvStore.close();
	}

	@Override
	public void delete() {
		close();
		file.delete();
	}

	
}
