package io.sdmx.core.sdmx.manager.structure;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;

public class ConstraintRetrievalManagerImpl implements ConstraintRetrievalManager {
	private static final Logger LOG = LoggerFactory.getLogger(ConstraintRetrievalManagerImpl.class);

	private static WeakHashMap<ISdmxBeanRestRetrievalManager, ConstraintRetrievalManager> instanceMap = new WeakHashMap<>();
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private ISdmxBeanRestRetrievalManager restRetreivalManager;

	public ConstraintRetrievalManagerImpl(ISdmxBeanRestRetrievalManager restRetreivalManager) {
		this.beanRetrievalManager = new SdmxRestToBeanRetrievalManager(restRetreivalManager);
		this.restRetreivalManager = restRetreivalManager;
		instanceMap.put(restRetreivalManager, this);
	}
	
	public static ConstraintRetrievalManager getInstance(ISdmxBeanRestRetrievalManager restRetreivalManager) {
		ConstraintRetrievalManager returnManager = instanceMap.get(restRetreivalManager);
		if(returnManager == null) {
			returnManager = new ConstraintRetrievalManagerImpl(restRetreivalManager);
		}
		return returnManager;
	}

	@Override
	public Set<ContentConstraintBean> getAllConstraintsDefiningAllowedData(ConstrainableBean constrainable, Date validAt) {
		Set<ContentConstraintBean> constraints = getAllConstraintsDefiningAllowedData(constrainable);
		if(validAt == null) {
			return constraints;
		}
		Set<ContentConstraintBean> returnSet = new HashSet<>(constraints.size());
		for(ContentConstraintBean constraint : constraints) {
			if(constraint.hasValidityPeriod() && !constraint.getValidityPeriod().isInPeriod(new Date())) {
				continue;
			}
			returnSet.add(constraint);
		}
		return returnSet;
	}

	@Override
	public Set<ContentConstraintBean> getAllConstraintsDefiningAllowedData(ConstrainableBean constrainable) {
		LOG.debug("getAllConstraintsDefiningAllowedData for Constrainable: "+constrainable);
		RESTStructureQuery structureQuery = new RESTStructureQueryImpl(
				STRUCTURE_QUERY_DETAIL.FULL,
				STRUCTURE_REFERENCE_DETAIL.SPECIFIC,
				SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT,
				constrainable.getURN());

		Set<ContentConstraintBean> returnSet = new HashSet<>();
		Map<String, ContentConstraintBean> latestVersion = new HashMap<>();
		for(ContentConstraintBean constraintBean : restRetreivalManager.getMaintainables(structureQuery).getContentConstraintBeans()) {
			if(!constraintBean.isDefiningActualDataPresent()) {
				//Even though we have a constraint, it may not be attached to the constrainable.  This is true in the situation where the constrainable
				//Is a Data Provider.  In this case the constraint may be attached to a different provider who happens to be in the same scheme
				//(Note the REST Query is for the data provider scheme, with references = constraint).
				//Also there appears to be a bug in Registry 9.0.89 where asking for a DSD and parents returns constraints attached to the Dataflow!
				if(isMatch(constraintBean, constrainable)) {
					String key = constraintBean.getURN().getURNNoVersion();
					ContentConstraintBean alreadyStored = latestVersion.get(key);
					if(alreadyStored == null || constraintBean.getVersion().isLater(alreadyStored.getVersion())) {
						latestVersion.put(key, constraintBean);
					}
				}
			}
		}
		returnSet.addAll(latestVersion.values());
		for(ICrossReferenceBean<? extends ConstrainableBean> childConstrainableRef : constrainable.getCrossReferencedConstrainables()) {
			ConstrainableBean childConstrainable = beanRetrievalManager.getBean(childConstrainableRef.getReference());
			returnSet.addAll(getAllConstraintsDefiningAllowedData(childConstrainable));
		}
		return returnSet;
	}
	
	private boolean isMatch(ContentConstraintBean constraintBean, ConstrainableBean constrainable) {
		for(ICrossReferenceBean<?> sRef : constraintBean.getConstraintAttachment().getStructureReference()) {
			if(sRef.isMatch(constrainable)) {
				LOG.debug("Constraint Match: "+constraintBean);
				return true;
			}
		}
		return false;
	}

}

