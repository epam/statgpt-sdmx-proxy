package io.sdmx.core.sdmx.manager.format;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IFormatFactory;
import io.sdmx.api.format.IInformationFormatManager;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.format.VNDHeader;
import io.sdmx.utils.core.http.EmptyRequest;

/**
 * High level manager which delegates question of response format to individual ISchemaFormatFactory
 */
public class InformationFormatManager implements IInformationFormatManager, IFusionSingleton {
	private static final String VND_HEADER = "application/vnd.";
	private static InformationFormatManager INSTANCE = new InformationFormatManager();
	
	private SortedSet<IFormatFactory<InformationFormat>> factories = null;
	private Map<Class<? extends InformationFormat>, SortedSet<IFormatFactory<? extends InformationFormat>>> typeFactories;
	private Map<Class<? extends InformationFormat>, InformationFormat> defaultFormats = new HashMap<>();
	
	public static InformationFormatManager getInstance() {
		if(INSTANCE == null) {
			InformationFormatManager.INSTANCE = new InformationFormatManager();
			SingletonStore.registerInstance(InformationFormatManager.INSTANCE);
		}
		return INSTANCE;
	}
	
	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	
	@Override
	public <T extends InformationFormat> Map<String, FormatDetails> getSupportedFormats(Class<T> classType) {
		Map<String, FormatDetails> returnMap = new HashMap<>();
		for(IFormatFactory<T> factory : getFormatFactories(classType)) {
			Map<String, FormatDetails> factoryFormats = factory.getSupportedFormats();
			if(factoryFormats != null) {
				returnMap.putAll(factoryFormats);
			}
		}
		return Collections.unmodifiableMap(returnMap);
	}

	@Override
	public <T extends InformationFormat> T getFormat(Request request, Class<T> classType) {
		return getFormat(request, classType, true);
	}
	
	@Override
	public <T extends InformationFormat> T getFormat(Request request, Class<T> classType, boolean includeDefaultFormats) {
		List<IVNDHeader> vndHeaders = buildVndHeaders(request);
		if(vndHeaders.size() > 0) {
			for(IFormatFactory<T> factory : getFormatFactories(classType)) {
				for(IVNDHeader header : vndHeaders) {
					T format = factory.getFormat(request, header);
					if(format != null) {
						return format;
					}
				}
			}
			throw new SdmxNotAcceptableException("Unsupported Accept format: " +request.getHeader("Accept"));
		}
		String formatString = request.getParameter("format");
		if(formatString != null) {
			for(IFormatFactory<T> factory : getFormatFactories(classType)) {
				T format = factory.getFormat(formatString, request);
				if(format != null) {
					return format;
				}
			}
			throw new SdmxNotAcceptableException("Unsupported format: " +request.getParameter("format"));
		}
		if (!includeDefaultFormats) {
			return null;
		}
		
		T defaultFormat = (T)defaultFormats.get(classType);
		return defaultFormat;
	}

	@Override
	public <T extends InformationFormat> T getFormat(Request request, IVNDHeader vndHeader, Class<T> classType) {
		if(request == null) {
			request = EmptyRequest.INSTANCE;
		}
		for(IFormatFactory<T> factory : getFormatFactories(classType)) {
			T format = factory.getFormat(request, vndHeader);
			if(format != null) {
				return format;
			}
		}
		if(request != null) {
			if(request.getParameter("format") != null) {
				throw new SdmxNotAcceptableException("Unsupported format: " +request.getParameter("format"));
			} else if(request.getHeader("Accept") != null) {
				throw new SdmxNotAcceptableException("Unsupported Accept format: " +request.getHeader("Accept"));
			}
		} 
		if(vndHeader != null) {
			throw new SdmxNotAcceptableException("Unsupported format: " +vndHeader.getOriginalVND());
		} 
		throw new SdmxNotAcceptableException("Unsupported response format");
	}

	@Override
	public <T extends InformationFormat> void addDefaultFormat(Class<T> claz, InformationFormat format) {
		defaultFormats.put(claz, format);
	}

	private List<IVNDHeader> buildVndHeaders(Request request) {
		List<IVNDHeader> headers = Collections.emptyList();
		if(request.hasHeader("Accept")) {
			String accept = request.getHeader("Accept");
			String acceptSplit[] = accept.split(",");
			headers = new ArrayList<>(acceptSplit.length);
			for(String currentAccept : acceptSplit) {
				if(currentAccept.startsWith(VND_HEADER)) {
					headers.add(new VNDHeader(currentAccept));
				}
			}
		}
		return headers;
	}

	@Override
	public <T extends InformationFormat> Collection<IFormatFactory<T>> getFormatFactories(Class<T> ofType) throws IllegalArgumentException {
		if(typeFactories == null) {
			Map<Class<? extends InformationFormat>, SortedSet<IFormatFactory<? extends InformationFormat>>> typeFactories = new HashMap<>();
			for(IFormatFactory<InformationFormat> factory : getFormatFactories()) {
				Class<? extends InformationFormat> formatClass = factory.getFormatClass();
				SortedSet<IFormatFactory<? extends InformationFormat>> byType = typeFactories.get(formatClass);
				if(byType == null) {
					byType = new TreeSet<>(new Comparator<IFormatFactory<? extends InformationFormat>>() {

						@Override
						public int compare(IFormatFactory<? extends InformationFormat> arg0, IFormatFactory<? extends InformationFormat> arg1) {
							int compare = arg0.getPriority() - arg1.getPriority();
							if(compare != 0) {
								return compare;
							}
							return arg0.getClass().getName().compareTo(arg1.getClass().getName());
						}

					});
					typeFactories.put(formatClass, byType);
				}
				byType.add(factory);
			}
			this.typeFactories = typeFactories;
		}
		
		@SuppressWarnings("rawtypes")
		SortedSet factories = typeFactories.get(ofType);
		if(factories == null) {
			throw new SdmxNotAcceptableException("Unsupported format");
		}
		return factories;
	}

	private Collection<IFormatFactory<InformationFormat>> getFormatFactories() throws IllegalArgumentException {
		if(factories == null) {
			SortedSet<IFormatFactory<InformationFormat>> factories = new TreeSet<>();
			for(IFormatFactory factory : FusionBeanStore.getBeans(IFormatFactory.class)) {
				factories.add(factory);
			}
			this.factories = factories;
		}
		return factories;
	}
}
