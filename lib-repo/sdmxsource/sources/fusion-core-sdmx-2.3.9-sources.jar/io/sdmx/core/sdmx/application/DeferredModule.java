package io.sdmx.core.sdmx.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredAgencySchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredCategorisationReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredCategorySchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredCodelistReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredConceptSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredCustomTypeSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredDataConstrantReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredDataConsumerSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredDataProviderSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredDataStructureReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredDataflowReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredHierarchyAssociationReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredHierarchyReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredMetadataProviderSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredMetadataProvisionReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredMetadataSetReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredMetadataStructureReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredMetadataflowReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredNamePersonalisationSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredOrganisationSchemeMapReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredOrganisationUnitSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredProcessReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredProvisionAgreementReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredRegistrationReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredReportingTaxonomyReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredRepresentationMapReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredRulesetSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredStructureMapReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredTransformationSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredUserDefinedOperatorSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredVTLMappingSchemeReaderEngine;
import io.sdmx.core.sdmx.engine.structure.deferred.DeferredValuelistReaderEngine;
import io.sdmx.core.sdmx.manager.structure.DeferredStructureReaderManager;

public class DeferredModule implements IFusionModule {

    public static void register() {
        //Structure Reader Manager
        DeferredStructureReaderManager.getInstance();
        
        //Maintainable Reader Engines
        DeferredAgencySchemeReaderEngine.getInstance();
        DeferredCategorisationReaderEngine.getInstance();
        DeferredCategorySchemeReaderEngine.getInstance();
        DeferredCodelistReaderEngine.getInstance();
        DeferredConceptSchemeReaderEngine.getInstance();
        DeferredCustomTypeSchemeReaderEngine.getInstance();
        DeferredDataConstrantReaderEngine.getInstance();
        DeferredDataConsumerSchemeReaderEngine.getInstance();
        DeferredDataflowReaderEngine.getInstance();
        DeferredDataProviderSchemeReaderEngine.getInstance();
        DeferredDataStructureReaderEngine.getInstance();
        DeferredHierarchyReaderEngine.getInstance();
        DeferredHierarchyAssociationReaderEngine.getInstance();
        DeferredMetadataStructureReaderEngine.getInstance();
        DeferredMetadataflowReaderEngine.getInstance();
        DeferredMetadataProviderSchemeReaderEngine.getInstance();
        DeferredMetadataProvisionReaderEngine.getInstance();
        DeferredNamePersonalisationSchemeReaderEngine.getInstance();
        DeferredOrganisationUnitSchemeReaderEngine.getInstance();
        DeferredOrganisationSchemeMapReaderEngine.getInstance();
        DeferredProcessReaderEngine.getInstance();
        DeferredProvisionAgreementReaderEngine.getInstance();
        DeferredRegistrationReaderEngine.getInstance();
        DeferredReportingTaxonomyReaderEngine.getInstance();
        DeferredRepresentationMapReaderEngine.getInstance();
        DeferredRulesetSchemeReaderEngine.getInstance();
        DeferredStructureMapReaderEngine.getInstance();
        DeferredTransformationSchemeReaderEngine.getInstance();
        DeferredUserDefinedOperatorSchemeReaderEngine.getInstance();
        DeferredValuelistReaderEngine.getInstance();
        DeferredVTLMappingSchemeReaderEngine.getInstance();
        
        DeferredMetadataSetReaderEngine.getInstance();
    }
}
