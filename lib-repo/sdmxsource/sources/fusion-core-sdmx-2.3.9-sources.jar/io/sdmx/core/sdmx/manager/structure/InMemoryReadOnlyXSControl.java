package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ActualContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.AdvancedReleaseCalendarBean;
import io.sdmx.api.sdmx.model.beans.registry.AllowedContentConstraintBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

@Deprecated //replaced with AbstractCrossReferenceControl
public class InMemoryReadOnlyXSControl {
//implements CrossReferencedRetrievalManager, CrossReferencingRetrievalManager  {
//
//	private SdmxBeanRetrievalManager retrievalManager;
//
//	private Map<String, MaintainableBean> maintCache = new HashMap<>();;//A map of all the identifiables that this is built from
//
//	private Map<String, Set<String>> references;  			//Identifiable URN to Maintainable URN
//	private Map<String, Set<String>> referencing; 			//Identifiable URN to Maintainable URN
//	private Map<String, Set<String>> indirectReferences;	//Identifiable URN to Maintainable URN
//	private Map<String, Set<String>> indirectReferencing;	//Identifiable URN to Maintainable URN
//	
//	public InMemoryReadOnlyXSControl(ICrossReferenceLookupTable lookupTable, SdmxBeanRetrievalManager retrievalManager) {
//		this.retrievalManager = retrievalManager;
//		
//		int referencesCount = lookupTable.getMaintDirectReferences().size();
//		this.references = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();  
//		this.referencing = referencesCount > 0 ? new HashMap<>(referencesCount) : Collections.emptyMap();
//
//		int indirectReferencesCount = lookupTable.getMaintIndirectReferences().size();
//		this.indirectReferences = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();  
//		this.indirectReferencing = indirectReferencesCount > 0 ? new HashMap<>(indirectReferencesCount) : Collections.emptyMap();
//		
//		populateReferencesMaps(lookupTable.getMaintDirectReferences(), this.references, this.referencing);
//		populateReferencesMaps(lookupTable.getMaintIndirectReferences(), this.indirectReferences, this.indirectReferencing);
//	}
//	
//	private void populateReferencesMaps(Set<IMaintainableReferences> mReferences, Map<String, Set<String>> referencesMap,  Map<String, Set<String>> referencingMap) {
//		for(IMaintainableReferences mRef : mReferences) {
//			Map<IURNAbsolute<?>, Set<IURNAbsolute<?>>> references = mRef.getReferences();
//			for(IURNAbsolute<?> identURNFrom : references.keySet()) {
//				IURNMaintainable<?> maintURNFrom = identURNFrom.getMaintainableURN(); 
//				for(IURNAbsolute<?> identURNTo : references.get(identURNFrom)) {
//					IURNMaintainable<?> maintURNTo = identURNTo.getMaintainableURN(); 
//					CollectionUtil.addToMappedSet(referencesMap, identURNFrom, maintURNTo);
//					CollectionUtil.addToMappedSet(referencingMap, identURNTo, maintURNFrom);
//				}
//			}
//		}
//	}
//	
//	
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencingStructures(StructureReferenceBean structureReference, boolean includeIndirectReferences, SDMX_STRUCTURE_TYPE... structures) {
//		if(structureReference.getTargetUrn() == null) {
//			Set<MaintainableBean> returnSet = new HashSet<>();
//			for(IdentifiableBean ident : retrievalManager.getIdentifiableBeans(structureReference)) {
//				returnSet.addAll(getCrossReferencingStructures(ident, includeIndirectReferences, structures));
//			}
//			return returnSet;
//		}
//		return getCrossReferencingStructures(retrievalManager.getIdentifiableBean(structureReference, IdentifiableBean.class), includeIndirectReferences, structures);
//	}
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencingStructures(IdentifiableBean identifiable, boolean includeIndirectReferences, SDMX_STRUCTURE_TYPE... structures) {
//		if(identifiable == null) {
//			return new HashSet<>();
//		}
//		Set<MaintainableBean> maints = extractFromMap(this.referencing, identifiable);
//		if(includeIndirectReferences) {
//			maints.addAll(extractFromMap(this.indirectReferencing, identifiable));
//		}
//		for(IdentifiableBean currentComposite : identifiable.getIdentifiableComposites()) {
//			maints.addAll(extractFromMap(this.referencing, currentComposite));
//			if(includeIndirectReferences) {
//				maints.addAll(extractFromMap(this.indirectReferencing, currentComposite));
//			}
//		}
//		return filterList(maints, structures);
//	}
//	
//	@Override
//	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURNAbsolute<?> sourceStructureURN, boolean includeIndirect, Class<T> structures) {
//		referencing.get(s)
//		
//		return null;
//	}
//
//	@Override
//	public <T extends MaintainableBean> Set<T> getCrossReferencedStructures(IURNAbsolute<?> sourceStructureURN, boolean includeIndirectReferences, boolean fullTreeResolution, Class<T> structuresOfType) {
//		return null;
//	}
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencedStructures(StructureReferenceBean structureReference,boolean includeIndirect, boolean fullTreeResolution,
//			SDMX_STRUCTURE_TYPE... structures) {
//		Set<MaintainableBean> maintainables = getCrossReferencedStructures(structureReference, includeIndirect, structures);
//		if(fullTreeResolution) {
//			SdmxBeans resolved = new SdmxBeansImpl();
//			resolveDescendants(maintainables, resolved, includeIndirect);
//			maintainables.addAll(resolved.getAllMaintainables());
//		}
//		return maintainables;
//	}
//	
//	private void resolveDescendants(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans,boolean includeIndirect) {
//		int numBeans = -2;
//		while(numBeans != resolveFor.size()) {
//			numBeans = referencedBeans.getAllMaintainables().size();
//			resolveChildren(resolveFor, referencedBeans, includeIndirect);
//			resolveFor = referencedBeans.getAllMaintainables();
//		}
//	}
//
//	private void resolveChildren(Set<? extends MaintainableBean> resolveFor, SdmxBeans referencedBeans,boolean includeIndirect) {
//		for(MaintainableBean currentMaintainable : resolveFor) {
//			Set<MaintainableBean> children = getCrossReferencedStructures(currentMaintainable, includeIndirect);
//			referencedBeans.addIdentifiables(children);
//		}
//	}
//
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencedStructures(StructureReferenceBean structureReference, boolean includeIndirect, SDMX_STRUCTURE_TYPE... structures) {
//		if(structureReference.getTargetUrn() == null) {
//			Set<MaintainableBean> returnSet = new HashSet<>();
//			for(IdentifiableBean ident : retrievalManager.getIdentifiableBeans(structureReference)) {
//				returnSet.addAll(getCrossReferencedStructures(ident, includeIndirect, structures));
//			}
//			return returnSet;
//		}
//		return getCrossReferencedStructures(retrievalManager.getIdentifiableBean(structureReference, IdentifiableBean.class), includeIndirect, structures);
//	}
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencedStructures(IdentifiableBean identifiable, boolean includeIndirect, SDMX_STRUCTURE_TYPE... structures) {
//		if(identifiable == null) {
//			return new HashSet<>();
//		}
//		Set<MaintainableBean> maints = extractFromMap(this.references, identifiable);
//		if(includeIndirect) {
//			maints.addAll(extractFromMap(this.indirectReferences, identifiable));
//		}
//		for(IdentifiableBean currentComposite : identifiable.getIdentifiableComposites()) {
//			maints.addAll(extractFromMap(this.references, currentComposite));
//			if(includeIndirect) {
//				maints.addAll(extractFromMap(this.indirectReferences, currentComposite));
//			}
//		}
//		return filterList(maints, structures);
//	}
//
//	private Set<MaintainableBean> extractFromMap(Map<String, Set<String>> map, IdentifiableBean identifiable) {
//		Set<MaintainableBean> returnSet = new HashSet<>();
//		if(map.containsKey(identifiable.getUrn())) {
//			for(String maintUrn : map.get(identifiable.getUrn())) {
//				MaintainableBean maint = this.maintCache.get(maintUrn);
//				if(maint == null) {
//					maint = this.retrievalManager.getMaintainableBean(new StructureReferenceBeanImpl(maintUrn));
//					if(maint != null) {
//						this.maintCache.put(maint.getUrn(), maint);
//					}
//				}
//				if(maint != null) {
//					returnSet.add(maint);
//				}
//			}
//		}
//		return returnSet;
//	}
//
//	private Set<MaintainableBean> filterList(Set<MaintainableBean> maints, SDMX_STRUCTURE_TYPE... structures) {
//		if(maints == null) {
//			return new HashSet<>();
//		}
//		boolean hasStructureFilters = false;
//		if(structures != null) {
//			for(SDMX_STRUCTURE_TYPE st : structures) {
//				if(st != null) {
//					hasStructureFilters = true;
//					break;
//				}
//			}
//		}
//		Set<MaintainableBean> returnList = new HashSet<>();
//		if(!hasStructureFilters) {
//			for(MaintainableBean currentMaint : maints) {
//				if(!returnList.contains(currentMaint)) {
//					returnList.add(currentMaint);
//				}
//			}
//		}
//
//		for(SDMX_STRUCTURE_TYPE st : structures) {
//			if(st == null) {
//				continue;
//			}
//			for(MaintainableBean currentMaint : maints) {
//				SDMX_STRUCTURE_TYPE maintSt = currentMaint.getStructureType();
//				boolean addMaint = currentMaint.getStructureType() == st;
//				if(!addMaint && maintSt == SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT) {
//					if(st == SDMX_STRUCTURE_TYPE.ACTUAL_CONSTRAINT) {
//						addMaint = currentMaint instanceof ActualContentConstraintBean;
//					} else if(st == SDMX_STRUCTURE_TYPE.ALLOWED_CONSTRAINT) {
//						addMaint = currentMaint instanceof AllowedContentConstraintBean;
//					} else if(st == SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR) {
//						addMaint = currentMaint instanceof AdvancedReleaseCalendarBean;
//					}
//				} 
//				if(addMaint) {
//					if(!returnList.contains(currentMaint)) {
//						returnList.add(currentMaint);
//					}
//				}
//			}
//		}
//		return returnList;
//	}
//
	
}
