package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.conceptscheme.ConceptSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ConceptSchemeBeanDeferred}
 */
public class DeferredConceptSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<ConceptSchemeBean> {
    private static DeferredConceptSchemeReaderEngine INSTANCE;
    
    private DeferredConceptSchemeReaderEngine() {
        super(ConceptSchemeBean.class);
    }
    
    public static DeferredConceptSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredConceptSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ConceptSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ConceptSchemeBeanDeferred(bean, loader);
    }

}
