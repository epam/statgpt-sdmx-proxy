package io.sdmx.core.sdmx.manager.structure;

import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;

public class SdmxRestToBeanRetrievalManager implements SdmxBeanRetrievalManager {
	private ISdmxBeanRestRetrievalManager restBeanRestRetrievalManager;
	
	public SdmxRestToBeanRetrievalManager(ISdmxBeanRestRetrievalManager restBeanRestRetrievalManager) {
		this.restBeanRestRetrievalManager = restBeanRestRetrievalManager;
	}
	
	@Override
	public <T extends MaintainableBean> Set<T> getMaintainableBeans(IURN<T> urn) {
		return restBeanRestRetrievalManager.getMaintainables(new RESTStructureQueryImpl(urn)).getMaintainableBeans(urn.getStructureClass());
	}
}
