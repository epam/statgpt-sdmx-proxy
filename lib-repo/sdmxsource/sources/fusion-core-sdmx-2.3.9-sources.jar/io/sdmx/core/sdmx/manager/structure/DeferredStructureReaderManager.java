package io.sdmx.core.sdmx.manager.structure;

import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.io.IDeferredObjectReaderManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.IDeferredStructureReaderEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * Reads in IMaintainableBeanDeferred from
 */
public class DeferredStructureReaderManager implements IDeferredObjectReaderManager<IDeferredBeanDefinition, MaintainableBean>, IFusionSingleton {
    private static DeferredStructureReaderManager INSTANCE;
    private Map<IMaintainableStructureType<?>, IDeferredStructureReaderEngine<?>> readerMap;
    
    private DeferredStructureReaderManager() {}
    
    public static DeferredStructureReaderManager getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredStructureReaderManager();
            SingletonStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    
    @Override
    public IMaintainableBeanDeferred read(IDeferredBeanDefinition definition, IDeferredLoader<MaintainableBean> loader) {
        IDeferredStructureReaderEngine<MaintainableBean> deferredReader = getReader(definition.getUrn());
        if(deferredReader == null) {
            throw new RuntimeException("Can not read deferred bean '"+definition.getUrn()+"' no reader registered for type: "+definition.getUrn().getStructureType().getFullyQualifiedClass());
        }
        return deferredReader.read(definition, loader);
    }
    
    @SuppressWarnings("rawtypes")
    private IDeferredStructureReaderEngine getReader(IURNMaintainable urn) {
        if(this.readerMap == null) {
            Map<IMaintainableStructureType<?>, IDeferredStructureReaderEngine<?>> readerMap =
                    FusionBeanStore.getBeans(IDeferredStructureReaderEngine.class).stream().collect(Collectors.toMap(e->e.getSupportedType(), e->e));

            this.readerMap = Collections.unmodifiableMap(readerMap);
        }
        return this.readerMap.get(urn.getStructureType());
    }
    
    @Override
    public boolean supports(IDeferredBeanDefinition definition) {
        if(definition == null) {
            return false;
        }
        return getReader(definition.getUrn()) != null;
    }

    @Override
    public void destroyInstance() {
       INSTANCE = null;
       readerMap = null;
    }

}
