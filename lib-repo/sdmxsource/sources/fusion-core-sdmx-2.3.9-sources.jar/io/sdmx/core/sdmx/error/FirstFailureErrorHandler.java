package io.sdmx.core.sdmx.error;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.core.sdmx.api.error.DataFormatError;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.api.sdmx.exception.ErrorLimitException;
import io.sdmx.api.sdmx.exception.ExceptionHandler;

public class FirstFailureErrorHandler implements DataReaderExceptionHandler, DataValidationErrorHandler, ExceptionHandler {
	private Throwable exception;

	/**
	 * First Failure, so fail
	 * @param ex
	 * @throws ErrorLimitException
	 */
	@Override
    public void handleException(Throwable ex) throws ErrorLimitException {
		exception = ex;
		// This is unrecoverable so throw a RuntimeException
		if(ex instanceof RuntimeException) {
			RuntimeException e = (RuntimeException)ex;
			throw e;
		}
		throw new RuntimeException(ex);
	}


	@Override
	public void handleError(DataError err) throws ErrorLimitException {
		StringBuilder sb = new StringBuilder();
		sb.append("Error in "+err.getErrorPosition().getName());
		String concat = "";
		for(String shortCode : err.getShortCode()) {
			sb.append(concat + shortCode);
			concat = ", ";
		}
		sb.append(" error is:"+ err.getMessage());

		handleException(new SdmxSemmanticException(sb.toString()));
	}

	@Override
	public void handleException(DataFormatError ex) throws ErrorLimitException {
		handleException(new SdmxSemmanticException(ex.getMessage()));
	}

	@Override
	public void setDataset(int dsIndex) {
		//Irrelevant
	}

	public Throwable getException() {
		return exception;
	}

	public boolean hasException() {
		return exception != null;
	}
}
