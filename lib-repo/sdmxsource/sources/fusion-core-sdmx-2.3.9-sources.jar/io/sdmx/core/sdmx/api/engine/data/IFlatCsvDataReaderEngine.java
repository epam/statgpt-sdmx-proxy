package io.sdmx.core.sdmx.api.engine.data;

import java.util.Map;

public interface IFlatCsvDataReaderEngine extends IFlatDataReaderEngine {
	/**
	 * @return current byte count for lineage notifications
	 */
	long getCurrentByteCount();

	/**
	 * @return a map of dataset components to their header positions
	 */
	Map<String, Integer> getComponentPositionMap();
}
