package io.sdmx.core.sdmx.engine.data;

import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.model.data.InMemoryDatasetContainer;
import io.sdmx.core.sdmx.test.DataReaderEqualityUtil;

/**
 * Proxies a Data Writer to record the data written, which can then be used to assert the contents of 
 * a Data Reader Engine
 */
public class DataWriterAssertionProxy extends DataWriterEngineProxy {
	private InMemoryDataWriterEngine inMemoryDWE = new InMemoryDataWriterEngine();
	
	public DataWriterAssertionProxy(ISeriesObsDataWriterEngine dwe) {
		super(dwe);
	}

	@Override
	public void writeHeader(HeaderBean header) {
		super.writeHeader(header);
		inMemoryDWE.writeHeader(header);
	}
	
	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		super.startDataset(structures, header, datasetAttributes, annotations);
		inMemoryDWE.startDataset(structures, header, datasetAttributes, annotations);
	}
	

	public InMemoryDatasetContainer getDatasetContainer() {
		return inMemoryDWE.getDatasetContainer();
	}

	@Override
	public void writeKey(Keyable key) {
		super.writeKey(key);
		inMemoryDWE.writeKey(key);
	}

	@Override
	public void writeObservation(Observation obs) {
		super.writeObservation(obs);
		inMemoryDWE.writeObservation(obs);
	}
	
	/**
	 * Asserts the contents of the data reader engine match what was written to the writer
	 */
	public void assertReader(DataReaderEngine dre) {
		DataReaderEngine inMemoryDRE = new DatasetStoreDataReaderEngine(getDatasetContainer());
		DataReaderEqualityUtil.assertEquals(dre, inMemoryDRE);
	}
}
