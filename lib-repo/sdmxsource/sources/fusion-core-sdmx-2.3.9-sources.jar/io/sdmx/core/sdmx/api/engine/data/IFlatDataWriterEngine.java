package io.sdmx.core.sdmx.api.engine.data;

import io.sdmx.core.sdmx.api.model.data.IDataRow;
import io.sdmx.api.sdmx.engine.WriterEngine;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;

/**
 * Treats data as columnar, flattened, not grouped by anything.  Example
 * 
 * FREQ, RE_AREA, BIRTHS, DEATHS, MARRIAGES
 */
public interface IFlatDataWriterEngine extends WriterEngine {

	/**
	 * Starts a dataset with the data conforming to the DSD.
	 * 
	 * @param provision agreement (optional)   The provision agreement can be provided to give extra information about the dataset
	 * @param dataflow (optional) The dataflow can be provided to give extra information about the dataset
	 * @param dataStructureBean (mandatory) the data structure is used to know the dimensionality of the data
	 * @param header (optional) containing, amongst others, the dataset action, reporting dates, dimension at observation if null then the dimension at observation is 
	 * assumed to be TIME_PERIOD and the dataset action is assumed to be INFORMATION
	 * @param  columnOrder sets the column order for the writer
	 * @param annotations (optional) any additional annotations that are attached to the dataset, can be null if no annotations exist
	 * @throws IllegalArgumentException if the dataStructureBean is null
	 */
	void startDataset(DatasetHeaderBean header, AnnotationBean...annotations);
	
	/**
	 * Writes a row of data, passed in map should not be expected to be immutable, and as such is subject to change after this method is returned
	 * @param values
	 */
	void writeRow(IDataRow row);
	
	/**
	 * Closes the writer
	 */
	void close();
}
