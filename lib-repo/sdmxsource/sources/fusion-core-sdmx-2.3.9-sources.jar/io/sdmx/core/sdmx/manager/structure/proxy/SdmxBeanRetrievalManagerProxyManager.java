package io.sdmx.core.sdmx.manager.structure.proxy;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;

public class SdmxBeanRetrievalManagerProxyManager {
	private SdmxBeanRetrievalManagerProxy proxy;
	
	public SdmxBeanRetrievalManagerProxyManager(SdmxBeanRetrievalManagerProxy proxy) {
		this.proxy = proxy;
	}

	public void setProxy(SdmxBeanRetrievalManager proxy) {
		this.proxy.setProxy(proxy);
	}
	
	
}
