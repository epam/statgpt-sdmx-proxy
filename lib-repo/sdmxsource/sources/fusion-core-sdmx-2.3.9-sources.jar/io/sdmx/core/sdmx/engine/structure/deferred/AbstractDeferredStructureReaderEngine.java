package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.core.sdmx.api.engine.structure.IDeferredStructureReaderEngine;
import io.sdmx.utils.sdmx.structure.StructureTypes;

/**
 * Subclassed by concrete maintainable types. Converts a IDeferredBeanDefinition into a IMaintainableBeanDeferred of the correct concrete type.
 * This class allows processes to operate and an abstract level, where they have the {@link MaintainableBean} and want to convert to a deferred instance
 * with a
 * 
 * @param <T>
 */
public abstract class AbstractDeferredStructureReaderEngine<T extends MaintainableBean> implements IDeferredStructureReaderEngine<T> {
    private IMaintainableStructureType<T> type;
    
    public AbstractDeferredStructureReaderEngine(Class<T> type) {
        this.type = StructureTypes.getMaintStructureType(type);
    }
    
    @Override
    public final IMaintainableBeanDeferred<T> read(IDeferredBeanDefinition deferred, IDeferredLoader<MaintainableBean> loader) {
        if(!deferred.getUrn().getStructureType().equals(type)) {
            throw new IllegalArgumentException(this.getClass().getCanonicalName() + " can not read deferred bean of type:"+deferred.getUrn().getStructureType().getFullyQualifiedClass());
        }
        return readInternal(deferred, loader);
    }

    @Override
    public IMaintainableStructureType<T> getSupportedType() {
        return type;
    }
    
    protected abstract IMaintainableBeanDeferred<T> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader);

}
