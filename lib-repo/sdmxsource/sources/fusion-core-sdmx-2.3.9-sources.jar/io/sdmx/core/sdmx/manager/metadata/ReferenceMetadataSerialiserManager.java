package io.sdmx.core.sdmx.manager.metadata;

import java.io.InputStream;
import java.io.OutputStream;

import io.sdmx.api.io.IObjectSerialiser;
import io.sdmx.api.sdmx.manager.output.IMetadataWriterManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.core.sdmx.api.manager.metadata.IReferenceMetadataReaderManager;
import io.sdmx.utils.core.io.InMemoryReadableDataLocation;

/**
 * Writes and reads reference metadata from a specific format for object serialisation
 */
public class ReferenceMetadataSerialiserManager implements IObjectSerialiser<MaintainableBean> {
	private IMetadataWriterManager metadataWriterManager;
	private IReferenceMetadataReaderManager metadataReaderManager;
	private IMetadataFormat backupFormat;
	private String id;

	public ReferenceMetadataSerialiserManager(String id, IMetadataWriterManager metadataWriterManager, 
											  IReferenceMetadataReaderManager metadataReaderManager, 
											  IMetadataFormat backupFormat) {
		this.id = id;
		this.metadataWriterManager = metadataWriterManager;
		this.metadataReaderManager = metadataReaderManager;
		this.backupFormat = backupFormat;
	}
	
	@Override
	public String getId() {
		return id;
	}
	
	@Override
	public void write(MaintainableBean object, OutputStream out) {
		metadataWriterManager.write(object, backupFormat, out);
	}

	@Override
	public IReportedMetadataSetBean read(InputStream stream) {
		IReferenceMetadataContainer container = metadataReaderManager.parse(new InMemoryReadableDataLocation(stream));
		if(container == null || container.getReferenceMetadata().size() == 0) {
			return null;
		}
		IReportedMetadataSetBean rebuilt = (IReportedMetadataSetBean) container.getReferenceMetadata().toArray()[0];
		return rebuilt;
	}
}
