package io.sdmx.core.sdmx.engine.data;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Attributable;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Rolls down Keyable/Observation data to call the proxy DataWriterEngine API 
 */
public class RolldownDataWriterEngine implements ISeriesObsDataWriterEngine {
	private DataWriterEngine dwe;

	public RolldownDataWriterEngine(DataWriterEngine dwe) {
		ObjectUtil.assertNotNull("DataWriterEngine required", dwe);
		this.dwe = dwe;
	}

	@Override
	public void writeHeader(HeaderBean header) {
		dwe.writeHeader(header);
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		dwe.startDataset(structures.getProvisionAgreement(), structures.getDataflow(), structures.getDataStructure(), header, annotations);
		writeDatasetAttributes(datasetAttributes);
	}

	private void writeDatasetAttributes(IDatasetAttributes datasetAttributes) {
		if(datasetAttributes != null) {
			writeAttributes(datasetAttributes.getAttributes());
			writeMultilingualAttributes(datasetAttributes.getMultilingualAttributes());
		}
	}
	
	@Override
	public void writeKey(Keyable key) {
		if(key.isSeries()) {
			if(key.getAnnotations().size() > 0) {
				dwe.startSeries(key.getAnnotations().toArray(new AnnotationBean[key.getAnnotations().size()]));
			} else {
				dwe.startSeries();
			}
			for(KeyValue kv : key.getKey()) {
				if(kv.getCode() != null) {
					dwe.writeSeriesKeyValue(kv.getConcept(), kv.getCode());
				}
			}
		} else {
			if(key.getAnnotations().size() > 0) {
				dwe.startGroup(key.getGroupName(), toArray(key.getAnnotations()));
			} else {
				dwe.startGroup(key.getGroupName());
			}
			for(KeyValue kv : key.getKey()) {
				if(kv.getCode() != null) {
					dwe.writeGroupKeyValue(kv.getConcept(), kv.getCode());
				}
			}
		}
		writeAttributable(key);
	}
	
	private void writeAttributable(Attributable attributable)  {
		writeAttributes(attributable.getAttributes());
		writeMultilingualAttributes(attributable.getMultilingualAttributes());
	}
	
	
	private void writeAttributes(List<KeyValue> attributes) {
		List<KeyValue> multivalueAttributes = new ArrayList<>();
		if(attributes != null) {
			for(KeyValue attr : attributes) {
				if(attr.getValues() != null){
					multivalueAttributes.add(attr);
					continue;
				}
				String codeVal = attr.getCode() == null ? "" : attr.getCode();
				dwe.writeAttributeValue(attr.getConcept(), codeVal);
			}
			for(KeyValue multiValueAttr : multivalueAttributes){
				dwe.writeAttributeValue(multiValueAttr.getConcept(), multiValueAttr.getValues().toArray(new String[0]));
			}
		}
	}

	private void writeMultilingualAttributes(List<IMultilingualKeyValue> complexAttributes) {
		if(complexAttributes != null) {
			for(IMultilingualKeyValue complexAttribute : complexAttributes) {
				dwe.writeMultilingualAttributeValue(complexAttribute);
			}
		}
	}

	@Override
	public void writeObservation(Observation obs) {
		if(obs.getAnnotations().size() > 0) {
			dwe.writeObservation(obs.getDimensionId(), obs.getDimensionValue(), obs.getMeasures(), toArray(obs.getAnnotations()));
		} else {
			dwe.writeObservation(obs.getDimensionId(), obs.getDimensionValue(), obs.getMeasures());
		}
		writeMultilingualAttributes(obs.getMultilingualMeasures());
		writeAttributable(obs);
	}
	
	private AnnotationBean[] toArray(List<AnnotationBean> annotations) {
		return annotations.toArray(new AnnotationBean[annotations.size()]);
	}

	@Override
	public void close(FooterMessage... footer) {
		dwe.close(footer);
	}

}
