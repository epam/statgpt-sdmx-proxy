package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.im.beans.transformation.CustomTypeSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link CustomTypeSchemeBeanDeferred}
 */
public class DeferredCustomTypeSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<ICustomTypeSchemeBean> {
    private static DeferredCustomTypeSchemeReaderEngine INSTANCE;
    
    private DeferredCustomTypeSchemeReaderEngine() {
        super(ICustomTypeSchemeBean.class);
    }
    
    public static DeferredCustomTypeSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredCustomTypeSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ICustomTypeSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new CustomTypeSchemeBeanDeferred(bean, loader);
    }

}
