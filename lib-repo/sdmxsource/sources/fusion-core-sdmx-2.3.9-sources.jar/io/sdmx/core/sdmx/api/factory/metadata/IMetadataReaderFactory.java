package io.sdmx.core.sdmx.api.factory.metadata;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.factory.PriorityFactory;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;

/**
 * Parses reference metadata (in any supported format)  into IReferenceMetadataContainer
 */
public interface IMetadataReaderFactory extends PriorityFactory, IPluggable {
	
	/**
	 * reads a stream of data to return a metadata set
	 * @param rdl containing the stream of data
	 * @return metadata container or null if this factory does not support the provided format
	 * @throws SdmxSemmanticException if the built metadata set has errors
	 */
	IReferenceMetadataContainer parse(ReadableDataLocation rdl);
}
