package io.sdmx.core.sdmx.error;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.error.FusionError;
import io.sdmx.api.sdmx.exception.DataValidationEngineErrorHandler;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.api.error.DataValidationErrorReporter;

public class InMemoryErrorHandler implements DataValidationEngineErrorHandler, DataValidationErrorReporter {
	private Map<FusionError, KeyValue> errors = new HashMap<>();
	private Map<FusionError, IMultilingualKeyValue> errorsComplex = new HashMap<>();
	
	public InMemoryErrorHandler() {}

	@Override
	public void reportError(FusionError fe, KeyValue component) {
		errors.put(fe, component);
	}

	public void reportError(FusionError fe, IMultilingualKeyValue component) {errorsComplex.put(fe, component);}
	
	public boolean hasError() {
		return (errors.size() > 0) || (errorsComplex.size() <0);
	}
	
	public void resetState() {
		if(hasError()) {
			this.errors =  new HashMap<>();
		}
	}

	public Map<FusionError, KeyValue> getErrors() {
		return errors;
	}
	public Map<FusionError, IMultilingualKeyValue> getErrorsComplex(){return errorsComplex;}

	@Override
	public void reportError(FusionError fe, KeyValue component, Observation obs) {
		errors.put(fe, component);
	}

	@Override
	public void reportObsError(FusionError fe, KeyValue component, String... obsShortCode) {
		errors.put(fe, component);
	}

	@Override
	public void reportError(FusionError fe, KeyValue component, Keyable obs) {
		errors.put(fe, component);
	}

	@Override
	public void reportError(FusionError fe, IMultilingualKeyValue component, Keyable key) { errorsComplex.put(fe, component);}

	@Override
	public void reportDatasetAttributeError(FusionError fe, KeyValue attribute) {
		errors.put(fe, attribute);
	}
	
}
