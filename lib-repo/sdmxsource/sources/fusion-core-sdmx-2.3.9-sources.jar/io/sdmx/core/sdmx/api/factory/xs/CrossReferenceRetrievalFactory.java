package io.sdmx.core.sdmx.api.factory.xs;

import java.util.Set;

import io.sdmx.api.plugin.IPluggable;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.utils.sdmx.xs.IndirectReferenceBean;
import io.sdmx.utils.sdmx.xs.WeakReferenceBean;

/**
 * To support the use case where cross references can not be fully determined from a MaintainableBean (IndirectReferenceBean) or where the reference 
 * can only be derived by applying a pattern matching rule against a target structure (i.e. a regular expression against a list of Codes).  The former is an indirect
 * reference, the latter is a weak reference.
 * 
 * An example of an indirect reference is a Constraint which constrains REF_AREA to UK but references a Dataflow - it is not possible to know what codelist UK belongs to without
 * first getting the DSD and then the Codelist.  The Constraint indirectly references UK and is unable to provide UK as a {@link ICrossReferenceBean} via the maintBean.getCrossReferences() method.  
 * The system can only determine what Codelist UK lives in by getting additional MaintainableBeans.
 * 
 * @see IndirectReferenceBean
 * @see WeakReferenceBean
 */
public interface CrossReferenceRetrievalFactory extends IPluggable {

	/**
	 * @return the structure that this factory reports cross references for
	 */
	Class<? extends MaintainableBean> getSupportedType();
	
	/**
	 * @param retrievalManager - to help find indirect or weak cross references
	 * @param maintBean - to obtain all cross references for
	 * @return mutable set of cross references in addition to those which are obtained from the maintBean.getCrossReferences() method
	 */
	Set<ICrossReferenceBean<?>> getIndirectReferences(SdmxBeanRetrievalManager retrievalManager, 
													  MaintainableBean maintBean);
}
