package io.sdmx.core.sdmx.engine.metadata;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IMetadatasetStructures;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;

/**
 * Validates the agency of the metadata set is a Metadata Provider ID if reported against a Provision Agreement
 */
public class MetadataAgencyValidationEngine extends AbstractMetadataValidationEngine {
	
	public MetadataAgencyValidationEngine(SdmxBeanRetrievalManager beanRetrievalManager) {
		super(beanRetrievalManager);
	}

	@Override
	protected void validate(IReportedMetadataSetBean mds, IMetadatasetStructures mdsStructures) {
		MetadataProvisionAgreementBean mpa = mdsStructures.getProvisionAgreement();
		
		if(mpa != null) {
			String providerId = mpa.getMetadataProviderRef().getReference().getFullIdentifiableId();
			String providerAgency = mpa.getMetadataProviderRef().getReference().getAgencyId();
			String providerFullId = providerAgency.equals("SDMX") ? providerId : providerAgency+"."+providerId;
			if(!mds.getAgencyId().equals(providerFullId)) {
				throw new SdmxSemmanticException("Metadata Set '"+mds.getShortURN()+"' must have an Agency ID of '"+providerFullId+"' to match the Metadata Data Provider ID of the Provision Agreement");
			}
		}
	}
	
 }
