package io.sdmx.core.sdmx.api.model.mvstore;

import org.h2.mvstore.MVStore;

public interface IMVStore {
	
	/**
	 * @return the store	
	 */
	MVStore getStore();

	/**
	 * Closes the store, does not delete the resources
	 */
	void close();
	
	/**
	 * Deletes the MV Store and all resources
	 */
	void delete();
	
}
