package io.sdmx.core.sdmx.manager.structure;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class CrossReferenceRetrievalMananger implements CrossReferencedRetrievalManager, CrossReferencingRetrievalManager, IURNRetrievalManager {
	private IURNRetrievalManager urnRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private IURNReferenceRetreivalManager urnReferenceRetreivalManager;  //TODO can this be a link back to the database to find only the references for 1 maint as and when required?
	
	public CrossReferenceRetrievalMananger(IURNRetrievalManager urnRetrievalManager,
										   SdmxBeanRetrievalManager beanRetrievalManager, 
										   IURNReferenceRetreivalManager urnReferenceRetreivalManager) {
		this.urnRetrievalManager = urnRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
		this.urnReferenceRetreivalManager = urnReferenceRetreivalManager;
	}

	
	@Override
	public Set<IURNMaintainable<?>> find(IURN<?> urn) {
		return urnRetrievalManager.find(urn);
	}

	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURN<?> sourceStructureURN, boolean includeIndirectReferences, Class<T> structures) {
		boolean includeWeak = true;  //TODO
		Set<IURNMaintainable<?>> resolvedURNs = new HashSet<>();
		toAbsolute(sourceStructureURN).forEach(urnAbsolute -> {
			Set<IURNMaintainable<?>> referencedBy = urnReferenceRetreivalManager.whoReferencesMe(urnAbsolute, includeIndirectReferences, includeWeak);
			resolvedURNs.addAll(referencedBy);
		});
		return runFilter(resolvedURNs, structures);
	}

	
	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencedStructures(IURN<?> sourceStructureURN,
																			boolean includeIndirectReferences, 
																			boolean fullTreeResolution, 
																			Class<T> structuresOfType) {
		//Resolve the source URN into a set of absolute URNs
		boolean includeWeak = true;  //TODO
		
		Set<IURNMaintainable<?>> resolvedURNs = new HashSet<>();
		toAbsolute(sourceStructureURN).forEach(urnAbsolute -> {
			Set<IURNMaintainable<?>> references = urnReferenceRetreivalManager.whoDoIReference(urnAbsolute, includeIndirectReferences, includeWeak);
			resolvedURNs.addAll(references);
		});
		if(fullTreeResolution) {
			resolveDescendants(resolvedURNs, includeIndirectReferences, includeWeak);
		}
		return runFilter(resolvedURNs, structuresOfType);
	}
	
	/**
	 * Converts a URN (which may be absolute, semantic, or wildcard) to a set of absolute URNs
	 * @param structureURN
	 * @return
	 */
	private Set<IURNAbsolute<?>> toAbsolute(IURN<?> structureURN) {
		Set<IURNAbsolute<?>> absolute = new HashSet<>();
		if(structureURN.getReferenceType() == REFERENCE_TYPE.ABSOLUTE) {
			absolute.add(structureURN.asAbsolute());
		} else {
			Set<IURNMaintainable<?>> resolvedAbsoluteMaint = urnRetrievalManager.find(structureURN); 
			if(resolvedAbsoluteMaint != null) {
				if(structureURN.isMaintainableReference()) {
					absolute.addAll(resolvedAbsoluteMaint);
				} else {
					resolvedAbsoluteMaint.forEach(urnMaintAbsolute -> {
						absolute.add(urnMaintAbsolute.toIdentifiable(structureURN.getStructureClass(), structureURN.getFullIdentifiableId().split("\\.")));
					});
				}
			}
		}
		return absolute;
	}
	
	/**
	 * resolves all the descendants of the resolvedReferences
	 * @param <T>
	 * @param resolvedReferences URNs to find descendants of
	 * @param includeIndirectReferences
	 * @param includeWeak
	 * @param structuresOfType optional filter (only return structures of  type)
	 */
	private <T extends MaintainableBean> void resolveDescendants(Set<IURNMaintainable<?>> resolvedReferences, 
																 boolean includeIndirectReferences, 
																 boolean includeWeak) {
		//keep walking down the tree until all the references are resolved
		Set<IURNMaintainable<?>> newSet = new HashSet<>(resolvedReferences);
		while(newSet.size() > 0) {
			Set<IURNMaintainable<?>> nextNewSet = new HashSet<>();
			newSet.forEach(urnAbsolute -> {
				Set<IURNMaintainable<?>> references = urnReferenceRetreivalManager.whoDoIReference(urnAbsolute, includeIndirectReferences, includeWeak);
				references.forEach(urn-> {
					if(!resolvedReferences.contains(urn)) {
						nextNewSet.add(urn);
						resolvedReferences.add(urn);
					}
				});
			});
			newSet = nextNewSet;
		}
	}

	private <T extends MaintainableBean> Set<IURNMaintainable<?>> filterUrns(Set<IURNMaintainable<?>> urns, Class<T> filter) {
		if(filter != null) {
			urns = urns.stream().filter(e-> filter.isAssignableFrom(e.getStructureClass())).collect(Collectors.toSet());
		}
		return urns;
	}
	
	private <T extends MaintainableBean> Set<T> runFilter(Set<IURNMaintainable<?>> urns, Class<T> filter) {
		urns = filterUrns(urns, filter);
		final Set<T> returnSet = new HashSet<>(urns.size());
		urns.forEach(urn-> {
			MaintainableBean maint = beanRetrievalManager.getBean(urn);
			if(maint != null) {
				returnSet.add((T)maint);
			}
		});
		return returnSet;
	}
	
}
