package io.sdmx.core.sdmx.engine.structure;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;

public abstract class AbstractStructureWriterEngine implements StructureWriterEngine {

	private Set<SDMX_STRUCTURE_TYPE> supportedTypes;

	public AbstractStructureWriterEngine(boolean include, SDMX_STRUCTURE_TYPE... types) {
		if(types != null) {
			Set<SDMX_STRUCTURE_TYPE> supportedTypes = new HashSet<>();
			for(SDMX_STRUCTURE_TYPE st : types) {
				supportedTypes.add(st);
			}
			createSupportedTypes(include, supportedTypes);
		}
	}

	public AbstractStructureWriterEngine(boolean include, Collection<SDMX_STRUCTURE_TYPE> types) {
		createSupportedTypes(include, types);
	}

	protected void createSupportedTypes(boolean include, Collection<SDMX_STRUCTURE_TYPE> types) {
		supportedTypes = new HashSet<>();
		if(include) {
			supportedTypes.addAll(types);
		} else {
			supportedTypes = SDMX_STRUCTURE_TYPE.getMaintainableStructureTypes().stream().filter(maintType -> !types.contains(maintType)).collect(Collectors.toSet());
		}
		this.supportedTypes = Collections.unmodifiableSet(supportedTypes);
	}

	@Override
	public Set<SDMX_STRUCTURE_TYPE> getSupportedTypes() {
		return supportedTypes;
	}

	@Override
	public boolean isSupportedType(MaintainableBean structureType) {
		if(structureType == null) {
			return false;
		}
		return getSupportedTypes().contains(structureType.getStructureType());
	}
}
