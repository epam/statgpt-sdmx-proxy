package io.sdmx.core.sdmx.engine.structure.deferred;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.im.beans.base.OrganisationUnitSchemeBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link OrganisationUnitSchemeBeanDeferred}
 */
public class DeferredOrganisationUnitSchemeReaderEngine extends AbstractDeferredStructureReaderEngine<OrganisationUnitSchemeBean> {
    private static DeferredOrganisationUnitSchemeReaderEngine INSTANCE;
    
    private DeferredOrganisationUnitSchemeReaderEngine() {
        super(OrganisationUnitSchemeBean.class);
    }
    
    public static DeferredOrganisationUnitSchemeReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredOrganisationUnitSchemeReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<OrganisationUnitSchemeBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new OrganisationUnitSchemeBeanDeferred(bean, loader);
    }

}
