package io.sdmx.core.sdmx.error;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.core.sdmx.api.error.DataError;
import io.sdmx.api.sdmx.exception.ErrorLimitException;

public class ReportedErrors {
	private Map<String, List<DataError>> categorisedErrors = new HashMap<>();  //Factory Id to Errors
	private List<String> uncategorisedErrors = new ArrayList<>();			   //Format specific errors
	
//	private Map<DataValidationErrorType, Set<ValidationError>> errors = new HashMap<>();
	
	
	public void handleException(Throwable ex) throws ErrorLimitException {
		uncategorisedErrors.add(ex.getMessage());
	}
	
	public void handleDataError(DataError dataError) {
		String errorCategory = dataError.getErrorCategory();
		List<DataError> errors = categorisedErrors.get(errorCategory);
		if(errors == null) {
			errors = new ArrayList<>();
			categorisedErrors.put(errorCategory, errors);
		}
		errors.add(dataError);
	}
	
	/**
	 * Returns a list of data errors for the given category, or an empty list if none exist
	 * @param category
	 * @return
	 */
	public List<DataError> getCategorisedErrors(String category) {
		List<DataError> returnErrors = categorisedErrors.get(category);
		if(returnErrors == null) {
			return new ArrayList<>();
		}
		return returnErrors;
	}
	
	public Map<String, List<DataError>> getCategorisedErrors() {
		return categorisedErrors;
	}

	public List<String> getUncategorisedErrors() {
		return uncategorisedErrors;
	}

//	public void addError(ValidationError err) {
//		DataValidationErrorType category = err.getErrorType();
//		Set<ValidationError> validationErrorSet = errors.get(category);
//		if(validationErrorSet == null) {
//			validationErrorSet = new HashSet<>();
//			errors.put(category, validationErrorSet);
//		} 
//		for (ValidationError validationError : validationErrorSet) {
//			
//			if (err.getMessage().equals(validationError.getMessage())) {
//				if (err.getReportedValue() == null) {
//					if (validationError.getReportedValue() == null) {
//						for (String aLoc : err.getKeys()) {
//							validationError.addKey(aLoc);
//						}
//						return;
//					}
//				} else if (err.getReportedValue().equals(validationError.getReportedValue())) {
//					for (String aLoc : err.getKeys()) {
//						validationError.addKey(aLoc);
//					}
//					return;
//				}
//			}
//					
//		}
//		validationErrorSet.add(err);
//	}
}
