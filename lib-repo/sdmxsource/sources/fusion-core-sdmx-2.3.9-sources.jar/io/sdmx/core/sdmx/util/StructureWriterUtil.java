package io.sdmx.core.sdmx.util;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.im.beans.container.SdmxBeansImpl;

public class StructureWriterUtil {

	/**
	 * Default implementation of writeStructure, which passes the request on the writeStructures method
	 * @param swe
	 * @param bean
	 * @param additionalLinks
	 * @param out
	 */
	public static void writeStructure(StructureWriterEngine swe, MaintainableBean bean, IExternalMaintainableLinks additionalLinks, OutputStream out) {
		if(!swe.isSupportedType(bean)) {
			throw new SdmxNotImplementedException("Unsupported Format for structure '"+bean.getUrn()+"'");
		}
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(bean);
		Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinksMap = null;
		if(additionalLinks != null) {
			additionalLinksMap = new HashMap<>(1);
			additionalLinksMap.put(additionalLinks.getMaintainableURN(), additionalLinks);
		}
		swe.writeStructures(beans, additionalLinksMap, out);
	}
}
