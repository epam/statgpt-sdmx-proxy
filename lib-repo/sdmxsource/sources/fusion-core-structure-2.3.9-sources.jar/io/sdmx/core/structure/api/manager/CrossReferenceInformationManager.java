
package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.CrossReferencingTree;

/**
 * Provides information on which structures cross reference a given structure
 *
 */
public interface CrossReferenceInformationManager {

	
	/**
	 * Returns a tree structure representing the identifiable and all the structures that cross reference it, and the structures that reference them, and so on.
	 * @return
	 */
	CrossReferencingTree getCrossReferenceTree(MaintainableBean maintainableBean);
}
