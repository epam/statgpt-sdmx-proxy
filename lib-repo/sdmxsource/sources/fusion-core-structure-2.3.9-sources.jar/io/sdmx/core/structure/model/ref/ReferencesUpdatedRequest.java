package io.sdmx.core.structure.model.ref;

import java.util.Collections;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.modify.IReferencesUpdatedRequest;

public class ReferencesUpdatedRequest implements IReferencesUpdatedRequest {
	private MaintainableBean sourceMaintainable;
	private MaintainableBean modifiedMaintainable;
	private Map<StructureReferenceBean, StructureReferenceBean> modifiedReferences;

	public ReferencesUpdatedRequest(MaintainableBean sourceMaintainable, MaintainableBean modifiedMaintainable,
			Map<StructureReferenceBean, StructureReferenceBean> modifiedReferences) {
		this.sourceMaintainable = sourceMaintainable;
		this.modifiedMaintainable = modifiedMaintainable;
		this.modifiedReferences = Collections.unmodifiableMap(modifiedReferences);
	}

	public MaintainableBean getSourceMaintainable() {
		return sourceMaintainable;
	}


	public MaintainableBean getModifiedMaintainable() {
		return modifiedMaintainable;
	}


	public Map<StructureReferenceBean, StructureReferenceBean> getModifiedReferences() {
		return modifiedReferences;
	}
}
