package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.core.sdmx.manager.structure.MultipleBeanRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.proxy.SdmxBeanRetrievalManagerProxy;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * This class wraps an underlying bean retrieval manager which is the link to the persisted beans, 
 * in addition beans which have not been persisted can be set on here which allows the returned structures
 * to come from either the non-persisted store (checked first) or persisted store (checked second)
 */
public class UnpersistedBeanRetreivalManager extends SdmxBeanRetrievalManagerProxy {
	private static final String THREAD_KEY = "unpersisted";
	
	public UnpersistedBeanRetreivalManager(SdmxBeanRetrievalManager retrievalManager) {
		super(retrievalManager);
	}

	/**
	 * Stores un-persited beans, any calls to get structures on this thread will first check the unpersisted bean store followed
	 * by the persisted bean store
	 * @param beans
	 */
	public void setUnPersisted(SdmxBeans beans) {
		clearUnPersisted();
		MultipleBeanRetrievalManager brm = new MultipleBeanRetrievalManager(beans, getProxy());
		ThreadLocalUtil.storeOnThread(THREAD_KEY, brm);
	}
	
	/**
	 * Clears un-persisted beans from this thread
	 */
	public void clearUnPersisted() {
		ThreadLocalUtil.clearFromThread(THREAD_KEY);
	}
	


	@Override
	protected SdmxBeanRetrievalManager getProxy() {
		if(ThreadLocalUtil.contains(THREAD_KEY)) {
			return (SdmxBeanRetrievalManager) ThreadLocalUtil.retrieveFromThread(THREAD_KEY);
		}
		return super.getProxy();
	}
}
