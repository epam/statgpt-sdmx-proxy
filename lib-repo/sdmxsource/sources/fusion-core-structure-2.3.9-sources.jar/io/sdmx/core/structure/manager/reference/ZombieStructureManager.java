package io.sdmx.core.structure.manager.reference;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.dao.maintainable.ISdmxBeansDao;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.sdmx.api.manager.structure.ServiceRetrievalManager;
import io.sdmx.core.structure.api.manager.IZombieStructureManager;
import io.sdmx.core.structure.manager.retrieval.StructureStoreRetrievalManager;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.SingletonStore;

public class ZombieStructureManager implements IZombieStructureManager, ApplicationStartupAware {
	
	private StructureWriterManager structureWriterManager = SingletonStore.getSingleton(StructureWriterManager.class);
	private ServiceRetrievalManager serviceRetrievalManager = SingletonStore.getSingleton(ServiceRetrievalManager.class);
	private ISdmxBeansDao dao;
	
	private SdmxBeans zombieStructures = new SdmxBeansImpl();
	
	public ZombieStructureManager(ISdmxBeansDao structureDao) {
		this.dao = structureDao;
		SingletonStore.registerInstance(this);
	}

	@Override
	public void applicationRestarting() {}

	@Override
	public void applicationStarted() {
		SdmxBeans zombieRegistrations = new SdmxBeansImpl(DATASET_ACTION.DELETE);
		boolean hasZombieRegistrations = false;
		for(RegistrationBean reg : zombieStructures.getRegistrations()) {
			zombieRegistrations.addIdentifiable(reg);
			hasZombieRegistrations = true;
		}
		if(hasZombieRegistrations) {
			dao.saveBeans(zombieRegistrations);
		}
	}

	@Override
	public Class[] getDependsOn() {
		return new Class[] {StructureStoreRetrievalManager.class};
	}

	@Override
	public void registerZombies(SdmxBeans zombies) {
		zombieStructures.merge(zombies);
	}

	@Override
	public void writeStructures(OutputStream out, boolean asStub, StructureFormat format) {
		if(asStub) {
			SdmxBeans stubBeans = new SdmxBeansImpl();
			for(MaintainableBean maint : zombieStructures.getAllMaintainables()) {
				stubBeans.addIdentifiable(serviceRetrievalManager.createStub(maint, false));
			}
			structureWriterManager.writeStructures(stubBeans, format, out);
		} else {
			structureWriterManager.writeStructures(zombieStructures, format, out);
		}
	}

	@Override
	public void removeStructures(Set<String> urns) {
		SdmxBeans toRemove = new SdmxBeansImpl(DATASET_ACTION.DELETE);
		for(MaintainableBean maint : zombieStructures.getAllMaintainables()) {
			if(urns.contains(maint.getUrn())) {
				toRemove.addIdentifiable(maint);
			}
		}
		for(MaintainableBean maint : toRemove.getAllMaintainables()) {
			zombieStructures.removeMaintainable(maint);
		}
		dao.saveBeans(toRemove);
	}
	
	@Override
	public void removeAllStructures() {
		SdmxBeans toRemove = new SdmxBeansImpl(zombieStructures);
		toRemove.setAction(DATASET_ACTION.DELETE);
		zombieStructures = new SdmxBeansImpl();
		dao.saveBeans(toRemove);
	}
}
