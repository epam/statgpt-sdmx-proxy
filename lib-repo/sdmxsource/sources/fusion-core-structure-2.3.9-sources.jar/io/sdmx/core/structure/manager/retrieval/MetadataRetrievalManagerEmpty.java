package io.sdmx.core.structure.manager.retrieval;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.structure.api.manager.IMetadataRetrievalManager;

/**
 * Empty instance has no reference metadata
 */
public class MetadataRetrievalManagerEmpty implements IMetadataRetrievalManager {
    public static final IMetadataRetrievalManager INSTANCE = new MetadataRetrievalManagerEmpty();
    
    @Override
    public IReportedMetadataSetBean getMetadata(IURNMaintainable<IReportedMetadataSetBean> ref, SdmxDate asOf) {
        return null;
    }

    @Override
    public Set<IReportedMetadataSetBean> findByMetadataSet(IURN<IReportedMetadataSetBean> ref, SdmxDate asOf) {
        return Collections.emptySet();
    }

    @Override
    public Set<IReportedMetadataSetBean> findByMetadataflow(IURN<MetadataFlowBean> ref,
            IURN<IMetadataProviderBean> providerRef, SdmxDate asOf) {
        return Collections.emptySet();
    }

    @Override
    public Set<IReportedMetadataSetBean> findByStructure(IURN<?> urn, SdmxDate asOf) {
        return Collections.emptySet();
    }

}
