package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;

/**
 * Resolves who references a structure by querying for all structure types that could reference a structure
 */
public class BeanRetrievalCrossReferencingRetrievalManager { //implements CrossReferencingRetrievalManager {

	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public BeanRetrievalCrossReferencingRetrievalManager(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

//	@Override
//	public Set<MaintainableBean> getCrossReferencingStructures(IdentifiableBean identifiable, boolean includeIndirectReferences, SDMX_STRUCTURE_TYPE... structures) {
//		return getCrossReferencingStructures(identifiable.asReference(), includeIndirectReferences, structures);
//	}
//
//	@Override
//	public Set<MaintainableBean> getCrossReferencingStructures(StructureReferenceBean structureReference, boolean includeIndirectReferences, SDMX_STRUCTURE_TYPE... structures) {
//		Set<MaintainableBean> returnSet = new HashSet<>();
//		Set<SDMX_STRUCTURE_TYPE> includeTypes = new HashSet<>();
//		if(structures != null) {
//			for(SDMX_STRUCTURE_TYPE type : structures) {
//				includeTypes.add(type);
//			}
//		}
//		resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.CATEGORISATION, includeTypes, returnSet);
//		resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.PROCESS, includeTypes, returnSet);
//		switch(structureReference.getMaintainableStructureType()) {
//		case CONCEPT_SCHEME :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.DSD, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.MSD, includeTypes, returnSet);
//			break;
//		case CODE_LIST :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.DSD, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.MSD, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP, includeTypes, returnSet);
//			break;
//		case CATEGORY_SCHEME :
//			break;
//		case DSD :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.DATAFLOW, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, includeTypes, returnSet);
//			break;
//		case DATAFLOW :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, includeTypes, returnSet);
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, includeTypes, returnSet);
//			break;
//		case DATA_PROVIDER_SCHEME :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, includeTypes, returnSet);
//			break;
//		case PROVISION_AGREEMENT :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.REGISTRATION, includeTypes, returnSet);
//			break;
//		case MSD :
//			resolveReferences(structureReference, SDMX_STRUCTURE_TYPE.METADATA_FLOW, includeTypes, returnSet);
//			break;
//		}
//		return returnSet;
//	}
//
//	private void resolveReferences(StructureReferenceBean referenceTo, SDMX_STRUCTURE_TYPE type, Set<SDMX_STRUCTURE_TYPE> includeTypes, Set<MaintainableBean> returnSet) {
//		if(includeTypes.size() > 0 && !includeTypes.contains(type)) {
//			return;
//		}
//		for(MaintainableBean maint : beanRetrievalManager.getMaintainableBeans(type.getMaintainableInterface())) {
//			if(maint.getCrossReferences().contains(referenceTo)) {  //Only works off complete reference
//				//Match!
//				returnSet.add(maint);
//			}
//		}
//	}
}
