package io.sdmx.core.structure.manager.constraint;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.core.structure.api.manager.CommonDimenisonRetrievalManager;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class CommonDimenisonRetrievalManagerImpl implements CommonDimenisonRetrievalManager {

	private SdmxBeanRetrievalManager beanRetrievalManager;

	public CommonDimenisonRetrievalManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	@Override
	public Set<ComponentBean> getCommonComponentsForQuery(Set<IMaintainableRef> dsdReferecnes) {
		Set<DataStructureBean> dsds = new HashSet<>();
		for(IMaintainableRef currentRef : dsdReferecnes) {
			dsds.addAll(beanRetrievalManager.getMaintainableBeans(URN.builder().maint(currentRef).build(DataStructureBean.class)));
		}
		Set<ComponentBean> returnSet = new HashSet<>();

		if(dsds.size() > 0) {
			DataStructureBean firstDsd = (DataStructureBean)dsds.toArray()[0];
			returnSet.addAll(firstDsd.getComponents());
			dsds.remove(firstDsd);
			if(dsds.size() > 0) {
				Set<ComponentBean> removeSet = new HashSet<>();

				outer:
				for(ComponentBean currentComponent : returnSet) {
					for(DataStructureBean currentDsd : dsds) {
						if(!verifyComponentInclusion(currentComponent, currentDsd, removeSet)) {
							if(removeSet.size() == returnSet.size()) {
								break outer;
							}
						}
					}
				}
				returnSet.removeAll(removeSet);
			}
		}
		return returnSet;
	}

	private boolean verifyComponentInclusion(ComponentBean currentComponent, DataStructureBean dsd, Set<ComponentBean> removeSet) {
		ComponentBean compareComponent = dsd.getComponent(currentComponent.getId());
		if(compareComponent == null) {
			removeSet.add(currentComponent);
			return false;
		}
		if(!compareComponent.getConceptRef().equals(compareComponent.getConceptRef())) {
			removeSet.add(currentComponent);
			return false;
		}
		ICrossReferenceBean<? extends EnumeratedListBean> currentCodelistRef = null;
		ICrossReferenceBean<? extends EnumeratedListBean> compareCodelistRef = null;
		
		if(currentComponent.getRepresentation() != null) {
			currentCodelistRef = currentComponent.getRepresentation().getRepresentation();
		}
		if(compareComponent.getRepresentation() != null) {
			compareCodelistRef = compareComponent.getRepresentation().getRepresentation();
		}
		if(!ObjectUtil.equivalent(currentCodelistRef, compareCodelistRef)) {
			removeSet.add(currentComponent);
			return false;
		}
		return true;
	}
	
}
