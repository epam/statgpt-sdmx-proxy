package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Acts as a temporary storage area for beans, allowing them to be held by the Registry until the user either confirms the commit, aborts the commit
 * or they are evicted from the store after a timeout.
 */
public interface StructureConfirmationManager {

    /**
     * Stores the supplied beans in a temporary store, returning the GUID to that reference
     * @param beans
     * @return the GUID
     */
    public String store(SdmxBeans beans);

    /**
     * Confirm the previously submitted item with the specified GUID
     * @param guid the GUID
     */
    public void confirmSubmission(String guid);

    /**
     * Abort the previously submitted item with the specified GUID
     * @param guid the GUID
     */
    public void abortSubmission(String guid);
}
