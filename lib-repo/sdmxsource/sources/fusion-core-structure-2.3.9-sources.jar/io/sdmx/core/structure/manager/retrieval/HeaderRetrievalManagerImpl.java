package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.utils.sdmx.structure.HeaderUtil;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.im.header.HeaderBeanImpl;

/**
 * Returns a basic header with Id, and sender Id
 */
public class HeaderRetrievalManagerImpl implements HeaderRetrievalManager {
	private String senderId = "unknown";
	
	@Override
	public HeaderBean getHeader() {
		return new HeaderBeanImpl(HeaderUtil.generateIREF(), senderId);
	}
	
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
}
