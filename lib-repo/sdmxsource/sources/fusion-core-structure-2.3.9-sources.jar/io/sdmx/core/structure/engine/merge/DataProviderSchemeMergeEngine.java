package io.sdmx.core.structure.engine.merge;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Merges the data providers in the data provider schemes by adding all the items of one scheme, that do not exist in the other, together.
 */
public class DataProviderSchemeMergeEngine implements MaintainableMergeEngine<DataProviderSchemeBean>, IFusionSingleton {
	private static DataProviderSchemeMergeEngine INSTANCE;

	public static DataProviderSchemeMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new DataProviderSchemeMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private DataProviderSchemeMergeEngine() {}

	@Override
	public DataProviderSchemeBean mergeMaintainables(DataProviderSchemeBean maint1, DataProviderSchemeBean maint2) {
		if(maint1 != null && maint2 != null) {
			DataProviderSchemeMutableBean mutableBean = maint1.getMutableInstance();
			for(DataProviderBean currentAgency : maint2.getItems()) {
				if(!maint1.getItems().contains(currentAgency)) {
					mutableBean.addItem(new DataProviderMutableBeanImpl(currentAgency, mutableBean));
				}
			}
			return mutableBean.getImmutableInstance();
		}
		if(maint1 == null) {
			return maint2;
		}
		if(maint2 == null) {
			return maint1;
		}
		return null;
	}
}
