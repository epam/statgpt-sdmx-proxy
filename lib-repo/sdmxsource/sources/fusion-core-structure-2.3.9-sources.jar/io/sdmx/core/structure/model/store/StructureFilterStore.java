package io.sdmx.core.structure.model.store;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.utils.sdmx.structure.MaintainableSDMXStructureType;


public class StructureFilterStore<T> extends AbstractStructureFilterStore<T> {
	private Map<IMaintainableStructureType<?>, StructureTypeFilterStore<T>> structureTypeStoreMap = new HashMap<>();

	public StructureFilterStore() {}
	
	@Override
	public void store(IURN<?> urn, T toStore) {
		IMaintainableStructureType<?> strucutreType = urn.getStructureType().getMaintainableStructureType();
		StructureTypeFilterStore<T> agencyStore = structureTypeStoreMap.get(strucutreType);
		if(agencyStore == null) {
			agencyStore = new StructureTypeFilterStore<>();
			structureTypeStoreMap.put(strucutreType, agencyStore);
		}
		agencyStore.store(urn, toStore);
	}

	@Override
	public Set<T> find(MaintainableBean maint) {
		Set<T> returnSet = new HashSet<>();
		returnSet.addAll(get(maint, structureTypeStoreMap.get(MaintainableSDMXStructureType.ANY)));
		returnSet.addAll(get(maint, structureTypeStoreMap.get(maint.getStructureClass())));
		return Collections.unmodifiableSet(returnSet);
	}
}
