package io.sdmx.core.structure.manager.application;

import java.util.Collections;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.lang.LanguageInformationManager;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansRetreivalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Implements the interface by extracting all the unique languages from the underlying metadata obtained from the SdmxBeansRetreivalManager
 */
public class LanguageInformationManagerImpl implements LanguageInformationManager, IStructureEventListener {

	private SortedSet<String> lang;
	private SdmxBeansRetreivalManager beansRetreivalManager;
	
	public LanguageInformationManagerImpl(SdmxBeansRetreivalManager beansRetreivalManager) {
		this.beansRetreivalManager = beansRetreivalManager;
	}

	@Override
	public Set<String> getSupportedLanguages() {
		if(lang == null) {
			updateLanguages(this.beansRetreivalManager.getSdmxBeans());
		}
		return lang;
	}

	@Override
	public void notifyStructureEvent(IStructureEvent event) {
		if(lang == null || event == null) {
			return;
		}
		updateLanguages(event.getAdditions());
		updateLanguages(event.getModification());
	}

	private void updateLanguages(SdmxBeans... allBeans) {
		SortedSet<String> supportedLanguagesLocal = new TreeSet<>();
		for(SdmxBeans beans : allBeans) {
			for(MaintainableBean maint : beans.getAllMaintainables()) {
				supportedLanguagesLocal.addAll(maint.getLocales());
			}
		}
		if(supportedLanguagesLocal.isEmpty()) {
			supportedLanguagesLocal.add("en");
		}
		lang = Collections.unmodifiableSortedSet(supportedLanguagesLocal);
	}

}
