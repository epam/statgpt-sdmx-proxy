package io.sdmx.core.structure.model.reverseengineer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.reverseengineer.CodedDimensionCoumnDefinition;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;

public class CodedDimensionColumnDefinitionImpl extends ColumnDefinitionImpl implements CodedDimensionCoumnDefinition {
	private IMaintainableRef codelistIds;
	private Integer idColumn;
	private Map<Integer, String> nameColumn;
	private Map<Integer, String> descriptionColumn;
	private ID_GENERATION_STRATEGY idGen;
	
	/**
	 * Package protected constructor, built from JSON:
	 * {
	 * 	 "ID" : "FREQ",
	 *   "Name?" : "ConceptName" //defaults to id of concept
	 *   "Type" : "DIMENSION|ATTRIBUTE|MEASURE",
	 * 	 "Codelist" : {
	 *      "Id?" : "CL_FREQ",    //defaults to concept id prefixed with CL_
	 *      "Agency?" : "ACY",   //defaults to agency of parent
	 *      "Version?" : "1.0"   //defaults to 1.0
	 *      "IdCol" : 0      //Code Id Column
	 *      "NameCol" : {
	 *        "en" : 1
	 *      },
	 *      "DescCol" : {
	 *        "en" : 2
	 *      },
	 *      "IdGeneration" : ID_GENERATION_STRATEGY
	 *   }
	 * }
	 * 
	 */
	public CodedDimensionColumnDefinitionImpl(StructureDiscoveryRules parent, Map<String, Object> jsonMap) {
		super(jsonMap);
		Map codelist = (Map)jsonMap.get("Codelist");
		String clId =  (String)codelist.get("Id");
		if(!ObjectUtil.validString(clId)) {
			clId = "CL_"+this.getConceptId();
		}
		String agencyId = (String)codelist.get("Agency");
		if(!ObjectUtil.validString(agencyId)) {
			agencyId = parent.getAgencyId();
		}
		String version = (String)codelist.get("Version");
		if(!ObjectUtil.validString(version)) {
			version = MaintainableBean.DEFAULT_VERSION;
		}
		this.codelistIds = MaintainableRef.getInstance(agencyId, clId, version);
		this.idColumn = (Integer)codelist.get("IdCol");
		this.nameColumn = readPosLocaleColumns(codelist, "NameCol");
		this.descriptionColumn = readPosLocaleColumns(codelist, "DescCol");
		String idGen = (String)codelist.get("IdGeneration");
		if (idGen != null) {
			this.idGen = ID_GENERATION_STRATEGY.valueOf(idGen);
		}
		validate();
	}
	
	private Map<Integer, String> readPosLocaleColumns(Map json, String property) {
		Map<Integer, String> returnMap = new HashMap<>();
		Map<String, Object> p = (Map<String, Object>)json.get(property);
		if (p == null) {
			return returnMap;
		}
		for (String aKey: p.keySet()) {
			Integer i = (Integer)p.get(aKey);
			returnMap.put(i, aKey);
			returnMap.put((Integer)CollectionUtil.getMapValueEnforcingNotNull(p, aKey), aKey);
		}
		return returnMap;
	}

	@Override
	public IMaintainableRef getCodelistIdentifiers() {
		return codelistIds;
	}

	@Override
	public Integer getIdColumn() {
		return idColumn;
	}

	

	@Override
	public Map<Integer, String> getNameColumn() {
		return nameColumn;
	}

	@Override
	public Map<Integer, String> getDescriptionColumn() {
		return descriptionColumn;
	}

	@Override
	public ID_GENERATION_STRATEGY getIdGenerationStrategy() {
		return idGen;
	}
	
	private void validate() {
		if(idColumn == null) {
			if(idGen == null) {
				throw new SdmxSemmanticException("Coded Column Definition Requires either an Id column or an Id generation strategy");
			}
//			if(idGen != ID_GENERATION_STRATEGY.AUTO_INCREMENT_ALPHA && idGen != ID_GENERATION_STRATEGY.AUTO_INCREMENT_NUMERICAL && !ObjectUtil.validMap(nameColumn)) {
//				throw new SdmxSemmanticException("Coded Column Definition Requires Name Column to assist the ID Generation Strategy of: "+idGen);
//			}
			if(!ObjectUtil.validMap(nameColumn)) {
				throw new SdmxSemmanticException("Coded Column Definition Requires Name Column to assist the ID Generation Strategy of: "+idGen);
			}
		}
		this.descriptionColumn = Collections.unmodifiableMap(this.descriptionColumn);
		this.nameColumn = Collections.unmodifiableMap(this.nameColumn);
	}
}
