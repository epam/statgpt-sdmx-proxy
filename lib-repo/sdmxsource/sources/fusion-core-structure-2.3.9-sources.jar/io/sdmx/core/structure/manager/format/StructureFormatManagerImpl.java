package io.sdmx.core.structure.manager.format;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.IMetadataStandard;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.core.sdmx.manager.format.AbstractFormatManager;
import io.sdmx.core.sdmx.manager.format.InformationFormatManager;

public class StructureFormatManagerImpl extends AbstractFormatManager<StructureFormat> implements StructureFormatManager {
	private Map<IMetadataStandard, StructureFormat> defaultFormats = new HashMap<>();


	public StructureFormatManagerImpl(InformationFormatManager informationFormatManager, Map<IMetadataStandard, StructureFormat> defaultFormats) {
		super(informationFormatManager, StructureFormat.class);
		this.defaultFormats = defaultFormats;
	}

	@Override
	public StructureFormat getDefaultFormat(IMetadataStandard standard) {
		return defaultFormats.get(standard);
	}

	@Override
	public StructureFormat getFormat(Request request) {
		StructureFormat sf = getFormatInternal(request);
		checkSupported(sf);
		return sf;
	}

	private StructureFormat getFormatInternal(Request request) {
		StructureFormat sf = super.getFormat(request);
		if(sf == null) {
			//Check old way of doing it (v8.0)
			if(request.hasParameter("version")) {
				String version = request.getParameter("version");
				if(version != null) {
					switch(version) {
					case "1.0":
						return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V1_STRUCTURE_DOCUMENT);
					case "2.0":
						return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V2_STRUCTURE_DOCUMENT);
					case "2.1":
						return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT);
					case "edi":
						return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.EDI);
					}
				}
			}
		}
		return sf;
	}
}
