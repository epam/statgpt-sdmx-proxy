package io.sdmx.core.structure.manager.persist;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.dao.maintainable.ISdmxBeansDao;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.notification.Notifier;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.event.IMetadataEvent;
import io.sdmx.api.sdmx.manager.persist.IMetadataPersistenceManager;
import io.sdmx.api.sdmx.manager.security.IMetadataWriteAuthorisationManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.manager.metadata.IMetadataLinkRetrievalManager;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.event.MetadataEvent;
import io.sdmx.utils.core.audit.AuditUtil;
import io.sdmx.utils.core.collection.CollectionUtil;

public class MetadataPersistenceManager implements IMetadataPersistenceManager, Notifier<IMetadataEvent> {
	private IMetadataWriteAuthorisationManager metadataWriteAuthorisationManager;
	private IMetadataLinkRetrievalManager linkRetrievalManager;
	private List<Listener<IMetadataEvent>> listeners = new ArrayList<>();
	
	private ISdmxBeansDao beansDao;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public MetadataPersistenceManager(ISdmxBeansDao beansDao,
			SdmxBeanRetrievalManager beanRetrievalManager,
									  IMetadataWriteAuthorisationManager metadataWriteAuthorisationManager,
									  IMetadataLinkRetrievalManager linkRetrievalManager) {
		this.beansDao = beansDao;
		this.beanRetrievalManager = beanRetrievalManager;
		this.metadataWriteAuthorisationManager = metadataWriteAuthorisationManager;
		this.linkRetrievalManager = linkRetrievalManager;
	}
	
	

	@Override
	public void addListener(Listener<IMetadataEvent> listener) {
		listeners.add(listener);
	}

	@Override
	public void removeListener(Listener<IMetadataEvent> listener) {
		listeners.remove(listener);
	}

	@Override
	public void saveMetadata(IReferenceMetadataContainer metadataContainer) {
		AuditUtil.startAuditEvent("METADATA", "SAVE", ()-> {
			for(IReportedMetadataSetBean set : metadataContainer.getReferenceMetadata()) {
				metadataWriteAuthorisationManager.authorise(set);
			}
			MetadataEvent event = new MetadataEvent();
			boolean refreshLinks = false;  //If there are new links, or any modified links, then refresh
			for(IReportedMetadataSetBean mds : metadataContainer.getReferenceMetadata()) {
				IReportedMetadataSetBean persisted =  beanRetrievalManager.getBean(mds.getURN());
				if(persisted == null) {
					event.getAdded().addReferenceMetadata(mds);
					refreshLinks = true;
					break;
				} else {
					event.getEdit().addReferenceMetadata(mds);
				}
				Set<String> targets1 = mds.getTargets().stream().map(e -> e.getReference().toURNString()).collect(Collectors.toSet());
				Set<String> targets2 = persisted.getTargets().stream().map(e -> e.getReference().toURNString()).collect(Collectors.toSet());
				if(!CollectionUtil.isSame(targets1, targets2)) {
					refreshLinks = true;
					break;
				}
			}
			SdmxBeans beans = new SdmxBeansImpl(metadataContainer.getAction());
			beans.addIdentifiables(metadataContainer.getReferenceMetadata());
			beansDao.saveBeans(beans);
//			if(refreshLinks) {//TODO CACHE
//				linkRetrievalManager.refreshLinks();
//			}
			notifyEvent(event);
		});
	}
	
	@Override
	public void deleteMetadata(Set<IURNMaintainable<IReportedMetadataSetBean>> urns) {
		AuditUtil.startAuditEvent("METADATA", "DELETE", ()-> {
			Set<IReportedMetadataSetBean> toDelete = new HashSet<>(urns.size());
			Set<IURNMaintainable<IReportedMetadataSetBean>> urnNotification = new HashSet<>(urns.size());
			for(IURNMaintainable<IReportedMetadataSetBean> urn : urns) {
				IReportedMetadataSetBean metadataSet = beanRetrievalManager.getBean(urn);
				if(metadataSet != null) {
					toDelete.add(metadataSet);
					urnNotification.add(metadataSet.getURN());
				}
				metadataWriteAuthorisationManager.authorise(metadataSet);
			}
			if(toDelete.isEmpty()) {
				return;
			}
			SdmxBeans beans = new SdmxBeansImpl(DATASET_ACTION.DELETE);
			beans.addIdentifiables(toDelete);
			beansDao.saveBeans(beans);

			//			linkRetrievalManager.refreshLinks();  //TODO CACHE
			notifyEvent(new MetadataEvent(urnNotification));
		});
	}
	
	private void notifyEvent(IMetadataEvent event) {
		for(Listener<IMetadataEvent> currentListener : listeners) {
			try {
				currentListener.invoke(event);;
			} catch(Throwable th) {
				th.printStackTrace();
				//TODO Audit the Error
			}
		}
	}

}
