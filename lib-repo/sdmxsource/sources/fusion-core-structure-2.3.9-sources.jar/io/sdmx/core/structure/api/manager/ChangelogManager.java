package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.diff.Changelog;
import io.sdmx.api.sdmx.model.diff.TransactionChangeLog;

public interface ChangelogManager {

	/**
	 * Given 2 structures of the same type, this will return the changes between them
	 * @param fromStructure
	 * @param toStructure
	 * @return
	 */
	Changelog getChangesBetweenStructures(IURNMaintainable<?> fromStructure, IURNMaintainable<?> toStructure);

	/**
	 * Get a changelog for a structure
	 * @param structure -will return a changelog of all versions of this structure.
	 * @return
	 */
	public Changelog getChangeLog(IURNMaintainable<?> structure);

	/**
     * This will return a changelog of the changes made to this structure between two transactions
     *
     * @param structure reference of structure to write changelog for
     * @param fromRev transaction Id to identify which revision to compare from
     * @param toRev transaction Id to identify which revision to compare to
     * @return
     */
    TransactionChangeLog getChangeLogFromRevisions(IURNMaintainable<?> structure, Integer fromRev, Integer toRev);
}
