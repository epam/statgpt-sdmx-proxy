package io.sdmx.core.structure.manager.merge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.core.structure.api.manager.ConstraintMergeManager;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ConstraintMergeManagerImpl implements ConstraintMergeManager, IFusionSingleton {
	private static final KeySorter KEYSORTER = new KeySorter();

	private static ConstraintMergeManagerImpl INSTANCE;

	public static ConstraintMergeManagerImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ConstraintMergeManagerImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private ConstraintMergeManagerImpl() {}

	/**
	 * Returns the list from the map from the key with the id.
	 * If the list does not exist it will be added to the map.
	 * @param map
	 * @param id
	 * @return
	 */
	private Set<String> getListFromMap(Map<String, Set<String>> map, String id) {
		Set<String> codesList = map.get(id);
		if(codesList == null) {
			codesList = new HashSet<>();
		}
		return codesList;
	}

	/**
	 * Populates the map with concept and codes from the cube region.
	 * It will also add a cascade code if the code is cascade and has not already been added to the map of include codes.
	 * @param cubeRegion
	 * @param includedCodes
	 * @param cascadeCodes
	 */
	private void mergeKeyValues(CubeRegionBean cubeRegion,
			Map<String, Set<String>> includedCodes,
			Map<String, Set<String>> excludedCodes,
			Map<String, Set<String>> cascadeCodes,
			Set<String> attributeIds,
			boolean addToIncludeList) {
		if(cubeRegion != null) {
			List<KeyValues> keyValues = new ArrayList<>(cubeRegion.getKeyValues());
			keyValues.addAll(cubeRegion.getAttributeValues());
			for(KeyValues kvs : cubeRegion.getAttributeValues()) {
				attributeIds.add(kvs.getId());
			}
			for(KeyValues kvs : keyValues) {
				String dimensionId = kvs.getId();
				if(addToIncludeList == true && includedCodes.containsKey(dimensionId)) {
					//If the includedCodes has already been populated with includedCodes then we
					//will replace them with whatever is now being stated as included by the higher level constraint
					includedCodes.remove(dimensionId);
				}
				//Create the list of strings in the map: includeCodes for the dimension id if it does not exist
				Set<String> includedCodesList = getListFromMap(includedCodes, kvs.getId());
				Set<String> excludeCodesList = getListFromMap(excludedCodes, kvs.getId());

				//Create the list of strings in cascade codes map for the dimension id if it does not exist
				Set<String> cascadeCodeSet = cascadeCodes.get(dimensionId);
				if(cascadeCodeSet == null) {
					cascadeCodeSet = new HashSet<>();
					cascadeCodes.put(dimensionId, cascadeCodeSet);
				}

				//Add any codes to the cascade codes set IF the code does not already exist in the list of included codes
				for(String currentVal : kvs.getValues()) {
					if(!includedCodesList.contains(currentVal) && !excludeCodesList.contains(currentVal) && kvs.isCascadeValue(currentVal)) {
						cascadeCodeSet.add(currentVal);
					}
					if(addToIncludeList && !excludeCodesList.contains(currentVal)) {
						//Only add code if it is an add code and has not already been excluded
						includedCodes.put(kvs.getId(), kvs.getValues());
					} else if(addToIncludeList == false) {
						if(includedCodesList.contains(currentVal)) {
							//IF this code was included, then remove it from the include list (as it is now exlcuded)
							includedCodesList.remove(currentVal);
						} else {
							//Only add code to exclude list if it is an exclude code and has not already been included
							excludedCodes.put(kvs.getId(), kvs.getValues());
						}
					}
				}
			}
		}
	}

	/**
	 * Merges a Constraint (mergeConstraint) with another (masterConstraint).  The master constraint can not become more restrictive from the contents of the merge constraint,
	 * this means, if the master constraint defines includes or excludes for a particular component, it does not care what the merge constraint is defining.
	 *
	 * <p/>
	 * <u>Cube Region (Codes and attributes)</u>
	 * <br/>
	 */
	@Override
	public ContentConstraintBean merge(ContentConstraintBean masterConstraint, ContentConstraintBean mergeConstraint) {
		if (masterConstraint == null && mergeConstraint != null) {
			return mergeConstraint;
		}
		if (mergeConstraint == null && masterConstraint != null) {
			return masterConstraint;
		}
		if (mergeConstraint == null && masterConstraint == null) {
			return null;
		}
		ContentConstraintBean holder = null;

		SDMX_STRUCTURE_TYPE masterRef = masterConstraint.getConstraintAttachment().getAttachedStructure();
		SDMX_STRUCTURE_TYPE mergeRef = mergeConstraint.getConstraintAttachment().getAttachedStructure();

		//The master constraint should always be the LOWEST LEVEL
		//So if the Merge constraint is lower then the master, swap them over
		if(masterRef != null && mergeRef != null) {
			switch (mergeRef) {
			case DSD:
				if(masterRef == SDMX_STRUCTURE_TYPE.DATAFLOW || masterRef == SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT) {
					//Swap them over
					holder = masterConstraint;
					masterConstraint = mergeConstraint;
					mergeConstraint = holder;
				}
				break;
			case DATAFLOW:
				if(masterRef == SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT) {
					//Swap them over
					holder = masterConstraint;
					masterConstraint = mergeConstraint;
					mergeConstraint = holder;
				}
				break;
			case PROVISION_AGREEMENT:
				//Nothing to do
				break;
			case DATA_PROVIDER:
				//Not sure what to do!
				break;
			default:
				break;
			}
		}


		// Create local fields for ALL of the include codes, exclude codes, cascade codes and attributes from both constraints
		// and populate these fields
		Map<String, Set<String>> includedCodes = new HashMap<>();
		Map<String, Set<String>> excludedCodes = new HashMap<>();
		Map<String, Set<String>> cascadeCodes = new HashMap<>();
		Set<String> attributeIds = new HashSet<>();

		mergeKeyValues(masterConstraint.getIncludedCubeRegion(), includedCodes, excludedCodes, cascadeCodes, attributeIds, true);
		mergeKeyValues(mergeConstraint.getIncludedCubeRegion(), includedCodes, excludedCodes, cascadeCodes, attributeIds, true);
		mergeKeyValues(masterConstraint.getExcludedCubeRegion(), includedCodes, excludedCodes, cascadeCodes, attributeIds, false);
		mergeKeyValues(mergeConstraint.getExcludedCubeRegion(), includedCodes, excludedCodes, cascadeCodes, attributeIds, false);

		// The resultant constraint will be the master constraint and we shall add to it.
		ContentConstraintMutableBean masterMutableConstraint = masterConstraint.getMutableInstance();

		//Store all the concepts that have been explicitly fixed by the series definitions
		Set<String> wildcardedConcepts = new HashSet<>();
		Set<String> fixedConcepts = new HashSet<>();

		if(masterConstraint.getIncludedSeriesKeys() != null) {
			for(ConstrainedDataKeyBean cdk : masterConstraint.getIncludedSeriesKeys().getConstrainedDataKeys()) {
				for(KeyValue kv : cdk.getKeyValues()) {
					String concept = kv.getConcept();
					if(kv.getCode().equals(ContentConstraintBean.WILDCARD_CODE)) {
						wildcardedConcepts.add(concept);
						fixedConcepts.remove(concept);
					} else if(!wildcardedConcepts.contains(kv.getConcept())){
						fixedConcepts.add(concept);
					}
				}
			}
		}

		//Remove any codes which are trying to exclude codes which have been already included in the master constraint's series keys
		for(String concept : fixedConcepts) {
			excludedCodes.remove(concept);
			includedCodes.remove(concept);
		}

		// Merge the included codes
		if (includedCodes.size() > 0) {
			CubeRegionMutableBean cubeRegion  = new CubeRegionMutableBeanImpl();
			masterMutableConstraint.setIncludedCubeRegion(cubeRegion);
			for(String dimensionId : includedCodes.keySet()) {
				KeyValuesMutable keyValues = createKeyValues(dimensionId, includedCodes, cascadeCodes);
				if(attributeIds.contains(dimensionId)) {
					cubeRegion.addAttributeValue(keyValues);
				} else {
					cubeRegion.addKeyValues(keyValues);
				}
			}
		}

		// Merge the excluded codes
		if (excludedCodes.size() > 0) {
			CubeRegionMutableBean cubeRegion = new CubeRegionMutableBeanImpl();
			masterMutableConstraint.setExcludedCubeRegion(cubeRegion);
			for(String dimensionId : excludedCodes.keySet()) {
				KeyValuesMutable keyValues = createKeyValues(dimensionId, excludedCodes, cascadeCodes);
				if (keyValues != null) {
					if(attributeIds.contains(dimensionId)) {
						cubeRegion.addAttributeValue(keyValues);
					} else {
						cubeRegion.addKeyValues(keyValues);
					}
				}
			}
		}


		// Merge Included Series Keys
		if (mergeConstraint.getIncludedSeriesKeys() != null) {
			ConstraintDataKeySetMutableBean csksMutable  = new ConstraintDataKeySetMutableBeanImpl();
			masterMutableConstraint.setIncludedSeriesKeys(csksMutable);
			mergeConstraintDataKeySetBean(csksMutable, masterConstraint.getExcludedSeriesKeys(), mergeConstraint.getIncludedSeriesKeys());
		}

		// Merge Excluded Series Keys
		if (mergeConstraint.getExcludedSeriesKeys() != null) {
			ConstraintDataKeySetMutableBean csksMutable  = new ConstraintDataKeySetMutableBeanImpl();
			masterMutableConstraint.setExcludedSeriesKeys(csksMutable);
			mergeConstraintDataKeySetBean(csksMutable,	masterConstraint.getIncludedSeriesKeys(), mergeConstraint.getExcludedSeriesKeys());
		}

		// TODO Merge Reference Period
		if (mergeConstraint.getReferencePeriod() != null) {
		}

		// TODO Merge Dates
		return masterMutableConstraint.getImmutableInstance();
	}

	private KeyValuesMutable createKeyValues(String dimensionId, Map<String, Set<String>> codesMap, Map<String, Set<String>> cascadeCodes) {
		Set<String> codes = codesMap.get(dimensionId);

		if (codes == null || codes.size() == 0) {
			return null;
		}

		KeyValuesMutable keyValues = new KeyValuesMutableImpl();
		for(String currentAddValue : codes) {
			keyValues.setId(dimensionId);
			keyValues.addValue(currentAddValue);
			if(cascadeCodes.get(dimensionId).contains(currentAddValue)) {
				keyValues.addCascade(currentAddValue);
			}
		}

		return keyValues;
	}

	private void mergeConstraintDataKeySetBean(ConstraintDataKeySetMutableBean mutable,
			ConstraintDataKeySetBean doNotMereKeys,
			ConstraintDataKeySetBean mergeKeys) {
		List<ConstrainedDataKeyMutableBean> cdkMutable = mutable.getConstrainedDataKeys();

		Set<String> keys = new HashSet<>();
		for(ConstrainedDataKeyMutableBean masterDataKeys : cdkMutable) {
			keys.add(getKeysAsString(masterDataKeys.getKeyValues()));
		}
		if(doNotMereKeys != null) {
			for(ConstrainedDataKeyBean cdk : doNotMereKeys.getConstrainedDataKeys()) {
				keys.add(getKeysAsString(cdk.getKeyValues()));
			}
		}
		for(ConstrainedDataKeyBean cdk : mergeKeys.getConstrainedDataKeys()) {
			String keyAsString = getKeysAsString(cdk.getKeyValues());
			if(!keys.contains(keyAsString)) {
				ConstrainedDataKeyMutableBean cdkMut = new ConstrainedDataKeyMutableBeanImpl();
				cdkMut.setKeyValues(cdk.getKeyValues());
				cdkMutable.add(cdkMut);
			}
		}
	}

	private String getKeysAsString(List<IConstrainedKeyValue> seriesKey) {
		Collections.sort(seriesKey, KEYSORTER);

		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(KeyValue kv : seriesKey) {
			sb.append(kv.getCode() + concat);
			concat = ":";
		}
		return sb.toString();
	}

	private static class KeySorter implements Comparator<KeyValue> {

		@Override
		public int compare(KeyValue o1, KeyValue o2) {
			return o1.getConcept().compareTo(o2.getConcept());
		}
	}
}