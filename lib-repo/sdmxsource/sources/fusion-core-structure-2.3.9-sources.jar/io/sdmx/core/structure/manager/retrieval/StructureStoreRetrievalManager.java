package io.sdmx.core.structure.manager.retrieval;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.ApplicationStarter;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.builder.SuperBeansBuilder;
import io.sdmx.api.sdmx.builder.SuperBeansBuilder.SuperBeansBuildErrorHander;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.event.SdmxBeansEventXS;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansStorageManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.superbeans.SuperBeans;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution.RESOLUTION_TYPE;
import io.sdmx.core.sdmx.builder.superbeans.SuperBeansBuilderImpl;
import io.sdmx.core.sdmx.manager.structure.InMemoryCrossReferenceControl;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.InMemorySdmxSuperBeanRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.proxy.SdmxBeanRetrievalManagerProxy;
import io.sdmx.core.structure.api.manager.IZombieStructureManager;
import io.sdmx.core.structure.api.manager.SdmxSuperBeansRetreivalManager;
import io.sdmx.im.beans.SdmxBeansEventImpl;
import io.sdmx.im.beans.SdmxBeansEventXSImpl;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.container.SuperBeansImpl;
import io.sdmx.utils.core.application.SingletonStore;

/**
 * Wrappers a structure store to obtain the structures on startup.
 * 
 * Relies on the save and delete API to keep in sync.
 */
public class StructureStoreRetrievalManager extends SdmxBeanRetrievalManagerProxy implements SdmxBeanRetrievalManager,
																							 SdmxBeansStorageManager,
																							 SdmxSuperBeanRetrievalManager,
																							 SdmxSuperBeansRetreivalManager,
																							 Listener<SdmxBeansEvent> {

	private static final Logger LOG = LoggerFactory.getLogger(StructureStoreRetrievalManager.class);

	private SdmxBeansStorageManager sdmxBeansStorageManager;

	private InMemoryCrossReferenceControl crossReferenceControl;
	private InMemorySdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private Set<Listener<SdmxBeansEvent>> listeners = new HashSet<>();
	private boolean removeZombieStructures;

	private SuperBeansBuilder superBeansBuilder = SuperBeansBuilderImpl.getInstance();

	/**
	 * to notify zombie structures, can be null
	 */
	private IZombieStructureManager zombieStore;

	public StructureStoreRetrievalManager() {
		super.setProxy(new InMemoryRetrievalManager());
	}



	public void setSdmxBeansStorageManager(SdmxBeansStorageManager sdmxBeansStorageManager) {
		this.sdmxBeansStorageManager = sdmxBeansStorageManager;
		this.sdmxBeansStorageManager.addListener(this);
	}

	public void setCrossReferenceControl(InMemoryCrossReferenceControl crossReferenceControl) {
		this.crossReferenceControl = crossReferenceControl;
		if(this.crossReferenceControl != null) {
			crossReferenceControl.setRetrievalManager(this);
		}
	}



	public void setRemoveZombieStructures(boolean removeZombieStructures) {
		this.removeZombieStructures = removeZombieStructures;
	}

	@Override
	public void addListener(Listener<SdmxBeansEvent> listener) {
		listeners.add(listener);
	}

	@Override
	public void removeListener(Listener<SdmxBeansEvent> listener) {
		listeners.remove(listener);
	}

	@Override
	public SuperBeans getSuperBeans() {
		return superBeanRetrievalManager.getSuperBeans();
	}

	@Override
	public void clearCache() {
		LOG.info("Clear Cache");
		super.setProxy(new InMemoryRetrievalManager());
		SuperBeans superBeansLocal = new SuperBeansImpl();
		superBeanRetrievalManager = new InMemorySdmxSuperBeanRetrievalManager(superBeansLocal);
		if (crossReferenceControl != null) {
			crossReferenceControl.clearCache();
		}
		LOG.info("Clear Cache Complete");
	}

	@Override
	public void invoke(SdmxBeansEvent beansNotification) {
		LOG.info("Beans Event Received");
		IReferenceResolution referenceResolution = null;
		try {
			referenceResolution = tryUpdate(beansNotification, true);
		} catch(Throwable th) {
			LOG.error("Update failed from beans notification - attempt rebuild", th);
			SdmxBeans beans = sdmxBeansStorageManager.getSdmxBeans();
			referenceResolution = tryUpdate(new SdmxBeansEventImpl(null, beans), false);
		} finally {
			SdmxBeans refUpdate = referenceResolution == null ? beansNotification.getNewContainer() : referenceResolution.getAllBeans(RESOLUTION_TYPE.BOTH);
			notifyListeners(new SdmxBeansEventXSImpl(beansNotification, refUpdate));
		}
	}

	/**
	 * Try to update this cache based on the notification
	 * @param beansNotification
	 * @param isUpdate if true, treat this as an update, if false, treat it as a full replace
	 */
	private IReferenceResolution tryUpdate(SdmxBeansEvent beansNotification, boolean isUpdate) {
		// By default assume that the event is "additions only" and "no registrations"
		boolean isAdditionsOnly = true;
		boolean isRegistrationsOnly = false;

		if(beansNotification.getDeletions().getAllMaintainables().size() > 0) {
			// There are deletions
			isAdditionsOnly = false;
		} else {
			Set<MaintainableBean> modified = beansNotification.getModification().getAllMaintainables();

			if(modified.size() > 0) {
				// There are modifications
				isAdditionsOnly = false;

				if(modified.size() == beansNotification.getModification().getRegistrations().size()) {
					// All of the modifications are registrations
					isRegistrationsOnly = true;
				}
			}
		}

		SdmxBeans beans = beansNotification.getNewContainer();

		LOG.debug("Create new InMemory Retrieval Manager");

		if(crossReferenceControl != null) {
			//Ensure the Cross Reference Control is pointing to the proxy service so it can check
			//what cross references have changed against the previous copy of the structures, not the new ones
			crossReferenceControl.setRetrievalManager(super.getProxy());
		}
		
		InMemoryRetrievalManager retrievalManager = new InMemoryRetrievalManager(beans);
		super.setProxy(retrievalManager);

		Set<MaintainableBean> zombieBeans = new HashSet<>();

		LOG.debug("Rebuild Super Beans");
		IReferenceResolution resolution = null;
		try {
			if(superBeanRetrievalManager != null && isUpdate && (isAdditionsOnly || isRegistrationsOnly)) {
				if(isAdditionsOnly) {
					superBeanRetrievalManager.addNewSuperBeans(beansNotification.getAdditions(), retrievalManager);
				} else if(isRegistrationsOnly) {
					superBeanRetrievalManager.addNewSuperBeans(beansNotification.getModification(), retrievalManager);
				}
			} else {
				SuperBeans superBeansLocal = new SuperBeansImpl();
				superBeansBuilder.build(beans, superBeansLocal, retrievalManager, new SuperBeansBuildErrorHander() {

					@Override
					public void handleError(MaintainableBean errorBuildingBean, Throwable th) {
						LOG.error("Critical Error: Super bean for '"+errorBuildingBean.getUrn()+"' could not be built");
						zombieBeans.add(errorBuildingBean);
					}
				}, null);
				superBeanRetrievalManager = new InMemorySdmxSuperBeanRetrievalManager(superBeansLocal);
			}
		} finally {
			if(superBeanRetrievalManager == null) {
				superBeanRetrievalManager = new InMemorySdmxSuperBeanRetrievalManager();
				LOG.error("Critical Error: Super Bean Retrival Manager could not be built");
			}
			if (crossReferenceControl != null) {
				if(isUpdate) {
					ApplicationStarter applicationStarter = SingletonStore.getSingleton(ApplicationStarter.class, false);
					boolean isLienient = applicationStarter == null || applicationStarter.isStarted() == false;
					resolution = crossReferenceControl.update(beansNotification, isLienient, this);
					crossReferenceControl.setRetrievalManager(this);
				} else {
					crossReferenceControl.setRetrievalManager(this);
					resolution = crossReferenceControl.resync(true);
				}
				if(resolution.hasMissingReferences()) {
					for(IdentifiableBean missingRefFrom : resolution.getMissingReferences()) {
						MaintainableBean zombieMaintainable = missingRefFrom.getMaintainableParent();
						zombieBeans.add(zombieMaintainable);
						for(ICrossReferenceBean missingRefTo : resolution.getMissingReferences(missingRefFrom)) {
							LOG.error("Critical Error: missing reference from '"+missingRefFrom.getUrn()+"' to '"+missingRefTo.getTargetUrn()+"'");
						}
						for(MaintainableBean zombieAncestor : crossReferenceControl.getAllAncestors(zombieMaintainable.getURN())) {
							LOG.error("Ancestor of broken tree '"+zombieAncestor.getUrn()+"' detected");
							zombieBeans.add(zombieAncestor);
						}
					}
				}
			}
		}
		SdmxBeans zombies = new SdmxBeansImpl(zombieBeans);
//		if(zombieBeans.size() > 0 && removeZombieStructures) {
//			LOG.error("Structures with broken references, and their ancestors are being partitioned to ensure system stability");
//			retrievalManager.deleteStructures(zombies);
//			if(zombieStore == null) {
//				this.zombieStore = new ZombieStructureManager();
//			}
//			zombieStore.registerZombies(zombies);
//		}
		
		return resolution;
	}

	private void notifyListeners(SdmxBeansEventXS event) {
		LOG.info("Beans Event processed. Notify all listeners");
		for(Listener<SdmxBeansEvent> currentListener : listeners) {
			//Ensure the notification is just the beans that changed, not all of them
			LOG.debug("Notify Listener: " + currentListener);
			try {
				currentListener.invoke(event);
			} catch(Throwable th) {
				LOG.error("Error notifying listener '"+currentListener+"' of structure update", th);
			}
		}
		LOG.info("Notifying all listeners completed");
	}


	public InMemoryCrossReferenceControl getCrossReferenceControl() {
		return crossReferenceControl;
	}

	@Override
	public SdmxBeans getSdmxBeans() {
		LOG.debug("Get SdmxBeans");
		InMemoryRetrievalManager retrievalManager = (InMemoryRetrievalManager)super.getProxy();
		if(retrievalManager == null) {
			//NPE Defence
			LOG.warn("Proxy NULL - NPE Defence");
			retrievalManager = new InMemoryRetrievalManager();
			super.setProxy(retrievalManager);
		}

		SdmxBeans beans =  retrievalManager.getBeans();
		if(beans == null) {
			LOG.warn("Sdmx Beans NULL - NPE Defence");
			return new SdmxBeansImpl();
		}
		return beans;
	}

	@Override
	public ConceptSchemeSuperBean getConceptSchemeSuperBean(IURNSingle<ConceptSchemeBean> ref) {
		LOG.debug("getConceptSchemeSuperBean");
		return superBeanRetrievalManager.getConceptSchemeSuperBean(ref);
	}

	@Override
	public DataflowSuperBean getDataflowSuperBean(IURNSingle<DataflowBean> ref) {
		LOG.debug("getDataflowSuperBean");
		return superBeanRetrievalManager.getDataflowSuperBean(ref);
	}

	@Override
	public DataStructureSuperBean getDataStructureSuperBean(IURNSingle<DataStructureBean> ref) {
		LOG.debug("getDataStructureSuperBean");
		return superBeanRetrievalManager.getDataStructureSuperBean(ref);
	}

	@Override
	public HierarchySuperBean getHierarchicCodeListSuperBean(IURNSingle<HierarchyBean> ref) {
		LOG.debug("getHierarchicCodeListSuperBean");
		return superBeanRetrievalManager.getHierarchicCodeListSuperBean(ref);
	}

	@Override
	public MetadataStructureSuperBean getMetadataStructureSuperBean(IURNSingle<MetadataStructureDefinitionBean> ref) {
		LOG.debug("getMetadataStructureSuperBean");
		return superBeanRetrievalManager.getMetadataStructureSuperBean(ref);
	}

	@Override
	public ProvisionAgreementSuperBean getProvisionAgreementSuperBean(IURNSingle<ProvisionAgreementBean> ref) {
		LOG.debug("getProvisionAgreementSuperBean");
		return superBeanRetrievalManager.getProvisionAgreementSuperBean(ref);
	}

	@Override
	public RegistrationSuperBean getRegistrationSuperBean(IURNSingle<RegistrationBean> ref) {
		LOG.debug("getRegistrationSuperBean");
		return superBeanRetrievalManager.getRegistrationSuperBean(ref);
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemeSuperBeans(IURN<ConceptSchemeBean> ref) {
		LOG.debug("getConceptSchemeSuperBeans");
		return superBeanRetrievalManager.getConceptSchemeSuperBeans(ref);
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructureSuperBeans(IURN<DataStructureBean> ref) {
		LOG.debug("getDataStructureSuperBeans");
		return superBeanRetrievalManager.getDataStructureSuperBeans(ref);
	}


}