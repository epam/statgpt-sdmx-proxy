package io.sdmx.core.structure.model.constraint;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.constants.ITEM_FILTER_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;

public class ConstrainedCodesImpl implements ConstrainedCodes {
	private DataStructureSuperBean dsd;
	private Map<String, Set<String>> validCodes;
	private IDatasetStructures datasetStructures;
	private Set<ContentConstraintBean> inputConstraints = Collections.emptySet();

	public ConstrainedCodesImpl(DataStructureSuperBean dsd, 
								Map<String, Set<String>> validCodes, 
								IDatasetStructures datasetStructures,
								Set<ContentConstraintBean> inputConstraints) {
		this.dsd = dsd;
		this.validCodes = validCodes;
		this.datasetStructures = datasetStructures;
		if(inputConstraints != null) {
			this.inputConstraints = new HashSet<>(inputConstraints);
			this.inputConstraints = Collections.unmodifiableSet(inputConstraints);
		}
	}

	@Override
	public DataStructureSuperBean getDsd() {
		return dsd;
	}

	@Override
	public Set<ContentConstraintBean> getConstraintsUsed() {
		return inputConstraints;
	}

	@Override
	public IDatasetStructures getDatasetStructures() {
		return datasetStructures;
	}

	@Override
	public EnumeratedListBean<? extends EnumeratedItemBean> getCodelist(String componentId) {
		EnumeratedListBean<? extends EnumeratedItemBean> cl = dsd.getCodelistByComponentId(componentId);
		if(cl == null) {
			return null;
		}

		Set<String> validCodesForComponent = validCodes.get(componentId);
		if(validCodesForComponent == null) {
			return cl;
		}
		Set<String> codeIds = new HashSet<>();
		for(EnumeratedItemBean code : cl.getItems()) {
			codeIds.add(code.getId());
		}

		codeIds.removeAll(validCodesForComponent);
		if(codeIds.size() > 0) {
			if(cl.getStructureType() == SDMX_STRUCTURE_TYPE.VALUE_LIST) {
				ValueListBean vl = (ValueListBean) cl;
				return vl.filterItems(codeIds, false);
			} else {
				CodelistMutableBean clMut = ((CodelistBean)cl).getMutableInstance();
				clMut.createPartialList(codeIds, false, ITEM_FILTER_ACTION.NO_ACTION);
				return clMut.getImmutableInstance();
			}
			
		}
		return cl;
	}

	@Override
	public Map<String, Set<String>> getValidCodes() {
		return validCodes;
	}
}
