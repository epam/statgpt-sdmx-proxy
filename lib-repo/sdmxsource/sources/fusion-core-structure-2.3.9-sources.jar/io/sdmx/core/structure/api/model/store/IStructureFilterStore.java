package io.sdmx.core.structure.api.model.store;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * Stores information at the level of the structure type/agency/id/version where all or none are mandatory, enables retrieval of that
 * information.
 * 
 * Example, information is stored against Codelists for BIS and any structure at version 3.0, information is retrieved for version 3.0 BIS codelists will 
 * contain both pieces of information
 */
public interface IStructureFilterStore<T> {

	/**
	 * Stores information against a full or wildcard URN
	 * @param urn to store against
	 * @param toStore information to store
	 */
	void store(IURN<?> urn, T toStore);
	
	/**
	 * Retrieves information that matches a specific maintainable
	 * @param maint to search information for
	 * @return not null, immutable set
	 */
	Set<T> find(MaintainableBean maint);
	
}
