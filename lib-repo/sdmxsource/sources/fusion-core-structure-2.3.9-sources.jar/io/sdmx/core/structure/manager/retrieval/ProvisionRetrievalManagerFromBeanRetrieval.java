package io.sdmx.core.structure.manager.retrieval;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.core.structure.api.manager.ProvisionBeanRetrievalManager;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class ProvisionRetrievalManagerFromBeanRetrieval implements ProvisionBeanRetrievalManager {
    private SdmxBeanRetrievalManager beanRetrievalManager;

    public ProvisionRetrievalManagerFromBeanRetrieval(SdmxBeanRetrievalManager beanRetrievalManager) {
        this.beanRetrievalManager = beanRetrievalManager;
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisions() {
        return beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class));
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisions(IURNSingle<? extends ConstrainableBean> structureRef) {
        SDMX_STRUCTURE_TYPE targetReference = structureRef.getSdmxStructure();
        switch(targetReference) {
        case DSD : return getProvisionsByDataStructure(structureRef.toType(DataStructureBean.class));
        case DATAFLOW : return getProvisionsByDataflow(structureRef.toType(DataflowBean.class));
        case DATA_PROVIDER : return getProvisionsByProvider(structureRef.toType(DataProviderBean.class));
        case PROVISION_AGREEMENT :
            ProvisionAgreementBean prov = getProvisionByProvision(structureRef.toType(ProvisionAgreementBean.class));
            if(prov == null) {
                return Collections.emptySet();
            }
            return Set.of(prov);
        default: throw new SdmxNotImplementedException("Can not get Provisions by stucture type:" + targetReference.getType());
        }
    }

    @Override
    public ProvisionAgreementBean getProvisionByProvision(IURNSingle<ProvisionAgreementBean> provision) {
        return beanRetrievalManager.getBean(provision);
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByDataStructure(IURNSingle<DataStructureBean> dsdUrn) {
        DataStructureBean dsd = beanRetrievalManager.getBean(dsdUrn);
        if(dsd == null) {
            return Collections.emptySet();
        }
        Set<ProvisionAgreementBean> returnSet = new HashSet<>();
        for(DataflowBean currentFlow : beanRetrievalManager.getMaintainableBeans(URN.build(DataflowBean.class))) {
            returnSet.addAll(getProvisionsByDataflow(currentFlow.getURN()));
        }
        return returnSet;
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByDataflow(IURNSingle<DataflowBean> dataflow) {
        Set<ProvisionAgreementBean> allProvisions = beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class));

        Set<ProvisionAgreementBean> returnSet = new HashSet<>();
        for(ProvisionAgreementBean currentProvision : allProvisions) {
            if(currentProvision.getStructureUseage().getReference().isMatch(dataflow))  {
                returnSet.add(currentProvision);
            }
        }
        return returnSet;
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByProvider(IURNSingle<DataProviderBean> provider) {
        Set<ProvisionAgreementBean> returnSet = new HashSet<>();
        Set<ProvisionAgreementBean> allProvisions = beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class));

        for(MaintainableBean currentProvision : allProvisions) {
            ProvisionAgreementBean prov = (ProvisionAgreementBean) currentProvision;
            if(prov.getDataproviderRef().getReference().isMatch(provider)) {
                returnSet.add(prov);
            }
        }
        return returnSet;
    }

    @Override
    public ProvisionAgreementBean getProvision(RegistrationBean registration) {
        Set<ProvisionAgreementBean> provisions = getProvisions(registration.getProvisionAgreementRef().getReference());
        if(ObjectUtil.validCollection(provisions)) {
            if(provisions.size() > 1) {
                throw new RuntimeException("Only one provision agreement expected from reference : " + registration.getProvisionAgreementRef());
            }
            return (ProvisionAgreementBean)provisions.toArray()[0];
        }
        return null;
    }
}
