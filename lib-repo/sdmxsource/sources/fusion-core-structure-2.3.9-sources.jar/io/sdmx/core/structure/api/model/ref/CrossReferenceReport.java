package io.sdmx.core.structure.api.model.ref;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * A report of how beans reference other beans
 */
public interface CrossReferenceReport {

    /**
     * For each Identifiable (key) returns the Set of Identifiables (value) that it references.
     * e.g. a Concept Scheme Concept references a Codelist, or a Dimension references a Concept
     */
    Map<IdentifiableBean, Set<IdentifiableBean>> getReferences();

    /**
     * For each Maintainable (key) that is referenced by another Identifiable, return a set of those references.
     * e.g. A Codelist is referenced by a Concept Scheme Concept
     */
    Map<MaintainableBean, Set<IdentifiableBean>> getReferencedBy();

    /**
     * For each Maintainable (key) returns the Set of Identifiables (value) that it references.
     * e.g. a DSD refers to a number of Concepts.
     */
    Map<MaintainableBean, Set<IdentifiableBean>> getMaintReferences();
}
