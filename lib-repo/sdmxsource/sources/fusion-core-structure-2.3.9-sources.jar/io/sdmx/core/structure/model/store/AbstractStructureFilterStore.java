package io.sdmx.core.structure.model.store;

import java.util.Collections;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.structure.api.model.store.IStructureFilterStore;


public abstract class AbstractStructureFilterStore<T> implements IStructureFilterStore<T> {
	
	protected Set<T> get(MaintainableBean maint, IStructureFilterStore<T> store) {
		if(store != null) {
			return store.find(maint);
		}
		return Collections.emptySet();
	}
	
}
