
package io.sdmx.core.structure.api.manager;

import java.util.Set;

import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.SubscriptionBean;


/**
 * Manages the retrieval of subscriptions
 * @author Matt Nelson
 *
 */
public interface SdmxSubscriptionRetrievalManager {


	/**
	 * Returns a count of all the subscriptions in the system
	 * @return
	 */
	int getSubscriptionCount();
	
	/**
	 * Returns a set of all the subscriptions which are owned by the a given organisation.
	 * <p/>
	 * Returns an empty set if no subscriptions are found
	 * @return
	 */
	Set<SubscriptionBean> getSubscriptions(OrganisationBean organisation);
	
	/**
	 * Returns a set of all the subscriptions for a given organisation (Data Consumer, Data Provider or Agency)
	 * @param organisationReference this will be validated that the reference is to a data consumer, and it a full reference (contains all reference parameters)
	 * @return
	 * @throws CrossReferenceException  if the StructureReferenceBean does not reference a valid Organisation
	 */
	Set<SubscriptionBean> getSubscriptions(StructureReferenceBean organisationReference);
	
	/**
	 * Returns a set of subscriptions of the given type for the trigger identifiable
	 * @param triggerEvent the identifiable that triggers this event 
	 * @param type This defines the type of subscriptions to return 
	 * @return
	 */
	Set<SubscriptionBean> getSubscriptionsForEvent(IdentifiableBean triggerEvent, SubscriptionBean.SUBSCRIPTION_TYPE type);

}
