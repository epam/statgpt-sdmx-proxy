package io.sdmx.core.structure.manager.reverseengineer;

import java.io.OutputStream;
import java.util.UUID;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;
import io.sdmx.core.structure.api.manager.ReverseEngineerDSDManager;
import io.sdmx.core.structure.api.manager.StructureDiscoveryManager;
import io.sdmx.utils.core.collection.FiniteMap;
import io.sdmx.utils.core.csv.CSVColumnReaderEngineImpl;

public class ReverseEngineerDSDManagerImpl implements ReverseEngineerDSDManager {

	//60 minute map
	private FiniteMap<String, ReadableDataLocation> loadedDataMap = new FiniteMap<String, ReadableDataLocation>(1000*60*60);
	
	private StructureDiscoveryManager structureDiscoveryManager = StructureDiscoveryManagerImpl.getInstance();
	
	private StructurePersistenceManager structurePersistenceManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public ReverseEngineerDSDManagerImpl(SdmxBeanRetrievalManager retrievalManager, StructurePersistenceManager structurePersistenceManager) {
		this.beanRetrievalManager = retrievalManager;
		this.structurePersistenceManager = structurePersistenceManager;
	}
	
	@Override
	public void analyseData(ReadableDataLocation rdl, OutputStream out) {
		String token = UUID.randomUUID().toString();
		JSONObject response = new JSONObject();
		rdl.setProtected(true);
		try(ColumnReaderEngine cre = new CSVColumnReaderEngineImpl(rdl)) {
			response.put("token", token);
			int i=0;

			response.append("rows", new JSONArray(cre.readHeader()));
			while(cre.moveNextRow()) {
				response.append("rows", new JSONArray(cre.readRow()));
				i++;
				if(i > 10) {
					break;
				}
			}
			out.write(response.toString().getBytes());
			loadedDataMap.put(token, rdl);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void generateStructures(String token, StructureDiscoveryRules rules) {
		ReadableDataLocation rdl = loadedDataMap.get(token);
		if(rdl == null) {
			throw new SdmxSemmanticException("Can not find data file from token.  Your session may have timed out.");
		}
		generateStructures(rdl, rules);
	}

	@Override
	public void generateStructures(ReadableDataLocation rdl, StructureDiscoveryRules rules) {
		try(ColumnReaderEngine cre = new CSVColumnReaderEngineImpl(rdl)) {
			SdmxBeans beans = structureDiscoveryManager.buildStructures(cre, rules, beanRetrievalManager);
			beans.setAction(DATASET_ACTION.MERGE);
			structurePersistenceManager.saveStructures(beans);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
	
}
