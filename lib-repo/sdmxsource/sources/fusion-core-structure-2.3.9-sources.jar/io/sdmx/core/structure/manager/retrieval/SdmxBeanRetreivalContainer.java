package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRetreivalContainer;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;

public class SdmxBeanRetreivalContainer implements ISdmxBeanRetreivalContainer {
	private IStructureEnvironment secureEnvironment;
	private IStructureEnvironment publicEnvironment;
	
	
	public SdmxBeanRetreivalContainer(IStructureEnvironment publicEnvironment) {
		this(publicEnvironment, publicEnvironment);
	}
			
	public SdmxBeanRetreivalContainer(IStructureEnvironment publicEnvironment, IStructureEnvironment secureEnvironment) {
		this.publicEnvironment = publicEnvironment;
		this.secureEnvironment = secureEnvironment;
	}

	@Override
	public SdmxBeanRetrievalManager getBeanRetrievalManager(boolean isSecure) {
		return getEnvironment(isSecure).getBeanRetrievalManager();
	}
	
	@Override
	public SdmxSuperBeanRetrievalManager getSuperBeanRetrievalManager(boolean isSecure) {
		return getEnvironment(isSecure).getSuperBeanRetrievalManager();
	}

	@Override
	public CrossReferencingRetrievalManager getCrossReferenceManager(boolean isSecure) {
		return getEnvironment(isSecure).getAncestorRetrievalManager();
	}

	@Override
	public CrossReferencedRetrievalManager getCrossReferencedManager(boolean isSecure) {
		return getEnvironment(isSecure).getDescendantRetrievalManager();
	}

	@Override
	public ISdmxBeanRestRetrievalManager getRestRetrievalManager(boolean isSecure) {
		return getEnvironment(isSecure).getRestBeanRetrievalManager();
	}

	private IStructureEnvironment getEnvironment(boolean isSecure) {
		return isSecure ? secureEnvironment : publicEnvironment;
	}
}
