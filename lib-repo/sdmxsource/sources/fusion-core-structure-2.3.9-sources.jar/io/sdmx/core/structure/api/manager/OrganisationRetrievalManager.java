
package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;

/**
 * Used to retrieve Organisations
 * @author MetaTech
 *
 */
public interface OrganisationRetrievalManager {

	/**
	 * Returns the data provider belongning to the given agency, with the given id
	 * @param agencyId a period separated agency id, where the periods are used to define sub Agencies
	 * @param id id of the data provider to return
	 * @return DataProvider, or null if one can not be found with the given reference parameters
	 */
	DataProviderBean getDataProvider(String agencyId, String id);
	
	/**
	 * Returns the data consumer belonging to the given agency, with the given id
	 * @param agencyId a period separated agency id, where the periods are used to define sub Agencies
	 * @param id id of the data provider to return
	 * @return DataProvider, or null if one can not be found with the given reference parameters
	 */
	DataConsumerBean getDataConsumerBean(String agencyId, String id);
	
	/**
	 * Returns the agency with the given id
	 * @param agencyId a period separated agency id, where the periods are used to define sub Agencies
	 * @return DataProvider, or null if one can not be found with the given reference parameters
	 */
	AgencyBean getAgency(String agencyId);
}
