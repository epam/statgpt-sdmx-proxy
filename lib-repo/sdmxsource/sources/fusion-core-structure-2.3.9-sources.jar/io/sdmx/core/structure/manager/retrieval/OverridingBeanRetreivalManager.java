package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.core.sdmx.manager.structure.proxy.SdmxBeanRetrievalManagerProxy;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * Dynamically changes the underlying bean retrieval manager by proxing the for the on supplied in this file 
 *
 */
public class OverridingBeanRetreivalManager extends SdmxBeanRetrievalManagerProxy {
	
	private static final String THREAD_KEY = "PROXY_REL_MAN";
	
	public OverridingBeanRetreivalManager(SdmxBeanRetrievalManager retrievalManager) {
		super(retrievalManager);
	}
	
	public void setProxyManager(SdmxBeanRetrievalManager retrievalManager) {
		clear();
		ThreadLocalUtil.storeOnThread(THREAD_KEY, retrievalManager);
	}

	@Override
	protected SdmxBeanRetrievalManager getProxy() {
		if(ThreadLocalUtil.contains(THREAD_KEY)) {
			return (SdmxBeanRetrievalManager) ThreadLocalUtil.retrieveFromThread(THREAD_KEY);
		}
		return super.getProxy();
	}
	
	public void clear() {
		ThreadLocalUtil.clearFromThread(THREAD_KEY);
	}
}
