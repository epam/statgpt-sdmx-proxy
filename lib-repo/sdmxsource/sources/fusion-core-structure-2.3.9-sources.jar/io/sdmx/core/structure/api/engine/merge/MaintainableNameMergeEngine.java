package io.sdmx.core.structure.api.engine.merge;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface MaintainableNameMergeEngine {

	/**
	 * Merge the nameable names and descriptions from the mergeFrom maintainable to the maintIn maintainable
	 * <p/>
	 * If a name or description exists in the mergeFrom that does not exist in the maintIn then the name/description
	 * will be copied from the mergeFro into the maintIn
	 * 
	 * 
	 * @param maintIn
	 * @param mergeFrom
	 * @return a new copy of the maintIn with names and descriptions merged in from maintFrom
	 */
	MaintainableBean mergeMaintainables(MaintainableBean maintIn, MaintainableBean mergeFrom);
	
}
