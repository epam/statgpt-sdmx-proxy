package io.sdmx.core.structure.manager.merge;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.engine.merge.MaintainableNameMergeEngine;
import io.sdmx.core.structure.api.engine.merge.OrganisationSchemeMergeEngine;
import io.sdmx.core.structure.api.manager.StructureMergeManager;
import io.sdmx.core.structure.engine.merge.MaintainablenameMergeEngineImpl;
import io.sdmx.core.structure.engine.merge.OrganisationSchemeMergeEngineImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StructureMergeManagerImpl implements StructureMergeManager, IFusionSingleton {
	private OrganisationSchemeMergeEngine organisationSchemeMergeEngine = OrganisationSchemeMergeEngineImpl.getInstance();
	private MaintainableNameMergeEngine maintainableNameMergeEngine = MaintainablenameMergeEngineImpl.getInstance();

	private static StructureMergeManagerImpl INSTANCE;

	public static StructureMergeManagerImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureMergeManagerImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private StructureMergeManagerImpl() {}

	@Override
	public void mergeNames(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager) {
		for(MaintainableBean maint : beans.getAllMaintainables()) {
			MaintainableBean existing = beanRetrievalManager.getBean(maint.getURN());
			if(existing != null) {
				beans.addIdentifiable(maintainableNameMergeEngine.mergeMaintainables(maint, existing));
			}
		}
	}

	@Override
	public void mergeDefaultAgencySchemeIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager) {
		organisationSchemeMergeEngine.mergeDefaultAgencySchemeIfExists(beans, beanRetrievalManager);
	}
}
