package io.sdmx.core.structure.manager.persist;

import java.util.Map;
import java.util.UUID;

import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.core.structure.api.manager.StructureConfirmationManager;
import io.sdmx.utils.core.collection.FiniteMap;
import io.sdmx.utils.core.object.ObjectUtil;

public class StructureConfirmationManagerImpl implements StructureConfirmationManager {

    private Map<String, SdmxBeans> map = new FiniteMap<>(60*1000*15); // 15 minute lifetime

    private StructurePersistenceManager structurePersistenceManager;

    public StructureConfirmationManagerImpl(StructurePersistenceManager structurePersistenceManager) {
        this.structurePersistenceManager = structurePersistenceManager;
    }
    
	@Override
    public String store(SdmxBeans beans) {
        String uid = UUID.randomUUID().toString();
        map.put(uid, beans);
        return uid;
    }

    @Override
    public void confirmSubmission(String guid) {
        if (!ObjectUtil.validString(guid)) {
            throw new RuntimeException("Unable to perform the confirm. No guid was specified");
        }

        if (!map.containsKey(guid)) {
            throw new RuntimeException("Unable to perform the confirm. Unable to locate guid:" + guid);
        }
        SdmxBeans beans = map.remove(guid);
        structurePersistenceManager.saveStructures(beans);
    }

    @Override
    public void abortSubmission(String id) {
        if (!ObjectUtil.validString(id)) {
            throw new RuntimeException("Unable to perform the abort. No id was specified");
        }

        SdmxBeans beans = map.get(id);
        if (beans == null) {
            throw new RuntimeException("Unable to perform the abort. Unable to locate id:" + id);
        }

        map.remove(id);
    }
}
