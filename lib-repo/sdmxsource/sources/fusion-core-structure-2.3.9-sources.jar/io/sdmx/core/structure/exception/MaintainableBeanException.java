package io.sdmx.core.structure.exception;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class MaintainableBeanException extends SdmxSemmanticException {
	private static final long serialVersionUID = -8099955589762191856L;
	private final String agencyId;
	private final String id;
	private final String version;
	private final SDMX_STRUCTURE_TYPE structureType;
	
	public MaintainableBeanException(Throwable th, MaintainableBean maintainableBean) {
		this(th, maintainableBean.getStructureType(), maintainableBean.getAgencyId(), maintainableBean.getId(), maintainableBean.getVersion().toString());
	}
	
	
	public MaintainableBeanException(Throwable th, SDMX_STRUCTURE_TYPE structureType, String agencyId, String id, String version) {
		super(th, "Error with maintainable artefact of type '"+structureType.getType()+"' and identifiers '" + getAgencyId(agencyId) + ":"+getId(id) +"("+getVersion(version)+")'");
		this.agencyId = agencyId;
		this.id = id;
		this.version = version;
		this.structureType = structureType;
	}

	private static String getAgencyId(String agencyId) {
		if(agencyId == null || agencyId.length() == 0) {
			return  "agency missing";
		}
		return agencyId;
	}
	
	private static String getId(String id) {
		if(id == null || id.length() == 0) {
			return  "id missing";
		}
		return id;
	}
	
	private static String getVersion(String version) {
		if(version == null || version.length() == 0) {
			return  MaintainableBean.DEFAULT_VERSION;
		}
		return version;
	}
	
	@Override
	public SDMX_ERROR_CODE getSdmxErrorCode() {
		return SDMX_ERROR_CODE.SEMANTIC_ERROR;
	}
	
	public String getAgencyId() {
		return agencyId;
	}

	public String getId() {
		return id;
	}

	public String getVersion() {
		return version;
	}

	public SDMX_STRUCTURE_TYPE getStructureType() {
		return structureType;
	}
	
	@Override
	public String getErrorType() {
		return "Maintainable Bean Exception";
	}
}
