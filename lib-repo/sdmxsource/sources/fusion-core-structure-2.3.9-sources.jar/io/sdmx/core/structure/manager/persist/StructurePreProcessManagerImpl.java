package io.sdmx.core.structure.manager.persist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.core.structure.api.engine.persist.StructurePreProcessEngine;
import io.sdmx.core.structure.api.manager.StructurePreProcessManager;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StructurePreProcessManagerImpl implements StructurePreProcessManager {
    private static final Logger LOG = LoggerFactory.getLogger(StructurePreProcessManagerImpl.class);

	@Override
	public void preProcess(SdmxBeans beans, boolean isPreValidation) {
		LOG.info("Pre-process Beans Event");
		try {
			FusionBeanStore.getBeans(StructurePreProcessEngine.class).forEach(spp -> spp.preProcess(beans, isPreValidation));
		} catch(Throwable th) {
			LOG.error("Error in pre-processor while pre-processing beans event", th);
		}
	}
}
