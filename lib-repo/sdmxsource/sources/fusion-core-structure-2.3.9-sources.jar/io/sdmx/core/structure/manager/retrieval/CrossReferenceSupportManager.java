package io.sdmx.core.structure.manager.retrieval;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Adds some useful methods regarding cross-referencing of structures.
 * This class should probably be moved into another package or the functionality merged into CrossReferencingRetrievalManager
 */
public class CrossReferenceSupportManager {

	private ISdmxBeanRestRetrievalManager beanRetrievalManager;
	
	public CrossReferenceSupportManager(ISdmxBeanRestRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	/**
	 * @param agency id to search for
	 * @return  all the structures maintained by the Agency, and structures that also use those structures that may be owned by other agencies
	 */
	public Set<MaintainableBean> getAllStructuresOwnedByAgency(String agency) {
		IURN<?> urn = URN.builder().agencyId(agency).build();
		SdmxBeans maintainables = beanRetrievalManager.getMaintainables(new RESTStructureQueryImpl(urn));
		Set<MaintainableBean> allMaintainables = maintainables.getAllMaintainables();

		SdmxBeans sdmxBean = new SdmxBeansImpl(allMaintainables);
		for (MaintainableBean aMaint : allMaintainables) {
			Set<MaintainableBean> allReferringMaints = getMaintainableReferences(aMaint);
			sdmxBean.addIdentifiables(allReferringMaints);
		}

		allMaintainables = sdmxBean.getAllMaintainables();

		Set<MaintainableBean> subAcyMaints = new HashSet<>();
		for (MaintainableBean aMaint : allMaintainables) {
			if (aMaint instanceof AgencySchemeBean) {
				subAcyMaints.addAll(getOwnedByAgencyStructures((AgencySchemeBean)aMaint));
			}
		}
		allMaintainables.addAll(subAcyMaints);
		return allMaintainables;
	}
	
	/**
	 * Returns all of the Maintainables and their ancestors that Reference the specified Identifiable
	 * and if the Identifiable is an Agency Scheme,
	 * 
	 * @param maint
	 * @return
	 */
	private Set<MaintainableBean> getMaintainableReferences(MaintainableBean maint) {
		return getAllAncestors(beanRetrievalManager, maint);
	}

	private Set<MaintainableBean> getOwnedByAgencyStructures(AgencySchemeBean agencyScheme) {
		Set<MaintainableBean> returnSet = new HashSet<>();

		for (AgencyBean agency : agencyScheme.getItems()) {
			IURN<?> urn = URN.builder().agencyId(agency.getFullId()).build();
			SdmxBeans maintainables = beanRetrievalManager.getMaintainables(
					new RESTStructureQueryImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.DESCENDANTS, null, urn));
			Set<MaintainableBean> allMaintainables = maintainables.getAllMaintainables();
			for (MaintainableBean maintainableBean : allMaintainables) {
				if (maintainableBean instanceof AgencySchemeBean) {
					if (((AgencySchemeBean) maintainableBean).isDefaultScheme()) {
						continue;
					}
				}
				returnSet.addAll(getAllAncestors(beanRetrievalManager, maintainableBean));
			}
		}
		return returnSet;
	}
	
	private  Set<MaintainableBean> getAllAncestors(ISdmxBeanRestRetrievalManager retreivalManager, MaintainableBean maint) {
		Set<MaintainableBean> ancestors = retreivalManager.getMaintainables(
				new RESTStructureQueryImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.ANCESTORS, null, maint.getURN())).getAllMaintainables();
		ancestors.remove(maint);
		return ancestors;
	}
	
}
