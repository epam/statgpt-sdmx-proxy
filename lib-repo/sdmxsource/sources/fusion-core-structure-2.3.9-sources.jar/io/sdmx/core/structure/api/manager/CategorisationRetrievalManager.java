
package io.sdmx.core.structure.api.manager;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.superbeans.categoryscheme.CategorisationSuperBean;


/**
 * Responsible for retrieving categorisations for particular structures
 * @author MetaTech
 *
 */
public interface CategorisationRetrievalManager {

	/**
	 * Returns categorisations for a given identifiable
	 * @param identifiable
	 * @return
	 */
	Set<CategorisationBean> getCategorisations(IdentifiableBean identifiable);
	

	/**
	 * Returns all categorisations for the given category scheme
	 * @param category
	 * @return
	 */
	Set<CategorisationBean> getCategorisationsForCategoryScheme(CategorySchemeBean scheme);
	
	/**
	 * Returns all categorisations for the given category
	 * @param category
	 * @return
	 */
	Set<CategorisationBean> getCategorisationsForCategory(CategoryBean category);
	
	/**
	 * Returns the categorisation super beans for a given identifiable
	 * @param identifiable
	 * @return
	 */
	Set<CategorisationSuperBean> getCategorisationSuperBean(IdentifiableBean identifiable);
	
	/**
	 * Returns the categorisation super beans for a given category, optionally a filter of allowable categorised
	 * structure types can be returned
	 * @param identifiable
	 * @return
	 */
	Set<CategorisationSuperBean> getCategorisationSuperBeanForCategory(CategoryBean category, SDMX_STRUCTURE_TYPE... includeTypes);
	

	
	
}
