package io.sdmx.core.structure.notifier;

import java.util.List;

import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.utils.core.notifier.AbstractNotifier;

public class SdmxBeansNotifier extends AbstractNotifier<SdmxBeans>  {
	
	public void setListners(List<Listener<SdmxBeans>> listners) {
		for(Listener<SdmxBeans> listener : listners) {
			addListener(listener);
		}
	}
}
