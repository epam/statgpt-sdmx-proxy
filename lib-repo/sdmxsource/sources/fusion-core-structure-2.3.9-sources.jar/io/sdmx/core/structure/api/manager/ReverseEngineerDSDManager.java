package io.sdmx.core.structure.api.manager;

import java.io.OutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;

/**
 * Used to reverse engineer a Data Structure Definition, Concepts, and Codelists from a Dataset
 */
public interface ReverseEngineerDSDManager {

	/**
	 * From a data stream of CSV, the response will include the first 'x' lines of data along with a token which can be used
	 * in further processes for this manager
	 * 
	 * {
	 * 		token: "123455",
	 *      data :  [
	 *   				["FREQ","REF_AREA,"SEX","AGE"],
	 *  				 ["A","UK,"M","122"],
	 *  				 ["A","FR,"M","22"],
	 * 				]
	 * }
	 * @param rdl
	 * @param out
	 */
	void analyseData(ReadableDataLocation rdl, OutputStream out);
	
	/**
	 * Generates structures from the data and persists them to the database
	 * @param token
	 * @param rules
	 */
	void generateStructures(String token, StructureDiscoveryRules rules);
	
	/**
	 * Generates structures from the data and persists them to the database
	 * @param rdl CSV data to generate the structures from
	 * @param rules to define how to generate the structures from the data
	 */
	void generateStructures(ReadableDataLocation rdl, StructureDiscoveryRules rules);
	
}
