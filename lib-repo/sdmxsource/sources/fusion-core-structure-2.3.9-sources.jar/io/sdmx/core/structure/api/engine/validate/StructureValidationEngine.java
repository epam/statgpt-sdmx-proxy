package io.sdmx.core.structure.api.engine.validate;

import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Used to validate structures for insertion/deletion from the registry
 * @author Matt Nelson
 *
 */
public interface StructureValidationEngine {

	/**
	 * Validates the structures are okay to be stored, the validation performed here is instance specific.
	 * @param errorHandler the error handler to report error to, which may be null
	 */
	void validateStructuresForInsertion(SdmxBeans beans, IStructureValidationErrorHandler errorHandler);
	
	/**
	 * Validates the structures are okay to be deleted, the validation performed here is instance specific
	 * @param beans
	 */
	void validateStructuresForDeletion(SdmxBeans beans);
	
}
