package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.superbeans.SuperBeans;

/**
 * Manages the retrieval of a SuperBeans container, returning all the known SdmxBeans that the manager is capable of getting
 * 
 * @deprecated not used and not easily implementable wrt. large amounts of metadata & semantic versioning
 */
@Deprecated
public interface SdmxSuperBeansRetreivalManager {
	
	/**
	 * Returns a copy of the SuperBeans from this manager.  Any additions or removals using the API of the returned 
	 * SuperBeans will not be reflected in the beans returned from this manager.
	 * @return
	 */
	SuperBeans getSuperBeans();
	
}
