package io.sdmx.core.structure.engine.merge;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.engine.merge.OrganisationSchemeMergeEngine;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.URN;

public class OrganisationSchemeMergeEngineImpl implements OrganisationSchemeMergeEngine, IFusionSingleton {
	private static OrganisationSchemeMergeEngineImpl INSTANCE;

	public static OrganisationSchemeMergeEngineImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new OrganisationSchemeMergeEngineImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private OrganisationSchemeMergeEngineImpl() {}

	@Override
	public void mergeDefaultAgencySchemeIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager) {
		//1. Merge Any new Agencies with Default Agency Scheme
		for(AgencySchemeBean currentAgencyScheme : beans.getAgenciesSchemes()) {
			if(currentAgencyScheme.getAgencyId().equals(AgencySchemeBean.DEFAULT_SCHEME)) {
				if(currentAgencyScheme.isDefaultScheme()) {
					IMaintainableRef ref = MaintainableRef.getInstance(AgencySchemeBean.DEFAULT_SCHEME, AgencySchemeBean.FIXED_ID, AgencySchemeBean.FIXED_VERSION);
					AgencySchemeBean defaultScheme =beanRetrievalManager.getBean(URN.builder().maint(ref).buildSingle(AgencySchemeBean.class));
					mergeAgencySchemes(defaultScheme, currentAgencyScheme, beans);
				}
			}
		}
	}

	/**
	 * Merges any item schemes in the SdmxBeans with any that already exist in the SdmxBeanRetrievalManager
	 * @param beans
	 */
	@Override
	public void mergeItemSchemesIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager) {
		for(AgencySchemeBean currentAgencyScheme : beans.getAgenciesSchemes()) {
			AgencySchemeBean persistedScheme = beanRetrievalManager.getBean(currentAgencyScheme.getURN());
			mergeAgencySchemes(persistedScheme, currentAgencyScheme, beans);
		}
		for(DataConsumerSchemeBean currentDataConsumerScheme : beans.getDataConsumerSchemes()) {
			DataConsumerSchemeBean persistedScheme = beanRetrievalManager.getBean(currentDataConsumerScheme.getURN());
			if(persistedScheme != null) {
				DataConsumerSchemeMutableBean mutableBean = currentDataConsumerScheme.getMutableInstance();
				for(DataConsumerBean currentDataConsumer : persistedScheme.getItems()) {
					if(!currentDataConsumerScheme.getItems().contains(currentDataConsumer)) {
						mutableBean.addItem(new DataConsumerMutableBeanImpl(currentDataConsumer, mutableBean));
					}
				}
				beans.addIdentifiable(mutableBean.getImmutableInstance());
			}
		}
		for(DataProviderSchemeBean currentDataProviderScheme : beans.getDataProviderSchemes()) {
			DataProviderSchemeBean persistedScheme = beanRetrievalManager.getBean(currentDataProviderScheme.getURN());
			if(persistedScheme != null) {
				DataProviderSchemeMutableBean mutableBean = currentDataProviderScheme.getMutableInstance();
				for(DataProviderBean currentDataProvider : persistedScheme.getItems()) {
					if(!currentDataProviderScheme.getItems().contains(currentDataProvider)) {
						mutableBean.addItem(new DataProviderMutableBeanImpl(currentDataProvider, mutableBean));
					}
				}
				beans.addIdentifiable(mutableBean.getImmutableInstance());
			}
		}
	}

	private void mergeAgencySchemes(AgencySchemeBean toMergeFrom, AgencySchemeBean toMergeInto, SdmxBeans beans) {
		if(toMergeFrom != null && toMergeInto != null) {
			AgencySchemeMutableBean mutableBean = toMergeInto.getMutableInstance();
			for(AgencyBean currentAgency : toMergeFrom.getItems()) {
				if(!toMergeInto.getItems().contains(currentAgency)) {
					mutableBean.addItem(new AgencyMutableBeanImpl(currentAgency, mutableBean));
				}
			}
			beans.addIdentifiable(mutableBean.getImmutableInstance());
		}
	}
}
