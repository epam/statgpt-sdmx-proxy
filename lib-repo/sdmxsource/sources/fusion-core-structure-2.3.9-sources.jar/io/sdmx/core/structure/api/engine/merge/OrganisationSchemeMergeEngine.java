package io.sdmx.core.structure.api.engine.merge;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

public interface OrganisationSchemeMergeEngine {

	/**
	 * If the SdmxBeans contains the default agency scheme, then merge the new scheme with the scheme that the merge manager has access to
	 * @param beans
	 */
	void mergeDefaultAgencySchemeIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Merges any item schemes in the SdmxBeans with any that alredy exist in the SdmxBeanRetrievalManager
	 * @param beans
	 */
	void mergeItemSchemesIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager);
	
	
}
