package io.sdmx.core.structure.model.ref;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.structure.api.model.ref.ZombieReport;

public class ZombieReportImpl implements ZombieReport {

    private Set<MaintainableBean> unreferencedMaintainables;

    public ZombieReportImpl(Set<MaintainableBean> unreferencedMaintainables) {
        this.unreferencedMaintainables = unreferencedMaintainables;
    }

    @Override
    public Set<MaintainableBean> getUnreferencedMaintainables() {
        return unreferencedMaintainables;
    }
}
