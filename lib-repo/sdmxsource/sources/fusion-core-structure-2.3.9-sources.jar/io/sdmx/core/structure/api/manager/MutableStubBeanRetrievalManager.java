
package io.sdmx.core.structure.api.manager;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;


/**
 * This interfaces is responsible for returning stub beans (mutable) from reference objects
 */
public interface MutableStubBeanRetrievalManager {

	/**
	 * Returns a set of maintaintable mutable beans from a structure reference
	 * @param sRef
	 * @return
	 */
	Set<MaintainableMutableBean> getStubBeans(StructureReferenceBean sRef);
}
