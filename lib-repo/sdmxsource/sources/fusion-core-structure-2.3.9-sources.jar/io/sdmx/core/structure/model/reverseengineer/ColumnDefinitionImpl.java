package io.sdmx.core.structure.model.reverseengineer;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean.COMPONENT_TYPE;
import io.sdmx.api.sdmx.model.reverseengineer.ColumnDefinition;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class ColumnDefinitionImpl implements ColumnDefinition {
	private String conceptId;
	private String conceptName;
	private COMPONENT_TYPE componentType;
	
	/**
	 * Built from JSON
	 * {
	 * 	 "ID" : "ConceptId",
	 *   "Name?" : "ConceptName"
	 *   "Type" : "DIMENSION|ATTRIBUTE|MEASURE"
	 *   ...other
	 * }
	 * 
	 */
	public ColumnDefinitionImpl(Map<String, Object> jsonMap) {
		this.conceptId = (String)CollectionUtil.getMapValueEnforcingNotNull(jsonMap, "ID");
		this.conceptName = (String) jsonMap.get("Name");
		if(!ObjectUtil.validString(conceptName)) {
			this.conceptName = conceptId;
		}
		this.componentType = COMPONENT_TYPE.valueOf((String)CollectionUtil.getMapValueEnforcingNotNull(jsonMap, "Type"));
	}

	@Override
	public String getConceptId() {
		return conceptId;
	}
	
	@Override
	public String getConceptName() {
		return conceptName;
	}
	
	@Override
	public COMPONENT_TYPE getComponentType() {
		return componentType;
	}
}
