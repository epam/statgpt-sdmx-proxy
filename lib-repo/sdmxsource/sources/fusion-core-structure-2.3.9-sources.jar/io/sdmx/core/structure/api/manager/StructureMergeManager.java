package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Responsible for merging structures with existing structures from a bean retrieval manager
 *
 */
public interface StructureMergeManager {

	/**
	 * If the SdmxBeans contains the default agency scheme, then merge the new scheme with the scheme that the merge manager has access to
	 * @param beans
	 */
	void mergeDefaultAgencySchemeIfExists(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager);
	
	/**
	 * Merges the names and descriptions from any existing beans
	 * @param beans
	 */
	void mergeNames(SdmxBeans beans, SdmxBeanRetrievalManager beanRetrievalManager);
	
}
