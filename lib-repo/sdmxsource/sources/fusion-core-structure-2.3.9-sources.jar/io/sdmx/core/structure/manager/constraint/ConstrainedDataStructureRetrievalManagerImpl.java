package io.sdmx.core.structure.manager.constraint;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.manager.constraint.ConstrainedDataStructureRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IStructureTimeTravelManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.core.structure.model.constraint.ConstrainedCodesImpl;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.constraint.ContentConstraintModelImpl;
import io.sdmx.im.superbeans.SuperBeansUtil;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class ConstrainedDataStructureRetrievalManagerImpl implements ConstrainedDataStructureRetrievalManager {
	private IStructureTimeTravelManager structureTimeTravelManager;
	
	public ConstrainedDataStructureRetrievalManagerImpl(IStructureTimeTravelManager structureTimeTravelManager) {
		this.structureTimeTravelManager = structureTimeTravelManager;
	}

	@Override
	public SortedSet<SdmxPeriod> getConstraintPeriods(IURNSingle<?> sRef) {
		return getConstraintPeriods(sRef, null);
	}

	@Override
	public SortedSet<SdmxPeriod> getConstraintPeriods(IURNSingle<?> sRef, String componentId) {
		IStructureEnvironment liveEnvironment = structureTimeTravelManager.getEnvironment(null);
		
		ConstrainableBean constrainable = getConstrainable(liveEnvironment, sRef);
		Set<ContentConstraintBean> constraints = liveEnvironment.getConstraintRetrievalManager().getAllConstraintsDefiningAllowedData(constrainable);
		SortedSet<SdmxPeriod> periods = new TreeSet<>();
		for(ContentConstraintBean constraint : constraints) {
			if(componentId == null || constraint.isConstrainingComponent(componentId)) {
				if(constraint.hasValidityPeriod()) {
					periods.add(constraint.getValidityPeriod());
				}
			}
		}
		return periods;
	}

	private ConstrainableBean getConstrainable(IStructureEnvironment environment, IURNSingle<?> sRef) {
		SdmxSuperBeanRetrievalManager superBeanRetrievalManager = environment.getSuperBeanRetrievalManager();
		switch(sRef.getSdmxStructure()) {
		case PROVISION_AGREEMENT:
			ProvisionAgreementSuperBean pa = superBeanRetrievalManager.getProvisionAgreementSuperBean(sRef.toType(ProvisionAgreementBean.class));
			if (pa == null) {
				throw new SdmxNoResultsException("No results for structure; " + sRef);
			}
			return pa.getBuiltFrom();
		case DATAFLOW:
			DataflowSuperBean dfSb = superBeanRetrievalManager.getDataflowSuperBean(sRef.toType(DataflowBean.class));
			if (dfSb == null) {
				throw new SdmxNoResultsException("No results for structure; " + sRef);
			}

			return dfSb.getBuiltFrom();
		case DSD:
			DataStructureSuperBean dsdSb = superBeanRetrievalManager.getDataStructureSuperBean(sRef.toType(DataStructureBean.class));
			if(dsdSb == null) {
				throw new SdmxNoResultsException("No results for structure; " + sRef);
			}
			return dsdSb.getBuiltFrom();
		default:
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "get valid codes for structure type: " +sRef.getSdmxStructure());
		}
	}

	/**
	 * 
	 * @param sRef
	 * @param validFrom
	 * @param validTo
	 * @return
	 */
	@Override
	public ConstrainedCodes getValidCodes(IURNSingle<? extends IDSDRelatedBean> sRef, SdmxDate asOf, Date validFrom, Date validTo) {
		IStructureEnvironment environment = structureTimeTravelManager.getEnvironment(asOf);
		
		IDatasetStructures datasetStructures = new DatasetStructures(sRef, environment.getBeanRetrievalManager());
		DataStructureSuperBean dsdSb = environment.getSuperBeanRetrievalManager().getDataStructureSuperBean(datasetStructures.getDataStructure().getURN());
		ConstrainableBean constrainable = datasetStructures.getConstrainable();
		Set<ContentConstraintBean> constraints = environment.getConstraintRetrievalManager().getAllConstraintsDefiningAllowedData(constrainable);
		Map<String, Set<String>> validCodes = new HashMap<>();
		
		List<ContentConstraintModel> constraintModels = new ArrayList<>();
		Map<String, String> removePrefixes = new HashMap<>();
		for(ContentConstraintBean constraintBean : constraints) {
			for(ContentConstraintModel model : ContentConstraintModelImpl.build(constraintBean, dsdSb, false)) {
				if(model.hasValidityPeriod() && !model.getValidityPeriod().isInPeriod(validFrom, validTo)) {
					continue;
				}
				constraintModels.add(model);
				removePrefixes.putAll(model.getRemovePrefixes());
			}
		}
		
		//Modify DSD Codelists if required, then build picture of what is valid
		dsdSb = SuperBeansUtil.removeCodeIdPrefixes(dsdSb, removePrefixes);
		for(ComponentSuperBean<?> comp : dsdSb.getComponents()) {
			EnumeratedListBean<?>  cl = comp.getCodelist(true);
			if(cl != null) {
				if(cl instanceof CodelistBean) {
					cl = processValidityPeriods((CodelistBean)cl, validFrom, validTo);
				}
				validCodes.put(comp.getId(), getIdSet(cl));
			}
		}

		Map<String, Set<String>> excludeCodes = new HashMap<>();
		Set<ContentConstraintBean> constraintUsed = new HashSet<>(constraintModels.size());
		for(ContentConstraintModel model : constraintModels) {
			constraintUsed.add(model.getBuiltFrom());
			for(String dimId : validCodes.keySet()) {
				Set<String> validValues = model.getValidValues(dimId);
				if(validValues != null) {
					if(validCodes.get(dimId) == null) {
						validCodes.put(dimId, new HashSet<>(validValues));
					} else {
						validCodes.get(dimId).retainAll(validValues);
					}
				} else if(ObjectUtil.validCollection(validCodes.get(dimId))){
					Set<String> excluded = model.getExcludedValues(dimId);
					if(excluded != null) {
						CollectionUtil.addToMappedSet(excludeCodes, dimId, excluded);
					}
				}
			}
		}
		for(String excludedDim : excludeCodes.keySet()) {
			validCodes.get(excludedDim).removeAll(excludeCodes.get(excludedDim));
		}
		
		return new ConstrainedCodesImpl(dsdSb, validCodes, datasetStructures, constraintUsed);
	}
	
	private Set<String> getIdSet(EnumeratedListBean<?> itemScheme) {
		return itemScheme.getItems().stream().map( e -> e.getId()).collect(Collectors.toSet());
	}

	/**
	 * Creates a partial codelist if the codelist has validity period on codes which require stripping based on the valid
	 * from and valid to information
	 * @param codelist
	 * @param queryValidFrom
	 * @param queryValidTo
	 * @return
	 */
	private CodelistBean processValidityPeriods(CodelistBean codelist, Date queryValidFrom, Date queryValidTo){
		if(queryValidFrom == null && queryValidTo == null) {
			return codelist;
		}
		SdmxPeriod queryPeriod = new SdmxPeriodImpl(queryValidFrom, queryValidTo, TIME_FORMAT.DATE_TIME);
		Set<String> stripCodes = new HashSet<>();
		for (CodeBean code : codelist.getItems()) {
			if(codelist.itemsHasValidityPeriod()){
				SdmxPeriod codeValidityPeriod = code.getValidityPeriod();
				if(codeValidityPeriod != null){
					if(!codeValidityPeriod.isInPeriod(queryPeriod)){
						stripCodes.add(code.getId());
					}
				}
			}
		}
		if(stripCodes.size() == 0) {
			return codelist;
		}
		return codelist.filterItems(stripCodes, false);
	}
	
	

	@Override
	public EnumeratedListBean<? extends EnumeratedItemBean> getPartialCodelist(
			IURNSingle<? extends IDSDRelatedBean> constrsRefainable, String componentId, Date validFrom,
			Date validTo) {
		ConstrainedCodes constrainedCodes = getValidCodes(constrsRefainable, null, validFrom, validTo);
		return constrainedCodes.getCodelist(componentId);
	}
}
