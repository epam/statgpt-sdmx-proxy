package io.sdmx.core.structure.manager.reverseengineer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.api.sdmx.model.reverseengineer.CodedDimensionCoumnDefinition;
import io.sdmx.api.sdmx.model.reverseengineer.CodedDimensionCoumnDefinition.ID_GENERATION_STRATEGY;
import io.sdmx.api.sdmx.model.reverseengineer.ColumnDefinition;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;
import io.sdmx.api.sdmx.model.reverseengineer.UncodedColumnDefinition;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.manager.StructureDiscoveryManager;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.reference.MaintainableProperties;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.ValidationUtil;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StructureDiscoveryManagerImpl implements StructureDiscoveryManager, IFusionSingleton {
	private static StructureDiscoveryManagerImpl INSTANCE;

	public static StructureDiscoveryManagerImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureDiscoveryManagerImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private StructureDiscoveryManagerImpl() {}

	@Override
	public SdmxBeans buildStructures(ColumnReaderEngine columnReader, StructureDiscoveryRules rules, SdmxBeanRetrievalManager retrievalManager) {
		DataStructureMutableBean dsmBean = new DataStructureMutableBeanImpl();
		dsmBean.setId(rules.getDataStructureId());
		dsmBean.setAgencyId(rules.getAgencyId());
		dsmBean.addName("en", rules.getDataStructureName());

		List<? extends ColumnDefinition> columnDefs = rules.getColumnDefinitions();


		IMaintainableRef conceptSchemeRef = MaintainableRef.getInstance(rules.getAgencyId(), rules.getConceptSchemeId(), "1.0");
		ConceptSchemeBean csBean = createConceptSchemeBean(conceptSchemeRef, rules.getConceptSchemeId(), columnDefs);
		for (ColumnDefinition def: columnDefs){
			ComponentMutableBean component = getComponentFromDefinition(def, conceptSchemeRef);
			if(component instanceof DimensionMutableBean) {
				dsmBean.addDimension((DimensionMutableBean) component);
			} else if(component instanceof MeasureMutableBean) {
				dsmBean.addMeasure((MeasureMutableBean) component);
			} else if(component instanceof AttributeMutableBean) {
				dsmBean.addAttribute((AttributeMutableBean) component);
			}
		}

		List<CodedDimensionCoumnDefinition> codedColumns = new ArrayList<>();
		for(ColumnDefinition colDef : rules.getColumnDefinitions()) {
			if(colDef instanceof CodedDimensionCoumnDefinition) {
				codedColumns.add((CodedDimensionCoumnDefinition)colDef);
			}
		}
		SdmxBeans smdxBeans = new SdmxBeansImpl();
		deriveStructuresFromData(smdxBeans, dsmBean, columnReader, codedColumns);

		List<String> dimenisonIdsExcludingTime = new ArrayList<>();
		if(dsmBean.getDimensionList() != null) {
			for(DimensionMutableBean dim : dsmBean.getDimensionList().getDimensions()) {
				dimenisonIdsExcludingTime.add(dim.getId());
			}
		}
		if(dsmBean.getAttributeList() != null) {
			for(AttributeMutableBean attr : dsmBean.getAttributeList().getAttributes()) {
				if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
					attr.setDimensionReferences(dimenisonIdsExcludingTime);
				}
			}
		}

		smdxBeans.addIdentifiable(dsmBean.getImmutableInstance());
		smdxBeans.addIdentifiable(csBean);
		return smdxBeans;
	}

	/**
	 * Walks the data reader engine to determine the codelists, and if any components are set to min/max length this is derived here
	 * @param beans
	 * @param dsdBean - required to modify any Codelist references if they are changed to ValueLists
	 * @param cre
	 * @param codedDefinitions
	 */
	private void deriveStructuresFromData(SdmxBeans beans, DataStructureMutableBean dsdBean, ColumnReaderEngine cre, List<CodedDimensionCoumnDefinition> codedDefinitions) {
		List<DiscoveredCodelist> discoveredCodelists = new ArrayList<>();
		for(CodedDimensionCoumnDefinition colDef : codedDefinitions) {
			discoveredCodelists.add(new DiscoveredCodelist(colDef));
		}
		cre.reset();
		while(cre.moveNextRow()) {
			for(DiscoveredCodelist cl : discoveredCodelists) {
				cl.processRow(cre.readRow(), "en");  //TODO Default Locale
			}
		}

		//MERGE
		Map<String, DiscoveredCodelist> discoveredCodelistsByUrn = new HashMap<>();
		for(DiscoveredCodelist cl : discoveredCodelists) {
			String shortUrn = cl.getShortUrn();
			DiscoveredCodelist existing = discoveredCodelistsByUrn.get(shortUrn);
			if(existing != null) {
				existing.merge(cl);
			} else {
				discoveredCodelistsByUrn.put(shortUrn, cl);
			}
		}
		for(DiscoveredCodelist cl : discoveredCodelistsByUrn.values()) {
			EnumeratedListBean enumList = cl.createEnumeration();
			if(enumList.getStructureType()  == SDMX_STRUCTURE_TYPE.VALUE_LIST) {
				//Change codelist reference to value list
				StructureReferenceBean changeRef = enumList.asReference();
				if(dsdBean.getDimensions() != null) {
					for(ComponentMutableBean comp : dsdBean.getDimensions()) {
						changeRepresentation(comp, changeRef);
					}
				}
				if(dsdBean.getMeasureList() != null) {
					for(ComponentMutableBean comp : dsdBean.getMeasureList().getMeasures()) {
						changeRepresentation(comp, changeRef);
					}
				}
				if(dsdBean.getAttributes() != null) {
					for(ComponentMutableBean comp : dsdBean.getAttributes()) {
						changeRepresentation(comp, changeRef);
					}
				}
			}

			beans.addIdentifiable(enumList);
		}
	}

	/**
	 * If the component is referencing a codelist of the same agency, id, and version as the value list, the reference is updated
	 * to reference the value list
	 * @param comp
	 * @param vlRef
	 */
	private void changeRepresentation(ComponentMutableBean comp, StructureReferenceBean vlRef) {
		if(comp.getRepresentation() != null &&
				comp.getRepresentation().getRepresentation() != null &&
				comp.getRepresentation().getRepresentation().getTargetUrn().split("=")[1].equals(vlRef.getTargetUrn().split("=")[1])) {
			comp.getRepresentation().setRepresentation(vlRef);
		}
	}


	/**
	 * Creates and initialises a ConceptScheme, as well as the contained Concepts.
	 * @param ref - reference to create ConceptScheme with.
	 * @param name ConceptScheme name.
	 * @param columnDefs ColumnDefinitions to create concepts from.
	 * @return Created and initialised ConceptScheme.
	 */
	private ConceptSchemeBean createConceptSchemeBean(IMaintainableRef ref, String name, List<? extends ColumnDefinition> columnDefs)
	{
		ConceptSchemeMutableBean csmb = new ConceptSchemeMutableBeanImpl();
		csmb.addName("en", name);
		csmb.setAgencyId(ref.getAgencyId());
		csmb.setId(ref.getMaintainableId());
		csmb.setVersion(ref.getVersion());

		for(ColumnDefinition def : columnDefs) {
			ConceptMutableBean concept = ConceptMutableBeanImpl.getInstance(def.getConceptId(), def.getConceptName());
			csmb.addItem(concept);
		}
		return csmb.getImmutableInstance();
	}

	/**
	 *
	 * @param colDef Column Definition
	 * @param csRef Concept Scheme Reference
	 * @return
	 */
	private ComponentMutableBean getComponentFromDefinition(ColumnDefinition colDef, IMaintainableRef csRef) 	{
		ComponentMutableBean component = createComponent(colDef);
		component.setConceptRef(new StructureReferenceBeanImpl(csRef, SDMX_STRUCTURE_TYPE.CONCEPT, colDef.getConceptId()));
		RepresentationMutableBean representation = new RepresentationMutableBeanImpl();
		component.setRepresentation(representation);
		if (colDef instanceof CodedDimensionCoumnDefinition) {
			processCodedColumns((CodedDimensionCoumnDefinition) colDef, component);
		} else {
			processTextColumns((UncodedColumnDefinition) colDef, component);
		}
		return component;
	}

	/**
	 * Maps ColumnId and ColumnName positions to their respective CodedDimensionColumnDefinitions.
	 * @param colDef - ColumnDefinition to map.
	 * @param ci - ColumnMap
	 */
	private void processCodedColumns(CodedDimensionCoumnDefinition colDef, ComponentMutableBean component) 	{
		component.getRepresentation().setRepresentation(new StructureReferenceBeanImpl(colDef.getCodelistIdentifiers(), SDMX_STRUCTURE_TYPE.CODE_LIST));
	}

	/**
	 * Processes TextColumnDefinitions using the given ConceptScheme and creates Dimensions.
	 * @param colDef - TextColumnDefinitions to process.
	 * @param csBean - ConceptScheme to work with.
	 * @param header - Data header toe extract dimension names from.
	 * @return created DimensionMutableBean
	 */
	private void processTextColumns(UncodedColumnDefinition colDef, ComponentMutableBean component)	{
		TextFormatMutableBean formatBean = new TextFormatMutableBeanImpl();
		if(colDef.getConceptId().equals("TIME_PERIOD")) {
			formatBean.setTextType(TEXT_TYPE.OBSERVATIONAL_TIME_PERIOD);
		} else {
			formatBean.setTextType(colDef.getTextType());
		}
		component.getRepresentation().setTextFormat(formatBean);
	}

	/**
	 * creates the correct DSD Component from the column definition
	 * @param def
	 * @return
	 */
	private ComponentMutableBean createComponent(ColumnDefinition def) {
		switch(def.getComponentType()) {
		case DIMENSION :
			DimensionMutableBean dim = new DimensionMutableBeanImpl();
			if(def.getConceptId().equals("TIME_PERIOD")) {
				dim.setTimeDimension(true);
			}
			return dim;
		case ATTRIBUTE :
			AttributeMutableBean att = new AttributeMutableBeanImpl();
			//TODO Attribute Attachment
			att.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
			//TODO Attribute is Mandatory
			att.setMandatory(false);

			return att;
		case MEASURE : return new MeasureMutableBeanImpl();
		}
		throw new SdmxNotImplementedException("Unsupported Component Type: " + def.getComponentType());
	}



	private class DiscoveredCodelist {
		private Integer idColumn;
		private Map<Integer, String> nameColumn; 		//column index to locale
		private Map<Integer, String> descriptionColumn; //column index to locale
		private ID_GENERATION_STRATEGY idGenerationStrategy;

		//Id to Code
		private Map<String, DiscoveredCode> discoveredCodes = new TreeMap<>();
		private Map<String, DiscoveredCode> codeByName = new HashMap<>();

		private CodedDimensionCoumnDefinition def;
		public DiscoveredCodelist(CodedDimensionCoumnDefinition def) {
			this.def = def;
			this.idColumn = def.getIdColumn();
			this.nameColumn = def.getNameColumn();
			if(!ObjectUtil.validMap(nameColumn)) {
				nameColumn = null;
			}
			this.descriptionColumn = def.getDescriptionColumn();
			this.idGenerationStrategy = def.getIdGenerationStrategy();
		}

		public void merge(DiscoveredCodelist cl) {
			for(String codeId : cl.discoveredCodes.keySet()) {
				DiscoveredCode toMergeCode = cl.discoveredCodes.get(codeId);
				DiscoveredCode existingCode = this.discoveredCodes.get(codeId);
				if(existingCode != null) {
					existingCode.merge(toMergeCode);
				} else {
					this.discoveredCodes.put(codeId, toMergeCode);
				}
			}
		}

		/**
		 * Builds the final Codelist or ValueList from the extracted information
		 * @return
		 */
		public EnumeratedListBean createEnumeration() {
			boolean isCodelist = true;
			boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
			try {
				SdmxException.disableExceptionTrace(true);
				for(String codeId : discoveredCodes.keySet()) {
					try {
						codeId = ValidationUtil.cleanAndValidateId(codeId, true);
					} catch(SdmxSemmanticException e) {
						isCodelist = false;
						break;
					}
				}
			} finally {
				SdmxException.disableExceptionTrace(wasDisabled);
			}
			if(isCodelist) {
				CodelistMutableBean clMutable = new CodelistMutableBeanImpl();
				populateMaintainableProperties(clMutable);
				for(String codeId : discoveredCodes.keySet()) {
					DiscoveredCode code = discoveredCodes.get(codeId);
					clMutable.addItem(code.buildCode());
				}
				return clMutable.getImmutableInstance();
			}
			ValueListMutableBean valueList = new ValueListMutableBeanImpl();
			populateMaintainableProperties(valueList);
			for(String codeId : discoveredCodes.keySet()) {
				DiscoveredCode code = discoveredCodes.get(codeId);
				valueList.addItem(code.buildItem());
			}
			return valueList.getImmutableInstance();
		}

		public String getShortUrn() {
			IMaintainableProperties ref = getMaintainableProperties();
			return ref.getAgencyId() + ":"+ref.getId()+"("+ref.getVersion()+")";
		}

		public IMaintainableProperties getMaintainableProperties() {
			String agencyId = def.getCodelistIdentifiers().getAgencyId();
			String id = def.getCodelistIdentifiers().getMaintainableId();
			String version = def.getCodelistIdentifiers().getVersion().toString();
			return MaintainableProperties.getInstance(agencyId, id, version);
		}

		private void populateMaintainableProperties(MaintainableMutableBean maint) {
			IMaintainableProperties ref = getMaintainableProperties();
			maint.setMaintainableProperties(ref);
			maint.addName("en", maint.getId());
		}

		/**
		 * Processes a row of data
		 * @param row
		 */
		public void processRow(List<String> row, final String defaultLocale) {
			String id = null;

			Map<String, String> codeNames = new HashMap<>();
			String defaultName = null;
			if(nameColumn != null) {
				for(Integer namePos : nameColumn.keySet()) {
					String nameValue = getRowValue(row, namePos);
					if(nameValue != null) {
						//Set default name to either the first encountered, or overwrite it to the one
						//with the default locale.
						String locale = nameColumn.get(namePos);
						if(defaultName == null) {
							defaultName = nameValue;
						} else if(locale.equals(defaultLocale)) {
							defaultName = nameValue;
						}
						codeNames.put(locale, nameValue);
					}
				}
			}

			DiscoveredCode code;
			if(idColumn != null) {
				id = getRowValue(row, idColumn);
				if(!ObjectUtil.validString(id)) {
					//No reported value
					return;
				}
				code = discoveredCodes.get(id);
			} else {
				code = codeByName.get(defaultName.toLowerCase());
				if(code == null) {
					switch(idGenerationStrategy) {
					case AUTO_INCREMENT_ALPHA:
						int numCodes = discoveredCodes.size();

						break;
					case AUTO_INCREMENT_NUMERICAL:
						id = ""+discoveredCodes.size();

						break;
					case FIRST_LETTER_ONLY:
						id = getFirstNLetters(defaultName, 1);
						break;
					case FIRST_TWO_LETTERS:
						id = getFirstNLetters(defaultName, 2);
						break;
					case FIRST_THREE_LETTERS:
						id = getFirstNLetters(defaultName, 3);
						break;
					case FIRST_OF_EACH_WORD:
						String[] split = defaultName.split(" ");
						StringBuilder sb = new StringBuilder();
						for(String currentWord : split) {
							sb.append(currentWord.substring(0,1).toUpperCase());
						}
						id = sb.toString();
						break;
					default:
						break;
					}
				}
			}
			if(code == null) {
				code = new DiscoveredCode(id);
				discoveredCodes.put(id, code);
			}
			if(nameColumn == null) {
				code.addCodeName("en", id);
			} else {
				for(Integer namePos : nameColumn.keySet()) {
					String nameValue = getRowValue(row, namePos);
					if(nameValue != null) {
						code.addCodeName(nameColumn.get(namePos), nameValue);
					}
				}
			}
			if(descriptionColumn != null) {
				for(Integer namePos : descriptionColumn.keySet()) {
					String nameValue = getRowValue(row, namePos);
					if(nameValue != null) {
						code.addCodeDescription(descriptionColumn.get(namePos), nameValue);
					}
				}
			}
		}

		private String getFirstNLetters(String str, int n) {
			return str.substring(0, n).toUpperCase();
		}


		/**
		 * Read the value from the current row with protection against ArrayIndexOutOfBoundsException
		 * @param pos
		 * @return
		 */
		private String getRowValue(List<String> row, Integer pos) {
			if(pos == null) {
				return null;
			}
			if(row.size() <= pos) {
				return null;
			}
			return row.get(pos);
		}
	}


	private class DiscoveredCode {
		String codeId;
		Map<String, Set<String>> codeNames = new HashMap<>();  //locale to names that the code has (it may need cleaning)
		Map<String, Set<String>> codeDescriptions = new HashMap<>();

		public DiscoveredCode(String id) {
			this.codeId = id;
		}

		public void merge(DiscoveredCode code) {
			mergeSets(this.codeNames, code.codeNames);
			mergeSets(this.codeDescriptions, code.codeDescriptions);
		}

		private void mergeSets(Map<String, Set<String>> existingLabels, Map<String, Set<String>> newLabels) {
			for(String locale : newLabels.keySet()) {
				Set<String> newNames = newLabels.get(locale);
				Set<String> existingNames = existingLabels.get(locale);
				if(existingNames == null) {
					existingLabels.put(locale, newNames);
				} else {
					existingNames.addAll(newNames);
				}
			}
		}

		public void addCodeName(String locale, String name) {
			name = name.trim();
			if(name.length() > 0) {
				CollectionUtil.addToMappedSet(codeNames, locale, name);
			}
		}
		public void addCodeDescription(String locale, String name) {
			name = name.trim();
			if(name.length() > 0) {
				CollectionUtil.addToMappedSet(codeDescriptions, locale, name);
			}
		}

		public ValueItemMutableBean buildItem() {
			ValueItemMutableBean code = new ValueItemMutableBeanImpl();
			code.setId(codeId);
			for(String nameLocale : codeNames.keySet()) {
				code.addName(nameLocale, reolveValue(codeNames.get(nameLocale)));
			}
			for(String nameLocale : codeDescriptions.keySet()) {
				code.addDescription(nameLocale, reolveValue(codeDescriptions.get(nameLocale)));
			}
			return code;
		}

		public CodeMutableBean buildCode() {
			CodeMutableBean code = new CodeMutableBeanImpl();
			code.setId(codeId);
			for(String nameLocale : codeNames.keySet()) {
				code.addName(nameLocale, reolveValue(codeNames.get(nameLocale)));
			}
			for(String nameLocale : codeDescriptions.keySet()) {
				code.addDescription(nameLocale, reolveValue(codeDescriptions.get(nameLocale)));
			}
			return code;
		}

		private String reolveValue(Set<String> strings) {
			String str = null;
			for(String string : strings) {
				if(str == null) {
					str = string;
				} else if(!str.equalsIgnoreCase(string)) {
					//Report Ambigeous Value
					throw new SdmxSemmanticException("Ambiguous values for code: "+codeId);
				}
			}
			return str;
		}
	}
}
