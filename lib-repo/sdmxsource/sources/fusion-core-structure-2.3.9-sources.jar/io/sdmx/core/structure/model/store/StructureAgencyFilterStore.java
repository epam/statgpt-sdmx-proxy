package io.sdmx.core.structure.model.store;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

class StructureAgencyFilterStore<T>  extends AbstractStructureFilterStore<T> {
	private Map<String, StructureIdFilterStore<T>> idStoreMap = new HashMap<>();

	@Override
	public void store(IURN<?> urn, T toStore) {
		String id = urn.getMaintainableId();
		StructureIdFilterStore<T> idStore = idStoreMap.get(id);
		if(idStore == null) {
			idStore = new StructureIdFilterStore<>();
			idStoreMap.put(id, idStore);
		}
		idStore.store(urn, toStore);
	}

	@Override
	public Set<T> find(MaintainableBean maint) {
		Set<T> returnSet = new HashSet<>();
		returnSet.addAll(get(maint, idStoreMap.get(null)));
		returnSet.addAll(get(maint, idStoreMap.get(maint.getId())));
		return returnSet;
	}

}
