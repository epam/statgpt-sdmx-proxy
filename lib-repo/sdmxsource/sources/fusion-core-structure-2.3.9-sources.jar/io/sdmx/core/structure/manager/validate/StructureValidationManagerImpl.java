package io.sdmx.core.structure.manager.validate;

import java.io.ByteArrayOutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.ReadableDataLocationFactory;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.core.structure.api.manager.StructureValidationManager;
import io.sdmx.utils.core.io.StreamUtil;

public class StructureValidationManagerImpl implements StructureValidationManager {
	
	private StructureReaderManager structureParsingManager;
	private StructureWriterManager structureWritingManager;
	private ReadableDataLocationFactory readableDataLocationFactory;
	
	public StructureValidationManagerImpl(StructureReaderManager structureParsingManager, StructureWriterManager structureWritingManager, ReadableDataLocationFactory readableDataLocationFactory) {
		this.structureParsingManager = structureParsingManager;
		this.structureWritingManager = structureWritingManager;
		this.readableDataLocationFactory = readableDataLocationFactory;
	}
	
	@Override
	public void validateStructure(MaintainableBean maintainableBean) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		structureWritingManager.writeStructure(maintainableBean, null, new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT), out);
		ReadableDataLocation dataLocation = readableDataLocationFactory.getReadableDataLocation(out.toByteArray());
		try {
			structureParsingManager.parseStructures(dataLocation);
		} finally {
			dataLocation.close();
			StreamUtil.closeStream(out);
		}
	}
}
