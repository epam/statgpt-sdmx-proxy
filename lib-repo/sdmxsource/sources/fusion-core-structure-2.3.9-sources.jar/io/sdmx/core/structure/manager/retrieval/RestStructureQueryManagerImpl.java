package io.sdmx.core.structure.manager.retrieval;

import java.io.OutputStream;

import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.manager.retrieval.rest.RestStructureQueryManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;


public class RestStructureQueryManagerImpl implements RestStructureQueryManager {

	private StructureWriterManager structureWritingManager;
	private ISdmxBeanRestRetrievalManager beanRetrievalManager;

	public RestStructureQueryManagerImpl(StructureWriterManager structureWritingManager, ISdmxBeanRestRetrievalManager beanRetrievalManager) {
		this.structureWritingManager = structureWritingManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}

	public void getStructures(RESTStructureQuery query, OutputStream out, StructureFormat outputFormat) {
		SdmxBeans beans = beanRetrievalManager.getMaintainables(query);
		structureWritingManager.writeStructures(beans, outputFormat, out);
	}
}
