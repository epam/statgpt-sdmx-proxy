package io.sdmx.core.structure.model.diff;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.audit.ITXLog;
import io.sdmx.api.sdmx.model.diff.BeanDiff;
import io.sdmx.api.sdmx.model.diff.TransactionChangeLog;

/**
 * Describes a change between the same structure at for different transactions (i.e modifications to the same codelist)
 */
public class TransactionChangeLogImpl extends ChangelogImpl implements TransactionChangeLog {
	private ITXLog sourceTx;
	private ITXLog targetTx;

	public TransactionChangeLogImpl(BeanDiff diff, ITXLog sourceTx, ITXLog targetTx){
		super(diff);
		this.sourceTx = sourceTx;
		this.targetTx = targetTx;
	}

	@Override
	protected JSONObject toJsonObject() {
		JSONObject jsonObject = super.toJsonObject();
		try {
			JSONObject tx = new JSONObject();
			tx.put("SourceDate", sourceTx.getCreated());
			tx.put("TargetDate", targetTx.getCreated());
			jsonObject.put("Transaction", tx);
		} catch (JSONException e) {
			throw new RuntimeException("error writing TransactionChangeLog",e);
		}
		return jsonObject;
	}
}
