package io.sdmx.core.structure.engine.merge;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ConceptSchemeMergeEngine implements MaintainableMergeEngine<ConceptSchemeBean>, IFusionSingleton {
	private static ConceptSchemeMergeEngine INSTANCE;

	public static ConceptSchemeMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ConceptSchemeMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private ConceptSchemeMergeEngine() {}

	@Override
	public ConceptSchemeBean mergeMaintainables(ConceptSchemeBean maint1, ConceptSchemeBean maint2) {
		if(maint1 != null && maint2 != null) {
			Set<ConceptBean> itemSet = new HashSet<>(maint1.getItems());

			ConceptSchemeMutableBean returnScheme = maint1.getMutableInstance();
			for (ConceptBean aItem: maint2.getItems()) {
				if (itemSet.contains(aItem)) {
					continue;
				}
				ConceptMutableBean conceptMutableBean = new ConceptMutableBeanImpl(aItem, returnScheme);
				returnScheme.addItem(conceptMutableBean);
			}
			return returnScheme.getImmutableInstance();
		}
		if(maint1 == null) {
			return maint2;
		}
		if(maint2 == null) {
			return maint1;
		}
		return null;
	}
}
