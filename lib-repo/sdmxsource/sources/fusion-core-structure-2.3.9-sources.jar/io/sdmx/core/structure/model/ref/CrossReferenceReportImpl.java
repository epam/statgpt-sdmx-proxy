package io.sdmx.core.structure.model.ref;

import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.structure.api.model.ref.CrossReferenceReport;

public class CrossReferenceReportImpl implements CrossReferenceReport {
    private Map<IdentifiableBean, Set<IdentifiableBean>> references;
    private Map<MaintainableBean, Set<IdentifiableBean>> referencedBy;
    private Map<MaintainableBean, Set<IdentifiableBean>> maintReferences;

    public CrossReferenceReportImpl(
                Map<IdentifiableBean, Set<IdentifiableBean>> references,
                Map<MaintainableBean, Set<IdentifiableBean>> referencedBy,
                Map<MaintainableBean, Set<IdentifiableBean>> maintReferences ) {
        this.references = references;
        this.referencedBy = referencedBy;
        this.maintReferences = maintReferences;
    }

    @Override
    public Map<IdentifiableBean, Set<IdentifiableBean>> getReferences() {
        return references;
    }

    @Override
    public Map<MaintainableBean, Set<IdentifiableBean>> getReferencedBy() {
        return referencedBy;
    }

    @Override
    public Map<MaintainableBean, Set<IdentifiableBean>> getMaintReferences() {
        return maintReferences;
    }
}