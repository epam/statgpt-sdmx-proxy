package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.event.SdmxBeansEvent;

/**
 * Performs operations based on structure modifications in the database
 */
public interface StructurePostProcessManager {

	/**
	 * Called after a SdmxBeansEvent (new structures committed) in the DAO layer
	 * @param beansEvent
	 */
	void postProces(SdmxBeansEvent beansEvent);
	
}
