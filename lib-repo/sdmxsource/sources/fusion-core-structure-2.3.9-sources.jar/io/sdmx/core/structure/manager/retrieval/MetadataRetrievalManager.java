package io.sdmx.core.structure.manager.retrieval;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.IStructureTimeTravelManager;
import io.sdmx.api.sdmx.manager.structure.IURNReferenceRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.IURNRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.IStructureEnvironment;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURN.REFERENCE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNMultiple;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.structure.api.manager.IMetadataRetrievalManager;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;



public class MetadataRetrievalManager implements IMetadataRetrievalManager {
	
	private IStructureTimeTravelManager timeTravelManager;
	
	public MetadataRetrievalManager(IStructureTimeTravelManager timeTravelManager) {
		this.timeTravelManager = timeTravelManager;
	}

	@Override
	public IReportedMetadataSetBean getMetadata(IURNMaintainable<IReportedMetadataSetBean> ref, SdmxDate asOf) {
		return timeTravelManager.getEnvironment(asOf).getBeanRetrievalManager().getBean(ref);
	}

	@Override
	public Set<IReportedMetadataSetBean> findByMetadataSet(IURN<IReportedMetadataSetBean> ref, SdmxDate asOf) {
		return timeTravelManager.getEnvironment(asOf).getBeanRetrievalManager().getMaintainableBeans(ref);
	}

	@Override
	public Set<IReportedMetadataSetBean> findByMetadataflow(IURN<MetadataFlowBean> ref, IURN<IMetadataProviderBean> providerRef, SdmxDate asOf) {
		IStructureEnvironment environment = timeTravelManager.getEnvironment(asOf);
		Set<IURNMaintainable<IReportedMetadataSetBean>> urns = resolveReferences(ref, environment, IReportedMetadataSetBean.class);
		
		//Get the provisions that reference the flow
		Set<IURNMaintainable<MetadataProvisionAgreementBean>> metadataProvs = resolveReferences(ref, environment, MetadataProvisionAgreementBean.class);
		for(IURNMaintainable<MetadataProvisionAgreementBean> currentMP : metadataProvs) {
		    urns.addAll(resolveReferences(currentMP, environment, IReportedMetadataSetBean.class));
		}
		
		//filter URNs by Provider, note the agency ID of the metadata set is the provider ID
		if(providerRef != null) {
			List<IMetadataProviderBean> metadataProviders = new ArrayList<>();
			if(providerRef.getReferenceType().isSingle()) {
				//TODO
			} else {
				//TODO
			}
		}
		
		return resolveUrns(environment.getBeanRetrievalManager(),  urns);
	}

	@Override
	public Set<IReportedMetadataSetBean> findByStructure(IURN<?> urn, SdmxDate asOf) {
		IStructureEnvironment environment = timeTravelManager.getEnvironment(asOf);
		Set<IURNMaintainable<IReportedMetadataSetBean>> urns = resolveReferences(urn, environment, IReportedMetadataSetBean.class);

		Set<IReportedMetadataSetBean> response = resolveUrns(environment.getBeanRetrievalManager(),  urns);
		//Filter out matches that are only because of the metadataflow
		if(urn.getSdmxStructure() == SDMX_STRUCTURE_TYPE.ANY || urn.getSdmxStructure() == SDMX_STRUCTURE_TYPE.METADATA_FLOW) {
		    Set<IReportedMetadataSetBean> filteredMetadataSet = new HashSet<>(response.size());
		    for(IReportedMetadataSetBean mds : response) {
		        if(mds.getStructure().getReference().isMatch(urn)) {
		            //matches on the linked MSD/MDF or Metadata Provision, does it also match on the
		            if(isMatch(mds, urn)) {
		                filteredMetadataSet.add(mds);
		            }
		        } else {
		            filteredMetadataSet.add(mds);
		        }
		    }
		    response = filteredMetadataSet;
		}
		return response;
	}
	
	private boolean isMatch(IReportedMetadataSetBean mds, IURN<?> target) {
        for(ICrossReferenceBeanBase xs : mds.getTargets()) {
            if(xs.getReference().isMatch(target)) {
                return true;
            }
        }
        return false;
    }
	
	/**
	 * @param searchByUrn
	 * @return all the IReportedMetadataSetBean URNs which cross reference the given URN
	 */
	private <T extends MaintainableBean> Set<IURNMaintainable<T>> resolveReferences(IURN<?> searchByUrn, IStructureEnvironment environment, Class<T> claz) {
		IURNReferenceRetreivalManager urnReferenceRetrievalManager =  environment.getURNReferenceRetreivalManager();
		IURNRetrievalManager urnRetrievalManager =  environment.getURNRetrievalManager();
		
		Set<IURNMaintainable<T>> urns = new HashSet<>();
		if(searchByUrn.getReferenceType() == REFERENCE_TYPE.ABSOLUTE) {
			urns.addAll(urnReferenceRetrievalManager.whoReferencesMe(searchByUrn.asAbsolute(), false, true, claz));
		} else if(searchByUrn.isWildcard()) {
			Set<IURNMaintainable<?>> allUrns = urnRetrievalManager.find(searchByUrn);
			allUrns.forEach(maintUrn -> {
				IURNAbsolute<?> target = maintUrn;
				if(!searchByUrn.getStructureType().isAny() && !searchByUrn.isMaintainableReference()) {
					URNBuilder urnBuilder = URN.builder(maintUrn).structure(searchByUrn.getStructureType());
					if(searchByUrn.getReferenceType() == REFERENCE_TYPE.MULTIPLE) {
						IURNMultiple<?> wildcardUrn = searchByUrn.asMultiple();
						if(ObjectUtil.validCollection(wildcardUrn.getIdentifiableIds())) {
							for(String identifiableId : wildcardUrn.getIdentifiableIds()) {
								target = urnBuilder.identifableId(identifiableId).buildAbsolute();
								urns.addAll(urnReferenceRetrievalManager.whoReferencesMe(target, false, true, claz));
							}
						} else {
							urns.addAll(urnReferenceRetrievalManager.whoReferencesMe(target, false, true, claz));
						}
					} else {
					    if(searchByUrn.hasIdentifiableId()) {
					        urnBuilder.identifableId(searchByUrn.getFullIdentifiableId());
					    } else {
					        urnBuilder.structure(searchByUrn.getMaintainableURN().getStructureClass());
					    }
						target = urnBuilder.buildAbsolute();
						urns.addAll(urnReferenceRetrievalManager.whoReferencesMe(target, false, true, claz));
					}
				} else {
					urns.addAll(urnReferenceRetrievalManager.whoReferencesMe(target, false, true, claz));
				}
			});
		}
		return urns;
	}
	
	private Set<IReportedMetadataSetBean> resolveUrns(SdmxBeanRetrievalManager beanRetrievalManager, Set<IURNMaintainable<IReportedMetadataSetBean>> urns) {
		final Set<IReportedMetadataSetBean> returnSet = new HashSet<>(urns.size());
		urns.forEach(urn -> {
			IReportedMetadataSetBean metadataSet = beanRetrievalManager.getBean(urn);
			if(metadataSet != null) {
				returnSet.add(metadataSet);
			}
		});
		return returnSet;
	}
	
}
