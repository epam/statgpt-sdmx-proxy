package io.sdmx.core.structure.model.reverseengineer;

import java.util.Map;

import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.reverseengineer.UncodedColumnDefinition;
import io.sdmx.utils.core.object.ObjectUtil;

public class UnCodedColumnDefinitionImpl extends ColumnDefinitionImpl implements UncodedColumnDefinition {
	private TEXT_TYPE textType = TEXT_TYPE.STRING;
	private Integer column;
	private Integer minLength;
	private Integer maxLength;

	/**
	 * {
	 * 	 "ID" : "FREQ",
	 *   "Name?" : "ConceptName" //defaults to id of concept
	 *   "Type" : "DIMENSION|ATTRIBUTE|MEASURE",
	 * 	 "TextFormat?" : {
	 *      "Column" : 1
	 *      "MinLength" : 1
	 *      "MaxLength" : 5
	 *      "TextType" :
	 *   }
	 * }
	 * @param json
	 */
	public UnCodedColumnDefinitionImpl(Map<String, Object> jsonMap) {
		super(jsonMap);
		Map textFormat = (Map)jsonMap.get("TextFormat");
		if(textFormat != null) {
			String textType = (String)textFormat.get("TextType");
			if(ObjectUtil.validString(textType)) {
				this.textType = TEXT_TYPE.parseString(textType);
			}
			this.column = (Integer)textFormat.get("Column");
			this.minLength = (Integer)textFormat.get("MinLength");
			this.maxLength = (Integer)textFormat.get("MaxLength");
		}
	}

	@Override
	public TEXT_TYPE getTextType() {
		return textType;
	}

	@Override
	public Integer getColumn() {
		return column;
	}

	@Override
	public Integer minLength() {
		return minLength;
	}

	@Override
	public Integer maxLength() {
		return maxLength;
	}
}
