package io.sdmx.core.structure.util;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.INamedBean;
import io.sdmx.api.sdmx.model.beans.base.ItemBean;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.core.structure.manager.merge.MaintainableMergeManagerImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;

public class MaintainableMergeUtil {

	private static final Logger LOG = LoggerFactory.getLogger(MaintainableMergeUtil.class);
	
	/**
	 * Merges the item schemes from the mergeFrom into the mergeInto container.  Any item schemes
	 * in the mergeInto will be merged from the mergeFrom - a merge will copy across any new items not in
	 * the item scheme, or overwrite any if they exist in both, it will not delete existing items.  Any other
	 * maintainables will be copied into the mergeInto container
	 *
	 *
	 * @param mergeInto the container that will be updated
	 * @param mergeFrom the container that contain the structure to merge into the other container
	 */
	public static void mergeBeansContainers(SdmxBeans mergeInto, SdmxBeans mergeFrom) {
		InMemoryRetrievalManager brm = new InMemoryRetrievalManager(mergeFrom);
		Set<String> processed = new HashSet<>();
		processed.addAll( MaintainableMergeUtil.mergeMaintainableAnnotations(mergeInto, brm) );
		processed.addAll( MaintainableMergeUtil.mergeItemSchemes(mergeInto, brm) );  //merge any item schemes if they are repeated in more then one file
		for(MaintainableBean maint : mergeFrom.getAllMaintainables()) {
			if(!processed.contains(maint.getUrn())) {
				mergeInto.addIdentifiable(maint);
			}
		}
	}

	/**
	 * Merge annotations from all the supplied maintainables with the maintainables obtained
	 * from the bean retrieval manager.
	 * @param beans
	 * @return maintainables that were processed
	 */
	public static Set<String> mergeMaintainableAnnotations(SdmxBeans beans, SdmxBeanRetrievalManager brm) {
		Set<String> maints = new HashSet<>();
		for (MaintainableBean aMaint : beans.getAllMaintainables()) {
			MaintainableBean persisted = brm.getBean(aMaint.getURN());
			if(persisted == null) {
				continue;
			}
			List<AnnotationBean> annotations = persisted.getAnnotations();
			if (annotations.isEmpty()) {
				continue;
			}

			Set <AnnotationBean> allAnnotations = new HashSet<>();
			allAnnotations.addAll(annotations);
			allAnnotations.addAll(aMaint.getAnnotations());

			maints.add(aMaint.getUrn());

			MaintainableMutableBean mutable = aMaint.getMutableInstance();
			mutable.setAnnotations(null);

			for (AnnotationBean anno : allAnnotations) {
				AnnotationMutableBean annoMut = new AnnotationMutableBeanImpl(anno, mutable);
				mutable.addAnnotation(annoMut);
			}

			beans.addIdentifiable(mutable.getImmutableInstance());
		}
		return maints;
	}

	/**
	 * Merge submitted item schemes with item schemes which are obtained from the bean retrieval manager
	 * merge in this case means adds new items if they do not exist, it does not add names and descriptions to existing items
	 * @param beans
	 * @return maintainables that were processed
	 */
	public static Set<String> mergeItemSchemes(SdmxBeans beans, SdmxBeanRetrievalManager brm) {
		Set<String> maints = new HashSet<>();
		for(CodelistBean codelist : beans.getCodelists()) {
			 maints.add(codelist.getUrn());
			 beans.addIdentifiable(mergeItemScheme(codelist, brm));
		}
		for(ConceptSchemeBean conceptScheme : beans.getConceptSchemes()) {
			maints.add(conceptScheme.getUrn());
			beans.addIdentifiable(mergeItemScheme(conceptScheme, brm));
		}
		for(AgencySchemeBean acyScheme : beans.getAgenciesSchemes()) {
			maints.add(acyScheme.getUrn());
			beans.addIdentifiable(mergeItemScheme(acyScheme, brm));
		}
		for(DataProviderSchemeBean dpsScheme : beans.getDataProviderSchemes()) {
			maints.add(dpsScheme.getUrn());
			beans.addIdentifiable(mergeItemScheme(dpsScheme, brm));
		}
		for(DataConsumerSchemeBean dcsScheme : beans.getDataConsumerSchemes()) {
			maints.add(dcsScheme.getUrn());
			beans.addIdentifiable(mergeItemScheme(dcsScheme, brm));
		}
		for(ValueListBean valueList : beans.getValueLists()) {
			maints.add(valueList.getUrn());
			beans.addIdentifiable(mergeValueList(valueList, brm));
		}
		return maints;
	}

	private static MaintainableBean mergeItemScheme(ItemSchemeBean<? extends ItemBean> itemScheme, SdmxBeanRetrievalManager brm) {
		ItemSchemeBean<?> persisted = brm.getBean(itemScheme.getURN());
		if(persisted != null) {
			Set<String> persistedItems = persisted.getItems().stream().map(e-> e.getId()).collect(Collectors.toSet());
			Set<String> newCodes = itemScheme.getItems().stream().map(e-> e.getId()).collect(Collectors.toSet());

			persistedItems.removeAll(newCodes);

			if(persistedItems.size() > 0) {
				try {
					return MaintainableMergeManagerImpl.getInstance().mergeMaintainables(itemScheme, persisted);
				} catch(Throwable th) {
					LOG.error("Unable to merge ItemScheme: " + itemScheme.getShortURN() + " into existing bean. Merging aborted and existing ItemScheme will be replaced by new bean.");
				}
			}

		}
		return itemScheme;
	}
	
	private static MaintainableBean mergeValueList(ValueListBean vlb, SdmxBeanRetrievalManager brm) {
		ValueListBean persisted = brm.getBean(vlb.getURN());
		
		if(persisted != null) {
			Set<String> persistedItems = persisted.getItems().stream().map(INamedBean::getId).collect(Collectors.toSet());
			Set<String> newCodes = vlb.getItems().stream().map(ValueItemBean::getId).collect(Collectors.toSet());

			persistedItems.removeAll(newCodes);

			if(persistedItems.size() > 0) {
				try {
					return MaintainableMergeManagerImpl.getInstance().mergeMaintainables(vlb, persisted);
				} catch(Throwable th) {
					LOG.error("Unable to merge ValueList: " + vlb.getShortURN() + " into existing bean. Merging aborted and existing ValueList will be replaced by new bean.");
				}
			}

		}
		return vlb;
	}
}
