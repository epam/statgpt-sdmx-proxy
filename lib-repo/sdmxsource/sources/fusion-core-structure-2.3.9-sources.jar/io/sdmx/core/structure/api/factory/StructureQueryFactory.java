
package io.sdmx.core.structure.api.factory;

import io.sdmx.api.sdmx.builder.StructureQueryBuilder;
import io.sdmx.api.sdmx.model.format.StructureQueryFormat;

/**
 * A structure query factory is a factory which is responsible fore creating a builder that can build
 * a StructureQuery message in the format defined by the StructureQueryFormat 
 */
public interface StructureQueryFactory {

	/**
	 * Returns a StructureQueryBuilder only if this factory understands the StructureQueryFormat.  If the format is unknown, null will be returned
	 * @param format
	 * @return StructureQueryBuilder is this factory knows how to build this query format, or null if it doesn't
	 */
	<T> StructureQueryBuilder<T> getStructureQueryBuilder(StructureQueryFormat<T> format);
	
}
