package io.sdmx.core.structure.engine.merge;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.engine.merge.IHierarchyMergeEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class HierarchyMergeEngine implements IHierarchyMergeEngine, IFusionSingleton {
	private static HierarchyMergeEngine INSTANCE;

	public static HierarchyMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new HierarchyMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private HierarchyMergeEngine() {}
	
	@Override
	public CodelistBean merge(CodelistBean codelist, Set<HierarchyBean> hierarchies, SdmxBeanRetrievalManager brm) {
		if(brm == null) {
			throw new IllegalArgumentException("HierarchyMergeEngine can not merge, expected argument SdmxBeanRetrievalManager was null");
		}
		if(!ObjectUtil.validCollection(hierarchies)) {
			return codelist;
		}
		Set<String> codelistUrns = new HashSet<>();
		for(HierarchyBean currentHierarchy : hierarchies) {
			for(ICrossReferenceBean<?> ref : currentHierarchy.getCrossReferences()) {
				codelistUrns.add(ref.getReference().getMaintainableURN().getURN());
			}
		}
		for(String codelistUrn : codelistUrns) {
			if(!codelistUrn.equals(codelist.getUrn())) {
				CodelistBean toMergeCodelist = brm.getBean(URN.builder(codelistUrn).buildSingle(CodelistBean.class));
				if(toMergeCodelist != null) {
					codelist = CodelistMergeEngine.getInstance().mergeMaintainables(codelist, toMergeCodelist); 
				}
			}
		}
		return codelist;
	}

}
