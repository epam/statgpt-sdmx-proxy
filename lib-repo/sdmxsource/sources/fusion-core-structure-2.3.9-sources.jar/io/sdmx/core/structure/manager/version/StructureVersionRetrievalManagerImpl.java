package io.sdmx.core.structure.manager.version;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.structure.api.manager.StructureVersionRetrievalManager;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.VersionRef;

public class StructureVersionRetrievalManagerImpl implements StructureVersionRetrievalManager {
	private SdmxBeanRetrievalManager beanRetrievalManager;
	
	public StructureVersionRetrievalManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public MaintainableBean getLatest(MaintainableBean maintainableBean) {
		if(maintainableBean == null) {
			return null;
		}
		IURNMaintainable<?> urn = URN.builder(maintainableBean.getUrn()).versionRef(VersionRef.LATEST).buildMaintainable();
		return beanRetrievalManager.getBean(urn);
	}

}
