package io.sdmx.core.structure.manager.retrieval;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.ServiceRetrievalManager;
import io.sdmx.utils.core.io.URLUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.application.WEB_SERVICE;

/**
 * Gets the URL for the full Maintainable based on the incoming request.
 * <p/>
 * To use this class, a process must have stored on the ThreadLocalUtil the ClientRequest against the Key CLIENT_REQUEST_KEY.KEY.
 * One such implementation is the RequestServerFilter, which is a ServeltFilter which obtains this information from the ServletRequest.
 */
public class ServiceRetrievalManagerImpl implements ServiceRetrievalManager {

	private FusionProductInformationRetrievalManager productInformationRetrievalManager;

	public ServiceRetrievalManagerImpl(FusionProductInformationRetrievalManager productInformationRetrievalManager) {
		this.productInformationRetrievalManager = productInformationRetrievalManager;
    }

	@Override
	public ArtefactURL getStructureOrServiceURL(MaintainableBean maint) {
		ClientRequest clientRequest = ThreadLocalUtil.getClientRequest();
		if(clientRequest == null) {
			return null;
		}

		String serverUrl = getServerURL();

		// Ensure that the current baseUrl now ends with a slash
		if (!serverUrl.endsWith("/")) {
			serverUrl += "/";
		}
		if(maint.getStructureURL() != null) {
			return new ArtefactURL(maint.getStructureURL(), false);
		}
		String fullRest = serverUrl + maint.getStructureType().getUrnClass().toLowerCase() + "/" + maint.getAgencyId() + "/" + maint.getId() + "/" + maint.getVersion();

		try {
			return new ArtefactURL(new URL(fullRest), false);
		} catch (MalformedURLException e) {
			throw new RuntimeException("Could not return service URL for structure - bad URL syntax " + fullRest, e);
		}
	}

	@Override
	public MaintainableBean createStub(MaintainableBean maint, boolean completeStub) {
		ArtefactURL artefactUrl = getStructureOrServiceURL(maint);
		if(artefactUrl != null) {
			return maint.getStub(artefactUrl.getUrl(), artefactUrl.isSserviceUrl(), completeStub);
		}
		return maint;
	}

	@Override
    public MaintainableBean createStub(MaintainableBean maint, boolean completeStub, Map<String, String> queryParameters) {
        String fullRest = URLUtil.appendQueryParameters(getRestURL(maint), queryParameters);
        return maint.getStub(getURL(fullRest), false, completeStub);
    }

	private URL getURL(String url) {
        try {
            return new URL(url);
        } catch (MalformedURLException e) {
            throw new RuntimeException("Could not return service URL for structure - bad URL syntax " + url, e);
        }
    }

	private String getRestURL(MaintainableBean maint) {
        String serverUrl = getServerURL();
        // Ensure that the current serverUrl ends with a slash
        if (!serverUrl.endsWith("/")) {
            serverUrl += "/";
        }
        return serverUrl + maint.getStructureType().getUrnClass().toLowerCase() + "/" + maint.getAgencyId() + "/" + maint.getId() + "/" + maint.getVersion();
    }

    protected String getServerURL() {
        return productInformationRetrievalManager.getFusionProductInformation().getServiceURL(WEB_SERVICE.SDMX_GET.service());
    }
}