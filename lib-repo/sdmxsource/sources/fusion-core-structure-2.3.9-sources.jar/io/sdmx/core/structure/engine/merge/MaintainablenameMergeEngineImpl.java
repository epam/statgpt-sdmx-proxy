package io.sdmx.core.structure.engine.merge;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.core.structure.api.engine.merge.MaintainableNameMergeEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

public class MaintainablenameMergeEngineImpl implements MaintainableNameMergeEngine, IFusionSingleton {
	private static MaintainablenameMergeEngineImpl INSTANCE;

	public static MaintainablenameMergeEngineImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MaintainablenameMergeEngineImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private MaintainablenameMergeEngineImpl() {}

	@Override
	public MaintainableBean mergeMaintainables(MaintainableBean newMaint, MaintainableBean oldMaint) {
		Set<NameableBean> oldNameables = oldMaint.getComposites(NameableBean.class);
		oldNameables.add(oldMaint);
		Map<String, NameableMutableBean> nameables = new HashMap<>();

		MaintainableMutableBean mutbale = newMaint.getMutableInstance();
		nameables.put(mutbale.getUrn(), mutbale);
		for(NameableMutableBean nameable : mutbale.getComposites(NameableMutableBean.class)) {
			nameables.put(nameable.getUrn(), nameable);
		}

		//TODO Populate the nameables map with all NameabelMutbaleBeans

		for(NameableBean oldNameable : oldNameables) {
			NameableMutableBean mutable = nameables.get(oldNameable.getUrn());
			if(mutable != null) {
				mergeLanguage(mutable, oldNameable);
			}
		}
		return mutbale.getImmutableInstance();
	}

	private void mergeLanguage(NameableMutableBean mutable, NameableBean oldNameable) {
		for(TextTypeWrapper tt : oldNameable.getNames()) {
			String lang = tt.getLocale();
			TextTypeWrapperMutableBean mutableName = mutable.getName(lang);
			if(mutableName == null) {
				mutable.addName(lang, tt.getValue());
			}
		}
		for(TextTypeWrapper tt : oldNameable.getDescriptions()) {
			String lang = tt.getLocale();
			TextTypeWrapperMutableBean mutableNDesc = mutable.getDescription(lang);
			if(mutableNDesc == null) {
				mutable.addDescription(lang, tt.getValue());
			}
		}
	}
}
