package io.sdmx.core.structure.model.diff;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.diff.BeanDiff;
import io.sdmx.api.sdmx.model.diff.DiffReport;

public class BeanDiffImpl implements BeanDiff {
	private MaintainableBean source;
	private MaintainableBean target;
	private DiffReport report;
	
	
	public BeanDiffImpl(MaintainableBean soruce, MaintainableBean target) {
		this.source = soruce;
		this.target = target;
	}

	@Override
	public int compareTo(BeanDiff o) {
		return this.getDiffReport().getTarget().getVersion().isLater(o.getDiffReport().getTarget().getVersion()) ? -1: 1;
	}

	
	@Override
	public MaintainableBean getSource() {
		return source;
	}
	
	@Override
	public MaintainableBean getTarget() {
		return target;
	}
	
	@Override
	public DiffReport getDiffReport() {
		if(report == null) {
			this.report = this.source.diff(target);
		}
		return report;
	}

}
