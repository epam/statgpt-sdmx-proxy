package io.sdmx.core.structure.engine.create;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.builder.ConstraintBuilder;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReferencePeriodMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;


public class ConstraintBuilderImpl implements ConstraintBuilder, IFusionSingleton {
	private static ConstraintBuilderImpl INSTANCE;

	public static ConstraintBuilderImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ConstraintBuilderImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private ConstraintBuilderImpl() {}

	@Override
    public ContentConstraintBean buildConstraint(DataReaderEngine dre,
    		IURN<? extends IDSDRelatedBean> attachment,
			DataSourceBean dsAttachement,
			boolean indexAttributes, boolean indexDataset,
			boolean indexReportingPeriod, boolean indexTimeSeries,
			boolean definingDataPresent, IMaintainableProperties refParams) {

		dre.reset();
		//TODO Should it check if there is more then one dataset in the datasource
		if(!dre.moveNextDataset()) {
			 throw new SdmxSemmanticException("Can not index time series for registered datasource, the data retrieved from the datasource does not contain a dataset");
		}

		if(!indexAttributes && !indexDataset && !indexReportingPeriod && !indexTimeSeries) {
			return null;
		}

		DatasetHeaderBean header = dre.getCurrentDatasetHeaderBean();
		if(indexTimeSeries && !header.isTimeSeries()) {
			 throw new SdmxSemmanticException("Can not index time series for registered datasource, the data retrieved from the datasource is not time series");
		}

		//Create mutable Maintainable
		ContentConstraintMutableBean mutableBean = new ContentConstraintMutableBeanImpl();
		mutableBean.setAgencyId(refParams.getAgencyId());
		mutableBean.setId(refParams.getId());
		mutableBean.setVersion(refParams.getVersion());
		mutableBean.addName("en", "Generated Constraint");
		mutableBean.addDescription("en", "Constraint built from dataset");
		mutableBean.setIsDefiningActualDataPresent(true);
		mutableBean.setConstraintAttachment(buildAttachement(attachment, dsAttachement));

		ConstraintDataKeySetMutableBean dataKeySet = null;

		Map<String, Set<String>> cubeRegionMap = new HashMap<>();
		Map<String, Set<String>> attributeMap = new HashMap<>();
		Date reportFrom = null;
		Date reportTo = null;
		Set<String> processedDates = new HashSet<>();

		while(dre.moveNextKeyable()) {
			Keyable key = dre.getCurrentKey();
			if(key.isSeries()) {
				//TODO Check if Cross Sectional and put out exception if it is
				//1. If indexing the time series store the time Series Key on the Constraint
				if(indexTimeSeries) {
					if(dataKeySet == null) {
						dataKeySet = new ConstraintDataKeySetMutableBeanImpl();
						mutableBean.setIncludedSeriesKeys(dataKeySet);
					}
					ConstrainedDataKeyMutableBean dataKey = new ConstrainedDataKeyMutableBeanImpl();
					dataKey.setSimpleKeyValues(key.getKey());
					dataKeySet.addConstrainedDataKey(dataKey);
				}
				//2. If indexing the dataset, store the individual code values
				if(indexDataset) {
					storeKeyValuesOnMap(key.getKey(), cubeRegionMap);
				}
				//3. If indexing attributes, store the individual code values for each attribute
				if(indexAttributes) {
					storeKeyValuesOnMap(key.getAttributes(), attributeMap);
				}
			}
			if(indexAttributes || indexReportingPeriod) {
				while(dre.moveNextObservation()) {
					Observation obs = dre.getCurrentObservation();
					//If indexing the dates, determine the data start and end dates from the obs dates
					//To save time, do not process the same date twice
					if(indexReportingPeriod && obs.hasObsTime()) {
						if(!processedDates.contains(obs.getDimensionValue())) {
							Date obsDate = obs.getSdmxObsTime().getDate();
							if(reportFrom == null || reportFrom.getTime() > obsDate.getTime()) {
								reportFrom = obsDate;
							}
							if(reportTo == null || reportTo.getTime() < obsDate.getTime()) {
								reportTo = obsDate;
							}
							processedDates.add(obs.getDimensionValue());
						}
					}
					if(indexAttributes) {
						storeKeyValuesOnMap(obs.getAttributes(), attributeMap);
					}
				}
			}
		}
		if(indexAttributes || indexDataset) {
			CubeRegionMutableBean cubeRegionMutableBean = new CubeRegionMutableBeanImpl();
			mutableBean.setIncludedCubeRegion(cubeRegionMutableBean);
			if(indexAttributes) {
				createKeyValues(attributeMap, cubeRegionMutableBean.getAttributeValues());
			}
			if(indexDataset) {
				createKeyValues(cubeRegionMap, cubeRegionMutableBean.getKeyValues());
			}
		}
		if(indexReportingPeriod && reportFrom != null && reportTo != null) {
			ReferencePeriodMutableBean refPeriodMutable = new ReferencePeriodMutableBeanImpl();
			refPeriodMutable.setEndTime(reportTo);
			refPeriodMutable.setStartTime(reportFrom);
			mutableBean.setReferencePeriod(refPeriodMutable);
		}

		return mutableBean.getImmutableInstance();
	}

	private void createKeyValues(Map<String, Set<String>> cubeRegionMap, List<KeyValuesMutable> populateMap) {
		for(String currentConcept : cubeRegionMap.keySet()) {
			KeyValuesMutable kvs = new KeyValuesMutableImpl();
			kvs.setId(currentConcept);
			kvs.setKeyValues(new ArrayList<>(cubeRegionMap.get(currentConcept)));
			populateMap.add(kvs);
		}
	}

	private void storeKeyValuesOnMap(List<KeyValue> kvs, Map<String, Set<String>> cubeRegionMap) {
		for(KeyValue kv : kvs) {
			Set<String> valuesForConcept = cubeRegionMap.get(kv.getConcept());
			if(valuesForConcept == null) {
				valuesForConcept = new HashSet<>();
				cubeRegionMap.put(kv.getConcept(), valuesForConcept);
			}
			valuesForConcept.add(kv.getCode());
		}
	}


	private ConstraintAttachmentMutableBean buildAttachement(IURN<? extends IDSDRelatedBean> attachment, DataSourceBean dsAttachement) {
		ConstraintAttachmentMutableBean mutable = new ContentConstraintAttachmentMutableBeanImpl();
		mutable.addStructureReference(attachment.asMutable());
		return mutable;
	}
}
