package io.sdmx.core.structure.manager.application;

import java.util.Collection;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.sdmx.manager.structure.BeansAwareManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansRetreivalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * On application startup, this class will query for all structures from the StructureSearchManager
 * and register them with any class that implements BeansAwareManager
 */
public class ApplicationStartupStructureManager implements ApplicationStartupAware {
	private SdmxBeansRetreivalManager beanRetrievalManager;
	
	public ApplicationStartupStructureManager(SdmxBeansRetreivalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public void applicationRestarting() {
	    // Left intentionally empty
	}

	@Override
	public void applicationStarted() {
		Collection<BeansAwareManager> beansAwareManagers = FusionBeanStore.getBeans(BeansAwareManager.class);
		if(ObjectUtil.validCollection(beansAwareManagers)) {
			SdmxBeans beans = beanRetrievalManager.getSdmxBeans();
			for(BeansAwareManager beansAware : beansAwareManagers) {
				beansAware.registerBeans(beans);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Class[] getDependsOn() {
		return null;
	}
}
