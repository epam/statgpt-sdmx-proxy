package io.sdmx.core.structure.model;

import io.sdmx.utils.core.thread.Lockable;

public class StructurePersistenceLock extends Lockable {
	public static final StructurePersistenceLock INSTANCE = new StructurePersistenceLock();
}
