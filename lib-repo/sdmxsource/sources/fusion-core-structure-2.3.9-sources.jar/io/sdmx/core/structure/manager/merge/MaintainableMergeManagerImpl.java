package io.sdmx.core.structure.manager.merge;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.manager.MaintainableMergeManager;
import io.sdmx.core.structure.engine.merge.AgencySchemeMergeEngine;
import io.sdmx.core.structure.engine.merge.CodelistMergeEngine;
import io.sdmx.core.structure.engine.merge.ConceptSchemeMergeEngine;
import io.sdmx.core.structure.engine.merge.DataConsumerSchemeMergeEngine;
import io.sdmx.core.structure.engine.merge.DataProviderSchemeMergeEngine;
import io.sdmx.core.structure.engine.merge.ValueListMergeEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

public class MaintainableMergeManagerImpl implements MaintainableMergeManager, IFusionSingleton {
	private static MaintainableMergeManagerImpl INSTANCE;

	public static MaintainableMergeManagerImpl getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MaintainableMergeManagerImpl();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private MaintainableMergeManagerImpl() {}

	@Override
	@SuppressWarnings("unchecked")
	public <T extends MaintainableBean> T mergeMaintainables(T maint1, T maint2) {
		switch(maint1.getStructureType()) {
		case AGENCY_SCHEME : return (T) AgencySchemeMergeEngine.getInstance().mergeMaintainables((AgencySchemeBean)maint1, (AgencySchemeBean)maint2);
		case DATA_PROVIDER_SCHEME : return (T) DataProviderSchemeMergeEngine.getInstance().mergeMaintainables((DataProviderSchemeBean)maint1, (DataProviderSchemeBean)maint2);
		case DATA_CONSUMER_SCHEME : return (T) DataConsumerSchemeMergeEngine.getInstance().mergeMaintainables((DataConsumerSchemeBean)maint1, (DataConsumerSchemeBean)maint2);
		case CODE_LIST : return (T) CodelistMergeEngine.getInstance().mergeMaintainables((CodelistBean)maint1, (CodelistBean)maint2);
		case CONCEPT_SCHEME : return (T) ConceptSchemeMergeEngine.getInstance().mergeMaintainables((ConceptSchemeBean)maint1, (ConceptSchemeBean)maint2);
		case VALUE_LIST: return (T) ValueListMergeEngine.getInstance().mergeMaintainables((ValueListBean)maint1, (ValueListBean)maint2);
		default : throw new SdmxNotImplementedException("Can not merge maintainables of type: " + maint1.getStructureType().getUrnClass());
		}
	}
}
