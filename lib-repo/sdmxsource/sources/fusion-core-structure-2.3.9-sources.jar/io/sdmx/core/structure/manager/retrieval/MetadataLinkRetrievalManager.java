package io.sdmx.core.structure.manager.retrieval;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.cache.Cache;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.manager.structure.ICrossReferenceLookupTableRetrievalManager;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceLookupTable;
import io.sdmx.api.sdmx.model.beans.reference.IMaintainableReferences;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.core.sdmx.api.manager.metadata.IMetadataLinkRetrievalManager;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.core.structure.model.store.ExternalMaintainableLinks;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.sdmx.application.WEB_SERVICE;
import io.sdmx.utils.sdmx.structure.StructureTypes;

/**
 * Associates Maintainables with Reference Metadata Links
 */
public class MetadataLinkRetrievalManager implements IMetadataLinkRetrievalManager, IStructureEventListener, Cache  {
	private static final Logger LOG = LoggerFactory.getLogger(MetadataLinkRetrievalManager.class);

	private ICrossReferenceLookupTableRetrievalManager crossReferenceLookupTableRetrievalManager;
	private FusionProductInformationRetrievalManager fpiRm;
	private String baseUrl;


	private Map<IURNMaintainable<?>, IExternalMaintainableLinks> maintLinks = null;

	private final IMaintainableStructureType<IReportedMetadataSetBean> STRUCTURE_TYPE_METADATA_SET =  StructureTypes.getMaintStructureType(IReportedMetadataSetBean.class);
	private final IMaintainableStructureType<IReportedMetadataSetBean> STRUCTURE_TYPE_METADATAFLOW =  StructureTypes.getMaintStructureType(MetadataFlowBean.class);
	private final IMaintainableStructureType<IReportedMetadataSetBean> STRUCTURE_TYPE_METADATAPROVISION =  StructureTypes.getMaintStructureType(ProvisionAgreementBean.class);
	private final ISDMXStructureType<?, AgencyBean> STRUCTURE_TYPE_AGENCY =  StructureTypes.getAnyStructureType(AgencyBean.class);
	
	public MetadataLinkRetrievalManager(FusionProductInformationRetrievalManager fpiRm,
			ICrossReferenceLookupTableRetrievalManager crossReferenceLookupTableRetrievalManager) {
		this.fpiRm = fpiRm;
		this.crossReferenceLookupTableRetrievalManager = crossReferenceLookupTableRetrievalManager;
	}

	@Override
	public void notifyStructureEvent(IStructureEvent event) {
		clearCache();
	}

	@Override
	public void clearCache() {
		maintLinks = null;
	}



	private Map<IURNMaintainable<?>, IExternalMaintainableLinks> getLinks() {
		Map<IURNMaintainable<?>, IExternalMaintainableLinks> maintLinks = this.maintLinks; //Take a local copy just in case the cache clears while we are doing this
		if(maintLinks != null) {
			return maintLinks;
		}
		/**
		 * A lookup table will have the Metadata Set with link to 'n' number of identifiables
		 * This relationship needs to be inverted, so the Maintainable URN that is the target (or parent of the target) lists
		 * a map of Identifiable URNs to Metadata Sets
		 * 
		 * Example: Input ICrossReferenceLookupTable
		 * 
		 * MetadataSet:MDS1 ->   Codelist:CL1, Code:A, B
		 *						 Dataflow:DF1
		 * MetadataSet:MDS2 ->   Codelist:CL1, Code:B
		 * 
		 *          Output IExternalMaintainableLinks
		 * 
		 * Codelist CL1 -> Code A ->MDS1, Code:B -> MDS1,MDS2
		 * Dataflow:DF1 -> Dataflow:DF1 ->MDS1
		 * 
		 */
		ICrossReferenceLookupTable lookupTable = crossReferenceLookupTableRetrievalManager.getCrossReferenceLookupTable();

		List<IMaintainableReferences<IReportedMetadataSetBean>> setReferences = new ArrayList<>();
		processReferences(lookupTable.getMaintDirectReferences(), setReferences);
		processReferences(lookupTable.getMaintIndirectReferences(), setReferences);

		Map<IURNMaintainable<?>, LinkBuilder> targetMaint2LinkBuilder = new HashMap<>();

		setReferences.forEach(metadataSetRef -> {
			IURNMaintainable<IReportedMetadataSetBean> metadataSetURN = metadataSetRef.getMaintURN();
			ILinkBean link = toLink(metadataSetURN);
			if(link != null) {
				metadataSetRef.getReferences().values().forEach(valueSet -> {
					valueSet.forEach( linkedStructure -> {
						IURNAbsolute<?> linkedURN = linkedStructure.getReference();
						IURNMaintainable<?> parentMaintainable = linkedURN.getMaintainableURN();
						LinkBuilder linkBuilder = targetMaint2LinkBuilder.get(parentMaintainable);
						if(linkBuilder == null) {
							linkBuilder = new LinkBuilder(parentMaintainable);
							targetMaint2LinkBuilder.put(parentMaintainable, linkBuilder);
						}
						if(linkedURN.getStructureType() == STRUCTURE_TYPE_METADATAFLOW ||
								linkedURN.getStructureType() == STRUCTURE_TYPE_METADATAPROVISION ||
								(linkedURN.getStructureType() == STRUCTURE_TYPE_AGENCY && linkedURN.getFullIdentifiableId().equals(metadataSetURN.getAgencyId())) ) {
							//Skip these, this reference exists because the metadataset is reported against this collection structure (or is maintained by the agency)
							//the metadata is not about this
						} else {
							linkBuilder.addLink(linkedURN, link);
						}
					});
				});
			}
		});
		Map<IURNMaintainable<?>, IExternalMaintainableLinks> newLinks = new HashMap<>();
		targetMaint2LinkBuilder.forEach((urnMaint, linkBuilder) -> {
			newLinks.put(urnMaint, linkBuilder.build());
		});
		this.maintLinks = newLinks;
		return newLinks;
	}

	private void processReferences(Set<IMaintainableReferences> references, List<IMaintainableReferences<IReportedMetadataSetBean>> setReferences ) {
		references.forEach(ref -> {

			if(ref.getMaintURN().getStructureType() == STRUCTURE_TYPE_METADATA_SET) {
				setReferences.add(ref);
			}

		});
	}

	private class LinkBuilder {
		IURNMaintainable<?> maintUrn;
		Map<IURNAbsolute<?>, Set<ILinkBean>> urn2Links = new HashMap<>();

		public LinkBuilder(IURNMaintainable<?> maintUrn) {
			this.maintUrn = maintUrn;
		}

		void addLink(IURNAbsolute<?> linkTo, ILinkBean link) {
			CollectionUtil.addToMappedSet(urn2Links, linkTo, link);
		}

		IExternalMaintainableLinks build() {
			return new ExternalMaintainableLinks(maintUrn, urn2Links);
		}
	}


	@Override
	public IExternalMaintainableLinks getLinks(MaintainableBean maint) {
		return getLinks().get(maint.getURN());
	}

	private ILinkBean toLink(IURNMaintainable<IReportedMetadataSetBean> urn) {
		try {
			String linkURL = getBaseURL() + urn.getAgencyId() + "/" + urn.getMaintainableId() + "/"+urn.getVersion();
			return new LinkBean("metadata", new URI(linkURL),  null, urn, null, null);
		} catch (URISyntaxException e) {
			LOG.error("Error building Link from Metadataset URN", e);
		}
		return null;
	}

	private String getBaseURL() {
		if(baseUrl == null) {
			baseUrl = fpiRm.getFusionProductInformation().getServiceURL(WEB_SERVICE.SDMX_GET_V2.service())+"/metadata/metadataset/";
		}
		return baseUrl;
	}
}
