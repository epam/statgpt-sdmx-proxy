package io.sdmx.core.structure.api.manager;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

public interface CommonDimenisonRetrievalManager {

	/**
	 * Returns a set of common components based on the data structure references.
	 * <p/>
	 * Two components are deemed common if they share the same id, concept reference, and codelist reference
	 * @param dsdReferences
	 * @return
	 */
	Set<ComponentBean> getCommonComponentsForQuery(Set<IMaintainableRef> dsdReferences);
	
}
