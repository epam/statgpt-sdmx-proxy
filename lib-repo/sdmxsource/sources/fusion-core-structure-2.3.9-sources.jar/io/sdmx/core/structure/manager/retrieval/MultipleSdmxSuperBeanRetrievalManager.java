package io.sdmx.core.structure.manager.retrieval;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.superbeans.conceptscheme.ConceptSchemeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.ProvisionAgreementSuperBean;
import io.sdmx.api.sdmx.model.superbeans.registry.RegistrationSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class MultipleSdmxSuperBeanRetrievalManager implements SdmxSuperBeanRetrievalManager {
	private List<SdmxSuperBeanRetrievalManager> managers = new ArrayList<>();

	public MultipleSdmxSuperBeanRetrievalManager(List<SdmxSuperBeanRetrievalManager> managers) {
		this.managers = Collections.unmodifiableList(managers);
	}

	@Override
	public ConceptSchemeSuperBean getConceptSchemeSuperBean(IURNSingle<ConceptSchemeBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			ConceptSchemeSuperBean sb = manager.getConceptSchemeSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public DataflowSuperBean getDataflowSuperBean(IURNSingle<DataflowBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			DataflowSuperBean sb = manager.getDataflowSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public DataStructureSuperBean getDataStructureSuperBean(IURNSingle<DataStructureBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			DataStructureSuperBean sb = manager.getDataStructureSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public HierarchySuperBean getHierarchicCodeListSuperBean(IURNSingle<HierarchyBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			HierarchySuperBean sb = manager.getHierarchicCodeListSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}
	
	@Override
	public MetadataStructureSuperBean getMetadataStructureSuperBean(IURNSingle<MetadataStructureDefinitionBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			MetadataStructureSuperBean sb = manager.getMetadataStructureSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public ProvisionAgreementSuperBean getProvisionAgreementSuperBean(IURNSingle<ProvisionAgreementBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			ProvisionAgreementSuperBean sb = manager.getProvisionAgreementSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public RegistrationSuperBean getRegistrationSuperBean(IURNSingle<RegistrationBean> ref) {
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			RegistrationSuperBean sb = manager.getRegistrationSuperBean(ref);
			if(sb != null) {
				return sb;
			}
		}
		return null;
	}

	@Override
	public Set<ConceptSchemeSuperBean> getConceptSchemeSuperBeans(IURN<ConceptSchemeBean> ref) {
		Set<ConceptSchemeSuperBean> sbs = new HashSet<>();
		
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			Set<ConceptSchemeSuperBean> sb = manager.getConceptSchemeSuperBeans(ref);
			if(ObjectUtil.validCollection(sb)) {
				sbs.addAll(sb);
			}
		}
		return sbs;
	}

	@Override
	public Set<DataStructureSuperBean> getDataStructureSuperBeans(IURN<DataStructureBean> ref) {
		Set<DataStructureSuperBean> sbs = new HashSet<>();
		
		for(SdmxSuperBeanRetrievalManager manager : managers) {
			Set<DataStructureSuperBean> sb = manager.getDataStructureSuperBeans(ref);
			if(ObjectUtil.validCollection(sb)) {
				sbs.addAll(sb);
			}
		}
		return sbs;
	}

}
