package io.sdmx.core.structure.manager.retrieval;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.ServiceRetrievalManager;

public class DefaultServiceRetrievalManager implements ServiceRetrievalManager {
	private String baseUrl;

	public DefaultServiceRetrievalManager(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	
	@Override
	public ArtefactURL getStructureOrServiceURL(MaintainableBean maint) {
		String fullRest = baseUrl + "/" + maint.getStructureType().getUrnClass().toLowerCase() + "/" + maint.getAgencyId() + "/" + maint.getId() + "/" + maint.getVersion();

		try {
			return new ArtefactURL(new URL(fullRest), false);
		} catch (MalformedURLException e) {
			throw new RuntimeException("Could not return service URL for structure - bad URL syntax " + fullRest, e);
		}
	}

	@Override
	public MaintainableBean createStub(MaintainableBean maint, boolean completeStub) {
		ArtefactURL artefactUrl = getStructureOrServiceURL(maint);
		return maint.getStub(artefactUrl.getUrl(), artefactUrl.isSserviceUrl(), completeStub);
	}

    @Override
    public MaintainableBean createStub(MaintainableBean maint, boolean completeStub, Map<String, String> queryParameters) {
        // TODO Auto-generated method stub
        return createStub(maint, completeStub);
    }
}
