package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface StructureValidationManager {

	/**
	 * Validates a structure is compliant to the 2.1 SDMX schema, by writing it out as SDMX and validating against the schema
	 * @param maintainableBean
	 */
	void validateStructure(MaintainableBean maintainableBean);
	
}
