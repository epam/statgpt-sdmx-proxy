package io.sdmx.core.structure.api.manager;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;

/**
 * Manages zombie structures - those which reference other structures which no longer exist
 */
public interface IZombieStructureManager {

	/**
	 * Registers the zombie structures with the system
	 * @param beans
	 */
	void registerZombies(SdmxBeans beans);
	
	/**
	 * Writes the structures to the output stream in the given format
	 * @param out
	 * @param format
	 */
	void writeStructures(OutputStream out, boolean asStub, StructureFormat format);
	
	/**
	 * Removes the zombie structures from the system
	 * @param urns
	 */
	void removeStructures(Set<String> urns);
	
	
	/**
	 * Removes all zombie structures from the system
	 */
	void removeAllStructures();
}
