package io.sdmx.core.structure.manager.version;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.VERSION_PART;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.core.structure.api.manager.StructureVersionIncrementManager;
import io.sdmx.core.structure.api.manager.StructureVersionRetrievalManager;

public class StructureVersionIncrementManagerImpl implements StructureVersionIncrementManager {
    private static final Logger LOG = LoggerFactory.getLogger(StructureVersionIncrementManagerImpl.class);

	private StructureVersionRetrievalManager structureVersionRetrievalManager;

	private SdmxBeanRetrievalManager  beanRetrievalManager;

	public StructureVersionIncrementManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager, StructureVersionRetrievalManager structureVersionRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}
	
	@Override
	public void incrementVersions(SdmxBeans beans) {
		LOG.info("Update Versions of Structures if existing structures found");
		//Store a map of old versions vs the new version
		for(MaintainableBean currentMaint : beans.getAllMaintainables()) {
			LOG.debug("Auto Version - check latest version for maintainable: " + currentMaint);

			MaintainableBean persistedMaintainable = structureVersionRetrievalManager.getLatest(currentMaint);
			if(persistedMaintainable ==  null) {
				persistedMaintainable = beanRetrievalManager.getBean(currentMaint.getURN());
			}

			if(persistedMaintainable != null) {
				if(persistedMaintainable.getVersion().isLater(currentMaint.getVersion())) {
					//Modify version of maintainable to be the same as persisted maintainable
					MaintainableMutableBean mutableInstance = currentMaint.getMutableInstance();
					mutableInstance.setVersion(persistedMaintainable.getVersion());
					
					//Remove the Maintainable from the submission - as we've changed the versions
					beans.removeMaintainable(currentMaint);
					beans.addIdentifiable(mutableInstance.getImmutableInstance());
				}
				if(persistedMaintainable.getVersion().equals(currentMaint.getVersion())) {
					LOG.debug("Latest version is '" + persistedMaintainable.getVersion() + "' perform update checks");
					if(!currentMaint.deepEquals(persistedMaintainable, true)) {

						Set<IdentifiableBean> allIdentifiables1 = currentMaint.getIdentifiableComposites();
						Set<IdentifiableBean> allIdentifiables2 = persistedMaintainable.getIdentifiableComposites();

						boolean containsAll = allIdentifiables1.containsAll(allIdentifiables2) && allIdentifiables2.containsAll(allIdentifiables1);
						if(LOG.isInfoEnabled()) {
							String increment = containsAll ? "Minor" : "Major";
							LOG.info("Perform "+increment+" Version Increment for structure:" + currentMaint.getUrn());
						}

						//Increment the version number
						MaintainableBean newVersion = incrmentVersion(currentMaint, persistedMaintainable.getVersion(), !containsAll);

						//Remove the Maintainable from the submission
						beans.removeMaintainable(currentMaint);
						beans.addIdentifiable(newVersion);
					}
				}
			}
		}
	}



	/**
	 * Increments the version of the old maintainable
	 * @param beans
	 * @param updatedMaintainables
	 * @param currentMaint
	 * @param majorIncrement
	 * @return
	 */
	private MaintainableBean incrmentVersion(MaintainableBean currentMaint, ISdmxVersion incrementFromVersion, boolean majorIncrement) {
		MaintainableMutableBean mutable = currentMaint.getMutableInstance();
		String newVersion = incrementFromVersion.incrementVersion(majorIncrement ? VERSION_PART.MAJOR : VERSION_PART.MINOR).toString();
		mutable.setVersion(newVersion);

		MaintainableBean newMaint = mutable.getImmutableInstance();
		return newMaint;
	}

}
