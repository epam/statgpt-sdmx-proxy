package io.sdmx.core.structure.engine.merge;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Merges the data consumers in the data consumer schemes by adding all the items of one scheme, that do not exist in the other, together.
 */
public class DataConsumerSchemeMergeEngine implements MaintainableMergeEngine<DataConsumerSchemeBean>, IFusionSingleton {
	private static DataConsumerSchemeMergeEngine INSTANCE;

	public static DataConsumerSchemeMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new DataConsumerSchemeMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private DataConsumerSchemeMergeEngine() {}

	@Override
	public DataConsumerSchemeBean mergeMaintainables(DataConsumerSchemeBean maint1, DataConsumerSchemeBean maint2) {
		if(maint1 != null && maint2 != null) {
			DataConsumerSchemeMutableBean mutableBean = maint1.getMutableInstance();
			for(DataConsumerBean currentAgency : maint2.getItems()) {
				if(!maint1.getItems().contains(currentAgency)) {
					mutableBean.addItem(new DataConsumerMutableBeanImpl(currentAgency, mutableBean));
				}
			}
			return mutableBean.getImmutableInstance();
		}
		if(maint1 == null) {
			return maint2;
		}
		if(maint2 == null) {
			return maint1;
		}
		return null;
	}
}
