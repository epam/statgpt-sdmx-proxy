package io.sdmx.core.structure.model.diff;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.SortedSet;
import java.util.TreeSet;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONString;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.diff.BeanDiff;
import io.sdmx.api.sdmx.model.diff.Changelog;
import io.sdmx.api.sdmx.model.diff.Diff;
import io.sdmx.api.sdmx.model.diff.DiffReport;
import io.sdmx.api.sdmx.model.diff.ModificationAction;
import io.sdmx.utils.core.object.ObjectUtil;

public class ChangelogImpl implements Changelog, JSONString{

	/**
	 * The type of changelog
	 */
	protected CHANGELOG_TYPE typeOfChangelog;

	/**
	 * if this has a version, then we are making a change log of revisions, if version is ommited, then we are getting a changelog of version
	 */
	private SortedSet<BeanDiff> changes;
	public ChangelogImpl(SortedSet<BeanDiff> changes) {
		if(changes == null) {
			throw new IllegalArgumentException("changes can not be null");
		}
		if(!ObjectUtil.validCollection(changes)) {
			throw new IllegalArgumentException("changes must have a size of at least 1");
		}
		this.changes = Collections.unmodifiableSortedSet(new TreeSet<>(changes));
		this.typeOfChangelog = CHANGELOG_TYPE.VERSION_CHANGE;
	}

	public ChangelogImpl(BeanDiff diff){
		this(new TreeSet<>(Arrays.asList(diff)));
		this.typeOfChangelog = CHANGELOG_TYPE.STRUCTURE_DIFFERENCE;
	}


	@Override
	public SortedSet<BeanDiff> getChanges() {
		return changes;
	}

	@Override
	public void writeJSON(OutputStream out) {
		try {
			out.write(toJSONString().getBytes(StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String toJSONString() {
		return toJsonObject().toString();
	}

	protected JSONObject toJsonObject() {
		SortedSet<BeanDiff> changes = this.getChanges();
		JSONObject returnJson = new JSONObject();
		try {
			JSONObject details = new JSONObject();
			BeanDiff next = changes.iterator().next();
			MaintainableBean structure = next.getTarget();
			details.put("Type", structure.getURN().getStructureType().toString());
			details.put("AgencyId", structure.getAgencyId());
			details.put("Id", structure.getId());
			returnJson.put("Structure", details);

			JSONObject changelog = new JSONObject();
		//	changelog.put("type", this.typeOfChangelog);
			returnJson.put("Changelog", changelog);


			int count = 0;
			for (BeanDiff versionChange : changes) {
				count++;
				JSONObject modObj = new JSONObject();
				SdmxPeriod period = versionChange.getTarget().getValidityPeriod();

				if(period != null) {
					SdmxDate start = period.getStartPeriod();
					if(start != null) {
						modObj.put("startPeriod", start.getDateInSdmxFormat());
					}
					SdmxDate end = period.getEndPeriod();
					if(end != null) {
						modObj.put("endPeriod", end.getDateInSdmxFormat());
					}
				}

				//				// because the first version (inital version) is special in the fact that it is the source (and we normally do the target), and we also know this the source of the LAST version change, we need to make sure we add it in
				processDiffReportToJson(versionChange.getDiffReport(), changelog, modObj);
				if(this.typeOfChangelog == CHANGELOG_TYPE.STRUCTURE_DIFFERENCE){
					details.put("fromUrn", versionChange.getSource().getUrn());
					details.put("toUrn", versionChange.getTarget().getUrn());
				}else{
					if(count == changes.size()) {
						modObj = new JSONObject();
						period = versionChange.getSource().getValidityPeriod();
						if(period != null) {
							SdmxDate start = period.getStartPeriod();
							if(start != null) {
								modObj.put("startPeriod", start.getDateInSdmxFormat());
							}
							SdmxDate end = period.getEndPeriod();
							if(end != null) {
								modObj.put("endPeriod", end.getDateInSdmxFormat());
							}
						}
					}
					changelog.put(versionChange.getSource().getVersion().toString(), modObj);
				}

			}
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
		return returnJson;
	}


	private void processDiffReportToJson(DiffReport diffRep, JSONObject versionChangeJson, JSONObject modObj) throws JSONException {
		ModificationAction[] values = ModificationAction.values();
		for (int i = 0; i < values.length; i++) {
		    ModificationAction modification = values[i];
			SortedSet<Diff> diffs = diffRep.getdifferences(modification);
			JSONArray additions = new JSONArray();
			for (Diff diff : diffs) {
				JSONObject infoObj = new JSONObject();
				String source = diff.getURN().getURN();
				if(source == null) {
					source = diff.getSourceValue();
				}
				String prop = diff.getProperty();
				String sourceValue = null;
				String targetValue = null;
				infoObj.put("urn", source);
				infoObj.put("property", prop);
				switch(modification) {
				case ADDITION:
					String add = diff.getTargetValue();
					infoObj.put("value", add);
					break;
				case REMOVAL:
					String rem = diff.getSourceValue();
					infoObj.put("value", rem);
					break;
				case EDIT:
					if(prop.equals("URN")) {
						infoObj = new JSONObject();
						continue;
					}
					sourceValue = diff.getSourceValue();
					targetValue = diff.getTargetValue();
					break;
				default:
					sourceValue = diff.getSourceValue();
					targetValue = diff.getTargetValue();
					break;
				}
				if(sourceValue != null) {
					infoObj.put("sourcevalue", diff.getSourceValue());
				}
				if(targetValue != null) {
					infoObj.put("targetvalue", diff.getTargetValue());
				}
				additions.put(infoObj);
			}
			modObj.put(modification.toString(), additions);
		}
		versionChangeJson.put(diffRep.getTarget().getVersion().toString(), modObj);
	}

	@Override
	public String toString() {
		return this.toJSONString();
	}

}
