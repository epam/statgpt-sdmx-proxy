package io.sdmx.core.structure.manager.retrieval;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public class MultipleCrossReferencingRetrievalManager implements CrossReferencingRetrievalManager {
	private Set<CrossReferencingRetrievalManager> set = new HashSet<>();

	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURN<?> sourceStructureURN, boolean includeIndirectReferences, Class<T> structures) {
		Set<T> allMaints = new HashSet<>();
		for(CrossReferencingRetrievalManager currentManager : set) {
			allMaints.addAll(currentManager.getCrossReferencingStructures(sourceStructureURN, includeIndirectReferences, structures));
		}
		return allMaints;
	}

	public void addCrossReferencingRetrievalManager(CrossReferencingRetrievalManager crossReferencingRetrievalManager) {
		if(this.set == null) {
			this.set = new HashSet<>();
		}
		this.set.add(crossReferencingRetrievalManager);
	}

	public void setSet(Set<CrossReferencingRetrievalManager> set) {
		this.set = set;
	}
}
