package io.sdmx.core.structure.manager.constraint;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IConstraintModelRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.constraint.ContentConstraintModelImpl;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;

public class ConstraintModelRetreivalManager implements IConstraintModelRetreivalManager {
	private ConstraintRetrievalManager constraintRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	
	public ConstraintModelRetreivalManager(ConstraintRetrievalManager constraintRetrievalManager, SdmxSuperBeanRetrievalManager superBeanRetrievalManager, SdmxBeanRetrievalManager beanRetrievalManager) {
		this.constraintRetrievalManager = constraintRetrievalManager;
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public Set<ContentConstraintModel> getContentConstraintModels(ConstrainableBean maint, Date validOn) {
		DatasetStructures structures = new DatasetStructures(maint, beanRetrievalManager);
		DataStructureBean dsd = structures.getDataStructure();
		DataStructureSuperBean dsdSb = superBeanRetrievalManager.getDataStructureSuperBean(dsd.getURN());
		
		Set<ContentConstraintBean> constraints= constraintRetrievalManager.getAllConstraintsDefiningAllowedData((ConstrainableBean)maint);
		Set<ContentConstraintModel> constraintModels = new HashSet<>();
		for(ContentConstraintBean constraint : constraints) {
			if(validOn != null && constraint.hasValidityPeriod()) {
				if(!constraint.getValidityPeriod().isInPeriod(validOn)) {
					continue;
				}
				constraint = MaintainableUtil.stripOff(constraint);
			}
			constraintModels.addAll(ContentConstraintModelImpl.build(constraint, dsdSb, false));
		}
		return constraintModels;
	}
}
