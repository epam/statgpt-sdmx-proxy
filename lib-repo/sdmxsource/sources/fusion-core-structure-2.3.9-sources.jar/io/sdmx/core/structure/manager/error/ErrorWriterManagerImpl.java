package io.sdmx.core.structure.manager.error;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.engine.ErrorWriterEngine;
import io.sdmx.api.sdmx.factory.ErrorWriterFactory;
import io.sdmx.api.sdmx.manager.output.ErrorWriterManager;
import io.sdmx.api.sdmx.model.error.ISdmxError;
import io.sdmx.api.sdmx.model.validation.ErrorFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ErrorWriterManagerImpl implements ErrorWriterManager {
	
	private ErrorWriterEngine defaultEngine;
	
	public ErrorWriterManagerImpl(ErrorWriterEngine defaultEngine) {
		this.defaultEngine = defaultEngine;
	}


	@Override
	public int writeError(Throwable th, OutputStream out, ErrorFormat format) {
		return getErrorWriterEngine(format).writeError(th, out);
	}
	

	@Override
	public void writeError(ISdmxError error, OutputStream out, ErrorFormat format) {
		getErrorWriterEngine(format).writeError(error, out);
	}

	private ErrorWriterEngine getErrorWriterEngine(ErrorFormat format) {
		if(format == null && defaultEngine != null) {
			return defaultEngine;
		}
		for(ErrorWriterFactory factory : FusionBeanStore.getBeans(ErrorWriterFactory.class)) {
			ErrorWriterEngine engine = factory.getErrorWriterEngine(format);
			if(engine != null) {
				return engine;
			}
		}
		throw new SdmxNotImplementedException("Could not write error out in format: " +format);
	}
}
