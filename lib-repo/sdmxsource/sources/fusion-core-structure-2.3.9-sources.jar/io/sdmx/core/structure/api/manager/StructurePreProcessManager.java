package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Allows the SdmxBeans to be mutated or changed BEFORE and AFTER validation on a save message
 *
 */
public interface StructurePreProcessManager {
	/**
	 * Called before and after validation on the save message
	 * @param SdmxBeans
	 * @param isPreValidation if true then the validation is yet to occur, false to indicate validation was good and the save is about
	 * to be actioned
	 */
	void preProcess(SdmxBeans beans, boolean isPreValidation);
}
