package io.sdmx.core.structure.api.engine.merge;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

public interface MaintainableMergeEngine<T extends MaintainableBean> {

	/**
	 * Merges two content of two maintainables of the same type to return a sinlge merged instance.
	 * <p/>
	 * <strong>Note: </strong> The two maintainables must be of the same agency, id, and version
	 * 
	 * If one argument is null then the not null maintainable will be returned.  If both arguments are null, null will be returned
	 *
	 * @param maint1
	 * @param maint2
	 * @return
	 */
	T mergeMaintainables(T maint1, T maint2);
	
}
