package io.sdmx.core.structure.model.store;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.core.structure.api.model.store.IStructureFilterStore;

class StructureIdFilterStore<T> implements IStructureFilterStore<T> {
	private Map<IVersionRef, Set<T>> versionStore = new HashMap<>();

	@Override
	public void store(IURN<?> urn, T toStore) {
		IVersionRef version = urn.getVersion();
		Set<T> versions = versionStore.get(version);
		if(versions == null) {
			versions = new HashSet<>();
			versionStore.put(version, versions);
		}
		versions.add(toStore);
	}

	@Override
	public Set<T> find(MaintainableBean maint) {
		Set<T> returnSet = new HashSet<>();
		ISdmxVersion version = maint.getVersion();
		for(IVersionRef vRef : this.versionStore.keySet()) {
			if(vRef.isMatch(version)) {
				returnSet.addAll(this.versionStore.get(vRef));
			}
		}
		return returnSet;
	}
}
