package io.sdmx.core.structure.api.manager;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;

/**
 * Used to extract structural metadata from a columnar data file
 */
public interface StructureDiscoveryManager {

	/**
	 * Builds a Data Structure Definition, Concepts, and Related Codelists based on the StructureDiscoveryRules.
	 * <p/>
	 * The Data Structure and Concepts are based soley on the StructureDiscoveryRules, the Codelists are built
	 * from the passed in dataset
	 * 
	 * @param columnReader to read the data
	 * @param rules the rules
	 * @return
	 */
	SdmxBeans buildStructures(ColumnReaderEngine columnReader, StructureDiscoveryRules rules, SdmxBeanRetrievalManager retrievalManager);
	
}
