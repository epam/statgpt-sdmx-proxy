package io.sdmx.core.structure.manager.reference;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.CrossReferencingTree;
import io.sdmx.core.structure.api.manager.CrossReferenceInformationManager;
import io.sdmx.im.beans.reference.CrossReferencingTreeImpl;

public class CrossReferenceInformationManagerImpl implements CrossReferenceInformationManager {
	private CrossReferencingRetrievalManager crossReferencingRetrievalManager;
	
	public CrossReferenceInformationManagerImpl(CrossReferencingRetrievalManager crossReferencingRetrievalManager) {
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
	}

	@Override
	public CrossReferencingTree getCrossReferenceTree(MaintainableBean maintainableBean) {
		Set<MaintainableBean> allMaintainables = new HashSet<>();
		allMaintainables.add(maintainableBean);
		return getCrossReferenceTree(maintainableBean, allMaintainables);
	}
	
	private CrossReferencingTree getCrossReferenceTree(MaintainableBean maintainableBean, Set<MaintainableBean> allMaintainables) {
		List<CrossReferencingTree> referencingBeans = new ArrayList<>();
		for(MaintainableBean currentReferencing : crossReferencingRetrievalManager.getCrossReferencingStructures(maintainableBean, true)) {
			if(allMaintainables.add(currentReferencing)) {
				referencingBeans.add(getCrossReferenceTree(currentReferencing));
			}
		}
		return new CrossReferencingTreeImpl(maintainableBean, referencingBeans);
	}
}
