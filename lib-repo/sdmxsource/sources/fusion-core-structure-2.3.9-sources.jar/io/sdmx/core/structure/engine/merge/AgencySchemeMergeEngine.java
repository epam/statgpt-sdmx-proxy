package io.sdmx.core.structure.engine.merge;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Merges the agencies in the agency schemes by adding all the items of one scheme, that do not exist in the other, together.
 */
public class AgencySchemeMergeEngine implements MaintainableMergeEngine<AgencySchemeBean>, IFusionSingleton {
	private static AgencySchemeMergeEngine INSTANCE;

	public static AgencySchemeMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new AgencySchemeMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private AgencySchemeMergeEngine() {}

	@Override
	public AgencySchemeBean mergeMaintainables(AgencySchemeBean maint1, AgencySchemeBean maint2) {
		if(maint1 != null && maint2 != null) {
			AgencySchemeMutableBean mutableBean = maint1.getMutableInstance();
			for(AgencyBean currentAgency : maint2.getItems()) {
				if(!maint1.getItems().contains(currentAgency)) {
					mutableBean.addItem(new AgencyMutableBeanImpl(currentAgency, mutableBean));
				}
			}
			return mutableBean.getImmutableInstance();
		}
		if(maint1 == null) {
			return maint2;
		}
		if(maint2 == null) {
			return maint1;
		}
		return null;
	}
}
