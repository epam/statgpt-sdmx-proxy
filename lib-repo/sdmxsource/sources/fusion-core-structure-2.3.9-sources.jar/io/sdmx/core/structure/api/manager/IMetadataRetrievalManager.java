package io.sdmx.core.structure.api.manager;

import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;

public interface IMetadataRetrievalManager {

	/**
	 * Find a single instance of metadata, where all parameters are provided in the URN
	 * @param ref expects agency, id, and version to be non null
	 * @return matched reference metadata, or null if it does not exist
	 */
	IReportedMetadataSetBean getMetadata(IURNMaintainable<IReportedMetadataSetBean> ref, SdmxDate asOf);
	
	/**
	 * Finds all the metadata sets where the parameters are optional
	 * @param ref required filters
	 * @return not null, immutable list of matched metadata sets
	 */
	Set<IReportedMetadataSetBean> findByMetadataSet(IURN<IReportedMetadataSetBean> ref, SdmxDate asOf);
	
	/**
	 * Finds all the metadata sets which use the metadataflow with the given agency, id, and version
	 * @param ref required filters
	 * @param providerRef - optional filter by metadata provider
	 * @return not null, immutable list of matched metadata sets
	 */
	Set<IReportedMetadataSetBean> findByMetadataflow(IURN<MetadataFlowBean> ref, IURN<IMetadataProviderBean> providerRef, SdmxDate asOf);
	
	/**
	 * Finds all the metadata sets which reference the structure with the given agency, id, and version
	 * @param st the structure to query by
	 * @param ref required filters
	 * @return not null, immutable list of matched metadata sets
	 */
	Set<IReportedMetadataSetBean> findByStructure(IURN<?> urn, SdmxDate asOf);
	
}
