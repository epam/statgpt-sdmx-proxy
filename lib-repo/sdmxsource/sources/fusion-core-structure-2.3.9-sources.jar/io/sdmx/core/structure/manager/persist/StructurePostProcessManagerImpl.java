package io.sdmx.core.structure.manager.persist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.core.structure.api.engine.persist.StructurePostProcessEngine;
import io.sdmx.core.structure.api.manager.StructurePostProcessManager;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StructurePostProcessManagerImpl implements StructurePostProcessManager {
    private static final Logger LOG = LoggerFactory.getLogger(StructurePostProcessManagerImpl.class);
	
	@Override
	public void postProces(SdmxBeansEvent beansEvent) {
		LOG.info("Post Process Beans Event");
		for(StructurePostProcessEngine spp : FusionBeanStore.getBeans(StructurePostProcessEngine.class)) {
			try {
				spp.postProces(beansEvent);
			} catch(Throwable th) {
				LOG.error("Error in post processor '"+spp.getClass().getName()+"' while post processing beans event", th);
			}
		}
	}
}
