package io.sdmx.core.structure.manager.cache;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.sdmx.api.notification.Listener;
import io.sdmx.api.notification.Notifier;
import io.sdmx.api.sdmx.engine.CacheEngine;
import io.sdmx.api.sdmx.event.IEvent;
import io.sdmx.api.sdmx.event.IMetadataEvent;
import io.sdmx.api.sdmx.event.IStructureEvent;
import io.sdmx.api.sdmx.event.IStructureEventListener;
import io.sdmx.api.sdmx.manager.structure.StrucutreInformationManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StrucutreInformationManagerImpl implements StrucutreInformationManager, Listener<IEvent>, IStructureEventListener, CacheEngine {

	private Map<String, Long> urnToLastUpdatedTimeMap = new ConcurrentHashMap<>();

	@Override
	public void notifyStructureEvent(IStructureEvent beansEvent) {
		SdmxBeans deletions = beansEvent.getDeletions();
		Set<MaintainableBean> allDeletions = deletions.getAllMaintainables();
		if (!allDeletions.isEmpty()) {
			for (MaintainableBean maint : allDeletions) {
				String urn = maint.getUrn();
				if(urnToLastUpdatedTimeMap.containsKey(urn)) {
					urnToLastUpdatedTimeMap.remove(urn);
				}
			}

			// MEDIT #410 - Tactical patch.
			// If any bean has been deleted, reset every element in the map to the current time. This may give false positives later
			// but these are better than false negatives
			long timeNow = System.currentTimeMillis();
			for (Map.Entry<String,Long> entry : urnToLastUpdatedTimeMap.entrySet()) {
				urnToLastUpdatedTimeMap.put(entry.getKey(), timeNow);
			}
			
			urnToLastUpdatedTimeMap = new ConcurrentHashMap<>();
		}
		
		addToMap(beansEvent.getAdditions());
		addToMap(beansEvent.getModification());
	}

	@Override
	public void invoke(IEvent notification) {
		if(notification instanceof IMetadataEvent) {
			// Trash everything - this is because the metadata could have been applied to anything
			urnToLastUpdatedTimeMap = new ConcurrentHashMap<>();
			
			IMetadataEvent beansEvent = (IMetadataEvent)notification;
			addToMap(beansEvent.getAdded());
			addToMap(beansEvent.getEdit());
			Set<IURNMaintainable<IReportedMetadataSetBean>> deletions = beansEvent.getDeleted();
			for (IURNMaintainable<IReportedMetadataSetBean> iurn : deletions) {
				String urn = iurn.getURN();
				if(urnToLastUpdatedTimeMap.containsKey(urn)) {
					urnToLastUpdatedTimeMap.remove(urn);
				}
			}
		}
	}
	
	private void addToMap(SdmxBeans beans) {
		for (MaintainableBean maint : beans.getAllMaintainables()) {
			urnToLastUpdatedTimeMap.put(maint.getUrn(), System.currentTimeMillis());
		}
	}
	
	private void addToMap(IReferenceMetadataContainer rmc) {
		for (MaintainableBean maint : rmc.getReferenceMetadata()) {
			urnToLastUpdatedTimeMap.put(maint.getUrn(), System.currentTimeMillis());
		}
	}
	
	@Override
	public void banDataForDataFlow(StructureReferenceBean flowRef) {
		if(flowRef == null) {
		    Map<String, Long> newMap = new ConcurrentHashMap<>();
		    for(String urn : urnToLastUpdatedTimeMap.keySet()) {
		        StructureReferenceBean ref = new StructureReferenceBeanImpl(urn);
		        switch(ref.getTargetReference()) {
		        case PROVISION_AGREEMENT :
		        case DATAFLOW :
		        case DATA_PROVIDER_SCHEME :
                case CATEGORY_SCHEME :
                case CONCEPT_SCHEME :
                case CONTENT_CONSTRAINT :
		        case DSD :
		            newMap.put(urn, System.currentTimeMillis());
		            break;
		        default :
	                    newMap.put(urn, urnToLastUpdatedTimeMap.get(urn));
		        }
		    }
		    urnToLastUpdatedTimeMap = newMap;
		} else {
		    urnToLastUpdatedTimeMap.put(flowRef.getTargetUrn(), System.currentTimeMillis());
		}
	}

	@Override
	public void banReferenceMetadata() {
		
	}

	@Override
	public void banAllStructures() {
//	    banAll();
	}

	@Override
	public void banAll() {
//	    Map<String, Long> newMap = new ConcurrentHashMap<>();
//        for(String urn : urnToLastUpdatedTimeMap.keySet()) {
//                newMap.put(urn, System.currentTimeMillis());
//        }
//        urnToLastUpdatedTimeMap = newMap;
	}

	@Override
	public Long getLastModifiedTime(MaintainableBean maint) {
		if(urnToLastUpdatedTimeMap.containsKey(maint.getUrn())) {
			return urnToLastUpdatedTimeMap.get(maint.getUrn());
		}
		urnToLastUpdatedTimeMap.put(maint.getUrn(), System.currentTimeMillis());
		//DEV-1376 This no longer works because reference metadata can change a structure without
		//it changing in the database
//		if(txManager != null) {
//			Long txLastUpdate = txManager.getLastUpdatedDate(maint);
//			if(txLastUpdate == null) {
//				return null;
//			}
//			urnToLastUpdatedTimeMap.put(maint.getUrn(), txLastUpdate);
//			return txLastUpdate;
//		}
		return null;
	}

	public void setStructureNotifier(Notifier<IEvent> beansEventNotifier) {
		beansEventNotifier.addListener(this);
	}
	public void setMetadataNotifier(Notifier<IEvent> metadataEventNotifier) {
		metadataEventNotifier.addListener(this);
	}
}
