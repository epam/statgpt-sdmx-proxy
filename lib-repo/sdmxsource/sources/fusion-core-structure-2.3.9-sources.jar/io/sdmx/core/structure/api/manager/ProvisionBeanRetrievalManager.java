package io.sdmx.core.structure.api.manager;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;

/**
 * Manages the retrieval of provision agreements using simple reference of structures that directly reference a provision.
 */
public interface ProvisionBeanRetrievalManager {
	
	/**
	 * Returns all the provisions in the system
	 * @return a Set of ProvisionAgreementBeans
	 */
	Set<ProvisionAgreementBean> getProvisions();
	
	/**
	 * Returns a list of provisions that match the structure reference.
	 * <p/>
	 * The structure reference can either be referencing a Provision structure, a Data or MetdataFlow, or a DataProvider.
	 * 
	 * @param structureRef
	 * @return a Set of ProvisionAgreementBeans
	 */
	Set<ProvisionAgreementBean> getProvisions(IURNSingle<? extends ConstrainableBean> structureRef);
	
	/**
	 * @param dsdUrn
	 * @return all the provision agreements that reference any of the dataflows with the given URN
	 */
	Set<ProvisionAgreementBean> getProvisionsByDataStructure(IURNSingle<DataStructureBean> dsdUrn);

	/**
	 * Returns the provision agreement that the registration is referencing
	 * @param registration
	 * @return a single ProvisionAgreementBeans
	 */
	default ProvisionAgreementBean getProvision(RegistrationBean registration) {
	    return getProvisionByProvision(registration.getProvisionAgreementRef().getReference());
	}
	
	ProvisionAgreementBean getProvisionByProvision(IURNSingle<ProvisionAgreementBean> provision);
	
	/**
	 * Returns all the provision Agreements that are referencing the given dataflow
	 * @param dataflow
	 * @return a Set of ProvisionAgreementBeans
	 */
	default Set<ProvisionAgreementBean> getProvisions(DataflowBean dataflow) {
		return getProvisionsByDataflow(dataflow.getURN());
	}
	Set<ProvisionAgreementBean> getProvisionsByDataflow(IURNSingle<DataflowBean> dataflow);

	default Set<ProvisionAgreementBean> getProvisions(DataProviderBean provider) {
		return getProvisionsByProvider(provider.getURN());
	}
	Set<ProvisionAgreementBean> getProvisionsByProvider(IURNSingle<DataProviderBean> provider);
	
	/**
	 * Returns all the provision Agreements that are referencing the given dataflow
	 * 
	 * @param dataflow
	 * @param dataProviderBean
	 * @return a Set of ProvisionAgreementBeans
	 */
	default Set<ProvisionAgreementBean> getProvisions(DataflowBean dataflow, DataProviderBean dataProviderBean) {
		return getProvisionsByFlowAndProvider(dataflow.getURN(), dataProviderBean.getURN());
	}
	
	default Set<ProvisionAgreementBean> getProvisionsByFlowAndProvider(IURNSingle<DataflowBean> dataflow, IURNSingle<DataProviderBean> providerRef) {
		Set<ProvisionAgreementBean> returnSet = new HashSet<>();
		for(ProvisionAgreementBean prov : getProvisionsByDataflow(dataflow)) {
			if(prov.getDataproviderRef().getReference().isMatch(providerRef)) {
				returnSet.add(prov);
			}
		}
		return returnSet;
	}

}