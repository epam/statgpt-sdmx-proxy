package io.sdmx.core.structure.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.core.structure.model.ref.ReferencesUpdatedRequest;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StructureUtil {
	private static final Logger LOG = LoggerFactory.getLogger(StructureUtil.class);

	
	/**
	 * Returns true if the DSD structure (Dimensions or Dimension order) is different between source and target
	 * @param source
	 * @param target
	 * @return
	 */
	public static boolean isStructureDifferent(DataStructureBean source, DataStructureBean target) {
		//1. DIMENSION VALIDATION
		for(DimensionBean newDimension : source.getDimensions()) {
			DimensionBean existingDimension = target.getDimension(newDimension.getId());

			//DIMENSION ADDITION
			if(existingDimension == null) {
				LOG.debug("Dimension Added : " + newDimension.getId());
				return true;
			}
			
			// Check dimension position remains the same
			if (existingDimension != null) {
				int existingPosition = existingDimension.getPosition();
				int newDimensionPosition = newDimension.getPosition();
				if (existingPosition != newDimensionPosition) {
					return true;
				}
			}
		}

		//DIMENSION REMOVAL
		for(DimensionBean existingDimension : target.getDimensions()) {
			if(source.getDimension(existingDimension.getId()) == null) {
				return true;
			}
		}
		
		return false;
	}
	

	/**
	 * Changes the unique identifiers for a maintainable structure
	 * @param aMaint
	 * @param targetRef
	 * @return
	 */
	public static MaintainableBean changeValues(MaintainableBean aMaint, IURNSingle<?> targetRef) {
		MaintainableMutableBean mutable = aMaint.getMutableInstance();
		if(targetRef.hasMaintainableId()) {
			mutable.setId(targetRef.getMaintainableId());
		}
		if(targetRef.hasAgencyId()) {
			mutable.setAgencyId(targetRef.getAgencyId());
		}
		mutable.setVersion(targetRef.getVersion().toString());
		return mutable.getImmutableInstance();
	}

	/**
	 * Changes the references for a maintainable structure
	 * @param maintainableBeanToChange the bean to change, this is the maintainable that was referencing the old maint
	 * @param oldMaint this is the maintainable that was previously referenced by the maintainableBeanToChange
	 * @param newValues - this is the new refernece parameters (agency, id, version)
	 * @return
	 */
	public static ReferencesUpdatedRequest changeReferences(MaintainableBean maintainableBeanToChange, MaintainableBean oldMaint, IMaintainableProperties newValues) {
		MaintainableMutableBean mutable = maintainableBeanToChange.getMutableInstance();
		Map<StructureReferenceBean, StructureReferenceBean> modifiedReferences = new HashMap<>();
		for(StructureReferenceBean modifiedRef : mutable.getStructureReferences()) {
			if(modifiedRef.getMaintainableUrn().equals(oldMaint.getUrn())) {
				StructureReferenceBean originalRef = new StructureReferenceBeanImpl(modifiedRef.getTargetUrn());
				changeReferences(mutable, modifiedRef, newValues);
				modifiedReferences.put(originalRef, modifiedRef);
			} 
		}
		return new ReferencesUpdatedRequest(maintainableBeanToChange, mutable.getImmutableInstance(), modifiedReferences);
	}

	
	/**
	 * Changes all maintainables with the agency from to the agency to, updates all references 
	 * @param agencyFrom
	 * @param agencyTo
	 * @param allBeans
	 * @return
	 */
	public static void changeAgency(String agencyFrom, String agencyTo, SdmxBeans allBeans) {
		for(MaintainableBean maint : allBeans.getAllMaintainables()) {
			MaintainableMutableBean mutable = null;
			if(maint.getAgencyId().equals(agencyFrom)) {
				mutable = maint.getMutableInstance().setAgencyId(agencyTo);
			}
			boolean updateRef = false;
			for(ICrossReferenceBean<?> xsRef : maint.getCrossReferences()) {
				if(xsRef.getReference().getAgencyId().equals(agencyFrom)) {
					updateRef = true;
					if(mutable == null) {
						mutable = maint.getMutableInstance();
					}
					break;
				}
			}
			if(updateRef) {
				for(StructureReferenceBean ref : mutable.getStructureReferences()) {
					if(ref.getAgencyId().equals(agencyFrom)) {
						ref.setAgencyId(agencyTo);
					}
				}
			}
			if(mutable != null) {
				allBeans.removeMaintainable(maint);
				allBeans.addIdentifiable(mutable.getImmutableInstance());
			}
		}
	}

	/**
	 * Changes the references for a maintainable structure
	 * @param maintainableBeanToChange
	 * @param oldMaint
	 * @param newValues
	 * @return
	 */
	public static MaintainableBean changeReferences(MaintainableBean maintainableBeanToChange, Map<StructureReferenceBean, StructureReferenceBean> refs) {
		MaintainableMutableBean mutable = maintainableBeanToChange.getMutableInstance();
		changeReferences(mutable, refs);
		return mutable.getImmutableInstance();
	}


	public static void changeReferences(MaintainableMutableBean mutable, Map<StructureReferenceBean, StructureReferenceBean> refs) {
		for(StructureReferenceBean ref : mutable.getStructureReferences()) {
			StructureReferenceBean changeTo = refs.get(ref);
			if(changeTo != null) {
				ref.setMaintainableId(changeTo.getMaintainableId());
				ref.setAgencyId(changeTo.getAgencyId());
				ref.setVersion(changeTo.getVersion());
			}
		}
	}

	public static void changeReferences(MaintainableMutableBean mutable, StructureReferenceBean from, IMaintainableProperties to) {
		from.setMaintainableId(to.getId());
		from.setAgencyId(to.getAgencyId());
		from.setVersion(to.getVersion().toString());
	}
}
