package io.sdmx.core.structure.api.manager;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableProperties;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;

public interface IStructureIdentityModificationManager {

	/**
	 * Changes the Id, Version and/or Agency of structures and any structures that reference them.
	 *
	 * @param modifiedMaintainables A map of structure references to maintainable references, where the structure reference is the current
	 * and the maintainable reference containing the potentially new values of Id, Version and/or Agency.
	 * @return the modified beans
	 */
	SdmxBeans changeIdentity(Map<IURNMaintainable<?>, IMaintainableProperties> modifiedMaintainables);

}
