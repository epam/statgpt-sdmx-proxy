package io.sdmx.core.structure.engine.merge;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class CodelistMergeEngine implements MaintainableMergeEngine<CodelistBean>, IFusionSingleton {
	private static CodelistMergeEngine INSTANCE;

	public static CodelistMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new CodelistMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private CodelistMergeEngine() {}

	@Override
	/**
	 * Merges all of the codes from Cb1 and Cb2 into a new CodelistBean. Neither Cb1 or Cb2 will be modified in any way.
	 * <p>
	 * Cb1 is the baseline for the merge operation. The Cb2 codes are applied to Cb1.
	 * If the codes already exist in cb1, they will not be imported from cb2, so this method cannot be used to update existing values.
	 * @param cb1 A CodelistBean providing the baseline of codes.
	 * @param cb2 A CodelistBean providing additional codes.
	 * @return A new CodelistBean with the elements from cb1 and cb2.
	 */
	public CodelistBean mergeMaintainables(CodelistBean cb1, CodelistBean cb2) {
		if (cb1 == null && cb2 == null) {
			throw new IllegalArgumentException("Cannot merge two null CodelistBeans");
		}
		if (cb1 == null) {
			return new CodelistMutableBeanImpl(cb2).getImmutableInstance();
		}
		if (cb2 == null) {
			return new CodelistMutableBeanImpl(cb1).getImmutableInstance();
		}

		Set<CodeBean> codesSet = new HashSet<>(cb1.getItems());

		CodelistMutableBean returnCodelist = new CodelistMutableBeanImpl(cb1);
		for (CodeBean aCode: cb2.getItems()) {
			if (codesSet.contains(aCode)) {
				continue;
			}
			CodeMutableBean codeMutableBean = new CodeMutableBeanImpl(aCode, returnCodelist);

			//get Position is 1 indexed, set position is zero indexed
			returnCodelist.addItemAtPosition(codeMutableBean, aCode.getPosition()-1);
		}
		return returnCodelist.getImmutableInstance();
	}
}
