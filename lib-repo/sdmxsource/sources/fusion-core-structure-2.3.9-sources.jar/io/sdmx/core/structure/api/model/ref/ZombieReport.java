package io.sdmx.core.structure.api.model.ref;

import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;

/**
 * A report of which maintainables are not referenced by any other identifiables
 */
public interface ZombieReport {

    /**
     * @return a set of maintainables, none of which are referenced by any other structure
     */
    public Set<MaintainableBean> getUnreferencedMaintainables();
}
