package io.sdmx.core.structure.manager.retrieval;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.ReadableDataLocationFactory;
import io.sdmx.api.notification.Listener;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansStorageManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.im.beans.SdmxBeansEventImpl;
import io.sdmx.im.beans.container.SdmxBeansImpl;

/**
 * An implementation of SdmxBeansStorageManager which allows the SdmxBeans container to be built from
 * an input stream of structures (any supported structure format) - listeners are notified when the beans are on updated
 *
 * @see updateStructures
 */
public class ReadFromStreamSdmxBeansStorageManager implements SdmxBeansStorageManager {

	private List<Listener<SdmxBeansEvent>> listeners = new ArrayList<>();

	private ReadableDataLocationFactory rdlFactory;
	private StructureReaderManager structureReaderManager;
	private SdmxBeans sdmxBeans = new SdmxBeansImpl();
	
	public ReadFromStreamSdmxBeansStorageManager(ReadableDataLocationFactory rdlFactory, StructureReaderManager structureReaderManager) {
		this.rdlFactory = rdlFactory;
		this.structureReaderManager = structureReaderManager;
	}
	
	@Override
	public SdmxBeans getSdmxBeans() {
		return sdmxBeans;
	}

	@Override
	public void clearCache() {
		sdmxBeans = new SdmxBeansImpl();
	}

	/**
	 * Updates the SdmxBeans based on a structures document (any format) read as a stream - performs a full replace
	 * @param rdl
	 */
	public void updateStructures(InputStream is, DATASET_ACTION action) {
		try (ReadableDataLocation rdl = rdlFactory.getReadableDataLocation(is)) {
            updateStructures(rdl, action);
        }
	}

	/**
	 * Updates the SdmxBeans based on a structures document (any format) read as a stream - performs a full replace
	 * @param rdl
	 */
	public void updateStructures(ReadableDataLocation rdl, DATASET_ACTION action) {
		SdmxBeans newBeans = structureReaderManager.parseStructures(rdl);
		updateStructures(newBeans, action);
	}

	/**
	 * Updates the structures with the new SdmxBeans - performs a full replace
	 * @param newBeans
	 */
	public void updateStructures(SdmxBeans beans, DATASET_ACTION action) {
		SdmxBeans newBeans;
		if(action == DATASET_ACTION.FULL_REPLACE) {
			newBeans = beans;
		} else {
			newBeans = new SdmxBeansImpl(sdmxBeans);
			if(action == DATASET_ACTION.DELETE) {
				for(MaintainableBean maint : beans.getAllMaintainables()) {
					newBeans.removeMaintainable(maint);
				}
			} else {
				for(MaintainableBean maint : beans.getAllMaintainables()) {
					newBeans.addIdentifiable(maint);
				}
			}
		}

		SdmxBeansEvent event = new SdmxBeansEventImpl(sdmxBeans, newBeans);
		this.sdmxBeans = newBeans;
		for(Listener<SdmxBeansEvent> l : listeners) {
			l.invoke(event);
		}
	}

	@Override
	public void addListener(Listener<SdmxBeansEvent> listener) {
		listeners.add(listener);
	}

	@Override
	public void removeListener(Listener<SdmxBeansEvent> listener) {
		listeners.remove(listener);
	}

}
