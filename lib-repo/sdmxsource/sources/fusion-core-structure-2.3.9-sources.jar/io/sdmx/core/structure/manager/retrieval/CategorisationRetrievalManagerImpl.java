package io.sdmx.core.structure.manager.retrieval;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.sdmx.model.superbeans.categoryscheme.CategorisationSuperBean;
import io.sdmx.core.structure.api.manager.CategorisationRetrievalManager;
import io.sdmx.im.superbeans.categoryscheme.CategorisationSuperBeanImpl;

public class CategorisationRetrievalManagerImpl implements CategorisationRetrievalManager {

	private SdmxBeanRetrievalManager retrievalManager;
	private CrossReferencingRetrievalManager crossReferencingRetrievalManager;
	
	public CategorisationRetrievalManagerImpl(SdmxBeanRetrievalManager retrievalManager, CrossReferencingRetrievalManager crossReferencingRetrievalManager) {
		this.retrievalManager = retrievalManager;
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
	}

	@Override
	public Set<CategorisationBean> getCategorisations(IdentifiableBean identifiable) {
		Set<CategorisationBean> returnSet = new HashSet<>();
		String identifiableUrn = identifiable.getUrn();
		for(CategorisationBean cat : getCrossReferencingCategorisations(identifiable)) {
			if(cat.getStructureReference().getTargetUrn().equals(identifiableUrn)) {
				returnSet.add(cat);
			}
		}
		return returnSet;
	}
	
	@Override
	public Set<CategorisationBean> getCategorisationsForCategoryScheme(CategorySchemeBean scheme) {
		Set<CategorisationBean> returnSet = new HashSet<>();
		for(IdentifiableBean currentIdentifiable : scheme.getIdentifiableComposites()) {
			for(CategorisationBean categorisation : crossReferencingRetrievalManager.getCrossReferencingStructures(currentIdentifiable, false, CategorisationBean.class)) {
				returnSet.add((CategorisationBean)categorisation);
			}
		}
		return returnSet;
	}

	@Override
	public Set<CategorisationBean> getCategorisationsForCategory(CategoryBean category) {
		Set<CategorisationBean> returnSet = new HashSet<>();
		for(CategorisationBean cat : getCrossReferencingCategorisations(category)) {
			if(cat.getCategoryReference().isMatch(category)) {
				returnSet.add(cat);
			}
		}
		return returnSet;
	}
	
	@Override
	public Set<CategorisationSuperBean> getCategorisationSuperBean(IdentifiableBean identifiable) {
		Set<CategorisationSuperBean> returnSet = new HashSet<>();
		for(CategorisationBean categorisation : getCategorisations(identifiable)) {
			returnSet.add(new CategorisationSuperBeanImpl(categorisation, retrievalManager));
		}
		return returnSet;
	}

	@Override
	public Set<CategorisationSuperBean> getCategorisationSuperBeanForCategory(CategoryBean category, SDMX_STRUCTURE_TYPE... includeTypes) {
		Set<CategorisationSuperBean> returnSet = new HashSet<>();
		Set<SDMX_STRUCTURE_TYPE> includeTypesSet = new HashSet<>();
		if(includeTypesSet != null) {
			for(SDMX_STRUCTURE_TYPE currentType : includeTypes) {
				includeTypesSet.add(currentType);
			}
		}
		for(CategorisationBean categorisation : getCategorisationsForCategory(category)) {
			if(includeTypesSet.size() == 0 || includeTypesSet.contains(categorisation.getStructureReference().getTargetReference())) {
				returnSet.add(new CategorisationSuperBeanImpl(categorisation, retrievalManager));
			}
		}
		return returnSet;
	}
	
	private Set<CategorisationBean> getCrossReferencingCategorisations(IdentifiableBean identifiableBean) {
		Set<CategorisationBean> returnSet = new HashSet<>();
		for(CategorisationBean categorisation : crossReferencingRetrievalManager.getCrossReferencingStructures(identifiableBean, false, CategorisationBean.class)) {
			returnSet.add(categorisation);
		}
		return returnSet;
	}
}
