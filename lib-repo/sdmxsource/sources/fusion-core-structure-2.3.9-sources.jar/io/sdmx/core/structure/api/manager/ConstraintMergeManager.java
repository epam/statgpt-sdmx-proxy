package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;

public interface ConstraintMergeManager {

	/**
	 * Merges the keys, codes and dates from the mergeConstraint into the master constraint
	 * Any of the arguments can be null, if both are null null is returned.
	 * @param masterConstraint
	 * @param mergeConstraint
	 * @return
	 */
	ContentConstraintBean merge(ContentConstraintBean masterConstraint, ContentConstraintBean mergeConstraint);
	
}
