package io.sdmx.core.structure.model.ref;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.modify.IReferencesUpdatedRequest;
import io.sdmx.api.sdmx.model.modify.IURNChangeRequest;

/**
 * The URN of one or more maintainables has been modified, this results in not only maintainable URNs changing
 * but also Maintainables being modified because the reference is changed
 */
public class URNChangeRequest implements IURNChangeRequest {
	private String uid = UUID.randomUUID().toString();
	private Map<MaintainableBean, MaintainableBean> urnChanges;
	private Map<String, IReferencesUpdatedRequest> referenceUpdates;
	
	
	/**
	 * 
	 * @param urnChanges
	 * @param referenceUpdates
	 */
	public URNChangeRequest(Map<MaintainableBean, MaintainableBean> urnChanges, Map<String, IReferencesUpdatedRequest> referenceUpdates) {
		this.urnChanges = Collections.unmodifiableMap(urnChanges);
		this.referenceUpdates = Collections.unmodifiableMap(referenceUpdates);
	}
	
	/**
	 * Unique identifier for this change request
	 */
	public String getUid() {
		return uid;
	}

	public Map<MaintainableBean, MaintainableBean> getUrnChanges() {
		return urnChanges;
	}
	
	public Map<String, IReferencesUpdatedRequest> getReferenceUpdates() {
		return referenceUpdates;
	}
}
