package io.sdmx.core.structure.manager.retrieval;

import java.util.List;

import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.im.beans.container.SdmxBeansImpl;

public class MultiSubmissionRequest  implements StructurePersistenceManager {
	private List<StructurePersistenceManager> managers;
	
	
	public MultiSubmissionRequest(List<StructurePersistenceManager> managers) {
		this.managers = managers;
	}
	
	@Override
	public void saveStructure(MaintainableBean maintainable) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		saveStructures(beans);
	}

	@Override
	public void deleteStructure(MaintainableBean maintainable) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		deleteStructures(beans);
	}

	@Override
	public void saveStructures(SdmxBeans beans, IStructureValidationErrorHandler errorHandler) {
		for(StructurePersistenceManager manager : managers) {
			manager.saveStructures(beans, errorHandler);
		}
	}

	@Override
	public void deleteStructures(SdmxBeans beans) {
		for(StructurePersistenceManager manager : managers) {
			manager.deleteStructures(beans);
		}
	}
}

