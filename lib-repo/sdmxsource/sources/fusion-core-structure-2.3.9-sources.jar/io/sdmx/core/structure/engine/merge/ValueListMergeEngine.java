package io.sdmx.core.structure.engine.merge;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.structure.api.engine.merge.MaintainableMergeEngine;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ValueListMergeEngine implements MaintainableMergeEngine<ValueListBean>, IFusionSingleton {
	private static ValueListMergeEngine INSTANCE;

	public static ValueListMergeEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ValueListMergeEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	private ValueListMergeEngine() {}

	@Override
	/**
	 * Merges all of the items from vl1 and vl2 into a new ValueListBean. Neither vl1 or vl22 will be modified in any way.
	 * <p>
	 * vl1 is the baseline for the merge operation. The vl2 items are applied to vl1.
	 * If the items already exist in vl1, they will not be imported from vl2, so this method cannot be used to update existing values.
	 * @param vl1 A ValueListBean providing the baseline of items.
	 * @param vl2 A ValueListBean providing additional items.
	 * @return A new ValueListBean with the elements from vl1 and vl2.
	 */
	public ValueListBean mergeMaintainables(ValueListBean vl1, ValueListBean vl2) {
		if (vl1 == null && vl2 == null) {
			throw new IllegalArgumentException("Cannot merge two null ValueListBeans");
		}
		if (vl1 == null) {
			return new ValueListMutableBeanImpl(vl2).getImmutableInstance();
		}
		if (vl2 == null) {
			return new ValueListMutableBeanImpl(vl1).getImmutableInstance();
		}

		Set<ValueItemBean> itemsSet = new HashSet<>(vl1.getItems());

		ValueListMutableBean returnValueList = new ValueListMutableBeanImpl(vl1);
		for (ValueItemBean anItem: vl2.getItems()) {
			if (itemsSet.contains(anItem)) {
				continue;
			}
			ValueItemMutableBeanImpl valueItemMutableBean = new ValueItemMutableBeanImpl(anItem, returnValueList);

			//get Position is 1 indexed, set position is zero indexed
			returnValueList.addItemAtPosition(valueItemMutableBean, anItem.getPosition()-1);
		}
		return returnValueList.getImmutableInstance();
	}
}
