package io.sdmx.core.structure.manager.constraint;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IConstraintPrefixDetailRetreivalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.im.beans.container.DatasetStructures;
import io.sdmx.im.constraint.ConstraintPrefixCleaned;

public class ConstraintPrefixDetailRetreivalManager implements IConstraintPrefixDetailRetreivalManager {
	private ConstraintRetrievalManager constraintRetrievalManager;
	private SdmxSuperBeanRetrievalManager sdmxSuperBeanRetrievalManager;
	private SdmxBeanRetrievalManager beanRetreivalManager;
	
	public ConstraintPrefixDetailRetreivalManager(ConstraintRetrievalManager constraintRetrievalManager, SdmxSuperBeanRetrievalManager sdmxSuperBeanRetrievalManager, SdmxBeanRetrievalManager beanRetreivalManager) {
		this.constraintRetrievalManager = constraintRetrievalManager;
		this.sdmxSuperBeanRetrievalManager = sdmxSuperBeanRetrievalManager;
		this.beanRetreivalManager = beanRetreivalManager;
	}

	@Override
	public Map<String, String> getRemovePrefixDetails(IURNSingle<? extends ConstrainableBean> ref) {
		return getRemovePrefixDetails(new DatasetStructures(ref, beanRetreivalManager));
	}

	@Override
	public Map<String, String> getRemovePrefixDetails(ConstrainableBean maint) {
		return getRemovePrefixDetails(new DatasetStructures(maint, beanRetreivalManager));
	}
	
	private Map<String, String> getRemovePrefixDetails(IDatasetStructures structures) {
		DataStructureSuperBean dsdSb = sdmxSuperBeanRetrievalManager.getDataStructureSuperBean(structures.getDataStructure().getURN());
		ConstrainableBean constraintable = structures.getConstrainable();
		Set<ContentConstraintBean> constraints= constraintRetrievalManager.getAllConstraintsDefiningAllowedData(constraintable);
		
		Map<String, String> returnMap = null;
		for(ContentConstraintBean constraint : constraints) {
			ConstraintPrefixCleaned cleanConstraint = new ConstraintPrefixCleaned(constraint, dsdSb);
			if(cleanConstraint.getRemovePrefixes() != null) {
				if(returnMap == null) {
					returnMap = new HashMap<>(cleanConstraint.getRemovePrefixes().size());
				}
				for(String key : cleanConstraint.getRemovePrefixes().keySet()) {
					returnMap.put(key, cleanConstraint.getRemovePrefixes().get(key));
				}
			}
		}
		return returnMap;
	}
}
