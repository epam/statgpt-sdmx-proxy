package io.sdmx.core.structure.api.manager;

import java.util.Date;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;

/**
 * The DataConstraintRetrievalManager manages the retrieval of data constraints for a given constrainable artefact
 */
public interface DataConstraintRetrievalManager {

	/**
	 * Returns true if there are constraints available for this constrainable bean
     *
	 * @param constrainable
	 * @return
	 */
	boolean hasConstraint(ConstrainableBean constrainable);
	
	/**
	 * The cube region takes into account whether data exists for a concept/code combination based 
	 * on the selected codes in the data query, the constraint codes are determined from what has been attached to the 
	 * constrainable artifact if it is given, if the constrainable artifact is null, then the key family from the data query
	 * will be used as the constrainable artifact.
	 * <p/>
	 * A set of valid keys is returned based on the data query passed in, which contains concept/code selections,
	 * in this way the result is 'what is still a valid selection based on the selections that have already been made'
	 *  
	 * @param dataQuery
	 * @return
	 */
	Set<KeyValue> filterKeysUsingCubeRegion(DataQuery dataQuery);
	
	/**
	 * Returns all the valid key values for this constrainable bean
	 * @param constrainable
	 * @return
	 */
	Set<KeyValue> getAllValidKeyValues(ConstrainableBean constrainable);
	
	/**
	 * Returns the start date for the constrainable bean
	 * @param constrainable
	 * @return
	 */
	Date getDataStartDate(ConstrainableBean constrainable);
	
	/**
	 * Returns the end date for the constrainable bean
	 * @param constrainable
	 * @return
	 */
	Date getDataEndDate(ConstrainableBean constrainable); 
	
}
