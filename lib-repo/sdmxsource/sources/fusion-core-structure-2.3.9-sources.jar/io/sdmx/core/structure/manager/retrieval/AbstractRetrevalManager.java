package io.sdmx.core.structure.manager.retrieval;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;

public abstract class AbstractRetrevalManager {
	protected SdmxBeanRetrievalManager sdmxBeanRetrievalManager;

	public AbstractRetrevalManager(SdmxBeanRetrievalManager sdmxBeanRetrievalManager) {
		if(sdmxBeanRetrievalManager == null) {
			throw new IllegalArgumentException("SdmxBeanRetrievalManager can not be null");
		}
		this.sdmxBeanRetrievalManager = sdmxBeanRetrievalManager;
	}	
}
