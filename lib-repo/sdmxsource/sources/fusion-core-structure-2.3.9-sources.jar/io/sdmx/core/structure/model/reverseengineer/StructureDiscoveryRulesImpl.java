package io.sdmx.core.structure.model.reverseengineer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.reverseengineer.ColumnDefinition;
import io.sdmx.api.sdmx.model.reverseengineer.StructureDiscoveryRules;
import io.sdmx.utils.core.object.ObjectUtil;

public class StructureDiscoveryRulesImpl implements StructureDiscoveryRules {
	private String agencyId;
	private String conceptSchemeId;
	private String dataStructureId;
	private String dataStructureName;
	private List<ColumnDefinition> columnDefinitions = new ArrayList<>();
	
	/**
	 * Built from JSON
	 * {
	 * 	 "AgencyId" : "AcyId",
	 *   "ConceptScheme?" : "CsID"
	 *   "DataStructureId" : ""
	 *   "DataStructureName" : ""
	 *   "Columns" : [
	 *   	{
	 *       ...
	 *      }
	 *   ]
	 *   ...other
	 * }
	 * 
	 */
	public StructureDiscoveryRulesImpl(Map jsonMap) {
		this.agencyId = (String)jsonMap.get("AgencyId");
		this.conceptSchemeId = (String)jsonMap.get("ConceptScheme");
		if(conceptSchemeId == null) {
			conceptSchemeId = agencyId +"_CONCEPTS";
		}
		this.dataStructureId = (String)jsonMap.get("DataStructureId");
		this.dataStructureName = (String)jsonMap.get("DataStructureName");
		if(!ObjectUtil.validString(dataStructureName)) {
			this.dataStructureName = dataStructureId;
		}
		List<Map> columns = (List<Map>)jsonMap.get("Columns");
		for(Map column : columns) {
			Object codelist = column.get("Codelist");
			if (codelist != null) {
				this.columnDefinitions.add(new CodedDimensionColumnDefinitionImpl(this, column));
			} else {
				this.columnDefinitions.add(new UnCodedColumnDefinitionImpl(column));
			}
		}
		validate();
	}

	private void validate() {
		this.columnDefinitions = Collections.unmodifiableList(this.columnDefinitions);
	}

	@Override
	public String getAgencyId() {
		return agencyId;
	}

	@Override
	public String getConceptSchemeId() {
		return conceptSchemeId;
	}

	@Override
	public String getDataStructureId() {
		return dataStructureId;
	}

	@Override
	public String getDataStructureName() {
		return dataStructureName;
	}

	@Override
	public List<? extends ColumnDefinition> getColumnDefinitions() {
		return columnDefinitions;
	}
}
