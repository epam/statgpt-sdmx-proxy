package io.sdmx.core.structure.manager.retrieval;

import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.api.sdmx.model.query.StructureQueryMetadata;
import io.sdmx.core.structure.api.manager.ProvisionBeanRetrievalManager;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.im.beans.reference.StructureQueryMetadataImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class ProvisionRetrievalFromRestRetrieval implements ProvisionBeanRetrievalManager {
    private ISdmxBeanRestRetrievalManager restRetrievalManager;
    private static final RESTStructureQuery allProvQuery = new RESTStructureQueryImpl(URN.build(ProvisionAgreementBean.class));
    private static final StructureQueryMetadata parents = new StructureQueryMetadataImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.PARENTS, null);
    private static final StructureQueryMetadata ancestors = new StructureQueryMetadataImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.ANCESTORS, null);
    
    public ProvisionRetrievalFromRestRetrieval(ISdmxBeanRestRetrievalManager restRetrievalManager) {
        this.restRetrievalManager = restRetrievalManager;
    }
    
    @Override
    public Set<ProvisionAgreementBean> getProvisions() {
        return executeRestQuery(allProvQuery);
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisions(IURNSingle<? extends ConstrainableBean> structureRef) {
        StructureQueryMetadata queryMetadata = parents;
        if(structureRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.DSD) {
            queryMetadata = ancestors;
        }
        return executeRestQuery(new RESTStructureQueryImpl(structureRef, queryMetadata));
    }

    @Override
    public ProvisionAgreementBean getProvisionByProvision(IURNSingle<ProvisionAgreementBean> provisionUrn) {
        Set<ProvisionAgreementBean> provisions = executeRestQuery(new RESTStructureQueryImpl(provisionUrn));
        if(provisions.isEmpty()) {
            return null;
        }
        if(provisions.size() > 1) {
            throw new SdmxException("Unexpected response size, expected 0 or 1, got "+provisions.size());
        }
        return (ProvisionAgreementBean) provisions.toArray()[0];
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByDataflow(IURNSingle<DataflowBean> dataflow) {
        return executeRestQuery(new RESTStructureQueryImpl(dataflow, parents));
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByProvider(IURNSingle<DataProviderBean> provider) {
        return executeRestQuery(new RESTStructureQueryImpl(provider, parents));
    }
    
    private Set<ProvisionAgreementBean> executeRestQuery(RESTStructureQuery query) {
        return restRetrievalManager.getMaintainables(query).getProvisionAgreements();
    }

    @Override
    public Set<ProvisionAgreementBean> getProvisionsByDataStructure(IURNSingle<DataStructureBean> dsdUrn) {
        return executeRestQuery(new RESTStructureQueryImpl(dsdUrn, ancestors));
    }

}
