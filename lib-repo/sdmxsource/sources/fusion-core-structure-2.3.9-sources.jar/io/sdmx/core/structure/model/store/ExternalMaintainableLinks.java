package io.sdmx.core.structure.model.store;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.sdmx.comparator.LinkComparator;

public class ExternalMaintainableLinks implements IExternalMaintainableLinks {
	private IURNMaintainable<?> maintUrn;
	private Map<IURNAbsolute<?>, Set<ILinkBean>> links;

	public ExternalMaintainableLinks(IURNMaintainable<?> maintUrn, Map<IURNAbsolute<?>, Set<ILinkBean>> urn2Links) {
		this.links = new HashMap<>(urn2Links.size());
		//Copy map to make immutable
		for(IURNAbsolute<?> urn : urn2Links.keySet()) {
			Set<ILinkBean> links = new TreeSet<>(LinkComparator.INSTANCE);
			links.addAll(urn2Links.get(urn));
			this.links.put(urn, Collections.unmodifiableSet(links));
		}
		this.maintUrn = maintUrn;
		this.links =  Collections.unmodifiableMap(links);
	}

	@Override
	public IURNMaintainable<?> getMaintainableURN() {
		return maintUrn;
	}

	@Override
	public Set<IURNAbsolute<?>> getLinkedIdentifiable() {
		return links.keySet();
	}

	@Override
	public Set<ILinkBean> getLinks(IURNAbsolute<?> identifableUrn) {
		 Set<ILinkBean> returnSet = links.get(identifableUrn);
		 if(returnSet == null) {
			 returnSet = Collections.emptySet();
		 }
		 return returnSet;
	}
}
