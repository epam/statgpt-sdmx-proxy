
package io.sdmx.core.structure.api.manager;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.MutableCrossReferencingTree;

/**
 * The CrossReferenceRetrievalMutableManager is used to retrieve mutable structures that cross reference or are cross referenced by the 
 * given structures.
*/
public interface CrossReferenceMutableRetrievalManager {
	
	/**
	 * Returns a tree structure representing the identifiable and all the structures that cross reference it, and the structures that reference them, and so on.
	 * @return
	 */
	MutableCrossReferencingTree getCrossReferenceTree(MaintainableMutableBean maintainableBean);
	
	/**
	 * Returns a list of MaintainableBean that cross reference the structure(s) that match the reference parameter
	 * @param structureReference Who References Me?
	 * @param returnStub if true, then will return the stubs that reference the structure
	 * @param structures an optional parameter to further filter the list by structure type
	 * @return
	 */
	List<MaintainableMutableBean> getCrossReferencingStructures(StructureReferenceBean structureReference, boolean returnStub,  SDMX_STRUCTURE_TYPE...structures);
	
	/**
	 * Returns a list of MaintainableBean that cross reference the given identifiable structure
	 * @param identifiable the identifiable bean to retrieve the references for - Who References Me?
	 * @param returnStub if true, then will return the stubs that reference the structure
	 * @param structures an optional parameter to further filter the list by structure type
	 * @return
	 */
	List<MaintainableMutableBean> getCrossReferencingStructures(IdentifiableMutableBean identifiable,  boolean returnStub, SDMX_STRUCTURE_TYPE...structures);
	
	/**
	 * Returns a list of MaintainableBean that cross reference the structure(s) that match the reference parameter
	 * @param structureReference  - What Do I Reference?
	 * @param returnStub if true, then will return the stubs that reference the structure
	 * @param structures an optional parameter to further filter the list by structure type
	 * @return
	 */
	List<MaintainableMutableBean> getCrossReferencedStructures(StructureReferenceBean structureReference,  boolean returnStub, SDMX_STRUCTURE_TYPE...structures);
	
	/**
	 * Returns a list of MaintainableBean that are cross referenced by the given identifiable structure
	 * @param identifiable the identifiable bean to retrieve the references for - What Do I Reference?
	 * @param returnStub if true, then will return the stubs that reference the structure
	 * @param structures an optional parameter to further filter the list by structure type
	 * @return
	 */
	List<MaintainableMutableBean> getCrossReferencedStructures(IdentifiableMutableBean identifiable,  boolean returnStub, SDMX_STRUCTURE_TYPE...structures);

}
