
package io.sdmx.core.structure.api.manager;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;


/**
 * Provides methods for retrieving beans where version information is the key criteria
 */
public interface StructureVersionRetrievalManager {
	
	/**
	 * Returns the latest version of the maintainable for the given maintainable input
	 * @param maintainableBean
	 * @return
	 */
	MaintainableBean getLatest(MaintainableBean maintainableBean);
	

}
