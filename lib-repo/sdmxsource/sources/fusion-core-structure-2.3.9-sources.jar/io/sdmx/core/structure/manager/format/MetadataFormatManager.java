package io.sdmx.core.structure.manager.format;

import io.sdmx.api.format.IInformationFormatManager;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.core.sdmx.api.manager.metadata.IMetadataFormatManager;
import io.sdmx.core.sdmx.manager.format.AbstractFormatManager;

public class MetadataFormatManager  extends AbstractFormatManager<IMetadataFormat> implements IMetadataFormatManager {

	public MetadataFormatManager(IInformationFormatManager informationFormatManager) {
		super(informationFormatManager, IMetadataFormat.class);
	}

}
