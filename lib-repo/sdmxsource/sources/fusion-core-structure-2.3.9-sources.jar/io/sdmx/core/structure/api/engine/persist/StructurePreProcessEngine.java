package io.sdmx.core.structure.api.engine.persist;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * Allows the SdmxBeans to be mutated or changed BEFORE OR AFTER validation on a save message
 *
 */
public interface StructurePreProcessEngine {
	/**
	 * Called before Validation on the save message
	 * @param isPreValidation - true if the structures have not yet been validated, false if not
	 * @param SdmxBeans
	 */
	void preProcess(SdmxBeans beans, boolean isPreValidation);
}
