package io.sdmx.core.structure.api.engine.merge;

import java.util.Set;

import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;

public interface IHierarchyMergeEngine {

	/**
	 * Merge the hierarchies into the Codelist, to return a single Codelist with the original Codelist codes present, as well
	 * as the Codes from the Hierarchy that were not in the original Codelist
	 * @param codelist
	 * @param hierarchies
	 * @param brm
	 * @return
	 */
	CodelistBean merge(CodelistBean codelist, Set<HierarchyBean> hierarchies, SdmxBeanRetrievalManager brm);
	
}
