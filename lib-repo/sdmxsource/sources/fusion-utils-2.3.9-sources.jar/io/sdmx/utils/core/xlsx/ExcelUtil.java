package io.sdmx.utils.core.xlsx;

public class ExcelUtil {
	private static final String[] alphabet = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

	
	/**
	 * Changes a column and row index (zero indexed) to a cell reference.
	 * 
	 * 0,0 = A1
	 * 0,1 = A2
	 * 1,1 = B2
	 * 
	 * @param coll
	 * @param row
	 * @return
	 */
	public static String toCellReference(int col, int row) {		
		int dividend = col+1;
		StringBuilder sb = new StringBuilder();
	    int modulo;

	    while (dividend > 0)
	    {
	        modulo = (dividend - 1) % 26;
	        sb.append(alphabet[modulo]);
	        dividend = (int)((dividend - modulo) / 26);
	    } 

		return sb.reverse().toString()+(row+1);
	}
}
