package io.sdmx.utils.core.io;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.io.IObjectSerialiser;
import io.sdmx.api.io.IObjectSerialiserRetrievalManager;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ObjectSerialiserRetrievalManager implements IObjectSerialiserRetrievalManager {

	private Map<String, IObjectSerialiser<?>> serialisers = null;
	
	@Override
	public IObjectSerialiser<?> getSerialiser(String id) {
		return getSerialisers().get(id);
	}

	private Map<String, IObjectSerialiser<?>> getSerialisers() {
		if(this.serialisers == null) {
			Collection<IObjectSerialiser> serialisers = FusionBeanStore.getBeans(IObjectSerialiser.class);
			Map<String, IObjectSerialiser<?>> serialiserMap = serialisers.stream().collect(Collectors.toMap(e->e.getId(), e->e));
			this.serialisers = Collections.unmodifiableMap(serialiserMap);
		}
		return serialisers;
	}

	
}
