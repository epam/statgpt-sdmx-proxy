package io.sdmx.utils.core.date;

import io.sdmx.api.date.PeriodContainer;
import io.sdmx.api.date.PeriodContents;
import io.sdmx.api.date.SdmxPeriod;

public class PeriodContainerImpl<T> implements PeriodContainer<T> {
	private SdmxPeriod sdmxPeriod;
	private PeriodContents<T> periodContents;
	
	public PeriodContainerImpl(SdmxPeriod sdmxPeriod, PeriodContents<T> periodContents) {
		this.sdmxPeriod = sdmxPeriod;
		this.periodContents = periodContents;
	}

	@Override
	public SdmxPeriod getSdmxPeriod() {
		return sdmxPeriod;
	}

	@Override
	public PeriodContainer<T> copy(SdmxPeriod period) {
		return new PeriodContainerImpl<>(period, periodContents.copy());
	}

	@Override
	public PeriodContents<T> getPeriodContents() {
		return periodContents;
	}

	@Override
	public T getContents() {
		return periodContents.getContents();
	}
}
