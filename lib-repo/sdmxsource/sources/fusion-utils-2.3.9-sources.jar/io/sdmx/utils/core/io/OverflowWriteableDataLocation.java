package io.sdmx.utils.core.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.nio.file.Path;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.RemovalCause;
import com.google.common.io.Files;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.utils.core.file.FormatUtil;

public class OverflowWriteableDataLocation extends AbstractReadableDataLocation implements WriteableDataLocation {
    private static final Logger LOG = LoggerFactory.getLogger(OverflowWriteableDataLocation.class);
    
    private static final long serialVersionUID = 2278635606454143014L;
    private static long maxMemory = 1024l * 1024l * 30;  //DEFALUT TO 30Mb
    private static long currentMemory = 0l;

    private URI tmpUri;
    private OutputStream uriOut;

    private Buffer inMemoryBuffer = new Buffer();
    private String name;
    
    private UUID uuid = UUID.randomUUID();
    
    /**
     * Clean up an resources that are unclosed for 1 day
     */
    private static final Cache<UUID, OverflowWriteableDataLocation> cache = Caffeine.newBuilder()
            .expireAfterAccess(1, TimeUnit.DAYS)
            .removalListener((UUID key, OverflowWriteableDataLocation value, RemovalCause cause) -> {
                if(value != null) {
                    String name = value.getName() == null ? value.uuid.toString() : value.getName();
                    if(cause != RemovalCause.EXPLICIT) {
                        LOG.warn("Force close due to '"+cause+"' on OverflowWriteableDataLocation: "+name);
                    }
                    value.isProtected = false;
                    value.close();
                }
            })
            .build();
    
    /**
     * Force close of all unclosed OverflowWriteableDataLocation
     * @return
     */
    public static long forceClose() {
        long count = cache.estimatedSize();
        cache.invalidateAll();
        return count;
    }
    
    public OverflowWriteableDataLocation() {
        this((String)null);
    }

    public OverflowWriteableDataLocation(FILE_FORMAT fileFormat) {
        this((String)null);
        this.format = fileFormat;
    }

    public OverflowWriteableDataLocation(String name) {
        if(currentMemory > maxMemory) {
            tmpUri = URIUtil.getTemporaryURI();
            uriOut = URIUtil.getOutputStream(tmpUri);
            inMemoryBuffer.isOverflow = true;
        }
        this.name = name;
        register();
    }

    private OverflowWriteableDataLocation(String name, URI tmpUri) {
        this.name = name;
        this.tmpUri = tmpUri;
        if(tmpUri != null) {
            uriOut = URIUtil.getOutputStream(tmpUri);
            inMemoryBuffer.isOverflow = true;
        }
        register();
    }

    @Override
    public String getName() {
        return name;
    }

    public boolean isOverflow() {
        return this.inMemoryBuffer.isOverflow;
    }
    
    @Override
    protected long calculateSize() {
        if(inMemoryBuffer.isOverflow) {
            return URIUtil.getFile(tmpUri).length();
        }
        return inMemoryBuffer.size();
    }

    @Override
    public ReadableDataLocation move(Path moveTo) {
        if(inMemoryBuffer.isOverflow) {
            File f = URIUtil.getFile(tmpUri);
            try {
                Files.move(f, moveTo.toFile());
                return completeMove(moveTo);
            } catch (IOException e) {
                return super.move(moveTo);
            }

        }
        return super.move(moveTo);
    }

    @Override
    public FILE_FORMAT getFormat() {
        if(format == null) {
            format = FormatUtil.determineFileFormat(this);
        }
        return format;
    }

    
    private void register() {
        cache.put(this.uuid, this);
    }

    private class Buffer extends ByteArrayOutputStream {
        private boolean isOverflow;
        @Override
        public synchronized void write(byte[] b, int off, int len) {
            if(isOverflow) {
                try {
                    uriOut.write(b, off, len);
                } catch (IOException e) {
                    throw new SdmxException(e, "IO Exception whilst trying to write to file output stream: " + tmpUri);
                }
            } else {
                super.write(b, off, len);
                checkOverflow(len);
            }
        }

        public int getCount() {
            return count;
        }

        @Override
        public void write(int b) {
            if(isOverflow) {
                try {
                    uriOut.write(b);
                } catch (IOException e) {
                    throw new SdmxException(e, "IO Exception whilst trying to write to file output stream: " + tmpUri);
                }
            } else {
                super.write(b);
                checkOverflow(1);
            }
        }

        private void checkOverflow(int increment) {
            currentMemory += increment;
            if(currentMemory >= maxMemory) {
                isOverflow = true;
                //Copy over data to file
                if(tmpUri == null) {
                    //Create an output file
                    tmpUri = URIUtil.getTemporaryURI();
                    uriOut = URIUtil.getOutputStream(tmpUri);
                }
                try {
                    this.writeTo(uriOut);
                } catch (IOException e) {
                    throw new SdmxException(e, "IO Exception whilst trying to overflow from in-memory outputstream to file output stream:" + tmpUri);
                }
                currentMemory -= super.count;
                super.buf =  new byte[100];
                super.count = 0;
            }
        }

        @Override
        public void flush() throws IOException {
            if(uriOut != null) {
                uriOut.flush();
            }
        }
    }

    @Override
    protected void closeInternal() {
        closeInternal(true);
    }
    
    private void closeInternal(boolean invalidate) {
        if(invalidate) {
            cache.invalidate(uuid);
        }
        if(uriOut != null) {
            URIUtil.closeUri(tmpUri);
            URIUtil.deleteUri(tmpUri);
        } else if(inMemoryBuffer != null){
            currentMemory -= inMemoryBuffer.getCount();
            inMemoryBuffer = null;
        }
    }

    @Override
    protected InputStream getStreamInternal() throws IOException {
        if(uriOut == null) {
            if(inMemoryBuffer == null) {
                return null;
            }
            return new ByteArrayInputStream(inMemoryBuffer.toByteArray());
        }
        try {
            uriOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return URIUtil.getInputStream(tmpUri);
    }

    @Override
    public OutputStream getOutputStream() {
        return inMemoryBuffer;
    }

    @Override
    public String toString() {
        if(tmpUri == null) {
            return new String(inMemoryBuffer.toByteArray());
        }
        return "OverflowWriteableDataLocation: " + tmpUri.toString();
    }

    /**
     * Sets the maximum amount of data to store in memory, in kb
     * @param maxMemory
     */
    public static void setMaxMemoryKb(long maxMemory) {
        OverflowWriteableDataLocation.maxMemory = maxMemory * 1024l;
    }

    /**
     * Returns the current memory usage
     * @return
     */
    public static long getCurrentMemory() {
        return currentMemory;
    }

    public static long getMaxMemory() {
        return maxMemory;
    }

    @Override
    public OverflowWriteableDataLocation copy() {
        if (this.tmpUri != null) {
            // Copy the contents of the URI since the close method deletes the original URI on close.
            URI uriCopy = URIUtil.getTemporaryURI();
            try {
                uriOut.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            URIUtil.copyURIs(this.tmpUri, uriCopy);
            return new OverflowWriteableDataLocation(name, uriCopy);
        } else {
            OverflowWriteableDataLocation newOverflow = new OverflowWriteableDataLocation(name);
            StreamUtil.copyStream(getInputStream(), newOverflow.getOutputStream());
            return newOverflow;
        }
    }
}