package io.sdmx.utils.core.comparator;

import java.util.Comparator;
import java.util.List;

public class StringListComparator implements Comparator<List<String>> {
	public static final StringListComparator INSTANCE = new StringListComparator();
	
	private StringListComparator() { }
	
	@Override
	public int compare(List<String> aSource, List<String> bSource) {
		
		if(aSource.size() > bSource.size()) {
			return 1;
		}
		if(bSource.size() > aSource.size()) {
			return -1;
		}
		for(int i=0; i < aSource.size(); i++) {
			String a = aSource.get(i);
			String b = bSource.get(i);
			int r = a.compareTo(b);
			if(r != 0) {
				return r;
			}
		}
		return 0;
	}

	
	
}
