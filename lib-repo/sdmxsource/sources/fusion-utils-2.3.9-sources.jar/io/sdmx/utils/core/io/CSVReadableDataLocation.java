package io.sdmx.utils.core.io;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * a proxy on an underlying RDL which fixes the format to CSV and adds a delimiter
 */
public class CSVReadableDataLocation extends ProxyReadableDataLocation {
	private static final long serialVersionUID = 1L;
	private DELIMITER delimiter;
	private int startRow;
	
	public CSVReadableDataLocation(ReadableDataLocation proxy, DELIMITER delimiter, int startRow) {
		super(proxy);
		this.delimiter = delimiter;
		this.startRow = startRow;
	}

	@Override
	public FILE_FORMAT getFormat() {
		return FILE_FORMAT.CSV;
	}
	
	public DELIMITER getDelimiter() {
		return delimiter;
	}

	public int getStartRow() {
		return startRow;
	}

	@Override
	public ReadableDataLocation copy() {
		return new CSVReadableDataLocation(super.copy(), delimiter, startRow);
	}

	@Override
	public boolean splitable() {
		return false;
	}

	@Override
	public List<ReadableDataLocation> split(boolean closeSource) {
		return CollectionUtil.getImmutableList(this);
	}
}
