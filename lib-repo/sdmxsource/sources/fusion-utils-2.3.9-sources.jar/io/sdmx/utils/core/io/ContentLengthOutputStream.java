package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Keeps a record of content length
 */
public class ContentLengthOutputStream extends ProxyOutputStream {
	private long bytesWritten = 0;
	
	/**
	 * Output stream does not write anything to the output
	 */
	public ContentLengthOutputStream() {
		super(DummyOutputStream.INSTANCE);
	}
	
	public ContentLengthOutputStream(OutputStream proxy) {
		super(proxy);
	}

	@Override
    public void write(int b) throws IOException {
		if(isClosed()) {
			return;
		}
    	
		super.write(b);
        bytesWritten++;
    }

    @Override
    public void write(byte[] b) throws IOException {
    	if(isClosed()) {
    		return;
    	}
    	
    	super.write(b);
    	bytesWritten += b.length;
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
    	if(isClosed()) {
    		return;
    	}
    	
    	super.write(b, off, len);
    	long length = b.length-off;
    	
    	long lMax = Math.min(length, len);  
    	bytesWritten += lMax;
    }
    
    /**
     * @return count of the bytes written
     */
    public long getBytesWritten() {
    	return this.bytesWritten;
    }

}
