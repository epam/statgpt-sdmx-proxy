package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.file.FormatUtil;
import io.sdmx.utils.core.file.MultipartUtil;
import io.sdmx.utils.core.file.ZipUtil;

public abstract class AbstractReadableDataLocation  implements ReadableDataLocation {
	private static final long serialVersionUID = 1L;
	protected boolean isClosed = false;
	protected boolean isProtected = false;
	protected boolean deleteOnClose = false;
	protected FILE_FORMAT format;
	private ReadableDataLocation proxy;
	private Set<InputStream> inputStreams = new HashSet<>();
	private long size = -1;

	/**
	 * @param proxy optional - if provided, the proxy state (closed, protected) is also managed by this RDL
	 */
	public AbstractReadableDataLocation(ReadableDataLocation proxy) {
		this.proxy = proxy;
		if(proxy != null) {
			this.isProtected = proxy.isProtected();
		}
	}

	public AbstractReadableDataLocation() {
	}


	@Override
	public FILE_FORMAT getFormat() {
		if(format == null) {
			format = FormatUtil.determineFileFormat(this);
		}
		return format;
	}

	protected ReadableDataLocation getProxy() {
		return proxy;
	}

	public void setProxy(ReadableDataLocation proxy) {
		this.proxy = proxy;
	}
	
	@Override
    public ReadableDataLocation move(Path moveTo) {
        StreamUtil.copyStream(getInputStream(), PathUtil.getOutputStream(moveTo, false), true);
        return completeMove(moveTo);
    }
	
	protected ReadableDataLocation completeMove(Path moveTo) {
	    close();
        return new ReadableDataLocationTmp(moveTo);
	}
   

    @Override
    public long getSize() {
        if(size < 0) {
            size = calculateSize();
        }
        return size;
    }
    
    protected abstract long calculateSize();


    @Override
	public InputStream getInputStream() {
		if (isClosed) {
			throw new RuntimeException("Can not obtain InputStream ReadableDataLocation has been closed.");
		}
		InputStream is;
		try {
			is = getStreamInternal();
			inputStreams.add(is);
			return is;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void close() {
		if(isClosed || isProtected) {
			return;
		}
		isClosed = true;
		if(proxy != null) {
			proxy.close();
		}
		closeStreams();
		closeInternal();
	}

	
	protected void closeStreams() {
	    for(InputStream is : inputStreams) {
            StreamUtil.closeStream(is);
        }
	}

	@Override
	public boolean isClosed() {
		return isClosed;
	}

	@Override
	public boolean isProtected() {
		return isProtected;
	}

	@Override
	public void setProtected(boolean protect) {
		isProtected = protect;
		if(proxy != null) {
			proxy.setProtected(protect);
		}
	}

	@Override
	public boolean splitable() {
		return getFormat() == FILE_FORMAT.ZIP || getFormat() == FILE_FORMAT.MULTIPART;
	}

	@Override
	public List<ReadableDataLocation> split(boolean closeSource) {
		List<ReadableDataLocation> returnList = new ArrayList<>();
		switch(getFormat()) {
		case ZIP :
			returnList = ZipUtil.unzipFiles(this);
			break;
		case MULTIPART :
			returnList = MultipartUtil.splitFiles(this, closeSource);
			break;
			default :
				returnList.add(this);
				closeSource = false;
		}
		if(closeSource) {
			this.close();  //Close the Zip/Multipart files
		}
		return returnList;
	}

	protected abstract void closeInternal();
	protected abstract InputStream getStreamInternal() throws IOException;
}
