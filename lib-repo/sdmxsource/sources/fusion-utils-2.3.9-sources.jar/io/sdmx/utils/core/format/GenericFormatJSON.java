package io.sdmx.utils.core.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IGenericInformationFormat;
import io.sdmx.api.http.MIME_TYPE;

public class GenericFormatJSON implements IGenericInformationFormat {
	private static final long serialVersionUID = 1L;
	private static final GenericFormatJSON INSTANCE = new GenericFormatJSON();
	private static final FormatDetails DETAILS = new FormatDetailsImpl("json", MIME_TYPE.APPLICATION_JSON, true, MIME_TYPE.APPLICATION_JSON.getMimeType());
			
	public static GenericFormatJSON getInstance() {
		return INSTANCE;
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		return DETAILS;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this == getInstance();
	}

	@Override
	public String toString() {
		return "JSON";
	}
}
