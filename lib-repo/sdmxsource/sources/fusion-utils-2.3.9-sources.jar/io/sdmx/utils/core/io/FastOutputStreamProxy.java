package io.sdmx.utils.core.io; 

import java.io.IOException;
import java.io.OutputStream;

import it.unimi.dsi.fastutil.io.FastBufferedOutputStream;

public abstract class FastOutputStreamProxy extends OutputStream {
	private FastBufferedOutputStream fastOutputStream;
	protected OutputStream finalOut;
	private boolean isClosed;
	
	public FastOutputStreamProxy(OutputStream finalOut, int lastn) {
		this.finalOut = finalOut;
		int bufferSize = 1024;
		fastOutputStream = new FastBufferedOutputStream(new FastOutBuffer(), bufferSize);
	}
	
	@Override
	public void write(int b) throws IOException {
		fastOutputStream.write(b);
	}

	@Override
	public void write(byte[] b) throws IOException {
		fastOutputStream.write(b);
	}
	
	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		fastOutputStream.write(b, off, len);
	}
	
	@Override
	public void flush() throws IOException {
		fastOutputStream.flush();
	}

	@Override
	public void close() throws IOException {
		if(isClosed) {
			return;
		}
		isClosed = true;
		fastOutputStream.close();
		finalOut.close();
	}

	private class FastOutBuffer extends OutputStream {
		@Override
		public void write(byte[] b) throws IOException {}
		@Override
		public void write(byte[] b, int off, int len) throws IOException {
			if(bufferFlush(b, off, len)) {
				finalOut.write(b, off, len);
			}
		}
		@Override
		public void write(int b) throws IOException {}
	}
	
	protected abstract boolean bufferFlush(byte[] b, int off, int len);
}
