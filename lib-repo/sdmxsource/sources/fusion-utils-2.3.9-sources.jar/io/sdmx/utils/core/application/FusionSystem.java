package io.sdmx.utils.core.application;

import io.sdmx.api.io.ReadableDataLocationFactory;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.utils.core.io.SdmxSourceReadableDataLocationFactory;
import io.sdmx.utils.core.io.SdmxSourceWriteableDataLocationFactory;
import io.sdmx.utils.core.resource.MessageDecoder;

/**
 * Holds a critical parts of any Fusion Application, defaults provided which can be overridden via setters
 */
public class FusionSystem {
	public static final FusionSystem INSTANCE = new FusionSystem();
	private static ReadableDataLocationFactory rdlFactory = new SdmxSourceReadableDataLocationFactory();
	private static WriteableDataLocationFactory wdlFactory = new SdmxSourceWriteableDataLocationFactory();
//	private FusionProductInformationRetrievalManager productInformationRetrievalManager;
	private static MessageDecoder messageDecoder;
	
	public static void register() {
		SingletonStore.registerInstance(getWdlFactory());
		SingletonStore.registerInstance(getRdlFactory());
	}
	
	private FusionSystem() {
		FusionSystem.messageDecoder = new MessageDecoder();
	}
	
	public static ReadableDataLocationFactory getRdlFactory() {
		if(FusionSystem.rdlFactory == null) {
			FusionSystem.rdlFactory = new SdmxSourceReadableDataLocationFactory();
		}
		return FusionSystem.rdlFactory;
	}
	public static WriteableDataLocationFactory getWdlFactory() {
		if(FusionSystem.wdlFactory == null) {
			FusionSystem.wdlFactory = new SdmxSourceWriteableDataLocationFactory();
		}
		return FusionSystem.wdlFactory;
	}

	public static void setRdlFactory(ReadableDataLocationFactory rdlFactory) {
		FusionSystem.rdlFactory = rdlFactory;
	}

	public static void setWdlFactory(WriteableDataLocationFactory wdlFactory) {
		FusionSystem.wdlFactory = wdlFactory;
	}
}
