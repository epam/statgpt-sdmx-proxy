package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;

public class StreamUtil {
    private static final Logger LOG = LoggerFactory.getLogger(StreamUtil.class);

    /**
     * Adds the missing BOM character required for UTF-8
     * FR-3573 Data REST API csv not interpreted as UTF-8 without BOM characters
     *
     * @param out
     * @return
     */
    public static PrintWriter getPrintWriterUTF8(OutputStream out) {
        return getPrintWriterUTF8(out, true);
    }

    public static PrintWriter getPrintWriterUTF8(OutputStream out, boolean outputBOM) {
        PrintWriter pwOut = new PrintWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), true);
        if (outputBOM) {
            pwOut.write('\ufeff');
        }
        return pwOut;
    }


    /**
     * Returns the byte[] as a Stream
     * @param bytesList
     * @return
     */
    public static InputStream asStream(List<byte[]> bytesList) {
        return new ByteArrayInputStream(joinBytes(bytesList));
    }

    /**
     * Returns the byte[] as a Stream
     * @param bytesList
     * @return
     */
    public static byte[] joinBytes(List<byte[]> bytesList) {
        int length = 0;
        for(byte[] currentArray : bytesList) {
            length += currentArray.length;
        }
        byte[] merged = new byte[length];
        length = 0;
        for(byte[] currentArray : bytesList) {
            System.arraycopy(currentArray, 0, merged, length, currentArray.length);
            length += currentArray.length;
        }
        return merged;
    }

    /**
     * Splits the input byte[] into a List of byte[] of length chunkLength
     * @param list
     * @param bytes
     * @param chunkLength
     * @param offset
     */
    public static void splitBytes(List<byte[]> list, byte[] bytes, int chunkLength, int offset) {
        int lengthTocopy;
        while(bytes.length - offset > chunkLength) {
            if((bytes.length - offset) > chunkLength) {
                lengthTocopy = chunkLength;
            } else {
                lengthTocopy = bytes.length - offset;
            }
            byte[] dest = new byte[lengthTocopy];
            System.arraycopy(bytes, offset, dest, 0, lengthTocopy);
            list.add(dest);
            offset = offset + lengthTocopy;
        }
        lengthTocopy = bytes.length - offset;
        if(lengthTocopy > 0) {
            byte[] dest = new byte[lengthTocopy];
            System.arraycopy(bytes, offset, dest, 0, lengthTocopy);
            list.add(dest);
        }
    }

    //HACK - THIS IS FOR INPUT STREAMS THAT ARE NOT UTF*, BUT IF THE STREAM IS UTF- THIS METHOD BREAKS THE ENCODING
    //BY CONVERTING AN INT TO A CHAR
    private static void copyNonUTF8InputStream(InputStream is, OutputStream os) {
        try (BufferedInputStream bis = new BufferedInputStream(is);
                Writer bos = new OutputStreamWriter(new BufferedOutputStream(os), "UTF-8") ){

            byte[] bytes = new byte[1024];
            int i;
            while((i = bis.read(bytes)) > 0) {
                bos.write(new String(bytes, 0, i));
            }
            bos.flush();
        } catch(Throwable th) {
            throw new RuntimeException(th);
        }
    }

    /**
     * Copies the first 'x' number of lines to a list, each list element represents a line.
     * @param stream
     * @param numLines
     * @return
     */
    public static List<String> copyFirstXLines(InputStream stream, int numLines) {
        ArrayList<String> firstXRows = new ArrayList<>();
        if (stream == null) {
            return firstXRows;
        }
        int rowCount = 0;
        boolean lastCharWasEndOfLine = false;

        StringBuffer buff = new StringBuffer();
        byte[] bytes = new byte[1024];
        int i;
        boolean keepProcessing = true;
        try {
            while((i = stream.read(bytes)) > 0 && keepProcessing) {
                for (int j=0; j < i; j++) {
                    byte aByte = bytes[j];
                    if (aByte == 0x0A || aByte == 0x0D) {
                        if (!lastCharWasEndOfLine) {
                            lastCharWasEndOfLine = true;
                            rowCount++;
                            firstXRows.add(buff.toString());
                            buff = new StringBuffer();
                        }
                    } else {
                        lastCharWasEndOfLine = false;
                        buff.append((char)aByte);
                    }

                    if (rowCount==numLines) {
                        keepProcessing = false;
                        break;
                    }
                }
            }
            if(rowCount < numLines) {
                firstXRows.add(buff.toString());
            }
        } catch(Throwable th) {
            throw new RuntimeException(th);
        }
        return firstXRows;
    }

    public static byte[] readFirstXBytes(InputStream stream, int numberOfBytes) {
        byte[] b = new byte[numberOfBytes];
        try {
            int numberRead = stream.read(b);
            if(numberRead < numberOfBytes) {
                byte[] returnArray = new byte[numberRead];
                for(int i=0; i < numberRead; i++) {
                    returnArray[i] = b[i];
                }
                return returnArray;
            }
        } catch (NegativeArraySizeException e) {
            return new byte[0];  //no bytes
        }  catch (IOException e) {
            throw new RuntimeException("Error reading stream");
        }
        return b;
    }

    /**
     * Copies the supplied InputStream to the supplied OutputStream.
     * Converts the OutputStream to UTF-8.
     * The output stream is NOT closed on completion, uses a buffer of 1Kb
     * @param is the InputStream to copy.
     * @param os the OutputStream to write to.
     */
    public static int copyStream(InputStream is, OutputStream os) {
        return copyUTF8InputStream(is, os, false);
    }

    /**
     * Copies the supplied InputStream to the supplied OutputStream.
     * Converts the OutputStream to UTF-8.
     * The output stream is NOT closed on completion, uses a buffer of 1Kb
     * @param is the InputStream to copy.
     * @param os the OutputStream to write to.
     * @param closeOuptutStream whether to close the output stream or not
     */
    public static int copyStream(InputStream is, OutputStream os, boolean closeOuptutStream) {
        return copyUTF8InputStream(is, os, closeOuptutStream);
    }

    /**
     * @param is1
     * @param is2
     * @return true if both streams are equal
     */
    public static boolean equals(InputStream is1, InputStream is2) {
        BufferedInputStream bis1=null;
        BufferedInputStream bis2=null;
        if(is1 instanceof BufferedInputStream) {
            bis1 = (BufferedInputStream)is1;
        } else {
            bis1 = new BufferedInputStream(is1);
        }
        if(is2 instanceof BufferedInputStream) {
            bis2 = (BufferedInputStream)is2;
        } else {
            bis2 = new BufferedInputStream(is2);
        }
        byte[] bytes1 = new byte[1024];
        byte[] bytes2 = new byte[1024];
        int i;
        try {
            while((i = bis1.read(bytes1)) > 0) {
                int j = bis2.read(bytes2);
                if(i != j) {
                    return false;
                }
                for(int x =0; x < i; x++) {
                    if(bytes1[x] != bytes2[x]) {
                        return false;
                    }
                }
            }
            return bis2.read(bytes2) <= 0;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param is
     * @param os
     * @param closeOutputStream
     * @return number of bytes copied
     */
    private static int copyUTF8InputStream(InputStream is, OutputStream os, boolean closeOutputStream) {
        if(LOG.isTraceEnabled()) {
            LOG.trace("Copy Input Stream:" + is + " to output stream:" + os + ", close output stream on completion="+closeOutputStream);
        }
        BufferedOutputStream bos=null;
        BufferedInputStream bis=null;
        try {
            if(is instanceof BufferedInputStream) {
                bis = (BufferedInputStream)is;
            } else {
                bis = new BufferedInputStream(is);
            }
            if(os instanceof BufferedOutputStream) {
                bos = (BufferedOutputStream)os;
            } else {
                bos = new BufferedOutputStream(os);
            }

            byte[] bytes = new byte[1024];
            int i;
            int bytesRead = 0;
            while((i = bis.read(bytes)) > 0) {
                bytesRead+= i;
                bos.write(bytes, 0, i);
            }
            bos.flush();
            return bytesRead;
        } catch(Throwable th) {
            th.printStackTrace();
            throw new RuntimeException(th);
        } finally {
            StreamUtil.closeStream(bis);
            if(bos != null) {
                try {
                    bos.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(os != null) {
                try {
                    os.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(closeOutputStream) {
                StreamUtil.closeStream(bos);
            }
        }
    }

    /**
     * Copies a stream but does not copy the last n bytes, if n is less than 1024
     * @param is
     * @param os
     * @param ignoreEndBytesCount
     * @param closeOuptutStream
     */
    public static void copyUTF8InputStream(InputStream is, OutputStream os, int ignoreEndBytesCount, boolean closeOutputStream) {
        LOG.debug("Copy Input Stream:" + is + " to output stream:" + os + ", close output stream on completion="+closeOutputStream);
        BufferedOutputStream bos=null;
        BufferedInputStream bis=null;
        try {
            if(is instanceof BufferedInputStream) {
                bis = (BufferedInputStream)is;
            } else {
                bis = new BufferedInputStream(is);
            }
            if(os instanceof BufferedOutputStream) {
                bos = (BufferedOutputStream)os;
            } else {
                bos = new BufferedOutputStream(os);
            }

            byte[] bytes = new byte[1024 + ignoreEndBytesCount];
            int off = 0;
            int len = bytes.length;
            int i;

            while ((i = bis.read(bytes, off, len)) >= 0) { // loop while not eof
                if (i > 0) { // if any byte was read
                    off += i;
                    len -= i;

                    int cnt = off - ignoreEndBytesCount; // bytes to be written

                    if (cnt > 0) {
                        bos.write(bytes, 0, cnt);
                        System.arraycopy(bytes, cnt, bytes, 0, ignoreEndBytesCount);
                        off -= cnt;
                        len += cnt;
                    }
                }
            }

            bos.flush();
        } catch(Throwable th) {
            th.printStackTrace();
            throw new RuntimeException(th);
        } finally {
            StreamUtil.closeStream(bis);

            if(bos != null) {
                try {
                    bos.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(os != null) {
                try {
                    os.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            if(closeOutputStream) {
                StreamUtil.closeStream(bos);
            }
        }
    }

    /**
     * @param is
     * @return contents of the intput stream as a string
     */
    public static String toString(InputStream is) {
        return new String(toByteArray(is));
    }

    /**
     * Create a byte[] from the supplied InputStream.
     * The InputStream is closed after use.
     * @param is
     * @param os
     */
    public static byte[] toByteArray(InputStream is) {
        try (ByteArrayOutputStream byteOs = new ByteArrayOutputStream();
                BufferedOutputStream bos = new BufferedOutputStream(byteOs) ) {

            byte[] bytes = new byte[1024];
            int i;
            while((i = is.read(bytes)) > 0) {
                bos.write(bytes, 0, i);
            }
            bos.flush();

            return byteOs.toByteArray();
        } catch(Throwable th) {
            throw new RuntimeException(th);
        } finally {
            StreamUtil.closeStream(is);
        }
    }

    /**
     * Returns the first X number of bytes from the InputStream
     * @param is
     * @param lengthToObtain
     * @return
     */
    public static byte[] getFirstXBytes(InputStream is, int lengthToObtain) {
        try {
            if(lengthToObtain <=0) {
                return new byte[0];
            }
            byte[] b = new byte[lengthToObtain];
            int count = 0;
            while (count < b.length) {
                int n;
                n = is.read(b, count, b.length-count);
                if (n==-1) {
                    break;
                }
                count += n;
            }

            if(count <= 0) {
                return new byte[0];
            }
            if(count < lengthToObtain) {
                return Arrays.copyOfRange(b, 0, count);
            }
            // Convert the bytes into a new Throwable object which will be passed to the super-class
            return b;
        } catch (Exception e) {
            // There was an error processing the InputStream. Simply return null.
            return null;
        } finally {
            try {
                is.close();
            } catch(Throwable th) {
            }
        }
    }

    public static void writeOutput(JSONArray str, OutputStream out) {
        writeOutput(str.toString(), out);
    }

    public static void writeOutput(JSONObject str, OutputStream out) {
        writeOutput(str.toString(), out);
    }

    public static void writeOutput(String str, OutputStream out) {
        writeOutput(str.getBytes(), out);
    }

    /**
     * Writes the byte[] to the output stream, handles IO exception by throwing a runtime
     */
    public static void writeOutput(byte[] b, OutputStream out) {
        try {
            out.write(b);
        } catch (IOException e) {
            throw new RuntimeException("Error writing to stream", e);
        }
    }

    /**
     * Returns the first X number of bytes from the InputStream unless a carriage return or line feed is encountered.
     * @param is
     * @param lengthToObtain
     * @return
     */
    public static byte[] getFirstXBytesUpToCRLF(InputStream is, int lengthToObtain) {
        try {
            byte[] byteArray = new byte[lengthToObtain];
            int count = 0;
            while (count < byteArray.length) {
                int n;
                n = is.read(byteArray, count, byteArray.length-count);
                if (n==-1) {
                    break;
                }
                count += n;
            }

            int stopPosition = 0;
            for (byte aByte : byteArray) {
                // Notes:  0 is null, 10 is CarriageReturn, 13 is LineFeed
                if (aByte == 0 || aByte == 10 || aByte == 13) {
                    break;
                }
                stopPosition++;
            }
            if (stopPosition == lengthToObtain) {
                return byteArray;
            }
            return Arrays.copyOfRange(byteArray, 0, stopPosition);

        } catch (Exception e) {
            // There was an error processing the InputStream. Simply return null.
            return null;
        } finally {
            try {
                is.close();
            } catch(Throwable th) {
            }
        }
    }

    /**
     * Closes all of the supplied OutputStreams.
     * @param out the OutputStream
     */
    public static void closeStream(OutputStream... out) {
        if(out == null) {
            return;
        }
        for(OutputStream currentOut : out) {
            try {
                if(currentOut != null) {
                    currentOut.close();
                }
            } catch(Throwable th) {
                th.printStackTrace();
            }
        }
    }

    /**
     * Closes all of the supplied InputStreams.
     * @param in the InputStream
     */
    public static void closeStream(InputStream... in) {
        if(in == null) {
            return;
        }
        for(InputStream currentIn : in) {
            if(currentIn == null) {
                continue;
            }
            try {
                currentIn.close();
            } catch(Throwable th) {
                th.printStackTrace();
            }
        }
    }

    /**
     * @param rdl
     * @return whether the InputStream contained in the ReadableDataLocation is empty. This
     * is false when it has any content other than spaces or tabs
     */
    public static boolean isEmpty(ReadableDataLocation rdl) {
        if (rdl == null) {
            throw new IllegalArgumentException("No ReadableDataLocation supplied");
        }

        char tabCharacter = (char)0x09;

        try (InputStream in = rdl.getInputStream()) {
            int nextByte;
            while ((nextByte = in.read()) != -1) {
                // If the byte is not a space character then return false. This RDL is not empty
                if (nextByte != ' ' && nextByte != tabCharacter) {
                    return false;
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error obtaining InputStream", e);
        };
        // The input stream is empty
        return true;
    }

    /**
     * From the supplied InputStream, returns the end-of-line characters which are either int 13 and int 10 (Windows)
     * or int 10 (all other systems). Will return an empty string if there are no end of line characters.
     * @param inputStream
     * @return
     */
    public static String getEndOfLineCharacters(InputStream inputStream ) {
        StringBuilder endOfLineChars = new StringBuilder();
        if (inputStream == null) {
            throw new IllegalArgumentException("No InputStream supplied");
        }
        try {
            int currentChar;
            while ((currentChar = inputStream.read()) != -1) {
                if (currentChar == 13) {
                    // For Windows-style line endings ( \r\n - int 13 followed by int 10)
                    endOfLineChars.append((char) currentChar);
                    if ((currentChar = inputStream.read()) == 10) {
                        endOfLineChars.append((char) currentChar);
                        break;
                    }
                    break;
                } else if (currentChar == 10) {
                    // For Unix-style line endings (\n - int 10 )
                    endOfLineChars.append((char) currentChar);
                    break;
                }
            }
        } catch (IOException e) {
            LOG.error(e.getMessage());
            throw new RuntimeException("Error reading InputStream", e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    LOG.error("Unable to close InputStream due to: {}", e.getMessage(), e);
                }
            }
        }
        return endOfLineChars.toString();
    }
}
