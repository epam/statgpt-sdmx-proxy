package io.sdmx.utils.core.mail;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidation {
	
	// A legal email address is defined as conforming to the following Regular Expression.
	private static final Pattern p = Pattern.compile(
			"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");

	public static boolean validateEmail(String email) {
		if (email == null) {
			// Null is not a valid email address
			return false;
		}
		
		// Convert the email address to lower case and obtain a Matcher
		Matcher m = p.matcher(email.toLowerCase());

		// Return whether a match is found
		return m.matches();
	}
}
