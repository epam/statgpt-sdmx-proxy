package io.sdmx.utils.core.file;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.utils.core.io.OverflowWriteableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.StringUtil;

public class MultipartUtil {

	
	/**
	 * Splits a multipart stream into individual files
	 * @param dataLocation
	 * @return
	 * @throws IOException 
	 */
	public static List<ReadableDataLocation> splitFiles(ReadableDataLocation dataLocation, boolean closeSource) {
		List<ReadableDataLocation> files = new ArrayList<>();
		
		InputStream stream = dataLocation.getInputStream();
		try(Scanner scanner = new Scanner(stream)) {
			WriteableDataLocation wdl = null;
			OutputStream out = null;
			String boundaryName;
			if(scanner.hasNextLine()) {
				String currentLine = scanner.nextLine();
				if(!currentLine.startsWith("--")) {
					throw new IllegalArgumentException("Multipart data first line must be --[boundaryname]");
				}
				boundaryName = currentLine;
				String fileName = moveToStart(scanner);
				wdl = new OverflowWriteableDataLocation(fileName);
				out = wdl.getOutputStream();
			} else {
				return files;
			}
			while(scanner.hasNextLine()) {
				String currentLine = scanner.nextLine();
				if(currentLine.startsWith(boundaryName)) {
					String fileName = moveToStart(scanner);
					wdl = new OverflowWriteableDataLocation(fileName);
					out = wdl.getOutputStream();
				} else {
					boolean firstLine = wdl != null;
					try {
						if(firstLine) {
							files.add(wdl);
							wdl = null;
						} else {
							out.write(System.lineSeparator().getBytes());
						}
						out.write(currentLine.getBytes());
					} catch (IOException e) {
						for(ReadableDataLocation rdl : files) {
							rdl.close();
						}
						throw new SdmxException(e, "Error trying to split multipart data");
					}
				}
			}
		} finally {
			StreamUtil.closeStream(stream);
		}
		if(closeSource) {
			dataLocation.close();
		}
		return files;
	}
	
	/**
	 * Moves to the start of the file within the multipart stream
	 * @param scanner
	 * @return
	 */
	private static String moveToStart(Scanner scanner) {
		String fileName = null;
		while(scanner.hasNextLine()) {
			String currentLine = scanner.nextLine();
			if(currentLine.toLowerCase().startsWith("content-disposition")) {
				String[] split = currentLine.split(";");
				for(String splitPart : split) {
					splitPart = StringUtil.cleanString(splitPart);
					if(splitPart.startsWith("filename")) {
						fileName = splitPart.split("=")[1];
					}
				}
			} else if(currentLine.isEmpty()) {
				break;
			}
		}
		return fileName;
	}
}
