package io.sdmx.utils.core.audit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.api.logging.ILogDistributionEngine;

public class InMemoryLogDistributionEngine implements ILogDistributionEngine {
	private List<IFusionLogEvent> loggingEvents = new ArrayList<>();
	
	@Override
	public void logEvent(IFusionLogEvent loggingEvent) {
		loggingEvents.add(loggingEvent);
	}

	public List<IFusionLogEvent> getLoggingEvents() {
		return Collections.unmodifiableList(loggingEvents);
	}

}
