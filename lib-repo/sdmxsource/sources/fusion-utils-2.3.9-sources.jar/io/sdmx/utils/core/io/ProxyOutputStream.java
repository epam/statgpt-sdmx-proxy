package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Proxy a OutputStream to allow extensions of behaviour, passes all requests onto
 * proxy unless this is closed, then the proxy has no more calls made on it
 */
public abstract class ProxyOutputStream extends OutputStream {
    private OutputStream proxy;
    private boolean isClosed;

    public ProxyOutputStream(OutputStream proxy) {
        this.proxy = proxy;
    }

    protected OutputStream getProxy() {
        return proxy;
    }
    
    @Override
    public void write(int b) throws IOException {
    	if(isClosed()) return;
    	
    	getProxy().write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
    	if(isClosed()) return;
    	
    	getProxy().write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
    	if(isClosed()) return;
    	
    	getProxy().write(b, off, len);
    }

    @Override
    public void flush() throws IOException {
    	if(isClosed()) return;
    	
    	getProxy().flush();
    }

    @Override
    public void close() throws IOException {
    	if(isClosed) {
    		return;
    	}
    	this.isClosed = true;
    	getProxy().close();
    }
    
    protected boolean isClosed() {
    	return this.isClosed;
    }
}
