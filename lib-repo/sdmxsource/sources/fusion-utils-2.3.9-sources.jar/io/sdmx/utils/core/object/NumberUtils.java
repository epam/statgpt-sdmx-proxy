package io.sdmx.utils.core.object;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import io.sdmx.api.chars.CHARS;



public class NumberUtils {
	private static final char NUM_0 = "0".charAt(0);
	private static final char NUM_1 = "1".charAt(0);
	private static final char NUM_2 = "2".charAt(0);
	private static final char NUM_3 = "3".charAt(0);
	private static final char NUM_4 = "4".charAt(0);
	private static final char NUM_5 = "5".charAt(0);
	private static final char NUM_6 = "6".charAt(0);
	private static final char NUM_7 = "7".charAt(0);
	private static final char NUM_8 = "8".charAt(0);
	private static final char NUM_9 = "9".charAt(0);

	/**
	 * Represents the formatting style used for displaying numerical values.
	 */
	public enum NotationStyle  {
		/**
	     * Values may be represented using exponential notation e.g. 1.23E+4
	     */
		SCIENTIFIC_NOTATION,
		/**
		 * Similar to scientific notation, but the exponent is always a multiple of 3.
		 */
		ENGINGEERING_NOTATION,
		/**
		 * Values are displayed without any exponential notation or truncation.
		 */
		PLAIN
	}
	
	public static class Format {
		private int precision = -1;
		private boolean isDecimalPlace = true;
		private boolean normalise = false;
		private RoundingMode roundingMode = RoundingMode.HALF_UP;
		private NotationStyle notationStyle = NotationStyle.PLAIN;
		private Locale formatLocale;
		private Integer scalingFactor;

		public static Format get() {
			return new Format();
		}
		
		/**
		 * Copy constructor
		 * @param format
		 * @return
		 */
		public static Format get(Format format) {
			Format copy = get();
			copy.precision = format.precision;
			copy.isDecimalPlace = format.isDecimalPlace;
			copy.normalise = format.normalise;
			copy.roundingMode = format.roundingMode;
			copy.notationStyle = format.notationStyle;
			copy.formatLocale = format.formatLocale;
			copy.scalingFactor = format.scalingFactor;
			return copy;
		}

		/**
		 * @param decimal places
		 */
		public Format dp(int decimals) {
			this.precision = decimals;
			this.isDecimalPlace = true;
			return this;
		}
		
		/**
		 * @param significantFigures
		 */
		public Format sf(int significantFigures) {
			this.precision = significantFigures;
			this.isDecimalPlace = false;
			return this;
		}
		
		/**
		 * @return nullable - if provided, the thousand and period separator of the local will be used
		 */
		public Locale locale() {
			return formatLocale;
		}

		public Format locale(Locale formatLocale) {
			this.formatLocale = formatLocale;
			return this;
		}
		
		/**
		 * @return nullable - if provided, the number will be multiplied by 10^scaling factor before formatting takes place
		 */
		public Integer scalingFactor() {
			return scalingFactor;
		}

		public Format scalingFactor(Integer scalingFactor) {
			this.scalingFactor = scalingFactor;
			return this;
		}

		/**
		 * normalise will ensure there are always 'x' number of decimal places/significant figures even if it is longer then the
		 * original number, i.e. 1.1 to 3 decial places would be 1.100 normalised and 1.1 not normalised
		 */
		public Format normalise() {
			return normalise(true);
		}
		public Format normalise(boolean normalise) {
			this.normalise = normalise;
			return this;
		}
		
		public Format outputNotation(NotationStyle newVal) {
			this.notationStyle = newVal;
			return this;
		}

		public Format roundMode(RoundingMode roundingMode) {
			if(roundingMode != null) {
				this.roundingMode = roundingMode;
			}
			return this;
		}
	}
	
	public static String scaleNumber(String numberAsString, int scalingFactor) {
		if(!NumberUtils.isParsable(numberAsString)) {
			return numberAsString;
		}
		BigDecimal decimal = new BigDecimal(numberAsString);
		return scaleNumber(decimal, scalingFactor).toPlainString();
	}
	

	public static BigDecimal scaleNumber(BigDecimal decimal, int scalingFactor) {
		decimal = decimal.multiply(BigDecimal.TEN.pow(scalingFactor, MathContext.DECIMAL32));
		return decimal;
	}
	
	public static String formatNumber(String numberAsString, Format format) {
		if(!NumberUtils.isParsable(numberAsString)) {
			return numberAsString;
		}
		int precision = format.precision;
		
		BigDecimal decimal = new BigDecimal(numberAsString);
		if(format.scalingFactor != null) {
			decimal = scaleNumber(decimal, format.scalingFactor);
		}
		if(precision >= 0) {
			int newScale;
			if(format.isDecimalPlace) {
				newScale = precision;
			} else {
				newScale = precision-decimal.precision()+decimal.scale();
			}
			if(format.normalise==false && decimal.scale() < newScale) {
				if(format.locale() == null) {
					if(format.scalingFactor != null) {
						return decimal.toPlainString();
					}
					return numberAsString;
				}
			} else {
				decimal = decimal.setScale(newScale, format.roundingMode);
			}
		}
		
		switch (format.notationStyle) {
			case SCIENTIFIC_NOTATION:
				// In BigDecimal, 'toString' returns a value in Scientific Notation
				return decimal.toString();
			case ENGINGEERING_NOTATION:
				return decimal.toEngineeringString();
		}
		
		if(format.locale() != null) {
			DecimalFormat df = new DecimalFormat();
			df.setDecimalFormatSymbols(new DecimalFormatSymbols(format.locale()));
			df.setMinimumFractionDigits(decimal.scale());  //DEV-1897 ensure we don't loose trailing zeros in the decimal places
			return df.format(decimal);
		}
		return decimal.toPlainString();
	}

	public static boolean startWithNumber(String str) {
		return isNumber(str.charAt(0));
	}

	/**
	 * @param str
	 * @param upTo
	 * @return true if the input string is numbers (integer) up to the given char
	 */
	public static boolean isInteger(String str, boolean allowNegative) {
		if(str == null | str.length() == 0) {
			return false;
		}
		int startIdx = 0;
		if(allowNegative && str.charAt(0) == CHARS.MINUS.getChar()) {
			if(str.length() == 1) {
				return false;
			}
			startIdx = 1;
		}
		for(int i=startIdx; i < str.length(); i++) {
			char c = str.charAt(i);
			if(!isNumber(c)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @param str
	 * @param upTo
	 * @return true if the input string is numbers (integer) up to the given char
	 */
	public static boolean startWithNumber(String str, char upTo) {
		if(str == null) {
			return false;
		}
		for(int i=0; i < str.length(); i++) {
			char c = str.charAt(i);
			if(c == upTo) {
				return true;
			}
			if(!isNumber(c)) {
				return false;
			}
		}
		return str.length() > 0;
	}

	public static boolean isNumber(char c) {
		if(c == NUM_0) {
			return true;
		}
		if(c == NUM_1) {
			return true;
		}
		if(c == NUM_2) {
			return true;
		}
		if(c == NUM_3) {
			return true;
		}
		if(c == NUM_4) {
			return true;
		}
		if(c == NUM_5) {
			return true;
		}
		if(c == NUM_6) {
			return true;
		}
		if(c == NUM_7) {
			return true;
		}
		if(c == NUM_8) {
			return true;
		}
		if(c == NUM_9) {
			return true;
		}
		return false;
	}

	/**
	 * @param maxDecimals number of decimal places to round to
	 * @return decimal formatter set to round to the number of decimal places passed in
	 */
	public static DecimalFormat getDecimalFormat(int maxDecimals) {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i < maxDecimals; i++) {
			sb.append("#");
		}
		return new DecimalFormat("."+sb.toString());
	}

	/**
	 * Rounds the string parameter treating it as a number based on the decimal format passed in
	 * <p/>
	 * If the input string is not a number, returns the input string unmodified
	 * @param df
	 * @param number
	 * @return
	 */
	public static String round(DecimalFormat df, String number) {
		if(df != null && number != null) {
			double d;
			try {
				d = Double.parseDouble(number);
			} catch(NumberFormatException e) {
				return number;
			}
			if(df.getMaximumFractionDigits() == 0) {
				return number.split("\\.")[0];
			}
			//if(df.get)
			if(Double.isNaN(d)) {
				return number;
			}
			return df.format(d);
		}
		return number;
	}

	/**
	 * @param number
	 * @return string as double, or NaN if string is not parsable as a Double
	 */
	public static Double asDouble(String number) {
		if(!isParsable(number)) {
			return Double.NaN;
		}
		try {
			return Double.parseDouble(number);
		} catch(NumberFormatException e) {
			return Double.NaN;
		}
	}

	/**
	 * Returns true with:
		    Hexadecimal numbers starting with 0x or 0X
		    Octal numbers starting with a leading 0
		    Scientific notation (for example 1.05e-10)
		    Numbers marked with a type qualifier (for example 1L or 2.2d)
		If the supplied string is null or empty/blank, then it's not considered a number and the method will return false.
	 */
	public static boolean isParsable(final String str) {
		if (!ObjectUtil.validString(str)) {
			return false;
		}
		return org.apache.commons.lang3.math.NumberUtils.isCreatable(str);
	}

}
