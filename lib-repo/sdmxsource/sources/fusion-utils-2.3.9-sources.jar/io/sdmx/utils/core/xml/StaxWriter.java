package io.sdmx.utils.core.xml;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.object.ObjectUtil;

public class StaxWriter {
	//NAMESPACES
	public static final String XML_NS = "http://www.w3.org/XML/1998/namespace";
	public static final String XSI_NS = "http://www.w3.org/2001/XMLSchema-instance";

	private XMLStreamWriter writer;

	private Namespace[] namespaces;
	private String schemaLocation;

	public StaxWriter(OutputStream out, String schemaLocation,  boolean prettyPrint, Namespace... ns) {
		this.namespaces = ns;
		XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();
		try {
			writer = xmlOutputfactory.createXMLStreamWriter(out, StandardCharsets.UTF_8.toString());
			if(prettyPrint) {
				writer = new IndentingXMLStreamWriter(writer);
			}
			this.schemaLocation = schemaLocation;

		} catch (XMLStreamException e) {
			throw new SdmxException(e, "Could not create XML Writer");
		}
	}


	public void startDocument(Namespace ns, String element) {
		try {
			writer.writeStartDocument();
			if(ns != null) {
				writer.writeStartElement(ns.getNamespacePrefix(), element, ns.getNamespaceURL());
			} else {
				writer.writeStartElement(element);
			}
			writer.writeNamespace("xsi", XSI_NS);
			writer.writeNamespace("xml", XML_NS);
			if(namespaces != null) {
				for(Namespace currnetNs : namespaces) {
					writer.writeNamespace(currnetNs.getNamespacePrefix(), currnetNs.getNamespaceURL());
				}
			}
			if(ObjectUtil.validString(schemaLocation)) {
				writer.writeAttribute(XSI_NS, "schemaLocation", schemaLocation);
			}
		} catch (XMLStreamException e) {
			throw new SdmxException(e, "Could not create XML Writer");
		}
	}

	public void writeNameSpace(Namespace ns)  {
		if(ns != null) {
			try {
				writer.writeNamespace(ns.getNamespacePrefix(), ns.getNamespaceURL());
			} catch (XMLStreamException e) {
				throw new SdmxException(e, "Could not create XML Writer");
			}
		}
	}
	
	public void writeAttribute(String id, Boolean value) {
		if(value != null) {
			writeAttribute(id, value.toString());
		}
	}

	public void writeAttribute(String id, Integer value) {
		if(value != null) {
			writeAttribute(id, value.toString());
		}
	}

	public void writeAttribute(String id, String value) {
		if(ObjectUtil.validString(value)) {
			try {
				writer.writeAttribute(id, value);
			} catch (XMLStreamException e) {
				throw new SdmxException(e, "Could not write attribute '"+id+"' with value '"+value+"'");
			}
		}
	}
	public void writeXMLLang(String value) {
		if(ObjectUtil.validString(value)) {
			try {
				writer.writeAttribute("xml", XML_NS, "lang", value);
			} catch (XMLStreamException e) {
				throw new SdmxException(e, "Could not write xml:lang with value '"+value+"'");
			}
		}
	}

	public void writeAttributes(Map<String, String> attributes) {
		if(attributes != null) {
			for(String key : attributes.keySet()) {
				writeAttribute(key, attributes.get(key));
			}
		}
	}

	/**
	 * Writes an element with the given text, if the given text is not present, then the element will not be written
	 * @param ns
	 * @param elementName
	 * @param elementText
	 */
	public void writeElement(Namespace ns, String elementName, String elementText) {
		if(ObjectUtil.validString(elementText)) {
			writeElement(ns, elementName, elementText, null);
		}
	}

	public void writeElement(Namespace ns, String elementName, Map<String, String> attributes) {
		writeElement(ns, elementName, null, attributes, false);
	}

	public void writeElement(Namespace ns, String elementName, String elementText, Map<String, String> attributes) {
		writeElement(ns, elementName, elementText, attributes, true);
	}

	/**
	 * Writes an element with the given text even if the element text is blank.
	 * @param ns
	 * @param elementName
	 * @param elementText if null will be converted to a blank string
	 */
	public void writeElementAllowBlank(Namespace ns, String elementName, String elementText) {
		writeElement(ns, elementName, (elementText == null ? "" : elementText), null);
	}

	private void writeElement(Namespace ns, String elementName, String elementText, Map<String, String> attributes, boolean endElement) {
		if(elementName != null) {
			writeStartElement(ns, elementName);
		}
		writeAttributes(attributes);
		if(elementText != null) {
			writeElementText(elementText);
		}
		if(endElement) {
			writeEndElement();
		}
	}

	public void writeElementText(String elementText) {
		if(elementText != null) {
			try {
				writer.writeCharacters(elementText);
			} catch (XMLStreamException e) {
				throw new SdmxException(e, "Could not create XML Writer");
			}
		}
	}

	public void writeStartElement(Namespace ns, String elementName) {
		try {
			if(ns != null) {
				writer.writeStartElement(ns.getNamespacePrefix(), elementName, ns.getNamespaceURL());
			} else {
				writer.writeStartElement(elementName);
			}
		} catch (XMLStreamException e) {
			throw new SdmxException(e, "Could not create XML Writer");
		}
	}

	public void writeEndElement() {
		try {
			writer.writeEndElement();
		} catch (XMLStreamException e) {
			throw new SdmxException(e, "Could not create XML Writer");
		}
	}

	public void close() {
		try {
			writer.writeEndDocument();
			writer.close();
		} catch (XMLStreamException e) {
			throw new SdmxException(e, "Could not close XML Writer");
		}
	}

}
