package io.sdmx.utils.core.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;

public class KeyValueUtil {

	/**
	 * Appends a new KeyValue to the mutable list, and returns the new list (mutable) 
	 * @param list
	 * @param concept
	 * @param code
	 * @return
	 */
	public static List<KeyValue> append(List<KeyValue> list, String concept, String... code) {
		List<KeyValue> newList = new ArrayList<>(list.size()+1);
		newList.addAll(list);
		newList.add(KeyValueImpl.getInstance(concept, code));
		return newList;
	}

	/**
	 * Appends a new KeyValue to the mutable list, and returns the new list (mutable) 
	 * @param list
	 * @param concept
	 * @param code
	 * @return
	 */
	public static List<KeyValue> append(List<KeyValue> list, Collection<KeyValue> kvs) {
		List<KeyValue> newList = new ArrayList<>(list.size()+kvs.size());
		newList.addAll(list);
		for(KeyValue kv : kvs) {
			newList.add(kv);
		}
		return newList;
	}


	/**
	 * Converts a collection of key values into a map of key to a collection of values
	 * @param keyValues
	 * @return
	 */
	public static Map<String, Set<String>> toMapOfSet(Collection<KeyValue> keyValues) {
		Map<String, Set<String>> returnMap = new HashMap<>();
		for(KeyValue kv : keyValues) {
			CollectionUtil.addToMappedSet(returnMap, kv.getConcept(), kv.getCode());
		}
		return returnMap;
	}

	/**
	 * @param keyValues  string with whitespace to seperate key from value, values can be comma separated to create multiple
	 * @return
	 */
	public static List<KeyValue> toKeyValues(String... kvs) {
		List<KeyValue> returnList = new ArrayList<>();
		if(kvs != null) {
			for(String kvString : kvs) {
				String[] split = kvString.split(" ", 2);
				String[] splitValues = split[1].split(",");
				returnList.add(KeyValueImpl.getInstance(split[0], splitValues));
			}
		}
		return returnList;
	}


	/**
	 * @param keyValues  string with whitespace to seperate key from value, values can be comma separated to create multiple
	 * @return
	 */
	public static List<KeyValue> toKeyValues(Collection<String> kvs) {
		List<KeyValue> returnList = new ArrayList<>();
		if(kvs != null) {
			for(String kvString : kvs) {
				String[] split = kvString.split(" ", 2);
				String[] splitValues = split[1].split(",");
				returnList.add(KeyValueImpl.getInstance(split[0], splitValues));
			}
		}
		return returnList;
	}

	/**
	 * @param keyValues
	 * @return
	 */
	public static List<KeyValue> toKeyValues(Map<String, String> kvs) {
		if(kvs == null) {
			return null;
		}
		List<KeyValue> returnList = new ArrayList<>(kvs.size());

		for(String key : kvs.keySet()) {
			returnList.add(KeyValueImpl.getInstance(key, kvs.get(key)));
		}

		return returnList;
	}

	/**
	 * Copies a subset of the map
	 * @param kvs the key value key to value
	 * @param copySet the set of keys to copy from the map
	 * @return
	 */
	public static List<KeyValue> toKeyValues(Map<String, String> kvs, Collection<String> copySet, boolean copyNulls) {
		if(kvs == null || copySet == null) {
			return null;
		}
		List<KeyValue> returnList = new ArrayList<>(kvs.size());
		for(String key : copySet) {
			String value = kvs.get(key);
			if(value == null && !copyNulls) {
				continue;
			}
			returnList.add(KeyValueImpl.getInstance(key, value));
		}
		return returnList;
	}

	/**
	 * @param kv
	 * @return values for the key value as a string  e.g. UK, a collection of strings, e.g. [UK,FR,dE], or an empty string []
	 */
	public static String getValueString(KeyValue kv) {
		if(kv == null) {
			return "[]";
		}
		String val;
		if (kv.hasMultipleValues()) {
			List<String> values = kv.getValues();

			if (values.isEmpty())
				val = "[]";
			else
				val = "['" + String.join("', '", values) + "']";
		} else
			val = kv.getCode();

		return val;
	}

}
