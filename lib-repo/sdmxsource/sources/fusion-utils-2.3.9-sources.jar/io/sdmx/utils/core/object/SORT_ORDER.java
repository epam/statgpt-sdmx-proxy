package io.sdmx.utils.core.object;

/**
 * Defines the sort order which can be:
 * <ol>
 *  <li>NATURAL - do not sort and use whatever the natural order is</li>
 *  <li>ASCENDING - alphabetically sorted</li>
 *  <li>DESCENDING - reverse alphabetic</li>
 * </ol>
 */
public enum SORT_ORDER {
	NATURAL,
	ASCENDING,
	DESCENDING;
}

