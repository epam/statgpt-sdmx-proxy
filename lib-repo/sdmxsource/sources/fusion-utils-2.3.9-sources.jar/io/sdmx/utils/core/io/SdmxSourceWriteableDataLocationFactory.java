package io.sdmx.utils.core.io;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;

public class SdmxSourceWriteableDataLocationFactory implements WriteableDataLocationFactory {

	@Override
	public WriteableDataLocation getTemporaryWriteableDataLocation() {
		return new OverflowWriteableDataLocation();
	}
	
	@Override
	public WriteableDataLocation getTemporaryWriteableDataLocation(FILE_FORMAT fileFormat) {
		return new OverflowWriteableDataLocation(fileFormat);
	}
	
	/**
	 * Sets the maximum amount of data to store in memory, in kb
	 * @param maxMemory
	 */
	public void setMaxMemoryKb(long maxMemory) {
		OverflowWriteableDataLocation.setMaxMemoryKb(maxMemory);
	}
}
