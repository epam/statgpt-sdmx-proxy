package io.sdmx.utils.core.date;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.date.PERIOD_OVERLAP;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxPeriodImpl implements SdmxPeriod {
	private static final long serialVersionUID = 1L;
	private SdmxDate startPeriod;
	private SdmxDate endPeriod;

	private boolean isAllPeriods = false;
	public static final SdmxPeriod ALL_PERIODS = new SdmxPeriodImpl();



	private SdmxPeriodImpl() {
		isAllPeriods = true;
	}
	
	public static SdmxPeriod fromISOString(String isoPeriod) {
        if(isoPeriod == null || isoPeriod.equals("AllPeriods")) {
            return SdmxPeriodImpl.ALL_PERIODS;
        }
        String[] splitPeriod = isoPeriod.split("/", 2);
        splitPeriod[0] = splitPeriod[0].length() == 0 ? null : splitPeriod[0];
        splitPeriod[1] = splitPeriod[1].length() == 0 ? null : splitPeriod[1];
        return new SdmxPeriodImpl(splitPeriod[0], splitPeriod[1]);
    }
	
	public static SdmxPeriod instance(String startPeriod, String endPeriod) {
		if(startPeriod == null && endPeriod == null) {
			return SdmxPeriodImpl.ALL_PERIODS;
		}
		return new SdmxPeriodImpl(startPeriod, endPeriod);
	}

	/**
	 * Constructor taking string representations of dates, either can be null but at least one must be non-null.
	 *
	 * @param startPeriod
	 * @param endPeriod
	 */
	public SdmxPeriodImpl(String startPeriod, String endPeriod) {
		if(ObjectUtil.validString(startPeriod)) {
			this.startPeriod = SdmxDateImpl.getSdmxDate(startPeriod, true);
		}
		if(ObjectUtil.validString(endPeriod)) {
			this.endPeriod = SdmxDateImpl.getSdmxDate(endPeriod, false);
		}
		validate();
	}

	public SdmxPeriodImpl(Date startPeriod, Date endPeriod, TIME_FORMAT tf) {
		if(startPeriod != null) {
			this.startPeriod = new SdmxDateImpl(startPeriod, tf, true);
		}
		if(endPeriod != null) {
			this.endPeriod  = new SdmxDateImpl(endPeriod, tf, false);
		}
		validate();
	}

	public SdmxPeriodImpl(SdmxDate startPeriod, SdmxDate endPeriod) {
		this.startPeriod = startPeriod;
		if(endPeriod != null && endPeriod.isStartPeriod()) {
		    endPeriod = SdmxDateImpl.getSdmxDate(endPeriod.getDateInSdmxFormat(), false);
		}
		this.endPeriod = endPeriod;
		validate();
	}

	private void validate() {
		if(startPeriod == null && endPeriod == null) {
			throw new SdmxException("Can not create SdmxPeriod - no startPeriod or endPeriod defined");
		}
		if(startPeriod != null && endPeriod != null) {
			if(startPeriod.isLater(endPeriod)) {
				throw new SdmxSemmanticException(ExceptionCode.END_DATE_BEFORE_START_DATE);
			}
		}
	}
	
	@Override
	public boolean isAllPeriods() {
		return isAllPeriods;
	}

	@Override
	public SdmxDate getStartPeriod() {
		return startPeriod;
	}

	@Override
	public SdmxDate getEndPeriod() {
		return endPeriod;
	}


	@Override
	public PERIOD_OVERLAP getOverlap(SdmxPeriod that) {
		if(this.equals(that)) {
			return PERIOD_OVERLAP.EXACT_MATCH;
		}
		if(this.isAllPeriods) {
			return PERIOD_OVERLAP.SUPERSET;
		}
		if(that == ALL_PERIODS) {
			return PERIOD_OVERLAP.SUBSET;
		}
		//This condition can be hit when the two periods have the same start and end but are in different frequencies
		if(this.isStartEqual(that) && this.isEndEqual(that)) {
			return PERIOD_OVERLAP.EXACT_MATCH;
		}
		if(!isInPeriod(that)) {
			return PERIOD_OVERLAP.NOT_IN_PERIOD;
		}
		if(isFullyInPeriod(that)) {
			return PERIOD_OVERLAP.SUPERSET;
		}
		if(that.isFullyInPeriod(this)) {
			return PERIOD_OVERLAP.SUBSET;
		}
		return PERIOD_OVERLAP.OVERLAP;
	}

	@Override
	public Set<SdmxPeriod> split(SdmxPeriod that) {
		Set<SdmxPeriod> periods = new HashSet<>();
		if(that == null) {
			periods.add(this);
			return periods;
		}
		//Work out the least granular time format
		TIME_FORMAT tf = null;
		if(this.hasStartPeriod()) {
			tf = this.getStartPeriod().getTimeFormatOfDate();
		}
		if(this.hasEndPeriod()) {
			TIME_FORMAT thatTf = this.getEndPeriod().getTimeFormatOfDate();
			if(tf == null) {
				tf = thatTf;
			} else if (thatTf.getPeriodsInAYear() > tf.getPeriodsInAYear()) {
				tf = thatTf;
			}
		}
		if(that.hasStartPeriod()) {
			TIME_FORMAT thatTf = that.getStartPeriod().getTimeFormatOfDate();
			if(tf == null) {
				tf = thatTf;
			} else if (thatTf.getPeriodsInAYear() > tf.getPeriodsInAYear()) {
				tf = thatTf;
			}
		}
		if(that.hasEndPeriod()) {
			TIME_FORMAT thatTf = that.getEndPeriod().getTimeFormatOfDate();;
			if(tf == null) {
				tf = thatTf;
			} else if (thatTf.getPeriodsInAYear() > tf.getPeriodsInAYear()) {
				tf = thatTf;
			}
		}
		Date start1, start2, start3, end1, end2, end3;
		boolean thisIsSubset = false;
		switch(getOverlap(that)) {
		case EXACT_MATCH:
			periods.add(this);
			break;
		case NOT_IN_PERIOD:
			periods.add(this);
			periods.add(that);
			break;
		case OVERLAP:
			//Create three new periods; before, intesection, after
			//Example 2010 - 2015 overlaps with 2011-2016
			//Split 2010-2010, 2011-2015, 2016-2016
			//Determine which period comes first and which second
			SdmxPeriod earlierPeriod = this.isBeforePeriod(that) ? this : that;
			SdmxPeriod laterPeriod = this == earlierPeriod ? that : this;

			start1 = earlierPeriod.hasStartPeriod() ? earlierPeriod.getStartPeriod().getDate() : null;
			start2 = laterPeriod.getStartPeriod().getDate();

			end1 = new Date(start2.getTime()-1000); //minus 1 millisecond from the start of the second period
			end2 = earlierPeriod.getEndPeriod().getDate();

			start3 = new Date(end2.getTime()+1000); //add 1 millisecond from the end of the second period
			end3 = laterPeriod.hasEndPeriod() ? laterPeriod.getEndPeriod().getDate() : null;

			periods.add(new SdmxPeriodImpl(start1, end1, tf));
			periods.add(new SdmxPeriodImpl(start2, end2, tf));
			periods.add(new SdmxPeriodImpl(start3, end3,tf));

			break;
		case SUBSET:
			thisIsSubset = true;
		case SUPERSET:
			//This period is fully contained in that period or vica verca example
			//This = 2010-2011, that= 2009-2012
			//Split 2009-2009, 2010-2011, 2012-2012

			//Note an overlap includes where start or end period match, for example
			//This = 2010-2011, that= 2010-2012
			//Split 2010-2011, 2012-2012
			SdmxPeriod outerPeriod = thisIsSubset ? that : this;
			SdmxPeriod innerPeriod = thisIsSubset ? this : that;
			if(this.isStartEqual(that) || this.isEndEqual(that)) {
				start1 = outerPeriod.hasStartPeriod() ? outerPeriod.getStartPeriod().getDate() : null;
				if(this.isStartEqual(that)) {
					end1 = innerPeriod.getEndPeriod().getDate();
				} else {
					end1 =  new Date((innerPeriod.getStartPeriod().getDate().getTime() - 1000));
				}
				start2 = new Date(end1.getTime()+1000); //add 1 millisecond from the end of the first period
				end2 = outerPeriod.hasEndPeriod() ? outerPeriod.getEndPeriod().getDate() : null;
				periods.add(new SdmxPeriodImpl(start1, end1, tf));
				periods.add(new SdmxPeriodImpl(start2, end2, tf));
			} else {
				start1 = outerPeriod.hasStartPeriod() ? outerPeriod.getStartPeriod().getDate() : null;
				start2 = innerPeriod.getStartPeriod().getDate();

				end1 = new Date(start2.getTime()-1000); //minus 1 millisecond from the start of the second period
				end2 = innerPeriod.getEndPeriod().getDate();

				start3 = new Date(end2.getTime()+1000); //add 1 millisecond from the end of the second period
				end3 = outerPeriod.hasEndPeriod() ? outerPeriod.getEndPeriod().getDate() : null;

				periods.add(new SdmxPeriodImpl(start1, end1, tf));
				periods.add(new SdmxPeriodImpl(start2, end2, tf));
				periods.add(new SdmxPeriodImpl(start3, end3,tf));
			}
			break;
		}
		return periods;
	}


	@Override
	public boolean isStartEqual(SdmxPeriod period) {
		if(this.getStartPeriod() == null && period.getStartPeriod() == null) {
			return true;
		}
		if(this.getStartPeriod() == null || period.getStartPeriod() == null) {
			return false;
		}
		return this.getStartPeriod().getDate().getTime() == period.getStartPeriod().getDate().getTime();
	}

	@Override
	public boolean isBeforePeriod(SdmxPeriod period) {
		//This has no start period so it is before the other period if that does have one
		if(!this.hasStartPeriod()) {
			return period.hasStartPeriod() == true;
		}
		//If the passed in period has no start period then it is before this one
		if(!period.hasStartPeriod()) {
			return false;
		}
		//Both have a start period
		return this.getStartPeriod().isEarlier(period.getStartPeriod());
	}

	@Override
	public boolean isEndEqual(SdmxPeriod period) {
		if(this.getEndPeriod() == null && period.getEndPeriod() == null) {
			return true;
		}
		if(this.getEndPeriod() == null || period.getEndPeriod() == null) {
			return false;
		}
		return this.getEndPeriod().getDate().getTime() == period.getEndPeriod().getDate().getTime();
	}

	@Override
	public boolean isAfterPeriod(SdmxPeriod period) {
		//This has no start period so it is before the other period if that does have one
		if(!this.hasEndPeriod()) {
			return period.hasEndPeriod() == true;
		}
		//If the passed in period has no start period then it is before this one
		if(!period.hasEndPeriod()) {
			return false;
		}
		//Both have a start period
		return this.getEndPeriod().isLater(period.getEndPeriod());
	}

	@Override
	public boolean isInPeriod(SdmxPeriod period) {
		if(isAllPeriods || period == ALL_PERIODS) {
			return true;
		}
		if(period != null) {
			return isInPeriod(period.hasStartPeriod() ? period.getStartPeriod().getDate() : null,
					period.hasEndPeriod() ? period.getEndPeriod().getDate() : null);
		}
		return false;
	}

	@Override
	public boolean isFullyInPeriod(SdmxPeriod period) {
		if(period == null) {
			return false;
		}
		boolean isOutsidePeriod = period.hasStartPeriod() ? isBeforeStartPeriod(period.getStartPeriod().getDate()) : this.hasStartPeriod();
		if(isOutsidePeriod) {
			return false;
		}
		isOutsidePeriod = period.hasEndPeriod() ? isAfterEndPeriod(period.getEndPeriod().getDate()) : this.hasEndPeriod();
		return !isOutsidePeriod;
	}

	@Override
	public boolean hasStartPeriod() {
		return startPeriod != null;
	}

	@Override
	public boolean hasEndPeriod() {
		return endPeriod != null;
	}

	@Override
	public boolean isInPeriod(Date dateFrom, Date dateTo) {
		if(isAllPeriods) {
			return true;
		}
		if((dateTo != null && isBeforeStartPeriod(dateTo)) || (dateFrom != null && isAfterEndPeriod(dateFrom))) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isBeforeStartPeriod(Date date) {
		if(isAllPeriods) {
			return false;
		}
		if(date != null) {
			if(!hasStartPeriod()) {
				return false;
			}
			return date.before(getStartPeriod().getDate());
		}
		return startPeriod != null;
	}

	@Override
	public boolean isAfterEndPeriod(Date date) {
		if(isAllPeriods) {
			return false;
		}
		if(date != null) {
			if(!hasEndPeriod()) {
				return false;
			}
			return date.after(getEndPeriod().getDate());
		}
		return false;
	}

	@Override
	public boolean isInPeriod(Date date) {
		if(isAllPeriods) {
			return true;
		}
		if(hasStartPeriod()) {
			if(date.before(getStartPeriod().getDate())) {
				return false;
			}
		}
		if(hasEndPeriod()) {
			if(date.after(getEndPeriod().getDate())) {
				return false;
			}
		}
		return true;
	}



	@Override
	public int compareTo(SdmxPeriod o) {
		if(o == this) {
			return 0;
		}
		if(startPeriod == null && o.getStartPeriod() != null) {
			return -1;
		}
		if(startPeriod != null && o.getStartPeriod() == null) {
			return 1;
		}
		if(startPeriod != null && o.getStartPeriod() != null) {
			int result = startPeriod.getDate().compareTo(o.getStartPeriod().getDate());
			if(result != 0) {
				return result;
			}
		}
		if(endPeriod == null && o.getEndPeriod() != null) {
			return 1;
		}
		if(endPeriod != null && o.getEndPeriod() == null) {
			return -1;
		}
		if(endPeriod != null && o.getEndPeriod() != null) {
			int result = endPeriod.getDate().compareTo(o.getEndPeriod().getDate());
			if(result != 0) {
				return result;
			}
		}
		return 0;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SdmxPeriod) {
			SdmxPeriod that = (SdmxPeriod) obj;
			if(!ObjectUtil.equivalent(that.getStartPeriod(), this.getStartPeriod())) {
				return false;
			}
			if(!ObjectUtil.equivalent(that.getEndPeriod(), this.getEndPeriod())) {
				return false;
			}
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		if(isAllPeriods) {
			return "[All Periods]";
		}
		StringBuilder sb = new StringBuilder();
		String startPeriod = hasStartPeriod() ? getStartPeriod().getDateInSdmxFormat() : "[no start]";
		String endPeriod =  hasEndPeriod() ? getEndPeriod().getDateInSdmxFormat() : "[no end]";
		sb.append(startPeriod + " - " + endPeriod);
		return sb.toString();
	}
}
