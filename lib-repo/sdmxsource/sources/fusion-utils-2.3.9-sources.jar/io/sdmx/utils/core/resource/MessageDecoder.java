package io.sdmx.utils.core.resource;

import java.text.MessageFormat;
import java.util.HashSet;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.lang.MessageResolver;

public class MessageDecoder implements MessageResolver {
	
	private static final Set<String> baseNames = new HashSet<>();
    private static Locale defaultLocale = new Locale("en");
    
    static {
        baseNames.add("exception");
    }
	
	public MessageDecoder() {
		SdmxException.setMessageResolver(this);
	}

	@Override
	public String resolveMessage(String messageCode, Locale locale, Object... args) {
		return getMessage(messageCode, locale, args);
	}

	public static String decodeMessage(String id, Object... args) {
		return getMessage(id, defaultLocale, args);
	}
	
	public static String decodeMessageDefaultLocale(String id, Object... args) {
		return getMessage(id, defaultLocale, args);
	}
	
	public static String decodeMessageGivenLocale(String id, String lang, Object... args) {
		Locale locale = new Locale(lang);
        return getMessage(id, locale, args);
	}
	
	public static void addBaseName(String baseName) {
		baseNames.add(baseName);
	}

	public void setBasenames(Set<String> basenames) {
		baseNames.addAll(basenames);
	}
	
	/**
	 * Givven a key
	 * @param key
	 * @param locale
	 * @param args
	 * @return
	 */
	
	/**
	 * Returns a localized message string for the given key from all available resource bundles.
	 * If no bundle contains the key, the method returns the original key.
	 * @param key the message key to look up in the resource bundles
	 * @param locale the locale used to select the appropriate resource bundle
	 * @param args optional arguments to format the message string
	 * @return the localized and formatted message string if found; otherwise the key itself
	 */
    private static String getMessage(String key, Locale locale, Object... args) {
        for (String baseName : baseNames) {
            try {
                ResourceBundle rb = ResourceBundle.getBundle(baseName, locale);
                if (rb.containsKey(key)) {
                    String msg = rb.getString(key);
                    return MessageFormat.format(msg, args);
                }
            } catch (Exception ignored) {
                // Silently try the next bundle
            }
        }
        return key;  // Fallback: return the key itself
    }
	
}
