package io.sdmx.utils.core.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.InMemoryReadableDataLocation;
import io.sdmx.utils.core.xml.StaxUtil;

public class XLSXTestUtil {

	/**
	 * Checks that two XLSX files are the same, ignoring certain styling aspects such as column width
	 * @param actualOuptut
	 * @param expectedFile
	 */
	public static void assertSameXLSX(byte[] actualOuptut, String expectedFile) {
		Set<String> ignoreAttributes = new HashSet<>();
		ignoreAttributes.add("width");
		ignoreAttributes.add("created");
		ignoreAttributes.add("lpwstr");
		ignoreAttributes.add("borderId");
		
		List<ReadableDataLocation> files = null;
		ReadableDataLocation expectedRDL = new InMemoryReadableDataLocation(expectedFile);
		List<ReadableDataLocation> expectedFiles = null;

		
		try {
			files = ZipUtil.unzipFiles(new InMemoryReadableDataLocation(actualOuptut));
			expectedFiles = ZipUtil.unzipFiles(expectedRDL);
			Map<String, ReadableDataLocation> fileMap = new HashMap<>();
			for(ReadableDataLocation rdl : expectedFiles) {
				if(rdl.getName().endsWith(".xml") && !rdl.getName().endsWith("styles.xml")) {
					fileMap.put(rdl.getName(), rdl);
				}
			}
			for(ReadableDataLocation rdl : files) {
				//Only check XML files, do not check the styles file
				if(rdl.getName().endsWith(".xml") && !rdl.getName().endsWith("styles.xml")) {
					
					ReadableDataLocation expected = fileMap.get(rdl.getName());
					if(expected == null) {
						throw new RuntimeException("expected file is null");
					}
					try {
						// IMPORTANT NOTE: FMR#750:
						// Now that the StaxUtil has been corrected and all attributes are being checked, the node 's'
						// keeps reporting a difference. This might be a "shared string", but I am not sure.
						// For now, simply ignore it
						ignoreAttributes.add("s");
						StaxUtil.isSameXML(expected.getInputStream(), rdl.getInputStream(), ignoreAttributes, null, "width", "created", "lpwstr");
					} catch (Exception e) {
						throw new RuntimeException("Files '"+rdl.getName()+"' differ: " + e.getMessage());
					}
				}
			}
		} finally {
			for(ReadableDataLocation rdl : files) {
				rdl.close();
			}
			for(ReadableDataLocation rdl : expectedFiles) {
				rdl.close();
			}
			expectedRDL.close();
		}
	}
	
}
