package io.sdmx.utils.core.xml;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;

public class XmlUtils {
	public static Document document(InputStream is) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			// Set the DocumentBuilder so it will ignore all external referenced entities
			db.setEntityResolver(new EntityResolver() {
				@Override
				public InputSource resolveEntity(String publicId, String systemId) {
					return new InputSource(new StringReader("")); // Return a valid dummy source
				}
			});
			return db.parse(is);
		} catch(SAXException | IOException | ParserConfigurationException e) {
			throw new SdmxSemmanticException(e, "Could not read xml document");
		}
	}

	public static NodeList searchForNodeList(Document document, String xpath) {
		try {
			return (NodeList) XPathFactory.newInstance().newXPath().compile(xpath)
					.evaluate(document, XPathConstants.NODESET);
		} catch(XPathExpressionException e) {
			throw new SdmxSemmanticException(e, "Could not read xml document");
		}
	}

	/**
	 * Returns true if the specified ReadableDataLocation contains valid XML.
	 * @param sourceData The ReadableDataLocation to test
	 * @return true if the specified  ReadableDataLocation contains valid XML.
	 */
	public static boolean isXML(ReadableDataLocation rdl) {
		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
		SdmxException.disableExceptionTrace(true);
		StaxReader reader = null;
		try {
			//Try and read it as a JSON dataset
			reader = new StaxReader(rdl);
			reader.moveNextNode();
			return true;
		} catch(Throwable th) {
			return false;
		} finally {
			if(reader != null) {
				reader.close();
			}
			SdmxException.disableExceptionTrace(wasDisabled);
		}
	}

	/**
	 * Formats the specified XML String so it has indentation
	 * @param unformattedXml A string representation of some XML
	 * @return a formatted version of the input XML.
	 */
	public static String formatXml(String unformattedXml) {
		try {
			TransformerFactory factory = TransformerFactory.newInstance();
			factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

			Transformer transformer = factory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");

			StreamResult result = new StreamResult(new StringWriter());

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			// Set the DocumentBuilder so it will ignore all external referenced entities
			db.setEntityResolver(new EntityResolver() {
				@Override
				public InputSource resolveEntity(String publicId, String systemId) {
					return new InputSource(new StringReader("")); // Return a valid dummy source
				}
			});
			InputSource is = new InputSource(new StringReader(unformattedXml));
			Document doc = db.parse(is);

			DOMSource source = new DOMSource(doc);
			transformer.transform(source, result);
			return result.getWriter().toString();
		} catch(Throwable th) {
			throw new RuntimeException(th);
		}
	}

}
