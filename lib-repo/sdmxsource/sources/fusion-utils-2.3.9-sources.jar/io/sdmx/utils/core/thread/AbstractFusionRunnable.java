package io.sdmx.utils.core.thread;

import java.util.Map;

public abstract class AbstractFusionRunnable implements Runnable {
    private Map<Object, Object> localThreadContents;

    public AbstractFusionRunnable() {
        this(true);
    }

    public AbstractFusionRunnable(boolean copyThreadLocal) {
        if(copyThreadLocal) {
           localThreadContents = ThreadLocalUtil.getThreadContents();
        }
    }

    @Override
    public final void run() {
        try {
            if(localThreadContents != null) {
                for(Object o : localThreadContents.keySet()) {
                    ThreadLocalUtil.storeOnThread(o, localThreadContents.get(o));
                }
            }
            runInternal();
        } finally {
            ThreadLocalUtil.clearThread();
        }
    }

    protected abstract void runInternal();
}
