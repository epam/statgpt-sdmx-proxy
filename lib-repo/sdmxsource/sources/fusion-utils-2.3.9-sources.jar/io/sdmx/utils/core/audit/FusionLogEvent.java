package io.sdmx.utils.core.audit;

import java.util.Map;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * built from Logback {@link ILoggingEvent}
 */
public class FusionLogEvent extends AbstractFusionLogEvent {

	/**
	 * @param loggingEvent the logged information
	 * @param auditId optional, the audit id to which this log event belongs
	 * @param expireTime optional, log level to the number of milliseconds the log should be persisted for
	 */
	public FusionLogEvent(ILoggingEvent loggingEvent, String auditId, Map<Integer, Long> expireTime) {
		if(loggingEvent.getLevel() != null) {
			switch(loggingEvent.getLevel().levelInt) {
			case Level.TRACE_INT : 
				this.logLevel = 0;
				break;
			case Level.DEBUG_INT : 
				this.logLevel = 1;
				break;
			case Level.INFO_INT : 
				this.logLevel = 2;
				break;
			case Level.WARN_INT : 
				this.logLevel = 3;
				break;
			case Level.ERROR_INT :
				this.logLevel = 4; 
				break;
			case Level.ALL_INT : 
				this.logLevel = -1;
				break;
			case Level.OFF_INT : 
				this.logLevel = 10;
				break;
			}
		} else {
			this.logLevel = -1;
		}
		this.loggerName = loggingEvent.getLoggerName();
		this.message = loggingEvent.getMessage();
		this.threadName = loggingEvent.getThreadName();
		this.timestamp = loggingEvent.getTimeStamp();
		this.auditId = auditId;
		if(expireTime != null) {
			Long expires = expireTime.get(this.logLevel);
			if(expires != null) {
				this.expires = this.timestamp + expires;
			}
		}
	}
}
