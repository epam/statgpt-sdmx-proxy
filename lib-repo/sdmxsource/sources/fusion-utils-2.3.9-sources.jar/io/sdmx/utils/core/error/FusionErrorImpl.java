package io.sdmx.utils.core.error;

import java.text.MessageFormat;

import io.sdmx.api.error.FusionError;

public class FusionErrorImpl implements FusionError {

    private String errorCode;
    private String errorMessage;

    public FusionErrorImpl(String errorMessage) {
        this(null, errorMessage, (String[])null);
    }

    public FusionErrorImpl(String errorCode, String errorMessage) {
        this(errorCode, errorMessage, (String[])null);
    }

    public FusionErrorImpl(String errorCode, String errorMessage, String... args) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        if (args != null) {
            String err = MessageFormat.format(errorMessage, (Object[])args);
            this.errorMessage = err;
        }
    }

    public FusionErrorImpl(FusionError fe, String... args) {
        this(fe.getErrorCode(), fe.getErrorMessage(), args);
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getErrorMessage() {
        return errorMessage;
    }

	@Override
	public String toString() {
		return errorMessage;
	}
}
