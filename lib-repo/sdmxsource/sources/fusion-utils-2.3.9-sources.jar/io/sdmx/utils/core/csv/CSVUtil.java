package io.sdmx.utils.core.csv;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import io.sdmx.utils.core.io.StreamUtil;

public class CSVUtil {


	/**
	 * Adds the missing BOM character required for UTF-8
	 * FR-3573 Data REST API csv not interpreted as UTF-8 without BOM characters
	 *
	 * @param out
	 * @return
	 */
	public static CSVWriter getCSVWriter(OutputStream out, boolean includeBOM) {
	    return new CSVWriter(StreamUtil.getPrintWriterUTF8(out, includeBOM));
	}
	
	/**
	 * 
	 * @param is
	 * @return CSV Reader
	 */
	public static CSVReader getCSVReader(InputStream is) {
		BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
	    return new CSVReader(br);
	}
}
