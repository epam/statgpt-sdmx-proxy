package io.sdmx.utils.core.application;

import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * Enables services to know if they are being run by a system process, in which case 
 * certain security rules may not apply
 */
public class SystemSecurity {
	private static SystemSecurity INSTANCE = new SystemSecurity();
	
	private static boolean isApplicationStarted;
	
	private SystemSecurity() {}

	public static void setApplicationStarted(boolean bool) {
		isApplicationStarted = bool;
	}
	
	public static boolean isSystemProcess() {
		if(isApplicationStarted == false) {
			return true;
		}
		SYSPROC sysproc = (SYSPROC)ThreadLocalUtil.retrieveFromThread(SYSPROC.class.getName());
		return sysproc != null;
	}
	
	public static void setSystemProcess() {
		synchronized(INSTANCE) {
			SYSPROC sysproc = (SYSPROC)ThreadLocalUtil.retrieveFromThread(SYSPROC.class.getName());
			if(sysproc == null) {
				sysproc = INSTANCE.createSystemProcess();
				ThreadLocalUtil.storeOnThread(SYSPROC.class.getName(), sysproc);
			}
			sysproc.processCount++;
		}
	}
	
	public static void clearSystemProcess() {
		synchronized(INSTANCE) {
			SYSPROC sysproc = (SYSPROC)ThreadLocalUtil.retrieveFromThread(SYSPROC.class.getName());
			if(sysproc != null) {
				sysproc.processCount--;
				if(sysproc.processCount <= 0) {
					ThreadLocalUtil.clearFromThread(SYSPROC.class.getName());
				}
			}
		}
	}
	
	private SYSPROC createSystemProcess() {
		return new SYSPROC();
	}
	
	/**
	 * System process, containing count of number of sub-processes
	 */
	private class SYSPROC {
		private int processCount = 0;
	}
}

