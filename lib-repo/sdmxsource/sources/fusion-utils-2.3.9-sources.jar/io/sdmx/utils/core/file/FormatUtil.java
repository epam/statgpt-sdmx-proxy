package io.sdmx.utils.core.file;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.StringUtil;
import io.sdmx.utils.core.xlsx.XLSXUtil;
import io.sdmx.utils.core.xml.XmlUtils;

public class FormatUtil {

	/**
	 * Determines the file format based on the content
	 * @param rdl
	 * @return
	 */
	public static FILE_FORMAT determineFileFormat(ReadableDataLocation rdl) {
		if(rdl == null) {
			return null;
		}

		if (StreamUtil.isEmpty(rdl)) {
			return FILE_FORMAT.EMPTY;
		}

		if(ZipUtil.isAZip(rdl)) {
		    return FILE_FORMAT.ZIP;
		}

		if(XLSXUtil.isXlsx(rdl)) {
		    return FILE_FORMAT.XLSX;
		}

//		String fileName = rdl.getName();
//
//		FILE_FORMAT postFixFormat = null;
//		if(fileName != null && fileName.contains(".")) {
//			String postFix = fileName.substring(fileName.lastIndexOf(".")+1);
//			postFixFormat = FILE_FORMAT.valueOf(postFix);
//		}
		if(XmlUtils.isXML(rdl)) {
			return FILE_FORMAT.XML;
		}
		boolean wasAlreadyDisabled = SdmxException.isDisabledExceptionTrace();
		String firstXChars = null;
		InputStream stream = null;
		try {
			stream = rdl.getInputStream();
			firstXChars = new String(StreamUtil.readFirstXBytes(stream, 100));
		} finally {
			StreamUtil.closeStream(stream);
			SdmxException.disableExceptionTrace(wasAlreadyDisabled);
		}
		firstXChars = StringUtil.trim(firstXChars).toUpperCase(); //remove any leading or training whitespace
		if(isEDI(firstXChars)) {
			return FILE_FORMAT.EDI;
		}
		if(isJson(firstXChars)) {
			return FILE_FORMAT.JSON;
		}
		if(isHtml(firstXChars)) {
			return FILE_FORMAT.HTML;
		}
		if(isCSV(firstXChars, rdl)) {
			return FILE_FORMAT.CSV;
		}
		if(isMultipart(firstXChars, rdl)) {
			return FILE_FORMAT.MULTIPART;
		}

		if(isGZIP(firstXChars, rdl)){
			return FILE_FORMAT.GZIP;
		}

		return FILE_FORMAT.TEXT;
	}

	/**
	 * Determines if this is a multipart file, the first line is expected to lead with a double dash
	 * followed by the boundary name.  The next lines are the HttpHeader details, with a blank line, followed by the data
	 *
	 * This tests for a double dash, if that exists it will look for a line which starts with Content-Disposition
	 *
	 * <pre>
	 * --fusionboundary
	   Content-Type: text/csv
	   Content-Disposition: form-data; name= out; filename=out.csv
	 * </pre>
	 *
	 * @param firstXChars An uppercase value of the first few characters of the file
	 * @param first2Rows
	 * @return
	 */
	private static boolean isMultipart(String firstXChars, ReadableDataLocation rdl) {
		if (firstXChars != null) {
			if (firstXChars.startsWith("--")) {
				String[] lines = StringUtil.splitOnLineBreaks(firstXChars);
				for(int i =0; i < lines.length; i++) {
					if(lines[i].trim().startsWith("CONTENT-DISPOSITION")) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Determines if this is a CSV file by the following logic:
	 * - If the first word (supplied in the parameter 'firstXChars') is 'DATAFLOW' it is SDMX CSV 1.0.
	 * * If the first word (supplied in the parameter 'firstXChars') is 'STRUCTURE' it is SDMX CSV 2.0.
	 * - If the lines of the file (within the parameter rdl) can be split on a delimiter and return the same number of
	 * components, then CSV is assumed
	 * @param firstXChars An uppercase value of the first few characters of the file
	 * @param first2Rows
	 * @return
	 */
	private static boolean isCSV(String firstXChars, ReadableDataLocation rdl) {
		if (firstXChars != null) {
			if (firstXChars.startsWith("DATAFLOW") || (firstXChars.startsWith("STRUCTURE"))) {
				return true;
			}
		}
		// This file does not contain the SDMX 1.0 or 2.0 identifiers so analyse the delimiters to determine if it CSV
		return getCSVDelimiter(rdl) != null;
	}

	private static boolean isGZIP(String firstXChars, ReadableDataLocation rdl) {
		if (firstXChars != null) {
			//GZIP streams start with a 'magic number' consisting of the two hex values 0x1F and 0x8B.
			return firstXChars.startsWith(new String(new byte[]{0x1F, ((byte) 0x8B)}));
		}
		return false;
	}

	/**
	 * Checks the rows passed in to see if they can be split on a delimiter and return the same number of
	 * components, if it can, CSV is assumed
	 * @param first2Rows
	 * @return
	 */
	private static DELIMITER getCSVDelimiter(ReadableDataLocation rdl) {
		for(DELIMITER currentDelimiter : DELIMITER.values()) {
			try {
				if(isSameSplitSize(rdl.getInputStream(), currentDelimiter.getDelimiter())) {
					return currentDelimiter;
				}
			} catch(Throwable th) {
				//Nope
			}
		}
		return null;
	}

	/**
	 * Evaluates a CSV file to ensure that each line has the same number of elements as determined by the separator.
	 * If there is less than 2 lines, false is returned.
	 * @param is
	 * @param separator
	 * @return
	 */
	private static boolean isSameSplitSize(InputStream is, char separator) {
		Reader streamReader = new InputStreamReader(is);
		int size = -1;
		int row = 0;
		CSVParser parser = new CSVParserBuilder().withSeparator(separator).build();
		try(CSVReader csvReader = new CSVReaderBuilder(streamReader).withCSVParser(parser).build()) {

			while(row < 3) {
				String[] nextLine = csvReader.readNext();
				if (nextLine == null) {
					// Finished reading the file
					break;
				}
				int rowSize = nextLine.length;
				if(size == -1) {
					size = rowSize;
				}
				if(rowSize != size) {
					return false;
				}
				row++;
			}
		} catch (IOException | CsvValidationException e) {
			StreamUtil.closeStream(is);
		}
		if (row < 2) {
			return false;
		}
		return size > 1;
	}

	private static boolean isHtml(String firstXChars) {
		return firstXChars.contains("<HTML") ||
				firstXChars.contains("<!DOCTYPE HTML");
	}

	private static boolean isEDI(String firstXChars) {
		return firstXChars.startsWith("UNA");
	}

	
	/**
	 * Returns whether the supplied string (which is a Snippet of JSON and not a complete JSON string) is valid JSON or not.
	 * Important note: this method is not an exhaustive test of whether the String supplied is legal JSON. There are a number of cases which will return false
	 * from this method, but are not legal JSON. This method tries to determine if the JSON snippet is valid with respect to our use within this class.
	 * <p>
	 * Examples of valid JSON which will return false:
	 * <pre>
	 *   "[]",		// Empty array
	 *   "{true}",	// A true object
	 *   "[1,2,3]",	// Array of numbers
	 *   "[-1,2.5,3e4]",	// more complex array of numbers
	 *   "[null]"	// Null object
	 * </pre>
	 * @param firstXChars
	 * @return
	 */
	private static boolean isJson(String firstXChars) {
		if (firstXChars == null || firstXChars.length() == 0) {
			return false;
		}
		
		// Input string is already trimmed and upper-cased. However strip all remaining spaces, tabs and carriage-returns
		String condensedStr = firstXChars.replaceAll("\\s+", "");
		
		if (condensedStr.length() == 0) {
			// No JSON characters present. Assume not-JSON but the case of many tabs, carriage returns, etc. preceding
			// the JSON this would give a false negative.
			return false;
		}
		
		for (int i=0; i < condensedStr.length(); i++) {
			char nextChar = condensedStr.charAt(i);
			if (nextChar == '[') {
				// Valid so far, but check the next character
				continue;
			}
			if (nextChar == '{') {
				// The start of an object. This must be followed by either a close of the object or a double-quote
				if (i+1 >= condensedStr.length()) {
					// Assume the snippet wasn't long enough and this is JSON
					return true;
				}
				char followingChar = condensedStr.charAt(i+1);
				if (followingChar == '}') {
					// The end of an empty object. Skip the end object and continue.
					i++;
					continue;
				}
				if (followingChar == '"') {
					// The start of a key field in JSON. Assume what we have so far is valid JSON
					return true;
				}
				// Something other than } or " was following the opening brace. It's invalid
				return false;
			}
			return false;
		}
		
		return true;
	}
}
