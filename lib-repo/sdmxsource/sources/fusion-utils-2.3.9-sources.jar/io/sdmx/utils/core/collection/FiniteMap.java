package io.sdmx.utils.core.collection;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.sdmx.api.notification.Listener;

/**
 * A Finite Map is a HashMap with the added functionality that it evicts objects
 * periodically.  The eviction time is given to the constructor of this object
 * and periodically the elements of this map are checked, and evicted if the
 * last time the object was accessed is longer then the eviction time.
 * <p/>
 * If the get method is called, the object's last access time is updated, all other
 * method calls do not update the last accessed time
 *
 * @param <K>
 * @param <V>
 * @deprecated not thread safe, use com.github.benmanes.caffeine.cache.Caffeine, see DataLoadManagerImpl
 */
@Deprecated
public class FiniteMap<K, V> extends HashMap<K, V> {
	private static final long serialVersionUID = 1L;
	private int lifetimeMills;
	private static int i = 0;

	private Listener<V>[] listeners;


	private Map<Key, Object> lastAccessedMap = new TreeMap<>();
	
	private Thread t; //cache reset

	public FiniteMap(int lifeTime, Listener<V>... listeners ) {
		lifetimeMills = lifeTime;
		this.listeners = listeners;
		
		startResetThread();
	}

	public FiniteMap(int lifeTime) {
		this(lifeTime, null);
	}
	
	private void startResetThread() {
		t = new Thread(new CacheReseter());
		t.setDaemon(true);
		t.start();
	}
	
	/**
	 * Stops the reset action
	 */
	public void stop() {
		Thread that = t;
		t = null;
		if(that != null) {
			that.interrupt();
		}
	}

	@Override
	public V get(Object key) {
		V returnObj =  super.get(key);
		if(returnObj != null) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(key);
				lastAccessedMap.put(new Key(returnObj), key);
			}
		}
		return returnObj;
	}

	@Override
	public V put(K key, V value) {
		if(key != null && value != null) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(key);
				lastAccessedMap.put(new Key(value), key);
			}
		}
		return super.put(key, value);
	}

	@Override
	public V remove(Object key) {
		synchronized(lastAccessedMap) {
			lastAccessedMap.values().remove(key);
		}
		return super.remove(key);
	}

	private void filterMap() {
		Set<Key> removeSet = new HashSet<>();
		long currentTime = new Date().getTime();
		long evictionTime = currentTime - lifetimeMills;
		synchronized(lastAccessedMap) {
			for(Key currentKey : lastAccessedMap.keySet()) {
				if(currentKey.getTime() < evictionTime) {
					removeSet.add(currentKey);
				} else {
					break;
				}
			}
			for(Key currentKey : removeSet) {
				Object o = lastAccessedMap.get(currentKey);
				if(listeners != null) {
					for(Listener<V> listener : listeners) {
						listener.invoke(currentKey.value);
					}
				}
				remove(o);
			}
		}
	}


	/**
	 * Resets the metadata and/or structrualMetadata cache depending on the cache settings
	 */
	private class CacheReseter implements Runnable {
		
		@Override
		public void run() {
			while(t == Thread.currentThread()) {
				filterMap();
				try {
					Thread.sleep(lifetimeMills/2);
				} catch (InterruptedException ie) {
					Thread.currentThread().interrupt();
					if(t != null) {
						//thread was unexpectedly interrupted
						startResetThread(); //Start a new thread
					}
				}
			}
		}
	}

	private class Key implements Comparable<Key> {
		private int num;
		private long time;
		private V value;

		Key(V value) {
			this.value = value;
			time = new Date().getTime();
			num = FiniteMap.i++;
		}

		public V getValue() {
			return value;
		}

		long getTime() {
			return time;
		}

		@Override
        public boolean equals(Object obj) {
            if (obj instanceof FiniteMap.Key) {
                Key that = (FiniteMap.Key)obj;
                return this.num == that.num;
            }
            return false;
        }

		@Override
        public int hashCode() {
			return num;
		}

		@Override
		public int compareTo(Key that) {
			return this.num - that.num;
		}
	}
}
