package io.sdmx.utils.core.io;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class InMemoryReadableDataLocation extends AbstractReadableDataLocation {
	private static final long serialVersionUID = 971633373372917354L;
	private byte[] bytes;
	private String name;

	public InMemoryReadableDataLocation(InputStream stream) {
		this.bytes = StreamUtil.toByteArray(stream);
	}

	public InMemoryReadableDataLocation(byte[] bytes) {
		this(bytes, null);
	}

	public InMemoryReadableDataLocation(byte[] bytes, String name) {
		this.bytes = bytes;
		this.name = name;
	}

	public InMemoryReadableDataLocation(String uriStr) {
		if(uriStr == null) {
			throw new IllegalArgumentException("Can not create StreamSourceData - uriStr can not be null");
		}
		name = uriStr;
		try {
			URI uri = new URI(uriStr);
			if(uri.isAbsolute()) {
				if(!uri.getScheme().equals("file")) {
					URL url = uri.toURL();
					bytes = StreamUtil.toByteArray(URLUtil.getInputStream(url));
				} else {
					bytes = URIUtil.getByteArray(uri);
					//FileUtil.readFileAsString(uri.getPath()).getBytes();
				}
			} else {
				bytes = StreamUtil.toByteArray(URIUtil.getInputStream(uri));
			}
		} catch (URISyntaxException e) {
			throw new RuntimeException(e);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String getName() {
		return name;
	}


    @Override
    protected long calculateSize() {
        if (bytes == null) {
            return 0;
        }
        return bytes.length;
    }
    
	@Override
	protected InputStream getStreamInternal() throws IOException {
		if (bytes == null) {
			return new ByteArrayInputStream(new byte[0]);
		}
		return new ByteArrayInputStream(bytes);
	}

	@Override
	protected void closeInternal() {
		this.bytes = null;
	}

	@Override
	public InMemoryReadableDataLocation copy() {
		return new InMemoryReadableDataLocation(bytes, name);
	}

}