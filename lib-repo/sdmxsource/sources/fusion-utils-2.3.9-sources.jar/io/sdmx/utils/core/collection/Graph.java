package io.sdmx.utils.core.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.process.IVisitor;

/**
 * Converts a map of Objects<T> that reference a set of Objects<T> into a hierarchical tree of GraphNode. 
 * Each GraphNode contains one Object<T> zero to many references to child Objects<T> and zero to may parent Objects<T>.
 * The root GraphNode are not referenced by any other Object<T>
 * @param <T>
 */
public class Graph<T> {
	private List<GraphNode<T>> rootElements = new ArrayList<>();
	
	/**
	 * Creates a Graph from the given map which represents Parent to a Set of Children
	 * @param asMap
	 */
	public Graph(Map<T, Set<T>> asMap) {
		this(asMap, false);
	}
	
	/**
	 * Creates a Graph from the given map which represents Parent to a Set of Children
	 * @param asMap
	 */
	public Graph(Map<T, Set<T>> asMap, boolean preserveOrder) {
		Map<T, GraphNode<T>> allElements = preserveOrder ? new LinkedHashMap<>() : new HashMap<>();
		for(T el : asMap.keySet()) {
			addGraphNode(el, asMap.get(el), allElements);
		}
		for(T currentElement : allElements.keySet()) {
			GraphNode<T> currentNode = allElements.get(currentElement);
			if(currentNode.getParents().size() == 0) {
				rootElements.add(currentNode);
			}
		}
		rootElements = Collections.unmodifiableList(rootElements);
	}

	/**
	 * Calls the Visitors visit method for each Object<T> in this graph.  
	 * The Graph is walked in a specific order, so that the Object<T> is only passed to the Visitor
	 * once all of its ancestors have been passed to the Visitor.    
	 * 
	 * @param visitor
	 */
	public void visit(IVisitor<T> visitor) {
		if(visitor == null) {
			return;
		}
		visit(visitor, rootElements, new HashSet<>());
	}
	
	private void visit(IVisitor<T> visitor, List<GraphNode<T>> elements, Set<GraphNode<T>> visited) {
		for(GraphNode<T> el : elements) {
			if(visited.contains(el)) {
				continue;
			}
			if(!visited.containsAll(el.getParents())) {
				visit(visitor, el.getParents(), visited);
			}
			visitor.visit(el.getElement());
			visited.add(el);
			visit(visitor, el.getChildren(), visited);
		}
	}
	
	public void addGraphNode(T el, Collection<T> children, Map<T, GraphNode<T>> allElements) {
		GraphNode<T> node = getGraphNode(el, allElements);
		if(children != null) {
			for(T child : children) {
				node.addChild(getGraphNode(child, allElements));
			}
		}
	}
	
	private GraphNode<T> getGraphNode(T el, Map<T, GraphNode<T>> allElements) {
		GraphNode<T> node = allElements.get(el);
		if(node == null) {
			node = new GraphNode<T> (el);
			allElements.put(el, node);
		}
		return node;
	}

	public List<GraphNode<T>> getRootElements() {
		return rootElements;
	}
}
