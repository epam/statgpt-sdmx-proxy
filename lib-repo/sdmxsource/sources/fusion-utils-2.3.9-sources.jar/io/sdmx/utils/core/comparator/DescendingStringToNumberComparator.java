package io.sdmx.utils.core.comparator;

import java.util.Comparator;

/**
 * A Comparator that compares string versions of numbers and returns the Strings in their numerical order but descending.
 * e.g. The strings "1.1", "1.0", "9", "9999", "10", "55.1", "55.01", "55.5", "1", "5", "55" would return as 
 * 9999, 55.5, 55.1, 55.01, 55, 10, 9, 5, 1.1, 1.0
 * TODO what about numerics in this list
 */
public class DescendingStringToNumberComparator implements Comparator<String> {
	 @Override
	 public int compare(String o1, String o2) {
		 if (o1 == null && o2 == null) {
			 return 0;
		 }
		 if (o2 == null) {
			 return 1;
		 }
		 if (o1 == null) {
			 return -1;
		 }
		 Double val1;
		 try {
			 val1 = Double.parseDouble(o1);
		 } catch (Exception e) {
			 return 1;
		 }
		 Double val2;
		 try {
			 val2 = Double.parseDouble(o2);
		 } catch (Exception e) {
			 return -1;
		 }
		 
         int res = val1.compareTo(val2);
         if (res == 0) {
        	 // Values are the same. Just ensure that the lengths are the same
			 return o2.length() - o1.length();
         } else {
        	 return -1 * res;  // Multiply by -1 since its a descending list. 
         }
	 }
}