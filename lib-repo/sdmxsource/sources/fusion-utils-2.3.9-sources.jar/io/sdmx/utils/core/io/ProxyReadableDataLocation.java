package io.sdmx.utils.core.io;

import java.io.InputStream;
import java.nio.file.Path;
import java.util.List;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;

/**
 * A proxy on an existing RDL
 */
public abstract class ProxyReadableDataLocation implements ReadableDataLocation {
	private static final long serialVersionUID = 1L;
	private ReadableDataLocation proxy;

	public ProxyReadableDataLocation(ReadableDataLocation proxy) {
		this.proxy = proxy;
	}

	@Override
	public FILE_FORMAT getFormat() {
		return proxy.getFormat();
	}

	@Override
	public InputStream getInputStream() {
		return proxy.getInputStream();
	}

	@Override
	public String getName() {
		return proxy.getName();
	}
	
	@Override
    public ReadableDataLocation move(Path moveTo) {
        return proxy.move(moveTo);
    }

    @Override
    public long getSize() {
        return proxy.getSize();
    }

    @Override
	public void close() {
		proxy.close();
	}

	@Override
	public boolean isClosed() {
		return proxy.isClosed();
	}

	@Override
	public ReadableDataLocation copy() {
		return proxy.copy();
	}

	@Override
	public boolean isProtected() {
		return proxy.isProtected();
	}

	@Override
	public void setProtected(boolean protect) {
		proxy.setProtected(protect);
	}
	
	@Override
    public boolean splitable() {
        return proxy.splitable();
    }

    @Override
    public List<ReadableDataLocation> split(boolean closeSource) {
        return proxy.split(closeSource);
    }
}
