package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.ReadableDataLocationFactory;

public class SdmxSourceReadableDataLocationFactory implements ReadableDataLocationFactory {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxSourceReadableDataLocationFactory.class);
	private Long maxMemory = (1024l* 1024l * 30l);  //DEFAULT to 30Mb in memory
	private Long memoryUseage = 0l;

	class OverflowReadableDataLocation extends AbstractReadableDataLocation {
		private static final long serialVersionUID = -8299140445772552916L;
		private byte[] bytes;
		private URI uri;
		private boolean deleteOnClose;

		private OverflowReadableDataLocation(byte[] bytes) {
			this.bytes = bytes;
		}

		private OverflowReadableDataLocation(URI uri, boolean deleteOnClose) {
			this.uri = uri;
			this.deleteOnClose = deleteOnClose;
		}

		@Override
		public String getName() {
			return null;
		}
		
		@Override
		protected void closeInternal() {
			if(bytes != null) {
				memoryUseage -= bytes.length;
				bytes = null;
			} else if(uri != null ){
				URIUtil.closeUri(uri);
				if(deleteOnClose) {
					URIUtil.deleteUri(uri);
				}
			}
		}

		@Override
		protected InputStream getStreamInternal() throws IOException {
			if(bytes != null) {
				return new BufferedInputStream(new ByteArrayInputStream(bytes));
			}
			return URIUtil.getInputStream(uri);
		}

		@Override
		public OverflowReadableDataLocation copy() {
			if (uri != null) {
				URI uriCopy = uri;
				if(deleteOnClose) {
					uriCopy = URIUtil.getTemporaryURI();
					URIUtil.copyURIs(uri, uriCopy);
				}
				return new OverflowReadableDataLocation(uriCopy, this.deleteOnClose);
			}
			return new OverflowReadableDataLocation(bytes);
		}

        @Override
        protected long calculateSize() {
            if (uri != null) {
                return URIUtil.getFile(uri).length();
            }
            return bytes.length;
        }
	}

	@Override
	public ReadableDataLocation getReadableDataLocation(String uriStr) {
		if(uriStr == null) {
			throw new IllegalArgumentException("Can not create StreamSourceData - uriStr can not be null");
		}
		try {
			URI uri = new URI(uriStr);
			if(uri.isAbsolute()) {
				if(!uri.getScheme().equals("file")) {
					URL url = uri.toURL();
					InputStream is = URLUtil.getInputStream(url);
					return getReadableDataLocation(is);
				} else {
					File f = URIUtil.getFile(uri);
					if(!f.exists()) {
						throw new IllegalArgumentException("Can not read stream, file does not exist: " +uriStr);
					}
				}
			}
			return new OverflowReadableDataLocation(uri, false);
		} catch (URISyntaxException e) {
			throw new RuntimeException(e);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}


	@Override
	public ReadableDataLocation getReadableDataLocation(byte[] bytes) {
		return new OverflowReadableDataLocation(bytes);
	}

	@Override
	public ReadableDataLocation getReadableDataLocation(File file) {
		if(file == null) {
			throw new IllegalArgumentException("Can not create StreamSourceData - file can not be null");
		}

		if(FileUtil.getFileSize(file) > (maxMemory - memoryUseage)) {
			return new OverflowReadableDataLocation(file.toURI(), false);
		}
		try {
			return getReadableDataLocation(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public ReadableDataLocation getReadableDataLocation(URL url) {
		if(url == null) {
			throw new IllegalArgumentException("Can not create StreamSourceData - url can not be null");
		}
		InputStream is = URLUtil.getInputStream(url);
		return getReadableDataLocation(is);
	}

	@Override
	public ReadableDataLocation getReadableDataLocation(URI uri) {
		if(uri == null) {
			throw new IllegalArgumentException("Can not create StreamSourceData - uri can not be null");
		}
		return getReadableDataLocation(URIUtil.getInputStream(uri));
	}

	@Override
	public ReadableDataLocation getReadableDataLocation(InputStream is) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(out);

		boolean completedRead = false;
		if(memoryUseage < maxMemory) {
			completedRead = true;
			try {
				byte[] bytes = new byte[1024];
				int i;
				while((i = is.read(bytes)) > 0) {
					bos.write(bytes, 0, i);
					memoryUseage += i;
					if(memoryUseage > maxMemory) {
						completedRead = false;
						break;
					}
				}
				bos.flush();
			} catch(IOException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		if(completedRead) {
			StreamUtil.closeStream(is);
			return new OverflowReadableDataLocation(out.toByteArray());
		}
		LOG.info("Limit hit on getting ReadableDataLocation, overflow to tmp URI");

		//THE READ WAS NOT COMPLETE (MEMORY LIMITS HIT) - COPY THE STREAM TO A FILE
		URI uri = URIUtil.getTemporaryURI();

		LOG.debug("URI: " + uri.toString());

		OutputStream tmpOut = URIUtil.getOutputStream(uri);
		bos=new BufferedOutputStream(tmpOut);

		if(out.size() > 0) {
			//Write to file system
			StreamUtil.copyStream(new ByteArrayInputStream(out.toByteArray()), bos, false);
			memoryUseage -= out.size();
			out = null;
		}

		try {
			StreamUtil.copyStream(is, bos, false);
		} finally {
			StreamUtil.closeStream(is);
			StreamUtil.closeStream(bos);
		}
		return new OverflowReadableDataLocation(uri, true);
	}

	public Long getMemoryUseageBytes() {
		return memoryUseage;
	}

	public void setMaxMemoryKb(int maxMemory) {
		this.maxMemory = Long.valueOf(maxMemory) * 1024l;
	}

}