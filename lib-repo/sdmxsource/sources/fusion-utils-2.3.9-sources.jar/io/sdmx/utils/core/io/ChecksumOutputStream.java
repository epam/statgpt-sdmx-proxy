package io.sdmx.utils.core.io;

import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public class ChecksumOutputStream extends FastOutputStreamProxy {
	private  MessageDigest digest;
	private String checksum = null;

	public ChecksumOutputStream(OutputStream finalOut) {
		super(finalOut, 8192);
		try {
			// Initialize the MessageDigest with SHA-256 algorithm
			digest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	protected boolean bufferFlush(byte[] b, int off, int len) {
		digest.update(b, off, len);
		return true;
	}

	public String getChecksum() {
		if(this.checksum == null) {
			this.checksum = HexFormat.of().formatHex(digest.digest());
		}
		return this.checksum;
	}
}
