package io.sdmx.utils.core.reflection;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Simple proxy to override for method interception
 * @author Metadata Technology
 *
 */

public abstract class AbstractObjectProxy implements InvocationHandler {
    private ProxyTarget proxyTarget;
    
    
    public AbstractObjectProxy(Object target) {
        this.proxyTarget = new ProxyTarget(target);
    }

    protected void setTarget(Object newTarget) {
        this.proxyTarget = new ProxyTarget(newTarget);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args)  throws Throwable {
        ProxyTarget proxyTarget = getTarget();
        String methodName = method.toGenericString();
        Object target = proxyTarget.target;
        Method m = proxyTarget.methods.get(methodName);
        m = m == null ? method : m;
        try {
           return m.invoke(target, args);
        } catch(InvocationTargetException e) {
            throw e.getCause();
        }
    }
    
    protected ProxyTarget getTarget() {
        return this.proxyTarget;
    }
    
    protected class ProxyTarget {
        private Map<String, Method> methods = new HashMap<>();
        protected Object target;
        
        public ProxyTarget(Object target) {
            this.target = target;
            Map<String, Method> methods = new HashMap<>();
            for(Method method: target.getClass().getDeclaredMethods()) {
                method.setAccessible(true); // exactly the same as with the field
                String methodName = method.toGenericString();
                methods.put(methodName, method);
            }
            this.methods = methods;
        }

        public synchronized Map<String, Method> getMethods() {
            return methods;
        }

        public synchronized Object getTarget() {
            return target;
        }
    }
    
  }