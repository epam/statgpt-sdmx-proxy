package io.sdmx.utils.core.version;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

/**
 * Utility class providing helper methods to determine if a String is a valid version.
 */
public class VersionableUtil {

	/**
	 * Returns if a version String is a valid version number for the Registry.
	 * @param version the String to check validity of
	 * @return true if the version is valid for the registry
	 */
	public static boolean validVersion(String version) {
		if (version == null || version.length() == 0) {
			return false;
		}
		try {
			verifyVersion(version);
		} catch (Throwable th) {
			return false;
		}
		return true;
	}

	
	private static final Pattern VERSION_PATTERN = Pattern.compile("[0-9]+(?:\\.[0-9]+)*");
	
	/**
	 * Verifies a version is in the correct format.
	 * The accepted format is a positive integer followed by zero or more sub-values, where a sub-value is
	 * a period (.) followed by a positive integer. There may only be 10 characters in total.
	 * Examples of legal values: 1 , 1.1 , 1.2.3.4.5  123.1224.
	 * <p/>
	 * An IllegalArgumentException is thrown if the String argument cannot be represented as a number.
	 *
	 * @param version The string representation of the version
	 * @throws IllegalArgumentException If an illegal value was supplied
	 */
	private static void verifyVersion(String version) {
		if (version == null) {
			throw new IllegalArgumentException("Null version supplied.");
		}

		if (version.equals("*")) {
			return;
		}

		Matcher m = VERSION_PATTERN.matcher(version);
		if(!m.matches()) {
			boolean wasDisabled  = SdmxSemmanticException.isDisabledExceptionTrace();
			if(version.equalsIgnoreCase("$version$")){
				SdmxSemmanticException.disableExceptionTrace(true);
			}
			SdmxSemmanticException exception = new SdmxSemmanticException("Illegal in version supplied '"+version+"'");
			SdmxSemmanticException.disableExceptionTrace(wasDisabled);
			throw exception;
		}
	}

	/**
	 * Formats the supplied version String.
	 *
	 * @param version The version string to format.
	 * @return The formatted version of the input.
	 */
	public static String formatVersion(String version) {
		version = StringUtil.cleanString(version);
		if (version == null) {
			return null;
		}
		if (version.contains("+")) {
			StringBuilder formatted = new StringBuilder();
			String concat = "";
			for(String currentVersion: version.split("\\+")) {
				formatted.append(concat + formatVersion(currentVersion));
				concat = "+";
			}
			return formatted.toString();
		}
		if (version.equals("*")) {
			return version;
		}
		if(!ObjectUtil.validString(version)) {
			version = "1.0";
		}
		// Check the version BEFORE appending on any required decimal places
		verifyVersion(version);

		// Now add the decimal places (if required)
		if(!version.contains(".")) {
			version += ".0";
		} else if(version.endsWith(".")) {
			version += "0";
		}
		return version;
	}

    /**
     * Returns true if version1 has a higher version then version2
     * @param version1 a String representing a valid version
     * @param version2 a String representing a valid version
     * @return true if version1 has a higher version then version2
     */
    public static boolean isHigherVersion(String version1, String version2) {
    	verifyVersion(version1);
    	verifyVersion(version2);

    	String[] v1Comps = version1.split("\\.");
    	String[] v2Comps = version2.split("\\.");
    	int limit = (v1Comps.length > v2Comps.length) ? v2Comps.length : v1Comps.length;

    	for(int i=0;i < limit; i++){
    	    BigDecimal part1int = new BigDecimal(v1Comps[i]);
    		BigDecimal part2int = new BigDecimal(v2Comps[i]);
    		int compare = part1int.compareTo(part2int);
			if (compare!=0) {
			    return compare > 0;
			}
    	}
    	return v1Comps.length > v2Comps.length;
    }

    /**
     * Test that one version is higher than another but account for the 4th "part" of the number being the beta version.
     * Given the version 1.2.3.4, the 4th part indicates that this version is the 4th beta version of version 1.2.3
     * Thus 1.2.3 is HIGHER than 1.2.3.4
     * In the same way, version 1 is higher than 1.0.0.32  (the 32nd beta of version 1)
     *
     * @param version1
     * @param version2
     * @return
     */
    public static boolean isHigherVersionWithBetaProvision(String version1, String version2) {
    	verifyVersion(version1);
    	verifyVersion(version2);

    	String[] v1Comps = version1.split("\\.");
    	String[] v2Comps = version2.split("\\.");

    	// Both are less than length 4, so treat as usual
    	if ((v1Comps.length < 4 && v2Comps.length < 4)) {
    		return isHigherVersion(version1, version2);
    	}

    	// Ensure neither is greater than 4 characters
    	if (v1Comps.length > 4) {
    	    throw new IllegalArgumentException("Only 4 part values may be supplied. The supplied argument: " + version1 + " has more than 4 parts");
    	}

    	if (v2Comps.length > 4) {
    	    throw new IllegalArgumentException("Only 4 part values may be supplied. The supplied argument: " + version2 + " has more than 4 parts");
        }

    	// At least one of the inputs has a 4th part.
    	// If a number isn't 3 at least 3 elements long, "pad" it with zeroes.
    	/// E.g. When comparing 9 to 9.0.0.123, need to pad 9 to 9.0.0
    	if (v1Comps.length < 4) {
    	    String[] newArr = new String[3];
    	    for (int i = 0; i < 3; i++) {
    	        newArr[i] = i < v1Comps.length ? v1Comps[i] : "0";
    	    }
    	    v1Comps = newArr;
    	}

    	if (v2Comps.length < 4) {
            String[] newArr = new String[3];
            for (int i = 0; i < 3; i++) {
                newArr[i] = i < v2Comps.length ? v2Comps[i] : "0";
            }
            v2Comps = newArr;
        }

    	// Compare the first 3 elements without using the 4th "beta" part
    	for (int i=0; i < 3; i++){
            BigDecimal part1int = new BigDecimal(v1Comps[i]);
            BigDecimal part2int = new BigDecimal(v2Comps[i]);
            int compare = part1int.compareTo(part2int);
            if (compare != 0) {
                return compare > 0;
            }
        }

    	// First 3 parts are the same at this point (e.g. 1.2.3.99 and 1.2.3.45), result is now dependant on 4th part.
    	if (v1Comps.length  != 4) {
    	    // No 4th part, so v1 is Higher as it doesn't have a beta. E.g comparing "1.2.3" with "1.2.3.4" - the latter is a beta of version 1.2.3
    	    return true;
    	}
    	if (v2Comps.length  != 4) {
            // No 4th part, so v2 is Higher as it doesn't have a beta. E.g comparing "1.2.3.4" with "1.2.3" - the former is a beta of version 1.2.3
    	    return false;
        }

    	BigDecimal lastPart1int = new BigDecimal(v1Comps[3]);
        BigDecimal lastPart2int = new BigDecimal(v2Comps[3]);

        return lastPart1int.compareTo(lastPart2int) > 0;
    }
}
