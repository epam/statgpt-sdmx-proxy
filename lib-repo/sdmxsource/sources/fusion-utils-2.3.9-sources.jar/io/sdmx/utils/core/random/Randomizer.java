package io.sdmx.utils.core.random;

import java.security.SecureRandom;
import java.util.Random;

public class Randomizer {
	
	public synchronized static String generateRandomKey() {
		Random rand = new SecureRandom();
		return Long.toString(rand.nextLong());
	}
}
