package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.process.IProcessArgResponse;
import io.sdmx.api.process.IProcessWithArgument;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class PathUtil {
	private static Logger LOG = LoggerFactory.getLogger(PathUtil.class);

	/**
	 * @param p
	 * @return last updated timestamp on file or -1 if the file does not exist
	 */
	public static long getLastUpdated(Path p) {
		if(!Files.exists(p)) {
			return -1;
		}

		BasicFileAttributes attr;
		try {
			attr = Files.readAttributes(p, BasicFileAttributes.class);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return attr.lastModifiedTime().toMillis();
	}

	/**
	 * Returns the properties directory, which can be one of three values:
	 * 1. A specified override
	 * 2. <user.home>/MetadataTechnology/FusionNode
	 * 3. The WEB-INF directory
	 * @return
	 */
	public static Path getHomeDir(String productName, String JVMOverrideArg) {
		// Check for a user override value
		String homeDirOverride = System.getProperty(JVMOverrideArg);
		LOG.debug(JVMOverrideArg+"="+homeDirOverride);
		if (ObjectUtil.validString(homeDirOverride)) {
			LOG.info("User specified "+productName+" Home Directory of " + homeDirOverride);
			Path specifiedHomeDir = Paths.get(homeDirOverride);
			ensureDirectory(specifiedHomeDir, true);
			LOG.info("Home Directory ="+specifiedHomeDir);
			return specifiedHomeDir;
		}

		// Use <user.home>/MetadataTechnology/FusionNode
		String userHome = System.getProperty("user.home");
		if (ObjectUtil.validString(userHome)) {
			LOG.info("userHome ="+userHome);
			Path aPath = Paths.get(userHome, "MetadataTechnology", productName);
			try {
				ensureDirectory(aPath, true);
			} catch (Exception e) {
				LOG.warn(e.getMessage());
			}
		}
		throw new RuntimeException("Please specify '"+JVMOverrideArg+"' Java property");
	}

	public static  List<ReadableDataLocation> upzip(Path path) {
		ReadableDataLocation rdl = new ReadableDataLocationTmp(path);
		List<ReadableDataLocation> unzipped;
		if(ZipUtil.isAZip(rdl)) {
			try {
				unzipped = ZipUtil.unzipFiles(rdl);
			} finally {
				rdl.close();
			}
		} else {
			unzipped = new ArrayList<>();
			unzipped.add(rdl);
		}
		return unzipped;
	}

	/**
	 * Ensures the directory exists by creating it if it does not
	 * @param p
	 */
	public static Path ensureDirectory(Path p, boolean ensureWritable) {
		if (Files.notExists(p)) {
			try {
				LOG.debug("createDirectories ="+p);
				Files.createDirectories(p);
			} catch (IOException e) {
				throw new RuntimeException("Unable to create specified directory: '" + p.toString() + "'");
			}
		}
		if (!Files.isDirectory(p)) {
			throw new RuntimeException("Expected directory is not a directory: " + p.toString() + "'");
		}
		if (ensureWritable && !Files.isWritable(p)) {
			throw new RuntimeException("Directory is not writeable. '" + p.toString() + "'");
		}
		return p;
	}

	public static Long getModifiedTime(Path path) {
		try {
			return Files.getLastModifiedTime(path).toMillis();
		} catch (IOException e) {
			System.err.println("Cannot get the last modified time - " + e);
		}
		return null;
	}

	/**
	 * Lists the files under the folder, if the folder does not exist an empty list
	 * will be returned
	 * @param folder
	 * @return
	 * @throws IllegalArgumentException if the input path is not a folder
	 */
	public static List<Path> listFiles(Path folder) {
	    List<Path> files = new ArrayList<>();
	    if(!Files.exists(folder)) {
	        return Collections.emptyList();
	    }
	    if(!Files.isDirectory(folder)) {
	        throw new IllegalArgumentException("Not a directory: "+folder);
	    }
	    try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
            for (Path path : stream) {
               if(!Files.isDirectory(path)) {
                   files.add(path);
               }
            }
	    } catch (IOException e) {
            throw new RuntimeException(e);
        }
	    return files;
	}
	
	public static Path createDir(Path path) {
		if (Files.notExists(path)) {
			FileUtil.ensureDirectoryExists(path.toString());
		}
		return path;
	}

	public static void move(Path from, Path to) {
		try {
			Files.deleteIfExists(to);
			Files.move(from, to);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	/**
	 * @param path
	 * @return the byte[] contents of the file
	 */
	public static byte[] toBytes(Path path) {
		try(InputStream inputStream = toStream(path)) {
			return StreamUtil.toByteArray(inputStream);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param path
	 * @return an input stream of this file
	 */
	public static InputStream toStream(Path path) {
		if(!Files.exists(path)) {
			throw new IllegalArgumentException("Can not read file as it does not exist '"+path.toString()+"'");
		}
		if(Files.isDirectory(path)) {
			throw new IllegalArgumentException("Illegal attempt to read directory as a file '"+path.toString()+"'");
		}
 		try {
			return Files.newInputStream(path);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	/**
	 * Runs the input stream in a process and then ensures the stream is closed on completion
	 * @param <T>
	 * @param process
	 * @return
	 */
	public static void toStream(Path path, IProcessWithArgument<InputStream> process) {
		InputStream stream = PathUtil.toStream(path);
		try {
			process.runProcess(stream);
		} finally {
			StreamUtil.closeStream(stream);
		}
	}

	/**
	 * Runs the input stream in a process and then ensures the stream is closed on completion
	 * @param <T>
	 * @param process
	 * @return
	 */
	public static <T> T toStreamWithResponse(Path path, IProcessArgResponse<InputStream, T> process) {
		InputStream stream = PathUtil.toStream(path);
		try {
			return process.runProcess(stream);
		} finally {
			StreamUtil.closeStream(stream);
		}
	}

	/**
	 */
	public static void deleteFile(Path path) {
		try {
			Files.deleteIfExists(path);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Deletes the directory
	 * @param path dir to delete
	 * @param includeRoot if false, will only delete files and subfolders of path, if true the directory will also be deleted
	 */
	public static void deleteDir(Path path, boolean includeRoot) {
		new PathFolder(path, null, true).deleteContents(includeRoot);
	}

	public static void replaceFileContents(Path p, String newContents, boolean createBck) {
		if(createBck) {
			Path moveTo = p.getParent().resolve(p.toFile().getName()+".bck");
			try {
				Files.deleteIfExists(moveTo);
				Files.move(p, moveTo);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		writeFile(p, newContents.getBytes(), false);
	}

	public static void writeFile(Path p, byte[] bytes, boolean zip) {
		OutputStream out = getOutputStream(p, zip);
		StreamUtil.copyStream(new BufferedInputStream(new ByteArrayInputStream(bytes)), out, true);
	}

	public static OutputStream getOutputStream(Path p, boolean zip) {
		try {
			String fileName = p.getFileName().toString();
			if(zip) {
				p = p.getParent().resolve(p.getFileName().toString()+".zip");
			}
			createNewFile(p);
			OutputStream out = Files.newOutputStream(p);
			if(zip) {
				ZipOutputStream zout = new ZipOutputStream(out);
				zout.putNextEntry(new ZipEntry(fileName));
				out = zout;
			}
			 return new BufferedOutputStream(out);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @return the file name without the .[x] postfix, for example data.json would return data
	 */
	public static String getFileNameNoPostfix(Path p) {
		return  getFileNameNoPostfix(p.getFileName().toString());
	}

	/**
	 * @return the file name without the .[x] postfix, for example data.json would return data
	 */
	public static String getFileNameNoPostfix(String fileName) {
		int lastIndexOf = fileName.lastIndexOf(".");
		if(lastIndexOf < 0 || lastIndexOf == fileName.length()-1) {
			return fileName;
		}
		return fileName.substring(0, lastIndexOf);
	}

	/**
	 * @return the file type from the file name, i.e. if the file name is data.json the fileNameType is json
	 */
	public static String getFileNameType(Path p) {
		return  getFileNameType(p.getFileName().toString());
	}

	/**
	 * @return the file type from the file name, i.e. if the file name is data.json the fileNameType is json
	 */
	public static String getFileNameType(String fileName) {
		int lastIndexOf = fileName.lastIndexOf(".");
		if(lastIndexOf < 0 || lastIndexOf == fileName.length()-1) {
			return null;
		}
		return fileName.substring(lastIndexOf+1);
	}


	public static void writeFile(Path p, ReadableDataLocation rdl, boolean zip) {
		writeFile(p, rdl.getInputStream(), zip);
	}

	public static void writeFile(Path p, InputStream stream, boolean zip) {
		try {
			OutputStream out = getOutputStream(p, zip);
			StreamUtil.copyStream(stream, out, true);
		} finally {
			StreamUtil.closeStream(stream);
		}
	}

	/**
	 * Creates a new file, deletes the file if it already exists
	 * @param p
	 */
	public static Path createNewFile(Path p) {
		try {
			ensureDirectory(p.getParent(), true);
			Files.deleteIfExists(p);
			Files.createFile(p);
			return p;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	// zip a directory, including sub files and sub directories
	public static void zipFolder(Path source, OutputStream out)  {

		try (ZipOutputStream zos = new ZipOutputStream(out)) {
			Files.walkFileTree(source, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file,
						BasicFileAttributes attributes) {

					// only copy files, no symbolic links
					if (attributes.isSymbolicLink()) {
						return FileVisitResult.CONTINUE;
					}

					try (FileInputStream fis = new FileInputStream(file.toFile())) {

						Path targetFile = source.relativize(file);
						zos.putNextEntry(new ZipEntry(targetFile.toString()));

						byte[] buffer = new byte[1024];
						int len;
						while ((len = fis.read(buffer)) > 0) {
							zos.write(buffer, 0, len);
						}

						// if large file, throws out of memory
						//byte[] bytes = Files.readAllBytes(file);
						//zos.write(bytes, 0, bytes.length);

						zos.closeEntry();

						LOG.debug("Zip file : %s%n", file);

					} catch (IOException e) {
						e.printStackTrace();
					}
					return FileVisitResult.CONTINUE;
				}

				@Override
				public FileVisitResult visitFileFailed(Path file, IOException exc) {
					LOG.error("Unable to zip : %s%n%s%n", file, exc);
					return FileVisitResult.CONTINUE;
				}
			});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void unzipFolder(Path sourceFile, Path targetFolder) {
		try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(sourceFile.toFile()))) {

			// list files in zip
			ZipEntry zipEntry = zipInputStream.getNextEntry();

			while (zipEntry != null) {
				// Check for zip slip vulnerability attack
				Path newUnzipPath = zipSlipVulnerabilityProtect(zipEntry, targetFolder);
				LOG.debug("Unzip to " + newUnzipPath.toString());
				
				// Check if the ZipEntry is a file or a Directory
				// For modern Javas and Zip files, querying "isDirectory" should suffice.
				// If not, the file name will end with a forward slash and NOT the use of 'File.separator' which is platform specific.
				boolean isDirectory = (zipEntry.isDirectory() || zipEntry.getName().endsWith("/"));

				if (isDirectory) {
					PathUtil.ensureDirectory(newUnzipPath, true);
				} else {
					PathUtil.createNewFile(newUnzipPath);

					// copy files using nio
					Files.copy(zipInputStream, newUnzipPath, StandardCopyOption.REPLACE_EXISTING);
				}
				zipEntry = zipInputStream.getNextEntry();
			}
			zipInputStream.closeEntry();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	// Check for Zip -Slip attack
	public static Path zipSlipVulnerabilityProtect(ZipEntry zipEntry, Path targetDir)
			throws IOException {

		/**
		 * resolve(String other) method of java. nio. file.Path used to converts a given
		 * path string to a Path and resolves it against this Path in the exact same manner
		 * as specified by the resolve method
		 */
		Path dirResolved = targetDir.resolve(zipEntry.getName());
		LOG.debug("Normalise Path"+dirResolved);
		/**
		 * Normalizing a path involves modifying the string that identifies a
		 * path or file so that it conforms to a valid path on the target operating system.
		 */
		//normalize the path on target directory or else throw exception
		Path normalizePath = dirResolved.normalize();
		if (!normalizePath.startsWith(targetDir)) {
			throw new IOException("Invalid zip: " + zipEntry.getName());
		}

		return normalizePath;
	}

	/**
	 * Returns the bytes of specified length at the specified offset from the specified Path object
	 * @param path the Path object to obtain the bytes from
	 * @param startOffset the start offset to obtain the
	 * @param length the length of the bytes to return
	 * @return an array of bytes
	 * @throws IOException if there was an issue reading from the file
	 * @throws IllegalArgumentException if the startOffset value is beyond the end of the file
	 */
	public static byte[] getContentsFromOffset(Path path, long startOffset, long length) throws IOException {
		if(length == 0) {
			return new byte[0];
		}
		if (length < 0) {
            throw new IllegalArgumentException("The length must be specified as a positive integer");
        }

		try (RandomAccessFile file = new RandomAccessFile(path.toFile(), "r");
            FileChannel channel = file.getChannel()) {

           long fileSize = channel.size();
           if (startOffset >= fileSize) {
               throw new IllegalArgumentException("Start offset is beyond the end of the file");
           }

           long remainingLength = Math.min(length, fileSize - startOffset);
           ByteBuffer buffer = ByteBuffer.allocate((int)remainingLength);

           channel.position(startOffset);
           channel.read(buffer);
           buffer.flip();

           byte[] result = new byte[buffer.remaining()];
           buffer.get(result);
           return result;
       }
	}
}
