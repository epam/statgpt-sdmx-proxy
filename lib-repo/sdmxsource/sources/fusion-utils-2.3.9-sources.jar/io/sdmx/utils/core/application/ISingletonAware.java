package io.sdmx.utils.core.application;

public interface ISingletonAware<T> {

	void setSingleton(T singleton);
	
}
