package io.sdmx.utils.core.timer;

public abstract class TimeoutRequest<T> {
	
	protected abstract T runRequest();
	
	public final T runRequest(int timeoutMillis) {
		RequestRunner runner = new RequestRunner();
		Thread t = new Thread(runner);
		
		t.start();
		int i =0;
		int sleepMillis = 500;
		while(!runner.hasResponse()) {
			if(runner.isError()) {
				throw new RuntimeException(runner.getThrowable());
			}
			i++;
			try {
				Thread.sleep(sleepMillis);
			} catch(InterruptedException e) {
				Thread.currentThread().interrupt();
				return null;
			}
			if((i * sleepMillis) > timeoutMillis) {
				//Time out
				return null;
			}
		}
		return runner.getResponse();
	}
	
	private class RequestRunner implements Runnable {
		private T response;
		private Throwable th;
		
		@Override
		public void run() {
			try {
				response = runRequest();
			} catch(Throwable th) {
				this.th = th;
			}
		}
		
		public boolean hasResponse() {
			return response != null;
		}
		

		public boolean isError() {
			return th != null;
		}

		public T getResponse() {
			return response;
		}

		public Throwable getThrowable() {
			return th;
		}
	}
}
