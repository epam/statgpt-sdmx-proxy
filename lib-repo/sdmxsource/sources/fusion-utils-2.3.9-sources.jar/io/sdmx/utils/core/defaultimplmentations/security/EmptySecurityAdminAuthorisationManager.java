package io.sdmx.utils.core.defaultimplmentations.security;

import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.security.ISecurityAdminAuthorisationManager;

/**
 * Everything is authorised
 */
public class EmptySecurityAdminAuthorisationManager implements ISecurityAdminAuthorisationManager {
	public static ISecurityAdminAuthorisationManager INSTANCE = new EmptySecurityAdminAuthorisationManager();
	
	public static ISecurityAdminAuthorisationManager getInstance() {
		return INSTANCE;
	}
	
	private EmptySecurityAdminAuthorisationManager() {}

	@Override
	public void authorise(String adminFunctionId) throws SdmxUnauthorisedException {}

	@Override
	public boolean isAuthorised(String adminFunctionId) {
		return true;
	}
}
