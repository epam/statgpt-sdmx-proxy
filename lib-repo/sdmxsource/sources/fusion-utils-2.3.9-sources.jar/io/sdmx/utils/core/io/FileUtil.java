package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {
	private static final Logger LOG = LoggerFactory.getLogger(FileUtil.class);

	public static File createTemporaryFile(String prefix, String suffix) {
		String TMP_FILE_DIR = System.getProperty("java.io.tmpdir");
		File tmpDir = new File(TMP_FILE_DIR);
		if(!tmpDir.exists()) {
			if(!tmpDir.mkdirs()) {
				throw new RuntimeException("Unable to create directory to store temporary files: " + tmpDir.getAbsolutePath());
			}
		}
		try {
			return File.createTempFile(prefix, suffix, tmpDir);
		} catch (IOException e) {
		    String msg = "Unable to create a temporary file in the directory: " + tmpDir.getAbsolutePath();
		    LOG.error(msg);
			throw new RuntimeException(msg, e);
		}
	}

	/**
	 * Deletes all the files from the directory which match the specified regEx pattern.
	 * @param regExPattern
	 * @param directory
	 * @return false if some files could not be deleted, true if either all files were deleted or no files match the pattern
	 */
	public static boolean deleteFilesFromDirectoryWithName(String regExPattern, File directory) {
	    LOG.info("Attempting to delete files from directory: '" + directory.getAbsolutePath() + "' which match the pattern: '" + regExPattern + "'");

	    File[] matchingFiles = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.matches(regExPattern);
            }
        });

	    if (matchingFiles.length == 0) {
	        LOG.info("There are no files that match this specified pattern. Nothing to do.");
	        return true;
	    }

	    LOG.info("There are " + matchingFiles.length + " files that match this criteria. Attempting to delete.");

	    int remainingItems = matchingFiles.length;
	    for (File aFile : matchingFiles) {
	        if (aFile.delete()) {
	            remainingItems--;
	        }
        }

	    if (remainingItems > 0) {
	        LOG.warn("Unable to delete " + remainingItems + " files from the temporary directory.");
	        return false;
	    }

	    LOG.info("All matching items in the directory deleted ");
	    return true;
	}


	public static InputStream readFileAsStream(String filePath)  {
		File f = new File(filePath);
		return readFileAsStream(f);
	}

	public static InputStream readFileAsStream(File f)  {
	    if(f == null) {
            throw new IllegalArgumentException("Missing Argument 'File' to method readFileAsStream");
        }
	    FileInputStream stream = null;
		try {
			if(!f.exists()) {
				throw new IllegalArgumentException("File not found : " + f.getAbsolutePath());
			}
			stream = new FileInputStream(f);
			return new BufferedInputStream(stream);
		} catch(Exception e) {
		    if (stream != null) {
		        StreamUtil.closeStream(stream);
		    }
            throw new IllegalArgumentException(e);
		}
	}

	public static OutputStream getOutputStream(File f)  {
		if(f == null) {
			throw new IllegalArgumentException("Missing Argument 'File' to method getOutputStream");
		}
		FileOutputStream stream = null;
		try {
			if (!f.exists()) {
				createFile(f);
			}
			stream = new FileOutputStream(f);
			return new BufferedOutputStream(stream);
		} catch(Exception e) {
		    if (stream != null) {
                StreamUtil.closeStream(stream);
            }
            throw new IllegalArgumentException(e);
		}
	}

	public static OutputStream getOutputStream(String filePath)  {
		File f = new File(filePath);
		return getOutputStream(f);
	}

	public static byte[] readFileAsByteArray(File f)  {
		if(!f.exists()) {
			throw new IllegalArgumentException("File '"+f.getAbsolutePath()+"' does not exist");
		}
		FileInputStream fis = null;
		try {
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			fis = new FileInputStream(f);
			StreamUtil.copyStream(fis, bytes);
			return bytes.toByteArray();
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		} finally {
			StreamUtil.closeStream(fis);
		}
	}

	public static byte[] readFileAsByteArray(String filePath)  {
		File f = new File(filePath);
		return readFileAsByteArray(f);
	}

	public static String readFileAsString(String filePath)  {
		File f = new File(filePath);
		if(!f.exists()) {
			throw new IllegalArgumentException("File '"+filePath+"' does not exist");
		}
		BufferedReader br = null;
		try (FileReader fr = new FileReader(f)) {
			br = new BufferedReader(fr);

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), true);
			String line;
			while ((line = br.readLine()) != null) {
				pw.println(line);
			}
			pw.close();
			return new String(out.toByteArray());
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// Unable to close the BufferedReader
				}
			}
		}
	}

	public static void readFile(String filePath, OutputStream out)  {
		File f = new File(filePath);
		if(!f.exists()) {
			throw new IllegalArgumentException("File '"+filePath+"' does not exist");
		}
		try {
			StreamUtil.copyStream(new FileInputStream(f), out);
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		} finally {

		}
	}

	public static boolean exists(String filePath) {
		File f = new File(filePath);
		return f.exists();
	}

	public static boolean deleteFile(String filePath) {
		File f = new File(filePath);
		return f.delete();
	}

	/**
	 * Creates the directory (or group of directories) if it does not already exist, if the supplied path is a path to a known file location, then an exception wil be thrown
	 * @param dir
	 */
	public static void createDirectory(String dir) {
		File f = new File(dir);
		if(!f.exists()) {
			f.mkdirs();
		} else if(!f.isDirectory()) {
			throw new IllegalArgumentException("Directory '" + dir  + "' can not be created, it already exists as a file");
		}
	}

	/**
	 * Creates a file at location given by the string, will create any directories required, and will create the file, but only if
	 * it does not already exist
	 * @param fileStr
	 * @return
	 */
	public static File createFile(String fileStr) {
		File f = new File(fileStr);
		createFile(f);
		return f;
	}
	/**
	 * Creates the specified file if it doesn't exists and creates all of the required sub-directories if they don't exist.
	 * @param aFile The file to create.
	 * @throw IllegalStateException if the file or parent directories could not be created.
	 */
	public static File createFile(File aFile) {
		if (aFile.exists()) {
			// Since the file already exists, there is nothing further to do.
			return aFile;
		}

		File parentDir = aFile.getParentFile();
		if (!parentDir.exists()) {
			boolean createdParentDirectories = parentDir.mkdirs();
			if (!createdParentDirectories) {
				throw new IllegalStateException("Unable to create directory structure: " + parentDir.getAbsolutePath());
			}
		}
		try {
			aFile.createNewFile();
		} catch (IOException e) {
			throw new IllegalStateException("Unable to create file: " + aFile.getAbsolutePath());
		}
		return aFile;
	}

	static public boolean deleteDirectory(String path) {
		return deleteDirectory(new File(path));
	}

	public static boolean deleteDirectory(File path) {
		if( path.exists() ) {
			File[] files = path.listFiles();
			for(int i=0; i<files.length; i++) {
				if(files[i].isDirectory()) {
					deleteDirectory(files[i]);
				}
				else {
					files[i].delete();
				}
			}
		}
		return( path.delete() );
	}

	public static int countFiles(String directory) {
		File f = new File(directory);
		if(f.isDirectory()) {
			String[] list = f.list();
			if(list == null) {
				return 0;
			}
			return list.length;
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	/**
	 * Returns a list of strings - representing all the file names in the given directory
	 * @param directory
	 * @return
	 */
	public static String[] getFileNames(String directory) {
		File f = new File(directory);
		if(f.isDirectory()) {
			return f.list();
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	/**
	 * Returns a list of files for the specified directory
	 * @param directory A directory
	 * @return An array of File objects.
	 */
	public static File[] getFiles(String directory) {
		File f = new File(directory);
		if(f.isDirectory()) {
			return f.listFiles();
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	/**
	 * Deletes all the files in a directory older then a given date
	 * @param directory
	 * @return
	 */
	public static void deleteFilesOlderThen(String directory, Date deleteFilesOlderThen) {
		File f = new File(directory);
		if(f.isDirectory()) {
			File files[] = f.listFiles();
			for(File currentFile : files) {
				long lastModified = currentFile.lastModified();
				if(lastModified < deleteFilesOlderThen.getTime()) {
					currentFile.delete();
				}
			}
			return;
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	public static void deleteOldestFile(String directory) {
		long oldestFileTime = Long.MAX_VALUE;
		File oldestFile = null;
		File f = new File(directory);
		if(f.isDirectory()) {
			File files[] = f.listFiles();
			for(File currentFile : files) {
				long lastModified = currentFile.lastModified();
				if(lastModified < oldestFileTime) {
					oldestFileTime = lastModified;
					oldestFile = currentFile;
				}
			}
			if(oldestFile != null) {
				oldestFile.delete();
			}
			return;
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	/**
	 * Returns the most recent file from a directory
	 * @param directory
	 */
	public static File getNewestFile(String directory) {
		long newestFileTime = Long.MIN_VALUE;
		File newestFile = null;
		File f = new File(directory);
		if(f.isDirectory()) {
			File files[] = f.listFiles();
			for(File currentFile : files) {
				long lastModified = currentFile.lastModified();
				if(lastModified > newestFileTime) {
					newestFileTime = lastModified;
					newestFile = currentFile;
				}
			}
			return newestFile;
		}
		throw new IllegalArgumentException(directory + " is not a directory");
	}

	private static InputStream obtainInputStream(File aFile) {
		// To prevent this method from waiting for ever (if the file is locked by another process)
		// create a time-out value. This is currently set to 3 minutes.
		long proposedAbortTime = System.currentTimeMillis() + (180 * 1000);

		while(true) {
			try {
				return new FileInputStream(aFile);
			} catch (FileNotFoundException e) {
				// On Windows OS attempting to access a file being written to throws this exception.
				// Pause and retry.
				// On Linux, the OS allows access to a file being written to.

				// Note, it is possible that the file has been removed from the file system, so
				// perform a check.
				if (!aFile.exists()) {
					return null;
				}

				LOG.warn("Unable to access the file - it appears to be locked! File: " + aFile.getAbsolutePath());
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ie) {
					// Do nothing
				}

				if (System.currentTimeMillis() > proposedAbortTime) {
					System.out.println("Due to timeout, aborting attempting to get a lock on file: "+aFile);
					return null;
				}
			}
		}
	}

	private static long readFile(InputStream is) {
		int size = 0;
		BufferedInputStream bis = new BufferedInputStream(is);
		byte[] ba = new byte[1024];

		try {
			while (bis.read(ba) != -1) {
				size += ba.length;
			}
		} catch(IOException e) {
			System.err.println("IO exception when trying to read input Stream: "+e);
			e.printStackTrace();
		}
		try {
			bis.close();
		} catch (IOException e) {
			System.err.println("IO exception when trying to close BufferedInputStream: "+e);
			e.printStackTrace();
		}
		try {
			is.close();
		} catch (IOException e) {
			System.err.println("IO exception when trying to close InputStream: "+e);
			e.printStackTrace();
		}

		return size;
	}

	/**
	 * Pause the current thread until the specified file is available for writing to.
	 * @param aFile The file
	 * @return false if something has gone wrong with the InputStreams
	 */
	public static boolean waitTillAvailableForWriting(File aFile) {
		if (!aFile.exists()) {
			// Since the file doesn't exist there is nothing to do
			return true;
		}

		long priorSize = -1;
		try (InputStream is = obtainInputStream(aFile)) {
    		if (is == null) {
    		    return false;
    		}
		    priorSize = readFile(is);
		    StreamUtil.closeStream(is);
		} catch (IOException e) {
		    return false;
		}

		while (true) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException ie) {
				// Do nothing
			}

			try (InputStream is = obtainInputStream(aFile)) {
    			if (is == null) {
    				return true;
    			}

				long currentSize = readFile(is);

				if (currentSize == priorSize) {
					// The file size hasn't changed. Assume no-one else is writing to it.
					break;
				}

				priorSize = currentSize;
			} catch (IOException e) {
			    return false;
			}
		}
		return true;
	}

	/**
	 * Given a specified directory name, returns a File object representing that directory if the
	 * specified name is valid. Validity is determined by if the directory already exists, it being a directory
	 * and it being readable. If the specified directory does not exist, then it is created.
	 * @param directoryName The fully-qualified name of the directory
	 * @return A file object representing the directory
	 */
	public static File ensureDirectoryExists(String directoryName) {
		File f = new File(directoryName);

		// If the directory exists, not need to create it, but need to check validity and permissions.
		if (f.exists()) {
			if (!f.isDirectory()) {
				// The directory exists but the specified location is a file
				throw new RuntimeException(
						"The specified directory is a file not a directory! Specified value: '" + directoryName + "'");
			}

			if (!f.canWrite()) {
				// The directory exists but cannot be written to
				throw new RuntimeException(
						"The specified directory does not have read permission! Specified value: '" + directoryName + "'");
			}
		} else {
			// Create the directory.
			boolean successfulCreate = f.mkdirs();
			if (!successfulCreate) {
				throw new RuntimeException("Unable to create directory: " + directoryName);
			}
		}
		return f;
	}

	/**
	 * Returns the size in bytes of the specified file.
	 * @param aFile The file to evaluate.
	 * @return The size in bytes.
	 */
	public static long getFileSize(File aFile) {
		return size(aFile.toPath());
	}

	/**
	 * Attempts to calculate the size of a file or directory.
	 *
	 * <p>
	 * Since the operation is non-atomic, the returned value may be inaccurate.
	 * However, this method is quick and does its best.
	 */
	public static long size(Path path) {

	    final AtomicLong size = new AtomicLong(0);

	    try {
	        Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
	            @Override
	            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {

	                size.addAndGet(attrs.size());
	                return FileVisitResult.CONTINUE;
	            }

	            @Override
	            public FileVisitResult visitFileFailed(Path file, IOException exc) {

	                System.out.println("skipped: " + file + " (" + exc + ")");
	                // Skip folders that can't be traversed
	                return FileVisitResult.CONTINUE;
	            }

	            @Override
	            public FileVisitResult postVisitDirectory(Path dir, IOException exc) {

	                if (exc != null)
	                    System.out.println("had trouble traversing: " + dir + " (" + exc + ")");
	                // Ignore errors traversing a folder
	                return FileVisitResult.CONTINUE;
	            }
	        });
	    } catch (IOException e) {
	        throw new AssertionError("walkFileTree will not throw IOException if the FileVisitor does not");
	    }

	    return size.get();
	}

	/**
	 * Returns the size in bytes of the specified URI.
	 * @param aURI The URI to evaluate.
	 * @return The size in bytes.
	 */
	public static long getFileSize(URI aURI) {
		return getFileSize(URIUtil.getFile(aURI));
	}

	/**
	 * Copies all of the files in the specified source directory into the specified target directory.
	 * @param srcDir The source directory
	 * @param targetDir The target directory
	 * @throws IOException If anything goes wrong
	 */
	public static void copyAllFilesInDir(File srcDir, File targetDir) throws IOException {
		if (!srcDir.exists()) {
			// Since the source directory doesn't exist there is nothing to do
			return;
		}

		File[] files = srcDir.listFiles();
		for (int i=0; i < files.length; i++) {
			File aFile = files[i];
			File target =  new File(targetDir, aFile.getName());
			if (aFile.isDirectory()) {
				target.mkdirs();
				copyAllFilesInDir(aFile, target);
			} else {
				copyFile(aFile, target);
			}
		}
	}

	public static void copyFile(File sourceFile, File destFile) throws IOException {
		if (!sourceFile.exists()) {
			// Since the source file doesn't exist there is nothing to do
			return;
		}

		if (!destFile.exists()) {
			destFile.createNewFile();
		}

		try (FileInputStream fis = new FileInputStream(sourceFile); FileOutputStream fos = new FileOutputStream(destFile) ) {
		    FileChannel source = fis.getChannel();
			FileChannel destination = fos.getChannel();
			destination.transferFrom(source, 0, source.size());
		}
	}

	public static List<String> getAllLines(Path f, Charset charset) throws IOException {
		if(charset == null) {
			charset = StandardCharsets.UTF_8;
		}
		return Files.readAllLines(f, charset);
		/*		List<String> lines = new ArrayList<String>();
		Scanner sc = null;
		try {
			sc = new Scanner(f, charset.name());
			while (sc.hasNextLine()) {
			  lines.add(sc.nextLine());
			}
		} finally {
			if (sc != null) {
				sc.close();
			}
		}
		return lines;*/
	}
}
