package io.sdmx.utils.core.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;


/**
 * Utility class providing helper methods to expand the functionality of Java Collections.
 */
public class CollectionUtil {
	public static final Set<String> EMPTY_STRING_SET = Collections.unmodifiableSet(new HashSet<String>());
	public static final List<String> EMPTY_STRING_LIST = Collections.unmodifiableList(new ArrayList<String>());

	

	/**
	 * Create a new list with the current content and additional given element.
	 */
	public static <T> List<T> extendList(List<T> in, T elem) {
		int size = (in == null) ? 0 : in.size();
		List<T> out = new ArrayList<>(size + 1);

		if (in != null)
			out.addAll(in);

		out.add(elem);

		return out;
	}
	
	/**
	 * Builds a map of string to string where the source values are separated by a whitespace,
	 * for example buildMapValues("IN MAPOUT", "IN2 MAPOUT2") would result in IN being mapped to MAPOUT and
	 * IN2 being mapped to MAPOUT2
	 * @param values
	 * @return
	 */
	public static Map<String, String> buildMapValues(String... values) {
		return buildMapValues(false, values);
	}
	public static Map<String, String> buildMapValues(boolean preserveOrder, String... values) {
		Map<String, String> map = preserveOrder ? new LinkedHashMap<>() : new HashMap<>();
		if(values != null) {
			for(String currentConceptValue : values) {
				String[] split = currentConceptValue.split(" ", 2);
				if(split.length == 1) {
					map.put(split[0], null);
				} else {
					map.put(split[0], split[1]);
				}
			}
		}
		return map;
	}
	
	public static Map<String, String> singleMap(String key, String value) {
		Map<String, String> map = new HashMap<>(1);
		map.put(key, value);
		return map;
	}

	/**
	 * Create a new set of T and return immutable instance
	 * @param <T>
	 * @param set
	 * @return
	 */
	public static <T> Set<T> copyToImmutable(Set<T> set) {
		return Collections.unmodifiableSet(new HashSet<>(set));
	}
	
	public static <K,V> Map<K,Set<V>> getImmutableMapOfSets(Map<K,Set<V>> map) {
		for(K link : map.keySet()) {
			Set<V> links = map.get(link);
			map.put(link, Collections.unmodifiableSet(links));
		}
		return Collections.unmodifiableMap(map);
	}

	public static <T> List<T> getImmutableList(T...contents) {
		List<T> list = new ArrayList<>(contents == null ? 0 : contents.length);
		if(contents != null) {
			for(T item : contents) {
				if(item != null) {
					list.add(item);
				}
			}
		}
		return Collections.unmodifiableList(list);
	}

	/**
	 * Merges a map of key to a collection of targets
	 * @param fromMap
	 * @param toMap
	 */
	public static  <V, T> void mergeMap(Map<V, Set<T>> fromMap, Map<V, Set<T>> toMap) {
		for(V mapKey : fromMap.keySet()) {
			Set<T> refs = toMap.get(mapKey);
			Set<T> fromSet = fromMap.get(mapKey);
			if(fromSet == null) {
				continue;
			}
			if(refs == null) {
				refs = new HashSet<>();
				toMap.put(mapKey, refs);
			}
			refs.addAll(fromSet);
		}
	}

	/**
	 * Returns a copy of the map, with a copy of the mapped set
	 * @param fromMap
	 * @param toMap
	 */
	public static  <V, T> Map<V, Set<T>> copyMap(Map<V, Set<T>> fromMap) {
		Map<V, Set<T>> toMap = new HashMap<>();
		for(V mapKey : fromMap.keySet()) {
			Set<T> mapped = fromMap.get(mapKey);
			if(mapped == null) {
				toMap.put(mapKey, null);
			} else {
				toMap.put(mapKey, new HashSet<T>(mapped));
			}
		}
		return toMap;
	}

	/**
	 * Converts a list of values to a map of value to position
	 * @param compIds
	 * @param posMap
	 */
	public static void listToPosition(List<String> compIds, Map<String, Integer> posMap) {
		for(int i=0; i < compIds.size(); i++) {
			posMap.put(compIds.get(i), i);
		}
	}

	/**
	 * Converts a list of values to a map of value to position
	 * @param compIds
	 * @param posMap
	 */
	public static Map<String, Integer> arrayToPosition(String[] arr) {
		Map<String, Integer> returnMap = new HashMap<>();
		for(int i=0; i < arr.length; i++) {
			returnMap.put(arr[i], i);
		}
		return returnMap;
	}

	/**
	 * Converts an array to a set, a null array returns an empty set
	 */
	public static Set<String> arrayToSet(String... arr) {
		int length = arr != null ? arr.length : 0;
		Set<String> returnSet = new HashSet<>(length);
		if(length > 0) {
			for(int i=0; i < arr.length; i++) {
				returnSet.add(arr[i]);
			}
		}
		return returnSet;
	}

	/**
	 * Converts an array to a list, a null array returns an empty set
	 */
	public static List<String> arrayToList(boolean intern, String... arr) {
		int length = arr != null ? arr.length : 0;
		List<String> returnList = new ArrayList<>(length);
		if(length > 0) {
			arr = intern ? StringUtil.manualIntern(arr) : arr;
			for(int i=0; i < arr.length; i++) {
				returnList.add(arr[i]);
			}
		}
		return returnList;
	}


	/**
	 * Converts a map of string to position to an array of strings in the correct poistion, the positions in the map must start from 0 and
	 * be sequential
	 * @param posMap
	 */
	public static String[] positionMapToArray(Map<String, Integer> posMap) {
		String[] returnArray = new String[posMap.size()];
		for(String str : posMap.keySet()) {
			Integer position = posMap.get(str);
			returnArray[position] = str;
		}
		return returnArray;
	}


	public static <T> List<T> toList(T... str) {
		List<T> list = new ArrayList<>();
		if(str != null) {
			for(T s : str) {
				list.add(s);
			}
		}
		return list;
	}


	/**
	 * @param arr array of objects, can contain nulls
	 * @param str object to search for, can be null
	 * @return index of object in array
	 */
	public static int indexInArray(Object[] arr, Object str) {
		int i = 0;
		for(Object obj : arr) {
			if(ObjectUtil.equivalent(obj, str)) {
				return i;
			}
			i++;
		}
		return -1;
	}

	/**
	 * Adds to the collection if T is not null and the collection is not null
	 * @param <T>
	 * @param collection
	 * @param entry
	 */
	public static <T> void addToCollection(Collection<T> collection, T entry) {
		if(entry != null && collection != null) {
			collection.add(entry);
		}
	}

	public static <V, T> void addToMappedSet(Map<V, Set<T>> map, V key, Set<T> value) {
		Set<T> set = map.get(key);
		if(set == null) {
			set = new HashSet<T>(value.size());
			map.put(key, set);
		}
		set.addAll(value);
	}

	public static <V, T> void addToMappedSet(Map<V, Set<T>> map, V key, List<T> value) {
		Set<T> set = map.get(key);
		if (set == null) {
			set = new HashSet<T>(value.size());
			map.put(key, set);
		}
		set.addAll(value);
	}

	public static <V, T> void addToMappedSet(Map<V, Set<T>> map, V key, T value) {
		Set<T> set = map.get(key);
		if(set == null) {
			set = new HashSet<T>();
			map.put(key, set);
		}
		set.add(value);
	}

	public static <V, T> void addToMappedList(Map<V, List<T>> map, V key, T value) {
		List<T> list = map.get(key);
		if(list == null) {
			list = new ArrayList<T>();
			map.put(key, list);
		}
		list.add(value);
	}

	public static <K, T, V> void addToMappedMap(Map<K, Map<T, V>> map, K key, T submapKey, V value) {
		Map<T, V> submap = map.get(key);
		if(submap == null) {
			submap = new HashMap<T, V>();
			map.put(key, submap);
		}
		submap.put(submapKey, value);
	}



	/**
	 * Converts a set of KeyValues (concept->value pair) to a map of concept -> set<value>
	 * @param keyValues
	 * @return
	 */
	public static Map<String, Set<String>> keyValuesToMap(Set<KeyValue> keyValues) {
		Map<String, Set<String>> returnMap = new HashMap<>();
		for(KeyValue kv : keyValues) {
			if(kv.getCode() == null) {
				continue;
			}
			String dimId = kv.getConcept();
			Set<String> valueSet = returnMap.get(dimId);
			if(valueSet == null) {
				valueSet = new HashSet<>();
				returnMap.put(dimId, valueSet);
			}
			valueSet.add(kv.getCode());
		}
		return returnMap;
	}

	/**
	 * Converts a set of KeyValues (concept->value pair) only storing one value per key
	 * @param keyValues one or more collections of key values
	 * @return
	 */
	public static Map<String, String> keyValuesToFlatMap(Collection<KeyValue> keyValues) {
		Map<String, String> returnMap = new HashMap<>();
		if(keyValues != null) {
			for(KeyValue kv : keyValues) {
				if(kv == null || kv.getCode() == null) {
					continue;
				}
				returnMap.put(kv.getConcept(), kv.getCode());
			}
		}
		return returnMap;
	}


	public static Set<Object> toSet(Collection<?> collection) {
		Set<Object> set = new HashSet<>();
		for(Object obj : collection) {
			set.add(obj);
		}
		return set;
	}

	/**
	 * Copies the collection into an array of the same type, returns an empty array of size 0 if the collection is null
	 * @param coll
	 * @return
	 */
	public static String[] toArray(Collection<String> coll) {
		if(coll == null) {
			return new String[0];
		}
		String[] arr = new String[coll.size()];
		coll.toArray(arr);
		return arr;
	}

	public static String collectionToString(Collection<? extends Object> array, String join, String replaceMissing) {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		if(array != null) {
			for(Object arrayItem : array) {
				String asString = arrayItem == null ? replaceMissing : arrayItem.toString();
				if(asString == null) {
					asString = "";
				}
				sb.append(concat + asString);
				concat = join;
			}
		}
		return sb.toString();
	}


	public static String arrayToString(Object[] array, String replaceMissing) {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(Object arrayItem : array) {
			String asString = arrayItem == null ? replaceMissing : arrayItem.toString();
			if(asString == null) {
				asString = "";
			}
			sb.append(concat + asString);
			concat = ":";
		}
		return sb.toString();
	}

	/**
	 * Return the difference between 2 collections
	 * @param coll1
	 * @param coll2
	 * @return
	 */
	public static <T> Collection<T> disjunction(Collection<T> coll1, Collection<T> coll2) {
		Set<T> union = new HashSet<>(coll1);
		union.addAll(coll2);
		Set<T> intersection = CollectionUtil.intersection(coll1, coll2);
		Set<T> result = union;
		result.removeAll(intersection);
		return result;
	}
	
	/**
	 * Return the difference between 2 collections
	 * @param coll1
	 * @param coll2
	 * @return
	 */
	public static <T> Set<T> intersection(Collection<T>... collection) {
		if(collection == null || collection.length == 0) {
			return new HashSet<>();
		}
		Set<T> intersection = new HashSet<>(collection[0]);
		intersection.addAll(collection[0]);
		for(int i=1; i < collection.length; i++) {
			intersection.retainAll(collection[i]);
		}
		return intersection;
	}

	
	/**
	 * Returns all values that intersect with one or more of the sets
	 * @param coll1
	 * @param coll2
	 * @return
	 */
	public static <T> Set<T> anyIntersection(Collection<T>... collection) {
		if(collection == null || collection.length == 0) {
			return new HashSet<>();
		}
		if(collection.length == 1) {
			return new HashSet<>(collection[0]);
		}
		if(collection.length == 2) {
			return intersection(collection);
		}
		Map<T, Integer> valueCount = new HashMap<>();
		for(Collection<T> currentCollection : collection) {
			for(T currentEl : currentCollection) {
				valueCount.put(currentEl, valueCount.getOrDefault(currentEl, 0)+1);
			}
		}
		Set<T> returnSet = new HashSet<>();
		for(T value : valueCount.keySet()) {
			if(valueCount.get(value) > 1) {
				returnSet.add(value);
			}
		}
		return returnSet;
	}
	
	@SafeVarargs
	public static<E> void removeAll(Collection<E> toRemoveFrom, Collection<E>... toRemove) {
		for (Collection<E> items : toRemove) {
			toRemoveFrom.removeAll(items);
		}
	}

	public static<E> boolean isSame(Collection<E> collectionOne, Collection<E> collectionTwo) {
		Object[] objArrOne = collectionOne.toArray();
		Object[] objArrTwo = collectionTwo.toArray();

		if(objArrOne.length != objArrTwo.length) {
			return false;
		}

		for(int i = 0; i < objArrOne.length; i++) {
			if(!objArrOne[i].equals(objArrTwo[i])) {
				return false;
			}
		}
		return true;
	}

	public static int getTotalCollectionSize(Collection<?>... collections) {
		int size = 0;
		if(collections != null) {
			for(Collection<?> collection : collections) {
				size += collection.size();
			}
		}
		return size;
	}

	/**
	 * @param list1
	 * @param list2
	 * @return position of the item in list 2, from the items in list 1
	 */
	public static int[] getListPositions(List<?> list1, List<?> list2) {
		int[] positions = new int[list1.size()];
		int i = 0;
		for(Object item : list1) {
			positions[i] = list2.lastIndexOf(item);
			i++;
		}
		return positions;
	}


	public static int getIntersectionSize(Set<?> set1, Set<?> set2) {
		if(!ObjectUtil.validCollection(set1)) {
			return 0;
		}
		if(!ObjectUtil.validCollection(set2)) {
			return 0;
		}
		int intersection = 0;
		for(Object o : set1) {
			if(set2.contains(o)) {
				intersection++;
			}
		}
		return intersection;
	}
	
	public static boolean containsAny(Set<?> set1, Collection<?> collection2) {
		if(!ObjectUtil.validCollection(set1)) {
			return false;
		}
		if(!ObjectUtil.validCollection(collection2)) {
			return false;
		}
		for(Object o : collection2) {
			if(set1.contains(o)) {
				return true;
			}
		}
		return false;
	}

	public static <T> Collector<T, ?, T> toSingleton() {
		return Collectors.collectingAndThen(Collectors.toList(), list -> {
			if (list.size() != 1) {
				throw new IllegalStateException();
			}
			return list.get(0);
		}
				);
	}
	
	public static <T> String join(String join, String replaceNullString, Collection<String> collection) {
		return join(join, replaceNullString, CollectionUtil.toArray(collection));
	}
	
	/**
	 * Joins the toString of the collection items to create one string
	 * @param join - the join string, e.g. comma to comma sperate a list of strings
	 * @param str
	 * @param replaceNullString - the string to replace a null with, if null then nulls will be removed from the final string
	 * @return
	 */
	public static <T> String join(String join, String replaceNullString, T... str) {
		StringBuilder sb = new StringBuilder();
		if(str != null) {
			String concat = "";
			for(T s : str) {
				if(s == null) {
					if(replaceNullString == null) {
						continue;
					}
					sb.append(concat+replaceNullString);
				} else {
					sb.append(concat+s.toString());
				}
				concat = join;
			}
		}
		return sb.toString();
	}

	/**
	 * Returns the value from the supplied Map ensuring that this value is not null. If the key does not exist or the value is null an exception is thrown
	 * @param aMap the map to check
	 * @param key the key to use against the Map
	 * @return the specified value which will not be null
	 */
	public static Object getMapValueEnforcingNotNull(Map<String, Object> aMap, String key) {
		if (key == null) {
			throw new IllegalArgumentException("A key must be specified");
		}
		
		if (aMap == null) {
			throw new IllegalArgumentException("A Map must be specified");
		}
		
		Object value = aMap.get(key);
		if (value == null) {
			throw new IllegalArgumentException("Expected property '"+key+"' not present in supplied Map");
		}
		
		return value;
	}
	
	public static <T> List<List<T>> cartesianProduct(List<Collection<T>> sets) {
		return cartesianProduct(sets, 0).collect(Collectors.toList());
	}
	
	private static <T> Stream<List<T>> cartesianProduct(List<Collection<T>> sets, int index) {
	    if (index == sets.size()) {
	        List<T> emptyList = new ArrayList<>();
	        return Stream.of(emptyList);
	    }
	    Collection<T> currentSet = sets.get(index);
	    return currentSet.stream().flatMap(element -> cartesianProduct(sets, index+1)
	      .map(list -> {
	          List<T> newList = new ArrayList<>(list);
	          newList.add(0, element);
	          return newList;
	      }));
	}
}