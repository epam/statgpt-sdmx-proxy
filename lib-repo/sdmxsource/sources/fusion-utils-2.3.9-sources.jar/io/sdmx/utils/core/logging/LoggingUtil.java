package io.sdmx.utils.core.logging;

import org.slf4j.Logger;

public class LoggingUtil {

	public static void debug(Logger log, String message) {
		if(log != null && log.isDebugEnabled()) {
			log.debug(message);
		}
	}
	
	public static void error(Logger log, String message) {
		if(log != null) {
			log.error(message);
		}
	}
	
	public static void warn(Logger log, String message) {
		if(log != null) {
			log.warn(message);
		}
	}
	
	public static void info(Logger log, String message) {
		if(log != null && log.isInfoEnabled()) {
			log.info(message);
		}
	}
	
}
