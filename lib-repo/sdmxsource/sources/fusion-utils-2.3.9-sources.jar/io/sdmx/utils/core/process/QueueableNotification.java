package io.sdmx.utils.core.process;

import java.util.Date;

import io.sdmx.utils.core.error.ErrorReport;
import io.sdmx.utils.core.process.QueueableProcess.PROCESS_STATUS;

public class QueueableNotification {
	private String id;                       // Unique Identifier assigned by system not for display purposes
	private Date processRequestTime;         // Time the system was aware of the process
	private Date processQueueTime;           // Time the system placed item on the queue
	private Date processStartTime;           // Time process stated processing
	private Date processEndTime;             // Time process complete / or errored
	private PROCESS_STATUS currentStatus;
	private int percentComplete; 
	private ErrorReport errorReport;
	private String auditId;
	
	QueueableNotification(QueueableProcess process) {
		this.auditId = process.getAuditId();
		this.id = process.getId();
		if(process.getProcessRequestTime() != null) {
			this.processRequestTime = new Date(process.getProcessRequestTime().getTime());
		}
		if(process.getProcessQueueTime() != null) {
			this.processQueueTime = new Date(process.getProcessQueueTime().getTime());
		}
		if(process.getProcessStartTime() != null) {
			this.processStartTime = new Date(process.getProcessStartTime().getTime());
		}
		if(process.getProcessEndTime() != null) {
			this.processEndTime = new Date(process.getProcessEndTime().getTime());
		}
		this.currentStatus = process.getCurrentStatus();
		this.percentComplete = process.getPercentComplete();
		this.errorReport = process.getErrorReport();
	}
	
	public String getId() {
		return id;
	}
	
	public String getAuditId() {
		return auditId;
	}

	/**
	 * Returns true if the process is either cancelled, error, or complete
	 * @return
	 */
	public boolean isTerminated() {
		return isCancelled() || isProcessed() || isError();
	}
	
	public boolean isCancelled() {
		return currentStatus.isCancelled();
	}
	
	public boolean isProcessed() {
		return currentStatus.isProcessed();
	}
	
	public boolean isError() {
		return currentStatus.isError();
	}
	
	public Date getProcessRequestTime() {
		return processRequestTime;
	}
	public Date getProcessQueueTime() {
		return processQueueTime;
	}
	public Date getProcessStartTime() {
		return processStartTime;
	}
	public Date getProcessEndTime() {
		return processEndTime;
	}
	public PROCESS_STATUS getCurrentStatus() {
		return currentStatus;
	}
	public int getPercentComplete() {
		return percentComplete;
	}
	public ErrorReport getErrorReport() {
		return errorReport;
	}
}
