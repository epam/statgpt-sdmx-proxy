package io.sdmx.utils.core.date;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.utils.core.object.NumberUtils;

public class SdmxDateImpl implements SdmxDate {
    private static final long serialVersionUID = 88935254909061494L;
    private Date date;
    private TIME_FORMAT timeFormat;
    private String dateInSdmx;
    private boolean startOfPeriod;
    
    private Long timeMillis;

    private static Cache<String, SdmxDate> sp_cache = Caffeine.newBuilder()
            .maximumSize(10000)
            .expireAfterAccess(10, TimeUnit.MINUTES)
            .build();
    
    private static Cache<String, SdmxDate> ep_cache = Caffeine.newBuilder()
            .maximumSize(10000)
            .expireAfterAccess(10, TimeUnit.MINUTES)
            .build();


    public SdmxDateImpl(Date date, TIME_FORMAT timeFormat) {
        this(date, timeFormat, true);
    }

    public SdmxDateImpl(Date date, TIME_FORMAT timeFormat, boolean startOfPeriod) {
        //Do not store the date, it is regenerated if asked for, the regeneration is based on the time format
        //for example if the Java date is generated as 100 miliseconds from 1970 with a time format of date time, the resulting
        //SDMX date will have a resolution to zero seconds, not 100 milliseconds meaning the java date returned from the getter will
        //state 0 milliseconds - this fixes an issue where 2 dates with equal SDMX dates (1970-01-01T00:00.0) were not seen as equal because
        //the underlying date differed in milliseconds
        if(startOfPeriod == false && timeFormat != TIME_FORMAT.DATE_TIME) {
            date = DateUtil.moveToEndofPeriod(date, timeFormat);
        } else {
            this.timeMillis = date.getTime();
        }
        this.timeFormat = timeFormat;
        this.startOfPeriod = startOfPeriod;
        dateInSdmx = DateUtil.formatDate(date, timeFormat);
    }

    public SdmxDateImpl(Long epochTime) {
        this(new Date(epochTime), TIME_FORMAT.DATE_TIME);
    }

    public static SdmxDate getSdmxDate(String dateInSdmx) {
        return getSdmxDate(dateInSdmx, true);
    }
    
    public static SdmxDate getSdmxDate(String dateInSdmx, boolean startOfPeriod) {
        Cache<String, SdmxDate> cache = startOfPeriod ? sp_cache : ep_cache;
        return cache.get(dateInSdmx, e-> new SdmxDateImpl(dateInSdmx, startOfPeriod));
    }

    public SdmxDateImpl(String dateInSdmx, boolean startOfPeriod) {
        this.startOfPeriod = startOfPeriod;
        if(NumberUtils.isInteger(dateInSdmx, true) && dateInSdmx.length() > 4) {
            this.timeFormat = TIME_FORMAT.DATE_TIME;
            this.date = new Date(Long.parseLong(dateInSdmx));
            this.dateInSdmx = DateUtil.getDateFormatter("yyyy-MM-dd'T'HH:mm:ss.SSSS").format(date);
        } else {
            this.timeFormat = DateUtil.getTimeFormatOfDate(dateInSdmx);
            this.dateInSdmx = dateInSdmx;
        }
    }

    @Override
    public boolean isStartPeriod() {
        return startOfPeriod;
    }

    @Override
    public SdmxDate movePeriod(int increment) {
        String nextDate = DateUtil.movePeriod(this, increment);
        SdmxDate sd = SdmxDateImpl.getSdmxDate(nextDate);
        return sd;
    }

    @Override
    public boolean isLater(SdmxDate date) {
        return this.getDate().getTime() > date.getDate().getTime();
    }


    @Override
    public boolean isEarlier(SdmxDate date) {
        return this.getDate().getTime() < date.getDate().getTime();
    }

    @Override
    public Date getDate() {
        if(date == null) {
            boolean startOfPeriod = this.timeFormat == TIME_FORMAT.DATE_TIME ? true : this.startOfPeriod;
            this.date = DateUtil.formatDate(dateInSdmx, startOfPeriod);
        }
        return new Date(date.getTime());
    }
    
    @Override
    public long getTimeMillis() {
        if(timeMillis == null) {
            if(timeFormat == TIME_FORMAT.DATE_TIME) {
                try {
                    this.timeMillis = DateUtil.getDateFormatter("yyyy-MM-dd'T'HH:mm:ss.SSSS").parse(dateInSdmx).getTime();
                } catch (ParseException e) {
                    this.timeMillis = getDate().getTime();
                }
            } else {
                this.timeMillis = getDate().getTime();
            }
        }
        return timeMillis;
    }

    @Override
    public TIME_FORMAT getTimeFormatOfDate() {
        return timeFormat;
    }

    @Override
    public String getDateInSdmxFormat() {
        return dateInSdmx;
    }

    @Override
    public Calendar getDateAsCalendar() {
        return DateUtil.createCalendar(getDate());
    }


    @Override
    public int hashCode() {
        return dateInSdmx.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof SdmxDate) {
            SdmxDate that = (SdmxDate) obj;
            return that.getDateInSdmxFormat().equals(this.getDateInSdmxFormat());
        }
        return false;
    }

    @Override
    //FR-1597 Exported Schema outputs date time incorrectly when it has min and max thresholds
    public String toString() {
        return getDateInSdmxFormat();
    }

    @Override
    public int compareTo(SdmxDate that) {
        int compare = this.getDate().compareTo(that.getDate());
        if(compare != 0) {
            return compare;
        }
        if(this.getTimeFormatOfDate() == that.getTimeFormatOfDate()) {
            return 0;
        }
        return this.getTimeFormatOfDate().getMillisInPeriod() > that.getTimeFormatOfDate().getMillisInPeriod() ? -1 : 1;
    }
}
