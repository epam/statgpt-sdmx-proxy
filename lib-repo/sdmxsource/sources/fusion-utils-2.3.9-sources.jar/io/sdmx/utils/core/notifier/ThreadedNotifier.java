package io.sdmx.utils.core.notifier;

import java.util.List;

import io.sdmx.api.notification.Listener;
import io.sdmx.utils.core.security.FusionSecurityContext;

public class ThreadedNotifier {

	public static void performNotifications(List<Listener<? extends Object>> listeners, Object notification) {
		for(Listener currentListener : listeners) {
			performNotification(currentListener, notification);
		}
	}
	
	public static void performNotification(Listener listener, Object notification) {
		FusionSecurityContext.CTX().createSecureThread(true).runProcess(()-> {
			Object toNotify = notification;
			if (toNotify != null && toNotify.getClass().equals(Integer.class)) {
				//Fixes an unusual bug - java.lang.ClassCastException: class java.lang.Integer cannot be cast to class java.lang.Float
				toNotify = new Float((Integer)notification);
			}
			listener.invoke(toNotify);
		});
	}
}
