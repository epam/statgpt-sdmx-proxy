package io.sdmx.utils.core.xml;

import javax.xml.stream.XMLStreamException;

import io.sdmx.api.exception.SdmxSyntaxException;

public class StaxException extends SdmxSyntaxException {
	private static final long serialVersionUID = 7641544343410075102L;
	private int lineNumber;
	private int column;

	public StaxException(XMLStreamException e) {
		this(
				e.getLocation() == null ? -1 : e.getLocation().getLineNumber(),
				e.getLocation() == null ? -1 :e.getLocation().getColumnNumber(),
				e.getMessage()
		);
	}

	private StaxException(int lineNumber, int column, String str) {
		super(str);
		this.lineNumber = lineNumber;
		this.column = column;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public int getColumn() {
		return column;
	}
}
