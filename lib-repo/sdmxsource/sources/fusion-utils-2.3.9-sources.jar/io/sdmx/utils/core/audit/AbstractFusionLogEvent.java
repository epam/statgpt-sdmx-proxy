package io.sdmx.utils.core.audit;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.logging.IFusionLogEvent;

public abstract class AbstractFusionLogEvent implements IFusionLogEvent {
	protected int logLevel;
	protected String loggerName;
	protected String message;
	protected String auditId;
	protected String threadName;
	protected Long expires;
	protected Long timestamp;

	@Override
	public JSONObject getJson() {
		JSONObject json = new JSONObject();
		try {
			json.put("AuditId", auditId);
			json.put("Level", logLevel);
			json.put("Logger", loggerName);
			json.put("Message", message);
			json.put("Thread", threadName);
			json.put("LogTime", timestamp);
			json.put("Expires", expires);
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return json;
	}
	
	@Override
	public String getAuditId() {
		return auditId;
	}

	@Override
	public String getLoggerName() {
		return loggerName;
	}

	@Override
	public String getThreadName() {
		return threadName;
	}

	@Override
	public Integer getLogLevel() {
		return logLevel;
	}
	
	@Override
	public Long getExpires() {
		return expires;
	}

	@Override
	public Long getLogTime() {
		return timestamp;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
