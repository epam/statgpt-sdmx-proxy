package io.sdmx.utils.core.object;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class AssertUtil {
	
	/**
	 * Verifies an object is not null and not empty, throws an exception if it is
	 */
	public static void boolMatch(boolean expected, boolean actual, String argName) {
		if(expected != actual) {
			throw new IllegalArgumentException(argName+ " is '"+actual+"' expecting '"+expected+"'");
		}
	}
	
	
	/**
	 * Verifies an object is not null and not empty, throws an exception if it is
	 */
	public static void equivalent(Object obj, Object obj2, String argName) {
		if(!ObjectUtil.equivalent(obj, obj2)) {
			throw new IllegalArgumentException(argName+ " are not equal");
		}
	}
	

	/**
	 * Verifies a string is not null and not empty, throws an exception if it is
	 */
	public static void notEmpty(String str, String argName) {
		if(!ObjectUtil.validString(str)) {
			throw new IllegalArgumentException("argument '"+argName+"' is empty or null");
		}
	}
	
	/**
	 * Verifies an object is not null and not empty, throws an exception if it is
	 */
	public static void notNull(Object obj, String argName) {
		if(obj == null) {
			throw new IllegalArgumentException("argument '"+argName+"' is null");
		}
	}
	
	public static void assertSet(Set<?> actual, Set<?> expected) {
		if(expected == null || expected.size() == 0) {
			if(actual.size() > 0) {
				throw new RuntimeException("Actual values not expected to contain anything");
			}
		} else {
			for(Object currentExpected : expected) {
				if(!actual.contains(currentExpected)) {
					throw new RuntimeException("Missing expected value: " + currentExpected);
				}
			}
			if(actual.size() != expected.size()) {
				throw new RuntimeException("Actual values exceeds expected length");
			}
		}
	}
	
	public static void assertValues(Collection<?> actual, String...expected) {
		if(expected == null || expected.length == 0) {
			if(actual.size() > 0) {
				throw new RuntimeException("Actual values not expected to contain anything");
			}
		} else {
			for(String currentExpected : expected) {
				if(!actual.contains(currentExpected)) {
					throw new RuntimeException("Missing expected value: " + currentExpected);
				}
			}
			if(actual.size() != expected.length) {
				throw new RuntimeException("Actual values exceeds expected length");
			}
		}
	}
	
	public static void assertMap(Map<?, ?> actual, Map<?, ?> expected) {
		for(Object key : actual.keySet()) {
			if(!expected.containsKey(key)) {
				throw new RuntimeException("Actual values contains key '"+key+"' not in expected map");
			}
		}
		for(Object key : expected.keySet()) {
			if(!actual.containsKey(key)) {
				throw new RuntimeException("Actual values contains key '"+key+"' not in expected map");
			}
		}
		for(Object key : actual.keySet()) {
		    Object expectedValue = expected.get(key);
		    Object actualValue = actual.get(key);
		    if(expectedValue instanceof Set && actualValue instanceof Set) {
	            assertSet((Set)actualValue, (Set)expectedValue);
		    } else if(!expected.get(key).equals(actual.get(key))) {
				throw new RuntimeException("Expected value '"+expected+"' differs from Actual value '"+actual+"' for map key '"+key+"'");
			}
		}
	}
	

}
