package io.sdmx.utils.core.process;

import io.sdmx.api.process.IProcess;

/**
 * A process with a return type
 */
public abstract class ReturnProcess<T> implements IProcess {
	private T returnObj;
	
	public T getReturnObj() {
		return returnObj;
	}

	public void setReturnObj(T returnObj) {
		this.returnObj = returnObj;
	}
}
