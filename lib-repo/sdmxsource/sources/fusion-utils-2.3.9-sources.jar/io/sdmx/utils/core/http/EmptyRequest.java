package io.sdmx.utils.core.http;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.ICacheHeaders;
import io.sdmx.api.http.IRESTURL;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.object.StringUtil;

public class EmptyRequest implements Request {
	public static final EmptyRequest INSTANCE = new EmptyRequest();
	
	@Override
	public String getIP() {
		return null;
	}

	@Override
	public String getHash() {
		return null;
	}

	@Override
	public IRESTURL getRestURL() {
		return new IRESTURL() {
			
			@Override
			public String getUrl() {
				return StringUtil.EMPTY;
			}
			
			@Override
			public List<String> getPathParts() {
				return Collections.emptyList();
			}
			
			@Override
			public Map<String, String> getParameters() {
				return Collections.emptyMap();
			}
			
			@Override
			public String getParameter(String parameterName) {
				return null;
			}
		};
	}
	@Override
	public HTTP_METHOD getMethod() {
		return HTTP_METHOD.GET;
	}

	@Override
	public ReadableDataLocation getReadableDataLocation() {
		return null;
	}

	@Override
	public String getPath() {
		return null;
	}

	@Override
	public boolean hasHeader(String header) {
		return false;
	}

	@Override
	public String getHeader(String header) {
		return null;
	}

	@Override
	public Map<String, String> getHeaders() {
		return Collections.emptyMap();
	}

	@Override
	public boolean hasParameter(String param) {
		return false;
	}

	@Override
	public String getParameter(String param) {
		return null;
	}

	@Override
	public Map<String, String> getParameters() {
		return Collections.emptyMap();
	}

	@Override
	public void close() {}

	@Override
	public ICacheHeaders getCacheHeaders() {
		return CacheHeaders.EMPTY_HEADERS;
	}

}
