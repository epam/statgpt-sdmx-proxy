package io.sdmx.utils.core.timer;

import java.time.Instant;
import java.util.Date;
import java.util.EnumMap;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Will execute a single task after a set duration
 *
 */
public class TimedExecutor {
	private static final Logger LOG = LoggerFactory.getLogger(TimedExecutor.class);
	private volatile ScheduledExecutorService scheduler;
	private volatile ScheduledFuture<?> scheduleExecutor;
	private volatile Thread executorListenr;

	private Map<LISTEN_OPTS, Consumer<ScheduledFuture<?>>> listeners;

	private Runnable task;
	private long duration;
	private TimeUnit unit;
	private Date dateOnExecution;

	/**
	 * Create a TimedExecutor with 3 arguments: the duration to wait until execution, the unit of time, and the task to run
	 * @param duration
	 * @param unit
	 * @param task
	 */
	public TimedExecutor(long duration, TimeUnit unit, Runnable task){
		if(duration < 0){
			throw new IllegalArgumentException("duation canot be a negative");
		}
		this.duration = duration;
		this.unit = unit;
		this.task = task;
		this.scheduler = Executors.newSingleThreadScheduledExecutor();
		this.listeners = new EnumMap<> (LISTEN_OPTS.class);
		// because this timer works on a countdown, the countdown time will be the time specified minus today's time
		Instant newDate = Instant.now();
		newDate = newDate.plusMillis(duration);
		dateOnExecution = Date.from(newDate);
	}

	/**
	 * The executor will wake up on the date specified. this date can not be before 'today'
	 * @param whenToWake
	 * @param task
	 */
	public TimedExecutor(Date whenToWake, Runnable task){
		this(whenToWake.getTime() - new Date().getTime(), TimeUnit.MILLISECONDS, task);

		dateOnExecution = whenToWake;
	}


	public Date getDuationFull(){
		return this.dateOnExecution;
	}

	/**
	 * add additinal tasks for execution
	 * @param method
	 */
	public void addMethod(Runnable method){
		this.scheduler.submit(method);
	}

	/**
	 * must be called after start, this will return how long until the next execution.
	 * @param format - the time unit format to get value, if null, the remaining time will be returned in milliseconds
	 * @return
	 */
	public long getRemainingDelay(TimeUnit format){
		if(!isRunning()){
			throw new IllegalStateException("Start must be called before this method");
		}
		if(format == null){
			format = TimeUnit.MILLISECONDS;
		}
		return this.scheduleExecutor.getDelay(format);
	}

	public void start(){
		Consumer<ScheduledFuture<?>> beforeStart = listeners.get(LISTEN_OPTS.BEFORE_START);
		if(beforeStart != null){
			beforeStart.accept(null);
		}
		scheduleExecutor = scheduler.schedule(task, duration, unit);

		Consumer<ScheduledFuture<?>> afterStart = listeners.get(LISTEN_OPTS.AFTER_START);
		if(afterStart != null){
			afterStart.accept(scheduleExecutor);
		}
		Runnable threadConstraint = () -> {
			if(scheduleExecutor != null){
				try{
					while(true){
						Thread.sleep(1000);
						if(scheduler.isTerminated() || scheduleExecutor == null){
							break;
						}
						if(scheduleExecutor.isDone()){
							shutDown(false);
							break;
						}
					}
				}catch(Throwable e){
					shutDown(false);
				}
			}
		};
		executorListenr = new Thread(threadConstraint, "Time executor watcher thread " + UUID.randomUUID().toString());
		executorListenr.start();
	}

	public void stop(){
		shutDown(true);
	}

	private void reset(){
		if(executorListenr != null){
			executorListenr.interrupt();
		}
		scheduleExecutor = null;
		dateOnExecution = null;
		executorListenr = null;
	}

	/**
	 * shutdown the timed executor. if argument is true, the shutdown will NOT execute the queued task, if false, the shutdown will commence after the next queued task
	 * @param force - if true, then the task executor will shut down immediately. and the remaining tasks will be removed.
	 */
	public void shutDown(boolean force){
		if(scheduleExecutor != null){
			Consumer<ScheduledFuture<?>> beforeShutDown = listeners.get(LISTEN_OPTS.BEFORE_SHUTDOWN);
			if(beforeShutDown != null){
				beforeShutDown.accept(scheduleExecutor);
			}
			if(force || (scheduler.isShutdown() && !scheduler.isTerminated())){ // the scheduler can be shutdown, but still pending the last task, in this case, the scheduler is shutdown but not terminated
				scheduler.shutdownNow();
			}else{
				scheduler.shutdown();
			}
			Consumer<ScheduledFuture<?>> afterShutDown = listeners.get(LISTEN_OPTS.AFTER_SHUTDOWN);
			if(afterShutDown != null){
				afterShutDown.accept(null);
			}
			LOG.info("The Timer for: '" + dateOnExecution + "' has been shut down");
			reset();
		}
	}

	public boolean isRunning(){
		return scheduleExecutor != null && !scheduler.isShutdown();
	}

	public void attachListener(LISTEN_OPTS op, Consumer<ScheduledFuture<?>> func){
		if(isRunning()){
			throw new IllegalStateException("Unable to attach listener, as the timer has already started");
		}

		this.listeners.put(op,  func);
	}

	public static enum LISTEN_OPTS{
		BEFORE_SHUTDOWN,
		BEFORE_START,
		AFTER_SHUTDOWN,
		AFTER_START
	}

	public static void main(String[] args) throws InterruptedException {
		/*Runnable task = () -> {
            System.out.println("task executed after 10 seconds");
        };
		TimedExecutor a = new TimedExecutor(10, TimeUnit.SECONDS, task);
		a.attachListener(LISTEN_OPTS.BEFORE_START, (scheduler) -> {
			System.out.println("before start");
		});
		a.attachListener(LISTEN_OPTS.AFTER_SHUTDOWN, (scheduler) -> {
			System.out.println("shutdown");
		});
		a.start();
		while(a.isRunning() && a.getRemainingDelay(null) > 0){
			Thread.sleep(1000);
			if(a.isRunning() && a.getRemainingDelay(null) > 0){
				System.out.println(a.getRemainingDelay(TimeUnit.SECONDS));
			}
		}*/

		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		Date time = gregorianCalendar.getTime();
		System.out.println(time);
	}
}
