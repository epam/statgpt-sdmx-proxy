package io.sdmx.utils.core.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IGenericInformationFormat;
import io.sdmx.api.http.MIME_TYPE;

public class GenericFormatCSV implements IGenericInformationFormat {
	private static final long serialVersionUID = 1L;
	private static final GenericFormatCSV INSTANCE = new GenericFormatCSV();
	private static final FormatDetails DETAILS = new FormatDetailsImpl("csv", MIME_TYPE.APPLICATION_CSV, true, MIME_TYPE.APPLICATION_CSV.getMimeType());
			
	public static GenericFormatCSV getInstance() {
		return INSTANCE;
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		return DETAILS;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this == getInstance();
	}

	@Override
	public String toString() {
		return "CSV";
	}

}
