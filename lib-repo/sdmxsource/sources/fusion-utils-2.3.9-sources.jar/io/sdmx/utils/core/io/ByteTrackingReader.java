package io.sdmx.utils.core.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import io.sdmx.api.io.ReadableDataLocation;

/**
 * Wraps a stream to convert char offsets to byte offset, i.e. 5 characters in from the start = 10 bytes
 */
public class ByteTrackingReader {
	private static final int CHAR_ONE_BYTE_MASK = 0xFFFFFF80;
	private static final int CHAR_TWO_BYTES_MASK = 0xFFFFF800;
	private static final int CHAR_THREE_BYTES_MASK = 0xFFFF0000;
	private static final int CHAR_FOUR_BYTES_MASK = 0xFFE00000;
	private static final int CHAR_FIVE_BYTES_MASK = 0xFC000000;
	private static final int CHAR_SIX_BYTES_MASK = 0x80000000;

	// Total bytes read
	private long currentByteOffset = 0;

	//Total chars read
	private long currentCharOffset = 0;

	private BufferedReader byteTrackingInputReader;
	private ReadableDataLocation rdl;
	/**
	 * Creates a new byte tracking reader.
	 *
	 * @param rdl ReadableDataLocation to the file parsed by the StaxReader
	 */
	public ByteTrackingReader(ReadableDataLocation rdl) {
		this.rdl = rdl;
		reset();
	}

	public void reset() {
		closeByteTrackingReader();
		byteTrackingInputReader= new BufferedReader(new InputStreamReader(rdl.getInputStream(), StandardCharsets.UTF_8));
		currentByteOffset = 0;
		currentCharOffset = 0;
	}

	/**
	 * calculates the byte offset by reading the file from the current offset until the charOffset is reached and
	 * calculating the byte count for each character.
	 * @param charOffset current offset of the parser
	 * @return the number of bytes read until the charOffset
	 * @throws IOException
	 */
	public long getByteOffset(long charOffset) throws IOException {
		while(currentCharOffset < charOffset){
			currentCharOffset++;
			char currentChar = (char)byteTrackingInputReader.read();
			currentByteOffset += countBytesForChar(currentChar);
		}
		return currentByteOffset;

	}

	/**
	 * Calculates the end byte offset for closing tags in a generic data set.
	 * @param searchString the closing tag for which the next occurrence should be searched.
	 * @return the byte offset of the last character of the search string, or -1 if the search string is not found in the stream
	 * @throws IOException
	 */
	public long getEndByteOffset(String searchString) throws IOException {
		char[] searchChars = searchString.toCharArray();
		int charLength = searchChars.length;
		int charPos = 0;
		int characterRead;
		while(-1 != (characterRead=byteTrackingInputReader.read())){
			char currentChar = (char)characterRead;
			currentByteOffset += countBytesForChar(currentChar);
			if(searchChars[charPos] == currentChar) {
				charPos++;
				if(charPos == charLength) {
					return currentByteOffset;
				}
			}
		}
		return -1;
	}

	/**
	 * Returns number of bytes for the input character.
	 * Method adapted from https://github.com/ThirdpartyLabs/XMLScalpel/blob/main/src/main/java/com/thirdpartylabs/xmlscalpel/io/reader/ByteTrackingReader.java
	 **/
	private int countBytesForChar(char character)
	{
		if ((character & CHAR_ONE_BYTE_MASK) == 0)
		{
			return 1;
		}
		else if ((character & CHAR_TWO_BYTES_MASK) == 0)
		{
			return 2;
		}
		else if ((character & CHAR_THREE_BYTES_MASK) == 0)
		{
			return 3;
		}
		else if ((character & CHAR_FOUR_BYTES_MASK) == 0)
		{
			return 4;
		}
		else if ((character & CHAR_FIVE_BYTES_MASK) == 0)
		{
			return 5;
		}
		else if ((character & CHAR_SIX_BYTES_MASK) == 0)
		{
			return 6;
		}
		else
		{
			return -1;
		}
	}

	public void close(){
		rdl.close();
		closeByteTrackingReader();
	}

	private void closeByteTrackingReader(){
		if(byteTrackingInputReader != null) {
			try {
				byteTrackingInputReader.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

}
