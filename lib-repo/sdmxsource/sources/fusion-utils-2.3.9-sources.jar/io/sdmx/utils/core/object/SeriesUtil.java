package io.sdmx.utils.core.object;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.core.comparator.SeriesComparator;
import io.sdmx.utils.core.expression.Exp;

public class SeriesUtil {
	public static final String KEY_DELIMITER = ":";
	public static final char KEY_DELIMITER_CHAR = KEY_DELIMITER.charAt(0);
	
	
	/**
	 * 
	 * @param key series key in syntax A:UK:EMP
	 * @param dimensionCount expected number of dimension
	 * @return true if the key has the expected number of dimensions, and
	 */
	public static boolean isFullKey(String key, int dimensionCount) {
		String[] splitKey = SeriesUtil.splitKey(key);
		if(splitKey.length == dimensionCount) {
			for(int i=0; i < splitKey.length; i++) {
				if(splitKey[i].length() == 0 || splitKey[i].contains("\\+") || splitKey[i].equals("*")) {
					return false;
				}
			}
		}
		return true;
	}

	

	/**
	 * Based on a list of series which contain wildcarded (null) values, this method will attempt to expand out and fix
	 * the values by looking at other series with fixed values:
	 * <pre>
	 * Example:
	 * 		[A, -, -, -]
			[A, B, -, -]
			[A, C, -, -]
			[A, -, E, -]
	   Result:
	   		[A, B, E, -]
			[A, C, E, -]
	 * </pre>
	 * <b>Note :</b> All series keys must be the same length
	 * @param series
	 * @return
	 */
	public static List<String[]> mergeWildcardedSeries(List<String[]> series) {
		//List<String[]> returnList = new ArrayList<>();
		if(series != null) {
			int length = -1;
			for(String[] currentSeries : series) {
				if(length < 0) {
					length = currentSeries.length;
				} else if(length != currentSeries.length) {
					throw new SdmxException("mergeWildcardedSeries can not process series of varying lengths");
				}
			}
			List<String[]> wildcardedForDimension;
			List<String[]> fixedForDimension;
			List<String[]> expanded;
			for(int idx = 0; idx < length; idx++) {
				expanded = new ArrayList<>();
				wildcardedForDimension = new ArrayList<>();
				fixedForDimension = new ArrayList<>();
				//Process Dimension
				for(String[] currentSeries : series) {
					if(currentSeries[idx]==null) {
						wildcardedForDimension.add(currentSeries);
					} else {
						fixedForDimension.add(currentSeries);
						expanded.add(currentSeries);
					}
				}
				if(wildcardedForDimension.size() > 0 && fixedForDimension.size() > 0) {
					//Expand the wildcarded based on the fixed
					for(String[] wildcarded : wildcardedForDimension) {
						Set<String> fixedCodes = new HashSet<>();
						for(String[] fixed : fixedForDimension) {
							//Do all of the other fixed codes match?
							if(isMatch(wildcarded, fixed)) {
								fixedCodes.add(fixed[idx]);
							}
						}
						if(fixedCodes.size() == 0) {
							//no matches
							expanded.add(wildcarded);
						} else {
							for(String fixedCode : fixedCodes) {
								String[] newArr = wildcarded.clone();
								newArr[idx] = fixedCode;
								expanded.add(newArr);
							}
						}
					}
				} else {
					expanded.addAll(wildcardedForDimension);
					fixedForDimension.addAll(wildcardedForDimension);
				}
				series = expanded;
			}
		}
		Set<String> removeDuplicates = new HashSet<>();
		for(String[] r : series) {
			removeDuplicates.add(SeriesUtil.toSeriesKey(r));
		}
		series = new ArrayList<>();
		for(String r : removeDuplicates) {
			String[] split = SeriesUtil.splitKey(r);
			for(int i=0; i < split.length; i++) {
				if(split[i].length() == 0) {
					split[i] = null;
				}
			}
			series.add(split);
		}
		return series;
	}

	/**
	 * Returns true if the values in the two series match, takes into account wildcard  values, denoted by null
	 * entries in the array.  If the length of the series is different false is returned
	 * @param seriesA
	 * @param seriesB
	 * @return
	 */
	public static boolean isMatch(String[] seriesA, String[] seriesB) {
		int length = seriesA.length;
		if(seriesB.length != length) {
			return false;
		}
		for(int i=0; i < length; i++) {
			if(seriesA[i] == null || seriesB[i] == null || seriesA[i].equals(seriesB[i])) {
				continue;
			}
			return false;
		}
		return true;
	}

	/**
	 * Performs a split on a series key returning a string array.
	 *
	 * @param series the series to split
	 * @param splitLimit - the maximum number of items in the array before the split stops, -1 to indicate no limit.  1 results in an array of size 1, 2 size 2, etc.
	 * @return
	 */
	public static String[] splitKey(String series, int splitLimit) {
		boolean addLeading = series.startsWith(SeriesUtil.KEY_DELIMITER);
		boolean addTrailing = series.endsWith(SeriesUtil.KEY_DELIMITER);

		if(addLeading) {
			series = "~"+series;
		}
		if(addTrailing) {
			series = series+"~";
		}
		String[] split = series.split(SeriesUtil.KEY_DELIMITER, splitLimit);
		if(addLeading) {
			split[0] = "";
		}
		if(addTrailing) {
			split[split.length-1] = "";
		}

		return split;
	}

	/**
	 * Sorts a list of Series in the appropriate order
	 * @param series A list of elements which are colon separated
	 * @param sortOrder
	 * @return a new List
	 */
	public static List<String> sort(List<String> seriesList, SORT_ORDER sortOrder) {
		if (seriesList == null) {
			return Collections.emptyList();
		}

		if (sortOrder == null || sortOrder.equals(SORT_ORDER.NATURAL)) {
			return seriesList;
		}

		List<String[]> seriesAsArray = new ArrayList<>(seriesList.size());
		for (String aSeries : seriesList) {
			seriesAsArray.add( SeriesUtil.splitKey(aSeries) );
		}

		seriesAsArray.sort(new SeriesComparator(sortOrder));

		List<String> returnSeries = new ArrayList<>(seriesAsArray.size());
		for (String[] aSeries : seriesAsArray) {
			returnSeries.add( SeriesUtil.toSeriesKey(aSeries) );
		}

		return returnSeries;
	}

	/**
	 * Performs a split on a series key returning a string array, note if the first or last part of the key is an empty string, the split
	 * key length will be the expected length with a leading/trailing empty string entry
	 *
	 * @param series
	 * @return
	 */
	public static String[] splitKey(String series) {
		return splitKey(series, -1);
	}

	/**
	 * @param series in syntax A:B:C or with multiple selections A:B1+B2:C or wildcard A::C
	 * @param dimensionIds order of dimension ids
	 * @param andDelimiter example '+' to indicate A:B1+B2:C has a and operator of +
	 * @return a map of dimension id to the selections - if a dimension has no selections (i.e. wildcard) the map will not contain the dimension as a key
	 */
	public static Map<String, Set<String>> toDimensionSelections(String series, List<String> dimensionIds, char andDelimiter) {
		String[] split = splitKey(series, -1);

		Map<String, Set<String>> returnMap = new HashMap<>();
		for(int i=0; i < Math.max(dimensionIds.size(), split.length); i++) {
			String dimId = dimensionIds.get(i);
			String value = split[i];
			Set<String> values = null;
			if(value.length() == 0) {
				continue;
			}
			Exp exp = Exp.get(andDelimiter).setSupportLevels(false).parse(value);
			values = new HashSet<>(exp.size());
			for(int j=0; j < exp.size(); j++) {
				if(exp.getLevel(j) >= 0) {
					values.add(exp.getBlock(j));
				}
			}
			returnMap.put(dimId, values);
		}
		return returnMap;
	}

	/**
	 * Removes parts of a key, i.e A:UK:FR:DE with collapse dimensions 0 and 2 will result in :UK::DE
	 *
	 * @param series
	 * @return
	 */
	public static String collapseKey(String series, int...collapseDimensions) {
		if(collapseDimensions == null) {
			return series;
		}
		String[] split = SeriesUtil.splitKey(series);
		for(int i : collapseDimensions) {
			if(i >= split.length) {
				continue;
			}
			split[i] = "";
		}
		return SeriesUtil.toSeriesKey(split);
	}

	/**
	 * Replace explicit wildcard '*' with an empty string, A:*:EMP becomes A::EMP
	 *
	 * @param series
	 * @return
	 */
	public static String removeExplitWildcard(String series) {
		if(series.contains("*")) {
			String[] keySplit = SeriesUtil.splitKey(series);
			for(int i=0; i < keySplit.length; i++) {
				if(keySplit[i].equals("*")) {
					keySplit[i] = "";
				}
			}
			series = SeriesUtil.toSeriesKey(keySplit);
		}
		return series;
	}


	/**
	 * Concatenates the series array converting it into a single delimited string, example A:B:C
	 *
	 * If any array values are null, they will be replaced with an empty string
	 *
	 * @param series
	 * @return
	 */
	public static String toSeriesKey(String[] series) {
		return toSeriesKey(series, -1, "");
	}

	/**
	 * Concatenates the series array converting it into a single delimited string, example A:B:C
	 *
	 * @param series
	 * @param replaceMissing if a value is missing, it will be replaced with the passed in String
	 * @return
	 */
	public static String toSeriesKey(String[] series, String replaceMissing) {
		return toSeriesKey(series, -1, replaceMissing);
	}

	/**
	 * Concatenates the series array converting it into a single delimited string, example A:B:C
	 *
	 * If any array values are null, they will be replaced with an empty string
	 *
	 * @param series
	 * @param toIdx if more then -1, then the series key will be built using a subset of the array passed in, up to an including the value at this position in the array
	 * @return
	 */
	public static String toSeriesKey(String[] series, int toIdx) {
		return toSeriesKey(series, toIdx, "");
	}

	/**
	 * Concatenates the series array converting it into a single delimited string, example A:B:C
	 *
	 * @param series
	 * @param toIdx if more then -1, then the series key will be built using a subset of the array passed in, up to an including the value at this position in the array
	 * @param replaceMissing if a value is missing, it will be replaced with the passed in String

	 * @return
	 */
	public static String toSeriesKey(String[] series, int toIdx, String replaceMissing) {
		return toSeriesKey(series, toIdx, replaceMissing, null);
	}

	/**
	 * Concatenates the series array converting it into a single delimited string, example A:B:C
	 *
	 * @param series
	 * @param toIdx if more then -1, then the series key will be built using a subset of the array passed in, up to an including the value at this position in the array
	 * @param replaceMissing if a value is missing, it will be replaced with the passed in String
	 * @param wildcard if passed in, the output key will have the given indexes replaced with a wildcard '*' value

	 * @return
	 */
	public static String toSeriesKey(String[] series, int toIdx, String replaceMissing, Set<Integer> wildcard) {
		return toSeriesKey(series, toIdx, replaceMissing, wildcard, SeriesUtil.KEY_DELIMITER);
	}
	
	public static String toSeriesKey(String[] series, int toIdx, String replaceMissing, Set<Integer> wildcard, String delimiter) {
		if(series == null) {
			return null;
		}
		if(toIdx < 0) {
			toIdx = series.length;
		} else if(toIdx > series.length) {
			toIdx = series.length;
		}

		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(int i=0; i < toIdx; i++) {
			String val;
			if(wildcard != null && wildcard.contains(i)) {
				val = "*";
			} else {
				val = series[i] == null ? replaceMissing : series[i];
			}
			sb.append(concat + val);
			concat = delimiter;
		}
		return sb.toString();
	}

	public static String toSeriesKey(List<String> series) {
		if(series == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		String concat = "";
		int toIdx = series.size();
		for(int i=0; i < toIdx; i++) {
			String val = series.get(i);
			sb.append(concat + val);
			concat = SeriesUtil.KEY_DELIMITER;
		}
		return sb.toString();
	}
	
	/**
	 * Given a shortCode, break it into its constituent parts and if any part contains the specified delimiter then that part becomes encased in quote marks
	 * e.g. A:B:C would not change, but A:Foo,Bar:C would become A:"Foo,Bar":C
	 * @param shortCode
	 * @param delimiter
	 * @return a String of the shortCode which may have been modified
	 */
	public static String addQuotesToShortKeyInnerElementsOnly(String shortCode, String delimiter) {
		if (shortCode == null || !shortCode.contains(delimiter)) {
			return shortCode;
		}
		String[] split = SeriesUtil.splitKey(shortCode);
		for (int i=0; i < split.length; i++) {
			String aPart = split[i];
			if (aPart.contains(delimiter)) {
				split[i] = "\"" + aPart + "\"";
			}
		}
		return toSeriesKey(split);
	}
	
	/**
	 * Given a shortCode, determines if it has the specified delimiter and encapsulates the entire short code in quote marks.
	 * e.g. A:B:C would not change, but A:Foo,Bar:C would become "A:Foo,Bar:C"
	 * @param shortCode
	 * @param delimiter
	 * @return a String of the shortCode which may have been modified
	 */
	public static String addQuotesToShortKeyElements(String shortCode, String delimiter) {
		if (shortCode == null || !shortCode.contains(delimiter)) {
			return shortCode;
		}

		return "\"" + shortCode + "\"";
	}

	/**
	 * From a wildcarded series delimited (:) string (contains * or no value) will find all series which match from a set of series
	 * @param wildcardedSeries
	 * @param allSeries
	 * @return
	 */
	public static Set<String> expandSeries(String wildcardedSeries, Set<String> allSeries) {
		Set<String> returnSet = new HashSet<>();
		if(SeriesUtil.hasWildcards(wildcardedSeries)) {
			Pattern p = wildcardSeriesToPattern(wildcardedSeries);
			for(String series : allSeries) {
				if (p.matcher(series).matches()){
					returnSet.add(series);
				}
			}
		} else {
			returnSet.add(wildcardedSeries);
		}
		return returnSet;
	}

	/**
	 * Returns a wildcarded series to a pattern which can be used to match any other series, for example
	 *
	 * A:B::D becomes A:B:([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*:D
	 *
	 * The returned pattern can then be used to match an input to see if it matches the wildcard, for example
	 *
	 * Pattern p = wildcardSeriesToPattern("A:B::D");
	 * p.matcher("A:B:C:D").matches();  //true
	 * p.matcher("A:B:C:F").matches();  //false
	 *
	 * Plus operators are used to create groups:
	 * A:B+C:D becomes A:(B|C):D
	 *
	 * @param wildcardedSeries
	 * @param allowWildcardMatch if true then any seriesKeys with wildcards in (denoted by the presence of a *) can be used to match this pattern
	 * for example the series; A:B:C will generate a pattern which will match A:*:C
	 *
	 * @return
	 */
	public static Pattern wildcardSeriesToPattern(String wildcardedSeries, boolean allowWildcardMatch) {
		String regExStr = "([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-|\\*)*";


		if(wildcardedSeries.endsWith(SeriesUtil.KEY_DELIMITER)) {
			wildcardedSeries = wildcardedSeries + "*";
		}
		if(wildcardedSeries.startsWith(SeriesUtil.KEY_DELIMITER)) {
			wildcardedSeries = "*" + wildcardedSeries;
		}

		StringBuilder seriesRebuild = new StringBuilder();
		String split[] = wildcardedSeries.split(SeriesUtil.KEY_DELIMITER);
		String concat = "";
		for(String currentSplit : split) {
			seriesRebuild.append(concat);
			if(currentSplit.equals("*") || currentSplit.length() == 0) {
				seriesRebuild.append(regExStr);
			} else if(currentSplit.contains("+")){
				seriesRebuild.append("(");
				String concatBar = "";
				for(String queryParam : currentSplit.split("\\+")) {
					seriesRebuild.append(concatBar+queryParam);
					concatBar = "|";
				}
				if(allowWildcardMatch) {
					seriesRebuild.append(concatBar+"\\*");
				}
				seriesRebuild.append(")");
			} else if(allowWildcardMatch) {
				seriesRebuild.append("(\\*|"+currentSplit+")");
			} else {
				seriesRebuild.append(currentSplit);
			}
			concat = SeriesUtil.KEY_DELIMITER;
		}
		String regEx = seriesRebuild.toString();

		if(wildcardedSeries.startsWith(SeriesUtil.KEY_DELIMITER)) {
			regEx = regExStr + regEx;
		}
		if(wildcardedSeries.endsWith(SeriesUtil.KEY_DELIMITER)) {
			regEx = regEx+regExStr;
		}
		return Pattern.compile(regEx);
	}

	/**
	 * Returns a wildcarded series to a pattern which can be used to match any other series, for example
	 *
	 * A:B::D becomes A:B:([A-Z]|[a-z]|\\\\|@|[0-9]|_|\\$|\\-)*:D
	 *
	 * Plus operators are used to create groups:
	 * A:B+C:D becomes A:(B|C):D
	 *
	 *
	 * The returned patten can then be used to match an input to see if it matches the wildcard, for example
	 *
	 * Pattern p = wildcardSeriesToPattern("A:B::D");
	 * p.matcher("A:B:C:D").matches();  //true
	 * p.matcher("A:B:C:F").matches();  //false
	 *
	 * @param wildcardedSeries
	 * @return
	 */
	public static Pattern wildcardSeriesToPattern(String wildcardedSeries) {
		return wildcardSeriesToPattern(wildcardedSeries, false);
	}

	/**
	 * Converts a series with wildcards denoted by lack of colons to a wildcard denoted by :*: for example
	 * A::C becomes A:*:C
	 *
	 * This can be useful if attempting to match a wildcarded input series with a Pattern generated from wildcardSeriesToPattern(series, true).
	 *
	 * @param wildcardedSeries
	 * @param allSeries
	 * @return
	 */
	public static String toWildCardSeries(String series) {
		if(series.startsWith(SeriesUtil.KEY_DELIMITER)) {
			series = "*" + series;
		}
		if(series.endsWith(SeriesUtil.KEY_DELIMITER)) {
			series = series + "*";
		}
		return series.replaceAll(SeriesUtil.KEY_DELIMITER+SeriesUtil.KEY_DELIMITER, SeriesUtil.KEY_DELIMITER+"*"+SeriesUtil.KEY_DELIMITER);
	}



	/**
	 * Returns true if the series contains wildcards
	 * @param series
	 * @return
	 */
	public static boolean hasWildcards(String series) {
		return isWildCardSeries(series, -1);
	}
	
	/**
	 * Returns true if the series contains wildcards
	 * @param series
	 * @return
	 */
	public static boolean hasWildcards(String series, int expectedKeySize) {
		return isWildCardSeries(series, expectedKeySize);
	}

	/**
	 * @param series
	 * @param expectedKeySize if positive then this will check that the key contains 'n-1' occurrences of the delimiter i.e UK:EMP:M is a key size of 3, with 2 delimiters
	 * @return true if the series has missing values, or * to indicate wildcard
	 */
	public static boolean isWildCardSeries(String series, int expectedKeySize) {
		if(series.contains("*")) {
			return true;
		}
		if(series.contains("+")) {
			return true;
		}
		if(series.startsWith(SeriesUtil.KEY_DELIMITER)) {
			return true;
		}
		if(series.endsWith(SeriesUtil.KEY_DELIMITER)) {
			return true;
		}
		if(series.contains(SeriesUtil.KEY_DELIMITER+SeriesUtil.KEY_DELIMITER)) {
			return true;
		}
		if(expectedKeySize > 0) {
			int expectedDelimiterCOunt = expectedKeySize-1;
			return series.chars().filter(ch -> ch == KEY_DELIMITER_CHAR).count() < expectedDelimiterCOunt;
		}
		return false;
	}


	/**
	 * Expands series containing the plus operator
	 *
	 * Example:
	 * A:B+C:D
	 *
	 * Expands to:
	 * A:B:D
	 * A:C:D
	 *
	 * @param wildcardedSeries
	 * @param allSeries
	 * @return
	 */
	public static Set<String> expandSeries(String series) {
		Set<String> returnSet = new HashSet<>();
		returnSet.add(series);
		boolean expand = series.contains("+");
		while(expand) {
			expand = false;
			Set<String> expandedSet = new HashSet<>();
			for(String currentSeries : returnSet) {
				if(currentSeries.contains("+")) {
					expand = true;
					currentSeries = currentSeries+"~";
					String[] keySplit = currentSeries.split(SeriesUtil.KEY_DELIMITER);
					String lastKey = keySplit[keySplit.length-1];
					keySplit[keySplit.length-1] = lastKey.substring(0, lastKey.length()-1);
					for(int x=0; x < keySplit.length; x++) {
						if(keySplit[x].contains("+")) {
							String[] splitChoices = keySplit[x].split("\\+");
							for(int xx=0; xx < splitChoices.length; xx++) {
								StringBuilder sb = new StringBuilder();
								String concat = "";
								for(int xxx=0; xxx < keySplit.length; xxx++) {
									String toAppend = xxx == x ? splitChoices[xx] : keySplit[xxx];
									sb.append(concat+toAppend);
									concat = SeriesUtil.KEY_DELIMITER;
								}
								expandedSet.add(sb.toString());
							}
							break;
						}
					}
				}
			}
			if(expandedSet.size() > 0) {
				returnSet = expandedSet;
			}
		}

		return returnSet;
	}
}
