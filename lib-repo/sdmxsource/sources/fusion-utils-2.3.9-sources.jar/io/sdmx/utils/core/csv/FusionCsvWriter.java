package io.sdmx.utils.core.csv;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import io.sdmx.api.csv.DELIMITER;
import io.sdmx.utils.core.io.StreamUtil;

import com.opencsv.ResultSetHelper;
import com.opencsv.ResultSetHelperService;

/**
 * A copy of the CSVWriter but where the application of quotes is up to the user of this API
 * by calling the escapeString method
 *
 */
public class FusionCsvWriter {
	public static final int INITIAL_STRING_SIZE = 128;
	/**
	 * The character used for escaping quotes.
	 */
	public static final char DEFAULT_ESCAPE_CHARACTER = '"';
	/**
	 * The default separator to use if none is supplied to the constructor.
	 */
	public static final char DEFAULT_SEPARATOR = ',';
	/**
	 * The default quote character to use if none is supplied to the
	 * constructor.
	 */
	public static final char DEFAULT_QUOTE_CHARACTER = '"';
	/**
	 * The quote constant to use when you wish to suppress all quoting.
	 */
	public static final char NO_QUOTE_CHARACTER = '\u0000';
	/**
	 * The escape constant to use when you wish to suppress all escaping.
	 */
	public static final char NO_ESCAPE_CHARACTER = '\u0000';
	/**
	 * Default line terminator uses platform encoding.
	 */
	public static final String DEFAULT_LINE_END = "\n";
	private Writer rawWriter;
	private PrintWriter pw;
	private char separator;
	private char quotechar;
	private char escapechar;
	private String lineEnd;
	private ResultSetHelper resultService = new ResultSetHelperService();
	
	private int linesWritten = 0;

	public FusionCsvWriter(OutputStream out) {
		this(out, DELIMITER.COMMA, true);
	}

	public FusionCsvWriter(OutputStream out, DELIMITER delimiter) {
	    this(out, delimiter, true);
	}

	public FusionCsvWriter(OutputStream out, DELIMITER delimiter, boolean outputBOM) {
	    this(StreamUtil.getPrintWriterUTF8(out, outputBOM), delimiter.getDelimiter());
	}

	/**
	 * Constructs CSVWriter using a comma for the separator.
	 *
	 * @param writer the writer to an underlying CSV source.
	 */
	public FusionCsvWriter(Writer writer) {
		this(writer, DEFAULT_SEPARATOR);
	}

	/**
	 * Constructs CSVWriter with supplied separator.
	 *
	 * @param writer    the writer to an underlying CSV source.
	 * @param separator the delimiter to use for separating entries.
	 */
	public FusionCsvWriter(Writer writer, char separator) {
		this(writer, separator, DEFAULT_QUOTE_CHARACTER);
	}

	/**
	 * Constructs CSVWriter with supplied separator and quote char.
	 *
	 * @param writer    the writer to an underlying CSV source.
	 * @param separator the delimiter to use for separating entries
	 * @param quotechar the character to use for quoted elements
	 */
	public FusionCsvWriter(Writer writer, char separator, char quotechar) {
		this(writer, separator, quotechar, DEFAULT_ESCAPE_CHARACTER);
	}

	/**
	 * Constructs CSVWriter with supplied separator and quote char.
	 *
	 * @param writer     the writer to an underlying CSV source.
	 * @param separator  the delimiter to use for separating entries
	 * @param quotechar  the character to use for quoted elements
	 * @param escapechar the character to use for escaping quotechars or escapechars
	 */
	public FusionCsvWriter(Writer writer, char separator, char quotechar, char escapechar) {
		this(writer, separator, quotechar, escapechar, DEFAULT_LINE_END);
	}


	/**
	 * Constructs CSVWriter with supplied separator and quote char.
	 *
	 * @param writer    the writer to an underlying CSV source.
	 * @param separator the delimiter to use for separating entries
	 * @param quotechar the character to use for quoted elements
	 * @param lineEnd   the line feed terminator to use
	 */
	public FusionCsvWriter(Writer writer, char separator, char quotechar, String lineEnd) {
		this(writer, separator, quotechar, DEFAULT_ESCAPE_CHARACTER, lineEnd);
	}


	/**
	 * Constructs CSVWriter with supplied separator, quote char, escape char and line ending.
	 *
	 * @param writer     the writer to an underlying CSV source.
	 * @param separator  the delimiter to use for separating entries
	 * @param quotechar  the character to use for quoted elements
	 * @param escapechar the character to use for escaping quotechars or escapechars
	 * @param lineEnd    the line feed terminator to use
	 */
	public FusionCsvWriter(Writer writer, char separator, char quotechar, char escapechar, String lineEnd) {
		this.rawWriter = writer;
		this.pw = new PrintWriter(writer);
		this.separator = separator;
		this.quotechar = quotechar;
		this.escapechar = escapechar;
		this.lineEnd = lineEnd;
	}

	/**
	 * Writes the entire list to a CSV file. The list is assumed to be a
	 * String[]
	 *
	 * @param allLines         a List of String[], with each String[] representing a line of
	 *                         the file.
	 * @param applyQuotesToAll true if all values are to be quoted.  false if quotes only
	 *                         to be applied to values which contain the separator, escape,
	 *                         quote or new line characters.
	 */
	public void writeAll(List<String[]> allLines, boolean applyQuotesToAll) {
		for (String[] line : allLines) {
			writeNext(line, applyQuotesToAll);
		}
	}

	/**
	 * Writes the entire list to a CSV file. The list is assumed to be a
	 * String[]
	 *
	 * @param allLines a List of String[], with each String[] representing a line of
	 *                 the file.
	 */
	public void writeAll(List<String[]> allLines) {
		for (String[] line : allLines) {
			writeNext(line);
		}
	}

	/**
	 * Writes the column names.
	 *
	 * @param rs - ResultSet containing column names.
	 * @throws SQLException - thrown by ResultSet::getColumnNames
	 */
	protected void writeColumnNames(ResultSet rs) throws SQLException {
		writeNext(resultService.getColumnNames(rs));
	}

	/**
	 * Writes the entire ResultSet to a CSV file.
	 *
	 * The caller is responsible for closing the ResultSet.
	 *
	 * @param rs                 the result set to write
	 * @param includeColumnNames true if you want column names in the output, false otherwise
	 * @throws java.io.IOException   thrown by getColumnValue
	 * @throws java.sql.SQLException thrown by getColumnValue
	 */
	public void writeAll(java.sql.ResultSet rs, boolean includeColumnNames) throws SQLException, IOException {
		writeAll(rs, includeColumnNames, false);
	}

	/**
	 * Writes the entire ResultSet to a CSV file.
	 *
	 * The caller is responsible for closing the ResultSet.
	 *
	 * @param rs the Result set to write.
	 * @param includeColumnNames  include the column names in the output.
	 * @param trim remove spaces from the data before writing.
	 *
	 * @throws java.io.IOException   thrown by getColumnValue
	 * @throws java.sql.SQLException thrown by getColumnValue
	 */
	public void writeAll(java.sql.ResultSet rs, boolean includeColumnNames, boolean trim) throws SQLException, IOException {
		if (includeColumnNames) {
			writeColumnNames(rs);
		}

		while (rs.next()) {
			writeNext(resultService.getColumnValues(rs, trim));
		}
	}

	/**
	 * Writes all the lines to the file.
	 * @param values a Collection of Strings
	 */
	public void writeLine(Collection<String> values) {
		String[] line = values.toArray(new String[0]);
		writeNext(line);
	}

	public void writeLine(Collection<String> values, boolean applyQuotesToAll) {
        String[] line = values.toArray(new String[0]);
        writeNext(line, applyQuotesToAll);
    }

	/**
     * Writes the specified line to the file.
     *
     * @param nextLine a string array with each comma-separated element as a separate entry.
     */
	public void writeLine(String... values) {
		writeNext(values);
	}

	public void writeLine(boolean applyQuotesToAll, String... values) {
        writeNext(values, applyQuotesToAll);
    }

	/**
	 * Writes the next line to the file.
	 *
	 * @param nextLine         a string array with each comma-separated element as a separate
	 *                         entry.
	 * @param applyQuotesToAll true if all values are to be quoted.  false applies quotes only
	 *                         to values which contain the separator, escape, quote or new line characters.
	 */
	public void writeNext(String[] nextLine, boolean applyQuotesToAll) {
		StringBuilder ret = convertStringArrayToStringBuilder(nextLine, applyQuotesToAll);
		if (ret == null) {
            return;
        }
		ret.append(lineEnd);
		linesWritten++;
		pw.write(ret.toString());
	}

	public String getCSVString(String[] nextLine, boolean applyQuotesToAll) {
		StringBuilder ret = convertStringArrayToStringBuilder(nextLine, applyQuotesToAll);
		if (ret == null) {
		    return null;
		}
		return ret.toString();
	}

	private StringBuilder convertStringArrayToStringBuilder(String[] nextLine, boolean applyQuotesToAll) {
        if (nextLine == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder(INITIAL_STRING_SIZE);
        for (int i = 0; i < nextLine.length; i++) {

            if (i != 0) {
                sb.append(separator);
            }

            String nextElement = nextLine[i];

            if (nextElement == null) {
                nextElement = "";
            }

            if (applyQuotesToAll) {
                sb.append(quotechar);
                sb.append(nextElement);
                sb.append(quotechar);
            } else {
                sb.append(nextElement);
            }

        }
        return sb;
    }

	public String escapeString(String input, boolean applyQuotesToAll) {
		if(input == null) {
			return null;
		}
		Boolean stringContainsSpecialCharacters = stringContainsSpecialCharacters(input);
		if (quotechar == NO_QUOTE_CHARACTER  || (!applyQuotesToAll && !stringContainsSpecialCharacters)) {
			return input;
		}

		StringBuilder sb = new StringBuilder();
		if ((applyQuotesToAll || stringContainsSpecialCharacters) && quotechar != NO_QUOTE_CHARACTER) {
			sb.append(quotechar);
		}

		if (stringContainsSpecialCharacters) {
			sb.append(processLine(input));
		} else {
			sb.append(input);
		}

		if ((applyQuotesToAll || stringContainsSpecialCharacters) && quotechar != NO_QUOTE_CHARACTER) {
			sb.append(quotechar);
		}
		return sb.toString();
	}

	/**
	 * Writes the next line to the file.
	 *
	 * @param nextLine a string array with each comma-separated element as a separate entry.
	 */
	public void writeNext(String[] nextLine) {
		writeNext(nextLine, false);
	}

	/**
	 * checks to see if the line contains special characters.
	 * @param line - element of data to check for special characters.
	 * @return true if the line contains the quote, escape, separator, newline or return.
	 */
	private boolean stringContainsSpecialCharacters(String line) {
		return line.indexOf(quotechar) != -1 || line.indexOf(escapechar) != -1 || line.indexOf(separator) != -1 || line.contains(DEFAULT_LINE_END) || line.contains("\r");
	}

	/**
	 * Processes all the characters in a line.
	 * @param nextElement - element to process.
	 * @return a StringBuilder with the elements data.
	 */
	protected StringBuilder processLine(String nextElement) {
		StringBuilder sb = new StringBuilder(INITIAL_STRING_SIZE);
		for (int j = 0; j < nextElement.length(); j++) {
			char nextChar = nextElement.charAt(j);
			processCharacter(sb, nextChar);
		}

		return sb;
	}

	/**
	 * Appends the character to the StringBuilder adding the escape character if needed.
	 * @param sb - StringBuffer holding the processed character.
	 * @param nextChar - character to process
	 */
	private void processCharacter(StringBuilder sb, char nextChar) {
		if (escapechar != NO_ESCAPE_CHARACTER && (nextChar == quotechar || nextChar == escapechar)) {
			sb.append(escapechar).append(nextChar);
		} else {
			sb.append(nextChar);
		}
	}

	/**
	 * Flush underlying stream to writer.
	 *
	 * @throws IOException if bad things happen
	 */
	public void flush() throws IOException {
		pw.flush();
	}

	/**
	 * Close the underlying stream writer flushing any buffered content.
	 *
	 */
	public void close() {
		try {
			flush();
			pw.close();
			rawWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
//			throw new SdmxException(e, "Error trying to close CSV Writer");
		}
	}

	/**
	 * Checks to see if the there has been an error in the printstream.
	 *
	 * @return <code>true</code> if the print stream has encountered an error,
	 *          either on the underlying output stream or during a format
	 *          conversion.
	 */
	public boolean checkError() {
		return pw.checkError();
	}

	/**
	 * @return a count of the lines written
	 */
	public int getLinesWritten() {
	    return linesWritten;
	}

	/**
	 * Sets the result service.
	 * @param resultService - the ResultSetHelper
	 */
	public void setResultService(ResultSetHelper resultService) {
		this.resultService = resultService;
	}

	/**
	 * flushes the writer without throwing any exceptions.
	 */
	public void flushQuietly() {
		try {
			flush();
		} catch (IOException e) {
			// catch exception and ignore.
		}
	}
}
