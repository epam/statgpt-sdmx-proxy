package io.sdmx.utils.core.collection;

import java.util.List;

public class KeyValueArray {
	private String key;
	private List<String> values;

	public KeyValueArray(String key, List<String> values) {
		this.key = key;
		this.values = values;
	}

	public String getKey() {
		return key;
	}
	
	public List<String> getValues() {
		return values;
	}
}
