package io.sdmx.utils.core.application;

public class UniqueProcess implements Comparable<UniqueProcess> {
	private String vmid;
	private String application;
	private String machineIdentifier;

	
	public UniqueProcess(String vmid, String machineIdentifier, String application) {
		this.vmid = vmid;
		this.machineIdentifier = machineIdentifier;
		this.application = application;
	}

	public String getApplication() {
		return application;
	}

	public String getVmid() {
		return vmid;
	}

	public String getMachineIdentifier() {
		return machineIdentifier;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof UniqueProcess) {
			UniqueProcess that = (UniqueProcess) this;
			return that.toString().equals(this.getVmid());
		}
		return false;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}
	
	@Override
	public int compareTo(UniqueProcess o) {
		int returnVal= o.getApplication().compareTo(this.getApplication());
		if(returnVal == 0) {
			return o.toString().compareTo(this.getApplication());
		}
		return returnVal;
	}

	@Override
	public String toString() {
		return getVmid();
	}
}
