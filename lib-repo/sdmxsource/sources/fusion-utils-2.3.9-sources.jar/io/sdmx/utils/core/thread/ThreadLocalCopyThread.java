package io.sdmx.utils.core.thread;

import java.util.Map;
/**
 * Copies the contents of ThreadLocal from one thread to a new one
 */
public class ThreadLocalCopyThread extends Thread{
	private Map<Object, Object> localThreadContents;
	
	
	public ThreadLocalCopyThread() {
		super();
		this.localThreadContents = ThreadLocalUtil.getThreadContents();
	}

	@Override
	public void run() {
		//COPY THREAD LOCAL
		for(Object threadKey : localThreadContents.keySet()) {
			ThreadLocalUtil.storeOnThread(threadKey, localThreadContents.get(threadKey));
		}
	}
}
