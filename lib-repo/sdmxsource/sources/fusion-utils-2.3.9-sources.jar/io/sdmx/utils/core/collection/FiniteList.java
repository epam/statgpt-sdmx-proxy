package io.sdmx.utils.core.collection;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.sdmx.api.notification.Listener;

/**
 * A FiniteList is an ArrayList with the added functionality that it evicts objects
 * periodically.  The eviction time is given to the constructor of this object
 * and periodically the elements of this map are checked, and evicted if the
 * last time the object was accessed is longer then the eviction time.
 * <p/>
 * If the get method is called, the object's last access time is updated, all other
 * method calls do not update the last accessed time
 *
 * @param <E>
 */
public class FiniteList<E> extends ArrayList<E> {
	private static final long serialVersionUID = 1L;
	private int lifetimeMills;
	private static int i = 0;
	
	private Listener[] listeners;
    
	
	private Map<Key, Object> lastAccessedMap = new TreeMap<>();

	public FiniteList(int lifeTime, Listener... listeners ) {
		lifetimeMills = lifeTime;
		this.listeners = listeners;
		Thread t = new Thread(new CacheReseter());
		t.setDaemon(true);
		t.start();
	}
	
	public FiniteList(int lifeTime) {
		this(lifeTime, null);
	}
	
	@Override
	public E get(int index) {
		E returnObj =  super.get(index);
		if(returnObj != null) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(returnObj);
				lastAccessedMap.put(new Key(), returnObj);
			}
		}
		return returnObj;
	}
	
	@Override
	public boolean add(E e) {
		boolean b = super.add(e);
		if (b) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(e);
				lastAccessedMap.put(new Key(), e);
			}
		}
		return b;
	}
	
	@Override
	public E remove(int index) {
		E retVal = super.remove(index);
		if (retVal != null) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(retVal);
			}
		}
		return retVal;
	}

	@Override
	public boolean remove(Object o) {
		boolean retVal = super.remove(o);
		if (retVal) {
			synchronized(lastAccessedMap) {
				lastAccessedMap.values().remove(o);
			}
		}
		return retVal;
	}

	private void filterMap() {
		Set<Key> removeSet = new HashSet<>();
		long currentTime = new Date().getTime();
		long evictionTime = currentTime - lifetimeMills;
		
		synchronized(lastAccessedMap) {
			for(Key currentKey : lastAccessedMap.keySet()) {
				if(currentKey.getTime() < evictionTime) {
					removeSet.add(currentKey);
				} else {
					break;
				}
			}
			for(Key currentKey : removeSet) {
				Object o = lastAccessedMap.get(currentKey);
				if(listeners != null) {
					for(Listener listener : listeners) {
						listener.invoke(o);
					}
				}
				remove(o);
			}
		}
	}


	/**
	 * Resets the metadata and/or structrualMetadata cache depending on the cache settings
	 */
	private class CacheReseter implements Runnable {
		boolean isRunning = true;
		
		@Override
		public void run() {
			while(isRunning) {
				filterMap();
				try {
					Thread.sleep(lifetimeMills/2);
				} catch (InterruptedException ie) {
					Thread.currentThread().interrupt();
					isRunning = false;
				}
			}
		}
	}
	
	private class Key implements Comparable<Key> {
		private int num;
		private long time;
		
		Key() {
			time = new Date().getTime();
			num = FiniteList.i++;
		}
		
		long getTime() {
			return time;
		}
		
		@Override
		public boolean equals(Object obj) {
		    if (obj instanceof FiniteList.Key) {
	            Key that = (FiniteList.Key)obj;
	            return this.num == that.num;
		    }
		    return false;
		}
		
		@Override
		public int hashCode() {
			return num;
		}

		@Override
        public int compareTo(Key that) {
			return this.num - that.num;
		}
	}
}
