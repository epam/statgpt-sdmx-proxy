package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.HttpException;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxServiceUnavailableException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.utils.core.object.ObjectUtil;

public class URLUtil {
	private static final Logger LOG = LoggerFactory.getLogger(URLUtil.class);
	private static int CONNECT_TIMEOUT = 120000;
	private static int RESPONSE_TIMEOUT = 120000;
	private static String userAgent;

	// By default, accessing an HTTPS URL using the URL class results in an exception if the server's certificate
	// chain cannot be validated has not previously been installed in the truststore.
	// If you want to disable the validation of certificates for testing purposes, override the
	// default trust manager with one that trusts all certificates.
	static {

		// Install the all-trusting Trust Manager
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, getTrustAllCerts(), new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Setup the Verifier to trust everything
			HttpsURLConnection.setDefaultHostnameVerifier( (hostname, ssls) -> true);

		} catch (Exception e) {
			System.out.println(e);
		}

		// Now that the SSLContext has been set up to be all-trusting,
		// you can access an HTTPS URL without having the certificate in the truststore
	}

	private static TrustManager[] getTrustAllCerts() {
		return new TrustManager[]{
				new X509TrustManager() {
					@Override
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					@Override
					public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
						return;
					}

					@Override
					public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException{
						return;
					}
				}
		};
	}

	/**
	 * Opens an input stream to the URL, accepts GZIP encoding.
	 * @param url
	 * @return
	 */
	public static InputStream getInputStream(URL url) {
		LOG.debug("Get Input Stream from URL: " + url);

		// Verify URL is no longer performed when loading a URL. Why?
		// A number of users of SdmxCentral were experiencing issues when attempting to load Registrations into SdmxCentral.
		// These were often that their servers would return a 403 (forbidden) when a HEAD request was made, but actually would return
		// the correct XML when a normal GET request was made.
		// Since the verifyURL made debugging of users' issues very problematic, it has been removed
		//verifyURL(url, true);

		URLConnection connection = getconnection(url);
		return getInputStream(connection, null);
	}

	private static URLConnection getconnection(URL url)  {
		LOG.debug("Get URLConnection: " + url);
		// Make connection, use post mode, and send query
		URLConnection urlc;
		try {
			urlc = url.openConnection();
		} catch (IOException e) {
			throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, url.toString());
		}
		urlc.setDoOutput(true);
		urlc.setAllowUserInteraction(false);
		urlc.addRequestProperty("Accept-Encoding", "gzip");
		urlc.addRequestProperty("Accept", "*/*;q=1.0");

		if (ObjectUtil.validString(userAgent)) {
			urlc.setRequestProperty("User-Agent", userAgent);
		}
		urlc.setConnectTimeout(CONNECT_TIMEOUT);
		urlc.setReadTimeout(RESPONSE_TIMEOUT);


		// Allow "followRedirects"
		if(urlc instanceof HttpURLConnection) {
			HttpURLConnection httpConn = (HttpURLConnection) urlc;
			httpConn.setInstanceFollowRedirects(true);
		} else if(urlc instanceof HttpsURLConnection) {
			HttpsURLConnection httpConn = (HttpsURLConnection) urlc;
			httpConn.setInstanceFollowRedirects(true);
		}

		return urlc;
	}

	/**
	 * Verify a connection to a comma-separated list of servers.
	 * Each element in the comma-separated list must be a host and port pair separated by a colon.
	 * E.g.: myserver:8080,myserver:8081,thirdserver:8080
	 * @param servers the list of servers
	 * @param timeout optional set to -1 for no timeout
	 * @return map of server to ping response time in milliseconds, -1 indicates connection timeout
	 */
	public static Map<String, Long> pingHosts(String servers, int timeout) {
		Map<String, Long> returnMap = new HashMap<>();
		String[] hostPortPairs = servers.split(",");
		for (String hostPortPair : hostPortPairs) {
			String[] elements = hostPortPair.split(":");
			if(elements.length != 2) {
				throw new SdmxSemmanticException("Illegal server format for string '"+hostPortPair+"'. expecting format 'server:port'");
			}
			String host = elements[0].trim();
			String port = elements[1].trim();
			Integer portInt;
			try {
				portInt =  Integer.parseInt(port);
			} catch(NumberFormatException e) {
				throw new SdmxSemmanticException("Illegal server format for string '"+hostPortPair+"'. expecting format 'server:port' where port is a valid Integer");
			}
			long timeNow = System.currentTimeMillis();

			if (URLUtil.pingHost(host, portInt, timeout)) {
				long timeComplete = System.currentTimeMillis();
				returnMap.put(hostPortPair, timeComplete-timeNow);
			} else {
				returnMap.put(hostPortPair, -1l);
			}
		}
		return returnMap;
	}

	/**
	 * Verify a connection to a url with an optional timeout
	 * @param host
	 * @param port
	 * @param timeout - optional set to -1 for no timeout
	 * @return
	 */
	public static boolean pingHost(String host, int port, int timeout) {

		try (Socket socket = new Socket()) {
			if(timeout == -1) {
				socket.connect(new InetSocketAddress(host, port));
			}else {
				socket.connect(new InetSocketAddress(host, port), timeout);
			}
			return true;
		} catch (IOException e) {
			return false; // Either timeout or unreachable or failed DNS lookup.
		}
	}

	/**
     * Appends query parameters to the URL
     * @param url
     * @param parameters
     * @return
     */
    public static String appendQueryParameters(String url, Map<String, String> parameters) {
        if(parameters == null || parameters.size() == 0) {
            return url;
        }
        StringBuilder sb = new StringBuilder(url);
        String concat = url.contains("?") ? "&" : "?";
        for(String param : parameters.keySet()) {
            sb.append(concat + param + "=" + parameters.get(param));
            concat = "&";
        }
        return sb.toString();
    }

	private static InputStream getInputStream(URLConnection urlc, Object payload) {
		InputStream stream;
		try {
			if(payload != null) {
				//Send Payload
				PrintStream ps = new PrintStream(urlc.getOutputStream());
				ps.print(payload);
				ps.close();
			}
			stream = getInputStream(urlc);
		} catch(IOException e) {
			throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, e.getMessage());
		}
		if(urlc.getContentEncoding() != null && urlc.getContentEncoding().equals("gzip")) {
			LOG.debug("Response received as GZIP");
			try {
				stream = new GZIPInputStream(stream);
			} catch (IOException e) {
				throw new SdmxException(e, "I/O Ecception while trying to unzip stream retrieved from service:" +urlc.getURL());
			}
		}
		return stream;
	}

	private static InputStream getInputStream(URLConnection urlc) {
		try {
			return urlc.getInputStream();
		}  catch(ConnectException c) {
			LOG.error("ConnectException:" +c.getMessage());
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, urlc.getURL());
		}  catch(SocketException c) {
			LOG.error("SocketException:" +c.getMessage());
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, urlc.getURL());
		} catch(SocketTimeoutException c) {
			LOG.error("SocketTimeoutException:" +c.getMessage());
			throw new SdmxServiceUnavailableException(c, ExceptionCode.WEB_SERVICE_SOCKET_TIMEOUT, urlc.getReadTimeout());
		} catch (IOException e) {
			if(urlc instanceof HttpURLConnection) {
				try {
					if(((HttpURLConnection) urlc).getResponseCode() == 401) {
						throw new SdmxUnauthorisedException(e.getMessage());
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				HttpURLConnection httpConnection = (HttpURLConnection) urlc;
				InputStream is = httpConnection.getErrorStream();
				if(is != null) {
					return is;
				}
			}
			String message = null;
			if(e.getMessage().contains("Server returned HTTP response code:")) {
				String split = e.getMessage().split(":")[1];
				split = split.trim();
				split = split.substring(0, split.indexOf(" "));

				try {
					int responseCode = Integer.parseInt(split);

					switch(responseCode) {
					case 400 : message = "Response Code 400 = The request could not be understood by the server due to malformed syntax"; break;
					case 401 : message = "Response Code 401 = Authentication failure"; break;
					case 403 : message = "Response Code 403 = The server understood the request, but is refusing to fulfill it"; break;
					case 404 : message = "Response Code 404 = Page not found"; break;
					//TODO Do others
					}
				} catch (Throwable th) {
					//DO NOTHING
				}
			}
			if(message != null) {
				throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, message);
			} else  {
				throw new SdmxServiceUnavailableException(e, ExceptionCode.WEB_SERVICE_BAD_CONNECTION, urlc.getURL());
			}
		}
	}

	/**
	 * Returns a URL from a String, throws a SdmxException if the URL String is not a valid URL
	 * @param urlStr
	 * @return
	 */
	public static URL getURL(String urlStr) {
		try {
			return new URL(urlStr);
		} catch (MalformedURLException e) {
			throw new SdmxException("Malformed URL: " + urlStr);
		}
	}

	/**
	 * Ensures the URL exists
	 * @param url
	 * @param followRedirects if true then 3xx status codes are deemed okay
	 * @throws IllegalArgumentException if the verification fails
	 */
	private static void verifyURL(URL url, boolean followRedirects) throws IllegalArgumentException {
		if(!urlExists(url)) {
			throw new IllegalArgumentException("URL could not be resolved: " + url.toString());
		}
		int responseCode = getResponseCode(url);
		if(responseCode == 0) {
			//It is not a HTTP URL
			return;
		}
		String responseCodeStr = Integer.toString(responseCode);
		if (responseCodeStr.startsWith("1") ||
				responseCodeStr.startsWith("2") ) {
			return;
		}
		if (responseCodeStr.startsWith("3") && !followRedirects) {
			throw new IllegalArgumentException("URL '"+url.toString()+"' returns an HTTP '"+responseCodeStr+"' response code (Redirect). Redirections are not supported");
		} else if (responseCodeStr.startsWith("401")) {
			throw new IllegalArgumentException("URL '"+url.toString()+"' returns an HTTP Redirect 401 response code (Unauthorised)");
		}
		else if (responseCodeStr.startsWith("402")) {
			throw new IllegalArgumentException("URL '"+url.toString()+"' returns an HTTP Redirect 402 response code (Payment Required)");
		}

		else if (responseCodeStr.startsWith("407")) {
			throw new IllegalArgumentException("URL '"+url.toString()+"' returns an HTTP Redirect 407 response code (Proxy Authentication Required)");
		}
	}

	/**
	 * Returns true if the HTTP Status is any of the following values:
	 * <ul>
	 * <li> 1xx - Informational</li>
	 * <li> 2xx - Successful</li>
	 * <li> 3xx - Redirection</li>
	 * <li> 401 Unauthorized</li>
	 * <li> 402 Payment Required</li>
	 * <li> 405 Method Not Allowed</li>
	 * <li> 406 Not Acceptable</li>
	 * <li> 407 Proxy Authentication Required </li>
	 * </ul>
	 * @param fileUri
	 * @return
	 */
	public static boolean urlExists(URL url) {

		try {
			int responseCode = getResponseCode(url);
			// Check the HTTP response code
			String responseCodeStr = Integer.toString(responseCode);
			if (responseCodeStr.startsWith("0") ||
					responseCodeStr.startsWith("1") ||
					responseCodeStr.startsWith("2") ||
					responseCodeStr.startsWith("3") ||
					responseCodeStr.equals("401") ||
					responseCodeStr.equals("402") ||
					responseCodeStr.equals("405") ||
					responseCodeStr.equals("406") ||
					responseCodeStr.equals("407")) {
				return true;
			}

			LOG.warn("URL "+url + " returns status code: " + responseCodeStr);
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Returns the response code from a URL
	 * <ul>
	 * <li> 1xx - Informational</li>
	 * <li> 2xx - Successful</li>
	 * <li> 3xx - Redirection</li>
	 * <li> 401 Unauthorized</li>
	 * <li> 402 Payment Required</li>
	 * <li> 405 Method Not Allowed</li>
	 * <li> 407 Proxy Authentication Required </li>
	 * </ul>
	 * @param fileUri
	 * @return
	 */
	public static int getResponseCode(URL url) {
		try {
			HttpURLConnection.setFollowRedirects(false);
			// note : you may also need
			//        HttpURLConnection.setInstanceFollowRedirects(false)
			URLConnection con = url.openConnection();

			//FR-1767 https connection refused from www.[domain].[subdomain].com when security certificate is registered for .[domain].[subdomain].com
			if(con instanceof HttpsURLConnection) {
				HttpsURLConnection httpsCon = (HttpsURLConnection) con;
				HostnameVerifier hv = (arg0, arg1) -> true;
				httpsCon.setHostnameVerifier(hv);
			}

			if(con instanceof HttpURLConnection) {
				HttpURLConnection httpCon = (HttpURLConnection) con;
				httpCon.setRequestMethod("HEAD");
				// Check the HTTP response code
				return httpCon.getResponseCode();
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	/**
	 * Tests if the current url has been encoded.
	 * </br>
	 * This will return true even if one char in the URl is encoded. it will not check if the whole URL has been encoded correctly
	 * </br>
	 * For example, the url "http://www.example.com/some url after slash" then this would return false, but for the url "http://www.example.com/some%20url%20after%20slash" it would return true.</br>
	 * however this "http://www.example.com/some url after%20slash" would also return true.
	 *
	 * @param url
	 * @param charSet -  the decoding charset to use. example "UTF-8"
	 * @return
	 * @throws UnsupportedEncodingException - If character encoding needs to be consulted, but named character encoding is not supported
	 */
	public static boolean isUrlEncoded(String url, String charSet) throws UnsupportedEncodingException{
		return !url.equals(URLDecoder.decode(url, charSet));
	}

	/**
	 * <p>
	 * Given a URL of type String, this method will make sure that HTTP or HTTPS has been placed at the start.
	 * </p>
	 * <p>
	 * For example. if url is "localhost:8080/FusionRegistry", then this method will concatenate http to the start.
	 * </p>
	 * <p>
	 * If the URL has https or http at the start, then it will just return it back
	 * </p>
	 * @param url
	 * @return
	 */
	public static String enforceHttpProtocol(String url){
		if(!ObjectUtil.validString(url)){
			return url;
		}
		url = url.trim();
		if(!(url.startsWith("http") || url.startsWith("https"))){
			url = "http://"+url;
		}
		return url;
	}
	
	/**
	 * Strips any trailing slashes of the supplied URL and replaces any multiple occurrences of / with a single occurrence without
	 * modifying the http:// or https:// protocol.
	 *
	 * For example a url like: http://localhost:800/fusionmatrix  would not be changed.
	 * A url like: http://localhost:800/fusionmatrix/ would become http://localhost:800/fusionmatrix .
	 * A url like: https://localhost:800/fusionmatrix//foo///bar/test/flip// would become: https://localhost:800/fusionmatrix/foo/bar/test/flip
	 * </p>
	 * @param url The URL to sanitise.
	 * @return
	 */
	public static String sanitiseSlashesInUrl(String url) {
		while (url.length() > 0 && url.endsWith("/")) {
			url = url.substring(0, url.length() -1);
		}
		url = url.replaceAll("(?<!(http:|https:))[//]+", "/");
		return url;
	}

	public static void setUserAgent(String val) {
		URLUtil.userAgent = val;
	}

	/**
	 * Sets response timeout in Seconds
	 * @param responseTimeout
	 */
	public static void setResponseTimeout(int responseTimeout) {
		RESPONSE_TIMEOUT = responseTimeout*1000;
	}
	
	/**
	 * Sets connect timeout in Seconds
	 * @param responseTimeout
	 */
	public static void setConnectTimeout(int responseTimeout) {
		CONNECT_TIMEOUT = responseTimeout*1000;
	}

	/**
	 * Ensures that the specified String is a URL and is for one of the permitted Protocols
	 * @param urlValue A String that must represent a URL
	 * @param permittedProtocols A list of permitted PROTOCOL values
	 */
	public static void enforceProtocol(String urlValue, PROTOCOL... permittedProtocols) {
		try {
			URL url = new URL(urlValue);
			enforceProtocol(url, permittedProtocols);
		} catch (MalformedURLException e) {
			throw new HttpException("Bad Request: Illegal URL supplied: " + urlValue, 400);
		}
	}
	
	/**
	 * Ensures that the specified URL is of one of the permitted Protocols
	 * @param url
	 * @param permittedProtocols A list of permitted PROTOCOL values
	 */
	public static void enforceProtocol(URL url, PROTOCOL... permittedProtocols) {
		if (url == null) {
			throw new HttpException("Bad Request: No URL supplied", 400);
		}
		
		String protocol = url.getProtocol();
		if (!ObjectUtil.validString(protocol)) {
			throw new HttpException("Bad Request: No protocol supplied", 400);
		}

		protocol = protocol.trim().toLowerCase();
		for (PROTOCOL currProtocol : permittedProtocols) {
			if (currProtocol.getValue().equals(protocol)) {
				return;
			}
		}
		throw new HttpException("Forbidden! The protocol: '" + protocol + "' is not supported", 403);
	}
	
	/**
	 * An enum of Protocols.
	 * This is not an exhaustive list as we are only interested in a small subset of all the possible types.
	 */
	public enum PROTOCOL {
		HTTP("http"),
		HTTPS("https"),
		FILE("file");

		private String value;

		PROTOCOL(String string) {
			this.value = string;
		}
		
		public String getValue() {
			return this.value;
		}
	}
}
