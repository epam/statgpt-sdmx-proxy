package io.sdmx.utils.core.audit;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import io.sdmx.api.logging.IFusionLogEvent;
import io.sdmx.api.logging.ILogDistributionManager;
import io.sdmx.api.process.IProcess;
import io.sdmx.utils.core.application.SingletonStore;

public class LogUtil {
	private static ILogDistributionManager logDistributionManager;
	
	static {
		SingletonStore.registerInterest(ILogDistributionManager.class, e-> logDistributionManager = e);  //set when it is ready
	}
	
	/**
	 * Run the process in debug and outputs the information to the output stream in the given format
	 * @param out output stream to write the logs to (in JSON format)
	 * @param p
	 * @param packages that should be explicitly ignored so the logging from these is not recorded. Useful for "noisy" pacakages such as Hibernate
	 * 
	 * Example Output
	 * {
	 *   "success": true,
	 *   "messages": [{
	 *    "AuditId":"697e8a48-2443-49c4-9e7c-63c5dd780dcb",
	 *    "Level":4,
	 *    "Logger":"ROOT",
	 *    "Message":"process failed",
	 *    "Thread":"http-nio-8080-exec-8",
	 *    "LogTime":1716291294160}
	 *    }]
	 * }
	 * 
	 */
	//TODO This should take an InformationFormat and delegate the write to a manager (using the manager-> factory paradigm)
	public static void outputInDebug(OutputStream out, IProcess p, String... packagesToIgnore) {
		runInDebug(()-> {
			
			LoggedProcess lp = new LoggedProcess();
			Logger rootLogger = getRootLogger();
			if(logDistributionManager != null) {
				//reuse the existing log distribution framework which will include audit information on the log event
				InMemoryLogDistributionEngine distributionEngine = new InMemoryLogDistributionEngine();
				logDistributionManager.runProcessWithTempDistributionEngine(distributionEngine, ()-> {
					try {
						p.runProcess();
						lp.setSuccess();
					} catch(Throwable th) {
						rootLogger.error("Process failed", th);
					}
				});
				lp.setLogEvents(distributionEngine.getLoggingEvents());
			} else {
				//Create a custom appender to catch these logging events, no audit information will be captured
				CustomAppender customAppender = new CustomAppender();
				customAppender.setContext((LoggerContext) LoggerFactory.getILoggerFactory());
				customAppender.start();
				try {
					rootLogger.addAppender(customAppender);
					p.runProcess();
					lp.setSuccess();
				} catch(Throwable th) {
					rootLogger.error("Process failed", th);
				} finally {
					// Finally restore the 'root logger' level and remove the Appender
					customAppender.stop();
					rootLogger.detachAppender(customAppender);
				}
				lp.setLogEvents(customAppender.getLoggingEvents());
			}
			try {
				out.write(JsonBuilderLogEvent.build(lp).toString().getBytes());
			} catch (IOException e) {
				e.printStackTrace(); //problem writing the logs
			}
		}, packagesToIgnore
		);
	}
	
	/**
	 * Runs the process in debug mode by setting the root logger to debug.
	 * On finish, reverts back to the original log level set on the root logger and for any logger for any ignored packages
	 * @param p
	 */
	public static void runInDebug(IProcess p, String... packagesToIgnore) {
		// Store the current level of the 'root logger' and create a new Appender
		Logger rootLogger = getRootLogger();
		Level currentLevel = rootLogger.getLevel();
		
		Map<String, Level> toRestore = new HashMap<>();
		
		try {
			rootLogger.setLevel(Level.DEBUG);
			
			for (String packageName : packagesToIgnore) {
				Logger aLogger = (ch.qos.logback.classic.Logger)LoggerFactory.getLogger(packageName);
				toRestore.put(packageName, aLogger.getLevel());
				aLogger.setLevel(Level.OFF);
			}
			
			p.runProcess();
		} finally {
			rootLogger.setLevel(currentLevel);
			
			for (String packageName : packagesToIgnore) {
				Level lvl = toRestore.get(packageName);
				Logger aLogger = (ch.qos.logback.classic.Logger)LoggerFactory.getLogger(packageName);
				aLogger.setLevel(lvl);
			}
			
		}
	}
	
	private static Logger getRootLogger() {
		return (ch.qos.logback.classic.Logger)LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
	}
	
	/**
	 * A custom Appender class which logs all log events into a List
	 */
	private static class CustomAppender extends AppenderBase<ILoggingEvent> {

	    private List<IFusionLogEvent> logList = new ArrayList<>();

	    @Override
	    protected void append(ILoggingEvent eventObject) {
	    	logList.add(new FusionLogEvent(eventObject, null, null));
	    }
	    
	    public List<IFusionLogEvent> getLoggingEvents() {
	        return logList;
	    }
	}
	
}
