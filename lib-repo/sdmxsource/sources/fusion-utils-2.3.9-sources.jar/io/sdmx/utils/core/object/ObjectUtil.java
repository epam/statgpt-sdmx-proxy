package io.sdmx.utils.core.object;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import io.sdmx.api.exception.SdmxSemmanticException;


/**
 * Utility class providing helper methods for generic Objects.
 */
public class ObjectUtil {
	public static final String POUND_SIGN = String.valueOf((char)163);
	public static final String PRIVATE_USE_ONE = String.valueOf((char)8216); //LEFT SINGLE QUOTATION MARK
	public static final String PRIVATE_USE_TWO = String.valueOf((char)8217); //RIGHT SINGLE QUOTATION MARK

	private static final  String[] ALPHABET = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

	public static void assertTrue(Boolean bool) {
		assertTrue(null, bool);
	}
	
	public static void assertTrue(String message, Boolean bool) {
		if(bool == null || bool != Boolean.TRUE) {
			throw new IllegalArgumentException(message != null ? message : "True Expected");
		}
	}
	public static void assertFalse(String message, Boolean bool) {
		if(bool == null || bool != Boolean.FALSE) {
			throw new IllegalArgumentException(message != null ? message : "False Expected");
		}
	}
	
	public static void assertFalse(Boolean bool) {
		assertFalse(null, bool);
	}
	
	public static void assertEquals(Object o1, Object o2) {
		assertEquals(null, o1, o2);
	}
	
	public static void assertCollectionEquals(Collection<?> c1, Collection<?> c2) {
		assertCollectionEquals(null, c1, c2);
	}
	
	public static void assertCollectionEquals(String message, Collection<?> c1, Collection<?> c2) {
		if(!ObjectUtil.equivalentCollection(c1, c2)) {
			throw new IllegalArgumentException(message != null ? message :"Collectionsa are not equal");
		}
	}
	
	public static void assertEquals(String message, Object o1, Object o2) {
		if(!ObjectUtil.equivalent(o1, o2) ) {
			throw new IllegalArgumentException(message != null ? message :"Not equal: "+o1+ " and " + o2);
		}
	}

	public static <T> T assertNotNull(T obj) {
		return assertNotNull(null, obj);
	}

	public static <T> T assertNotNull(String message, T obj) {
		if(obj == null) {
			throw new RuntimeException(message != null ? message : "Required object is null");
		}
		return obj;
	}

	public static void assertNull(Object obj) {
		assertNotNull(null, obj);
	}
	
	public static void assertNull(String message, Object obj) {
		if(obj == null) {
			throw new RuntimeException(message != null ? message : "Expected null");
		}
	}


	
	/**
	 * Takes a positive int, zero indexed, and converts it to an Excel style alpha. For example A, B, C, D....AA, AB, AC
	 * @param idx
	 * @return
	 */
	public static String intToAlpha(int idx) {
		String letter = "";
		int major = new Double(Math.floor(idx / 26)).intValue();
		int minor = idx - (major * 26);
		if(major > 0) {
			letter += ALPHABET[major-1];
		}
		letter += ALPHABET[minor];
		return letter;
	}

	/**
	 * 
	 * @param str
	 * @param defaultIfNull
	 * @return
	 */
	public static Integer toInteger(String str, Integer defaultIfNull) {
		if(!validString(str)) {
			return defaultIfNull;
		}
		if(!isInteger(str))  {
			throw new SdmxSemmanticException(str+" is not a valid Integer");
		}
		try {
			return Integer.valueOf(str);
		} catch (Exception e) {
			throw new SdmxSemmanticException(str+" is not a valid Integer");
		}
	}

	public static boolean isInteger(String s) {
		return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
		if(s.isEmpty()) return false;
		for(int i = 0; i < s.length(); i++) {
			if(i == 0 && s.charAt(i) == '-') {
				if(s.length() == 1) return false;
				else continue;
			}
			if(Character.digit(s.charAt(i),radix) < 0) return false;
		}
		return true;
	}

	/**
	 * Creates a new Array, and copies the contents from a1 if it is not null, and then copies the conents from a2 if it is not null
	 * into the copy, and returns the copy.
	 * 
	 * Example
	 * a1 = [A, null, B]
	 * a2 = [null, X, null]
	 * return [A, X, B]
	 * 
	 * @param a1
	 * @param a2
	 * @return
	 */
	public static <T extends Object> T[] mergeArrays(T[] a1, T[] a2) {
		if(a1 != null && a2 != null) {
			boolean cloneA1 = a1.length >= a2.length;
			T[] returnArr =  cloneA1 ? a1.clone() : a2.clone();
			if(cloneA1) {
				for(int i=0; i < a2.length; i++) {
					if(a2[i] != null) {
						returnArr[i] = a2[i];
					}
				}
			} else {
				for(int i=0; i < a1.length; i++) {
					if(a1[i] != null) {
						returnArr[i] = a1[i];
					}
				}
			}
			return returnArr;
		} else if(a1 != null) {
			return a1.clone();
		} else if(a2 != null) {
			return a2.clone();
		}
		return null;
	}
	
	/**
	 * Creates a new Array, and copies the contents from a1 if it is not null and not an empty string, and then copies the contents from a2 if it is not null
	 * into the copy, and returns the copy.
	 * 
	 * Example
	 * a1 = [A, "", B]
	 * a2 = [null, X, null]
	 * return [A, X, B]
	 * 
	 * @param a1
	 * @param a2
	 * @return
	 */
	public static String[] mergeStringArrays(String[] a1, String[] a2) {
		if(a1 != null && a2 != null) {
			boolean cloneA1 = a1.length >= a2.length;
			String[] returnArr =  cloneA1 ? a1.clone() : a2.clone();
			if(cloneA1) {
				for(int i=0; i < a2.length; i++) {
					if(ObjectUtil.validString(a2[i])) {
						returnArr[i] = a2[i];
					}
				}
			} else {
				for(int i=0; i < a1.length; i++) {
					if(ObjectUtil.validString(a1[i])) {
						returnArr[i] = a1[i];
					}
				}
			}
			return returnArr;
		} else if(a1 != null) {
			return a1.clone();
		} else if(a2 != null) {
			return a2.clone();
		}
		return null;
	}


	public static <T extends Object> Set<T> toSet(T[] o) {
		return new HashSet<>(Arrays.asList(o));
	}

	public static String toString(Collection<? extends Object> collection) {
		return Arrays.toString(collection.toArray());
	}

	public static <V, K> Map<V, K> invert(Map<K, V> map) {

		Map<V, K> inv = new HashMap<>();

	    for (Entry<K, V> entry : map.entrySet()) {
			inv.put(entry.getValue(), entry.getKey());
		}

		return inv;
	}

	/**
	 * Returns whether all of the strings are not null and have a length of greater than zero
	 * after trimming the leading and trailing whitespace.
	 * @param strings
	 * @return
	 */
	public static boolean validString(String...strings) {
		if(strings == null || strings.length == 0) {
			return false;
		}
		for(String str : strings) {
			if(str == null || str.length() == 0) {
				return false;
			}
			if(str.trim().length() == 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns whether at least one of the strings is not null and has a length of greater than zero
	 * after trimming the leading and trailing whitespace
	 * @param strings
	 * @return
	 */
	public static boolean validOneString(String...strings) {
		if (strings == null) {
			return false;
		}
		for(String str : strings) {
			if(str != null && str.length() > 0) {
				if(str.trim().length() == 0) {
					return false;
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns whether all of the objects are not null
	 * @param objs
	 * @return
	 */
	public static boolean validObject(Object... objs) {
		if (objs == null) {
			return false;
		}
		for(Object obj : objs) {
			if(obj == null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns true if at least one of the objects are not null
	 * @param objs
	 * @return
	 */
	public static boolean validOneObject(Object... objs) {
		if (objs == null) {
			return false;
		}
		for(Object obj : objs) {
			if(obj != null) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns true if:
	 * <ul>
	 *   <li>Both Strings are null</li>
	 *   <li>Both Strings are equal</li>
	 * </ul>
	 * @param s1
	 * @param s2
	 * @return
	 */
	@Deprecated
	public static boolean equivalentString(String s1, String s2) {
		return equivalent(s1, s2);
	}
	
	/**
	 * True is arrays are either:
	 * <ol>
	 * <li>both null</li>
	 * <li>both same length and every object is ObjectUtil.equivalent</li>
	 * </ol>
	 * @param o1
	 * @param o2
	 * @param skipIndexes an optional array of indexes to skip in the checks
	 * @return
	 */
	public static boolean equivalentArray(Object[] o1, Object[] o2, int... skipIndexes) {
		if(o1 == null && o2 == null) {
			return true;
		}
		if(o1 == null && o2 != null) {
			return false;
		}
		if(o2 == null && o1 != null) {
			return false;
		}
		if(o1.length != o2.length) {
			return false;
		}
		
		outer:
		for(int i=0; i < o1.length; i++) {
			if(skipIndexes != null) {
				for(int skip : skipIndexes) {
					if(skip == i) {
						continue outer;
					}
				}
			}
			if(!equivalent(o1[i], o2[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns true if:
	 * <ul>
	 *   <li>Both Strings are null</li>
	 *   <li>Both Strings are equal</li>
	 * </ul>
	 * @param o1
	 * @param o2
	 * @return
	 */
	public static boolean equivalent(Object o1, Object o2) {
		if(o1 == null && o2 == null) {
			return true;
		}
		if(o1 == null && o2 != null) {
			return false;
		}
		if(o2 == null && o1 != null) {
			return false;
		}

		return o1.equals(o2);
	}

	/**
	 * Ensures the collection contains both the same content, and is in the same order
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static boolean equivalentCollection(Collection<?> c1, Collection<?> c2) {
	    if(c1 == null && c2 == null) {
            return true;
        }
        if(c2 == null && c1 != null) {
            return false;
        }
        if(c1 == null && c2 != null) {
            return false;
        }
		if (!containsAll(c1, c2) ) {
			return false;
		}
		Iterator<?> it1 = c1.iterator();
		Iterator<?> it2 = c2.iterator();
		while(it1.hasNext()) {
			Object obj1 = it1.next();
			Object obj2 = it2.next();
			if(!equivalent(obj1, obj2)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Ensures the sets contain the same content, order is not important
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static boolean equivalentSet(Set<?> c1, Set<?> c2) {
		return containsAll(c1, c2);
	}

	/**
	 * Ensures the maps contain the same content, by applying a equals to each value
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static boolean equivalentMap(Map<?, ?> c1, Map<?,?> c2) {
		if(c1 == null && c2 == null) {
			return true;
		}
		if(c2 == null && c1 != null) {
			return false;
		}
		if(c1 == null && c2 != null) {
			return false;
		}
		if(!containsAll(c1.keySet(), c2.keySet())) {
			return false;
		}
		for(Object k : c1.keySet()) {
			if(!equivalent(c1.get(k), c2.get(k))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Trims the string in a string to string mapping
	 * @param map
	 * @return new map, trimmed
	 */
	public static Map<String, String> trimMap(Map<String, String> map) {
		Map<String, String> returnMap = new HashMap<>();
		for(String key : map.keySet()) {
			returnMap.put(safeTrim(key), safeTrim(map.get(key)));
		}
		return returnMap;
	}
	/**
	 * Only trims not null strings if null then null is returned
	 * @param str
	 * @return
	 */
	public static String safeTrim(String str) {
		if(str == null) {
			return null;
		}
		return str.trim();
	}
	
	
	
	public static boolean containsAll(Collection<?> c1, Collection<?> c2) {
		if(c1 == null && c2 == null) {
			return true;
		}
		if(c2 == null && c1 != null) {
			return false;
		}
		if(c1 == null && c2 != null) {
			return false;
		}
		if(c1.size() != c2.size()) {
			return false;
		}
		if(!c1.containsAll(c2)) {
			return false;
		}
		if(!c2.containsAll(c1)) {
			return false;
		}
		return true;
	}

	/**
	 * Returns true if the collection is not null and has a size greater than zero.
	 * @param collection
	 * @return
	 */
	public static boolean validCollection(Collection<?> collection) {
		return collection!= null && !collection.isEmpty();
	}

	/**
	 * Does the specified Iterable only contain nulls ?
	 * @param array The Iterable object
	 * @return true if there are only nulls in the Iterable or there are no elements in the Iterable
	 */
	public static boolean isAllNulls(Iterable<?> array) {
		for (Object element : array) {
			if (element != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns true if the array is not null and has a size greater than zero.
	 * @param arr
	 * @return
	 */
	public static boolean validArray(Object[] arr) {
		return arr!= null && arr.length > 0;
	}

	/**
	 * Returns true if the Map is not null and has a size greater than zero.
	 * @param map
	 * @return
	 */
	public static boolean validMap(Map<?, ?> map) {
		return map!= null && map.size() > 0;
	}

	public static boolean getBooleanValue(String str) {
		if (str.equalsIgnoreCase("true")) {
			return true;
		}
		if (str.equalsIgnoreCase("false")) {
			return false;
		}
		throw new IllegalArgumentException("Illegal value specified: " + str);
	}

	
	/**
	 * Collect the elements in this stream to a list.
     * <p>This is a terminal operation.</p>
	 * @param str
	 * @return
	 */
	public static <T> List<T> collectToList(Stream<T> str){
		return str.collect(Collectors.toList());
	}
	
	/**
	 * Collect the elements in this stream to a Set.
     * <p>This is a terminal operation.</p>
	 * @param str
	 * @return
	 */
	public static <T> Set<T> collectToSet(Stream<T> str){
		return str.collect(Collectors.toSet());
	}
}
