package io.sdmx.utils.core.application;

import io.sdmx.api.application.IVersion;
import io.sdmx.api.application.ProductUpgradeEngine;

public abstract class AbstractProductUpgradeEngine implements ProductUpgradeEngine {
	private IVersion upgradeVersion;

	public AbstractProductUpgradeEngine(IVersion upgradeVersion) {
		this.upgradeVersion = upgradeVersion;
	}

	@Override
	public IVersion getUpgradeVersion() {
		return upgradeVersion;
	}

	@Override
	public int compareTo(ProductUpgradeEngine productUpgradeEngine) {
		if(this.getUpgradeVersion().equals(productUpgradeEngine.getUpgradeVersion())) {
			return this.getClass().getName().compareTo(productUpgradeEngine.getClass().getName());
		}
		return this.getUpgradeVersion().compareTo(productUpgradeEngine.getUpgradeVersion());
//		return VersionableUtil.isHigherVersionWithBetaProvision(this.getUpgradeVersion(), productUpgradeEngine.getUpgradeVersion()) ? 1 : -1;
	}
}
