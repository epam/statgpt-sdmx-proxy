package io.sdmx.utils.core.http;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.ICacheHeaders;
import io.sdmx.api.http.IHttpHeaderAware;
import io.sdmx.utils.core.date.DateUtil;

public class CacheHeaders implements ICacheHeaders {
	public static final ICacheHeaders EMPTY_HEADERS = new CacheHeaders();
	private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
	private static final String IF_UNMODIFIED_SINCE = "If-Unmodified-Since";
	private static final String IF_MATCH = "If-Match";
	private static final String IF_NON_MATCH = "If-None-Match";

	private Long ifModifiedSince;
	private Long ifUnmodifiedSince;
	private String ifNonMatch;
	private String ifMatch;

	private CacheHeaders() {}
	
	public CacheHeaders(IHttpHeaderAware headerAware) {
		this.ifModifiedSince = dateHeaderToLong(headerAware, IF_MODIFIED_SINCE);
		this.ifUnmodifiedSince = dateHeaderToLong(headerAware, IF_UNMODIFIED_SINCE);
		this.ifNonMatch = headerAware.getHeader(IF_NON_MATCH);
		this.ifMatch = headerAware.getHeader(IF_MATCH);
	}

	/**
	 * @param lastModifed
	 * @return true if there is no modified since header, or the modified since header is prior to the last modified time 
	 */
	public boolean isModifiedSince(Long lastModifed) {
		Long modifiedSince = getIfModifiedSince();
		if(modifiedSince == null) {
			return true;
		}
		if(lastModifed > modifiedSince) {
			if(lastModifed-modifiedSince < 1000) {
				//within 1 second, this could be the same modified since timestamp 
				//as the resolution is to the nearest 1 second, check this
				Long diff = reparse(lastModifed) - reparse(modifiedSince);
				return diff != 0;
			}
			return true;
		}
		return false;
	}

	private Long reparse(Long lastModifed) {
		String parsed = DateUtil.convertEpochTimeToRFC1123(lastModifed);
		return dateHeaderToLong(parsed);
	}

	private Long dateHeaderToLong(IHttpHeaderAware headerAware, String headerName) {
		String headervalue = headerAware.getHeader(headerName);
		if(headervalue == null) {
			return null;
		}
		try {
			return dateHeaderToLong(headervalue);
		} catch(DateTimeParseException e ) {
			throw new SdmxSemmanticException("Illegal Value '"+headervalue+"' for HTTP Header '"+headerName+"'");
		}
	}

	private Long dateHeaderToLong(String headervalue)  {
		ZonedDateTime zonedDateTime = ZonedDateTime.parse(
				headervalue,
				DateTimeFormatter.RFC_1123_DATE_TIME.withLocale(Locale.US)
				);

		// Convert to epoch milliseconds
		return zonedDateTime.toInstant().toEpochMilli();

	}

	@Override
	public Long getIfModifiedSince() {
		return ifModifiedSince;
	}

	@Override
	public Long getIfUnmodifiedSince() {
		return ifUnmodifiedSince;
	}

	@Override
	public String getIfNonMatch() {
		return ifNonMatch;
	}

	@Override
	public String getIfMatch() {
		return ifMatch;
	}
}
