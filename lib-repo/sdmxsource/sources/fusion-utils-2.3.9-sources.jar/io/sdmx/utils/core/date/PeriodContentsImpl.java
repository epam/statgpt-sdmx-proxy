package io.sdmx.utils.core.date;

import io.sdmx.api.date.PeriodContents;
import io.sdmx.utils.core.object.AssertUtil;

/**
 * Abstract, subclasses need to implement copy and merge
 */
public abstract class PeriodContentsImpl<T> implements PeriodContents<T> {
	private T contents;
	
	public PeriodContentsImpl(T contents) {
		AssertUtil.notNull(contents, "contents");
		this.contents = contents;
	}

	@Override
	public T getContents() {
		return contents;
	}
}
