package io.sdmx.utils.core.process;

import io.sdmx.api.process.Processor;
import io.sdmx.utils.core.timer.Stopwatch;

public abstract class AbstractStoppableProcessor extends AbstractStoppable implements Processor {
	private PROCESSOR_STATUS currentProcessorStatus = PROCESSOR_STATUS.IDLE;
	private Stopwatch processorStopwatch = new Stopwatch();
	
	public PROCESSOR_STATUS getProcessorStatus() {
		return currentProcessorStatus;
	}

	public long getProcessorStatusRuntime() {
		return processorStopwatch.getDuration();
	}
	
	public boolean isProcessing() {
		return currentProcessorStatus == PROCESSOR_STATUS.PROCESSING;
	}


	protected void startProcessor() {
		changeStatus(PROCESSOR_STATUS.PROCESSING);
	}

	protected void stopProcessor() {
		changeStatus(PROCESSOR_STATUS.IDLE);
	}
	

	private void changeStatus(PROCESSOR_STATUS status) {
		currentProcessorStatus = status;
		processorStopwatch.start();
		notifyStatusChanged();
	}
}
