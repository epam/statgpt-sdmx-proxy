package io.sdmx.utils.core.http;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.ICacheHeaders;
import io.sdmx.api.http.IRESTGET;
import io.sdmx.api.http.Request;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class RESTGET implements IRESTGET {
	private Map<String, String> queryParameters = new HashMap<>();
	private List<String> path = new ArrayList<>();

	private Map<String, String> headers = Collections.emptyMap();
	private ICacheHeaders cacheHeaders = CacheHeaders.EMPTY_HEADERS;
		
	/**
	 * 
	 * @param url full or partial URL, example http://myquery/data/dataflow/A.B.C or data/dataflow/A.B.C
	 * @param pathEntry the start point for this GET, for example data/ will start the path from the data/ part of the URL
	 */
	public RESTGET(Request request, String pathEntry) {
		this(request.getPath(), pathEntry);
		this.cacheHeaders = request.getCacheHeaders();
		if(request.getHeaders() != null) {
			this.headers = Collections.unmodifiableMap(request.getHeaders());
		}
		this.queryParameters = Collections.unmodifiableMap(request.getParameters());
	}
	/**
	 * 
	 * @param url full or partial URL, example http://myquery/data/dataflow/A.B.C or data/dataflow/A.B.C
	 * @param pathEntry the start point for this GET, for example data/ will start the path from the data/ part of the URL
	 */
	public RESTGET(String url, String pathEntry) {
		if(pathEntry != null) {
			int dataIdx = url.indexOf(pathEntry);
			if(dataIdx > 0) {
				url = url.substring(dataIdx);
			}
		}
		if(url != null) {
			String[] pathParamSplit = url.split("\\?", 2);
			String path = pathParamSplit[0];
			for(String currentPath : path.split("/")) {
				this.path.add(currentPath);
			}

			if(pathParamSplit.length > 1 && ObjectUtil.validString(pathParamSplit[1])) {
				String params = pathParamSplit[1];

				String[] paramsSplit = params.split("&");
				for(String currentParam : paramsSplit) {
					String[] cParamSplit = currentParam.split("=");
					if(cParamSplit.length != 2) {
						throw new SdmxSemmanticException("Malformed query parameter: "+currentParam);
					}
					queryParameters.put(cParamSplit[0], cParamSplit[1]);  //make parameter case insensitive
				}
			}
		}
		this.queryParameters = Collections.unmodifiableMap(this.queryParameters);
		this.path = Collections.unmodifiableList(this.path);
	}
	
	@Override
	public Map<String, String> getHeaders() {
		return headers;
	}
	
	@Override
	public ICacheHeaders getCacheHeaders() {
		return cacheHeaders;
	}
	

	@Override
	public String getPathParameter(int idx) {
		return path.size() > idx ? path.get(idx) : null;
	}

	@Override
	public SdmxDate getSdmxDateParamValue(String param) {
		String val = getStringParamValue(param);
		if(val != null) {
			try {
				return SdmxDateImpl.getSdmxDate(val);
			} catch(Throwable e) {
				throw new SdmxSemmanticException("Illegal value '"+val+"' for parameter '"+param+"' - expecting an SDMX compliant Date");
			}
		}
		return null;
	}

	@Override
	public Integer getIntegerParamValue(String param) {
		String val = getStringParamValue(param);
		if(val != null) {
			try {
				return Integer.parseInt(val);
			} catch(NumberFormatException e) {
				throw new SdmxSemmanticException("Illegal value '"+val+"' for parameter '"+param+"' - expecting an Integer");
			}
		}
		return null;
	}

	@Override
	public Boolean getBooleanParamValue(String param) {
		String val = getStringParamValue(param);
		if(val != null) {
			return Boolean.valueOf(val);
		}
		return null;
	}

	@Override
	public String getStringParamValue(String param) {
		if(param == null) {
			return null;
		}
		return this.queryParameters.get(param);
	}

	@Override
	public Map<String, String> getQueryParameters() {
		return queryParameters;
	}

	@Override
	public List<String> getPath() {
		return path;
	}
	@Override
	public String toString() {
		return toURL();
	}

	@Override
	public String toURL(String... removeParams) {
		Set<String> ignoreParams = removeParams == null ? Collections.emptySet() : new HashSet<>();
		for(String removeParam : removeParams) {
			ignoreParams.add(removeParam.toLowerCase());
		}
		StringBuilder sb = new StringBuilder();
		sb.append(CollectionUtil.collectionToString(path, "/", ""));
		if(queryParameters.size() > 0) {
			String concat = "?";
			Set<String> keys = new TreeSet<>(queryParameters.keySet());
			for(String param : keys) {
				if(ignoreParams.contains(param)) {
					continue;
				}
				String paramValue = queryParameters.get(param);
				sb.append(concat + param + "=" + paramValue);
				concat = "&";
			}
		}
		return sb.toString();
	}
	@Override
	public int hashCode() {
		StringBuilder sb = new StringBuilder(toURL());
		for(String headerId : headers.keySet()) {
			sb.append(headerId+"="+headers.get(headerId));
		}
		return sb.toString().hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof IRESTGET) {
			IRESTGET that = (IRESTGET) obj;
			return that.toURL().equals(this.toURL()) &&
					ObjectUtil.equivalentMap(that.getHeaders(), this.getHeaders());
		}
		return false;
	}
}
