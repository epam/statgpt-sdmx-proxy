package io.sdmx.utils.core.thread;

import io.sdmx.utils.core.logging.LoggingUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Lockable {
	Logger LOG = LoggerFactory.getLogger(Lockable.class);
	private boolean isLocked = false;
	private String lockOwner;
	private int lockCount=0;
	
    public synchronized void lock() {
    	if(isLocked && lockOwner != null && lockOwner.equals(Thread.currentThread().getName())) {
    		lockCount++;
    		if(LOG.isDebugEnabled()) {
    			LOG.debug("Lockable Class " +this.getClass().getName() + " - Lock requested from thread that already owns lock ("+Thread.currentThread().getName()+"), lock count = " + lockCount); 
    		}
    		return;
    	}
    	
    	if(LOG.isDebugEnabled()) {
    		LOG.debug("Lockable Class " +this.getClass().getName() +  " - Aquire new lock : " + Thread.currentThread().getName()); 
    	}
    	
    	// If some other thread locked this object then we need to wait
        // until they release the lock
         if( isLocked ) {
              do {
                   try {
                        // this releases the synchronized that we are in
                        // then waits for a notify to be called in this object
                        // then does a synchronized again before continuing
                        wait();
                   }
                   catch( Exception e ) {
                        throw new RuntimeException("Error while trying to lock synchronized object");
                   }
              } while( isLocked );     // we can't leave until we got the lock, which
                                       // we may not have got if an exception occurred
         }
         isLocked = true;
         lockCount = 0;
         lockOwner = Thread.currentThread().getName();
    }

    /**
     * Releases the lock owned by the current thread
     * @param fullRelease - if true, this will release all locks the thread has called on this instance, if false, it will unlock the last call to this
     * instance, if the last call is the last lock to release then this instance is unlocked.
     */
    public synchronized void releaseLock(boolean fullRelease) {
    	if( !isLocked ) {
    		return;
    	}
    	if(!Thread.currentThread().getName().equals(lockOwner)) {
    		throw new RuntimeException("Lockable Class " +this.getClass().getName() + " releaseLock call from Thread " + Thread.currentThread().getName() + " is attempting to release a lock owned by " + lockOwner);
    	}
    	
    	LoggingUtil.debug(LOG, "Release Lock Request:" + Thread.currentThread().getName());
    	if( isLocked ) {
    		if(fullRelease) {
    			LoggingUtil.debug(LOG, "Full Release");
    			lockCount = 0;
    			isLocked = false;
    			notify();
    		} else {
        		if(lockCount <= 0) {
        			LoggingUtil.debug(LOG, "Lock Count " + lockCount + " Release Lock");
        			isLocked = false;
        			lockOwner = null;
        			notify();
        		}
        		LoggingUtil.debug(LOG, "Lock Count " + lockCount + " Decrease Count Value by 1");
        		lockCount--;
    		}
         }
    }

    public synchronized boolean isLocked() {
         return isLocked;
    }
}
