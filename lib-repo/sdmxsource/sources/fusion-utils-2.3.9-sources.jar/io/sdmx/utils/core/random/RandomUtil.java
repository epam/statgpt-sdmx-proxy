package io.sdmx.utils.core.random;

import java.security.SecureRandom;
import java.util.Random;

public class RandomUtil {
	private static final Random random = new SecureRandom();
	private static final String availableCharacters = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
	
	
	@Deprecated
	/**
	 * {@link Deprecated} use  randomString
	 */
	public static String generateRandomString() {
		return randomString();
	}
	
	/**
	 * Generates a long (32 character) random string by combining the hex of 2 random Long numbers generated using SecureRandom
	 * @return
	 */
	public static String randomString() {
		 long r1 = random.nextLong();
	     long r2 = random.nextLong();
	     String hash1 = Long.toHexString(r1);
	     String hash2 = Long.toHexString(r2);
	     return hash1 + hash2;
	}
	
	/**
	 * Generates a random string of the given length.  The random string consists of numeric, lower case, and upper case characters 
	 * @param length the length of the string.  SecureRandom is used to randomly generate these characters.
	 * 
	 * @return random string of the given length 
	 */
	public static String randomString(int length) {
		return randomString(random, length);
	}
	
	/**
	 * Generates a random string of the given length.  The random string consists of numeric, lower case, and upper case characters 
	 * @param rnd the random to use
	 * @param length the length of the string
	 * @return
	 */
	public static String randomString(Random rnd, int length) {
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < length; i++) {
			b.append(availableCharacters.charAt(rnd.nextInt(availableCharacters.length())));
		}
		return b.toString();
	}

}
