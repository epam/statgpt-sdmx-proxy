package io.sdmx.utils.core.io;

import java.io.OutputStream;

import io.sdmx.api.io.WriteableDataLocation;

public class WriteableDataLocationTmp extends ReadableDataLocationTmp implements WriteableDataLocation {
	private static final long serialVersionUID = 1L;

	public WriteableDataLocationTmp() {
		super(URIUtil.getTemporaryURI());
		super.deleteOnClose = true;
	}

	@Override
	public OutputStream getOutputStream() {
		return URIUtil.getOutputStream(uri);
	}
}
