package io.sdmx.utils.core.io;

import java.io.IOException;
import java.lang.ref.Cleaner;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Cleans files on when the owning class is garbage collected
 */
public class PathCleaner {
    private static final Cleaner CLEANER = Cleaner.create();

    private static final class PathDelter implements Runnable {
      private final Path file;
      
      private PathDelter(Path file) {
          this.file = file;
      }

      @Override public void run() {
        try { Files.deleteIfExists(file); }
        catch (IOException e) { /* log if you want */ }
      }
    }
    
    /**
     * Register a new file for deletion once the pathOwner is garbage collected
     * @param pathOwner - when this object is garbage collected, the file is deleted (if it exists)
     * @param file - the file to delete
     */
    public static void reigster(Object pathOwner, Path file) {
        CLEANER.register(pathOwner, new PathDelter(file));
    }
    
}
