package io.sdmx.utils.core.date;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;
import it.unimi.dsi.fastutil.longs.Long2ObjectRBTreeMap;
import it.unimi.dsi.fastutil.objects.Object2LongAVLTreeMap;

/**
 * Class provided to perform date operations
 */
public class DateUtil {
	//Regular expressions
	private static final String xmlDatePatternString =
			"[0-9]{4}-((01|03|05|07|08|10|12)-((0[1-9])|(1[0-9])|(2[0-9])|3[0-1])" +
					"|02-((0[1-9])|(1[0-9])|(2[0-9]))" +
					"|(04|06|09|11)-((0[1-9])|(1[0-9])|(2[0-9])|30))";
	private static final String xmlHourPatternString = "([0-1][0-9]|2[0-3])";

	private static final Pattern xmlDateTimePattern = Pattern.compile(xmlDatePatternString + "T"  + xmlHourPatternString + ":([0-5][0-9]:[0-5][0-9])(\\.[0-9]*)?(Z|((\\+|-)((0[0-9]|1[0-3]):([0-5][0-9])|14:00)))?");
	private static final Pattern xmlMinutelyPattern = Pattern.compile(xmlDatePatternString + "T"  + xmlHourPatternString + ":([0-5][0-9])");
	private static final Pattern xmlHourlyPattern = Pattern.compile(xmlDatePatternString + "T" + xmlHourPatternString);
	private static final Pattern xmlDailyPattern = Pattern.compile(xmlDatePatternString);
	// FR-4524 - permit single or double week digits to be read
	private static final Pattern xmlWeeklyPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-W([1-9]|0[1-9]|[1-4][0-9]|5[0-3])");
	private static final Pattern xmlMonthlyPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-M*(0[1-9]|1[0-2])");
	private static final Pattern xmlQuarterlyPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-Q[1-4]");
	private static final Pattern xmlBiAnnualPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-B[1-2]");
	private static final Pattern xmlSemiAnnualPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-S[1-2]");
	private static final Pattern xmlHalfYearlyHPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-H[1-2]");
	private static final Pattern xmlTriAnnualPattern = Pattern.compile("[0-9][0-9][0-9][0-9]-T[1-3]");
	private static final Pattern xmlYearlyPattern = Pattern.compile("[0-9][0-9][0-9][0-9]");
	private static final Pattern xmlAnnualRangePattern = Pattern.compile("[0-9][0-9][0-9][0-9]-A[1-9][0-9]*");  //Example 2009-A1 or 2009-A109

	//The following are only used for validation, not for returning a TIME_FORMAT
	//HH:MM:SS
	public static final Pattern date_TimePattern = Pattern.compile(xmlHourPatternString + ":([0-5][0-9]:[0-5][0-9])");
	//--MM
	public static final Pattern date_MonthPattern = Pattern.compile("--(0[1-9]|1[0-2])");
	public static final Pattern date_MonthDayPattern = Pattern.compile("--((01|03|05|07|08|10|12)-((0[1-9])|(1[0-9])|(2[0-9])|3[0-1])" +
			"|02-((0[1-9])|(1[0-9])|(2[0-9]))" +
			"|(04|06|09|11)-((0[1-9])|(1[0-9])|(2[0-9])|30))");
	public static final Pattern date_YearMonthPattern = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])");

	// FR- 3882 - if the environment value for "alternate half-year" has been set
	private static boolean alternateHalfYear;
	public static void setUseAlternateHalfYear(boolean val) {
		alternateHalfYear = val;
	}

	private static final ZoneId GMT_ZONEID = ZoneId.of("GMT");

	private static Long2ObjectRBTreeMap<String> formattedA = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedS = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedT = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedQ = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedM = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedW = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedD = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedH = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<String> formattedI = new Long2ObjectRBTreeMap<>();
	private static Object2LongAVLTreeMap<String> formattedStartPeriod  = new Object2LongAVLTreeMap<>();
	private static Object2LongAVLTreeMap<String> formattedEndPeriod  = new Object2LongAVLTreeMap<>();

	static {
		startCacheResetter();
	}

	private static void startCacheResetter() {
		Thread t = new Thread(new Runnable() {
			boolean isRunning = true;
			@Override
			public void run() {
				try {
					while(isRunning) {
						Thread.sleep(1000l*60*60*2);  //clear cache every 2 hours
						formattedA = new Long2ObjectRBTreeMap<>();
						formattedS = new Long2ObjectRBTreeMap<>();
						formattedT = new Long2ObjectRBTreeMap<>();
						formattedQ = new Long2ObjectRBTreeMap<>();
						formattedM = new Long2ObjectRBTreeMap<>();
						formattedW = new Long2ObjectRBTreeMap<>();
						formattedD = new Long2ObjectRBTreeMap<>();
						formattedH = new Long2ObjectRBTreeMap<>();
						formattedI = new Long2ObjectRBTreeMap<>();
						formattedStartPeriod  = new Object2LongAVLTreeMap<>();
						formattedEndPeriod  = new Object2LongAVLTreeMap<>();
					}
				} catch (InterruptedException ie) {
					Thread.currentThread().interrupt();
					isRunning = false;
					startCacheResetter();
				}
			}
		});
		t.setDaemon(true);
		t.start();
	}


	/**
	 * Returns whichever data is later, or null if both are null
	 * @param dte1
	 * @param dte2
	 * @return
	 */
	public static Date getLater(Date dte1, Date dte2) {
		if(dte1 == null) {
			return dte2;
		}
		if(dte2 == null) {
			return dte1;
		}
		return dte1.after(dte2) ? dte1 : dte2;
	}

	/**
	 * Returns whichever data is later, or null if both are null
	 * @param dte1
	 * @param dte2
	 * @return
	 */
	public static Date getEarlier(Date dte1, Date dte2) {
		if(dte1 == null) {
			return dte2;
		}
		if(dte2 == null) {
			return dte1;
		}
		return dte1.before(dte2) ? dte1 : dte2;
	}
	/**
	 * Returns a calendar which is initialized with date now() +/- the time given in the calfield, obtained from Calendar.[Feild]
	 * and the time.  For example to get a calendar where the date is 1 day previous to now()
	 * Calendar cal = Calendar.getCalendar(Calendar.DAY_OF_YEAR, -1)
	 *
	 * @param calfield
	 * @param num
	 * @return
	 */
	public static Calendar getCalendar(int calfield, int num) {
		Calendar cal = getCalendar(true);
		cal.add(calfield, num);
		return cal;
	}

	public static Calendar createCalendar(Date date) {
		Calendar cal = getCalendar(false);
		cal.setTime(date);
		return cal;
	}

	public static XMLGregorianCalendar createXMLGregorianCalendar(Date date) {
		if(date == null) {
			return null;
		}
		try {
			Calendar now = getCalendar(false);
			now.setTime(date);
			GregorianCalendar cal = new GregorianCalendar(now.get(Calendar.YEAR),
					now.get(Calendar.MONTH),
					now.get(Calendar.DATE),
					now.get(Calendar.HOUR),
					now.get(Calendar.MINUTE),
					now.get(Calendar.SECOND));
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch(Throwable th) {
			throw new RuntimeException(th);
		}
	}


	/**
	 * Returns the end value for the specified date. The end value is determined by the TIME_FORMAT.
	 * If the TIME_FORMAT is year then the returned date will be the end of the year.
	 * @param date the date to analyse
	 * @param timeFormat The timeFormat to use.
	 * @return The end date for the specified timeFormat
	 */
	public static Date moveToEndofPeriod(Date date, TIME_FORMAT timeFormat) {
		String dateAsString = formatDate(date, timeFormat);
		return formatDateEndPeriod(dateAsString);
	}

	/**
	 * Formats a String as a date.
	 * <p/>
	 * The expected string must be in either of the three following formats.
	 * <ol>
	 *   <li>yyyy-MM-dd'T'HH:mm:ss.SSSz</li>
	 *   <li>yyyy-MM-dd</li>
	 *   <li>12345678 ( an epoch date greater than 9999 )</li>
	 * </ol>
	 * @param dateObject
	 * @param startOfPeriod formats the date to the start of the period, otherwise it will be end of period
	 * @return
	 */
	public static Date formatDate(Object dateObject, boolean startOfPeriod) {
		if(dateObject == null) {
			return null;
		}
		if(dateObject instanceof Date) {
			return (Date)dateObject;
		}
		if(dateObject instanceof Long) {
			return new Date((Long)dateObject);
		}
		if(dateObject instanceof XMLGregorianCalendar) {
			XMLGregorianCalendar gregorianCal = (XMLGregorianCalendar)dateObject;
			Calendar cal = getCalendar(false);
			cal.set(Calendar.YEAR, gregorianCal.getYear());
			cal.set(Calendar.MONTH, gregorianCal.getMonth()-1);
			cal.set(Calendar.DATE, gregorianCal.getDay());
			cal.set(Calendar.AM_PM, 0);
			if (gregorianCal.getHour() > 0) {
				cal.set(Calendar.HOUR, gregorianCal.getHour());
			} else {
				cal.set(Calendar.HOUR, 0);
			}

			if (gregorianCal.getMinute() > 0) {
				cal.set(Calendar.MINUTE, gregorianCal.getMinute());
			} else {
				cal.set(Calendar.MINUTE, 0);
			}
			if (gregorianCal.getSecond() > 0) {
				cal.set(Calendar.SECOND, gregorianCal.getSecond());
			} else {
				cal.set(Calendar.SECOND, 0);
			}
			cal.set(Calendar.MILLISECOND, 0);

			return cal.getTime();
		}

		// Last chance: Our input is now either a String or it's invalid.
		String dateString = null;
		if(dateObject instanceof String) {
			dateString = (String)dateObject;
		} else {
			throw new IllegalArgumentException("Date type not recognised : " + dateObject.getClass().getName());
		}

		if (dateString.length() == 0) {
			return null;
		}

		// DEV-2174: If its a String that it only digits (and longer than 4 characters), its an epoch date
		if (dateString.length() > 4 && dateString.matches("^[0-9]+$")) {
			try {
				return new Date( Long.parseLong(dateString) );
			} catch (NumberFormatException nfe) {
				// This is extremely unlikely to happen (since we know that the String is all numerics)
			}
		}

		if (startOfPeriod) {
			return formatDateStartPeriod(dateString);
		}
		return formatDateEndPeriod(dateString);
	}

	private static Long2ObjectRBTreeMap<Date> datePoolStart = new Long2ObjectRBTreeMap<>();
	private static Long2ObjectRBTreeMap<Date> datePoolEnd = new Long2ObjectRBTreeMap<>();

	private static Date formatDateStartPeriod(String value) {
		long dte = formattedStartPeriod.getLong(value);
		if(dte != formattedStartPeriod.defaultReturnValue()) {
			synchronized (datePoolStart) {
				Date d = datePoolStart.get(dte);
				if(d != null) {
					return d;
				}
			}
		}
		Date d = formatDateStartPeriodInternal(value);
		synchronized (datePoolStart) {
			datePoolStart.put(d.getTime(), d);
			formattedStartPeriod.put(value, d.getTime());
		}
		return d;
	}
	private static Date formatDateStartPeriodInternal(String value) {
		TIME_FORMAT timeFormat = getTimeFormatOfDate(value);

		DateFormat df = null;
		String formatValue = null;
		String[] split = null;
		int quarter = 0;
		Calendar cal = null;
		switch(timeFormat) {
		case DATE :
			formatValue = value;
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case DATE_TIME :
			formatValue = value;
			if(formatValue.length() == 16) {
				df = getDateFormatter("yyyy-MM-dd'T'HH:mm");//.SSSz
			} else {
				df = getDateFormatter("yyyy-MM-dd'T'HH:mm:ss");//.SSSz
			}
			break;
		case HALF_OF_YEAR :
			String splitItem = null;
			if (alternateHalfYear) {
				if (value.contains("-H")) {
					splitItem = "-H";
				}
			}
			if (value.contains("-B")) {
				// It's SDMX 2.0 (bi-annual)
				splitItem = "-B";
			} else if (value.contains("-S")) {
				// It's SDMX 2.1 (Reporting Semester)
				splitItem = "-S";
			}

			if (splitItem == null) {
				throw new RuntimeException("The observation date: " + value + " does not conform to the half yearly format expected!");
			}

			split = value.split(splitItem);
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-01-01"; break;
			case 2: formatValue = split[0] + "-07-01"; break;
			}
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case HOUR :
			formatValue = value;
			if(formatValue.length() == 13) {
				df = getDateFormatter("yyyy-MM-dd'T'HH");//.SSSz
			} else if(formatValue.length() == 16) {
				df = getDateFormatter("yyyy-MM-dd'T'HH:mm");//.SSSz
			} else {
				df = getDateFormatter("yyyy-MM-dd'T'HH:mm:ss");//.SSSz
			}
			break;
		case MONTH :
			if (value.charAt(5) == 'M') {
				value = value.substring(0,5) + value.substring(6);
			}
			formatValue = value + "-01";
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case QUARTER_OF_YEAR :
			split = value.split("-Q");
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-01-01"; break;
			case 2: formatValue = split[0] + "-04-01"; break;
			case 3: formatValue = split[0] + "-07-01"; break;
			case 4: formatValue = split[0] + "-10-01"; break;
			}
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case THIRD_OF_YEAR :
			split = value.split("-T");
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-01-01"; break;
			case 2: formatValue = split[0] + "-05-01"; break;
			case 3: formatValue = split[0] + "-09-01"; break;
			}
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case WEEK :
			split = value.split("-W");
			cal = getCalendar(false);
			cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			cal.set(Calendar.YEAR, Integer.parseInt(split[0]));
			cal.set(Calendar.WEEK_OF_YEAR, Integer.parseInt(split[1]));
			return cal.getTime();
		case YEAR :
			formatValue = value + "-01-01";
			df = getDateFormatter("yyyy-MM-dd");
			break;
		case YEAR_RANGE :
			formatValue = value.split("-")[0] + "-01-01";
			df = getDateFormatter("yyyy-MM-dd");
			break;
		default: throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "formatting date of type " + timeFormat);
		}

		try {
			return df.parse(formatValue);
		} catch (ParseException e) {
			throw new IllegalArgumentException(e);
		}
	}

	private static Date formatDateEndPeriod(String value) {
		long dte = formattedEndPeriod.getLong(value);
		if(dte != formattedEndPeriod.defaultReturnValue()) {
			synchronized (datePoolEnd) {
				Date d = datePoolEnd.get(dte);
				if(d != null) {
					return d;
				}
			}
		}
		Date d = formatDateEndPeriodInternal(value);
		synchronized (datePoolEnd) {
			datePoolEnd.put(d.getTime(), d);
			formattedEndPeriod.put(value, d.getTime());
		}
		return d;
	}

	private static Date formatDateEndPeriodInternal(String value) {
		TIME_FORMAT timeFormat = getTimeFormatOfDate(value);

		DateFormat df = getDateFormatter("yyyy-MM-dd'T'HH:mm:ss");
		String formatValue = null;
		String[] split = null;
		int days = 0;
		int quarter = 0;
		Calendar cal = null;
		switch(timeFormat) {
		case DATE :
			formatValue = value;
			formatValue += "T23:59:59";
			//df = getDateFormatter("yyyy-MM-dd");
			break;
		case DATE_TIME :
			formatValue = value;
			formatValue = formatValue.split("T")[0];
			formatValue += "T23:59:59";
			df = getDateTimeFormat();
			break;
		case HALF_OF_YEAR :
			String splitItem = null;
			if (alternateHalfYear) {
				if (value.contains("-H")) {
					splitItem = "-H";
				}
			}
			if (value.contains("-B")) {
				// It's SDMX 2.0 (bi-annual)
				splitItem = "-B";
			} else if (value.contains("-S")) {
				// It's SDMX 2.1 (Reporting Semester)
				splitItem = "-S";
			}
			if (splitItem == null) {
				throw new RuntimeException("The observation date: " + value + " does not conform to the half yearly format expected!");
			}

			split = value.split(splitItem);
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-06-30T23:59:59"; break;
			case 2: formatValue = split[0] + "-12-31T23:59:59"; break;
			}
			break;
		case HOUR :
			formatValue = value;
			if(formatValue.length() == 13) {  //HOURLY
				formatValue = formatValue + ":59:59"; //Add the 59 minutes and 59 seconds
			} else if(formatValue.length() == 16) { //MINUTELY
				formatValue = formatValue + ":59:59"; //Add the 59 seconds
			}
			df = getDateFormatter("yyyy-MM-dd'T'HH:mm:ss");//.SSSz
			break;
		case MONTH :
			split = value.split("-");
			cal = getCalendar(false);
			cal.clear();
			cal.set(Calendar.YEAR, Integer.parseInt(split[0]));
			if (value.charAt(5) == 'M') {
				split[1] = split[1].substring(1);
				value = value.substring(0, 5) + value.substring(6);
			}
			cal.set(Calendar.MONTH, Integer.parseInt(split[1]) - 1);

			days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			formatValue = value + "-" + days+"T23:59:59";
			break;
		case QUARTER_OF_YEAR :
			split = value.split("-Q");
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-03-31T23:59:59"; break;
			case 2: formatValue = split[0] + "-06-30T23:59:59"; break;
			case 3: formatValue = split[0] + "-09-30T23:59:59"; break;
			case 4: formatValue = split[0] + "-12-31T23:59:59"; break;
			}
			break;
		case THIRD_OF_YEAR :
			split = value.split("-T");
			quarter = Integer.parseInt(split[1]);
			switch(quarter) {
			case 1: formatValue = split[0] + "-04-30T23:59:59"; break;
			case 2: formatValue = split[0] + "-08-31T23:59:59"; break;
			case 3: formatValue = split[0] + "-12-31T23:59:59"; break;
			}
			break;
		case WEEK :
			split = value.split("-W");
			cal = getCalendar(false);
			cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
			cal.set(Calendar.YEAR, Integer.parseInt(split[0]));
			cal.set(Calendar.WEEK_OF_YEAR, Integer.parseInt(split[1]));
			cal.set(Calendar.HOUR, 23);
			cal.set(Calendar.MINUTE, 59);
			cal.set(Calendar.SECOND, 59);
			return cal.getTime();
		case YEAR :
			formatValue = value + "-12-31T23:59:59";
			break;
		case YEAR_RANGE :
			Integer year = Integer.parseInt(value.split("-")[0]);
			Integer periods = Integer.parseInt(value.split("-")[1].substring(1));
			formatValue = (year + periods) + "-12-31T23:59:59";
			break;
		default: throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "formatting date of type " + timeFormat);
		}

		try {
			return df.parse(formatValue);
		} catch (ParseException e) {
			throw new IllegalArgumentException(e);
		}
	}

	/**
	 * Returns true if the input string can be expressed as an SDMX date, false if not
	 * @param dateString
	 * @return
	 */
	public static boolean isSdmxDate(String dateStr) {
		if (dateStr==null){
			return false;
		}
		if(dateStr.endsWith("Z")) {
			dateStr = dateStr.substring(0, dateStr.length()-1);
		}
		if (xmlAnnualRangePattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlYearlyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlTriAnnualPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlSemiAnnualPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlBiAnnualPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlQuarterlyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlMonthlyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlWeeklyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlDailyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlHourlyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlMinutelyPattern.matcher(dateStr).matches()){
			return true;
		}
		if (xmlDateTimePattern.matcher(dateStr).matches()){
			return true;
		}
		if (alternateHalfYear) {
			if (xmlHalfYearlyHPattern.matcher(dateStr).matches()){
				return true;
			}
		}
		return false;
	}

	/**
	 * Validates the date is in SDMX date/time format, and returns the Time Format for the date
	 * @param dateStr
	 * @return
	 */
	public static TIME_FORMAT getTimeFormatOfDate(String dateStr) {
		if (dateStr==null){
			throw new IllegalArgumentException("Could not determine date format, date null");
		}

		if(dateStr.endsWith("Z")) {
			dateStr = dateStr.substring(0, dateStr.length()-1);
		}

		if (xmlYearlyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.YEAR;
		} else if (xmlSemiAnnualPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.HALF_OF_YEAR;
		} else if (xmlBiAnnualPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.HALF_OF_YEAR;
		} else if (xmlQuarterlyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.QUARTER_OF_YEAR;
		} else if (xmlMonthlyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.MONTH;
		} else if (xmlWeeklyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.WEEK;
		} else if (xmlDailyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.DATE;
		} else if (xmlHourlyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.HOUR;
		} else if (xmlMinutelyPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.HOUR;
		} else if (xmlDateTimePattern.matcher(dateStr).matches()){
			return TIME_FORMAT.DATE_TIME;
		}  else if (xmlTriAnnualPattern.matcher(dateStr).matches()){
			return TIME_FORMAT.THIRD_OF_YEAR;
		} else if (alternateHalfYear && xmlHalfYearlyHPattern.matcher(dateStr).matches()) {
			return TIME_FORMAT.HALF_OF_YEAR;
		} else if(xmlAnnualRangePattern.matcher(dateStr).matches()) {
			return TIME_FORMAT.YEAR_RANGE;
		} else{
			throw new SdmxSemmanticException(ExceptionCode.INVALID_DATE_FORMAT, dateStr);
		}
	}

	/**
	 * Returns the Date in ISO-8601 format
	 * @param aDate
	 * @return
	 */
	public static String formatDate(Date aDate) {
		return formatDate(aDate, false);
	}

	public static String formatDate(Date dt, boolean includeTimeZone) {
		if (dt == null) {
			return null;
		}
		DateFormat df = getDateTimeFormat(includeTimeZone);
		return df.format(dt);
	}

	/**
	 * Returns a DateFormat object that can be used to format a date
	 * string as a date object.
	 * <p/>
	 * For a String to be successfully formatted as a Date using the
	 * returned DateFormat object, it must conform to the ISO8601 Standard Date/Time format.
	 * @return DateFormat object
	 */
	public static DateFormat getDateTimeFormat() {
		return getDateTimeFormat(false);
	}

	/**
	 * Returns a DateFormat object that can be used to format a date
	 * string as a date object.
	 * <p/>
	 * For a String to be successfully formatted as a Date using the
	 * returned DateFormat object, it must conform to the ISO8601 Standard Date/Time format.
	 * @return DateFormat object
	 */
	public static DateFormat getDateTimeFormat(boolean includeTimeZone) {
		if(includeTimeZone) {
			// ISO8601 Standard Date/Time format
			return getDateFormatter("yyyy-MM-dd'T'HH:mm:ss'Z'");
		} else {
			// ISO8601 Standard Date/Time format
			return getDateFormatter("yyyy-MM-dd'T'HH:mm:ss");
		}
	}

	public static DateFormat getDateFormat() {
		return getDateFormatter("yyyy-MM-dd");
	}

	public static DateFormat getYearFormat() {
		return getDateFormatter("yyyy");
	}

	public static DateFormat getMonthFormat() {
		return getDateFormatter("yyyy-MM");
	}

	public static DateFormat geWeekFormat() {
		return getDateFormatter("yyyy-ww");
	}

	public static DateFormat geHourFormat() {
		return getDateFormatter("yyyy-MM-dd'T'HH");
	}

	/**
	 * Groups dates my the target frequency, for example 2002-11,2002-12, 2003-01 grouped by ANNUAL would result in two map entries:
	 * <ol>
	 *   <li><b>2002</b> = 2002-11,2002-12</li>
	 *   <li><b>2003</b> = 2002-01</li>
	 * </ol>
	 * @param inputDates
	 * @param targetFrequency
	 * @return
	 */
	public static SortedMap<String, SortedSet<String>> groupByFrequency(Collection<String> inputDates, TIME_FORMAT targetFrequency) {
		SortedMap<String, SortedSet<String>> returnMap = new TreeMap<>();
		for(String currentInputDate : inputDates) {
			String converted = convertFrequency(currentInputDate, targetFrequency);
			SortedSet<String> datesForFreq = returnMap.get(converted);
			if(datesForFreq == null) {
				datesForFreq = new TreeSet<>();
				returnMap.put(converted, datesForFreq);
			}
			datesForFreq.add(currentInputDate);
		}
		return returnMap;
	}


	/**
	 * Returns the missing periods (gaps) from a collection of periods.
	 *
	 * @param startPeriod - optional, if procided missing periods will be included starting from this period
	 * @param endPeriod - optional, if provided missing periods will be added up to and including this period
	 * @param includeProvidedPeriods - if true the return list will include the periods provided, if false only the missing periods will be provided
	 * @return an ordered list of periods, time ascending
	 */
	public static List<String> findMissingPeriods(Collection<String> periods, SdmxDate startPeriod, SdmxDate endPeriod, boolean includeProvidedPeriods) {
		if(!ObjectUtil.validCollection(periods)) {
			return Collections.emptyList();
		}
		SortedSet<String> sortedPeriods = new TreeSet<>(periods);
		List<String>  returnPeriods = new ArrayList<>();
		TIME_FORMAT tf;
		String firstDate = sortedPeriods.first();
		if(startPeriod != null) {
			SdmxDate firstSdmxDate = new SdmxDateImpl(firstDate, true);
			tf = firstSdmxDate.getTimeFormatOfDate();
			if(startPeriod.isEarlier(firstSdmxDate)) {
				firstDate = startPeriod.getDateInSdmxFormat();
			}
		} else {
			tf = DateUtil.getTimeFormatOfDate(firstDate);
		}
		String lastDate = sortedPeriods.last();
		if(endPeriod != null) {
			SdmxDate lasstSdmxDate = new SdmxDateImpl(lastDate, true);
			if(endPeriod.isLater(lasstSdmxDate)) {
				lastDate = endPeriod.getDateInSdmxFormat();
			}
		}


		List<String> allValues = DateUtil.createTimeValues(DateUtil.formatDate(firstDate, true), DateUtil.formatDate(lastDate, true), tf);
		if(includeProvidedPeriods) {
			return allValues;
		}

		for(String currentDate : allValues) {
			if(!sortedPeriods.contains(currentDate)) {
				returnPeriods.add(currentDate);
			}
		}
		return returnPeriods;
	}

	/**
	 * Converts the frequency of the input date to the target frequency
	 * @param date
	 * @param targetFrequency
	 * @return
	 */
	public static String convertFrequency(String date, TIME_FORMAT targetFrequency) {
		return DateUtil.formatDate(date, targetFrequency, true);
	}

	/**
	 * Moves forwards or backwards the specified number of periods
	 * @param date
	 * @param periods
	 * @return
	 */
	public static String movePeriod(SdmxDate date, int periods) {
		if(periods == 0) {
			return date.getDateInSdmxFormat();
		}
		Calendar cal = date.getDateAsCalendar();
		int duration = 0;
		switch(date.getTimeFormatOfDate()) {
		case DATE : duration = Calendar.DATE;
		break;
		case DATE_TIME : duration = Calendar.SECOND;
		break;
		case HALF_OF_YEAR :
			duration = Calendar.MONTH;
			periods = periods * 6;
			break;
		case HOUR : duration = Calendar.HOUR;
		break;
		case MONTH : duration = Calendar.MONTH;
		break;
		case QUARTER_OF_YEAR :
			duration = Calendar.MONTH;
			periods = periods * 3;  //There are 3 months per quarter (3* 4Quarters = 12)
			break;
		case THIRD_OF_YEAR :
			duration = Calendar.MONTH;  // There are 4 months per third (4 * 3Thirds = 12)
			periods = periods * 4;
			break;
		case WEEK :
			Date dateObj = date.getDate();
			// Convert to LocalDate (without time) in UTC
			LocalDate locDate = dateObj.toInstant().atZone(ZoneId.of("UTC")).toLocalDate();
			// Add weeks to the LocalDate
			locDate = locDate.plusWeeks(periods);
			// Note: formatDate() treats the first parameter as an UTC date!
			return formatDate(
					Date.from(locDate.atStartOfDay(ZoneId.of("UTC")).toInstant()),
					date.getTimeFormatOfDate());
		case YEAR : duration = Calendar.YEAR;
		break;
		}
		cal.add(duration, periods);
		return formatDate(cal.getTime(), date.getTimeFormatOfDate());
	}

	/**
	 * Returns a rough calculation of the number of time periods between two dates with the given frequency
	 * @param dateFrom
	 * @param dateTo
	 * @param format
	 * @return
	 */
	public static long getTimePeriodCount(Date dateFrom, Date dateTo, TIME_FORMAT format) {
		long duration = 0;

		switch(format) {
		case DATE :
			duration = 86400000l;
			break;
		case DATE_TIME :
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, format); //FUNC Support iteration of date time

		case HALF_OF_YEAR :
			duration = 15768000000l; //Days in year * half a date
			break;

		case HOUR :
			duration = 3600000l;
			break;

		case MONTH :
			duration = 2628000000l;
			break;

		case QUARTER_OF_YEAR :
			duration = 7884000000l;
			break;

		case THIRD_OF_YEAR :
			duration = 10512000000l;
			break;

		case WEEK :
			duration = 604800000l;
			break;

		case YEAR :
			duration = 31536000000l;
			break;

		default :
			throw new RuntimeException("Unsupported time format : " + format);
		}
		long diff = dateTo.getTime() - dateFrom.getTime();
		if(diff == 0) {
			return 0;
		}
		return (diff / duration);
	}

	public static List<String> createTimeValues(SdmxPeriod period) {
		if(!period.hasStartPeriod()) {
			throw new SdmxSemmanticException("Missing Start Period");
		}
		if(!period.hasEndPeriod()) {
			throw new SdmxSemmanticException("Missing End Period");
		}
		return createTimeValues(period.getStartPeriod().getDate(), period.getEndPeriod().getDate(), period.getStartPeriod().getTimeFormatOfDate());
	}

	/**
	 * Creates a list of all the date values between the from and to dates.  The dates are iterated by the
	 * time format.  The format of the dates is also dependent on the time format.
	 * @param dateFrom
	 * @param dateTo
	 * @param format
	 * @return
	 */
	public static List<String> createTimeValues(Date dateFrom, Date dateTo, TIME_FORMAT format) {
		List<String> returnList = new ArrayList<>();
		switch(format) {
		case DATE :
			iterateDailyValues(dateFrom, dateTo, returnList);
			break;
		case DATE_TIME :
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, format); //FUNC Support iteration of date time

		case HALF_OF_YEAR :
			iterateHalfYearlyValues(dateFrom, dateTo, returnList);
			break;

		case HOUR :
			iterateHourlyValues(dateFrom, dateTo, returnList);
			break;

		case MONTH :
			iterateMonthlyValues(dateFrom, dateTo, returnList);
			break;

		case QUARTER_OF_YEAR :
			iterateQuarterlyValues(dateFrom, dateTo, returnList);
			break;

		case THIRD_OF_YEAR :
			iterateThirdOfYearValues(dateFrom, dateTo, returnList);
			break;

		case WEEK :
			iterateWeeklyValues(dateFrom, dateTo, returnList);
			break;

		case YEAR :
			iterateYearlyValues(dateFrom, dateTo, returnList);
			break;

		default :
			throw new RuntimeException("Unsupported time format : " + format);
		}
		return returnList;
	}

	private static void iterateDailyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateDateValues(dateFrom, dateTo, returnList, Calendar.DATE, 1, TIME_FORMAT.DATE);
	}

	private static void iterateHalfYearlyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateDateValues(dateFrom, dateTo, returnList, Calendar.MONTH, 6, TIME_FORMAT.HALF_OF_YEAR);
	}

	private static void iterateHourlyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateDateValues(dateFrom, dateTo, returnList, Calendar.HOUR, 1, TIME_FORMAT.HOUR);
	}

	private static void iterateMonthlyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateMonthValue(dateFrom, dateTo, returnList, 1, TIME_FORMAT.MONTH);
	}

	private static void iterateQuarterlyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateMonthValue(dateFrom, dateTo, returnList, 3, TIME_FORMAT.QUARTER_OF_YEAR);
	}

	private static void iterateThirdOfYearValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateDateValues(dateFrom, dateTo, returnList, Calendar.MONTH, 4, TIME_FORMAT.THIRD_OF_YEAR);
	}

	private static void iterateWeeklyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateWeekValue(dateFrom, dateTo, returnList, 1, TIME_FORMAT.WEEK);
	}

	private static void iterateYearlyValues(Date dateFrom, Date dateTo, List<String> returnList) {
		iterateDateValues(dateFrom, dateTo, returnList, Calendar.YEAR, 1, TIME_FORMAT.YEAR);
	}

	private static void iterateDateValues(
			Date dateFrom, Date dateTo, List<String> returnList, int duration, int number, TIME_FORMAT format) {

		Calendar cal = getCalendar(false);
		cal.setTime(dateFrom);

		Calendar calTo = getCalendar(false);
		calTo.setTime(dateTo);

		while (!cal.getTime().after(calTo.getTime())) {
			returnList.add(formatDate(cal.getTime(), format));
			cal.add(duration, number);
		}
	}

	private static void iterateMonthValue(Date dateFrom, Date dateTo, List<String> returnList, int number, TIME_FORMAT format) {
		Instant fromInstant = dateFrom.toInstant();
		LocalDate dateTimeFrom = fromInstant.atZone(ZoneId.of("UTC")).toLocalDate();
		Instant toInstant = dateTo.toInstant();
		LocalDate dateTimeTo = toInstant.atZone(ZoneId.of("UTC")).toLocalDate();

		while (!dateTimeFrom.isAfter(dateTimeTo)) {
			// we want to pass an UTC date to formatDate() !
			returnList.add(formatDate(
					Date.from(dateTimeFrom.atStartOfDay(ZoneId.of("UTC")).toInstant()),
					format));
			dateTimeFrom = dateTimeFrom.plusMonths(number);
		}
	}

	private static void iterateWeekValue(Date dateFrom, Date dateTo, List<String> returnList, int number, TIME_FORMAT format) {
		Instant fromInstant = dateFrom.toInstant();
		LocalDate dateTimeFrom = fromInstant.atZone(ZoneId.of("UTC")).toLocalDate();
		Instant toInstant = dateTo.toInstant();
		LocalDate dateTimeTo = toInstant.atZone(ZoneId.of("UTC")).toLocalDate();

		while (!dateTimeFrom.isAfter(dateTimeTo)) {
			// we want to pass an UTC date to formatDate() !
			returnList.add(formatDate(
					Date.from(dateTimeFrom.atStartOfDay(ZoneId.of("UTC")).toInstant()),
					format));
			dateTimeFrom = dateTimeFrom.plusWeeks(number);
		}
	}

	/**
	 * Formats a string representation of the date to be another string representation in the given time format,
	 * for example formatDate("2009", TIME_FORMAT.QUARTERLY, true) will return 2009-Q1
	 * @param date
	 * @param format
	 * @param startOfPeriod if moving from a lower frequency date (2009 for example) to a higher frequency date (Monthly) start of period
	 * would be 2009-01 and end of period would be 2009-12
	 * @return
	 */
	public static String formatDate(String date, TIME_FORMAT format, boolean startOfPeriod) {
		Date d = formatDate(date, startOfPeriod);
		return formatDate(d, format);
	}

	/**
	 * Return an SDMX-ML formatted time period, based on the frequency supplied. The value
	 * returned from this method will be determined based on the frequency and the date value
	 * supplied as follows:
	 *
	 * Annual: The year of the date
	 * Biannual: January 1 - June 30 = 1st half, July 1 - December 31 = 2nd half
	 * Triannual: January 1 - April 30 = 1st third, May 1 - August 30 = 2nd third, September 1 - December 31 = 3rd third
	 * Quarterly: January 1 - March 31 = 1st quarter, April 1 - June 30 = 2nd quarter, July 1 - September 30 = 3rd quarter, October 1 - December 31 = 4th quarter
	 * Monthly: The month of the date
	 * Weekly: The week of the year according to ISO 8601.
	 * Daily: The date only
	 * Hourly: The full date time representation.
	 *
	 * @param date  the date to convert
	 * @param freq  the frequency on which the conversion should be based
	 * @return      The date in SDMX-ML <code>TimePeriodType</code> format.
	 */
	public static String formatDate(Date date, TIME_FORMAT format) {
		if(date == null) {
			return null;
		}
		String returnVal = null;
		long timeL = date.getTime();
		switch (format) {
		case YEAR : returnVal = formattedA.get(timeL);
		break;
		case HALF_OF_YEAR : returnVal = formattedS.get(timeL);
		break;
		case THIRD_OF_YEAR : returnVal = formattedT.get(timeL);
		break;
		case QUARTER_OF_YEAR : returnVal = formattedQ.get(timeL);
		break;
		case MONTH : returnVal = formattedM.get(timeL);
		break;
		case WEEK : returnVal = formattedW.get(timeL);
		break;
		case DATE : returnVal = formattedD.get(timeL);
		break;
		case HOUR : returnVal = formattedH.get(timeL);
		break;
		case DATE_TIME : returnVal = formattedI.get(timeL);
		break;
		}
		if(returnVal != null) {
			return returnVal;
		}
		returnVal = StringUtil.manualIntern(formatDateInternal(date, format));
		switch (format) {
		case YEAR :
			synchronized (formattedA) {
				formattedA.put(timeL, returnVal);
			}
			break;
		case HALF_OF_YEAR :
			synchronized (formattedS) {
				formattedS.put(timeL, returnVal);
			}
			break;
		case THIRD_OF_YEAR :
			synchronized (formattedT) {
				formattedT.put(timeL, returnVal);
			}
			break;
		case QUARTER_OF_YEAR : synchronized (formattedQ) {
			formattedQ.put(timeL, returnVal);
		}
		break;
		case MONTH : synchronized (formattedM) {
			formattedM.put(timeL, returnVal);
		}
		break;
		case WEEK : synchronized (formattedW) {
			formattedW.put(timeL, returnVal);
		}
		break;
		case DATE : synchronized (formattedD) {
			formattedD.put(timeL, returnVal);
		}
		break;
		case HOUR : synchronized (formattedH) {
			formattedH.put(timeL, returnVal);
		}
		break;
		case DATE_TIME :
			synchronized (formattedI) {
				formattedI.put(timeL, returnVal);
			}
			break;
		}
		return returnVal;
	}
	private static String formatDateInternal(Date date, TIME_FORMAT format) {
		DateFormat df = null;
		String formatted = null;
		Calendar cal;
		switch(format) {
		case DATE :
			df = getDateFormat();
			return df.format(date);

		case DATE_TIME :
			df = getDateTimeFormat();
			return df.format(date);

		case YEAR :
			df = getYearFormat();
			formatted = df.format(date);
			cal = getCalendar(false);
			cal.setTime(date);
			return formatted;

		case HALF_OF_YEAR :
			df = getYearFormat();
			formatted = df.format(date);
			cal = getCalendar(false);
			cal.setTime(date);
			if(cal.get(Calendar.MONTH) <= 5) {  //January is month zero
				formatted += "-S1";
			} else {
				formatted += "-S2";
			}
			return formatted;

		case HOUR :
			df = geHourFormat();
			return df.format(date);

		case MONTH :
			df = getMonthFormat();
			return df.format(date);

		case QUARTER_OF_YEAR :
			df = getYearFormat();
			formatted = df.format(date);
			cal = getCalendar(false);
			cal.setTime(date);
			if(cal.get(Calendar.MONTH) <= 2) {
				formatted += "-Q1";
			} else if(cal.get(Calendar.MONTH) <= 5) {
				formatted += "-Q2";
			} else if(cal.get(Calendar.MONTH) <= 8) {
				formatted += "-Q3";
			} else {
				formatted += "-Q4";
			}
			return formatted;

		case THIRD_OF_YEAR :
			df = getYearFormat();
			formatted = df.format(date);
			cal = getCalendar(false);
			cal.setTime(date);
			if(cal.get(Calendar.MONTH) <= 3) {
				formatted += "-T1";
			} else if(cal.get(Calendar.MONTH) <= 7) {
				formatted += "-T2";
			} else {
				formatted += "-T3";
			}
			return formatted;

		case WEEK :
			// Convert the java.util.Date to a LocalDate object
			Instant dateInstant = date.toInstant();
			LocalDate dateTimeFrom = dateInstant.atZone(ZoneId.of("UTC")).toLocalDate();

			// Determine the week number and year number
			WeekFields weekFields = WeekFields.ISO;
			int weekNum = dateTimeFrom.get(weekFields.weekOfWeekBasedYear());
			int year = dateTimeFrom.get(weekFields.weekBasedYear());

			// Format the result as needed
			String weekNumStr = (weekNum < 10) ? "0" + weekNum : String.valueOf(weekNum);
			formatted = year + "-W" + weekNumStr;
			return formatted;
		}
		return null;
	}

	public static String getDateTimeStringNow() {
		DateFormat df = getDateFormatter("yyyy-MM-dd'T'HH:mm:ss.SSS");
		Date d = new Date();
		return df.format(d);
	}


	@Deprecated
	/**
	 * Returns a Calendar defaulting to 1970 timestamp
	 * @return
	 */
	public static Calendar getCalendar() {
		return getCalendar(false);
	}

	/**
	 * This method should be used instead of <code>Calendar.getInstance()</code> since it
	 * constructs a Calendar with the appropriate default settings which ensures Dates are calculated correctly.
	 * The use of a Calendar with TimeZone of GMT is important since GMT is NOT a TimeZone
	 * that has any daylight saving hours issues.
	 * @return A Calendar
	 */
	public static Calendar getCalendar(boolean defaultToNow) {
		Calendar cal = Calendar.getInstance();
		cal.clear();
		cal.setTimeZone(TimeZone.getTimeZone("GMT"));
		cal.setMinimalDaysInFirstWeek(4);
		cal.setFirstDayOfWeek(Calendar.MONDAY);
		if(defaultToNow == true) {
			cal.setTime(new Date());
		}
		return cal;
	}

	/**
	 * Returns the end of the day (23:59:59:999) for the supplied date and returns a new date instance.
	 * @param date
	 * @return
	 */
	public static Date getEndOfDay(Date date) {
		Calendar calendar = DateUtil.getCalendar(false);
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public static Date parseDate(String date, String dateFormat)  {
		DateFormat sdf = getDateFormatter(dateFormat);
		try {
			return sdf.parse(date);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Returns a DateFormat object which has its TimeZone set to GMT.
	 * The use of a Calendar with TimeZone of GMT is important since GMT is NOT a TimeZone
	 * that has any daylight saving hours issues.
	 */
	public static SimpleDateFormat getDateFormatter(String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		sdf.getCalendar().setMinimalDaysInFirstWeek(4);
		sdf.getCalendar().setFirstDayOfWeek(Calendar.MONDAY);
		return sdf;
	}

	/**
	 * SDMX 2.1 represents Bi-annual dates as [0-9][0-9][0-9][0-9]-S[1-2] e.g. 1999-S1 whereas
	 * SDMX 2.0 represents Bi-annual dates as [0-9][0-9][0-9][0-9]-B[1-2] e.g. 1999-B1.
	 * The reason appears to be that they were called biannual dates in SDMX 2.0 and Reporting Semesters in SDMX 2.1
	 * @param aDate
	 * @return
	 */
	public static String formatDateForSdmxVersion21(String aDate) {
		// This method may be called many, many times in a conversion, so let's optimise this method for speed.
		if (aDate == null) {
			return null;
		}

		if (aDate.length() != 7) {
			return aDate;
		}

		// Position 6 will contain the indicator
		char identifier = aDate.charAt(5);
		// If it is bi-annual, it will be represented by an 'S'. SDMX 2.1 states this should be a 'S'
		if (identifier == 'B') {
			char[] chars = aDate.toCharArray();
			chars[5] = 'S';
			return String.valueOf(chars);
		}
		return aDate;
	}

	/**
	 * SDMX 2.1 represents Bi-annual dates as [0-9][0-9][0-9][0-9]-S[1-2] e.g. 1999-S1 whereas
	 * SDMX 2.0 represents Bi-annual dates as [0-9][0-9][0-9][0-9]-B[1-2] e.g. 1999-B1.
	 * The reason appears to be that they were called biannual dates in SDMX 2.0 and Reporting Semesters in SDMX 2.1
	 * @param aDate
	 * @return
	 */
	public static String formatDateForSdmxVersion2(String aDate) {
		// This method may be called many, many times in a conversion, so let's optimise this method for speed.
		if (aDate == null) {
			return null;
		}

		if (aDate.length() != 7) {
			return aDate;
		}

		// Position 6 will contain the indicator
		char identifier = aDate.charAt(5);
		// If it is bi-annual, it will be represented by an 'S'. SDMX 2.0 states this should be a 'B'
		if (identifier == 'S') {
			char[] chars = aDate.toCharArray();
			chars[5] = 'B';
			return String.valueOf(chars);
		}
		return aDate;
	}

	/**
	 * SDMX 1.0 does not support quarterly dates (2001-Q1) or half-yearly dates (2001-S1) and these
	 * must be converted into monthly dates where:
	 * <li>
	 * <ul>Q1 is month 01</ul>
	 * <ul>Q2 is month 04</ul>
	 * <ul>Q3 is month 07</ul>
	 * <ul>Q4 is month 10</ul>
	 * <ul>S1 is month 01</ul>
	 * <ul>S2 is month 07</ul>
	 * </li>
	 */
	public static String formatDateForSdmxVersion1(String aDate) {
		// This method may be called many, many times in a conversion, so let's optimise this method for speed.
		if (aDate == null) {
			return null;
		}

		if (aDate.length() != 7) {
			return aDate;
		}

		// Whether its a quarterly date or bi-annual, position 6 will contain the indicator
		char identifier = aDate.charAt(5);
		if (identifier == 'Q') {
			return convertQuarterlyDateToMonthly(aDate);
		}
		if (identifier == 'S') {
			return convertBiAnnualDateToMonthly(aDate);
		}

		return aDate;
	}

	private static String convertQuarterlyDateToMonthly(String quarterlyDate) {
		// Characters 5 and 7 will contain the quarter information
		String quarter = quarterlyDate.substring(5, 7);
		String replace = "01";
		if (quarter.equals("Q1")) {
			replace = "01";
		} else if (quarter.equals("Q2")) {
			replace = "04";
		} else if (quarter.equals("Q3")) {
			replace = "07";
		} else if (quarter.equals("Q4")) {
			replace = "10";
		}
		return quarterlyDate.replace(quarter, replace);
	}

	private static String convertBiAnnualDateToMonthly(String biAnnualDate) {
		// Characters 6 and 7 will contain the date information
		String theDate = biAnnualDate.substring(5, 7);
		String replace;
		if (theDate.equals("S1")) {
			replace = "01";
		} else {
			replace = "07";  // It's a S2, so the value is 07
		}
		return biAnnualDate.replace(theDate, replace);
	}

	/**
	 * Format a date to be used on a last-modfied http header conforming to the latest RFC-1123 spec
	 * @param toFormat
	 * @return
	 */
	public static String formatDateToHttpDate(Date toFormat) {
		if (toFormat == null) {
			return "";
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateFormat.format(toFormat);
	}

	public static Optional<SdmxPeriod> parseStartAndEndDateToSdmxPeriod(Date startDate, Date endDate){
		SdmxDate startDateObj = null;
		SdmxDate endDateObj = null;
		SdmxPeriod period = null;
		if(startDate != null) {
			startDateObj = new SdmxDateImpl(startDate, TIME_FORMAT.DATE_TIME);
		}
		if(endDate != null) {
			endDateObj = new SdmxDateImpl(endDate, TIME_FORMAT.DATE_TIME);
		}
		if(ObjectUtil.validOneObject(startDateObj, endDateObj)) {
			period = new SdmxPeriodImpl(startDateObj, endDateObj);
		}
		return Optional.ofNullable(period);
	}

	/**
	 * Returns whether date2 is immediately after date1 with no gaps.
	 * For example if date1 is 2001-Q2, this method will only return true if date2 is 2001-Q3.
	 * False will be returned if the dates are of a different time format
	 * @param date1 an SdmxDate
	 * @param date2 an SdmxDate
	 * @return
	 */
	public static boolean isNextSequentialDate(SdmxDate date1, SdmxDate date2) {
		if (date1.getTimeFormatOfDate() != date2.getTimeFormatOfDate()) {
			return false;
		}
		SdmxDate sd = date1.movePeriod(1);
		return (sd.equals(date2));
	}

	/*
	 * Convert the given LocalDateTime to a Date using the given ZoneId
	 */
	public static Date localDateTime2Date(LocalDateTime ldt, ZoneId zi) {
		return Date.from(ldt.toInstant(zi.getRules().getOffset(ldt)));
	}

	/*
	 * Convert the given Date to a LocalDateTime using the given ZoneId
	 */
	public static LocalDateTime date2LocalDateTime(Date d, ZoneId zi) {
		return LocalDateTime.ofInstant(d.toInstant(), zi);
	}

	public static final ZoneId utcZoneId = ZoneId.of("UTC");
	public static final ZoneId defZoneId = ZoneId.systemDefault();

	/*
	 * Convert the given Date from the default timezone to UTC.
	 */
	public static Date dateDefault2Utc(Date d) {
		return localDateTime2Date(date2LocalDateTime(d, defZoneId), utcZoneId);
	}

	/*
	 * Convert the given Date from UTC to the default timezone.
	 */
	public static Date dateUtc2Default(Date d) {
		return localDateTime2Date(date2LocalDateTime(d, utcZoneId), defZoneId);
	}

	/**
	 * @return epoch time represented in a format compatiable with HTTP Date headers
	 */
	public static String convertEpochTimeToRFC1123(long epochTime) {
		// Convert milliseconds to Instant
		Instant instant = Instant.ofEpochMilli(epochTime);

		// Format to HTTP-date format in GMT
		return DateTimeFormatter.RFC_1123_DATE_TIME
				.withLocale(Locale.US)
				.withZone(ZoneOffset.UTC)
				.format(instant);
	}

	/**
	 * Returns the supplied epoch time in ISO-8601 format
	 * @param epochTime the time in milliseconds since 1970-01-01
	 * @return the formatted string
	 */
	public static String convertEpochTimeToIso8601(long epochTime) {
		Instant ins = Instant.ofEpochMilli(epochTime);
		DateTimeFormatter gmtStyleFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(GMT_ZONEID);
		return gmtStyleFormatter.format(ins);
	}

}
