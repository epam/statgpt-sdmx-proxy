package io.sdmx.utils.core.date;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.date.PeriodContents;

/**
 * Used to store Sets of objects against a period, default copy and merge methods provided
 * @param <T>
 */
public class PeriodSetContents<T> extends PeriodContentsImpl<Set<T>> {

	public PeriodSetContents() {
		this(new HashSet<T>());
	}

	public PeriodSetContents(Set<T> contents) {
		super(contents);
	}

	@Override
	/**
	 * Creates a copy of the underlying set to construct a new instnace
	 */
	public PeriodContents<Set<T>> copy() {
		return new PeriodSetContents<>(new HashSet<>(getContents()));
	}

	@Override
	/**
	 * Performs a set merge
	 */
	public void merge(Set<T> newContents) {
		if(newContents != null) {
			getContents().addAll(newContents);
		}
	}

}
