package io.sdmx.utils.core.object;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public class StringUtil {
	public static final String EMPTY = "";
	public static final char LF = '\n';
	/**
	 * {@code \u000d} carriage return CR ('\r').
	 *
	 * @see <a href="http://docs.oracle.com/javase/specs/jls/se7/html/jls-3.html#jls-3.10.6">JLF: Escape Sequences
	 *      for Character and String Literals</a>
	 * @since 2.2
	 */
	public static final char CR = '\r';

	private static final Map<String, WeakReference<String>> s_manualCache = Collections.synchronizedMap(new WeakHashMap<String, WeakReference<String>>( 100000 ));

	/**
	 * Get String from the local cache so that only one copy of the string exists
	 * @param str
	 * @return
	 */
	public static String manualIntern(String str) {
		if (str == null) {
			return str;
		}
		final WeakReference<String> cached = s_manualCache.get( str );
		if ( cached != null ) {
			final String value = cached.get();
			if ( value != null )
				return value;
		}
		str = new String(str);
		s_manualCache.put( str, new WeakReference<>( str ) );
		return str;
	}

	public static String[] manualIntern(String[] str) {
		if(str != null) {
			for(int i=0; i < str.length; i++) {
				str[i] = StringUtil.manualIntern(str[i]);
			}
		}
		return str;
	}

	/**
	 * Trims the string, removes line breaks and carriage returns, does a manual intern
	 * @param inputString
	 * @return
	 */
	public static String cleanString(String inputString) {
		if(inputString == null) {
			return null;
		}
		return manualIntern(removeLineBreaks(inputString).trim());
	}

	public static String stripBOM(String aString) {
		if (aString == null) {
			return null;
		}
		return stripBOM(aString.getBytes());
	}

	public static String stripBOM(byte[] asBytes) {
		if (asBytes == null) {
			return null;
		}

		if(asBytes.length > 1 && asBytes[0] == 63) {
			// byte 63 is an undisplayable character, formally known as a BOM (converted using a )
		    // There may be a number of 63 characters (encoding: ANSI_X3.4-1968) , so strip them all
		    int startPos = 1;
		    for (; startPos < asBytes.length; startPos++) {
		        if (asBytes[startPos] != 63) {
		            break;
		        }
		    }
			byte[] slice = Arrays.copyOfRange(asBytes, startPos, asBytes.length);
			return new String(slice);
		}
		if(asBytes.length > 2) {
			if(asBytes[0] == -2 && asBytes[1] == -1) {
				//BOM UTF-16 (Windows)
				byte[] slice = Arrays.copyOfRange(asBytes, 2, asBytes.length);
				return new String(slice);
			}
		}

		if(asBytes.length > 3) {
			if(asBytes[0] == -17 && asBytes[1] == -69 && asBytes[2] == -65) {
				//BOM UTF-8 (Windows)
				byte[] slice = Arrays.copyOfRange(asBytes, 3, asBytes.length);
				return new String(slice);
			}
		}

		if(asBytes.length > 4) {
			if(asBytes[0] == -61 && asBytes[1] == -66 && asBytes[2] == -61 && asBytes[3] == -65) {
				//BOM UTF-16 (Unix)
				byte[] slice = Arrays.copyOfRange(asBytes, 4, asBytes.length);
				return new String(slice);
			}
		}

		if(asBytes.length > 6) {
			if(asBytes[0] == -61 && asBytes[1] == -81 && asBytes[2] == -62 &&
					asBytes[3] == -69 && asBytes[4] == -62 && asBytes[5] == -65) {
				//BOM UTF-8 (Unix)
				byte[] slice = Arrays.copyOfRange(asBytes, 6, asBytes.length);
				return new String(slice);
			}
		}
		return new String(asBytes);
	}

	public static boolean hasBOM(String aString) {
		if (aString == null) {
			return false;
		}
		byte[] asBytes = aString.getBytes();
		if(asBytes.length > 1 && asBytes[0] == 63) {
			// byte 63 is an undisplayable character, formally known as a BOM (converted using a )
		    // There may be a number of 63 characters (encoding: ANSI_X3.4-1968) , so strip them all
			return true;
		}
		if(asBytes.length > 2) {
			if(asBytes[0] == -2 && asBytes[1] == -1) {
				//BOM UTF-16 (Windows)
				return true;
			}
		}

		if(asBytes.length > 3) {
			if(asBytes[0] == -17 && asBytes[1] == -69 && asBytes[2] == -65) {
				//BOM UTF-8 (Windows)
				return true;
			}
		}

		if(asBytes.length > 4) {
			if(asBytes[0] == -61 && asBytes[1] == -66 && asBytes[2] == -61 && asBytes[3] == -65) {
				//BOM UTF-16 (Unix)
				return true;
			}
		}

		if(asBytes.length > 6) {
			if(asBytes[0] == -61 && asBytes[1] == -81 && asBytes[2] == -62 &&
					asBytes[3] == -69 && asBytes[4] == -62 && asBytes[5] == -65) {
				//BOM UTF-8 (Unix)
				return true;
			}
		}
		return false;
	}

	public static String removeLineBreaks(String inputString) {
		if(inputString == null) {
			return null;
		}
		inputString = inputString.replaceAll("\\u000A", "");    // Removes all new-line characters
		inputString = inputString.replaceAll("\\u000D", "");    // Removes all carriage-return characters
		return inputString;
	}

	public static String[] splitOnLineBreaks(String inputString) {
		return inputString.split(System.lineSeparator());
	}

	private static final class WhiteSpace  {
		static final String WHITESPACE_CHARS =
				"\u2002\u3000\r\u0085\u200A\u2005\u2000\u3000\u2029\u000B\u3000\u2008\u2003\u205F\u3000\u1680"
			  + "\u0009\u0020\u2006\u2001\u202F\u00A0\u000C\u2009\u3000\u2004\u3000\u3000\u2028\n\u2007\u3000";

		private static final int SHIFT = Integer.numberOfLeadingZeros(WHITESPACE_CHARS.length() - 1);
		private static final int MULTIPLIER = 1682554634;
		private static final WhiteSpace INSTANCE = new WhiteSpace();
		public boolean matches(char c) {
			return WHITESPACE_CHARS.charAt((MULTIPLIER * c) >>> SHIFT) == c;
		}
	}

	/**
	 * Trims all whitespace characters from a string
	 * @param string
	 * @return
	 */
	public static String trim(String string) {
		int len = string.length();
		int first;
		int last;

		for (first = 0; first < len; first++) {
			if (!WhiteSpace.INSTANCE.matches(string.charAt(first))) {
				break;
			}
		}
		for (last = len - 1; last > first; last--) {
			if (!WhiteSpace.INSTANCE.matches(string.charAt(last))) {
				break;
			}
		}

		return string.subSequence(first, last + 1).toString();
	}

	/**
	 * \h is a horizontal whitespace character: [ \t\xA0\u1680\u180e\u2000-\u200a\u202f\u205f\u3000]
	 *
	 * @param inputString
	 * @return
	 */
	public static String removeHorizontalLineBreaks(String inputString) {
		if(inputString == null) {
			return null;
		}
		return inputString.trim().replaceAll("(^\\h*)|(\\h*$)","");
	}

	// Chopping
	//-----------------------------------------------------------------------
	/**
	 * <p>Remove the last character from a String.</p>
	 *
	 * <p>If the String ends in {@code \r\n}, then remove both
	 * of them.</p>
	 *
	 * <pre>
	 * StringUtils.chop(null)          = null
	 * StringUtils.chop("")            = ""
	 * StringUtils.chop("abc \r")      = "abc "
	 * StringUtils.chop("abc\n")       = "abc"
	 * StringUtils.chop("abc\r\n")     = "abc"
	 * StringUtils.chop("abc")         = "ab"
	 * StringUtils.chop("abc\nabc")    = "abc\nab"
	 * StringUtils.chop("a")           = ""
	 * StringUtils.chop("\r")          = ""
	 * StringUtils.chop("\n")          = ""
	 * StringUtils.chop("\r\n")        = ""
	 * </pre>
	 *
	 * @param str  the String to chop last character from, may be null
	 * @return String without last character, {@code null} if null String input
	 */
	public static String chop(final String str) {
		if (str == null) {
			return null;
		}
		final int strLen = str.length();
		if (strLen < 2) {
			return EMPTY;
		}
		final int lastIdx = strLen - 1;
		final String ret = str.substring(0, lastIdx);
		final char last = str.charAt(lastIdx);
		if (last == LF && ret.charAt(lastIdx - 1) == CR) {
			return ret.substring(0, lastIdx - 1);
		}
		return ret;
	}

	/**
	 * Splits a string which may include regex, and ensures that the string does not split
	 * on anything contained in the regex.  Example:
	 *
	 * (.*):\\1[^:]:C
	 *
	 * Would result in the following if split on the colon
	 * <ol>
	 *   <li>(.*)</li>
	 *   <li>\\1[^:]</li>
	 *   <li>C</li>
	 * </ol>
	 *
	 *
	 * @param source
	 * @param splitOn
	 * @param limit - the max split items, -1 to indicate no limit
	 * @return
	 */
	public static String[] splitWithRegex(String source, String splitOn, int limit) {
		if(limit == 1) {
			return new String[] {source};
		}
		List<String> targetsList = new ArrayList<>(5);
		StringBuilder sbx = new StringBuilder();
		char colon = splitOn.charAt(0);
		char openbracket = "[".charAt(0);
		char openparenthisis = "(".charAt(0);
		char closebracket = "]".charAt(0);
		char closeparenthisis = ")".charAt(0);

		int inbracket = 0;
		boolean limitHit = false;
		for(char c : source.toCharArray()) {
			if(!limitHit) {
				if(c == colon && inbracket == 0) {
					targetsList.add(sbx.toString());
					sbx = new StringBuilder();
					limitHit = targetsList.size() == limit;
					continue;
				} else if(c == openbracket || c == openparenthisis) {
					inbracket++;
				}  else if(c == closebracket || c == closeparenthisis) {
					inbracket--;
				}
			}
			sbx.append(c);
		}
		targetsList.add(sbx.toString());
		String[] returnArray = new String[targetsList.size()];
		return targetsList.toArray(returnArray);
	}

	/**
	 * Return the position of the "n"th occurrence of a specified character. Returns -1 if not found.
	 * For example in the String ABACADA, requesting the 3rd occurrence of "A" will return 4.
	 * Requesting the 2nd occurrence of "D" will return -1, since there is no 2nd occurrence.
	 * @param inputStr
	 * @param characterToFind
	 * @param targetCount The "1 indexed" item to find
	 * @return
	 */
	public static int findNthOccurence(String inputStr, char characterToFind, int targetCount) {
		if (targetCount < 1) {
			return -1;
		}
		int foundCount = 0;
		for (int i = 0; i < inputStr.length(); i++) {
			if (inputStr.charAt(i) == characterToFind) {
				foundCount++;
				if (foundCount == targetCount) {
					return i;
				}
			}
		}
		return -1;
	}

}
