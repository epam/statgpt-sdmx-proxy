package io.sdmx.utils.core.process;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.notification.SimpleListener;
import io.sdmx.api.process.Stoppable;
import io.sdmx.utils.core.timer.Stopwatch;

public abstract class AbstractStoppable implements Stoppable, SimpleListener {
	private STOPPABLE_STATUS status = STOPPABLE_STATUS.STOPPED;
	private Stopwatch stopwatch = new Stopwatch();
	
	private Set<SimpleListener> listeners = new HashSet<>();
	private Set<Stoppable> compositeStoppables = new HashSet<>();
	
	private boolean isRestartRequest;
	
	@Override
    public long getStatusDuration() {
		return stopwatch.getDuration();
	}

	@Override
    public STOPPABLE_STATUS getStoppableStatus() {
		return status;
	}
	
	protected void addCompositeStoppable(Stoppable stoppable) {
		compositeStoppables.add(stoppable);
		stoppable.addListener(this);
	}

	@Override
    public void restart() throws SdmxException {
		if(status == STOPPABLE_STATUS.STARTED) {
			isRestartRequest = true;
			shutdown();
		} else  if(status == STOPPABLE_STATUS.STOPPED) {
			startUp();
		}
	}

	@Override
    public void shutdown() throws SdmxException {
		if(status == STOPPABLE_STATUS.STARTED) {
			changeStatus(STOPPABLE_STATUS.SHUTTING_DOWN);
			for(Stoppable currentCompositeStoppable : compositeStoppables) {
				currentCompositeStoppable.shutdown();
			}
			performShutdownChecks();
		}
	}

	@Override
    public void startUp() throws SdmxException {
		if(status == STOPPABLE_STATUS.STOPPED) {
			changeStatus(STOPPABLE_STATUS.STARTING);
			for(Stoppable currentCompositeStoppable : compositeStoppables) {
				currentCompositeStoppable.startUp();
			}
			performStartupChecks();
		}
	}
	
	/**
	 * Checks each of the composite stoppables is started, if they are then this one can be started
	 */
	private void performStartupChecks() {
		for(Stoppable currentCompositeStoppable : compositeStoppables) {
			if(currentCompositeStoppable.getStoppableStatus() != STOPPABLE_STATUS.STARTED) {
				return;
			}
		}
		startupRequest();
	}
	
	
	/**
	 * Checks each of the composite stoppables is stopped, if they are then this one can be stopped
	 */
	private void performShutdownChecks() {
		for(Stoppable currentCompositeStoppable : compositeStoppables) {
			if(currentCompositeStoppable.getStoppableStatus() != STOPPABLE_STATUS.STOPPED) {
				return;
			}
		}
		shutdownRequest();
	}
	
	/**
	 * The status of one of the stoppables has changed
	 */
	@Override
    public void invoke() {
		if(this.status == STOPPABLE_STATUS.SHUTTING_DOWN) {
			performShutdownChecks();
		}
		if(this.status == STOPPABLE_STATUS.STARTING) {
			performStartupChecks();
		}
	}

	private void changeStatus(STOPPABLE_STATUS newStatus) {
		stopwatch.start();
		status = newStatus;
		notifyStatusChanged();
	}
	
	protected void notifyStatusChanged() {
		for(SimpleListener currentListener : listeners) {
			currentListener.invoke();
		}
	}
	
	protected void startupComplete() {
		changeStatus(STOPPABLE_STATUS.STARTED);
	}
	
	protected void shutdownComplete() {
		changeStatus(STOPPABLE_STATUS.STOPPED);
		if(isRestartRequest) {
			isRestartRequest = false;
			startUp();
		}
	}
	
	
	@Override
    public void addListener(SimpleListener listener) {
		listeners.add(listener);		
	}

	@Override
    public void removeListener(SimpleListener listener) {
		listeners.remove(listener);
	}

	/**
	 * Requests that the stoppable is started
	 */
	protected abstract void startupRequest();

	/**
	 * Requests that the stoppable is shutdown 
	 */
	protected abstract void shutdownRequest();
	
}
