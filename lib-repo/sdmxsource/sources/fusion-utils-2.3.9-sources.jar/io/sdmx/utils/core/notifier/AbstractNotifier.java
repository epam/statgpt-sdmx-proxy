package io.sdmx.utils.core.notifier;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.notification.Listener;
import io.sdmx.api.notification.Notifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractNotifier<T> implements Notifier<T> {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractNotifier.class);
	
	private List<Listener<T>> listners = new ArrayList<>();
	
	@Override
    public void addListener(Listener<T> listener) {
		if(!listners.contains(listener)) {
			listners.add(listener);
		}
	}

	@Override
    public void removeListener(Listener<T> listener) {
		listners.remove(listener);
	}
	
	public void notifyListeners(T notification) {
		for(Listener<T> currentLisener : listners) {
			try {
				currentLisener.invoke(notification);
			} catch(Throwable th) {
				th.printStackTrace();
				LOG.error(th.getMessage());
			}
		}
	}
}
