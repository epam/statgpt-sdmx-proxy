package io.sdmx.utils.core.application;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.dgc.VMID;

import io.sdmx.api.application.ISystemInformation;

/**
 * JVM specific information about the system
 */
public class SystemInformation implements ISystemInformation {
	private static final SystemInformation INSTANCE = new SystemInformation();
	private String machineIdentifier;
	private String vmIdentifier;
	private final long launchDate = System.currentTimeMillis();
	
	public static SystemInformation INSTANCE() {
		return INSTANCE;
	}

	private SystemInformation() {
		vmIdentifier = new VMID().toString();
		try {
			InetAddress addr = InetAddress.getLocalHost();
			machineIdentifier = addr.toString();
		} catch (UnknownHostException e) {
			machineIdentifier = "UNKNOWN";
		}
	}

	/**
	 * @return the time in milliseconds that the application was launched
	 */
	@Override
	public long getLaunchDate() {
		return launchDate;
	}

	/**
	 * Information about
	 * Example: DESKTOP-SN38HUC/10.0.75.1
	 * @return
	 */
	@Override
	public String getMachineIdentifier() {
		return machineIdentifier;
	}

	/**
	 * Identifier which is unique when the JVM launched, it is not tied to the machine, it is simple a Global GUID which is generated on JVM launch
	 * Example: DESKTOP-SN38HUC/10.0.75.1
	 * @return
	 */
	@Override
	public String getVmIdentifier() {
		return vmIdentifier;
	}
}
