package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

import io.sdmx.utils.core.collection.KeyValueImpl;

public class SingletonOIS extends ObjectInputStream {

    public SingletonOIS(InputStream in) throws IOException {
        super(in);
        super.enableResolveObject(true);
    }

	@Override
	protected Object resolveObject(Object obj) throws IOException {
		if(obj.getClass().getCanonicalName().equals("io.sdmx.utils.core.collection.KeyValueImpl")) {
			KeyValueImpl cast = (KeyValueImpl)obj;
			return KeyValueImpl.getInstance(cast.getConcept(), cast.getCode());
		}
		return super.resolveObject(obj);
	}
}
