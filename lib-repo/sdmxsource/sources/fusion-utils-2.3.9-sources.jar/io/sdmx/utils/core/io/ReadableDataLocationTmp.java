package io.sdmx.utils.core.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;

import com.google.common.io.Files;

import io.sdmx.api.io.ReadableDataLocation;

/**
 * Built from an InputStream - copies the data to a local temporary file, and allocates the information out as new input streams on demand
 */
public class ReadableDataLocationTmp extends AbstractReadableDataLocation {
    private static final long serialVersionUID = 860775214722641122L;
    protected URI uri;
    protected boolean deleteOnClose = false;
    private String name;

    public ReadableDataLocationTmp(String uriStr) {
        if(uriStr == null) {
            throw new IllegalArgumentException("Can not create StreamSourceData - uriStr can not be null");
        }
        try {
            this.uri = new URI(uriStr);
            if(uri.isAbsolute()) {
                if(!uri.getScheme().equals("file")) {
                    uri = URIUtil.getURIUtil().getUri(uri.toURL().openStream());
                    deleteOnClose = true;
                }
            }
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ReadableDataLocationTmp(File f) {
        if(f == null) {
            throw new IllegalArgumentException("Can not create StreamSourceData - file can not be null");
        }
        uri = f.toURI();
        name = f.getName();
    }

    public ReadableDataLocationTmp(Path p) {
        uri = p.toUri();
        name = p.getFileName().toString();
    }

    public ReadableDataLocationTmp(URL url) {
        if(url == null) {
            throw new IllegalArgumentException("Can not create StreamSourceData - url can not be null");
        }
        try {
            uri = URIUtil.getURIUtil().getUri(url.openStream());
            deleteOnClose = true;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public ReadableDataLocationTmp(URI uri) {
        if(uri == null) {
            throw new IllegalArgumentException("Can not create StreamSourceData - uri can not be null");
        }
        this.uri = uri;
    }


    public ReadableDataLocationTmp(InputStream is) {
        uri = URIUtil.getTemporaryURI();
        deleteOnClose = true;
        StreamUtil.copyStream(is, URIUtil.getOutputStream(uri));
        StreamUtil.closeStream(is);
    }

    @Override
    public ReadableDataLocation move(Path moveTo) {
        File f = URIUtil.getFile(uri);
        try {
            Files.move(f, moveTo.toFile());
            return completeMove(moveTo);
        } catch (IOException e) {
            return super.move(moveTo);
        }
    }

    @Override
    protected InputStream getStreamInternal() throws IOException {
        return URIUtil.getInputStream(uri);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    protected void closeInternal() {
        if(deleteOnClose) {
            URIUtil.deleteUri(uri);
        }
    }

    @Override
    public String toString() {
        return uri.toString();
    }

    @Override
    public ReadableDataLocationTmp copy() {
        return new ReadableDataLocationTmp(getInputStream());
    }

    @Override
    protected long calculateSize() {
        return URIUtil.getFile(uri).length();
    }

}