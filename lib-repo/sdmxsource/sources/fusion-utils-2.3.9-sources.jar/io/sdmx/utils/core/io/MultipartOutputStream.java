package io.sdmx.utils.core.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

/**
 * Writes multiple files to the output stream, each time the close() method is called the current part is closed
 * 
 * 
 * @example
 *  This is the preamble.  It is to be ignored, though it 
     is a handy place for mail composers to include an 
     explanatory note to non-MIME compliant readers. 
     --simple boundary 

     This is implicitly typed plain ASCII text. 
     It does NOT end with a linebreak. 
     --simple boundary 
     Content-type: text/plain; charset=us-ascii 

     This is explicitly typed plain ASCII text. 
     It DOES end with a linebreak. 

     --simple boundary-- 
     This is the epilogue.  It is also to be ignored.
 *
 */
public class MultipartOutputStream extends FilterOutputStream {
	private static byte[] __CRLF;
    private static byte[] __DASHDASH;
    private static final String ISO88591 = "iso-8859-1";
    
    public static String MULTIPART_MIXED="multipart/mixed";
    public static String MULTIPART_X_MIXED_REPLACE="multipart/x-mixed-replace";
    
    static
    {
        try
        {
            __CRLF="\015\012".getBytes(ISO88591);
            __DASHDASH="--".getBytes(ISO88591);
        }
        catch (Exception e) {e.printStackTrace(); System.exit(1);}
    }
    
    private byte[] boundaryBytes;
    private boolean inPart=false;    

	public MultipartOutputStream(OutputStream out, String boundary) {
		super(out);
		 try {
			boundaryBytes= boundary.getBytes(ISO88591);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}
    
	
    @Override
    public void close() throws IOException
    {
    	if (inPart) {
    		out.write(__CRLF);
    		out.write(__DASHDASH);
    		out.write(boundaryBytes);
    		out.write(__DASHDASH);
    		out.write(__CRLF);
    	}
    	super.close();
    }
 
    
    /**
     *  Start creation of the next Content.
     */
    public void startPart(String contentType, String formname, String fileName)  throws IOException
    {
        if (inPart)
            out.write(__CRLF);
        inPart=true;
        out.write(__DASHDASH);
        out.write(boundaryBytes);
        out.write(__CRLF);
        out.write(("Content-Type: "+contentType).getBytes(ISO88591));
        out.write(__CRLF);
        out.write(("Content-Disposition: form-data; name= "+formname+"; filename="+fileName).getBytes(ISO88591));
        out.write(__CRLF);
        out.write(__CRLF);
    }
}
