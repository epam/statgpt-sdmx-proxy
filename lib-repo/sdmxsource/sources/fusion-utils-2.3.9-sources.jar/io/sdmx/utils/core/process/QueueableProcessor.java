package io.sdmx.utils.core.process;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import io.sdmx.api.notification.SimpleListener;
import io.sdmx.api.process.Processor;
import io.sdmx.api.process.Stoppable;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class QueueableProcessor <K> extends AbstractStoppableProcessor implements Runnable, Stoppable, Processor, SimpleListener {
	private static final Logger LOG = LoggerFactory.getLogger(QueueableProcessor.class); 
	
	private String processorName;
	private BlockingQueue<K> itemsToProcess;
	private Map<K, LocalProcess> processMap = Collections.synchronizedMap(new HashMap<>());
	protected Thread aThread;
	private int processCountToDropFromQueue = 0;
	
	private boolean shutdownRequested;
	
	public QueueableProcessor(String processorName) {
		this.processorName = processorName;
		itemsToProcess = new LinkedBlockingQueue<>();
		addListener(this);
		startThread();
	}
	
	private void startThread() {
		LOG.info("Start QueueableProcessor: "+ this.getProcessorName());
		aThread = new Thread(this);
		aThread.start();
	}
	
	public String getProcessorName() {
		return processorName;
	}
	/**
	 */
	public QueueableProcess placeInQueue(QueueableProcess process, K queueItem) {
		if(queueItem == null) {
			LOG.warn("place item in queue fails as item was null");
			return process;
		}
		LOG.debug("Place item in queue");
		process.acknowledgeProcess();
		process.joinQueue();
		processMap.put(queueItem, new LocalProcess(process));
		itemsToProcess.add(queueItem);
		return process;
	}

	/**
	 * Empty the process queue by retrieving the current queue size.
	 * With that just the current queue is emptied, meaning that new processes can be added also during the empty process.
	 */
	public void emptyProcessQueue() {
		processCountToDropFromQueue = itemsToProcess.size();
	}

	/**
	 * @return the current queue size. This is >=0.
	 */
	public int getCurrentQueueSize(){
		return itemsToProcess.size();
	}
	
	private class LocalProcess {
		private Map<Object, Object> threadLocal;
		private QueueableProcess process;
		
		public LocalProcess(QueueableProcess process) {
			this.threadLocal = ThreadLocalUtil.getThreadContents();
			this.process = process;
		}
		
		public void copyThreadLocal() {
			for(Object o : threadLocal.keySet()) {
				ThreadLocalUtil.storeOnThread(o, threadLocal.get(o));
			}
		}
		public QueueableProcess getProcess() {
			return process;
		}
	}

	@Override
	public void shutdownRequest() {
		shutdownRequested = true;
		if(!isProcessing()) {
			aThread.interrupt();
			shutdownRequested = false;
			shutdownComplete();	
		}
	}

	@Override
	public void startupRequest() {
		aThread = new Thread(this, UUID.randomUUID().toString());
		aThread.start();
		startupComplete();
		
	}

	@Override
	public void invoke() {
		if(getStoppableStatus()==STOPPABLE_STATUS.STARTED && !isProcessing()) {
			synchronized(aThread) {
				aThread.notify();
			}
		}
		if(shutdownRequested && !isProcessing()) {
			shutdownRequest();
		}
	}

	@Override
	public void run() {
		K stufftoProcess = null;
		LocalProcess localProcess = null;
		try {
			while ((stufftoProcess = itemsToProcess.take()) != null) {
				synchronized(this) {
					if(!isProcessing()) {
						startProcessor();
					} 
				}
				localProcess = processMap.remove(stufftoProcess);
				if(localProcess == null) {
					continue;
				}
				QueueableProcess process = localProcess.getProcess();
				if (processCountToDropFromQueue > 0){
					process.cancelProcess();
					processCountToDropFromQueue = processCountToDropFromQueue - 1;
					continue;
				}
				final LocalProcess toRun = localProcess;
				final K toProcess = stufftoProcess;
				FusionSecurityContext.CTX().runAsUser(process.getSeurityDetails(), ()-> {
					LOG.debug("Take item from queue");
					process.startProcess();
					try {
						toRun.copyThreadLocal();
						process(process, toProcess);		
						process.endProcess();
					} catch(Throwable th) {
						process.setError(th);
					} finally {
						ThreadLocalUtil.clearThread();
						stopProcessor();
					}
				});
			}
		} catch (InterruptedException e) {
			LOG.error("InterruptedException on QueueableProcessor - Stop Processor");
			stopProcessor();
			LOG.error("InterruptedException on QueueableProcessor - place item back onto queue and restart thread");
			if(stufftoProcess != null) {
				itemsToProcess.add(stufftoProcess);
				processMap.put(stufftoProcess, localProcess);
			}
			startThread();
		} catch(Throwable th) {
			//Something blew up - ensure the processor continues to run, without the queue item
			stopProcessor();
			LOG.error("QueueableProcessor Exception - restart thread", th);
			startProcessor();
			startThread();
		}
	}
		
	protected abstract void process(QueueableProcess process, K stuff);	
	
}