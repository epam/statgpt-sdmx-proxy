package io.sdmx.utils.core.comparator;

import java.util.Comparator;

/**
 * Compares string length, if they are the same length, the strings undergo a natural compare, example sort
 * AAAA
 * BBBB
 * AAA
 * BBB
 * CC
 * D
 */
public class StringLengthComparator implements Comparator<String> {
	private boolean descending;
	
	public static final StringLengthComparator INSTANCE_DESCENDING = new StringLengthComparator(true);
	public static final StringLengthComparator INSTANCE_ASCENDING = new StringLengthComparator(false);

	private StringLengthComparator(boolean descending) {
		this.descending = descending;
	}

	@Override
	public int compare(String arg0, String arg1) {
		int l1 = arg0.length();
		int l2 = arg1.length();
		if(l1 != l2) {
			if(descending) {
				return  l2 - l1;
			}
			return  l1 - l2;
		}
		return arg0.compareTo(arg1);
	}

	
}
