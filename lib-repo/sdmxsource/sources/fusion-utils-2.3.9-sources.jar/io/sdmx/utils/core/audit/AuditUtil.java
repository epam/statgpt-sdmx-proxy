package io.sdmx.utils.core.audit;

import io.sdmx.api.audit.IAuditEventManager;
import io.sdmx.api.audit.IFusionAuditEvent;
import io.sdmx.api.process.IProcess;
import io.sdmx.api.process.IProcessWithResponse;
import io.sdmx.api.security.ISecureThread;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.security.FusionSecurityContext;

/**
 * Provides a static wrapper on top of the audit manager
 */
public class AuditUtil {
	private static IAuditEventManager auditEventManager;
	
	static {
		SingletonStore.registerInterest(IAuditEventManager.class, (manager)-> {
			auditEventManager = manager;	
		});
	}
	
	public static void setAuditEventManager(IAuditEventManager auditEventManager) {
		AuditUtil.auditEventManager = auditEventManager;
	}
	
	public static enum ACTION {
		ADD, EDIT, DELETE, VIEW;
	}
	
//	public static void reportError(IErrorReport report) {
//		if(errorReporterManager != null) {
//			errorReporterManager.reportError(report);
//		}
//	}
	
	/**
	 * Sets the current audit event, from the root event to all current and future child events,
	 * to be persisted, meaning the audit should not be removed even during housekeeping operations
	 */
	public static void persisted() {
		if(auditEventManager != null) {
			auditEventManager.setPersisted();
		}
	}
	
	/**
	 * Starts an event where settings are changed
	 * 
	 * @param processId example SECURITY
	 * @param target example USER
	 * @param action ADD
	 * @param auditProcss performs the action
	 */
	public static String startSettingsAuditEvent(String processId, String target, ACTION action, IProcess procss) {
		return AuditUtil.startAuditEvent(processId, "SETTINGS", ()-> {
			AuditUtil.addAuditProperty("Target", target);
			AuditUtil.addAuditProperty("Action", action);
			procss.runProcess();
		});
	}
	
	/**
	 * An operation is performed on an audited process
	 * @param processId example CACHE
	 * @param action example REFRESH
	 * @param auditProcss
	 */
	public static String startOperationEvent(String processId, String action, IProcess auditProcss) {
		return AuditUtil.startAuditEvent(processId, "OPERATION", ()-> {
			AuditUtil.addAuditProperty("Action", action);
			auditProcss.runProcess();
		});
	}
	
	public static String prepareAudit(String processId, String eventType, IProcess auditProcss) {
		if(auditEventManager != null) {
			return auditEventManager.prepareAudit(processId, eventType, auditProcss);
		}
		auditProcss.runProcess();
		return null;
	}
	
	/**
	 * starts an audited event with the event type passed in, the event type can be refined at a later 
	 * stage when more information is determined (example RESTQuery may be refined to Structure Query)
	 */
	public static String startAuditEvent(String processId, String eventType, IProcess auditProcss) {
		if(auditEventManager != null) {
			return auditEventManager.startAuditEvent(processId, eventType, auditProcss);
		}
		auditProcss.runProcess();
		return null;
	}
	
	/**
	 * starts an audited event with the event type passed in, the event type can be refined at a later 
	 * stage when more information is determined (example RESTQuery may be refined to Structure Query)
	 */
	public static String startAuditEvent(String processId, String eventType, String parentId, IProcess auditProcss) {
		if(auditEventManager != null) {
			return auditEventManager.startAuditEvent(processId, eventType, parentId, auditProcss);
		} 
		auditProcss.runProcess();
		return null;
	}
	
	/**
	 * starts an audited event with the processId passed in, if there is already an audit in place, the new audit 
	 * will be a child of the current audit
	 * 
	 * @param processId ID of the process which is writing this event
	 * @param eventType The type of event (optional) for further refinement
	 * @param auditProcss - the interface which executes the process
	 * @return audit id
	 */
	public static <T> T startAuditEventWithResponse(String processId, String eventType, IProcessWithResponse<T> auditProcss) {
		if(auditEventManager != null) {
			return auditEventManager.startAuditEventWithResponse(processId, eventType, auditProcss);
		} 
		return auditProcss.runProcess();
	}
	
	
	/**
	 * @param processId
	 * @param eventType
	 * @param copyThreadLocal
	 * @param process
	 * @return audit id created
	 */
	public static String startNewThread(String processId, String eventType, boolean copyThreadLocal, IProcess process) {
		if(auditEventManager != null) {
			return auditEventManager.startNewThread(processId, eventType, copyThreadLocal, process);
		} else {
			ISecureThread thread = FusionSecurityContext.CTX().createSecureThread(copyThreadLocal);
			thread.runProcess(process);
			return null;
		}	
	}
	
	/**
	 * adds a property to this audit event or subprocess if in a subprocess
	 * @param propertyId
	 * @param propertyValue - properties are stored in a JSONObject, so a property value can be a String, Numerical (Integer, Double) JsonObject or JsonArray
	 */
	public static void addAuditProperty(String propertyId, Object propertyValue) {
		if(auditEventManager != null && propertyValue != null) {
			auditEventManager.addAuditProperty(propertyId, propertyValue);
		}
	}

	/**
	 * @return the current audit or null if nothing is being audited
	 */
	public static IFusionAuditEvent getCurrentAudit() {
		if(auditEventManager != null) {
			return auditEventManager.getCurrentAudit();
		}
		return null;
	}
	
	/**
	 * @return the id of the current process being audited or null if nothing is being audited
	 */
	public static String getCurrentAuditId() {
		if(auditEventManager != null) {
			return auditEventManager.getCurrentAuditId();
		}
		return null;
	}
}
