package io.sdmx.utils.core.csv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.opencsv.RFC4180Parser;
import com.opencsv.RFC4180ParserBuilder;

import io.sdmx.api.csv.ColumnReaderEngine;
import io.sdmx.api.csv.DELIMITER;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.CountingBufferedReader;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class CSVColumnReaderEngineImpl implements ColumnReaderEngine {
	private static final FormatDetails formatDetails = new FormatDetailsImpl("csv", "csv", "application/vnd.csv", false);

	private ReadableDataLocation rdl;
	private InputStream inputStream;
	private BufferedReader br;
	private String currentString;
	private RFC4180Parser parser;
	private boolean endOfFileReached = false;

	private int startIndex = 0;
	private int pos = 0;

	private List<String> header;
	private String[] currentLine;  //Current CSV Line
	private List<String> currentRow; //Current CSV Line Converted into Immutable List

	private DELIMITER delimiter;
	
	private final boolean isNotificationRequired;
	private CountingBufferedReader cbr;

	public CSVColumnReaderEngineImpl(ReadableDataLocation rdl) {
		this(rdl, DELIMITER.COMMA);
	}

	public CSVColumnReaderEngineImpl(ReadableDataLocation rdl, DELIMITER delimiter) {
		this(rdl, delimiter, null, 0, false);
	}

	/**
	 * @param rdl - providing the stream for data
	 * @param delimiter - delimiter to use, or null to default to comma
	 * @param header the ids of each column header, or null/empty list to indicate this is read from the file
	 * @param startIndex zero index line to start reading on
	 */
	public CSVColumnReaderEngineImpl(ReadableDataLocation rdl, DELIMITER delimiter, List<String> header, int startIndex) {
		this(rdl, delimiter, header, startIndex, false);
	}

	public CSVColumnReaderEngineImpl(ReadableDataLocation rdl, DELIMITER delimiter, List<String> header, int startIndex, boolean isNotificationRequired) {
		if(delimiter == null) {
			delimiter = DELIMITER.COMMA;
		}
		boolean buildHeader = true;
		if(ObjectUtil.validCollection(header)) {
			this.header = Collections.unmodifiableList(new ArrayList<>(header));
			buildHeader = false;
		}
		this.rdl = rdl;
		this.delimiter = delimiter;
		this.startIndex = startIndex;
		this.isNotificationRequired = isNotificationRequired;
		
		if(buildHeader) {
			this.startIndex++;
		}
		parser = new RFC4180ParserBuilder().withSeparator(delimiter.getDelimiter()).build();
		try {
			createReader(buildHeader);
		} catch (Exception e) {
			throw new SdmxException(e, "Could not create CSVColumnReaderEngine");
		}
	}

	@Override
	public CSVColumnReaderEngineImpl copy() {
		return new CSVColumnReaderEngineImpl(rdl.copy(), delimiter, header, startIndex, isNotificationRequired);
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}

	private void createReader(boolean buildHeader) {
		pos = 0;
		inputStream = rdl.getInputStream();
		endOfFileReached = false;

		if (isNotificationRequired) {
			try {
				cbr = new CountingBufferedReader(rdl);
			} catch (IOException e) {
				throw new SdmxException(e, "Could not create CountingBufferedReader");
			}
		} else {
			br = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
		}
		
		if(buildHeader) {
			moveNextRow();
			buildHeader();
		}
		for(int i = pos; i < startIndex; i ++) {
			if(readLine() == null) {
				endOfFileReached = true;
				return;
			}
		}
	}

	/**
	 *
	 */
	private void buildHeader() {
		header = readRow();
		if (header.size() == 0) {
			throw new SdmxException("Can not read CSV Columnar data, no column header row detected");
		}
		
		// MEDIT#418 - Ensure any BOMs are removed from the header
		String firstElementWithoutBom = StringUtil.stripBOM( header.get(0).getBytes()  );
		if (firstElementWithoutBom.length() != header.get(0).length()) {
			// A BOM was removed, so update the "header" field
			ArrayList<String> newHeader = new ArrayList<>(header);
			newHeader.set(0,  firstElementWithoutBom);
			this.header = Collections.unmodifiableList(newHeader);
		}
	}

	@Override
	public List<String> readHeader() {
		return header;
	}

	@Override
	public void reset() {
		if (inputStream != null) {
			StreamUtil.closeStream(inputStream);
		}
		createReader(false);
	}

	@Override
	public boolean moveNextRow() {
		currentRow = null;
		if (endOfFileReached) {
			return false;
		}
		currentString = readLine();
		if (currentString == null) {
			endOfFileReached = true;
			return false;
		}
		try {
			currentLine = parser.parseLine(currentString);
		} catch (IOException e) {
			throw new SdmxException(e, "Error reading CSV Row: "+pos);
		}

		for(String lineItem : currentLine) {
			if(ObjectUtil.validString(lineItem)) {
				pos++;
				this.currentRow = Collections.unmodifiableList(Arrays.asList(currentLine));
				return true;
			}
		}
		//The current line has no valid strings
		return this.moveNextRow();
	}
	
	

	/**
	 * reads a line of text
	 * @return
	 */
	private String readLine() {
		try {
			if (isNotificationRequired) {
				return cbr.readLine();
			} else {
				return br.readLine();
			}
		} catch (IOException e) {
			throw new SdmxException(e, "Error reading row from stream");
		}
	}

	@Override
	public List<String> readRow() {
		if(currentLine == null) {
			return Collections.emptyList();
		}
		return this.currentRow;
	}

	@Override
	public void close() {
		if (rdl != null) {
			if (!rdl.isClosed()) {
				rdl.close();
			}
		}
	}

	@Override
	public int getPosition() {
		return pos;
	}

	public DELIMITER getDelimiter() {
		return delimiter;
	}

	@Override
	public long getCurrentByteCount() {
		if(cbr == null) {
			return -1;
		}
		return cbr.getByteCount();
	}
}
