package io.sdmx.utils.core.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Set;

public class PropertiesHelper {
	/**
	 * Loads the specified file into a Properties object.
	 * @param fileName The path and name to the properties file
	 * @return A Properties object containing the contents of the file. 
	 * @throws FileNotFoundException If the specified fileName could not be found.
	 * @throws IOException If the specified file could not be loaded into a Properties file.
	 */
	public static Properties loadPropertiesFile(String fileName) throws FileNotFoundException, IOException {
		FileInputStream fis = new FileInputStream(fileName);
		
		Properties properties = new Properties();
		properties.load(fis);
		
		fis.close();

		return properties;
	}
	
	/**
	 * Loads the specified file into a Properties object.
	 * @param fileName The path and name to the properties file
	 * @return A Properties object containing the contents of the file. 
	 * @throws FileNotFoundException If the specified fileName could not be found.
	 * @throws IOException If the specified file could not be loaded into a Properties file.
	 */
	public static Properties loadPropertiesFileFromJar(String fileName) throws FileNotFoundException, IOException {
		InputStream in = PropertiesHelper.class.getClassLoader().getResourceAsStream(fileName);
		if (in == null) {
			throw new FileNotFoundException(fileName);
		}
		Properties properties = new Properties();
		properties.load(in);
		in.close();
		return properties;
	}
	
	
	/**
	 * Copies the properties from the specified sourceFile to the specified target file. Both must be valid Properties
	 * files. 
	 * @param targetPropsFile
	 * @param sourceFile
	 * @param propsToCopy
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void mergeProperties(String targetPropsFile, File sourceFile, String... propsToCopy) throws FileNotFoundException, IOException {
		Properties source;
		try {
			source = loadPropertiesFile(sourceFile.getAbsolutePath());
		} catch (Exception e) {
			System.out.println("Unable to load configuration file: "+sourceFile);
			System.out.println("Skipping application of this file");
			return;
		}
		Properties targetProps = loadPropertiesFile(targetPropsFile);
		
		// Copy the properties
		if (propsToCopy.length == 0) {
			// If no properties have been specified, copy them all.
			Enumeration<?> e = source.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String)e.nextElement();
				String value = (String)source.get(key);
				targetProps.setProperty(key, value);
			}
		} else {
			for (int i=0; i < propsToCopy.length; i++) {
				String key = propsToCopy[i];
				String value = (String)source.get(key);
				targetProps.setProperty(key, value);
			}
		}
		
		// Write properties file.
		targetProps.store(new FileOutputStream(targetPropsFile), null);
	}
	
	/**
	 * Converts a new Properties file where the keys are all in lower-case from the supplied Properties file.  
	 * @param originalProps The original Properties file to analayse
	 * @return a new Properties file
	 */
	public static Properties createLowerCaseProperties(Properties originalProperties) {
		Properties lowerCaseKeysProperties = new Properties();
		Set<Object> keySet = originalProperties.keySet();
		for (Object aKey : keySet) {
			lowerCaseKeysProperties.put(aKey.toString().toLowerCase(), originalProperties.get(aKey));
		}
		return lowerCaseKeysProperties;
	}
}