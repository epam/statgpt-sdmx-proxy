package io.sdmx.utils.core.audit;

import java.util.List;

import io.sdmx.api.logging.IFusionLogEvent;

/**
 * A class that represents whether the process that was logged succeeded or not, and also stores a List of logEvents
 */
public class LoggedProcess {
	private boolean success;
	private List<IFusionLogEvent> logEvents;

	public void setSuccess() {
		this.success = true;
	}
	
	public boolean isSuccess() {
		return this.success;
	}
	
	public void setLogEvents(List<IFusionLogEvent> logEvents) {
		this.logEvents = logEvents;
	}
	
	public List<IFusionLogEvent> getLogEvents() {
		return this.logEvents;
	}
}
