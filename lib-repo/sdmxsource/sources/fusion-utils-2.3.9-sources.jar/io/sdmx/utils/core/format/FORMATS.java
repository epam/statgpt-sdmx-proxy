package io.sdmx.utils.core.format;

import io.sdmx.api.format.FormatDetails;

public enum FORMATS {
	JSON("JSON", "json", "application/json");
	
	private FormatDetails format;

	private FORMATS(String asString, String fileExtension, String mimeType) {
		this.format = new FormatDetailsImpl(asString, fileExtension, mimeType, false, "");
	}

	public FormatDetails getFormat() {
		return format;
	}
}
