package io.sdmx.utils.core.object;

/**
 * A class to represent null as an object.
 * The primary purpose of this class is to be used in ConcurrentHashMaps.
 * This class is also equal to null. 
 */
public class NullRepresentation {
	private static final NullRepresentation NULL_REP = new NullRepresentation();
	
	public static NullRepresentation getInstance() {
		return NULL_REP;
	}
	
	@Override
	public String toString() {
		return "NULL_REPRESENTATION";
	}
	
	@Override
	public boolean equals(Object that) {
		if (that == null) {
			return true;
		}
		return (that instanceof NullRepresentation); 
	}
	
	@Override
	public int hashCode() {
	    return NullRepresentation.class.hashCode();
	}
}