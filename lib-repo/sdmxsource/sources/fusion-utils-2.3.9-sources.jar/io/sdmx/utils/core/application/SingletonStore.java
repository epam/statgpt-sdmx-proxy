package io.sdmx.utils.core.application;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.sdmx.api.application.ISingletonContainer;
import io.sdmx.api.exception.SdmxException;

/**
 * Static retrieval of singletons by interface
 */
public class SingletonStore {
	private static ISingletonContainer container;

	@SuppressWarnings("rawtypes")
	private static Map<Class, Object> localInstanceStore = new HashMap<>();
	
	private static Map<Class<?>, List<ISingletonAware<?>>> futureStore = new ConcurrentHashMap<>();
	
	
	public static void clearState() {
		SingletonStore.container = null;
		localInstanceStore = new HashMap<>();
	}
	
	
	public static void setContainer(ISingletonContainer container) {
		SingletonStore.container = container;
		checkFutures();
	}
	
	@SuppressWarnings("rawtypes")
	public static void registerInstance(Object instance) {
		localInstanceStore.put(instance.getClass(), instance);
		registerInterface(instance, instance.getClass().getInterfaces());
		checkFutures();
	}
	
	private static void registerInterface(Object instance, Class<?>[] interfaces) {
	    if(interfaces != null) {
	        for(Class<?> iInterface : interfaces) {
	            localInstanceStore.put(iInterface, instance);
	            registerInterface(instance, iInterface.getInterfaces());
	        }
	    }
	}
	
	/**
	 * If the beans container has changed, re-check the future store to see if any new beans have been
	 * registered which are required by other classes
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void checkFutures() {
		Set<Class> removeKeys = null;
		for(Class key : futureStore.keySet()) {
			Object o = getSingleton(key, false);
			if(o != null) {
				List<ISingletonAware<?>> sis = futureStore.get(key);
				if(sis != null) {
					try {
						for(ISingletonAware si : sis) {
							for(Method m : ISingletonAware.class.getMethods()) {
								if(m.getName().equals("setSingleton")) {
									try {
										m.invoke(si, o);
									} catch (Throwable e) {
										e.printStackTrace();
									}
								}
							}
						}
						if(removeKeys == null) {
							removeKeys = new HashSet<>(10);
						}
						removeKeys.add(key);
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
			}
		}
		if(removeKeys != null) {
			futureStore.keySet().removeAll(removeKeys);
		}
	}
	
	public static <T> void registerInterest(Class<T> type, ISingletonAware<T> future) {
		T singleton = getSingleton(type, false);
		if(singleton != null) {
			future.setSingleton(singleton);
		} else {
			synchronized(futureStore) {
				List<ISingletonAware<?>> futures = futureStore.get(type);
				if(futures == null) {
					futures = new ArrayList<>();
					futureStore.put(type, futures);
				}
				futures.add(future);
			}
		}
	}
	
	public static <T> T getSingleton(Class<T> type) {
		return getSingleton(type, true);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getSingleton(Class<T> type, boolean required) {
		Object o = localInstanceStore.get(type);
		if(o != null) {
			return (T)o;
		}
		if(SingletonStore.container == null) {
			return null;
		}
		
		T singleton = container.getSingleton(type);
		if(singleton == null && required) {
			throw new SdmxException("Missing required instance of type:"+type);
		}
		return singleton;
	}
	
	public static <T> T getSingleton(Class<T> type, String name, boolean required) {
		if(SingletonStore.container == null) {
			return null;
		}
		T singleton = container.getSingleton(type, name);
		if(singleton == null && required) {
			throw new SdmxException("Missing required instance of type:"+type);
		}
		return singleton;
	}
}
