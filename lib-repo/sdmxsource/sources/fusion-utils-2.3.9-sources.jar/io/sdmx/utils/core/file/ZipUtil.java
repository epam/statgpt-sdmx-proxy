package io.sdmx.utils.core.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.utils.core.io.MutlipleReadableDataLocation;
import io.sdmx.utils.core.io.OverflowWriteableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.io.URIUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.random.RandomUtil;
import io.sdmx.utils.core.xlsx.XLSXUtil;

public class ZipUtil {
	// A Zip file always begin with these 4 bytes:
	private static final byte[] ZIP_BEGIN_BYTES = { (byte)0x50, (byte)0x4B, (byte)3, (byte)4};

	public static List<String> getZipFileNames(URI inFile) {
		List<String> returnList = new ArrayList<>();
		try (ZipFile zipFile = new ZipFile(inFile.toString())) {
			Enumeration<? extends ZipEntry> zipEntries = zipFile.entries();
			while (zipEntries.hasMoreElements()) {
				String fileName = ((ZipEntry) zipEntries.nextElement()).getName();
				returnList.add(fileName);
			}
		}catch(IOException e){
			throw new RuntimeException(e);
		}
		return returnList;
	}

	public static List<String> getZipFileNames(InputStream inS) throws IOException{
		List<String> returnList = new ArrayList<>();
		try(ZipInputStream in = new ZipInputStream(inS);){
			ZipEntry entry = null;
			while((entry = in.getNextEntry())!= null) {
				String entryName = entry.getName();
				returnList.add(entryName);
			}
			return returnList;
		}
	}
	/**
	 * Returns the contents of file with the given name from the zip
	 * @param inFile The URI for the Zip file
	 * @return true if the file was extracted
	 */
	public static boolean getFileFromZip(URI inFile, String fileName, OutputStream out) {
		return getFileFromZip(URIUtil.getInputStream(inFile), fileName, out);
	}

	/**
	 * Returns the contents of file with the given name from the zip
	 * @param inFile The URI for the Zip file
	 * @return true if the file was extracted
	 */
	public static boolean getFileFromZip(InputStream is, String fileName, OutputStream out) {
		ZipInputStream in=null;
		try {
			in = new ZipInputStream(is);
			// Get the first entry
			ZipEntry entry=null;
			while((entry = in.getNextEntry())!= null) {
				String entryName = entry.getName();
				if(entryName.equals(fileName)) {
					// Transfer bytes from the ZIP file to the output file
					byte[] buf = new byte[1024];
					int len;
					while ((len = in.read(buf)) > 0) {
						out.write(buf, 0, len);
					}
					return true;
				}
			}
			return false;
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			StreamUtil.closeStream(in);
			StreamUtil.closeStream(is);
			StreamUtil.closeStream(out);
		}
	}


	public static Map<String, ByteArrayOutputStream> upzipFiles(URI zipFileLoction) {
		Map<String, ByteArrayOutputStream> inputStreamMap = new HashMap<>();
		ZipInputStream in=null;
		try {
			in = new ZipInputStream(URIUtil.getInputStream(zipFileLoction));
			// Get the first entry
			ZipEntry entry=null;
			while((entry = in.getNextEntry())!= null) {
				String entryName = entry.getName();

				ByteArrayOutputStream out = new ByteArrayOutputStream();
				// Transfer bytes from the ZIP file to the output file
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Close the streams
				out.close();
				inputStreamMap.put(entryName, out);
				out = null;
			}
			return inputStreamMap;
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			StreamUtil.closeStream(in);
		}
	}


	/**
	 * Unzips the file given in the zip location, into the directory given by the unpackDirectory
	 * @param zipFileLoction
	 * @param unpackDirectory
	 */
	public static void upzipFiles(URI zipFileLoction, File unpackDirectory) {
		if(unpackDirectory.isFile()) {
			throw new IllegalArgumentException(unpackDirectory + " is not a directory");
		}
		if(!unpackDirectory.exists()) {
			unpackDirectory.mkdirs();
		}
		ZipInputStream in = null;
		BufferedOutputStream out = null;
		try {
			in = new ZipInputStream(URIUtil.getInputStream(zipFileLoction));
			// Get the first entry
			ZipEntry entry=null;
			while((entry = in.getNextEntry())!= null) {
				String entryName = entry.getName();
				File f = new File(unpackDirectory + "/" + entryName);
				f.createNewFile();

				OutputStream fOut = new FileOutputStream(f);
				out = new BufferedOutputStream(fOut);
				// Transfer bytes from the ZIP file to the output file
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			StreamUtil.closeStream(in);
			StreamUtil.closeStream(out);
		}
	}


	/**
	 * Determines whether the supplied byte array is a Zip file.
	 * @param data The byte array to analyse
	 * @return Whether the byte array represents a Zip file.
	 */
	public static boolean isAZip(byte[] data) {
		if (data == null || data.length < ZIP_BEGIN_BYTES.length) {
			return false;
		}
		for (int i=0; i < ZIP_BEGIN_BYTES.length; i++ ) {
			if (data[i] != ZIP_BEGIN_BYTES[i]) {
				return false;
			}
		}
		return true;
	}


	/**
	 * Determines whether the supplied URI represents a Zip file.
	 * @param data The URI to analyse
	 * @return Whether the URI represents a Zip file.
	 */
	public static boolean isAZip(ReadableDataLocation dataLocation) {
		if(dataLocation == null) {
			return false;
		}
	    if (dataLocation instanceof MutlipleReadableDataLocation) {
	        return true;
	    }
		InputStream in = dataLocation.getInputStream();
		BufferedInputStream bis = new BufferedInputStream(in);
		byte[] byteArray = new byte[4];
		try {
			bis.read(byteArray, 0, 4);
		} catch (IOException e) {
			// If couldn't read the first 4 bytes, then this isn't a Zip file
			return false;
		} finally {
			StreamUtil.closeStream(in);
		}
		//Only return true if this is of ZIP format and NOT a XLSX file
		boolean isZip = isAZip(byteArray);
		boolean isExcel = XLSXUtil.isXlsx(dataLocation);
		return isZip && isExcel == false;
	}



	/**
	 * Zips the specified entries in the map and creates a Zip file as the specified output filename.
	 * @param data a Map of the data, where the keys specify the names within the outputted Zip file.
	 * @param outFile The URI of the Zip file.
	 */
	public static void zipFiles(Map<String, URI> topZip, URI outFile) {
		// A specific URI can only be updated by one thing at a time.
		synchronized(outFile) {
			// Create a buffer for reading the files
			byte[] buf = new byte[1024];
			try {
				ZipOutputStream out = new ZipOutputStream(URIUtil.getOutputStream(outFile));
				for(String currentInputFileName : topZip.keySet()){
					URI zipURI = topZip.get(currentInputFileName);
					if(zipURI!= null) {
						buf = new byte[1024];

						InputStream in = URIUtil.getInputStream(zipURI);

						// Add ZIP entry to output stream.
						out.putNextEntry(new ZipEntry(currentInputFileName));

						// Transfer bytes from the file to the ZIP file
						int len;
						while ((len = in.read(buf)) > 0) {
							out.write(buf, 0, len);
						}
						// Complete the entry
						out.closeEntry();
						in.close();
					}
				}
				// Complete the ZIP file
				out.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}


	public static void zipFile(ReadableDataLocation inFile, WriteableDataLocation outFile) {
		zipFile(inFile.getInputStream(), inFile.getName(), outFile);
	}


	public static void zipFile(WriteableDataLocation outFile, ReadableDataLocation... inFiles) {
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		try {
			ZipOutputStream out = new ZipOutputStream(outFile.getOutputStream());

			for (ReadableDataLocation rdl : inFiles) {
				String zipEntryName = rdl.getName();
				if(!ObjectUtil.validString(zipEntryName)) {
					zipEntryName = RandomUtil.generateRandomString();
				}

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(zipEntryName));

				InputStream in = rdl.getInputStream();

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				// Complete the entry
				out.closeEntry();
				in.close();
			}

			// Complete the ZIP file
			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void zipFile(InputStream in, String zipEntryName, WriteableDataLocation outFile) {
		zipFile(in, zipEntryName, outFile.getOutputStream());
	}

	public static void zipFile(InputStream in, String zipEntryName, OutputStream outFile) {
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		try {
			ZipOutputStream out = new ZipOutputStream(outFile);

			if(!ObjectUtil.validString(zipEntryName)) {
				zipEntryName = RandomUtil.generateRandomString();
			}
			// Add ZIP entry to output stream.
			out.putNextEntry(new ZipEntry(zipEntryName));

			// Transfer bytes from the file to the ZIP file
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			// Complete the entry
			out.closeEntry();
			in.close();
			// Complete the ZIP file
			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void addFilesToExistingZip(File zipFile, File f) throws IOException {
		addFilesToExistingZip(zipFile, f.getName(), new FileInputStream(f));
	}

	
	public static void addFilesToExistingZip(File zipFile, String toAddName, InputStream toAdd) throws IOException {
		// get a temp file
		File tempFile = File.createTempFile(zipFile.getName(), null);
		// delete it, otherwise you cannot rename your existing zip to it.
		tempFile.delete();

		boolean renameOk=zipFile.renameTo(tempFile);
		if (!renameOk)
		{
			throw new RuntimeException("could not rename the file "+zipFile.getAbsolutePath()+" to "+tempFile.getAbsolutePath());
		}
		byte[] buf = new byte[1024];

		ZipInputStream zin = new ZipInputStream(new FileInputStream(tempFile));
		ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFile));

		ZipEntry entry = zin.getNextEntry();
		while (entry != null) {
			String name = entry.getName();
			boolean notInFiles = true;
			if (toAddName.equals(name)) {
				notInFiles = false;
				break;
			}
			if (notInFiles) {
				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(name));
				// Transfer bytes from the ZIP file to the output file
				int len;
				while ((len = zin.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
			}
			entry = zin.getNextEntry();
		}
		// Close the streams
		zin.close();
		// Compress the files
		// Add ZIP entry to output stream.
		out.putNextEntry(new ZipEntry(toAddName));
		// Transfer bytes from the file to the ZIP file
		int len;
		while ((len = toAdd.read(buf)) > 0) {
			out.write(buf, 0, len);
		}
		// Complete the entry
		out.closeEntry();
		toAdd.close();
		// Complete the ZIP file
		out.close();
		tempFile.delete();
	}

	/**
	 * Unzips the specified Zip file into a List of ReadableDataLocations.
	 * @param dataLocation The zip file itself
	 * @return a List of ReadableDataLocations which are the contents of the Zip file
	 */
	public static List<ReadableDataLocation> unzipFiles(ReadableDataLocation dataLocation) {
	    if (dataLocation instanceof MutlipleReadableDataLocation) {
	        return ((MutlipleReadableDataLocation)dataLocation).getItems();
	    }
		int fileCount = ZipUtil.getCountOfFiles(dataLocation);
		if (fileCount < 1) {
			throw new IllegalArgumentException("Can not unzip file - either supplied file is not a zip file, or file is corrupt");
		}
		List<ReadableDataLocation> returnLocations = new ArrayList<>();
		ZipInputStream in = new ZipInputStream(dataLocation.getInputStream());
		// Get the first entry
		ZipEntry zipEntry = null;
		OutputStream out = null;
		try {
			while((zipEntry = in.getNextEntry()) != null) {
			    if(zipEntry.getName().equals(".DS_Store")) {
			        continue;
			    }
				WriteableDataLocation dataLocationOut = new OverflowWriteableDataLocation(zipEntry.getName());
				out = dataLocationOut.getOutputStream();
				// Transfer bytes from the ZIP file to the output file
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Close the stream
				out.close();

				returnLocations.add(dataLocationOut);
			}

			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
		    StreamUtil.closeStream(out);
		}
		return returnLocations;
	}


	/**
	 * Returns the first entry from the specified URI.
	 * @param inFile The URI for the Zip file
	 * @return a URI for the first entry within the Zip file.
	 * @throws IllegalArgumentException if file is not a zip, or if it contains more then one file
	 */
	public static ReadableDataLocation unzipFile(ReadableDataLocation dataLocation) {
		int fileCount = ZipUtil.getCountOfFiles(dataLocation);
		if (fileCount < 1) {
			throw new IllegalArgumentException("Can not unzip file - either supplied file is not a zip file, or file is corrupt");
		}

		if (fileCount > 1) {
			throw new IllegalArgumentException("Can not unzip file, expecting only one file in zip contents, got " + fileCount);
		}
		WriteableDataLocation dataLocationOut = new OverflowWriteableDataLocation();
		unzipFile(dataLocation,  dataLocationOut.getOutputStream());
		return dataLocationOut;
	}

	/**
	 * Returns the first entry from the specified URI.
	 * @param inFile The URI for the Zip file
	 * @param out an OutputStream for the first entry within the Zip file
	 */
	public static void unzipFile(ReadableDataLocation dataLocation, OutputStream out) {
		try {
			ZipInputStream in = new ZipInputStream(dataLocation.getInputStream());
			// Get the first entry
			in.getNextEntry();

			// Transfer bytes from the ZIP file to the output file
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			// Close the streams
			out.close();
			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	/**
	 * Returns the first entry from the specified URI.
	 * @param inFile The URI for the Zip file
	 * @param out an OutputStream for the first entry within the Zip file
	 */
	public static void unzipFiles(ReadableDataLocation dataLocation, OutputStream out) {
		try {
			ZipInputStream in = new ZipInputStream(dataLocation.getInputStream());
			// Get the first entry
			in.getNextEntry();

			// Transfer bytes from the ZIP file to the output file
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			// Close the streams
			out.close();
			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static List<String> getZipFileNames(ReadableDataLocation rdl) {
		List<String> returnList = new ArrayList<>();
		ZipInputStream in=null;
		try {
			in = new ZipInputStream(rdl.getInputStream());
			ZipEntry entry=null;
			while((entry = in.getNextEntry())!= null) {
				String entryName = entry.getName();
				returnList.add(entryName);
			}
			return returnList;
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			StreamUtil.closeStream(in);
		}
	}


	/**
	 * Unzips the specified file into the specified directory.
	 * @param zipFile The file to unzip.
	 * @param unzipDir The directory to unzip the zip into.
	 */
	public static void unzipFileIntoDirectory(ZipFile zipFile, File unzipDir) {
		Enumeration<?> files = zipFile.entries();
		FileOutputStream fos = null;

		while (files.hasMoreElements()) {
			try {
				ZipEntry entry = (ZipEntry) files.nextElement();
				InputStream eis = zipFile.getInputStream(entry);
				byte[] buffer = new byte[1024];
				int bytesRead = 0;

				File f = new File(unzipDir.getAbsolutePath() + File.separator + entry.getName());

				if (entry.isDirectory()) {
					f.mkdirs();
					continue;
				}

				f.getParentFile().mkdirs();
				f.createNewFile();

				fos = new FileOutputStream(f);

				while ((bytesRead = eis.read(buffer)) != -1) {
					fos.write(buffer, 0, bytesRead);
				}
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			} finally {
				if (fos != null) {
					try {
						fos.close();
					} catch (IOException e) {
					}
				}
			}
		}

		try {
			zipFile.close();
		} catch (IOException e) {
			// If unable to close, what now....
			e.printStackTrace();
		}
	}

	/**
	 * Returns a count of the number of files within the specified Zip file.
	 * @param inFile The URI of the Zip file.
	 * @return The number of files within the Zip file.
	 */
	public static int getCountOfFiles(ReadableDataLocation rdl) {
		int count = 0;
		try ( ZipInputStream in = new ZipInputStream(rdl.getInputStream()) ) {
			while (in.getNextEntry() != null) {
				count++;
			}
		} catch (IOException e) {
			// If couldn't read the Zip file, return a negative value.
			return -1;
		}
		return count;
	}
}
