package io.sdmx.utils.core.memory;

public class MemoryUtil {

	
	public static float getMemoryRemaining() {
		Runtime runtime = Runtime.getRuntime();
		long maxMemory = runtime.maxMemory();  
		long allocatedMemory = runtime.totalMemory();  
		long freeMemory = runtime.freeMemory();  
		return freeMemory + (maxMemory - allocatedMemory);
	}
	
	public static float getMemoryRemainingAsPercentage() {
		Runtime runtime = Runtime.getRuntime();
		long maxMemory = runtime.maxMemory();  
		long allocatedMemory = runtime.totalMemory();  
		long freeMemory = runtime.freeMemory();  
		return (100f / (float)maxMemory) * (freeMemory + (maxMemory - allocatedMemory));
	}
}
