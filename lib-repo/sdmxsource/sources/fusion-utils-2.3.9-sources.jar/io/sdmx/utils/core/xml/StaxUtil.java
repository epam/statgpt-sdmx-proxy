package io.sdmx.utils.core.xml;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class StaxUtil {
	private static final String XML_NS = "http://www.w3.org/XML/1998/namespace";
	
	public static XMLStreamReader getXMLStreamReader(InputStream stream) {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
		factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
		try {
			return factory.createXMLStreamReader(stream, "UTF-8");
		}  catch(XMLStreamException e) {
			StreamUtil.closeStream(stream);
			throw new StaxException(e);
		}
	}

	/**
	 * Copies the current node, namespaces and all attributes.  Does not copy text if deepCopy is false.
	 * @param parser
	 * @param writer
	 * @param deepCopy - copies all the children of the current node, copies all text
	 * @param includeCurrentNode - if false will skip the current node and copy all children (only relevent if a deep copy - if false on a shallow copy, nothing will be copied)
	 * @throws XMLStreamException - if the parser is not at position XMLStreamConstants.START_ELEMENT
	 */
	public static void copyNode(XMLStreamReader parser, boolean deepCopy, boolean includeCurrentNode, boolean includeNamespaces, XMLStreamWriter... writers) throws XMLStreamException {
		if(writers == null || writers.length == 0) {
			throw new IllegalArgumentException("StxUtil.copyNode expects at least one XMLStreamWriter to copy to");
		}
		if(includeCurrentNode) {
			if(ObjectUtil.validString(parser.getNamespaceURI())) {
				for(XMLStreamWriter writer : writers) {
					writer.writeStartElement(parser.getNamespaceURI(), parser.getLocalName());
				}
			} else {
				for(XMLStreamWriter writer : writers) {
					writer.writeStartElement(parser.getLocalName());
				}
			}
			if(includeNamespaces) {
				for(int i = 0; i < parser.getNamespaceCount(); i++) {
					String nsPrefix = parser.getNamespacePrefix(i);
					String nsUri = parser.getNamespaceURI(i);
					for(XMLStreamWriter writer : writers) {
						writer.writeNamespace(nsPrefix, nsUri);
					}
				}
			}
			for(int i = 0; i < parser.getAttributeCount(); i++) {
				String attNs = parser.getAttributeNamespace(i);
				String attName = parser.getAttributeLocalName(i);
				String attVal = parser.getAttributeValue(i);
				if (ObjectUtil.validString(attNs)) {
					if(attNs.equals("http://www.w3.org/XML/1998/namespace")) {
						for(XMLStreamWriter writer : writers) {
							writer.writeAttribute("xml", attNs, attName, attVal);
						}
					} else {
						for(XMLStreamWriter writer : writers) {
							writer.writeAttribute(attNs, attName, attVal);
						}
					}
				} else {
					for(XMLStreamWriter writer : writers) {
						writer.writeAttribute(attName, attVal);
					}
				}
			}
		}
		if(deepCopy) {
			while(parser.hasNext()) {
				int event = parser.next();
				if(event == XMLStreamConstants.CHARACTERS) {
					for(XMLStreamWriter writer : writers) {
						writer.writeCharacters(parser.getText());
					}
				}
				else if(event == XMLStreamConstants.START_ELEMENT) {
					copyNode(parser, true, true, includeNamespaces, writers);
				}
				else if (event == XMLStreamConstants.END_ELEMENT) {
					for(XMLStreamWriter writer : writers) {
						writer.writeEndElement();
					}
					return;
				}
			}
		}
	}

	/**
	 * Moves the parser position forward to the point after this node and all children of this node
	 * @param parser
	 * @throws XMLStreamException
	 * @deprecated use StaxReader
	 */
	@Deprecated
	public static void skipNode(XMLStreamReader parser) throws XMLStreamException {
		while(parser.hasNext()) {
			int event = parser.next();
			if(event == XMLStreamConstants.START_ELEMENT) {
				skipNode(parser);
			}
			else if (event == XMLStreamConstants.END_ELEMENT) {
				return;
			}
		}
	}

	/**
	 * Moves the parser position forward to the next instance of the node with the given name
	 * @param parser
	 * @throws XMLStreamException
	 * @deprecated use StaxReader
	 */
	@Deprecated
	public static boolean skipToNode(XMLStreamReader parser, String nodeName) throws XMLStreamException {
		while(parser.hasNext()) {
			int event = parser.next();
			if(event == XMLStreamConstants.START_ELEMENT) {
				if(parser.getLocalName().equals(nodeName)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * @deprecated use StaxReader
	 * @param parser
	 * @param findNodeName
	 * @param doNotProcessPastNodeName
	 * @return
	 * @throws XMLStreamException
	 */
	@Deprecated
	public static boolean jumpToNode(XMLStreamReader parser, String findNodeName, String doNotProcessPastNodeName) throws XMLStreamException {
		String nodeName;
		while (parser.hasNext()) {
			int event = parser.next();
			if (event == XMLStreamConstants.START_ELEMENT) {
				nodeName = parser.getLocalName();
				if(nodeName.equals(findNodeName)) {
					return true;
				}
			}
			if (event == XMLStreamConstants.END_ELEMENT) {
				nodeName = parser.getLocalName();
				if(doNotProcessPastNodeName != null) {
					if(nodeName.equals(doNotProcessPastNodeName)) {
						return false;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Moves the parser position forward to the next instance of the end node given name
	 * @param parser
	 * @throws XMLStreamException
	 * @deprecated use StaxReader
	 */
	@Deprecated
	public static boolean skipToEndNode(XMLStreamReader parser, String nodeName) throws XMLStreamException {
		while(parser.hasNext()) {
			int event = parser.next();
			if(event == XMLStreamConstants.END_ELEMENT) {
				if(parser.getLocalName().equals(nodeName)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Returns the current node, all attributes and children as a string
	 * @param parser
	 * @return
	 * @throws XMLStreamException
	 */
	public static String parseString(XMLStreamReader parser) throws XMLStreamException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();
		XMLStreamWriter writer = xmlOutputfactory.createXMLStreamWriter(out);
		writer.writeStartDocument();
		boolean started = false;
		int event = XMLStreamConstants.START_ELEMENT;
		String endElement = parser.getLocalName();
		int level = 0 ;
		while (true) {
			switch(event)
			{
			case XMLStreamConstants.START_ELEMENT:
				if(parser.getLocalName().equals(endElement)) {
					level++;
				}
				writer.writeStartElement(parser.getNamespaceURI(), parser.getLocalName());
				if(!started) {
					writer.writeNamespace("xml", XML_NS);
					started = true;
				}
				for(int i = 0; i < parser.getAttributeCount(); i++) {
					if(parser.getAttributeNamespace(i) == null) {
						writer.writeAttribute(parser.getAttributeLocalName(i), parser.getAttributeValue(i));
					} else {
						writer.writeAttribute(parser.getAttributeNamespace(i), parser.getAttributeLocalName(i), parser.getAttributeValue(i));
					}
				}
				break;

			case XMLStreamConstants.CHARACTERS:
				writer.writeCharacters(parser.getText());
				break;

			case XMLStreamConstants.END_ELEMENT:
				writer.writeEndElement();
				if(parser.getLocalName().equals(endElement)) {
					if(level == 1) {
						writer.flush();
						writer.close();
						return out.toString();
					}
					level--;
				}
				break;
			}
			event = parser.next();
		}
	}

	/**
	 * Checks if the XML in the first input stream is the same as the XML in the second input stream, throws an exception if they differ
	 * @param xmlOne an inputStream
	 * @param xmlTwo an inputStream
	 * @param ignoreAttrValue if specified any attributes with this value will not be tested against the other stream
	 * @param ignoreNodes an optional list of nodes which shouldn't be compared.
	 * @throws Exception
	 */
	public static void isSameXML(InputStream xmlOne, InputStream xmlTwo, String ignoreAttrValue, String...ignoreNodes) throws Exception {
		Set<String> ignoreAttrValues = new HashSet<>();
		ignoreAttrValues.add(ignoreAttrValue);

		isSameXML(xmlOne, xmlTwo, null, ignoreAttrValues, ignoreNodes);
	}

//	private static void displayStream(ByteArrayInputStream in) {
//		int n = in.available();
//		byte[] bytes = new byte[n];
//		in.read(bytes, 0, n);
//		String s = new String(bytes, StandardCharsets.UTF_8);
//		System.out.println(s);
//	}

	public static void isSameXML(InputStream xmlOne, InputStream xmlTwo, Set<String> ignoreAttrIds, Set<String> ignoreAttrValues, String...ignoreNodes) throws Exception {
//		displayStream((ByteArrayInputStream) xmlOne);
//		displayStream((ByteArrayInputStream) xmlTwo);
		XMLInputFactory factory = XMLInputFactory.newInstance();
		// disable external entities
		factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
		factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
		ByteArrayInputStream xml2 = new ByteArrayInputStream(StreamUtil.toByteArray(xmlTwo));
		XMLStreamReader parser1 =factory.createXMLStreamReader(xmlOne, "UTF-8");
		XMLStreamReader parser2 = factory.createXMLStreamReader(xml2, "UTF-8");
		String nodeA = null;
		String nodeB = null;

		int element = 0;
		int a = -1;
		int b = -1;

		outer:
			while(parser1.hasNext()) {
				a = parser1.next();
				b = parser2.next();
				while(a == XMLStreamConstants.SPACE) {
					a = parser1.next();
				}
				while(b == XMLStreamConstants.SPACE) {
					b = parser2.next();
				}
				if(parser1.isCharacters()) {
					if(ObjectUtil.validString(parser1.getText())) {
						if(!parser2.isCharacters()) {
							throw new IllegalArgumentException("Text Differs on Node:" + nodeA);
						}
						if(!parser1.getText().equals(parser2.getText())) {
							if(!parser1.getText().equals("$IGNORE") && !parser2.getText().equals("$IGNORE")) {
								throw new IllegalArgumentException("Text Differs on Node:" + nodeA + "\nExpected:" + parser1.getText()+ "\nActual:" + parser2.getText());
							}
						}
					} else {
						a = parser1.next();
						if (parser2.isCharacters() && !ObjectUtil.validString(parser2.getText())) {
							b = parser2.next();
						}
					}
				} else if (parser2.isCharacters()) {

					if(ObjectUtil.validString(parser2.getText())) {
						throw new IllegalArgumentException("Text Differs on Node:" + nodeA + " : " +  parser2.getText());
					}
					b = parser2.next();
				}

				if (a == XMLStreamConstants.END_ELEMENT) {
					if(b != a) {
						nodeA = parser1.getLocalName();
						throw new IllegalArgumentException("Input A is ending XML element: " + nodeA + " whilst input B is not");
					}
				} else if (a == XMLStreamConstants.START_ELEMENT) {
					element++;
					nodeA = parser1.getLocalName();
					if(b != XMLStreamConstants.START_ELEMENT) {
						while(parser2.hasNext()) {
							b = parser2.next();
							if (b == XMLStreamConstants.START_ELEMENT) {
								nodeB = parser2.getLocalName();
								break;
							}
						}
					}
					if(b != XMLStreamConstants.START_ELEMENT) {
						throw new IllegalArgumentException("Parser B end of document, Parser A on node: " + nodeA);
					}
					nodeB = parser2.getLocalName();


					if(!nodeA.equals(nodeB)) {
						throw new IllegalArgumentException("XML NODES DIFFER: " + nodeA + "," + nodeB);
					}
					for(String ignoreNode : ignoreNodes) {
						if(nodeA.equals(ignoreNode)) {
							StaxUtil.skipNode(parser1);
							StaxUtil.skipNode(parser2);
							continue outer;
						}
					}



					if(parser1.getNamespaceCount() != parser2.getNamespaceCount()) {
						StringBuilder sb = new StringBuilder();
						sb.append("Namespace count for parser 1 : "  + parser1.getNamespaceCount()+"\n");
						for(int i = 0 ; i < parser1.getNamespaceCount(); i++) {
							sb.append("Parser 1 Namespace #"+(i+1)+":  " + parser1.getNamespaceURI(i)+"\n");
						}
						sb.append("Namespace count for parser 2 : "  + parser2.getNamespaceCount()+"\n");
						for(int i = 0 ; i < parser2.getNamespaceCount(); i++) {
							sb.append("Parser 2 Namespace #"+(i+1)+":  " + parser2.getNamespaceURI(i)+"\n");
						}
						throw new IllegalArgumentException("Namespace count differs on node:" + nodeA+"\n"+sb.toString());
					}

					for(int i = 0 ; i < parser1.getNamespaceCount(); i++) {
						boolean found = false;
						String nameSpaceURI = parser1.getNamespaceURI(i);
						for(int j = 0 ; j < parser2.getNamespaceCount(); j++) {
							if(parser2.getNamespaceURI(j).equals(nameSpaceURI)) {
								found = true;
								break;
							}
						}
						if(!found) {
							throw new IllegalArgumentException("Namespace not found " + nameSpaceURI);
						}
					}
					int ac1 =0;
					int ac2 = 0;
					for(int i = 0 ; i < parser1.getAttributeCount(); i++) {
						String attributeLocalName = parser1.getAttributeLocalName(i);
						if(ignoreAttrIds != null && ignoreAttrIds.contains(attributeLocalName)) {
							continue;
						}
						ac1++;
					}
					for(int i = 0 ; i < parser2.getAttributeCount(); i++) {
						String attributeLocalName = parser2.getAttributeLocalName(i);
						if(ignoreAttrIds != null && ignoreAttrIds.contains(attributeLocalName)) {
							continue;
						}
						ac2++;
					}
					if(ac1 != ac2) {
					    Set<String> attr1 = new HashSet<>();
					    for(int i = 0 ; i < parser1.getAttributeCount(); i++) {
					        attr1.add(parser1.getAttributeLocalName(i));
					    }
					    Set<String> attr2 = new HashSet<>();
                        for(int i = 0 ; i < parser2.getAttributeCount(); i++) {
                            String name = parser2.getAttributeLocalName(i);
                            if(attr1.contains(name)) {
                                attr1.remove(name);
                            } else {
                                attr2.add(name);
                            }
                        }
                        StringBuilder sb = new StringBuilder();
                        
                        sb.append("Element '"+nodeA+"' differs in attributes. ");
                        if(!attr1.isEmpty()) {
                            sb.append(" Input A additional attributes = '" + CollectionUtil.collectionToString(attr1, ",", "")+"'");
                        }
                        if(!attr2.isEmpty()) {
                            sb.append(" Input B additional attributes = '" + CollectionUtil.collectionToString(attr2, ",", "")+"'");
                        }
						throw new IllegalArgumentException(sb.toString());
					}

					for(int i = 0 ; i < parser1.getAttributeCount(); i++) {
						boolean found = false;
						String attributeLocalName = parser1.getAttributeLocalName(i);
						String attributeNameSpace = parser1.getAttributeNamespace(i);
						String attributeValue = parser1.getAttributeValue(i);
						if(attributeValue.equals("$IGNORE")) {
							continue;
						}
						int j;
						for(j =0; j < parser2.getAttributeCount(); j++) {
							if(parser2.getAttributeLocalName(j).equals(attributeLocalName)) {
								if(attributeNameSpace == null && parser2.getAttributeNamespace(j) == null) {
									//THIS IS OKAY
								} else {
									if(attributeNameSpace == null && parser2.getAttributeNamespace(j) != null) {
										throw new IllegalArgumentException("ATTRIBUTE NAMESPACE DIFFERS " + parser2.getAttributeNamespace(i) + "," + attributeNameSpace);
									}
									if(attributeNameSpace != null && parser2.getAttributeNamespace(j) == null) {
										throw new IllegalArgumentException("ATTRIBUTE NAMESPACE DIFFERS " + parser2.getAttributeNamespace(i) + "," + attributeNameSpace);
									}
									if(!parser2.getAttributeNamespace(j).equals(attributeNameSpace)) {
										throw new IllegalArgumentException("ATTRIBUTE NAMESPACE DIFFERS " + parser2.getAttributeNamespace(i) + "," + attributeNameSpace);
									}
								}


								found = true;
								break;
							}

						}
						if(!found) {
							throw new IllegalArgumentException("ATTRIBUTE NOT FOUND ON NODE '"+nodeA+"' : " + attributeLocalName);
						}

						// Ensure the attribute ID to be tested is not in the set of "ignore Attr IDs"
						if (ignoreAttrIds != null && ignoreAttrIds.contains(attributeLocalName)) {
							continue;
						}

						// Ensure the attribute value to be tested is not in the set of "ignore Attr VALUES"
						if (ignoreAttrValues != null && ignoreAttrValues.contains(attributeValue)) {
							continue;
						}
						
						if(!parser2.getAttributeValue(j).equals(attributeValue)) {
							if(parser2.getAttributeValue(j).equals("$IGNORE")) {
								continue;
							}
							String line_separator = System.getProperty("line.separator");
							throw new IllegalArgumentException("ATTRIBUTE VALUE DIFFERS on: " + attributeLocalName + " - Node: " + element + line_separator
									+ attributeValue + line_separator
									+ parser2.getAttributeValue(j));
						}
					}
				}
			}
	}

}