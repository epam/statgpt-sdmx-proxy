package io.sdmx.utils.core.date;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.PeriodContainer;
import io.sdmx.api.date.PeriodContents;
import io.sdmx.api.date.PeriodsContainer;
import io.sdmx.api.date.SdmxPeriod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PeriodsContainerImpl<T> implements PeriodsContainer<T> {
	private static final Logger LOG = LoggerFactory.getLogger(PeriodsContainerImpl.class);
	
	private Map<SdmxPeriod, PeriodContainer<T>> periodContainer = new HashMap<>();
	
	//Contain a record of how input periods have been split into smaller periods
//	private Map<SdmxPeriod, Set<SdmxPeriod>> splitPeriods = new HashMap<>();
	
	/**
	 * @return a new container which stores a map of string to a set of strings
	 */
	public static <K, V> PeriodsContainer<Map<K, Set<V>>> getMapContainer(boolean unionOnly) {
		PeriodMapContainer<K, V> contents = new PeriodMapContainer<>(unionOnly);
		return new PeriodsContainerImpl<>(contents);
	}
	
	
	/**
	 * Constructor making the default contents available for all periods
	 * @param contents
	 */
	public PeriodsContainerImpl(PeriodContents<T> contents) {
		PeriodContainer<T> pc = new PeriodContainerImpl<>(SdmxPeriodImpl.ALL_PERIODS, contents);
		periodContainer.put(pc.getSdmxPeriod(), pc);
	}

	@Override
	public void addContents(T contents, SdmxPeriod period) {
		if(LOG.isTraceEnabled()) {
			LOG.trace("addContents: "+period);
		}
		//1st check: EXACT - The exact same period already exists, Add the contents into that period
		PeriodContainer<T> container = periodContainer.get(period);
		if(container != null) {
			if(LOG.isTraceEnabled()) {
				LOG.trace("Merge: "+period);
			}
			container.getPeriodContents().merge(contents);
			return;
		}
//		//2nd check: ALREADY SPLIT - The exact same period was already split into smaller periods, Add the contents into that smaller periods
//		if(splitPeriods.containsKey(period)) {
//			for(SdmxPeriod splitPeriod : splitPeriods.get(period)) {
//				container = periodContainer.get(splitPeriod);
//				if(container != null) {
//					LOG.debug("Merge: "+container);
//					container.getPeriodContents().merge(contents);
//				}
//			}
//			return;
//		}
		//3rd check overlaps
		PeriodContainer<T> pc;
		Set<SdmxPeriod> periods = new HashSet<>(periodContainer.keySet());
		for(SdmxPeriod existingPeriod : periods) {
			if(LOG.isTraceEnabled()) {
				LOG.trace("existingPeriod: "+existingPeriod);
				LOG.trace("existingPeriod: "+existingPeriod.getOverlap(period));
			}
			switch(existingPeriod.getOverlap(period)) {
			case EXACT_MATCH:
				//This has already been tested BUT can occur if the two periods have different frequencies
				LOG.debug("Merge: "+existingPeriod);
				periodContainer.get(existingPeriod).getPeriodContents().merge(contents);
				break;
			case NOT_IN_PERIOD:
				//Ignore Period
				break;
			case OVERLAP:
				//It spans only part of this period, we need to split it
				//i.e existing = 2010-2015 and new= 2008-2012
				//We need to split the new period into 2008-2010, and 2010-2012, and 2012-2015
				//For 2008-2010 we need to re-call the method add contents, for 2010-2012 we need to add the contents, and for 2012-2015 we need to leave as is
				pc = periodContainer.get(existingPeriod);
				if(pc == null) {
					continue;
				}
				periodContainer.remove(existingPeriod);
				if(LOG.isTraceEnabled()) {
					LOG.trace("Remove: "+existingPeriod);
				}
				for(SdmxPeriod splitPeriod : existingPeriod.split(period)) {
					PeriodContainer<T> pcCopy;
					if(periodContainer.containsKey(splitPeriod)) {
						pcCopy = periodContainer.get(splitPeriod);
					} else if(pc.getSdmxPeriod().isInPeriod(splitPeriod)){
						pcCopy = pc.copy(splitPeriod);
					} else {
						addContents(contents, splitPeriod);
						continue;
					}
					if(LOG.isTraceEnabled()) {
						LOG.trace("Put: "+splitPeriod);
					}
					periodContainer.put(splitPeriod, pcCopy);
					if(period.isInPeriod(splitPeriod)) {
						if(LOG.isTraceEnabled()) {
							LOG.trace("Merge: "+splitPeriod);
						}
						pcCopy.getPeriodContents().merge(contents);
					}
				}
				break;
			case SUBSET:
				//Existing Period is fully contained in the one passed in
				//i.e existing= 2010-2011 and new= 2010-2015
				//We need to split the new period into 2010-2011, and 2012-2015 and then re-call add contents for each split
				pc = periodContainer.get(existingPeriod);
				if(pc == null) {
					continue;
				}
				if(LOG.isTraceEnabled()) {
					LOG.trace("Merge: "+existingPeriod);
				}
				pc.getPeriodContents().merge(contents);
				break;
			case SUPERSET:
				//Existing Period spans more then the new period 
				//i.e existing= 2010-2015 and new= 2010-2011
				//We need to split the existing period into 2010-2011, and 2012-2015 and then add the new contents into the first split
				pc = periodContainer.get(existingPeriod);
				if(pc == null) {
					continue;
				}
				periodContainer.remove(existingPeriod);
				if(LOG.isTraceEnabled()) {
					LOG.trace("Remove: "+existingPeriod);
				}
				for(SdmxPeriod splitPeriod : existingPeriod.split(period)) {
					PeriodContainer<T> pcCopy = pc.copy(splitPeriod);
					if(LOG.isTraceEnabled()) {
						LOG.trace("Put: "+splitPeriod);
					}
					periodContainer.put(splitPeriod, pcCopy);
					if(period.isInPeriod(splitPeriod)) {
						if(LOG.isTraceEnabled()) {
							LOG.trace("Merge: "+splitPeriod);
						}
						pcCopy.getPeriodContents().merge(contents);
					} 
				}
				break;
			default:
				break;
			}
		}
	}

	@Override
	public Set<SdmxPeriod> getPeriods() {
		return periodContainer.keySet();
	}

	@Override
	public T getContents(SdmxPeriod period) {
		PeriodContainer<T> container = periodContainer.get(period);
		if(container == null) {
			return null;
		}
		return container.getContents();
	}

	@Override
	public Map<SdmxPeriod, T> getContents() {
		Map<SdmxPeriod, T> returnMap = new HashMap<>();
		for(PeriodContainer<T> container : periodContainer.values()) {
			returnMap.put(container.getSdmxPeriod(), container.getContents());
		}
		return returnMap;
	}
}
