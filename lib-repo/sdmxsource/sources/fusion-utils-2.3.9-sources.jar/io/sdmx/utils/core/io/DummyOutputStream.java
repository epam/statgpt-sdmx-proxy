package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 * An output stream that does nothing to the data which is written
 */
public class DummyOutputStream extends OutputStream {
	public static DummyOutputStream INSTANCE = new DummyOutputStream();
	
	private DummyOutputStream() {}


	@Override
    public void write(int b) throws IOException {
       //Do nothing
    }

    @Override
    public void write(byte[] b) throws IOException {
    	//Do nothing
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
    	//Do nothing
    }
	
}
