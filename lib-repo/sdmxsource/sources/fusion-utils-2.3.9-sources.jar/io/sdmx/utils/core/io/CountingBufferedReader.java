package io.sdmx.utils.core.io;

import io.sdmx.api.io.ReadableDataLocation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class CountingBufferedReader extends BufferedReader {

	private final InputStream inputStream;
	private final boolean isCRLF;
	private long byteCount = -1;

	/**
	 * A BufferedReader that counts the total number of bytes read so far.
	 * This is updated after a line has been read and accounts for end
	 * of line characters as long as they are consistent throughout the file.
	 * @param rdl readable data location with the content to be read
	 * @throws IOException
	 */
	public CountingBufferedReader(ReadableDataLocation rdl) throws IOException {
		super(new InputStreamReader(rdl.getInputStream(), StandardCharsets.UTF_8));
		inputStream = rdl.getInputStream();
		isCRLF = isCRLF();
	}

	@Override
	public String readLine() throws IOException {
		// intercept read line and count bytes
		String line = super.readLine();
		if (line != null) {
			byte[] lineBytes = line.getBytes(StandardCharsets.UTF_8);
			byteCount += lineBytes.length;

			// account for 1 stripped end line character
			byteCount++;
			if (isCRLF) {
				// account for another stripped end line character
				byteCount++;
			}
		}
		return line;
	}

	/**
	 * Preread the first line of a file to determine line endings. This is subsequently used to add the appropriate number
	 * of bytes (2 for CRLF, 1 for LF or CR) to each line's total to account for end of line characters stripped by the reader.
	 * @return true if line endings are CRLF, false if LF or CR
	 * @throws IOException
	 */
	private boolean isCRLF() throws IOException {
		InputStreamReader reader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
		boolean isCRLF = false;

		while (true) {
			int i = reader.read();
			if (i == -1) {
				break;
			} else if (i == '\n') {
				// LF
				break;
			} else if (i == '\r') {
				// CR
				if (reader.read() == '\n') {
					// CRLF
					isCRLF = true;
					break;
				}
				break;
			}
		}
		return isCRLF;
	}

	/**
	 * @return the total number of bytes read so far, updated after a line has been read as part of a call to readLine().
	 */
	public long getByteCount() {
		return byteCount;
	}
}
