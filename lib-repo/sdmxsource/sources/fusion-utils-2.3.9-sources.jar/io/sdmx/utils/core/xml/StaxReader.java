package io.sdmx.utils.core.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.stream.StreamSource;

import org.codehaus.stax2.XMLInputFactory2;
import org.codehaus.stax2.XMLStreamReader2;
import org.codehaus.stax2.osgi.Stax2InputFactoryProvider;

import com.ctc.wstx.osgi.InputFactoryProviderImpl;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.utils.core.io.ByteTrackingReader;
import io.sdmx.utils.core.io.PathUtil;
import io.sdmx.utils.core.io.StreamUtil;

/**
 * Iterates XML elements, supports (over and above a typical stax reader):
 * <ul>
 *   <li>positional information as an offset from the start of the stream
 * for example current element starts is 2300 bytes from the start of the stream and is 80 bytes long</li>
 *   <li>peaking at the next element</li>
 *   <li>xpath of current element</li>
 * </li>
 */
public class StaxReader implements IStaxReader {
	private static final Stax2InputFactoryProvider INPUT_FACTORY_PROVIDER = new InputFactoryProviderImpl();
	private Stack<String> stack = new Stack<>();
	private ReadableDataLocation rdl;
	private InputStream stream;
	private StreamSource source;
	private XMLStreamReader2 streamReader;
	private Map<String, String> attributes;
	private String elementName;
	private boolean isStartElement;
	private boolean pop;
	private boolean hasDocType = false;
	private ByteTrackingReader byteTrackingReader;
	
	private boolean peakNext;
	private boolean peak;
	
	private XMLElementPosition elementPosition;

	public StaxReader(ReadableDataLocation rdl) {
		this.rdl = rdl;
		reset();
	}
	
	/**
	 * Provides the bytes off set from the start of the InputStream and byte length of the current XMLElement, this can be 
	 * either a start element or end element, this can be used to extract the exact string of the element from the file
	 * 
	 * @see PathUtil.getContentsFromOffset
	 * 
	 * Example Start Element:  <ns:Name attr1="foo" attr2="bar2>
	 * 
	 * Example End Element:  </ns:Name>
	 * 
	 */
	public class XMLElementPosition {
		private long startCharOffset;
		private long endCharOffset;
		
		private long byteOffset = -1;
		private long byteLength = -1;
		
		private XMLElementPosition() {
			if(byteTrackingReader == null) {
				byteTrackingReader = new ByteTrackingReader(rdl);
			}
			startCharOffset = streamReader.getLocationInfo().getStartingCharOffset();
			try {
				endCharOffset = streamReader.getLocationInfo().getEndingCharOffset();
			} catch (XMLStreamException e) {
				throw new RuntimeException(e);
			}
		}
		
		public XMLElementPosition(long byteOffset, long byteLength) {
			this.byteOffset = byteOffset;
			this.byteLength = byteLength;
		}

		/**
		 * Merges the start position of this XMLElementPosition with the end position of the XMLElementPosition
		 * passed in to reutrn an XMLElementPosition whose start pos and length encompass both - if the XMLElementPosition is resolved
		 * to a snippet in the file it would start from this XMLElementPosition to the end of that XMLElementPosition
		 * @param endPos merge the start pos with this endPos
		 * @return
		 */
		public XMLElementPosition merge(XMLElementPosition endPos) {
			calculateByteOffsets();
			if(endPos == null) {
				return this;
			}
			long newLength = -1;
			if(this.startCharOffset  > endPos.startCharOffset) {
				newLength = byteOffset - endPos.getByteOffset() + byteLength;
			} else {
				newLength = endPos.getByteOffset() - byteOffset + endPos.getByteLength();
			}
			return new XMLElementPosition(this.getByteOffset(), newLength);
		}
		
		/**
		 * @return byte offset from the start of the input stream of the current XML Element of the StaxReader
		 */
		public long getByteOffset() {
			calculateByteOffsets();
			return byteOffset;
		}
		
		/**
		 * @return byte length of the current element of the StaxReader, this includes everything up to the '>' of the XML Element
		 */
		public long getByteLength() {
			calculateByteOffsets();
			return byteLength;
		}
		
		private void calculateByteOffsets() {
			if(byteOffset < 0) {
				try {
					byteOffset = byteTrackingReader.getByteOffset(startCharOffset);
					long endByteOffset = byteTrackingReader.getByteOffset(endCharOffset);
					byteLength = endByteOffset - byteOffset;
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
	
	@Override
	public void reset() {
		pop = false;
		hasDocType = false;
		stack = new Stack<>();
		if(byteTrackingReader != null) {
			byteTrackingReader.reset();
		}
		elementPosition = null;
		XMLInputFactory2 factory = INPUT_FACTORY_PROVIDER.createInputFactory();
		factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
		factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
		try {
			stream = rdl.getInputStream();
			source = new StreamSource(stream, "UTF-8");
			streamReader = (XMLStreamReader2) factory.createXMLStreamReader(source);
		} catch (XMLStreamException e) {
			close();
			throw new StaxException(e);
		}
	}

	@Override
	public boolean moveNextStartNode() {
		while (moveNextNode()) {
			if (isStartElement()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String getElementNamespace() {
		return streamReader.getNamespaceURI();
	}

	@Override
	public void skipCurrentNode() {
		skipNode();
	}

	@Override
	public boolean jumpToNode(String findNodeName) {
		return jumpToNode(findNodeName, null);
	}

	/**
	 * Moves the parser position forward to the point after this node and all children of this node
	 *
	 * @param parser
	 * @throws XMLStreamException
	 */
	@Override
	public void skipNode() {
		while (moveNextNode()) {
			if (this.isStartElement()) {
				skipNode();
			} else {
				return;
			}
		}
	}

	/**
	 * Moves the parser position forward to the next instance of the node with the given name
	 *
	 * @param parser
	 * @throws XMLStreamException
	 */
	@Override
	public boolean skipToNode(String nodeName) {
		while (moveNextStartNode()) {
			if (getElementName().equals(nodeName)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean jumpToNode(String findNodeName, String doNotProcessPastNodeName) {
		String nodeName;
		while (moveNextStartNode()) {
			nodeName = getElementName();
			if (isStartElement()) {
				if (nodeName.equals(findNodeName)) {
					return true;
				}
			} else {
				if (doNotProcessPastNodeName != null) {
					if (nodeName.equals(doNotProcessPastNodeName)) {
						return false;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Moves the parser position forward to the next instance of the end node given name
	 *
	 * @param parser
	 * @throws XMLStreamException
	 */
	@Override
	public boolean skipToEndNode(String nodeName) {
		while (moveNextNode()) {
			if (isStartElement() == false && getElementName().equals(nodeName)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String getAttributeValue(String attrId) {
		return getAttributeValue(null, attrId);
	}

	@Override
	public String getAttributeValue(String namespace, String attrId) {
		if (attributes == null) {
			getAttributes();
		}
		return attributes.get(attrId);
	}
	
	/**
	 * Moves to the next element, the state of the StaxReader is updated, but the next call to moveNextNode will 
	 * not move the position forward, can be called multiple times, on each call the underlying reader will move to the next 
	 * element, but both the response value for 
	 * moveNextNode, getXMLPath, and getXMLElementPosition methods are always one step behind
	 * 
	 * @return true if there is a next element
	 */
	@Override
	public boolean peak() {
		peak = false;
		XMLElementPosition prePeakPosition = this.elementPosition != null ? this.elementPosition : new XMLElementPosition();
		peakNext = moveNextNode(true);
		this.elementPosition = prePeakPosition;
		peak = true;
		return peakNext;
	}
	
	@Override
	public boolean moveNextNode() throws StaxException {
		return moveNextNode(false);
	}
	
	/**
	 * Moves to the next start or end node
	 *
	 * @return
	 */
	private boolean moveNextNode(boolean areYouPeaking) throws StaxException {
		elementPosition = null;
		if(peak)  {
			peak = false;
			if(isStartElement) {
				stack.push(elementName);
			} else if (!stack.isEmpty()){
				stack.pop();
			}
			return peakNext;
		}
		attributes = null;
		elementName = null;
		if (pop) {
			//Pop as there was a call to get text from the node which moved onto the end node
			stack.pop();
			pop = false;
		}
		try {
			while (streamReader.hasNext()) {
				int event = streamReader.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					isStartElement = true;
					elementName = streamReader.getLocalName();
					if(!areYouPeaking)  {
						stack.push(elementName);
					}
					return true;
				}
				if (event == XMLStreamConstants.END_ELEMENT) {
					elementName = streamReader.getLocalName();
					if (stack.isEmpty()) {
						return false;
					} else {
						if(!areYouPeaking)  {
							stack.pop();
						}
					}
					isStartElement = false;
					return true;
				}
				if (event == XMLStreamConstants.DTD) {
					hasDocType = true;
				}
			}
			return false;
		} catch (XMLStreamException e) {
			close();
			throw new StaxException(e);
		}
	}

	/**
	 * Returns the XML path to the current element, for example Root/Element1/ChildElemet
	 *
	 * @return
	 */
	@Override
	public String getXMLPath() {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for (String stackEl : stack) {
			sb.append(concat + stackEl);
			concat = "/";
		}
		return sb.toString();
	}

	@Override
	public String getElementName() {
		return elementName;
	}

	@Override
	public String getElementText() {
		try {
			return streamReader.getElementText();
		} catch (XMLStreamException e) {
			close();
			throw new StaxException(e);
		} finally {
			pop = true;
		}
	}

	@Override
	public boolean isStartElement() {
		return isStartElement;
	}

	@Override
	public Map<String, String> getAttributes() {
		if (attributes == null) {
			attributes = new HashMap<>();
		}
		for (int i = 0; i < getAttributeCount(); i++) {
			String attrName = getAttributeLocalName(i);
			attributes.put(attrName, getAttributeValue(i));
		}
		return new HashMap<>(attributes);
	}

	@Override
	public boolean hasDocType() {
		return hasDocType;
	}

	@Override
	public int getAttributeCount() {
		return streamReader.getAttributeCount();
	}

	@Override
	public String getAttributeLocalName(int i) {
		return streamReader.getAttributeLocalName(i);
	}

	@Override
	public String getAttributeValue(int i) {
		return streamReader.getAttributeValue(i);
	}

	@Override
	public String getAttributePrefix(int i) {
		return streamReader.getAttributePrefix(i);
	}
	public int getEvent(){
		return streamReader.getEventType();
	}

	public int getNextEvent() {
		try {
			return streamReader.next();
		} catch (XMLStreamException e) {
			close();
			throw new StaxException(e);
		}
	}

	public String getText(){
		return streamReader.getText(); //or getElementText
	}

	/**
	 * @return the XMLElementPosition of the current element, note if peak is called this will return the XMLElementPosition of the element the stax
	 * reader is on before the peak check
	 */
	public XMLElementPosition getXMLElementPosition() {
		if(peak) {
			return elementPosition;
		}
		if(elementPosition == null) {
			elementPosition = new XMLElementPosition();
		}
		return elementPosition;
	}

	@Override
	public void close() {
		StreamUtil.closeStream(stream);
		if(byteTrackingReader != null) {
			byteTrackingReader.close();
		}
	}
}
