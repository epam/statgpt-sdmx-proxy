package io.sdmx.utils.core.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IGenericInformationFormat;
import io.sdmx.api.http.MIME_TYPE;

public class GenericFormatXLSX implements IGenericInformationFormat {
	private static final long serialVersionUID = 1L;
	private static final GenericFormatXLSX INSTANCE = new GenericFormatXLSX();
	private static final FormatDetails DETAILS = new FormatDetailsImpl("xlsx", MIME_TYPE.EXCEL, true, MIME_TYPE.EXCEL.getMimeType());
			
	public static GenericFormatXLSX getInstance() {
		return INSTANCE;
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		return DETAILS;
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this == getInstance();
	}

	@Override
	public String toString() {
		return "XLSX";
	}
}
