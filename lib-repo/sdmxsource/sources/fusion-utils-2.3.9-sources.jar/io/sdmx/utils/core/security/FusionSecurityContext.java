package io.sdmx.utils.core.security;

import java.util.Map;

import io.sdmx.api.process.IProcess;
import io.sdmx.api.security.ISecureThread;
import io.sdmx.api.security.ISecurityContextHolder;
import io.sdmx.api.security.SecurityDetails;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

/**
 * Decoupled from any security framework, this static class enables other processes to obtain security details when required,
 * default when not configured is to assume no security
 */
public class FusionSecurityContext {
	/**
	 * Default implementation
	 */
	private static ISecurityContextHolder securityContextHolder = new ISecurityContextHolder() {

		@Override
		public SecurityDetails getSecurityDetails() {
			return null;
		}
		
		@Override
		public boolean isAuthenticated() {
			return false;
		}

		@Override
		public void runAsRoot(IProcess process) {
			process.runProcess();
		}

		@Override
		public void runAsUser(SecurityDetails sd, IProcess process) {
			process.runProcess();
		}

		@Override
		public ISecureThread createSecureThread(boolean copyThreadLocal) {
			return new ISecureThread() {
				private Map<Object, Object> localThreadContents;
				private IProcess process;

				@Override
				public void run() {
					if(localThreadContents != null) {
						for(Object o : localThreadContents.keySet()) {
							ThreadLocalUtil.storeOnThread(o, localThreadContents.get(o));
						}
					}
					try {
						process.runProcess();
					} finally {
						ThreadLocalUtil.clearThread();
					}
				}

				@Override
				public void runProcess(IProcess process) {
					if(copyThreadLocal) {
						localThreadContents = ThreadLocalUtil.getThreadContents();
					}
					this.process = process;
					Thread t = new Thread(this);
					t.setDaemon(true);
					t.start();
				}
			};
		}
	};

	public static void setSecurityContextHolder(ISecurityContextHolder holder) {
		FusionSecurityContext.securityContextHolder = holder;
	}

	public static ISecurityContextHolder CTX() {
		return FusionSecurityContext.securityContextHolder;
	}

}
