package io.sdmx.utils.core.date;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.date.ITimePeriod;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.NumberUtils;

/**
 * For a given time period T obtains dates for that period as an offset of set
 */
public class TimePeriod implements ITimePeriod {
	/**
	 * Regular expression for matching a period expression and moving the frequency accordingly - i.e.:
	 * 
	 * A(P) - cast to annual
	 * A(P-1) - step back 1 base period on the base frequency and cast to annual
	 * A(P)+1 - cast to annual and move forward 1 annual period
	 * A(P-1)+1 - step back 1 base period, cast to annual and move forward 1 annual period
	 * 
	 * 
	 * Capture Group 1 = Match Frequency    (A|M|Q|T|...)
	 * Capture Group 2 = Match Period +/-   (P([(\\+\\-)]\\d+)?\\)
	 * Capture Group 3 = Match Cast +/-
	 */
	private static final Pattern CAST_DATE_PATTERN;
	
	private Map<String, SdmxDate> expressionToISOTime = new HashMap<>();
	private SdmxDate basePeriod;
	private SdmxDate basePeriodEndOfPeriod;
	
	private static char P = "P".charAt(0);
	private static char PLUS = "+".charAt(0);
	private static char MINUS = "-".charAt(0);

	
	 static {
		StringBuilder freqSb = new StringBuilder("[F]?");  //Start with an optional leading F
		//the first part of the pattern is an or condition against all SDMX frequencies in a capture group: (A|M|Q) - this builds the string
		String concat = "(";
		for(TIME_FORMAT tf : TIME_FORMAT.values()) {
			freqSb.append(concat+tf.getFrequencyCodeId());
			concat="|";
		}
		freqSb.append(")");
		//the remaining part contains (P) or (P+4) or (P+4)-1
		freqSb.append("\\(P([(\\+\\-)]\\d+)?\\)([(\\+\\-)]\\d+)?");
		CAST_DATE_PATTERN = Pattern.compile(freqSb.toString());
	}
	
	public TimePeriod(SdmxDate basePeriod) {
		if(basePeriod == null) {
			throw new SdmxException("TimePeriod.basePeriod can not be null");
		}
		this.basePeriod = basePeriod;
		this.basePeriodEndOfPeriod =  SdmxDateImpl.getSdmxDate(basePeriod.getDateInSdmxFormat(), false);
	}

	@Override
    public SdmxDate getBasePeriod() {
		return basePeriod;
	}
	
	@Override
	public boolean isExpression(String expression) {
		return TimePeriod.isExpresion(expression);
	}
	
	public static boolean isExpresion(String expression) {
		char[] chars = expression.toCharArray();
		if(chars.length == 0) {
			return false;
		}
		if(chars[0] == P) {
			if(chars.length == 1) {
				return true;
			}
			if(chars.length == 2) {
				return false;
			}
			if(chars[1] != PLUS && chars[1] != MINUS) {
				return false;
			}
			for(int i=2; i < chars.length; i++) {
				if(!NumberUtils.isNumber(chars[i])) {
					return false;
				}
			}
			return true;
		}
		//does not begin with P - is it an expression pattern
		Matcher m = CAST_DATE_PATTERN.matcher(expression);
		return m.find();
	}
	
	

	@Override
    public SdmxDate getTimePeriod(String expression) {
		SdmxDate isoTime = expressionToISOTime.get(expression);
		if(isoTime == null) {
			isoTime = executeTimePeriodExpresion(expression);
			expressionToISOTime.put(expression, isoTime);
		}
		return isoTime;
	}
	 
	/**
	 * Converts the base period based on the expression
	 * @param expression fixed time format, i.e. 2008, or an offset from the base period P+1, P+2, or a cast with optional offsets: A(P), A(P-1), A(P+1)-5.  If the date cast starts with an F, then the enclosing period rule is applied , i.e. FA(P)
	 * @return
	 */
	private SdmxDate executeTimePeriodExpresion(String expression) {
		if(expression.startsWith("P")) {
			//Time String is either P or P+/-n
			return processPeriodFunction(expression);
		}
		Matcher m = CAST_DATE_PATTERN.matcher(expression);
		if(m.matches()) {
			// DEV-1071
			/*
			 * For a relationship between a higher frequency i.e. Quarter, case to a lower frequency i.e. Annual
			   If the higher frequency is that last period of the enclosing period ( i.e. Q4 of 2021 is the same as 20201 end of period)
			   then we stay in the given enclosing period i.e. 2021
			   if the higher frequency is not the last period (Q1, Q2, or Q3 is not the same as end of period 2021) then we flip to the previous enclosing period (i.e 2021-Q3 becomes 2020)
			 */
			boolean enclosingPeriodRule = expression.startsWith("F");
			
			TIME_FORMAT castFreq =  TIME_FORMAT.getTimeFormatFromCodeId(m.group(1));
			String moveBasePeriod = m.group(2);
			String moveTargetPeriod = m.group(3);
			
			//check if we are moving to a higher frequency, in which case use end of period
			SdmxDate basePeriod = castFreq.getPeriodsInAYear() > this.basePeriod.getTimeFormatOfDate().getPeriodsInAYear() ? this.basePeriodEndOfPeriod : this.basePeriod;
			
			
			SdmxDate movedBasePeriod = moveBasePeriod == null ? basePeriod : moveNPeriods(basePeriod, moveBasePeriod);
			
			
			String cast = DateUtil.formatDate(movedBasePeriod.getDate(), castFreq);
			SdmxDate basePeriodCast = SdmxDateImpl.getSdmxDate(cast, false);

			int moveNPeriods = moveTargetPeriod == null ? 0 : moveNPeriods(moveTargetPeriod);
			if(enclosingPeriodRule) {
				//If the (optionally moved) base period resolves to the same timestamp as the case period, then we know the base period
				//was at the end of period, i.e. 2001-Q4 (end of period)
				SdmxDate endOfPeriodDate = SdmxDateImpl.getSdmxDate(movedBasePeriod.getDateInSdmxFormat(), false);
				if(!endOfPeriodDate.getDate().equals(basePeriodCast.getDate())) {
					moveNPeriods += -1;  //Subtract 1 from the moveNPeriods;
				}
			}
			
			if(moveNPeriods != 0) {
				return moveNPeriods(basePeriodCast, moveNPeriods);
			}
			return basePeriodCast;
		}
		if(!DateUtil.isSdmxDate(expression)) {
			//Does the expression contain inner expressions, i.e. Q(FA(P-1))+1
			
			Exp exp = Exp.build().blockCopy(CHARS.OPEN_PARENTHESIS, CHARS.CLOSE_PARENTHESIS).parse(expression);
			
			StringBuilder rewrite = new StringBuilder();  //Rewrite the expression as Q(P)+1 where P=a new TimePeriod built from FA(P-1)
			
			String innerBlock = null;
			for(int i=0; i < exp.size(); i++) {
				String block = exp.getBlock(i);
				if(exp.getLevel(i) == 0) {
					//Execute expression
					rewrite.append("(P)");
					innerBlock = block;
				} else {
					rewrite.append(block);
				}
			}
			if(innerBlock != null) {
				SdmxDate formattedDate = executeTimePeriodExpresion(innerBlock);
				TimePeriod p = new TimePeriod(formattedDate);
				return p.executeTimePeriodExpresion(rewrite.toString());
			} else {
				throw new SdmxSemmanticException("Unsupported date expression: "+expression);
			}
		}
		return SdmxDateImpl.getSdmxDate(expression);  //Just a standard date
	}
	
	
	/**
	 * Processes a period expression of either P, P+n, or P-n to move forwards/backwards from the base period
	 * @param period
	 * @return
	 */
	private SdmxDate processPeriodFunction(String period) {
		//Match on either P, meaning this period, or P-n/P+n to walk forwards or backwards in time from period P
		if(period.length() == 1) {
			return this.basePeriod;  //This period
		}
		//Strip off the leading P to move forward/backwards in time
		return moveNPeriods(this.basePeriod, period.substring(1));
	}
	
	/**
	 * move n periods forwards or backwards in time
	 * @param date to move
	 * @param expression either +n or -n
	 * @return moved date
	 */
	private SdmxDate moveNPeriods(SdmxDate date, String expression) {
		return moveNPeriods(date, moveNPeriods(expression));
	}
	
	/**
	 * move n periods forwards or backwards in time
	 * @param date to move
	 * @param expression either +n or -n
	 * @return moved date
	 */
	private SdmxDate moveNPeriods(SdmxDate date, int numPeriods) {
		return SdmxDateImpl.getSdmxDate(DateUtil.movePeriod(date, numPeriods), false);
	}
	
	/**
	 * 
	 * @param expression
	 * @return
	 */
	private int moveNPeriods(String expression) {
		boolean forwards = true;
		if(expression.startsWith("-")) {
			forwards = false;
		} else if(!expression.startsWith("+")) {
			throw new SdmxSemmanticException("Unexpected expresion for moving time periods: "+expression);
		}
		try {
			int numPeriods = Integer.parseInt(expression.substring(1));
			if(!forwards) {
				numPeriods = numPeriods * -1;
			}
			return numPeriods;
		} catch(NumberFormatException ex) {
			throw new SdmxSemmanticException("Unexpected expresion for moving time periods: "+expression);
		}
	}
}