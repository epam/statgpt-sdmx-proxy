package io.sdmx.utils.core.xlsx;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.ReadableDataLocationTmp;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxUtil;

public class XLSXUtil {

	public static boolean isXlsx(byte[] bytes) {
		return isXlsx(new ByteArrayInputStream(bytes));
	}
	
	public static boolean isXlsx(Path p) {
		return isXlsx(new ReadableDataLocationTmp(p));
	}

	/**
	 * Compares two xlsx files, ignoring certain attributes which can vary, ensuring the content is the same
	 * @param source
	 * @param target
	 * @throws IllegalArgumentException if there are any differences
	 */
	public static void compare(ReadableDataLocation source, ReadableDataLocation target) throws IllegalArgumentException {
		
		Set<String> ignoreAttributes = new HashSet<>();
		ignoreAttributes.add("width");
		ignoreAttributes.add("created");
		ignoreAttributes.add("lpwstr");
		ignoreAttributes.add("borderId");
		
		List<ReadableDataLocation> files = null;
		List<ReadableDataLocation> expectedFiles = null;

		
		try {
			files = ZipUtil.unzipFiles(target);
			expectedFiles = ZipUtil.unzipFiles(source);
			Map<String, ReadableDataLocation> fileMap = new HashMap<>();
			for(ReadableDataLocation rdl : expectedFiles) {
				if(rdl.getName().endsWith(".xml") && !rdl.getName().endsWith("styles.xml")) {
					fileMap.put(rdl.getName(), rdl);
				}
			}
			for(ReadableDataLocation rdl : files) {
				//Only check XML files, do not check the styles file
				if(rdl.getName().endsWith(".xml") && !rdl.getName().endsWith("styles.xml")) {
					
					ReadableDataLocation expected = fileMap.get(rdl.getName());
					Objects.requireNonNull(expected);
					try {
						StaxUtil.isSameXML(expected.getInputStream(), rdl.getInputStream(), ignoreAttributes, null, "width", "created", "lpwstr");
					} catch (Exception e) {
						throw new RuntimeException("Files '"+rdl.getName()+"' differ: " + e.getMessage());
					}
				}
			}
		} finally {
			if(files != null) {
				for(ReadableDataLocation rdl : files) {
					rdl.close();
				}
			}
			if(expectedFiles != null) {
				for(ReadableDataLocation rdl : expectedFiles) {
					rdl.close();
				}
			}
			source.close();
		}
//
//		List<ReadableDataLocation> expectedFiles = ZipUtil.unzipFiles(target);
//
//		Map<String, ReadableDataLocation> fileMap = new HashMap<>();
//		for(ReadableDataLocation currentRdl : expectedFiles) {
//			if(currentRdl.getName().endsWith(".xml")) {
//				fileMap.put(currentRdl.getName(), currentRdl);
//			}
//		}
//		Set<String> ignoreAttributes = new HashSet<>();
//		ignoreAttributes.add("width");
//		ignoreAttributes.add("created");
//		ignoreAttributes.add("lpwstr");
//
//		List<ReadableDataLocation> files = ZipUtil.unzipFiles(source);
//		try {
//			for(ReadableDataLocation currentRdl : files) {
//				for(ReadableDataLocation rdl : expectedFiles) {
//					if(rdl.getName().endsWith(".xml") && !rdl.getName().endsWith("styles.xml")) {
//						fileMap.put(rdl.getName(), rdl);
//					}
//				}
//				if(currentRdl.getName().endsWith(".xml")) {
//					ReadableDataLocation expected = fileMap.get(currentRdl.getName());
//					Assert.notNull(expected);
//					try {
//						StaxUtil.isSameXML(currentRdl.getInputStream(), expected.getInputStream(),  ignoreAttributes, null, "width", "created", "lpwstr");
//					} catch (Exception e) {
//						throw new RuntimeException("Files '"+currentRdl.getName()+"' differ: " + e.getMessage());
//					}
//				}
//			}
//		} finally {
//			for(ReadableDataLocation currentRdl : files) {
//				currentRdl.close();
//			}
//			for(ReadableDataLocation currentRdl : expectedFiles) {
//				currentRdl.close();
//			}
//			target.close();
//			source.close();
//		}
	}

	public static boolean isXlsx(ReadableDataLocation rdl) {
		if(rdl == null) {
			return false;
		}
		InputStream is = rdl.getInputStream();
		try {
			return isXlsx(is);
		} finally {
			StreamUtil.closeStream(is);
		}
	}

	public static boolean isXlsx(InputStream is) {
 		if(is == null) {
			return false;
		}
		List<String> zipFileNames = null;
		try {
			zipFileNames = ZipUtil.getZipFileNames(is);
		} catch (Exception e) {
			return false;
		}
		if(zipFileNames == null){
			return false;
		}

		Set<String> folders = new HashSet<>();
		Set<String> files = new HashSet<>();

		for (String file : zipFileNames) {
			if(file.contains("/")){
				String[] split = file.split("/");
				for (String part : split) {
					if(part.contains(".")){
						files.add(part);
					}else{
						folders.add(part);
					}
				}
			}else{
				files.add(file);
			}
		}
		if(!ObjectUtil.validCollection(files) || !ObjectUtil.validCollection(folders)){
			return false;
		}
		boolean hasCorrectFiles = files.contains("[Content_Types].xml");
		boolean hasCorrectFolters = folders.containsAll(Arrays.asList("xl", "_rels"));
		return hasCorrectFiles && hasCorrectFolters;
	}
}
