package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;

/**
 * A ReadableDataLocation that wraps a multiple RDLs
 */
public class MutlipleReadableDataLocation extends AbstractReadableDataLocation {

    private static final long serialVersionUID = 1L;
    private List<ReadableDataLocation> items;
    
    public MutlipleReadableDataLocation(List<ReadableDataLocation> items) {
        this.items = items;
    }
    
    public List<ReadableDataLocation> getItems() {
        return items;
    }
    
    @Override
	public FILE_FORMAT getFormat() {
		return FILE_FORMAT.MIXED;
	}

    @Override
	protected InputStream getStreamInternal() throws IOException {
    	throw new UnsupportedOperationException("Unable to query a MultipleReadableDataLocation class for its InputStream");
	}

	@Override
    public String getName() {
        throw new UnsupportedOperationException("Unable to query a MultipleReadableDataLocation class for its name");
    }

    @Override
    protected long calculateSize() {
        long size = 0;
        for(ReadableDataLocation rdl : items) {
            size += rdl.getSize();
        }
        return size;
    }
    
    @Override
	public boolean splitable() {
		return true;
	}

	@Override
	/**
	 * @param closeSource - sets the marker on this class to closed, does not close underlying RDLs
	 */
	public List<ReadableDataLocation> split(boolean closeSource) {
		if(closeSource) {
			super.isClosed = true;
		}
		return items;
	}

	@Override
	protected void closeInternal() {
    	 if(items != null) {
         	for(ReadableDataLocation rdl : items) {
         		rdl.close();
         	}
         }
	}

	@Override
    public ReadableDataLocation copy() {
        return new MutlipleReadableDataLocation(items);
    }
}