package io.sdmx.utils.core.security;

/**
 * persists in memory a global password/salt pair
 */
public class FusionCryptUtil {
	private static String password;
	private static String salt;
	
	public static void setPassword(String password) {
		FusionCryptUtil.password = password;
	}

	public static void setSalt(String salt) {
		FusionCryptUtil.salt = salt;
	}

	
	public static String encrypt(String value) {
		if(password == null) {
			throw new IllegalArgumentException("encryption password is not set");
		}
		if(salt == null) {
			throw new IllegalArgumentException("encryption salt is not set");
		}
		return CryptUtil.encrypt(value, password, salt);
	}

	public static String decrypt(String value) {
		if(password == null) {
			throw new IllegalArgumentException("encryption password is not set");
		}
		if(salt == null) {
			throw new IllegalArgumentException("encryption salt is not set");
		}
		return CryptUtil.decrypt(value, password, salt);
	}
	
}
