package io.sdmx.utils.core.http;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Wraps the JSON response in a JSON padding string e.g,jQuery123456789(...) 
 *
 */
public class JSONPOuputSream extends OutputStream {
	private OutputStream stream;
	
	public JSONPOuputSream(OutputStream stream, String jsonP) {
		this.stream = stream;
		try {
			stream.write(new String(jsonP+"(").getBytes());
		} catch (IOException e) {
			throw new RuntimeException("Error writing JSONP to outputstream");
		}
	}

	@Override
	public void write(int b) throws IOException {
		stream.write(b);
	}

	@Override
	public void close() throws IOException {
		stream.write(")".getBytes());
		stream.close();
	}

	@Override
	public void flush() throws IOException {
		stream.flush();
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		stream.write(b, off, len);
	}

	@Override
	public void write(byte[] b) throws IOException {
		stream.write(b);
	}
}
