package io.sdmx.utils.core.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;

import io.sdmx.api.io.FileReader;
import io.sdmx.api.io.ReadableDataLocation;

/**
 * This class reads a file a 'line' at a time where the end of the line is delimited by the specified endOfLineTag.
 * It also caters for some EDI specific code whereby
 * FR-983: Previous implementations of this class used a Scanner rather than a BufferedReader.
 * Due to various issues, this class must use a BufferedReader.
 */
public class FileReaderImpl implements FileReader {
    protected ReadableDataLocation dataFile;
    private String endOfLineTag;

    private BufferedReader bufferedReader;

    protected String currentLine;
    private int startLineOffset;
    private int endLineOffset;
    private int currentCharOffset;
    
    protected boolean backLine;
    protected int lineNumber;
    private int startIndex =-1;
    private int endIndex =-1;
    private String charset;
    protected boolean lineEndedWithTerminationCharacter;
    private String endOfLineCharacters;

    public FileReaderImpl(ReadableDataLocation dataFile, String endOfLineTag) {
        this.dataFile = dataFile;
        this.endOfLineTag = endOfLineTag;
        resetReader();
    }

    public FileReaderImpl(ReadableDataLocation dataFile, String endOfLineTag, String charset) {
        this.dataFile = dataFile;
        this.endOfLineTag = endOfLineTag;
        this.charset = charset;
        resetReader();
    }

    public FileReaderImpl(ReadableDataLocation dataFile, String endOfLineTag, int startindex, int endIndex) {
        this.dataFile = dataFile;
        this.endOfLineTag = endOfLineTag;
        this.startIndex = startindex;
        this.endIndex = endIndex;
        resetReader();
    }

    public FileReaderImpl(ReadableDataLocation dataFile, String endOfLineTag, int startindex, int endIndex, String charset) {
        this.dataFile = dataFile;
        this.endOfLineTag = endOfLineTag;
        this.startIndex = startindex;
        this.endIndex = endIndex;
        this.charset = charset;
        resetReader();
    }

    /**
     * Resets the reader to the start of the file
     */
    @Override
    public void resetReader() {
        if (bufferedReader != null) {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        currentLine = null;
        backLine = false;
        if (charset != null) {
            bufferedReader = new BufferedReader(new InputStreamReader(dataFile.getInputStream(),Charset.forName(charset)));
        } else {
            bufferedReader = new BufferedReader(new InputStreamReader(dataFile.getInputStream()));
        }

        lineNumber = 0;
        startLineOffset = -1;
        endLineOffset = -1;
        currentCharOffset = -1;
        if(startIndex > 0) {
            while(lineNumber != startIndex) {
                moveNext();
            }
        }
    }

    @Override
    public boolean moveNext() {
        if(lineNumber == endIndex) {
            currentLine = null;
            return false;
        }

        StringBuilder sb = new StringBuilder();

        boolean hasNext = false;
        int currentChar = -1;
        int previousChar = -1;
        int prevQuestionMarkCount = 0;
        lineEndedWithTerminationCharacter = false;
        
        // Set the start of the current line
        endLineOffset = currentCharOffset;
        boolean encounteredValidChar = false;
        StringBuffer eolBuff = new StringBuffer();
        while (true) {
            try {
                // ASCII value of ' is 39
                // ASCII value of ? is 63

                previousChar = currentChar;
                if(previousChar == 63) {
                    prevQuestionMarkCount++;
                }else {
                    prevQuestionMarkCount = 0;
                }
                
                currentChar = bufferedReader.read();
                currentCharOffset++;
                
                if (endOfLineCharacters == null && (currentChar == 10 || currentChar == 13)) {
                	// Note: the 'int' currentChar must be appended as a char for the StringBuffer to have the correct contents
                	eolBuff.append((char)currentChar);
                }
                
                // Ignore byte '0' (null) , byte '10' (line-feed) and byte '13' (carriage return)
                if (!encounteredValidChar && currentChar != 0 && currentChar != 10 && currentChar != 13) {
                	// Set the start of the line
                	startLineOffset = currentCharOffset;
                	encounteredValidChar = true;
                	if (endOfLineCharacters == null && eolBuff.length() > 0) {
                		endOfLineCharacters = eolBuff.toString();
                	}
                }
                
                if(currentChar == -1) {
                    break;
                }

                if (currentChar == 39) {
                    if(previousChar != 63) {
                    	lineEndedWithTerminationCharacter = true;
                        break;
                    }
                    if(prevQuestionMarkCount % 2 == 0) {
                        break;
                    }
                }
                hasNext = true;
                sb.append((char)currentChar);
            } catch (IOException e) {
                break;
            }
        }
        
        endLineOffset = currentCharOffset;

        if (hasNext) {
            lineNumber++;
            currentLine = sb.toString();
        } else {
            currentLine = null;
        }
        
        cleanLine();
        return currentLine != null && currentLine.length() > 0;
    }

    @Override
    public String getNextLine() {
        if(backLine) {
            backLine = false;
            return currentLine;
        }
        if(moveNext()) {
            return getCurrentLine();
        }
        return null;
    }

    @Override
    public boolean isBackLine() {
        return backLine;
    }

    /**
     * @return
     */
    @Override
    public String getCurrentLine() {
        return currentLine;
    }

    private void cleanLine() {
        if(currentLine != null) {
            currentLine = currentLine.replaceAll("\\u000A", "");    // Removes all new-line characters
            currentLine = currentLine.replaceAll("\\u000D", "");    // Removes all carriage-return characters
            //          currentLine = currentLine.replaceAll(lineSeperator, "");
            //          currentLine = currentLine.trim();
        }
    }

    @Override
    public int getLineNumber() {
        return lineNumber;
    }

    @Override
	public int getStartLineOffset() {
		return startLineOffset;
	}
    
    @Override
	public int getEndLineOffset() {
		return endLineOffset;
	}
    
    /**
     * Moves back to the last line read
     * @return
     */
    @Override
    public void moveBackLine() {
        backLine = true;
    }

    @Override
    public void copyToStream(OutputStream out) {
        StreamUtil.copyStream(dataFile.getInputStream(), out);
    }

    @Override
    public void close() {
        try {
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	@Override
	public boolean lineEndedWithTerminationCharacter() {
		return lineEndedWithTerminationCharacter;
	}

	@Override
	public String getNewlineCharacters() {
		return endOfLineCharacters;
	}
}
