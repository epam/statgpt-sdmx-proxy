package io.sdmx.utils.core.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GraphNode<T> {
	private T element;
	private List<GraphNode<T>> parents = new ArrayList<>();
	private List<GraphNode<T>> children = new ArrayList<>();

	public GraphNode(T element) {
		this.element = element;
	}
	
	private void addParent(GraphNode<T> el) {
		this.parents.add(el);
	}
	public void addChild(GraphNode<T> el) {
		el.addParent(this);
		this.children.add(el);
	}

	public T getElement() {
		return element;
	}

	public List<GraphNode<T>> getParents() {
		return Collections.unmodifiableList(parents);
	}

	public List<GraphNode<T>> getChildren() {
		return Collections.unmodifiableList(children);
	}
	
}
