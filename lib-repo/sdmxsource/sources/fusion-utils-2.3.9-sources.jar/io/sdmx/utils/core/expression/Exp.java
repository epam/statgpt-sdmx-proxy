package io.sdmx.utils.core.expression;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.chars.CHARS;

/**
 * Parses a string into blocks, based on paranthesis which push blocks down one level, and special characters, which
 * results in a new block but with the level negated to indicate it is a special character but also preserve the level information
 * 
 * 
 * Example: A:(EUR-(UK+FR+DE)/(2+ES)):EMP:(M+F)
 * Escape Chars: -, +, /, :
 * ["A", ":", "EUR", "-", "UK", "+", "FR", "+", "DE", "/", "2", "+", "ES", ":", "EMP", ":","M", "+", "F"]
 * [ 1,  1  ,  2,  , -2 ,  3  , -3 ,  3  ,  -3,  3  , -2 ,  3,  -3 ,  3  , -1 ,  1   ,  1,  2 ,  -2,  2 ]   //position in tree structure
 * 
 */
public class Exp {
	private static final char START_PARANTHESIS = "(".toCharArray()[0];
	private static final char END_PARANTHESIS = ")".toCharArray()[0];
	
	private List<String>  blocks =  new ArrayList<>(5);
	private List<Integer> blockLevel = new ArrayList<>(3);
	private List<Integer> charIdx = new ArrayList<>();
	
	private char startBlockCopy;
	private char endBlockCopy;
	private boolean trim = false;

	private char escape = "\\".charAt(0);
	private char[] breakOn;
	
	private boolean supportLevels = true;
	
	private String expression;
	
	private Exp(char... breakChars) {
		this.breakOn = breakChars;
	}
	
	public static Exp get(char... breakChars) {
		return new Exp(breakChars);
	}
	
	public static Exp build(CHARS... breakChars) {
		return new Exp(CHARS.toCharArray(breakChars));
	}
	
	public Exp blockCopy(CHARS start, CHARS end) {
		return this.blockCopy(start.getChar(), end.getChar());
	}
	/**
	 * Two characters used to denote that the Expression should copy the entire block of characters without parsing what is in middle
	 * Like a large escape block, for example if the block characters are '[' and ']' and the text is 10-[8+9*(9-1)] then the parser will create the
	 * following blocks '10, -, [,  8+9*(9-1), ]' the level is zero to indicate a block
	 * @param start
	 * @param end
	 */
	public Exp blockCopy(char start, char end) {
		this.startBlockCopy = start;
		this.endBlockCopy = end;
		return this;
	}
	
	/**
	 * @param escapeChar if preceeded by a break char the break char will be treated as a normal string, example: \
	 * @return
	 */
	public Exp escape(char escapeChar) {
		escape = escapeChar;
		return this;
	}
	
	/**
	 * @return trims each part of the expression
	 */
	public Exp trim() {
		trim = true;
		return this;
	}
	
	
	public Exp setSupportLevels(boolean supportLevels) {
		this.supportLevels = supportLevels;
		return this;
	}

	/**
	 * @param expression example: EUR=(DE+FR+ES)+10
	 */
	public Exp parse(String expression) {
		this.expression = expression;
		if(expression == null) {
			return this;
		}
		if(expression.length()==0) {
			addBlock("", 1, 0);
			return this;
		}
		StringBuilder sb = null;
		int level = 1;
		boolean escape = false;
		int inCopyBlock = -1;
		int charIdx = -1;
		outer:
		for(char c : expression.toCharArray()) {
			charIdx++;
			if(c == endBlockCopy && !escape) {
				inCopyBlock--;
				if(inCopyBlock < 0) {
					addBlock(sb, 0, charIdx);
					sb = null;
					continue;
				}
			}
			if(inCopyBlock >=0) {
				if(c == startBlockCopy) {
					inCopyBlock++;
				}
				if(sb == null) {
					sb = new StringBuilder();
				}
				sb.append(c);
				continue;
			}
		
			if(c == startBlockCopy) {
				inCopyBlock++;
				if(sb != null && sb.length() != 0) {
					addBlock(sb, level, charIdx-1);
				}
				sb = new StringBuilder();
			} else if(supportLevels && c == START_PARANTHESIS) {
				if(sb != null && sb.length() != 0) {
					addBlock(sb, level, charIdx-1);
				}
				sb = new StringBuilder();
				addBlock("(", level*-1, charIdx);
				level++;
			} else if(supportLevels && c == END_PARANTHESIS) {
				if(sb != null && sb.length() != 0) {
					addBlock(sb, level, charIdx-1);
					sb = null;
				}
				if(level > 1) {
					level--;
				}
				addBlock(")", level*-1, charIdx);
			} else if(c == this.escape) {
				escape = true;
			} else {
				//Either standard text, or an important character
				if(!escape && this.breakOn != null) {
					//Check for break char
					for(char breakChar : this.breakOn) {
						if(c == breakChar) {
							if(sb != null && sb.length() != 0) {
								addBlock(sb, level, charIdx-1);
								sb = new StringBuilder();
							}
							addBlock(new String(new char[] {breakChar}), level*-1, charIdx); //-1 to indicate a break char (implicitly the same level as previous block)
//							blocks.add(new String(new char[] {breakChar}));
//							blockLevel.add(level*-1);  //-1 to indicate a break char (implicitly the same level as previous block)
							continue outer;
						}
					}
				}
				escape = false;
				if(sb == null) {
					sb = new StringBuilder();
				}
				sb.append(c);
			}
		}
		addBlock(sb, level, charIdx);
		return this;
	}
	
	public String substring(int startBlock) {
		if(startBlock == 0) {
			return expression;
		}
		return expression.substring(this.getCharIdx(startBlock-1)+1);
	}
	
	public String substring(int startBlock, int endBlock) {
		int startIndex = startBlock == 0 ? 0 : this.getCharIdx(startBlock-1)+1;
		return expression.substring(startIndex, this.getCharIdx(endBlock)+1);
	}
	
	private void addBlock(StringBuilder sb, int poistion, int toCharIdx) {
		if(sb != null) {
			String str = sb.toString();
			if(trim) {
				str = str.trim();
			}
			addBlock(str, poistion, toCharIdx);
		}
	}
	
	private void addBlock(String string, int poistion, int toCharIdx) {
		if(string != null) {
			blocks.add(string);
			blockLevel.add(poistion);
			charIdx.add(toCharIdx);
		}
	}
	
	public int size() {
		return blocks.size();
	}
	
	public String getBlock(int pos) {
		return blocks.get(pos);
	}

	public Integer getLevel(int pos) {
		return blockLevel.get(pos);
	}

	/**
	 * @param pos
	 * @return the index in the original string of the end of the block
	 */
	public Integer getCharIdx(int pos) {
		return charIdx.get(pos);
	}
	
}
