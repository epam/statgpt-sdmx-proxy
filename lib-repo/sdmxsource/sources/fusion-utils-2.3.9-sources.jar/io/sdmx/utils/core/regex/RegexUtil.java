package io.sdmx.utils.core.regex;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import io.sdmx.api.chars.CHARS;
import io.sdmx.utils.core.expression.Exp;
import io.sdmx.utils.core.object.ObjectUtil;

public class RegexUtil {
	private static final Pattern captureGroupPtn = Pattern.compile("\\\\[1-9][0-9]*");

	/**
	 * @return true if the input string contains a capture group
	 */
	public static boolean hasCaptureGroup(String str) {
		if(!ObjectUtil.validString(str)) {
			return false;
		}
		return captureGroupPtn.matcher(str).find();
	}
	
	
	/**
	 * Converts a string with wildcards into a regex pattern
	 * @param str the string to convert
	 * @param wildcard the wildcard in the string to convert to a regex wildcard
	 * @return
	 */
	public static Pattern wildcardToRegEx(String str, String wildcard) {
		if(!wildcard.equals(".")) {
			str = str.replaceAll("\\.", "[.]");
		}
		if(!wildcard.equals("*")) {
			str = str.replaceAll("\\*", "[*]");
		}
		str = str.replaceAll("\\"+wildcard, ".*");
		return Pattern.compile(str);
	}

	/**
	 * Returns a List of groups from the supplied regex
	 * @param str
	 * @return
	 */
	public static List<String> obtainGroups(String str) {
		List<String> groupList = new ArrayList<>();
		// Create an EXP object where blocks are based around bracktes
		Exp exp = Exp.get().setSupportLevels(false).blockCopy(CHARS.OPEN_PARENTHESIS.getChar(), CHARS.CLOSE_PARENTHESIS.getChar()).parse(str);
		for (int j=0; j < exp.size(); j++) {
			if (exp.getLevel(j) == 0) {
				// Level 0 is a block so add to the group list
				String currentGroup = exp.getBlock(j);
				groupList.add(currentGroup);
			}
		}
		return groupList;
	}
	
	/**
	 * Replaces the captureGroups in the specified regEx with the values supplied
	 * @param str
	 * @param captureGroup
	 * @return
	 */
	public static String replaceCaptureGroups(String str, String... captureGroup) {
		if(captureGroup != null && str !=null) {
			for(int grpIdx = captureGroup.length-1; grpIdx >= 0; grpIdx--) {
				String groupToReplace = "\\\\" + (grpIdx+1);
				str = str.replaceAll(groupToReplace, captureGroup[grpIdx]);
			}
		}
		return str;
	}
}
