package io.sdmx.utils.core.thread;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.thread.LocalThreadStore;

public class ThreadLocalUtil {
	public static final String CLIENT_REQUEST  = "CLIENT_REQUEST";
	public static final String SESSION  = "SESSION";
	public static final String WEB_SERVICE_TYPE  = "WEB_SERVICE_TYPE";
	public static final String ACTION  = "ACTION";
	public static final String UUID_KEY  = "UUID";
	public static final String REQUEST_ORIGIN  = "REQUEST_ORIGIN";
	public static final String APPLY_EDI_LENIENCE  = "APPLY_EDI_LENIENCE";
	
	private static LocalThreadStore localObjectStore = LocalThreadStore.INSTANCE;
	    
	private ThreadLocalUtil() {}
	
	public static void createUID() {
		storeOnThread(UUID_KEY, UUID.randomUUID().toString());
	}
	
	public static void removeUID() {
		retrieveFromThread(UUID_KEY);
	}
	
	/**
	 * Gets a Unique id for this thread
	 * @return
	 */
	public static String getUID() {
		if(contains(UUID_KEY)) {
			return (String) localObjectStore.get().get(UUID_KEY);
		}
		return null;
	}
	
	public static void storeClientRequest(ClientRequest clientRequest) {
		storeOnThread(CLIENT_REQUEST, clientRequest);
	}
	
	public static ClientRequest getClientRequest() {
		if(contains(CLIENT_REQUEST)) {
			return (ClientRequest) localObjectStore.get().get(CLIENT_REQUEST);
		}
		return null;
	}
	
	public static void storeOnThread(Object key, Object obj) {
		localObjectStore.get().put(key, obj);
	}
	
	public static Object retrieveFromThread(Object key) {
		return localObjectStore.get().get(key);
	}
	
	public static boolean contains(Object key) {
		return localObjectStore.get().containsKey(key);
	}
	
	public static void clearFromThread(Object key) {
		localObjectStore.get().remove(key);
	}
	
	/**
	 * Remove everything stored on this thread
	 */
	public static void clearThread() {
		localObjectStore.get().clear();
	}
	
	/**
	 * Returns a copy of everything stored on the local thread
	 * @return
	 */
	public static Map<Object, Object> getThreadContents() {
		return new HashMap<>(localObjectStore.get());
	}
	
	public static void close() {
		localObjectStore = null;
	}
}
