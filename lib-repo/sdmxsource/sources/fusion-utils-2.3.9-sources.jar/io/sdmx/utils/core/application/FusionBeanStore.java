package io.sdmx.utils.core.application;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.application.IFusionContainer;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.collection.CollectionUtil;

/**
 * A store for registering and de-registering classes that can be picked up by other managers
 */
public class FusionBeanStore implements IFusionContainer {
	private static IFusionContainer container;
	private static Map<Class, Set<Object>> localInstanceStore = new HashMap<>();
	private static FusionBeanStore INSTANCE;
	private long startupTime;
	
	public static FusionBeanStore getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new FusionBeanStore();
		}
		return INSTANCE;
	}

	// Private constructor
	private FusionBeanStore() {
		this.startupTime = System.currentTimeMillis();
	}
	
	public static void clearState() {
	    Collection<IFusionSingleton> beans = null;
	    try {
	        beans = getBeans(IFusionSingleton.class);
	    } catch(IllegalStateException ise) {
	        // Do nothing - the context is in the process of being destroyed
	    }

	    if (beans != null) {
	        for (IFusionSingleton aFusionSingleton : beans) {
	            aFusionSingleton.destroyInstance();
            }
	    }

		FusionBeanStore.container = null;
		localInstanceStore = new HashMap<>();
	}

	public static void setContainer(IFusionContainer container) {
		FusionBeanStore.container = container;
	}

	public static void registerInstance(Object instance) {
		Class claz = instance.getClass();
		while(claz != null && claz != Object.class) {
			putInstance(claz, instance);
			for(Class iclaz : claz.getInterfaces()) {
				putInterface(iclaz, instance);
			}
			claz = claz.getSuperclass();
		}
	}

	private static void putInterface(Class claz, Object instance) {
		putInstance(claz, instance);
		for(Class iclaz : claz.getInterfaces()) {
			putInterface(iclaz, instance);
		}
	}

	private static void putInstance(Class claz, Object instance) {
		CollectionUtil.addToMappedSet(localInstanceStore, claz, instance);
	}

	public static <T> Collection<T> getBeans(Class<T> type) {
		Set set1 = localInstanceStore.get(type);

		Collection<T> set2 = null;
		if(container != null) {
			set2 = container.getBeansOfType(type);
		}
		if(set1 != null && set2 != null) {
			Set returnSet = new HashSet<>();
			returnSet.addAll(set1);
			returnSet.addAll(set2);
			return returnSet;
		}
		if(set1 != null) {
			return Collections.unmodifiableSet(set1);
		}
		if(set2 != null) {
			return Collections.unmodifiableCollection(set2);
		}
		T instance = SingletonStore.getSingleton(type);
		if(instance != null) {
		    return Set.of(instance);
		}
		return Collections.emptySet();
	}

	@Override
	public <T> Collection<T> getBeansOfType(Class<T> type) {
		return FusionBeanStore.getBeans(type);
	}

	@Override
	public long getStartupTime() {
		return startupTime;
	}
}
