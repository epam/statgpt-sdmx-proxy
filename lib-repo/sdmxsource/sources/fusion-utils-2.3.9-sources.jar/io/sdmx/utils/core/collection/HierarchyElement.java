package io.sdmx.utils.core.collection;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.collection.IHierarchyElement;

public class HierarchyElement<T extends Object> implements IHierarchyElement<T>, Serializable {
	private static final long serialVersionUID = 1L;
	public List<IHierarchyElement<T>> children = Collections.emptyList();
	private T value;

	public HierarchyElement(List<IHierarchyElement<T>> children, T value) {
		if(children != null) {
			this.children = children;
		}
		this.value = value;
	}

	public List<IHierarchyElement<T>> getChildren() {
		return children;
	}

	public T getValue() {
		return value;
	}
}
