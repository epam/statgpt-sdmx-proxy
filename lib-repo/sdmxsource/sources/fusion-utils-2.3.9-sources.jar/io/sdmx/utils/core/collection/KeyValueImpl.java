package io.sdmx.utils.core.collection;

import java.lang.ref.SoftReference;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.ReferenceMap;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class KeyValueImpl implements KeyValue {
	//Keep a weak hash map of previously created values for performance
	private static final Map<String, SoftReference<KeyValue>> cache = new ReferenceMap<>();
	
	private static final long serialVersionUID = 1L;

	private String code;
	private String concept;
	private List<String> values;
	
	private transient int hashCode = -1;
	private transient String asString = null;

	public static KeyValue getInstance(String id, String... value) {
		if(value != null && value.length > 1) {
			return new KeyValueImpl(id, value);
		}
		if(value == null || value.length == 0) {
			return new KeyValueImpl(id, value);
		}
		String key = id+":"+value[0];
		synchronized(cache) {
			SoftReference<KeyValue> softKv = cache.get(key);
			KeyValue returnKv = null;
			if(softKv != null) {
				returnKv = softKv.get();
			}
			if(returnKv == null) {
				returnKv = new KeyValueImpl(id, value);
				softKv = new SoftReference<>(returnKv);
				cache.put(key, softKv);
			}
			return returnKv;
		}
	} 

	private KeyValueImpl(String id, String... value) {
		this.concept =  StringUtil.manualIntern(id);
		if(value != null && value.length > 0) {
			if(value.length > 1) {
				this.values = Collections.unmodifiableList(CollectionUtil.arrayToList(true, value));
			} else {
				this.code = StringUtil.manualIntern(value[0]);
			}
		}
	}

	@Override
	public List<String> getValues() {
		return values;
	}

	@Override
	public boolean hasMultipleValues() {
		return values != null;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getConcept() {
		return concept;
	}


	@Override
	public int compareTo(KeyValue that) {
		if(concept.equals(that.getConcept())) {
			if (code == null && that.getCode() == null) {
				if (values == null && that.getValues() == null) {
					return 0;
				}
				if (values == null) {
					return -1;
				}
				if (that.getValues() == null) {
					return 1;
				}
				if (values.size() > that.getValues().size()) {
					return 1;
				}
				if (values.size() < that.getValues().size()) {
					return -1;
				}
				for (int i=0; i < values.size(); i++) {
					int compareVal = values.get(i).compareTo(that.getValues().get(i));
					if (compareVal != 0) {
						return compareVal;
					}
				}
				return 0;
			}
			
			if (code == null) {
				return -1;
			}
			if (that.getCode() == null) {
				return 1;
			}
			return code.compareTo(that.getCode());
		}
		return concept.compareTo(that.getConcept());
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof KeyValue) {
			KeyValue that = (KeyValue)obj;
			if (!this.getConcept().equals(that.getConcept())) {
			    return false;
			}
			
			if (this.getCode() == null && that.getCode() == null) {
				// Need to check the HashCode of the object since a sub-class could add further fields
				return ObjectUtil.equivalentCollection(this.getValues(), that.getValues()) && this.hashCode() == that.hashCode();
			} else {
				if (this.getCode() == null) {
					return false;
				}
				if (that.getCode() == null) {
					return false;
				}
				// Need to check the HashCode of the object since a sub-class could add further fields
				return this.getCode().equals(that.getCode()) && this.hashCode() == that.hashCode();
			}
		}
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		if(hashCode == -1) {
			hashCode = toString().hashCode();
		}
		return hashCode;
	}

	@Override
	public String getShortCode() {
		return toString();
	}

	@Override
	public String toString() {
		if(asString == null) {
			if(code == null) {
				if(values == null) {
					asString = concept + ":";
				} else {
					StringBuilder sb = new StringBuilder();
					String concat = "";
					for(String str : this.values) {
						sb.append(concat+str);
						concat = ", ";
					}
					asString = concept + ":" + sb.toString();
				}
			}  else {
				asString = concept + ":"+code;
			}
		}
		return asString;
	}
}
