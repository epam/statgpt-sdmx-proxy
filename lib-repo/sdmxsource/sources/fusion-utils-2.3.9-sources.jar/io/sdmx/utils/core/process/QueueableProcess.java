package io.sdmx.utils.core.process;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import io.sdmx.api.notification.Listener;
import io.sdmx.api.notification.Notifier;
import io.sdmx.api.security.SecurityDetails;
import io.sdmx.utils.core.audit.AuditUtil;
import io.sdmx.utils.core.error.ErrorReport;
import io.sdmx.utils.core.notifier.ThreadedNotifier;
import io.sdmx.utils.core.security.FusionSecurityContext;

public class QueueableProcess implements Notifier<QueueableNotification> {
	private String id;                       // Unique Identifier assigned by system not for display purposes
	private Date processRequestTime;         // Time the system was aware of the process
	private Date processQueueTime;           // Time the system placed item on the queue
	private Date processStartTime;           // Time process stated processing
	private Date processEndTime;             // Time process complete / or errored
	private PROCESS_STATUS currentStatus;
	private int percentComplete; 
	private ErrorReport errorReport;
	private String auditId;
	private SecurityDetails sd;

	
	private List<Listener<QueueableNotification>> listeners = new ArrayList<>();
	private QueueableProcess() {
		this.auditId = AuditUtil.getCurrentAuditId();
		sd = FusionSecurityContext.CTX().getSecurityDetails();
	}
	
	@Override
    public void addListener(Listener<QueueableNotification> listener) {
		synchronized(listeners) {
			if(!listeners.contains(listener)) {
				listeners.add(listener);
			}
		}
	}

	@Override
    public void removeListener(Listener<QueueableNotification> listener) {
		synchronized(listeners) {
			listeners.remove(listener);
		}
	}

	private void alertListenersOfChange() {
		QueueableNotification notification = new QueueableNotification(this);
		synchronized(listeners) {
			for(Listener<QueueableNotification> currentListener : listeners) {
				ThreadedNotifier.performNotification(currentListener, notification);
			}
		}
	}

	public static QueueableProcess createNewQueueableProcess() {
		QueueableProcess process = new QueueableProcess();
		process.id = UUID.randomUUID().toString();
		process.processRequestTime = new Date();
		return process;
	}
	
	public void acknowledgeProcess() {
		currentStatus = PROCESS_STATUS.PENDING;
		processQueueTime = new Date();
		alertListenersOfChange();
	}
	
	public void joinQueue() {
		currentStatus = PROCESS_STATUS.QUEUED;
		processQueueTime = new Date();
		alertListenersOfChange();
	}
	
	public void startProcess() {
		currentStatus = PROCESS_STATUS.PROCESSING;
		processStartTime = new Date();
		alertListenersOfChange();
	}
	
	public void cancelProcess() {
		currentStatus = PROCESS_STATUS.CANCELLED;
		processEndTime = new Date();
		alertListenersOfChange();
	}
	
	public void endProcess() {
		currentStatus = PROCESS_STATUS.PROCESSED;
		percentComplete = 100;
		processEndTime = new Date();
		alertListenersOfChange();
	}
	
	public void endProcessError() {
		currentStatus = PROCESS_STATUS.ERROR;
		processEndTime = new Date();
		alertListenersOfChange();
	}
	
	public void setError(Throwable th) {
		errorReport = ErrorReport.build(th);
		endProcessError();
	}
	
	public String getId() {
		return id;
	}
	
	
	
	public SecurityDetails getSeurityDetails() {
		return sd;
	}

	public String getAuditId() {
		return auditId;
	}
	
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public Date getProcessQueueTime() {
		return processQueueTime;
	}

	public Date getProcessRequestTime() {
		return processRequestTime;
	}

	public Date getProcessStartTime() {
		return processStartTime;
	}

	public Date getProcessEndTime() {
		return processEndTime;
	}

	public PROCESS_STATUS getCurrentStatus() {
		return currentStatus;
	}
	
	public void setPercentComplete(int percentComplete) {
		if(getCurrentStatus() != PROCESS_STATUS.PROCESSED) {
			if (percentComplete > this.percentComplete) {
				this.percentComplete = percentComplete;
				alertListenersOfChange();
			}
		}
	}

	public int getPercentComplete() {
		return percentComplete;
	}

	public ErrorReport getErrorReport() {
		return errorReport;
	}

	// An enum which is an Inner class needs to be public and static to allow hibernate to work correctly.
	public static enum PROCESS_STATUS {
		PENDING(1),
		QUEUED(2),
		PROCESSING(3),
		PROCESSED(4),
		ERROR(5),
		CANCELLED(6);
		
		private int sequentialValue;
		
		private PROCESS_STATUS(int sequentialValue) {
			this.sequentialValue = sequentialValue;
		}
		
		public static PROCESS_STATUS parseInt(int val) {
			for(PROCESS_STATUS status : PROCESS_STATUS.values()) {
				if(status.sequentialValue == val) {
					return status;
				}
			}
			return null;
		}
		
		public int getSequentialValue() {
			return sequentialValue;
		}

		public boolean isCancelled() {
			return this == PROCESS_STATUS.CANCELLED;
		}
		
		public boolean isProcessed() {
			return this == PROCESS_STATUS.PROCESSED;
		}
		
		public boolean isError() {
			return this == PROCESS_STATUS.ERROR;
		}
		/**
		 * Returns whether the current process has a status "equal" or "later" than the status specified.
		 * e.g. proc.isLater(PROCESS_STATUS.PROCESSED) would be true if "proc" was at PROCESSED or ERROR 
		 * @param aStatus
		 * @return whether the current process is later than that specified.
		 */
		public boolean isLater(PROCESS_STATUS aStatus) {
			if (aStatus == null) return true;
			return this.sequentialValue >= aStatus.sequentialValue;
		}
	}


}