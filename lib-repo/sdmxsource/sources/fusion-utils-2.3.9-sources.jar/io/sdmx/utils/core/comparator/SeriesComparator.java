package io.sdmx.utils.core.comparator;

import java.util.Comparator;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.SORT_ORDER;

public class SeriesComparator implements Comparator<String[]>, IFusionSingleton {
	private static SeriesComparator INSTANCE;
	private int mod;

	public SeriesComparator(SORT_ORDER order) {
		mod = order.equals(SORT_ORDER.ASCENDING) ? 1 : -1;
	}

	/**
	 * Returns a comparator in ASCENDING order
	 * @return
	 */
	public static SeriesComparator getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SeriesComparator(SORT_ORDER.ASCENDING);
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
	
	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public int compare(String[] o1, String[] o2) {
		if(o1.length > o2.length) {
			return 1 * mod;
		}
		if(o1.length < o2.length) {
			return -1 * mod;
		}
		for(int i=0; i < o1.length; i++) {
			int returnVal = o1[i].compareTo(o2[i]);
			if(returnVal != 0) {
				return returnVal * mod;
			}
		}
		return 0;
	}

}
