package io.sdmx.utils.core.xml;

import java.util.Stack;

import javax.xml.namespace.NamespaceContext;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class IndentingXMLStreamWriter implements XMLStreamWriter {
    private Object SEEN_CURRENT_OBJECT = new Object();
    private Object ELEMENT_SEEN = new Object();
    private Object DATA_SEEN = new Object();

    private Object currentStateOfObject = SEEN_CURRENT_OBJECT;
    private Stack<Object> stateStack = new Stack<>();

    private int depthOfIndent = 0;

    private String indentChar = "\n";

    private XMLStreamWriter writer;

    public IndentingXMLStreamWriter(XMLStreamWriter writer) {
    	this.writer = writer;
    }

    private void onStartElement() throws XMLStreamException {
        stateStack.push(ELEMENT_SEEN);
        currentStateOfObject = SEEN_CURRENT_OBJECT;
        if (depthOfIndent > 0) {
            this.writeCharacters(indentChar);
        }
        indent();
        depthOfIndent++;
    }

    private void onEndElement() throws XMLStreamException {
        depthOfIndent--;
        if (currentStateOfObject == ELEMENT_SEEN) {
            this.writeCharacters(indentChar);
            indent();
        }
        currentStateOfObject = stateStack.pop();
    }

    private void onEmptyElement() throws XMLStreamException {
        currentStateOfObject = ELEMENT_SEEN;
        if (depthOfIndent > 0) {
            this.writeCharacters(indentChar);
        }
        indent();
    }

    private void indent() throws XMLStreamException {
        if (depthOfIndent > 0) {
            for (int i = 0; i < depthOfIndent; i++) {
            	this.writeCharacters("  ");
            }
        }
    }


    @Override
    public void writeStartDocument() throws XMLStreamException {
        writer.writeStartDocument();
        this.writeCharacters(indentChar);
    }

    @Override
    public void writeStartDocument(String version) throws XMLStreamException {
    	writer.writeStartDocument(version);
        this.writeCharacters(indentChar);
    }

    @Override
    public void writeStartDocument(String encoding, String version) throws XMLStreamException {
    	writer.writeStartDocument(encoding, version);
        this.writeCharacters(indentChar);
    }

    @Override
    public void writeStartElement(String localName) throws XMLStreamException {
        onStartElement();
        writer.writeStartElement(localName);
    }

    @Override
    public void writeStartElement(String namespaceURI, String localName) throws XMLStreamException {
        onStartElement();
        writer.writeStartElement(namespaceURI, localName);
    }

    @Override
    public void writeStartElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
        onStartElement();
        writer.writeStartElement(prefix, localName, namespaceURI);
    }

    @Override
    public void writeEmptyElement(String namespaceURI, String localName) throws XMLStreamException {
        onEmptyElement();
        writer.writeEmptyElement(namespaceURI, localName);
    }

    @Override
    public void writeEmptyElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
        onEmptyElement();
        writer.writeEmptyElement(prefix, localName, namespaceURI);
    }

    @Override
    public void writeEmptyElement(String localName) throws XMLStreamException {
        onEmptyElement();
        writer.writeEmptyElement(localName);
    }

    @Override
    public void writeEndElement() throws XMLStreamException {
        onEndElement();
        writer.writeEndElement();
    }

    @Override
    public void writeCharacters(String text) throws XMLStreamException {
        currentStateOfObject = DATA_SEEN;
        writer.writeCharacters(text);
    }

    @Override
    public void writeCharacters(char[] text, int start, int len) throws XMLStreamException {
        currentStateOfObject = DATA_SEEN;
        writer.writeCharacters(text, start, len);
    }

    @Override
    public void writeCData(String data) throws XMLStreamException {
        currentStateOfObject = DATA_SEEN;
        writer.writeCData(data);
    }

	@Override
	public void writeEndDocument() throws XMLStreamException {
		writer.writeEndDocument();
	}

	@Override
	public void close() throws XMLStreamException {
		writer.close();

	}

	@Override
	public void flush() throws XMLStreamException {
		writer.flush();

	}

	@Override
	public void writeAttribute(String localName, String value) throws XMLStreamException {
		writer.writeAttribute(localName, value);

	}

	@Override
	public void writeAttribute(String prefix, String namespaceURI, String localName, String value) throws XMLStreamException {
		writer.writeAttribute(prefix, namespaceURI, localName, value);

	}

	@Override
	public void writeAttribute(String namespaceURI, String localName, String value) throws XMLStreamException {
		writer.writeAttribute(namespaceURI, localName, value);

	}

	@Override
	public void writeNamespace(String prefix, String namespaceURI) throws XMLStreamException {
		writer.writeNamespace(prefix, namespaceURI);

	}

	@Override
	public void writeDefaultNamespace(String namespaceURI) throws XMLStreamException {
		writer.writeDefaultNamespace(namespaceURI);

	}

	@Override
	public void writeComment(String data) throws XMLStreamException {
		writer.writeComment(data);

	}

	@Override
	public void writeProcessingInstruction(String target) throws XMLStreamException {
		writer.writeProcessingInstruction(target);

	}

	@Override
	public void writeProcessingInstruction(String target, String data) throws XMLStreamException {
		writer.writeProcessingInstruction(target, data);

	}

	@Override
	public void writeDTD(String dtd) throws XMLStreamException {
		writer.writeDTD(dtd);

	}

	@Override
	public void writeEntityRef(String name) throws XMLStreamException {
		writer.writeEntityRef(name);

	}

	@Override
	public String getPrefix(String uri) throws XMLStreamException {
		return writer.getPrefix(uri);
	}

	@Override
	public void setPrefix(String prefix, String uri) throws XMLStreamException {
		writer.setPrefix(prefix, uri);
	}

	@Override
	public void setDefaultNamespace(String uri) throws XMLStreamException {
		writer.setDefaultNamespace(uri);
	}

	@Override
	public void setNamespaceContext(NamespaceContext context) throws XMLStreamException {
		writer.setNamespaceContext(context);
	}

	@Override
	public NamespaceContext getNamespaceContext() {
		return writer.getNamespaceContext();
	}

	@Override
	public Object getProperty(String name) throws IllegalArgumentException {
		return writer.getProperty(name);
	}
}

