package io.sdmx.utils.core.timer;

import java.util.Date;

public class Stopwatch {
	private boolean isPaused;
	
	private Date statedDate;
	private Date stoppedDate;
	private long additionalDuration = 0;
	
	/**
	 * Creates and starts the stopwatch
	 */
	public Stopwatch() {
		start();
	}
	
	/**
	 * Starts the stop watch, if paused continues the count, otherwise clears off any old times
	 */
	public void start() {
		if(isPaused) {
			additionalDuration += getDuration();
			isPaused = false;
		} else {
			additionalDuration = 0;			
		}
		statedDate = new Date();
		stoppedDate = null;
		
	}
	
	public void stop() {
		stoppedDate = new Date();
	}
	
	/**
	 * Pauses the stopwatch
	 */
	public void pause() {
		isPaused = true;
		stoppedDate = new Date();
	}
	
	/**
	 * Returns the length of time the stop watch has been running for
	 */
	public long getDuration() {
		if(stoppedDate != null) {
			return stoppedDate.getTime() - statedDate.getTime() + additionalDuration;
		}
		return new Date().getTime() - statedDate.getTime() + additionalDuration;
	}
}
