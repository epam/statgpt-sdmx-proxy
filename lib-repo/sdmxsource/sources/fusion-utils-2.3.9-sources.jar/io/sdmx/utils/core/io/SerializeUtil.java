package io.sdmx.utils.core.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class SerializeUtil {
	
	public static <T extends Serializable> List<byte[]> serializeAsChunkedByteArray(T serializable, int chunkLength, boolean compress) {
		ByteArrayOutputStream serialized = serializeAsByteArray(serializable, compress);
		List<byte[]> byteList = new ArrayList<>();
    	splitBytes(byteList, serialized.toByteArray(), chunkLength, 0);
    	return byteList;
    }
    
	private static void splitBytes(List<byte[]> list, byte[] bytes, int chunkLength, int offset) {
    	int lengthTocopy;
    	if((bytes.length - offset) > chunkLength) {
    		lengthTocopy = chunkLength;
    	} else {
    		lengthTocopy = bytes.length - offset;
    	}
    	byte[] dest = new byte[lengthTocopy];
    	System.arraycopy(bytes, offset, dest, 0, lengthTocopy);
    	list.add(dest);
    	if((bytes.length - offset) > chunkLength) {
    		splitBytes(list, bytes, chunkLength, offset + lengthTocopy);
    	}
    }
    
    public static <T extends Serializable> T deSerializeChunkedByteArray(List<byte[]> buffer) {
    	int length = 0;
    	for(byte[] currentArray : buffer) {
    		length += currentArray.length;    		
    	}
    	byte[] merged = new byte[length];
    	length = 0;
    	for(byte[] currentArray : buffer) {
    		System.arraycopy(currentArray, 0, merged, length, currentArray.length);  	
    		length += currentArray.length;
    	}
    	InputStream is =  new ByteArrayInputStream(merged);
    	return deSerialize(is, false);
    }
    
    public static <T extends Serializable> void serializeToOutputStream(T serializable, OutputStream output) {
		ObjectOutputStream obj_out = null;
		try {
			obj_out = new ObjectOutputStream (output);
			obj_out.writeObject(serializable);
		} catch(Throwable th) {
			throw new RuntimeException(th);
		} finally {
			StreamUtil.closeStream(output);
			StreamUtil.closeStream(obj_out);
		}
	}
    
	public static <T extends Serializable> ByteArrayOutputStream serializeAsByteArray(T serializable, boolean compress) {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		if(compress) {
			GZIPOutputStream zipOut;
			try {
				zipOut = new GZIPOutputStream(output);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			serializeToOutputStream(serializable, zipOut);
		} else {
			serializeToOutputStream(serializable, output);
		}
		return output;
	}

	public static <T extends Serializable> void serialize(URI filelocation, T serializable) {
		File f = URIUtil.getFile(filelocation);
		SerializeUtil.serialize(f, serializable);
	}
	
	public static <T extends Serializable> void serialize(String fileName, T serializable) {
		SerializeUtil.serialize(new File(fileName), serializable);
	}
	
	public static <T extends Serializable> void serialize(File f, T Serializable) {
		FileOutputStream f_out = null;
		ObjectOutputStream obj_out = null;
		try {
			if(f.exists()) {
				f.delete();
			}
			f.createNewFile();
			
			f_out = new FileOutputStream (f);
			obj_out = new ObjectOutputStream (f_out);
			obj_out.writeObject(Serializable);
		} catch(Throwable th) {
			System.out.println(th);
		} finally {
			StreamUtil.closeStream(f_out);
			StreamUtil.closeStream(obj_out);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T deSerialize(InputStream inputStream, boolean unzip) {
		ObjectInputStream obj_in = null;
		try {
			if(unzip) {
				inputStream = new GZIPInputStream(inputStream);
			}
			
			// Read object using ObjectInputStream.
//			obj_in = new ObjectInputStream(inputStream);
			
			obj_in = new SingletonOIS(inputStream);

			// Read an object in
			Object obj = obj_in.readObject();

			return (T)obj;
				
		} catch(Throwable th) {
			throw new RuntimeException("Could not deserialize from stream", th);
		} finally {
			StreamUtil.closeStream(inputStream);
			StreamUtil.closeStream(obj_in);
		}	
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T deSerialize(String filePath) {
		FileInputStream f_in = null;
		ObjectInputStream obj_in = null;
		if(!FileUtil.exists(filePath)) {
			return null;
		}
		try {
			f_in = new FileInputStream (filePath);

			// Read object using ObjectInputStream.
			obj_in = new ObjectInputStream(f_in);

			// Read an object in
			Object obj = obj_in.readObject();

			return (T)obj;
				
		} catch(Throwable th) {
			throw new RuntimeException("Could not deserialize from file: " +filePath, th);
		} finally {
			StreamUtil.closeStream(f_in);
			StreamUtil.closeStream(obj_in);
		}		
	}
}
