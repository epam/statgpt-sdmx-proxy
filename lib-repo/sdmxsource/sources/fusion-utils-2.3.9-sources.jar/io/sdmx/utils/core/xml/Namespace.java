package io.sdmx.utils.core.xml;

public class Namespace {
	private String namespaceURL;
	private String namespacePrefix;

	public Namespace(String namespaceURL, String namespacePrefix) {
		this.namespaceURL = namespaceURL;
		this.namespacePrefix = namespacePrefix;
	}

	public String getNamespaceURL() {
		return namespaceURL;
	}

	public String getNamespacePrefix() {
		return namespacePrefix;
	}
	
	@Override
	public String toString() {
		return namespacePrefix+"="+namespaceURL;
	}
}
