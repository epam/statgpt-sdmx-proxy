package io.sdmx.utils.core.object;

import java.nio.charset.StandardCharsets;

import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;

/**
 * Convenience methods to wrap Google's Guava hashing methods. 
 * This can be faster than Java's built in hashing.
 * Secure hashes will use the SHA-512 (SHA-2) algorithm.
 * Fast insecure hashes will use the farm Hash Fingerprint hashing algorithm. (64-bit).
 */
public class HashUtils {
	
	private static HashFunction fastHasher = Hashing.farmHashFingerprint64();
	private static HashFunction secureHash = Hashing.sha512();
	
	/**
	 * Hash the specified String.
	 * @param toHash the String to hash
	 * @param secure if true, then this will use a cryptographically secure hashing algorithm. If false it will use a fast, non-secure algorithm.
	 * @return
	 */
	public static String hashString(String toHash, boolean secure) {
		return ObjectUtil.validString(toHash) ? hashBytes(toHash.getBytes(StandardCharsets.UTF_8), secure).toString(): "";
	}

	/**
	 * Hash bytes
	 * @param bytes
	 * @param secure if true, then this will use a cryptographically secure hashing algo. If false it will use a fast, non-secure algorithm.
	 * @return
	 */
	public static HashCode hashBytes(byte[] bytes, boolean secure) {
		return secure ? secureHash.hashBytes(bytes) : fastHasher.hashBytes(bytes);
	}
}
