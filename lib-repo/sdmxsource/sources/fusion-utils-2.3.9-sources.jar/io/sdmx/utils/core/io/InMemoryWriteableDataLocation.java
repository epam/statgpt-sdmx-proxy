package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;

public class InMemoryWriteableDataLocation extends AbstractReadableDataLocation implements WriteableDataLocation {
    private static final long serialVersionUID = 1L;
    private ByteArrayOutputStream out;
    private GZIPOutputStream gzipstream;

    public InMemoryWriteableDataLocation(boolean gzip) {
        out = new ByteArrayOutputStream();
        if(gzip) {
            try {
                gzipstream = new GZIPOutputStream(new BufferedOutputStream(out));
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        }
    }

    private InMemoryWriteableDataLocation(byte[] out, boolean gzip) {
        this.out = new ByteArrayOutputStream();
        try {
            this.out.write(out);
            if(gzip) {
                gzipstream = new GZIPOutputStream(new BufferedOutputStream(this.out));
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public byte[] toByteArray() {
        if(gzipstream != null) {
            try {
                gzipstream.flush();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return out.toByteArray();
    }

    @Override
    protected long calculateSize() {
        return out.size();
    }

    @Override
    protected void closeInternal() {
        out = null;
    }

    @Override
    protected InputStream getStreamInternal() throws IOException {
        InputStream is = new BufferedInputStream(new ByteArrayInputStream(toByteArray()));
        if(gzipstream != null) {
            try {
                return new GZIPInputStream(is);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return is;
    }

    @Override
    public String getName() {
        return null;
    }


    @Override
    public ReadableDataLocation copy() {
        return new InMemoryWriteableDataLocation(toByteArray(), gzipstream != null);
    }

    @Override
    public OutputStream getOutputStream() {
        if(gzipstream != null) {
            return gzipstream;
        }
        return new BufferedOutputStream(out);
    }

}
