package io.sdmx.utils.core.date;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.date.PeriodContents;

/**
 * Used to store Sets of objects against a period, default copy and merge methods provided
 * @param <T>
 */
public class PeriodObjectContents<T> extends PeriodContentsImpl<Set<T>> {

	public PeriodObjectContents() {
		super(new HashSet<T>());
	}
	
	public PeriodObjectContents(Set<T> initialContents) {
		super(new HashSet<>(initialContents));
	}

	@Override
	/**
	 * Creates a copy of the underlying set to construct a new instnace
	 */
	public PeriodContents<Set<T>> copy() {
		return new PeriodObjectContents<>(getContents());
	}

	@Override
	/**
	 * Performs a set merge
	 */
	public void merge(Set<T> newContents) {
		if(newContents != null) {
			getContents().addAll(newContents);
		}
	}

}
