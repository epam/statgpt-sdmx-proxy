package io.sdmx.utils.core.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;

public class GzipReadableDataLocation extends AbstractReadableDataLocation {
	private static final long serialVersionUID = 1L;

	protected GzipReadableDataLocation() {}

	public GzipReadableDataLocation(ReadableDataLocation rdl) {
		super(rdl);
	}

	public GzipReadableDataLocation(File f) {
		super(new ReadableDataLocationTmp(f));
	}
	
	@Override
	public FILE_FORMAT getFormat() {
		return FILE_FORMAT.GZIP;
	}

	@Override
	public String getName() {
		return getProxy().getName();
	}
	
	@Override
	protected InputStream getStreamInternal() throws IOException {
		return new GZIPInputStream(getProxy().getInputStream());
	}

	@Override
	protected void closeInternal() {}

	@Override
	public ReadableDataLocation copy() {
		return new GzipReadableDataLocation(getProxy());
	}

    @Override
    protected long calculateSize() {
        DummyOutputStream dout = DummyOutputStream.INSTANCE;
        InputStream in = getInputStream();
        try {
            return StreamUtil.copyStream(in, dout);
        } finally {
            StreamUtil.closeStream(in);
        }
    }

}
