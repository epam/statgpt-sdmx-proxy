package io.sdmx.utils.core.image;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.imageio.ImageIO;

/**
 * Represents an image based from a base 64 string.
 * Internally creates a BufferedImage storing the base 64 string.
 */
public class FusionImage {
	private BufferedImage image;
	private String base64Str;

	public FusionImage(String base64Str) throws IOException {
		if (base64Str == null) {
			throw new RuntimeException("base 64 string cannot be null");
		}
		this.base64Str = base64Str;
		String imageData = this.getPureBase64String();
		byte[] imageBytes = Base64.getDecoder().decode(imageData.getBytes("UTF8"));
		String imageFormat = this.getImageFormat();
		String[] validImageTypes = validFileTypes();
		boolean supported = false;
		for (int i = 0; i < validImageTypes.length; i++) {
			String currFormat = validImageTypes[i];
			if (imageFormat.equals(currFormat)) {
				supported = true;
				break;
			}
		}
		if (supported == false) {
			throw new RuntimeException("Image is unsupported");
		}
		ByteArrayInputStream stream = new ByteArrayInputStream(imageBytes);
		this.image = ImageIO.read(stream);
	}

	/**
	 * Returns the supported file types allowed by this class.
	 * @return a string array of supported file types
	 */
	public static String[] validFileTypes() {
		return ImageIO.getReaderFileSuffixes();
	}

	/**
	 * @return the image height in px
	 */
	public int getImageHeight() {
		return this.image.getHeight();
	}

	/**
	 * @return the image width in px
	 */
	public int getImageWidth() {
		return this.image.getWidth();
	}

	/**
	 * Returns the MIME type from the base 64 string.
	 * For example: 'data:image/png;base64'
	 *
	 * @return the MIME type
	 */
	public String getMimeType() {
		return this.base64Str.split(",")[0];
	}

	/**
	 * Return the pure base 64 string (without the MIME)
	 *
	 * @return the base 64 string
	 */
	public String getPureBase64String() {
		return this.base64Str.substring(base64Str.indexOf(",") + 1);
	}

	/**
	 * @return the image format
	 */
	public String getImageFormat() {
		String splitMimeType = this.getMimeType().split("/")[1];
		String type = splitMimeType.split(";")[0];
		if(type.equals("x-icon")) {
			return "ico";
		}
		return type;
	}

	/**
	 * @return the internal BufferedImage
	 */
	public BufferedImage getBufferedImage() {
		return this.image;
	}

	/**
	 * @return the whole base 64 string with MIME
	 */
	public String getBase64String() {
		return this.base64Str;
	}

	/**
	 * Returns the base 64 size in bytes. This is NOT the image size, as encoding an
	 * image in B64 makes it larger. This is the size that will be stored in the
	 * database.
	 *
	 * @return the base 64 size in bytes
	 */
	public long getBase64Size() {
		byte[] imageBytes = this.base64Str.getBytes(StandardCharsets.UTF_8);
		return imageBytes.length;
	}

	/**
	 * Returns the real file size with image file size compression taken into consideration.
	 * @return the file size in bytes
	 * @throws IOException
	 */
	public long getFileSize() throws IOException{
		ByteArrayOutputStream tmp = new ByteArrayOutputStream();
		ImageIO.write(this.image, this.getImageFormat(), tmp);
		tmp.close();
		long contentLength = tmp.size();
		return contentLength;
	}

}