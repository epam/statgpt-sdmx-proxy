package io.sdmx.utils.core.object;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.utils.core.collection.KeyValueImpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MeasureUtil {

	/**
	 * @param measureValues measure id to measure value
	 * @return measure values formatted as numbers. null value to represent not numerical
	 */
	public static Map<String, List<BigDecimal>> toBigDecimal(List<KeyValue> measures) {
		Map<String, List<BigDecimal>> returnMap = new HashMap<>(measures.size());
		for(KeyValue measure : measures) {
			List<BigDecimal> measureValues = new ArrayList<>();
			if(measure.hasMultipleValues()){
				for(String value : measure.getValues()){
					if(NumberUtils.isParsable(value)){
						BigDecimal parsed = null;
						try{
							measureValues.add(new BigDecimal(value));

						}catch(Throwable th){}
					}
				}
			} else{
				try{
					measureValues.add(new BigDecimal(measure.getCode()));
				}catch (Throwable th){}

			}
			returnMap.put(measure.getConcept(), measureValues);
		}
		return returnMap;
	}
	
	/**
	 * @param measureValues measure id to measure value
	 * @return measure values formatted as numbers back to string
	 */
	public static Map<String, String> toString(Map<String, BigDecimal> numericalMeasures, Map<String, String> measureValues, String replaceMissing) {
		Map<String, String> returnMap = new HashMap<>(numericalMeasures.size());
		for(String numericalMeasure : numericalMeasures.keySet()) {
			BigDecimal value = numericalMeasures.get(numericalMeasure);
			String asString = null;
			if(value != null) {
				asString = value.toPlainString();
			} else if(measureValues != null){
				asString = measureValues.get(numericalMeasure);
			}
			if(value == null) {
				asString = replaceMissing;
			} 
			returnMap.put(numericalMeasure, asString);
		}
		if(measureValues != null) {
			for(String measureId : measureValues.keySet()) {
				if(!returnMap.containsKey(measureId)) {
					returnMap.put(measureId, measureValues.get(measureId));
				}
			}
		}
		return returnMap;
	}
	
}
