package io.sdmx.utils.core.io;

import java.io.IOException;
import java.io.OutputStream;

/**
 *  Proxy on an output stream, this stream does not pass on the close or flush command. To fix issue with null pointer
 *  in Tomcat InputOutputBuffer where a flush is called on the output stream
 *  http://tomcat.10.x6.nabble.com/DO-NOT-REPLY-Bug-35798-New-Null-Pointer-Exception-in-InternalOutputBuffer-td2180551.html
 *
 */
public class UncloseableOutputStream extends OutputStream {

	private OutputStream out;
	
	
	public UncloseableOutputStream(OutputStream out) {
		this.out = out;
	}

	@Override
	public void write(byte[] b) throws IOException {
		out.write(b);
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		out.write(b, off, len);
	}

	@Override
	public void write(int b) throws IOException {
		out.write(b);
	}

	@Override
	public void close() throws IOException {}

	@Override
	public void flush() throws IOException {}
	
	
	/**
	 * Actually close the stream
	 */
	public void forceClose() {
		StreamUtil.closeStream(out);
	}

}
