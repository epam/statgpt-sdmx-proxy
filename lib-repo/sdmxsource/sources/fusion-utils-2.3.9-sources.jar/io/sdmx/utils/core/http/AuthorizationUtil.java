package io.sdmx.utils.core.http;

import java.util.Base64;

import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;

public class AuthorizationUtil {

	/**
	 * Returns a Basic Authorization Header value for user credentials
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public static String createAuthorizationHeader(String username, String password) {
		String source = username + ":" + password;
		String ret = "Basic " + Base64.getEncoder().encodeToString(source.getBytes());
		return ret;
	}

	public static void storeAuthorizationInThreadLocal(String username, String password) {
		ThreadLocalUtil.storeOnThread("Authorization", createAuthorizationHeader(username, password));
	}

	public static void storeCertificateAuthorizationInThreadLocal(byte[] certiciate, String password) {
		ThreadLocalUtil.storeOnThread("P12Certificate", certiciate);
		ThreadLocalUtil.storeOnThread("P12CertificatePassword", password);
	}

	public static void storeAuthorizationInThreadLocal(String username, String password, String forwardedFor) {
		storeAuthorizationInThreadLocal(username, password);
		if (ObjectUtil.validString(forwardedFor)) {
			ThreadLocalUtil.storeOnThread("X-Forwarded-For", forwardedFor);
		}
	}

	public static void clearAuthorizationFromThreadLocal() {
		ThreadLocalUtil.clearFromThread("P12Certificate");
		ThreadLocalUtil.clearFromThread("P12CertificatePassword");
		ThreadLocalUtil.clearFromThread("Authorization");
		ThreadLocalUtil.clearFromThread("X-Forwarded-For");
	}
}
