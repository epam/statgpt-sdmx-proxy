package io.sdmx.utils.core.format;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Breaks an application/vnd. header into its parts.  
 * <p/>
 * <b>Example:</b><br/>
 * <i>application/vnd.sdmx.genericdata+xml;version=2.1</i>
 * <p/>
 * <b>Becomes:</b><br/>
 * <i>vnd=sdmx.genericdata+xml</i><br/>
 * <i>version=2.1</i>  
 * <p/>
 * Where version is a parameter and 2.1 is the parameter value
 * 
 */
public class VNDHeader implements IVNDHeader  {
	private static final String VND_HEADER = "application/vnd.";
	private String applicationVnd;
	private String vnd;
	private Map<String, String> parameters = new HashMap<>();

	/**
	 * Builds the VND header starting with application/vnd. or with this prefix removed
	 */
	public VNDHeader(String applicationVnd) {
		if(!ObjectUtil.validString(applicationVnd)) {
			throw new SdmxException("VNDHEader can not be created with empty argument");
		}
		this.applicationVnd = applicationVnd;
		if(applicationVnd.startsWith(VND_HEADER)) {
			applicationVnd = applicationVnd.substring(VND_HEADER.length());
		}
		String[] split = applicationVnd.split(";");
		vnd = split[0];
		for(String currentSplit : split) {
			String[] vals = currentSplit.split("=");
			if(vals.length == 2) {
			    if (vals[0] != null) {
			        vals[0] = vals[0].trim();
			    }
			    parameters.put(vals[0], vals[1]);
			}
		}
		Collections.unmodifiableMap(parameters);
	}
	
	public String getOriginalVND() {
		return applicationVnd;
	}

	public boolean hasParameter(String parameter) {
		return parameters.containsKey(parameter);
	}
	
	public String getParameterValue(String parameter) {
		return parameters.get(parameter);
	}
	
	public String getVnd() {
		return vnd;
	}
}
