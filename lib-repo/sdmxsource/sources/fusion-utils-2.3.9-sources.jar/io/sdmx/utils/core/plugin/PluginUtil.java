package io.sdmx.utils.core.plugin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.github.classgraph.ClassGraph;
import io.github.classgraph.ScanResult;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Allows extra classes to be scanned and inserted into the system, such as extra Data Validators.
 */
public class PluginUtil {

	private static final Logger LOG = LoggerFactory.getLogger(PluginUtil.class);

	/**
	 * Searches the specified package name and creates an instance of all classes found.
	 * All classes are registered in the FusionBeanStore.
	 * @param packageToScan The dot separated Java package name of the package to scan
	 */
	public static void loadPlugins(String packageToScan) {
		LOG.debug("Scanning for package: " + packageToScan);
		if (packageToScan == null) {
			return;
		}

		long startTime = System.currentTimeMillis();
        try (ScanResult scanResult = new ClassGraph().enableClassInfo().scan()) {
            scanResult.getAllClasses().forEach(classInfo -> {
                if (classInfo.getPackageName().equals(packageToScan)) {
                	LOG.info("Encountered class: " + classInfo.getName());
                    Class<?> clazz = classInfo.loadClass();
                    try {
                    	Object instance = clazz.newInstance();
                    	FusionBeanStore.registerInstance(instance);
                    	LOG.info("Successfully registered: " + clazz.getName());
                    } catch (Exception e) {
                    	LOG.error("Unable to instantiate: " + clazz.getName(), e);
                    }
                }
            });
        }
        long endTime = System.currentTimeMillis();
        if (LOG.isDebugEnabled()) {
        	LOG.debug("Scan time took: " + (endTime - startTime) );
        }
	}

}
