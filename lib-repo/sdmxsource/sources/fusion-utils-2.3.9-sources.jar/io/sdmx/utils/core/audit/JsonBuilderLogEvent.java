package io.sdmx.utils.core.audit;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.logging.IFusionLogEvent;

public class JsonBuilderLogEvent {

	/**
	 * Builds an audit event as a JSONArray
	 * @param auditLogs
	 * @return
	 * 
	 * <pre>
	 * 
	 * 		[
	 * 			{
	 * 				"AuditId" : "auditId",
					"Level"   : 1,
					"Logger"  : "loggerName",
					"Message" : "message",
					"Thread"  : "threadName",
					"LogTime" : 1234,
					"Expires" : 1234
	 * 			}
	 * 			...
	 * 		]
	 * 
	 * </pre>
	 * 
	 */
	public static JSONArray build(List<IFusionLogEvent> auditLogs) {
		JSONArray json = new JSONArray();
		if(auditLogs != null) {
			for(IFusionLogEvent logEvent : auditLogs) {
				json.put(logEvent.getJson());
			}
		}
		return json;
	}
	
	/**
	 * Builds a JSONObject representing the contents of a LoggedProcess
	 * @param loggedProcess
	 * @return
	 * 
	 * <pre>
	 * {
	 *   "success": true,
	 *   "messages": [{
	 *    "AuditId":"697e8a48-2443-49c4-9e7c-63c5dd780dcb",
	 *    "Level":4,
	 *    "Logger":"ROOT",
	 *    "Message":"process failed",
	 *    "Thread":"http-nio-8080-exec-8",
	 *    "LogTime":1716291294160}
	 *    }]
	 * }
	 * 
	 * </pre>
	 * 
	 */
	public static JSONObject build(LoggedProcess loggedProcess) {
		JSONObject json = new JSONObject();
		try {
			json.put("success", loggedProcess.isSuccess());
			JSONArray ja = new JSONArray();
			if(loggedProcess.getLogEvents() != null) {
				for(IFusionLogEvent logEvent : loggedProcess.getLogEvents()) {
					ja.put(logEvent.getJson());
				}
			}
			json.put("messages", ja);
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
		return json;
	}

}
