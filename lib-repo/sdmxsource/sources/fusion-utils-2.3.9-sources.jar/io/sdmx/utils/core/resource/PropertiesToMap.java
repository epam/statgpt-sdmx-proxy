package io.sdmx.utils.core.resource;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PropertiesToMap {

	/**
	 * Creates a Map of key value paris from a Properties object
	 * @param properties
	 * @return
	 */
	public static Map<String, String> createMap(Properties properties) {
		Map<String, String> returnMap = new HashMap<>();
		for(Object currentKey : properties.keySet()) {
			if(currentKey instanceof String) {
				String key = (String) currentKey;
				returnMap.put(key, properties.getProperty(key));
			}
		}
		return returnMap;
	}
	
}
