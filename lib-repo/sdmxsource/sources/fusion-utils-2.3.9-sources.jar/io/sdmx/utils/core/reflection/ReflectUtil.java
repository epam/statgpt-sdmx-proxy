package io.sdmx.utils.core.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class ReflectUtil<T> {

	public Set<T> getCompositeObjects(Class referencedClass, Object o, Method... ignoreMethods) {
		Set<T> returnSet = new HashSet<>();
		try {
			for(Method currentMethod : o.getClass().getMethods()) {
				Class returnClass = currentMethod.getReturnType();
				if(!contains(currentMethod, ignoreMethods) && isGetter(currentMethod)) {
					if(Collection.class.isAssignableFrom(returnClass)) {
						Type returnType = currentMethod.getGenericReturnType();
						if(returnType instanceof ParameterizedType){
						    ParameterizedType type = (ParameterizedType) returnType;
						    Type[] typeArguments = type.getActualTypeArguments();
						    for(Type typeArgument : typeArguments){
						    	if(typeArgument instanceof Class) {
						    		Class typeArgClass = (Class) typeArgument;
						    		if(referencedClass.isAssignableFrom(typeArgClass)) {
						    			Collection<T> colection = (Collection<T>)currentMethod.invoke(o);
						    			if(colection != null) {
						    				returnSet.addAll(colection);
						    			}
						    			break;
						    		}
						    	} else if(typeArgument instanceof TypeVariable){
						    		TypeVariable typeVariable = (TypeVariable)typeArgument;
						    		if(typeVariable.getGenericDeclaration() instanceof Class) {
						    			Class typeArgClass = (Class) typeVariable.getGenericDeclaration();
						    			if(referencedClass.isAssignableFrom(typeArgClass)) {
							    			Collection<T> colection = (Collection<T>)currentMethod.invoke(o);
							    			if(colection != null) {
							    				returnSet.addAll(colection);
							    			}
							    			break;
							    		}
						    		}
						    	}
						    }
						}
					} else {
						 if(referencedClass.isAssignableFrom(returnClass)) {
							 T claz = (T)currentMethod.invoke(o);
							 if(claz != null) {
								 returnSet.add(claz);
							 }
						 }
					}
				}
			}
		} catch(InvocationTargetException e) {
			throw new RuntimeException(e);
		} catch(IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		return returnSet;
	}
	
	private boolean contains(Method mthd, Method[] mds) {
		if(mds == null) {
			return false;
		}
		for(Method currentMethod : mds) {
			if(currentMethod.getName().equals(mthd.getName())) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isGetter(Method method){
		  if(!method.getName().startsWith("get"))      return false;
		  if(method.getParameterTypes().length != 0)   return false;  
		  if(void.class.equals(method.getReturnType())) return false;
		  return true;
	}
}
