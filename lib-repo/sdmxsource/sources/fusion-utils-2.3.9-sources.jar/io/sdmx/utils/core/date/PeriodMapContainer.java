package io.sdmx.utils.core.date;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.PeriodContents;

/**
 * A container for a map of contents
 */
public class PeriodMapContainer<K, V> extends PeriodContentsImpl<Map<K, Set<V>>> {
	private boolean unionOnly;  
	
	public PeriodMapContainer(boolean unionOnly) {
		this(new HashMap<>(), unionOnly);
	}
	
	private PeriodMapContainer(Map<K, Set<V>> mappedValuesForPeriod, boolean unionOnly) {
		super(mappedValuesForPeriod);
		this.unionOnly = unionOnly;
	}

	@Override
	public PeriodContents<Map<K, Set<V>>> copy() {
		Map<K, Set<V>> copy = new HashMap<>();
		for(K key : getContents().keySet()) {
			copy.put(key, new HashSet<>(getContents().get(key)));
		}
		return new PeriodMapContainer<>(copy, unionOnly);
	}

	@Override
	public void merge(Map<K, Set<V>> newContents) {
		if(newContents != null) {
			performIntersection(getContents(), newContents);
		}
	}
	
	/**
	 * map1 is modified to contain the union and intersection of map2
	 * union (where map2 contains a concept not contained in map1, map1 is appended with all the values for this concept)
	 * intersection (where map2 and map1 contain the same concept, the values on map 1 is restricted to those defined in map2)
	 *
	 * @param map1
	 * @param map2
	 */
	private void performIntersection(Map<K, Set<V>> map1, Map<K, Set<V>> map2) {
		for(K key : map2.keySet()) {
			if(map1.containsKey(key)) {
				Set<V> values = map1.get(key);
				if(unionOnly) {
					values.addAll(map2.get(key));
				} else {
					values.retainAll(map2.get(key));
				}
			} else {
				map1.put(key, map2.get(key));
			}
			map1.get(key).remove(null); //remove nulls
		}
	}
}
