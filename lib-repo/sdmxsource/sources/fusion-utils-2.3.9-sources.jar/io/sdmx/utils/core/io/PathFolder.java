package io.sdmx.utils.core.io;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * A folder which contains zero to many folders and zero to many files
 */
public class PathFolder {
	private Path folder;
	private Map<String, PathFolder> subfolders = new HashMap<>();

	private List<Path> files = new ArrayList<>();

	/**
	 * @param folder to build the object from
	 * @param updatedSince only include files updated since this timestamp, null to indicate include all files
	 */
	public PathFolder(Path folder, Long updatedSince, boolean includeEmptyFolders) {
		this.folder = folder;
		if(Files.exists(folder)) {
			try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
				for (Path path : stream) {
					if (Files.isDirectory(path)) {
						PathFolder subfolder = new PathFolder(path, updatedSince, includeEmptyFolders);
						if(subfolder.files.size() > 0 || subfolder.subfolders.size() > 0 ||( subfolder.files.size() == 0 && includeEmptyFolders)) {
							this.subfolders.put(subfolder.getFolderName(), subfolder);
						}
					} else {
						if(updatedSince != null) {
							Long lastModified = PathUtil.getModifiedTime(path);
							if(lastModified != null && lastModified < updatedSince) {
								continue;
							}
						}
						files.add(path);
					}
				}
			} catch (IOException e) {
				throw new RuntimeException("Error reading folder: "+getFolderName(), e);
			}
		}
		this.subfolders = Collections.unmodifiableMap(this.subfolders);
		this.files = Collections.unmodifiableList(this.files);
	}
	
	public Set<String> getFileNames() {
		return getFiles().stream().map(e->e.getFileName().toString()).collect(Collectors.toSet());
	}

	public Path getFolder() {
		return folder;
	}

	public String getFolderName() {
		return folder.getFileName().toString();
	}

	public Set<String> getSubfolderNames() {
		return subfolders.keySet();
	}

	public PathFolder getSubfolder(String folderName) {
		return subfolders.get(folderName);
	}

	public Collection<PathFolder> getSubfolders() {
		return subfolders.values();
	}

	public List<Path> getFiles() {
		return files;
	}

	public void deleteContents(boolean includeFolder) {
		for(PathFolder folder : getSubfolders()) {
			folder.deleteContents(true);
		}
		for(Path file : files) {
			try {
				Files.deleteIfExists(file);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		if(includeFolder) {
			try {
				Files.deleteIfExists(this.folder);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Keeps only the paths passed in, delete all others not in the list
	 * If a path is a folder, the entire folder is kept, otherwise folders are only deleted
	 * if they have no contents
	 * 
	 * @param paths
	 */
	public void keep(Set<Path> paths) {
		for(PathFolder folder : getSubfolders()) {
			if(!paths.contains(folder.getFolder())) {
				folder.keep(paths);
			}
		}
		List<Path> newFiles = new ArrayList<>();
		for(Path file : files) {
			if(!paths.contains(file)) {
				try {
					Files.deleteIfExists(file);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			} else {
				newFiles.add(file);
			}
		}
		this.files = newFiles;
		if(this.files.size() == 0 && this.subfolders.size() == 0) {
			try {
				Files.deleteIfExists(this.folder);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
}
