package io.sdmx.utils.core.resource;

import java.io.InputStream;

public class SystemUtil {
	
	public static String lineSeparator() {
		return System.getProperty("line.separator");
	}
	
	public static InputStream loadClasspathFile(String fileName) { 
		// Ensure that the properties file exists since the application depends on it
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		return classLoader.getResourceAsStream(fileName);
	}
}
