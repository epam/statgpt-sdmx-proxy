package io.sdmx.utils.core.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.io.Files;

import io.sdmx.utils.core.logging.LoggingUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class URIUtil  {
	//SAME FOR ALL INSTANCES
	private static final Logger LOG = LoggerFactory.getLogger(URIUtil.class);
	private static URIUtil TEMPORARY_URI_UTIL = new URIUtil("resources/streams/tmp", "tmpFile", 1440000, true); //DELETE FILES ONE DAY OLD
	private static Set<String> uris = Collections.synchronizedSet(new HashSet<String>());

	private static Map<URI, List<OutputStream>> outputstreamMap = new HashMap<>();
	private static Map<URI, List<InputStream>> inputstreamMap = new HashMap<>();

	//INSTANCE SPECIFIC
	private String fileBaseName = "tmp_file.";
	//	private String uriDirectory = "resources/streams/tmp";
	//	private ScheduledTimerTask task;
	//	private long deleteFilesOlderThen;
	//	private boolean overwright = false;

	/**
	 * Creates a formatted string to be used for a URI
	 * @param input
	 * @return
	 */
	public static String formatStringForURI(String input) {
		return input.replaceAll(" ", "%20").replaceAll("\\\\", "/");
	}
	/**
	 * Returns a URIUtil class which creates temporary URI locations for storing files.
	 * <p/>
	 * Files which have been created through this which have not been modified for 24 hours, are deleted.
	 * @return
	 */
	public static URIUtil getURIUtil() {
		return TEMPORARY_URI_UTIL;

	}

	/**
	 * Returns a URI which will be deleted after a period of inactivity.
	 * URIs obtained through this method which have not been modified within a 24 hours period will be deleted.
	 * @return a URI
	 */
	public static URI getTemporaryURI() {
		URI uri = TEMPORARY_URI_UTIL.getUri();
		return uri;
	}

	public static URIUtil getURIUtil(String directoryName, String fileBaseName, boolean overwrite) {
		return new URIUtil(directoryName, fileBaseName, 0, overwrite);
	}

	private URIUtil(String uriDirectory, String fileBaseName, long deleteFilesOlderThen, boolean overwright) {
		//		this.deleteFilesOlderThen = deleteFilesOlderThen;
		//		if(deleteFilesOlderThen > 0) {
		//			task = new ScheduledTimerTask();
		//			task.setDelay(deleteFilesOlderThen / 2);
		//			task.setPeriod(deleteFilesOlderThen);
		//			task.setRunnable(new FileDeleter());
		//		}
		//		this.uriDirectory = uriDirectory;
		this.fileBaseName = fileBaseName;
		//		this.overwright = overwright;
	}

	public static void closeUri(URI uri) {
		if(uri != null) {
		    if(LOG.isDebugEnabled()) {
		        LOG.debug("Close URI: "+uri);
		    }
			uris.remove(uri.toString());
		}
	}

	public static String getFullPath(URI uri) {
		File file = new File(uri.getPath());
		return file.getAbsolutePath();
	}

	public static boolean deleteUri(URI uri) {
		if(uri == null) {
			return false;
		}
		closeStreams(uri);
		File file = new File(uri.getPath());
		boolean deleted = file.delete();
		if(LOG.isDebugEnabled()) {
            LOG.debug("Delete URI ("+deleted+"): "+uri);
        }
		/*
		 * DEBUG Code useful for when tracking down issues
		 */
		//		if(!deleted) {
		//			Throwable t = new Throwable();
		//			StackTraceElement[] elements = t.getStackTrace();

		//			String callerMethodName = elements[1].getMethodName();
		//			String callerClassName = elements[1].getClassName();
		//			LoggingUtil.error(log, "file not deleted: " + uri.getPath());
		//			LoggingUtil.error(log, "DELETE FILE FAILED CALLED FROM [CLASS, METHOD, METHOD NAME]:" + callerClassName + ", " + callerMethodName);
		//			throw new RuntimeException("Unable to delete file : " + uri.getPath());
		//		}
		closeUri(uri);
		return deleted;
	}

	public static void closeStreams(URI uri) {
		if(outputstreamMap.containsKey(uri)) {
			for(OutputStream out : outputstreamMap.get(uri)) {
				StreamUtil.closeStream(out);
			}
		}
		if(inputstreamMap.containsKey(uri)) {
			for(InputStream in : inputstreamMap.get(uri)) {
				StreamUtil.closeStream(in);
			}
		}
		outputstreamMap.remove(uri);
		inputstreamMap.remove(uri);
	}

	public static void copyURIs(URI uriIn, URI uriOut) {
	    File f = URIUtil.getFile(uriIn);
        try {
            Files.copy(f, URIUtil.getFile(uriOut));
        } catch (IOException e) {
            try ( InputStream fis = new FileInputStream(uriIn.getPath());
                    OutputStream fos = new FileOutputStream(uriOut.getPath()) ) {
                  StreamUtil.copyStream(fis, fos, true);
              } catch (Throwable th) {
                  throw new RuntimeException(th);
              }
        }
	}

	public static InputStream getInputStream(URI uri) {
		String filePath;
		InputStream stream;
		try {
			URL url = uri.toURL();
			stream = URLUtil.getInputStream(url);
		} catch(Throwable th) {
			if(ObjectUtil.validString(uri.getPath())) {
				filePath = uri.getPath();
			} else {
				filePath = uri.getSchemeSpecificPart();
			}
			try {
				stream =  new BufferedInputStream(new FileInputStream(filePath));
			} catch(FileNotFoundException e) {
				try {
					stream = URIUtil.class.getClassLoader().getResourceAsStream(filePath);
				} catch (Exception e1) {
					throw new RuntimeException("Could not load resource: " +filePath);
				}
			}
		}
		storeStream(uri, stream);
		return stream;
	}

	private static void storeStream(URI uri, InputStream stream) {
		List<InputStream> streams = null;
		if(inputstreamMap.containsKey(uri)) {
			streams = inputstreamMap.get(uri);
		} else {
			streams = new ArrayList<>();
			inputstreamMap.put(uri, streams);
		}
		streams.add(stream);
	}

	public static OutputStream getOutputStream(URI uri) {
	    OutputStream fos = null;
		try {
		    fos = new FileOutputStream(uri.getPath(), true);
			OutputStream out = new BufferedOutputStream(fos);
			List<OutputStream> streams = null;
			if(outputstreamMap.containsKey(uri)) {
				streams = outputstreamMap.get(uri);
			} else {
				streams = new ArrayList<>();
				outputstreamMap.put(uri, streams);
			}
			streams.add(out);
			return out;
		} catch (Exception e) {
		    if (fos != null) {
		        StreamUtil.closeStream(fos);
		    }
			throw new RuntimeException(e);
		}
	}

	public synchronized URI getUri() {
		try {
			File f = FileUtil.createTemporaryFile(fileBaseName, "sdmxsource_tmp");

			URI uri = f.toURI();

			if (!uris.contains(uri.toString())) {
				uris.add(uri.toString());
			}

			if (LOG.isDebugEnabled()) {
				Throwable t = new Throwable();
				StackTraceElement[] elements = t.getStackTrace();

				String callerMethodName = null;
				String callerClassName = null;
				for(int x = 0; x < elements.length ; x++) {
					callerMethodName = elements[x].getMethodName();
					callerClassName = elements[x].getClassName();
					if(!callerClassName.equals(URIUtil.class.getName())) {
						break;
					}
				}

				LoggingUtil.debug(LOG, "getTemporaryURI request from (class.method)" + callerClassName +"."+ callerMethodName);
				LoggingUtil.debug(LOG, "URI created " + uri.getPath());
			}

			return uri;
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	public static byte[] getByteArray(URI uri) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		StreamUtil.copyStream(getInputStream(uri), bos);
		return bos.toByteArray();
	}

	/**
	 * Copies the byte array into the returned URI
	 * @param stream
	 * @return
	 */
	public URI getUri(byte[] bytes) {
		URI uri = getUri();
		try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(uri.getPath()))) {
			bos.write(bytes, 0, bytes.length);
		} catch (Throwable th) {
			throw new RuntimeException(th);
		}
		return uri;
	}

	/**
	 * Copies the input stream into a temporary file location that can be discovered with the returned URI
	 * @param stream
	 * @return
	 */
	public URI getUri(InputStream stream) {
	    URI uri = getUri();
        try {
            StreamUtil.copyStream(stream, new BufferedOutputStream(new FileOutputStream(uri.getPath())), true );
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        return uri;
	}

	public static File getFile(URI uri) {
		return new File(uri.getPath());
	}
}

