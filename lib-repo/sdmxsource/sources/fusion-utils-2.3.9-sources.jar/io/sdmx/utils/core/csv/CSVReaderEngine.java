package io.sdmx.utils.core.csv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.opencsv.CSVParser;

import io.sdmx.api.csv.CellReaderEngine;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xlsx.ExcelUtil;

/**
 * Used to read a CSV structure file.
 * Note that these CSV files are created from Excel.
 */
public class CSVReaderEngine implements CellReaderEngine {
	private int sheetIndex = -1;
	private int rowIndex = -1;
	private int cellIndex = -1;

	private ReadableDataLocation rdl;
	private InputStream inputStream;
	private BufferedReader br;
	private String[] currentLine;
	private CSVParser parser = new CSVParser();
	private boolean endOfFileReached;

	public CSVReaderEngine(ReadableDataLocation rdl) {
		this.rdl = rdl;
		reset();
	}

	@Override
	public String getDataFormat() {
		return "CSV";
	}
	@Override
	public boolean moveNextWorkSheet() {
		if(sheetIndex < 0) {
			sheetIndex++;
			return true;
		}
		return false;
	}

	@Override
	public String getCellReference() {
		return ExcelUtil.toCellReference(cellIndex, rowIndex);
	}

	@Override
	public FormatDetails getFormatDetails() {
		return new FormatDetailsImpl("CSV", "csv", "text/csv", true, true);
	}

	@Override
	public String getSheetName() {
		// There is no sheet name, so return null.
		return null;
	}

	@Override
	public void resetSheet() {
	}

	@Override
	public boolean hasComments() {
		// There can be no comments, so return false
		return false;
	}


	@Override
	public int getSkippedRows() {
		return 0;
	}

	@Override
	public List<String> getComments() {
		// There can be no comments, so return an empty List.
		return new ArrayList<>();
	}

	@Override
	public boolean setCurrentRow(int targetRow) {
		cellIndex = -1;
		if (rowIndex == targetRow) {
			// Already on the specified row
			return true;
		}

		if (targetRow < rowIndex) {
			// Reset the reader
			reset();
			moveNextWorkSheet();
		}

		int skip = targetRow - rowIndex;

		skip = 1;

		String curLine = null;
		try {
			for (int i=0; i < skip; i++) {
				curLine = br.readLine();
			}
		} catch (Exception e) {
			throw new RuntimeException("Unable to move to row: " + targetRow);
		}

		setCurrentLine(curLine);
		this.rowIndex = targetRow;
		return true;
	}

	private void setCurrentLine(String curLine) {
		// An input line may look like:
		//   "Type","Codelist","","""
		// We want to split on the commas (outside of the quotes) and remove the quotes

		try {
			currentLine = parser.parseLine(curLine);
		} catch (IOException e) {
			throw new SdmxException(e, "Unable to parse the current line: " + curLine);
		}
	}

	@Override
	public int getCurrentRowIdx() {
		return rowIndex;
	}

	@Override
	public boolean moveNextRow(boolean skipNulls) {
		while(true) {
			setCurrentRow(rowIndex+1);
			if (ObjectUtil.validOneString(currentLine)) {
				return true;
			}
			if(skipNulls && currentLine != null) {
				continue;
			}
			endOfFileReached = true;
			return false;
		}
	}

	@Override
	public boolean setCurrentCell(int cellIdx) {
		if (cellIdx >= currentLine.length) {
			return false;
		}
		this.cellIndex = cellIdx;
		return true;
	}

	@Override
	public boolean moveNextCell(boolean skipNulls) {
		// TODO: Should the CSV reader react to skipNulls in any manner?
		this.cellIndex++;
		if (cellIndex >= currentLine.length) {
			return false;
		}
		return true;
	}

	@Override
	public int getCurrentCellIdx() {
		return cellIndex;
	}

	@Override
	public String getValue() {
		if (currentLine == null) {
			throw new RuntimeException("Current line is unset");
		}
		if (cellIndex >= currentLine.length) {
			throw new IllegalArgumentException("Unable to get value at column: " +cellIndex + ". This line only has " + currentLine.length + " elements");
		}
		return currentLine[cellIndex];
	}

	@Override
	public String getValue(int colNo) {
		cellIndex = colNo;
		return getValue();
	}

	@Override
	public boolean isDate() {
		return isDate(cellIndex);
	}

	@Override
	public boolean isDate(int cellNo) {
		String val = getValue(cellNo);
		try {
			SdmxDateImpl.getSdmxDate(val);
		} catch(Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public SdmxDate getSdmxDate(boolean startOfPeriod) {
		return getSdmxDate(cellIndex, startOfPeriod);
	}

	@Override
	public SdmxDate getSdmxDate(int colNo, boolean startOfPeriod) {
		String val = getValue(colNo);
		if (!ObjectUtil.validString(val)) {
			return null;
		}

		// JIRA: FRCE-61
		// The following code addresses an odd issue noticed in DateUtil.
		// If the cellVaLue includes a Time (e.g. 2001-12-31T14:00:00) if startOfPeriod is true the time does not change.
		// However if startOFPeriod is false then the time is moved to 23:59:59 even though the user specified a time..
		// We do NOT want to move to the END of the time period if the user has specified a time, only if the user hasn't specified a time.
		// So the workaround is that if the cell contains a Time, pretend that it is the start of period, so that the time does not change.
		if (!startOfPeriod) {
			if (val.contains("T") && val.charAt(val.length()-1) != 'T') {
				startOfPeriod = true;
			}
		}
		Date d1 = DateUtil.formatDate(val, startOfPeriod);
		return new SdmxDateImpl(d1, TIME_FORMAT.DATE_TIME, startOfPeriod);
	}

	@Override
	public Date getDate() {
		return getDate(cellIndex);
	}

	@Override
	public Date getDate(int colNo) {
		String val = getValue(colNo);
		if (!ObjectUtil.validString(val)) {
			return null;
		}
		DateFormat df = new SimpleDateFormat();
		try {
			return df.parse(val);
		} catch (ParseException e) {
			throw new SdmxSemmanticException(e, "unable to parse date");
		}
	}

	@Override
	public void reset() {
		if(inputStream != null) {
			StreamUtil.closeStream(inputStream);
		}
		inputStream = rdl.getInputStream();
		try {
			br = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
		} catch (Exception e) {
			throw new SdmxException(e, "Could not reset CSV Reader");
		}

		sheetIndex = -1;
		rowIndex = -1;
		cellIndex = -1;
		endOfFileReached = false;
	}

	@Override
	public CellReaderEngine createCopy(InputStream is) {
		return new CSVReaderEngine(rdl.copy());
	}

	@Override
	public void close() {
	}

	@Override
	public boolean skipEmptyRows() {
		while(true) {
			boolean moveNextRow = this.moveNextRow(true);
			if(!moveNextRow) {
				endOfFileReached = true;
				return false;
			}
			while(true) {
				boolean moveNextCell = this.moveNextCell(true);
				if(!moveNextCell) {
					break;
				}
				if(ObjectUtil.validString(this.getValue())) {
					return true;
				}
			}
		}
	}

	@Override
	public boolean atEndOfFile() {
		return endOfFileReached;
	}
}