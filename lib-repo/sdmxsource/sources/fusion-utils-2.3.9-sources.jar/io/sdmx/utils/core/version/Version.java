package io.sdmx.utils.core.version;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import io.sdmx.api.application.IVersion;
import io.sdmx.api.exception.SdmxSemmanticException;

/**
 * Represents a version in the format 1.0.1.2
 */
public class Version implements IVersion {
	private static Map<String, IVersion> refMap = new WeakHashMap<>();
	
	private int[] versionNumbers;
	private String suffix;
	private String asString;
	
	public static IVersion getInstance(String version) {
		synchronized(refMap) {
			IVersion instance = refMap.get(version);
			if(instance == null) {
				instance = new Version(version);
				refMap.put(version, instance);
			}
			return instance;
		}
	}
	
	public Version(String version) {
		version = version.trim();
		
		if(version.contains("-")) {
			String[] versionSuffixSplit = version.split("-", 2);
			version = versionSuffixSplit[0];
			suffix = versionSuffixSplit[1];
		}
		
		String[] parts = version.split("\\.");
		List<Integer> versionNumbers = new ArrayList<>();
		for(String part : parts) {
			try {
				versionNumbers.add(Integer.parseInt(part));
			} catch(NumberFormatException e) {
				throw new SdmxSemmanticException(e, version +" is not a valid version");
			}
		}
		if(versionNumbers.size() == 1) {
			Integer lastPart = versionNumbers.get(versionNumbers.size()-1);
			if(lastPart != 0) {
				versionNumbers.add(0);
			}
		}
		StringBuilder sb = new StringBuilder();
		String concat = "";
		this.versionNumbers = new int[versionNumbers.size()];
		int i=0;
		for(Integer currentVersion : versionNumbers) {
			this.versionNumbers[i] = currentVersion;
			i++;
			sb.append(concat+currentVersion);
			concat = ".";
		}
		if(suffix != null) {
			sb.append("-"+suffix);
		}
		asString = sb.toString();
	}
	
	
	@Override
	public String getSuffix() {
		return suffix;
	}

	/**
	 * Returns true if this is a higher version then the version passed in
	 * @param v
	 * @return
	 */
	public boolean isHigher(IVersion that) {
		int min = Math.min(this.versionNumbers.length, that.getVersionLength());
		for(int i=0; i < min; i++) {
			int vThis = this.getVersion(i);
			int vThat = that.getVersion(i);
			if(vThis > vThat) {
				return true;
			}
			if(vThis < vThat) {
				return false;
			}
		}
		if(this.versionNumbers.length > that.getVersionLength()) {
			return true;
		}
		if(this.versionNumbers.length < that.getVersionLength()) {
			return false;
		}
		if(that.getSuffix() != null) {
			if(this.getSuffix() == null) {
				return true;
			}
			return this.getSuffix().compareTo(that.getSuffix()) > 0;
		}
		return false;
	}

	public String getVersion() {
		return asString;
	}

	@Override
	public int getVersionLength() {
		return this.versionNumbers.length;
	}

	@Override
	public int getVersion(int part) {
		return this.versionNumbers[part];
	}

	@Override
	public int compareTo(IVersion that) {
		int min = Math.min(this.getVersionLength(), that.getVersionLength());
		for(int i=0; i < min; i++) {
			int vThis = this.getVersion(i);
			int vThat = that.getVersion(i);
			if(vThis > vThat) {
				return 1;
			}
			if(vThis < vThat) {
				return -1;
			}
		}
		if(this.versionNumbers.length > that.getVersionLength()) {
			return 1;
		}
		if(this.versionNumbers.length < that.getVersionLength()) {
			return -1;
		}
		if(this.getSuffix() != null) {
			if(that.getSuffix() != null) {
				return this.getSuffix().compareTo(that.getSuffix());
			}
			return -1;
		} 
		if(that.getSuffix() != null) {
			return 1;
		}
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Version) {
			Version that = (Version)obj;
			return that.getVersion().equals(this.getVersion());
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.asString.hashCode();
	}

	@Override
	public String toString() {
		return asString;
	}
	
	
	
}
