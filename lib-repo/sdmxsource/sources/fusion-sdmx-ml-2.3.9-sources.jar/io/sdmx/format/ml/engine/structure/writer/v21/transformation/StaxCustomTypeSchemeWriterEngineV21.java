package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCustomTypeSchemeWriterEngineV21 extends StaxAbstractVTLSchemeWriterEngineV21<ICustomTypeSchemeBean> implements IFusionSingleton {
	private static StaxCustomTypeSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCustomTypeSchemeWriterEngineV21() {}

	public static StaxCustomTypeSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCustomTypeSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CustomTypeScheme";
	}

	@Override
	protected void writeMaintainableInternal(ICustomTypeSchemeBean maint, StaxWriter writer) {
		writeItems(maint.getItems(), writer);
	}

	private void writeItems(List<ICustomTypeBean> items, StaxWriter writer) {
		for(ICustomTypeBean item : items) {
			StaxNameableWriterUtil.writeBean(item, "CustomType", writer);
			if(item.getVtlScalarType() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlScalarType", item.getVtlScalarType());
			}
			if(item.getDataType() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "DataType", item.getDataType());
			}
			if(item.getVtlLiteralFormat() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlLiteralFormat", item.getVtlLiteralFormat());
			}
			if(item.getOutputFormat() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "OutputFormat", item.getOutputFormat());
			}
			if(item.getNullValue() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "NullValue", item.getNullValue());
			}
			writer.writeEndElement();
		}
	}
}
