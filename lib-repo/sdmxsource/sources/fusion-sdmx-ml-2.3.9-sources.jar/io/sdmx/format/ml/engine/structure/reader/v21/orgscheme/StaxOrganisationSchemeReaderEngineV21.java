package io.sdmx.format.ml.engine.structure.reader.v21.orgscheme;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxOrganisationSchemeReaderEngineV21 implements StaxMaintainableReaderEngine<OrganisationSchemeMutableBean<?>>, IFusionSingleton {
    private static StaxOrganisationSchemeReaderEngineV21 INSTANCE;

    //Private constructor - lazy load instance
    private StaxOrganisationSchemeReaderEngineV21() {}

    public static StaxOrganisationSchemeReaderEngineV21 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxOrganisationSchemeReaderEngineV21();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                OrganisationSchemeMutableBean<?> mutable = null;
                if(nodeName.equals("AgencyScheme")) {
                    mutable = StaxAgencySchemeReaderEngineV21.getInstance().processMaintainable(reader);
                } else if(nodeName.equals("DataConsumerScheme")) {
                    mutable = StaxDataConsumerSchemeReaderEngineV21.getInstance().processMaintainable(reader);
                } else if(nodeName.equals("DataProviderScheme")) {
                    mutable = StaxDataProviderSchemeReaderEngineV21.getInstance().processMaintainable(reader);
                } else if(nodeName.equals("OrganisationUnitScheme")) {
                    mutable = StaxOrgUnitSchemeReaderEngineV21.getInstance().processMaintainable(reader);
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
                if(mutable != null) {
                    builder.build(mutable, beans);
                }
            } else if(nodeName.equals(getContainerNodeName())){
                break;
            }
        }
    }

    @Override
    public String getContainerNodeName() {
        return "OrganisationSchemes";
    }
	
}
