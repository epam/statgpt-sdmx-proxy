package io.sdmx.format.ml.engine.structure.reader;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.api.engine.StaxStructureReaderEngine;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.xml.StaxReader;

@SuppressWarnings("rawtypes")
/**
 * Iterates a Structure message, each time a new Structure container element it encountered, the corresponding StaxMaintainableReaderEngine is
 * used to read the structure(s) in the containers
 */
public abstract class AbstractStaxStructureReaderEngine implements StaxStructureReaderEngine {
	private String startNode;

	//Reader engine by root node name
	protected Map<String, StaxMaintainableReaderEngine> readerEngines = new HashMap<>();

	public AbstractStaxStructureReaderEngine(String startNode) {
		this.startNode = startNode;
	}

	protected void registerReader(StaxMaintainableReaderEngine reader) {
	    readerEngines.put(reader.getContainerNodeName(), reader);
	}

	@Override
	/**
	 * Input is expected to be a Structure document with the layout
	 *
	 * <Structure>
	 *    <Header>....</Header>
	 *    <Structures>....</Structures>
	 * </Structure>
	 *
	 */
	public SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder builder) {
		SdmxBeans sdmxBeans = new SdmxBeansImpl();
		IStaxReader staxReader = new StaxReader(rdl);
		try {
			if(!staxReader.jumpToNode("Header")) {
				return sdmxBeans;
			}
			sdmxBeans.setHeader(processHeader(staxReader));
			processBody(staxReader, sdmxBeans, builder);
		} finally {
			staxReader.close();
		}
		return sdmxBeans;
	}
	
	protected void processBody(IStaxReader staxReader, SdmxBeans sdmxBeans, IBeansBuilder builder) {
	    while(staxReader.moveNextStartNode()) {
            if(staxReader.getElementName().equals("SubmitStructureRequest")) {
                Map<String, String> attrs = staxReader.getAttributes();
                if(attrs.containsKey("action")) {
                    sdmxBeans.setAction(DATASET_ACTION.getAction(attrs.get("action")));
                }
            }
            
            if(startNode == null || staxReader.getElementName().equals(startNode)) {
                if(startNode != null) {
                    staxReader.moveNextNode();
                }
                do {
                    if(staxReader.isStartElement()) {
                        processNode(staxReader, sdmxBeans, builder);
                    } else if(staxReader.getElementName().equals(startNode)) {
                        break;
                    }
                } while(staxReader.moveNextNode());
            }
        }
	}

	protected abstract HeaderBean processHeader(IStaxReader reader);

	protected void processNode(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
	    getStaxMaintainableReaderEngine(reader).read(reader, beans, builder);
	}

	protected StaxMaintainableReaderEngine getStaxMaintainableReaderEngine(IStaxReader reader) {
		StaxMaintainableReaderEngine readerEngine = this.readerEngines.get(reader.getElementName());
		if(readerEngine == null) {
			throw new SdmxNotImplementedException("No support for reading structure '"+reader.getElementName()+"' in version '"+this.getOutputVersion()+"'");
		}
		return readerEngine;
	}

	protected abstract SDMX_SCHEMA getOutputVersion();
}
