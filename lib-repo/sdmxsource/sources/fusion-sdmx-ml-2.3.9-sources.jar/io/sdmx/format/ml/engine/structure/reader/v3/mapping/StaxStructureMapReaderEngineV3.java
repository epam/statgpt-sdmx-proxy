package io.sdmx.format.ml.engine.structure.reader.v3.mapping;

import java.util.Map;

import io.sdmx.api.date.PERIOD_POSITION;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.EPOCH;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IEpochMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IStructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimeComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.ITimePatternMapMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxAnnotableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxMaintainableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.mapping.v3.StructureMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxStructureMapReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IStructureMapMutableBean> {
	private static StaxStructureMapReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxStructureMapReaderEngineV3() {}
	public static StaxStructureMapReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureMapReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public String getContainerNodeName() {
        return "StructureMaps";
    }
	
    @Override
    protected String getRootNodeName() {
        return "StructureMap";
    }
    
	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
    @Override
    protected IStructureMapMutableBean processMaintainable(IStaxReader reader) {
		IStructureMapMutableBean returnBean = new StructureMapMutableBean();

		StaxMaintainableUtilV3.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Source")) {
				returnBean.setSourceRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DSD, SDMX_STRUCTURE_TYPE.DATAFLOW));
			} else if(nodeName.equals("Target")) {
				returnBean.setTargetRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DSD, SDMX_STRUCTURE_TYPE.DATAFLOW));
			} else if(nodeName.equals("EpochMap")) {
				processEpochMap(reader, returnBean);
			} else if(nodeName.equals("DatePatternMap")) {
				processTimePatternMap(reader, returnBean);
			} else if(nodeName.equals("FrequencyFormatMapping")) {
				processFrequencyFormatMap(reader, returnBean);
			} else if(nodeName.equals("ComponentMap")) {
				processComponentMap(reader, returnBean);
			} else if(nodeName.equals("FixedValueMap")) {
				processFixedValueMap(reader, returnBean);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
	
	private void processEpochMap(IStaxReader reader, IStructureMapMutableBean map) {
		IEpochMapMutableBean returnBean = map.addEpochMap();
		Map<String, String> attributes = reader.getAttributes();
		
		returnBean.setBasePeriod(attributes.get("basePeriod"));
		if(attributes.containsKey("epochPeriod")) {
			returnBean.setEpochInterval(EPOCH.fromString(attributes.get("epochPeriod")));
		}
		if(attributes.containsKey("resolvePeriod")) {
			returnBean.setPeriodResolution(PERIOD_POSITION.fromString(attributes.get("resolvePeriod")));
		}
		processBaseTimeMap(reader, returnBean);
	}
	

	private void processTimePatternMap(IStaxReader reader, IStructureMapMutableBean map) {
		ITimePatternMapMutableBean returnBean = map.addTimePatternMap();
		Map<String, String> attributes = reader.getAttributes();
		if(attributes.containsKey("resolvePeriod")) {
			returnBean.setPeriodResolution(PERIOD_POSITION.fromString(attributes.get("resolvePeriod")));
		}
		returnBean.setPattern(attributes.get("sourcePattern"));
		returnBean.setLocale(attributes.get("locale"));
		processBaseTimeMap(reader, returnBean);
	}
	
	private void processBaseTimeMap(IStaxReader reader, ITimeComponentMapMutableBean returnBean) {
		StaxAnnotableUtilV3.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Source")) {
				returnBean.setSourceComponent(reader.getElementText());
			} else if(nodeName.equals("Target")) {
				returnBean.setTargetComponent(reader.getElementText());
			} else if(nodeName.equals("FrequencyDimension")) {
				returnBean.setOutputFrequencyDimId(reader.getElementText());
			} else if(nodeName.equals("MappedFrequencies")) {
				//returnBean.setSourceComponent(reader.getElementText());
			} else if(nodeName.equals("TargetFrequencyID")) {
				returnBean.setOutputFrequencyId(reader.getElementText());
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
	}
	

	private void processFrequencyFormatMap(IStaxReader reader, IStructureMapMutableBean map) {
		//TODO
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("FrequencyId")) {
					//TODO
				} else if(nodeName.equals("DatePattern")) {
					//TODO
				}
			} else if(nodeName.equals("FrequencyFormatMapping")){
				return;
			}
		}
	}
	
	private void processComponentMap(IStaxReader reader, IStructureMapMutableBean map) {
		IComponentMapMutableBean returnBean = map.addComponentMap();
		StaxAnnotableUtilV3.processBean(returnBean, reader);
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Source")) {
				returnBean.addSourceComponent(reader.getElementText());
			} else if(nodeName.equals("Target")) {
				returnBean.addTargetComponent(reader.getElementText());
			} else if(nodeName.equals("RepresentationMap")) {
				returnBean.setRepresentationMapRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
	}
	
	private void processFixedValueMap(IStaxReader reader, IStructureMapMutableBean map) {
		StaxAnnotableUtilV3.processBean(map, reader);

		String source = null;
		String target = null;
		String value = null;
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Source")) {
				source = reader.getElementText();
			} else if(nodeName.equals("Target")) {
				target = reader.getElementText();
			} else if(nodeName.equals("Value")) {
				if(value != null) {
					value += ","+reader.getElementText();
				} else {
					value = reader.getElementText();
				}
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		if(source != null) {
			map.addFixedInput(source, value);
		} else if(target != null) {
			map.addFixedOutput(target, value);
		} else {
			throw new SdmxSemmanticException("FixedValueMap requires either a Source or Target value");
		}
	}
}
