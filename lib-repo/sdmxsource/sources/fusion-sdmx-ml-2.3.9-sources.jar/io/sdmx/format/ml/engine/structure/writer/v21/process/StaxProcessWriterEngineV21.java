package io.sdmx.format.ml.engine.structure.writer.v21.process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxAnnotableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxIdentifiableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxTextWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxProcessWriterEngineV21 extends AbstractV21Writer<ProcessBean> implements IFusionSingleton {
	private static StaxProcessWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProcessWriterEngineV21() {}

	public static StaxProcessWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProcessWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Process";
	}

	@Override
	protected void writeMaintainableInternal(ProcessBean maint, StaxWriter writer) {
		writeProcessStep(maint.getProcessSteps(), writer);
	}

	private void writeProcessStep(List<ProcessStepBean> processSteps, StaxWriter writer) {
		for(ProcessStepBean processStep : processSteps) {
			StaxNameableWriterUtil.writeBean(processStep, "ProcessStep", writer);
			writeInputOutputBean(processStep.getInput(), "Input", writer);
			writeInputOutputBean(processStep.getOutput(), "Output", writer);
			writeComputation(processStep.getComputation(), writer);
			writeTransition(processStep.getTransitions(), writer);
			writeProcessStep(processStep.getProcessSteps(), writer);
			writer.writeEndElement(); //End ProcessStep
		}
	}

	private void writeInputOutputBean(List<InputOutputBean> inOutBeans, String nodeName, StaxWriter writer) {
		for(InputOutputBean inOut : inOutBeans) {
			writer.writeStartElement(NS, nodeName);
			writer.writeAttribute("localID", inOut.getLocalId());
			StaxAnnotableWriterUtil.writeBean(inOut, writer);
			StaxRefUtil.writeReference(inOut.getStructureReference(), writer, "ObjectReference");
			writer.writeEndElement(); //End Input Output
		}
	}

	private void writeComputation(ComputationBean comp, StaxWriter writer) {
		if(comp != null) {
			writer.writeStartElement(NS, "Computation");
			writer.writeAttribute("localID", comp.getLocalId());
			writer.writeAttribute("softwarePackage", comp.getSoftwarePackage());
			writer.writeAttribute("softwareLanguage", comp.getSoftwareLanguage());
			writer.writeAttribute("softwareVersion", comp.getSoftwareVersion());
			StaxAnnotableWriterUtil.writeBean(comp, writer);
			StaxTextWriterUtil.writeTextTypes(comp.getDescription(), writer, "Description");
			writer.writeEndElement(); //End Computation
		}
	}

	private void writeTransition(List<TransitionBean> transitions, StaxWriter writer) {
		for(TransitionBean transition : transitions) {
			Map<String, String> attributes = new HashMap<>();
			attributes.put("localID", transition.getLocalId());
			StaxIdentifiableWriterUtil.writeBean(transition, "Transition", writer, attributes);
			StaxRefUtil.writeLocalReference(transition.getTargetStep().getFullIdPath(false), writer, "TargetStep");
			StaxTextWriterUtil.writeTextTypes(NS, transition.getCondition(), writer, "Condition");
			writer.writeEndElement(); //End Transition
		}
	}
}
