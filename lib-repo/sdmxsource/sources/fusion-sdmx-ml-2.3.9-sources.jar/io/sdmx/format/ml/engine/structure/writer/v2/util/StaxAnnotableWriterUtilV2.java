package io.sdmx.format.ml.engine.structure.writer.v2.util;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxAnnotableWriterUtilV2 {

	public static void writeBean(AnnotableBean annotableBean, StaxWriter writer) {
		writeAnnotations(annotableBean.getAnnotations(), writer);
	}

	public static void writeAnnotations(List<AnnotationBean>  annotations, StaxWriter writer) {
		if(ObjectUtil.validCollection(annotations)) {
			writer.writeStartElement(StaxStructureWriterUtilV2.STRUCTURE_NS, "Annotations");
			for(AnnotationBean annotation : annotations) {
				writeAnnotation(annotation, writer);
			}
			writer.writeEndElement();
		}
	}

	private static void writeAnnotation(AnnotationBean annotationBean, StaxWriter writer) {
		writer.writeStartElement(StaxStructureWriterUtilV2.COMMON_NS, "Annotation");
//	    writer.writeStartElementWithExplicitNamespace(StaxStructureWriterUtilV2.COMMON_NS, "Annotation");

//		writer.writeAttribute("id", annotationBean.getId());
		writer.writeElement(StaxStructureWriterUtilV2.COMMON_NS, "AnnotationTitle", annotationBean.getTitle());
		writer.writeElement(StaxStructureWriterUtilV2.COMMON_NS, "AnnotationType", annotationBean.getType());
		if(annotationBean.getUri() != null) {
			writer.writeElement(StaxStructureWriterUtilV2.COMMON_NS, "AnnotationURL", annotationBean.getUri().toString());
		}
		StaxTextWriterUtilV2.writeTextTypes(StaxStructureWriterUtilV2.COMMON_NS, annotationBean.getText(), writer, "AnnotationText");
		writer.writeEndElement();
	}
}
