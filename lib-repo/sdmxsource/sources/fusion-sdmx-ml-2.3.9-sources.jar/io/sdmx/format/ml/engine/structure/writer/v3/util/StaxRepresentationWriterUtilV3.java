package io.sdmx.format.ml.engine.structure.writer.v3.util;

import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRepresentationWriterUtilV3 {
	
	public static void writeRepresentation(RepresentationBean representation, StaxWriter writer, String elementName) {
		writeRepresentation(representation, writer, elementName, false, true);
	}

	public static void writeRepresentation(RepresentationBean representation, 
			StaxWriter writer, String elementName, boolean excludeMinMax, boolean includeMultiLingual) {
		if(representation != null) {
			writer.writeStartElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName);
			if(!excludeMinMax) {
				if(representation.getMinOccurs() != null) {
					writer.writeAttribute("minOccurs", representation.getMinOccurs());
				}
				if(representation.getMaxOccurs() != null) {
					writer.writeAttribute("maxOccurs",representation.getMaxOccurs());
				}
			}
			if(representation.getRepresentation() == null) {
				StaxTextFormatWriterUtilV3.writeTextFormat(representation.getTextFormat(), writer, "TextFormat", includeMultiLingual);
			} else {
				StaxRefUtilV3.writeReference(representation.getRepresentation(), writer, "Enumeration");
				StaxTextFormatWriterUtilV3.writeTextFormat(representation.getTextFormat(), writer, "EnumerationFormat", includeMultiLingual);
			}
			
			writer.writeEndElement();
		}
	}
}
