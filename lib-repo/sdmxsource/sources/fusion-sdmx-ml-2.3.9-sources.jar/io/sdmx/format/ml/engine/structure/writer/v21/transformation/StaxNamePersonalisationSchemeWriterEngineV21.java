package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxNamePersonalisationSchemeWriterEngineV21 extends StaxAbstractVTLSchemeWriterEngineV21<INamePersonalisationSchemeBean> implements IFusionSingleton {
	private static StaxNamePersonalisationSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxNamePersonalisationSchemeWriterEngineV21() {}

	public static StaxNamePersonalisationSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxNamePersonalisationSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "NamePersonalisationScheme";
	}
	@Override
	protected void writeMaintainableInternal(INamePersonalisationSchemeBean maint, StaxWriter writer) {
		writeItems(maint.getItems(), writer);
	}

	private void writeItems(List<INamePersonalisationBean> items, StaxWriter writer) {
		for(INamePersonalisationBean item : items) {
			StaxNameableWriterUtil.writeBean(item, "NamePersonalisation", writer, CollectionUtil.buildMapValues("vtlArtefact "+item.getVtlArtefact()));
			if(item.getVtlDefaultName() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlDefaultName", item.getVtlDefaultName());
			}
			if(item.getPersonalisedName() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "PersonalisedName", item.getPersonalisedName());
			}
			writer.writeEndElement();
		}
	}
}
