package io.sdmx.format.ml.manager;

import java.util.EnumMap;
import java.util.Map;
import java.util.Properties;

import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.utils.core.resource.PropertiesToMap;
import io.sdmx.utils.sdmx.application.WEB_SERVICE;

public class SchemaLocationManagerImpl implements SchemaLocationManager {
	
	private FusionProductInformationRetrievalManager productInformationRetrievalManager;
	
	private Map<SDMX_SCHEMA, String> schemaLocationMap = new EnumMap<> (SDMX_SCHEMA.class);
	
	/**
	 * Default constructor sets the location
	 */
	public SchemaLocationManagerImpl(FusionProductInformationRetrievalManager fpiManager, Properties properties) {
		schemaLocationMap.put(SDMX_SCHEMA.VERSION_ONE, "https://xml.sdmx.org/1.0/");
		schemaLocationMap.put(SDMX_SCHEMA.VERSION_TWO, "https://xml.sdmx.org/2.0/");
		schemaLocationMap.put(SDMX_SCHEMA.VERSION_TWO_POINT_ONE, "https://xml.sdmx.org/2.1/");
		schemaLocationMap.put(SDMX_SCHEMA.VERSION_THREE, "https://xml.sdmx.org/3.0.0/");
		
		this.productInformationRetrievalManager = fpiManager;
		if(fpiManager == null) {
			throw new IllegalArgumentException("SchemaLocationManagerImpl missing required FusionProductInformationRetrievalManager");
		}
		
		if (properties == null) {
			properties = new Properties();
		}
		Map<String, String> propsMap = PropertiesToMap.createMap(properties);
		for(String schemaVersion : propsMap.keySet()) {
			schemaLocationMap.put(SDMX_SCHEMA.valueOf(schemaVersion), propsMap.get(schemaVersion));
		}
	}

	@Override
	public String getSchemaLocation(SDMX_SCHEMA schemaVersion) {
		return schemaLocationMap.get(schemaVersion);
	}

	@Override
	public String getStructureSpecificSchemaLocation(ConstrainableBean cons, SDMX_SCHEMA schemaVersion) {
		MaintainableBean maint = cons.getMaintainableParent();
		StringBuilder sb = new StringBuilder();
		String sdmxWs = productInformationRetrievalManager.getFusionProductInformation().getServiceURL(WEB_SERVICE.SDMX_GET.service());
		if(!sdmxWs.endsWith("/")) {
			sdmxWs += "/";
		}
		sb.append(sdmxWs);
		sb.append("schema/"+cons.getStructureType().getUrnClass().toLowerCase());
		sb.append("/"+maint.getAgencyId());
		sb.append("/"+maint.getId());
		sb.append("/"+maint.getVersion());
		sb.append("?format=sdmx-");
		switch(schemaVersion) {
		case VERSION_ONE :
			sb.append("1.0");
			break;
		case VERSION_TWO :
			sb.append("2.0");
			break;
		case VERSION_TWO_POINT_ONE :
			sb.append("2.1");
			break;
		case VERSION_THREE:
			sb.append("3.0");
			break;
			default : throw new SdmxNotImplementedException("Structure Specific Schema location for version "+schemaVersion);
		}
		return sb.toString();
	}

}
