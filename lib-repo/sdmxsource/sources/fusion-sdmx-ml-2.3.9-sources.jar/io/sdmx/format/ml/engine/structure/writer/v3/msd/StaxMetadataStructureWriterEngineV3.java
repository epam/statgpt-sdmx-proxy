package io.sdmx.format.ml.engine.structure.writer.v3.msd;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeContainerBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxIdentifiableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRepresentationWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMetadataStructureWriterEngineV3 extends AbstractV3Writer<MetadataStructureDefinitionBean> implements IFusionSingleton {
	private static StaxMetadataStructureWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataStructureWriterEngineV3() {}

	public static StaxMetadataStructureWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataStructureWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "MetadataStructure";
	}

	@Override
	protected void writeMaintainableInternal(MetadataStructureDefinitionBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writer.writeStartElement(NS, "MetadataStructureComponents");
		writer.writeStartElement(NS, "MetadataAttributeList");
		writeMetadataAttributes(maint, externalLinks, writer);
		writer.writeEndElement();	//END MetadataAttributeList
		writer.writeEndElement();  	//END MetadataStructureComponents
	}

	private void writeMetadataAttributes(MetadataAttributeContainerBean attributeContainer, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(MetadataAttributeBean metadataAttribute : attributeContainer.getMetadataAttributes()) {
			writer.writeStartElement(NS, "MetadataAttribute");

			Map<String, String> attributes = StaxIdentifiableWriterUtilV3.getAttributes(metadataAttribute);
			if(metadataAttribute.getPresentational().isTrue()) {
				attributes.put("isPresentational", "true");
			}
			attributes.put("maxOccurs", "unbounded");
			
			RepresentationBean representation = metadataAttribute.getRepresentation();
			if(representation != null) {
				if(representation.getMinOccurs() != null && representation.getMinOccurs() >= 0) {
					attributes.put("minOccurs", Integer.toString(metadataAttribute.getMinOccurs()));
				}
				Integer maxOccurs = representation.getMaxOccurs();
				if(maxOccurs != null && maxOccurs >= 1 && maxOccurs < Integer.MAX_VALUE) {
					attributes.put("maxOccurs", Integer.toString(metadataAttribute.getMaxOccurs()));
				}
			}
			writer.writeAttributes(attributes);
			StaxAnnotableWriterUtilV3.writeBean(metadataAttribute, writer);
			StaxRefUtilV3.writeReference(metadataAttribute.getConceptRef(), writer, "ConceptIdentity");
			if(representation != null) {
				if(representation.getTextFormat() != null || representation.getRepresentation() != null) {
					StaxRepresentationWriterUtilV3.writeRepresentation(metadataAttribute.getRepresentation(), writer, "LocalRepresentation", true, true);
				}
			}
			writeMetadataAttributes(metadataAttribute, externalLinks, writer);

			writer.writeEndElement(); //End MetadataAttribute
		}
	}
}
