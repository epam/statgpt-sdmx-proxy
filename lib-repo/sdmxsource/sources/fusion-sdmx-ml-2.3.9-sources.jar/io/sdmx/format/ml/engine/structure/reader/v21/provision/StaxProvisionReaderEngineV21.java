package io.sdmx.format.ml.engine.structure.reader.v21.provision;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxProvisionReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<ProvisionAgreementMutableBean> {
	private static StaxProvisionReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProvisionReaderEngineV21() {}

	public static StaxProvisionReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProvisionReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
	}

    @Override
    public String getContainerNodeName() {
        return "ProvisionAgreements";
    }

    @Override
    protected String getRootNodeName() {
        return "ProvisionAgreement";
    }
    
    @Override
    protected ProvisionAgreementMutableBean processMaintainable(IStaxReader reader) {
		ProvisionAgreementMutableBean provisonAgreement = new ProvisionAgreementMutableBeanImpl();
		StaxMaintainableUtil.processBean(provisonAgreement, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("StructureUsage")) {
				provisonAgreement.setStructureUsage(StaxStructureUtil.getStructureReference(reader,  null));
			} else if(elementName.equals("DataProvider")) {
				provisonAgreement.setDataproviderRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATA_PROVIDER));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return provisonAgreement;
	}
}
