package io.sdmx.format.ml.engine.structure.reader.v21.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxAgencySchemeReaderEngineV21 extends StaxAbstractOrgansiationReaderV21 {
	private static StaxAgencySchemeReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxAgencySchemeReaderEngineV21() {}

	public static StaxAgencySchemeReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxAgencySchemeReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
    public AgencySchemeMutableBean processMaintainable(IStaxReader reader) {
        AgencySchemeMutableBean agencyScheme = new AgencySchemeMutableBeanImpl();
        StaxItemSchemeUtil.processBean(agencyScheme, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("Agency")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processAgency(agencyScheme, reader);
            reader.moveNextNode();
        }
        return agencyScheme;
    }

	private void processAgency(AgencySchemeMutableBean beanToPopulate, IStaxReader reader) {
		AgencyMutableBean org = new AgencyMutableBeanImpl();
		beanToPopulate.addItem(org);
		super.processOrganisation(org, reader);;
	}
}
