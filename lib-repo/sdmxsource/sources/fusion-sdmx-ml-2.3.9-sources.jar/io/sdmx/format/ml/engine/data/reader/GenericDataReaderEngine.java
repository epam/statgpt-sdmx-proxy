package io.sdmx.format.ml.engine.data.reader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.TimeFormatParsingException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.format.ml.model.XMLDatasetHeader;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.date.SdmxDateUtil;
import io.sdmx.utils.sdmx.structure.DataStructureUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

public class GenericDataReaderEngine extends AbstractSdmxDataReaderEngine {
	private static final long serialVersionUID = 8712324190069733547L;
	private Map<String, String> attributesOnDatasetNode = new HashMap<>();

	private static final Logger LOG = LoggerFactory.getLogger(GenericDataReaderEngine.class);
	private TIME_FORMAT timeFormat;

	/**
	 * Creates a reader engine based on the data location, and the data structure to use to interpret the data
	 * @param dataLocation the location of the data
	 * @param dataStructureBean the DSD to use to interpret the data
	 */
	public GenericDataReaderEngine(ReadableDataLocation dataLocation,
			DataStructureBean dataStructureBean,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreementBean,
			DataReaderExceptionHandler exceptionHandler) {
		this(dataLocation, null, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler);
	}

	/**
	 * Creates a reader engine based on the data location, the location of available data structures that can be used to retrieve dsds, and the default dsd to use
	 * @param dataLocation the location of the data
	 * @param beanRetrieval giving the ability to retrieve dsds for the datasets this reader engine is reading.  This can be null if there is only one relevent dsd - in which case the default dsd should be provided
	 * @param dataStructureBean the dsd to use if the beanRetrieval is null, or if the bean retrieval does not return the dsd for the given dataset
	 */
	public GenericDataReaderEngine(ReadableDataLocation dataLocation,
			SdmxBeanRetrievalManager beanRetrieval,
			DataStructureBean dataStructureBean,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreementBean,
			DataReaderExceptionHandler exceptionHandler) {
		this(dataLocation, beanRetrieval, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler, null);
	}

	/**
	 * All constructors end up here - this is private as it is used in the create copy method
	 */
	private GenericDataReaderEngine(ReadableDataLocation dataLocation,
			SdmxBeanRetrievalManager beanRetrieval,
			DataStructureBean dataStructureBean,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreementBean,
			DataReaderExceptionHandler exceptionHandler,
			Set<String> handledExceptions) {
		super(dataLocation, beanRetrieval, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler, BASE_DATA_FORMAT.GENERIC);
		super.handledExceptions = handledExceptions;
		if(super.handledExceptions == null) {
			super.handledExceptions = new HashSet<>();
		}
		reset();
	}

	@Override
	public FormatDetails getFormatDetails() {
		String acceptHeader = null;
		switch(getSchemaVersion()) {
		case VERSION_ONE :
			acceptHeader = "application/vnd.sdmx.genericdata+xml;version=1.0";
			break;
		case VERSION_TWO :
			acceptHeader = "application/vnd.sdmx.genericdata+xml;version=2.0";
			break;
		case VERSION_TWO_POINT_ONE :
			acceptHeader = "application/vnd.sdmx.genericdata+xml;version=2.1";
			break;
		}
		String mimeType = "application/xml";
		return new FormatDetailsImpl(toString(), "xml", mimeType, false, acceptHeader);
	}

	@Override
	public DataReaderEngine createCopy() {
		return new GenericDataReaderEngine(dataLocation,
				beanRetrieval,
				defaultDsd,
				defaultDataflow,
				defaultProvisionAgreement,
				exceptionHandler,
				handledExceptions);
	}

	public enum MOVE_TO {
		SERIES,
		GROUP,
		KEYABLE;
	}

	@Override
	protected AttributableBuilder<IDatasetAttributes> getDatasetAttributesBuilder() {
		List<KeyValue> returnList = new ArrayList<>();
		for (String keyValue : attributesOnDatasetNode.keySet()) {
			String attributeValue = attributesOnDatasetNode.get(keyValue);
			returnList.add(KeyValueImpl.getInstance(keyValue, attributeValue));
		}
		return DatasetAttributes.builder().attributes(returnList);
	}

	@Override
	protected DatasetHeaderBean processDataSetNode() {
		attributesOnDatasetNode = new HashMap<>();
		this.datasetHeaderBean = new XMLDatasetHeader(parser, headerBean, getDatasetPosition(), exceptionHandler);
		String dsdId = processDatasetNode();

		DatasetStructureReferenceBean dsRef = datasetHeaderBean.getDataStructureReference();
		IURNSingle<? extends IDSDRelatedBean> structureReference = null;
		String id = null;
		String serviceURL = null;
		String structureURL = null;
		String dimensionAtObservation = null;

		if(dsRef != null) {
			id = dsRef.getId();
			serviceURL = dsRef.getServiceURL();
			structureURL = dsRef.getStructureURL();
			dimensionAtObservation = dsRef.getDimensionAtObservation();
			structureReference = dsRef.getStructureReference();
		}
		if(structureReference == null) {
			if(defaultDsd != null && defaultDsd.getId().equals(dsdId)) {
				structureReference = defaultDsd.getURN();
			} else {
				URNBuilder urnBuilder = URN.builder();
				urnBuilder.maintId(dsdId).version(MaintainableBean.DEFAULT_VERSION);
				Set<DataStructureBean> dsds = beanRetrieval == null ? Collections.emptySet() : beanRetrieval.getMaintainableBeans(urnBuilder.build(DataStructureBean.class));
				if(dsds.size() > 0) {
					for(DataStructureBean dsd : dsds) {
						urnBuilder.agencyId(dsd.getAgencyId());
						break;
					}
				}
				if(urnBuilder.agencyId() == null) {
					urnBuilder.agencyId(AgencySchemeBean.DEFAULT_SCHEME);
				}
				structureReference = urnBuilder.buildSingle(DataStructureBean.class);
			}
		} 
		dsRef = new DatasetStructureReferenceBeanImpl(id, structureReference, serviceURL, structureURL, dimensionAtObservation);
		datasetHeaderBean = datasetHeaderBean.modifyDataStructureReference(dsRef);
		this.currentDsd = null;
		this.currentDataflow = null;
		this.currentProvisionAgreement = null;
		return datasetHeaderBean;
	}

	@Override
	protected boolean next(boolean includeObs) {
		String nodeName = null;
		while (parser.moveNextNode()) {
			nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if(nodeName.equals("DataSet")) {
					if (getRootNode().equals("MessageGroup")) {
						assertNameSpace(GENERIC_NS);
					} else {
						assertNameSpace(MESSAGE_NS);
					}
					datasetPosition = DATASET_POSITION.DATASET;
					return true;
				} else {
					assertNameSpace(GENERIC_NS);
					if(nodeName.equals("Series")) {
						datasetPosition = DATASET_POSITION.SERIES;
						return true;
					} else if(nodeName.equals("Group")) {
						datasetPosition = DATASET_POSITION.GROUP;
						groupId = parser.getAttributeValue(null, "type");
						return true;
					} else if(nodeName.equals("Obs")) {
						if(datasetPosition == DATASET_POSITION.SERIES || datasetPosition == DATASET_POSITION.OBSERVATION) {
							if(includeObs) {
								datasetPosition = DATASET_POSITION.OBSERVATION;
								return true;
							} else {
								continue;
							}
						}
						datasetPosition = DATASET_POSITION.OBSERAVTION_AS_SERIES;
						return true;
					} else if(nodeName.equals("Annotations") || nodeName.equals("Attributes"))  {
						parser.skipCurrentNode();
					} else if(nodeName.equals("KeyFamilyRef") || nodeName.equals("Time") || nodeName.equals("ObsValue") || nodeName.equals("ObsDimension") || nodeName.equals("SeriesKey") || nodeName.equals("Value") || nodeName.equals("GroupKey")) {
						//DO NOTHING
					} else  {
						reportNotValidNode(false);
					}
				}
			} else {
				if(nodeName.equals("Series")) {
					datasetPosition = null;
				} else if(nodeName.equals("Group")) {
					datasetPosition = null;
				}
			}
		}

		hasNext=false;
		datasetPosition = null;
		return false;
	}

	/**
	 * Sends the runAheadParser ahead to see if there are any dataset attributes, will stop running ahead if it finds a series, group or end of dataset element
	 * @return the DSD id referenced
	 * @throws XMLStreamException
	 *
	 */
	private String processDatasetNode() {
		String keyFamilyRef = null;
		while (parser.peak()) {
			String nodeName = parser.getElementName();
			LOG.debug("Run-ahead parser processing node: " + nodeName);
			if (parser.isStartElement()) {
				if(nodeName.equals("Attributes")) {
					List<KeyValue> attributes = getKeyValues("Attributes", ERROR_POSITION.DATASET);  //We have got the series key attributes
					for(KeyValue kv : attributes) {
						attributesOnDatasetNode.put(kv.getConcept(), kv.getCode());
					}
				} else if(nodeName.equals("KeyFamilyRef")) {
					parser.moveNextNode();
					keyFamilyRef = parser.getElementText();
				} else if(nodeName.equals("Series")) {
					return keyFamilyRef;
				} else if(nodeName.equals("Group")) {
					return keyFamilyRef;
				} else if(nodeName.equals("Obs")) {
					return keyFamilyRef;
				}
			} else {
				if(nodeName.equals("DataSet")) {
					return keyFamilyRef;
				}
			}
		}
		return null;
	}

	private void processFlatObsNode() {
		List<KeyValue> key = getKeyValues("ObsKey", ERROR_POSITION.SERIES);;
		List<KeyValue> attributes=null;
		String obsValue = null;
		String obsConcept = null;

		while(parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if(nodeName.equals("Attributes")) {
					attributes = getKeyValues("Attributes", ERROR_POSITION.SERIES);  //We have got the series key attributes
				} else if(nodeName.equals("Time")) {
					obsConcept = parser.getElementText();
				} else if(nodeName.equals("ObsDimension")) {
					obsConcept = parser.getAttributeValue(null, "value");
				} else if(nodeName.equals("ObsValue")) {
					//We are in a No series key situation here
					obsValue = parser.getAttributeValue(null, "value");
				}
			} else if(parser.getElementName().equals("Obs")) {
				break;
			}
		}
		List<KeyValue> seriesKey = new ArrayList<>();
		String obsTime = null;
		for(KeyValue currentKeyValue : key) {
			if(currentKeyValue.getConcept().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				obsTime = currentKeyValue.getCode();
			} else {
				seriesKey.add(currentKeyValue);
			}
		}
		List<KeyValue> seriesAttributes=new ArrayList<>();
		List<KeyValue> obsAttributes=new ArrayList<>();
		List<String> observationAttributeIds = DataStructureUtil.getObservationConcepts(currentDsd);

		for(KeyValue currentKv : attributes) {
			if(observationAttributeIds.contains(currentKv.getConcept())) {
				obsAttributes.add(currentKv);
			} else {
				seriesAttributes.add(currentKv);
			}
		}
		currentKey = KeyableImpl.seriesKey(currentDataflow, currentDsd, seriesKey, seriesAttributes);
		currentObs = ObservationImpl.timeSeries(currentKey, obsTime, obsValue, obsAttributes);
		flatObs = currentObs;
	}

	@Override
	protected Keyable processSeriesNode() {
		if(noSeries) {
			processFlatObsNode();
			return currentKey;
		} 
		if(parser.moveNextStartNode()) {
			assertNameSpace(GENERIC_NS);
			while(!parser.getElementName().equals("SeriesKey")) {
				handleException("Unexpected element '" + parser.getXMLPath() + "'", true, SEVERITY.HIGH, TYPE.ADDED_ELEMNET);
				parser.skipCurrentNode();
			}
		}
		List<KeyValue> key = getKeyValues("SeriesKey", ERROR_POSITION.SERIES);
		List<KeyValue> attributes=null;
		String obsConcept = null;
		timeFormat = null;



		//Send Run ahead parser to check the next node, if it is the attributes node then process it,
		//Also move forward to the first obs and get the time format, if we hit the end series node, without finding any obs then stop
		boolean inSeries = true;
		if(parser.peak()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {



				if(inSeries && nodeName.equals("Attributes")) {
					parser.moveNextNode();  //move next to assert the namespace correclty
					assertNameSpace(GENERIC_NS);
					attributes = getKeyValues("Attributes", ERROR_POSITION.SERIES);  //We have got the series key attributes
				} else if(nodeName.equals("Time")) {
					obsConcept = parser.getElementText();
				} else if(nodeName.equals("ObsDimension")) {
					obsConcept = parser.getAttributeValue(null, "value");
				} 
			} 
		}

		if(isTimeSeries()) {
			// Determine the time format by using the run-ahead parser,
			// but this can't be done in SDMX 1.0 (since YYYY-01 can represent many things
			// For SDMX 1.0 try to use the FREQ dimension if present
			if (SDMX_SCHEMA.VERSION_ONE == schemaVersion) {

				DimensionBean frequencyDimension = getDataStructure().getFrequencyDimension();
				if (frequencyDimension != null) {
					for (KeyValue keyValue : key) {
						// Try to determine the timeFormat from the FREQ attribute
						if (keyValue.getConcept().equals(frequencyDimension.getId())) {
							try {
								timeFormat = TIME_FORMAT.getTimeFormatFromCodeId(keyValue.getCode());
							} catch (Exception e) {
								// Consume error. The time format value is simply an unexpected code.
							}
							break;
						}
					}
				}
			}
			setTimeFormat(obsConcept);
		}
		currentKey = KeyableImpl.seriesKey(currentDataflow, currentDsd, key, attributes);
		return currentKey;
	}

	/**
	 * To be called when the parser is on the Group Node
	 * @return
	 * @throws XMLStreamException
	 */
	@Override
	protected Keyable processGroupNode() {
		List<KeyValue> key = getKeyValues("GroupKey", ERROR_POSITION.GROUP);
		List<KeyValue> attributes=null;

		//Send Run ahead parser to check the next node, if it is the attributes node then process it, otherwise stop
		while(parser.moveNextNode()) {
			if(parser.isStartElement()) {
				if(parser.getElementName().equals("Attributes")) {
					assertNameSpace(GENERIC_NS);
					attributes = getKeyValues("Attributes", ERROR_POSITION.GROUP);
					
					//In SDMX v2.0 and v1.0 the Group Attribute may be followed by a Series
					//In SDMX v2.1 and higher we would expect the following element to be close Group
					//If we peak now and find it is a close Group then we can move onto it, allowing
					//Any positional information to include the close group bytes, otherwise
					//we will break out of this Group and allow the moveNext to discover and handle
					//whatever it was we just peaked
					parser.peak();
					if(!parser.isStartElement() &&  parser.getElementName().equals("Group")) {
						parser.moveNextNode();
					}
					break;
				} 
			} else if(parser.getElementName().equals("Group")) {
				break;
			}
		}
		currentKey = KeyableImpl.groupKey(currentDataflow, currentDsd, groupId, key, attributes);
		return currentKey;
	}

	@Override
	protected Observation processObsNode(StaxReader parser) {
		String obsDimension = null;
		String obsValue = null;
		List<KeyValue> attributes = null;

		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				assertNameSpace(GENERIC_NS);
				if(nodeName.equals("Time")) {
					obsDimension = parser.getElementText();
				} else if(nodeName.equals("ObsDimension")) {
					obsDimension = parser.getAttributeValue(null, "value");
				} else if(nodeName.equals("ObsValue")) {
					obsValue = parser.getAttributeValue(null, "value");
				} else if(nodeName.equals("Attributes")) {
					attributes = getKeyValues("Attributes", ERROR_POSITION.OBSERVATION);
				} else if(nodeName.equals("Annotations")) {
					parser.skipCurrentNode();
				} else {
					reportNotValidNode(false);
				}
			} else {
				if(nodeName.equals("Obs")) {
					break;
				}
			}
		}
		obsDimension = getComponentId(obsDimension);

		try {
			if(isTimeSeries()) {
				String obsTime = obsDimension;
				setTimeFormat(obsTime);
				try {
					obsTime = SdmxDateUtil.unifyObservationTime(obsDimension, schemaVersion, timeFormat, enforceStrict2_1);
				} catch (TimeFormatParsingException e) {
					handleException(e.getMessage(), true, SEVERITY.HIGH, TYPE.INVALID_DATE, ERROR_POSITION.OBSERVATION);
				}
				return ObservationImpl.timeSeries(currentKey, obsTime, obsValue, attributes);
			}
			if(obsDimension == null) {
				throw new SdmxSemmanticException("Error while processing observation for series '"+currentKey+"' , missing required cross sectional concept value '"+getCrossSectionConcept()+"'");
			}

			return ObservationImpl.crossSection(currentKey, getCrossSectionConcept(), obsDimension, obsValue, attributes);
		} catch(Throwable th) {
			if(currentKey != null) {
				throw new RuntimeException("Error while processing observation for key " + currentKey, th);
			}
			throw new RuntimeException("Error while processing observation");
		}
	}

	private void setTimeFormat(String obsTime) {
		if(obsTime != null && timeFormat == null) {
			try {
				timeFormat = DateUtil.getTimeFormatOfDate(obsTime);
			} catch (Exception e) {
				// Unable to determine timeFormat.  Consume error.
			}
		}
	}

	private List<KeyValue> getKeyValues(String endElement, ERROR_POSITION errorPosition)  {
		Set<String> existingMembers = new HashSet<>();
		List<KeyValue> returnList = new ArrayList<>();

		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				assertNameSpace(GENERIC_NS);
				if(nodeName.equals(endElement)) {

				} else if(nodeName.equals("KeyFamilyRef")) {
					// FR-1486: Do nothing. This prevents semantic exceptions
				} else if(nodeName.equals("KeyFamilyURI")) {
					// FR-1486: Do nothing. This prevents semantic exceptions
				} else if(nodeName.equals("ObsValue")) {
					// FR-1486 / DEV-2263 Do nothing. This prevents semantic exceptions
				} else 	if(nodeName.equals("Value")) {
					String attrId = isTwoPointOne ? "id" : "concept";
					Map<String, String> attributes = getAttributes("value", attrId);
					String componentId = attributes.get(attrId);
					String componetVal = attributes.get("value");

					if (existingMembers.contains(componentId)) {
						handleException("Duplicate " + endElement + " encountered: " + componentId, true, SEVERITY.LOW, TYPE.DUPLICATE, errorPosition);
					} else {
						existingMembers.add(componentId);
						if(isTwoPointOne) {
							returnList.add(KeyValueImpl.getInstance(componentId, componetVal));
						} else {
							componentId = getComponentId(componentId);
							returnList.add(KeyValueImpl.getInstance(componentId, componetVal));
						}
					}
				} else {
					reportNotValidNode(false);
				}
			} else {
				if(nodeName.equals(endElement)) {
					break;
				}
			}
		}
		return returnList;
	}
}
