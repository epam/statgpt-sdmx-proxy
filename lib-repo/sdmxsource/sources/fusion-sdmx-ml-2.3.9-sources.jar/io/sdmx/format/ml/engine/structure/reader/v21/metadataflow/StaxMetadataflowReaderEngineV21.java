package io.sdmx.format.ml.engine.structure.reader.v21.metadataflow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxMetadataflowReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<MetadataFlowMutableBean> {
	private static StaxMetadataflowReaderEngineV21 INSTANCE;

	private static final Logger LOG = LoggerFactory.getLogger(StaxMetadataflowReaderEngineV21.class);

	//Private constructor - lazy load instance
	private StaxMetadataflowReaderEngineV21() {}

	public static StaxMetadataflowReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataflowReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Metadataflows";
    }

    @Override
    protected String getRootNodeName() {
        return "Metadataflow";
    }
    
    @Override
    protected MetadataFlowMutableBean processMaintainable(IStaxReader reader) {
		MetadataFlowMutableBean metadataflow = new MetadataflowMutableBeanImpl();
		StaxMaintainableUtil.processBean(metadataflow, reader);
		StructureReferenceBean tgtRef = null;

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Structure")) {
				metadataflow.setMetadataStructureRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.MSD));
			} else if(nodeName.equals("Target")) {
				try {
					tgtRef = StaxStructureUtil.getStructureReference(reader, null);
				} catch (SdmxSemmanticException sse) {
					LOG.warn("Illegal reference supplied as MetadataDataflow target.");
				}
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}

		if (tgtRef == null) {
			LOG.warn("Parsing an SDMX-ML 2.1 MetadataFlow and no valid target reference supplied. Defaulting to refer to all structures");
			StructureReferenceBeanImpl srb = new StructureReferenceBeanImpl(SDMX_STRUCTURE_TYPE.ANY);
			tgtRef = srb;
		}
		metadataflow.addTarget(tgtRef);
		return metadataflow;
	}
}
