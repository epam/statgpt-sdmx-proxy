package io.sdmx.format.ml.model;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;

public class SDMXMLDataFormat extends SdmxDataFormat implements DataFormat {
	public static final SDMXMLDataFormat GENERIC_1_0 = new SDMXMLDataFormat(DATA_TYPE.GENERIC_1_0);
	public static final SDMXMLDataFormat GENERIC_2_0 = new SDMXMLDataFormat(DATA_TYPE.GENERIC_2_0);
	public static final SDMXMLDataFormat GENERIC_2_1 = new SDMXMLDataFormat(DATA_TYPE.GENERIC_2_1);
	
	public static final SDMXMLDataFormat COMPACT_1_0 = new SDMXMLDataFormat(DATA_TYPE.COMPACT_1_0);
	public static final SDMXMLDataFormat COMPACT_2_0 = new SDMXMLDataFormat(DATA_TYPE.COMPACT_2_0);
	public static final SDMXMLDataFormat COMPACT_2_1 = new SDMXMLDataFormat(DATA_TYPE.COMPACT_2_1);
	public static final SDMXMLDataFormat COMPACT_3_0 = new SDMXMLDataFormat(DATA_TYPE.COMPACT_3_0);
	public static final SDMXMLDataFormat UTILITY_1_0 = new SDMXMLDataFormat(DATA_TYPE.UTILITY_1_0);
	public static final SDMXMLDataFormat UTILITY_2_0 = new SDMXMLDataFormat(DATA_TYPE.UTILITY_2_0);
	
	public static final SDMXMLDataFormat CROSS_SECTIONAL_1_0 = new SDMXMLDataFormat(DATA_TYPE.CROSS_SECTIONAL_1_0);
	public static final SDMXMLDataFormat CROSS_SECTIONAL_2_0 = new SDMXMLDataFormat(DATA_TYPE.CROSS_SECTIONAL_2_0);

	public static final SDMXMLDataFormat MESSAGE_GROUP_1_0_COMPACT = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_1_0_COMPACT);
	public static final SDMXMLDataFormat MESSAGE_GROUP_1_0_GENERIC = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_1_0_GENERIC);
	public static final SDMXMLDataFormat MESSAGE_GROUP_1_0_UTILITY = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_1_0_UTILITY);
	
	public static final SDMXMLDataFormat MESSAGE_GROUP_2_0_COMPACT = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_2_0_COMPACT);
	public static final SDMXMLDataFormat MESSAGE_GROUP_2_0_GENERIC = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_2_0_GENERIC);
	public static final SDMXMLDataFormat MESSAGE_GROUP_2_0_UTILITY = new SDMXMLDataFormat(DATA_TYPE.MESSAGE_GROUP_2_0_UTILITY);
	
	public static final SDMXMLDataFormat EDI = new SDMXMLDataFormat(DATA_TYPE.EDI_TS);
	
	private static final long serialVersionUID = 4645305040609339151L;
	private FormatDetails details;
	
	
	protected SDMXMLDataFormat(DATA_TYPE dataType) {
		super(dataType);
	}
	
	public static SDMXMLDataFormat getFormat(DATA_TYPE dataType) {
		switch(dataType) {
		case COMPACT_1_0: return SDMXMLDataFormat.COMPACT_1_0;
		case COMPACT_2_0: return SDMXMLDataFormat.COMPACT_2_0;
		case COMPACT_2_1: return SDMXMLDataFormat.COMPACT_2_1;
		case COMPACT_3_0: return SDMXMLDataFormat.COMPACT_3_0;
		case GENERIC_1_0: return SDMXMLDataFormat.GENERIC_1_0;
		case GENERIC_2_0: return SDMXMLDataFormat.GENERIC_2_0;
		case GENERIC_2_1: return SDMXMLDataFormat.GENERIC_2_1;
		default:
			throw new SdmxNotImplementedException("Sdmx Data Format Not Supported: "+dataType.toString());
		}
	}

	protected String getName() {
		return getSdmxDataFormat().toString();
	}
	

	@Override
	public FormatDetails getFormatDetails() {
		if(details == null) {
			details = new FormatDetailsImpl(getName(), getFileExtension(), "application/xml", false, getAcceptHeader());
		}
		return details;
	}
	
	protected String[] getAcceptHeader() {
		String[] acceptHeader = new String[2];
		switch(getSdmxDataFormat()) {
		case CROSS_SECTIONAL_1_0 :
			acceptHeader[0] = "application/vnd.sdmx.crosssectionaldata+xml;version=1.0";
			break;
		case CROSS_SECTIONAL_2_0 :
			acceptHeader[0] = "application/vnd.sdmx.crosssectionaldata+xml;version=2.0";
			break;
		case MESSAGE_GROUP_1_0_UTILITY :
		case UTILITY_1_0 :
			acceptHeader[0] = "application/vnd.sdmx.utilitydata+xml;version=1.0";
			break;
		case MESSAGE_GROUP_2_0_UTILITY :
		case UTILITY_2_0 :
			acceptHeader[0] = "application/vnd.sdmx.utilitydata+xml;version=2.0";
			break;
		case MESSAGE_GROUP_1_0_GENERIC :
		case GENERIC_1_0 :
			acceptHeader[0] = "application/vnd.sdmx.genericdata+xml;version=1.0";
			break;
		case MESSAGE_GROUP_2_0_GENERIC :
		case GENERIC_2_0 :
			acceptHeader[0] = "application/vnd.sdmx.genericdata+xml;version=2.0";
			break;
		case GENERIC_2_1 :
			acceptHeader[0] = "application/vnd.sdmx.genericdata+xml;version=2.1";
			acceptHeader[1] = "application/vnd.sdmx.generictimeseriesdata+xml;version=2.1";
			break;
		case MESSAGE_GROUP_1_0_COMPACT :
		case COMPACT_1_0 :
			acceptHeader[0] = "application/vnd.sdmx.structurespecificdata+xml;version=1.0";
			break;
		case MESSAGE_GROUP_2_0_COMPACT :
		case COMPACT_2_0 :
			acceptHeader[0] = "application/vnd.sdmx.structurespecificdata+xml;version=2.0";
			break;
		case COMPACT_2_1 :
			acceptHeader[0] = "application/vnd.sdmx.structurespecificdata+xml;version=2.1";
			acceptHeader[1] = "application/vnd.sdmx.structurespecifictimeseriesdata+xml;version=2.1";
			break;
		case COMPACT_3_0 :
			acceptHeader[0] = "application/vnd.sdmx.data+xml;version=3.0.0";
			break;
		}
		if(acceptHeader[1] == null) {
			String[] trimmedHeader = new String[1];
			trimmedHeader[0] = acceptHeader[0];
			return trimmedHeader;
		}
		return acceptHeader;
	}

	private String getFileExtension() {
		return "xml";
	}
}