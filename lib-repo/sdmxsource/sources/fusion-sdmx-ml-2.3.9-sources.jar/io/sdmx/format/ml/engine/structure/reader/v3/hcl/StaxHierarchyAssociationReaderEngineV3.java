package io.sdmx.format.ml.engine.structure.reader.v3.hcl;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchyAssociationMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxMaintainableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.HierarchyAssociationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxHierarchyAssociationReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<HierarchyAssociationMutableBean> {
	private static StaxHierarchyAssociationReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHierarchyAssociationReaderEngineV3() {}
	public static StaxHierarchyAssociationReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHierarchyAssociationReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public String getContainerNodeName() {
        return "HierarchyAssociations";
    }
	
    @Override
    protected String getRootNodeName() {
        return "HierarchyAssociation";
    }
    
	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
    @Override
    protected HierarchyAssociationMutableBean processMaintainable(IStaxReader reader) {
		HierarchyAssociationMutableBean returnBean = new HierarchyAssociationMutableBeanImpl();
		StaxMaintainableUtilV3.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("LinkedHierarchy")) {
				returnBean.setHierarchyRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.HIERARCHY));
			} else if(nodeName.equals("LinkedObject")) {
				returnBean.setLinkedStructure(StaxStructureRefReaderV3.getStructureReference(reader, null));
			} else if(nodeName.equals("ContextObject")) {
				returnBean.setContextStructure(StaxStructureRefReaderV3.getStructureReference(reader, null));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
}
