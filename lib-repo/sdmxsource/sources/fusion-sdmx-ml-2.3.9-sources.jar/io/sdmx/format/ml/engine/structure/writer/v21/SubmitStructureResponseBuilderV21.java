package io.sdmx.format.ml.engine.structure.writer.v21;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v21.util.SdmxStaxSubmitResponseWriterV21;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.util.ValidationErrorUtil;
import io.sdmx.im.beans.container.SdmxBeansSorted;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class SubmitStructureResponseBuilderV21 implements IFusionSingleton {
	private SchemaLocationManager schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
	private HeaderRetrievalManager headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);

	private static SubmitStructureResponseBuilderV21 INSTANCE;

	//Private constructor - lazy load instance
	private SubmitStructureResponseBuilderV21() {}
	public static SubmitStructureResponseBuilderV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SubmitStructureResponseBuilderV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public void writeErrorResponse(Throwable th, IURNSingle<?> errorReference, OutputStream  out) {
		SdmxStaxSubmitResponseWriterV21.writeRegistrInterfaceDocument(out, "SubmitStructureResponse",
				headerRetrievalManager, schemaLocationManager, (writer) -> {
					addSubmissionResult(writer, errorReference, th, null);
				});
	}

	public void buildSuccessResponse(SdmxBeans beans, OutputStream out, IStructureValidationErrorHandler errorHandler) throws SdmxException {
		final SdmxBeansSorted sortedBeans = SdmxBeansSorted.getInstance(beans);
		SdmxStaxSubmitResponseWriterV21.writeRegistrInterfaceDocument(out, "SubmitStructureResponse",
				new HeaderRetrievalManager() {
			@Override
			public HeaderBean getHeader() {
				return sortedBeans.getHeader();
			}
		}, schemaLocationManager, (writer) -> {
			processMaintainables(writer, beans.getAction(), sortedBeans.getAllMaintainables(), errorHandler);
		});
	}

	public void buildSuccessResponse(SdmxBeansEvent beansEvent, OutputStream out) throws SdmxException {
		SdmxStaxSubmitResponseWriterV21.writeRegistrInterfaceDocument(out, "SubmitStructureResponse",
				headerRetrievalManager, schemaLocationManager, (writer) -> {
					processMaintainables(writer, beansEvent);
				});
	}

	private void processMaintainables(StaxWriter writer, DATASET_ACTION action, Set<MaintainableBean> maints, IStructureValidationErrorHandler errorHandler) {
		// Write any successes
		for(MaintainableBean maint : maints) {
			addSubmissionResult(writer, maint.getURN(), null, DATASET_ACTION.APPEND);
		}

		// Write any errors
		Map<String, List<String>> maintsToErrors = ValidationErrorUtil.createMapOfMaintainableURNs(errorHandler);
		for (Entry<String, List<String>> m : maintsToErrors.entrySet()) {
			addSubmissionResultFailure(writer, m.getKey(), m.getValue());
		}
	}

	private void processMaintainables(StaxWriter writer, SdmxBeansEvent beansEvent) {
		SdmxBeans additions = SdmxBeansSorted.getInstance(beansEvent.getAdditions());
		for(MaintainableBean maint : additions.getAllMaintainables()) {
			addSubmissionResult(writer, maint.getURN(), null, DATASET_ACTION.APPEND);
		}

		SdmxBeans modifications = SdmxBeansSorted.getInstance(beansEvent.getModification());
		for(MaintainableBean maint : modifications.getAllMaintainables()) {
			addSubmissionResult(writer, maint.getURN(), null, DATASET_ACTION.REPLACE);
		}

		SdmxBeans deletions = SdmxBeansSorted.getInstance(beansEvent.getDeletions());
		for(MaintainableBean maint : deletions.getAllMaintainables()) {
			addSubmissionResult(writer, maint.getURN(), null, DATASET_ACTION.DELETE);
		}
	}

	private void addSubmissionResult(StaxWriter writer, IURN<?> sRef, Throwable th, DATASET_ACTION action) {
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "SubmissionResult");
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "SubmittedStructure");

		// FR-2020 - Add the action type to the response
		if (action != null) {
			writer.writeAttribute("action", action.getAction());
		}
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "MaintainableObject");
		if(sRef != null && !sRef.isWildcard()) {
			writer.writeElement(null, "URN", sRef.getURN());
		} else {
			StaxRefUtil.writeReference(sRef, writer, "Ref");
		}

		writer.writeEndElement();  //End MaintainableObject
		writer.writeEndElement();  //End SubmittedStructure

		SdmxStaxSubmitResponseWriterV21.writeStatusMessage(th, writer);
		writer.writeEndElement();  //End SubmissionResult

	}
	
	private void addSubmissionResultFailure(StaxWriter writer, String urn, List<String> errors) {
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "SubmissionResult");
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "SubmittedStructure");

		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "MaintainableObject");
		writer.writeElement(null, "URN", urn);
		writer.writeEndElement();  //End MaintainableObject
		writer.writeEndElement();  //End SubmittedStructure

		// Status Message
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "StatusMessage");
		writer.writeAttribute("status", "Failure");

		if (!errors.isEmpty()) {
			writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "MessageText");
			for (String anError : errors) {
				writer.writeStartElement(SDMX_NAMESPACE.COMMON_21.getNamespace(), "Text");
				writer.writeElementText(anError);
				writer.writeEndElement(); //End Text
			}
			writer.writeEndElement();  //End MessageText
		}
		writer.writeEndElement(); //End StatusMessage
		writer.writeEndElement();  //End SubmissionResult
	}
}
