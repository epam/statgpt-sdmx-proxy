package io.sdmx.format.ml.engine.structure.reader.v3.metadata;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMetadataflowReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<MetadataFlowMutableBean> {
	private static StaxMetadataflowReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataflowReaderEngineV3() {}

	public static StaxMetadataflowReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataflowReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
        return "Metadataflows";
    }
	
    @Override
    protected String getRootNodeName() {
        return "Metadataflow";
    }
    
    @Override
    protected MetadataFlowMutableBean processMaintainable(IStaxReader reader) {
		MetadataFlowMutableBean metadataflow = new MetadataflowMutableBeanImpl();
		StaxMaintainableUtil.processBean(metadataflow, reader);
		
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Structure")) {
				metadataflow.setMetadataStructureRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.MSD));
			} else if(nodeName.equals("Target")) {
				metadataflow.addTarget(StaxStructureRefReaderV3.getStructureReference(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return metadataflow;
	}
}
