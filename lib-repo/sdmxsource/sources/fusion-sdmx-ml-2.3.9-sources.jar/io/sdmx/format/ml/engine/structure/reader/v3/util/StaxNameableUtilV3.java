package io.sdmx.format.ml.engine.structure.reader.v3.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxNameableUtilV3 {

	/**
	 * Process bean either leave at the start of an unknown node, or the end of the object
	 * @param bean
	 * @param reader
	 */
	public static void processBean(NameableMutableBean bean, IStaxReader reader) {
		StaxIdentifiableUtilV3.processBean(bean, reader);
		while(processNode(bean, reader)) {
			//Processing Nodes
			reader.moveNextNode();
		}
	}
	
	public static boolean processNode(NameableMutableBean nameableMutableBean, IStaxReader staxReader) {
//		if(!staxReader.isStartElement()) {
//			//If it is an end element, we are expecting that to be end annotations, otherwise it should be
//			//the start of a name or description
//			staxReader.moveNextNode();
//		}
		if(staxReader.isStartElement()) {
			String nodeNameEnum = staxReader.getElementName();
			if(nodeNameEnum.equals("Name")) {
				nameableMutableBean.addName(StaxStructureUtil.getText(staxReader));
				return true; 
			} else if(nodeNameEnum.equals("Description")) {
				nameableMutableBean.addDescription(StaxStructureUtil.getText(staxReader));
				return true;
			}
			//If it is not a name or description then it is an unknown node, so we leave the method for
			//something else to process it
		}
		return false;
	}
}
