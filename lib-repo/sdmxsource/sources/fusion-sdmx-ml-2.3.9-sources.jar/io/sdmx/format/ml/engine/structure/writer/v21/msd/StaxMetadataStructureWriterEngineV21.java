package io.sdmx.format.ml.engine.structure.writer.v21.msd;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataAttributeContainerBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataStructureDefinitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxAnnotableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRepresentationWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxIdentifiableWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

/*
 * Although the SDMX v3.0 IM does not have all the information required to output an SDMX v2.1 MSD, we will hard code some aspects
 * such as the target (there is only 1 and it is linked to Dataflow), and there is only 1 report structure called Report
 */
public class StaxMetadataStructureWriterEngineV21 extends AbstractV21Writer<MetadataStructureDefinitionBean> implements IFusionSingleton {
	private static StaxMetadataStructureWriterEngineV21 INSTANCE;
	
	private static final String TARGET_ID= "Target"; //hard code the metadata target ID, required for v2.1, as it no longer exists in the v3.0 model
	private static final String REPORT_ID= "Report"; //hard code the metadata report ID, required for v2.1, as it no longer exists in the v3.0 model
	

	//Private constructor - lazy load instance
	private StaxMetadataStructureWriterEngineV21() {}

	public static StaxMetadataStructureWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataStructureWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "MetadataStructure";
	}


	@Override
	protected void writeMaintainableInternal(MetadataStructureDefinitionBean maint, StaxWriter writer) {
		writer.writeStartElement(NS, "MetadataStructureComponents");
		writeMetadataTargetBean(writer);
		writeReportStructureBean(maint, writer);
		writer.writeEndElement(); //MetadataStructureComponents
	}
	
	/**
	 * Writes a default target to an identifiable
	 * @param writer
	 */
	private void writeMetadataTargetBean(StaxWriter writer) {
		writeIdentifiableElement(writer, "MetadataTarget", TARGET_ID);
		writeIdentifiableElement(writer, "IdentifiableObjectTarget", "IdentifiableObjectTarget");

		//ideally this would have been 'Any' or 'IdentifiableObjectType' but the .stat service we want to save to does not support these
		writer.writeAttribute("objectType", "Dataflow");  
			
		writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "LocalRepresentation");
		writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "TextFormat ");
		writer.writeAttribute("textType", "IdentifiableReference");

		writer.writeEndElement(); //End TextFormat
		writer.writeEndElement(); //End LocalRepresentation
		writer.writeEndElement(); //End IdentifiableObjectTarget
		writer.writeEndElement(); //End MetadataTarget
	}
	
	private void writeReportStructureBean(MetadataStructureDefinitionBean msd, StaxWriter writer) {
		writeIdentifiableElement(writer, "ReportStructure", REPORT_ID);
		writeMetadataAttributes(msd, writer);
		StaxRefUtil.writeLocalReference(TARGET_ID, writer, "MetadataTarget");
		writer.writeEndElement(); //End ReportStructure
	}
	
	private void writeIdentifiableElement(StaxWriter writer, String elementName, String id) {
		writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName);
		writer.writeAttribute("id", id);
	}
	
	private void writeMetadataAttributes(MetadataAttributeContainerBean attributeContainer, StaxWriter writer) {
		for(MetadataAttributeBean metadataAttribute : attributeContainer.getMetadataAttributes()) {
			writer.writeStartElement(NS, "MetadataAttribute");

			Map<String, String> attributes = StaxIdentifiableWriterUtilV3.getAttributes(metadataAttribute);
			if(metadataAttribute.getPresentational().isTrue()) {
				attributes.put("isPresentational", "true");
			}
			attributes.put("maxOccurs", "unbounded");
			
			RepresentationBean representation = metadataAttribute.getRepresentation();
			if(representation != null) {
				if(representation.getMinOccurs() != null && representation.getMinOccurs() >= 0) {
					attributes.put("minOccurs", Integer.toString(metadataAttribute.getMinOccurs()));
				}
				Integer maxOccurs = representation.getMaxOccurs();
				if(maxOccurs != null && maxOccurs >= 1 && maxOccurs < Integer.MAX_VALUE) {
					attributes.put("maxOccurs", Integer.toString(metadataAttribute.getMaxOccurs()));
				}
			}
			writer.writeAttributes(attributes);
			StaxAnnotableWriterUtil.writeBean(metadataAttribute, writer);
			StaxRefUtil.writeReference(metadataAttribute.getConceptRef(), writer, "ConceptIdentity");
			if(representation != null) {
				if(representation.getTextFormat() != null || representation.getRepresentation() != null) {
					StaxRepresentationWriterUtil.writeRepresentation(metadataAttribute.getRepresentation(), writer, "LocalRepresentation", true);
				}
			}
			writeMetadataAttributes(metadataAttribute, writer);

			writer.writeEndElement(); //End MetadataAttribute
		}
	}
}