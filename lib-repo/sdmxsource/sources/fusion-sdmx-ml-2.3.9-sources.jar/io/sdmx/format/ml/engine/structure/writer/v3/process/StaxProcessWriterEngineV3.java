package io.sdmx.format.ml.engine.structure.writer.v3.process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.process.ComputationBean;
import io.sdmx.api.sdmx.model.beans.process.InputOutputBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessBean;
import io.sdmx.api.sdmx.model.beans.process.ProcessStepBean;
import io.sdmx.api.sdmx.model.beans.process.TransitionBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxIdentifiableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxTextWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxProcessWriterEngineV3 extends AbstractV3Writer<ProcessBean> implements IFusionSingleton {
	private static StaxProcessWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProcessWriterEngineV3() {}

	public static StaxProcessWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProcessWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Process";
	}

	@Override
	protected void writeMaintainableInternal(ProcessBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeProcessStep(maint.getProcessSteps(), externalLinks, writer);
	}

	private void writeProcessStep(List<ProcessStepBean> processSteps, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ProcessStepBean processStep : processSteps) {
			StaxNameableWriterUtilV3.writeBean(processStep, "ProcessStep", externalLinks, writer);
			writeInputOutputBean(processStep.getInput(), "Input", writer);
			writeInputOutputBean(processStep.getOutput(), "Output", writer);
			writeComputation(processStep.getComputation(), writer);
			writeTransition(processStep.getTransitions(), externalLinks, writer);
			writeProcessStep(processStep.getProcessSteps(), externalLinks, writer);
			writer.writeEndElement(); //End ProcessStep
		}
	}

	private void writeInputOutputBean(List<InputOutputBean> inOutBeans, String nodeName, StaxWriter writer) {
		for(InputOutputBean inOut : inOutBeans) {
			writer.writeStartElement(NS, nodeName);
			writer.writeAttribute("localID", inOut.getLocalId());
			StaxAnnotableWriterUtilV3.writeBean(inOut, writer);
			StaxRefUtilV3.writeReference(inOut.getStructureReference(), writer, "ObjectReference");
			writer.writeEndElement(); //End Input Output
		}
	}

	private void writeComputation(ComputationBean comp, StaxWriter writer) {
		if(comp != null) {
			writer.writeStartElement(NS, "Computation");
			writer.writeAttribute("localID", comp.getLocalId());
			writer.writeAttribute("softwarePackage", comp.getSoftwarePackage());
			writer.writeAttribute("softwareLanguage", comp.getSoftwareLanguage());
			writer.writeAttribute("softwareVersion", comp.getSoftwareVersion());
			StaxAnnotableWriterUtilV3.writeBean(comp, writer);
			StaxTextWriterUtilV3.writeTextTypes(comp.getDescription(), writer, "Description");
			writer.writeEndElement(); //End Computation
		}
	}

	private void writeTransition(List<TransitionBean> transitions, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(TransitionBean transition : transitions) {
			Map<String, String> attributes = new HashMap<>();
			attributes.put("localID", transition.getLocalId());
			StaxIdentifiableWriterUtilV3.writeBean(transition, "Transition", externalLinks, writer, attributes);
			StaxRefUtilV3.writeLocalReference(transition.getTargetStep().getFullIdPath(false), writer, "TargetStep");
			StaxTextWriterUtilV3.writeTextTypes(NS, transition.getCondition(), writer, "Condition");
			writer.writeEndElement(); //End Transition
		}
	}
}
