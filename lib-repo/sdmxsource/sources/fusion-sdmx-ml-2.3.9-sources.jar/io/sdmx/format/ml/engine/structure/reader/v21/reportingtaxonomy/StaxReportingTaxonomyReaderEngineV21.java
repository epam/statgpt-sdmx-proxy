package io.sdmx.format.ml.engine.structure.reader.v21.reportingtaxonomy;

import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingCategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.ReportingTaxonomyMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.categoryscheme.ReportingCategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.ReportingTaxonomyMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxReportingTaxonomyReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<ReportingTaxonomyMutableBean> {
	private static StaxReportingTaxonomyReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxReportingTaxonomyReaderEngineV21() {}

	public static StaxReportingTaxonomyReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxReportingTaxonomyReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "ReportingTaxonomies";
    }

    @Override
    protected String getRootNodeName() {
        return "ReportingTaxonomy";
    }

    @Override
    protected ReportingTaxonomyMutableBean processMaintainable(IStaxReader reader) {
		ReportingTaxonomyMutableBean repTax = new ReportingTaxonomyMutableBeanImpl();
		StaxItemSchemeUtil.processBean(repTax, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("ReportingCategory")) {
				repTax.addItem(processReportingCategory(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return repTax;
	}

	private ReportingCategoryMutableBean processReportingCategory(IStaxReader reader) {
		ReportingCategoryMutableBean repCat = new ReportingCategoryMutableBeanImpl();
		StaxNameableUtil.processBean(repCat, reader);
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("ReportingCategory")) {
				repCat.addItem(processReportingCategory(reader));
			} else if(nodeName.equals("StructuralMetadata")) {
				repCat.addStructuralMetadata(StaxStructureUtil.getStructureReference(reader, null));
			} else if(nodeName.equals("ProvisioningMetadata")) {
				repCat.addProvisioningMetadata(StaxStructureUtil.getStructureReference(reader, null));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return repCat;
	}
}
