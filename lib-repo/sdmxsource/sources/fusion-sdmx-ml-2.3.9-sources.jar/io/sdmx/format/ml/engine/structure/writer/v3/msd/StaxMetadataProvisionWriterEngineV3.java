package io.sdmx.format.ml.engine.structure.writer.v3.msd;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMetadataProvisionWriterEngineV3 extends AbstractV3Writer<MetadataProvisionAgreementBean> implements IFusionSingleton {
	private static StaxMetadataProvisionWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataProvisionWriterEngineV3() {}

	public static StaxMetadataProvisionWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataProvisionWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "MetadataProvisionAgreement";
	}

	@Override
	protected void writeMaintainableInternal(MetadataProvisionAgreementBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getMetadataflowRef(), writer, "Metadataflow");
		StaxRefUtilV3.writeReference(maint.getMetadataProviderRef(), writer, "MetadataProvider");
		
		for(ICrossReferenceBeanBase target : maint.getTargets()) {
			StaxRefUtilV3.writeReference(target, writer, "Target");
		}
	}
}
