package io.sdmx.format.ml.engine.structure.writer.v3.categorisation;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCategorisationWriterEngineV3 extends AbstractV3Writer<CategorisationBean> implements IFusionSingleton {
	private static StaxCategorisationWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorisationWriterEngineV3() {}
	public static StaxCategorisationWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorisationWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Categorisation";
	}

	@Override
	protected void writeMaintainableInternal(CategorisationBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getStructureReference(), writer, "Source");
		StaxRefUtilV3.writeReference(maint.getCategoryReference(), writer, "Target");
	}
}
