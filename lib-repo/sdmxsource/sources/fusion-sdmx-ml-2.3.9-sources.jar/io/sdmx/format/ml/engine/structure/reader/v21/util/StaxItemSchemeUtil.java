package io.sdmx.format.ml.engine.structure.reader.v21.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxItemSchemeUtil  {
	
	public static void processBean(ItemSchemeMutableBean<? extends ItemMutableBean> bean, IStaxReader reader) {
		boolean isPartial = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "isPartial", false, false);
		bean.setPartial(isPartial);
		StaxMaintainableUtil.processBean(bean, reader);
	}
}
