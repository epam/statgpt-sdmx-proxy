package io.sdmx.format.ml.engine.structure.writer.v21.hcl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxIdentifiableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxTextFormatWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxHclWriterEngineV21 extends AbstractV21Writer<HierarchyBean> implements IFusionSingleton {
	private static StaxHclWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHclWriterEngineV21() {}

	public static StaxHclWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHclWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "HierarchicalCodelist";
	}

	@Override
	protected void writeMaintainableInternal(HierarchyBean maint, StaxWriter writer) {
		Map<String, String> attrs = new HashMap<>();
		attrs.put("leveled", Boolean.toString(maint.hasFormalLevels()));
		StaxNameableWriterUtil.writeBean(maint, "Hierarchy", writer, attrs);
		writeHierarchicalCode(maint.getHierarchicalCodeBeans(), writer);
		writeLevel(maint.getLevel(), writer);
		writer.writeEndElement(); //End Hierarchy
	}

	private void writeHierarchicalCode(List<HierarchicalCodeBean> hCode, StaxWriter writer) {
		for(HierarchicalCodeBean currentHCode : hCode) {
			Map<String, String> attrs = new HashMap<>();
			if(currentHCode.getValidFrom() != null) {
				attrs.put("validFrom", currentHCode.getValidFrom().getDateInSdmxFormat());
			}
			if(currentHCode.getValidTo() != null) {
				attrs.put("validTo", currentHCode.getValidTo().getDateInSdmxFormat());
			}
			StaxIdentifiableWriterUtil.writeBean(currentHCode, "HierarchicalCode", writer, attrs);
			StaxRefUtil.writeReference(currentHCode.getCodeReference(), writer, "Code");
			writeHierarchicalCode(currentHCode.getCodeRefs(), writer);
			if(currentHCode.getLevel(false) != null) {
				StaxRefUtil.writeLocalReference(currentHCode.getLevel(false).getFullIdPath(false), writer, "Level");
			}
			writer.writeEndElement(); //End  HierarchicalCode
		}
	}

	private void writeLevel(LevelBean level, StaxWriter writer) {
		if(level != null) {
			StaxNameableWriterUtil.writeBean(level, "Level", writer);
			StaxTextFormatWriterUtil.writeTextFormat(level.getCodingFormat(), writer, "CodingFormat");
			writeLevel(level.getChildLevel(), writer);
			writer.writeEndElement(); //End  Level
		}
	}
}
