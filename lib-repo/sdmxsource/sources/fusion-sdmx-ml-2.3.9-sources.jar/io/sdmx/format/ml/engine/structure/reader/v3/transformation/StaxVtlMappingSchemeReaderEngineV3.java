package io.sdmx.format.ml.engine.structure.reader.v3.transformation;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IVtlMappingSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.VtlCodelistMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlConceptMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlDataflowMappingMutableBean;
import io.sdmx.im.mutable.transformation.VtlMappingSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxVtlMappingSchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IVtlMappingSchemeMutableBean> implements IFusionSingleton {
	private static StaxVtlMappingSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxVtlMappingSchemeReaderEngineV3() {}

	public static StaxVtlMappingSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxVtlMappingSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "VtlMappingSchemes";
	}

	@Override
	protected String getRootNodeName() {
		return "VtlMappingScheme";
	}

	@Override
	protected IVtlMappingSchemeMutableBean processMaintainable(IStaxReader reader) {
		IVtlMappingSchemeMutableBean maint = new VtlMappingSchemeMutableBean();
		StaxItemSchemeUtil.processBean(maint, reader);

		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("VtlMapping")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			IVtlMappingMutableBean item = readItem(reader);
			maint.addItem(item);
			reader.moveNextNode();
		}
		return maint;
	}

	private IVtlMappingMutableBean readItem(IStaxReader reader) {
		//We don't know what the concrete sub type is until we have finished processing the nameable section, so for now
		//use a container for this information which can then be copied accross
		IVtlMappingMutableBean nameable = new VtlDataflowMappingMutableBean();
		String alias = reader.getAttributeValue("alias");
		StaxNameableUtil.processBean(nameable, reader);

		IVtlMappingMutableBean item = null;
		outer:
		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "Codelist" :
					item = new VtlCodelistMappingMutableBean();
					item.setMapped(new StructureReferenceBeanImpl(reader.getElementText(), SDMX_STRUCTURE_TYPE.CODE_LIST));
					break;
				case "Concept" :
					item = new VtlConceptMappingMutableBean();
					item.setMapped(new StructureReferenceBeanImpl(reader.getElementText(), SDMX_STRUCTURE_TYPE.CONCEPT));
					break;
				case "Dataflow" :
					VtlDataflowMappingMutableBean dfMapping = new VtlDataflowMappingMutableBean();
					item = dfMapping;
					item.setMapped(new StructureReferenceBeanImpl(reader.getElementText(), SDMX_STRUCTURE_TYPE.DATAFLOW));
					readDataflowMapping(dfMapping, reader);
					break outer;
				}
			} else if(reader.getElementName().equals("VtlMapping")) {
				break;
			}
		} while(reader.moveNextNode());
		item.setAlias(alias);
		item.setNames(nameable.getNames());
		item.setDescriptions(nameable.getDescriptions());
		item.setAnnotations(nameable.getAnnotations());
		item.setId(nameable.getId());
		return item;
	}

	private void readDataflowMapping(VtlDataflowMappingMutableBean mapping, IStaxReader reader) {
		List<String> fromKey = new ArrayList<>();
		List<String> toKey = new ArrayList<>();


		List<String> currentKey = null;

		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "FromVtlMapping" :
					mapping.setFromMethod(reader.getAttributeValue("method"));
					break;
				case "ToVtlMapping" :
					mapping.setToMethod(reader.getAttributeValue("method"));
					break;
				case "FromVtlSuperSpace" :
					currentKey = fromKey;
				break;
				case "ToVtlSubSpace" :
					currentKey = toKey;
				break;
				case "Key" :
					if(currentKey == null) {
						throw new SdmxSemmanticException("Error reading VtlMapping Key element expected under FromVtlSuperSpace or ToVtlSubSpace");
					}
					currentKey.add(reader.getElementText());
				break;
				}
			} else if(reader.getElementName().equals("VtlMapping")) {
				break;
			}
		} while(reader.moveNextNode());
		mapping.setFromSubSpace(fromKey);
		mapping.setToSubSpace(toKey);
	}
}
