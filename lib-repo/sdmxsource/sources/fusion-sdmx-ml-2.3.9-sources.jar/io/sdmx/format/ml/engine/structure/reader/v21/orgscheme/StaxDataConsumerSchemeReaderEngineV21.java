package io.sdmx.format.ml.engine.structure.reader.v21.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataConsumerSchemeReaderEngineV21 extends StaxAbstractOrgansiationReaderV21 {
    private static StaxDataConsumerSchemeReaderEngineV21 INSTANCE;

    //Private constructor - lazy load instance
    private StaxDataConsumerSchemeReaderEngineV21() {}

    public static StaxDataConsumerSchemeReaderEngineV21 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxDataConsumerSchemeReaderEngineV21();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public DataConsumerSchemeMutableBean processMaintainable(IStaxReader reader) {
        DataConsumerSchemeMutableBean dpScheme = new DataConsumerSchemeMutableBeanImpl();
        StaxItemSchemeUtil.processBean(dpScheme, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("DataConsumer")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processDataConsumer(dpScheme, reader);
            reader.moveNextNode();
        }
        return dpScheme;
    }

    private void processDataConsumer(DataConsumerSchemeMutableBean beanToPopulate, IStaxReader reader) {
        DataConsumerMutableBean consumer = new DataConsumerMutableBeanImpl();
        beanToPopulate.addItem(consumer);
        super.processOrganisation(consumer, reader);
    }
}
