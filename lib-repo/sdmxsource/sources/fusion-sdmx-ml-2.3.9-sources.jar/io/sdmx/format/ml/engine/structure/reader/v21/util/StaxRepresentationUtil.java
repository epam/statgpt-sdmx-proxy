package io.sdmx.format.ml.engine.structure.reader.v21.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxRepresentationUtil {

	public static RepresentationMutableBean processBean(IStaxReader reader, boolean isCodelist) {
		RepresentationMutableBean bean = new RepresentationMutableBeanImpl();
		processBean(reader, bean, isCodelist);
		return bean;
	}

	
	public static void processBean(IStaxReader reader, RepresentationMutableBean bean, boolean isCodelist) {
		String exitNode = reader.getElementName();
		
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("TextFormat")) {
					bean.setTextFormat(StaxTextFormatUtil.processBean(reader));
				} else if(nodeName.equals("Enumeration")) {
					bean.setRepresentation(StaxStructureUtil.getStructureReference(reader, isCodelist ? SDMX_STRUCTURE_TYPE.CODE_LIST : SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME));
				} else if(nodeName.equals("EnumerationFormat")) {
					bean.setTextFormat(StaxTextFormatUtil.processBean(reader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitNode)) {
				break;
			}
		}
	}
}
