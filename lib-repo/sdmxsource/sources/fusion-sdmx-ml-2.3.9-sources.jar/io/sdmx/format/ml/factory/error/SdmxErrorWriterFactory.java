package io.sdmx.format.ml.factory.error;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.engine.ErrorWriterEngine;
import io.sdmx.api.sdmx.factory.ErrorWriterFactory;
import io.sdmx.api.sdmx.model.validation.ErrorFormat;
import io.sdmx.format.ml.engine.error.ErrorWriterEngineV21;
import io.sdmx.format.ml.model.SdmxErrorFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Returns the SDMX version 2.1 error message writer
 */
public class SdmxErrorWriterFactory implements ErrorWriterFactory, IFusionSingleton {
	private ErrorWriterEngineV21 errorWriterEngine = ErrorWriterEngineV21.getInstance();

	private static SdmxErrorWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxErrorWriterFactory() {}

	public static SdmxErrorWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxErrorWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxErrorWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public ErrorWriterEngine getErrorWriterEngine(ErrorFormat format) {
		if(format instanceof SdmxErrorFormat) {
			return errorWriterEngine;
		}
		return null;
	}

}
