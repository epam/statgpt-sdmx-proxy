package io.sdmx.format.ml.engine.structure.writer.v2;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxStructureWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;


public class StaxStructureWriterEngineV2 extends StaxAbstractStructureWriterEngineV2 implements IFusionSingleton {
	private static StaxStructureWriterEngineV2 INSTANCE;
	private static StaxStructureWriterEngineV2 PRETTY_INSTANCE;

	public static StaxStructureWriterEngineV2 getInstance(boolean prettyPrint) {
		if(!prettyPrint) {
			return getInstance();
		}
		if(PRETTY_INSTANCE == null) {
			PRETTY_INSTANCE = new StaxStructureWriterEngineV2();
			PRETTY_INSTANCE.prettyPrint = true;
			FusionBeanStore.registerInstance(PRETTY_INSTANCE);
		}
		return PRETTY_INSTANCE;
	}

	public static StaxStructureWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureWriterEngineV2();
			INSTANCE.prettyPrint = false;
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
        PRETTY_INSTANCE = null;
    }

	private StaxStructureWriterEngineV2() {
		super(SDMX_SCHEMA.VERSION_TWO,
		        StaxStructureWriterUtilV2.MESSAGE_NS,
		        StaxStructureWriterUtilV2.STRUCTURE_NS,
		        StaxStructureWriterUtilV2.COMMON_NS,
		        null);
	}


	@Override
	protected String getDocumentRoot() {
		return "Structure";
	}

	@Override
	protected void afterHeader(StaxWriter writer, DATASET_ACTION action) {
		//Do nothing
	}
}
