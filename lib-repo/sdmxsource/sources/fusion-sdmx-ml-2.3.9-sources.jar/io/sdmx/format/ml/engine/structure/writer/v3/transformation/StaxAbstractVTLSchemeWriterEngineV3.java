package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;

public abstract class StaxAbstractVTLSchemeWriterEngineV3<T extends IVtlSchemeBean> extends AbstractV3Writer<T> { 

	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(T maint) {
		Map<String, String> map = new HashMap<>();
		map.put("vtlVersion", maint.getVtlVersion());
		return map; 
	}
	
}
