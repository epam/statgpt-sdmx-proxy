package io.sdmx.format.ml.factory.structure;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.factory.structure.StructureWriterFactory;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.format.ml.engine.structure.writer.v1.StaxStructureWriterEngineV1;
import io.sdmx.format.ml.engine.structure.writer.v2.StaxStructureWriterEngineV2;
import io.sdmx.format.ml.engine.structure.writer.v21.StaxRegistrySubmitWriterEngineV21;
import io.sdmx.format.ml.engine.structure.writer.v21.StaxStructureWriterEngineV21;
import io.sdmx.format.ml.engine.structure.writer.v3.StaxStructureWriterEngineV3;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxMLStructureWriterFactory implements StructureWriterFactory, IFusionSingleton {
	private static SdmxMLStructureWriterFactory INSTANCE;

	public static SdmxMLStructureWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static SdmxMLStructureWriterFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxMLStructureWriterFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxMLStructureWriterFactory() {}

	@Override
	public StructureWriterEngine getStructureWriterEngine(StructureFormat outputFormat) {
		if(outputFormat instanceof SdmxStructureFormat) {
			SdmxStructureFormat sdmxStructureFormat = (SdmxStructureFormat) outputFormat;
			boolean prettyPrint = sdmxStructureFormat.isPrettyPrint();
			switch(outputFormat.getSdmxOutputFormat()) {
			case SDMX_V1_STRUCTURE_DOCUMENT:
				return StaxStructureWriterEngineV1.getInstance(prettyPrint);
			case SDMX_V21_QUERY_RESPONSE_DOCUMENT:
				break;
			case SDMX_V21_REGISTRY_SUBMIT_DOCUMENT:
				return StaxRegistrySubmitWriterEngineV21.getInstance(prettyPrint);
			case SDMX_V21_STRUCTURE_DOCUMENT:
				return StaxStructureWriterEngineV21.getInstance(prettyPrint);
			case SDMX_V2_REGISTRY_QUERY_RESPONSE_DOCUMENT:
				break;
			case SDMX_V2_REGISTRY_SUBMIT_DOCUMENT:
				break;
			case SDMX_V2_STRUCTURE_DOCUMENT:
				return StaxStructureWriterEngineV2.getInstance(prettyPrint);
			case SDMX_V3_STRUCTURE_DOCUMENT:
				return StaxStructureWriterEngineV3.getInstance(prettyPrint);
			default:
				break;
			}
		}
		return null;
	}

	@Override
	public Integer getPriority() {
		return 11;
	}
}
