package io.sdmx.format.ml.engine.structure.writer.v2.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataConsumerSchemeWriterEngineV2 extends StaxAbstractOrganisationSchemeWriterEngineV2<DataConsumerSchemeBean, DataConsumerBean> implements IFusionSingleton {
	private static StaxDataConsumerSchemeWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataConsumerSchemeWriterEngineV2() {}

	public static StaxDataConsumerSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataConsumerSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "OrganisationScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "DataConsumer";
	}

	@Override
    protected String getGroupNodeName() {
        return "DataConsumers";
    }
}
