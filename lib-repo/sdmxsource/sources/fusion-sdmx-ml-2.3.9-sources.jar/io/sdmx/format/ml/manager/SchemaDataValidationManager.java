package io.sdmx.format.ml.manager;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.api.sdmx.constants.DATA_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.api.sdmx.manager.schema.SchemaValidationManager;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.im.beans.reference.RESTSchemaQueryImpl;
import io.sdmx.format.ml.factory.data.SdmxMLDataFormatFactory;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;
import io.sdmx.format.ml.util.XMLParser;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.application.SingletonStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Validates data from a DataStructure against a Generated Schema
 */
public class SchemaDataValidationManager implements SchemaValidationManager, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SchemaDataValidationManager.class);

	private static SchemaDataValidationManager INSTANCE;

	public static SchemaDataValidationManager getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SchemaDataValidationManager();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SchemaDataValidationManager() {}

	@Override
	public void validateDatasetAgainstSchema(ReadableDataLocation dataset, DataStructureSuperBean dsd)  throws SdmxSemmanticException, SdmxSyntaxException {
		LOG.info("Validating dataset against schema");
		DataFormat dataFormat = SdmxMLDataFormatFactory.getInstance().getDataFormat(dataset);
		if(!(dataFormat instanceof SdmxDataFormat)) {
			throw new IllegalArgumentException("Could not determine datatype of data.  Expecting an SDMX message");
		}
		SdmxDataFormat sdmxDataFormat = (SdmxDataFormat)dataFormat;
		//Only validate if it is an SDMX data format
		DATA_TYPE dataType = sdmxDataFormat.getSdmxDataFormat();
		if(dataType == DATA_TYPE.GENERIC_1_0 || dataType == DATA_TYPE.GENERIC_2_0) {
			LOG.debug("Validate against Generic XSD");
			XMLParser.validateXML(dataset, dataType.getSchemaVersion());
		} else {
			if(dsd == null) {
				throw new IllegalArgumentException("Can not generate a Schema, no DataStructure was supplied");
			}
			WriteableDataLocation schemaLocation = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation();
			OutputStream out = null;
			SchemaFormat format = null;
			switch (dataType.getSchemaVersion()) {
			case VERSION_ONE:
				format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V1_0);
				break;
			case VERSION_TWO:
				format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_0);
				break;
			case VERSION_TWO_POINT_ONE:
				format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_1);
				break;
			case VERSION_THREE:
				format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
				break;
			default:
				format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
			}
			try {
				out = schemaLocation.getOutputStream();
				RESTSchemaQuery schemaQuery = new RESTSchemaQueryImpl(dsd.getBuiltFrom().getURN(), null);
				SingletonStore.getSingleton(ISdmxSchemaManager.class).generateSchema(format, schemaQuery, out);
				
				//GET THE TARGET NAMESPACE OF THE DATA XML FILE
				LOG.debug("schema generated, perform validation");
				XMLParser.validateXML(dataset, dataType.getSchemaVersion(), schemaLocation);
			} finally {
				// Tidy up
				schemaLocation.close();
			}
		}
		LOG.info("Dataset is valid against schema");
	}
}
