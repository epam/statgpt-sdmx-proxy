package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxTransformationSchemeWriterEngineV3 extends StaxAbstractVTLSchemeWriterEngineV3<ITransformationSchemeBean> implements IFusionSingleton {
	private static StaxTransformationSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxTransformationSchemeWriterEngineV3() {}

	public static StaxTransformationSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxTransformationSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "TransformationScheme";
	}
	
	@Override
	protected void writeMaintainableInternal(ITransformationSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtilV3.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
		if(maint.getNamePersonalisationSchemeRef() != null) {
			StaxRefUtilV3.writeReference(maint.getNamePersonalisationSchemeRef(), writer, "NamePersonalisationScheme");
		}
		if(maint.getCustomTypeSchemeRef() != null) {
			StaxRefUtilV3.writeReference(maint.getCustomTypeSchemeRef(), writer, "CustomTypeScheme");
		}
		if(maint.getRulesetSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getRulesetSchemeRef()) {
				StaxRefUtilV3.writeReference(ref, writer, "RulesetScheme");
			}
		}
		if(maint.getUserDefinedOperatorSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getUserDefinedOperatorSchemeRef()) {
				StaxRefUtilV3.writeReference(ref, writer, "UserDefinedOperatorScheme");
			}
		}
	}

	private void writeItems(List<ITransformationBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ITransformationBean item : items) {
			StaxNameableWriterUtilV3.writeBean(item, "Transformation", externalLinks, writer, CollectionUtil.buildMapValues("isPersistent "+item.isPersistent()));
			if(item.getExpression() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Expression", item.getExpression());
			}
			if(item.getResult() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Result", item.getResult());
			}
			writer.writeEndElement();
		}
	}
}
