package io.sdmx.format.ml.engine.structure.reader;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.util.StaxStructureUtil;

public abstract class AbstractStaxMaintainableReaderEngine<T extends MaintainableMutableBean> implements StaxMaintainableReaderEngine<T>, IFusionSingleton {
	
	@Override
	public final void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals(getRootNodeName())) {
					T aBean = processMaintainable(reader);
					builder.build(aBean, beans);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(getContainerNodeName())){
				break;
			}
		}
	}
	
	abstract protected T processMaintainable(IStaxReader reader);
	
	abstract protected String getRootNodeName();
}
