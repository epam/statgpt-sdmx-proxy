package io.sdmx.format.ml.engine.structure.writer.v21.conceptscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRepresentationWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxConceptSchemeWriterEngineV21 extends AbstractV21Writer<ConceptSchemeBean> implements IFusionSingleton {
	private static StaxConceptSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeWriterEngineV21() {}

	public static StaxConceptSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ConceptScheme";
	}

	@Override
	protected void writeMaintainableInternal(ConceptSchemeBean maint, StaxWriter writer) {
		writeConcepets(maint.getItems(), writer);
	}

	private void writeConcepets(List<ConceptBean> concepts, StaxWriter writer) {
		for(ConceptBean concept : concepts) {
			StaxNameableWriterUtil.writeBean(concept, "Concept", writer);
			if(concept.getParentConcept() != null) {
				StaxRefUtil.writeLocalReference(concept.getParentConcept(), writer, "Parent");
			}
			StaxRepresentationWriterUtil.writeRepresentation(concept.getRepresentation(), writer, "CoreRepresentation");
			if(concept.getIsoConceptReference() != null) {
				ICrossReferenceBean<ConceptBean> isoRef = concept.getIsoConceptReference();
				writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "ISOConceptReference");
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptAgency", isoRef.getReference().getAgencyId());
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptSchemeID", isoRef.getReference().getMaintainableId());
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptID",  isoRef.getReference().getIdentifiableId());
				writer.writeEndElement();
			}
			writer.writeEndElement(); //End Concept
		}
	}

}
