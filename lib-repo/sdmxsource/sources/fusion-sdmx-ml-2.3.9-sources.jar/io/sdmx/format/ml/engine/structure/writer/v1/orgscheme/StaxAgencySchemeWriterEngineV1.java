package io.sdmx.format.ml.engine.structure.writer.v1.orgscheme;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v1.AbstractV1Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxAgencySchemeWriterEngineV1 extends AbstractV1Writer<AgencySchemeBean> implements IFusionSingleton {
	private static StaxAgencySchemeWriterEngineV1 INSTANCE;

	//Private constructor - lazy load instance
	private StaxAgencySchemeWriterEngineV1() {}
	public static StaxAgencySchemeWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxAgencySchemeWriterEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return null;
	}

    @Override
    protected void writeMaintainableInternal(AgencySchemeBean agencyScheme, StaxWriter writer) {
        if (agencyScheme.getItems().isEmpty()) {
            return;
        }

        writer.writeStartElement(NS, "Agencies");

        for(AgencyBean anAgency : agencyScheme.getItems()) {
            Map<String, String> attributes = new HashMap<>();
            attributes.put("id", anAgency.getId());

            writer.writeElement(NS, "Agency", attributes);
            StaxTextWriterUtilV2.writeTextTypes(anAgency.getNames(), writer, "Name");
            writer.writeEndElement(); //End Agency
        }

        writer.writeEndElement();  // End "Agencies"
    }
}
