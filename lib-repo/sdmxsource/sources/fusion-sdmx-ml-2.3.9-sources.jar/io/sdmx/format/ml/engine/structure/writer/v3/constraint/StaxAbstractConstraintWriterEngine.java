package io.sdmx.format.ml.engine.structure.writer.v3.constraint;


import java.util.List;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.DataAndMetadataSetReference;
import io.sdmx.api.sdmx.model.beans.registry.ConstrainedDataKeyBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintAttachmentBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ConstraintDataKeySetBean;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class StaxAbstractConstraintWriterEngine<T extends ConstraintBean> extends AbstractV3Writer<T> {

	@Override
	protected void writeMaintainableInternal(T maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeConstraintAttachement(maint.getConstraintAttachment(), writer);
		writeKeySet(maint.getIncludedSeriesKeys(), "DataKeySet", true, writer);
		writeKeySet(maint.getExcludedSeriesKeys(), "DataKeySet", false, writer);
	}

	private void writeConstraintAttachement(ConstraintAttachmentBean constraintAttachment, StaxWriter writer) {
		if(constraintAttachment != null) {
			writer.writeStartElement(NS, "ConstraintAttachment");
			if(constraintAttachment.getDataOrMetadataSetReference() != null) {
				DataAndMetadataSetReference dsRef = constraintAttachment.getDataOrMetadataSetReference();
				String element = dsRef.isDataSetReference() ? "DataSet" : "MetadataSet";
				writer.writeStartElement(NS, element);
				writer.writeStartElement(StaxStructureWriterUtil.COMMON_NS, "DataProvider");
				StaxRefUtilV3.writeReference(dsRef.getDataSetReference(), writer);
				writer.writeEndElement(); // End DataProvider
				writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "ID", dsRef.getSetId());
				writer.writeEndElement(); // End DataSet
			}
			if(constraintAttachment.getDataSources() != null) {
				for(DataSourceBean ds : constraintAttachment.getDataSources()) {
					writer.writeElement(NS, "SimpleDataSource", ds.getDataUrl().toString());
				}
			}
			for(ICrossReferenceBean xsRef : constraintAttachment.getStructureReference()) {
				String nodeName;
				switch(xsRef.getTargetReference()) {
				case DATA_PROVIDER :
					nodeName = "DataProvider";
					break;
				case DSD :
					nodeName = "DataStructure";
					break;
				case MSD :
					nodeName = "MetadataStructure";
					break;
				case METADATA_FLOW:
					nodeName = "Metadataflow";
					break;
				case DATAFLOW :
					nodeName = "Dataflow";
					break;
				case PROVISION_AGREEMENT :
					nodeName = "ProvisionAgreement";
					break;
				case REGISTRATION :
					// ContentConstraints can be applied to Registrations but this is purely for Data Registration purposes. 
					// ContentConstraints when written out as SDMX should NOT output Registration Attachments 
					continue;
				default : throw new SdmxNotImplementedException("Writing a constraint attachment for target : "+xsRef.getTargetReference());
				}
				StaxRefUtilV3.writeReference(xsRef, writer, nodeName);
			}
			writer.writeEndElement(); // End ConstraintAttachment
		}
	}
	
	private void writeKeySet(ConstraintDataKeySetBean keySet, String nodeName, boolean isIncluded, StaxWriter writer) {
		if(keySet != null) {
			writer.writeStartElement(NS, "DataKeySet");
			writer.writeAttribute("isIncluded", Boolean.valueOf(isIncluded).toString());
			for(ConstrainedDataKeyBean key : keySet.getConstrainedDataKeys()) {
				writer.writeStartElement(NS, "Key");
				if(key.hasValidityPeriod()) {
					if(key.getValidityPeriod().hasStartPeriod()) {
						writer.writeAttribute("validFrom", key.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
					}
					if(key.getValidityPeriod().hasEndPeriod()) {
						writer.writeAttribute("validTo", key.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
					}
				}
				writeKeySetKeyValue(key.getKeyValues(), "KeyValue", writer);
				writeKeySetKeyValue(key.getComponentValues(), "Component", writer);
				writer.writeEndElement(); // End Key
			}
			writer.writeEndElement(); // End DataKeySet
		}
	}
	
	private void writeKeySetKeyValue(List<IConstrainedKeyValue> kvs, String elementName, StaxWriter writer) {
		for(IConstrainedKeyValue kv : kvs) {
			writer.writeStartElement(NS, elementName);
			writer.writeAttribute("id", kv.getConcept());
			if(kv.isRemovePrefix()) {
				writer.writeAttribute("removePrefix", kv.isRemovePrefix());
			}
			writer.writeElement(NS, "Value", kv.getCode());
			writer.writeEndElement(); // End KeyValue
		}
	}
	
}
