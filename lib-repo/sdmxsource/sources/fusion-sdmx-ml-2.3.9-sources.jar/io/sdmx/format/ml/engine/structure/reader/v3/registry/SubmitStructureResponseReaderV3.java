package io.sdmx.format.ml.engine.structure.reader.v3.registry;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.submissionresponse.SubmitStructureResponse;
import io.sdmx.im.ErrorListImpl;
import io.sdmx.im.submissionresponse.SubmitStructureResponseImpl;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxReader;

public class SubmitStructureResponseReaderV3 implements IFusionSingleton {
	private static SubmitStructureResponseReaderV3 INSTANCE;

	//Private constructor - lazy load instance
	private SubmitStructureResponseReaderV3() {}

	public static SubmitStructureResponseReaderV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SubmitStructureResponseReaderV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SubmitStructureResponse processSubmissionResult(StaxReader reader) {
		StructureReferenceBean sRef = null;
		ErrorList errorList  = null;
		DATASET_ACTION actionType = null;

		String status = reader.getAttributeValue(null, "StatusMessage");
		boolean hasErrors;
		if (status == null) {
		    hasErrors = false;
		} else {
		    hasErrors = status.equals("Failure") || status.equals("Warning");
		}
		List<String> errorMessages = new ArrayList<>();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("SubmittedStructure")) {
					String action = reader.getAttributeValue(null, "action");
					if(action != null) {
						actionType = DATASET_ACTION.getAction(action);
					}
				} if(nodeName.equals("MaintainableObject")) {
					sRef = StaxStructureUtil.getStructureReference(reader, null);
				} else if(nodeName.equals("Text")) {
					errorMessages.add(reader.getElementText());
				}
			} else if(nodeName.equals("SubmissionResult")) {
				break;
			}
		}
		if(hasErrors) {
			errorList = new ErrorListImpl(errorMessages, status.equals("Warning"));
		}
		return new SubmitStructureResponseImpl(sRef, errorList, actionType);
	}

	public List<SubmitStructureResponse> build(ReadableDataLocation rdl) throws SdmxException {
		List<SubmitStructureResponse> returnList = new ArrayList<>();
		StaxReader reader = new StaxReader(rdl);
		try {
			while(reader.jumpToNode("SubmissionResult")) {
				returnList.add(processSubmissionResult(reader));
			}
		} finally {
			reader.close();
		}
		return returnList;
	}
}
