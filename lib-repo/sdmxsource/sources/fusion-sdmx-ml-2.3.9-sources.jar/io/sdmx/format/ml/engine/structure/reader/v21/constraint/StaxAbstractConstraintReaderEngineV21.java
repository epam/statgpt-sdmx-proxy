package io.sdmx.format.ml.engine.structure.reader.v21.constraint;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public abstract class StaxAbstractConstraintReaderEngineV21<T extends ConstraintMutableBean> extends AbstractStaxMaintainableReaderEngine<T> {

	protected void processDataKeySet(IStaxReader reader, ConstraintMutableBean constraint) {
		ConstraintDataKeySetMutableBean includedKeys = new ConstraintDataKeySetMutableBeanImpl();
		ConstraintDataKeySetMutableBean excludedKeys = new ConstraintDataKeySetMutableBeanImpl();
		processConstraintKey(reader, includedKeys, excludedKeys);
		if(ObjectUtil.validCollection(includedKeys.getConstrainedDataKeys())) {
			constraint.setIncludedSeriesKeys(includedKeys);
		}
		if(ObjectUtil.validCollection(excludedKeys.getConstrainedDataKeys())) {
			constraint.setExcludedSeriesKeys(excludedKeys);
		}
	}
	
	protected void processMetadataKeySet(IStaxReader reader, ConstraintMutableBean constraint) {
		ConstraintDataKeySetMutableBean includedKeys = new ConstraintDataKeySetMutableBeanImpl();
		ConstraintDataKeySetMutableBean excludedKeys = new ConstraintDataKeySetMutableBeanImpl();
		processConstraintKey(reader, includedKeys, excludedKeys);
		if(ObjectUtil.validCollection(includedKeys.getConstrainedDataKeys())) {
			constraint.setIncludedMetadataKeys(includedKeys);
		}
		if(ObjectUtil.validCollection(excludedKeys.getConstrainedDataKeys())) {
			constraint.setExcludedMetadataKeys(excludedKeys);
		}
	}

	private void processConstraintKey(IStaxReader reader,
			ConstraintDataKeySetMutableBean includedKeys,
			ConstraintDataKeySetMutableBean excludedKeys) {

		boolean isIncluded = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "isIncluded", true, true);
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				StaxStructureUtil.checkStartNode(reader, "Key");
				
				Boolean isStillIncluded;
				String asString = StaxStructureUtil.getAttribute(reader.getAttributes(), "include", false);
				if(asString == null) {
					isStillIncluded = null;
				} else {
					isStillIncluded = Boolean.valueOf(asString);
				}
				
				ConstrainedDataKeyMutableBean key = processConstraintKeyValues(reader);
				if(isIncluded) {
					if(isStillIncluded != null && isStillIncluded.booleanValue() == false) {
						excludedKeys.addConstrainedDataKey(key);
					} else {
						includedKeys.addConstrainedDataKey(key);
					}
				} else {
					if(isStillIncluded != null && isStillIncluded.booleanValue() == false) {
						includedKeys.addConstrainedDataKey(key);
					} else {
						excludedKeys.addConstrainedDataKey(key);
					}
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
	}

	private ConstrainedDataKeyMutableBean processConstraintKeyValues(IStaxReader reader) {
		ConstrainedDataKeyMutableBean key = new ConstrainedDataKeyMutableBeanImpl();

		List<IConstrainedKeyValue> keyValues = new ArrayList<>();
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				StaxStructureUtil.checkStartNode(reader, "KeyValue");
				String id = StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true);
				id = StringUtil.cleanString(id);
				reader.moveNextNode();
				StaxStructureUtil.checkStartNode(reader, "Value");
				String value = reader.getElementText();
				value = StringUtil.cleanString(value);
				keyValues.add(ConstrainedKeyValue.getInstance(id, false, value));
				reader.skipToEndNode("KeyValue");
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		key.setKeyValues(keyValues);
		return key;
	}


	protected ConstraintAttachmentMutableBean processConstraintAttachment(IStaxReader reader) {
		ConstraintAttachmentMutableBean constraintAttach = new ContentConstraintAttachmentMutableBeanImpl();
		while(reader.moveNextNode()) {
			String elementName = reader.getElementName();
			if(reader.isStartElement()) {
				if(elementName.equals("DataProvider")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATA_PROVIDER));
				} else if(elementName.equals("MetadataSet")) {
					//TODO What about the 3.0 model - do we just drop support for this in version 2.1?
					//constraintAttach.setDataOrMetadataSetReference(processDataAndMetadataSetReference(reader, false));
				} else if(elementName.equals("SimpleDataSource")) {
					constraintAttach.addDataSources(reader.getElementText());
				} else if(elementName.equals("DataStructure")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DSD));
				} else if(elementName.equals("MetadataStructure")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.MSD));
				}  else if(elementName.equals("Dataflow")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATAFLOW));
				}  else if(elementName.equals("Metadataflow")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.METADATA_FLOW));
				}  else if(elementName.equals("ProvisionAgreement")) {
					constraintAttach.addStructureReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT));
				}  else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(elementName.equals("ConstraintAttachment")) {
				break;
			}
		}
		return constraintAttach;
	}

}
