package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.io.OutputStream;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.format.ml.api.process.IStaxWriteProcess;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.error.ErrorReport;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class SdmxStaxSubmitResponseWriterV3 {

	 
	public static void writeRegistrInterfaceDocument(OutputStream out, 
			String elementName, 
			HeaderRetrievalManager headerRetrievalManager,	
			SchemaLocationManager schemaLocationManager,
			IStaxWriteProcess process) {
		Namespace messageNs = SDMX_NAMESPACE.MESSAGE_3.getNamespace();
		Namespace commonNs = SDMX_NAMESPACE.COMMON_3.getNamespace();
		String schemaLocation = null;
		if(schemaLocationManager != null) {
			schemaLocation = schemaLocationManager.getSchemaLocation(SDMX_SCHEMA.VERSION_THREE);
		}
		StaxWriter writer = new StaxWriter(out, schemaLocation, true, messageNs, commonNs, SDMX_NAMESPACE.REGISTRY_3.getNamespace());

		writer.startDocument(messageNs, "RegistryInterface");
		HeaderBean header = null;
		if(headerRetrievalManager != null) {
			header = headerRetrievalManager.getHeader();
		} 
		if(header == null) {
			header = new HeaderBeanImpl("ZZZ");
		}
		if(header.getReceiver().size() == 0) {
			header.addReceiver(new PartyBeanImpl(null, "UNKNOWN", null, null));
		}
		StaxHeaderWriterUtilV3.writeHeader(writer, messageNs, header, true, false);
		writer.writeStartElement(messageNs, elementName);
		process.write(writer);
		writer.writeEndElement();	
		writer.close();
	}
	
	public static void writeStatusMessage(Throwable th, StaxWriter writer) {
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_3.getNamespace(), "StatusMessage");
		writer.writeAttribute("status", th == null ? "Success" : "Failure");
		if(th != null) {
			writeError(th, writer);
		}
		writer.writeEndElement(); //End StatusMessage
	}
	
	private static void writeError(Throwable th, StaxWriter writer) {
		ErrorReport errorReport = ErrorReport.build(th);
		if(ObjectUtil.validCollection(errorReport.getErrorMessage())) {
			writer.writeStartElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "MessageText");
			for(String currentError : errorReport.getErrorMessage()) {
				writer.writeElement(null, "Text", currentError);
			}
			writer.writeEndElement();
		}
	}
	
}
