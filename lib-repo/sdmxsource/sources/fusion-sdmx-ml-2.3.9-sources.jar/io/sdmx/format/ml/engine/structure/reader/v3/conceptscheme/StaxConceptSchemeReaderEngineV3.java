package io.sdmx.format.ml.engine.structure.reader.v3.conceptscheme;

import io.sdmx.api.sdmx.constants.MAINT_VALIDITY_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxRepresentationUtilV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxConceptSchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<ConceptSchemeMutableBean> {
	private static StaxConceptSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeReaderEngineV3() {}

	public static StaxConceptSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
    @Override
    public String getContainerNodeName() {
        return "ConceptSchemes";
    }

    @Override
    protected String getRootNodeName() {
        return "ConceptScheme";
    }

	@Override
    protected ConceptSchemeMutableBean processMaintainable(IStaxReader reader) {
		ConceptSchemeMutableBean maint = new ConceptSchemeMutableBeanImpl();
		StaxItemSchemeUtil.processBean(maint, reader);
		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("Concept")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			maint.addItem(processConcept(reader));
			reader.moveNextNode();
		}

		boolean hasItemValidation = false;
		for (ConceptMutableBean aConcept : maint.getItems()) {
			if (aConcept.hasValidityPeriod()) {
				hasItemValidation = true;
				break;
			}
		}
		if (hasItemValidation) {
			maint.setValidityType(MAINT_VALIDITY_TYPE.ITEM_VALIDITY);
		}

		return maint;
	}

	private ConceptMutableBean processConcept(IStaxReader reader) {
		ConceptMutableBean concept = new ConceptMutableBeanImpl();
		StaxNameableUtil.processBean(concept, reader);
		ValidityPeriodUtil.processValidityAnnotations(concept);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Parent")) {
				concept.setParentConcept(reader.getElementText());
			} else if(nodeName.equals("CoreRepresentation")) {
				concept.setCoreRepresentation(StaxRepresentationUtilV3.processBean(reader));
			} else if(nodeName.equals("ISOConceptReference")) {
				concept.setIsoConceptReference(processISOConceptReference(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();  //Move to end of parent element
		}
		//Leave on an end element
		return concept;
	}

	private StructureReferenceBean processISOConceptReference(IStaxReader reader) {
		String conceptAgency = null;
		String conceptSchemeId = null;
		String conceptId = null;

		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("ConceptAgency")) {
					conceptAgency = reader.getElementText();
				} else if(nodeName.equals("ConceptSchemeID")) {
					conceptSchemeId = reader.getElementText();
				} else if(nodeName.equals("ConceptID")) {
					conceptId = reader.getElementText();
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("ISOConceptReference")){
				return new StructureReferenceBeanImpl(conceptAgency, conceptSchemeId, "1.0", SDMX_STRUCTURE_TYPE.CONCEPT, conceptId);
			}
		}
		return null;
	}
}
