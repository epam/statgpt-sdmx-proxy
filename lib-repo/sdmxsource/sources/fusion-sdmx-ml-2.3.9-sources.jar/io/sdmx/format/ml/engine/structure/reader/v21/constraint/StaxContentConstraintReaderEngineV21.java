package io.sdmx.format.ml.engine.structure.reader.v21.constraint;

import java.util.Map;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReferencePeriodMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReferencePeriodMutableBeanImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.StringUtil;

public class StaxContentConstraintReaderEngineV21 extends StaxAbstractConstraintReaderEngineV21<ContentConstraintMutableBean>  {
	private static StaxContentConstraintReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxContentConstraintReaderEngineV21() {}
	public static StaxContentConstraintReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxContentConstraintReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Constraints";
    }
    
    @Override
    protected String getRootNodeName() {
        return "ContentConstraint";
    }

    @Override
    protected ContentConstraintMutableBean processMaintainable(IStaxReader reader) {
		ContentConstraintMutableBean constraint = new ContentConstraintMutableBeanImpl();

		String constraintType = reader.getAttributeValue(null, "type");
		if(constraintType != null) {
			constraint.setIsDefiningActualDataPresent(constraintType.equals("Actual"));
		}

		StaxMaintainableUtil.processBean(constraint, reader);

		CubeRegionMutableBean includedCubeRegion = new CubeRegionMutableBeanImpl();
		CubeRegionMutableBean excludedCubeRegion = new CubeRegionMutableBeanImpl();
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("ConstraintAttachment")) {
				constraint.setConstraintAttachment(processConstraintAttachment(reader));
			} else if(elementName.equals("DataKeySet")) {
				processDataKeySet(reader, constraint);
			} else if(elementName.equals("MetadataKeySet")) {
				processMetadataKeySet(reader, constraint);
			} else if(elementName.equals("CubeRegion")) {
				processCubeRegion(reader, includedCubeRegion, excludedCubeRegion);
				constraint.setIncludedCubeRegion(includedCubeRegion);
				constraint.setExcludedCubeRegion(excludedCubeRegion);
			} else if(elementName.equals("MetadataTargetRegion")) {
				throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "ContentConstraintBeanImpl - MetadataTargetRegionList");
			} else if(elementName.equals("ReleaseCalendar")) {
				constraint.setReleaseCalendar(processReleaseCalandar(reader));
			} else if(elementName.equals("ReferencePeriod")) {
				constraint.setReferencePeriod(processReferencePeriod(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return constraint;
	}

	private ReleaseCalendarMutableBean processReleaseCalandar(IStaxReader reader) {
		ReleaseCalendarMutableBean returnBean = new ReleaseCalendarMutableBeanImpl();

		while(reader.moveNextNode()) {
			String elementName = reader.getElementName();
			if(reader.isStartElement()) {
				if(elementName.equals("Periodicity")) {
					returnBean.setPeriodicity(reader.getElementText());
				} else if(elementName.equals("Offset")) {
					returnBean.setOffset(reader.getElementText());
				} else if(elementName.equals("Tolerance")) {
					returnBean.setTolerance(reader.getElementText());
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(elementName.equals("ReleaseCalendar")) {
				break;
			}
		}
		return returnBean;
	}

	private ReferencePeriodMutableBean processReferencePeriod(IStaxReader reader) {
		ReferencePeriodMutableBean returnBean = new ReferencePeriodMutableBeanImpl();
		Map<String, String> attributes = reader.getAttributes();
		returnBean.setStartTime(StaxStructureUtil.getAttributeAsDate(attributes, "startTime", true));
		returnBean.setEndTime(StaxStructureUtil.getAttributeAsDate(attributes, "endTime", true));
		reader.moveNextNode();
//		while(reader.moveNextNode()) {
//			String elementName = reader.getElementName();
//			if(reader.isStartElement()) {
//				if(elementName.equals("startTime")) {
//					returnBean.setStartTime(DateUtil.formatDate(reader.getElementText(), true));
//				} else if(elementName.equals("endTime")) {
//					returnBean.setEndTime(DateUtil.formatDate(reader.getElementText(), true));
//				} else {
//					StaxStructureUtil.throwUnexpectedNodeException(reader);
//				}
//			} else if(elementName.equals("ReferencePeriod")) {
//				break;
//			}
//		}
		return returnBean;
	}

	private void processCubeRegion(IStaxReader reader,
			CubeRegionMutableBean includedCubeRegion,
			CubeRegionMutableBean excludedCubeRegion) {

		boolean isIncluded = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "include", false, true);

		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				TERTIARY_BOOL isStillIncluded = StaxStructureUtil.getAttributeAsTeritaryBoolean(reader.getAttributes(), "include", false);
				if(nodeName.equals("KeyValue")) {
					KeyValuesMutable keyValues = processCubeRegionKeyValues(reader);
					if(isIncluded) {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							excludedCubeRegion.addKeyValues(keyValues);
						} else {
							includedCubeRegion.addKeyValues(keyValues);
						}
					} else {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							includedCubeRegion.addKeyValues(keyValues);
						} else {
							excludedCubeRegion.addKeyValues(keyValues);
						}
					}
				} else if(nodeName.equals("Attribute")) {
					KeyValuesMutable attrValues = processCubeRegionKeyValues(reader);
					if(isIncluded) {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							excludedCubeRegion.addAttributeValue(attrValues);
						} else {
							includedCubeRegion.addAttributeValue(attrValues);
						}
					} else {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							includedCubeRegion.addAttributeValue(attrValues);
						} else {
							excludedCubeRegion.addAttributeValue(attrValues);
						}
					}
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
	}

	private KeyValuesMutable processCubeRegionKeyValues(IStaxReader reader) {
		KeyValuesMutable returnBean = new KeyValuesMutableImpl();
		returnBean.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Value")) {
					Map<String, String> attributes = reader.getAttributes();
					String elText = reader.getElementText();
					elText = StringUtil.cleanString(elText);
					if(StaxStructureUtil.getAttributeAsTeritaryBoolean(attributes, "cascadeValues", false).isTrue()) {
						returnBean.addCascade(elText);
					}
					returnBean.addValue(elText);
				} else if(nodeName.equals("TimeRange")) {
					returnBean.setTimeRange(processTimeRange(reader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		return returnBean;
	}
	private TimeRangeMutableBean processTimeRange(IStaxReader reader) {
		TimeRangeMutableBean returnBean = new TimeRangeMutableBeanImpl();

		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("BeforePeriod")) {
					returnBean.setStartDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(false);
				} else if(nodeName.equals("AfterPeriod")) {
					returnBean.setEndDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(false);
				}  else if(nodeName.equals("StartPeriod")) {
					returnBean.setStartDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(true);
				}  else if(nodeName.equals("EndPeriod")) {
					returnBean.setEndDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(true);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		return returnBean;
	}
}
