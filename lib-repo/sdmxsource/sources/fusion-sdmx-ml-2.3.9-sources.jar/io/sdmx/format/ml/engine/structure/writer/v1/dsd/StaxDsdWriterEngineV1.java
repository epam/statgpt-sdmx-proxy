package io.sdmx.format.ml.engine.structure.writer.v1.dsd;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v1.AbstractV1Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDsdWriterEngineV1 extends AbstractV1Writer<DataStructureBean> implements IFusionSingleton {
	private static StaxDsdWriterEngineV1 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDsdWriterEngineV1() {}

	public static StaxDsdWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDsdWriterEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "KeyFamily";
	}

	@Override
	protected void writeMaintainableInternal(DataStructureBean maint, StaxWriter writer) {
	    Map<String, String> attributes = new HashMap<>();
        attributes.put("id", maint.getId());
        attributes.put("version", maint.getVersion().toString());
        attributes.put("agency", maint.getAgencyId());

        if (maint.getUri() != null) {
            attributes.put("uri", maint.getUri().toString());
        }
        if (maint.isExternalReference()) {
            attributes.put("isExternalReference", Boolean.toString(maint.isExternalReference()));
        }
	    writer.writeElement(NS, "KeyFamily", attributes);
	    StaxTextWriterUtilV2.writeTextTypes(maint.getNames(), writer, "Name");

		writer.writeStartElement(NS, "Components");
		writeDimensionList(maint.getDimensions(), writer, true);
		writeDimensionList(maint.getDimensions(SDMX_STRUCTURE_TYPE.TIME_DIMENSION), writer, false);
		writeGroups(maint.getGroups(), writer);
		writePrimaryMeasure(maint.getPrimaryMeasure(), writer);
		// FUNC - cross sectional Measure
		// Write CrossSectionalMeasure
		writeAttributeList(maint, maint.getAttributeList(), writer);
		writer.writeEndElement(); //End Components

		StaxAnnotableWriterUtilV2.writeAnnotations(maint.getAnnotations(), writer);

		writer.writeEndElement(); //End KeyFamily
	}

    private void writeDimensionList(List<DimensionBean> list, StaxWriter writer, boolean excludeTime) {
        if(list == null) {
            return;
        }

        for(DimensionBean dim : list) {
            if (excludeTime && dim.isTimeDimension()) {
                continue;
            }
            Map<String, String> attrs = new HashMap<>();
            ICrossReferenceBean<ConceptBean> conceptRef = dim.getConceptRef();
            if (conceptRef != null) {
                attrs.put("concept", conceptRef.getReference().getIdentifiableId());
            }

            RepresentationBean representation = dim.getRepresentation();
            if (representation != null) {
                ICrossReferenceBean representation2 = representation.getRepresentation();
                if (representation2 != null) {
                    attrs.put("codelist", representation2.getReference().getMaintainableId());
                }
            }

            if (dim.isMeasureDimension()) {
                attrs.put("isMeasureDimension", "true");
            }
            if (dim.isFrequencyDimension()) {
                attrs.put("isFrequencyDimension", "true");
            }

            String outputDimensionNode;
            if (dim.isTimeDimension()) {
                outputDimensionNode = "TimeDimension";
            } else {
                outputDimensionNode = "Dimension";
            }

            // FUNC: Have not implemented:
            // * crossSectionalAttachDataSet
            // * crossSectionalAttachDataGroup
            // * crossSectionalAttachSection
            // * crossSectionalAttachObservation

            writer.writeElement(NS, outputDimensionNode, attrs);

            // FUNC: Have not implemented TextFormat
            /*
            if (dim.isTimeDimension()) {
                if (dim.getRepresentation() != null && dim.getRepresentation().getTextFormat() != null) {
                  StaxTextFormatWriterUtil.writeTextFormat(dim.getRepresentation().getTextFormat(), writer, "TextFormat");
              }
            }
            */
            StaxAnnotableWriterUtilV2.writeAnnotations(dim.getAnnotations(), writer);

            writer.writeEndElement(); //End Dimension
        }
    }

    private void writePrimaryMeasure(PrimaryMeasureBean primaryMeasure, StaxWriter writer) {
        if (primaryMeasure == null) {
            return;
        }

        Map<String, String> attrs = new HashMap<>();
        ICrossReferenceBean<ConceptBean> conceptRef = primaryMeasure.getConceptRef();
        if (conceptRef != null) {
            attrs.put("concept", conceptRef.getReference().getIdentifiableId());
        }

        writer.writeElement(NS, "PrimaryMeasure", attrs);

        StaxAnnotableWriterUtilV2.writeAnnotations(primaryMeasure.getAnnotations(), writer);

        writer.writeEndElement(); //End Dimension
    }

	private void writeGroups(List<GroupBean> groups, StaxWriter writer) {
		if(ObjectUtil.validCollection(groups)) {
			for(GroupBean groupBean : groups) {
			    Map<String, String> attrs = new HashMap<>();
			    attrs.put("id", groupBean.getId());
                writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Group", attrs);

				for(String dimRef : groupBean.getDimensionRefs()) {
					writer.writeStartElement(NS, "DimensionRef");
					writer.writeElementText(dimRef);
					writer.writeEndElement();
				}
				StaxAnnotableWriterUtilV2.writeAnnotations(groupBean.getAnnotations(), writer);
				writer.writeEndElement(); //End Group
			}
		}
	}

	private void writeAttributeList(DataStructureBean buildFrom, AttributeListBean attrList, StaxWriter writer) {
        if(attrList == null || attrList.getAttributes() == null || attrList.getAttributes().size() == 0) {
            return;
        }

        for(AttributeBean attr : attrList.getAttributes()) {
            Map<String, String> attrs = new HashMap<>();

            ICrossReferenceBean<ConceptBean> conceptRef = attr.getConceptRef();
            if (conceptRef != null) {
                attrs.put("concept", conceptRef.getReference().getIdentifiableId());
            }

            if (attr.getRepresentation() != null) {
                ICrossReferenceBean<? extends EnumeratedListBean> rep = attr.getRepresentation().getRepresentation();
                if (rep != null) {
                    attrs.put("codelist", rep.getReference().getMaintainableId());
                }
            }

            String attachmentLevelStr;
            String attachmentGrp = null;
            ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel = attr.getAttachmentLevel();
            switch(attachmentLevel) {
            case DATA_SET:
                attachmentLevelStr = "DataSet";
                break;
            case OBSERVATION:
                attachmentLevelStr = "Observation";
                break;
            case GROUP:
                attachmentLevelStr = "Group";
                attachmentGrp = attr.getAttachmentGroup();
                break;
            case DIMENSION_GROUP:
                attachmentLevelStr = "Series";

                // This series level attachment could be "group"
                List<String> dimensionReferences = attr.getDimensionReferences();
                for(GroupBean grp : buildFrom.getGroups()) {
                    if(grp.getDimensionRefs().containsAll(dimensionReferences) && dimensionReferences.containsAll(grp.getDimensionRefs())) {
                        attachmentLevelStr = "Group";
                        attachmentGrp = grp.getId();
                        break;
                    }
                }

                break;
            default:
                throw new SdmxSemmanticException("Unknown attachment level: " + attachmentLevel);
            }

            attrs.put("attachmentLevel", attachmentLevelStr);
			String statusStr = attr.isMandatory()? "Mandatory" : "Conditional";
            attrs.put("assignmentStatus", statusStr);

            if (attr.isTimeFormat()) {
                attrs.put("isTimeFormat", "true");
            }

            writer.writeElement(NS, "Attribute", attrs);

            // Text Type
            if (attr.getRepresentation() != null && attr.getRepresentation().getTextFormat() != null) {
                TextFormatBean textFormatBean = attr.getRepresentation().getTextFormat();
                if(textFormatBean != null) {
                    Map<String, String> attributes = new HashMap<>();
                    if (textFormatBean.getMaxLength() != null) {
                        attributes.put("length", textFormatBean.getMaxLength().toString());
                    }
                    if (textFormatBean.getDecimals() != null) {
                        attributes.put("decimals", textFormatBean.getDecimals().toString());
                    }
                    if (textFormatBean.getTextType() != null) {
                        attributes.put("TextType", textFormatBean.getTextType().getSdmx1Value());
                    }

                    writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "TextFormat");
                    writer.writeAttributes(attributes);
                    writer.writeEndElement();
                }
            }

            if (attachmentLevelStr.equals("Group")) {
                writer.writeElement(NS, "AttachmentGroup", attachmentGrp);
            }

            // FUNC: AttachmentMeasure

            StaxAnnotableWriterUtilV2.writeAnnotations(attr.getAnnotations(), writer);

            writer.writeEndElement(); // End Attribute
        }
    }
}
