package io.sdmx.format.ml.engine.structure.writer.v3.hcl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxIdentifiableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxTextFormatWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxHclWriterEngineV3 extends AbstractV3Writer<HierarchyBean> implements IFusionSingleton {
	private static StaxHclWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHclWriterEngineV3() {}

	public static StaxHclWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHclWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "Hierarchy";
	}

	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(HierarchyBean maint) {
		Map<String, String> returnMap = new HashMap<>();
		returnMap.put("hasFormalLevels", Boolean.toString(maint.hasFormalLevels()));
		return returnMap;
	}

	@Override
	protected void writeMaintainableInternal(HierarchyBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeLevel(maint.getLevel(), externalLinks,  writer);
		writeHierarchicalCode(maint.getHierarchicalCodeBeans(), externalLinks, writer);
	}

	private void writeHierarchicalCode(List<HierarchicalCodeBean> hCode, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(HierarchicalCodeBean currentHCode : hCode) {
			Map<String, String> attrs = new HashMap<>();
			if(currentHCode.getValidFrom() != null) {
				attrs.put("validFrom", currentHCode.getValidFrom().getDateInSdmxFormat());
			}
			if(currentHCode.getValidTo() != null) {
				attrs.put("validTo", currentHCode.getValidTo().getDateInSdmxFormat());
			}
			StaxIdentifiableWriterUtilV3.writeBean(currentHCode, "HierarchicalCode", externalLinks, writer, attrs);
			StaxRefUtilV3.writeReference(currentHCode.getCodeReference().getReference(), writer, "Code");
			writeHierarchicalCode(currentHCode.getCodeRefs(), externalLinks, writer);
			if(currentHCode.getLevel(false) != null) {
				StaxRefUtilV3.writeLocalReference(currentHCode.getLevel(false).getFullIdPath(false), writer, "Level");
			}
			writer.writeEndElement(); //End  HierarchicalCode
		}
	}

	private void writeLevel(LevelBean level, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		if(level != null) {
			StaxNameableWriterUtilV3.writeBean(level, "Level", externalLinks, writer);
			StaxTextFormatWriterUtilV3.writeTextFormat(level.getCodingFormat(), writer, "CodingFormat");
			writeLevel(level.getChildLevel(), externalLinks, writer);
			writer.writeEndElement(); //End  Level
		}
	}
}
