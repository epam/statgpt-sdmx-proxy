package io.sdmx.format.ml.engine.data.writer;

import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.DataStructureUtil;

public class GenericDataWriterEngine extends SdmxDataWriterEngine {

	private static Logger LOG = LoggerFactory.getLogger(GenericDataWriterEngine.class);
	
	private Map<String, String> componentVals = new LinkedHashMap<>();
	private String conceptAttribute;
	private List<String> seriesKey;
	
	public GenericDataWriterEngine(SDMX_SCHEMA schemaVersion, OutputStream out, boolean prettyPrint) {
		super(schemaVersion, BASE_DATA_FORMAT.GENERIC, out, prettyPrint);
		setConceptAttribute();
	}

	/**
	 * In version 1.0 and 2.0 the concept attribute is named 'concept', whereas in 2.1 it is named 'id'
	 */
	private void setConceptAttribute() {
		if(isTwoPointOne()) {
			conceptAttribute = "id";
		} else {
			conceptAttribute = "concept";
		}
	}

	@Override
	public void startDataset(ProvisionAgreementBean provision, DataflowBean dataflow, DataStructureBean dsd, DatasetHeaderBean header, AnnotationBean... annotations) {
		// FMR-762: if ONLY Dataset Attributes were written in the previous Dataset, then this element needs to be ended
		if (currentPosition == POSITION.DATASET_ATTRIBUTE) {
			try {
				writer.writeEndElement();
			} catch (XMLStreamException e) {
				LOG.error("When starting a new dataset, where the current position is Dataset Attribute, unable to write to the Data Writer. Error is: " + e.getMessage());
				e.printStackTrace();
			}
		}
		
		super.startDataset(provision, dataflow, dsd, header, annotations);
		seriesKey = DataStructureUtil.getSeriesKeyConcepts(dsd);
		if(isFlat) {
			if(dsd.getTimeDimension() != null) {
				seriesKey.add(dsd.getTimeDimension().getId());
			}
		}
		if(!isTwoPointOne()) {
			if(this.isCrossSectional) {
				throw new SdmxSemmanticException("A 2.0 Generic Dataset must contain Time at the observation level.");
			}
			try {
				startElement(writer, GENERIC_NS, "KeyFamilyRef");
				writer.writeCharacters(dsd.getId());
				writer.writeEndElement();
				datasetAnnotations = annotations;
			} catch(XMLStreamException e) {
				throw new RuntimeException(e);
			}
		} else {
			writeAnnotations(writer, annotations);
		}
	}

	@Override
	public void startSeries(AnnotationBean... annotations) {
		super.startSeries();
		if(isFlat) {
			componentVals = new LinkedHashMap<>();

			try {
				if(currentPosition != null) {
					switch(currentPosition) {
					case OBSERVATION :
						writeEndObs();
						break;
					case OBSERVATION_ATTRIBUTE :
						seriesWriter.writeEndElement(); //END ATTRIBUTES
						writeEndObs();
						break;
					case SERIES_KEY_ATTRIBUTE :
					case SERIES_KEY :
						//DO NOTHING
						break;
					case GROUP :
						writeEndGroup();
						break;
					case GROUP_KEY_ATTRIBUTE :
						writer.writeEndElement(); //END ATTRIBUTES
						writeEndGroup();
						break;
					}
				}
			} catch(XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}

			currentPosition = POSITION.SERIES_KEY;
		} else {
			try {
				if(currentPosition != null) {
					//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
					switch(currentPosition) {
					case DATASET_ATTRIBUTE :
						writer.writeEndElement();
						break;
					case OBSERVATION :
						writeEndObs();
						writeEndSeries();
						break;
					case OBSERVATION_ATTRIBUTE :
						seriesWriter.writeEndElement(); //END ATTRIBUTES
						writeEndObs();
						writeEndSeries();
						break;
					case SERIES_KEY_ATTRIBUTE :
						seriesWriter.writeEndElement(); //END ATTRIBUTES
						writeEndSeries();
						break;
					case SERIES_KEY :
						seriesWriter.writeEndElement(); //END SERIES KEY
						writeEndSeries();
						break;
					case GROUP :
						writeEndGroup();
						break;
					case GROUP_KEY :
						writer.writeEndElement(); //END GROUP KEY
						writeEndGroup();
						break;
					case GROUP_KEY_ATTRIBUTE :
						writer.writeEndElement(); //END ATTRIBUTES
						writeEndGroup();
						break;
					}
				}
				startElement(seriesWriter, GENERIC_NS, "Series");  //WRITE THE START SERIES
				if(isTwoPointOne()) {
					writeAnnotations(seriesWriter, annotations);
				} else {
					seriesAnnotations = annotations;
				}
				startElement(seriesWriter, GENERIC_NS, "SeriesKey");  //WRITE THE START SERIES KEY
				currentPosition = POSITION.SERIES_KEY;
			} catch(XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}



	@Override
	public void close(FooterMessage... footer) {
		try {
			if(currentPosition != null) {
				switch(currentPosition) {
				case DATASET_ATTRIBUTE :
					writer.writeEndElement();
					break;
				case OBSERVATION :
					writeEndObs();
					writeEndSeries();
					break;
				case OBSERVATION_ATTRIBUTE :
					seriesWriter.writeEndElement(); //END ATTRIBUTES
					writeEndObs();
					writeEndSeries();
					break;
				case SERIES_KEY_ATTRIBUTE :
					seriesWriter.writeEndElement(); //END ATTRIBUTES
					writeEndSeries();
					break;
				case SERIES_KEY :
					seriesWriter.writeEndElement(); //END SERIES KEY
					writeEndSeries();
					break;
				case GROUP :
					writeEndGroup();
					break;
				case GROUP_KEY :
					writer.writeEndElement(); //END GROUP KEY
					writeEndGroup();
					break;
				case GROUP_KEY_ATTRIBUTE :
					writer.writeEndElement(); //END ATTRIBUTES
					writeEndGroup();
					break;
				case DATASET :
					//DO NOTHING
					break;
				}
			}
		} catch(XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		super.close(footer);
	}

	@Override
	public void writeAttributeValue(String conceptId, String... conceptValues) {
		super.writeAttributeValue(conceptId, conceptValues);
		conceptId = getComponentId(conceptId);
		if(conceptValues.length == 1) {
			String conceptValue = conceptValues[0];
			if (conceptValue == null) {
				conceptValue = "";
			}
			XMLStreamWriter attributeWriter = seriesWriter;
			try {
				switch (currentPosition) {
					case DATASET:
						currentPosition = POSITION.DATASET_ATTRIBUTE;
						startElement(writer, GENERIC_NS, "Attributes");
						attributeWriter = writer;  //Set the attribute write to be the group writer
						break;
					case DATASET_ATTRIBUTE:
						attributeWriter = writer;  //Set the attribute write to be the group writer
						break;
					case OBSERVATION:
						currentPosition = POSITION.OBSERVATION_ATTRIBUTE;
						startElement(seriesWriter, GENERIC_NS, "Attributes");
						break;
					case SERIES_KEY:
						if (isFlat) {
							componentVals.put(conceptId, conceptValue);
							return;
						}
						currentPosition = POSITION.SERIES_KEY_ATTRIBUTE;
						seriesWriter.writeEndElement(); //END SERIES KEY
						startElement(seriesWriter, GENERIC_NS, "Attributes");
						break;
					case GROUP:
						currentPosition = POSITION.GROUP_KEY_ATTRIBUTE;
						startElement(writer, GENERIC_NS, "Attributes");
						attributeWriter = writer;  //Set the attribute write to be the group writer
						break;
					case GROUP_KEY:
						writer.writeEndElement(); //END Group Key
						currentPosition = POSITION.GROUP_KEY_ATTRIBUTE;
						startElement(writer, GENERIC_NS, "Attributes");
						attributeWriter = writer;  //Set the attribute write to be the group writer
						break;
					case GROUP_KEY_ATTRIBUTE:
						attributeWriter = writer;  //Set the attribute write to be the group writer
				}

				startElement(attributeWriter, GENERIC_NS, "Value");  //WRITE THE VALUE NODE
				attributeWriter.writeAttribute(conceptAttribute, conceptId);
				attributeWriter.writeAttribute("value", conceptValue);
				attributeWriter.writeEndElement(); //END VALUE
			} catch (XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}

	@Override
	public void writeGroupKeyValue(String conceptId, String conceptValue) {
		try {
			conceptId = getComponentId(conceptId);
			if(currentPosition != POSITION.GROUP && currentPosition != POSITION.GROUP_KEY) {
				throw new IllegalArgumentException("startGroup must be called before valling writeGroupKeyValue");
			}
			currentPosition = POSITION.GROUP_KEY;
			startElement(writer, GENERIC_NS, "Value");  //WRITE THE VALUE NODE
			writer.writeAttribute(conceptAttribute, conceptId);
			writer.writeAttribute("value", conceptValue);
			writer.writeEndElement(); //END VALUE
		} catch(XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void writeSeriesKeyValue(String dimensionId, String dimensionValue) {
		dimensionId = getComponentId(dimensionId);
		if(isFlat) {
			componentVals.put(dimensionId, dimensionValue);
		} else {
			try {
				if(currentPosition != POSITION.SERIES_KEY) {
					startSeries();
				}
				startElement(seriesWriter, GENERIC_NS, "Value");  //WRITE THE START SERIES
				seriesWriter.writeAttribute(conceptAttribute, dimensionId);
				seriesWriter.writeAttribute("value", dimensionValue);
				seriesWriter.writeEndElement(); //END VALUE

			} catch(XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}

	@Override
	protected void closeGroupWriter() throws Exception {
		if(currentPosition != null) {
			switch(currentPosition) {
			case GROUP :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			case GROUP_KEY :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP_KEY
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			case GROUP_KEY_ATTRIBUTE :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP_KEY_ATTRIBUTE
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			}
		}
		writer.flush();
	}
	
	@Override
	public void writeObservation(String obsConceptId, String obsConceptValue,  List<KeyValue> measures, AnnotationBean... annotations) {
		String obsValue = checkWriteObs(measures);
		if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(obsConceptId)) {
			if (schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
				obsConceptValue = DateUtil.formatDateForSdmxVersion21(obsConceptValue);
			} else if (schemaVersion == SDMX_SCHEMA.VERSION_TWO) {
				obsConceptValue = DateUtil.formatDateForSdmxVersion2(obsConceptValue);
			} else if (schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
		    	obsConceptValue = DateUtil.formatDateForSdmxVersion1(obsConceptValue);
		    }
		}
		obsConceptId = getComponentId(obsConceptId);

		try {
			switch(currentPosition) {
			case OBSERVATION :
				writeEndObs();
				break;
			case OBSERVATION_ATTRIBUTE :
				seriesWriter.writeEndElement(); //END ATTRIBUTES
				writeEndObs();
				break;
			case SERIES_KEY_ATTRIBUTE :
				seriesWriter.writeEndElement(); //END ATTRIBUTES
				break;
			case SERIES_KEY :
				if (!isFlat) {
					seriesWriter.writeEndElement(); //END SERIES KEY
				}
				break;
			case GROUP :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			case GROUP_KEY :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP_KEY
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			case GROUP_KEY_ATTRIBUTE :
				if(isTwoPointOne()) {
					writer.writeEndElement(); //END GROUP_KEY_ATTRIBUTE
					writer.writeEndElement(); //END GROUP
				} else {
					throw new SdmxSemmanticException("Attempting to write observation to group , an observation must belong to a series");
				}
				break;
			default :
				if(!isTwoPointOne()) {
					throw new IllegalArgumentException("An observation may only be written while inside a series");
				}
			}
			currentPosition = POSITION.OBSERVATION;
			startElement(seriesWriter, GENERIC_NS, "Obs");  //WRITE THE OBS NODE

			if(isFlat) {
				if (obsConceptId != null) {
					componentVals.put(obsConceptId, obsConceptValue);
				}
				writeAnnotations(seriesWriter, annotations);
				startElement(seriesWriter, GENERIC_NS, "ObsKey");
				for(String componentId : seriesKey) {
					startElement(seriesWriter, GENERIC_NS, "Value");
					seriesWriter.writeAttribute("id", componentId);
					seriesWriter.writeAttribute("value", componentVals.get(componentId));
					seriesWriter.writeEndElement(); //END Value
				}
				seriesWriter.writeEndElement(); //END ObsKey

			} else if(isTwoPointOne()) {
				writeAnnotations(seriesWriter, annotations);

				startElement(seriesWriter, GENERIC_NS, "ObsDimension");
				if(isCrossSectional) {
					seriesWriter.writeAttribute("id", obsConceptId);
				}
				seriesWriter.writeAttribute("value", obsConceptValue);
				seriesWriter.writeEndElement(); //END ObsDimension
			} else {
				obsAnnotations = annotations;
				startElement(seriesWriter, GENERIC_NS, "Time");
				seriesWriter.writeCharacters(obsConceptValue);
				seriesWriter.writeEndElement(); //END Time
			}
			startElement(seriesWriter, GENERIC_NS, "ObsValue");
			if(ObjectUtil.validString(obsValue)) {
				seriesWriter.writeAttribute("value", obsValue);
			}
			seriesWriter.writeEndElement(); //END ObsValue
			if(isFlat) {
				// Write the Series Attributes as Observation Level Attributes
				// NOTE - we do not want to write the Series Keys here, so they need to be removed
				Map<String, String> componentValsClone = new LinkedHashMap<>(componentVals);
				componentValsClone.keySet().removeAll(seriesKey);
				for(String key : componentValsClone.keySet()) {
					writeAttributeValue(key, componentValsClone.get(key));
				}
			}
		}  catch(XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void startGroup(String groupId, AnnotationBean... annotations) {
		super.startGroup(groupId, annotations);
		try {
			if(currentPosition != null) {
				//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
				switch(currentPosition) {
				case DATASET_ATTRIBUTE :
					writer.writeEndElement(); //END ATTRIBUTES
					break;
				case OBSERVATION :
					writeEndObs();
					writeEndSeries();
					break;
				case OBSERVATION_ATTRIBUTE :
					seriesWriter.writeEndElement(); //END ATTRIBUTES
					writeEndObs();
					writeEndSeries();
					break;
				case SERIES_KEY_ATTRIBUTE :
					seriesWriter.writeEndElement(); //END ATTRIBUTES

					writeEndSeries();
					break;
				case SERIES_KEY :
					seriesWriter.writeEndElement(); //END SERIES KEY
					writeEndSeries();
					break;
				case GROUP :
					writeEndGroup();
					break;
				case GROUP_KEY : {
					writer.writeEndElement(); //END GROUP KEY
					writeEndGroup();
					break;
				}
				case GROUP_KEY_ATTRIBUTE :
					writer.writeEndElement(); //END ATTRIBUTES
					writeEndGroup();
					break;
				}
			}
			startElement(writer, GENERIC_NS, "Group");      //WRITE THE START GROUP
			writer.writeAttribute("type", groupId);
			if(isTwoPointOne()) {
				writeAnnotations(writer, annotations);
			} else {
				groupAnnotations = annotations;
			}
			startElement(writer, GENERIC_NS, "GroupKey");   //WRITE THE START GROUP KEY
			currentPosition = POSITION.GROUP;
		} catch(XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void writeMultilingualAttributeValue(IMultilingualKeyValue complexAttribute){
		throw new SdmxNotImplementedException();
	}

}
