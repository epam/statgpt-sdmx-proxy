package io.sdmx.format.ml.factory.metadata;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataFormatFactory;
import io.sdmx.format.ml.constant.SDMXML_VERSION;
import io.sdmx.format.ml.model.SdmxMLMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxMLMetadataFormatFactory implements IMetadataFormatFactory, IFusionSingleton {
	private static SdmxMLMetadataFormatFactory INSTANCE;

	private Map<String, FormatDetails> supportedFormats = new HashMap<>(1);
	
	//Private constructor - lazy load instance
	public static SdmxMLMetadataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLMetadataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxMLMetadataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	
	private SdmxMLMetadataFormatFactory() {
//		addSupportedFormat(SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V21));
		addSupportedFormat(SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V3));
		this.supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}
	
	private void addSupportedFormat(IMetadataFormat format) {
		supportedFormats.put(format.getFormatDetails().getAcceptHeaders()[0], format.getFormatDetails());
	}

	@Override
	public Class<IMetadataFormat> getFormatClass() {
		return IMetadataFormat.class;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public IMetadataFormat getFormat(String format, Request request) {
		if(format.equals("sdmx-3.0")) {
			return SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V3);
		}
//		if(format.equals("sdmx-2.1")) {
//			return SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V21);
//		}
		return null;
	}

	@Override
	public IMetadataFormat getFormat(Request request, IVNDHeader vndHeader) {
		String vnd = vndHeader.getVnd();
		boolean sdmxJson = vnd.startsWith("sdmx.metadata+xml");
		if(!sdmxJson) {
			return null;
		}
		// If a version is specified is must be 1.0.0
		String version = vndHeader.getParameterValue("version");
		if (version == null) {
			version = "3.0.0";
		}
		if(version.equals("3.0.0")) {
			return SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V3);
		} else {
			throw new SdmxNotAcceptableException("Unsupported sdmx-ml version: " +version + ". Supported versions are 3.0.0");
		}
	}
}
