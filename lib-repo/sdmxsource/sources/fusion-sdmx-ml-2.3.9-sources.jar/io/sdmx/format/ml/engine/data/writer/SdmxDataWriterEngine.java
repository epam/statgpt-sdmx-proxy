package io.sdmx.format.ml.engine.data.writer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.text.StringEscapeUtils;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DIMENSION_AT_OBSERVATION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.io.OverflowWriteableDataLocation;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.core.xml.IndentingXMLStreamWriter;
import io.sdmx.utils.sdmx.structure.ConceptRefUtil;

public abstract class SdmxDataWriterEngine implements DataWriterEngine {

	private SchemaLocationManager schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
	private HeaderRetrievalManager headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);

	protected boolean prettyPrint;

	protected AnnotationBean[] datasetAnnotations;  //For version 1.0 or 2.0 writer, store the annotation until the end of the message
	protected AnnotationBean[] seriesAnnotations;  //For version 1.0 or 2.0 writer, store the annotation until the end of the message
	protected AnnotationBean[] groupAnnotations;  //For version 1.0 or 2.0 writer, store the annotation until the end of the message
	protected AnnotationBean[] obsAnnotations;  //For version 1.0 or 2.0 writer, store the annotation until the end of the message

	protected boolean isClosed = false;
	private boolean hasGroups = false;
	private boolean hasDatasetAttributes = false;
	protected String PREFIX_GENERIC = "generic";
	protected String PREFIX_MESSAGE = "message";
	protected String PREFIX_COMMON = "common";
	protected String PREFIX_CROSS = "cross";
	protected String PREFIX_COMPACT = "ns";


	//NAMESPACES
	protected static final String XML_NS = "http://www.w3.org/XML/1998/namespace";
	protected static final String XSI_NS = "http://www.w3.org/2001/XMLSchema-instance";

	protected Namespace GENERIC_NS;
	private Namespace MESSAGE_NS;
	private Namespace COMMON_NS;
	protected Namespace CROSS_NS;
	protected Namespace COMPACT_NS;
	private Namespace FOOTER_NS = new Namespace("http://www.sdmx.org/resources/sdmxml/schemas/v2_1/message/footer", "footer");
	protected boolean headerWritten = false;
	protected SDMX_SCHEMA schemaVersion;

	protected String crossSectionConcept;
	protected boolean isCrossSectional;
	protected boolean isFlat;

	private BASE_DATA_FORMAT dataFormat;

	//WRITER
	protected XMLStreamWriter writer = null;
	protected XMLStreamWriter seriesWriter = null;


	//private WriteableDataLocation tmpDataLocation;

	//The current series output stream that is being written to
	private OutputStream seriesOut;

	//The current output stream that is being written to
	private OutputStream out;

	//Contains the user's output stream - this is where the data should eventually be written to
	private OutputStream finalOutputStream;

	//VARIABLES & STATE
	protected List<String> conceptIds;
	protected List<String> currentGroupConceptIds;

	//Contains a mapping from component id - to concept id
	private Map<String, String> componentIdMapping = new HashMap<>();


	POSITION currentPosition; //WHERE ARE WE IN THE OUTPUT SDMX
	POSITION positionBeforeComp; // <Comp/> nodes can be opened inside Series or inside Obs nodes, so we need to know where we are when we close the Comp node


	private List<DataSetOutputStreams> outputDatasetLocations = new ArrayList<>();
	private DataSetOutputStreams currentDatasetOutputLocations;

	private HeaderBean header;

	/**
	 * If true, then the dimension at the observation is the measure dimension
	 */
	boolean isCrossSectionalMeasure = false;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////CONSTRUCTOR							 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	public SdmxDataWriterEngine(SDMX_SCHEMA schemaVersion, BASE_DATA_FORMAT dataFormat, OutputStream out, boolean prettyPrint)  {
		this.finalOutputStream = out; //Store the user's output stream

		this.schemaVersion = schemaVersion;
		this.dataFormat = dataFormat;
		this.prettyPrint = prettyPrint;
		createNamespaces();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////INNER CLASSES						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	class Namespace {
		protected String namespaceURL;
		protected String namespacePrefix;

		public Namespace(String namespaceURL, String namespacePrefix) {
			this.namespaceURL = namespaceURL;
			this.namespacePrefix = namespacePrefix;
		}
	}

	enum POSITION {
		DATASET,
		DATASET_ATTRIBUTE,
		SERIES_KEY,
		SERIES_KEY_ATTRIBUTE,
		GROUP,
		GROUP_KEY,
		GROUP_KEY_ATTRIBUTE,
		OBSERVATION,
		OBSERVATION_ATTRIBUTE,
		COMP_KEY;
	}

	/**
	 * Contains output streams for each dataset that has been written
	 */
	private class DataSetOutputStreams {
		private WriteableDataLocation seriesOutLocation;
		private WriteableDataLocation out;
		private OutputStream outputStream;
		private DatasetHeaderBean headerBean;
		private ProvisionAgreementBean provision;
		private DataflowBean dataflow;
		private DataStructureBean dsd;
		private Namespace datasetNamespace;  //Namespace for the dataset
		private Namespace dataNamespace;     //Namespace for the data contents
		private String dimensionAtObservation;
		private Map<String, String> datasetAttributes = new HashMap<>();

		public DataSetOutputStreams(
				ProvisionAgreementBean provision,
				DataflowBean dataflow,
				DataStructureBean dsd,
				DatasetHeaderBean headerBean,
				List<Namespace> knownNamespaces,
				int writerNumber) {
			this.provision = provision;
			this.dataflow = dataflow;
			this.dsd = dsd;
			out = new OverflowWriteableDataLocation();
			outputStream = out.getOutputStream();

			this.headerBean = headerBean;
			setDimensionAtObservation();
			writer = createWriter(outputStream, knownNamespaces, writerNumber);
			try {
				writer.flush();
			} catch (XMLStreamException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(isTwoPointOne() && dsd.getGroups().size() > 0) {
				seriesOutLocation = new OverflowWriteableDataLocation();
				seriesWriter = createWriter(seriesOutLocation.getOutputStream(), knownNamespaces, writerNumber);
			} else {
				seriesWriter = writer;
				seriesOutLocation = out;
			}

			if(isThreePointZero()){
				FOOTER_NS = new Namespace(SdmxConstants.MESSAGE_FOOTER_NS_3_0, "footer");
			}
		}

		/**
		 * Returns either the dataflow if it exists, or data structure
		 * @return
		 */
		public MaintainableBean getStructureForData() {
			if(provision != null) {
				return provision;
			} else if(dataflow != null) {
				return dataflow;
			}
			return dsd;
		}

		public String getDimensionAtObservation() {
			return dimensionAtObservation;
		}

		private void setDimensionAtObservation() {
			if(headerBean == null || headerBean.getDataStructureReference() == null || !ObjectUtil.validString(headerBean.getDataStructureReference().getDimensionAtObservation())) {
				if(dsd.getTimeDimension() == null) {
					this.dimensionAtObservation = "AllDimensions";
				} else {
					this.dimensionAtObservation = DimensionBean.TIME_DIMENSION_FIXED_ID;
				}
			} else {
				this.dimensionAtObservation =  headerBean.getDataStructureReference().getDimensionAtObservation();
			}
		}

		private Namespace getNamespaceIfKnown(List<Namespace> knownNamespaces, String namespaceUrl) {
			for(Namespace currentNamespace : knownNamespaces) {
				if(currentNamespace.namespaceURL.equals(namespaceUrl)) {
					return currentNamespace;
				}
			}
			return null;
		}

		private XMLStreamWriter createWriter(OutputStream writerOut, List<Namespace> knownNamespaces, int writerNumber) {
			try {
				XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();

				String encoding = StandardCharsets.UTF_8.toString();

				XMLStreamWriter localWriter = xmlOutputfactory.createXMLStreamWriter(writerOut, encoding);
				if(prettyPrint == true) {
					localWriter = new IndentingXMLStreamWriter(localWriter);
				}

				localWriter.writeStartDocument(encoding, "1.0");

				MaintainableBean constrainable = getStructureForData();

				if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
					dataNamespace = generateStructureNameSpace(constrainable, writerNumber);
					if (isTwoPointOne() || isThreePointZero()) {
						datasetNamespace = MESSAGE_NS;
					} else {
						datasetNamespace = dataNamespace;
					}
					COMPACT_NS = dataNamespace;
				} else if(dataFormat == BASE_DATA_FORMAT.CROSS_SECTIONAL) {
					datasetNamespace = MESSAGE_NS;
					dataNamespace = generateStructureNameSpace(constrainable, writerNumber);
					CROSS_NS = dataNamespace;
				} else {
					datasetNamespace = MESSAGE_NS;
				}

				startElement(localWriter, datasetNamespace, "DataSet");
				if(isTwoPointOne()) {
					localWriter.writeNamespace(FOOTER_NS.namespacePrefix, FOOTER_NS.namespaceURL);
				}
				localWriter.writeNamespace(COMMON_NS.namespacePrefix, COMMON_NS.namespaceURL);
				localWriter.writeNamespace(MESSAGE_NS.namespacePrefix, MESSAGE_NS.namespaceURL);
				if(dataNamespace != null && dataNamespace != datasetNamespace) {
					localWriter.writeNamespace(dataNamespace.namespacePrefix, dataNamespace.namespaceURL);
				}
				if(dataFormat == BASE_DATA_FORMAT.GENERIC) {
					localWriter.writeNamespace(GENERIC_NS.namespacePrefix, GENERIC_NS.namespaceURL);
				}
				localWriter.writeNamespace("xsi", XSI_NS);
				localWriter.writeNamespace("xml", XML_NS);

				if(datasetNamespace != MESSAGE_NS) {
					localWriter.writeNamespace(datasetNamespace.namespacePrefix, datasetNamespace.namespaceURL);
				}


				if(!isTwoPointOne() && !isThreePointZero()) {
					if(constrainable instanceof DataflowBean) {
						//Version 2.0 and 1.0 have dataflowAgencyID and dataflowID on the Dataset as attributes
						datasetAttributes.put("dataflowAgencyID", constrainable.getAgencyId());
						datasetAttributes.put("dataflowID", constrainable.getId());
					} else if(constrainable instanceof ProvisionAgreementBean) {
						ProvisionAgreementBean prov = (ProvisionAgreementBean) constrainable;
						//Version 2.0 and 1.0 have dataflowAgencyID and dataflowID on the Dataset as attributes
						datasetAttributes.put("dataflowAgencyID", prov.getStructureUseage().getReference().getAgencyId());
						datasetAttributes.put("dataflowID", prov.getStructureUseage().getReference().getMaintainableId());
						datasetAttributes.put("dataProviderID", prov.getDataproviderRef().getReference().getIdentifiableId());
						datasetAttributes.put("dataProviderSchemeAgencyId", prov.getDataproviderRef().getReference().getAgencyId());
						datasetAttributes.put("dataProviderSchemeId", prov.getDataproviderRef().getReference().getMaintainableId());
					}
				}

				return localWriter;
			} catch(XMLStreamException e) {
				throw new RuntimeException(e);
			}
		}

		/**
		 * Writes out the namespace
		 * @param bean either a dataflow, data strucutre, or a provision agreement
		 * @param writerNumber
		 * @return
		 */
		private Namespace generateStructureNameSpace(MaintainableBean bean, int writerNumber) {
			String postFix = isTwoPointOne() || isThreePointZero() ? ":ObsLevelDim:"+getDimensionAtObservation() : dataFormat == BASE_DATA_FORMAT.CROSS_SECTIONAL ? ":cross" : ":compact";
			String ssNamespaceUrl = bean.getUrn() + postFix;

			Namespace dataNamespace = getNamespaceIfKnown(knownNamespaces, ssNamespaceUrl);
			if(dataNamespace == null) {
				dataNamespace = new Namespace(ssNamespaceUrl, "ns"+writerNumber);
			}
			return dataNamespace;
		}
	}




	/**
	 * Writes annotations to the writer, if the argument is null, then thie method will return
	 * @param annotationWriter to write the annotations to
	 * @param annotations
	 */
	void writeAnnotations(XMLStreamWriter annotationWriter, AnnotationBean... annotations) {
		try {
			if(annotations != null && annotations.length > 0) {

				if(isTwoPointOne() || isThreePointZero()) {
					startElement(annotationWriter, COMMON_NS, "Annotations");
					if(annotationWriter == writer) {
						hasGroups = true;
					}
				} else if(dataFormat == BASE_DATA_FORMAT.GENERIC) {
					startElement(annotationWriter, GENERIC_NS, "Annotations");
				} else {
					startElement(annotationWriter, COMPACT_NS, "Annotations");
				}
				for(AnnotationBean currentAnnotation : annotations) {
					if(currentAnnotation == null) {
						continue;
					}
					startElement(annotationWriter, COMMON_NS, "Annotation");
					if((isTwoPointOne() || isThreePointZero()) && ObjectUtil.validString(currentAnnotation.getId())) {
						annotationWriter.writeAttribute("id", currentAnnotation.getId());
					}
					if(ObjectUtil.validString(currentAnnotation.getTitle())) {
						startElement(annotationWriter, COMMON_NS, "AnnotationTitle");
						annotationWriter.writeCharacters(currentAnnotation.getTitle());
						annotationWriter.writeEndElement(); //END AnnotationTitle
					}
					if(ObjectUtil.validString(currentAnnotation.getType())) {
						startElement(annotationWriter, COMMON_NS, "AnnotationType");
						annotationWriter.writeCharacters(currentAnnotation.getType());
						annotationWriter.writeEndElement(); //END AnnotationType
					}
					if(currentAnnotation.getUri() != null) {
						startElement(annotationWriter, COMMON_NS, "AnnotationURL");
						annotationWriter.writeCharacters(currentAnnotation.getUri().toString());
						annotationWriter.writeEndElement(); //END AnnotationURL
					}
					if(ObjectUtil.validCollection(currentAnnotation.getText())) {
						for(TextTypeWrapper currentText : currentAnnotation.getText()) {
							startElement(annotationWriter, COMMON_NS, "AnnotationText");
							annotationWriter.writeAttribute("xml", XML_NS, "lang", currentText.getLocale());
							annotationWriter.writeCharacters(currentText.getValue());
							annotationWriter.writeEndElement(); //END AnnotationText
						}
					}
					annotationWriter.writeEndElement(); //END ANNOTATION
				}
				annotationWriter.writeEndElement(); //END ANNOTATIONS
			}
		} catch(XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////INTERNAL METHODS					 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	private void createNamespaces() {
		COMPACT_NS = new Namespace("http://www.sdmxfusion.com/ns/compact", PREFIX_COMPACT);

		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
			GENERIC_NS = new Namespace(SdmxConstants.GENERIC_NS_2_1, PREFIX_GENERIC);
			MESSAGE_NS = new Namespace(SdmxConstants.MESSAGE_NS_2_1, PREFIX_MESSAGE);
			COMMON_NS  = new Namespace(SdmxConstants.COMMON_NS_2_1, PREFIX_COMMON);
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO) {
			GENERIC_NS = new Namespace(SdmxConstants.GENERIC_NS_2_0, PREFIX_GENERIC);
			MESSAGE_NS = new Namespace(SdmxConstants.MESSAGE_NS_2_0, PREFIX_MESSAGE);
			COMMON_NS  = new Namespace(SdmxConstants.COMMON_NS_2_0, PREFIX_COMMON);
			if(dataFormat == BASE_DATA_FORMAT.CROSS_SECTIONAL) {
				CROSS_NS  = new Namespace(SdmxConstants.CROSS_NS_2_0, PREFIX_CROSS);
			}
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
			GENERIC_NS = new Namespace(SdmxConstants.GENERIC_NS_1_0, PREFIX_GENERIC);
			MESSAGE_NS = new Namespace(SdmxConstants.MESSAGE_NS_1_0, PREFIX_MESSAGE);
			COMMON_NS  = new Namespace(SdmxConstants.COMMON_NS_1_0, PREFIX_COMMON);
			if(dataFormat == BASE_DATA_FORMAT.CROSS_SECTIONAL) {
				CROSS_NS  = new Namespace(SdmxConstants.CROSS_NS_1_0, PREFIX_CROSS);
			}
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_THREE) {
			//TODO sdmx3.0 does not have generic?
			GENERIC_NS = null;
			MESSAGE_NS = new Namespace(SdmxConstants.MESSAGE_NS_3_0, PREFIX_MESSAGE);
			COMMON_NS  = new Namespace(SdmxConstants.COMMON_NS_3_0, PREFIX_COMMON);
		}
	}

	private void writeNameSpace(Namespace ns) throws XMLStreamException {
		if(ns != null) {
			writer.writeNamespace(ns.namespacePrefix, ns.namespaceURL);
		}
	}

	protected boolean isTwoPointOne() {
		return schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE;
	}
	protected boolean isThreePointZero() {
		return schemaVersion == SDMX_SCHEMA.VERSION_THREE;
	}

	protected void startElement(XMLStreamWriter streamWriter, Namespace ns, String elementName) throws XMLStreamException  {
		streamWriter.writeStartElement(ns.namespacePrefix, elementName, ns.namespaceURL);
	}

	private String getStructureRef(MaintainableBean maint) {
		return maint.getAgencyId() + "_" + maint.getId() + "_" + maint.getVersion().toString().replaceAll("\\.", "_");
	}

	private List<Namespace> knownNamespaces = new ArrayList<>();
	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////INTERFACE METHOD IMPLEMENTATIONS	 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void startDataset(ProvisionAgreementBean provision, DataflowBean dataflowBean, DataStructureBean dsd, DatasetHeaderBean header, AnnotationBean... annotationMutableBean) {
		checkClosed();
		if(dsd == null) {
			throw new IllegalArgumentException("Can not start dataset, no DataStructure provided");
		}
		if(dsd.getPrimaryMeasure() == null && dsd.getMeasures().isEmpty()) {
			throw new SdmxNotAcceptableException("SDMX-ML DSD must have a Primary Measure");
		}
		//TODO Nothing is done with the dataflow - it can be used to output on the header of the message


		componentIdMapping = new HashMap<>();
		for(ComponentBean currentComponent : dsd.getComponents()) {
			componentIdMapping.put(currentComponent.getId(), getComponentId(currentComponent));
		}

		closeCurrentWriter();
		currentPosition = POSITION.DATASET;

		currentDatasetOutputLocations = new DataSetOutputStreams(provision, dataflowBean, dsd, header, knownNamespaces, outputDatasetLocations.size()+1);
		if(currentDatasetOutputLocations.dataNamespace != null) {
			knownNamespaces.add(currentDatasetOutputLocations.dataNamespace);
		}
		this.crossSectionConcept = currentDatasetOutputLocations.getDimensionAtObservation();


		this.isFlat = crossSectionConcept.equals(DIMENSION_AT_OBSERVATION.ALL.getVal());
		this.isCrossSectional  = !crossSectionConcept.equals(DimensionBean.TIME_DIMENSION_FIXED_ID);

		if(!isFlat) {
			DimensionBean dimension = dsd.getDimension(crossSectionConcept);
			if(dimension == null) {
				if(dsd.getMeasure(crossSectionConcept) != null) {
					this.isCrossSectionalMeasure = true;
				} else {
					throw new IllegalArgumentException("Can not start dataset.  The dimension at observation has been set to '"+crossSectionConcept+"', but this dimension does not exist in the datastructure: '"+dsd.getUrn()+"'");
				}
			}
		}

		this.out = currentDatasetOutputLocations.outputStream;
		this.seriesOut = currentDatasetOutputLocations.seriesOutLocation.getOutputStream();

		outputDatasetLocations.add(currentDatasetOutputLocations);
	}

	@Override
	public void writeHeader(HeaderBean header) {
		checkClosed();
		this.header = header;
	}


	//	public void setCrossSectionConcept(String concept) throws UnsupportedException {
	//		if(concept == null) {
	//			throw new ValidationException("Can not set the cross section concept to null");
	//		}
	//		if(!concept.equals(DimensionBean.TIME_DIMENSION_FIXED_ID) && this.schemaVersion != SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
	//			throw new UnsupportedException("Compact Cross sectional datasets not supported for version " + schemaVersion.toString());
	//		}
	//		this.crossSectionConcept = concept;
	//		isCrossSectional = true;
	//	}

	/**
	 * Returns the id that should be output for a component Id.  For a 1.0 and 2.0 data message this is the Id of the Concept.
	 * For a 2.1 data message, this is the id of the component (and will just be returned unchanged).
	 *
	 * @param componentId
	 * @return
	 */
	protected String getComponentId(String componentId) {
		if(isTwoPointOne() || isThreePointZero()) {
			return componentId;
		}
		if(componentIdMapping.containsKey(componentId)) {
			return componentIdMapping.get(componentId);
		}
		return componentId;
	}


	protected String getComponentId(ComponentBean component) {
		if(component == null) {
			return null;
		}
		if(isTwoPointOne() || isThreePointZero()) {
			return component.getId();
		}
		return ConceptRefUtil.getConceptId(component.getConceptRef().getReference());
	}


	@Override
	public void startGroup(String groupId, AnnotationBean... annotationBean) {
		checkClosed();
		hasGroups = true;
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not startGroup, no call has been made to startDataset");
		}

	}

	@Override
	public void writeGroupKeyValue(String id, String value) {
		checkClosed();
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not writeGroupKeyValue, no call has been made to startDataset");
		}
		if(currentPosition != POSITION.GROUP && currentPosition != POSITION.GROUP_KEY && currentPosition != POSITION.GROUP_KEY_ATTRIBUTE) {
			throw new IllegalArgumentException("Can not writeGroupKeyValue, not in a group");
		}
	}

	@Override
	public void startSeries(AnnotationBean... annotationMutableBean) {
		checkClosed();
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not startSeries, no call has been made to startDataset");
		}
	}

	@Override
	public void writeSeriesKeyValue(String id, String value) {
		checkClosed();
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not writeSeriesKeyValue, no call has been made to startDataset");
		}
	}

	@Override
	public void writeAttributeValue(String id, String... value) {
		checkClosed();
		if(currentPosition == POSITION.DATASET) {
			hasDatasetAttributes = true;
		}
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not writeAttributeValue, no call has been made to startDataset");
		}
	}

	protected String checkWriteObs(List<KeyValue> measures) {
		checkClosed();
		if(currentPosition == null) {
			throw new IllegalArgumentException("Can not writeObservation, no call has been made to startDataset");
		}
		if (measures.size() >0){
			for (KeyValue measure: measures){
				if(Objects.equals(measure.getConcept(), PrimaryMeasureBean.FIXED_ID)){
					return measure.getCode();
				}
			}
			throw new IllegalArgumentException("Only OBS_VALUE measures supported");
		}
		else{
			return null;
		}
	}


	public void writeDatasetAttribute(String id, String value) {
		if (id != null &&  (id.equals("action") || id.equals("validFromDate") || id.contentEquals("validToDate") || id.equals("publicationPeriod") || id.equals("publicationYear"))) {
			// Ignore these types - they will be added later.
			return;
		}

		checkClosed();
		currentDatasetOutputLocations.datasetAttributes.put(id, value);
	}

	protected void writeEndComp() throws XMLStreamException {
		if(isThreePointZero()) {
			if(currentPosition==POSITION.COMP_KEY){
				seriesWriter.writeEndElement(); // close <Comp/>
				currentPosition = positionBeforeComp;
			}
		}
		else{
			throw new SdmxSemmanticException("Complex nodes are only supported in SDMX 3.0. Transforming SDMX 3.0 with complex nodes into "+schemaVersion+" is not supported.");
		}
	}

	protected void startComp(String id, String type) throws XMLStreamException{

		if(isThreePointZero()) {
			if(currentPosition == POSITION.COMP_KEY){
				writeEndComp();
			} else {
				positionBeforeComp = currentPosition;
			}
			currentPosition = POSITION.COMP_KEY;
		}
		else{
			throw new SdmxSemmanticException("Complex nodes are only supported in SDMX 3.0. Transforming SDMX 3.0 with complex nodes into "+schemaVersion+" is not supported.");
		}

	}

	protected void writeEndObs() throws XMLStreamException {
		if(!isTwoPointOne()) {
			writeAnnotations(seriesWriter, obsAnnotations);
			obsAnnotations = null;
		}
		seriesWriter.writeEndElement(); //END OBS
	}

	protected void writeEndSeries() throws XMLStreamException {
		if(!isTwoPointOne() && !isThreePointZero()) {
			writeAnnotations(seriesWriter, seriesAnnotations);
			seriesAnnotations = null;
		}
		seriesWriter.writeEndElement(); //END SERIES
		currentPosition = POSITION.DATASET; //Position is back to dataset
	}

	protected void writeEndGroup() throws XMLStreamException {
		if(!isTwoPointOne()) {
			writeAnnotations(writer, groupAnnotations);
			groupAnnotations = null;
		}

		writer.writeEndElement(); //END GROUP
		currentPosition = POSITION.DATASET; //Position is back to dataset
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////CLOSE WRITER						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////
	protected abstract void closeGroupWriter() throws Exception;


	@Override
	protected void finalize() throws Throwable {
		try {
			clearResources();        // close open files
		} finally {
			super.finalize();
		}
	}

	private void clearResources() {
		try {
			if(outputDatasetLocations != null) {
				for(DataSetOutputStreams dsOut : outputDatasetLocations) {
					if(dsOut.out != null) dsOut.out.close();
					if(dsOut.seriesOutLocation != null) dsOut.seriesOutLocation.close();
				}
			}
		} catch(Throwable th) {

		}
	}

	@Override
	public void close(FooterMessage... footer) {
		if(isClosed) {
			return;
		}
		isClosed = true;

		//1. Close the current writer
		closeCurrentWriter();

		//2. Flush the output to the master output stream
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		String endElement = null;
		try {
			endElement = flushOutput(bos);
		} finally {
			try {
				writer.flush();
				if(out != null) {
					out.flush();
					out.close();
				}
				//COPY AND INJECT

				if(finalOutputStream != null) {
					ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
					StreamUtil.copyStream(bis, finalOutputStream);


					boolean multipleDatasets = outputDatasetLocations.size() > 1;
					for(DataSetOutputStreams dsOut : outputDatasetLocations) {
						Namespace datasetNamespace = dsOut.datasetNamespace;
						boolean modifyEndTag = false;
						if(multipleDatasets && !isTwoPointOne() && dataFormat ==BASE_DATA_FORMAT.GENERIC) {
							//For a MessageGroup the dataset namespace is the underlying dataformat, otherwise for 2.0 Generic data it is message
							datasetNamespace = GENERIC_NS;
							modifyEndTag = true;
						}
						StringBuilder sb = new StringBuilder();
						sb.append("<"+datasetNamespace.namespacePrefix+":DataSet");
						//						startElement(writer, datasetNamespace, "DataSet");
						if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
							for(String attributeName : dsOut.datasetAttributes.keySet()) {
								String attributeValue = dsOut.datasetAttributes.get(attributeName);
								attributeValue = StringEscapeUtils.escapeXml11(attributeValue);
								sb.append(" "+attributeName+"=\""+attributeValue+"\"");
							}
						}
						writeDatasetHeader(dsOut, multipleDatasets, sb);
						sb.append(">");
						finalOutputStream.write(sb.toString().getBytes());
						InputStream is = dsOut.out.getInputStream();
						int i=1;
						int x =0;
						while(i!=-1 && x != 2) {
							i=is.read();
							if(i==62) {
								x++;
							}
						}
						if(modifyEndTag) {
							int ignoreEndBytesCount = "</message:DataSet>".getBytes().length;
							StreamUtil.copyUTF8InputStream(is, finalOutputStream, ignoreEndBytesCount, false);
							finalOutputStream.write(("</"+datasetNamespace.namespacePrefix+":DataSet>").getBytes());
						} else {
							StreamUtil.copyStream(is, finalOutputStream);
						}
					}

					if(footer != null && footer.length > 0 && (isTwoPointOne() || isThreePointZero())) {
						StringBuilder sb = new StringBuilder();
						sb.append("<"+FOOTER_NS.namespacePrefix+":Footer>");
						for(FooterMessage currentFooter : footer) {
							sb.append("<"+FOOTER_NS.namespacePrefix+":Message code='"+currentFooter.getCode()+"'");
							if(currentFooter.getSeverity() != null) {
								sb.append(" severity='"+currentFooter.getSeverity().toString()+"'");
							}
							sb.append(">");
							for(TextTypeWrapper ttw : currentFooter.getFooterText()) {
								sb.append("<"+COMMON_NS.namespacePrefix+":Text");
								startElement(writer, COMMON_NS, "Text");
								if(ttw.getLocale() != null) {
									sb.append(" xml:lang='"+ttw.getLocale()+"'");
								}
								sb.append(">");
								if(ttw.getValue() != null) {
									sb.append(ttw.getValue());
								}
								sb.append("</"+COMMON_NS.namespacePrefix+":Text>");
							}
							sb.append("</"+FOOTER_NS.namespacePrefix+":Message>");
						}
						sb.append("</"+FOOTER_NS.namespacePrefix+":Footer>");//End footer
						finalOutputStream.write(sb.toString().getBytes());
					}
					finalOutputStream.write((endElement).getBytes());
					finalOutputStream.close();
				}
				clearResources();
			} catch (Throwable e) {
				System.err.println("Error trying to close resources");
				e.printStackTrace();
				clearResources();
			}
		}
	}

	protected void checkClosed() {
		if(isClosed) {
			throw new RuntimeException("Data Write has already been closed and can not have any more information written to it");
		}
	}

	/**
	 * Closes the current writer if there is one
	 */
	private void closeCurrentWriter() {
		if(currentDatasetOutputLocations != null) {
			DataStructureBean dsd = currentDatasetOutputLocations.dsd;
			try {
				if(isTwoPointOne() && dsd.getGroups().size() > 0) {
					//Copy all the series to the master writer containing the groups
					seriesWriter.writeEndDocument();
					seriesWriter.flush();
					seriesWriter.close();

					closeGroupWriter();

					writer.flush();
					ReadableDataLocation rdl = currentDatasetOutputLocations.seriesOutLocation;
					try {
						int i=1;
						int x = hasGroups || (hasDatasetAttributes && dataFormat == BASE_DATA_FORMAT.GENERIC) ? -1 : 0;
//					int x = hasGroups || hasDatasetAttributes ? -1 : 0;
						InputStream is = rdl.getInputStream();


						while(i!=-1 && x != 1) {
							i=is.read();
							if(i==62) {
								x++;
							}
						}
						StreamUtil.copyStream(is, out);
						StreamUtil.closeStream(seriesOut);
					} finally {
						rdl.close();
					}
				} else {
					writeAnnotations(writer, datasetAnnotations);
					datasetAnnotations = null;
					writer.writeEndDocument();
					writer.flush();
					writer.close();
				}

				if(out != null) {
					out.flush();
					out.close();
				}
			} catch(Throwable e) {
				currentDatasetOutputLocations.out.close();
				currentDatasetOutputLocations.seriesOutLocation.close();
				currentDatasetOutputLocations = null;
				isClosed = true; //Close the writer engine
				throw new RuntimeException(e);
			} finally {
				currentPosition = null;
			}
		}
	}

	/**
	 * Writes out all the data to the final OutputStream
	 * @param out
	 * @return closs tag
	 */
	private String flushOutput(OutputStream out) {
		try {
			XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();

			String encoding = StandardCharsets.UTF_8.toString();
			writer = xmlOutputfactory.createXMLStreamWriter(out, encoding);;
			if(prettyPrint == true) {
				writer = new IndentingXMLStreamWriter(writer);
			}


			writer.writeStartDocument(encoding, "1.0");

			boolean multipleDatasets = outputDatasetLocations.size() > 1;

			//Write the start Node
			String startElement = null;
			if(isTwoPointOne() || isThreePointZero()) {
				if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
					startElement = MESSAGE_NS.namespacePrefix+":"+"StructureSpecificData";
					startElement(writer, MESSAGE_NS, "StructureSpecificData");
					if (isTwoPointOne()) {
						writer.writeNamespace("ss", SdmxConstants.STRUCTURE_SPECIFIC_NS_2_1);
					} else {
						writer.writeNamespace("ss", SdmxConstants.STRUCTURE_SPECIFIC_NS_3_0);
					}
				} else if(dataFormat == BASE_DATA_FORMAT.GENERIC) {
					startElement = MESSAGE_NS.namespacePrefix+":"+"GenericData";
					startElement(writer, MESSAGE_NS, "GenericData");
				}

				writeNameSpace(FOOTER_NS);
			}
			else if(isThreePointZero()){
				if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
					startElement = MESSAGE_NS.namespacePrefix+":"+"StructureSpecificData";
					startElement(writer, MESSAGE_NS, "StructureSpecificData");
					writer.writeNamespace("ss", SdmxConstants.MESSAGE_NS_3_0);
				}
				writeNameSpace(FOOTER_NS);
			}
			else if(multipleDatasets) {
				startElement = MESSAGE_NS.namespacePrefix+":"+"MessageGroup";
				startElement(writer, MESSAGE_NS, "MessageGroup");
			} else {
				startElement = MESSAGE_NS.namespacePrefix+":"+dataFormat.getRootNode();
				startElement(writer, MESSAGE_NS, dataFormat.getRootNode());
			}

			Set<String> nameSpacePrefixWritten = new HashSet<>();
			//Write the Namespaces
			if(dataFormat == BASE_DATA_FORMAT.GENERIC) {
				writeNameSpace(GENERIC_NS);
			} else {
				for(DataSetOutputStreams dsOut : outputDatasetLocations) {
					if(!nameSpacePrefixWritten.contains(dsOut.dataNamespace.namespacePrefix)) {
						writeNameSpace(dsOut.dataNamespace);
						nameSpacePrefixWritten.add(dsOut.dataNamespace.namespacePrefix);
					}
					if(!nameSpacePrefixWritten.contains(dsOut.datasetNamespace.namespacePrefix)) {
						writeNameSpace(dsOut.datasetNamespace);
						nameSpacePrefixWritten.add(dsOut.datasetNamespace.namespacePrefix);
					}
				}
			}
			if(!nameSpacePrefixWritten.contains(COMMON_NS.namespacePrefix)) {
				writeNameSpace(COMMON_NS);
			}
			if(!nameSpacePrefixWritten.contains(MESSAGE_NS.namespacePrefix)) {
				writeNameSpace(MESSAGE_NS);
			}
			writer.writeNamespace("xsi", XSI_NS);
			writer.writeNamespace("xml", XML_NS);

			if(schemaLocationManager != null) {
				String namespaceLocation = schemaLocationManager.getSchemaLocation(schemaVersion);
				if(!namespaceLocation.endsWith("/")) {
					namespaceLocation += "/";
				}
				StringBuilder sb = new StringBuilder();
				sb.append(MESSAGE_NS.namespaceURL);
				sb.append(" ");
				sb.append(namespaceLocation+"SDMXMessage.xsd");
				if(this.dataFormat == BASE_DATA_FORMAT.COMPACT) {
					ConstrainableBean cons = null;
					Set<ConstrainableBean> written = new HashSet<>();
					for(DataSetOutputStreams dsOut : outputDatasetLocations) {
						cons = dsOut.provision;
						if(cons == null) {
							cons = dsOut.dataflow;
						}
						if(cons == null) {
							cons = dsOut.dsd;
						}
						if(!written.contains(cons)) {
							Namespace ns = dsOut.dataNamespace;
							written.add(cons);
							sb.append(" ");
							sb.append(ns.namespaceURL);
							sb.append(" ");
							sb.append(schemaLocationManager.getStructureSpecificSchemaLocation(cons, schemaVersion));
						}
					}
				}
				writer.writeAttribute(XSI_NS, "schemaLocation", sb.toString());
			}


			writeHeader();

			return "</"+startElement+">";

		} catch(XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////
	////////////WRITE HEADER						 //////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Writes out the dataset header to the writer
	 * @param datasetHeader the header to write, if null will not write anything
	 * @param hasMultipleDatasets if there are multiple datasets, then it will include attributes such as action and dataset id, which will normally get written to the messsage header when dealing with a sinlge dataset
	 * @throws XMLStreamException
	 */
	private void writeDatasetHeader(DataSetOutputStreams dsOut, boolean hasMultipleDatasets, StringBuilder sb) throws XMLStreamException {
		if(isTwoPointOne() || isThreePointZero()) {
			//TODO Will this namespace be written multiple times?
			//			writer.writeNamespace("structurespec", SdmxConstants.STRUCTURE_SPECIFIC_NS_2_1);
			if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
				if(isTwoPointOne()) {
					writeAttribute(sb, "ss", "dataScope", "DataStructure");
				}
				writeAttribute(sb, "xsi", "type", dsOut.dataNamespace.namespacePrefix+":DataSetType");
				writeAttribute(sb, "ss", "structureRef", getStructureRef(dsOut.getStructureForData()));
			} else {
				writeAttribute(sb, null, "structureRef", getStructureRef(dsOut.getStructureForData()));
			}
		}
		if(dsOut.headerBean != null) {
			DatasetHeaderBean datasetHeader = dsOut.headerBean;
			if(ObjectUtil.validString(datasetHeader.getPublicationPeriod())) {
				writeAttribute(sb, null, "publicationPeriod", datasetHeader.getPublicationPeriod());
			}
			if(datasetHeader.getPublicationYear() > 0) {
				writeAttribute(sb, null, "publicationYear", Integer.toString(datasetHeader.getPublicationYear()));
			}
			if(datasetHeader.getValidFrom() != null) {
				writeAttribute(sb, null, "validFromDate", DateUtil.formatDate(datasetHeader.getValidFrom()));
			}
			if(datasetHeader.getValidTo() != null) {
				writeAttribute(sb, null, "validToDate", DateUtil.formatDate(datasetHeader.getValidTo()));
			}
			if(hasMultipleDatasets) {
				//Write out the dataset id, action, reporting begin and end dates
				if(datasetHeader.getAction() != null) {
					String namespacePrefix = isTwoPointOne() && dataFormat == BASE_DATA_FORMAT.COMPACT ? "ss" : null;
					writeAttribute(sb, namespacePrefix, "action", datasetHeader.getAction().getAction());
				}
				if(ObjectUtil.validString(datasetHeader.getDatasetId())) {
					if(isTwoPointOne()) {
						writeAttribute(sb, null, "setID", datasetHeader.getDatasetId());
					} else {
						writeAttribute(sb, null, "datasetID", datasetHeader.getDatasetId());
					}
				}
				if(!isTwoPointOne()) {
					writeAttribute(sb, null, "keyFamilyURI", dsOut.dsd.getUrn());
				}
				if(datasetHeader.getReportingBeginDate() != null) {
					writeAttribute(sb, null, "reportingBeginDate", DateUtil.formatDate(datasetHeader.getReportingBeginDate()));
				}
				if(datasetHeader.getReportingEndDate() != null) {
					writeAttribute(sb, null, "reportingEndDate", DateUtil.formatDate(datasetHeader.getReportingEndDate()));
				}
			}
		}
	}

	private void writeAttribute(StringBuilder sb, String nsPrefix, String attId, String attVal) {
		if(nsPrefix != null) {
			sb.append(" "+nsPrefix+":"+attId+"=\""+attVal+"\"");
		} else {
			sb.append(" "+attId+"=\""+attVal+"\"");
		}
	}

	/**
	 * Writes the header to the writer
	 */
	private void writeHeader() {
		try {
			startElement(writer, MESSAGE_NS, "Header");  //START HEADER
			//ID
			startElement(writer, MESSAGE_NS, "ID");
			if(header != null && ObjectUtil.validString(header.getId())) {
				writer.writeCharacters(header.getId());
			} else {
				writer.writeCharacters("DS"+Long.toString(new Date().getTime()));
			}
			writer.writeEndElement();

			//Test
			startElement(writer, MESSAGE_NS, "Test");
			if(header != null) {
				writer.writeCharacters(new Boolean(header.isTest()).toString());
			} else {
				writer.writeCharacters("false");
			}
			writer.writeEndElement();

			if(!isTwoPointOne() && header != null && header.getName() != null) {
				//In 2.0 the name goes in this location
				writeTextTypes(MESSAGE_NS, "Name", header.getName());
			}

			//Prepared
			startElement(writer, MESSAGE_NS, "Prepared");
			if(header != null && header.getPrepared() != null) {
				writer.writeCharacters(DateUtil.formatDate(header.getPrepared(), true));
			} else {
				writer.writeCharacters(DateUtil.formatDate(new Date(), true));
			}
			writer.writeEndElement();

			startElement(writer, MESSAGE_NS, "Sender");
			if(header != null && header.getSender() != null) {
				writeParty(header.getSender(), isTwoPointOne()); //Only 2.1 has the concept of timeZone in the Sender
			} else {
				if (headerRetrievalManager != null && headerRetrievalManager.getHeader() != null) {
					writeParty(headerRetrievalManager.getHeader().getSender(), isTwoPointOne()); //Only 2.1 has the concept of timeZone in the Sender
				} else {
					writer.writeAttribute("id", "MetadataTechnology");
				}
			}
			writer.writeEndElement();

			if(header != null && header.getReceiver() != null) {
				writeReceiver(header.getReceiver());
			}
			if(isTwoPointOne() && header != null && header.getName() != null) {
				//In 2.1 the name goes in this location
				writeTextTypes(COMMON_NS, "Name", header.getName());
			}
			Map<MaintainableBean, SdmxDataWriterEngine.Namespace> constrainables = new HashMap<>();
			Set<DataStructureBean> dsds = new HashSet<>();
			for(DataSetOutputStreams os : outputDatasetLocations) {
				constrainables.put(os.getStructureForData(), os.dataNamespace);
				dsds.add(os.dsd);
			}

			if(isTwoPointOne() || isThreePointZero()) {
				for(MaintainableBean currentStructure : constrainables.keySet()) {
					//Start Structure
					startElement(writer, MESSAGE_NS, "Structure");

					writer.writeAttribute("structureID", getStructureRef(currentStructure));


					if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
						//currentStructure.get
						SdmxDataWriterEngine.Namespace ns = constrainables.get(currentStructure);
						if(ns == null) {
							ns = COMPACT_NS;
						}
						writer.writeAttribute("namespace", ns.namespaceURL);
					}
					if(crossSectionConcept != null) {
						writer.writeAttribute("dimensionAtObservation", crossSectionConcept);
					} else {
						writer.writeAttribute("dimensionAtObservation", DimensionBean.TIME_DIMENSION_FIXED_ID);
					}

					//Start Structure (in this case Structure refers to DSD)
					if(isThreePointZero()){
						if (currentStructure instanceof ProvisionAgreementBean) {
							startElement(writer, COMMON_NS, "ProvisionAgreement");
						} else if (currentStructure instanceof DataflowBean) {
							startElement(writer, COMMON_NS, "StructureUsage");
						} else {
							startElement(writer, COMMON_NS, "Structure");
						}
						writer.writeCharacters(currentStructure.getUrn());
					}
					else {
						if (currentStructure instanceof ProvisionAgreementBean) {
							startElement(writer, COMMON_NS, "ProvisionAgrement");
						} else if (currentStructure instanceof DataflowBean) {
							startElement(writer, COMMON_NS, "StructureUsage");
						} else {
							startElement(writer, COMMON_NS, "Structure");
						}

						//Start Ref
						writer.writeStartElement("Ref");


						writer.writeAttribute("agencyID", currentStructure.getAgencyId());
						writer.writeAttribute("id", currentStructure.getId());
						writer.writeAttribute("version", currentStructure.getVersion().toString());
						//End Ref
						writer.writeEndElement();
					}

					//End Structure
					writer.writeEndElement();

					//End Structure
					writer.writeEndElement();
				}
			} else if(dsds.size() == 1) {
				DataStructureBean dsd = (DataStructureBean)dsds.toArray()[0];
				StructureReferenceBean dsdRef = dsd.asReference();
				// KeyFamilyRef
				startElement(writer, MESSAGE_NS, "KeyFamilyRef");
				writer.writeCharacters(dsdRef.getMaintainableReference().getMaintainableId());
				writer.writeEndElement();

				// KeyFamilyAgency
				startElement(writer, MESSAGE_NS, "KeyFamilyAgency");
				writer.writeCharacters(dsdRef.getMaintainableReference().getAgencyId());
				writer.writeEndElement();
			}
			//The following are all optional, and only output if the header is not null
			if(header != null) {
				if(isTwoPointOne()  && header.getDataProviderReference() != null) {
					IURNSingle<DataProviderBean> dpRef = header.getDataProviderReference();
					if(ObjectUtil.validString(dpRef.getAgencyId(), dpRef.getMaintainableId())) {
						//Start DataProvider
						startElement(writer, MESSAGE_NS, "DataProvider");

						//Start Ref
						writer.writeStartElement("Ref");
						writer.writeAttribute("agencyID", dpRef.getAgencyId());
						writer.writeAttribute("id", dpRef.getMaintainableId());
						if(dpRef.getVersion().isAll()) {
							writer.writeAttribute("version", MaintainableBean.DEFAULT_VERSION);
						} else {
							writer.writeAttribute("version", dpRef.getVersion().toString());
						}
						//End Ref
						writer.writeEndElement();

						//End DataProvider
						writer.writeEndElement();

					}
				}
				if(!isTwoPointOne() && header.hasAdditionalAttribute(HeaderBean.DATASET_AGENCY)) {
					startElement(writer, MESSAGE_NS, "DataSetAgency");
					writer.writeCharacters(header.getAdditionalAttribute(HeaderBean.DATASET_AGENCY));
					writer.writeEndElement();
				}
				String datasetId = getDatasetIdForHeader();
				String datasetAction = getDatasetActionForHeader();

				if(datasetAction != null) {
					//FR-4101 / FMR-137: Enforce that SDMX 1.0 only supports actions of 'Update' and 'Delete'
					if(schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
						if(!datasetAction.equals(DATASET_ACTION.DELETE.getAction())) {
							datasetAction = DATASET_ACTION.UPDATE.getAction();
						}
					} else if(datasetAction.equals(DATASET_ACTION.UPDATE.getAction())) {
						datasetAction = DATASET_ACTION.REPLACE.getAction();
					}
				}


				if(isTwoPointOne() || isThreePointZero()) {
					writeDatasetAction(datasetAction);
					writeDatasetId(datasetId);
				} else {
					writeDatasetId(datasetId);
					writeDatasetAction(datasetAction);
				}

				if(header.getExtracted() != null) {
					startElement(writer, MESSAGE_NS, "Extracted");
					writer.writeCharacters(DateUtil.formatDate(header.getExtracted()));
					writer.writeEndElement();
				}
				String reportingBeginDate = getReportingBeginForHeader();
				if(reportingBeginDate != null) {
					startElement(writer, MESSAGE_NS, "ReportingBegin");
					writer.writeCharacters(reportingBeginDate);
					writer.writeEndElement();
				}

				String reportingEndDate = getReportingEndForHeader();
				if(reportingEndDate != null) {
					startElement(writer, MESSAGE_NS, "ReportingEnd");
					writer.writeCharacters(reportingEndDate);
					writer.writeEndElement();
				}
				if(isTwoPointOne() && header.getEmbargoDate() !=  null) {
					startElement(writer, MESSAGE_NS, "EmbargoDate");
					writer.writeCharacters(DateUtil.formatDate(header.getEmbargoDate()));
					writer.writeEndElement();
				}
				writeTextTypes(MESSAGE_NS, "Source", header.getSource());
			}

			writer.writeEndElement(); //END HEADER
			headerWritten = true;
		} catch(XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	private boolean writeDatasetId(String datasetId) throws XMLStreamException {
		if(ObjectUtil.validString(datasetId)) {
			startElement(writer, MESSAGE_NS, "DataSetID");
			writer.writeCharacters(datasetId);
			writer.writeEndElement();
			return true;
		}
		return false;
	}

	private boolean writeDatasetAction(String datasetAction) throws XMLStreamException {
		if(ObjectUtil.validString(datasetAction)) {
			startElement(writer, MESSAGE_NS, "DataSetAction");
			writer.writeCharacters(datasetAction);
			writer.writeEndElement();
			return true;
		}
		return false;
	}

	/**
	 * Returns the dataset id for the header.
	 * If the header does not contain this information, obtain the information from the datasets.
	 * If there are no datasets, null will be returned.
	 * If there is only one dataset, use that datasets information (if available).
	 * If there is more than one dataset, all datasets will be inspected. If they all have the same id, that value
	 * will be returned otherwise null will be returned.
	 * @return returns the dataset id or null if the id could not be determined.
	 */
	private String getDatasetIdForHeader() {
		if (ObjectUtil.validString(header.getDatasetId())) {
			return header.getDatasetId();
		}

		if (outputDatasetLocations.size() == 0) {
			return null;
		}

		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
		if (primaryHeaderBean == null) {
			return null;
		}

		if(outputDatasetLocations.size() == 1) {
			return primaryHeaderBean.getDatasetId();
		}

		String primaryId = primaryHeaderBean.getDatasetId();
		for (int i=1; i < outputDatasetLocations.size(); i++) {
			DatasetHeaderBean headerBean = outputDatasetLocations.get(i).headerBean;
			if (headerBean == null) {
				return null;
			}
			if (!ObjectUtil.equivalent(primaryId, headerBean.getDatasetId())) {
				return null;
			}
		}
		return primaryId;
	}

	/**
	 * Returns the dataset action for the header.
	 * This information may be obtained from the header or from the action on the dataset(s).
	 * If null is returned, either the header did not contain this information or multiple contradictory datasets mean that no single
	 * action could be determined.
	 *
	 * If there are no datasets, null will be returned unless the header states an action.
	 * If there is only one dataset, use that datasets information (if available).
	 * If there is more than one dataset, all datasets will be inspected. If they all have the same action, that value
	 * will be returned otherwise null will be returned.
	 * @return returns the dataset action or null if the action could not be determined.
	 */
	private String getDatasetActionForHeader() {
		DATASET_ACTION headerAction = header.getAction();

		Object k = ThreadLocalUtil.retrieveFromThread("ENFORCE_DATASET_ACTION");
		if (k != null && (k instanceof DATASET_ACTION)) {
			return ((DATASET_ACTION)k).getAction();
		}


		if (outputDatasetLocations.size() == 0) {
			return (headerAction == null) ? null : headerAction.getAction();
		}

		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
		if (primaryHeaderBean == null || primaryHeaderBean.getAction() == null) {
			return (headerAction == null) ? null : headerAction.getAction();
		}

		if(outputDatasetLocations.size() == 1) {
			return primaryHeaderBean.getAction().getAction();
		}

		DATASET_ACTION primaryAction = primaryHeaderBean.getAction();
		for (int i=1; i < outputDatasetLocations.size(); i++) {
			DatasetHeaderBean aDsHeaderBean = outputDatasetLocations.get(i).headerBean;
			if (aDsHeaderBean == null || aDsHeaderBean.getAction() == null) {
				return null;
			}
			if (!primaryAction.equals(aDsHeaderBean.getAction())) {
				return null;
			}
		}
		return primaryAction.getAction();
	}

	/**
	 * Returns the reporting begin date for the header.
	 * If the header does not contain this information, obtain the information from the datasets.
	 * If there are no datasets, null will be returned.
	 * If there is only one dataset, use that datasets information (if available).
	 * If there is more than one dataset, all datasets will be inspected. If they all have the same reporting begin date, that value
	 * will be returned otherwise null will be returned.
	 * @return returns the dataset action or null if the reporting begin date could not be determined.
	 */
	private String getReportingBeginForHeader() {
		if (header.getReportingBegin() != null) {
			return DateUtil.formatDate(header.getReportingBegin());
		}

		if (outputDatasetLocations.size() == 0) {
			return null;
		}

		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
		if (primaryHeaderBean == null || primaryHeaderBean.getReportingBeginDate() == null) {
			return null;
		}

		if (outputDatasetLocations.size() == 1) {
			return DateUtil.formatDate(primaryHeaderBean.getReportingBeginDate());
		}

		Date primaryDate = primaryHeaderBean.getReportingBeginDate();
		for (int i=1; i < outputDatasetLocations.size(); i++) {
			DatasetHeaderBean headerBean = outputDatasetLocations.get(i).headerBean;
			if (headerBean == null || headerBean.getReportingBeginDate() == null) {
				return null;
			}
			if (!primaryDate.equals(headerBean.getReportingBeginDate())) {
				return null;
			}
		}
		return DateUtil.formatDate(primaryDate);
	}

	/**
	 * Returns the reporting end date for the header.
	 * If the header does not contain this information, obtain the information from the datasets.
	 * If there are no datasets, null will be returned.
	 * If there is only one dataset, use that datasets information (if available).
	 * If there is more than one dataset, all datasets will be inspected. If they all have the same reporting end date, that value
	 * will be returned otherwise null will be returned.
	 * @return returns the dataset action or null if the reporting end date could not be determined.
	 */
	private String getReportingEndForHeader() {
		if(header.getReportingEnd() != null) {
			return DateUtil.formatDate(header.getReportingEnd());
		}

		if (outputDatasetLocations.size() == 0) {
			return null;
		}

		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
		if (primaryHeaderBean == null || primaryHeaderBean.getReportingEndDate() == null) {
			return null;
		}

		if (outputDatasetLocations.size() == 1) {
			return DateUtil.formatDate(primaryHeaderBean.getReportingEndDate());
		}

		Date primaryDate = primaryHeaderBean.getReportingEndDate();
		for (int i=1; i < outputDatasetLocations.size(); i++) {
			DatasetHeaderBean headerBean = outputDatasetLocations.get(i).headerBean;
			if (headerBean == null || headerBean.getReportingEndDate() == null) {
				return null;
			}
			if (!primaryDate.equals(headerBean.getReportingEndDate())) {
				return null;
			}
		}
		return DateUtil.formatDate(primaryDate);
	}

	private void writeReceiver(List<PartyBean> receivers) throws XMLStreamException {
		if(receivers != null) {
			for(PartyBean currentReceiver : receivers) {
				startElement(writer, MESSAGE_NS, "Receiver");
				writeParty(currentReceiver, false);
				writer.writeEndElement();
			}
		}
	}

	private void writeParty(PartyBean party, boolean includeTimeZone) throws XMLStreamException {
		if(ObjectUtil.validString(party.getId())) {
			writer.writeAttribute("id", party.getId());
			if(party.getName() != null) {
				Namespace nameNamespace = schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE ? COMMON_NS : MESSAGE_NS;
				writeTextTypes(nameNamespace, "Name", party.getName());
			}
			if(party.getContacts() != null) {
				writeContacts(party.getContacts());
			}
			if(includeTimeZone && ObjectUtil.validString(party.getTimeZone())) {
				startElement(writer, MESSAGE_NS, "Timezone");
				writer.writeCharacters(party.getTimeZone());
				writer.writeEndElement();
			}
		} else {
			writer.writeAttribute("id", "ZZZ");
		}
	}

	private void writeTextTypes(Namespace ns, String elementName, List<TextTypeWrapper> textTypes) throws XMLStreamException {
		if(textTypes != null) {
			for(TextTypeWrapper tt : textTypes) {
				startElement(writer, ns, elementName);
				writer.writeAttribute("xml", XML_NS, "lang", tt.getLocale());
				writer.writeCharacters(tt.getValue());
				writer.writeEndElement();
			}
		}
	}

	private void writeListContents(Namespace nameSpace, String elementName, List<String> list) throws XMLStreamException {
		if(list != null) {
			for(String value : list) {
				if(ObjectUtil.validString(value)) {
					startElement(writer, nameSpace, elementName);
					writer.writeCharacters(value);
					writer.writeEndElement();
				}
			}
		}
	}

	private void writeContacts(List<ContactBean> contacts) throws XMLStreamException {
		if(contacts != null) {
			for(ContactBean currentContact : contacts) {
				startElement(writer, MESSAGE_NS, "Contact");
				writeContact(currentContact);
				writer.writeEndElement();
			}
		}
	}


	private void writeContact(ContactBean contact) throws XMLStreamException {
		Namespace nameNamespace = schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE ? COMMON_NS : MESSAGE_NS;
		writeTextTypes(nameNamespace, "Name", contact.getName());
		writeTextTypes(MESSAGE_NS, "Department", contact.getDepartments());
		writeTextTypes(MESSAGE_NS, "Role", contact.getRole());
		writeListContents(MESSAGE_NS, "Telephone", contact.getTelephone());
		writeListContents(MESSAGE_NS, "Fax", contact.getFax());
		writeListContents(MESSAGE_NS, "X400", contact.getX400());
		writeListContents(MESSAGE_NS, "URI", contact.getUri());
		writeListContents(MESSAGE_NS, "Email", contact.getEmail());
	}


}