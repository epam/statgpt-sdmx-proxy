package io.sdmx.format.ml.api.process;

import io.sdmx.utils.core.xml.StaxWriter;

/**
 * Functional interface for writing STAX
 */
public interface IStaxWriteProcess {

	void write(StaxWriter writer);
	
}
