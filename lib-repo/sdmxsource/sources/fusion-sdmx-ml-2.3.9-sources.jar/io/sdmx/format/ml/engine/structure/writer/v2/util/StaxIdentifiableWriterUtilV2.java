package io.sdmx.format.ml.engine.structure.writer.v2.util;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxIdentifiableWriterUtilV2 {

	public static void writeBean(IdentifiableBean ident, String elementName, StaxWriter writer) {
		writeBean(ident, elementName, writer, null);
	}

	public static void writeBean(IdentifiableBean ident, String elementName, StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = getAttributes(ident);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(StaxStructureWriterUtilV2.STRUCTURE_NS, elementName, attributes);
		StaxAnnotableWriterUtilV2.writeBean(ident, writer);
	}

	public static Map<String, String> getAttributes(IdentifiableBean ident) {
		Map<String, String> attributes = new HashMap<>();
		attributes.put("id", ident.getId());
		attributes.put("urn", ident.getUrn());
		if(ident.getUri() != null) {
			attributes.put("uri", ident.getUri().toString());
		}
		return attributes;
	}

}
