package io.sdmx.format.ml.engine.structure.writer.v3;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.core.sdmx.engine.structure.AbstractStructureWriterEngine;
import io.sdmx.core.sdmx.util.StructureWriterUtil;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxHeaderWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.categorisation.StaxCategorisationWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.catscheme.StaxCategorySchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.codelist.StaxCodelistWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.codelist.StaxGeoCodelistWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.codelist.StaxGeographicCodelistWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.codelist.StaxValuelistWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.conceptscheme.StaxConceptSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.constraint.StaxContentConstraintWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.dataflow.StaxDataflowWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.dsd.StaxDsdWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.hcl.StaxHclWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.hcl.StaxHierarchyAssociationWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.mapping.StaxRepresentationMapWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.mapping.StaxStructureMapWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.msd.StaxMetadataProvisionWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.msd.StaxMetadataStructureWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.msd.StaxMetadataflowWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.orgscheme.StaxAgencySchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.orgscheme.StaxDataConsumerSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.orgscheme.StaxDataProviderSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.orgscheme.StaxMetadataProviderSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.orgscheme.StaxOrgUnitSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.process.StaxProcessWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.provision.StaxProvisionWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.registration.StaxRegistrationWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.reportingtaxonomy.StaxReportingTaxonomyWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxCustomTypeSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxNamePersonalisationSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxRulesetSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxTransformationSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxUserDefinedOperatorSchemeWriterEngineV3;
import io.sdmx.format.ml.engine.structure.writer.v3.transformation.StaxVtlMappingSchemeWriterEngineV3;
import io.sdmx.im.format.SDMXMetadataStandard;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.util.ItemValidityPeriodHelper;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxStructureWriterEngineV3 extends AbstractStructureWriterEngine implements IFusionSingleton {
	private static StaxStructureWriterEngineV3 INSTANCE;
	private static StaxStructureWriterEngineV3 PRETTY_INSTANCE;
	
	private SDMX_SCHEMA ouputVersion = SDMX_SCHEMA.VERSION_THREE;

	private SchemaLocationManager schemaLocationManager;
	private HeaderRetrievalManager headerRetrievalManager;

	private Map<SDMX_STRUCTURE_TYPE, StaxMaintainableWriterEngine> writerEngines = new HashMap<>();
	private Namespace messageNs = SDMX_NAMESPACE.MESSAGE_3.getNamespace();
	private Namespace structureNs =SDMX_NAMESPACE.STRUCTURE_3.getNamespace();
	private Namespace commonNs = SDMX_NAMESPACE.COMMON_3.getNamespace();
	private Namespace registryNs = SDMX_NAMESPACE.REGISTRY_3.getNamespace();
	
	
	protected boolean prettyPrint = false;


	public static StaxStructureWriterEngineV3 getInstance(boolean prettyPrint) {
		if(!prettyPrint) {
			return getInstance();
		}
		if(PRETTY_INSTANCE == null) {
			PRETTY_INSTANCE = new StaxStructureWriterEngineV3();
			PRETTY_INSTANCE.prettyPrint = true;
			FusionBeanStore.registerInstance(PRETTY_INSTANCE);
		}
		return PRETTY_INSTANCE;
	}

	public static StaxStructureWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureWriterEngineV3();
			INSTANCE.prettyPrint = false;
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
        PRETTY_INSTANCE = null;
    }


	//Private constructor - lazy load instance
	private StaxStructureWriterEngineV3() {
		super(true);
		
		this.schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
		this.headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);
		
		writerEngines.put(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME, StaxAgencySchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME, StaxDataProviderSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME, StaxDataConsumerSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME, StaxOrgUnitSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CATEGORISATION, StaxCategorisationWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME, StaxCategorySchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CODE_LIST, StaxCodelistWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, StaxConceptSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT, StaxContentConstraintWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR, StaxContentConstraintWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.DSD, StaxDsdWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.DATAFLOW, StaxDataflowWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.MSD, StaxMetadataStructureWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.METADATA_PROVIDER_SCHEME, StaxMetadataProviderSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.METADATA_FLOW, StaxMetadataflowWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.HIERARCHY, StaxHclWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION, StaxHierarchyAssociationWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.PROCESS, StaxProcessWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, StaxProvisionWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.METADATA_PROVISION, StaxMetadataProvisionWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.REGISTRATION, StaxRegistrationWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, StaxStructureMapWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP, StaxRepresentationMapWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY, StaxReportingTaxonomyWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VALUE_LIST, StaxValuelistWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME, StaxCustomTypeSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME, StaxNamePersonalisationSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME, StaxRulesetSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME, StaxTransformationSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME, StaxUserDefinedOperatorSchemeWriterEngineV3.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME, StaxVtlMappingSchemeWriterEngineV3.getInstance());
		
		createSupportedTypes(true, writerEngines.keySet());
	}

	@Override
	public void writeStructure(MaintainableBean bean, IExternalMaintainableLinks additionalLinks, OutputStream out) {
		StructureWriterUtil.writeStructure(this, bean, additionalLinks, out);
	}

	@Override
	public void writeStructures(SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, OutputStream out) {
		StaxWriter writer = null;
		try {
			if(beans.hasStructuresOfType(SDMX_STRUCTURE_TYPE.REGISTRATION)) {
				//TODO REGISTRATIONS
				writer = new StaxWriter(out, getSchemaLocation(), prettyPrint, messageNs, registryNs, commonNs);
				writeRegistrations(writer, beans, out);
			} else {
				writer = new StaxWriter(out, getSchemaLocation(), prettyPrint, messageNs, structureNs, commonNs);
				writeStructuresInternal(writer, beans, additionalLinks, out);
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}
	
	@SuppressWarnings({ "unchecked" })
	protected void writeRegistrations(StaxWriter writer, SdmxBeans beans, OutputStream out) {
		Set<RegistrationBean> registrations = beans.getRegistrations();
		writer.startDocument(messageNs, "RegistryInterface");
		writeHeader(writer, beans, true);
		writer.writeStartElement(messageNs, "QueryRegistrationResponse");


		StaxMaintainableWriterEngine writerEngine = getWriterEngine(SDMX_STRUCTURE_TYPE.REGISTRATION);
		writer.writeStartElement(registryNs, "StatusMessage");
		writer.writeAttribute("status", "Success");
		writer.writeEndElement();


		for(RegistrationBean registration : registrations) {
			writer.writeStartElement(registryNs, "QueryResult");
			writer.writeAttribute("timeSeriesMatch", "false");  //TODO What is this?
			writer.writeStartElement(registryNs, "DataResult");
			writerEngine.writeMaintainable(registration, null, writer);
			writer.writeEndElement(); //End Data Result
			writer.writeEndElement(); //End Query Result
		}
		writer.writeEndElement(); //End QueryRegistrationResponse
	}
	
	/**
	 * Writes structures, expects the document to have been started and relevant namespaces to have been added
	 * @param writer
	 * @param beans
	 * @param out
	 */
	private void writeStructures(StaxWriter writer, SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks) {
		Set<CodelistBean> codelists = beans.getCodelists();
		//Maintain order by using a list
		List<CodelistBean> standardCodelists = codelists.size() > 0 ? new ArrayList<>(codelists.size()) : Collections.emptyList();
		List<IGeographicCodelistBean> geographicalCodelists = codelists.size() > 0 ? new ArrayList<>(): Collections.emptyList();
		List<IGeoGridCodelistBean> geoCodelists = codelists.size() > 0 ? new ArrayList<>(): Collections.emptyList();
		if(ObjectUtil.validCollection(codelists)) {
			for(CodelistBean cl : codelists) {
				if(cl.isGeoCodelist()) {
					if(cl instanceof IGeographicCodelistBean) {
						geographicalCodelists.add((IGeographicCodelistBean)cl);
					} else if(cl instanceof IGeoGridCodelistBean) {
						geoCodelists.add((IGeoGridCodelistBean)cl);
					}
				} else {
					standardCodelists.add(cl);
				}
			}
		}
		
		writeStructures(writer, "AgencySchemes", beans, SDMX_STRUCTURE_TYPE.AGENCY_SCHEME, additionalLinks);
		writeStructures(writer, "Categorisations", beans, SDMX_STRUCTURE_TYPE.CATEGORISATION, additionalLinks);
		//CategorySchemeMaps
		writeStructures(writer, "CategorySchemes", beans, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME, additionalLinks);
		writeStructures(writer, "Codelists", standardCodelists, StaxCodelistWriterEngineV3.getInstance(), additionalLinks);
		//ConceptSchemeMaps
		writeStructures(writer, "ConceptSchemes", beans, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, additionalLinks);
		writeStructures(writer, "CustomTypeSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME, additionalLinks);
		writeStructures(writer, "DataConstraints", beans, SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT, additionalLinks);
		writeStructures(writer, "DataConsumerSchemes", beans, SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME, additionalLinks);
		writeStructures(writer, "Dataflows", beans, SDMX_STRUCTURE_TYPE.DATAFLOW, additionalLinks);
		writeStructures(writer, "DataProviderSchemes", beans, SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME, additionalLinks);
		writeStructures(writer, "DataStructures", beans, SDMX_STRUCTURE_TYPE.DSD, additionalLinks);
		writeStructures(writer, "GeographicCodelists", geographicalCodelists, StaxGeographicCodelistWriterEngineV3.getInstance(), additionalLinks);
		writeStructures(writer, "GeoGridCodelists", geoCodelists, StaxGeoCodelistWriterEngineV3.getInstance(), additionalLinks);  //TODO Other writers
		writeStructures(writer, "Hierarchies", beans, SDMX_STRUCTURE_TYPE.HIERARCHY, additionalLinks);
		writeStructures(writer, "HierarchyAssociations", beans, SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION, additionalLinks);
		//MetadataConstraints
		writeStructures(writer, "Metadataflows", beans, SDMX_STRUCTURE_TYPE.METADATA_FLOW, additionalLinks);
		writeStructures(writer, "MetadataProviderSchemes", beans, SDMX_STRUCTURE_TYPE.METADATA_PROVIDER_SCHEME, additionalLinks);
		writeStructures(writer, "MetadataProvisionAgreements", beans, SDMX_STRUCTURE_TYPE.METADATA_PROVISION, additionalLinks);
		writeStructures(writer, "MetadataStructures", beans, SDMX_STRUCTURE_TYPE.MSD, additionalLinks);
		writeStructures(writer, "NamePersonalisationSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME, additionalLinks);
		//OrganisationSchemeMaps
		writeStructures(writer, "OrganisationUnitSchemes", beans, SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME, additionalLinks);
		writeStructures(writer, "Processes", beans, SDMX_STRUCTURE_TYPE.PROCESS, additionalLinks);
		writeStructures(writer, "ProvisionAgreements", beans, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, additionalLinks);
		writeStructures(writer, "ReportingTaxonomies", beans, SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY, additionalLinks);
		//ReportingTaxonomyMaps
		writeStructures(writer, "RepresentationMaps", beans, SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP, additionalLinks);
		writeStructures(writer, "RulesetSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME, additionalLinks);
		writeStructures(writer, "StructureMaps", beans, SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, additionalLinks);
		writeStructures(writer, "TransformationSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME, additionalLinks);
		writeStructures(writer, "UserDefinedOperatorSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME, additionalLinks);
		
		writeStructures(writer, "ValueLists", beans, SDMX_STRUCTURE_TYPE.VALUE_LIST, additionalLinks);
		writeStructures(writer, "VtlMappingSchemes", beans, SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME, additionalLinks);
	}

	private String getSchemaLocation() {
		String messageSchema = messageNs.getNamespaceURL();
		String schemaName = SdmxConstants.getSchemaName(messageSchema);
		if(schemaLocationManager != null) {
			return messageSchema + " " + schemaLocationManager.getSchemaLocation(ouputVersion) + schemaName;
		}
		return null;
	}

	protected void writeStructuresInternal(StaxWriter writer, SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, OutputStream out) {
		writer.startDocument(messageNs, "Structure");
		writeHeader(writer, beans, true);
		writer.writeStartElement(messageNs, "Structures");
		writeStructures(writer, beans, additionalLinks);
	}
	
	protected void writeHeader(StaxWriter writer, SdmxBeans beans, boolean includeReceiver) {
		HeaderBean header = beans.getHeader();
		if(header == null && headerRetrievalManager != null) {
			header = headerRetrievalManager.getHeader();
		}
		if(header == null) {
			header = new HeaderBeanImpl("ZZZ");
		}
		if(beans.getHeader() == null && beans.getAction() != null) {
			header.setAction(beans.getAction());
		}
		StaxHeaderWriterUtil.writeHeader(writer, messageNs, header, includeReceiver, false);
	}

	private void writeStructures(StaxWriter writer, String startNode, SdmxBeans beans, SDMX_STRUCTURE_TYPE structureType, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks) {
		StaxMaintainableWriterEngine<MaintainableBean> writerEngine = getWriterEngine(structureType);
		writeStructures(writer, startNode, beans.getMaintainables(structureType), writerEngine, additionalLinks);
	}
	
	@SuppressWarnings("unchecked")
	private void writeStructures(StaxWriter writer, String startNode, Collection<? extends MaintainableBean> maints, StaxMaintainableWriterEngine writerEngine, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks) {
		if(additionalLinks == null) {
			additionalLinks = Collections.emptyMap();
		}
		if(writerEngine != null && ObjectUtil.validCollection(maints)) {
			writer.writeStartElement(structureNs, startNode);
			for(MaintainableBean maint : maints) {
				/*if (structureType == SDMX_STRUCTURE_TYPE.CODE_LIST) {
					maint = ItemValidityPeriodHelper.potentiallyMutateIt((CodelistBean)maint);
				} else if (structureType == SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME) {
					maint = ItemValidityPeriodHelper.potentiallyMutateIt((ConceptSchemeBean)maint);
				}*/
				if (maint instanceof ValidatableBean) {
					maint = ItemValidityPeriodHelper.potentiallyMutateIt((ValidatableBean<?>) maint);
				}
				writerEngine.writeMaintainable(maint, additionalLinks.get(maint.getURN()), writer);
			}
			writer.writeEndElement();
		}
	}
	
	@Override
	public boolean isSupportedType(MaintainableBean structure) {
		if(structure.getDefaultStandard() != SDMXMetadataStandard.getInstance()) {
			return false;
		}

		return super.isSupportedType(structure) && structure.isCompatible(this.ouputVersion);
	}


	protected StaxMaintainableWriterEngine<MaintainableBean> getWriterEngine(SDMX_STRUCTURE_TYPE structureType) {
		StaxMaintainableWriterEngine<MaintainableBean> writerEngine = writerEngines.get(structureType);
		if(writerEngine == null) {
			throw new SdmxNotImplementedException("No support for writing structure '"+structureType.getType()+"' in version '"+this.ouputVersion+"'");
		}
		return writerEngine;
	}

}
