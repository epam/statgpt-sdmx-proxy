package io.sdmx.format.ml.engine.structure.writer.v3.notification;

import java.io.OutputStream;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v21.StaxStructureWriterEngineV21;
import io.sdmx.format.ml.engine.structure.writer.v21.registration.StaxRegistrationWriterEngineV21;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class SdmxNotificationEventWriterEngine implements IFusionSingleton {
	private static SdmxNotificationEventWriterEngine INSTANCE;

	private SchemaLocationManager schemaLocationManager;
	private StaxRegistrationWriterEngineV21 registrationWriterEngineV21 = StaxRegistrationWriterEngineV21.getInstance();
	private StaxStructureWriterEngineV21 staxStructureWriterEngineV21 = StaxStructureWriterEngineV21.getInstance();

	public static SdmxNotificationEventWriterEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxNotificationEventWriterEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxNotificationEventWriterEngine() {}

	public void writeSdmxNotification(RegistrationBean registration, DATASET_ACTION action, String subscriptionURN, OutputStream out) {
		StaxWriter writer = startDocument(out, subscriptionURN, action);
		writer.writeElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "RegistrationID", registration.getId());
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "RegistrationEvent");
		registrationWriterEngineV21.writeMaintainable(registration, writer);
		writer.close();
	}

	public void writeSdmxNotification(SdmxBeans beans, DATASET_ACTION action, String subscriptionURN, OutputStream out) {
		StaxWriter writer = startDocument(out, subscriptionURN, action);
		String urn  = ((MaintainableBean)beans.getAllMaintainables().toArray()[0]).getUrn();
		writer.writeElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "ObjectURN", urn);
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "StructureEvent");
		staxStructureWriterEngineV21.writeStructures(writer, beans);
		writer.close();
	}

	private SchemaLocationManager getSchemaLocationMamanger() {
	    if (schemaLocationManager == null) {
	        schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, true);
	    }
	    return schemaLocationManager;
	}

	private StaxWriter startDocument(OutputStream out, String subscriptionURN, DATASET_ACTION action) {
		String schemaLocation = getSchemaLocationMamanger().getSchemaLocation(SDMX_SCHEMA.VERSION_TWO_POINT_ONE);

		StaxWriter writer = new StaxWriter(out, schemaLocation, true,
				SDMX_NAMESPACE.MESSAGE_21.getNamespace(),
				SDMX_NAMESPACE.COMMON_21.getNamespace(),
				SDMX_NAMESPACE.STRUCTURE_21.getNamespace(),
				SDMX_NAMESPACE.REGISTRY_21.getNamespace());

		writer.startDocument(SDMX_NAMESPACE.MESSAGE_21.getNamespace(), "RegistryInterface");
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "NotifyRegistryEvent");
		writer.writeElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "EventTime", DateUtil.getDateTimeStringNow());
		writer.writeElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "SubscriptionURN", subscriptionURN);
		writer.writeElement(SDMX_NAMESPACE.REGISTRY_21.getNamespace(), "EventAction", action.getAction());

		return writer;
	}
}
