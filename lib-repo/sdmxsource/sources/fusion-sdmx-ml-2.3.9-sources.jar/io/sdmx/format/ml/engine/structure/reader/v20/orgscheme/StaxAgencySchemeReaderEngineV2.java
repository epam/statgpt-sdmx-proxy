package io.sdmx.format.ml.engine.structure.reader.v20.orgscheme;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.AgencyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AgencySchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.im.mutable.base.AgencyMutableBeanImpl;
import io.sdmx.im.mutable.base.AgencySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * In SDMX 2.0, AgencyBeans, DataConsumers and DataProviders are all under "OrganisationScheme"
 * Simply process each type in this class
 */
public class StaxAgencySchemeReaderEngineV2 extends StraxAbstractOrganisationReaderEngineV2 {
    private static StaxAgencySchemeReaderEngineV2 INSTANCE;

    //Private constructor - lazy load instance
    private StaxAgencySchemeReaderEngineV2() {}

    public static StaxAgencySchemeReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxAgencySchemeReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public AgencySchemeMutableBean processMaintainable(IStaxReader reader) {
        AgencySchemeMutableBean bean = new AgencySchemeMutableBeanImpl();

        List<AgencyMutableBean> agencies = processAgencies(reader);
        for (AgencyMutableBean agencyMutableBean : agencies) {
            bean.addItem(agencyMutableBean);
        }
        return bean;
    }

    private List<AgencyMutableBean> processAgencies(IStaxReader reader) {
        List<AgencyMutableBean> retSet = new ArrayList<>();
        reader.moveNextNode();

        do {
            AgencyMutableBean agency = new AgencyMutableBeanImpl();
            analyseOrganisation(reader, agency );
            retSet.add(agency);
            reader.moveNextNode();
        } while(reader.isStartElement() && reader.getElementName().equals("Agency"));

        return retSet;
    }
}
