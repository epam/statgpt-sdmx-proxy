package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxTextWriterUtil {

	public static void writeTextTypes(Collection<TextTypeWrapper> text, StaxWriter writer, String elementName) {
		writeTextTypes(StaxStructureWriterUtil.COMMON_NS, text, writer, elementName);
	}
	
	public static void writeTextTypes(Namespace ns, Collection<TextTypeWrapper> text, StaxWriter writer, String elementName) {
		if(text != null) {
			for(TextTypeWrapper tt : text) {
				Map<String, String> attributes = new HashMap<>();
				attributes.put("xml:lang", tt.getLocale());
				writer.writeElement(ns, elementName, tt.getValue(), attributes);
			}
		}
	}
}
