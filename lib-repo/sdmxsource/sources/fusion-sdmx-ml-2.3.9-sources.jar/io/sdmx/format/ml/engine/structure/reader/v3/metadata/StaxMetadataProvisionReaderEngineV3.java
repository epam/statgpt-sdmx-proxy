package io.sdmx.format.ml.engine.structure.reader.v3.metadata;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.IMetadataProvisionAgreementMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataProvisionAgreementMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMetadataProvisionReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IMetadataProvisionAgreementMutableBean> {
	private static StaxMetadataProvisionReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataProvisionReaderEngineV3() {}

	public static StaxMetadataProvisionReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataProvisionReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
        return "MetadataProvisionAgreements";
    }
	
    @Override
    protected String getRootNodeName() {
        return "MetadataProvisionAgreement";
    }

    @Override
    protected IMetadataProvisionAgreementMutableBean processMaintainable(IStaxReader reader) {
		IMetadataProvisionAgreementMutableBean provision = new MetadataProvisionAgreementMutableBean();
		StaxMaintainableUtil.processBean(provision, reader);
		
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Metadataflow")) {
				provision.setMetadataflowRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.METADATA_FLOW));
			} else if(nodeName.equals("Target")) {
				provision.addTarget(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.ANY));
			} else if(nodeName.equals("MetadataProvider")) {
				provision.setMetadataProviderRef((StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.METADATA_PROVIDER)));
			}else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return provision;
	}
}
