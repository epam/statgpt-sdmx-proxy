package io.sdmx.format.ml.factory.data;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.core.sdmx.error.DataReadException;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.format.ml.engine.data.reader.CompactDataReaderEngine;
import io.sdmx.format.ml.engine.data.reader.GenericDataReaderEngine;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * The SdmxChainedDataReaderFactory is used to get a DataReaderEngine from a source location.
 * <p/>
 * The SdmxChainedDataReaderFactory will first check any child DataReaderFactory instances that have been provided to ensure that there are not
 * alternative DataReaderEngine for the source data. If there are no child DataReaderFactory's or any child DataReaderFactorys that return the expected DataReaderEngine
 * then the SdmxChainedDataReaderFactory will assume the data is SDMX or EDI.
 */
public class SdmxMLDataReaderFactory implements DataReaderFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMLDataReaderFactory.class);

	private ArrayList<DataErrorCategory> throwableErrors;

	private static SdmxMLDataReaderFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxMLDataReaderFactory() {}

	public static SdmxMLDataReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLDataReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxMLDataReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public DataReaderEngine getDataReaderEngine(DataFormat dataFormat,
												ReadableDataLocation sourceData,
												DataStructureBean dsd,
												DataflowBean dataflowBean,
												ProvisionAgreementBean provisionAgreement,
												DataValidationErrorHandler exceptionHandler) {
		if(dataFormat instanceof SdmxDataFormat) {
			SdmxDataFormat sdmxDataFormat = (SdmxDataFormat) dataFormat;
			DataReaderExceptionHandler readerEx = getDataReaderExceptionHandler(exceptionHandler);
			switch(sdmxDataFormat.getSdmxDataFormat().getBaseDataFormat()) {
				case COMPACT : return new CompactDataReaderEngine(sourceData, dsd, dataflowBean, provisionAgreement, readerEx);
				case GENERIC : return new GenericDataReaderEngine(sourceData, dsd, dataflowBean, provisionAgreement, readerEx);
			}
		}
		return null;
	}

	@Override
	public DataReaderEngine getDataReaderEngine(DataFormat dataFormat,
												ReadableDataLocation sourceData,
												SdmxBeanRetrievalManager retrievalManager,
												DataValidationErrorHandler exceptionHandler) {
		if(dataFormat instanceof SdmxDataFormat) {
			SdmxDataFormat sdmxDataFormat = (SdmxDataFormat) dataFormat;
			DataReaderExceptionHandler readerEx = getDataReaderExceptionHandler(exceptionHandler);
			switch(sdmxDataFormat.getSdmxDataFormat().getBaseDataFormat()) {
				case COMPACT : return new CompactDataReaderEngine(sourceData, retrievalManager, null, null, null, readerEx);
				case GENERIC : return new GenericDataReaderEngine(sourceData, retrievalManager, null, null, null, readerEx);
			}
		}
		return null;
	}

	@Override
	public String getOverride() {
		return null;
	}

	@Override
	public List<DataErrorCategory> getThrowableErrors() {
		if (throwableErrors == null) {
			throwableErrors = new ArrayList<>();

			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.ADDED_HEADER_ELEMNET, "Unexpected Header Element", "An unexpected XML Node is in the SDMX Header.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.HEADER_ELEMENT_ORDER, "Incorrect Header Element Order", "The order of the XML Elements in the SDMX Header does not match the required order.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.HEADER_ELEMENT_DUPLICATE, "Duplicate Header Element", "The same element in the SDMX Header has been reported twice.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.MISSING_HEADER_ELEMENT, "Missing Header Element", "A required SDMX Header element is not present.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.CASE_SENSITVE, "Header Text Incorrect Case", "The reported SDMX Header value is in the wrong case (example Test=TRUE vs Test=true).") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INVALID_HEADER_CONTENT, "Invalid Content in Header", "The content of a reported SDMX Header value contains invalid content.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INVALID_ID_SYNTAX, "Invalid Header Id Syntax", "The Id of the Header does not match the expected syntax.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INVALID_DATE, "Invalid Header Date Syntax", "The Date syntax reported in the Header does not match the expected syntax.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INVALID_SENDER_RECIEVER, "Invalid Sender / Receiver", "The Reported Sender or Receiver Id does not match the expected syntax.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.INVALILD_ACTION, "Invalid Action in Header", "The reported dataset action in the Header does not match any known actions.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.ADDED_ATTRIBUTE, "Unexpected Attribute", "An XML Attribute has been reported which does not match any expected attributes.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.ADDED_ELEMNET, "Unexpected XML Element", "An XML element has been added into the dataset which does not match any expected elements.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.NAMESPACE, "Incorrect Namespace", "The namespace reported is unexpected.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.MISSING_XML_ATTRIBUTE, "Missing XML Attribute", "An XML Attribute was expected to be found but was not present.") );
			throwableErrors.add( new DataErrorCategory(this, DataReadException.TYPE.STRUCUTRE_REF_INCONSISTENT_WITH_HEADER, "Invalid Data Structure Reference", "The reference to the Data Structure, Dataflow, or Provision Agreement does not conform to the correct syntax.") );
		}

		return throwableErrors;
	}

	@Override
	public String getId() {
		return "SDMX-ML";
	}

	@Override
	public String getName() {
		return "SDMX-ML";
	}
}