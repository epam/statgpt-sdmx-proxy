package io.sdmx.format.ml.engine.structure.reader.v20.codelist;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCodelistReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<CodelistMutableBean> {
	private static StaxCodelistReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistReaderEngineV2() {}
	public static StaxCodelistReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    public String getContainerNodeName() {
        return "CodeLists";
    }
    
    @Override
    protected String getRootNodeName() {
        return "CodeList";
    }

    @Override
    protected CodelistMutableBean processMaintainable(IStaxReader reader) {
		CodelistMutableBean maint = new CodelistMutableBeanImpl();
		StaxItemSchemeUtil.processBean(maint, reader);

		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("Code") &&
			    !reader.getElementName().equals("Annotations")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}

			CodeMutableBean aCode = processCode(reader);
			maint.addItem(aCode);
			reader.moveNextNode();
			if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
            }
			ValidityPeriodUtil.processValidityAnnotations(maint);
		}
		return maint;
	}

	private CodeMutableBean processCode(IStaxReader reader) {
		CodeMutableBean code = new CodeMutableBeanImpl();

		Map<String, String> attributes = reader.getAttributes();
		code.setId(StaxStructureUtil.getAttribute(attributes, "value", false));  //Id may not be mandatory for an identifiable that inherits it from a concept if not provided
		code.setUri(StaxStructureUtil.getAttribute(attributes, "uri", false));
		code.setParentCode(StaxStructureUtil.getAttribute(attributes, "parentCode", false));
		StaxAnnotableUtil.processBean(code, reader);

		while(StaxNameableUtil.processNode(code, reader)) {
            //Processing Nodes - convert the descriptions to names
            List<TextTypeWrapperMutableBean> descriptions = code.getDescriptions();
            for (TextTypeWrapperMutableBean textTypeWrapperMutableBean : descriptions) {
                code.addName(textTypeWrapperMutableBean);
            }
            code.setDescriptions(null);

            reader.moveNextNode();
            // In SDMX 2.0 Annotations come at the end of a Code
            if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(code, reader);
                reader.moveNextNode(); //Move to the start/end of the next node
            }
        }
		return code;
	}
}
