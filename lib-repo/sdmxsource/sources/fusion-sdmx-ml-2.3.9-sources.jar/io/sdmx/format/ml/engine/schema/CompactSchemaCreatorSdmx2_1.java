package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import javax.xml.stream.XMLStreamException;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Generates a Compact Schema for SDMX 2.1
 */
public class CompactSchemaCreatorSdmx2_1 extends CompactSchemaCreator {
	
	private static final Logger LOG = LoggerFactory.getLogger(CompactSchemaCreatorSdmx2_1.class);

	public CompactSchemaCreatorSdmx2_1(ConstrainedCodes constrainedCodes, String dimensionAtObservation, String schemaLocation, OutputStream out, boolean prettyPrint) {
		super(constrainedCodes, dimensionAtObservation, schemaLocation, out, prettyPrint);
	}
	
	@Override
	public void createSchema() {
		LOG.info("Generating Schema: SDMX 2.1 " + (generatingCrossSectional ? " - cross sectional" : "") );
		super.createSchema();
	}
	
	@Override
	protected void writeSchemaInformation() {
		String namespaceId;
		if(generatingAllDimensions) {
			namespaceId = "AllDimensions";
		} else if (generatingCrossSectional) {
			// The targetNamespace will be the URN of the cross-sectional dimension
			// FIX SLi According to the standard this should be dsd urn followed by the ObsLevelDim and cross dimension id. 
			namespaceId = crossSectionDimension.getId();
		} else {
			DimensionSuperBean timeDimensionBean = dsd.getTimeDimension();
			if (timeDimensionBean == null) {
				namespaceId = PrimaryMeasureBean.FIXED_ID;
			} else {
				namespaceId = timeDimensionBean.getId();
			}
		}
		targetNamespace = srb.getTargetUrn() + ":ObsLevelDim:" + namespaceId;
		init(out, COMPACT, targetNamespace, SDMX_SCHEMA.VERSION_TWO_POINT_ONE, dsd);
	}
	
	@Override
	protected void writeDataset() throws Exception {
		addElement("DataSet",  "DataSetType",  "compact:DataSet");

		if(generatingAllDimensions || generatingCrossSectional) {
		    addComplexContentRoot("DataSetType", "DataSetType");
		} else {
		    addComplexContentRoot("DataSetType", "TimeSeriesDataSetType");
		}

		writer.writeStartElement(SCHEMA_NS, "sequence");
		addAnnotations();

		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "DataProvider");
		writer.writeAttribute("type", "common:DataProviderReferenceType");
		writer.writeAttribute("form", "unqualified");
		writer.writeAttribute("minOccurs", "0");
		writer.writeEndElement();  // End DataProvider
		
		// Add each group
		for(GroupSuperBean currentGroup : dsd.getGroups()) {
			// Write a group element
			writer.writeStartElement(SCHEMA_NS, "element");
			writer.writeAttribute("name", "Group");
			writer.writeAttribute("type", currentGroup.getId());  //FMR11-140 Do not include Type postfix on Group element
			writer.writeAttribute("form", "unqualified");
			writer.writeAttribute("minOccurs", "0");
			writer.writeAttribute("maxOccurs", "unbounded");
			writer.writeEndElement();	
		}

		// Add a choice with only a MinOccurs
		writer.writeStartElement(SCHEMA_NS, "choice");
		writer.writeAttribute("minOccurs", "0");

		if (generatingAllDimensions) {
		    // Write an Observation element
            writer.writeStartElement(SCHEMA_NS, "element");
            writer.writeAttribute("name", "Obs");
            writer.writeAttribute("type", "ObsType");
            writer.writeAttribute("form", "unqualified");
            writer.writeAttribute("maxOccurs", "unbounded");
            writer.writeEndElement();
		} else {
    		// Write a Series element
		    writer.writeStartElement(SCHEMA_NS, "element");
            writer.writeAttribute("name", "Series");
            writer.writeAttribute("type", "SeriesType");
            writer.writeAttribute("form", "unqualified");
            writer.writeAttribute("maxOccurs", "unbounded");
            writer.writeEndElement();
		}

		writer.writeEndElement();  // End Choice
		writer.writeEndElement();  // End Sequence

		for (AttributeSuperBean bean : dsd.getDatasetAttributes()) {
			addAttributeBean(bean);
		}

		writeReportingYearStartDay();
		endComplexType(writer);
	}
	
	@Override
	protected void writeGroups() throws Exception {
		for (GroupSuperBean currentGroup : dsd.getGroups()) {
			addComplexTypeForRestriction(currentGroup.getId(), "dsd:GroupType");

			writer.writeStartElement(SCHEMA_NS, "sequence");  // Start Sequence
			addAnnotations();
			writer.writeEndElement();	                      // End Sequence

			writeGroupAttributes(currentGroup);
			writeReportingYearStartDay();
			endComplexType(writer);
		}
	}

	@Override
	protected void writeSeries() throws Exception {
		if(generatingAllDimensions) {
			//All Dimensions are at the observation level
			return;
		}

		addComplexContentRoot("SeriesType", "TimeSeriesType");

		writer.writeStartElement(SCHEMA_NS, "sequence");     // Start Sequence

		addAnnotations();
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Obs");
		writer.writeAttribute("type", "ObsType");
		writer.writeAttribute("form", "unqualified");
		writer.writeAttribute("minOccurs", "0");
		writer.writeAttribute("maxOccurs", "unbounded");
		writer.writeEndElement();

		writer.writeEndElement();                            // End Sequence

		if (generatingCrossSectional) {
			for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
				if(!bean.getId().equals(crossSectionDimension.getId())) {
					addRequiredDimensionBean(bean);
				}
			}
		} else {
			for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION) ) {
				addRequiredDimensionBean(bean);
			}
		}

		for(AttributeSuperBean bean : dsd.getSeriesAttributes()) {
			addComponentBean(bean);	
			writer.writeAttribute("use", "optional");
			writer.writeEndElement();
		}
		writeReportingYearStartDay();

		endComplexType(writer);
	}
	
	@Override
	protected void writeObservations() throws Exception {
	    if(generatingAllDimensions || generatingCrossSectional) {
	        addComplexContentRoot("ObsType", "ObsType");
	    } else {
	        addComplexContentRoot("ObsType", "TimeSeriesObsType");
	    }

		writer.writeStartElement(SCHEMA_NS, "sequence");   // Start Sequence
		addAnnotations();
		writer.writeEndElement();	                       // End Sequence

		// If Cross-Sectional add the dimension now
		if (generatingCrossSectional) {
			addRequiredDimensionBean(crossSectionDimension);
		} else if(generatingAllDimensions) {
			for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION) ) {
				addRequiredDimensionBean(bean);
			}
		}
		
		if(dsd.getMeasure(PrimaryMeasureBean.FIXED_ID) != null) {
			addOptionalDimensionBean(dsd.getMeasure(PrimaryMeasureBean.FIXED_ID));
		}

		for(AttributeSuperBean bean : dsd.getObservationAttributes()) {
			addComponentBean(bean);		
			writer.writeAttribute("use", "optional");
			writer.writeEndElement();
		}

		// If Cross-Sectional add the time dimension
		if (generatingCrossSectional) {
			if(dsd.getTimeDimension() != null) {
				addProhibitedDimensionBean(dsd.getTimeDimension());
			}
		}
		
		writeReportingYearStartDay();

		endComplexType(writer);
	}
	
	@Override
	protected void addComplexContentRoot(String type, String type_2_1) throws Exception {
		String complexType;
		if (generatingCrossSectional) {
			complexType = type;
		} else {
			complexType = type_2_1;
		}
		addComplexTypeForRestriction(type, "dsd:" + complexType);
	}
	
	@Override
	void addElement(String name, String type, String substitutionGroup) throws XMLStreamException {
		super.addElement(name,type,null);
	}
	
	@Override
	void addComponentBean(ComponentSuperBean componentBean) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "attribute");
		writer.writeAttribute("name", componentBean.getId());
		if(componentBean.getBuiltFrom().getStructureType() == SDMX_STRUCTURE_TYPE.TIME_DIMENSION) {
			writeTimePeriodType();
		} else if(componentBean.getCodelist(true) == null) {
			TextFormatBean textFormat = componentBean.getTextFormat();
			if (textFormat == null) {
				writer.writeAttribute("type", "xs:string");
			} else if (textFormat.hasRestrictions()) {
				writer.writeAttribute("type", componentBean.getId());
			} else {
				TEXT_TYPE textType = textFormat.getTextType();
				writer.writeAttribute("type", determineSchemaType(textFormat, textType) );
			}
		} else {
		    writer.writeAttribute("type", getCodelistReference(componentBean));
        }
	}
	
	@Override
	void addAnnotations() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("ref", "common:Annotations");
		writer.writeAttribute("minOccurs", "0");	
		writer.writeEndElement();	
	}
	
	private void writeReportingYearStartDay() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "attribute");
		writer.writeAttribute("name", "REPORTING_YEAR_START_DAY");
		writer.writeAttribute("type", "xs:gMonthDay");
		writer.writeAttribute("use", "prohibited");
		writer.writeEndElement();
	}
}