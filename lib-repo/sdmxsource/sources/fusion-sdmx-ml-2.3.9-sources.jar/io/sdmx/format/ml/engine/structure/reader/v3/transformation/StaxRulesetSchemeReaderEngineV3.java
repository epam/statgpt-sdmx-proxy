package io.sdmx.format.ml.engine.structure.reader.v3.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IRulesetSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.RulesetMutableBean;
import io.sdmx.im.mutable.transformation.RulesetSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxRulesetSchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IRulesetSchemeMutableBean> implements IFusionSingleton {
	private static StaxRulesetSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRulesetSchemeReaderEngineV3() {}

	public static StaxRulesetSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRulesetSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "RulesetSchemes";
	}
	
	@Override
	protected String getRootNodeName() {
		return "RulesetScheme";
	}

	@Override
	protected IRulesetSchemeMutableBean processMaintainable(IStaxReader reader) {
		IRulesetSchemeMutableBean maint = new RulesetSchemeMutableBean();
		maint.setVtlVersion(reader.getAttributeValue(null, "vtlVersion"));
		StaxItemSchemeUtil.processBean(maint, reader);
		while(reader.isStartElement()) {
			switch(reader.getElementName()) {
			case "Ruleset" :
				IRulesetMutableBean item = readItem(reader);
				maint.addItem(item);
				break;
			case "VtlMappingScheme" :
				maint.setVtlMappingSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
				break;
			default :
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return maint;
	}

	private IRulesetMutableBean readItem(IStaxReader reader) {
		IRulesetMutableBean item = new RulesetMutableBean();
		item.setRulesetType(reader.getAttributeValue("rulesetType"));
		item.setRulesetScope(reader.getAttributeValue("rulesetScope"));
		StaxNameableUtil.processBean(item, reader);
		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "RulesetDefinition" :
					item.setRulesetDefinition(reader.getElementText());
					break;
				}
			} else if(reader.getElementName().equals("Ruleset")) {
				break;
			}
		} while(reader.moveNextNode());
		return item;
	}
}
