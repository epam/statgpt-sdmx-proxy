package io.sdmx.format.ml.engine.structure.writer.v21.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.DataConsumerBean;
import io.sdmx.api.sdmx.model.beans.base.DataConsumerSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataConsumerSchemeWriterEngineV21 extends StaxAbstractOrganisationSchemeWriterEngine<DataConsumerSchemeBean, DataConsumerBean> implements IFusionSingleton {
	private static StaxDataConsumerSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataConsumerSchemeWriterEngineV21() {}

	public static StaxDataConsumerSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataConsumerSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "DataConsumerScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "DataConsumer";
	}


}
