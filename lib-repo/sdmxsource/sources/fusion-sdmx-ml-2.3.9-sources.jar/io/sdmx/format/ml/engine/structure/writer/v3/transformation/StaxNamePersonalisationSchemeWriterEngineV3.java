package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationBean;
import io.sdmx.api.sdmx.model.beans.transformation.INamePersonalisationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxNamePersonalisationSchemeWriterEngineV3 extends StaxAbstractVTLSchemeWriterEngineV3<INamePersonalisationSchemeBean> implements IFusionSingleton {
	private static StaxNamePersonalisationSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxNamePersonalisationSchemeWriterEngineV3() {}

	public static StaxNamePersonalisationSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxNamePersonalisationSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "NamePersonalisationScheme";
	}
	@Override
	protected void writeMaintainableInternal(INamePersonalisationSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
	}

	private void writeItems(List<INamePersonalisationBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(INamePersonalisationBean item : items) {
			StaxNameableWriterUtilV3.writeBean(item, "NamePersonalisation", externalLinks, writer, CollectionUtil.buildMapValues("vtlArtefact "+item.getVtlArtefact()));
			if(item.getVtlDefaultName() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlDefaultName", item.getVtlDefaultName());
			}
			if(item.getPersonalisedName() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "PersonalisedName", item.getPersonalisedName());
			}
			writer.writeEndElement();
		}
	}
}
