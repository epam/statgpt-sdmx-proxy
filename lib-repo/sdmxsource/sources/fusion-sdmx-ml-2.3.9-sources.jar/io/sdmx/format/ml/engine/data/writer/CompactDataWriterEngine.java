package io.sdmx.format.ml.engine.data.writer;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class CompactDataWriterEngine extends SdmxDataWriterEngine {
	private static final Logger LOG = LoggerFactory.getLogger(CompactDataWriterEngine.class);

	private Map<String, String> componentVals = new HashMap<>();
	private String primaryMeasureConcept;
	private String timeConcept;

	public CompactDataWriterEngine(SDMX_SCHEMA schemaVersion,  OutputStream out, boolean prettyPrint) {
		super(schemaVersion, BASE_DATA_FORMAT.COMPACT, out, prettyPrint);
	}

	@Override
	public void startDataset(ProvisionAgreementBean provision, DataflowBean dataflow, DataStructureBean dsd, DatasetHeaderBean header, AnnotationBean... annotations) {
		super.startDataset(provision, dataflow, dsd, header);

		if (dsd.getPrimaryMeasure() != null) {
            this.primaryMeasureConcept = getComponentId(dsd.getPrimaryMeasure());
        } else {
            List<MeasureDimensionBean> measures = dsd.getMeasures();
            if (measures.size() == 0) {
                throw new SdmxSemmanticException("Unable to read since no measure dimension");
            } else {
                this.primaryMeasureConcept = getComponentId(measures.get(0));
            }
        }

		this.timeConcept = getComponentId(dsd.getTimeDimension());
		if(isTwoPointOne() || isThreePointZero()) {
			writeAnnotations(writer, annotations);
		} else {
			if(this.isCrossSectional) {
				throw new SdmxSemmanticException("A 2.0 Compact Dataset must contain Time at the observation level.");
			}
			datasetAnnotations = annotations;
		}
	}

	@Override
	public void startGroup(String groupId, AnnotationBean... annotations) {
		super.startGroup(groupId);
		try {
			if(currentPosition != null) {
				//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
				switch(currentPosition) {
				case OBSERVATION :
					writeEndObs();
					writeEndSeries();
					break;
				case OBSERVATION_ATTRIBUTE :
					writeEndObs();
					writeEndSeries();
					break;
				case COMP_KEY:
					writeEndComp();
					if(positionBeforeComp == POSITION.OBSERVATION || positionBeforeComp == POSITION.OBSERVATION_ATTRIBUTE){
						writeEndObs();
					}
					if(positionBeforeComp != POSITION.DATASET){
						writeEndSeries();
					}
					break;
				case SERIES_KEY_ATTRIBUTE :
					writeEndSeries();
					break;
				case SERIES_KEY :
					writeEndSeries();
					break;
				case GROUP :
					writeEndGroup();
					break;
				case GROUP_KEY_ATTRIBUTE :
					writeEndGroup();
					break;
				}
			}
			if(isTwoPointOne() || isThreePointZero()) {
				writer.writeStartElement("Group");      //WRITE THE START GROUP
				writer.writeAttribute(XSI_NS, "type", COMPACT_NS.namespacePrefix + ":" + groupId);
				writeAnnotations(writer, annotations);
			} else {
				groupAnnotations = annotations;
				writer.writeStartElement(COMPACT_NS.namespacePrefix, groupId, COMPACT_NS.namespaceURL);      //WRITE THE START GROUP
			}
			currentPosition = POSITION.GROUP;
		} catch(XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	protected void closeGroupWriter() throws Exception {
		if(currentPosition != null) {
			//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
			switch(currentPosition) {
			case GROUP :
				writeEndGroup();
				break;
			case GROUP_KEY_ATTRIBUTE :
				writeEndGroup();
				break;
			}
		}
		writer.flush();
	}

	@Override
	public void writeGroupKeyValue(String conceptId, String conceptValue) {
		conceptId = getComponentId(conceptId);
		super.writeGroupKeyValue(conceptId, conceptValue);
		try {
			if(currentPosition != POSITION.GROUP) {
				throw new IllegalArgumentException("startGroup must be called before calling writeGroupKeyValue");
			}
			writer.writeAttribute(conceptId, conceptValue);
		} catch (XMLStreamException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}


	@Override
	public void startSeries(AnnotationBean... annotations) {
		super.startSeries();
		if(isFlat) {
			componentVals = new HashMap<>();
			try {
			if(currentPosition != null) {
					//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
					switch(currentPosition) {
					case OBSERVATION :
					case OBSERVATION_ATTRIBUTE :
						writeEndObs();
						break;
					case COMP_KEY:
						writeEndComp();
						if(positionBeforeComp == POSITION.OBSERVATION || positionBeforeComp == POSITION.OBSERVATION_ATTRIBUTE){
							writeEndObs();
						}
						writeEndSeries();
						break;
					case SERIES_KEY_ATTRIBUTE :
					case SERIES_KEY :
						//DO NOTHING
						break;
					case GROUP :
					case GROUP_KEY_ATTRIBUTE :
						writeEndGroup();
						break;
					}
				}
			} catch(XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
			currentPosition = POSITION.SERIES_KEY;
		} else {
				try {
					if(currentPosition != null) {
						//WE HAVE NOT YET WRITTEN ANYTHING, CHECK WHERE WE ARE AND CLOSE OFF NODES
						switch(currentPosition) {
						case OBSERVATION :
							writeEndObs();
							writeEndSeries();
							break;
						case OBSERVATION_ATTRIBUTE :
							writeEndObs();
							writeEndSeries();
							break;
						case COMP_KEY:
							writeEndComp();
							if(positionBeforeComp == POSITION.OBSERVATION || positionBeforeComp == POSITION.OBSERVATION_ATTRIBUTE){
								writeEndObs();
							}
							writeEndSeries();
							break;
						case SERIES_KEY_ATTRIBUTE :
							writeEndSeries();
							break;
						case SERIES_KEY :
							writeEndSeries();
							break;
						case GROUP :
							writeEndGroup();
							break;
						case GROUP_KEY_ATTRIBUTE :
							writeEndGroup();
							break;
						}
					}
					seriesAnnotations = annotations;
					if(isTwoPointOne() || isThreePointZero()) {
						if(isFlat) {
							seriesWriter.writeStartElement("Obs");  //WRITE THE START SERIES (WHICH IN THIS CASE IS AN OBS AS IT IS A FLAT DATASET)
						} else {
							seriesWriter.writeStartElement("Series");  //WRITE THE START SERIES
						}
					} else {
						startElement(seriesWriter, COMPACT_NS, "Series");  //WRITE THE START SERIES
					}
					currentPosition = POSITION.SERIES_KEY;
				} catch(XMLStreamException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			}
		}

		@Override
		protected void writeEndSeries() throws XMLStreamException {
			//IF THE VERSION IS 2.1 OR 3.0 AND THE CURRENT POSITION IS THE SERIES, THEN OUTPUT ANY ANNOTATIONS ATTACHED TO THE SERIES
			//BEFORE CLOSING IT
			if(isTwoPointOne() || isThreePointZero()) {
				if(currentPosition == POSITION.SERIES_KEY || currentPosition == POSITION.SERIES_KEY_ATTRIBUTE) {
					writeAnnotations(seriesWriter, seriesAnnotations);
					seriesAnnotations = null;
				}
			}
			super.writeEndSeries();
		}


		@Override
		public void writeSeriesKeyValue(String dimensionId, String dimensionValue) {
			if(dimensionId == null) {
				LOG.warn("Ignoring null dimensionId");
				return;
			}
			if(dimensionValue == null) {
				LOG.warn("Ignoring null series key value for dimension: "+dimensionId);
				return;
			}
			dimensionId = getComponentId(dimensionId);
			super.writeSeriesKeyValue(dimensionId, dimensionValue);
			if(isFlat) {
				componentVals.put(dimensionId, dimensionValue);
			} else {
				try {
					if(currentPosition != POSITION.SERIES_KEY) {
						startSeries();
					}
					seriesWriter.writeAttribute(dimensionId, dimensionValue);
				} catch(XMLStreamException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			}
		}



		@Override
		public void writeObservation(String obsConceptId, String obsIdValue, List<KeyValue> measures, AnnotationBean... annotations) {
			if(!isThreePointZero()) {
				checkWriteObs(measures);
			}
			if(DimensionBean.TIME_DIMENSION_FIXED_ID.equals(obsConceptId)) {
				obsConceptId = timeConcept;
			}
			if(obsConceptId != null && obsConceptId.equals(timeConcept)) {
				if (schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE || schemaVersion == SDMX_SCHEMA.VERSION_THREE) {
					obsIdValue = DateUtil.formatDateForSdmxVersion21(obsIdValue);
				} else if (schemaVersion == SDMX_SCHEMA.VERSION_TWO) {
					obsIdValue = DateUtil.formatDateForSdmxVersion2(obsIdValue);
				} else if (schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
					obsIdValue = DateUtil.formatDateForSdmxVersion1(obsIdValue);
				}
			} else {
				obsConceptId = getComponentId(obsConceptId);
			}

			try {
				switch(currentPosition) {
				case OBSERVATION :
					writeEndObs();
					break;
				case OBSERVATION_ATTRIBUTE :
					writeEndObs();
					break;
				case COMP_KEY:
					writeEndComp();
					if(positionBeforeComp == POSITION.OBSERVATION || positionBeforeComp == POSITION.OBSERVATION_ATTRIBUTE){
						writeEndObs();
					}
					break;
				case SERIES_KEY :
				case SERIES_KEY_ATTRIBUTE :
					if(isTwoPointOne() || isThreePointZero()) {
						writeAnnotations(seriesWriter, seriesAnnotations);
						seriesAnnotations = null;
					}
					break;
				default :
					if(!(isTwoPointOne() || isThreePointZero())) {
						throw new IllegalArgumentException("An observation may only be written while inside a series");
					}
				}
				obsAnnotations = annotations;  //STORE THE ANNOTATIONS

				currentPosition = POSITION.OBSERVATION;
				if(isTwoPointOne() || isThreePointZero()) {
					seriesWriter.writeStartElement("Obs");  //WRITE THE OBS NODE
				} else {
					startElement(seriesWriter, COMPACT_NS, "Obs");  //WRITE THE OBS NODE
				}

				if(isFlat) {
					for(String key : componentVals.keySet()) {
						seriesWriter.writeAttribute(key, componentVals.get(key));
					}
				}
				if(isCrossSectionalMeasure) {
					seriesWriter.writeAttribute("xsi", XSI_NS, "type", COMPACT_NS.namespacePrefix+":"+obsIdValue);
				} else {
					if (obsConceptId == null || obsConceptId.equals("AllDimensions")) {
						// Do nothing
					} else {
						if(obsIdValue == null) {
							obsIdValue = "";
						}
						seriesWriter.writeAttribute(obsConceptId, obsIdValue);
					}
				}
				
				List<KeyValue> multiValueMeasures = null;
				for(KeyValue measure : measures) {
					if(measure.hasMultipleValues()) {
						if(multiValueMeasures == null) {
							multiValueMeasures = new ArrayList<>(measures.size());
						}
						multiValueMeasures.add(measure);
					} else if(ObjectUtil.validString(measure.getCode())){
						seriesWriter.writeAttribute(measure.getConcept(), measure.getCode());
					}
				}
				if(multiValueMeasures != null) {
					for(KeyValue multiValueMeasure : multiValueMeasures) {
						writeMultiValuedComponent(multiValueMeasure.getConcept(), multiValueMeasure.getValues().toArray(new String[0]));
					}
				}
			} catch(XMLStreamException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		@Override
		protected void writeEndObs() throws XMLStreamException {
			if(isTwoPointOne()) {
				writeAnnotations(seriesWriter, obsAnnotations);
				obsAnnotations = null;
			}
			super.writeEndObs();
		}


		@Override
		public void writeAttributeValue(String attributeId, String... attributeValues) {
			attributeId = getComponentId(attributeId);
			super.writeAttributeValue(attributeId, attributeValues);
			if(attributeValues.length == 1) {
				String attributeValue = attributeValues[0];
				if (attributeValue == null) {
					attributeValue = "";
				}
				try {
					switch (currentPosition) {
						case DATASET:
						case DATASET_ATTRIBUTE:
							currentPosition = POSITION.DATASET_ATTRIBUTE;
							super.writeDatasetAttribute(attributeId, attributeValue);
							break;
						case OBSERVATION:
						case OBSERVATION_ATTRIBUTE:
							currentPosition = POSITION.OBSERVATION_ATTRIBUTE;
							seriesWriter.writeAttribute(attributeId, attributeValue);
							break;
						case SERIES_KEY:
						case SERIES_KEY_ATTRIBUTE:
							currentPosition = POSITION.SERIES_KEY_ATTRIBUTE;
							if (isFlat) {
								componentVals.put(attributeId, attributeValue);
							} else {
								seriesWriter.writeAttribute(attributeId, attributeValue);
							}
							break;
						case GROUP:
						case GROUP_KEY_ATTRIBUTE:
						case GROUP_KEY:
							currentPosition = POSITION.GROUP_KEY_ATTRIBUTE;
							writer.writeAttribute(attributeId, attributeValue);
							break;
						case COMP_KEY:
							writeEndComp();
							if (positionBeforeComp == POSITION.OBSERVATION || positionBeforeComp == POSITION.OBSERVATION_ATTRIBUTE) {
								writeEndObs();
							}
							break;
					}
				} catch (XMLStreamException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			} else if (attributeValues.length > 1) {
				writeMultiValuedComponent(attributeId, attributeValues);
			}
		}
		
		private void writeMultiValuedComponent(String attributeId, String[] attributeValues) {
			try{
				startComp(attributeId,attributeId+"_ATTRIBUTE");
				
				for(String value : attributeValues) {
					seriesWriter.writeStartElement("Value");
					if(value!=null){
						seriesWriter.writeCharacters(value);
					}
					seriesWriter.writeEndElement();
				}
				
				writeEndComp();
			}catch(XMLStreamException e){
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}


		@Override
		public void close(FooterMessage... footer) {
			if(currentPosition != null) {
				try {
					switch(currentPosition) {
					case DATASET :
						//DO NOTHING
						break;
					case OBSERVATION :
						writeEndObs();
						writeEndSeries();
						break;
					case OBSERVATION_ATTRIBUTE :
						writeEndObs();
						writeEndSeries();
						break;
					case SERIES_KEY_ATTRIBUTE :
						writeEndSeries();
						break;
					case SERIES_KEY :
						writeEndSeries();
						break;
					case GROUP :
						writeEndGroup();
						break;
					case GROUP_KEY_ATTRIBUTE :
						writeEndGroup();
						break;
					case GROUP_KEY :
						writeEndGroup();
						break;
					case DATASET_ATTRIBUTE :
						//DO NOTHING
						break;
					}

				} catch(XMLStreamException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			}
			super.close(footer);
		}

	@Override
	public void writeMultilingualAttributeValue(IMultilingualKeyValue multilingualKeyValue){
		if (multilingualKeyValue.getMultilingualNodeValues() != null && multilingualKeyValue.getMultilingualNodeValues().size()>0){
			try{
				startComp(multilingualKeyValue.getConcept(), multilingualKeyValue.getConcept() + "_ATTRIBUTE");
				for(IMultilingualNodeValue node : multilingualKeyValue.getMultilingualNodeValues()){
					writeMultilingualValueNode(node);
				}
				writeEndComp();
			} catch (XMLStreamException e){
				e.printStackTrace();
			}
		}
		else{
			throw new IllegalArgumentException("error while writing complex attributes: CompKeyValue.getComplexNodeValues() cannot be null or empty");
		}
	}

	@Override
	public void startComp(String id, String type) throws XMLStreamException{
		super.startComp(id, type);
		if(currentPosition == POSITION.COMP_KEY){
			seriesWriter.writeStartElement("Comp");
			seriesWriter.writeAttribute("id", id);
			writer.writeAttribute("xsi", XSI_NS, "type", COMPACT_NS.namespacePrefix+":"+type);
		}
	}

	public void writeMultilingualValueNode(IMultilingualNodeValue node) throws XMLStreamException{
		seriesWriter.writeStartElement("Value");
		if(node.getTexts() != null && node.getTexts().size()>0){
			for(TextTypeWrapper text : node.getTexts()){
				seriesWriter.writeStartElement(PREFIX_COMMON + ":Text");
				if(text.getLocale()!=null){
					seriesWriter.writeAttribute("xml:lang", text.getLocale());
				}
				seriesWriter.writeCharacters(text.getValue());
				seriesWriter.writeEndElement(); // Close <Text/>
			}
		}
		seriesWriter.writeEndElement(); //close <Value/>
	}


	}
