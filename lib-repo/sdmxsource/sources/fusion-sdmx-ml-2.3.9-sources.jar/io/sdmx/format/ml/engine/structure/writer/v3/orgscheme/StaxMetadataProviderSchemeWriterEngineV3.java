package io.sdmx.format.ml.engine.structure.writer.v3.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMetadataProviderSchemeWriterEngineV3 extends StaxAbstractOrganisationSchemeWriterEngine<IMetadataProviderSchemeBean, IMetadataProviderBean> implements IFusionSingleton {
	private static StaxMetadataProviderSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataProviderSchemeWriterEngineV3() {}

	public static StaxMetadataProviderSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataProviderSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "MetadataProviderScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "MetadataProvider";
	}
}
