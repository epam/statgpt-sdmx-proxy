package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxUserDefinedOperatorSchemeWriterEngineV21 extends StaxAbstractVTLSchemeWriterEngineV21<IUserDefinedOperatorSchemeBean> implements IFusionSingleton {
	private static StaxUserDefinedOperatorSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxUserDefinedOperatorSchemeWriterEngineV21() {}

	public static StaxUserDefinedOperatorSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxUserDefinedOperatorSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "UserDefinedOperatorScheme";
	}

	@Override
	protected void writeMaintainableInternal(IUserDefinedOperatorSchemeBean maint, StaxWriter writer) {
		writeItems(maint.getItems(), writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtil.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
		if(maint.getRulesetSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getRulesetSchemeRef()) {
				StaxRefUtil.writeReference(ref, writer, "RulesetScheme");
			}
		}
	}

	private void writeItems(List<IUserDefinedOperatorBean> items, StaxWriter writer) {
		for(IUserDefinedOperatorBean item : items) {
			StaxNameableWriterUtil.writeBean(item, "UserDefinedOperator", writer);
			if(item.getOperatorDefinition() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "OperatorDefinition", item.getOperatorDefinition());
			}
			writer.writeEndElement();
		}
	}
}
