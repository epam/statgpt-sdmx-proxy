package io.sdmx.format.ml.engine.structure.reader.v20.catscheme;

import java.util.Map;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.CategorisationUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxCategorySchemeReaderEngineV2 implements StaxMaintainableReaderEngine<CategorySchemeMutableBean>, IFusionSingleton {
	private static StaxCategorySchemeReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorySchemeReaderEngineV2() {}
	public static StaxCategorySchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorySchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
	    INSTANCE = null;
	}

    @Override
    public String getContainerNodeName() {
        return "CategorySchemes";
    }
    
    protected String getRootNodeName() {
        return "CategoryScheme";
    }
    
    @Override
    public void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals(getRootNodeName())) {
                    CategorySchemeMutableBean aBean = processMaintainable(reader, beans, builder);
                    builder.build(aBean, beans);
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
            } else if(nodeName.equals(getContainerNodeName())){
                break;
            }
        }
    }
    
    private CategorySchemeMutableBean processMaintainable(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
        CategorySchemeMutableBean maint = new CategorySchemeMutableBeanImpl();
        StaxMaintainableUtilV2.processBean(maint, reader);

        String parentId = "";
        while(reader.isStartElement()) {
            if(!reader.getElementName().equals("Category")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            maint.addItem(processCategory(reader, maint, parentId, beans, builder));

            //After processing the category move to the next element which is either ending this
            //category, an annotation or the starting a new category
            reader.moveNextNode();

            if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
                reader.moveNextNode(); //Move to the start/end of the next node
            }
        }

        return maint;
    }

    private CategoryMutableBean processCategory(IStaxReader reader, CategorySchemeMutableBean catScheme, String parentId, SdmxBeans beans, IBeansBuilder builder) {
        CategoryMutableBean cat = new CategoryMutableBeanImpl();

        Map<String, String> attributes = reader.getAttributes();
        cat.setId(StaxStructureUtil.getAttribute(attributes, "id", false));  //Id may not be mandatory for an identifiable that inherits it from a concept if not provided
        cat.setUri(StaxStructureUtil.getAttribute(attributes, "uri", false));

        // Process Name and Description
        reader.moveNextNode();
        while(StaxNameableUtil.processNode(cat, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("MetadataflowRef")) {
                StructureReferenceBean flowRef = processMetadataflowRef(reader);
                builder.build(createCategorisation(catScheme, cat, parentId, flowRef), beans);
                continue;
            } else if(reader.getElementName().equals("DataflowRef")) {
                StructureReferenceBean flowRef = processDataflowRef(reader);
                builder.build(createCategorisation(catScheme, cat, parentId, flowRef), beans);
                continue;
            } else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(cat, reader);
                reader.moveNextNode(); //Move to the start/end of the next node
                continue;
            } else  if(!reader.getElementName().equals("Category")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }

            String newParentId;
            if (ObjectUtil.validString(parentId)) {
                newParentId = parentId + "." + cat.getId();
            } else {
                newParentId = cat.getId();
            }
            cat.addItem(processCategory(reader, catScheme, newParentId, beans, builder));
            //After processing the category move to the next element which is either ending this
            //category, or starting a new one
            reader.moveNextNode();
        }

        //Leave on an end element
        return cat;
    }
    
    private CategorisationMutableBean createCategorisation(CategorySchemeMutableBean catScheme, CategoryMutableBean cat, String parentId, StructureReferenceBean flowRef) {
        CategorisationMutableBean catMut = new CategorisationMutableBeanImpl();

        String[] splitArr;
        if (ObjectUtil.validString(parentId)) {
            String fullIdPath = parentId + "." + cat.getId();
            splitArr = fullIdPath.split("\\.");
        } else {
            splitArr = new String[] { cat.getId() };
        }
        StructureReferenceBean categoryRef = new StructureReferenceBeanImpl(catScheme.getAgencyId(), catScheme.getId(), catScheme.getVersion(), SDMX_STRUCTURE_TYPE.CATEGORY, splitArr);
        catMut.setCategoryReference(categoryRef);

        catMut.setNames(cat.getNames());
        catMut.setStructureReference(flowRef);

        catMut.setAgencyId(catScheme.getAgencyId());

        if (flowRef.getFullId() != null) {
            catMut.setId(flowRef.getFullId());
        } else {
            catMut.setId( CategorisationUtil.generateId(catMut) );
        }

        return catMut;
    }

    private StructureReferenceBean processDataflowRef(IStaxReader reader) {
        return processFlowRefNodes(reader, SDMX_STRUCTURE_TYPE.DATAFLOW, "DataflowRef", "DataflowID");
    }

    private StructureReferenceBean processMetadataflowRef(IStaxReader reader) {
        return processFlowRefNodes(reader, SDMX_STRUCTURE_TYPE.METADATA_FLOW, "MetadataflowRef", "MetadataflowID");
    }
    
    private StructureReferenceBean processFlowRefNodes(IStaxReader reader, SDMX_STRUCTURE_TYPE strucType, String nodeStartName, String idFlowName) {
        String urn = null;
        String acyId = null;
        String id = null;
        String version = null;
        reader.moveNextNode();
        while (!reader.getElementName().equals(nodeStartName)) {
            if (reader.getElementName().equals("URN")) {
                urn = reader.getElementText();
            } else if (reader.getElementName().equals("AgencyID")) {
                acyId = reader.getElementText();
            } else if (reader.getElementName().equals(idFlowName)) {
                id = reader.getElementText();
            } else if (reader.getElementName().equals("Version")) {
                version = reader.getElementText();
            }
            reader.moveNextNode();
        }
        // Move to Start of next node
        reader.moveNextNode();

        if (ObjectUtil.validOneString(acyId, id, version)) {
            return new StructureReferenceBeanImpl(acyId, id, version, strucType);
        }
        return new StructureReferenceBeanImpl(urn, strucType);
    }

}
