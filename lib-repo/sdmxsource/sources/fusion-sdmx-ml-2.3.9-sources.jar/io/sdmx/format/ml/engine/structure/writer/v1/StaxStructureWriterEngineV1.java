package io.sdmx.format.ml.engine.structure.writer.v1;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.format.ml.engine.structure.writer.v1.util.StaxStructureWriterUtilV1;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;


public class StaxStructureWriterEngineV1 extends StaxAbstractStructureWriterEngineV1 implements IFusionSingleton {
	private static StaxStructureWriterEngineV1 INSTANCE;
	private static StaxStructureWriterEngineV1 PRETTY_INSTANCE;

	public static StaxStructureWriterEngineV1 getInstance(boolean prettyPrint) {
		if(!prettyPrint) {
			return getInstance();
		}
		if(PRETTY_INSTANCE == null) {
			PRETTY_INSTANCE = new StaxStructureWriterEngineV1();
			PRETTY_INSTANCE.prettyPrint = true;
			FusionBeanStore.registerInstance(PRETTY_INSTANCE);
		}
		return PRETTY_INSTANCE;
	}

	public static StaxStructureWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureWriterEngineV1();
			INSTANCE.prettyPrint = false;
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
        PRETTY_INSTANCE = null;
    }

	private StaxStructureWriterEngineV1() {
		super(SDMX_SCHEMA.VERSION_ONE,
		        StaxStructureWriterUtilV1.MESSAGE_NS,
		        StaxStructureWriterUtilV1.STRUCTURE_NS,
		        StaxStructureWriterUtilV1.COMMON_NS,
		        null);
	}

	@Override
	protected String getDocumentRoot() {
		return "Structure";
	}

	@Override
	protected void afterHeader(StaxWriter writer, DATASET_ACTION action) {
		//Do nothing
	}
}
