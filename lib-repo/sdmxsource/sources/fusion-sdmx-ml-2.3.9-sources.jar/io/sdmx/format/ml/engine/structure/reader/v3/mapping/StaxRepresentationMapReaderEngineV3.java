package io.sdmx.format.ml.engine.structure.reader.v3.mapping;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedRelationshipMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IMappedValueMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.v3.IRepresentationMapMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxAnnotableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxMaintainableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.mapping.v3.RepresentationMapMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxRepresentationMapReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IRepresentationMapMutableBean> {
	private static StaxRepresentationMapReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRepresentationMapReaderEngineV3() {}
	public static StaxRepresentationMapReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRepresentationMapReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public String getContainerNodeName() {
        return "RepresentationMaps";
    }
	
    @Override
    protected String getRootNodeName() {
        return "RepresentationMap";
    }
    
	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
    @Override
    protected IRepresentationMapMutableBean processMaintainable(IStaxReader reader) {
		IRepresentationMapMutableBean returnBean = new RepresentationMapMutableBean();

		StaxMaintainableUtilV3.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("SourceCodelist")) {
				returnBean.addSourceRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE_LIST, SDMX_STRUCTURE_TYPE.VALUE_LIST));
			} else if(nodeName.equals("TargetCodelist")) {
				returnBean.addTargetRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE_LIST, SDMX_STRUCTURE_TYPE.VALUE_LIST));
			} else if(nodeName.equals("SourceDataType")) {
				returnBean.addSourceRef(TEXT_TYPE.parseString(reader.getElementText()));
			} else if(nodeName.equals("TargetDataType")) {
				returnBean.addTargetRef(TEXT_TYPE.parseString(reader.getElementText()));
			} else if(nodeName.equals("RepresentationMapping")) {
				processMappedRelationship(reader, returnBean);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
	

	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private void processMappedRelationship(IStaxReader reader, IRepresentationMapMutableBean mutable) {
		IMappedRelationshipMutableBean mr = mutable.addMappedRelationship();
		
		Map<String, String> attributes = reader.getAttributes();
		mr.setValidFrom(StaxStructureUtil.getAttribute(attributes, "validFrom", false));
		mr.setValidTo(StaxStructureUtil.getAttribute(attributes, "validTo", false));
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.getElementName().equals("Annotations")) {
				StaxAnnotableUtilV3.processAnnotations(mr, reader);
			}
			if(reader.isStartElement()) {
				attributes = reader.getAttributes();
				if(nodeName.equals("SourceValue")) {
					IMappedValueMutableBean mv = mr.addSourceValue().setValue(reader.getElementText());
					mv.setRegEx(StaxStructureUtil.getAttributeAsBoolean(attributes, "isRegEx", false, false));
					
					Integer startIndex = StaxStructureUtil.getAttributeAsInteger(attributes, "startIndex", false);
					Integer endIndex = StaxStructureUtil.getAttributeAsInteger(attributes, "endIndex", false);
					
					if(startIndex != null) {
						mv.setStartIndex(startIndex);
					}
					if(endIndex != null) {
						mv.setEndIndex(endIndex);
					}
				} else if(nodeName.equals("TargetValue")) {
					mr.addTargetValue(reader.getElementText());
				}
				else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("RepresentationMapping")){
				break;
			}
		}
	}

	
}
