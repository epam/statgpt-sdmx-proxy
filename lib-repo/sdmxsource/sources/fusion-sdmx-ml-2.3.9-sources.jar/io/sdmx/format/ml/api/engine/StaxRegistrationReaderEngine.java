package io.sdmx.format.ml.api.engine;

import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.xml.StaxReader;

public interface StaxRegistrationReaderEngine extends StaxMaintainableReaderEngine<RegistrationMutableBean>, StaxStructureReaderEngine, IFusionSingleton {

	List<RegistrationInformation> readRegistrations(IStaxReader reader);
	
	@Override
	default void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
		for(RegistrationInformation reg : readRegistrations(reader)) {
		    beans.addIdentifiable(reg.getRegistration());
		}
	}
	
	@Override
	default SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder builder) {
		SdmxBeans returnBeans = new SdmxBeansImpl();
		IStaxReader staxReader = new StaxReader(rdl);
		try {
			for(RegistrationInformation regInfo : readRegistrations(staxReader)) {
				returnBeans.addIdentifiable(regInfo.getRegistration());
			}
		} finally {
			staxReader.close();
		}
		return returnBeans;
	}
}
