package io.sdmx.format.ml.engine.structure.writer.v1.util;

import io.sdmx.utils.core.xml.Namespace;

public class StaxStructureWriterUtilV1 {
    public static final Namespace XML_NS = new Namespace("http://www.w3.org/XML/1998/namespace", "xml");
    public static final Namespace MESSAGE_NS = new Namespace("http://www.SDMX.org/resources/SDMXML/schemas/v1_0/message", "mes");
    public static final Namespace STRUCTURE_NS = new Namespace("http://www.SDMX.org/resources/SDMXML/schemas/v1_0/structure", "str");
    public static final Namespace COMMON_NS = new Namespace("http://www.SDMX.org/resources/SDMXML/schemas/v1_0/common", "com");
}
