package io.sdmx.format.ml.engine.structure.reader.v3.dsd;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxRepresentationUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.datastructure.AttributeListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDsdReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<DataStructureMutableBean>{
    private static StaxDsdReaderEngineV3 INSTANCE;

    //Private constructor - lazy load instance
    private StaxDsdReaderEngineV3() {}

    public static StaxDsdReaderEngineV3 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxDsdReaderEngineV3();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "DataStructures";
    }
    
    @Override
    protected String getRootNodeName() {
        return "DataStructure";
    }

    @Override
    protected DataStructureMutableBean processMaintainable(IStaxReader reader) {
        DataStructureMutableBean dsd = new DataStructureMutableBeanImpl();
        StaxMaintainableUtil.processBean(dsd, reader);
        do {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals("DataStructureComponents")) {
                    processDataStructureComponents(dsd, reader);
                } else if(nodeName.equals("Metadata")) {
                    dsd.setMSDReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.MSD));
                }
            } else if(nodeName.equals("DataStructure")){
                break;
            }
        } while((reader.moveNextNode()));
        return dsd;
    }

    private void processDataStructureComponents(DataStructureMutableBean dsd, IStaxReader reader) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals("DimensionList")) {
                    dsd.setDimensionList(processDimensionList(reader));
                } else if(nodeName.equals("Group")) {
                    dsd.addGroup(processGroup(reader));
                } else if(nodeName.equals("AttributeList")) {
                    dsd.setAttributeList(processAttributeList(reader));
                } else if(nodeName.equals("MeasureList")) {
                    dsd.setMeasureList(processMeasuresList(reader));
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
            } else if(nodeName.equals("DataStructureComponents")) {
                break;
            }
        }
    }

    private DimensionListMutableBean processDimensionList(IStaxReader reader) {
        DimensionListMutableBean bean = new DimensionListMutableBeanImpl();
        StaxIdentifiableUtil.processBean(bean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("Dimension")) {
                bean.addDimension(processDimension(reader, false, false));
            } else if(nodeName.equals("MeasureDimension")) {
                bean.addDimension(processDimension(reader, true, false));
            }  else if(nodeName.equals("TimeDimension")) {
                bean.addDimension(processDimension(reader, false, true));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return bean;
    }

    private DimensionMutableBean processDimension(IStaxReader reader, boolean isMeasureDimension, boolean isTimeDimension) {
        DimensionMutableBean returnBean = new DimensionMutableBeanImpl();
        StaxIdentifiableUtil.processBean(returnBean, reader);
        returnBean.setMeasureDimension(isMeasureDimension);
        returnBean.setTimeDimension(isTimeDimension);
        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(processComponent(reader, returnBean)) {
                //OK
            } else if(nodeName.equals("ConceptRole")) {
                returnBean.addConceptRole(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return returnBean;
    }

    private boolean processComponent(IStaxReader reader, ComponentMutableBean comp) {
        String nodeName = reader.getElementName();
        if(nodeName.equals("ConceptIdentity")) {
            comp.setConceptRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
            return true;
        } else if(nodeName.equals("LocalRepresentation")) {
            comp.setRepresentation(StaxRepresentationUtilV3.processBean(reader));
            return true;
        }
        return false;
    }

    private GroupMutableBean processGroup(IStaxReader reader) {
        GroupMutableBean returnBean = new GroupMutableBeanImpl();
        StaxIdentifiableUtil.processBean(returnBean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("GroupDimension")) {
                reader.moveNextStartNode();
                if(reader.getElementName().equals("DimensionReference")) {
                    returnBean.addDimensionRef(StaxStructureRefReaderV3.getLocalReference(reader));
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
                reader.skipToEndNode("GroupDimension");
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return returnBean;
    }

    private AttributeListMutableBean processAttributeList(IStaxReader reader) {
        AttributeListMutableBean bean = new AttributeListMutableBeanImpl();
        StaxIdentifiableUtil.processBean(bean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("Attribute")) {
                bean.addAttribute(processAttribute(reader));
            } else if(nodeName.equals("ReportingYearStartDay")) {
                //TODO Not Supported
            }  else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return bean;
    }

    private AttributeMutableBean processAttribute(IStaxReader reader) {
        AttributeMutableBean returnBean = new AttributeMutableBeanImpl();

        String assignmentStatus = StaxStructureUtil.getAttribute(reader.getAttributes(), "usage", false);
        boolean assignmentStatusBool;
        if (assignmentStatus == null || assignmentStatus.equals("optional")) {
            assignmentStatusBool = false;
        } else if (assignmentStatus.equals("mandatory")) {
            assignmentStatusBool = true;
        } else {
            throw new SdmxSemmanticException("'usage' has illegal value of: " + assignmentStatus);
        }
        returnBean.setMandatory(assignmentStatusBool);

        StaxIdentifiableUtil.processBean(returnBean, reader);
        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(processComponent(reader, returnBean)) {
                //OK
            } else if(nodeName.equals("ConceptRole")) {
                returnBean.addConceptRole(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
            }  else if(nodeName.equals("AttributeRelationship")) {
                processAttributeRelationship(reader, returnBean);
            } else if(nodeName.equals("MeasureRelationship")) {
                processMeasureRelationship(reader, returnBean);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return returnBean;
    }

    private void processAttributeRelationship(IStaxReader reader, AttributeMutableBean attribute) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                // FMR-107: Note that "None" is SDMX-2.1 and not valid in SDMX-3, but is present here as users may have DSDs
                // which have been written incorrectly.
                if(nodeName.equals("None")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
                } else if(nodeName.equals("Dataflow")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
                } else if(nodeName.equals("Dimension")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
                    attribute.addDimensionReferences(StaxStructureRefReaderV3.getLocalReference(reader));
                } else if(nodeName.equals("Observation")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
                } else if(nodeName.equals("PrimaryMeasure")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
                    attribute.addMeasureReference("OBS_VALUE");
                } else if(nodeName.equals("AttachmentGroup")) {
                    reader.skipCurrentNode();  //TODO Not supported
                } else if(nodeName.equals("Group")) {
                    attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP);
                    attribute.setAttachmentGroup(StaxStructureRefReaderV3.getLocalReference(reader));
                }
            } else if(nodeName.equals("AttributeRelationship")) {
                return;
            }
        }
    }

    private void processMeasureRelationship(IStaxReader reader, AttributeMutableBean attribute) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals("Measure")) {
                    attribute.addMeasureReference(StaxStructureRefReaderV3.getLocalReference(reader));
                }
            } else if(nodeName.equals("MeasureRelationship")) {
                return;
            }
        }
    }

    private MeasureListMutableBean processMeasuresList(IStaxReader reader) {
        MeasureListMutableBean returnBean = new MeasureListMutableBeanImpl();
        StaxIdentifiableUtil.processBean(returnBean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("Measure")) {
                MeasureMutableBean measure = new MeasureMutableBeanImpl();
                returnBean.addMeasures(measure);

                String assignmentStatus = StaxStructureUtil.getAttribute(reader.getAttributes(), "usage", false);
                boolean assignmentStatusBool;
                if (assignmentStatus == null || assignmentStatus.equals("optional")) {
                    assignmentStatusBool = false;
                } else if (assignmentStatus.equals("mandatory")) {
                    assignmentStatusBool = true;
                } else {
                    throw new SdmxSemmanticException("'assignmentStatus' has illegal value of : " + assignmentStatus);
                }
                measure.setMandatory(assignmentStatusBool);

                StaxIdentifiableUtil.processBean(measure, reader);

                while(reader.isStartElement()) {
                    if(processComponent(reader, measure)) {
                        //OK
                    } else {
                        StaxStructureUtil.throwUnexpectedNodeException(reader);
                    }
                    reader.moveNextNode();
                }
            }  else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }


        return returnBean;
    }
}