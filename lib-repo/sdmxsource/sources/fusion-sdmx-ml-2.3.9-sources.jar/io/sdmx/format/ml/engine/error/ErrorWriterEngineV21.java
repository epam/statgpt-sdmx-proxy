package io.sdmx.format.ml.engine.error;

import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.ErrorWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.error.ISdmxError;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.exception.SchemaValidationException;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class ErrorWriterEngineV21 implements ErrorWriterEngine, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(ErrorWriterEngineV21.class);

	private SchemaLocationManager schemaLocationManager;

	private static ErrorWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	public static ErrorWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ErrorWriterEngineV21();
			FusionBeanStore.registerInstance(getInstance());
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
	    INSTANCE = null;
	}

	public static ErrorWriterEngineV21 registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	private ErrorWriterEngineV21() {
		schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
	}

	@Override
	public void writeError(ISdmxError error, OutputStream out) {
		StaxWriter writer = getErrorWriter(out, error.getSdmxErrorCode());
		for(String errorMessage : error.getErrorMessage()) {
			writeErrorText(writer, errorMessage);
		}
		writer.close();
	}

	@Override
	public int writeError(Throwable th, OutputStream out) {
		int statusCode = 500;
		SDMX_ERROR_CODE errorCode =  SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
		if(th instanceof SdmxException) {
			SdmxException ex = (SdmxException)th;
			statusCode  = ex.getHttpRestErrorCode() == null ? statusCode : ex.getHttpRestErrorCode();
			errorCode = ex.getSdmxErrorCode();
		}
		StaxWriter writer = getErrorWriter(out, errorCode);
		buildErrorResponse(th, writer);
		return statusCode;
	}

	private StaxWriter getErrorWriter(OutputStream out, SDMX_ERROR_CODE errorCode) {
		String schemaLocation = null;
		if(schemaLocationManager != null) {
			schemaLocation = schemaLocationManager.getSchemaLocation(SDMX_SCHEMA.VERSION_TWO_POINT_ONE);
		}
		StaxWriter writer = new StaxWriter(out, schemaLocation, true, SDMX_NAMESPACE.MESSAGE_21.getNamespace(), SDMX_NAMESPACE.COMMON_21.getNamespace());
		writer.startDocument(SDMX_NAMESPACE.MESSAGE_21.getNamespace(), "Error");
		writer.writeStartElement(SDMX_NAMESPACE.MESSAGE_21.getNamespace(), "ErrorMessage");
		writer.writeAttribute("code", errorCode == null ? "500" : errorCode.getClientErrorCode().toString());
		return writer;
	}

	/**
	 * Writes the SDMX Error Response
	 * <mes:Error xsi:schemaLocation="http://www.sdmx.org/resources/sdmxml/schemas/v2_1/message https://registry.sdmx.org/schemas/v2_1/SDMXMessage.xsd">
		<mes:ErrorMessage code="100">
			<com:Text>
				Error message
			</com:Text>
		</mes:ErrorMessage>
		</mes:Error>

	 * @param th
	 * @param exceptionCode
	 * @param writer
	 */
	private void buildErrorResponse(Throwable th,  StaxWriter writer) {
		if(th instanceof SchemaValidationException) {
			processSchemaValidationError(writer, (SchemaValidationException) th);
		} else {
			processThrowable(writer, th);
		}
		writer.writeEndElement(); //End ErrorMessage
		writer.writeEndElement(); //End Error
		writer.close();
	}

	private void processSchemaValidationError(StaxWriter writer, SchemaValidationException e) {
		if (ObjectUtil.validCollection(e.getValidationErrors())) {
			for(String error : e.getValidationErrors()) {
				writeErrorText(writer, error);
			}
		} else {
			String message;
			Throwable cause = e.getCause();
			if (cause == null) {
				message = e.getMessage();
			} else {
				message = cause.getMessage();
			}
			writeErrorText(writer, message);
		}
	}

	private void processThrowable(StaxWriter writer, Throwable th) {
		Throwable th2 = th;
		StringBuilder sb = new StringBuilder();
		String previousMessage = "";
		while(th2 != null) {
			String newMessage = th2.getMessage();
			if(newMessage == null) {
				newMessage = th2.getClass().toString();
			} else if(newMessage.contains("Exception: ")) {
				newMessage = newMessage.split("Exception: ")[1];
			}
			
			if (th instanceof SdmxException && !LOG.isDebugEnabled()) {
                // Suppress all SdmxException Stack Traces
                LOG.error(newMessage);
            } else {
                LOG.error(newMessage, th2);
            }

			if (!ObjectUtil.validString(previousMessage)) {
				sb.append(newMessage);
			} else if(!newMessage.equals(previousMessage)) {
				sb.append(System.getProperty("line.separator") + newMessage);
			}
			previousMessage = newMessage;
			th2 = th2.getCause();
		}
		writeErrorText(writer, sb.toString());
	}

	private void writeErrorText(StaxWriter writer, String errorMessage) {
		writer.writeElement(SDMX_NAMESPACE.COMMON_21.getNamespace(), "Text", errorMessage);
	}
}
