package io.sdmx.format.ml.engine.structure.reader.v3.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

public class StaxStructureRefReaderV3 {
	
	public static StructureReferenceBean getStructureReference(IStaxReader staxReader, SDMX_STRUCTURE_TYPE... targetStructure) {
		return StructureReferenceBeanImpl.buildAndVerify(staxReader.getElementText(), targetStructure);
	}
	
	public static String getLocalReference(IStaxReader staxReader) {
		return staxReader.getElementText();
	}
}
