package io.sdmx.format.ml.exception;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.exception.SdmxSyntaxException;

public class SchemaValidationException extends SdmxSyntaxException {

	private static final long serialVersionUID = -6863926329160671609L;
	private List<String> validationErrors = new ArrayList<>();
	
	
	public SchemaValidationException(List<String> errors) {
		super(mergeErrors(errors));
		for(String currentError : errors) {
			validationErrors.add(currentError);
		}
	}

	public SchemaValidationException(Throwable th) {
		super(th);
	}
	
	private static String mergeErrors(List<String> errors) {
		StringBuilder sb = new StringBuilder();
		for(String currentError : errors) {
			sb.append(currentError);
		}
		return sb.toString();
	}

	public List<String> getValidationErrors() {
		return new ArrayList<>(validationErrors);
	}
}
