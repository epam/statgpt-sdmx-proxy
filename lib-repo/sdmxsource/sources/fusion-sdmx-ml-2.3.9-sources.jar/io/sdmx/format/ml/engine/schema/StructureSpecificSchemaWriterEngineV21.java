package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class StructureSpecificSchemaWriterEngineV21 implements SchemaWriterEngine {
	private static StructureSpecificSchemaWriterEngineV21 INSTANCE;

	public static StructureSpecificSchemaWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureSpecificSchemaWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}


	@Override
	public void writeSchema(ConstrainedCodes validCodes, String dimensionAtObservation, boolean prettyPrint, OutputStream out) {
		SchemaLocationManager schemaLocation = SingletonStore.getSingleton(SchemaLocationManager.class);
		CompactSchemaCreatorSdmx2_1 schema = new CompactSchemaCreatorSdmx2_1(validCodes, dimensionAtObservation, 
				schemaLocation.getSchemaLocation(SDMX_SCHEMA.VERSION_TWO_POINT_ONE), out, prettyPrint);
		schema.createSchema();
	}

}
