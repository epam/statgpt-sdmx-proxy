package io.sdmx.format.ml.engine.structure.writer.v21.dataflow;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDataflowWriterEngineV21 extends AbstractV21Writer<DataflowBean> implements IFusionSingleton {
	private static StaxDataflowWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataflowWriterEngineV21() {}

	public static StaxDataflowWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataflowWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Dataflow";
	}

	@Override
	protected void writeMaintainableInternal(DataflowBean maint, StaxWriter writer) {
		StaxRefUtil.writeReference(maint.getDataStructureRef(), writer, "Structure");
	}
}
