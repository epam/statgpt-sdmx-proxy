package io.sdmx.format.ml.engine.structure.reader.v3.codelist;

import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeoGridCodelistMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.GeoGridCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeoGridCodelistMutableBean;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxGeoGridCodelistReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IGeoGridCodelistMutableBean> {
	private static StaxGeoGridCodelistReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxGeoGridCodelistReaderEngineV3() {}

	public static StaxGeoGridCodelistReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxGeoGridCodelistReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "GeoGridCodelists";
    }

    @Override
    protected String getRootNodeName() {
        return "GeoGridCodelist";
    }
    
    @Override
    protected IGeoGridCodelistMutableBean processMaintainable(IStaxReader reader) {
        IGeoGridCodelistMutableBean maint = new GeoGridCodelistMutableBean();
        StaxItemSchemeUtil.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("GeoGridCode")) {
                IGeoGridCodeMutableBean aCode = processGeoGridCode(reader);
                maint.addItem(aCode);
            } else if(reader.getElementName().equals("GridDefinition")) {
                maint.setGridDefinition(reader.getElementText());
            }  else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        ValidityPeriodUtil.processValidityAnnotations(maint);
        return maint;
    }
  
	private IGeoGridCodeMutableBean processGeoGridCode(IStaxReader reader) {
		IGeoGridCodeMutableBean code = new GeoGridCodeMutableBean();
		StaxNameableUtil.processBean(code, reader);

		if(reader.isStartElement()) {
			if(reader.getElementName().equals("GeoCell")) {
				code.setGeoCell(reader.getElementText());
			} else if(reader.getElementName().equals("Parent")) {
				code.setParentCode(StaxStructureRefReaderV3.getLocalReference(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();  //Move to end of parent element
		}
		//Leave on an end element
		return code;
	}
}