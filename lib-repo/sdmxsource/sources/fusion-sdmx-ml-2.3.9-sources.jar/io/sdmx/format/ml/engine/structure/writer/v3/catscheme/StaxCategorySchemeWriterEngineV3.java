package io.sdmx.format.ml.engine.structure.writer.v3.catscheme;

import java.util.List;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCategorySchemeWriterEngineV3 extends AbstractV3Writer<CategorySchemeBean> implements IFusionSingleton {
	private static StaxCategorySchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorySchemeWriterEngineV3() {}

	public static StaxCategorySchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorySchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CategoryScheme";
	}

	@Override
	protected void writeMaintainableInternal(CategorySchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeCategories(maint.getItems(), externalLinks, writer);
	}

	private void writeCategories(List<CategoryBean> categories, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(CategoryBean cat : categories) {
			StaxNameableWriterUtilV3.writeBean(cat, "Category", externalLinks, writer);
			writeCategories(cat.getItems(), externalLinks, writer);
			writer.writeEndElement();
		}
	}
}
