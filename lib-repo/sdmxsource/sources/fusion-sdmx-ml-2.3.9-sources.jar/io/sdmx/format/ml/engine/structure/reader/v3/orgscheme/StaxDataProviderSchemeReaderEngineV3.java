package io.sdmx.format.ml.engine.structure.reader.v3.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataProviderSchemeReaderEngineV3 extends StaxAbstractOrgansiationReaderV3<DataProviderSchemeMutableBean> {
	private static StaxDataProviderSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataProviderSchemeReaderEngineV3() {}

	public static StaxDataProviderSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataProviderSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
        return "DataProviderSchemes";
    }
    
    @Override
    protected String getRootNodeName() {
        return "DataProviderScheme";
    }
    
	@Override
    protected DataProviderSchemeMutableBean processMaintainable(IStaxReader reader) {
	    DataProviderSchemeMutableBean dpScheme = new DataProviderSchemeMutableBeanImpl();
        StaxItemSchemeUtil.processBean(dpScheme, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("DataProvider")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processDataProvider(dpScheme, reader);
            reader.moveNextNode();
        }
        return dpScheme;
    }

	private void processDataProvider(DataProviderSchemeMutableBean beanToPopulate, IStaxReader reader) {
		DataProviderMutableBean provider = new DataProviderMutableBeanImpl();
		beanToPopulate.addItem(provider);
		super.processOrganisation(provider, reader);
	}
}
