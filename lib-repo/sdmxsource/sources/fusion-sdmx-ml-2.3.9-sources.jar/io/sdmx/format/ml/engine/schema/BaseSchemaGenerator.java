package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import io.sdmx.utils.core.xml.IndentingXMLStreamWriter;

/**
 * Abstract class which contains the code necessary for writing information common to the various XML schema types.
 */
public abstract class BaseSchemaGenerator {
	public static final String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";
	public String COMPACT_NS;
	public String COMMON_NS;
	public String UTILITY_NS;
	public String MESSAGE_NS;

	public static final int COMPACT = 1;
	public static final int UTILITY = 2;

	DataStructureSuperBean dsd;
	XMLStreamWriter writer;

	protected String schemaLocation;

	private SDMX_SCHEMA targetSchemaVersion;
	private boolean prettyPrint;
	//A code map containing
	protected Map<String, Set<String>> validCodeMap;


	//	//By default the type name for a sinmpleType defining a Codelist id the codelist Id.  However,
	//	private Map<String, String> componetCodelistIdToTypeName = new HashMap<String, String>();

	public BaseSchemaGenerator(Map<String, Set<String>> validCodeMap, boolean prettyPrint) {
		this.validCodeMap = validCodeMap;
		this.prettyPrint = prettyPrint;
	}

	/**
	 * Init method output the various namespaces and schemas at the start of the XML document
	 *
	 * @param out
	 * @param xsdType
	 * @param targetNamespace
	 * @param keyFamily
	 * @param codelists
	 * @param writer
	 */
	protected void init (OutputStream out, int xsdType, String targetNamespace, SDMX_SCHEMA targetSchemaVersion, DataStructureSuperBean keyFamily) {
		this.targetSchemaVersion = targetSchemaVersion;
		switch(targetSchemaVersion) {
		case VERSION_ONE :
			COMPACT_NS = SdmxConstants.COMPACT_NS_1_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_1_0;
			UTILITY_NS = SdmxConstants.UTILITY_NS_1_0;
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_1_0;
			break;
		case VERSION_TWO:
			COMPACT_NS = SdmxConstants.COMPACT_NS_2_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_2_0;
			UTILITY_NS = SdmxConstants.UTILITY_NS_2_0;
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_2_0;
			break;
		case VERSION_TWO_POINT_ONE:
			COMPACT_NS = SdmxConstants.COMPACT_NS_2_1;
			COMMON_NS  = SdmxConstants.COMMON_NS_2_1;
			MESSAGE_NS = SdmxConstants.STRUCTURE_SPECIFIC_NS_2_1;
			break;
		case VERSION_THREE:
			COMPACT_NS = SdmxConstants.COMMON_NS_3_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_3_0;
			MESSAGE_NS = SdmxConstants.STRUCTURE_SPECIFIC_NS_3_0;
			break;
		default:
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, targetSchemaVersion);
		}

		if(!keyFamily.getBuiltFrom().isCompatible(targetSchemaVersion)) {
			String errorString = "The Data Structure '"+keyFamily.getBuiltFrom().getName()+"' is not compatible with the target schema version: " + targetSchemaVersion;
			throw new IllegalArgumentException(errorString);
		}

		if (targetNamespace == null) {
			targetNamespace = "undefined";
		}

		this.dsd = keyFamily;
		try {

			XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();

			String encoding = StandardCharsets.UTF_8.toString();
			writer = xmlOutputfactory.createXMLStreamWriter(out, encoding);
			if(prettyPrint) {
				writer = new IndentingXMLStreamWriter(writer);
			}
			writer.writeStartDocument(encoding, "1.0");

			writer.writeStartElement("xs", "schema", SCHEMA_NS);    // Start Schema - not ended till end of document

			if (targetSchemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
				writer.writeAttribute("xmlns:dsd", "http://www.sdmx.org/resources/sdmxml/schemas/v2_1/data/structurespecific");
			} else if (targetSchemaVersion == SDMX_SCHEMA.VERSION_THREE) {
				writer.writeAttribute("xmlns:dsd", "http://www.sdmx.org/resources/sdmxml/schemas/v3_0/data/structurespecific");
			}

			writer.writeDefaultNamespace(targetNamespace);
			writer.writeNamespace("xs", SCHEMA_NS);

			switch(xsdType) {
			case COMPACT : writer.writeNamespace("compact", COMPACT_NS);
			break;
			case UTILITY : writer.writeNamespace("utility", UTILITY_NS);
			break;
			}

			writer.writeNamespace("common", COMMON_NS);
			writer.writeNamespace("message", MESSAGE_NS);
			writer.writeNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
			writer.writeAttribute("targetNamespace", targetNamespace);
			writer.writeAttribute("elementFormDefault", "qualified");
			writer.writeAttribute("attributeFormDefault", "unqualified");

			//IMPORT SCHEMAS
			writer.writeStartElement(SCHEMA_NS, "import");      // Start Import
			writer.writeAttribute("namespace", COMMON_NS);

			if(schemaLocation == null) {
				schemaLocation = "";
			}
			writer.writeAttribute("schemaLocation", schemaLocation+"SDMXCommon.xsd");

			//String schema = MESSAGE_NS + " " + schemaLocation+"SDMXMessage.xsd";

			writer.writeEndElement();	                        // End Import

			if (targetSchemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE || targetSchemaVersion == SDMX_SCHEMA.VERSION_THREE) {
				writer.writeStartElement(SCHEMA_NS, "import");  // Start Import
				writer.writeAttribute("namespace", MESSAGE_NS);
				writer.writeAttribute("schemaLocation", schemaLocation+"SDMXDataStructureSpecific.xsd");
				writer.writeEndElement();                       // End Import
			} else {
				writer.writeStartElement(SCHEMA_NS, "import");  // Start Import
				switch(xsdType) {
				case COMPACT:
					writer.writeAttribute("namespace", COMPACT_NS);
					writer.writeAttribute("schemaLocation", schemaLocation+"SDMXCompactData.xsd");
					break;
				case UTILITY:
					writer.writeAttribute("namespace", UTILITY_NS);
					writer.writeAttribute("schemaLocation", schemaLocation+"SDMXUtilityData.xsd");
					break;
				}

				writer.writeEndElement();                      // End Import

				writer.writeStartElement(SCHEMA_NS, "import");    // Start Import
				writer.writeAttribute("namespace", MESSAGE_NS);
				writer.writeAttribute("schemaLocation", schemaLocation+"SDMXMessage.xsd");
				writer.writeEndElement();                         // End Import
			}


			// Components
			Set<String> fullCodelistsOutput = new HashSet<>();
			for(ComponentSuperBean<ComponentBean> component : keyFamily.getComponents()) {
				String componentId = component.getId();
				if(writeSimpleType(component)) {
					EnumeratedListBean<EnumeratedItemBean> cl = component.getCodelist(true);
					if(cl != null) {
						boolean isConstrained = isConstrained(componentId);
						if(!isConstrained && fullCodelistsOutput.contains(cl.getUrn())) {
							continue;
						}
						if(!isConstrained) {
							fullCodelistsOutput.add(cl.getUrn());
						}
						processCodelist(cl, component);
					} else {
						TextFormatBean tf = component.getTextFormat();
						if (tf != null && tf.getTextType() != null) {
							processUncodedWithRestriction(component.getId(), tf);
						}
					}
				}
			}
		} catch(Throwable th) {
			throw new RuntimeException(th);
		}
	}

	/**
	 * @param component
	 * @return true if this simple type is to be written at the top of the schema (before the Dataset)
	 */
	protected boolean writeSimpleType(ComponentSuperBean<ComponentBean> component) {
		if(component.getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
			return false;
		}
		return true;
	}
	
	private boolean isConstrained(String componentId) {
		if(validCodeMap == null) {
			return false;
		}
		if(validCodeMap.get(componentId) == null) {
			return false;
		}
		if(validCodeMap.get(componentId).size() == 0) {
			return false;
		}

		return true;
	}

	/**
	 * Returns true if the target schema version is 1.0 or 2.0 and the attachment level is to a group of dimensions, which is also already defined by a group
	 * @param attr
	 * @return
	 */
	boolean skipAttribute(AttributeBean attr) {
		if(targetSchemaVersion == SDMX_SCHEMA.VERSION_ONE || targetSchemaVersion == SDMX_SCHEMA.VERSION_TWO) {
			if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
				//If the group of dimensions is also a group, do not create the attribute;
				List<String> dimensionReferences = attr.getDimensionReferences();
				for(GroupBean grp : dsd.getBuiltFrom().getGroups()) {
					if(grp.getDimensionRefs().containsAll(dimensionReferences) &&
							dimensionReferences.containsAll(grp.getDimensionRefs())) {
						return true;
					}
				}
			}
		}
		return false;
	}

	void writeGroupAttributes(GroupSuperBean group) throws XMLStreamException {
		for (DimensionSuperBean dim : group.getDimensions()) {
			writer.writeStartElement(SCHEMA_NS, "attribute");
			writer.writeAttribute("name", dim.getConcept().getId());
			if(dim.getCodelist(true) != null) {
				writer.writeAttribute("type", getCodelistReference(dim));
			} else {
				writer.writeAttribute("type", dim.getId());
				//				writer.writeAttribute("type", "xs:string");
			}
			writer.writeAttribute("use", "required");
			writer.writeEndElement();   // End Attribute
		}

		//For all versions attach any dimension group attributes to the group
		for (AttributeSuperBean bean : dsd.getGroupAttributes(group.getId(), true)) {
			addGroupAttributeBean(bean);
		}
	}

	void addGroupAttributeBean(AttributeSuperBean attributeBean) throws XMLStreamException {
		addComponentBean(attributeBean);
		if(attributeBean.getBuiltFrom().isMandatory()) {
			writer.writeAttribute("use", "required");
		} else {
			writer.writeAttribute("use", "optional");
		}
		writer.writeEndElement();   // End Attribute
	}

	/**
	 * All attributes are optional
	 * @param attributeBean
	 * @throws XMLStreamException
	 */
	void addAttribute(AttributeSuperBean attributeBean) throws XMLStreamException {
		addComponentBean(attributeBean);
		if(attributeBean.getBuiltFrom().isMandatory()) {
			writer.writeAttribute("use", "required");
		} else {
			writer.writeAttribute("use", "optional");
		}
		writer.writeEndElement();   // End Attribute
	}

	
	void addComponentBean(ComponentSuperBean componentBean) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "attribute");
		if(targetSchemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE || targetSchemaVersion == SDMX_SCHEMA.VERSION_THREE) {
			writer.writeAttribute("name", componentBean.getId());
		} else {
			writer.writeAttribute("name", componentBean.getConcept().getId());
		}
		String type = determineSchemaType(componentBean);
		writer.writeAttribute("type", type);
	}
	
	String determineSchemaType(ComponentSuperBean<ComponentBean> componentBean) {
		if(componentBean.getBuiltFrom().getStructureType() == SDMX_STRUCTURE_TYPE.TIME_DIMENSION) {
			return determineSchemaType(null, TEXT_TYPE.OBSERVATIONAL_TIME_PERIOD);//not in v2 or 1
		} else if(componentBean.getCodelist(true) == null) {
			return determineAttributeType(componentBean);
		} 
		return getCodelistReference(componentBean);
	}

	private String determineAttributeType(ComponentSuperBean<ComponentBean> componentBean) {
		// FR-772: Any attribute with a text format, use it's Id
		if(componentBean.getTextFormat() != null ) {
			//		if(componentBean.getTextFormat() != null && componentBean.getTextFormat().hasRestrictions()) {
			return componentBean.getId();
		}
		return "xs:string";
	}

	protected String determineSchemaType(TextFormatBean tf, TEXT_TYPE textType) {
	    // FR-4599: NPE defence
	    if (textType == null) {
	        return "xs:string";
	    }

		String attrType;
		switch(textType) {
		case ALPHA :
			attrType = "common:AlphaType";
			break;
		case ALPHA_NUMERIC:
			attrType = "common:AlphaNumericType";
			break;
		case BASIC_TIME_PERIOD:
			attrType = "common:BasicTimePeriodType";
			break;
		case BIG_INTEGER:
			attrType = "xs:integer";
			break;
		case BOOLEAN:
			attrType = "xs:boolean";
			break;
		case COUNT:
			attrType = "xs:integer";
			break;
//		case DATE:
//			attrType = "xs:date";
//			break;
		case DATE_TIME:
			attrType = "xs:dateTime";
			break;
		case DAY:
			attrType = "xs:gDay";
			break;
		case DECIMAL:
			attrType = "xs:decimal";
			break;
		case DOUBLE:
			attrType = "xs:double";
			if(tf != null && tf.getDecimals() != null) {
				//FR-1598 Exported Schema contains fractionDigits for OBS_VALUE which is not allowed
				attrType = "xs:decimal";
			}
			break;
		case DURATION:
			attrType = "xs:duration";
			break;
		case EXCLUSIVE_VALUE_RANGE:
			attrType = "xs:decimal";
			break;
		case FLOAT:
			attrType = "xs:float";
			break;
		case GREGORIAN_DAY:
			attrType = "xs:date";
			break;
		case GREGORIAN_TIME_PERIOD:
			attrType = "common:GregorianTimePeriodType";
			break;
		case GREGORIAN_YEAR:
			attrType = "xs:gYear";
			break;
		case GREGORIAN_YEAR_MONTH:
			attrType = "xs:gYearMonth";
			break;
		case INCLUSIVE_VALUE_RANGE:
			attrType = "xs:decimal";
			break;
		case INCREMENTAL:
			attrType = "xs:decimal";
			break;
		case INTEGER:
			attrType = "xs:int";
			break;
		case LONG:
			attrType = "xs:long";
			break;
		case MONTH:
			attrType = "xs:gMonth";
			break;
		case MONTH_DAY:
			attrType = "xs:gMonthDay";
			break;
		case NUMERIC:
			attrType = "common:NumericType";
			break;
		case OBSERVATIONAL_TIME_PERIOD:
			if (targetSchemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
				attrType = "common:ObservationalTimePeriodType";
			} else {
				attrType = "common:TimePeriodType";
			}
			break;
		case REPORTING_DAY:
			attrType = "common:ReportingDayType";
			break;
		case REPORTING_MONTH:
			attrType = "common:ReportingMonthType";
			break;
		case REPORTING_QUARTER:
			attrType = "common:ReportingQuarterType";
			break;
		case REPORTING_SEMESTER:
			attrType = "common:ReportingSemesterType";
			break;
		case REPORTING_TIME_PERIOD:
			attrType = "common:ReportingTimePeriodType";
			break;
		case REPORTING_TRIMESTER:
			attrType = "common:ReportingTrimesterType";
			break;
		case REPORTING_WEEK:
			attrType = "common:ReportingWeekType";
			break;
		case REPORTING_YEAR:
			attrType = "common:ReportingYearType";
			break;
		case SHORT:
			attrType = "xs:short";
			break;
		case STANDARD_TIME_PERIOD:
			attrType = "common:StandardTimePeriodType";
			break;
		case STRING:
			attrType = "xs:string";
			break;
		case TIME:
			attrType = "xs:time";
			break;
//		case TIMESPAN:
//			attrType = "xs:duration";
//			break;
//		case TIMES_RANGE:
//			attrType = "common:TimeRangeType";
//			break;
//		case TIME_PERIOD:
//			attrType = "common:TimePeriodRangeType";
//			break;
		case URI:
			attrType = "xs:anyURI";
			break;
		case XHTML:
			attrType = "common:StructuredTextValueType";
			break;
//		case YEAR:
//			attrType = "xsd:gYear";
//			break;
//		case YEAR_MONTH:
//			attrType = "xs:gYearMonth";
//			break;
		default:
			attrType = "xs:string";
		}
		return attrType;
	}

	void addTextFormat(TextFormatBean tx) throws XMLStreamException {
		if(tx.getDecimals() != null) {
			writer.writeStartElement(SCHEMA_NS, "fractionDigits");
			writer.writeAttribute("value", tx.getDecimals().toString());
			writer.writeEndElement();
		}
		if(tx.getEndTime() != null) {
			// The restriction type must be xs:date
			writer.writeStartElement(SCHEMA_NS, "maxInclusive");
			writer.writeAttribute("value", tx.getEndTime().toString());
			writer.writeEndElement();
		}
		if(tx.getEndValue() != null) {
			writer.writeStartElement(SCHEMA_NS, "maxInclusive");
			writer.writeAttribute("value", tx.getEndValue().toString());
			writer.writeEndElement();
		}
		if(tx.getInterval() != null) {
		}
		if(tx.getMaxLength() != null) {
			//FR-772 The generated XSD in the Global Registry are not valid with regards to the schema standard (A double can only have a max value, not a max length.)
			if(tx == null ||
					tx.getTextType() == TEXT_TYPE.STRING ||
					tx.getTextType() == TEXT_TYPE.ALPHA ||
					tx.getTextType() == TEXT_TYPE.ALPHA_NUMERIC) {
				writer.writeStartElement(SCHEMA_NS, "maxLength");
				writer.writeAttribute("value", tx.getMaxLength().toString());
				writer.writeEndElement();
			}
		}
		if(tx.getMaxValue() != null) {
			writer.writeStartElement(SCHEMA_NS, "maxInclusive");
			writer.writeAttribute("value", tx.getMaxValue().toString());
			writer.writeEndElement();
		}

		if(tx.getMinLength() != null) {
			//FR-772 The generated XSD in the Global Registry are not valid with regards to the schema standard (A double can only have a max value, not a max length.)
			if(tx == null ||
					tx.getTextType() == TEXT_TYPE.STRING ||
					tx.getTextType() == TEXT_TYPE.ALPHA ||
					tx.getTextType() == TEXT_TYPE.ALPHA_NUMERIC) {
				writer.writeStartElement(SCHEMA_NS, "minLength");
				writer.writeAttribute("value", tx.getMinLength().toString());
				writer.writeEndElement();
			}
		}
		if(tx.getMinValue() != null) {
			writer.writeStartElement(SCHEMA_NS, "minInclusive");
			writer.writeAttribute("value", tx.getMinValue().toString());
			writer.writeEndElement();
		}
		if(tx.getPattern() != null) {
			writer.writeStartElement(SCHEMA_NS, "pattern");
			writer.writeAttribute("value", tx.getPattern());
			writer.writeEndElement();
		}
		if(tx.getStartTime() != null) {
			// The restriction type must be xs:date
			writer.writeStartElement(SCHEMA_NS, "minInclusive");
			writer.writeAttribute("value", tx.getStartTime().toString());
			writer.writeEndElement();
		}
		if(tx.getStartValue() != null) {
			writer.writeStartElement(SCHEMA_NS, "minInclusive");
			writer.writeAttribute("value", tx.getStartValue().toString());
			writer.writeEndElement();
		}
		if(tx.getTimeInterval() != null) {
		}
	}

	void addAnnotations() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Annotations");
		writer.writeAttribute("type", "common:AnnotationsType");
		writer.writeAttribute("minOccurs", "0");
		writer.writeEndElement();   // End Element
	}

	void addChoice(int xsdType, String minOccurs, String maxOccurs) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "choice");
		// Only need "minOccurs" if Compact, not Utility
		if (xsdType == COMPACT)
			writer.writeAttribute("minOccurs", minOccurs);
		writer.writeAttribute("maxOccurs", maxOccurs);
	}

	void addComplexType(String name, String extensionBaseName) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "complexType");
		writer.writeAttribute("name", name);

		writer.writeStartElement(SCHEMA_NS, "complexContent");
		writer.writeStartElement(SCHEMA_NS, "extension");
		writer.writeAttribute("base", extensionBaseName);
	}
	

	void addComplexTypeForRestriction(String name, String restrictionBaseName) throws XMLStreamException {
		addComplexTypeForRestriction(name, restrictionBaseName, true);
	}

	void addComplexTypeForRestriction(String name, String restrictionBaseName, boolean isComplexContent) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "complexType");
		writer.writeAttribute("name", name);

		writer.writeStartElement(SCHEMA_NS, isComplexContent ? "complexContent" : "simpleContent");
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", restrictionBaseName);
	}

	void endComplexType(XMLStreamWriter writer) throws XMLStreamException {
		writer.writeEndElement();	// End extension
		writer.writeEndElement();	// End ComplexContent
		writer.writeEndElement();   // End ComplexType
	}

	void addElement(String name, String type) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", name);
		writer.writeAttribute("type", type);
		writer.writeEndElement();
	}

	void addElement(String name, String type, String substitutionGroup) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", name);
		writer.writeAttribute("type", type);
		if (substitutionGroup != null) {
			writer.writeAttribute("substitutionGroup", substitutionGroup);
		}
		writer.writeEndElement();
	}

	void processCodelist(EnumeratedListBean<EnumeratedItemBean> codelist, ComponentSuperBean component) throws XMLStreamException {
		processCodelist(codelist, component, "xs:string");
	}
	
	void processCodelist(EnumeratedListBean<EnumeratedItemBean> codelist, ComponentSuperBean component, String restrictionBase) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "simpleType");
		writer.writeAttribute("name", getCodelistReference(component));
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", "xs:string");
		String componentId = component.getId();
		for(EnumeratedItemBean code : codelist.getItems()) {
			processCode(componentId, code);
		}
		writer.writeEndElement();	// End restriction
		writer.writeEndElement();	// End simpleType
	}

	void processUncodedWithRestriction(String componentId, TextFormatBean tx) throws XMLStreamException {
		if (tx == null || tx.getTextType() == null) {
			return;
		}
		writer.writeStartElement(SCHEMA_NS, "simpleType");
		writer.writeAttribute("name", componentId);
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", determineSchemaType(tx, tx.getTextType()));
		addTextFormat(tx);
		writer.writeEndElement();	// End restriction
		writer.writeEndElement();	// End simpleType
	}

	protected String getCodelistReference(ComponentSuperBean component) {
		if(this.isConstrained(component.getId())) {
			return "CL_"+component.getId();
		}
		EnumeratedListBean<EnumeratedItemBean> codelist = component.getCodelist(true);
		String version = codelist.getVersion().toString().replaceAll("\\.", "_");
        return codelist.getAgencyId() + "." + codelist.getId() + "." + version;
	}

	void processCode(String componentId, EnumeratedItemBean code) throws XMLStreamException {
		boolean validForOutput = true;
		if(validCodeMap != null) {
			Set<String> validCodes = validCodeMap.get(componentId);
			if(validCodes != null) {
				validForOutput = validCodes.contains(code.getId());
			}
		}

		if(validForOutput) {
			writer.writeStartElement(SCHEMA_NS, "enumeration");
			writer.writeAttribute("value", code.getId());
			writer.writeStartElement(SCHEMA_NS, "annotation");
			for(TextTypeWrapper tt : code.getDescriptions()) {
				writer.writeStartElement(SCHEMA_NS, "documentation");
				writer.writeAttribute("xml:lang", tt.getLocale());
				writer.writeCharacters(tt.getValue());
				writer.writeEndElement();	// End Documentation
			}
			writer.writeEndElement();  // End Annotation
			writer.writeEndElement();  // End Enumeration
		}
	}

	void close() {
		try {
			if(writer != null) {
				writer.writeEndDocument();
				writer.flush();
				writer.close();
			}
		} catch (XMLStreamException e) {
			throw new RuntimeException("Error trying to close parser : " + e);
		}
	}
}
