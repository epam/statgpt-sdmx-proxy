package io.sdmx.format.ml.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.VersionableBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.TextTypeWrapperMutableBean;
import io.sdmx.im.mutable.base.TextTypeWrapperMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class StaxStructureUtil {
	
	public static void throwUnexpectedNodeException(IStaxReader staxReader) {
		throw new SdmxSemmanticException("Unexpected XML element : " + staxReader.getXMLPath());
	}
	
	public static void checkStartNode(IStaxReader staxReader, String expectedNode) {
		if(!staxReader.isStartElement()) {
			throw new SdmxSemmanticException("Missing expected XML element : " + expectedNode);
		}
		if(!staxReader.getElementName().equals(expectedNode)) {
			throw new SdmxSemmanticException("Unexpected XML element : " + staxReader.getXMLPath()  + ". Expected XML element: " + expectedNode);
		}
	}

	public static boolean getAttributeAsBoolean(Map<String, String> attributes, String attributeId, boolean isMandatory, boolean defaultValue) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return Boolean.valueOf(asString);
		}
		return defaultValue;
	}
	
	public static TERTIARY_BOOL getAttributeAsTeritaryBoolean(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return TERTIARY_BOOL.parseBoolean(Boolean.valueOf(asString));
		}
		return TERTIARY_BOOL.UNSET;
	}

	public static TEXT_TYPE getAttributeAsTextType(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return TEXT_TYPE.parseString(asString);
		}
		return null;
	}
	
	public static BigInteger getAttributeAsBigInteger(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return new BigInteger(asString);
		}
		return null;
	}
	
	public static Integer getAttributeAsInteger(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			if(asString.equals("unbounded")) {
				return null;
			}
			return Integer.parseInt(asString);
		}
		return null;
	}
	
	public static BigDecimal getAttributeAsBigDecimal(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return new BigDecimal(asString);
		}
		return null;
	}
	
	
	public static Date getAttributeAsDate(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String asString = getAttribute(attributes, attributeId, isMandatory);
		if(asString != null) {
			return DateUtil.formatDate(asString, true);
		}
		return null;
	}

	public static String getAttribute(Map<String, String> attributes, String attributeId, boolean isMandatory) {
		String attr = attributes.get(attributeId);
		
		if(isMandatory && !ObjectUtil.validString(attr)) {
			throw new SdmxSemmanticException("Missing mandatory attribute: " + attributeId);
		}
		if(attr != null && attr.length() == 0 ){
			return null;
			//throw new SdmxSemmanticException("Attribute value is missing: " + attributeId);
		}
		return attr;
	}
	
	public static TextTypeWrapperMutableBean getText(IStaxReader staxReader) {
		return new TextTypeWrapperMutableBeanImpl(getLangLocale(staxReader), staxReader.getElementText());
	}
	
	
	/**
	 * <root-node>
	 *    <Ref></Ref>
	 *    <URN></URN>
	 * </root-node>
	 * @param staxReader
	 * @param targetStructure
	 * @return
	 */
	public static StructureReferenceBean getStructureReference(IStaxReader staxReader, SDMX_STRUCTURE_TYPE targetStructure) {
		String exitNode = staxReader.getElementName();
		
		staxReader.moveNextStartNode();
		String element = staxReader.getElementName();
		if(element.equals("Ref")) {
			Map<String, String> attributes = staxReader.getAttributes();
			
			String agencyId = getAttribute(attributes, "agencyID", true);
			
			String maintId = getAttribute(attributes, "maintainableParentID", targetStructure != null && !targetStructure.isMaintainable());
			String version = getAttribute(attributes, "version", false);
			String[] identifiableId=null;
			if(maintId == null) {
				maintId = getAttribute(attributes, "id", true);
			} else {
				//Identifiable
				version = getAttribute(attributes, "maintainableParentVersion", false);
				String containerId = getAttribute(attributes, "ContainerID", false);
				String id = getAttribute(attributes, "id", true);
				if (id == null) {
				    throw new SdmxSemmanticException("Attribute value of 'id' is missing");
				}
				if(containerId != null) {
					String[] idArr = id.split("\\.");
					identifiableId = new String[idArr.length+1];
					identifiableId[0] = containerId;
					for(int i = 0; i < idArr.length ; i++) {
						identifiableId[i+1] = idArr[i];
					}
				} else {
					identifiableId = id.split("\\.");
				}
			}
			String refClass =  getAttribute(attributes, "class", false); 
			String refPackage = getAttribute(attributes, "package", false);
			if(refClass  != null) {
				if(refPackage != null) {
					targetStructure = SDMX_STRUCTURE_TYPE.parsePackageAndClass(refPackage, refClass);
				} else {
					targetStructure = SDMX_STRUCTURE_TYPE.parseClass(refClass);
				}
			}
			if(version == null) {
				version = VersionableBean.DEFAULT_VERSION;
			}
			staxReader.skipToEndNode(exitNode);
			return new StructureReferenceBeanImpl(agencyId, maintId, version, targetStructure, identifiableId);
		} else if(element.equals("URN")) {
			String urn = staxReader.getElementText();
			staxReader.skipToEndNode(exitNode);
			return new StructureReferenceBeanImpl(urn);
		} else {
			throwUnexpectedNodeException(staxReader);
		}
		return null;
	}
	
	public static String getLocalReference(IStaxReader staxReader) {
		String exitNode = staxReader.getElementName();
		staxReader.moveNextStartNode();
		String id = null;
		if(staxReader.getElementName().equals("Ref")) {
			id = getAttribute(staxReader.getAttributes(), "id", true);
		} else {
			throwUnexpectedNodeException(staxReader);
		}
		staxReader.skipToEndNode(exitNode);
		return id;
	}
	
	public static String getLangLocale(IStaxReader staxReader) {
		String lang = staxReader.getAttributes().get("lang");
		if(!ObjectUtil.validString(lang)) {
			lang = "en";
		}
		return lang;
	}
}
