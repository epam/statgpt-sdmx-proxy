package io.sdmx.format.ml.engine.structure.reader.v21.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataProviderSchemeReaderEngineV21 extends StaxAbstractOrgansiationReaderV21 {
	private static StaxDataProviderSchemeReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataProviderSchemeReaderEngineV21() {}

	public static StaxDataProviderSchemeReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataProviderSchemeReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public DataProviderSchemeMutableBean processMaintainable(IStaxReader reader) {
		DataProviderSchemeMutableBean dpScheme = new DataProviderSchemeMutableBeanImpl();
		StaxItemSchemeUtil.processBean(dpScheme, reader);

		//Expected position is now Agency
		String elementName = reader.getElementName();
		while(reader.isStartElement()) {
			if(!elementName.equals("DataProvider")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			processDataProvider(dpScheme, reader);
			reader.moveNextNode();
		}
		return dpScheme;
	}

	private void processDataProvider(DataProviderSchemeMutableBean beanToPopulate, IStaxReader reader) {
		DataProviderMutableBean provider = new DataProviderMutableBeanImpl();
		beanToPopulate.addItem(provider);
		super.processOrganisation(provider, reader);
	}
}
