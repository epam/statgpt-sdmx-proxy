package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMaintainableWriterUtilV3 {

	public static void writeBean(MaintainableBean maint, String elementName, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeBean(maint, elementName, externalLinks, writer, null);
	}

	public static void writeBean(MaintainableBean maint, String elementName, IExternalMaintainableLinks externalLinks, StaxWriter writer, Map<String, String> attributes) {
		if(attributes != null) {
			attributes.putAll(StaxIdentifiableWriterUtilV3.getAttributes(maint));
		} else {
			attributes = StaxIdentifiableWriterUtilV3.getAttributes(maint);
		}
		if(maint instanceof ItemSchemeBean) {
			ItemSchemeBean itemScheme = (ItemSchemeBean)maint;
			if(itemScheme.isPartial()) {
				attributes.put("isPartial", Boolean.toString(itemScheme.isPartial()));
			}
		}
		if(!maint.isFixedVersion()) {
			attributes.put("version", maint.getVersion().toString());
		}
		attributes.put("agencyID", maint.getAgencyId());

		// Always write the values of isFinal and isExternalReference
		attributes.put("isExternalReference", Boolean.toString(maint.isExternalReference()));

		if(maint.hasValidityPeriod()) {
			if(maint.getValidityPeriod().hasStartPeriod()) {
				attributes.put("validFrom", maint.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
			}
			if(maint.getValidityPeriod().hasEndPeriod()) {
				attributes.put("validTo", maint.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
			}
		}
		if(maint.getStructureURL() != null) {
			attributes.put("structureURL", maint.getStructureURL().toString());
		}
		if(maint.getServiceURL() != null) {
			attributes.put("serviceURL", maint.getServiceURL().toString());
		}
		writer.writeElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName, attributes);
		StaxNameableWriterUtilV3.writeBean(maint, externalLinks, writer);
	}

}
