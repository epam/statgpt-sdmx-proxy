package io.sdmx.format.ml.factory.schema;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.factory.ISchemaFormatFactory;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * When the response format is for an XSD
 */
public class SdmxXSDSchemaFormatFactory implements ISchemaFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();
	
	private static SdmxXSDSchemaFormatFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxXSDSchemaFormatFactory() {
		addSupportedFormat("application/vnd.sdmx.schema+xml;version=3.0.0", SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0));
		addSupportedFormat("application/vnd.sdmx.schema+xml;version=2.1", SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_1));
		addSupportedFormat("application/vnd.sdmx.schema+xml;version=2.0", SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_0));
		addSupportedFormat("application/vnd.sdmx.schema+xml;version=1.0", SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V1_0));
	}
	
	private void addSupportedFormat(String vnd, SchemaFormat format) {
		supportedFormats.put(vnd, format.getFormatDetails());
	}

	public static SdmxXSDSchemaFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxXSDSchemaFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxXSDSchemaFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Class<SchemaFormat> getFormatClass() {
		return SchemaFormat.class;
	}
	


	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	@Override
	public SchemaFormat getFormat(String format, Request request) {
		if(format.startsWith("sdmx")) {
			switch(format) {
			case "sdmx-1.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V1_0);
			case "sdmx-2.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_0);
			case "sdmx-2.1" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_1);
			case "sdmx-3.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
			}
		}
		return null;
	}
    
	@Override
	/**
	 * Supports
	 *  application/vnd.sdmx.schema+xml;version=3.0.0
	 *  application/vnd.sdmx.schema+xml;version=2.1
	 *  application/vnd.sdmx.schema+xml;version=1.0
	 */
	public SchemaFormat getFormat(Request req,  IVNDHeader vnd) {
		if(vnd.getVnd().equals("sdmx.schema+xml")) {
			String version = vnd.getParameterValue("version");
			if(version == null) {
				version = "3.0.0";
			}
			switch(version) {
			case "1.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V1_0);
			case "2.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_0);
			case "2.1" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_1);
			case "3.0.0" :
				return SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
			}
		}
	    return null;
	}
	
	@Override
	public int getPriority() {
		// FR11-3
		// This class has a low priority to give other factories a chance to be processed before it
		return 10;
	}
}
