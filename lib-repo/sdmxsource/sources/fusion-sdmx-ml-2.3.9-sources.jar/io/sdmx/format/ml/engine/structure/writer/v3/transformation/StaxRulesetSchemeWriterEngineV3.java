package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRulesetSchemeWriterEngineV3 extends StaxAbstractVTLSchemeWriterEngineV3<IRulesetSchemeBean> implements IFusionSingleton {
	private static StaxRulesetSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRulesetSchemeWriterEngineV3() {}
	public static StaxRulesetSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRulesetSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "RulesetScheme";
	}
	
	@Override
	protected void writeMaintainableInternal(IRulesetSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtilV3.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
	}

	private void writeItems(List<IRulesetBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(IRulesetBean item : items) {
			Map<String, String> attributes = new HashMap<>();
			if(item.getRulesetType() != null) {
				attributes.put("rulesetType", item.getRulesetType());
			}
			if(item.getRulesetScope() != null) {
				attributes.put("rulesetScope", item.getRulesetScope());
			}
			StaxNameableWriterUtilV3.writeBean(item, "Ruleset", externalLinks, writer, attributes);
			if(item.getRulesetDefinition() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "RulesetDefinition", item.getRulesetDefinition());
			}
			writer.writeEndElement();
		}
	}
}
