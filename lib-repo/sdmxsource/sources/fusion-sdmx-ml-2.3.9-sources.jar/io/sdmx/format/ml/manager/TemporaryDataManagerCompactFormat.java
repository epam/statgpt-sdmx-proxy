package io.sdmx.format.ml.manager;

import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.core.sdmx.api.engine.data.ITemporaryDataWriterEngine;
import io.sdmx.core.sdmx.api.manager.data.ITemporaryDataManager;
import io.sdmx.core.sdmx.engine.data.RolldownDataWriterEngine;
import io.sdmx.core.sdmx.engine.data.TemporaryDataWriterEngine;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.format.ml.engine.data.reader.CompactDataReaderEngine;
import io.sdmx.format.ml.engine.data.writer.CompactDataWriterEngine;
import io.sdmx.utils.core.application.FusionSystem;

/**
 * Writes the data in compact format so that it can be stored temporarily and read at a a later date
 */
@Deprecated //To support SDMX 3.0 use cases use TemporaryDataManagerCSVFormat
public class TemporaryDataManagerCompactFormat implements ITemporaryDataManager {
	
	@Override
	public ITemporaryDataWriterEngine getDataWriterEngine() {
		WriteableDataLocation wdl = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation(FILE_FORMAT.XML);
		DataWriterEngine dwe = new CompactDataWriterEngine(SDMX_SCHEMA.VERSION_TWO_POINT_ONE, wdl.getOutputStream(), false);
		return new TemporaryDataWriterEngine(new RolldownDataWriterEngine(dwe), wdl);
	}

	@Override
	public DataReaderEngine getDataReaderEngine(ITemporaryDataWriterEngine writer) {
		SdmxBeanRetrievalManager brm = new InMemoryRetrievalManager(writer.getWrittenStructures());
		return new CompactDataReaderEngine(writer.getReadableDataLocation(), brm, null, null, null, null);
	}

	@Override
	public void close(ITemporaryDataWriterEngine writer) {
		writer.getReadableDataLocation().close();
	}

}
