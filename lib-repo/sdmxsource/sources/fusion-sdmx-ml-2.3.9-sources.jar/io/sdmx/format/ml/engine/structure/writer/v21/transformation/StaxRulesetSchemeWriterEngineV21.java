package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.transformation.IRulesetBean;
import io.sdmx.api.sdmx.model.beans.transformation.IRulesetSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRulesetSchemeWriterEngineV21 extends StaxAbstractVTLSchemeWriterEngineV21<IRulesetSchemeBean> implements IFusionSingleton {
	private static StaxRulesetSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRulesetSchemeWriterEngineV21() {}
	public static StaxRulesetSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRulesetSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "RulesetScheme";
	}
	@Override
	protected void writeMaintainableInternal(IRulesetSchemeBean maint, StaxWriter writer) {
		writeItems(maint.getItems(), writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtil.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
	}

	private void writeItems(List<IRulesetBean> items, StaxWriter writer) {
		for(IRulesetBean item : items) {
			Map<String, String> attributes = new HashMap<>();
			if(item.getRulesetType() != null) {
				attributes.put("rulesetType", item.getRulesetType());
			}
			if(item.getRulesetScope() != null) {
				attributes.put("rulesetScope", item.getRulesetScope());
			}
			StaxNameableWriterUtil.writeBean(item, "Ruleset", writer, attributes);
			if(item.getRulesetDefinition() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "RulesetDefinition", item.getRulesetDefinition());
			}
			writer.writeEndElement();
		}
	}
}
