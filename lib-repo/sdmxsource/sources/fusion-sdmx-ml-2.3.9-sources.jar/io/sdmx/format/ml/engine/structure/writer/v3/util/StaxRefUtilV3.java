package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRefUtilV3 {

	public static void writeLocalReference(String id, StaxWriter writer, String elementName) {
		if(!ObjectUtil.validString(id)) {
			return;
		}
		writer.writeElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName, id);
	}

	public static void writeReference(IURN<?> crossReference, StaxWriter writer) {
		writeReference(crossReference, writer, null);
	}
	public static void writeReference(ICrossReferenceBean<?> crossReference, StaxWriter writer) {
		writeReference(crossReference, writer, null);
	}
	public static void writeReferences(List<? extends ICrossReferenceBean<?>> refs, StaxWriter writer, String elementName) {
		for(ICrossReferenceBean<?> ref : refs) {
			writeReference(ref, writer, elementName);
		}
	}

//	public static void writeReferences(List<? extends IURN<?>> refs, StaxWriter writer, String elementName) {
//		for(IURN<?> ref : refs) {
//			writeReference(ref, writer, elementName);
//		}
//	}
	
	public static void writeReference(ICrossReferenceBeanBase crossReference, StaxWriter writer, String elementName) {
		if(crossReference == null) {
			return;
		}
		writeReference(crossReference.getReference(), writer, elementName);
	}

	public static void writeReference(IURN<?> crossReference, StaxWriter writer, String elementName) {
		if(crossReference == null) {
			return;
		}
		writer.writeElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName, crossReference.getURN());
	}
}
