package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Generates a Compact Schema for SDMX 1.0 and SDMX 2.0
 */
public class CompactSchemaCreatorSdmx extends CompactSchemaCreator {
    private static final Logger LOG = LoggerFactory.getLogger(CompactSchemaCreatorSdmx.class);
    private SDMX_SCHEMA targetSchemaVersion;
    
    
    public CompactSchemaCreatorSdmx(ConstrainedCodes constrainedCodes, String dimensionAtObservation, 
    		String schemaLocation, 
    		SDMX_SCHEMA targetSchemaVersion, OutputStream out, boolean prettyPrint) {
		super(constrainedCodes, dimensionAtObservation, schemaLocation, out, prettyPrint);
		this.targetSchemaVersion = targetSchemaVersion;
	}
	
	@Override
	public void createSchema() {
		LOG.info("Generating Schema: " + targetSchemaVersion + (generatingCrossSectional ? " - cross sectional" : "") );
		super.createSchema();
	}
	
	@Override
	protected void writeSchemaInformation() { 
		targetNamespace = srb.getTargetUrn() + ":compact";
		init(out, COMPACT, targetNamespace, targetSchemaVersion, dsd);
	}
	
	@Override
	protected void writeDataset() throws Exception {
		addElement("DataSet",  "DataSetType",  "compact:DataSet");

		addComplexContentRoot("DataSetType", "TimeSeriesDataSetType");

		addChoice(COMPACT, "0", "unbounded");    // Start Choice

		// Add each group
		for(GroupSuperBean currentGroup : dsd.getGroups()) {
			// Write a group element
			writer.writeStartElement(SCHEMA_NS, "element");
			writer.writeAttribute("ref", currentGroup.getId());
			writer.writeEndElement();	
		}

		// Write a series element
		writer.writeStartElement(SCHEMA_NS, "element");    // Start Element
		writer.writeAttribute("ref", "Series");
		writer.writeEndElement();	                       // End Element

		addAnnotations();

		writer.writeEndElement();               // End Choice

		for(DimensionSuperBean bean : dsd.getDimensions()) {
			addOptionalDimensionBean(bean);
		}
		for(AttributeSuperBean bean : dsd.getDatasetAttributes()) {
			addAttributeBean(bean);
		}

		endComplexType(writer);
	}
	
	@Override
	protected void writeGroups() throws Exception {
		for(GroupSuperBean currentGroup : dsd.getGroups()) {
			addElement(currentGroup.getId(), currentGroup.getId() + "Type", "compact:Group");

			addComplexType(currentGroup.getId() + "Type", "compact:GroupType");

			writer.writeStartElement(SCHEMA_NS, "sequence");   // Start Sequence
			addAnnotations();
			writer.writeEndElement();	                       // End Sequence

			writeGroupAttributes(currentGroup);

			endComplexType(writer);
		}
	}
	
	@Override
	protected void writeSeries() throws Exception {
		addElement("Series", "SeriesType", "compact:Series");

		addComplexContentRoot("SeriesType", "TimeSeriesType");

		writer.writeStartElement(SCHEMA_NS, "sequence");   // Start Sequence

		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("ref", "Obs");
		writer.writeAttribute("minOccurs", "0");
		writer.writeAttribute("maxOccurs", "unbounded");
		writer.writeEndElement();
		addAnnotations();

		writer.writeEndElement();                          // End Sequence
		
		for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.TIME_DIMENSION)) {
			addOptionalDimensionBean(bean);
		}

		for(AttributeSuperBean attr : dsd.getSeriesAttributes()) {
			//For version 1.0 and 2.0 messages, dimension group attribtues are attached to the group
			if(!skipAttribute(attr.getBuiltFrom())) {
				addComponentBean(attr);	
				writer.writeAttribute("use", "optional");
				writer.writeEndElement();
			}
		}

		endComplexType(writer);
	}
	
	@Override
	protected void writeObservations() throws Exception {
		addElement("Obs", "ObsType",  "compact:Obs");

		addComplexContentRoot("ObsType", "TimeSeriesObsType");

		writer.writeStartElement(SCHEMA_NS, "sequence");   // Start Sequence
		addAnnotations();
		writer.writeEndElement();	                       // End Sequence

		// If Cross-Sectional add the cross-sectional dimension now
		if (generatingCrossSectional) {
			addRequiredDimensionBean(crossSectionDimension);
		}

		if (dsd.getMeasure(PrimaryMeasureBean.FIXED_ID) != null) {
			addOptionalDimensionBean(dsd.getMeasure(PrimaryMeasureBean.FIXED_ID));
		}

		// Add the time dimension
		if (dsd.getTimeDimension() != null) {
			addOptionalDimensionBean(dsd.getTimeDimension());
		}
		
		for(AttributeSuperBean bean : dsd.getObservationAttributes()) {
			addComponentBean(bean);		
			writer.writeAttribute("use", "optional");
			writer.writeEndElement();
		}

		endComplexType(writer);
	}
	
	@Override
	protected void addComplexContentRoot(String type, String type_2_1) throws Exception {
		addComplexType(type, "compact:" + type);
	}
}
