package io.sdmx.format.ml.api.engine;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.xml.IStaxReader;

public interface StaxMaintainableReaderEngine<T extends MaintainableMutableBean> {
	
    /**
     * Reads the structures and adds them to the beans container
     * @param reader to read the XML
     * @param beans to add to
     * @param builder used to build the maintainable from the mutable, and add to the container
     */
	void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder);
	
	/**
	 * @return not null, the XML element that contains the list of objects of the given type
	 */
	String getContainerNodeName();
}
