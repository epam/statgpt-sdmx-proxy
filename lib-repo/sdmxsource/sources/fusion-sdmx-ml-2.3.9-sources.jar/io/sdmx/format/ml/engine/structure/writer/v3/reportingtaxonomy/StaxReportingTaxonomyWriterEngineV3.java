package io.sdmx.format.ml.engine.structure.writer.v3.reportingtaxonomy;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxReportingTaxonomyWriterEngineV3 extends AbstractV3Writer<ReportingTaxonomyBean> implements IFusionSingleton {
	private static StaxReportingTaxonomyWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxReportingTaxonomyWriterEngineV3() {}

	public static StaxReportingTaxonomyWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxReportingTaxonomyWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ReportingTaxonomy";
	}

	@Override
	protected void writeMaintainableInternal(ReportingTaxonomyBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeCategories(maint.getItems(), externalLinks, writer);
	}

	private void writeCategories(List<ReportingCategoryBean> categories, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ReportingCategoryBean cat : categories) {
			StaxNameableWriterUtilV3.writeBean(cat, "ReportingCategory", externalLinks, writer);
			writeCategories(cat.getItems(), externalLinks, writer);
			StaxRefUtilV3.writeReferences(cat.getStructuralMetadata(), writer, "StructuralMetadata");
			StaxRefUtilV3.writeReferences(cat.getProvisioningMetadata(), writer, "ProvisioningMetadata");
			writer.writeEndElement(); //End ReportingCategory
		}
	}
}
