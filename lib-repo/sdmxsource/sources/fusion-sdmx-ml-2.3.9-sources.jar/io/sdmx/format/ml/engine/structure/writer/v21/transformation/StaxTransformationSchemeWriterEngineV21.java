package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationBean;
import io.sdmx.api.sdmx.model.beans.transformation.ITransformationSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxTransformationSchemeWriterEngineV21 extends StaxAbstractVTLSchemeWriterEngineV21<ITransformationSchemeBean> implements IFusionSingleton {
	private static StaxTransformationSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxTransformationSchemeWriterEngineV21() {}

	public static StaxTransformationSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxTransformationSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "TransformationScheme";
	}
	@Override
	protected void writeMaintainableInternal(ITransformationSchemeBean maint, StaxWriter writer) {
		writeItems(maint.getItems(), writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtil.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
		if(maint.getNamePersonalisationSchemeRef() != null) {
			StaxRefUtil.writeReference(maint.getNamePersonalisationSchemeRef(), writer, "NamePersonalisationScheme");
		}
		if(maint.getCustomTypeSchemeRef() != null) {
			StaxRefUtil.writeReference(maint.getCustomTypeSchemeRef(), writer, "CustomTypeScheme");
		}
		if(maint.getRulesetSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getRulesetSchemeRef()) {
				StaxRefUtil.writeReference(ref, writer, "RulesetScheme");
			}
		}
		if(maint.getUserDefinedOperatorSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getUserDefinedOperatorSchemeRef()) {
				StaxRefUtil.writeReference(ref, writer, "UserDefinedOperatorScheme");
			}
		}
	}

	private void writeItems(List<ITransformationBean> items, StaxWriter writer) {
		for(ITransformationBean item : items) {
			StaxNameableWriterUtil.writeBean(item, "Transformation", writer, CollectionUtil.buildMapValues("isPersistent "+item.isPersistent()));
			if(item.getExpression() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Expression", item.getExpression());
			}
			if(item.getResult() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Result", item.getResult());
			}
			writer.writeEndElement();
		}
	}
}
