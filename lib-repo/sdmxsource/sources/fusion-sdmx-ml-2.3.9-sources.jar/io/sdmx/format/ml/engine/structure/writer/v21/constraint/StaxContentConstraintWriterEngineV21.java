package io.sdmx.format.ml.engine.structure.writer.v21.constraint;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.DataSetReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetKeyValuesBean;
import io.sdmx.api.sdmx.model.beans.registry.MetadataTargetRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.ReferencePeriodBean;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxContentConstraintWriterEngineV21 extends StaxAbstractConstraintWriterEngine<ContentConstraintBean> implements IFusionSingleton {
	private static StaxContentConstraintWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxContentConstraintWriterEngineV21() {}

	public static StaxContentConstraintWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxContentConstraintWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ContentConstraint";
	}

	@Override
	protected void writeMaintainableInternal(ContentConstraintBean maint, StaxWriter writer) {
		super.writeMaintainableInternal(maint, writer);
		writeCubeRegion(maint.getIncludedCubeRegion(), true, writer);
		writeCubeRegion(maint.getExcludedCubeRegion(), false, writer);
		writeCubeRegion(maint.getMetadataTargetRegion(), writer);
		writeReleaseCalendar(maint.getReleaseCalendar(), writer);
		writeReferencePeriod(maint.getReferencePeriod(), writer);
	}



	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(ContentConstraintBean maint) {
		Map<String, String> returnMap = new HashMap<>();
		returnMap.put("type", maint.isDefiningActualDataPresent() ? "Actual" : "Allowed");
		return returnMap;
	}

	private void writeReleaseCalendar(ReleaseCalendarBean relCal, StaxWriter writer) {
		if(relCal != null) {
			writer.writeStartElement(NS, "ReleaseCalendar");
			writer.writeElement(NS, "Periodicity", relCal.getPeriodicity());
			writer.writeElement(NS, "Offset", relCal.getOffset());
			writer.writeElement(NS, "Tolerance", relCal.getTolerance());
			writer.writeEndElement(); // End ReleaseCalendar
		}
	}

	private void writeReferencePeriod(ReferencePeriodBean refPeriod, StaxWriter writer) {
		if(refPeriod != null) {
			writer.writeStartElement(NS, "ReferencePeriod");
			writer.writeAttribute("startTime", refPeriod.getStartTime().getDateInSdmxFormat());
			writer.writeAttribute("endTime", refPeriod.getEndTime().getDateInSdmxFormat());
			writer.writeEndElement(); // End ReferencePeriod
		}
	}


	private void writeCubeRegion(CubeRegionBean cubeRegion, boolean isIncluded, StaxWriter writer) {
		if(cubeRegion != null) {
			writer.writeStartElement(NS, "CubeRegion");
			writer.writeAttribute("include", Boolean.valueOf(isIncluded).toString());
			writeKeyValues(cubeRegion.getKeyValues(),"KeyValue", writer);
			writeKeyValues(cubeRegion.getAttributeValues(),"Attribute", writer);
			writer.writeEndElement(); // End CubeRegion
		}
	}

	private void writeCubeRegion(MetadataTargetRegionBean metadataRegion, StaxWriter writer) {
		if(metadataRegion != null) {
			writer.writeStartElement(NS, "MetadataTargetRegion");
			writer.writeAttribute("include", Boolean.valueOf(metadataRegion.isInclude()).toString());
			writer.writeAttribute("metadataTarget", metadataRegion.getMetadataTarget());
			writer.writeAttribute("report", metadataRegion.getReport());

			writeKeyValues(metadataRegion.getTargetKeyValues(), writer);
			writeKeyValues(metadataRegion.getAttributes(),"Attribute", writer);
			writer.writeEndElement(); // End DataKeySet
		}
	}

	private void writeKeyValues(List<KeyValues> kvsList, String nodeName, StaxWriter writer) {
		for(KeyValues kvs : kvsList) {
			writeStartKeyValues(kvs, nodeName, writer);
			writeTimeRange(kvs.getTimeRange(), writer);
			writer.writeEndElement(); // End KeyValue
		}
	}

	private void writeStartKeyValues(KeyValues kvs, String nodeName, StaxWriter writer) {
		writer.writeStartElement(StaxStructureWriterUtil.COMMON_NS, nodeName);
		writer.writeAttribute("id", kvs.getId());
		for(String val : kvs.getValues()) {
			writer.writeStartElement(StaxStructureWriterUtil.COMMON_NS, "Value");
			if(kvs.isCascadeValue(val)) {
				writer.writeAttribute("cascadeValues", "true");
			}
			writer.writeElementText(val);
			writer.writeEndElement(); // End Value
		}
	}

	private void writeKeyValues(List<MetadataTargetKeyValuesBean> kvsList, StaxWriter writer) {
		for(MetadataTargetKeyValuesBean kvs : kvsList) {
			writeStartKeyValues(kvs, "KeyValue", writer);
			for(DataSetReferenceBean dsRef : kvs.getDatasetReferences()) {
				writer.writeStartElement(NS, "DataSet");
				StaxRefUtil.writeReference(dsRef.getDataProviderReference(), writer, "DataProvider");
				writer.writeElement(NS, "ID", dsRef.getDatasetId());
				writer.writeEndElement(); // End DataSet
			}
			StaxRefUtil.writeReferences(kvs.getObjectReferences(), writer, "Object");
			writeTimeRange(kvs.getTimeRange(), writer);
			writer.writeEndElement(); // End KeyValue
		}
	}

	private void writeTimeRange(TimeRangeBean timeRange, StaxWriter writer) {
		if(timeRange != null) {
			writer.writeStartElement(NS, "TimeRange");
			if(timeRange.getStartDate() != null) {
				String startNodeName = timeRange.isRange() ? "StartPeriod" : "BeforePeriod";
				writer.writeStartElement(NS, startNodeName);
				writer.writeAttribute("isInclusive", Boolean.valueOf(timeRange.isStartInclusive()).toString());
				writer.writeElementText(timeRange.getStartDate().getDateInSdmxFormat());
				writer.writeEndElement(); //End Start|BeforePeriod
			}
			if(timeRange.getEndDate() != null) {
				String endNodeName = timeRange.isRange() ? "EndPeriod" : "AfterPeriod";
				writer.writeStartElement(NS, endNodeName);
				writer.writeAttribute("isInclusive", Boolean.valueOf(timeRange.isEndInclusive()).toString());
				writer.writeElementText(timeRange.getEndDate().getDateInSdmxFormat());
				writer.writeEndElement(); //End Start|BeforePeriod
			}
			writer.writeEndElement(); // End TimeRange
		}
	}
}
