package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxContactWriterUtil {

    /**
     * Writes one or more Contact objects
     * @param contacts
     * @param writer
     */
	public static void writeContact(List<ContactBean> contacts, StaxWriter writer) {
	    writeContact(StaxStructureWriterUtil.STRCUTURE_NS, contacts, writer);
	}

	/**
	 * The Receiver in an SDMX Header has different Namespaces to other Contacts, so gets its own method
	 * @param contacts
	 * @param writer
	 */
	public static void writeContactForReceiver(List<ContactBean> contacts, StaxWriter writer) {
	    writeContact(StaxStructureWriterUtil.MESSAGE_NS, contacts, writer);
    }

    private static void writeContact(Namespace namespace, List<ContactBean> contacts, StaxWriter writer) {
        for(ContactBean contact : contacts) {
            writer.writeStartElement(namespace, "Contact");
            writer.writeAttribute("id", contact.getId());
            StaxTextWriterUtil.writeTextTypes(contact.getName(), writer, "Name");
            StaxTextWriterUtil.writeTextTypes(namespace, contact.getDepartments(), writer, "Department");
            StaxTextWriterUtil.writeTextTypes(namespace, contact.getRole(), writer, "Role");
            writeElements(namespace, contact.getTelephone(), "Telephone", writer);
            writeElements(namespace, contact.getFax(), "Fax", writer);
            writeElements(namespace, contact.getX400(), "X400", writer);
            writeElements(namespace,contact.getUri(), "URI", writer);
            writeElements(namespace, contact.getEmail(), "Email", writer);
            writer.writeEndElement(); //End Org
        }
    }

	private static void writeElements(Namespace namespace, List<String> str, String elementName, StaxWriter writer) {
        for(String currentStr : str) {
            writer.writeElement(namespace, elementName, currentStr);
        }
    }
}