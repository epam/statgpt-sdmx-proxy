package io.sdmx.format.ml.constant;

import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.utils.core.xml.Namespace;

public enum SDMX_NAMESPACE {
	XML("xml", "http://www.w3.org/XML/1998/namespace"),
	XSI("xsi", "http://www.w3.org/2001/XMLSchema-instance"),
	GENERIC_21("generic", SdmxConstants.GENERIC_NS_2_1),
	MESSAGE_21("message", SdmxConstants.MESSAGE_NS_2_1),
	MSD_21("generic", SdmxConstants.GENERICMETADATA_NS_2_1),
	COMMON_21("com", SdmxConstants.COMMON_NS_2_1),
	REGISTRY_21("reg", SdmxConstants.REGISTRY_NS_2_1),
	STRUCTURE_21("str", SdmxConstants.STRUCTURE_NS_2_1),
	
	MESSAGE_3("message", SdmxConstants.MESSAGE_NS_3_0),
	COMMON_3("com", SdmxConstants.COMMON_NS_3_0),
	STRUCTURE_3("str", SdmxConstants.STRUCTURE_NS_3_0),
	REGISTRY_3("reg", SdmxConstants.REGISTRY_NS_3_0),
	FOOTER_3_0("footer", "http://www.sdmx.org/resources/sdmxml/schemas/v3_0/message/footer");

	private Namespace namespace;

	private SDMX_NAMESPACE(String prefix, String namespace) {
		this.namespace = new Namespace(namespace, prefix);
	}

	public Namespace getNamespace() {
		return namespace;
	}

	public String getPrefix() {
		return namespace.getNamespacePrefix();
	}

	public String getNamespaceURL() {
		return namespace.getNamespaceURL();
	}

	@Override
	public String toString() {
		return namespace.toString();
	}

}
