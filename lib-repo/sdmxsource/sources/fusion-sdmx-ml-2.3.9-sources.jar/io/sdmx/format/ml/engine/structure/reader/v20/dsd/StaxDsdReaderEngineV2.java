package io.sdmx.format.ml.engine.structure.reader.v20.dsd;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.VersionableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.CrossSectionalDataStructureBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.ComponentMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxTextFormatUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.ConceptRefUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxDsdReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<DataStructureMutableBean> {
	private static StaxDsdReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDsdReaderEngineV2() {}
	public static StaxDsdReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDsdReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	

	@Override
    public String getContainerNodeName() {
        return "KeyFamilies";
    }
    
    @Override
    protected String getRootNodeName() {
        return "KeyFamily";
    }
    
    @Override
    protected DataStructureMutableBean processMaintainable(IStaxReader reader) {
		DataStructureMutableBean maint = new DataStructureMutableBeanImpl();
		StaxMaintainableUtilV2.processBean(maint, reader);

		while(reader.isStartElement()) {
			if(reader.getElementName().equals("Components")) {
				processComponents(maint, reader);
			} else if(reader.getElementName().equals("Annotations")) {
				StaxAnnotableUtil.processAnnotations(maint, reader);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}

		return maint;
	}

	/**
	 * Populates the DSD with Dimensions, Groups, etc.
	 * Expected start node: Components
	 * @param dsd
	 * @param reader
	 */
	private void processComponents(DataStructureMutableBean dsd, IStaxReader reader) {
		DimensionListMutableBean dimensionList = new DimensionListMutableBeanImpl();
		AttributeListMutableBean attributeList = new AttributeListMutableBeanImpl();

		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Dimension")) {
					dimensionList.addDimension(processDimension(reader, dsd.getAgencyId(), false, dsd));
				} else if(nodeName.equals("TimeDimension")) {
					dimensionList.addDimension(processDimension(reader, dsd.getAgencyId(), true, dsd));
				} else if(nodeName.equals("Group")) {
					dsd.addGroup(processGroup(reader, dsd.getAgencyId()));
				} else if(nodeName.equals("PrimaryMeasure")) {
					MeasureMutableBean pmmb = processPrimaryMeasure(reader, dsd.getAgencyId());
					dsd.setPrimaryMeasure(pmmb);
				} else if(nodeName.equals("CrossSectionalMeasure")) {
					// FUNC - crossSectionalMeasure ignored
					reader.skipToEndNode("CrossSectionalMeasure");
				} else if(nodeName.equals("Attribute")) {
					attributeList.addAttribute(processAttribute(reader, dsd.getAgencyId(), dsd.getGroups(), dimensionList));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("Components")) {
				break;
			}
		}

		dsd.setDimensionList(dimensionList);
		dsd.setAttributeList(attributeList);
	}

	/**
	 * Creates a DimensionMutableBean
	 * Expected start node: Dimension
	 * @param reader
	 * @param isTimeDimension
	 * @return
	 */
	private DimensionMutableBean processDimension(IStaxReader reader, String dsdAgencyId, boolean isTimeDimension, DataStructureMutableBean parent) {
		DimensionMutableBean dimension = new DimensionMutableBeanImpl();
		dimension.setTimeDimension(isTimeDimension);

		// Process the attributes
		Map<String, String> attributes = reader.getAttributes();

		String conceptId = StaxStructureUtil.getAttribute(attributes, "conceptRef", true);
		String conceptVersion = StaxStructureUtil.getAttribute(attributes, "conceptVersion", false);
		String conceptAgency = StaxStructureUtil.getAttribute(attributes, "conceptAgency", false);

		String conceptSchemeId = StaxStructureUtil.getAttribute(attributes, "conceptSchemeRef", false);
		String conceptSchemeAcy = StaxStructureUtil.getAttribute(attributes, "conceptSchemeAgency", false);

		// Set the Dimension's representation to be the specified Codelist
		String codelistId = StaxStructureUtil.getAttribute(attributes, "codelist", false);
		String codelistVersion = StaxStructureUtil.getAttribute(attributes, "codelistVersion", false);
		String codelistAgency = StaxStructureUtil.getAttribute(attributes, "codelistAgency", false);

		// Measure Dimension and Frequency Dimension

		if(parent instanceof CrossSectionalDataStructureBean) {
			dimension.setMeasureDimension(StaxStructureUtil.getAttributeAsBoolean(attributes, "isMeasureDimension", false, false));
		}

		dimension.setFrequencyDimension(StaxStructureUtil.getAttributeAsBoolean(attributes, "isFrequencyDimension", false, false));

		// The following attributes are ignored:
		//   "isEntityDimension"
		//   "isCountDimension"
		//   "isNonObservationTimeDimension"
		//   "isIdentityDimension"
		//   "crossSectionalAttachDataSet"
		//   "crossSectionalAttachGroup"
		//   "crossSectionalAttachSection"
		//   "crossSectionalAttachObservation"



		TextFormatMutableBean textFormat = null;
		while (reader.moveNextNode()) {
			if ((reader.getElementName().equals("Dimension") || reader.getElementName().equals("TimeDimension")) && !reader.isStartElement()) {
				break;
			}
			if(reader.getElementName().equals("TextFormat")) {
				textFormat = StaxTextFormatUtil.processBean(reader);
				if(isTimeDimension) {
					textFormat.setTextType(TEXT_TYPE.OBSERVATIONAL_TIME_PERIOD);
				}
				reader.moveNextNode();
			} else if(reader.getElementName().equals("Annotations")) {
				StaxAnnotableUtil.processAnnotations(dimension, reader);
			}
		}

		// Set the values on the DimensionBean
		dimension.setId(conceptId);

		// Set the conceptRef
		setConceptRef(dimension, conceptId, conceptVersion, conceptAgency, conceptSchemeId, conceptSchemeAcy, dsdAgencyId);

		// Set the representation
		setRepresentation(dimension, codelistId, codelistVersion, codelistAgency, textFormat, dsdAgencyId, dimension.isMeasureDimension());

		return dimension;
	}

	/**
	 * Creates a AttributeMutableBean
	 * @param reader
	 * @param dsdAgencyId
	 * @param groups
	 * @param dimensionList
	 * @return
	 */
	private AttributeMutableBean processAttribute(IStaxReader reader, String dsdAgencyId,
			List<GroupMutableBean> groups, DimensionListMutableBean dimensionList) {
		AttributeMutableBean attr = new AttributeMutableBeanImpl();

		// Process the attributes
		Map<String, String> attributes = reader.getAttributes();

		String conceptId = StaxStructureUtil.getAttribute(attributes, "conceptRef", true);
		String conceptVersion = StaxStructureUtil.getAttribute(attributes, "conceptVersion", false);
		String conceptAgency = StaxStructureUtil.getAttribute(attributes, "conceptAgency", false);

		String conceptSchemeId = StaxStructureUtil.getAttribute(attributes, "conceptSchemeRef", false);
		String conceptSchemeAcy = StaxStructureUtil.getAttribute(attributes, "conceptSchemeAgency", false);

		// Set the Dimension's representation to be the specified Codelist
		String codelistId = StaxStructureUtil.getAttribute(attributes, "codelist", false);
		String codelistVersion = StaxStructureUtil.getAttribute(attributes, "codelistVersion", false);
		String codelistAgency = StaxStructureUtil.getAttribute(attributes, "codelistAgency", false);

		String attachmentLevel = StaxStructureUtil.getAttribute(attributes, "attachmentLevel", true);
		String assignmentStatus = StaxStructureUtil.getAttribute(attributes, "assignmentStatus", true);

		// Ignoring the following attributes:
		//   "isTimeFormat"
		//   "crossSectionalAttachDataSet"
		//   "crossSectionalAttachGroup"
		//   "crossSectionalAttachSection"
		//   "crossSectionalAttachObservation"
		//   "isEntityAttribute"
		//   "isNonObservationTimeAttribute"
		//   "isCountAttribute"
		//   "isFrequencyAttribute"
		//   "isidentityAttribute"


		TextFormatMutableBean textFormat = null;
		String attachmentGroup = null;
		while (reader.moveNextNode()) {
			if (reader.getElementName().equals("Attribute") && !reader.isStartElement()) {
				break;
			}
			if(reader.getElementName().equals("TextFormat")) {
				textFormat = StaxTextFormatUtil.processBean(reader);
				reader.moveNextNode();
			} else if(reader.getElementName().equals("AttachmentGroup")) {
				attachmentGroup = reader.getElementText();
			} else if(reader.getElementName().equals("AttachmentMeasure")) {
				// Not supported
				reader.moveNextNode();
			} else if(reader.getElementName().equals("Annotations")) {
				StaxAnnotableUtil.processAnnotations(attr, reader);
			}
		}

		// Set the values on the AttributeBean
		attr.setId(conceptId);

		// Set the attachment level
		switch(attachmentLevel) {
		case "Series":
			attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
			List<DimensionMutableBean> dimensions = dimensionList.getDimensions();
			List<String> dimensionRefs = dimensions.stream().filter(d -> !d.isTimeDimension()).map(DimensionMutableBean::getId).collect(Collectors.toList());
			attr.setDimensionReferences(dimensionRefs);
			break;
		case "Group":
			attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP);
			for (GroupMutableBean groupMutableBean : groups) {
				if (groupMutableBean.getId().equals(attachmentGroup)) {
					attr.setAttachmentGroup(groupMutableBean.getId());
					break;
				}
			}
			break;
		case "DataSet":
			attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
			break;
		case "Observation":
			attr.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
			break;
		}

        boolean assignmentStatusBool;
        if (assignmentStatus.equals("Conditional")) {
        	assignmentStatusBool = false;
        } else if (assignmentStatus.equals("Mandatory")) {
        	assignmentStatusBool = true;
        } else {
        	throw new SdmxSemmanticException("'assignmentStatus' has illegal value of: " + assignmentStatus);
        }
		attr.setMandatory(assignmentStatusBool);

		// Set the concept ref
		setConceptRef(attr, conceptId, conceptVersion, conceptAgency, conceptSchemeId, conceptSchemeAcy, dsdAgencyId);

		// Set the representation
		setRepresentation(attr, codelistId, codelistVersion, codelistAgency, textFormat, dsdAgencyId, false);

		return attr;
	}

	private void setRepresentation(ComponentMutableBean attr, String codelistId,
			String codelistVersion, String codelistAgency, TextFormatMutableBean textFormat, String dsdAgencyId, boolean isMeasureDimension) {
		if(textFormat != null || ObjectUtil.validOneString(codelistAgency, codelistId, codelistVersion)) {
			RepresentationMutableBean repMut = new RepresentationMutableBeanImpl();

			if(ObjectUtil.validOneString(codelistAgency, codelistId, codelistVersion)) {
				if(!ObjectUtil.validString(codelistAgency)) {
					codelistAgency = dsdAgencyId;
				}
				if(!ObjectUtil.validString(codelistVersion)) {
					codelistVersion = VersionableBean.DEFAULT_VERSION;
				}
				
				
				SDMX_STRUCTURE_TYPE type = isMeasureDimension ?  SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME: SDMX_STRUCTURE_TYPE.CODE_LIST;
				StructureReferenceBean sref = new StructureReferenceBeanImpl(codelistAgency, codelistId, codelistVersion, type);
				repMut.setRepresentation(sref);
			}

			repMut.setTextFormat(textFormat);
			attr.setRepresentation(repMut);
		}
	}


	/**
	 * Creates a PrimaryMeasureMutableBean
	 * Expected start node: PrimaryMeasure
	 * @param reader
	 * @return
	 */
	private MeasureMutableBean processPrimaryMeasure(IStaxReader reader, String dsdAgencyId) {
		MeasureMutableBean dimension = new PrimaryMeasureMutableBeanImpl();

		// Process the attributes
		Map<String, String> attributes = reader.getAttributes();

		String conceptId = StaxStructureUtil.getAttribute(attributes, "conceptRef", true);
		String conceptVersion = StaxStructureUtil.getAttribute(attributes, "conceptVersion", false);
		String conceptAgency = StaxStructureUtil.getAttribute(attributes, "conceptAgency", false);

		String conceptSchemeId = StaxStructureUtil.getAttribute(attributes, "conceptSchemeRef", false);
		String conceptSchemeAcy = StaxStructureUtil.getAttribute(attributes, "conceptSchemeAgency", false);

		// Set the Dimension's representation to be the specified Codelist
		String codelistId = StaxStructureUtil.getAttribute(attributes, "codelist", false);
		String codelistVersion = StaxStructureUtil.getAttribute(attributes, "codelistVersion", false);
		String codelistAgency = StaxStructureUtil.getAttribute(attributes, "codelistAgency", false);

		reader.moveNextNode();
		// Process TextFormat if present
		TextFormatMutableBean textFormat = null;
		if(reader.getElementName().equals("TextFormat")) {
			textFormat = StaxTextFormatUtil.processBean(reader);
			reader.moveNextNode();
		}

		// Process annotations if present
		if(reader.getElementName().equals("Annotations")) {
			StaxAnnotableUtil.processAnnotations(dimension, reader);
		}

		// Set the PrimaryMeasure
		dimension.setId(conceptId);

		// Set the Concept Ref
		setConceptRef(dimension, conceptId, conceptVersion, conceptAgency, conceptSchemeId, conceptSchemeAcy, dsdAgencyId);

		// Set the representation
		setRepresentation(dimension, codelistId, codelistVersion, codelistAgency, textFormat, dsdAgencyId, false);

		return dimension;
	}

	private void setConceptRef(ComponentMutableBean component,
			String conceptId, String conceptVersion, String conceptAgency, String conceptSchemeId, String conceptSchemeAcy, String dsdAgencyId) {
		if(!ObjectUtil.validString(conceptAgency)) {
			conceptAgency = dsdAgencyId;
		}
		if(!ObjectUtil.validString(conceptVersion)) {
			conceptVersion = VersionableBean.DEFAULT_VERSION;
		}
		StructureReferenceBean conceptRef = ConceptRefUtil.buildConceptRef(conceptSchemeAcy, conceptSchemeId, conceptVersion, conceptAgency, conceptId);
		component.setConceptRef(conceptRef);
	}

	/**
	 * Creates a GroupMutableBean
	 * Expected start node: Group
	 * @param reader
	 * @return
	 */
	private GroupMutableBean processGroup(IStaxReader reader, String dsdAgencyId) {
		GroupMutableBean returnBean = new GroupMutableBeanImpl();
		returnBean.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));

		reader.moveNextNode();
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("DimensionRef")) {
				returnBean.addDimensionRef(reader.getElementText());
			} else if(nodeName.equals("Description")) {
				// Ignoring "Descriptions" on Group when reading SDMX 2.0
				reader.moveNextNode();
			} else if(reader.getElementName().equals("Annotations")) {
				StaxAnnotableUtil.processAnnotations(returnBean, reader);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
}
