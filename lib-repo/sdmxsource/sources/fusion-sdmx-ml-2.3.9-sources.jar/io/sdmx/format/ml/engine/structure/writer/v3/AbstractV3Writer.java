package io.sdmx.format.ml.engine.structure.writer.v3;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxMaintainableWriterUtilV3;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class AbstractV3Writer<T extends MaintainableBean> implements StaxMaintainableWriterEngine<T> {
	protected static Namespace NS = StaxStructureWriterUtil.STRCUTURE_NS;
	
	@Override
	public void writeMaintainable(T maint, StaxWriter writer) {
		writeMaintainable(maint, null, writer);
	}

	@Override
	public final void writeMaintainable(T maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxMaintainableWriterUtilV3.writeBean(maint, getRootNodeName(), externalLinks, writer, getAdditionalMaintainableAttributes(maint));
		
		//Note a Provision Agreement can not be a stub according to the SDMX version 2.1 Schema
		if(maint.getStructureType() == SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT || !maint.isExternalReference()) {
			writeMaintainableInternal(maint, externalLinks, writer);
		}
		writer.writeEndElement(); //End Maintainable
	}
	
	/**
	 * Allows sub classes to override to provide additional maintainable attributes
	 * @return
	 */
	protected Map<String, String> getAdditionalMaintainableAttributes(T maint) {
		return null;
	}
	
	protected abstract String getRootNodeName();
	

	protected abstract void writeMaintainableInternal(T maint, IExternalMaintainableLinks externalLinks, StaxWriter writer);
}
