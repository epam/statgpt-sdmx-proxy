package io.sdmx.format.ml.engine.structure.reader.v21.msd;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataStructureDefinitionMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxRepresentationUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataAttributeMutableBeanImpl;
import io.sdmx.im.mutable.metadatastructure.MetadataStructureDefinitionMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMSDReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<MetadataStructureDefinitionMutableBean> {
	private static StaxMSDReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMSDReaderEngineV21() {}

	public static StaxMSDReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMSDReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "MetadataStructures";
    }

    @Override
    protected String getRootNodeName() {
        return "MetadataStructure";
    }
    
    @Override
    protected MetadataStructureDefinitionMutableBean processMaintainable(IStaxReader reader) {
		MetadataStructureDefinitionMutableBean msd = new MetadataStructureDefinitionMutableBeanImpl();
		StaxMaintainableUtil.processBean(msd, reader);
		if(reader.isStartElement()) {
			if(!reader.getElementName().equals("MetadataStructureComponents")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			while(reader.moveNextNode()) {
				String nodeName = reader.getElementName();
				if(reader.isStartElement()) {
					if(nodeName.equals("MetadataTarget")) {
						reader.skipCurrentNode();
					} else if(nodeName.equals("ReportStructure")) {
						processReportStructure(msd, reader);
					} else {
						StaxStructureUtil.throwUnexpectedNodeException(reader);
					}
				} else if(nodeName.equals("MetadataStructureComponents")) {
					break;
				}
			}
		}
		return msd;
	}

	private void processReportStructure(MetadataStructureDefinitionMutableBean msd, IStaxReader reader) {
		//Just pass in anything - we don't care about this information as it is lost in the v3.0 model
		StaxIdentifiableUtil.processBean(new CodelistMutableBeanImpl(), reader);
		
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("MetadataAttribute")) {
				msd.addMetadataAttributes(processMetadataAttribute(reader));
			} else if(elementName.equals("MetadataTarget")) {
				reader.skipCurrentNode();
			}
			reader.moveNextNode();
		}
	}

	private MetadataAttributeMutableBean processMetadataAttribute(IStaxReader reader) {
		MetadataAttributeMutableBean returnBean = new MetadataAttributeMutableBeanImpl();
		Map<String, String> attributes = reader.getAttributes();

		returnBean.setMinOccurs(StaxStructureUtil.getAttributeAsInteger(attributes, "minOccurs", false));
		returnBean.setMaxOccurs(StaxStructureUtil.getAttributeAsInteger(attributes, "maxOccurs", false));
		returnBean.setPresentational(StaxStructureUtil.getAttributeAsTeritaryBoolean(attributes, "isPresentational", false));

		StaxIdentifiableUtil.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("ConceptIdentity")) {
				returnBean.setConceptRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			} else if(elementName.equals("LocalRepresentation")) {
				RepresentationMutableBean representation = returnBean.getRepresentation();
				if(representation != null) {
					StaxRepresentationUtil.processBean(reader, representation, true);
				} else {
					returnBean.setRepresentation(StaxRepresentationUtil.processBean(reader, true));
				}
			} else if(elementName.equals("MetadataAttribute")) {
				returnBean.addMetadataAttributes(processMetadataAttribute(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
}
