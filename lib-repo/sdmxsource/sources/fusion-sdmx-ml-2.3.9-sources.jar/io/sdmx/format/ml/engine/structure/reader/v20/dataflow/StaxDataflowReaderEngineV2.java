package io.sdmx.format.ml.engine.structure.reader.v20.dataflow;

import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxStructureUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataflowReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<DataflowMutableBean> {
	private static StaxDataflowReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataflowReaderEngineV2() {}
	public static StaxDataflowReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataflowReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
    public String getContainerNodeName() {
        return "Dataflows";
    }
    
    @Override
    protected String getRootNodeName() {
        return "Dataflow";
    }
    
    @Override
    protected DataflowMutableBean processMaintainable(IStaxReader reader) {
	    DataflowMutableBean maint = new DataflowMutableBeanImpl();
	    StaxMaintainableUtilV2.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("KeyFamilyRef")) {
                maint.setDataStructureRef( StaxStructureUtilV2.obtainKeyFamilyRefForDSD(reader) );
            } else if(reader.getElementName().equals("CategoryRef")) {
                reader.skipCurrentNode();
            } else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode(); // Move to the end of the annotations
        }

        return maint;
	}
}
