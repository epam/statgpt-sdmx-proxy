package io.sdmx.format.ml.engine.structure.writer.v3.codelist;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoGridCodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxGeoCodelistWriterEngineV3 extends AbstractV3Writer<IGeoGridCodelistBean> implements IFusionSingleton {
	private static StaxGeoCodelistWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxGeoCodelistWriterEngineV3() {}

	public static StaxGeoCodelistWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxGeoCodelistWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "GeoGridCodelist";
	}
	
	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(IGeoGridCodelistBean maint) {
		return CollectionUtil.buildMapValues("geoType GeoGridCodelist");
	}

	@Override
	protected void writeMaintainableInternal(IGeoGridCodelistBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeCodes(maint.getItems(), externalLinks, writer);
		writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "GridDefinition", maint.getGridDefinition());
	}

	private void writeCodes(List<CodeBean> codes, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(CodeBean ucast : codes) {
			IGeoGridCodeBean code = (IGeoGridCodeBean)ucast;
			StaxNameableWriterUtilV3.writeBean(code, "GeoGridCode", externalLinks, writer);
			if(code.getParentCode() != null) {
				StaxRefUtilV3.writeLocalReference(code.getParentCode(), writer, "Parent");
			}
			writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "GeoCell", code.getGeoCell());
			writer.writeEndElement();
		}
	}
}
