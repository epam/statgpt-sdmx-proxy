package io.sdmx.format.ml.manager;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.factory.ISchemaWriterFactory;
import io.sdmx.api.sdmx.manager.constraint.ConstrainedDataStructureRetrievalManager;
import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxSchemaManager implements ISdmxSchemaManager {
	private ConstrainedDataStructureRetrievalManager constraintInfoManager;
	private Set<ISchemaWriterFactory> factories = null;
	
	public SdmxSchemaManager(ConstrainedDataStructureRetrievalManager constraintInfoManager) {
		this.constraintInfoManager = constraintInfoManager;
	}

	@Override
	public void generateSchema(SchemaFormat format, RESTSchemaQuery schemaQuery, OutputStream out) {
		IURNSingle<? extends IDSDRelatedBean> srb = schemaQuery.getReference();
		if (srb == null) {
			throw new IllegalArgumentException("Unable to evaluate the context requested");
		}
		Date queryValidFrom = schemaQuery.getValidFrom();
		Date queryValidTo =  schemaQuery.getValidTo();
		ConstrainedCodes validCodes = constraintInfoManager.getValidCodes(srb, schemaQuery.getAsOf(), queryValidFrom, queryValidTo);
		
		String dimAtObs = schemaQuery.getDimAtObs();
		if(dimAtObs == null && validCodes.getDsd().getTimeDimension() == null) {
			dimAtObs = "AllDimensions";
		}
		getSchemaWritingEngine(format).writeSchema(validCodes, schemaQuery.getDimAtObs(), schemaQuery.prettyPrint(), out);
	}
	
	private SchemaWriterEngine getSchemaWritingEngine(SchemaFormat outputFormat) {
		for(ISchemaWriterFactory factory : getSchemaWriterFactory()) {
			SchemaWriterEngine engine = factory.getSchemaWriterEngine(outputFormat);
			if(engine != null) {
				return engine;
			}
		}
		throw new SdmxNotAcceptableException("Could not write schema out in format: " + outputFormat.getFormatDetails().getFormatAsString());
	}

	private Collection<ISchemaWriterFactory> getSchemaWriterFactory() throws IllegalArgumentException {
		if(factories != null) {
			return factories;
		}
		synchronized(this) {
			Set<ISchemaWriterFactory> localFactories = new HashSet<>();
			Collection<ISchemaWriterFactory> allBeans = FusionBeanStore.getBeans(ISchemaWriterFactory.class);
			for (ISchemaWriterFactory structureWriterFactory : allBeans) {
				localFactories.add(structureWriterFactory);
			}
			this.factories = localFactories;
		}
		return factories;
	}
	

}
