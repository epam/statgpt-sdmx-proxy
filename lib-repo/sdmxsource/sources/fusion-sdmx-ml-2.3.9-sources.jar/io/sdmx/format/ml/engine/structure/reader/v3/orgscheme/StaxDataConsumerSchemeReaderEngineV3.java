package io.sdmx.format.ml.engine.structure.reader.v3.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataConsumerSchemeReaderEngineV3 extends StaxAbstractOrgansiationReaderV3<DataConsumerSchemeMutableBean> {
	private static StaxDataConsumerSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataConsumerSchemeReaderEngineV3() {}

	public static StaxDataConsumerSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataConsumerSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	@Override
	public String getContainerNodeName() {
        return "DataConsumerSchemes";
    }
	
    @Override
    protected String getRootNodeName() {
        return "DataConsumerScheme";
    }
	
	@Override
    protected DataConsumerSchemeMutableBean processMaintainable(IStaxReader reader) {
	    DataConsumerSchemeMutableBean dpScheme = new DataConsumerSchemeMutableBeanImpl();
        StaxItemSchemeUtil.processBean(dpScheme, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("DataConsumer")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processDataConsumer(dpScheme, reader);
            reader.moveNextNode();
        }
        return dpScheme;
    }

	private void processDataConsumer(DataConsumerSchemeMutableBean beanToPopulate, IStaxReader reader) {
		DataConsumerMutableBean consumer = new DataConsumerMutableBeanImpl();
		beanToPopulate.addItem(consumer);
		super.processOrganisation(consumer, reader);
	}
}
