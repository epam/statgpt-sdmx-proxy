package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxIdentifiableWriterUtilV3 {

	public static void writeBean(IdentifiableBean ident, String elementName, IExternalMaintainableLinks externalLinks,  StaxWriter writer) {
		writeBean(ident, elementName, externalLinks, writer, null);
	}
	
	public static void writeBean(IdentifiableBean ident, String elementName, IExternalMaintainableLinks externalLinks,  StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = getAttributes(ident);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName, attributes);
		StaxAnnotableWriterUtilV3.writeBean(ident, writer);
		writeLinks(ident, externalLinks, writer);
	}

	public static Map<String, String> getAttributes(IdentifiableBean ident) {
		Map<String, String> attributes = new HashMap<>();
		attributes.put("id", ident.getId());
		attributes.put("urn", ident.getUrn());
		if(ident.getUri() != null) {
			attributes.put("uri", ident.getUri().toString());
		}
		return attributes;
	}
	
	public static void writeLinks(IdentifiableBean ident, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		Set<ILinkBean> links = externalLinks != null ? externalLinks.getLinks(ident.getURN()) : null;
		writeLinks(links, writer);
		writeLinks(ident.getLinks(), writer);
	}
	
	private static void writeLinks(Collection<ILinkBean> links, StaxWriter writer) {
		if(links != null) {
			for(ILinkBean link : links) {
				writer.writeStartElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "Link");
				
				if(link.getRel() != null) {
					writer.writeAttribute("rel", link.getRel());
				}
				if(link.getHRef() != null) {
					writer.writeAttribute("url", link.getHRef().toString());
				}
				if(link.getUrn() != null) {
					writer.writeAttribute("urn", link.getUrn().toString());
				}
				if(link.getType() != null) {
					writer.writeAttribute("type", link.getType());
				}
				writer.writeEndElement();
			}
		}
	}

}
