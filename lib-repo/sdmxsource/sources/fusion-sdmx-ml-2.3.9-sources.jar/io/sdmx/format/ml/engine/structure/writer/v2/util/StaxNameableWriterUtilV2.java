package io.sdmx.format.ml.engine.structure.writer.v2.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxNameableWriterUtilV2 {

	public static void writeBean(NameableBean nameable, String elementName, StaxWriter writer) {
		writeBean(nameable, elementName, writer, null);
	}

	public static void writeBean(NameableBean nameable, String elementName, StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = StaxIdentifiableWriterUtilV2.getAttributes(nameable);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(StaxStructureWriterUtilV2.STRUCTURE_NS, elementName, attributes);
		writeBean(nameable, writer);
	}

	public static void writeBean(NameableBean nameable, StaxWriter writer) {
		StaxTextWriterUtilV2.writeTextTypes(nameable.getNames(), writer, "Name");
		StaxTextWriterUtilV2.writeTextTypes(nameable.getDescriptions(), writer, "Description");
	}
}
