package io.sdmx.format.ml.util;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SdmxConstants;

/**
 * Provides mappings between different schema versions.
 */
public class SchemaUtils {
	/**
	 * Takes in an action string and returns the appropriate action string  for the schema version
	 * @param action
	 * @param schemaVersion
	 * @return
	 */
	public static String parseAction(String action, SDMX_SCHEMA schemaVersion) {
		switch(schemaVersion) {
		case VERSION_ONE : 
			if(action.equals("Update") || action.equals("Delete")) {
				return action;
			}
			return "Update";
		case VERSION_TWO :
			if(action.equals("Update")) {
				return "Append";
			}
			return action;
		default : throw new SdmxNotImplementedException(schemaVersion);
		}
		//TODO 2.1
	}
	
	/**
	 * Processes an input namespace, if it is a sdmx namespace URI which is incorrect
	 * with the targetSchemaVersion, then the namespace will be altered to match the correct targetSchemaVersion URI.
	 * 
	 * If the input namespace is already the correct SDMX namespace for the targetSchemaVersion or the namespace
	 * if unrecognised, it will return the inputNamespace. 
	 * @param inputNamespace - the namespace to parse
	 * @param targetSchemaVersion - the target schema version for the output namespace
	 * @return
	 */
	public static String parseNamespace(String inputNamespace, SDMX_SCHEMA targetSchemaVersion ) {
		switch(targetSchemaVersion) {
		case VERSION_ONE : 
			if(SdmxConstants.getNamespacesV1().contains(inputNamespace)) {
				return inputNamespace;
			} 
			if(SdmxConstants.getNamespacesV2().contains(inputNamespace)) {
				return SdmxConstants.getV2toV1Map().get(inputNamespace);
			}
			return inputNamespace;
		case VERSION_TWO :
			if(SdmxConstants.getNamespacesV2().contains(inputNamespace)) {
				return inputNamespace;
			} 
			if(SdmxConstants.getNamespacesV1().contains(inputNamespace)) {
				return SdmxConstants.getV1toV2Map().get(inputNamespace);
			}
			return inputNamespace;
			
		default : throw new SdmxNotImplementedException(targetSchemaVersion);
		}
		//TODO 2.1
	}
	
	
}
