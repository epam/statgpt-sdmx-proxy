package io.sdmx.format.ml.engine.structure.writer.v3.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataProviderSchemeWriterEngineV3 extends StaxAbstractOrganisationSchemeWriterEngine<DataProviderSchemeBean, DataProviderBean> implements IFusionSingleton {
	private static StaxDataProviderSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataProviderSchemeWriterEngineV3() {}

	public static StaxDataProviderSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataProviderSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "DataProviderScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "DataProvider";
	}
}
