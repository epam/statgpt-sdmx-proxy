package io.sdmx.format.ml.engine.structure.reader.v3.dataflow;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataflowMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.DataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataflowReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<DataflowMutableBean> {
    private static StaxDataflowReaderEngineV3 INSTANCE;

    //Private constructor - lazy load instance
    private StaxDataflowReaderEngineV3() {}
    public static StaxDataflowReaderEngineV3 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxDataflowReaderEngineV3();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Dataflows";
    }
    
    @Override
    protected String getRootNodeName() {
        return "Dataflow";
    }

    @Override
    protected DataflowMutableBean processMaintainable(IStaxReader reader) {
        DataflowMutableBean dataflow = new DataflowMutableBeanImpl();
        StaxMaintainableUtil.processBean(dataflow, reader);
        if(reader.isStartElement()) {
            if(!reader.getElementName().equals("Structure")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            dataflow.setDataStructureRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DSD));
        }
        return dataflow;
    }
}
