package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import javax.xml.stream.XMLStreamException;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;



abstract public class CompactSchemaCreator extends BaseSchemaGenerator {

	protected OutputStream out;
	protected String targetNamespace;
	protected StructureReferenceBean srb;
	protected DataStructureSuperBean dsd;
	protected DimensionSuperBean crossSectionDimension; 
	protected boolean generatingCrossSectional;
	protected boolean generatingAllDimensions;
	

	public CompactSchemaCreator(ConstrainedCodes constrainedCodes, String dimensionAtObservation, String schemaLocation, OutputStream out, boolean prettyPrint) {
		super(constrainedCodes.getValidCodes(), prettyPrint);
		this.out = out;
		this.dsd = constrainedCodes.getDsd();
		if (out == null) {
			throw new IllegalArgumentException("No output stream provided");
		}
		if(dimensionAtObservation != null && !dimensionAtObservation.equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
			if(dimensionAtObservation.equals("AllDimensions")) {
				this.generatingAllDimensions = true;
			} else {
				// Check that the specified dimension id actually exists within the Key Family
				this.crossSectionDimension = dsd.getDimensionById(dimensionAtObservation);
				if (crossSectionDimension == null) {
					throw new SdmxSemmanticException("The dimension at observation '" + dimensionAtObservation + "' does not exist for the Data Structure Definition: " + dsd);
				}
				generatingCrossSectional = true;
			}
		}
		this.srb = constrainedCodes.getConstrainable().asReference();
		this.schemaLocation = schemaLocation;
	}

	public void createSchema() {
		try {
			writeSchemaInformation();
			writeDataset();
			writeDatasetAttributes();
			writeGroups();
			writeSeries();
			writeObservations();
			writeCompTypes();
			close();
		} catch(Exception th) {
			throw new RuntimeException(th);
		}
	}

	abstract protected void addComplexContentRoot(String type, String type_2_1) throws Exception;

	abstract protected void writeSchemaInformation();

	abstract protected void writeDataset() throws Exception;
	
	void writeDatasetAttributes() throws Exception {
		//For override (in SDMX v3.0 this is the Atts element)
	}
	
	void writeCompTypes() throws Exception {
		//For override (in SDMX v3.0 this is the Atts element)
	}

	abstract protected void writeGroups() throws Exception;

	abstract protected void writeSeries() throws Exception;

	abstract protected void writeObservations() throws Exception;

	protected void addOptionalDimensionBean(ComponentSuperBean dimensionBean) throws XMLStreamException {
		addDimensionBean(dimensionBean, "optional");
	}

	protected void addRequiredDimensionBean(ComponentSuperBean dimensionBean) throws XMLStreamException {
		addDimensionBean(dimensionBean, "required");
	}

	protected void addProhibitedDimensionBean(ComponentSuperBean dimensionBean) throws XMLStreamException {
		addDimensionBean(dimensionBean, "prohibited");
	}

	private void addDimensionBean(ComponentSuperBean dimensionBean, String useageType) throws XMLStreamException {
		addComponentBean(dimensionBean);		
		writer.writeAttribute("use", useageType);
		writer.writeEndElement();
	}

	void addAttributeBean(AttributeSuperBean attributeBean) throws XMLStreamException {
		addComponentBean(attributeBean);		
		writer.writeAttribute("use", "optional");  // This is always OPTIONAL
		writer.writeEndElement();
	}
	
	void writeTimePeriodType() throws XMLStreamException {
		writer.writeAttribute("type", "common:ObservationalTimePeriodType");
	}
}
