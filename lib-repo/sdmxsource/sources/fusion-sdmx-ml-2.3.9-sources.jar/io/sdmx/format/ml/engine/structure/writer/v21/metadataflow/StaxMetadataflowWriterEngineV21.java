package io.sdmx.format.ml.engine.structure.writer.v21.metadataflow;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMetadataflowWriterEngineV21 extends AbstractV21Writer<MetadataFlowBean> implements IFusionSingleton {
	private static StaxMetadataflowWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataflowWriterEngineV21() {}

	public static StaxMetadataflowWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataflowWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Metadataflow";
	}

	@Override
	protected void writeMaintainableInternal(MetadataFlowBean maint, StaxWriter writer) {
		StaxRefUtil.writeReference(maint.getMetadataStructureRef(), writer, "Structure");
	}
}
