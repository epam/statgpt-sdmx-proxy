package io.sdmx.format.ml.constant;

public enum SDMXML_VERSION {
	V1("1.0"),
	V2("2.0"),
	V21("2.1"),
	V3("3.0.0");
	
	private String asString;
	
	private SDMXML_VERSION(String v) {
		this.asString = v;
	}

	public String getVersion() {
		return asString;
	}

	@Override
	public String toString() {
		return getVersion();
	}
	
}
