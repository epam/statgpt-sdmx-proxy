package io.sdmx.format.ml.engine.structure.writer.v21.codelist;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCodelistWriterEngineV21 extends AbstractV21Writer<CodelistBean> implements IFusionSingleton {
	private static StaxCodelistWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistWriterEngineV21() {}

	public static StaxCodelistWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Codelist";
	}

	@Override
	protected void writeMaintainableInternal(CodelistBean maint, StaxWriter writer) {
		writeCodes(maint.getItems(), writer);
	}

	private void writeCodes(List<CodeBean> codes, StaxWriter writer) {
		for(CodeBean code : codes) {
			StaxNameableWriterUtil.writeBean(code, "Code", writer);
			if(code.getParentCode() != null) {
				StaxRefUtil.writeLocalReference(code.getParentCode(), writer, "Parent");
			}
			writer.writeEndElement();
		}
	}
}
