package io.sdmx.format.ml.model;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.model.validation.ErrorFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Defines an SDMX Error format, no methods required
 */
public class SdmxErrorFormat implements ErrorFormat, IFusionSingleton {
	private static SdmxErrorFormat INSTANCE;

	public static SdmxErrorFormat getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxErrorFormat();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxErrorFormat() { }

}
