package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxTextWriterUtilV3 {

	public static void writeTextTypes(Collection<TextTypeWrapper> text, StaxWriter writer, String elementName) {
		writeTextTypes(SDMX_NAMESPACE.COMMON_3.getNamespace(), text, writer, elementName);
	}
	
	public static void writeTextTypes(Namespace ns, Collection<TextTypeWrapper> text, StaxWriter writer, String elementName) {
		if(text != null) {
			for(TextTypeWrapper tt : text) {
				Map<String, String> attributes = new HashMap<>();
				attributes.put("xml:lang", tt.getLocale());
				writer.writeElement(ns, elementName, tt.getValue(), attributes);
			}
		}
	}
}
