package io.sdmx.format.ml.engine.structure.writer.v1.conceptscheme;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v1.AbstractV1Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxConceptSchemeWriterEngineV1 extends AbstractV1Writer<ConceptSchemeBean> implements IFusionSingleton {
	private static StaxConceptSchemeWriterEngineV1 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeWriterEngineV1() {}
	public static StaxConceptSchemeWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeWriterEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ConceptScheme";
	}

    @Override
    protected void writeMaintainableInternal(ConceptSchemeBean maint, StaxWriter writer) {
        writeConceptList(maint.getItems(), maint, writer);
    }

    private void writeConceptList(List<ConceptBean> list, ConceptSchemeBean csBean, StaxWriter writer) {
        // Sub-concepts should be written out flattened
        for(ConceptBean concept : list) {
            Map<String, String> attributes = new HashMap<>();
            attributes.put("id", concept.getId());
            if (concept.getUri() != null) {
                attributes.put("uri", concept.getUri().toString());
            }
            attributes.put("agency", csBean.getAgencyId());
            attributes.put("version", csBean.getVersion().toString());

            writer.writeElement(NS, "Concept", attributes);
            StaxTextWriterUtilV2.writeTextTypes(concept.getNames(), writer, "Name");
            StaxAnnotableWriterUtilV2.writeAnnotations(concept.getAnnotations(), writer);
            writer.writeEndElement();
        }
    }
}
