package io.sdmx.format.ml.engine.structure.reader.v21.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxContactUtil    {

	public static void processBean(ContactMutableBean contact, IStaxReader reader) {
		contact.setId(reader.getAttributes().get("id"));
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Name")) {
					contact.addName(StaxStructureUtil.getText(reader));
				} else if(nodeName.equals("Department")) {
					contact.addDepartment(StaxStructureUtil.getText(reader));
				} else if(nodeName.equals("Role")) {
					contact.addRole(StaxStructureUtil.getText(reader));
				}  else if(nodeName.equals("Telephone")) {
					contact.addTelephone(reader.getElementText());
				} else if(nodeName.equals("Fax")) {
					contact.addFax(reader.getElementText());
				} else if(nodeName.equals("X400")) {
					contact.addX400(reader.getElementText());
				} else if(nodeName.equals("URI")) {
					contact.addUri(reader.getElementText());
				} else if(nodeName.equals("Email")) {
					contact.addEmail(reader.getElementText());
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("Contact")) {
				return;
			}
		}
	}
}
