package io.sdmx.format.ml.engine.structure.reader.v21.transformation;

import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ICustomTypeSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.CustomTypeMutableBean;
import io.sdmx.im.mutable.transformation.CustomTypeSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCustomTypeSchemeReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<ICustomTypeSchemeMutableBean> implements IFusionSingleton {
	private static StaxCustomTypeSchemeReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCustomTypeSchemeReaderEngineV21() {}

	public static StaxCustomTypeSchemeReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCustomTypeSchemeReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "CustomTypes";
	}

	@Override
	protected String getRootNodeName() {
		return "CustomTypeScheme";
	}

	@Override
	protected ICustomTypeSchemeMutableBean processMaintainable(IStaxReader reader) {
		ICustomTypeSchemeMutableBean maint = new CustomTypeSchemeMutableBean();
		maint.setVtlVersion(reader.getAttributeValue(null, "vtlVersion"));
		StaxItemSchemeUtil.processBean(maint, reader);

		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("CustomType")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			ICustomTypeMutableBean item = readItem(reader);
			maint.addItem(item);
			reader.moveNextNode();
		}
		return maint;
	}

	private ICustomTypeMutableBean readItem(IStaxReader reader) {
		ICustomTypeMutableBean item = new CustomTypeMutableBean();
		StaxNameableUtil.processBean(item, reader);
		do {
			if(reader.isStartElement()) {
				String element = reader.getElementName();
				switch(element) {
				case "VtlScalarType" :
					item.setVtlScalarType(reader.getElementText());
					break;
				case "DataType" :
					item.setDataType(reader.getElementText());
					break;
				case "VtlLiteralFormat" :
					item.setVtlLiteralFormat(reader.getElementText());
					break;
				case "OutputFormat" :
					item.setOutputFormat(reader.getElementText());
					break;
				case "NullValue" :
					item.setNullValue(reader.getElementText());
					break;

				}
			} else if(reader.getElementName().equals("CustomType")) {
				break;
			}
		} while(reader.moveNextNode());
		return item;
	}
}
