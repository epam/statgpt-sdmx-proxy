package io.sdmx.format.ml.engine.structure.writer.v1.util;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxIdentifiableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMaintainableWriterUtilV1 {

	public static void writeBean(MaintainableBean maint, String elementName, StaxWriter writer) {
		writeBean(maint, elementName, writer, null);
	}

	public static void writeBean(MaintainableBean maint, String elementName, StaxWriter writer, Map<String, String> attributes) {
		if(attributes != null) {
			attributes.putAll(StaxIdentifiableWriterUtilV2.getAttributes(maint));
		} else {
		    attributes = new HashMap<>();
	        attributes.put("id", maint.getId());
//			attributes = StaxIdentifiableWriterUtilV2.getAttributes(maint);
		}
//		if(maint instanceof ItemSchemeBean) {
//			ItemSchemeBean itemScheme = (ItemSchemeBean)maint;
//			if(itemScheme.isPartial()) {
//				attributes.put("isPartial", Boolean.toString(itemScheme.isPartial()));
//			}
//		}
		attributes.put("version", maint.getVersion().toString());
//		attributes.put("agency", maint.getAgencyId());

		// Always write the values of isFinal and isExternalReference
//		attributes.put("isFinal", Boolean.toString(maint.isFinal()));
		attributes.put("isExternalReference", Boolean.toString(maint.isExternalReference()));

//		if(maint.hasValidityPeriod()) {
//			if(maint.getValidityPeriod().hasStartPeriod()) {
//				attributes.put("validFrom", maint.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
//			}
//			if(maint.getValidityPeriod().hasEndPeriod()) {
//				attributes.put("validTo", maint.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
//			}
//		}
		/*
		if(maint.getStructureURL() != null) {
			attributes.put("structureURL", maint.getStructureURL().toString());
		}
		if(maint.getServiceURL() != null) {
			attributes.put("serviceURL", maint.getServiceURL().toString());
		}
		*/
		writer.writeElement(StaxStructureWriterUtilV1.STRUCTURE_NS, elementName, attributes);
		StaxTextWriterUtilV2.writeTextTypes(maint.getNames(), writer, "Name");
//		StaxNameableWriterUtilV2.writeBean(maint, writer);
	}

}
