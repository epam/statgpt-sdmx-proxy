package io.sdmx.format.ml.engine.structure.reader.v21.process;

import java.util.Map;

import io.sdmx.api.sdmx.model.mutable.base.TransitionMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ComputationMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.InputOutputMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessMutableBean;
import io.sdmx.api.sdmx.model.mutable.process.ProcessStepMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.process.ComputationMutableBeanImpl;
import io.sdmx.im.mutable.process.InputOutputMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessMutableBeanImpl;
import io.sdmx.im.mutable.process.ProcessStepMutableBeanImpl;
import io.sdmx.im.mutable.process.TransitionMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxProcessReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<ProcessMutableBean> {
	private static StaxProcessReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProcessReaderEngineV21() {}

	public static StaxProcessReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProcessReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
    @Override
    public String getContainerNodeName() {
        return "Processes";
    }

    @Override
    protected String getRootNodeName() {
        return "Process";
    }

    @Override
    protected ProcessMutableBean processMaintainable(IStaxReader reader) {
		ProcessMutableBean process = new ProcessMutableBeanImpl();
		StaxMaintainableUtil.processBean(process, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("ProcessStep")) {
				process.addProcessStep(processProcessStep(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return process;
	}

	private ProcessStepMutableBean processProcessStep(IStaxReader reader) {
		ProcessStepMutableBean processStep = new ProcessStepMutableBeanImpl();
		StaxNameableUtil.processBean(processStep, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("Input")) {
				processStep.addInput(processInputOutput(reader));
			} else if(elementName.equals("Output")) {
				processStep.addOutput(processInputOutput(reader));
			} else if(elementName.equals("Computation")) {
				processStep.setComputation(processComputation(reader));
			} else if(elementName.equals("Transition")) {
				processStep.addTransition(processTransition(reader));
			} else if(elementName.equals("ProcessStep")) {
				processStep.addProcessStep(processProcessStep(reader));
			}  else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return processStep;
	}

	private InputOutputMutableBean processInputOutput(IStaxReader reader) {
		String exitNode = reader.getElementName();
		InputOutputMutableBean returnBean = new InputOutputMutableBeanImpl();
		returnBean.setLocalId(reader.getAttributeValue(null, "localID"));

		StaxAnnotableUtil.processBean(returnBean, reader);
		if(reader.isStartElement()) {
			StaxStructureUtil.checkStartNode(reader, "ObjectReference");
			returnBean.setStructureReference(StaxStructureUtil.getStructureReference(reader, null));
		}
		reader.skipToEndNode(exitNode);
		return returnBean;
	}

	private ComputationMutableBean processComputation(IStaxReader reader) {
		ComputationMutableBean returnBean = new ComputationMutableBeanImpl();
		Map<String, String> attributes = reader.getAttributes();

		returnBean.setLocalId(attributes.get("localID"));
		returnBean.setSoftwarePackage(attributes.get("softwarePackage"));
		returnBean.setSoftwareLanguage(attributes.get("softwareLanguage"));
		returnBean.setSoftwareVersion(attributes.get("softwareVersion"));

		StaxAnnotableUtil.processBean(returnBean, reader);
		while(reader.isStartElement()) {
			StaxStructureUtil.checkStartNode(reader, "Description");
			returnBean.addDescriptions(StaxStructureUtil.getText(reader));
			reader.moveNextNode();
		}
		return returnBean;
	}

	private TransitionMutableBean processTransition(IStaxReader reader) {
		TransitionMutableBean returnBean = new TransitionMutableBeanImpl();
		Map<String, String> attributes = reader.getAttributes();
		returnBean.setLocalId(attributes.get("localID"));

		StaxIdentifiableUtil.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			StaxStructureUtil.checkStartNode(reader, "TargetStep");
			returnBean.setTargetStep(StaxStructureUtil.getLocalReference(reader));
			reader.moveNextNode();
			while(reader.isStartElement()) {
				StaxStructureUtil.checkStartNode(reader, "Condition");
				returnBean.addCondition(StaxStructureUtil.getText(reader));
				reader.moveNextNode();
			}
		}
		return returnBean;
	}
}
