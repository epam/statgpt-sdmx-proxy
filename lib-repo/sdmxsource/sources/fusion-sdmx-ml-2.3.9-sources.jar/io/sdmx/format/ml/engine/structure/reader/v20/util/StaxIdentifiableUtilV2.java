package io.sdmx.format.ml.engine.structure.reader.v20.util;

import java.util.Map;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxIdentifiableUtilV2 {

	public static void processBean(IdentifiableMutableBean bean, IStaxReader reader) {
		processAttributes(bean, reader);
		reader.moveNextNode();
	}

	/**
	 * populates the Identifiable with 'id' and 'uri' attribute values read from the current XML node.
	 * @param identifiableBean
	 * @param staxReader
	 */
	private static void processAttributes(IdentifiableMutableBean identifiableBean, IStaxReader staxReader) {
		Map<String, String> attributes = staxReader.getAttributes();
		identifiableBean.setId(StaxStructureUtil.getAttribute(attributes, "id", false));  //Id may not be mandatory for an identifiable that inherits it from a concept if not provided
		identifiableBean.setUri(StaxStructureUtil.getAttribute(attributes, "uri", false));
	}
}
