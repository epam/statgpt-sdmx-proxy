package io.sdmx.format.ml.engine.structure.reader.v20.orgscheme;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * In SDMX 2.0, AgencyBeans, DataConsumers and DataProviders are all under "OrganisationScheme"
 * Simply process each type in this class
 */
public class StaxOrganisationSchemeReaderEngineV2 implements StaxMaintainableReaderEngine<OrganisationSchemeMutableBean<?>>, IFusionSingleton {
    private static StaxOrganisationSchemeReaderEngineV2 INSTANCE;

    //Private constructor - lazy load instance
    private StaxOrganisationSchemeReaderEngineV2() {}

    public static StaxOrganisationSchemeReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxOrganisationSchemeReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "OrganisationSchemes";
    }

    @Override
    /**
     * In v2.0 there is an outer 'OrganisationScheme' container which contains Agencies, Data Providers, Data Consumers
     * the container has the maintainable properties
     */
    public void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals("OrganisationScheme")) {
                    OrganisationSchemeMutableBean bean = new OrganisationUnitSchemeMutableBeanImpl();
                    StaxMaintainableUtilV2.processBean(bean, reader);
                    readSchemes(reader, bean, beans, builder);
                } else if(nodeName.equals("Annotations")) {
                    reader.skipCurrentNode();
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
            } else if(reader.getElementName().equals(getContainerNodeName())) {
                return;
            }
        }
    }

    private void readSchemes(IStaxReader reader, OrganisationSchemeMutableBean template, SdmxBeans beans, IBeansBuilder builder) {
        String nodeName = reader.getElementName();
        OrganisationSchemeMutableBean<?> mutable = null;
        if(nodeName.equals("Agencies")) {
            mutable = StaxAgencySchemeReaderEngineV2.getInstance().processMaintainable(reader);
        } else if(nodeName.equals("DataProviders")) {
            mutable = StaxDataProviderSchemeReaderEngineV2.getInstance().processMaintainable(reader);
        } else if(nodeName.equals("DataConsumers")) {
            mutable = StaxDataConsumerSchemeReaderEngineV2.getInstance().processMaintainable(reader);
        } else if(nodeName.equals("Annotations")) {
            reader.skipCurrentNode();
        } else {
            StaxStructureUtil.throwUnexpectedNodeException(reader);
        }

        if(mutable != null) {
            mutable.setAgencyId(template.getAgencyId());
            mutable.setId(template.getId());
            mutable.setNames(template.getNames());
            mutable.setDescriptions(template.getDescriptions());
            builder.build(mutable, beans);
        }
    }
}
