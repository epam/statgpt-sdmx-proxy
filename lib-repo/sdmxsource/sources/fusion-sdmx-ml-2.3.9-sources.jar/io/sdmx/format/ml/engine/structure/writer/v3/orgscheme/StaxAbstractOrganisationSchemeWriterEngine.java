package io.sdmx.format.ml.engine.structure.writer.v3.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxContactWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.utils.core.xml.StaxWriter;


public abstract class StaxAbstractOrganisationSchemeWriterEngine<T extends OrganisationSchemeBean<Y>, Y extends OrganisationBean>  extends AbstractV3Writer<T>  {

	@Override
	protected void writeMaintainableInternal(T maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(Y org : maint.getItems()) {
			StaxNameableWriterUtilV3.writeBean(org, getOrgNodeName(), externalLinks, writer);
			StaxContactWriterUtilV3.writeContact(org.getContacts(), writer);
			writer.writeEndElement(); //End Org
		}
	}
	
	
	protected abstract String getOrgNodeName();
	
}
