package io.sdmx.format.ml.engine.structure.writer.v3.registration;

import java.io.OutputStream;
import java.util.Map;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v21.util.SdmxStaxSubmitResponseWriterV21;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxSubmitRegistrationResponseWriterEngineV3 implements IFusionSingleton {
	private static StaxSubmitRegistrationResponseWriterEngineV3 INSTANCE;

	private SchemaLocationManager schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
	private HeaderRetrievalManager headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);
	private StaxRegistrationWriterEngineV3 staxRegistrationWriterEngineV3 = StaxRegistrationWriterEngineV3.getInstance();

	private StaxSubmitRegistrationResponseWriterEngineV3() {}

	public static StaxSubmitRegistrationResponseWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxSubmitRegistrationResponseWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public void buildResponse(Map<RegistrationBean, Throwable> response, OutputStream out) {
		SdmxStaxSubmitResponseWriterV21.writeRegistrInterfaceDocument(out, "SubmitRegistrationResponse",
				headerRetrievalManager, schemaLocationManager, (writer) -> {
					for(RegistrationBean registration : response.keySet()) {
						processResponse(writer, registration, response.get(registration));
					}
		});
	}

	private void processResponse(StaxWriter writer, RegistrationBean registrationBean, Throwable th) {
		writer.writeStartElement(SDMX_NAMESPACE.REGISTRY_3.getNamespace(), "RegistrationStatus");
		staxRegistrationWriterEngineV3.writeMaintainable(registrationBean, null, writer);
		SdmxStaxSubmitResponseWriterV21.writeStatusMessage(th, writer);
		writer.writeEndElement(); //End RegistrationStatus
	}
}
