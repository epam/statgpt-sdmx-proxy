package io.sdmx.format.ml.engine.structure.reader.v3.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.ITransformationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.TransformationMutableBean;
import io.sdmx.im.mutable.transformation.TransformationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxTransformationSchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<ITransformationSchemeMutableBean> implements IFusionSingleton {
	private static StaxTransformationSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxTransformationSchemeReaderEngineV3() {}

	public static StaxTransformationSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxTransformationSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "TransformationSchemes";
	}

	@Override
	protected String getRootNodeName() {
		return "TransformationScheme";
	}


	@Override
	protected ITransformationSchemeMutableBean processMaintainable(IStaxReader reader) {
		ITransformationSchemeMutableBean maint = new TransformationSchemeMutableBean();
		maint.setVtlVersion(reader.getAttributeValue(null, "vtlVersion"));
		StaxItemSchemeUtil.processBean(maint, reader);
		while(reader.isStartElement()) {
			switch(reader.getElementName()) {
			case "Transformation" :
				ITransformationMutableBean item = readItem(reader);
				maint.addItem(item);
				break;
			case "VtlMappingScheme" :
				maint.setVtlMappingSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
				break;
			case "NamePersonalisationScheme" :
				maint.setNamePersonalisationSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME));
				break;
			case "CustomTypeScheme" :
				maint.setCustomTypeSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME));
				break;
			case "RulesetScheme" :
				maint.addRulesetSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
				break;
			case "UserDefinedOperatorScheme" :
				maint.addUserDefinedOperatorSchemeRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME));
				break;
			default :
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return maint;
	}

	private ITransformationMutableBean readItem(IStaxReader reader) {
		ITransformationMutableBean item = new TransformationMutableBean();
		item.setPersistent("true".equalsIgnoreCase(reader.getAttributeValue("isPersistent")));
		StaxNameableUtil.processBean(item, reader);
		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "Expression" :
					item.setExpression(reader.getElementText());
					break;
				case "Result" :
					item.setResult(reader.getElementText());
					break;
				}
			} else if(reader.getElementName().equals("Transformation")) {
				break;
			}
		} while(reader.moveNextNode());
		return item;
	}
}
