package io.sdmx.format.ml.engine.structure.reader.v20.orgscheme;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.DataConsumerMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataConsumerSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.im.mutable.base.DataConsumerMutableBeanImpl;
import io.sdmx.im.mutable.base.DataConsumerSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * In SDMX 2.0, AgencyBeans, DataConsumers and DataProviders are all under "OrganisationScheme"
 * Simply process each type in this class
 */
public class StaxDataConsumerSchemeReaderEngineV2 extends StraxAbstractOrganisationReaderEngineV2 {
    private static StaxDataConsumerSchemeReaderEngineV2 INSTANCE;

    //Private constructor - lazy load instance
    private StaxDataConsumerSchemeReaderEngineV2() {}

    public static StaxDataConsumerSchemeReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxDataConsumerSchemeReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public DataConsumerSchemeMutableBean processMaintainable(IStaxReader reader) {
        DataConsumerSchemeMutableBean bean = new DataConsumerSchemeMutableBeanImpl();

        List<DataConsumerMutableBean> orgs = processItems(reader);
        for (DataConsumerMutableBean org : orgs) {
            bean.addItem(org);
        }
        return bean;
    }

    private List<DataConsumerMutableBean> processItems(IStaxReader reader) {
        List<DataConsumerMutableBean> retSet = new ArrayList<>();
        reader.moveNextNode();

        do {
            DataConsumerMutableBean agency = new DataConsumerMutableBeanImpl();
            analyseOrganisation(reader, agency );
            retSet.add(agency);
            reader.moveNextNode();
        } while(reader.isStartElement() && reader.getElementName().equals("DataConsumer"));

        return retSet;
    }
}
