package io.sdmx.format.ml.engine.structure.writer.v3.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxAgencySchemeWriterEngineV3 extends StaxAbstractOrganisationSchemeWriterEngine<AgencySchemeBean, AgencyBean> implements IFusionSingleton {
	private static StaxAgencySchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxAgencySchemeWriterEngineV3() {}

	public static StaxAgencySchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxAgencySchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "AgencyScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "Agency";
	}

}
