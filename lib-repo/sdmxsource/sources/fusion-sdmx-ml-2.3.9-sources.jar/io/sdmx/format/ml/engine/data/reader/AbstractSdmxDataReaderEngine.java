package io.sdmx.format.ml.engine.data.reader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.constants.DIMENSION_AT_OBSERVATION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.IFilePosition;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.engine.data.AbstractDataReaderEngine;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.core.sdmx.model.data.FilePosition;
import io.sdmx.im.beans.base.AnnotationBeanImpl;
import io.sdmx.im.beans.base.ContactBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.PositionalKey;
import io.sdmx.im.data.PositionalObservation;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxException;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.core.xml.StaxReader.XMLElementPosition;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.structure.ValidationUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

public abstract class AbstractSdmxDataReaderEngine extends AbstractDataReaderEngine {
	private static final long serialVersionUID = 2653866522651246489L;

	protected static final String XML_NS = "http://www.w3.org/XML/1998/namespace";

	private static final Logger LOG = LoggerFactory.getLogger(AbstractSdmxDataReaderEngine.class);

	protected transient StaxReader parser;
	protected boolean isTwoPointOne;
	protected boolean isThreePointZero;
	protected boolean enforceStrict2_1;

	protected SDMX_SCHEMA schemaVersion;

	protected String groupId;
	protected boolean noSeries;

	protected Observation flatObs;

	protected String GENERIC_NS;
	protected String MESSAGE_NS;
	private String COMMON_NS;
	protected String CROSS_NS;
	protected String COMPACT_NS;
	private String FOOTER_NS = "http://www.sdmx.org/resources/sdmxml/schemas/v2_1/message/footer";

	private BASE_DATA_FORMAT dataFormat;

	//A mapping of concept id, to component id
	private Map<String, String> conceptToComponentId = new HashMap<>();

	private String rootNode;
	protected ReadableDataLocation dataLocation;
	
	/**
	 * Creates a reader engine based on the data location, the location of available data structures that can be used to retrieve dsds, and the default dsd to use
	 * @param dataLocation the location of the data
	 * @param beanRetrieval giving the ability to retrieve dsds for the datasets this reader engine is reading.  This can be null if there is only one relevent dsd - in which case the default dsd should be provided
	 * @param defaultDsd the default dsd to use if the beanRetrieval is null, or if the bean retrieval does not return the dsd for the given dataset
	 */
	public AbstractSdmxDataReaderEngine(ReadableDataLocation dataLocation,
			SdmxBeanRetrievalManager beanRetrieval,
			DataStructureBean defaultDsd,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreement,
			DataReaderExceptionHandler exceptionHandler,
			BASE_DATA_FORMAT dataFormat) {
		super(beanRetrieval, defaultDsd, dataflowBean, provisionAgreement, exceptionHandler);
		this.dataLocation = dataLocation;
		schemaVersion = SdmxMessageUtil.getSchemaVersion(dataLocation);
		isTwoPointOne = schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE;
		isThreePointZero = schemaVersion == SDMX_SCHEMA.VERSION_THREE;
		enforceStrict2_1 = false;
		this.dataFormat = dataFormat;

		if(schemaVersion == SDMX_SCHEMA.VERSION_THREE) {
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_3_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_3_0;
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
			GENERIC_NS = SdmxConstants.GENERIC_NS_2_1;
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_2_1;
			COMMON_NS  = SdmxConstants.COMMON_NS_2_1;
			if (SDMX_SCHEMA.VERSION_TWO_POINT_ONE.equals(schemaVersion)) {
				String enforceStrictStr = System.getProperty("ENFORCE_STRICT_SDMX_2.1");
				enforceStrict2_1 = (enforceStrictStr != null && enforceStrictStr.equalsIgnoreCase("true"));
			}
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO) {
			GENERIC_NS = SdmxConstants.GENERIC_NS_2_0;
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_2_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_2_0;
			CROSS_NS  = SdmxConstants.CROSS_NS_2_0;
		}
		if(schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
			GENERIC_NS = SdmxConstants.GENERIC_NS_1_0;
			MESSAGE_NS = SdmxConstants.MESSAGE_NS_1_0;
			COMMON_NS  = SdmxConstants.COMMON_NS_1_0;
			CROSS_NS  = SdmxConstants.CROSS_NS_1_0;
		}
		if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
			COMPACT_NS = getTargetNamepace(dataLocation);
		}

		parser = new StaxReader(dataLocation);
	}

	protected SDMX_SCHEMA getSchemaVersion() {
		return schemaVersion;
	}

	@Override
	public String getDataFormat() {
		if(dataFormat == BASE_DATA_FORMAT.EDI) {
			return "EDI";
		}
		if(dataFormat == BASE_DATA_FORMAT.SDMXJSON) {
			return "JSON";
		}
		return dataFormat.toString()  + " v" + schemaVersion.toString();
	}

	private String getTargetNamepace(ReadableDataLocation sourceData) {
		StaxReader reader = new StaxReader(sourceData);
		String ns = null;
		try {
			if(reader.jumpToNode("DataSet", null)) {
				if(isTwoPointOne || isThreePointZero) {
					String dsType = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type");
					if(ObjectUtil.validString(dsType)) {
						String[] type = dsType.split(":");
						if(type.length < 2) {
							handleException("DataSet xsi:type expected format ns:DataSetType where ns is the structure specific namespace alias", true, SEVERITY.LOW, TYPE.NAMESPACE);
						} else {
							ns = type[0];
							if(!"DataSetType".equals(type[1])) {
								handleException("DataSet xsi:type expected format ns:DataSetType where ns is the structure specific namespace alias", true, SEVERITY.LOW, TYPE.NAMESPACE);
							}
						}
					} else {
						handleException("DataSet missing xsi:type", true, SEVERITY.LOW, TYPE.NAMESPACE);
					}
				} else {
					ns = reader.getElementNamespace();
				}
			}
			boolean validNamespace = true;
			if(ns == null) {
				validNamespace = false;
			} else if(ns.equals(GENERIC_NS)) {
				validNamespace = false;
			} else if(ns.equals(COMMON_NS)) {
				validNamespace = false;
			} else if(ns.equals(MESSAGE_NS)) {
				validNamespace = false;
			}
			if(!validNamespace) {
				handleException("Can not determine namespace for compact/structure specific dataset", true, SEVERITY.LOW, TYPE.NAMESPACE);
				ns = "BAD";
			}
			return ns;
		} finally {
			reader.close();
		}
	}

	@Override
	protected void setCurrentDsd(DataStructureBean currentDsd) {
		super.setCurrentDsd(currentDsd);
		for(ComponentBean component : currentDsd.getComponents()) {
			conceptToComponentId.put(component.getConceptRef().getReference().getIdentifiableId(), component.getId());
		}
	}

	/**
	 * Returns the id that should be output for a component Id.  This will be the id of the dimension
	 * For a 2.1 data message, this is the id of the component (and will just be returned unchanged).
	 *
	 * @param componentId
	 * @return
	 */
	protected String getComponentId(String componentId) {
		if(isTwoPointOne || isThreePointZero) {
			return componentId;
		}
		if(conceptToComponentId.containsKey(componentId)) {
			return conceptToComponentId.get(componentId);
		}
		return componentId;
	}

	/**
	 * Closes all the streams and recreates them from the input locations
	 */
	@Override
	public void reset() {
		super.reset();
		// Close all of the streams and parsers.

		lastCall = null;
		groupId = null;
		flatObs = null;

		parser.reset();
		parser.moveNextStartNode();
		//Validate Root Node
		assertNameSpace(MESSAGE_NS);
		rootNode = parser.getElementName();
		switch(dataFormat) {
		case  COMPACT :
			if(isTwoPointOne || isThreePointZero) {
				if(!rootNode.equals("StructureSpecificData") && !rootNode.equals("StructureSpecificTimeSeriesData")) {
					handleException("Unexpected Root node '"+rootNode+"' expecting 'StructureSpecificData|StructureSpecificTimeSeriesData'", true, SEVERITY.MEDIUM, TYPE.INCORRECT_ROOT_NODE);
				}
			} else {
				if(!rootNode.equals("CompactData") && !rootNode.equals("MessageGroup")) {
					handleException("Unexpected Root node '"+rootNode+"' expecting 'CompactData|MessageGroup'", true, SEVERITY.MEDIUM, TYPE.INCORRECT_ROOT_NODE);
				}
			}
			break;
		case CROSS_SECTIONAL :
			if(!rootNode.equals("CrossSectionalData") && !rootNode.equals("MessageGroup")) {
				handleException("Unexpected Root node '"+rootNode+"' expecting 'CrossSectionalData|MessageGroup'", true, SEVERITY.MEDIUM, TYPE.INCORRECT_ROOT_NODE);
			}
			break;
		case GENERIC :
			if(isTwoPointOne) {
				if(!rootNode.equals("GenericData") && !rootNode.equals("GenericTimeSeriesData")) {
					handleException("Unexpected Root node '"+rootNode+"' expecting 'GenericData|GenericTimeSeriesData'", true, SEVERITY.MEDIUM, TYPE.INCORRECT_ROOT_NODE);
				}
			} else {
				if(!rootNode.equals("GenericData") && !rootNode.equals("MessageGroup")) {
					handleException("Unexpected Root node '"+rootNode+"' expecting 'GenericData|MessageGroup'", true, SEVERITY.MEDIUM, TYPE.INCORRECT_ROOT_NODE);
				}
			}
			break;
		case UTILITY :

			break;
		}

		if(!parser.moveNextStartNode()) {
			//No Data?
		}
		if(!parser.getElementName().equals("Header")) {
			handleException("Expected Element 'Header' after dataset node, but got '"+parser.getElementName()+"", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
		}
		assertNameSpace(MESSAGE_NS);
		this.headerBean = processHeader();
	}

	@Override
	public HeaderBean getHeader() {
		return headerBean;
	}

	//protected abstract void processRootNode();

	private HeaderBean processHeader()  {
		//All the attributes required to build a header
		Map<String, String> additionalAttributes = new HashMap<>();
		IURNSingle<DataProviderBean> dataProviderReference = null;
		List<DatasetStructureReferenceBean> structure = new ArrayList<>();
		DATASET_ACTION datasetAction = null;
		String id = null;
		String datasetId = null;
		Date embargoDate = null;
		Date extracted = null;
		Date prepared = null;
		Date reportingBegin = null;
		Date reportingEnd = null;
		List<TextTypeWrapper>  name = new ArrayList<>();
		List<TextTypeWrapper> source = new ArrayList<>();
		List<PartyBean> receiver = new ArrayList<>();
		PartyBean sender = null;
		boolean test = false;
		String dsdId = null;
		String dsdAgency = null;

		String prevNode = "Header";

		List<String> mandatoryElements = new ArrayList<>();
		mandatoryElements.add("ID");
		mandatoryElements.add("Test");
		mandatoryElements.add("Prepared");
		mandatoryElements.add("Sender");

		if(isTwoPointOne) {
			mandatoryElements.add("Structure");
		}


		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			mandatoryElements.remove(nodeName);

			if (parser.isStartElement()) {
				if(nodeName.equals("Header")) {
					getAttributes();
					if(prevNode != null) {
						handleException("Header element is not expected to be under the '"+prevNode+"' element", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
					}
				} else if(nodeName.equals("ID")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					enforceHeaderPreviousNode(nodeName, prevNode, "Header");
					getAttributes();
					id = ensureTextPresent();
					if(exceptionHandler != null) {
						try {
							ValidationUtil.cleanAndValidateId(id, true);
						} catch(SdmxSemmanticException e) {
							handleException("Illegal Header Id: " + e.getMessage(), true, SEVERITY.LOW, TYPE.INVALID_ID_SYNTAX);
						}
					}
				} else if(nodeName.equals("Test")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					enforceHeaderPreviousNode(nodeName, prevNode, "ID");
					getAttributes();
					test = Boolean.valueOf(enforceContent("true", "false"));
				} else if(nodeName.equals("Prepared")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Test");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Test", "Truncated", "Name");
					}
					getAttributes();
					prepared = getDate(false);
				} else if(nodeName.equals("Sender")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Prepared");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Prepared", "Sender");
					}
					sender = processParty(nodeName, true);

				} else if(nodeName.equals("Receiver")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver");
					receiver.add(processParty(nodeName, false));
				} else if(nodeName.equals("Truncated")) {
					if(isTwoPointOne || isThreePointZero) {
						reportNotValidNode(true);
					} else {
						assertNameSpace(MESSAGE_NS);
						enforceHeaderPreviousNode(nodeName, prevNode, "Test");
						getAttributes();
						enforceContent("true", "false");
					}
				} else if(nodeName.equals("Name")) {
					if(isTwoPointOne || isThreePointZero) {
						assertNameSpace(COMMON_NS);
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "Name");
					} else {
						assertNameSpace(MESSAGE_NS);
						enforceHeaderPreviousNode(nodeName, prevNode, "Test", "Truncated", "Name");
					}
					addItemToLangMap(name);
				} else if(nodeName.equals("Structure")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "Name", nodeName);
						structure.add(processStructure());
					} else {
						reportNotValidNode(true);
					}
				} else if(nodeName.equals("DataProvider")) {
					//TODO Namespace
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure");
						dataProviderReference = parseStructureReference(nodeName, DataProviderBean.class).toType(DataProviderBean.class);
					} else {
						reportNotValidNode(true);
					}
				} else if(nodeName.equals("KeyFamilyRef")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						reportNotValidNode(true);
					} else {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver");
						getAttributes();
						dsdId =  ensureTextPresent();
					}
				} else if(nodeName.equals("KeyFamilyAgency")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						reportNotValidNode(true);
					} else {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef");
						getAttributes();
						dsdAgency = ensureTextPresent();
					}
				} else if(nodeName.equals("DataSetAgency")) {
					//TODO namespace
					if(isTwoPointOne || isThreePointZero) {
						reportNotValidNode(true);
					} else {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency");
						getAttributes();
						ensureTextPresent();
					}
				} else if(nodeName.equals("DataSetID")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", nodeName);
					} else {
						enforceHeaderNoDuplicate(nodeName, prevNode);
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency");
					}
					getAttributes();
					try {
						datasetId = ValidationUtil.cleanAndValidateId(ensureTextPresent(), true);
					} catch(SdmxSemmanticException e) {
						handleException("Illegal DataSetID: " +e.getMessage(), true, SEVERITY.LOW, TYPE.INVALID_ID_SYNTAX);
					}
				} else if(nodeName.equals("DataSetAction")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency", "DataSetID");
					}
					getAttributes();
					String actionAsString = ensureTextPresent();
					if(actionAsString != null) {
						for(DATASET_ACTION currentAction : DATASET_ACTION.values()) {
							if(currentAction.getAction().equalsIgnoreCase(actionAsString)) {
								if(exceptionHandler != null && !currentAction.getAction().equals(actionAsString)) {
									handleException("Action '"+actionAsString+"' is in the wrong case, expected '"+currentAction.getAction()+"'", true, SEVERITY.LOW, TYPE.CASE_SENSITVE);
								}
								datasetAction = currentAction;
							}
						}
						if(datasetAction == null) {
							handleException("Action '"+actionAsString+"' not supported, expected one of the following: Append, Replace, Delete, Information", true, SEVERITY.MEDIUM, TYPE.INVALILD_ACTION);
						} else if (datasetAction.equals(DATASET_ACTION.UPDATE)) {
							if (!schemaVersion.equals(SDMX_SCHEMA.VERSION_ONE)) {
								handleException("Action '"+actionAsString+"' is only supported for SDMX 1.0", true, SEVERITY.MEDIUM, TYPE.INVALILD_ACTION);
							}
							// UPDATE is not available in the internal format, so we map it to REPLACE
							datasetAction = DATASET_ACTION.REPLACE; // NOTE: the 2.0 specification seems to require APPEND, here, but that would kill EDI compatibility.
						}
					}
				} else if(nodeName.equals("Extracted")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					getAttributes();
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", "DataSetID");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency", "DataSetID", "DataSetAction");
					}
					extracted = getDate(true);
				} else if(nodeName.equals("ReportingBegin")) {
					assertNameSpace(MESSAGE_NS);
					enforceHeaderNoDuplicate(nodeName, prevNode);
					getAttributes();
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", "DataSetID", "Extracted");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency", "DataSetID", "DataSetAction", "Extracted");
					}
					reportingBegin = getDate(true);
				} else if(nodeName.equals("ReportingEnd")) {
					assertNameSpace(MESSAGE_NS);
					getAttributes();
					enforceHeaderNoDuplicate(nodeName, prevNode);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", "DataSetID", "Extracted", "ReportingBegin");
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency", "DataSetID", "DataSetAction", "Extracted", "ReportingBegin");
					}
					reportingEnd = getDate(true);
				} else if(nodeName.equals("EmbargoDate")) {
					assertNameSpace(MESSAGE_NS);
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", "DataSetID", "Extracted", "ReportingBegin", "ReportingEnd");
						embargoDate = getDate(true);
					} else {
						reportNotValidNode(true);
					}
				} else if(nodeName.equals("Source")) {
					assertNameSpace(MESSAGE_NS);
					getAttributes("lang");
					if(isTwoPointOne || isThreePointZero) {
						enforceHeaderPreviousNode(nodeName, prevNode, "Structure", "DataProvider", "DataSetAction", "DataSetID", "Extracted", "ReportingBegin", "ReportingEnd", "EmbargoDate", nodeName);
					} else {
						enforceHeaderPreviousNode(nodeName, prevNode, "Sender", "Receiver", "KeyFamilyRef", "KeyFamilyAgency", "DataSetAgency", "DataSetID", "DataSetAction", "Extracted", "ReportingBegin", "ReportingEnd", nodeName);
					}
					addItemToLangMap(source);
				} else {
					reportNotValidNode(true);
				}
				//if(inSequence) {
				prevNode = nodeName;
				//}
			} else {  //End Element
				if(nodeName.equals("Header")) {
					if(mandatoryElements.size() >0) {
						handleException("Missing Mandatory Header Elements : "+ObjectUtil.toString(mandatoryElements), true, SEVERITY.MEDIUM, TYPE.MISSING_HEADER_ELEMENT);
					}
					if(dsdId != null) {
						if(defaultDsd != null && dsdId.equals(defaultDsd.getId())) {
							structure.add(new DatasetStructureReferenceBeanImpl(defaultDsd.getURN()));
						} else {
							structure.add(new DatasetStructureReferenceBeanImpl(URN.builder().agencyId(dsdAgency).maintId(dsdId).version(MaintainableBean.DEFAULT_VERSION).buildSingle(DataStructureBean.class)));
						}
					}

					try {
						ValidationUtil.cleanAndValidateId(id, true);
					} catch(SdmxSemmanticException e) {
						// The IMF requested this so that illegal IDs do not prevent validation
						id = UUID.randomUUID().toString();
					}
					// FR-4909 always set a datasetId
					if (datasetId == null) {
						datasetId = UUID.randomUUID().toString();
					} else {
						try {
							ValidationUtil.cleanAndValidateId(datasetId, true);
						} catch(SdmxSemmanticException e) {
							datasetId = UUID.randomUUID().toString();
						}
					}

					return new HeaderBeanImpl(additionalAttributes,
							structure,
							dataProviderReference,
							datasetAction,
							id,
							datasetId,
							embargoDate,
							extracted,
							prepared,
							reportingBegin,
							reportingEnd,
							name,
							source,
							receiver,
							sender,
							test);
				}
			}
		}
		throw new SdmxSemmanticException("Dataset does not contain a Header");
	}

	protected void assertNameSpace(String ns) {
		if(exceptionHandler != null && !"BAD".equals(ns)) {
			String actualNs = parser.getElementNamespace();

			if(!ObjectUtil.validString(ns)) {
				if(ObjectUtil.validString(actualNs)) {
					handleException("Element "+parser.getXMLPath()+" is in namespace of '"+actualNs+"' but should not be in a namespace", true, SEVERITY.MEDIUM, TYPE.NAMESPACE);
				}
			} else if(!ns.equals(parser.getElementNamespace())) {
				if(!ObjectUtil.validString(parser.getElementNamespace())) {
					handleException("Element "+parser.getXMLPath()+" should have namespace of '"+ns+"' but no namespace was provided", true, SEVERITY.MEDIUM, TYPE.NAMESPACE);
				} else {
					handleException("Element "+parser.getXMLPath()+" should have namespace of '"+ns+"' but was '"+parser.getElementNamespace()+"'", true, SEVERITY.MEDIUM, TYPE.NAMESPACE);
				}
			}
		}
	}

	/**
	 *
	 * @param fullDateTime if true expects the date to include the
	 * @return
	 * @throws XMLStreamException
	 */
	private Date getDate(boolean fullDateTime) {
		String asString = ensureTextPresent();
		if(ObjectUtil.validString(asString)) {
			if(DateUtil.isSdmxDate(asString)) {
				if(exceptionHandler != null) {
					TIME_FORMAT tf = DateUtil.getTimeFormatOfDate(asString);
					if(fullDateTime) {
						if(tf != TIME_FORMAT.DATE_TIME) {
							handleException("Date '"+asString+"' for element '"+parser.getElementName()+"' expected to be of type datetime and to be in the format yyyy-MM-dd'T'HH:mm:ss", true, SEVERITY.MEDIUM, TYPE.INVALID_DATE);
						}
					} else {
						if(tf != TIME_FORMAT.DATE && tf != TIME_FORMAT.DATE_TIME) {
							handleException("Date '"+asString+"' for element '"+parser.getElementName()+"' expected to be of type date (yyyy-MM-dd) or datetime (yyyy-MM-dd'T'HH:mm:ss)", true, SEVERITY.MEDIUM, TYPE.INVALID_DATE);
						}
					}
				}
				return DateUtil.formatDate(asString, true);
			} else {
				handleException("Date '"+asString+"' for element '"+parser.getElementName()+"' is not a valid SDMX date format", true, SEVERITY.MEDIUM, TYPE.INVALID_DATE);
			}
		}
		return null;
	}

	protected void reportMissingChildNode(boolean recoverable, String... nodeNames) {
		StringBuilder sb = new StringBuilder();
		String concat = "";
		for(String name : nodeNames) {
			sb.append(concat + name);
			concat = "|";
		}
		String plur = nodeNames.length > 1 ? "one of the following child elements: " : "the following child element: ";
		handleException(parser.getXMLPath() + " is expected to have " + plur+sb.toString() , recoverable, SEVERITY.MEDIUM, TYPE.MISSING_HEADER_ELEMENT);
	}

	protected void reportNotValidNode(boolean header) {
		TYPE type = header ?  TYPE.ADDED_HEADER_ELEMNET : TYPE.ADDED_ELEMNET;
		handleException("Illegal element '"+parser.getXMLPath()+"'", true, SEVERITY.MEDIUM, type);
		parser.skipCurrentNode();
	}

	private void enforceHeaderNoDuplicate(String nodeName, String prevNode) {
		if(prevNode.equals(nodeName)  ) {
			handleException("Multiple Header elements for '"+nodeName+"', only one element expected", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_DUPLICATE);
		}
	}

	private String enforceContent(String... text) {
		TYPE type = TYPE.INVALID_HEADER_CONTENT;
		String content = ensureTextPresent();
		outer:
			if(ObjectUtil.validString(content)) {
				for(String currentText : text) {
					if(content.equals(currentText)) {
						break outer;
					}
				}
				for(String currentText : text) {
					if(content.equalsIgnoreCase(currentText)) {
						type = TYPE.CASE_SENSITVE;
					}
				}
				handleException("Element '"+parser.getXMLPath()+"'  with text content '"+content+"' was expected to have one of the following as its text content:" + Arrays.toString(text), true, SEVERITY.MEDIUM, type);

			}
		return content;
	}

	private boolean enforceHeaderPreviousNode(String nodeName, String prevNode, String... allowedPrevious) {
		if(exceptionHandler != null) {
			for(String currentPrevious : allowedPrevious) {
				if(prevNode.equals(currentPrevious)) {
					return true;
				}
			}
			StringBuilder sb = new StringBuilder();
			String prefix = "";
			String postfix = "mandatory";
			for(String currentPrevious : allowedPrevious) {
				if(currentPrevious.equals(nodeName)) {
					//Do not add name in the error if it is the same node as this one
					continue;
				}
				sb.append(prefix+currentPrevious);
				//              sb.append(prefix+currentPrevious + " ("+postfix+")");
				prefix = "|";
				postfix = "optional";
			}
			handleException("Element '"+parser.getXMLPath()+"' expected to come after the '"+sb.toString()+"' element", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
			return false;
		}
		return true;
	}

	private void addItemToLangMap(List<TextTypeWrapper> tts) {
		Map<String, String> langMap = getAttributes("lang");

		String lang =  parser.getAttributeValue(XML_NS, "lang");

		//The following exception is no longer checked as we ignore attribute name spaces
		//      try {
		//          lang =
		//      } catch(Throwable th) {
		//
		//      }
		//      if(lang == null && langMap.containsKey("lang")) {
		//          lang = langMap.get("lang");
		//          if(lang != null) {
		//              handleException("the 'lang' attribute on element '"+parser.getXMLPath()+"' should be prefixed with xml (i.e xml:lang)", true);
		//          }
		//      }
		if(lang == null) {
			lang = "en";
		}
		String value = parser.getElementText();
		if(ObjectUtil.validString(value)) {
			tts.add(new TextTypeWrapperImpl(lang, value, null));
		}
	}

	/**
	 * parser expects at position and reading a Structure node in the header
	 * @return
	 * @throws XMLStreamException
	 */
	private DatasetStructureReferenceBean processStructure() {
		String id = null;
		String serviceURL = null;
		String structureURL = null;
		String dimensionAtObservation =  null;

		String namespace = dataFormat == BASE_DATA_FORMAT.COMPACT ? "namespace" : null;
		Map<String, String> attributes = getAttributes("structureID", "serviceURL", "structureURL", "dimensionAtObservation", namespace);

		id = ensureAttributePresent("structureID", attributes, false);

		if(!ValidationUtil.isValidXsdId(id)) {
			handleException("structureID '"+id+"' is not valid. "
					+ " structureID must be of type xsd:ID.  An xsd:ID value must be an NCName. This means that it must start with a letter or underscore, and can only contain letters, digits, "+
					" underscores, hyphens, and periods.", true, SEVERITY.MEDIUM, TYPE.INVALID_ID_SYNTAX);
		}
		serviceURL = attributes.get("serviceURL");
		structureURL = attributes.get("structureURL");
		dimensionAtObservation = ensureAttributePresent("dimensionAtObservation", attributes, false);
		try {
			dimensionAtObservation = ValidationUtil.cleanAndValidateId(dimensionAtObservation, false);
		} catch(SdmxSemmanticException e) {
			handleException("Attribute 'dimensionAtObservation' for the Structure element does not contain a valid dimension id '"+dimensionAtObservation+"'", false, SEVERITY.HIGH, TYPE.UNRECOVERABLE_ERROR);
		}

		IURNSingle<IDSDRelatedBean> structureReference = null;
		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if(nodeName.equals("ProvisionAgrement") || nodeName.equals("ProvisionAgreement")) {  //This accounts for the
					//typo in the SDMX 2.1 Schema
					if(nodeName.equals("ProvisionAgreement") && !isThreePointZero) {
						handleException("'ProvisionAgreement' is not a valid Header Structure according to the SDMX Schema. Did you mean 'ProvisionAgrement'?", true, SEVERITY.MEDIUM, TYPE.ADDED_HEADER_ELEMNET);
					}
					structureReference = getReference(nodeName, ProvisionAgreementBean.class);
				} else if(nodeName.equals("StructureUsage")) {
					structureReference = getReference(nodeName, DataflowBean.class);
				} else if(nodeName.equals("Structure")) {
					structureReference = getReference(nodeName, DataStructureBean.class);
				} else {
					reportNotValidNode(true);
					reportMissingChildNode(false, "Structure", "StructureUsage", "ProvisionAgrement");
				}
			} else {
				if(nodeName.equals("Structure")) {
					break;
				}
			}
		}
		if(dimensionAtObservation.equals(DIMENSION_AT_OBSERVATION.ALL.getVal())) {
			noSeries = true;
		}
		
		return new DatasetStructureReferenceBeanImpl(id, structureReference, serviceURL, structureURL, dimensionAtObservation);
	}
	
	private IURNSingle<IDSDRelatedBean> getReference(String nodeName, Class<? extends IDSDRelatedBean> expectedType) {
		//Check exptected type
		IURNSingle<?> structureReference = parseStructureReference(nodeName, expectedType);
		if(!structureReference.isType(expectedType)) {
			ISDMXStructureType<?, ?> type = StructureTypes.getAnyStructureType(expectedType);
			boolean recoverable = structureReference.isType(IDSDRelatedBean.class);
			SEVERITY severity = recoverable ? SEVERITY.MEDIUM : SEVERITY.HIGH;
			handleException("Structure reference defined in "+parser.getXMLPath()+" was expected to be a reference to structure type '"+type.toString()+
					"' but got a reference to structure type '"+structureReference.getStructureType().toString()+"'", recoverable, severity, TYPE.STRUCUTRE_REF_INCONSISTENT_WITH_HEADER);
		}
		
		return structureReference.toType(IDSDRelatedBean.class);
	}

	private IURNSingle<?> parseURN(String urn) {
		try {
			return URN.builder(urn).buildSingle();
		} catch(Throwable th) {
			handleException("Could not process element "+parser.getXMLPath()+" -  Illegal URN '"+urn+"'", false, SEVERITY.HIGH, TYPE.UNRECOVERABLE_ERROR);
			return null;
		}
	}
	
	private IURNSingle<?> parseStructureReference(String parseNodeName, Class<? extends ConstrainableBean> claz) {
		getAttributes();
		if (isThreePointZero) {
			String nodeName = parser.getElementName();
			String[] nodeNames = new String[] {"StructureUsage", "Structure", "ProvisionAgreement"};
			if( Arrays.asList(nodeNames).contains(nodeName)){
				String urn = parser.getElementText();
				if (ObjectUtil.validString(urn)){
					return parseURN(urn);
				}
			}
			throw new RuntimeException("Dataset structure reference invalid, could not process reference, no URN found");

		} else {
			while (parser.moveNextNode()) {
				String nodeName = parser.getElementName();
				if (parser.isStartElement()) {
					if(nodeName.equals("Ref")) {

						Map<String, String> attributes = getAttributes("agencyID", "id", "version", "maintainableParentID","maintainableParentVersion", "local", "class", "package");

						String agencyId = attributes.get("agencyID");
						String id = attributes.get("id");
						String maintainableId = attributes.get("maintainableParentID");
						String version = attributes.get("version");

						
						if(!ObjectUtil.validString(agencyId)) {
							throw new RuntimeException("Dataset structure reference incomplete, missing agencyId");
						}
						if(!ObjectUtil.validString(id)) {
							throw new RuntimeException("Dataset structure reference incomplete, missing id");
						}
						if (!ObjectUtil.validString(version)) {
							// FR-4391 - schema states that if a version is not specified, the default value is "1.0"
							version = "1.0";
						}
						
						URNBuilder urnBuilder = URN.builder().agencyId(agencyId).version(version);  
						if(maintainableId != null) {
							return urnBuilder.maintId(maintainableId).identifableId(id).buildSingle(DataProviderBean.class);
						} else {
							urnBuilder.maintId(id);
						}
						return urnBuilder.buildSingle(claz);
					} else if(nodeName.equals("URN")) {
						assertNameSpace(null);
						String urn = ensureTextPresent();
						return parseURN(urn);
					} else {
						reportNotValidNode(true);
					}
				} else {
					if (nodeName.equals(parseNodeName)) {
						break;
					}
				}
			}
			reportMissingChildNode(false, "Ref", "URN");
			return null;
		}
	}

	private PartyBean processParty(String partyNodeName, boolean isSender) {
		Map<String, String> attributes = getAttributes("id");
		String id = attributes.get("id"); //TODO Validate IDType start with int allowed

		String el = isSender ? "Sender" : "Receiver";

		String timeZone = null;
		List<TextTypeWrapper> nameMap = new ArrayList<>();
		List<ContactBean> contacts = new ArrayList<>();

		String prevNode = null;
		String xpath = parser.getXMLPath();
		ensureNoTextContent();
		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if(nodeName.equals("Name")) {
					if(prevNode != null && !prevNode.equals("Name")) {
						handleException("Error in Header/"+el+"'. The 'Name' element expected to come directly after the '"+el+"' element", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
					}
					addItemToLangMap(nameMap);
				} else if(nodeName.equals("Timezone")) {
					if(!isTwoPointOne && !isThreePointZero) {
						handleException("Error in '"+parser.getXMLPath()+"'. The 'Timezone' element is not expected in this version of SDMX", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
					}
					if(!isSender) {
						handleException("Error in '"+parser.getXMLPath()+"'. The 'Timezone' element is not expected", true, SEVERITY.LOW, TYPE.HEADER_ELEMENT_ORDER);
					} else {
						timeZone = ensureTextPresent();
					}
				} else if(nodeName.equals("Contact")) {
					contacts.add(processContact());
				} else {
					reportNotValidNode(true);
				}
			} else {
				if(nodeName.equals(partyNodeName)) {
					break;
				}
			}
		}
		try {
			return new PartyBeanImpl(nameMap, id, contacts, timeZone);
		} catch(SdmxException e) {
			if(exceptionHandler != null) {
				handleException("Invalid " +xpath+": "+ e.getMessage(), true, SEVERITY.MEDIUM, TYPE.INVALID_SENDER_RECIEVER);
				return null;
			}
			throw e;
		}
	}

	private void ensureNoTextContent() {
		//      if(ObjectUtil.validString(parser.getElementText())) {
		//          handleException("Text content was not expected for element  " +parser.getXMLPath()+"  but got: "+ parser.getElementText(), true);
		//      }
	}

	protected Map<String, String> getAttributes(String...allowedAttributes) {
		Map<String, String> returnMap = new HashMap<>();
		Set<String> allowedAttributesSet = null;
		if(exceptionHandler != null) {
			allowedAttributesSet = new HashSet<>();
			allowedAttributesSet.add("type");
			if(allowedAttributes != null) {
				for(String at : allowedAttributes) {
					allowedAttributesSet.add(at);
				}
			}
		}
		for(int i=0; i < parser.getAttributeCount(); i++) {
			String attrName = parser.getAttributeLocalName(i);
			if(allowedAttributesSet != null && !allowedAttributesSet.contains(attrName)) {
				handleException("Unexpected XML attribute '"+attrName+"' for element '"+parser.getXMLPath()+"", true, SEVERITY.HIGH, TYPE.ADDED_ATTRIBUTE);
			}
			returnMap.put(attrName, parser.getAttributeValue(i));
		}
		return returnMap;
	}

	private ContactBean processContact() {
		List<TextTypeWrapper> name = new ArrayList<>();
		List<TextTypeWrapper> role = new ArrayList<>();
		List<TextTypeWrapper> departments = new ArrayList<>();
		List<String> email = new ArrayList<>();
		List<String> fax = new ArrayList<>();
		List<String> telephone = new ArrayList<>();
		List<String> uri = new ArrayList<>();
		List<String> x400 = new ArrayList<>();

		//TODO Order of nodes
		String prevNode = "Contact";
		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if(nodeName.equals("Name")) {
					enforceHeaderPreviousNode(nodeName, prevNode, "Contact", nodeName);
					addItemToLangMap(name);
				} else if(nodeName.equals("Department")) {
					enforceHeaderPreviousNode(nodeName, prevNode, "Contact", "Name", nodeName);
					addItemToLangMap(departments);
				} else if(nodeName.equals("Role")) {
					enforceHeaderPreviousNode(nodeName, prevNode, "Contact", "Name", "Department", nodeName);
					addItemToLangMap(role);
				}  else if(nodeName.equals("Telephone")) {
					telephone.add(parser.getElementText());
				} else if(nodeName.equals("Fax")) {
					fax.add(ensureTextPresent());
				} else if(nodeName.equals("X400")) {
					x400.add(ensureTextPresent());
				} else if(nodeName.equals("URI")) {
					uri.add(ensureTextPresent());
				} else if(nodeName.equals("Email")) {
					email.add(ensureTextPresent());  //TODO Verify Email?
				} else {
					handleException("Error in Header.  Unexpected element '"+nodeName+"' for Contact element", true, SEVERITY.LOW, TYPE.ADDED_HEADER_ELEMNET);
				}
			} else {
				if(nodeName.equals("Contact")) {
					break;
				}
			}
		}
		return new ContactBeanImpl(name, role, departments, email, fax, telephone, uri, x400);
	}

	protected String ensureTextPresent()  {
		String str = null;
		try {
			str = parser.getElementText();
		} catch(StaxException e) {
			handleException("Element '"+parser.getXMLPath()+"' should have text content but has unexpected child elements", false, SEVERITY.HIGH, TYPE.ADDED_HEADER_ELEMNET);
		}
		if(!ObjectUtil.validString(str)) {
			handleException("Element '"+parser.getXMLPath()+"' should have text content", true, SEVERITY.MEDIUM, TYPE.INVALID_HEADER_CONTENT);
			return null;  //Return null here as str may be an empty string which we do not want to return
		}
		return str;
	}

	protected String ensureAttributePresent(String attr, Map<String, String> attributes, boolean recoverable) {
		if(!attributes.containsKey(attr)) {
			handleException("Attribute '"+attr+"' for element '"+parser.getXMLPath()+"'  is mandatory and was not provided", recoverable, SEVERITY.HIGH, TYPE.MISSING_XML_ATTRIBUTE);
			return null;
		}
		String attribute = attributes.get(attr);
		if(!ObjectUtil.validString(attribute)) {
			handleException("Attribute '"+attr+"' for element '"+parser.getXMLPath()+"' is mandatory and has no content", recoverable, SEVERITY.HIGH, TYPE.MISSING_XML_ATTRIBUTE);
			return null;
		}
		return attribute;
	}

	/**
	 * Implementation of Move next, does not actually set the currentObs value, as it is lazy loaded on demand - instead this operation moves the pointer in the file
	 * to the next observation to be read (if there is one) and reports true if there is a next observation to be read.
	 */
	@Override
	protected boolean moveNextObservationInternal() {
		try {
			currentObs = null;  //Set the current observation to null, this is so when the user reads the observation it can generate it on demand

			//If we are at the end of the file, then return false, there is no point in processing anything
			if(!hasNext) {
				return false;
			}
			//If the dataset position is an observation that is also acting as a series, then the following rules apply;
			//1. The user has made a call on hasNextSeries, this has returned true, but they have not processed the series, in this case, we need to process the series to extract the observation
			//2. The user's last call was readNextSeries, in which case there will be an observation, as the series IS also the observation
			//3. The user's last call was hasNextObservation, or readNextObs in both cases we return false, as there is only one observation here
			if(datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
				if(lastCall == LAST_CALL.HAS_NEXT_SERIES || lastCall == LAST_CALL.NEXT_SERIES) {
					currentObs = flatObs;
					return true;
				}
				//We have read the next obs, or already made this call, set the position to null and return false
				datasetPosition = null;
				return false;
			}
			if(next(true) && datasetPosition!= DATASET_POSITION.GROUP && datasetPosition != DATASET_POSITION.SERIES && datasetPosition != DATASET_POSITION.DATASET) {
				XMLElementPosition elementStartPos = parser.getXMLElementPosition();
				currentObs = processObsNode(parser);
				XMLElementPosition elementEndPos = parser.getXMLElementPosition();
				currentObs = new PositionalObservation(currentObs, getFilePosition(elementStartPos, elementEndPos));
				return datasetPosition == DATASET_POSITION.OBSERVATION;

			}
			return false;
		} catch(SdmxException e) {
			throw e;
		} finally {
			lastCall = LAST_CALL.HAS_NEXT_OBS;
		}
	}
	@Override
	protected Observation lazyLoadObservation(){
		return null;
	}
	@Override
	protected boolean moveNextDatasetInternal() {
		try {
			//If a check was made to hasNextSeries, the parser may have moved forward to the next dataset,
			if(lastCall != LAST_CALL.HAS_NEXT_DATASET && datasetPosition == DATASET_POSITION.DATASET)  {
				return true;
			}
			//Set the dataset to null at this point, as it may be recreated
			datasetHeaderBean = null;
			while(next(false)) {
				if(datasetPosition == DATASET_POSITION.DATASET) {
					return true;
				}
			}
			return false;

		} finally {
			lastCall = LAST_CALL.HAS_NEXT_DATASET;
			processDatasetElement();
		}
	}
	
	/**
	 * Process the Dataset element by building the DatasetHeaderBean, and notify position if there is a notifier
	 */
	private void processDatasetElement() {
		if(datasetPosition == DATASET_POSITION.DATASET) {
			XMLElementPosition elementStartPos =  parser.getXMLElementPosition();
			this.datasetHeaderBean = processDataSetNode();
			XMLElementPosition elementEndPos = parser.getXMLElementPosition();
			//datasetHeaderBean =
			IFilePosition filePosition = getFilePosition(elementStartPos, elementEndPos);
			super.currentDatasetAttributes =  getDatasetAttributesBuilder().position(filePosition).build();
		}
	}
	
	@Override
	protected IDatasetAttributes lazyLoadDatasetAttributes() {
		return super.currentDatasetAttributes;
	}

	protected abstract AttributableBuilder<IDatasetAttributes> getDatasetAttributesBuilder();


	@Override
	protected boolean moveNextKeyableInternal() {
		try {
			if(datasetPosition == DATASET_POSITION.DATASET
					&& lastCall != LAST_CALL.HAS_NEXT_DATASET) {
				return false;
			}

			//If a check was made to hasNextObservation, the parser may have moved forward to the next series as obs,
			//and this may not yet have been processed, in which case check to see if a call has been made to hasNextKeyable since the last
			//call to hasNextObservation
			if(lastCall == LAST_CALL.HAS_NEXT_OBS
					&& (datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES
					|| datasetPosition == DATASET_POSITION.SERIES
					|| datasetPosition == DATASET_POSITION.GROUP))  {
				return true;
			}
			while(next(false)) {
				if(datasetPosition == DATASET_POSITION.SERIES
						|| datasetPosition == DATASET_POSITION.GROUP
						|| datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
					return true;
				}
				if(datasetPosition == DATASET_POSITION.DATASET) {
					return false;
				}
			}
			return false;
		} catch(SdmxException e) {
			handleException("Error while attempting to read key: " +e.getMessage(), false, SEVERITY.HIGH, TYPE.UNRECOVERABLE_ERROR);
			return false;
		} finally {
			lastCall = LAST_CALL.HAS_NEXT_SERIES;
			processKeyableElement();
		}
	}
	
	/**
	 * Process the Series or Group element
	 */
	private void processKeyableElement() {
		XMLElementPosition elementStartPos = parser.getXMLElementPosition();
		if (datasetPosition == DATASET_POSITION.SERIES ||
				datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
			processSeriesNode();
			if(datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
				flatObs = currentObs;
			}
		} else if (datasetPosition == DATASET_POSITION.GROUP) {
			processGroupNode();
		}
		XMLElementPosition elementEndPos = parser.getXMLElementPosition();
		if (currentKey == null) {
			return;
		}
		currentKey = new PositionalKey(currentKey, getFilePosition(elementStartPos, elementEndPos));
	}
	
	private FilePosition getFilePosition(XMLElementPosition elementStartPos, XMLElementPosition elementEndPos) {
		XMLElementPosition elementPos = elementStartPos.merge(elementEndPos);
		return new FilePosition(elementPos.getByteOffset(), elementPos.getByteLength());
	}

	@Override
	protected Keyable lazyLoadKey() {
		try {
			//If the last call was to read the next series, then we are reading the one after that, so move on,
			//Otherwise, if we're not on a series, group, or obs as series, move on
			if(lastCall == LAST_CALL.NEXT_SERIES ||
					(datasetPosition != DATASET_POSITION.SERIES
					&& datasetPosition != DATASET_POSITION.GROUP
					&& datasetPosition != DATASET_POSITION.OBSERAVTION_AS_SERIES)) {
				if(!moveNextKeyable()) {
					return null;
				}
			}

			if(datasetPosition == DATASET_POSITION.GROUP) {
				Keyable key = processGroupNode();
				if(LOG.isDebugEnabled()) {
					LOG.debug("Read Key " + key.toString());
				}
				return key;
			} else if(datasetPosition == DATASET_POSITION.SERIES || datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
				Keyable key = processSeriesNode();
				flatObs = currentObs;   //STORE THE OBSERVATION LOCALLY IN THIS CLASS THAT WAS CREATED AS PART OF GENERATING THE SERIES
				if(LOG.isDebugEnabled()) {
					LOG.debug(key.toString());
				}
				return key;
			}
			return null;
		} finally {
			lastCall = LAST_CALL.NEXT_SERIES;
		}
	}

	protected List<AnnotationBean> processAnnotations(StaxReader parser) {
		List<AnnotationBean> annotations = new ArrayList<>();
		while(parser.moveNextNode()) {
			if(!parser.isStartElement() && parser.getElementName().equals("Annotations")) {
				break;
			}
			if(parser.isStartElement()) {
				if(parser.getElementName().equals("Annotation")) {
					annotations.add(processAnnotation(parser));
				}
			}
		}
		return annotations;
	}

	private AnnotationBean processAnnotation(StaxReader parser) {
		AnnotationMutableBean annotationMutable = new AnnotationMutableBeanImpl();
		annotationMutable.setId(parser.getAttributeValue(null, "id"));

		while(parser.moveNextNode()) {
			if(!parser.isStartElement() && parser.getElementName().equals("Annotation")) {
				break;
			}
			if(parser.isStartElement()) {
				if(parser.getElementName().equals("AnnotationTitle")) {
					annotationMutable.setTitle(parser.getElementText());
				} else if(parser.getElementName().equals("AnnotationType")) {
					annotationMutable.setType(parser.getElementText());
				}  else if(parser.getElementName().equals("AnnotationURL")) {
					annotationMutable.setUri(parser.getElementText());
				}  else if(parser.getElementName().equals("AnnotationText")) {
					String locale = parser.getAttributeValue("xml", "lang");
					annotationMutable.addText(locale, parser.getElementText());
				}
			}
		}
		return new AnnotationBeanImpl(annotationMutable, null);
	}


	@Override
	public List<FooterMessage> close() {
		closeStreams();
		if(dataLocation != null) {
			dataLocation.close();
			dataLocation = null;
		}
		return null;
	}

	private void closeStreams() {
		if (parser != null) {
			parser.close();
		}
	}

	protected abstract DatasetHeaderBean processDataSetNode();
	
	protected abstract Keyable processGroupNode();

	protected abstract Keyable processSeriesNode();

	protected abstract Observation processObsNode(StaxReader parser);

	protected abstract boolean next(boolean includeObs);

	protected String getRootNode() {
		return rootNode;
	}

}
