package io.sdmx.format.ml.util;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.format.ml.engine.data.writer.SdmxDataWriterEngine;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.Namespace;

public class SDMXMLWriterUtil {
	
	public static void writeNameSpace(XMLStreamWriter writer, Namespace ns) throws XMLStreamException {
		if(ns != null) {
			writer.writeNamespace(ns.getNamespacePrefix(), ns.getNamespaceURL());
		}
	}

	public static void startElement(XMLStreamWriter streamWriter, Namespace ns, String elementName) throws XMLStreamException  {
		streamWriter.writeStartElement(ns.getNamespacePrefix(), elementName, ns.getNamespaceURL());
	}

	//TODO Placeholder for future implementation
//	/**
//	 * Writes the header to the writer
//	 */
//	private void writeHeader(XMLStreamWriter writer, HeaderBean header, Namespace MESSAGE_NS, Namespace COMMON_NS, SDMX_SCHEMA version) {
//		try {
//			startElement(writer, MESSAGE_NS, "Header");  //START HEADER
//			//ID
//			startElement(writer, MESSAGE_NS, "ID");
//			if(header != null && ObjectUtil.validString(header.getId())) {
//				writer.writeCharacters(header.getId());
//			} else {
//				writer.writeCharacters("DS"+Long.toString(new Date().getTime()));
//			}
//			writer.writeEndElement();
//
//			//Test
//			startElement(writer, MESSAGE_NS, "Test");
//			if(header != null) {
//				writer.writeCharacters(new Boolean(header.isTest()).toString());
//			} else {
//				writer.writeCharacters("false");
//			}
//			writer.writeEndElement();
//
//			if(!isTwoPointOne() && header != null && header.getName() != null) {
//				//In 2.0 the name goes in this location
//				writeTextTypes(MESSAGE_NS, "Name", header.getName());
//			}
//
//			//Prepared
//			startElement(writer, MESSAGE_NS, "Prepared");
//			if(header != null && header.getPrepared() != null) {
//				writer.writeCharacters(DateUtil.formatDate(header.getPrepared(), true));
//			} else {
//				writer.writeCharacters(DateUtil.formatDate(new Date(), true));
//			}
//			writer.writeEndElement();
//
//			startElement(writer, MESSAGE_NS, "Sender");
//			if(header != null && header.getSender() != null) {
//				writeParty(header.getSender(), isTwoPointOne()); //Only 2.1 has the concept of timeZone in the Sender
//			} else {
//				if (headerRetrievalManager != null && headerRetrievalManager.getHeader() != null) {
//					writeParty(headerRetrievalManager.getHeader().getSender(), isTwoPointOne()); //Only 2.1 has the concept of timeZone in the Sender
//				} else {
//					writer.writeAttribute("id", "MetadataTechnology");
//				}
//			}
//			writer.writeEndElement();
//
//			if(header != null && header.getReceiver() != null) {
//				writeReceiver(header.getReceiver());
//			}
//			if(isTwoPointOne() && header != null && header.getName() != null) {
//				//In 2.1 the name goes in this location
//				writeTextTypes(COMMON_NS, "Name", header.getName());
//			}
//			Map<MaintainableBean, SdmxDataWriterEngine.Namespace> constrainables = new HashMap<>();
//			Set<DataStructureBean> dsds = new HashSet<>();
//			for(DataSetOutputStreams os : outputDatasetLocations) {
//				constrainables.put(os.getStructureForData(), os.dataNamespace);
//				dsds.add(os.dsd);
//			}
//
//			if(isTwoPointOne()) {
//				for(MaintainableBean currentStructure : constrainables.keySet()) {
//					//Start Structure
//					startElement(writer, MESSAGE_NS, "Structure");
//
//					writer.writeAttribute("structureID", getStructureRef(currentStructure));
//
//
//					if(dataFormat == BASE_DATA_FORMAT.COMPACT) {
//						//currentStructure.get
//						SdmxDataWriterEngine.Namespace ns = constrainables.get(currentStructure);
//						if(ns == null) {
//							ns = COMPACT_NS;
//						}
//						writer.writeAttribute("namespace", ns.namespaceURL);
//					}
//					if(crossSectionConcept != null) {
//						writer.writeAttribute("dimensionAtObservation", crossSectionConcept);
//					} else {
//						writer.writeAttribute("dimensionAtObservation", DimensionBean.TIME_DIMENSION_FIXED_ID);
//					}
//
//					//Start Structure (in this case Structure refers to DSD)
//					if(currentStructure instanceof ProvisionAgreementBean) {
//						startElement(writer, COMMON_NS, "ProvisionAgrement");
//					} else if(currentStructure instanceof DataflowBean) {
//						startElement(writer, COMMON_NS, "StructureUsage");
//					} else {
//						startElement(writer, COMMON_NS, "Structure");
//					}
//
//					//Start Ref
//					writer.writeStartElement("Ref");
//
//
//					writer.writeAttribute("agencyID", currentStructure.getAgencyId());
//					writer.writeAttribute("id", currentStructure.getId());
//					writer.writeAttribute("version", currentStructure.getVersion());
//					//End Ref
//					writer.writeEndElement();
//
//					//End Structure
//					writer.writeEndElement();
//
//					//End Structure
//					writer.writeEndElement();
//				}
//			} else if(dsds.size() == 1) {
//				DataStructureBean dsd = (DataStructureBean)dsds.toArray()[0];
//				StructureReferenceBean dsdRef = dsd.asReference();
//				// KeyFamilyRef
//				startElement(writer, MESSAGE_NS, "KeyFamilyRef");
//				writer.writeCharacters(dsdRef.getMaintainableReference().getMaintainableId());
//				writer.writeEndElement();
//
//				// KeyFamilyAgency
//				startElement(writer, MESSAGE_NS, "KeyFamilyAgency");
//				writer.writeCharacters(dsdRef.getMaintainableReference().getAgencyId());
//				writer.writeEndElement();
//			}
//			//The following are all optional, and only output if the header is not null
//			if(header != null) {
//				if(isTwoPointOne()  && header.getDataProviderReference() != null) {
//					MaintainableRefBean ref = header.getDataProviderReference().getMaintainableReference();
//					if(ObjectUtil.validString(ref.getAgencyId(), ref.getMaintainableId())) {
//						//Start DataProvider
//						startElement(writer, MESSAGE_NS, "DataProvider");
//
//						//Start Ref
//						writer.writeStartElement("Ref");
//						writer.writeAttribute("agencyID", ref.getAgencyId());
//						writer.writeAttribute("id", ref.getMaintainableId());
//						if(ObjectUtil.validString(ref.getVersion())) {
//							writer.writeAttribute("version", ref.getVersion());
//						} else {
//							writer.writeAttribute("version", MaintainableBean.DEFAULT_VERSION);
//						}
//						//End Ref
//						writer.writeEndElement();
//
//						//End DataProvider
//						writer.writeEndElement();
//
//					}
//				}
//				if(!isTwoPointOne() && header.hasAdditionalAttribute(HeaderBean.DATASET_AGENCY)) {
//					startElement(writer, MESSAGE_NS, "DataSetAgency");
//					writer.writeCharacters(header.getAdditionalAttribute(HeaderBean.DATASET_AGENCY));
//					writer.writeEndElement();
//				}
//				String datasetId = getDatasetIdForHeader(header);
//				String datasetAction = getDatasetActionForHeader(header);
//
//				if(datasetAction != null) {
//					//FR-4101: Enforce that action 'Update' is only applicable for 1.0 messages
//					if(schemaVersion == SDMX_SCHEMA.VERSION_ONE) {
//						if(datasetAction.equals(DATASET_ACTION.REPLACE.getAction())) {
//							datasetAction = DATASET_ACTION.UPDATE.getAction();
//						}
//					} else if(datasetAction.equals(DATASET_ACTION.UPDATE.getAction())) {
//						datasetAction = DATASET_ACTION.REPLACE.getAction();
//					}
//				}
//
//
//				if(isTwoPointOne()) {
//					writeDatasetAction(datasetAction);
//					writeDatasetId(datasetId);
//				} else {
//					writeDatasetId(datasetId);
//					writeDatasetAction(datasetAction);
//				}
//
//				if(header.getExtracted() != null) {
//					startElement(writer, MESSAGE_NS, "Extracted");
//					writer.writeCharacters(DateUtil.formatDate(header.getExtracted()));
//					writer.writeEndElement();
//				}
//				String reportingBeginDate = getReportingBeginForHeader(header);
//				if(reportingBeginDate != null) {
//					startElement(writer, MESSAGE_NS, "ReportingBegin");
//					writer.writeCharacters(reportingBeginDate);
//					writer.writeEndElement();
//				}
//
//				String reportingEndDate = getReportingEndForHeader(header);
//				if(reportingEndDate != null) {
//					startElement(writer, MESSAGE_NS, "ReportingEnd");
//					writer.writeCharacters(reportingEndDate);
//					writer.writeEndElement();
//				}
//				if(isTwoPointOne() && header.getEmbargoDate() !=  null) {
//					startElement(writer, MESSAGE_NS, "EmbargoDate");
//					writer.writeCharacters(DateUtil.formatDate(header.getEmbargoDate()));
//					writer.writeEndElement();
//				}
//				writeTextTypes(MESSAGE_NS, "Source", header.getSource());
//			}
//
//			writer.writeEndElement(); //END HEADER
//		} catch(XMLStreamException e) {
//			throw new RuntimeException(e);
//		}
//	}
//	
//	
//	
//	private static boolean writeDatasetId(XMLStreamWriter writer, Namespace MESSAGE_NS, String datasetId) throws XMLStreamException {
//		if(ObjectUtil.validString(datasetId)) {
//			startElement(writer, MESSAGE_NS, "DataSetID");
//			writer.writeCharacters(datasetId);
//			writer.writeEndElement();
//			return true;
//		}
//		return false;
//	}
//
//	private static boolean writeDatasetAction(XMLStreamWriter writer, Namespace MESSAGE_NS, String datasetAction) throws XMLStreamException {
//		if(ObjectUtil.validString(datasetAction)) {
//			startElement(writer, MESSAGE_NS, "DataSetAction");
//			writer.writeCharacters(datasetAction);
//			writer.writeEndElement();
//			return true;
//		}
//		return false;
//	}
//	
//
//	/**
//	 * Returns the reporting begin date for the header.
//	 * If the header does not contain this information, obtain the information from the datasets.
//	 * If there are no datasets, null will be returned.
//	 * If there is only one dataset, use that datasets information (if available).
//	 * If there is more than one dataset, all datasets will be inspected. If they all have the same reporting begin date, that value
//	 * will be returned otherwise null will be returned.
//	 * @return returns the dataset action or null if the reporting begin date could not be determined.
//	 */
//	private String getReportingBeginForHeader(HeaderBean header) {
//		if (header.getReportingBegin() != null) {
//			return DateUtil.formatDate(header.getReportingBegin());
//		}
//
//		if (outputDatasetLocations.size() == 0) {
//			return null;
//		}
//
//		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
//		if (primaryHeaderBean == null || primaryHeaderBean.getReportingBeginDate() == null) {
//			return null;
//		}
//
//		if (outputDatasetLocations.size() == 1) {
//			return DateUtil.formatDate(primaryHeaderBean.getReportingBeginDate());
//		}
//
//		Date primaryDate = primaryHeaderBean.getReportingBeginDate();
//		for (int i=1; i < outputDatasetLocations.size(); i++) {
//			DatasetHeaderBean headerBean = outputDatasetLocations.get(i).headerBean;
//			if (headerBean == null || headerBean.getReportingBeginDate() == null) {
//				return null;
//			}
//			if (!primaryDate.equals(headerBean.getReportingBeginDate())) {
//				return null;
//			}
//		}
//		return DateUtil.formatDate(primaryDate);
//	}
//	/**
//	 * Returns the reporting end date for the header.
//	 * If the header does not contain this information, obtain the information from the datasets.
//	 * If there are no datasets, null will be returned.
//	 * If there is only one dataset, use that datasets information (if available).
//	 * If there is more than one dataset, all datasets will be inspected. If they all have the same reporting end date, that value
//	 * will be returned otherwise null will be returned.
//	 * @return returns the dataset action or null if the reporting end date could not be determined.
//	 */
//	public static String getReportingEndForHeader(HeaderBean header) {
//		if(header.getReportingEnd() != null) {
//			return DateUtil.formatDate(header.getReportingEnd());
//		}
//
//		if (outputDatasetLocations.size() == 0) {
//			return null;
//		}
//
//		DatasetHeaderBean primaryHeaderBean = outputDatasetLocations.get(0).headerBean;
//		if (primaryHeaderBean == null || primaryHeaderBean.getReportingEndDate() == null) {
//			return null;
//		}
//
//		if (outputDatasetLocations.size() == 1) {
//			return DateUtil.formatDate(primaryHeaderBean.getReportingEndDate());
//		}
//
//		Date primaryDate = primaryHeaderBean.getReportingEndDate();
//		for (int i=1; i < outputDatasetLocations.size(); i++) {
//			DatasetHeaderBean headerBean = outputDatasetLocations.get(i).headerBean;
//			if (headerBean == null || headerBean.getReportingEndDate() == null) {
//				return null;
//			}
//			if (!primaryDate.equals(headerBean.getReportingEndDate())) {
//				return null;
//			}
//		}
//		return DateUtil.formatDate(primaryDate);
//	}
//
//	public static void writeReceiver(List<PartyBean> receivers) throws XMLStreamException {
//		if(receivers != null) {
//			for(PartyBean currentReceiver : receivers) {
//				startElement(writer, MESSAGE_NS, "Receiver");
//				writeParty(currentReceiver, false);
//				writer.writeEndElement();
//			}
//		}
//	}
//
//	public static void writeParty(PartyBean party, boolean includeTimeZone) throws XMLStreamException {
//		if(ObjectUtil.validString(party.getId())) {
//			writer.writeAttribute("id", party.getId());
//			if(party.getName() != null) {
//				Namespace nameNamespace = schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE ? COMMON_NS : MESSAGE_NS;
//				writeTextTypes(nameNamespace, "Name", party.getName());
//			}
//			if(party.getContacts() != null) {
//				writeContacts(party.getContacts());
//			}
//			if(includeTimeZone && ObjectUtil.validString(party.getTimeZone())) {
//				startElement(writer, MESSAGE_NS, "Timezone");
//				writer.writeCharacters(party.getTimeZone());
//				writer.writeEndElement();
//			}
//		} else {
//			writer.writeAttribute("id", "ZZZ");
//		}
//	}
//
//	public static void writeTextTypes(Namespace ns, String elementName, List<TextTypeWrapper> textTypes) throws XMLStreamException {
//		if(textTypes != null) {
//			for(TextTypeWrapper tt : textTypes) {
//				startElement(writer, ns, elementName);
//				writer.writeAttribute("xml", XML_NS, "lang", tt.getLocale());
//				writer.writeCharacters(tt.getValue());
//				writer.writeEndElement();
//			}
//		}
//	}
//
//	public static void writeListContents(Namespace nameSpace, String elementName, List<String> list) throws XMLStreamException {
//		if(list != null) {
//			for(String value : list) {
//				if(ObjectUtil.validString(value)) {
//					startElement(writer, nameSpace, elementName);
//					writer.writeCharacters(value);
//					writer.writeEndElement();
//				}
//			}
//		}
//	}
//
//	public static void writeContacts(List<ContactBean> contacts) throws XMLStreamException {
//		if(contacts != null) {
//			for(ContactBean currentContact : contacts) {
//				startElement(writer, MESSAGE_NS, "Contact");
//				writeContact(currentContact);
//				writer.writeEndElement();
//			}
//		}
//	}
//
//
//	public static void writeContact(ContactBean contact) throws XMLStreamException {
//		Namespace nameNamespace = schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE ? COMMON_NS : MESSAGE_NS;
//		writeTextTypes(nameNamespace, "Name", contact.getName());
//		writeTextTypes(MESSAGE_NS, "Department", contact.getDepartments());
//		writeTextTypes(MESSAGE_NS, "Role", contact.getRole());
//		writeListContents(MESSAGE_NS, "Telephone", contact.getTelephone());
//		writeListContents(MESSAGE_NS, "Fax", contact.getFax());
//		writeListContents(MESSAGE_NS, "X400", contact.getX400());
//		writeListContents(MESSAGE_NS, "URI", contact.getUri());
//		writeListContents(MESSAGE_NS, "Email", contact.getEmail());
//	}
}
