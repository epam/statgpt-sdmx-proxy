package io.sdmx.format.ml.engine.structure.reader.v20.metadataflow;

import io.sdmx.api.sdmx.model.mutable.metadatastructure.MetadataFlowMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxStructureUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.metadatastructure.MetadataflowMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMetadataflowReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<MetadataFlowMutableBean> {
    private static StaxMetadataflowReaderEngineV2 INSTANCE;

    //Private constructor - lazy load instance
    private StaxMetadataflowReaderEngineV2() {}
    public static StaxMetadataflowReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxMetadataflowReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Metadataflows";
    }

    @Override
    protected String getRootNodeName() {
        return "Metadataflow";
    }

    @Override
    protected MetadataFlowMutableBean processMaintainable(IStaxReader reader) {
        MetadataFlowMutableBean maint = new MetadataflowMutableBeanImpl();
        StaxMaintainableUtilV2.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("MetadataStructureRef")) {
                maint.setMetadataStructureRef( StaxStructureUtilV2.obtainKeyFamilyRefForMSD(reader) );
            } else if(reader.getElementName().equals("CategoryRef")) {
                //Not Supported
            } else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode(); // Move to the end of the annotations
        }

        return maint;
    }
}
