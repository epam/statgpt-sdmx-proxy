package io.sdmx.format.ml.engine.structure.reader.v21;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxStructureReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.categorisation.StaxCategorisationReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.catscheme.StaxCategorySchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.codelist.StaxCodelistReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.conceptscheme.StaxConceptSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.constraint.StaxContentConstraintReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.dataflow.StaxDataflowReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.dsd.StaxDsdReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.hcl.StaxHclReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.metadataflow.StaxMetadataflowReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.msd.StaxMSDReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.orgscheme.StaxOrganisationSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.process.StaxProcessReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.provision.StaxProvisionReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.registration.StaxRegistrationReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.reportingtaxonomy.StaxReportingTaxonomyReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.structureset.StaxStructureSetReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxCustomTypeSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxNamePersonalisationSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxRulesetSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxTransformationSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxUserDefinedOperatorSchemeReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.transformation.StaxVtlMappingSchemeReaderEngineV21;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxStructureReaderEngineV21 extends AbstractStaxStructureReaderEngine implements IFusionSingleton {
	private static StaxStructureReaderEngineV21 INSTANCE;

	public static StaxStructureReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	//Private constructor - lazy load instance
	private StaxStructureReaderEngineV21() {
		super("Structures");

		registerReader(StaxOrganisationSchemeReaderEngineV21.getInstance());
		registerReader(StaxCategorisationReaderEngineV21.getInstance());
		registerReader(StaxCategorySchemeReaderEngineV21.getInstance());
		registerReader(StaxCodelistReaderEngineV21.getInstance());
		registerReader(StaxConceptSchemeReaderEngineV21.getInstance());
		registerReader(StaxDataflowReaderEngineV21.getInstance());
		registerReader(StaxContentConstraintReaderEngineV21.getInstance());
		registerReader(StaxContentConstraintReaderEngineV21.getInstance());
		registerReader(StaxDsdReaderEngineV21.getInstance());
		registerReader(StaxHclReaderEngineV21.getInstance());
		registerReader(StaxMetadataflowReaderEngineV21.getInstance());
		registerReader(StaxMSDReaderEngineV21.getInstance());
		registerReader(StaxProcessReaderEngineV21.getInstance());
		registerReader(StaxProvisionReaderEngineV21.getInstance());
		registerReader(StaxRegistrationReaderEngineV21.getInstance());
		registerReader(StaxStructureSetReaderEngineV21.getInstance());
		registerReader(StaxReportingTaxonomyReaderEngineV21.getInstance());
		registerReader(StaxCustomTypeSchemeReaderEngineV21.getInstance());
		registerReader(StaxNamePersonalisationSchemeReaderEngineV21.getInstance());
		registerReader(StaxRulesetSchemeReaderEngineV21.getInstance());
		registerReader(StaxTransformationSchemeReaderEngineV21.getInstance());
		registerReader(StaxUserDefinedOperatorSchemeReaderEngineV21.getInstance());
		registerReader(StaxVtlMappingSchemeReaderEngineV21.getInstance());
	}

	@Override
	protected SDMX_SCHEMA getOutputVersion() {
		return SDMX_SCHEMA.VERSION_TWO_POINT_ONE;
	}

	@Override
	protected HeaderBean processHeader(IStaxReader reader) {
		return StaxHeaderReaderEngineV21.readerHeader(reader);
	}
}
