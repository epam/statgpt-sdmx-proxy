package io.sdmx.format.ml.engine.structure.reader.v21.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.AnnotableMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.format.ml.util.StaxStructureUtil;


public class StaxAnnotableUtil  {

	public static void processBean(AnnotableMutableBean bean, IStaxReader reader) {
		if(reader.moveNextStartNode()) {
			if(reader.getElementName().equals("Annotations")) {
				processAnnotations(bean, reader);
				reader.moveNextNode(); //Move to the start/end of the next node
			}
		}
	}

	/**
	 * if the IStaxReader points at an Annotations start node, it will then call
	 * this method for processing.
	 *
	 * @param annotableBean
	 * @param staxReader
	 */
	public static void processAnnotations(AnnotableMutableBean annotableBean, IStaxReader staxReader) {
		while (staxReader.moveNextNode()) {
			String nodeName = staxReader.getElementName();
			if (staxReader.isStartElement()) {
				if (!nodeName.equals("Annotation")) {
					StaxStructureUtil.throwUnexpectedNodeException(staxReader);
				}
				AnnotationMutableBean currentAnnotation = new AnnotationMutableBeanImpl();
				processAnnotation(currentAnnotation, staxReader);
				annotableBean.addAnnotation(currentAnnotation);
			} else if(nodeName.equals("Annotations")){
				return;
			}
		}
	}

	/**
	 * Process an annotation, the stax reader is expecting to be on the node Annoation
	 * @param annotation
	 * @param staxReader
	 */
	private static void processAnnotation(AnnotationMutableBean annotation,IStaxReader staxReader) {
		annotation.setId(staxReader.getAttributeValue(null, "id"));
		while (staxReader.moveNextNode()) {
			String nodeName = staxReader.getElementName();
			if(staxReader.isStartElement()) {
				if(nodeName.equals("AnnotationTitle")) {
					annotation.setTitle(staxReader.getElementText());
				} else if(nodeName.equals("AnnotationType")) {
					annotation.setType(staxReader.getElementText());
				} else if(nodeName.equals("AnnotationURL")) {
					annotation.setUri(staxReader.getElementText());
				} else if(nodeName.equals("AnnotationText")) {
					annotation.addText(StaxStructureUtil.getText(staxReader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(staxReader);
				}
			} else if (nodeName.equals("Annotation")) {
				return;
			}
		}
	}
}