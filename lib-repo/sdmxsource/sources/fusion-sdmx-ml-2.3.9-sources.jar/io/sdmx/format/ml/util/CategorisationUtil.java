package io.sdmx.format.ml.util;

import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;

public class CategorisationUtil {

    /**
     * Generates a "default" ID from a Categorisation which may be used as the ID on the mutable Categorisation bean
     * @param mutableCategorisation
     * @return
     */
    public static String generateId(CategorisationMutableBean mutableCategorisation) {
        if (mutableCategorisation.getCategoryReference() == null) {
            throw new IllegalArgumentException("The Categorisation requires a category reference.  Categorisation: " + mutableCategorisation.toString());
        }

        if (mutableCategorisation.getStructureReference() == null) {
            throw new IllegalArgumentException("The Categorisation requires a structure reference.  Categorisation: " + mutableCategorisation.toString());
        }

        return mutableCategorisation.getCategoryReference().hashCode() + "_" + mutableCategorisation.getStructureReference().hashCode();
    }

}
