package io.sdmx.format.ml.engine.structure.reader.v21.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.OrganisationUnitMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxOrgUnitSchemeReaderEngineV21 extends StaxAbstractOrgansiationReaderV21 {
	private static StaxOrgUnitSchemeReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxOrgUnitSchemeReaderEngineV21() {}

	public static StaxOrgUnitSchemeReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxOrgUnitSchemeReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public OrganisationUnitSchemeMutableBean processMaintainable(IStaxReader reader) {
		OrganisationUnitSchemeMutableBean maint = new OrganisationUnitSchemeMutableBeanImpl();
		StaxItemSchemeUtil.processBean(maint, reader);

		//Expected position is now Agency
		String elementName = reader.getElementName();
		while(reader.isStartElement()) {
			if(!elementName.equals("OrganisationUnit")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			processOrgUnit(maint, reader);
			reader.moveNextNode();
		}
		return maint;
	}

	private void processOrgUnit(OrganisationUnitSchemeMutableBean beanToPopulate, IStaxReader reader) {
		OrganisationUnitMutableBean org = new OrganisationUnitMutableBeanImpl();
		beanToPopulate.addItem(org);
		super.processOrganisation(org, reader);
	}

	@Override
    protected void processStartElement(OrganisationMutableBean org, IStaxReader reader) {
		if(reader.getElementName().equals("Parent")) {
			((OrganisationUnitMutableBean)org).setParentUnit(StaxStructureUtil.getLocalReference(reader));

			reader.moveNextNode();
			if(reader.isStartElement()) {
				super.processStartElement(org, reader);
			}
		} else {
			super.processStartElement(org, reader);
		}
	}
}
