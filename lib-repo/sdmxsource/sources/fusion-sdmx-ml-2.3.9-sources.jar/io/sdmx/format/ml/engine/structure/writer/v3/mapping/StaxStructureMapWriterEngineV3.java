package io.sdmx.format.ml.engine.structure.writer.v3.mapping;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.mapping.v3.IComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IEpochMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimeComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.ITimePatternMapBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxStructureMapWriterEngineV3 extends AbstractV3Writer<IStructureMapBean> implements IFusionSingleton {
	private static StaxStructureMapWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxStructureMapWriterEngineV3() {}

	public static StaxStructureMapWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureMapWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "StructureMap";
	}

	@Override
	protected void writeMaintainableInternal(IStructureMapBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getSourceRef(), writer, "Source");
		StaxRefUtilV3.writeReference(maint.getTargetRef(), writer, "Target");

		writeEpochMaps(maint.getEpochMap(), writer);
		writeTimePatternMaps(maint.getTimePatternMaps(), writer);
		//TODO Frequency Format Mapping
		writeComponentMaps(maint.getComponentMaps(), writer);
		writeFixedValues(maint.getFixedInputs(), "Source", writer);
		writeFixedValues(maint.getFixedOutputs(), "Target", writer);
		
	}
	
	private void writeEpochMaps(List<IEpochMapBean> maps, StaxWriter writer) {
		for(IEpochMapBean map : maps) {
			writer.writeStartElement(NS, "EpochMap");
			writer.writeAttribute("basePeriod", map.getBasePeriod().getDateInSdmxFormat());
			writer.writeAttribute("epochPeriod", map.getEpochInterval().toString());
			writeAbstractTimePatternMap(map, writer);
			writer.writeEndElement(); //End FixedValueMap
		}
	}

	private void writeTimePatternMaps(List<ITimePatternMapBean> maps, StaxWriter writer) {
		for(ITimePatternMapBean map : maps) {
			writer.writeStartElement(NS, "DatePatternMap");
			writer.writeAttribute("sourcePattern", map.getPattern());
			writer.writeAttribute("locale", map.getLocale());
			writeAbstractTimePatternMap(map, writer);
			writer.writeEndElement();  //End EpochMap
		}
	}
	
	private void writeAbstractTimePatternMap(ITimeComponentMapBean map, StaxWriter writer) {
		if(map.getPeriodResolution() != null) {
			String periodResolution = null;
			switch(map.getPeriodResolution()) {
			case END_PERIOD:
				periodResolution = "endOfPeriod";
				break;
			case MID_PERIOD:
				periodResolution = "midPeriod";
				break;
			case START_PERIOD:
				periodResolution = "startOfPeriod";
				break;
			}
			writer.writeAttribute("resolvePeriod", periodResolution);
		}
		StaxAnnotableWriterUtilV3.writeBean(map, writer);
		writeCompRef(map.getSourceComponent(), writer, "Source"); 
		writeCompRef(map.getTargetComponent(), writer, "Target"); 
		
		if(map.getOutputFrequencyId() != null) {
			writer.writeElement(NS, "TargetFrequencyID", map.getOutputFrequencyId());
		} else if(map.getOutputFrequencyDimId() != null) {
			writeCompRef(map.getOutputFrequencyDimId(), writer, "FrequencyDimension"); 
		}
	}
	
	private void writeComponentMaps(List<IComponentMapBean> maps, StaxWriter writer) {
		for(IComponentMapBean map : maps) {
			writer.writeStartElement(NS, "ComponentMap");
			StaxAnnotableWriterUtilV3.writeBean(map, writer);
			for(String source : map.getSourceComponents()) {
				writeCompRef(source, writer, "Source"); 
			}
			for(String target : map.getTargetComponents()) {
				writeCompRef(target, writer, "Target"); 
			}
			if(map.getRepresentationMapRef() != null) {
				StaxRefUtilV3.writeReference(map.getRepresentationMapRef(), writer, "RepresentationMap");
			}
			writer.writeEndElement();  //End ComponentMap
		}
	}

	private void writeFixedValues(Map<String, String> values, String refLabel, StaxWriter writer) {
		for(String compId : values.keySet()) {
			writer.writeStartElement(NS, "FixedValueMap");
			writeCompRef(compId, writer, refLabel); 
			writer.writeElement(NS, "Value", values.get(compId));
			writer.writeEndElement(); //End FixedValueMap
		}
	}
	
	private void writeCompRef(String compId, StaxWriter writer, String label) {
		writer.writeElement(NS, label, compId);
	}
}
