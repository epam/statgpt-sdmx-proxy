package io.sdmx.format.ml.engine.structure.writer.v3.conceptscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRepresentationWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxConceptSchemeWriterEngineV3 extends AbstractV3Writer<ConceptSchemeBean> implements IFusionSingleton {
	private static StaxConceptSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeWriterEngineV3() {}

	public static StaxConceptSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ConceptScheme";
	}

	@Override
	protected void writeMaintainableInternal(ConceptSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeConcepts(maint.getItems(), externalLinks, writer);
	}

	private void writeConcepts(List<ConceptBean> concepts, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ConceptBean concept : concepts) {
			StaxNameableWriterUtilV3.writeBean(concept, "Concept", externalLinks, writer);
			if(concept.getParentConcept() != null) {
				StaxRefUtilV3.writeLocalReference(concept.getParentConcept(), writer, "Parent");
			}
			StaxRepresentationWriterUtilV3.writeRepresentation(concept.getRepresentation(), writer, "CoreRepresentation");
			if(concept.getIsoConceptReference() != null) {
				ICrossReferenceBean<ConceptBean> isoRef = concept.getIsoConceptReference();
				writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "ISOConceptReference");
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptAgency", isoRef.getReference().getAgencyId());
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptSchemeID", isoRef.getReference().getMaintainableId());
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "ConceptID",  isoRef.getReference().getIdentifiableId());
				writer.writeEndElement();
			}
			writer.writeEndElement(); //End Concept
		}
	}

}
