package io.sdmx.format.ml.engine.structure.reader.v21.codelist;

import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCodelistReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<CodelistMutableBean> {
	private static StaxCodelistReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistReaderEngineV21() {}

	public static StaxCodelistReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Codelists";
    }

    @Override
    protected String getRootNodeName() {
        return "Codelist";
    }

    @Override
    protected CodelistMutableBean processMaintainable(IStaxReader reader) {
		CodelistMutableBean maint = new CodelistMutableBeanImpl();
		StaxItemSchemeUtil.processBean(maint, reader);

		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("Code")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			CodeMutableBean aCode = processCode(reader);
			maint.addItem(aCode);
			reader.moveNextNode();
		}
		ValidityPeriodUtil.processValidityAnnotations(maint);

		return maint;
	}

	private CodeMutableBean processCode(IStaxReader reader) {
		CodeMutableBean code = new CodeMutableBeanImpl();
		StaxNameableUtil.processBean(code, reader);

		if(reader.isStartElement()) {
			if(!reader.getElementName().equals("Parent")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			code.setParentCode(StaxStructureUtil.getLocalReference(reader));
			reader.moveNextNode();  //Move to end of parent element
		}
		//Leave on an end element
		return code;
	}
}
