package io.sdmx.format.ml.model;

import java.util.Date;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.core.sdmx.api.error.DataFormatError;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.error.DataFormatErrorImpl;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.im.header.DatasetHeaderBeanImpl;
import io.sdmx.im.header.DatasetStructureReferenceBeanImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.xs.MaintainableRef;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.sdmx.xs.URN.URNBuilder;

/**
 * Build from a StaxReader
 * @author mnelson
 *
 */
public class XMLDatasetHeader implements DatasetHeaderBean {
    private IURNAbsolute<DataProviderBean> dataProviderRef;
    private DatasetStructureReferenceBean datasetStructureReferenceBean;
    private String datasetId;
    private Date reportingBeginDate;
    private Date reportingEndDate;
    private Date validFrom;
    private Date validTo;
    private DATASET_ACTION action = DATASET_ACTION.INFORMATION;
    private int publicationYear = -1;
    private String publicationPeriod;


    /**
     * Create an instance from a parser reading the dataset XML Node and the header
     * @param parser
     * @param datasetHeader
     * @param datasetIndex
     * @param exceptionHandler an optional exceptionHandler
     */
    public XMLDatasetHeader(StaxReader parser, HeaderBean datasetHeader, int datasetIndex, DataReaderExceptionHandler exceptionHandler) {
        if(parser.getAttributeValue(null, "structureRef") != null) {
            String structureRef = parser.getAttributeValue(null, "structureRef");
            datasetStructureReferenceBean = getStructureFromHeader(datasetHeader, structureRef);
            if(datasetStructureReferenceBean == null) {
                SdmxSemmanticException ex = new SdmxSemmanticException("Dataset references Structure that is not defined in the Header of the message.  Structure reference defined by Dataset is:" +structureRef);
                handleException(ex, datasetIndex, exceptionHandler, TYPE.STRUCUTRE_REF_INCONSISTENT_WITH_HEADER);
            }
        } else {
            try {
                datasetStructureReferenceBean = generateOrUseDefaultStructure(parser, datasetHeader);
            } catch (Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_HEADER_CONTENT);
            }
        }

        if(parser.getAttributeValue(null, "action") != null) {
            try {
                this.action = DATASET_ACTION.getAction(parser.getAttributeValue(null, "action"));
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_HEADER_CONTENT);
            }
        } else if(datasetHeader.getAction() != null) {
            this.action = datasetHeader.getAction();
        }

        if(parser.getAttributeValue(null, "datasetID") != null) {
            try {
                this.datasetId = parser.getAttributeValue(null, "datasetID");
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_HEADER_CONTENT);
            }
        }

        if(parser.getAttributeValue(null, "publicationPeriod") != null) {
            try {
                this.publicationPeriod = parser.getAttributeValue(null, "publicationPeriod");
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_HEADER_CONTENT);
            }
        }
        if(parser.getAttributeValue(null, "publicationYear") != null) {
            try {
                this.publicationYear = Integer.parseInt(parser.getAttributeValue(null, "publicationYear"));
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_HEADER_CONTENT);
            }
        }
        if(parser.getAttributeValue(null, "reportingBeginDate") != null) {
            try {
                this.reportingBeginDate = DateUtil.formatDate(parser.getAttributeValue(null, "reportingBeginDate"), true);
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_DATE);
            }
        }
        if(parser.getAttributeValue(null, "reportingEndDate") != null) {
            try {
                this.reportingEndDate = DateUtil.formatDate(parser.getAttributeValue(null, "reportingEndDate"), false);
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_DATE);
            }
        }
        if(parser.getAttributeValue(null, "validFromDate") != null) {
            try {
                this.validFrom = DateUtil.formatDate(parser.getAttributeValue(null, "validFromDate"), true);
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_DATE);
            }
        }
        if(parser.getAttributeValue(null, "validToDate") != null) {
            try {
                this.validTo = DateUtil.formatDate(parser.getAttributeValue(null, "validToDate"), false);
            } catch(Throwable th) {
                SdmxSemmanticException ex = new SdmxSemmanticException(th.getMessage());
                handleException(ex, datasetIndex, exceptionHandler, TYPE.INVALID_DATE);
            }
        }
    }

    private void handleException(SdmxSemmanticException ex, int datasetIndex, DataReaderExceptionHandler exceptionHandler, TYPE type) {
        if(exceptionHandler != null) {
        	DataFormatError error = new DataFormatErrorImpl(ex.getMessage(), type);
            exceptionHandler.handleException(error);
        } else {
            throw ex;
        }
    }

    @Override
    public DatasetHeaderBean modifyDataStructureReference(DatasetStructureReferenceBean datasetStructureReferenceBean) {
        return new DatasetHeaderBeanImpl(getDatasetId(),
                getAction(),
                datasetStructureReferenceBean,
                getDataProviderReference(),
                getReportingBeginDate(),
                getReportingEndDate(),
                getValidFrom(),
                getValidTo(),
                getPublicationYear(),
                getPublicationPeriod(), null);  //TODO reportingYearStartDate
    }

    private DatasetStructureReferenceBean generateOrUseDefaultStructure(StaxReader parser, HeaderBean datasetHeader) {
        URNBuilder urnBuilder = URN.builder();
        IMaintainableRef dataflowReference = getDataflowReference(parser);
        IMaintainableRef dsdReference = getDsdReference(parser);
        if(dataflowReference != null) {
        	urnBuilder.ref(dataflowReference);
            urnBuilder.structure(DataflowBean.class);
        } else if(dsdReference != null) {
            urnBuilder.structure(DataStructureBean.class);
            urnBuilder.ref(dsdReference);
        } else if(datasetHeader.getStructures().size() == 1){
            return datasetHeader.getStructures().get(0);
        } else {
            return null;
        }
        return new DatasetStructureReferenceBeanImpl("generated", urnBuilder.buildSingle(IDSDRelatedBean.class) , null, null, DimensionBean.TIME_DIMENSION_FIXED_ID);
    }

    private DatasetStructureReferenceBean getStructureFromHeader(HeaderBean header, String structureRef) {
        if(header.getStructures() == null) {
            return null;
        }
        for(DatasetStructureReferenceBean currentStructure : header.getStructures()) {
            if(currentStructure.getId().equals(structureRef)) {
                return currentStructure;
            }
        }
        return null;
    }

    //TODO THIS MAY NOT RESOLVE TO A SINLGE DSD as the agency or ID can be null
    private IMaintainableRef getDataflowReference(StaxReader parser) {
        String dfId = null;
        String dfAcy = null;
        if(parser.getAttributeValue(null, "dataflowAgencyID") != null) {
            dfAcy = parser.getAttributeValue(null, "dataflowAgencyID");
        }
        if(parser.getAttributeValue(null, "dataflowID") != null) {
            dfId = parser.getAttributeValue(null, "dataflowID");
        }
        if(ObjectUtil.validString(dfId)) {
            return MaintainableRef.getInstance(dfAcy, dfId, MaintainableBean.DEFAULT_VERSION);
        }
        return null;
    }

    private IMaintainableRef getDsdReference(StaxReader parser) {
        if(parser.getAttributeValue(null, "keyFamilyURI") != null) {
            String dsdUri = parser.getAttributeValue(null, "keyFamilyURI");
            return URN.builder(dsdUri).buildMaintainable();
        }
        return null;
    }

    @Override
    public boolean isTimeSeries() {
        if(datasetStructureReferenceBean == null) {
            return true;
        }
        return datasetStructureReferenceBean.isTimeSeries();
    }

    @Override
    public DatasetStructureReferenceBean getDataStructureReference() {
        return datasetStructureReferenceBean;
    }

    @Override
    public DATASET_ACTION getAction() {
        return action;
    }

    @Override
	public DatasetHeaderBean setAction(DATASET_ACTION action) {
    	this.action = action;
		return this;
	}

	@Override
    public IURNAbsolute<DataProviderBean> getDataProviderReference() {
        return dataProviderRef;
    }


    @Override
    public String getDatasetId() {
        return datasetId;
    }

    @Override
    public Date getReportingBeginDate() {
        return reportingBeginDate;
    }

    @Override
    public Date getReportingEndDate() {
        return reportingEndDate;
    }

    @Override
    public Date getValidFrom() {
        return validFrom;
    }

    @Override
    public Date getValidTo() {
        return validTo;
    }

    @Override
    public int getPublicationYear() {
        return publicationYear;
    }

    @Override
    public String getPublicationPeriod() {
        return publicationPeriod;
    }
}
