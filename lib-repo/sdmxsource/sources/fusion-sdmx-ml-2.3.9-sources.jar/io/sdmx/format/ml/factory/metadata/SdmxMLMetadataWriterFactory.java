package io.sdmx.format.ml.factory.metadata;

import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataWriterEngine;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataWriterFactory;
import io.sdmx.format.ml.constant.SDMXML_VERSION;
import io.sdmx.format.ml.model.SdmxMLMetadataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxMLMetadataWriterFactory implements IMetadataWriterFactory, IFusionSingleton {
	private static SdmxMLMetadataWriterFactory INSTANCE;
	
	//Private constructor - lazy load instance
	public static SdmxMLMetadataWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLMetadataWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxMLMetadataWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	public IMetadataWriterEngine getMetadataWriterEngine(IMetadataFormat outputFormat) {
		if(outputFormat == SdmxMLMetadataFormat.getInstance(SDMXML_VERSION.V3)) {
			//return SdmxJsonMetadataSetWriterEngineV2.getInstance();
		}
		return null;
	}
}
