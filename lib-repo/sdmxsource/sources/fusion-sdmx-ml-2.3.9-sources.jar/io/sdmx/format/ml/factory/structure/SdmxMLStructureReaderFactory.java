package io.sdmx.format.ml.factory.structure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.ARTIFACT_TYPE;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.REGISTRY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.structure.StructureReaderFactory;
import io.sdmx.format.ml.api.engine.StaxStructureReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.StaxStructureReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.registration.StaxRegistrationReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v21.StaxStructureReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v21.registration.StaxRegistrationReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v3.StaxStructureReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.registration.StaxRegistrationReaderEngineV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

public class SdmxMLStructureReaderFactory implements StructureReaderFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMLStructureReaderFactory.class);
	private static SdmxMLStructureReaderFactory INSTANCE;

	public static SdmxMLStructureReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static SdmxMLStructureReaderFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxMLStructureReaderFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private SdmxMLStructureReaderFactory() {}

	@Override
    public SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder builder) {
		SDMX_SCHEMA schema = null;
		boolean wasDisabled  = SdmxException.isDisabledExceptionTrace();
		try {
			SdmxException.disableExceptionTrace(true);
			schema = SdmxMessageUtil.getSchemaVersion(rdl);
		} catch(Throwable th) {
			SdmxException.disableExceptionTrace(wasDisabled);
			return null;
		}

		if(schema != null) {
			StaxStructureReaderEngine reader = null;
			MESSAGE_TYPE messageType = SdmxMessageUtil.getMessageType(rdl);
			if(messageType == MESSAGE_TYPE.REGISTRY_INTERFACE) {
				REGISTRY_MESSAGE_TYPE registryMessage = SdmxMessageUtil.getRegistryMessageType(rdl);
				reader = getStaxStructureReaderEngine(schema, registryMessage);
			} else if(messageType == MESSAGE_TYPE.STRUCTURE) {
				reader = getStaxStructureReaderEngine(schema);
			}
			if(reader != null) {
				LOG.info("Read SdmxBeans using " + reader.getClass().getCanonicalName());
				return reader.getSdmxBeans(rdl, builder);
			}

		}
		return null;
	}

	public StaxStructureReaderEngine getStaxStructureReaderEngine(SDMX_SCHEMA schemaVersion) {
		switch(schemaVersion) {
		case VERSION_ONE:
			throw new SdmxNotImplementedException("V1 SDMX is not supported");
		case VERSION_TWO :
			return StaxStructureReaderEngineV2.getInstance();
		case VERSION_TWO_POINT_ONE :
			return StaxStructureReaderEngineV21.getInstance();
		case VERSION_THREE :
			return StaxStructureReaderEngineV3.getInstance();
		}
		return null;
	}

	private StaxStructureReaderEngine getStaxStructureReaderEngine(SDMX_SCHEMA schemaVersion, REGISTRY_MESSAGE_TYPE registryMessage) {
		ARTIFACT_TYPE artifactType = registryMessage.getArtifactType();
		switch(artifactType) {
		case PROVISION :
			return null;
		case REGISTRATION :
			switch(schemaVersion) {
			case VERSION_TWO :
				return StaxRegistrationReaderEngineV2.getInstance();
			case VERSION_TWO_POINT_ONE :
				return StaxRegistrationReaderEngineV21.getInstance();
			case VERSION_THREE :
				return StaxRegistrationReaderEngineV3.getInstance();
			}
			return null;
		case STRUCTURE :
			switch(schemaVersion) {
			case VERSION_ONE:
	            throw new SdmxNotImplementedException("V1 SDMX is not supported");
			case VERSION_TWO :
				return StaxStructureReaderEngineV2.getInstance();
			case VERSION_TWO_POINT_ONE :
				return StaxStructureReaderEngineV21.getInstance();
			case VERSION_THREE :
				return StaxStructureReaderEngineV3.getInstance();
			}

		case SUBSCRIPTION :
			return null;
		}
		return null;
	}


	@Override
	public Integer getPriority() {
		return 11;
	}
}
