package io.sdmx.format.ml.api.engine;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.xml.StaxWriter;

public interface StaxMaintainableWriterEngine<T extends MaintainableBean> {
	
	void writeMaintainable(T maint, StaxWriter writer);
	
	
	default void writeMaintainable(T maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeMaintainable(maint, writer);
	}
	
}
