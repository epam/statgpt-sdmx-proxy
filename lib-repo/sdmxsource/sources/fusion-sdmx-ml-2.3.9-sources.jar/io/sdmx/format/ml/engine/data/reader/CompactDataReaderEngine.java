package io.sdmx.format.ml.engine.data.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.DATASET_POSITION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.exception.TimeFormatParsingException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.complex.IMultilingualNodeValue;
import io.sdmx.api.sdmx.model.beans.registry.IMultilingualKeyValue;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.core.sdmx.api.error.DataError.ERROR_POSITION;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.error.DataReadException.SEVERITY;
import io.sdmx.core.sdmx.error.DataReadException.TYPE;
import io.sdmx.format.ml.model.XMLDatasetHeader;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.beans.reference.complex.MultilingualNodeValue;
import io.sdmx.im.data.AbstractAttributable.AttributableBuilder;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.MultilingualKeyValue;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.date.SdmxDateUtil;
import io.sdmx.utils.sdmx.structure.ConceptRefUtil;

public class CompactDataReaderEngine extends AbstractSdmxDataReaderEngine {
	private static final long serialVersionUID = 7750528288236102625L;
	private Map<String, String> rolledUpAttributes = new HashMap<>();
	private Map<String, String> keyValues = new HashMap<>();
	private Map<String, String> attributeValues = new HashMap<>();
	private HashMap<String, List<IMultilingualNodeValue>> multilingualAttributeValues = new HashMap<>();
	private HashMap<String, List<IMultilingualNodeValue>> multilingualMeasureValues = new HashMap<>();

	private List<String> groups = new ArrayList<>();

	//CONCEPTS
	private List<String> dimensionConcepts = new ArrayList<>();
	private Map<String, List<String>> groupConcepts = new HashMap<>();

	private String primaryMeasureConcept;
	private String timeConcept;

	//ATTRIBUTES
	private Set<String> datasetAttributes = new HashSet<>();
	private Set<String> seriesAttributes = new HashSet<>();
	private Set<String> observationAttributes = new HashSet<>();
	private Map<String, Set<String>> groupAttributeConcepts = new HashMap<>();

	//OBS INFO
	private String obsTime = null;
	private String obsValue = null;
	private List<KeyValue> attributes = new ArrayList<>();
	private List<IMultilingualKeyValue> complexAttributes = new ArrayList<>();
	private List<IMultilingualKeyValue> complexMeasures = new ArrayList<>();
	private List<KeyValue> measures = new ArrayList<>();
	private KeyValue crossSection = null;

	private List<AnnotationBean> annotations = null;

	private TIME_FORMAT timeFormat;

	/**
	 * Creates a reader engine based on the data location, and the data structure to use to interpret the data
	 *
	 * @param dataLocation      the location of the data
	 * @param dataStructureBean the dsd to use to interpret the data
	 */
	public CompactDataReaderEngine(ReadableDataLocation dataLocation,
								   DataStructureBean dataStructureBean,
								   DataflowBean dataflowBean,
								   ProvisionAgreementBean provisionAgreementBean,
								   DataReaderExceptionHandler exceptionHandler) {
		this(dataLocation, null, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler, null);
	}

	/**
	 * Creates a reader engine based on the data location, the location of available data structures that can be used to retrieve dsds, and the default dsd to use
	 *
	 * @param dataLocation      the location of the data
	 * @param beanRetrieval     giving the ability to retrieve dsds for the datasets this reader engine is reading.  This can be null if there is only one relevent dsd - in which case the default dsd should be provided
	 * @param dataStructureBean the dsd to use if the beanRetrieval is null, or if the bean retrieval does not return the dsd for the given dataset
	 */
	public CompactDataReaderEngine(ReadableDataLocation dataLocation,
								   SdmxBeanRetrievalManager beanRetrieval,
								   DataStructureBean dataStructureBean,
								   DataflowBean dataflowBean,
								   ProvisionAgreementBean provisionAgreementBean,
								   DataReaderExceptionHandler exceptionHandler) {
		this(dataLocation, beanRetrieval, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler, null);
	}


	/**
	 * All constructors end up here - this is private as it is used in the create copy method
	 */
	private CompactDataReaderEngine(ReadableDataLocation dataLocation,
									SdmxBeanRetrievalManager beanRetrieval,
									DataStructureBean dataStructureBean,
									DataflowBean dataflowBean,
									ProvisionAgreementBean provisionAgreementBean,
									DataReaderExceptionHandler exceptionHandler,
									Set<String> handledExceptions) {
		super(dataLocation, beanRetrieval, dataStructureBean, dataflowBean, provisionAgreementBean, exceptionHandler, BASE_DATA_FORMAT.COMPACT);
		super.handledExceptions = handledExceptions;
		if (super.handledExceptions == null) {
			super.handledExceptions = new HashSet<>();
		}
		reset();
	}

	@Override
	public FormatDetails getFormatDetails() {
		String acceptHeader = null;
		switch (getSchemaVersion()) {
			case VERSION_ONE:
				acceptHeader = "application/vnd.sdmx.structurespecificdata+xml;version=1.0";
				break;
			case VERSION_TWO:
				acceptHeader = "application/vnd.sdmx.structurespecificdata+xml;version=2.0";
				break;
			case VERSION_TWO_POINT_ONE:
				acceptHeader = "application/vnd.sdmx.structurespecificdata+xml;version=2.1";
				break;
			case VERSION_THREE:
				acceptHeader = "application/vnd.sdmx.data+xml;version=3.0.0";
		}
		String mimeType = "application/xml";
		return new FormatDetailsImpl(toString(), "xml", mimeType, false, acceptHeader);
	}

	@Override
	public DataReaderEngine createCopy() {
		return new CompactDataReaderEngine(dataLocation.copy(), beanRetrieval, defaultDsd, defaultDataflow, defaultProvisionAgreement, exceptionHandler, handledExceptions);
	}


	private void populateGroupConcepts(GroupBean groupBean, List<String> groups) {
		for (String dimensionId : groupBean.getDimensionRefs()) {
			groups.add(dimensionId);
		}
	}

	private String getComponentId(ComponentBean component) {
		if (component == null) {
			return null;
		}
		if (isTwoPointOne || isThreePointZero) {
			return component.getId();
		}
		return ConceptRefUtil.getConceptId(component.getConceptRef().getReference());
	}

	public enum MOVE_TO {
		SERIES,
		GROUP,
		KEYABLE;
	}

	private void setGroupId(String groupId) {
		if (groupId == null) {
			return;
		}
		String[] split = groupId.split(":", 2);
		this.groupId = split.length > 1 ? split[1] : split[0];
		if (!groups.contains(this.groupId)) {
			if (this.groupId.endsWith("Type")) {
				this.groupId = this.groupId.substring(0, this.groupId.length() - 4);
			}
		}
	}


	@Override
	protected boolean next(boolean includeObs) {
		while (parser.moveNextNode()) {
			String nodeName = parser.getElementName();
			if (parser.isStartElement()) {
				if (nodeName.equals("DataSet")) {
					if (isTwoPointOne || isThreePointZero) {
						assertNameSpace(MESSAGE_NS);
					} else {
						assertNameSpace(COMPACT_NS);
					}
					datasetPosition = DATASET_POSITION.DATASET;
					return true;
				} else if (nodeName.equals("Series")) {
					if (!(isTwoPointOne || isThreePointZero)) {
						assertNameSpace(COMPACT_NS);
					}
					datasetPosition = DATASET_POSITION.SERIES;
					return true;
				} else if (!(isTwoPointOne || isThreePointZero) && groups.contains(nodeName)) {
					assertNameSpace(COMPACT_NS);
					datasetPosition = DATASET_POSITION.GROUP;
					groupId = nodeName;
					return true;
				} else if ((isTwoPointOne || isThreePointZero) && nodeName.equals("Group")) {
					if (!(isTwoPointOne || isThreePointZero)) {
						assertNameSpace(COMPACT_NS);
					}
					datasetPosition = DATASET_POSITION.GROUP;
					setGroupId(parser.getAttributeValue("xsi", "type"));
					return true;
				} else if (nodeName.equals("Obs")) {
					if (!(isTwoPointOne || isThreePointZero)) {
						assertNameSpace(COMPACT_NS);
					}
					if (datasetPosition == DATASET_POSITION.SERIES || datasetPosition == DATASET_POSITION.OBSERVATION) {
						if (includeObs) {
							datasetPosition = DATASET_POSITION.OBSERVATION;
							return true;
						} else {
							continue;
						}
					}
					datasetPosition = DATASET_POSITION.OBSERAVTION_AS_SERIES;
					return true;
				} else if (nodeName.equals("Annotations")) {
					if (!(isTwoPointOne || isThreePointZero)) {
						assertNameSpace(COMPACT_NS);
					}
					parser.skipCurrentNode();
				} else {
					handleException("Unexpected element '" + parser.getXMLPath() + "'", true, SEVERITY.HIGH, TYPE.ADDED_ELEMNET);
					parser.skipCurrentNode();
				}
			} else {
				if (nodeName.equals("Series")) {
					datasetPosition = null;
				} else if (groups.contains(nodeName)) {
					datasetPosition = null;
				} else if (nodeName.equals("Group")) {
					datasetPosition = null;
				}
			}
		}

		datasetPosition = null;
		hasNext = false;
		return false;
	}

	@Override
	protected DatasetHeaderBean processDataSetNode() {
		rolledUpAttributes = new HashMap<>();
		keyValues = new HashMap<>();
		attributeValues = new HashMap<>();
		multilingualAttributeValues = new HashMap<>();
		attributesOnDatasetNode = new HashMap<>();

		this.datasetHeaderBean = new XMLDatasetHeader(parser, headerBean, getDatasetPosition(), exceptionHandler);
		this.currentDsd = null;
		this.currentDataflow = null;
		this.currentProvisionAgreement = null;
		for (int i = 0; i < parser.getAttributeCount(); i++) {
			String attributeId = parser.getAttributeLocalName(i);
			attributeId = getComponentId(attributeId);

			if (
					attributeId.equals("type") || attributeId.equals("structureRef") || attributeId.equals("setID") || attributeId.equals("action") ||
							attributeId.equals("reportingBeginDate") || attributeId.equals("reportingEndDate") ||
							attributeId.equals("validFromDate") || attributeId.equals("validToDate") ||
							attributeId.equals("publicationYear") || attributeId.equals("publicationPeriod") ||
							attributeId.equals("dataScope") || attributeId.equals("dataflowID") || attributeId.equals("dataflowAgencyID") ||
							attributeId.equals("schemaLocation") || attributeId.equals("keyFamilyURI")) {
				continue;
			}
			attributesOnDatasetNode.put(attributeId, parser.getAttributeValue(i));
		}
		processComplexAttributes();
		return datasetHeaderBean;

	}

	private void processComplexAttributes() {
		parser.peak();
		if (parser.isStartElement()) {
			String nextNodeName = parser.getElementName();
			if (nextNodeName.equals("Comp")) {
				parser.moveNextNode();
				processComplexAttribute(parser, attributes, measures);
			}
		}
	}

	private void setDimensionAtObservation(String dimensionAtObservation) {
		if (dimensionAtObservation.equals("AllDimensions")) {
			// By changing the value to "null" from "AllDimensions", subsequent queries to
			// obtain the sets of series and observation attributes, will return all values
			dimensionAtObservation = null;
		}
		observationAttributes = new HashSet<>();
		seriesAttributes = new HashSet<>();
		for (AttributeBean attributeBean : currentDsd.getSeriesAttributes(dimensionAtObservation)) {
			seriesAttributes.add(getComponentId(attributeBean));
		}

		//Create a list of observation attribute concepts
		for (AttributeBean attributeBean : currentDsd.getObservationAttributes(dimensionAtObservation)) {
			observationAttributes.add(getComponentId(attributeBean));
		}
	}

	@Override
	protected AttributableBuilder<IDatasetAttributes> getDatasetAttributesBuilder() {
		List<KeyValue> returnList = new ArrayList<>();
		// Add all dataset attributes
		for (String keyId : attributesOnDatasetNode.keySet()) {
			String attributeValue = attributesOnDatasetNode.get(keyId);
			returnList.add(KeyValueImpl.getInstance(keyId, attributeValue));
		}

		return DatasetAttributes.builder().attributes(returnList);
	}


	private Map<String, String> attributesOnDatasetNode = new HashMap<>();

	/**
	 * Sets the current data structure, this is called by the superclass immediately after the reader has read the dataset node
	 *
	 * @param dsd
	 */
	@Override
	protected void setCurrentDsd(DataStructureBean dsd) {
		super.setCurrentDsd(dsd);

		//reset all maps
		dimensionConcepts = new ArrayList<>();
		datasetAttributes = new HashSet<>();
		seriesAttributes = new HashSet<>();
		observationAttributes = new HashSet<>();
		groups = new ArrayList<>();
		groupConcepts = new HashMap<>();

		if (datasetHeaderBean.getDataStructureReference() != null) {
			setDimensionAtObservation(datasetHeaderBean.getDataStructureReference().getDimensionAtObservation());
		} else {
			setDimensionAtObservation(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}

		//Roll up any attribute values
		for (String attributeId : attributesOnDatasetNode.keySet()) {
			ComponentBean component = dsd.getComponent(attributeId);
			if (component != null) {
				rolledUpAttributes.put(attributeId, attributesOnDatasetNode.get(attributeId));
			}
		}

		//Create a list of dimension concepts
		for (DimensionBean dimensionBean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			dimensionConcepts.add(dimensionBean.getId());
		}

		//Create a list of dataset attribute concepts
		for (AttributeBean attributeBean : dsd.getDatasetAttributes()) {
			datasetAttributes.add(attributeBean.getId());
		}

		//Create a list of dimension group attribute concepts
		for (AttributeBean attributeBean : dsd.getDimensionGroupAttributes()) {
			seriesAttributes.add(attributeBean.getId());
		}

		//Create a list of observation attribute concepts
		for (AttributeBean attributeBean : dsd.getObservationAttributes()) {
			observationAttributes.add(attributeBean.getId());
		}

		if (dsd.getPrimaryMeasure() == null) {
			int size = dsd.getMeasures().size();
			if (size == 1) {
				primaryMeasureConcept = dsd.getMeasures().get(0).getId();
			}
		} else {
			primaryMeasureConcept = dsd.getPrimaryMeasure().getId();
		}

		if (dsd.getTimeDimension() != null) {
			//			throw new SdmxNotImplementedException("The DSD: " + dsd.getId() + " has no time dimension. This is unsupported!");
			timeConcept = dsd.getTimeDimension().getId();
		}

		for (GroupBean groupBean : dsd.getGroups()) {
			String groupId = groupBean.getId();
			groups.add(groupId);

			Set<String> groupAttributes = new HashSet<>();
			for (AttributeBean attributeBean : dsd.getGroupAttributes(groupId, true)) {
				groupAttributes.add(attributeBean.getId());
			}
			groupAttributeConcepts.put(groupId, groupAttributes);

			List<String> groups = new ArrayList<>();
			populateGroupConcepts(groupBean, groups);
			groupConcepts.put(groupId, groups);
		}
	}

	@Override
	protected Keyable processSeriesNode() {
		//Clear values
		annotations = null;
		keyValues.clear();
		attributeValues.clear();
		multilingualAttributeValues.clear();
		timeFormat = null;
		KeyValue timeValue = null;
		List<KeyValue> key = new ArrayList<>();
		for (int i = 0; i < parser.getAttributeCount(); i++) {
			String attributeId = getComponentId(parser.getAttributeLocalName(i));
			String attributeValue = parser.getAttributeValue(i);
			String attributePrefix = parser.getAttributePrefix(i);

			if (attributeId.equals(timeConcept)) {
				timeValue = KeyValueImpl.getInstance(timeConcept, attributeValue);
			} else if (measureDimension != null && "xsi".equals(attributePrefix) && attributeId.equals("type")) {
				key.add(KeyValueImpl.getInstance(measureDimension, attributeValue.split(":")[1]));
			} else if (dimensionConcepts.contains(attributeId)) {
				keyValues.put(attributeId, attributeValue);
			} else if (seriesAttributes.contains(attributeId)) {
				attributeValues.put(attributeId, attributeValue);
			} else if (datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
				//This attribute was not found as a series level attribute, it could still be an observation level attribute
				//But this is only allowed if we are processing this series node as a FLAT obs node which is both an obs and key
				//In which case this attributeName could be an observation attribute, the primary measure, or the time concept.
				if (!observationAttributes.contains(attributeId)
						&& !attributeId.equals(primaryMeasureConcept)
						&& !attributeId.equals(timeConcept)) {
					handleException("Unexpected attribute '" + attributeId + "' for element '" + parser.getXMLPath() + "'", true, SEVERITY.HIGH, TYPE.ADDED_ATTRIBUTE);
				}
			} else {
				//Series attr
				attributeValues.put(attributeId, attributeValue);
			}
		}
		for (String dimensionConcept : dimensionConcepts) {
			String conceptValue = null;
			if (keyValues.containsKey(dimensionConcept)) {
				conceptValue = keyValues.get(dimensionConcept);
			} else {
				conceptValue = rolledUpAttributes.get(dimensionConcept);
			}

			if (conceptValue == null && datasetHeaderBean.getAction() != DATASET_ACTION.DELETE) {
				if (!isTimeSeries() && getCrossSectionConcept().equals(dimensionConcept)) {
					//This is expected
				} else {
					//Missing series key value
				}
			} else {
				KeyValue kv = KeyValueImpl.getInstance(dimensionConcept, conceptValue);
				key.add(kv);
			}
		}
		if (!isTimeSeries() && timeValue != null) {
			key.add(timeValue);
		}

		List<KeyValue> attributes = new ArrayList<>();
		List<IMultilingualKeyValue> complexAttributes = new ArrayList<>();
		List<IMultilingualKeyValue> complexMeasures = new ArrayList<>();
		try {
			processAttributes(seriesAttributes, attributes);
		} catch (SdmxException e) {
			throw new SdmxException(e, "Error while procesing series attributes");
		}

		//Clear values
		keyValues.clear();
		attributeValues.clear();

		if (datasetPosition == DATASET_POSITION.SERIES) {
			while (parser.peak()) {
				String nodeName = parser.getElementName();
				if (parser.isStartElement()) {
					if (nodeName.equals("Annotations")) {
						annotations = processAnnotations(parser);
					}
					else if (nodeName.equals("Obs")) {
						if (isTimeSeries()) {
							for (int i = 0; i < parser.getAttributeCount(); i++) {
								String attributeId = getComponentId(parser.getAttributeLocalName(i));
								if (attributeId.equals(timeConcept)) {
									try {
										// Determine the time format by using the run-ahead parser,
										// but this can't be done in SDMX 1.0 (since YYYY-01 can represent many things
										// For SDMX 1.0 use the FREQ dimension if present
										if (SDMX_SCHEMA.VERSION_ONE == schemaVersion) {
											DimensionBean frequencyDimension = getDataStructure().getFrequencyDimension();
											if (frequencyDimension != null) {
												for (KeyValue keyValue : key) {
													// Try to determine the timeFormat from the FREQ attribute
													if (keyValue.getConcept().equals(frequencyDimension.getId())) {
														try {
															timeFormat = TIME_FORMAT.getTimeFormatFromCodeId(keyValue.getCode());
														} catch (Exception e) {
															// Consume error. The time format value is simply an unexpected code.
														}
														break;
													}
												}

											}
										}

										if (timeFormat == null && DateUtil.isSdmxDate(parser.getAttributeValue(i))) {
											timeFormat = DateUtil.getTimeFormatOfDate(parser.getAttributeValue(i));
										}
									} catch (Exception e) {
										// The TimeFormat could not be determined. Consume error
									}
								}
							}
						}
						break;
					} else if (nodeName.equals("Comp")) {
						processComplexAttribute(parser, attributes, measures);
						addNewComplexAttributes(complexAttributes);
						addNewComplexMeasures(complexMeasures);
					} else {
						parser.moveNextNode();  //move next forces it to move past the peak so the xpath is correct on the error message
						handleException("Unexpected element '" + parser.getXMLPath() + "'", true, SEVERITY.HIGH, TYPE.ADDED_ELEMNET,ERROR_POSITION.SERIES);
						parser.skipCurrentNode();  //then  skip this entire unknown element and all child elements
					}
				} else {
					if (nodeName.equals("Series")) {
						break;
					}
				}
			}
		}

		AnnotationBean[] seriesAnnotations = null;
		if (annotations != null) {
			seriesAnnotations = annotations.stream().toArray(AnnotationBean[]::new);
		}
		currentKey = KeyableImpl.seriesKey(currentDataflow, currentDsd, key, attributes, complexAttributes, seriesAnnotations);
		if (datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
			currentObs = processObsNode(parser);
		}

		attributeValues.clear();
		multilingualAttributeValues.clear();
		return currentKey;
	}

	@Override
	protected Keyable processGroupNode() {
		//Clear values
		keyValues.clear();
		attributeValues.clear();
		multilingualAttributeValues.clear();

		for (int i = 0; i < parser.getAttributeCount(); i++) {
			String attributeName = getComponentId(parser.getAttributeLocalName(i));
			String attributeValue = parser.getAttributeValue(i);
			String namespace = parser.getAttributePrefix(i);
			if (namespace != null && namespace.equals("xsi") && attributeName.equals("type")) {
				setGroupId(attributeValue);
			} else {
				if (dimensionConcepts.contains(attributeName)) {
					keyValues.put(attributeName, attributeValue);
				} else {
					attributeValues.put(attributeName, attributeValue);
				}
			}
		}
		List<KeyValue> key = new ArrayList<>();
		List<KeyValue> attributes = new ArrayList<>();
		List<KeyValue> measures = new ArrayList<>();
		List<IMultilingualKeyValue> complexAttributes = new ArrayList<>();

		if (groupId == null) {
			// Group ID is OPTIONAL only if there is a single group in the DSD
			if (groups.size() == 1) {
				// Set the group ID
				groupId = groups.get(0);
			} else {
				throw new SdmxSemmanticException("Group is missing Group Id. Syntax on the Group element is xsi:type='group_id'");
			}
		}
		if (!groupConcepts.containsKey(groupId)) {
			throw new SdmxSemmanticException("Data Structure '" + currentDsd + "' does not contain group '" + groupId + "'");
		}
		for (String groupConcept : groupConcepts.get(groupId)) {
			String conceptValue = null;
			if (keyValues.containsKey(groupConcept)) {
				conceptValue = keyValues.get(groupConcept);
			} else {
				conceptValue = rolledUpAttributes.get(groupConcept);
			}
			if (conceptValue != null) {
				KeyValue kv = KeyValueImpl.getInstance(groupConcept, conceptValue);
				key.add(kv);
			}
		}

		processAttributes(groupAttributeConcepts.get(groupId), attributes);

		if (isThreePointZero) {
			// check for complex attributes
			processComplexAttributes();
			try {
				addNewComplexAttributes(complexAttributes);
			} catch (SdmxException e) {
				throw new SdmxSemmanticException(e, "Error while processing group attributes for group '" + groupId + "'");
			}
		}

		//Clear values
		keyValues.clear();
		attributeValues.clear();

		currentKey = KeyableImpl.groupKey(currentDataflow, currentDsd, groupId, key, attributes, complexAttributes);
		return currentKey;
	}

	@Override
	protected Observation processObsNode(StaxReader parser) {
		clearObsInformation();
		processObservation(parser);
		try {
			AnnotationBean[] obsAnnotations = null;
			if (annotations != null) {
				obsAnnotations = annotations.stream().toArray(AnnotationBean[]::new);
			}
			try {
				obsTime = SdmxDateUtil.unifyObservationTime(obsTime, schemaVersion, timeFormat, enforceStrict2_1);
			} catch (TimeFormatParsingException e) {
				handleException(e.getMessage(), true, SEVERITY.HIGH, TYPE.INVALID_DATE, ERROR_POSITION.OBSERVATION);
			}

			if (isThreePointZero) {
				// Since the obsValue is in its own variable, add it to the list of measures
				if (obsValue != null) {
					measures.add(KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue));
				}
				if (PrimaryMeasureBean.FIXED_ID.equals(primaryMeasureConcept)) {
					if (crossSection != null) {
						return ObservationImpl.crossSection(currentKey, crossSection.getConcept(), crossSection.getCode(), obsValue, attributes, measures, complexAttributes, complexMeasures, obsAnnotations);
					}
					if (!hasTimeDimension) {
						return new ObservationImpl(currentKey, null, null, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, complexAttributes, complexMeasures, annotations);
					}
					return ObservationImpl.multipleMeasureTimeSeries(currentKey, obsTime, measures, attributes, complexAttributes, complexMeasures, obsAnnotations);

				} else {
					if (hasTimeDimension) {
						return ObservationImpl.multipleMeasureTimeSeries(currentKey, obsTime, measures, attributes, complexAttributes, complexMeasures, obsAnnotations);
					}
					return ObservationImpl.multipleMeasure(currentKey, measures, attributes, complexAttributes, complexMeasures, obsAnnotations);
				}
			} else {
				if (primaryMeasureConcept.equals(PrimaryMeasureBean.FIXED_ID)) {
					if (crossSection != null) {
						return ObservationImpl.crossSection(currentKey, crossSection.getConcept(), crossSection.getCode(), obsValue, attributes, obsAnnotations);
					}
					if (!hasTimeDimension) {
						return new ObservationImpl(currentKey, null, null, KeyValueImpl.getInstance(PrimaryMeasureBean.FIXED_ID, obsValue), attributes, annotations);
					}
					return ObservationImpl.timeSeries(currentKey, obsTime, obsValue, attributes, complexAttributes, obsAnnotations);
				} else {
					return ObservationImpl.singleMeasure(currentKey, obsTime, primaryMeasureConcept, obsValue, attributes, obsAnnotations);
				}
			}

		} catch (Throwable th) {
			if (currentKey != null) {
				throw new SdmxSemmanticException(th, "Error while processing observation for key " + currentKey);
			}
			throw new SdmxSemmanticException(th, "Error while processing observation");
		} finally {
			attributes.clear();
			complexAttributes.clear();
		}
	}

	private void processObservation(StaxReader parser) {
		clearObsInformation();

		for (int i = 0; i < parser.getAttributeCount(); i++) {
			String attributeId = getComponentId(parser.getAttributeLocalName(i));
			String attributeValue = parser.getAttributeValue(i);
			String attributePrefix = parser.getAttributePrefix(i);
			if (measureDimension != null && "xsi".equals(attributePrefix) && attributeId.equals("type")) {
				crossSection = KeyValueImpl.getInstance(measureDimension, attributeValue.split(":")[1]);
			} else if (!isTimeSeries() && attributeId.equals(getCrossSectionConcept())) {
				crossSection = KeyValueImpl.getInstance(attributeId, attributeValue);
			} else if (observationAttributes.contains(attributeId)) {
				attributeValues.put(attributeId, attributeValue);
			} else if (attributeId.equals(primaryMeasureConcept)) {
				obsValue = attributeValue;
			} else if (attributeId.equals(timeConcept)) {
				obsTime = attributeValue;
			} else if (isThreePointZero) {
				ComponentBean c = this.currentDsd.getComponent(attributeId);
				if (c.getStructureType() == SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION) {
					KeyValue kv = KeyValueImpl.getInstance(attributeId, attributeValue);
					measures.add(kv);
				}
			} else {
				if (datasetPosition == DATASET_POSITION.OBSERAVTION_AS_SERIES) {
					if (!seriesAttributes.contains(attributeId)) {
						//handleException("Unexpected attribute '"+attributeId+"' for element '"+parser.getXMLPath()+"'", true, SEVERITY.HIGH, TYPE.ADDED_ATTRIBUTE);
					}
				} else {
					attributeValues.put(attributeId, attributeValue);
					//handleException("Unexpected attribute '"+attributeId+"' for element '"+parser.getXMLPath()+"'", true, SEVERITY.HIGH, TYPE.ADDED_ATTRIBUTE);
				}
			}
		}
		if (isThreePointZero) {
			while (parser.moveNextNode()) {
				if (parser.isStartElement()) {
					if (parser.getElementName().equals("Comp")) {
						processComplexAttribute(parser, attributes, measures);
						addNewComplexAttributes(complexAttributes);
						addNewComplexMeasures(complexMeasures);
					}
				} else if (parser.getEvent() == 2) {
					if (parser.getElementName().equals("Obs")) {
						break;
					}
				}
			}
		}

		try {
			processAttributes(observationAttributes, attributes);
		} catch (SdmxSemmanticException e) {
			throw new SdmxSemmanticException(e, "Error while procesing observation attributes");
		}
		try {
			if (!isTimeSeries() && crossSection == null && !getCrossSectionConcept().equals("AllDimensions")) {
				throw new SdmxSemmanticException("Error while processing observation for series '" + currentKey + "' , missing required concept '" + getCrossSectionConcept() + "'");
			}
		} catch (Throwable th) {
			if (currentKey != null) {
				throw new SdmxSemmanticException(th, "Error while processing observation for key " + currentKey);
			}
			throw new SdmxSemmanticException(th, "Error while processing observation");
		}
		//Clear values
		attributeValues.clear();

		//Check for Annotations
		if (!isThreePointZero) {
			parser.moveNextNode();
		}
		if (parser.isStartElement()) {
			if (parser.getElementName().equals("Annotations")) {
				//Next node is not a start element, this is expecting an Annotations em
				annotations = processAnnotations(parser);
			} else {
				handleException("Unexpected element '" + parser.getXMLPath() + "'", true, SEVERITY.HIGH, TYPE.ADDED_ELEMNET);
				parser.skipCurrentNode();
			}
		}
	}

	private void clearObsInformation() {
		//Clear values
		attributeValues.clear();
		multilingualAttributeValues.clear();
		multilingualMeasureValues.clear();
		annotations = null;

		//Clear the current Obs information
		obsTime = null;
		obsValue = null;
		attributes = new ArrayList<>();
		complexAttributes = new ArrayList<>();
		measures = new ArrayList<>();
		complexMeasures = new ArrayList<>();
		crossSection = null;
	}


	private void processAttributes(Set<String> attributeConcepts, List<KeyValue> attributes) {
		for (String id : attributeValues.keySet()) {
			String conceptValue;
			if (attributeConcepts.contains(id)) {
				conceptValue = attributeValues.get(id);
			} else {
				conceptValue = rolledUpAttributes.get(id);
			}

			if (conceptValue == null) {
				conceptValue = attributeValues.get(id);
			}

			if (conceptValue != null) {
				KeyValue kv = KeyValueImpl.getInstance(id, conceptValue);
				attributes.add(kv);
			}
		}
	}

	private void processComplexAttribute(StaxReader parser, List<KeyValue> attributes, List<KeyValue> measures) {
		String attributeName = "";
		List<IMultilingualNodeValue> multilingualNodeValues = new ArrayList<>();
		List<String> values = new ArrayList<String>();
		DataStructureBean dsd = this.currentDsd;
		try {
			for (int i = 0; i < parser.getAttributeCount(); i++) {
				String attributeId = getComponentId(parser.getAttributeLocalName(i));
				String attributeValue = parser.getAttributeValue(i);
				if (attributeId.equals("id")) {
					attributeName = attributeValue;
				}
			}
			while (parser.moveNextNode()) {
				if (parser.isStartElement()) {
					String nextNodeName = parser.getElementName();
					if (nextNodeName.equals("Value")) {
						List<TextTypeWrapper> wrapperList = new ArrayList<>();
						String plainText = null;
						if ((parser.getEvent() == 4 && !parser.getText().trim().isEmpty()) || parser.getNextEvent() == 4 && !parser.getText().trim().isEmpty()) {
							plainText = parser.getText().trim();
							values.add(plainText);
						} else {
							while (parser.moveNextNode()) {
								if (parser.isStartElement()) {
									if (parser.getElementName().equals("Text")) {
										String locale = "en";
										String text = "";
										if (parser.getAttributeCount() > 0) {
											locale = parser.getAttributeValue(0);
										}
										text = parser.getElementText();
										TextTypeWrapper textTypeWrapper = new TextTypeWrapperImpl(locale, text, null);
										wrapperList.add(textTypeWrapper);
									}
								} else {
									if (parser.getElementName().equals("Value")) {
										MultilingualNodeValue multilingualNodeValue = new MultilingualNodeValue(wrapperList);
										multilingualNodeValues.add(multilingualNodeValue);
										break;
									}
								}
							}
						}
					}
				} else {
					if (parser.getElementName().equals("Comp")) {
						ComponentBean c = dsd != null ? dsd.getComponent(attributeName) : defaultDsd.getComponent(attributeName);
						if (c.getStructureType() == SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION) {
							if (!values.isEmpty()){
								KeyValue multivalueMeasure = KeyValueImpl.getInstance(attributeName, values.toArray(new String[0]));
								measures.add(multivalueMeasure);
							} else {
								multilingualMeasureValues.put(attributeName, multilingualNodeValues);
							}
						} else if (c.getStructureType() == SDMX_STRUCTURE_TYPE.DATA_ATTRIBUTE) {
							if (!values.isEmpty()){
								KeyValue multivalueAttribute = KeyValueImpl.getInstance(attributeName, values.toArray(new String[0]));
								attributes.add(multivalueAttribute);
							} else {
								multilingualAttributeValues.put(attributeName, multilingualNodeValues);
							}
						}
						break;
					}
				}
			}

		} catch (SdmxException e) {
			throw new SdmxSemmanticException("Comp XML element does not contain Value elements.");
		}
	}

	private void addNewComplexAttributes(List<IMultilingualKeyValue> complexAttributes) {
		Set<String> allConcepts = new HashSet<>();
		for (IMultilingualKeyValue iMultilingualKeyValue : complexAttributes) {
			allConcepts.add(iMultilingualKeyValue.getConcept());
		}

		for (Map.Entry<String, List<IMultilingualNodeValue>> entry : multilingualAttributeValues.entrySet()) {
			if (!allConcepts.contains(entry.getKey())) {
				IMultilingualKeyValue multilingualKv = MultilingualKeyValue.getInstance(entry.getKey(), entry.getValue());
				complexAttributes.add(multilingualKv);
			}
		}
		multilingualAttributeValues.clear();
	}

	private void addNewComplexMeasures(List<IMultilingualKeyValue> multilingualMeasures) {
		Set<String> allConcepts = new HashSet<>();
		for (IMultilingualKeyValue iMultilingualKeyValue : complexAttributes) {
			allConcepts.add(iMultilingualKeyValue.getConcept());
		}

		for (Map.Entry<String, List<IMultilingualNodeValue>> entry : multilingualMeasureValues.entrySet()) {
			if (!allConcepts.contains(entry.getKey())) {
				IMultilingualKeyValue compKeyValue = MultilingualKeyValue.getInstance(entry.getKey(), entry.getValue());
				complexMeasures.add(compKeyValue);
			}
		}
		multilingualMeasureValues.clear();
	}
}
