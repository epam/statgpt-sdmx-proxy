package io.sdmx.format.ml.factory.data;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_DATA_FORMAT;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.format.ml.model.SDMXMLDataFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxMLDataFormatFactory implements DataFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();
	
	private static SdmxMLDataFormatFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxMLDataFormatFactory() {
		addSupportedFormat(SDMXMLDataFormat.GENERIC_1_0);
		addSupportedFormat(SDMXMLDataFormat.GENERIC_2_0);
		addSupportedFormat(SDMXMLDataFormat.GENERIC_2_1);
		addSupportedFormat(SDMXMLDataFormat.COMPACT_1_0);
		addSupportedFormat(SDMXMLDataFormat.COMPACT_2_0);
		addSupportedFormat(SDMXMLDataFormat.COMPACT_2_1);
		addSupportedFormat(SDMXMLDataFormat.COMPACT_3_0);
		supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}

	public static SdmxMLDataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLDataFormatFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxMLDataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Class<DataFormat> getFormatClass() {
		return DataFormat.class;
	}

	private void addSupportedFormat(SdmxDataFormat df) {
		String[] acceptHeaders = df.getFormatDetails().getAcceptHeaders();
		for(String acceptHeader : acceptHeaders) {
			supportedFormats.put(acceptHeader, df.getFormatDetails());
		}
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}
	
	@Override
	/**
	 * Will process something like the following:
	 *
	 * sdmx.genericdata+xml;version=2.1
	 * sdmx.structurespecificdata+xml;version=2.1
	 * sdmx.generictimeseriesdata+xml;version=2.1
	 * sdmx.structurespecifictimeseriesdata+xml;version=2.1
	 * sdmx.genericmetadata+xml;version=2.1
	 * sdmx.structurespecificmetadata+xml;version=2.1
	 */
	public DataFormat getFormat(Request request, IVNDHeader vndHeader) {
		String applicationVnd = vndHeader.getVnd();
		String version = vndHeader.getParameterValue("version");
		if(applicationVnd.startsWith("sdmx")) {

			BASE_DATA_FORMAT bdf = null;
			if(applicationVnd.equals("sdmx.genericdata+xml")) {
				bdf = BASE_DATA_FORMAT.GENERIC;
			} else if(applicationVnd.equals("sdmx.structurespecificdata+xml")) {
				bdf = BASE_DATA_FORMAT.COMPACT;
			} else if(applicationVnd.equals("sdmx.generictimeseriesdata+xml")) {
				bdf = BASE_DATA_FORMAT.GENERIC;
			} else if(applicationVnd.equals("sdmx.structurespecifictimeseriesdata+xml")) {
				bdf = BASE_DATA_FORMAT.COMPACT;
			} else if(applicationVnd.equals("sdmx.data+xml")) {
                bdf = BASE_DATA_FORMAT.COMPACT;
            }

			if(version == null) {
				version = "2.1";
			}
			if(version.equals("1.0")) {
				if(bdf == BASE_DATA_FORMAT.COMPACT) {
					return SDMXMLDataFormat.COMPACT_1_0;
				} else if(bdf == BASE_DATA_FORMAT.GENERIC)  {
					return SDMXMLDataFormat.GENERIC_1_0;
				}
			} else if(version.equals("2.0")) {
				if(bdf == BASE_DATA_FORMAT.COMPACT) {
					return SDMXMLDataFormat.COMPACT_2_0;
				} else if(bdf == BASE_DATA_FORMAT.GENERIC)  {
					return SDMXMLDataFormat.GENERIC_2_0;
				}
			} else if(version.equals("2.1")) {
				if(bdf == BASE_DATA_FORMAT.COMPACT) {
					return SDMXMLDataFormat.COMPACT_2_1;
				} else if(bdf == BASE_DATA_FORMAT.GENERIC)  {
					return SDMXMLDataFormat.GENERIC_2_1;
				}
			} else if(version.equals("3.0.0")) {
				if(bdf == BASE_DATA_FORMAT.COMPACT) {
					return SDMXMLDataFormat.COMPACT_3_0;
				}
			}
		}
		return null;
	}

	@Override
	public DataFormat getFormat(String format, Request request) {
		if(format == null) {
			return null;
		}
		String[] split = format.split("-");
		format = split[0];
		if(!format.equals("sdmx")) {
			return null;
		}
		if(split.length == 1) {
			return SDMXMLDataFormat.COMPACT_2_1;
		}
		String sdmxType = split[1];

		SDMXMLDataFormat responseDataType = SDMXMLDataFormat.GENERIC_2_1;
		if(sdmxType != null) {
			if(sdmxType.equals("compact")) {
				responseDataType = SDMXMLDataFormat.COMPACT_2_1;
			} else if(sdmxType.equals("generic")) {
				responseDataType = SDMXMLDataFormat.GENERIC_2_1;
			} else {
				return null;
			}
		}
		if(split.length == 2) {
			return responseDataType;
		}

		String responseVersion = split[2];
		if(responseVersion != null) {
			BASE_DATA_FORMAT baseFormat = responseDataType.getSdmxDataFormat().getBaseDataFormat();
			if(responseVersion.equals("1.0")) {
				switch(baseFormat) {
				case COMPACT : return SDMXMLDataFormat.COMPACT_1_0;
				case GENERIC : return SDMXMLDataFormat.GENERIC_1_0;
				default : throw new SdmxNotImplementedException("Response format 1.0 " + baseFormat);
				}
			} else if(responseVersion.equals("2.0")) {
				switch(baseFormat) {
				case COMPACT : return SDMXMLDataFormat.COMPACT_2_0;
				case GENERIC : return SDMXMLDataFormat.GENERIC_2_0;
				default : throw new SdmxNotImplementedException("Response format 2.0 " + baseFormat);
				}
			} else if(responseVersion.equals("2.1")) {
				switch(baseFormat) {
				case COMPACT : return SDMXMLDataFormat.COMPACT_2_1;
				case GENERIC : 	return SDMXMLDataFormat.GENERIC_2_1;
				default : throw new SdmxNotImplementedException("Response format 2.1 " + baseFormat);
				}
			} else if(responseVersion.equals("3.0")) {
				return SDMXMLDataFormat.COMPACT_3_0;
			} else {
				throw new IllegalArgumentException("Unknown response version for a data query '"+responseVersion+"', known types are 1.0, 2.0, 2.1, 3.0");
			}
		}
		return null;
	}

	@Override
	public DataFormat getDataFormat(ReadableDataLocation sourceData) {
		if(sourceData == null) {
			return null;
		}
		FILE_FORMAT format = sourceData.getFormat();
		if(format != FILE_FORMAT.XML) {
			return null;
		}

		try (InputStream stream = sourceData.getInputStream()) {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
			XMLStreamReader parser = factory.createXMLStreamReader(stream, "UTF-8");
			String rootNode = null;
			while (parser.hasNext()) {
				int event = parser.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					rootNode = parser.getLocalName();
					for(int i = 0 ; i < parser.getNamespaceCount(); i ++) {
						String ns = parser.getNamespaceURI(i);
						if(SdmxConstants.getNamespacesV1().contains(ns)) {
							if(rootNode.equals(SdmxConstants.GENERIC_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.GENERIC_1_0;
							} else if(rootNode.equals(SdmxConstants.UTILITY_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.UTILITY_1_0;
							} else if(rootNode.equals(SdmxConstants.COMPACT_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.COMPACT_1_0;
							} else if(rootNode.equals(SdmxConstants.CROSS_SECTIONAL_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.CROSS_SECTIONAL_1_0;
							}  else if(rootNode.equals(SdmxConstants.MESSAGE_GROUP_ROOT_NODE)) {
								BASE_DATA_FORMAT dataForamt = getMessageGroupDataFormat(parser);
								if(dataForamt != null) {
									switch(dataForamt) {
									case COMPACT : return SDMXMLDataFormat.MESSAGE_GROUP_1_0_COMPACT;
									case GENERIC : return SDMXMLDataFormat.MESSAGE_GROUP_1_0_GENERIC;
									case UTILITY : return SDMXMLDataFormat.MESSAGE_GROUP_1_0_UTILITY;
									}
								}
								return null;
							}else {
								return null;
							}

						}
						if(SdmxConstants.getNamespacesV2().contains(ns)) {
							if(rootNode.equals(SdmxConstants.GENERIC_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.GENERIC_2_0;
							} else if(rootNode.equals(SdmxConstants.UTILITY_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.UTILITY_2_0;
							} else if(rootNode.equals(SdmxConstants.COMPACT_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.COMPACT_2_0;
							} else if(rootNode.equals(SdmxConstants.CROSS_SECTIONAL_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.CROSS_SECTIONAL_2_0;
							} else if(rootNode.equals(SdmxConstants.MESSAGE_GROUP_ROOT_NODE)) {
								BASE_DATA_FORMAT dataForamt = getMessageGroupDataFormat(parser);
								if(dataForamt != null) {
									switch(dataForamt) {
									case COMPACT : return SDMXMLDataFormat.MESSAGE_GROUP_2_0_COMPACT;
									case GENERIC : return SDMXMLDataFormat.MESSAGE_GROUP_2_0_GENERIC;
									case UTILITY : return SDMXMLDataFormat.MESSAGE_GROUP_2_0_UTILITY;
									}
								}
								throw new SdmxSyntaxException("Unknown Message Group Format");
							} else {
								return null;
							}
						}
						if(SdmxConstants.getNamespacesV2_1().contains(ns)) {
							if(rootNode.equals(SdmxConstants.STRUCTURE_SPECIFIC_TIME_SERIES_DATA)
									|| rootNode.equals(SdmxConstants.STRUCTURE_SPECIFIC_DATA)) {
								return SDMXMLDataFormat.COMPACT_2_1;
							} else if(rootNode.equals(SdmxConstants.GENERIC_TIME_SERIES_DATA_ROOT_NODE) ||
									rootNode.equals(SdmxConstants.GENERIC_DATA_ROOT_NODE)) {
								return SDMXMLDataFormat.GENERIC_2_1;
							}
							else {
								throw new SdmxSyntaxException("Unexpected root node '"+rootNode+"'");
							}
						}
						if(SdmxConstants.getNamespacesV3().contains(ns)) {
							if(rootNode.equals(SdmxConstants.STRUCTURE_SPECIFIC_TIME_SERIES_DATA)
									|| rootNode.equals(SdmxConstants.STRUCTURE_SPECIFIC_DATA)) {
								return SDMXMLDataFormat.COMPACT_3_0;
							}
							else {
								throw new SdmxSyntaxException("Unexpected root node '"+rootNode+"'");
							}
						}
					}
					return null;
				}
			}
			return null;
		} catch (javax.xml.stream.XMLStreamException e) {
			return null;
		} catch (IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}

	private BASE_DATA_FORMAT getMessageGroupDataFormat(XMLStreamReader parser) throws XMLStreamException {
		while (parser.hasNext()) {
			int event = parser.next();
			if (event == XMLStreamConstants.START_ELEMENT) {
				String rootNode = parser.getLocalName();
				if(rootNode.equals("DataSet")) {
					String namespaceURI = parser.getNamespaceURI();
					if(SdmxConstants.GENERIC_NS_1_0.equals(namespaceURI) || SdmxConstants.GENERIC_NS_2_0.equals(namespaceURI)) {
						return BASE_DATA_FORMAT.GENERIC;
					}
					if(SdmxConstants.UTILITY_NS_1_0.equals(namespaceURI) || SdmxConstants.UTILITY_NS_2_0.equals(namespaceURI)) {
						return BASE_DATA_FORMAT.UTILITY;
					}
					//The Compact Messages start with Namespace URN, but to be lienient also check for compact namespace
					if(SdmxConstants.COMPACT_NS_1_0.equals(namespaceURI) || SdmxConstants.COMPACT_NS_2_0.equals(namespaceURI) || namespaceURI.startsWith("urn")) {
						return BASE_DATA_FORMAT.COMPACT;
					}
					return null;
				}
			}
		}
		return null;
	}


}
