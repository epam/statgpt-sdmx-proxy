package io.sdmx.format.ml.engine.structure.writer.v21.provision;

import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxProvisionWriterEngineV21 extends AbstractV21Writer<ProvisionAgreementBean> implements IFusionSingleton {
	private static StaxProvisionWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProvisionWriterEngineV21() {}

	public static StaxProvisionWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProvisionWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ProvisionAgreement";
	}

	@Override
	protected void writeMaintainableInternal(ProvisionAgreementBean maint, StaxWriter writer) {
		StaxRefUtil.writeReference(maint.getStructureUseage(), writer, "StructureUsage");
		StaxRefUtil.writeReference(maint.getDataproviderRef(), writer, "DataProvider");
	}
}
