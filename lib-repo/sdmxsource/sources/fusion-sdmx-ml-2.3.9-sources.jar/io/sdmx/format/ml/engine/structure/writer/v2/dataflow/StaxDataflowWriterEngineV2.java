package io.sdmx.format.ml.engine.structure.writer.v2.dataflow;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxRefUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDataflowWriterEngineV2 extends AbstractV2Writer<DataflowBean> implements IFusionSingleton {
	private static StaxDataflowWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataflowWriterEngineV2() {}

	public static StaxDataflowWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataflowWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Dataflow";
	}

	@Override
	protected void writeMaintainableInternal(DataflowBean maint, StaxWriter writer) {
		StaxRefUtilV2.writeReference(maint.getDataStructureRef(), writer, "KeyFamilyRef");
	}
}
