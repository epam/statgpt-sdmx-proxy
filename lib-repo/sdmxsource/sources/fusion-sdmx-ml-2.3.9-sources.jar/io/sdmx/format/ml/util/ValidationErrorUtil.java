package io.sdmx.format.ml.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import io.sdmx.api.sdmx.error.IStructureValidationError;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.beans.base.IURN;

/**
 * Utility method for helping with IStructureValidationError and IStructureValidationErrorHandler
 */
public class ValidationErrorUtil {
	
	/**
	 * Converts a List of StructureValidationErrors, which are Identifiables to Errors, into a Map of MaintainableURNs to errors for that maintainable.
	 * @param errorHandler which may be null, in which case an empty Map will be returned
	 * @return
	 */
	public static Map<String, List<String>> createMapOfMaintainableURNs(IStructureValidationErrorHandler errorHandler) {
		// Use of a TreeMap is for sorting the URNs alphabetically
		Map<String, List<String>> maintsToErrors = new TreeMap<>();
		
		if (errorHandler == null || errorHandler.getErrors().isEmpty()) {
			return maintsToErrors;
		}
		
		for (IStructureValidationError err : errorHandler.getErrors()) {
			IURN urn = err.getUrn();
			IURN tgtUrn;
			String errPrefix;
			if (urn.isMaintainableReference()) {
				tgtUrn = urn;
				errPrefix="";
			} else {
				// PRL check this
				tgtUrn = urn.getMaintainableURN();
				// The prefix for each line is most of the URN of the Identifiable
				String firstPartOfUrn = urn.getURN().split("=")[0];
				int lastDot = firstPartOfUrn.lastIndexOf('.') + 1;
				errPrefix = urn.getURN().substring(lastDot)  + ": ";
			}
				
			List<String> list = maintsToErrors.get(tgtUrn.getURN());
			if (list == null) {
				list = new ArrayList<>();
				maintsToErrors.put(tgtUrn.getURN(), list);
			}
			for (String anErr : err.getErrors()) {
				list.add(errPrefix +anErr);
			}
		}
		return maintsToErrors;
	}

}
