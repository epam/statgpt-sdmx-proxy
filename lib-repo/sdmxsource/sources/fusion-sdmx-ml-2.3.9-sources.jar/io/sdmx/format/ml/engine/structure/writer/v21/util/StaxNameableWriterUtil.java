package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxNameableWriterUtil {

	public static void writeBean(NameableBean nameable, String elementName, StaxWriter writer) {
		writeBean(nameable, elementName, writer, null);
	}
	
	public static void writeBean(NameableBean nameable, String elementName, StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = StaxIdentifiableWriterUtil.getAttributes(nameable);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName, attributes);
		writeBean(nameable, writer);
	}
	
	public static void writeBean(NameableBean nameable, StaxWriter writer) {
		StaxAnnotableWriterUtil.writeBean(nameable, writer);
		StaxTextWriterUtil.writeTextTypes(nameable.getNames(), writer, "Name");
		StaxTextWriterUtil.writeTextTypes(nameable.getDescriptions(), writer, "Description");
	}
	
}
