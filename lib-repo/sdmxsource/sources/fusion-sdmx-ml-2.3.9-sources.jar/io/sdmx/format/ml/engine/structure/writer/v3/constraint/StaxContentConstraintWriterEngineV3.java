package io.sdmx.format.ml.engine.structure.writer.v3.constraint;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.sdmx.model.beans.base.TimeRangeBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.CubeRegionBean;
import io.sdmx.api.sdmx.model.beans.registry.KeyValues;
import io.sdmx.api.sdmx.model.beans.registry.ReleaseCalendarBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxContentConstraintWriterEngineV3 extends StaxAbstractConstraintWriterEngine<ContentConstraintBean> implements IFusionSingleton {
	private static StaxContentConstraintWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxContentConstraintWriterEngineV3() {}

	public static StaxContentConstraintWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxContentConstraintWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "DataConstraint";
	}

	@Override
	protected void writeMaintainableInternal(ContentConstraintBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		super.writeMaintainableInternal(maint, externalLinks, writer);
		writeCubeRegion(maint.getIncludedCubeRegion(), true, writer);
		writeCubeRegion(maint.getExcludedCubeRegion(), false, writer);
		writeReleaseCalendar(maint.getReleaseCalendar(), writer);
	}



	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(ContentConstraintBean maint) {
		Map<String, String> returnMap = new HashMap<>();
		returnMap.put("role", maint.isDefiningActualDataPresent() ? "Actual" : "Allowed");
		return returnMap;
	}

	private void writeReleaseCalendar(ReleaseCalendarBean relCal, StaxWriter writer) {
		if(relCal != null) {
			writer.writeStartElement(NS, "ReleaseCalendar");
			writer.writeElement(NS, "Periodicity", relCal.getPeriodicity());
			writer.writeElement(NS, "Offset", relCal.getOffset());
			writer.writeElement(NS, "Tolerance", relCal.getTolerance());
			writer.writeEndElement(); // End ReleaseCalendar
		}
	}

	private void writeCubeRegion(CubeRegionBean cubeRegion, boolean isIncluded, StaxWriter writer) {
		if(cubeRegion != null) {
			writer.writeStartElement(NS, "CubeRegion");
			writer.writeAttribute("include", isIncluded);
			writeKeyValues(cubeRegion.getKeyValues(),"KeyValue", writer);
			writeKeyValues(cubeRegion.getAttributeValues(),"Component", writer);
			writer.writeEndElement(); // End CubeRegion
		}
	}

	private void writeKeyValues(List<KeyValues> kvsList, String nodeName, StaxWriter writer) {
		for(KeyValues kvs : kvsList) {
			writeStartKeyValues(kvs, nodeName, writer);
			writeTimeRange(kvs.getTimeRange(), writer);
			writer.writeEndElement(); // End KeyValue
		}
	}

	private void writeStartKeyValues(KeyValues kvs, String nodeName, StaxWriter writer) {
		writer.writeStartElement(NS, nodeName);
		writer.writeAttribute("id", kvs.getId());
		if(kvs.isRemovePrefix()) {
			writer.writeAttribute("removePrefix", kvs.isRemovePrefix());
		}
		for(String val : kvs.getValues()) {
			writeKeyValues(val, kvs.isCascadeValue(val) ? "true" : null, kvs.getValidityPeriod(val), nodeName, writer);
		}
		for(String val : kvs.getCascadeValues()) {
			if(!kvs.getValues().contains(val)) {
				writeKeyValues(val, kvs.isCascadeValue(val) ? "excluderoot" : null, kvs.getValidityPeriod(val), nodeName, writer);
			}
		}
	}


	private void writeKeyValues(String val, String cascde, SdmxPeriod period, String nodeName, StaxWriter writer) {
		writer.writeStartElement(NS, "Value");
		if(cascde != null) {
			writer.writeAttribute("cascadeValues", cascde);
		}
		if(period != null) {
			if(period.hasStartPeriod()) {
				writer.writeAttribute("validFrom", period.getStartPeriod().getDateInSdmxFormat());
			}
			if(period.hasEndPeriod()) {
				writer.writeAttribute("validTo", period.getEndPeriod().getDateInSdmxFormat());
			}
		}
		writer.writeElementText(val);
		writer.writeEndElement(); // End Value
	}

	private void writeTimeRange(TimeRangeBean timeRange, StaxWriter writer) {
		if(timeRange != null) {
			writer.writeStartElement(NS, "TimeRange");
			if(timeRange.getStartDate() != null) {
				String startNodeName = timeRange.isRange() ? "StartPeriod" : "BeforePeriod";
				writer.writeStartElement(NS, startNodeName);
				writer.writeAttribute("isInclusive", Boolean.valueOf(timeRange.isStartInclusive()).toString());
				writer.writeElementText(timeRange.getStartDate().getDateInSdmxFormat());
				writer.writeEndElement(); //End Start|BeforePeriod
			}
			if(timeRange.getEndDate() != null) {
				String endNodeName = timeRange.isRange() ? "EndPeriod" : "AfterPeriod";
				writer.writeStartElement(NS, endNodeName);
				writer.writeAttribute("isInclusive", Boolean.valueOf(timeRange.isEndInclusive()).toString());
				writer.writeElementText(timeRange.getEndDate().getDateInSdmxFormat());
				writer.writeEndElement(); //End Start|BeforePeriod
			}
			writer.writeEndElement(); // End TimeRange
		}
	}
}
