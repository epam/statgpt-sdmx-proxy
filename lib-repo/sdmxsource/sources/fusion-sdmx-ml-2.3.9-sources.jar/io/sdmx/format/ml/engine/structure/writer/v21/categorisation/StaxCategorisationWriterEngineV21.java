package io.sdmx.format.ml.engine.structure.writer.v21.categorisation;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCategorisationWriterEngineV21 extends AbstractV21Writer<CategorisationBean> implements IFusionSingleton {
	private static StaxCategorisationWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorisationWriterEngineV21() {}
	public static StaxCategorisationWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorisationWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Categorisation";
	}

	@Override
	protected void writeMaintainableInternal(CategorisationBean maint, StaxWriter writer) {
		StaxRefUtil.writeReference(maint.getStructureReference(), writer, "Source");
		StaxRefUtil.writeReference(maint.getCategoryReference(), writer, "Target");
	}
}
