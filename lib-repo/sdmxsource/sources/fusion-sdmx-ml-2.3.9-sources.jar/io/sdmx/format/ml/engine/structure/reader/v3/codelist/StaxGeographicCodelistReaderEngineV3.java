package io.sdmx.format.ml.engine.structure.reader.v3.codelist;

import io.sdmx.api.sdmx.model.mutable.codelist.IGeoFeatureSetCodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.IGeographicCodelistMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.GeoFeatureSetCodeMutableBean;
import io.sdmx.im.mutable.codelist.GeographicCodelistMutableBean;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxGeographicCodelistReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<IGeographicCodelistMutableBean> {
    private static StaxGeographicCodelistReaderEngineV3 INSTANCE;

    //Private constructor - lazy load instance
    private StaxGeographicCodelistReaderEngineV3() {}

    public static StaxGeographicCodelistReaderEngineV3 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxGeographicCodelistReaderEngineV3();
            FusionBeanStore.registerInstance(INSTANCE);
        }

        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "GeographicCodelists";
    }

    @Override
    protected String getRootNodeName() {
        return "GeographicCodelist";
    }
    
    @Override
    protected IGeographicCodelistMutableBean processMaintainable(IStaxReader reader) {
        IGeographicCodelistMutableBean maint = new GeographicCodelistMutableBean();
        StaxItemSchemeUtil.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("GeoFeatureSetCode")) {
                IGeoFeatureSetCodeMutableBean aCode = processGeographicCode(reader);
                maint.addItem(aCode);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        ValidityPeriodUtil.processValidityAnnotations(maint);
        return maint;
    }
    
    private IGeoFeatureSetCodeMutableBean processGeographicCode(IStaxReader reader) {
        IGeoFeatureSetCodeMutableBean code = new GeoFeatureSetCodeMutableBean();
        String geoValue = reader.getAttributeValue("value");
        code.setGeoFeatureSet(geoValue);
        
        StaxNameableUtil.processBean(code, reader);

        if(reader.isStartElement()) {
            if(reader.getElementName().equals("Parent")) {
                code.setParentCode(StaxStructureRefReaderV3.getLocalReference(reader));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();  //Move to end of parent element
        }
        //Leave on an end element
        return code;
    }
}
