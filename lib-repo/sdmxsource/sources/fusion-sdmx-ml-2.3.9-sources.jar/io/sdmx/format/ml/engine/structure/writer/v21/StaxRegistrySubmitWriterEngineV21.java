package io.sdmx.format.ml.engine.structure.writer.v21;

import java.io.OutputStream;
import java.util.Set;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRegistrySubmitWriterEngineV21 extends StaxAbstractStructureWriterEngineV21 implements IFusionSingleton {
	private static StaxRegistrySubmitWriterEngineV21 INSTANCE;
	private static StaxRegistrySubmitWriterEngineV21 PRETTY_INSTANCE;

	public static StaxRegistrySubmitWriterEngineV21 getInstance(boolean prettyPrint) {
		if(!prettyPrint) {
			return getInstance();
		}
		if(PRETTY_INSTANCE == null) {
			PRETTY_INSTANCE = new StaxRegistrySubmitWriterEngineV21();
			PRETTY_INSTANCE.prettyPrint = true;
			FusionBeanStore.registerInstance(PRETTY_INSTANCE);
		}
		return PRETTY_INSTANCE;
	}

	public static StaxRegistrySubmitWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRegistrySubmitWriterEngineV21();
			INSTANCE.prettyPrint = false;
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
        PRETTY_INSTANCE = null;
    }

	private StaxRegistrySubmitWriterEngineV21() {
		super(SDMX_SCHEMA.VERSION_TWO_POINT_ONE,
				StaxStructureWriterUtil.MESSAGE_NS,
				StaxStructureWriterUtil.STRCUTURE_NS,
				StaxStructureWriterUtil.COMMON_NS,
				StaxStructureWriterUtil.REGISTRY_NS,
				SingletonStore.getSingleton(SchemaLocationManager.class, false),
				SingletonStore.getSingleton(HeaderRetrievalManager.class, false) );
	}

	@Override
	protected String getDocumentRoot() {
		return "RegistryInterface";
	}

	@Override
	protected void writeRegistrations(StaxWriter writer, SdmxBeans beans, OutputStream out) {
		Set<RegistrationBean> registrations = beans.getRegistrations();
		writer.startDocument(messageNs, "RegistryInterface");
		writeHeader(writer, beans.getHeader(), true);
		writer.writeStartElement(messageNs, "SubmitRegistrationsRequest");
		StaxMaintainableWriterEngine writerEngine = getWriterEngine(SDMX_STRUCTURE_TYPE.REGISTRATION);
		for(RegistrationBean registration : registrations) {
			writer.writeStartElement(registryNs, "RegistrationRequest");
			writer.writeAttribute("action", beans.getAction().getAction());
			writerEngine.writeMaintainable(registration, null, writer);
			writer.writeEndElement();
		}
		writer.writeEndElement(); //End RegistrationRequest
		writer.writeEndElement(); //End SubmitRegistrationsRequest
	}

	@Override
	protected void afterHeader(StaxWriter writer, DATASET_ACTION action) {
		writer.writeStartElement(messageNs, "SubmitStructureRequest");

		// JIRA FR-299: If there is an action which is NOT the default action of APPEND, now is the time to write it.
		if (action != DATASET_ACTION.APPEND) {
			writer.writeAttribute("action", action.getAction());
		}
		// END JIRA FR-299
	}
}

