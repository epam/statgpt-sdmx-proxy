package io.sdmx.format.ml.factory.schema;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.factory.ISchemaWriterFactory;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.format.ml.engine.schema.StructureSpecificSchemaWriterEngineV1;
import io.sdmx.format.ml.engine.schema.StructureSpecificSchemaWriterEngineV2;
import io.sdmx.format.ml.engine.schema.StructureSpecificSchemaWriterEngineV21;
import io.sdmx.format.ml.engine.schema.StructureSpecificSchemaWriterEngineV3;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;
import io.sdmx.utils.core.application.FusionBeanStore;

public class SdmxXSDSchemaWriterFactory implements ISchemaWriterFactory, IFusionSingleton {
	private static SdmxXSDSchemaWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxXSDSchemaWriterFactory() {}

	public static SdmxXSDSchemaWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxXSDSchemaWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxXSDSchemaWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	
	
	@Override
	public SchemaWriterEngine getSchemaWriterEngine(SchemaFormat format) {
		if(format instanceof SDMX_XSDSchemaFormat) {
			SDMX_VERSION version = ((SDMX_XSDSchemaFormat)format).getVersion();
			switch(version) {
			case V1_0:
				return StructureSpecificSchemaWriterEngineV1.getInstance();
			case V2_0:
				return StructureSpecificSchemaWriterEngineV2.getInstance();
			case V2_1:
				return StructureSpecificSchemaWriterEngineV21.getInstance();
			case V3_0:
				return StructureSpecificSchemaWriterEngineV3.getInstance();
			}
		}
		return null;
	}
}
