package io.sdmx.format.ml.engine.structure.writer.v3.hcl;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchyAssociationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxHierarchyAssociationWriterEngineV3 extends AbstractV3Writer<HierarchyAssociationBean> implements IFusionSingleton {
	private static StaxHierarchyAssociationWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHierarchyAssociationWriterEngineV3() {}

	public static StaxHierarchyAssociationWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHierarchyAssociationWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "HierarchyAssociation";
	}

	
	@Override
	protected void writeMaintainableInternal(HierarchyAssociationBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getHierarchyRef(), writer, "LinkedHierarchy");
		StaxRefUtilV3.writeReference(maint.getLinkedStructureRef(), writer, "LinkedObject");
		if(maint.getContextStructureRef() != null) {
			StaxRefUtilV3.writeReference(maint.getContextStructureRef(), writer, "ContextObject");
		}
	}

	
}
