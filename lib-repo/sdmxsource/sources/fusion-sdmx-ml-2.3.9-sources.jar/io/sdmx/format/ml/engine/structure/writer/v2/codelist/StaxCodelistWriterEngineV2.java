package io.sdmx.format.ml.engine.structure.writer.v2.codelist;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxStructureWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;


public class StaxCodelistWriterEngineV2 extends AbstractV2Writer<CodelistBean> implements IFusionSingleton {
	private static StaxCodelistWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistWriterEngineV2() {}

	public static StaxCodelistWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CodeList";
	}

	@Override
	protected void writeMaintainableInternal(CodelistBean maint, StaxWriter writer) {
		writeCodes(maint.getItems(), writer);
	}

	private void writeCodes(List<CodeBean> codes, StaxWriter writer) {
		for(CodeBean code : codes) {
		    Map<String, String> attributes = new HashMap<>();
		    if(code.getParentCode() != null) {
                attributes.put("parentCode", code.getParentCode());
            }
		    attributes.put("value", code.getId());
		    attributes.put("urn", code.getUrn());

		    writer.writeElement(StaxStructureWriterUtilV2.STRUCTURE_NS, "Code", attributes);
		    StaxTextWriterUtilV2.writeTextTypes(code.getNames(), writer, "Description");

		    StaxAnnotableWriterUtilV2.writeAnnotations(code.getAnnotations(), writer);
		    writer.writeEndElement(); // End code
		}
	}
}
