package io.sdmx.format.ml.engine.structure.writer.v21;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxStructureWriterEngineV21 extends StaxAbstractStructureWriterEngineV21 implements IFusionSingleton {
	private static StaxStructureWriterEngineV21 INSTANCE;
	private static StaxStructureWriterEngineV21 PRETTY_INSTANCE;

	public static StaxStructureWriterEngineV21 getInstance(boolean prettyPrint) {
		if(!prettyPrint) {
			return getInstance();
		}
		if(PRETTY_INSTANCE == null) {
			PRETTY_INSTANCE = new StaxStructureWriterEngineV21();
			PRETTY_INSTANCE.prettyPrint = true;
			FusionBeanStore.registerInstance(PRETTY_INSTANCE);
		}
		return PRETTY_INSTANCE;
	}

	public static StaxStructureWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureWriterEngineV21();
			INSTANCE.prettyPrint = false;
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
        PRETTY_INSTANCE = null;
    }


	//Private constructor - lazy load instance
	private StaxStructureWriterEngineV21() {
		super(SDMX_SCHEMA.VERSION_TWO_POINT_ONE,
				StaxStructureWriterUtil.MESSAGE_NS,
				StaxStructureWriterUtil.STRCUTURE_NS,
				StaxStructureWriterUtil.COMMON_NS,
				StaxStructureWriterUtil.REGISTRY_NS,
				SingletonStore.getSingleton(SchemaLocationManager.class, false),
				SingletonStore.getSingleton(HeaderRetrievalManager.class, false) );
	}

	@Override
	protected String getDocumentRoot() {
		return "Structure";
	}

	@Override
	protected void afterHeader(StaxWriter writer, DATASET_ACTION action) {
		//Do nothing
	}


}

