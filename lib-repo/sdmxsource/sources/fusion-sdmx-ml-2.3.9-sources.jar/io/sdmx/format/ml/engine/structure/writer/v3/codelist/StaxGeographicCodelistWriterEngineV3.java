package io.sdmx.format.ml.engine.structure.writer.v3.codelist;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeoFeatureSetCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.IGeographicCodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxGeographicCodelistWriterEngineV3 extends AbstractV3Writer<IGeographicCodelistBean> implements IFusionSingleton {
	private static StaxGeographicCodelistWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxGeographicCodelistWriterEngineV3() {}

	public static StaxGeographicCodelistWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxGeographicCodelistWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "GeographicCodelist";
	}

	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(IGeographicCodelistBean maint) {
		return CollectionUtil.buildMapValues("geoType GeographicCodelist");
	}

	@Override
	protected void writeMaintainableInternal(IGeographicCodelistBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeCodes(maint.getItems(), externalLinks, writer);
	}

	private void writeCodes(List<CodeBean> codes, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(CodeBean ucast : codes) {
			IGeoFeatureSetCodeBean code = (IGeoFeatureSetCodeBean)ucast;
			Map<String, String> attributes = CollectionUtil.buildMapValues("value "+code.getGeoFeatureSet());
			StaxNameableWriterUtilV3.writeBean(code, "GeoFeatureSetCode", externalLinks, writer, attributes);
			if(code.getParentCode() != null) {
				StaxRefUtilV3.writeLocalReference(code.getParentCode(), writer, "Parent");
			}
			writer.writeEndElement();
		}
	}
}
