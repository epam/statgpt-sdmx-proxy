package io.sdmx.format.ml.engine.structure.reader.v3.codelist;

import io.sdmx.api.sdmx.model.mutable.valuelist.ValueItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.valuelist.ValueListMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxMaintainableUtilV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.valuelist.ValueItemMutableBeanImpl;
import io.sdmx.im.mutable.valuelist.ValueListMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxValueListReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<ValueListMutableBean> {
	private static StaxValueListReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxValueListReaderEngineV3() {}

	public static StaxValueListReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxValueListReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

    @Override
    public String getContainerNodeName() {
        return "ValueLists";
    }

    @Override
    protected String getRootNodeName() {
        return "ValueList";
    }

    @Override
    protected ValueListMutableBean processMaintainable(IStaxReader reader) {
		ValueListMutableBean maint = new ValueListMutableBeanImpl();
		StaxMaintainableUtilV3.processBean(maint, reader);

		do {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("ValueItem")) {
					ValueItemMutableBean aCode = processValueItem(reader);
					maint.addItem(aCode);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("ValueList")) {
				break;
			}
		} while(reader.moveNextNode());
		
		return maint;
	}

	private ValueItemMutableBean processValueItem(IStaxReader reader) {
		ValueItemMutableBean code = new ValueItemMutableBeanImpl();
		code.setId(reader.getAttributeValue("id"));
		StaxAnnotableUtil.processBean(code, reader);

		do {
			String nodeNameEnum = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeNameEnum.equals("Name")) {
					code.addName(StaxStructureUtil.getLangLocale(reader), reader.getElementText());
				} else if(nodeNameEnum.equals("Description")) {
					code.addDescription(StaxStructureUtil.getLangLocale(reader), reader.getElementText());
				}
			} else if(nodeNameEnum.equals("ValueItem")){
				break;
			}
		} while(reader.moveNextNode());
		
		return code;
	}
}