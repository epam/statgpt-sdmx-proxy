package io.sdmx.format.ml.engine.structure.writer.v21.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataProviderSchemeWriterEngineV21 extends StaxAbstractOrganisationSchemeWriterEngine<DataProviderSchemeBean, DataProviderBean> implements IFusionSingleton {
	private static StaxDataProviderSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataProviderSchemeWriterEngineV21() {}

	public static StaxDataProviderSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataProviderSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "DataProviderScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "DataProvider";
	}


}
