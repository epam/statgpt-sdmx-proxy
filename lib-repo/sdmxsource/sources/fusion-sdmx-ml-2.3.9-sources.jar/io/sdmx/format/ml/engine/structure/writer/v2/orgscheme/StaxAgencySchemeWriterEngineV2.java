package io.sdmx.format.ml.engine.structure.writer.v2.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AgencySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxAgencySchemeWriterEngineV2 extends StaxAbstractOrganisationSchemeWriterEngineV2<AgencySchemeBean, AgencyBean> implements IFusionSingleton {
	private static StaxAgencySchemeWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxAgencySchemeWriterEngineV2() {}

	public static StaxAgencySchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxAgencySchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "OrganisationScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "Agency";
	}

    @Override
    protected String getGroupNodeName() {
        return "Agencies";
    }
}
