package io.sdmx.format.ml.factory.registration;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.error.ISdmxError;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.registration.IRegistrationReaderFactory;
import io.sdmx.format.ml.engine.error.ErrorReaderEngineV21;
import io.sdmx.format.ml.engine.structure.reader.v20.registration.StaxRegistrationReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v21.registration.StaxRegistrationReaderEngineV21;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

/**
 * Reads SDMX-ML Registration messags
 *
 */
public class SdmxMLRegistrationReaderFactory implements IRegistrationReaderFactory, IFusionSingleton {
	private static SdmxMLRegistrationReaderFactory INSTANCE;
	
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMLRegistrationReaderFactory.class);

	public static SdmxMLRegistrationReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLRegistrationReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxMLRegistrationReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}
	
	private SdmxMLRegistrationReaderFactory() {}

	@Override
	public List<RegistrationInformation> readRegistrations(ReadableDataLocation rdl) {
		if(rdl.getFormat() == FILE_FORMAT.XML) {
			SDMX_SCHEMA schemaVersion = SdmxMessageUtil.getSchemaVersion(rdl);
			MESSAGE_TYPE messageType = SdmxMessageUtil.getMessageType(rdl);
			if(messageType != MESSAGE_TYPE.ERROR && messageType != MESSAGE_TYPE.REGISTRY_INTERFACE) {
				throw new RuntimeException("Unexpected Document found, expecting RegistryInterfaceDocument containing Registrations, received " +messageType.getNodeName());
			}
			if(messageType == MESSAGE_TYPE.ERROR) {
				ISdmxError error = ErrorReaderEngineV21.INSTANCE.readError(rdl);
				if(error.getSdmxErrorCode() == SDMX_ERROR_CODE.NO_RESULTS_FOUND) {  //mo results found
					return new ArrayList<>();
				}
				throw new SdmxException(error.getErrorMessage().get(0), error.getSdmxErrorCode());
			}
			StaxReader reader = new StaxReader(rdl);
			switch(schemaVersion) {
			case VERSION_TWO :
				return StaxRegistrationReaderEngineV2.getInstance().readRegistrations(reader);
			case VERSION_TWO_POINT_ONE :
				return StaxRegistrationReaderEngineV21.getInstance().readRegistrations(reader);
			default : throw new IllegalArgumentException("Schema version unsupported: " + schemaVersion.toString());
			}
		}
		return null;
	}
}