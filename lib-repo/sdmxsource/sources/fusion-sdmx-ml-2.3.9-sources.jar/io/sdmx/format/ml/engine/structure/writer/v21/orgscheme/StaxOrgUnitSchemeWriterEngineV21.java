package io.sdmx.format.ml.engine.structure.writer.v21.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxContactWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxOrgUnitSchemeWriterEngineV21 extends AbstractV21Writer<OrganisationUnitSchemeBean> implements IFusionSingleton {
	private static StaxOrgUnitSchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxOrgUnitSchemeWriterEngineV21() {}

	public static StaxOrgUnitSchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxOrgUnitSchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "OrganisationUnitScheme";
	}

	@Override
	protected void writeMaintainableInternal(OrganisationUnitSchemeBean maint,StaxWriter writer) {
		for(OrganisationUnitBean org : maint.getItems()) {
			StaxNameableWriterUtil.writeBean(org, "OrganisationUnit", writer);
			StaxRefUtil.writeLocalReference(org.getParentUnit(), writer, "Parent");
			StaxContactWriterUtil.writeContact(org.getContacts(), writer);
			writer.writeEndElement(); //End Org
		}
	}

}
