package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMaintainableWriterUtil {

	public static void writeBean(MaintainableBean maint, String elementName, StaxWriter writer) {
		writeBean(maint, elementName, writer, null);
	}

	public static void writeBean(MaintainableBean maint, String elementName, StaxWriter writer, Map<String, String> attributes) {
		if(attributes != null) {
			attributes.putAll(StaxIdentifiableWriterUtil.getAttributes(maint));
		} else {
			attributes = StaxIdentifiableWriterUtil.getAttributes(maint);
		}
		if(maint instanceof ItemSchemeBean) {
			ItemSchemeBean itemScheme = (ItemSchemeBean)maint;
			if(itemScheme.isPartial()) {
				attributes.put("isPartial", Boolean.toString(itemScheme.isPartial()));
			}
		}
		attributes.put("version", maint.getVersion().toString());
		attributes.put("agencyID", maint.getAgencyId());

		// Always write the values of isFinal and isExternalReference
		attributes.put("isFinal", Boolean.toString(maint.isFinal()));
		attributes.put("isExternalReference", Boolean.toString(maint.isExternalReference()));

		if(maint.hasValidityPeriod()) {
			if(maint.getValidityPeriod().hasStartPeriod()) {
				attributes.put("validFrom", maint.getValidityPeriod().getStartPeriod().getDateInSdmxFormat());
			}
			if(maint.getValidityPeriod().hasEndPeriod()) {
				attributes.put("validTo", maint.getValidityPeriod().getEndPeriod().getDateInSdmxFormat());
			}
		}
		if(maint.getStructureURL() != null) {
			attributes.put("structureURL", maint.getStructureURL().toString());
		}
		if(maint.getServiceURL() != null) {
			attributes.put("serviceURL", maint.getServiceURL().toString());
		}
		writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName, attributes);
		StaxNameableWriterUtil.writeBean(maint, writer);
	}

}
