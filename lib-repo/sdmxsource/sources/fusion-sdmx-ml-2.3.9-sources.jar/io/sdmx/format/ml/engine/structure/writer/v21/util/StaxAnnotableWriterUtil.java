package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxAnnotableWriterUtil {

	public static void writeBean(AnnotableBean annotableBean, StaxWriter writer) {
		writeAnnotations(annotableBean.getAnnotations(), writer);
	}
	
	public static void writeAnnotations(List<AnnotationBean>  annotations, StaxWriter writer) {
		if(ObjectUtil.validCollection(annotations)) {
			writer.writeStartElement(StaxStructureWriterUtil.COMMON_NS, "Annotations");
			for(AnnotationBean annotation : annotations) {
				writeAnnotation(annotation, writer);
			}
			writer.writeEndElement();
		}
	}
	
	private static void writeAnnotation(AnnotationBean annotationBean, StaxWriter writer) {
		writer.writeStartElement(StaxStructureWriterUtil.COMMON_NS, "Annotation");
		writer.writeAttribute("id", annotationBean.getId());
		writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "AnnotationTitle", annotationBean.getTitle());
		writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "AnnotationType", annotationBean.getType());
		if(annotationBean.getUri() != null) {
			writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "AnnotationURL", annotationBean.getUri().toString());
		}
		StaxTextWriterUtil.writeTextTypes(annotationBean.getText(), writer, "AnnotationText");
		writer.writeEndElement();
	}
}
