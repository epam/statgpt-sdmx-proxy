package io.sdmx.format.ml.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.core.sdmx.api.factory.registration.IRegistrationReaderFactory;
import io.sdmx.format.ml.api.manager.RegistrationParsingManager;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.file.ZipUtil;

public class RegistrationParsingManagerImpl implements RegistrationParsingManager {

	private Set<IRegistrationReaderFactory> factories = null;

	@Override
	public List<RegistrationInformation> parseRegistrations(ReadableDataLocation dataLocation) {
		try {
			if (ZipUtil.isAZip(dataLocation)) {
				List<RegistrationInformation> returnList = new ArrayList<>();
				List<ReadableDataLocation> items = ZipUtil.unzipFiles(dataLocation);
				for(ReadableDataLocation currentRdl : items) {
					try {
						returnList.addAll(readRegistrationsFromFactories(currentRdl));
					} finally {
						currentRdl.close();
					}
					
				}
			}
			return readRegistrationsFromFactories(dataLocation);
		} finally {
			dataLocation.close();
		}
	}

	private List<RegistrationInformation> readRegistrationsFromFactories(ReadableDataLocation sourceData) {
		for(IRegistrationReaderFactory currentFactory : getReaderFactories()) {
			List<RegistrationInformation> registrations = currentFactory.readRegistrations(sourceData);
			if(registrations != null) {
				return registrations;
			}
		}
		throw new UnrecognisedFormatException(sourceData.getInputStream());
	}

	private Collection<IRegistrationReaderFactory> getReaderFactories()  {
		if(factories != null) {
			return factories;
		}
		factories = new HashSet<>();
		synchronized(this) {
			Collection<IRegistrationReaderFactory> allBeans = FusionBeanStore.getBeans(IRegistrationReaderFactory.class);
			if(allBeans != null) {
				for (IRegistrationReaderFactory structureReaderFactory : allBeans) {
					factories.add(structureReaderFactory);
				}
			}
		}
		return factories;
	}
}
