package io.sdmx.format.ml.engine.structure.reader.v3.catscheme;

import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategoryMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorySchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.categoryscheme.CategoryMutableBeanImpl;
import io.sdmx.im.mutable.categoryscheme.CategorySchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCategorySchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<CategorySchemeMutableBean> {
	private static StaxCategorySchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorySchemeReaderEngineV3() {}

	public static StaxCategorySchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorySchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
    @Override
    public String getContainerNodeName() {
        return "CategorySchemes";
    }

    @Override
    protected String getRootNodeName() {
        return "CategoryScheme";
    }
    
    @Override
    protected CategorySchemeMutableBean processMaintainable(IStaxReader reader) {
		CategorySchemeMutableBean catSch = new CategorySchemeMutableBeanImpl();
		StaxItemSchemeUtil.processBean(catSch, reader);
		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("Category")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			catSch.addItem(processCategory(reader));
			//After processing the category move to the next element which is either ending this
			//category, or starting a new one
			reader.moveNextNode();
		}
		return catSch;
	}

	private CategoryMutableBean processCategory(IStaxReader reader) {
		CategoryMutableBean cat = new CategoryMutableBeanImpl();
		StaxNameableUtil.processBean(cat, reader);


		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("Category")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			cat.addItem(processCategory(reader));
			//After processing the category move to the next element which is either ending this
			//category, or starting a new one
			reader.moveNextNode();
		}
		//Leave on an end element
		return cat;
	}
}
