package io.sdmx.format.ml.engine.structure.reader.v20;

import java.util.Map;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxStructureReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.catscheme.StaxCategorySchemeReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.codelist.StaxCodelistReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.conceptscheme.StaxConceptSchemeReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.dataflow.StaxDataflowReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.dsd.StaxDsdReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.hcl.StaxHclReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.metadataflow.StaxMetadataflowReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.orgscheme.StaxOrganisationSchemeReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.registration.StaxRegistrationReaderEngineV2;
import io.sdmx.format.ml.engine.structure.reader.v20.structureset.StaxStructureSetReaderEngineV2;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxStructureReaderEngineV2 extends AbstractStaxStructureReaderEngine implements IFusionSingleton {
	private static StaxStructureReaderEngineV2 INSTANCE;

	public static StaxStructureReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
	    INSTANCE = null;
	}

	private StaxStructureReaderEngineV2() {
		super("Structure");
		registerReader(StaxOrganisationSchemeReaderEngineV2.getInstance());
		registerReader(StaxCategorySchemeReaderEngineV2.getInstance());
		registerReader(StaxCodelistReaderEngineV2.getInstance());
		registerReader(StaxConceptSchemeReaderEngineV2.getInstance());
		registerReader(StaxDataflowReaderEngineV2.getInstance());
		registerReader(StaxMetadataflowReaderEngineV2.getInstance());
		registerReader(StaxDsdReaderEngineV2.getInstance());
		registerReader(StaxHclReaderEngineV2.getInstance());
		registerReader(StaxRegistrationReaderEngineV2.getInstance());
		registerReader(StaxStructureSetReaderEngineV2.getInstance());
	}
	
	@Override
    protected void processBody(IStaxReader staxReader, SdmxBeans sdmxBeans, IBeansBuilder builder) {
        while(staxReader.moveNextStartNode()) {
            if(staxReader.getElementName().equals("SubmitStructureRequest")) {
                Map<String, String> attrs = staxReader.getAttributes();
                if(attrs.containsKey("action")) {
                    sdmxBeans.setAction(DATASET_ACTION.getAction(attrs.get("action")));
                }
            }
            processNode(staxReader, sdmxBeans, builder);
        }
    }

	@Override
	protected SDMX_SCHEMA getOutputVersion() {
		return SDMX_SCHEMA.VERSION_TWO;
	}

	@Override
	protected HeaderBean processHeader(IStaxReader reader) {
		return StaxHeaderReaderEngineV2.readerHeader(reader);
	}

}
