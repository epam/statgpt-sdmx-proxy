package io.sdmx.format.ml.engine.structure.reader.v3.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationUnitSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.OrganisationUnitMutableBeanImpl;
import io.sdmx.im.mutable.base.OrganisationUnitSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxOrgUnitSchemeReaderEngineV3 extends StaxAbstractOrgansiationReaderV3<OrganisationUnitSchemeMutableBean> {
	private static StaxOrgUnitSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxOrgUnitSchemeReaderEngineV3() {}

	public static StaxOrgUnitSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxOrgUnitSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	@Override
	public String getContainerNodeName() {
        return "OrganisationUnitSchemes";
    }
    
    @Override
    protected String getRootNodeName() {
        return "OrganisationUnitScheme";
    }
    
	@Override
    protected OrganisationUnitSchemeMutableBean processMaintainable(IStaxReader reader) {
	    OrganisationUnitSchemeMutableBean maint = new OrganisationUnitSchemeMutableBeanImpl();
        StaxItemSchemeUtil.processBean(maint, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("OrganisationUnit")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processOrgUnit(maint, reader);
            reader.moveNextNode();
        }
        return maint;
    }

	private void processOrgUnit(OrganisationUnitSchemeMutableBean beanToPopulate, IStaxReader reader) {
		OrganisationUnitMutableBean org = new OrganisationUnitMutableBeanImpl();
		beanToPopulate.addItem(org);
		super.processOrganisation(org, reader);
	}

	@Override
    protected void processStartElement(OrganisationMutableBean org, IStaxReader reader) {
		if(reader.getElementName().equals("Parent")) {
			((OrganisationUnitMutableBean)org).setParentUnit(StaxStructureRefReaderV3.getLocalReference(reader));

			reader.moveNextNode();
			if(reader.isStartElement()) {
				super.processStartElement(org, reader);
			}
		} else {
			super.processStartElement(org, reader);
		}
	}
}
