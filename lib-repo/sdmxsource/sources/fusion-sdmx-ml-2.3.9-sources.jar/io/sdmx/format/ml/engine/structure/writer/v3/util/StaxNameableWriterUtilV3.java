package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.NameableBean;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxNameableWriterUtilV3 {

	public static void writeBean(NameableBean nameable, String elementName, IExternalMaintainableLinks externalLinks,  StaxWriter writer) {
		writeBean(nameable, elementName, externalLinks, writer, null);
	}
	
	public static void writeBean(NameableBean nameable, String elementName, IExternalMaintainableLinks externalLinks,  StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = StaxIdentifiableWriterUtilV3.getAttributes(nameable);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName, attributes);
		writeBean(nameable, externalLinks, writer);
	}
	
	public static void writeBean(NameableBean nameable, IExternalMaintainableLinks externalLinks,  StaxWriter writer) {
		StaxAnnotableWriterUtilV3.writeBean(nameable, writer);
		StaxIdentifiableWriterUtilV3.writeLinks(nameable, externalLinks, writer);
		StaxTextWriterUtilV3.writeTextTypes(nameable.getNames(), writer, "Name");
		StaxTextWriterUtilV3.writeTextTypes(nameable.getDescriptions(), writer, "Description");
	}
	
}
