package io.sdmx.format.ml.engine.structure.reader.v21.structureset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxTextFormatUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.mapping.CategorySchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodelistMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ComponentMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ConceptSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ItemMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.OrganisationSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.RepresentationMapRefMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class StaxStructureSetReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<StructureSetMutableBean> {
	private static StaxStructureSetReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxStructureSetReaderEngineV21() {}

	public static StaxStructureSetReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureSetReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "StructureSets";
    }

    @Override
    protected String getRootNodeName() {
        return "StructureSet";
    }
    
	@Override
    protected StructureSetMutableBean processMaintainable(IStaxReader reader) {
		StructureSetMutableBean ss = new StructureSetMutableBeanImpl();
		StaxMaintainableUtil.processBean(ss, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("RelatedStructure")) {
				ss.addRelatedStructure(StaxStructureUtil.getStructureReference(reader, null));
			} else if(elementName.equals("OrganisationSchemeMap")) {
				ss.addOrganisationSchemeMap(processOrganisationScheme(reader));
			}  else if(elementName.equals("CategorySchemeMap")) {
				ss.addCategorySchemeMap(processCategoryScheme(reader));
			}  else if(elementName.equals("CodelistMap")) {
				ss.addCodelistMap(processCodelistMap(reader));
			}  else if(elementName.equals("ConceptSchemeMap")) {
				ss.addConceptSchemeMap(processConceptSchemeMap(reader));
			}  else if(elementName.equals("ReportingTaxonomyMap")) {
				throw new SdmxNotImplementedException("Can not process XML '"+reader.getXMLPath()+"' ReportingTaxonomyMap is not supported");
			} else if(elementName.equals("HybridCodelistMap")) {
				throw new SdmxNotImplementedException("Can not process XML '"+reader.getXMLPath()+"' HybridCodelistMap is not supported");
			} else if(elementName.equals("StructureMap")) {
				ss.addStructureMap(processStructureMap(reader, ss));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return ss;
	}

	private OrganisationSchemeMapMutableBean processOrganisationScheme(IStaxReader reader) {
		OrganisationSchemeMapMutableBean orgMap = new OrganisationSchemeMapMutableBeanImpl();
		processMapScheme(orgMap, reader, null);
		processMapItemScheme(orgMap, reader);
		return orgMap;
	}

	private CodelistMapMutableBean processCodelistMap(IStaxReader reader) {
		CodelistMapMutableBean codelistMap = new CodelistMapMutableBeanImpl();
		processMapScheme(codelistMap, reader, SDMX_STRUCTURE_TYPE.CODE_LIST);
		processMapItemScheme(codelistMap, reader);
		return codelistMap;
	}

	private CategorySchemeMapMutableBean processCategoryScheme(IStaxReader reader) {
		CategorySchemeMapMutableBean csMap = new CategorySchemeMapMutableBeanImpl();
		processMapScheme(csMap, reader, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME);
		processMapItemScheme(csMap, reader);
		return csMap;
	}


	private ConceptSchemeMapMutableBean processConceptSchemeMap(IStaxReader reader) {
		ConceptSchemeMapMutableBean conceptSchemeMap = new ConceptSchemeMapMutableBeanImpl();
		processMapScheme(conceptSchemeMap, reader, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
		processMapItemScheme(conceptSchemeMap, reader);
		return conceptSchemeMap;
	}

	private StructureMapMutableBean processStructureMap(IStaxReader reader, StructureSetMutableBean ss) {
		StructureMapMutableBean structureMap = new StructureMapMutableBeanImpl();
		processMapScheme(structureMap, reader, null);

		while(reader.isStartElement()) {
			while(reader.isStartElement()) {
				StaxAnnotableUtil.processBean(structureMap, reader);

				ComponentMapMutableBean compMap = new ComponentMapMutableBeanImpl();
				StaxStructureUtil.checkStartNode(reader, "Source");
				compMap.addMapConceptRef(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();

				StaxStructureUtil.checkStartNode(reader, "Target");
				compMap.addMapTargetConceptRef(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();

				List<AnnotationMutableBean> annotations =  structureMap.getAnnotations();
				if(annotations != null) {
					List<AnnotationMutableBean> newAnnotations = new ArrayList<>();
					for(AnnotationMutableBean annotationMutableBean : annotations) {
						if("SOURCE".equals(annotationMutableBean.getTitle())) {
							compMap.addMapConceptRef(annotationMutableBean.getId());
						} else if("TARGET".equals(annotationMutableBean.getTitle())) {
							compMap.addMapTargetConceptRef(annotationMutableBean.getId());
						} else {
							newAnnotations.add(annotationMutableBean);
						}
						structureMap.setAnnotations(newAnnotations);
					}
				}

				if(reader.isStartElement() && reader.getElementName().equals("RepresentationMapping")) {
					compMap.setRepMapRef(processRepresentationMapRef(reader, ss));
					reader.moveNextNode();
				}
				structureMap.addComponent(compMap);
			}
			reader.moveNextNode();
		}

		return structureMap;
	}

	private RepresentationMapRefMutableBean processRepresentationMapRef(IStaxReader reader, StructureSetMutableBean ss) {
		RepresentationMapRefMutableBean repMap = new RepresentationMapRefMutableBeanImpl();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("CodelistMap")) {
					repMap.setCodelistMapRef(StaxStructureUtil.getLocalReference(reader));
				} else if(nodeName.equals("ToTextFormat")) {
					repMap.setToTextFormat(StaxTextFormatUtil.processBean(reader));
				} else if(nodeName.equals("ToValueType")) {
					String toValue = reader.getElementText();
					if(toValue.equals("Name")) {
						repMap.setToValueType(TO_VALUE.NAME);
					} else if(toValue.equals("Description")) {
						repMap.setToValueType(TO_VALUE.DESCRIPTION);
					} else if(toValue.equals("Value")) {
						repMap.setToValueType(TO_VALUE.VALUE);
					} else {
						throw new SdmxSemmanticException("Unexpected ToValueType of '"+toValue+"'.  Expecting 'Name', 'Description', or 'Value'");
					}
				} else if(nodeName.equals("ValueMap")) {
					repMap.setValueMappings(processValueMap(reader));
				}
			} else if(nodeName.equals("RepresentationMapping")) {
				break;
			}
		}
		return repMap;
	}

	private Map<String, Set<String>> processValueMap(IStaxReader reader) {
		Map<String, Set<String>> returnMap = new LinkedHashMap<>();

		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("ValueMapping")) {
					String source = StaxStructureUtil.getAttribute(reader.getAttributes(), "source", false);
					String target = StaxStructureUtil.getAttribute(reader.getAttributes(), "target", false);
					if(!ObjectUtil.validOneString(source, target)) {
						throw new SdmxSemmanticException("Value Mapping has an empty source value mapped to an empty target value, this is not allowed");
					}
					if(source == null) {
						source = "";
					}
					if(target == null) {
						target = "";
					}
					Set<String> targetSet = returnMap.get(source);
					if(targetSet == null) {
						targetSet = new HashSet<>();
						returnMap.put(source, targetSet);
					}
					targetSet.add(target);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("ValueMap")) {
				break;
			}
		}
		return returnMap;
	}


	private void processMapScheme(SchemeMapMutableBean map, IStaxReader reader, SDMX_STRUCTURE_TYPE targetStructure) {
		StaxNameableUtil.processBean(map, reader);
		StaxStructureUtil.checkStartNode(reader, "Source");
		map.setSourceRef(StaxStructureUtil.getStructureReference(reader, targetStructure));
		reader.moveNextNode();

		StaxStructureUtil.checkStartNode(reader, "Target");
		map.setTargetRef(StaxStructureUtil.getStructureReference(reader, targetStructure));

		reader.moveNextNode();

	}

	private void processMapItemScheme(ItemSchemeMapMutableBean map, IStaxReader reader) {
		while(reader.isStartElement()) {
			while(reader.isStartElement()) {
				ItemMapMutableBean itemMap = new ItemMapMutableBeanImpl();
				if(map instanceof CodelistMapMutableBean){
					itemMap = new CodeMapMutableBeanImpl();
				}
				StaxAnnotableUtil.processBean(itemMap, reader);

				StaxStructureUtil.checkStartNode(reader, "Source");
				itemMap.setSourceId(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();

				StaxStructureUtil.checkStartNode(reader, "Target");
				itemMap.setTargetId(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();
				if(itemMap instanceof CodeMapMutableBeanImpl){
					ValidityPeriodUtil.processValidityAnnotations((CodeMapMutableBeanImpl)itemMap);
				}

				map.addItem(itemMap);
			}
			reader.moveNextNode();
		}

	}
}
