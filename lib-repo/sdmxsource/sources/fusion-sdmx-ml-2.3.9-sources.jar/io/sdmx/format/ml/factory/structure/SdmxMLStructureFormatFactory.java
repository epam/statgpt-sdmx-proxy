package io.sdmx.format.ml.factory.structure;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.structure.StructureFormatFactory;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;

public class SdmxMLStructureFormatFactory implements StructureFormatFactory, IFusionSingleton {
	private Map<String, FormatDetails> supportedFormats = new HashMap<>();
	
	private static SdmxMLStructureFormatFactory INSTANCE;

	public SdmxMLStructureFormatFactory() {
		addSupportedFormat(new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V1_STRUCTURE_DOCUMENT));
		addSupportedFormat(new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V2_STRUCTURE_DOCUMENT));
		addSupportedFormat(new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT));
		supportedFormats = Collections.unmodifiableMap(supportedFormats);
	}
	

	private void addSupportedFormat(SdmxStructureFormat sf) {
		String[] acceptHeaders = sf.getFormatDetails().getAcceptHeaders();
		for(String acceptHeader : acceptHeaders) {
			supportedFormats.put(acceptHeader, sf.getFormatDetails());
		}
	}

	public static SdmxMLStructureFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	public static SdmxMLStructureFormatFactory getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SdmxMLStructureFormatFactory();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public Class<StructureFormat> getFormatClass() {
		return StructureFormat.class;
	}

	@Override
	public StructureFormat getFormat(Request request, IVNDHeader vndHeader) {
		String applicationVnd = vndHeader.getVnd();

		String responseVersion = vndHeader.getParameterValue("version");
		if (!applicationVnd.equals("sdmx.structure+xml")) {
            return null;
        }

		/*
		 * Section 4.6 of the SDMX Web Services Guidelines
		 *
		 * 432 application/vnd.sdmx.[format]+xml;version=[version], where [format] should be replaced with
			   433 the desired format (i.e. : genericdata, structurespecificdata, structure, etc) and [version]
			   434 should be replaced with one of the versions of the SDMX standard, starting with SDMX 2.1
			   435 (e.g.: 2.1, future SDMX versions, etc).
			   436 A few examples are listed below
			   437 SDMX-ML Generic Data Format, version 2.1:  application/vnd.sdmx.genericdata+xml;version=2.1
			   439 SDMX-ML Structure Specific Data Format, version 2.1: application/vnd.sdmx.structurespecificdata+xml;version=2.1
			   441 SDMX-ML Structure Format, version 2.1: application/vnd.sdmx.structure+xml;version=2.1
		 */
		if(responseVersion == null) {
		    responseVersion = "2.1";
		}
		String prettyParameter = vndHeader.getParameterValue("prettyPrint");
		boolean prettyPrint = false;
		if(ObjectUtil.validString(prettyParameter) ) {
		    prettyPrint = Boolean.parseBoolean(prettyParameter);
		}
		return parseExtraInfo(responseVersion, prettyPrint);
	}

	@Override
	public StructureFormat getFormat(String format, Request request) {
		if(format != null) {
			if(format.startsWith("sdmx")) {
				String prettyParameter = request.getParameter("prettyPrint");
				boolean prettyPrint = false;
				if(ObjectUtil.validString(prettyParameter) ) {
					prettyPrint = Boolean.parseBoolean(prettyParameter);
				}
				String split[] = format.split("-");
				if(split.length > 1) {
					String version = split[1];
					return parseExtraInfo(version, prettyPrint);
				}
				return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT, false, prettyPrint);
			}
		}
		return null;
	}

	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return supportedFormats;
	}

	private SdmxStructureFormat parseExtraInfo(String version, boolean prettyprint) {
		if(version.equals("1.0")) {
			return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V1_STRUCTURE_DOCUMENT, false, prettyprint);
		} else if(version.equals("2.0")) {
			return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V2_STRUCTURE_DOCUMENT, false, prettyprint);
		} else if(version.equals("2.1")) {
			return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT, false, prettyprint);
		}  else if(version.equals("3.0") || version.equals("3.0.0")) {
			return new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V3_STRUCTURE_DOCUMENT, false, prettyprint);
		}
		return null;
	}
}
