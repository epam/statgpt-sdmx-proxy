package io.sdmx.format.ml.engine.structure.writer.v2.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRefUtilV2 {
	private static final String DELIMITER = "~";

	/*
	public static void writeLocalReference(String id, StaxWriter writer, String elementName) {
		if(!ObjectUtil.validString(id)) {
			return;
		}
		writer.writeStartElement(StaxStructureWriterUtilV2.STRUCTURE_NS, elementName);
		writer.writeStartElement(null, "Ref");  //No namespace
		writer.writeAttribute("id", id);
		writer.writeEndElement(); //End Ref
		writer.writeEndElement(); //End Start Element
	}
	*/

	public static void writeReference(ICrossReferenceBean<?> crossReference, StaxWriter writer) {
		writeReference(crossReference, writer, null);
	}

	public static void writeReferences(List<ICrossReferenceBean<?>> refs, StaxWriter writer, String elementName) {
		for(ICrossReferenceBean<?> ref : refs) {
			writeReference(ref, writer, elementName);
		}
	}

	public static void writeReference(ICrossReferenceBean<?> crossReference, StaxWriter writer, String elementName) {
		if(crossReference == null) {
			return;
		}
		if(elementName != null) {
			writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName);
		}

		Map<String, String> attributes = new HashMap<>();

		IMaintainableRef maintRef = crossReference.getReference();
		if(!crossReference.getReference().getStructureType().isMaintainable()) {
			String fullId = crossReference.getReference().getFullIdentifiableId();
			if(fullId.contains(DELIMITER)) {
				String containerId = fullId.substring(0, fullId.lastIndexOf(DELIMITER));
				String targetId = fullId.substring(fullId.indexOf(DELIMITER)+1, fullId.length());
				attributes.put("maintainableParentID", containerId);  //TODO What is this?
				attributes.put("id", targetId);
			} else {
				attributes.put("id", fullId);
			}
			if(ObjectUtil.validString(maintRef.getMaintainableId())) {
				attributes.put("maintainableParentID", maintRef.getMaintainableId());
			}
			if(!maintRef.getVersion().isAll()) {
				attributes.put("maintainableParentVersion", maintRef.getVersion().toString());
			}
		} else {
		    writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "URN");
	        writer.writeElementText(crossReference.getTargetUrn());
	        writer.writeEndElement();

			if(ObjectUtil.validString(maintRef.getMaintainableId())) {
			    writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "KeyFamilyID");
			    writer.writeElementText(maintRef.getMaintainableId());
				writer.writeEndElement();
			}
			if(ObjectUtil.validString(maintRef.getAgencyId())) {
	            writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "KeyFamilyAgencyID");
	            writer.writeElementText(maintRef.getAgencyId());
	            writer.writeEndElement();
	        }
			if(!maintRef.getVersion().isAll()) {
			    writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, "Version");
                writer.writeElementText(maintRef.getVersion().toString());
                writer.writeEndElement();
			}
		}


//		attributes.put("package", crossReference.getTargetReference().getUrnPackage());
//		attributes.put("class", crossReference.getTargetReference().getUrnClass());
//		writer.writeElement(null, "Ref", attributes);  //No namespace
//		writer.writeEndElement(); //End Ref
		if(elementName != null) {
			writer.writeEndElement(); //End Start Element
		}
	}

}
