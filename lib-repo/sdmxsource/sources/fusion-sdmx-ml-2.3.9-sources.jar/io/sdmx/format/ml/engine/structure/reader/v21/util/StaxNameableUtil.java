package io.sdmx.format.ml.engine.structure.reader.v21.util;

import io.sdmx.api.xml.IStaxReader;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.mutable.base.NameableMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.beans.base.LinkBean;
import io.sdmx.utils.sdmx.xs.URN;

public class StaxNameableUtil {

	/**
	 * Process bean either leave at the start of an unknown node, or the end of the object
	 * @param bean
	 * @param reader
	 */
	public static void processBean(NameableMutableBean bean, IStaxReader reader) {
		StaxIdentifiableUtil.processBean(bean, reader);
		while(processNode(bean, reader)) {
			//Processing Nodes
			reader.moveNextNode();
		}
	}
	
	public static boolean processNode(NameableMutableBean nameableMutableBean, IStaxReader staxReader) {
//		if(!staxReader.isStartElement()) {
//			//If it is an end element, we are expecting that to be end annotations, otherwise it should be
//			//the start of a name or description
//			staxReader.moveNextNode();
//		}
		if(staxReader.isStartElement()) {
			String nodeNameEnum = staxReader.getElementName();
			if(nodeNameEnum.equals("Name")) {
				nameableMutableBean.addName(StaxStructureUtil.getText(staxReader));
				return true; 
			} else if(nodeNameEnum.equals("Description")) {
				nameableMutableBean.addDescription(StaxStructureUtil.getText(staxReader));
				return true;
			} else if(nodeNameEnum.equals("Link")) {
				Map<String, String> attributes = staxReader.getAttributes();
				String rel = attributes.get("rel");
				URI href = toURI(attributes.get("url"));
				URI uri = toURI(attributes.get("uri"));
				IURN urn = attributes.containsKey("urn") ? URN.getInstance(attributes.get("urn")) : null;
				String type = attributes.get("type");
				ILinkBean link = new LinkBean(rel, href, uri, urn, type, null);
				nameableMutableBean.addLink(link);
				staxReader.skipToEndNode("Link");
				return true;
			}
			//If it is not a name or description then it is an unknown node, so we leave the method for
			//something else to process it
		}
		return false;
	}
	
	private static URI toURI(String value) {
		if(value == null) {
			return null;
		}
		try {
			return new URI(value);
		} catch (URISyntaxException e) {
			throw new SdmxSemmanticException(e, "Link contains illegal URI : "+value);
		}
	}
}
