package io.sdmx.format.ml.engine.structure.reader.v21.util;

import java.util.Map;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxMaintainableUtil  {
	
	public static void processBean(MaintainableMutableBean bean, IStaxReader reader) {
		processAttributes(bean, reader);
		StaxNameableUtil.processBean(bean, reader);
	}
	
	public static void processAttributes(MaintainableMutableBean maint, IStaxReader staxReader){
		Map<String, String> attributes = staxReader.getAttributes();
		maint.setStartDate(StaxStructureUtil.getAttributeAsDate(attributes, "validFrom", false));
		maint.setEndDate(StaxStructureUtil.getAttributeAsDate(attributes, "validTo", false));
		maint.setAgencyId(StaxStructureUtil.getAttribute(attributes, "agencyID", true));
		maint.setExternalReference(StaxStructureUtil.getAttributeAsBoolean(attributes, "isExternalReference", false, false));
		maint.setServiceURL(StaxStructureUtil.getAttribute(attributes, "serviceURL", false));
		maint.setStructureURL(StaxStructureUtil.getAttribute(attributes, "structureURL", false));
		
		maint.setFinalStructure(StaxStructureUtil.getAttributeAsBoolean(attributes, "isFinal", false, false));
		maint.setVersion(StaxStructureUtil.getAttribute(attributes, "version", false));
	}
}
