package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxAnnotableWriterUtilV3 {

	public static void writeBean(AnnotableBean annotableBean, StaxWriter writer) {
		writeAnnotations(annotableBean.getAnnotations(), writer);
	}
	
	public static void writeAnnotations(List<AnnotationBean>  annotations, StaxWriter writer) {
		if(ObjectUtil.validCollection(annotations)) {
			writer.writeStartElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "Annotations");
			for(AnnotationBean annotation : annotations) {
				writeAnnotation(annotation, writer);
			}
			writer.writeEndElement();
		}
	}
	
	private static void writeAnnotation(AnnotationBean annotationBean, StaxWriter writer) {
		writer.writeStartElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "Annotation");
		writer.writeAttribute("id", annotationBean.getId());
		writer.writeElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "AnnotationTitle", annotationBean.getTitle());
		writer.writeElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "AnnotationType", annotationBean.getType());
		if(annotationBean.getUri() != null) {
			writer.writeElement(SDMX_NAMESPACE.COMMON_3.getNamespace(), "AnnotationURL", annotationBean.getUri().toString());
		}
		StaxTextWriterUtilV3.writeTextTypes(annotationBean.getText(), writer, "AnnotationText");
		writer.writeEndElement();
	}
}
