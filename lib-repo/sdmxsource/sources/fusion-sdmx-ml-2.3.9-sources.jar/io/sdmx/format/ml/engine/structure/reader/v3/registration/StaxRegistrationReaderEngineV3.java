package io.sdmx.format.ml.engine.structure.reader.v3.registration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxRegistrationReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.im.RegistrationInformationImpl;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;

public class StaxRegistrationReaderEngineV3 implements StaxRegistrationReaderEngine {
    private static StaxRegistrationReaderEngineV3 INSTANCE;

    //Private constructor - lazy load instance
    private StaxRegistrationReaderEngineV3() {}

    public static StaxRegistrationReaderEngineV3 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxRegistrationReaderEngineV3();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "RegistrationRequest";
    }

    @Override
    public List<RegistrationInformation> readRegistrations(IStaxReader reader) {
        List<RegistrationInformation> returnList = new ArrayList<>();
        while(reader.moveNextStartNode()) {
            String nodeName = reader.getElementName();
            DATASET_ACTION action = DATASET_ACTION.INFORMATION;
            if(nodeName.equals("RegistrationRequest")) {
                String actionStr = reader.getAttributeValue(null, "Action");
                if(actionStr != null) {
                    action = DATASET_ACTION.getAction(actionStr);
                }
            } else if(nodeName.equals("Registration")) {
                returnList.add(new RegistrationInformationImpl(action, buildRegistration(reader, action)));
            }
        }

        return returnList;
    }

    private RegistrationBean buildRegistration(IStaxReader reader, DATASET_ACTION action) {
        RegistrationMutableBean regMutable = new RegistrationMutableBeanImpl();
        regMutable.setId(reader.getAttributeValue(null, "id"));
        if(regMutable.getId() == null) {
            if(action == DATASET_ACTION.DELETE || action == DATASET_ACTION.REPLACE) {
                throw new IllegalArgumentException("Registration submissions with REPLACE or DELETE actions must contain an id identifying the Registration to perform this action on");
            }
            regMutable.setId(MaintainableUtil.generateRandomId());
        }
        regMutable.setValidFrom(readDate(reader, "validFrom"));
        regMutable.setValidTo(readDate(reader, "validTo"));
        regMutable.setLastUpdated(readDate(reader, "lastUpdated"));
        regMutable.setIndexAttributes(readBool(reader, "indexAttributes"));
        regMutable.setIndexDataset(readBool(reader, "indexDataset"));
        regMutable.setIndexReportingPeriod(readBool(reader, "indexReportingPeriod"));
        regMutable.setIndexTimeSeries(readBool(reader, "indexTimeSeries"));

        while(reader.moveNextNode()) {
            String element = reader.getElementName();
            if(reader.isStartElement()) {
                if(element.startsWith("Provision")) {
                    regMutable.setProvisionAgreementRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT));
                } else if(element.equals("Datasource")) {
                    parseDatasource(reader, regMutable);
                }
            } else if(element.equals("Registration")) {
                break;
            }
        }
        return regMutable.getImmutableInstance();
    }

    private void parseDatasource(IStaxReader reader, RegistrationMutableBean regMutable) {
        DataSourceMutableBean datasource = new DataSourceMutableBeanImpl();
        regMutable.setDataSource(datasource);
        while(reader.moveNextNode()) {
            String element = reader.getElementName();
            if(reader.isStartElement()) {
                if(element.equals("SimpleDataSource")) {
                    datasource.setSimpleDatasource(true);
                    datasource.setRESTDatasource(false);
                    datasource.setDataUrl(reader.getElementText());
                } else if(element.equals("QueryableDataSource")) {
                    parseQueryableDatasource(reader, datasource);
                }
            } else if(element.equals("Datasource")) {
                break;
            }
        }
    }


    private void parseQueryableDatasource(IStaxReader reader, DataSourceMutableBean datasource) {
        datasource.setSimpleDatasource(false);
        datasource.setRESTDatasource(readBool(reader, "isRESTDatasource").isTrue());
        while(reader.moveNextNode()) {
            String element = reader.getElementName();
            if(reader.isStartElement()) {
                switch(element) {
                case "DataURL" :
                    datasource.setDataUrl(reader.getElementText());
                    break;
                case "WSDLURL" :
                    datasource.setWSDLUrl(reader.getElementText());
                    break;
                case "WADLURL" :
                    datasource.setWADLUrl(reader.getElementText());
                    break;
                }
            } else if(element.equals("QueryableDataSource")) {
                break;
            }
        }
    }

    private TERTIARY_BOOL readBool(IStaxReader reader, String attributeValue) {
        String value = reader.getAttributeValue(null, attributeValue);
        if(value != null) {
            return TERTIARY_BOOL.parseBoolean(Boolean.parseBoolean(value));
        }
        return TERTIARY_BOOL.UNSET;
    }

    private Date readDate(IStaxReader reader, String attributeValue) {
        String value = reader.getAttributeValue(null, attributeValue);
        if(value != null) {
            return SdmxDateImpl.getSdmxDate(value).getDate();
        }
        return null;
    }
}
