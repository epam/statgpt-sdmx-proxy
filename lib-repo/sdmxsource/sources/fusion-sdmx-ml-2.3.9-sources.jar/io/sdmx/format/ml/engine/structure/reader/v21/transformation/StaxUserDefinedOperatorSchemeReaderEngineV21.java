package io.sdmx.format.ml.engine.structure.reader.v21.transformation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.IUserDefinedOperatorSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorMutableBean;
import io.sdmx.im.mutable.transformation.UserDefinedOperatorSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxUserDefinedOperatorSchemeReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<IUserDefinedOperatorSchemeMutableBean> implements IFusionSingleton {
	private static StaxUserDefinedOperatorSchemeReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxUserDefinedOperatorSchemeReaderEngineV21() {}

	public static StaxUserDefinedOperatorSchemeReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxUserDefinedOperatorSchemeReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "UserDefinedOperators";
	}
	
	@Override
	protected String getRootNodeName() {
		return "UserDefinedOperatorScheme";
	}

	@Override
	protected IUserDefinedOperatorSchemeMutableBean processMaintainable(IStaxReader reader) {
		IUserDefinedOperatorSchemeMutableBean maint = new UserDefinedOperatorSchemeMutableBean();
		maint.setVtlVersion(reader.getAttributeValue(null, "vtlVersion"));
		StaxItemSchemeUtil.processBean(maint, reader);
		while(reader.isStartElement()) {
			switch(reader.getElementName()) {
			case "UserDefinedOperator" :
				IUserDefinedOperatorMutableBean item = readItem(reader);
				maint.addItem(item);
				break;
			case "VtlMappingScheme" :
				maint.setVtlMappingSchemeRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME));
				break;
			case "RulesetScheme" :
				maint.addRulesetSchemeRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME));
				break;
			default :
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return maint;
	}

	private IUserDefinedOperatorMutableBean readItem(IStaxReader reader) {
		IUserDefinedOperatorMutableBean item = new UserDefinedOperatorMutableBean();
		StaxNameableUtil.processBean(item, reader);
		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "OperatorDefinition" :
					item.setOperatorDefinition(reader.getElementText());
					break;
				}
			} else if(reader.getElementName().equals("UserDefinedOperator")) {
				break;
			}
		} while(reader.moveNextNode());
		return item;
	}
}
