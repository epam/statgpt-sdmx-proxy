package io.sdmx.format.ml.engine.structure.writer.v3.dataflow;

import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDataflowWriterEngineV3 extends AbstractV3Writer<DataflowBean> implements IFusionSingleton {
	private static StaxDataflowWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataflowWriterEngineV3() {}

	public static StaxDataflowWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataflowWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Dataflow";
	}

	@Override
	protected void writeMaintainableInternal(DataflowBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getDataStructureRef(), writer, "Structure");
	}
}
