package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.Date;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxHeaderWriterUtil {
	
	
	public static void writeHeader(StaxWriter writer, Namespace messageNs, HeaderBean header, boolean includeReceiver, boolean isRegistryInterfaceMessage) {
		writer.writeStartElement(messageNs, "Header");
		writer.writeElement(messageNs, "ID", header.getId());
		writer.writeElement(messageNs, "Test", Boolean.toString(header.isTest()));

		Date prepared = header.getPrepared() != null ? header.getPrepared() : new Date();
		// The Prepared date must be in ISO 8601 Zulu Time
		writer.writeElement(messageNs, "Prepared", DateUtil.formatDate(prepared) + "Z");
		writer.writeStartElement(messageNs, "Sender");
		writer.writeAttribute("id", header.getSender().getId());
		writer.writeEndElement();  //End Sender
		if(includeReceiver || isRegistryInterfaceMessage) {
			// Write Receiver

			if(ObjectUtil.validCollection(header.getReceiver())) {
				// If this is a registry message, there may only be one receiver, otherwise there can be multiple.
				if (isRegistryInterfaceMessage) {
					// Only write the first
					writeReceiver(writer, messageNs, header.getReceiver().get(0));
				} else {
					// Write all receivers
					List<PartyBean> allReceivers = header.getReceiver();
					for (PartyBean partyBean : allReceivers) {
						writeReceiver(writer, messageNs, partyBean);
					}
				}

			} else {
				// Write "default" receiver
				writeReceiver(writer, messageNs, "not_supplied");
			}
		}

		writer.writeEndElement();  //End Header
	}
	

	private static void writeReceiver(StaxWriter writer,  Namespace messageNs, PartyBean partyBean) {
		writer.writeStartElement(messageNs, "Receiver");
		writer.writeAttribute("id", partyBean.getId());

		// Write names if present
		List<TextTypeWrapper> names = partyBean.getName();
		if (ObjectUtil.validCollection(names)) {
			StaxTextWriterUtil.writeTextTypes(names, writer, "Name");
		}

		// Write contacts if present
		List<ContactBean> contacts = partyBean.getContacts();
		if (ObjectUtil.validCollection(contacts)) {
			StaxContactWriterUtil.writeContactForReceiver(contacts, writer);
		}

		writer.writeEndElement();  //End Receiver
	}

	private static void writeReceiver(StaxWriter writer,  Namespace messageNs, String receiverId) {
		writer.writeStartElement(messageNs, "Receiver");
		writer.writeAttribute("id", receiverId);
		writer.writeEndElement();  //End Receiver
	}
}
