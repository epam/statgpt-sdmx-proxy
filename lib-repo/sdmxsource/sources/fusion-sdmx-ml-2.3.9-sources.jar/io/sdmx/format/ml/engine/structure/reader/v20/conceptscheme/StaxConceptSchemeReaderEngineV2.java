package io.sdmx.format.ml.engine.structure.reader.v20.conceptscheme;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptMutableBean;
import io.sdmx.api.sdmx.model.mutable.conceptscheme.ConceptSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptMutableBeanImpl;
import io.sdmx.im.mutable.conceptscheme.ConceptSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxConceptSchemeReaderEngineV2 implements StaxMaintainableReaderEngine<ConceptSchemeMutableBean>, IFusionSingleton {
	private static StaxConceptSchemeReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeReaderEngineV2() {}
	public static StaxConceptSchemeReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
	    INSTANCE = null;
	}
	
	@Override
    public String getContainerNodeName() {
        return "Concepts";
    }
	
	@Override
    public final void read(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
	    Map<String, List<ConceptMutableBean>> freeStandingConcepts = new HashMap<>();
        while(reader.moveNextNode()) {
            String nodeName = reader.getElementName();
            if(reader.isStartElement()) {
                if(nodeName.equals("ConceptScheme")) {
                    processConceptScheme(reader, beans, builder);
                } else if(nodeName.equals("Concept")) {
                    processConcept(reader, freeStandingConcepts);
                } else {
                    StaxStructureUtil.throwUnexpectedNodeException(reader);
                }
            } else if(nodeName.equals(getContainerNodeName())){
                break;
            }
        }
        for (String acyId : freeStandingConcepts.keySet()) {
            ConceptSchemeMutableBean maint = new ConceptSchemeMutableBeanImpl();
            maint.setAgencyId(acyId);
            maint.setId(ConceptSchemeBean.DEFAULT_SCHEME_ID);
            maint.setVersion(ConceptSchemeBean.DEFAULT_SCHEME_VERSION);
            maint.addName("en", ConceptSchemeBean.DEFAULT_SCHEME_NAME);

            for (ConceptMutableBean aConcept : freeStandingConcepts.get(acyId)) {
                maint.addItem(aConcept);
            }
            builder.build(maint, beans);
        }
    }
	
	private void processConceptScheme(IStaxReader reader, SdmxBeans beans, IBeansBuilder builder) {
	    ConceptSchemeMutableBean maint = new ConceptSchemeMutableBeanImpl();
        StaxMaintainableUtilV2.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("Concept")) {
                maint.addItem(processConcept(reader, null));
            } else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
	    builder.build(maint, beans);
	}
	
	private ConceptMutableBean processConcept(IStaxReader reader, Map<String, List<ConceptMutableBean>> freeStandingConcepts) {
		ConceptMutableBean concept = new ConceptMutableBeanImpl();

		Map<String, String> attributes = reader.getAttributes();
		concept.setId(StaxStructureUtil.getAttribute(attributes, "id", false));  //Id may not be mandatory for an identifiable that inherits it from a concept if not provided

		if (freeStandingConcepts != null) {
		    String acyId =  StaxStructureUtil.getAttribute(attributes, "agencyID", false);
		    if (acyId == null) {
		        acyId = "SDMX";
		    }
	        List<ConceptMutableBean> aList = freeStandingConcepts.get(acyId);
	        if (aList == null) {
	            aList = new ArrayList<>();
	            freeStandingConcepts.put(acyId, aList);
	        }
	        aList.add(concept);
		}

		concept.setUri(StaxStructureUtil.getAttribute(attributes, "uri", false));
		concept.setParentConcept(StaxStructureUtil.getAttribute(attributes, "parent", false));

		String coreRep = StaxStructureUtil.getAttribute(attributes, "coreRepresentation", false);
		String coreRepAcy =  StaxStructureUtil.getAttribute(attributes, "coreRepresentationAgency", false);
		if (!(coreRep == null && coreRepAcy == null)) {
		    if (coreRep != null && coreRepAcy != null) {
		        StructureReferenceBean sRef = new StructureReferenceBeanImpl(coreRepAcy, coreRep, "1.0", SDMX_STRUCTURE_TYPE.CODE_LIST);
		        RepresentationMutableBean coreRepresentation = new RepresentationMutableBeanImpl();
		        coreRepresentation.setRepresentation(sRef);
		        concept.setCoreRepresentation(coreRepresentation);
		    } else {
		        if (coreRep == null) {
		            throw new IllegalArgumentException("Unable to specify Core Representation since the attribute 'coreRepresentation' was missing");
		        }
		        if (coreRepAcy == null) {
		            throw new IllegalArgumentException("Unable to specify Core Representation since the attribute 'coreRepresentationAgency' was missing");
		        }
		    }
		}

		reader.moveNextNode();

		while(StaxNameableUtil.processNode(concept, reader)) {
		    //Processing Nodes
		    reader.moveNextNode();
		}

		if(reader.getElementName().equals("Annotations")) {
            StaxAnnotableUtil.processAnnotations(concept, reader);
            reader.moveNextNode(); //Move to the start/end of the next node
        }

		return concept;
	}
}
