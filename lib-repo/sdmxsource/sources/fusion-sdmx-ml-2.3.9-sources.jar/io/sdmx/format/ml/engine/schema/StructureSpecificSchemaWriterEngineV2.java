package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class StructureSpecificSchemaWriterEngineV2 implements SchemaWriterEngine {
	private static StructureSpecificSchemaWriterEngineV2 INSTANCE;

	private SchemaLocationManager schemaLocationManager;
	
	public StructureSpecificSchemaWriterEngineV2() {
		SingletonStore.registerInterest(SchemaLocationManager.class, (instance)-> {
			this.schemaLocationManager = instance;
		});
	}


	public static StructureSpecificSchemaWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureSpecificSchemaWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}


	@Override
	public void writeSchema(ConstrainedCodes validCodes, String dimensionAtObservation, boolean prettyPrint, OutputStream out) {
		if(schemaLocationManager == null) {
			throw new SdmxNotImplementedException("Missing required SchemaLocationManager");
		}
		SDMX_SCHEMA schema = SDMX_SCHEMA.VERSION_TWO;
		CompactSchemaCreator schemaWriter = new CompactSchemaCreatorSdmx(validCodes, dimensionAtObservation, 
				schemaLocationManager.getSchemaLocation(schema), schema, out, prettyPrint);
		schemaWriter.createSchema();
	}

}
