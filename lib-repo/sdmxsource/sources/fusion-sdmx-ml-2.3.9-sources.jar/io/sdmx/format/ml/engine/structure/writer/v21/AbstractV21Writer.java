package io.sdmx.format.ml.engine.structure.writer.v21;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxMaintainableWriterUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class AbstractV21Writer<T extends MaintainableBean> implements StaxMaintainableWriterEngine<T> {
	protected static Namespace NS = StaxStructureWriterUtil.STRCUTURE_NS;
	

	@Override
	public void writeMaintainable(T maint, StaxWriter writer) {
		StaxMaintainableWriterUtil.writeBean(maint, getRootNodeName(), writer, getAdditionalMaintainableAttributes(maint));
		
		//Note a Provision Agreement can not be a stub according to the SDMX version 2.1 Schema
		if(maint.getStructureType() == SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT || !maint.isExternalReference()) {
			writeMaintainableInternal(maint, writer);
		}
		writer.writeEndElement(); //End Maintainable
	}
	
	/**
	 * Allows sub classes to override to provide additional maintainable attributes
	 * @return
	 */
	protected Map<String, String> getAdditionalMaintainableAttributes(T maint) {
		return null;
	}
	
	protected abstract String getRootNodeName();
	

	protected abstract void writeMaintainableInternal(T maint, StaxWriter writer);
}
