package io.sdmx.format.ml.engine.structure.reader.v3.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.OrganisationSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxContactUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;

public abstract class StaxAbstractOrgansiationReaderV3<T extends OrganisationSchemeMutableBean> extends AbstractStaxMaintainableReaderEngine<T> {

	
	protected void processOrganisation(OrganisationMutableBean org, IStaxReader reader) {
		StaxNameableUtil.processBean(org, reader);
		if(reader.isStartElement()) {
			processStartElement(org, reader);
		}
	}
	
	protected void processStartElement(OrganisationMutableBean org, IStaxReader reader) {
		while(reader.isStartElement()) {
			if(reader.getElementName().equals("Contact")) {
				ContactMutableBean contact = new ContactMutableBeanImpl();
				org.addContact(contact);
				StaxContactUtil.processBean(contact, reader);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		
	}
}
