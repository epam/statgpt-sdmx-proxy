package io.sdmx.format.ml.engine.structure.reader.v21.dsd;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.AttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DataStructureMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.DimensionMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.GroupMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureListMutableBean;
import io.sdmx.api.sdmx.model.mutable.datastructure.MeasureMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxRepresentationUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.datastructure.AttributeListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.AttributeMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DataStructureMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.DimensionMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.GroupMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.MeasureListMutableBeanImpl;
import io.sdmx.im.mutable.datastructure.PrimaryMeasureMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDsdReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<DataStructureMutableBean> {
	private static StaxDsdReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDsdReaderEngineV21() {}

	public static StaxDsdReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDsdReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
    @Override
    public String getContainerNodeName() {
        return "DataStructures";
    }

    @Override
    protected String getRootNodeName() {
        return "DataStructure";
    }

    @Override
    protected DataStructureMutableBean processMaintainable(IStaxReader reader) {
		DataStructureMutableBean dsd = new DataStructureMutableBeanImpl();
		StaxMaintainableUtil.processBean(dsd, reader);
		if(reader.isStartElement()) {
			if(!reader.getElementName().equals("DataStructureComponents")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			while(reader.moveNextNode()) {
				String nodeName = reader.getElementName();
				if(reader.isStartElement()) {
					if(nodeName.equals("DimensionList")) {
						dsd.setDimensionList(processDimensionList(reader));
					} else if(nodeName.equals("Group")) {
						dsd.addGroup(processGroup(reader));
					} else if(nodeName.equals("AttributeList")) {
						dsd.setAttributeList(processAttributeList(reader));
					} else if(nodeName.equals("MeasureList")) {
						dsd.setMeasureList(processPrimaryMeasure(reader));
					} else {
						StaxStructureUtil.throwUnexpectedNodeException(reader);
					}
				} else if(nodeName.equals("DataStructureComponents")) {
					break;
				}
			}
		}
		return dsd;
	}

	private DimensionListMutableBean processDimensionList(IStaxReader reader) {
		DimensionListMutableBean bean = new DimensionListMutableBeanImpl();
		StaxIdentifiableUtil.processBean(bean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Dimension")) {
				bean.addDimension(processDimension(reader, false, false));
			} else if(nodeName.equals("MeasureDimension")) {
				bean.addDimension(processDimension(reader, true, false));
			}  else if(nodeName.equals("TimeDimension")) {
				bean.addDimension(processDimension(reader, false, true));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return bean;
	}

	private DimensionMutableBean processDimension(IStaxReader reader, boolean isMeasureDimension, boolean isTimeDimension) {
		DimensionMutableBean returnBean = new DimensionMutableBeanImpl();
		StaxIdentifiableUtil.processBean(returnBean, reader);
		returnBean.setMeasureDimension(isMeasureDimension);
		returnBean.setTimeDimension(isTimeDimension);
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("ConceptIdentity")) {
				returnBean.setConceptRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			} else if(nodeName.equals("LocalRepresentation")) {
				returnBean.setRepresentation(StaxRepresentationUtil.processBean(reader, isMeasureDimension==false));
			}  else if(nodeName.equals("ConceptRole")) {
				returnBean.addConceptRole(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}

	private GroupMutableBean processGroup(IStaxReader reader) {
		GroupMutableBean returnBean = new GroupMutableBeanImpl();
		StaxIdentifiableUtil.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("GroupDimension")) {
				reader.moveNextStartNode();
				if(reader.getElementName().equals("DimensionReference")) {
					 returnBean.addDimensionRef(StaxStructureUtil.getLocalReference(reader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
				reader.skipToEndNode("GroupDimension");
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}

	private AttributeListMutableBean processAttributeList(IStaxReader reader) {
		AttributeListMutableBean bean = new AttributeListMutableBeanImpl();
		StaxIdentifiableUtil.processBean(bean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Attribute")) {
				bean.addAttribute(processAttribute(reader));
			} else if(nodeName.equals("ReportingYearStartDay")) {
				//TODO Not Supported
			}  else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return bean;
	}

	private AttributeMutableBean processAttribute(IStaxReader reader) {
		AttributeMutableBean returnBean = new AttributeMutableBeanImpl();

		String assignmentStatus = StaxStructureUtil.getAttribute(reader.getAttributes(), "assignmentStatus", true);
        boolean assignmentStatusBool;
        if (assignmentStatus.equals("Conditional")) {
        	assignmentStatusBool = false;
        } else if (assignmentStatus.equals("Mandatory")) {
        	assignmentStatusBool = true;
        } else {
        	throw new SdmxSemmanticException("'assignmentStatus' has illegal value of: " + assignmentStatus);
        }
		returnBean.setMandatory(assignmentStatusBool);
		StaxIdentifiableUtil.processBean(returnBean, reader);
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("ConceptIdentity")) {
				returnBean.setConceptRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			} else if(nodeName.equals("LocalRepresentation")) {
				returnBean.setRepresentation(StaxRepresentationUtil.processBean(reader, true));
			} else if(nodeName.equals("ConceptRole")) {
				returnBean.addConceptRole(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			}  else if(nodeName.equals("AttributeRelationship")) {
				processAttributeRelationship(reader, returnBean);
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}

	private void processAttributeRelationship(IStaxReader reader, AttributeMutableBean attribute) {
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("None")) {
					attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DATA_SET);
				} else if(nodeName.equals("Dimension")) {
					attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP);
					attribute.addDimensionReferences(StaxStructureUtil.getLocalReference(reader));
				} else if(nodeName.equals("PrimaryMeasure")) {
					attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION);
					attribute.addMeasureReference("OBS_VALUE");
				} else if(nodeName.equals("AttachmentGroup")) {
					reader.skipCurrentNode();  //TODO Not supported
				} else if(nodeName.equals("Group")) {
					attribute.setAttachmentLevel(ATTRIBUTE_ATTACHMENT_LEVEL.GROUP);
					attribute.setAttachmentGroup(StaxStructureUtil.getLocalReference(reader));
				}
			} else if(nodeName.equals("AttributeRelationship")) {
				return;
			}
		}
	}

	private MeasureListMutableBean processPrimaryMeasure(IStaxReader reader) {
		MeasureListMutableBean returnBean = new MeasureListMutableBeanImpl();
		StaxIdentifiableUtil.processBean(returnBean, reader);

		MeasureMutableBean pm = new PrimaryMeasureMutableBeanImpl();
		returnBean.addMeasures(pm);
		if(!reader.isStartElement()) {
			throw new SdmxSemmanticException("MeasureList missing PrimaryMeasure");
		}
		if(!reader.getElementName().equals("PrimaryMeasure")) {
			StaxStructureUtil.throwUnexpectedNodeException(reader);
		}
		StaxIdentifiableUtil.processBean(pm, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("ConceptIdentity")) {
				pm.setConceptRef(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CONCEPT));
			} else if(nodeName.equals("LocalRepresentation")) {
				pm.setRepresentation(StaxRepresentationUtil.processBean(reader, true));
			}  else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
}