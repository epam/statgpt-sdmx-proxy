package io.sdmx.format.ml.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.format.ml.factory.data.SdmxMLDataFormatFactory;
import io.sdmx.format.ml.factory.data.SdmxMLDataReaderFactory;
import io.sdmx.format.ml.factory.data.SdmxMLDataWriterFactory;
import io.sdmx.format.ml.factory.error.SdmxErrorWriterFactory;
import io.sdmx.format.ml.factory.metadata.SdmxMLMetadataFormatFactory;
import io.sdmx.format.ml.factory.metadata.SdmxMLMetadataReaderFactory;
import io.sdmx.format.ml.factory.metadata.SdmxMLMetadataWriterFactory;
import io.sdmx.format.ml.factory.registration.SdmxMLRegistrationReaderFactory;
import io.sdmx.format.ml.factory.schema.SdmxXSDSchemaFormatFactory;
import io.sdmx.format.ml.factory.schema.SdmxXSDSchemaWriterFactory;
import io.sdmx.format.ml.factory.structure.SdmxMLStructureFormatFactory;
import io.sdmx.format.ml.factory.structure.SdmxMLStructureReaderFactory;
import io.sdmx.format.ml.factory.structure.SdmxMLStructureWriterFactory;

/**
 * Register all SDMX-ML factories, readers and writers with the applicaiton framework
 */
public class SdmxMLModule implements IFusionModule {

	public static void register() {
		SdmxXSDSchemaWriterFactory.registerInstance();
		SdmxXSDSchemaFormatFactory.registerInstance();
		
		SdmxMLDataFormatFactory.registerInstance();
		SdmxMLDataReaderFactory.registerInstance();
		SdmxMLDataWriterFactory.registerInstance();

		SdmxMLStructureReaderFactory.registerInstance();
		SdmxMLStructureWriterFactory.registerInstance();
		SdmxMLStructureFormatFactory.registerInstance();
		
		SdmxMLMetadataFormatFactory.registerInstance();
		SdmxMLMetadataReaderFactory.registerInstance();
		SdmxMLMetadataWriterFactory.registerInstance();
		
		SdmxMLRegistrationReaderFactory.getInstance();
		
		SdmxErrorWriterFactory.registerInstance();
	}
	
}
