package io.sdmx.format.ml.engine.structure.writer.v3.provision;

import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxProvisionWriterEngineV3 extends AbstractV3Writer<ProvisionAgreementBean> implements IFusionSingleton {
	private static StaxProvisionWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProvisionWriterEngineV3() {}

	public static StaxProvisionWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProvisionWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ProvisionAgreement";
	}

	@Override
	protected void writeMaintainableInternal(ProvisionAgreementBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getStructureUseage(), writer, "Dataflow");
		StaxRefUtilV3.writeReference(maint.getDataproviderRef(), writer, "DataProvider");
	}
}
