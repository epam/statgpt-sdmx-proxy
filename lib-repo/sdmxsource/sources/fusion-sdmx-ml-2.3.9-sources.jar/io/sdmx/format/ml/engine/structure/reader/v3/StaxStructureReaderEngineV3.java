package io.sdmx.format.ml.engine.structure.reader.v3;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxStructureReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.categorisation.StaxCategorisationReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.catscheme.StaxCategorySchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.codelist.StaxCodelistReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.codelist.StaxGeoGridCodelistReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.codelist.StaxGeographicCodelistReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.codelist.StaxValueListReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.conceptscheme.StaxConceptSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.constraint.StaxContentConstraintReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.dataflow.StaxDataflowReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.dsd.StaxDsdReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.hcl.StaxHclReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.hcl.StaxHierarchyAssociationReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.mapping.StaxRepresentationMapReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.mapping.StaxStructureMapReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.metadata.StaxMSDReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.metadata.StaxMetadataProvisionReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.metadata.StaxMetadataflowReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.orgscheme.StaxAgencySchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.orgscheme.StaxDataConsumerSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.orgscheme.StaxDataProviderSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.orgscheme.StaxMetadataProviderSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.orgscheme.StaxOrgUnitSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.process.StaxProcessReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.provision.StaxProvisionReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.registration.StaxRegistrationReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.reportingtaxonomy.StaxReportingTaxonomyReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxCustomTypeSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxNamePersonalisationSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxRulesetSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxTransformationSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxUserDefinedOperatorSchemeReaderEngineV3;
import io.sdmx.format.ml.engine.structure.reader.v3.transformation.StaxVtlMappingSchemeReaderEngineV3;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxStructureReaderEngineV3 extends AbstractStaxStructureReaderEngine implements IFusionSingleton {
	private static StaxStructureReaderEngineV3 INSTANCE;

	public static StaxStructureReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	//Private constructor - lazy load instance
	private StaxStructureReaderEngineV3() {
		super("Structures");
		
		registerReader(StaxAgencySchemeReaderEngineV3.getInstance());
		registerReader(StaxDataProviderSchemeReaderEngineV3.getInstance());
		registerReader(StaxMetadataProviderSchemeReaderEngineV3.getInstance());
		registerReader(StaxDataConsumerSchemeReaderEngineV3.getInstance());
		registerReader(StaxOrgUnitSchemeReaderEngineV3.getInstance());
		registerReader(StaxCategorisationReaderEngineV3.getInstance());
		registerReader(StaxCategorySchemeReaderEngineV3.getInstance());
		registerReader(StaxCodelistReaderEngineV3.getInstance());
		registerReader(StaxConceptSchemeReaderEngineV3.getInstance());
		registerReader(StaxMetadataflowReaderEngineV3.getInstance());
		registerReader(StaxMetadataProvisionReaderEngineV3.getInstance());
		registerReader(StaxDataflowReaderEngineV3.getInstance());
		registerReader(StaxContentConstraintReaderEngineV3.getInstance());
		registerReader(StaxContentConstraintReaderEngineV3.getInstance());
		registerReader(StaxDsdReaderEngineV3.getInstance());
        registerReader(StaxGeographicCodelistReaderEngineV3.getInstance());
        registerReader(StaxGeoGridCodelistReaderEngineV3.getInstance());
		registerReader(StaxHierarchyAssociationReaderEngineV3.getInstance());
		registerReader(StaxHclReaderEngineV3.getInstance());
		registerReader(StaxMSDReaderEngineV3.getInstance());
		registerReader(StaxProcessReaderEngineV3.getInstance());
		registerReader(StaxProvisionReaderEngineV3.getInstance());
		registerReader(StaxRegistrationReaderEngineV3.getInstance());
		registerReader(StaxStructureMapReaderEngineV3.getInstance());
		registerReader(StaxRepresentationMapReaderEngineV3.getInstance());
		registerReader(StaxReportingTaxonomyReaderEngineV3.getInstance());
		registerReader(StaxValueListReaderEngineV3.getInstance());
		registerReader(StaxCustomTypeSchemeReaderEngineV3.getInstance());
		registerReader(StaxNamePersonalisationSchemeReaderEngineV3.getInstance());
		registerReader(StaxRulesetSchemeReaderEngineV3.getInstance());
		registerReader(StaxTransformationSchemeReaderEngineV3.getInstance());
		registerReader(StaxUserDefinedOperatorSchemeReaderEngineV3.getInstance());
		registerReader(StaxVtlMappingSchemeReaderEngineV3.getInstance());
	}

	@Override
	protected SDMX_SCHEMA getOutputVersion() {
		return SDMX_SCHEMA.VERSION_THREE;
	}

	@Override
	protected HeaderBean processHeader(IStaxReader reader) {
		return StaxHeaderReaderEngineV3.readerHeader(reader);
	}
}
