package io.sdmx.format.ml.engine.structure.writer.v2;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxMaintainableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxStructureWriterUtilV2;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class AbstractV2Writer<T extends MaintainableBean> implements StaxMaintainableWriterEngine<T> {
	protected static Namespace NS = StaxStructureWriterUtilV2.STRUCTURE_NS;

	@Override
	public void writeMaintainable(T maint, StaxWriter writer) {
		StaxMaintainableWriterUtilV2.writeBean(maint, getRootNodeName(), writer, getAdditionalMaintainableAttributes(maint));
		writeMaintainableInternal(maint, writer);
		StaxAnnotableWriterUtilV2.writeBean(maint, writer);
		writer.writeEndElement(); //End Maintainable
	}

	/**
	 * Allows sub classes to override to provide additional maintainable attributes
	 * @return
	 */
	protected Map<String, String> getAdditionalMaintainableAttributes(T maint) {
		return null;
	}

	protected abstract String getRootNodeName();


	protected abstract void writeMaintainableInternal(T maint, StaxWriter writer);
}
