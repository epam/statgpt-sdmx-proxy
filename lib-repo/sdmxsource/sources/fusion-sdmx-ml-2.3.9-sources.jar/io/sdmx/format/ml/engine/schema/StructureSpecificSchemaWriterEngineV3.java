package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class StructureSpecificSchemaWriterEngineV3 implements SchemaWriterEngine {
	private static StructureSpecificSchemaWriterEngineV3 INSTANCE;

	public static StructureSpecificSchemaWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureSpecificSchemaWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void writeSchema(ConstrainedCodes validCodes, String dimensionAtObservation, boolean prettyPrint, OutputStream out) {
		SchemaLocationManager schemaLocation = SingletonStore.getSingleton(SchemaLocationManager.class);
		CompactSchemaCreator schemaWriter = new CompactSchemaCreatorSdmx3_0(validCodes, dimensionAtObservation, 
				schemaLocation.getSchemaLocation(SDMX_SCHEMA.VERSION_THREE), out, prettyPrint);
		schemaWriter.createSchema();
	}
}
