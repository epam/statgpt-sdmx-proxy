package io.sdmx.format.ml.engine.structure.reader.v21.categorisation;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCategorisationReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<CategorisationMutableBean> {
	private static StaxCategorisationReaderEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorisationReaderEngineV21() {}
	public static StaxCategorisationReaderEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorisationReaderEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
        return "Categorisations";
    }
	
    @Override
    protected String getRootNodeName() {
        return "Categorisation";
    }

	@Override
    protected CategorisationMutableBean processMaintainable(IStaxReader reader) {
		CategorisationMutableBean bean = new CategorisationMutableBeanImpl();
		StaxMaintainableUtil.processBean(bean, reader);

		while(reader.isStartElement()) {
			if(reader.getElementName().equals("Source")) {
				bean.setStructureReference(StaxStructureUtil.getStructureReference(reader, null));
			} else if(reader.getElementName().equals("Target")) {
				bean.setCategoryReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CATEGORY));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return bean;
	}
}
