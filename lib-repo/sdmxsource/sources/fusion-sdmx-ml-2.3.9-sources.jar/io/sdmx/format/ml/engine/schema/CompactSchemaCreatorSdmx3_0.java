package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.AttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.GroupSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.MeasureSuperBean;

/**
 * Generates a Compact Schema for SDMX 2.1
 */
public class CompactSchemaCreatorSdmx3_0 extends CompactSchemaCreator {

	private static final Logger LOG = LoggerFactory.getLogger(CompactSchemaCreatorSdmx3_0.class);

	private Set<String> complexTypes;

	public CompactSchemaCreatorSdmx3_0(ConstrainedCodes constrainedCodes, String dimensionAtObservation, String schemaLocation, OutputStream out, boolean prettyPrint) {
		super(constrainedCodes, dimensionAtObservation, schemaLocation, out, prettyPrint);
	}

	@Override
	public void createSchema() {
		LOG.info("Generating Schema: SDMX 3.0 " + (generatingCrossSectional ? " - cross sectional" : "") );
		super.createSchema();
	}
	
	

	@Override
	protected void writeSchemaInformation() {
		String namespaceId;
		if(generatingAllDimensions) {
			namespaceId = "AllDimensions";
		} else if (generatingCrossSectional) {
			// The targetNamespace will be the URN of the cross-sectional dimension
			// FIX SLi According to the standard this should be dsd urn followed by the ObsLevelDim and cross dimension id. 
			namespaceId = crossSectionDimension.getId();
		} else {
			DimensionSuperBean timeDimensionBean = dsd.getTimeDimension();
			if (timeDimensionBean == null) {
				namespaceId = PrimaryMeasureBean.FIXED_ID;
			} else {
				namespaceId = timeDimensionBean.getId();
			}
		}
		targetNamespace = srb.getTargetUrn() + ":ObsLevelDim:" + namespaceId;
		this.complexTypes = getComplexTypes();
		init(out, COMPACT, targetNamespace, SDMX_SCHEMA.VERSION_THREE, dsd);
	}
	
	/**
	 * @param component
	 * @return true if this simple type is to be written at the top of the schema (before the Dataset)
	 */
	protected boolean writeSimpleType(ComponentSuperBean<ComponentBean> component) {
		if(this.complexTypes.contains(component.getId()) && this.getComplexTypeRef(component) != null) {
			return false;
		}
		return super.writeSimpleType(component);
	}


	private boolean hasComplexTypes() {
		return complexTypes.size() > 0;
	}

	/**
	 * <h1>Representation with Complex Text Format</h1>
		A representation which defines a complex text format will result in a complex type. The representation is complex if any of the following conditions are true: 
	    <ul>
	      <li>representation max occurs is greater than 1</li>
	      <li>text format data type is XHMTL</li>
	      <li>text format is multi-lingual</li>
	    </ul>
	 */
	private Set<String> getComplexTypes() {
		Set<String> returnSet = new TreeSet<>();
		for(ComponentBean comp : dsd.getBuiltFrom().getComponents()) {
			if(comp.getMinOccurs() > 1 || comp.getMaxOccurs() > 1 || comp.isMultilingual() || comp.getTextType() == TEXT_TYPE.XHTML) {
				returnSet.add(comp.getId());
			}
		}
		return returnSet;
	}

	@Override
	/**
	 * A complex type named DataSetType must be created. Its content model will be derived via restriction. If the dimension at the observation level is the time dimension (TIME_PERIOD) the base type of the restriction is dsd:TimeSeriesDataSetType. Otherwise, the base type of the restriction is dsd:DataSetType. The complex type content model will be as follows:
    	<ol>
    	  <li>A sequence consisting of:
    	    <ul>
    	      <li>An element reference to common:Annotations, with a minimum occurrence of 0</li>
        	  <li>A local element named DataProvider with the type common:DataProviderReferenceType, a form of unqualified and a minimum occurrence of 0</li>
        	  <li>A choice with a minimum occurrence of 0 and a maximum occurrence of unbounded consisting of:
        	    <ul>
    	         <li>A local element named Atts with a form of unqualified and a type of AttsType (as defined in the AttsType section which follows)</li>
                 <li>If the data structure defines groups, a local element named Group with a form of unqualified. The type of this element should be the type that is described in the GroupType section which follows.</li>
                 <li>If the dimension at the observation level is not AllDimensions, a local element named Series with a form of unqualified and a type of SeriesType (as defined in the SeriesType section which follows)</li>
                 <li>If the dimension at the observation level is AllDimensions, a local element named Obs with a form of unqualified and a type of ObsType (as defined in the AttsType section which follows)</li>
               </ul>
           </ul>
       </ol>    
	 */
	protected void writeDataset() throws Exception {
		addElement("DataSet",  "DataSetType",  "compact:DataSet");
		
		addComplexTypeForRestriction("DataSetType", "dsd:DataSetType");
		writer.writeStartElement(SCHEMA_NS, "sequence");
		addAnnotations();
		writeDataProviderElement();

		writer.writeStartElement(SCHEMA_NS, "choice");
		writer.writeAttribute("minOccurs", "0");
		writer.writeAttribute("maxOccurs", "unbounded");
		
		//Write Attrs Elements if there is at least 1 Attribute which is not Complex
		if(requiresAttsType()) {
			writeAttsElement();
		}
		
		writeGroupsElements();
		if (generatingAllDimensions) {
			writeObsElement(false);
		} else {
			writeSeriesElement(); 
		}
		writer.writeEndElement(); //End choice
		writer.writeEndElement(); //End sequence

		prohibitReportingYearStartDay();
		endComplexType(writer);
	}

	private void writeDataProviderElement() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "DataProvider");
		writer.writeAttribute("type", "common:DataProviderReferenceType");
		writer.writeAttribute("form", "unqualified");
		writer.writeAttribute("minOccurs", "0");
		writer.writeEndElement(); 
	}

	private void writeGroupsElements() throws XMLStreamException {
		for(GroupSuperBean currentGroup : dsd.getGroups()) {
			// Write a group element
			writer.writeStartElement(SCHEMA_NS, "element");
			writer.writeAttribute("name", "Group");
			writer.writeAttribute("type", currentGroup.getId());
			writer.writeAttribute("form", "unqualified");
			writer.writeEndElement();	
		}
	}

	private void writeSeriesElement() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Series");
		writer.writeAttribute("type", "SeriesType");
		writer.writeAttribute("form", "unqualified");
		writer.writeEndElement();
	}

	private void writeAttsElement() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Atts");
		writer.writeAttribute("type", "AttsType");
		writer.writeAttribute("form", "unqualified");
		writer.writeEndElement();  
	}

	private void writeObsElement(boolean includeCardinality) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Obs");
		writer.writeAttribute("type", "ObsType");
		writer.writeAttribute("form", "unqualified");
		if(includeCardinality) {
			writer.writeAttribute("minOccurs", "0");
			writer.writeAttribute("maxOccurs", "unbounded");
		}
		writer.writeEndElement();
	}

	private void writeCompElement() throws XMLStreamException {
		if(hasComplexTypes()) {  //TODO this question needs to be asked in context of which components are to be written (i.e series attributes, obs attributes)
			writer.writeStartElement(SCHEMA_NS, "element");
			writer.writeAttribute("name", "Comp");
			writer.writeAttribute("type", "dsd:CompType");
			writer.writeAttribute("form", "unqualified");
			writer.writeAttribute("minOccurs", "0");
			writer.writeAttribute("maxOccurs", "unbounded");
			writer.writeEndElement();
		}
	}

	/**
	 * Writes the sequence
	 * 	<xs:sequence>
		  <xs:element ref="common:Annotations" minOccurs="0"/>
		  <xs:element name="Comp" type="dsd:CompType" form="unqualified" minOccurs="0" maxOccurs="unbounded"/>
		</xs:sequence>

		Only adds CompType if there are complex types
	 */
	private void writeAnnotationAndComplexElements() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "sequence");
		addAnnotations();
		writeCompElement();
		writer.writeEndElement(); //End sequence
	}

	/**
	 * A a complex type named AttsType must be created. Its content model will be derived via restriction of dsd:AttsType. The complex type content model will be as follows:
	 * 
	 * <ol>
	 *   <li>A sequence consisting of:
         <ul>
           <li>An element reference to common:Annotations, with a minimum occurrence of 0
           <li>If any attributes with complex representation are defined in the data structure, </li>
               a Comp element with a form of unqualified, a minimum occurrence of 0, a maximum occurrence of unbounded, and a type of dsd:CompType </li>
        </ul>
        </li>
        <li>An attribute for all dimension defined by the data structure definition. 
            The XML attribute name and type are defined according to the general rules defined in the previous section, and the usage is optional</li>
        <li>If the reporting year start day attribute is not declared in the data structure definition, an attribute named REPORTING_YEAR_START_DAY with a type of xs:gMonthDay and a usage of prohibited</li>
        <li>An attribute for each data and metadata attribute defined with simple representation in the data structure. 
           The XML attribute name and type are defined according to the general rules defined in the previous section, and the usage is optional</li>
	 * @throws Exception 
	 * @throws XMLStreamException 
	 */
	protected void writeDatasetAttributes() throws Exception {
		if(requiresAttsType()) {
			addComplexTypeForRestriction("AttsType", "dsd:AttsType");
			
			writeAnnotationAndComplexElements();
			for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION) ) {
				addRequiredDimensionBean(bean);
			}
			addAttributes(dsd.getDatasetAttributes());
			addAttributes(dsd.getSeriesAttributes());
			//TODO MSD Attributes
			prohibitTimePeriod(false);
			prohibitReportingYearStartDay();
			endComplexType(writer);
		}
	}
	
	/**
	 * @return true if the DSD has at least 1 dataset or series attribute which is not complex
	 */
	private boolean requiresAttsType() {
		for(AttributeSuperBean att : dsd.getDatasetAttributes()) {
			if(!complexTypes.contains(att.getId())) {
				return true;
			}
		}
		for(AttributeSuperBean att : dsd.getSeriesAttributes()) {
			if(!complexTypes.contains(att.getId())) {
				return true;
			}
		}
		return false;
	}

	private void addAttributes(List<AttributeSuperBean> attributes) throws XMLStreamException {
		for(AttributeSuperBean attributeBean : attributes) {
			addAttribute(attributeBean);
		}
	}

	@Override
	/**
	 * Only add a simple type if it is not a complex type
	 */
	void addAttribute(AttributeSuperBean attributeBean) throws XMLStreamException {
		if(!complexTypes.contains(attributeBean.getId())) {
			addComponentBean(attributeBean);	
			writer.writeAttribute("use", "optional");
			writer.writeEndElement();
		}
	}

	@Override
	protected void writeGroups() throws Exception {
		for (GroupSuperBean currentGroup : dsd.getGroups()) {
			addComplexTypeForRestriction(currentGroup.getId(), "dsd:GroupType");

			writer.writeStartElement(SCHEMA_NS, "sequence");  // Start Sequence
			addAnnotations();
			writer.writeEndElement();	                      // End Sequence

			writeGroupAttributes(currentGroup);
			prohibitReportingYearStartDay();
			endComplexType(writer);
		}
	}

	@Override
	protected void writeSeries() throws Exception {
		if(generatingAllDimensions) {
			//All Dimensions are at the observation level
			return;
		}

		addComplexContentRoot("SeriesType", "SeriesType");

		writer.writeStartElement(SCHEMA_NS, "sequence");     // Start Sequence
		addAnnotations();
		writeCompElement();
		writeObsElement(true);
		writer.writeEndElement();                            // End Sequence

		for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION) ) {
			if(crossSectionDimension == null || !bean.getId().equals(crossSectionDimension.getId())) {
				addRequiredDimensionBean(bean);
			}
		}

		addAttributes(dsd.getSeriesAttributes());
		prohibitTimePeriod(false);
		prohibitReportingYearStartDay();
		endComplexType(writer);
	}

	@Override
	/**
	 * <h1>ObsType</h1>
		A complex type name ObsType must be created. Its content model will be derived via restriction of the base type dsd:ObsType. The complex type content model will be as follows:
		<ol>
		    <li> A sequence consisting of:
		        <ul>
		          <li>An element reference to common:Annotations, with a minimum occurrence of 0
		          <li>If any measures with complex representations are defined in the data structure, any attributes with complex representation that declare an attribute relationship with the observation, a Comp element with a form of unqualified, a minimum occurrence of 0, a maximum occurrence of unbounded, and a type of dsd:CompType
		    	</ul>
		    </li>
		    
		    <li>If the dimension at the observation level is not the time dimension (TIME_PERIOD) 
		    an attribute named TIME_PERIOD with a type of common:TimePeriodType and a usage of prohibited</li>
		    
		    <li>If the dimension at the observation level is not the time dimension (TIME_PERIOD) 
		    an attribute for the dimension at the observation level. 
		    The XML attribute name and type are defined according to the general rules defined in the previous section, and the usage is required</li>
		    
		    <li>An attribute for each measure with simple representation defined by the data structure definition. 
		    The XML attribute name and type is defined according to the general rules defined in the previous section, and the usage is optional</li>
		    
		    <li>An attribute for each data and metadata attribute with simple representation defined in the data structure 
		    that declares an attribute relationship with the observation. The XML attribute name and type are defined according 
		    to the general rules defined in the previous section, and the usage is optional</li>
		    
		    <li>An attribute named type. If the explicit measure option is not used, this attribute must have a type of common:IDType and a usage of prohibited. 
		    If the explicit measure option is used, this attribute must have a type of the simple type 
		    generated for the representation of the measure dimension that is the dimension at the observation level 
		    (this will be an simple type with enumerations with values 
		    of the concept identifiers which make up the concept scheme that is the representation of the measure dimension) a and a usage of optional</li>
	 */
	protected void writeObservations() throws Exception {
		addComplexContentRoot("ObsType", "ObsType");

		writeAnnotationAndComplexElements();

		// If Cross-Sectional add the dimension now
		if (generatingCrossSectional) {
			addRequiredDimensionBean(crossSectionDimension);
		} else if(generatingAllDimensions) {
			for(DimensionSuperBean bean : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION) ) {
				addRequiredDimensionBean(bean);
			}
		}
		for(MeasureSuperBean measure : dsd.getMeasures()) {
			if(!complexTypes.contains(measure.getId())) {
				addOptionalDimensionBean(measure);
			}
		}
		addAttributes(dsd.getObservationAttributes());
		prohibitTimePeriod(generatingCrossSectional == true); 
		prohibitReportingYearStartDay();
		endComplexType(writer);
	}

	@Override
	protected void addComplexContentRoot(String type, String type_2_1) throws Exception {
		String complexType;
		if (generatingCrossSectional) {
			complexType = type;
		} else {
			complexType = type_2_1;
		}
		addComplexTypeForRestriction(type, "dsd:" + complexType);
	}

	@Override
	void addElement(String name, String type, String substitutionGroup) throws XMLStreamException {
		super.addElement(name,type,null);
	}
	
//	void processCodelist(EnumeratedListBean<EnumeratedItemBean> codelist, ComponentSuperBean component) throws XMLStreamException {
//		boolean isComplexType = complexTypes.contains(component.getId());
//		if(isComplexType) {
//			//Writes the codelist as a ValueType and then outputs anther complex content as a restriction of CompType
//			super.processCodelist(codelist, component, "common:ValueType");
//		} else {
//			super.processCodelist(codelist, component);
//		}
//	}
	
	
	
	/**
     *<h1>CompType</h1>
	 * Writes a complex type for each component that has a representation which requires a structure (not just an XML attribute)
		For every measure and data or metadata attribute with complex representation defined by the data structure definition, 
		a complex type must be derived from the restriction of the dsd:CompType. The complex type content model will be as follows:
		 <ol>
		   <li>A sequence consisting of:
		     <ul>
		       <li>An element reference to common:Annotations, with a minimum occurrence of 0</li>
		       <li>A Value element with a form of unqualified, with a minimum occurrence of 0, 
		       a maximum occurrence defined by the representation, and a type based on the complex representation 
		       type defined according to the general rules defined in the previous section<li>
		     </ul>
		   </li>
		   <li>An attribute named id with a type of common: NCNameIDType, usage of required, and a fixed value of the identifier of the measure or attribute</li>
		 </ol>
		 
		 Example
		 <xs:complexType name="OBS_STATUS_ValueType">
			<xs:simpleContent>
				<xs:restriction base="common:ValueType">
					<xs:simpleType>
						<xs:restriction base="CL_OBS_STATUS"/>
					</xs:simpleType>
				</xs:restriction>
			</xs:simpleContent>
		</xs:complexType>	
		
		<xs:complexType name="OBS_STATUS_ATTRIBUTE">
			<xs:complexContent>
				<xs:restriction base="dsd:CompType">
					<xs:sequence>
						<xs:element ref="common:Annotations" minOccurs="0"/>
						<xs:element name="Value" type="OBS_STATUS_ValueType" form="unqualified" minOccurs="1" maxOccurs="unbounded"/>
					</xs:sequence>
					<xs:attribute name="id" type="common:NCNameIDType" use="required" fixed="OBS_STATUS"/>
				</xs:restriction>
			</xs:complexContent>
		</xs:complexType>	
	 */
	@Override
	void writeCompTypes() throws Exception {
		for(String complexType : complexTypes) {
			ComponentSuperBean<ComponentBean> compSb = dsd.getComponentById(complexType);
			if(writeCompAttributeElement(compSb)) {
				writeCompAttributeValueType(compSb);
			}
		}
	}
	
	/**
	 * The resulting complex type will be derived via restriction of the common:ValueType. In simple cases, there are pre-defined types that can be used: 
	    <ul>
    	  <li>if the text format data type is XHTML, common:StructuredTextValueType can be used</li>
	      <li>if the text format is multi-lingual, common:TextValueType can be used</li>
	      <li>if the text format has no additional facets and the data type is:
	        <ul>
	          <li>Boolean, common:BooleanValueType can be used</li>
	          <li>String, common:StringValueType can be used</li>
	          <li>Integer, common:IntValueType can be used</li>
	          <li>Double, common:DoubleValueType can be used</li>
	          <li> ObservationalTimePeriod, common:ObservationalTimePeriodValueType can be used</li>
	        </ul>
	    </ul>
	    
	    Example
	 *  <xs:complexType name="OBS_STATUS_ValueType">
			<xs:simpleContent>
				<xs:restriction base="common:ValueType">
					<xs:simpleType>
						<xs:restriction base="CL_OBS_STATUS"/>
					</xs:simpleType>
				</xs:restriction>
			</xs:simpleContent>
		</xs:complexType>	
		
		@return true if the ValueType references another ComplexType
	 */
	private void writeCompAttributeValueType(ComponentSuperBean<ComponentBean> comp) throws XMLStreamException {
		String typeRef = determineSchemaType(comp);
		
		addComplexTypeForRestriction(comp.getId()+"_ValueType", "common:ValueType", false);
		writer.writeStartElement(SCHEMA_NS, "simpleType");
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", typeRef);
		writer.writeEndElement();  //end restriction
		writer.writeEndElement();  //end simpleType
		endComplexType(writer);
	}
	
	/**
	 * @param comp
	 * @return the complex type if it can use an existing type, e.g. common:StructuredTextValueType - otherwise null is returned
	 */
	private String getComplexTypeRef(ComponentSuperBean<ComponentBean> comp) {
		String typeRef = null;
		if(comp.getCodelist(true) == null) {
			TEXT_TYPE textType = comp.getTextFormat() == null ? null : comp.getTextFormat().getTextType();
			if(textType == null) {
				textType = TEXT_TYPE.STRING;
			}
			if(textType == TEXT_TYPE.XHTML) {
				typeRef = "common:StructuredTextValueType";
			} else if(comp.getTextFormat() != null && comp.getTextFormat().getMultiLingual() == TERTIARY_BOOL.TRUE) {
				typeRef = "common:TextValueType";
			} else if(!hasAdditionalRestritions(comp.getTextFormat())) {
				switch(textType) {
				case BOOLEAN:
					typeRef = "common:BooleanValueType";
					break;
				case STRING:
					typeRef = "common:StringValueType";
					break;
				case INTEGER:
					typeRef = "common:IntValueType";
					break;
				case DOUBLE:
					typeRef = "common:DoubleValueType";
					break;
				case OBSERVATIONAL_TIME_PERIOD :
					typeRef = "common:ObservationalTimePeriodValueType";
					break;
				}
			}
		}
		return typeRef;
	}
	
	private boolean hasAdditionalRestritions(TextFormatBean tf) {
		if(tf == null) {
			return false;
		}
		return tf.getDecimals() != null ||
				tf.getEndTime() != null ||
				tf.getStartTime() !=null ||
				tf.getEndValue() !=null ||
				tf.getStartValue() !=null ||
				tf.getMaxLength() !=null ||
				tf.getMaxValue() !=null ||
				tf.getPattern() !=null;
	}
	
	/**
	 * <xs:complexContent>
			<xs:restriction base="dsd:CompType">
				<xs:sequence>
					<xs:element ref="common:Annotations" minOccurs="0"/>
					<xs:element name="Value" type="OBS_STATUS_ValueType" form="unqualified" minOccurs="1" maxOccurs="unbounded"/>
				</xs:sequence>
				<xs:attribute name="id" type="common:NCNameIDType" use="required" fixed="OBS_STATUS"/>
			</xs:restriction>
		</xs:complexContent>
	 */
	private boolean writeCompAttributeElement(ComponentSuperBean<ComponentBean> comp) throws XMLStreamException {
		super.addComplexTypeForRestriction(comp.getId()+"_ATTRIBUTE", "dsd:CompType");
		writer.writeStartElement(SCHEMA_NS, "sequence");
		
		addAnnotations();

		RepresentationBean rep = comp.getBuiltFrom().getRepresentation();
		if(rep == null) {
			ConceptBean concept = comp.getConcept().getBuiltFrom();
			rep =concept.getRepresentation();
		}
		int minOccurs = rep == null || rep.getMinOccurs() == null ? 0 : rep.getMinOccurs();
		int maxOccurs = rep == null || rep.getMaxOccurs() == null ? 1 : rep.getMaxOccurs();
		String typeRef = getComplexTypeRef(comp);
		boolean requiresComplexType = typeRef == null;
		if(requiresComplexType) {
			typeRef = comp.getId()+"_ValueType";
		}
		
		//<xs:element name="Value" type="OBS_STATUS_ValueType" form="unqualified" minOccurs="1" maxOccurs="unbounded"/>
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", "Value");
		writer.writeAttribute("type", typeRef);
		writer.writeAttribute("form", "unqualified");
		writer.writeAttribute("minOccurs", Integer.toString(minOccurs));
		if(maxOccurs == Integer.MAX_VALUE) {
			writer.writeAttribute("maxOccurs", "unbounded");
		} else {
			writer.writeAttribute("maxOccurs", Integer.toString(maxOccurs));
		}
		writer.writeEndElement();  //end element name=Value 
		writer.writeEndElement();    //End sequence
		
		//<xs:attribute name="id" type="common:NCNameIDType" use="required" fixed="OBS_STATUS"/>
		writer.writeStartElement(SCHEMA_NS, "attribute");
		writer.writeAttribute("name", "id");
		writer.writeAttribute("type", "common:NCNameIDType");
		writer.writeAttribute("use", "required");
		writer.writeAttribute("fixed", comp.getId());
		writer.writeEndElement();  //end attribute
		
		endComplexType(writer);
		return requiresComplexType;
	}

	void processUncodedWithRestriction(String componentId, TextFormatBean tx) throws XMLStreamException {
		if (tx == null) {
			return;
		}
		writer.writeStartElement(SCHEMA_NS, "simpleType");
		writer.writeAttribute("name", componentId);
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", determineSchemaType(tx, tx.getTextType()));
		addTextFormat(tx);
		writer.writeEndElement();	// End restriction
		writer.writeEndElement();	// End simpleType
	}

	@Override
	void addComponentBean(ComponentSuperBean componentBean) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "attribute");
		writer.writeAttribute("name", componentBean.getId());
		if(componentBean.getBuiltFrom().getStructureType() == SDMX_STRUCTURE_TYPE.TIME_DIMENSION) {
			//Do nothing as time period is already part of the schema
		} else if(componentBean.getCodelist(true) == null) {
			TextFormatBean textFormat = componentBean.getTextFormat();
			if (textFormat == null) {
				writer.writeAttribute("type", "xs:string");
			} else if (textFormat.hasRestrictions()) {
				writer.writeAttribute("type", componentBean.getId());
			} else {
				TEXT_TYPE textType = textFormat.getTextType();
				writer.writeAttribute("type", determineSchemaType(textFormat, textType) );
			}
		} else {
			writer.writeAttribute("type", getCodelistReference(componentBean));
		}
	}

	@Override
	void addAnnotations() throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("ref", "common:Annotations");
		writer.writeAttribute("minOccurs", "0");	
		writer.writeEndElement();	
	}

	/**
	 * prohibit the inheritance of this from the base schema if necessary
	 */
	private void prohibitReportingYearStartDay() throws XMLStreamException {
		if(dsd.getComponentById("REPORTING_YEAR_START_DAY") == null) {
			writer.writeStartElement(SCHEMA_NS, "attribute");
			writer.writeAttribute("name", "REPORTING_YEAR_START_DAY");
			writer.writeAttribute("type", "xs:gMonthDay");
			writer.writeAttribute("use", "prohibited");
			writer.writeEndElement();
		}
	}


	/**
	 * prohibit the inheritance of this from the base schema if necessary
	 */
	private void prohibitTimePeriod(boolean force) throws XMLStreamException {
		if(force || dsd.getTimeDimension() == null) {
			writer.writeStartElement(SCHEMA_NS, "attribute");
			writer.writeAttribute("name", DimensionBean.TIME_DIMENSION_FIXED_ID);
			writeTimePeriodType();
			writer.writeAttribute("use",  "prohibited");
			writer.writeEndElement();
		}
	}
}