package io.sdmx.format.ml.engine.metadata.v21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.IMSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataAttributeMutableBean;
import io.sdmx.api.sdmx.model.mutable.refmetadata.IReportedMetadataSetMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.core.sdmx.api.engine.metadata.IMetadataReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataAttributeMutableBean;
import io.sdmx.im.mutable.refmetadata.ReportedMetadataSetMutableBean;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class SdmxMLMetadataSetReaderEngineV21 implements IMetadataReaderEngine {
	private SdmxBeanRetrievalManager brm;
	
	public SdmxMLMetadataSetReaderEngineV21(SdmxBeanRetrievalManager brm) {
		this.brm = brm;
	}

	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) { 
		IReferenceMetadataContainer returnContainer = new ReferenceMetadataContainer();
		IStaxReader reader = new StaxReader(rdl);
		
		Map<String, IURNSingle<? extends IMSDRelatedBean>> sRefMap = Collections.emptyMap();
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				String elementName = reader.getElementName(); 
				if("Header".equals(elementName)) {
					sRefMap = parseHeader(reader);
				} else if("MetadataSet".equals(elementName)) {
					parseMetadataSets(reader, sRefMap, returnContainer);
				}
			} 
		}
		return returnContainer;
	}
	
	private Map<String, IURNSingle<? extends IMSDRelatedBean>> parseHeader(IStaxReader reader) {
		Map<String, IURNSingle<? extends IMSDRelatedBean>> returnMap = new HashMap<>();
		String structureId = null;
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				String elementName = reader.getElementName(); 
				if("Structure".equals(elementName) && reader.getAttributeValue("structureID") != null) {
					structureId = reader.getAttributeValue("structureID");
				} else if("URN".equals(elementName)) {
					returnMap.put(structureId, URN.builder(reader.getElementText()).buildSingle(IMSDRelatedBean.class));
				}
			} else {
				if("Header".equals(reader.getElementName())) {
					return returnMap;
				}
			}
		}
		return returnMap;
	}
	
	private void parseMetadataSets(IStaxReader reader, Map<String, IURNSingle<? extends IMSDRelatedBean>> sRefMap, IReferenceMetadataContainer returnContainer) { 
		IReportedMetadataSetMutableBean mds = new ReportedMetadataSetMutableBean();
		String sAlias = reader.getAttributeValue("structureRef");
		if(sAlias == null) {
			throw new SdmxSemmanticException("Can not read Metadata Set XML Document, structureRef attribute missing on MetadataSet");
		}
		IURNSingle<? extends IMSDRelatedBean> sRef = sRefMap.get(sAlias);
		if(sRef == null) {
			throw new SdmxSemmanticException("Can not read Metadata Set XML Document, structureRef='"+sAlias+"' does not correspond to any structureID in Header");
		}
		if(sRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.MSD) {
			for(MetadataFlowBean flow : this.brm.getMaintainableBeans(URN.build(MetadataFlowBean.class))) {
				if(sRef.isMatch(flow.getMetadataStructureRef().getReference())) {
					sRef = flow.getURN();
					break;
				}
			}
		}
		if(sRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.MSD) {
			throw new SdmxSemmanticException("No Metadataflow found for MSD: "+sRef.getURN());
		}

		mds.setStructure(sRef.asMutable());
		mds.setAgencyId(sRef.getAgencyId());
		mds.setVersion(sRef.getVersion());
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				StaxNameableUtil.processNode(mds, reader);
				String elementName = reader.getElementName(); 
				if("Report".equals(elementName)) {
					parseMetadataReport(reader, mds);
				}
			} else {
				if("MetadataSet".equals(reader.getElementName())) {
					StringBuilder sb = new StringBuilder();
					sb.append(mds.getId());
					for(StructureReferenceBean currentTarget: mds.getTargets()) {
						sb.append("_"+currentTarget.getMaintainableId());
					}
					mds.setId(sb.toString());
					returnContainer.addReferenceMetadata(mds.getImmutableInstance());
					return;
				}
			}
		}
	}
	
	private void parseMetadataReport(IStaxReader reader, IReportedMetadataSetMutableBean mds) { 
		mds.setId(reader.getAttributeValue("id"));
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				String elementName = reader.getElementName(); 
				if("Target".equals(elementName)) {
					parseTarget(reader, mds);
				}
				if("AttributeSet".equals(elementName)) {
					mds.setAttributes(parseAttributeSet(reader));
				}
			} else {
				if("Report".equals(reader.getElementName())) {
					return;
				}
			}
		}
	}
	
	private void parseTarget(IStaxReader jReader, IReportedMetadataSetMutableBean mds) { 
		while(jReader.moveNextNode()) {
			if(jReader.isStartElement()) {
				if("URN".equals(jReader.getElementName())) {
					String urn = jReader.getElementText();
					mds.addTarget(StructureReferenceBeanImpl.buildAndVerify(urn));
				}
			} else {
				if("Target".equals(jReader.getElementName())) {
					return;
				}
			}
		}
	}
	
	private List<IReportedMetadataAttributeMutableBean> parseAttributeSet(IStaxReader reader) { 
		List<IReportedMetadataAttributeMutableBean> reportedAttributes = new ArrayList<>();
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				String elementName = reader.getElementName(); 
				if("ReportedAttribute".equals(elementName)) {
					reportedAttributes.add(parseReportedAttribute(reader));
				}
			} else {
				if("AttributeSet".equals(reader.getElementName())) {
					return reportedAttributes;
				}
			}
		}
		return reportedAttributes;
	}
	
	private IReportedMetadataAttributeMutableBean parseReportedAttribute(IStaxReader reader) { 
		IReportedMetadataAttributeMutableBean reportedAttribute = new ReportedMetadataAttributeMutableBean();
		reportedAttribute.setId(reader.getAttributeValue("id"));
		reportedAttribute.setValue(reader.getAttributeValue("value"));
		
		while(reader.moveNextNode()) {
			if(reader.isStartElement()) {
				String elementName = reader.getElementName(); 
				if("AttributeSet".equals(elementName)) {
					reportedAttribute.setAttributes(parseAttributeSet(reader));
				}
				if("StructuredText".equals(elementName)) {
					String lang = StaxStructureUtil.getLangLocale(reader);
					String value = reader.getElementText();
					reportedAttribute.addStructuredValue(lang, value);
				}
			} else {
				if("ReportedAttribute".equals(reader.getElementName())) {
					return reportedAttribute;
				}
			}
		}
		return reportedAttribute;
	}
	
}
