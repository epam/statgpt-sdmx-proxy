package io.sdmx.format.ml.engine.structure.writer.v21.reportingtaxonomy;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingCategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.ReportingTaxonomyBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxReportingTaxonomyWriterEngineV21 extends AbstractV21Writer<ReportingTaxonomyBean> implements IFusionSingleton {
	private static StaxReportingTaxonomyWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxReportingTaxonomyWriterEngineV21() {}

	public static StaxReportingTaxonomyWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxReportingTaxonomyWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ReportingTaxonomy";
	}

	@Override
	protected void writeMaintainableInternal(ReportingTaxonomyBean maint, StaxWriter writer) {
		writeCategories(maint.getItems(), writer);
	}

	private void writeCategories(List<ReportingCategoryBean> categories, StaxWriter writer) {
		for(ReportingCategoryBean cat : categories) {
			StaxNameableWriterUtil.writeBean(cat, "ReportingCategory", writer);
			writeCategories(cat.getItems(), writer);
			StaxRefUtil.writeReferences(cat.getStructuralMetadata(), writer, "StructuralMetadata");
			StaxRefUtil.writeReferences(cat.getProvisioningMetadata(), writer, "ProvisioningMetadata");
			writer.writeEndElement(); //End ReportingCategory
		}
	}
}
