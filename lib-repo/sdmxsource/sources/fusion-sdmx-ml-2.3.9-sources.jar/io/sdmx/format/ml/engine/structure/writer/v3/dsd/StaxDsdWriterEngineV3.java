package io.sdmx.format.ml.engine.structure.writer.v3.dsd;

import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean.COMPONENT_TYPE;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureDimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxIdentifiableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRepresentationWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDsdWriterEngineV3 extends AbstractV3Writer<DataStructureBean> implements IFusionSingleton {
	private static StaxDsdWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDsdWriterEngineV3() {}

	public static StaxDsdWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDsdWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "DataStructure";
	}

	@Override
	protected void writeMaintainableInternal(DataStructureBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writer.writeStartElement(NS, "DataStructureComponents");
		writeDimensionList(maint.getDimensionList(), externalLinks, writer);
		writeGroups(maint.getGroups(), externalLinks, writer);
		writeAttributeList(maint.getAttributeList(), externalLinks, writer);
		writeMeasureList(maint.getMeasureList(), externalLinks, writer);
		writer.writeEndElement(); //End DataStructureComponents
		
		if(maint.getMSDRef() != null) {
			StaxRefUtilV3.writeReference(maint.getMSDRef(), writer, "Metadata");
		}
	}

	private void writeDimensionList(DimensionListBean dimList, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		if(dimList == null) {
			return;
		}
		StaxIdentifiableWriterUtilV3.writeBean(dimList, "DimensionList", externalLinks, writer);
		int pos = 0;
		for(DimensionBean dim : dimList.getDimensions()) {
			pos++;
			if(dim.isTimeDimension()) {
				writer.writeStartElement(NS, "TimeDimension");
				writeComponent(dim, externalLinks, writer, null, null);
			} else {
				writer.writeStartElement(NS, "Dimension");
				writeComponent(dim, externalLinks, writer, "position", Integer.toString(pos));
				if(dim.getConceptScheme() != null) {
					writer.writeStartElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), "LocalRepresentation");
					StaxRefUtilV3.writeReference(dim.getConceptScheme(), writer, "Enumeration");
					writer.writeEndElement();
				}
			}
			for(ICrossReferenceBean<ConceptBean> conceptRole : dim.getConceptRole()) {
				StaxRefUtilV3.writeReference(conceptRole, writer, "ConceptRole");
			}
			writer.writeEndElement(); //End [X]Dimension
		}
		writer.writeEndElement(); //End DimensionList
	}


	private void writeComponent(ComponentBean comp, IExternalMaintainableLinks externalLinks, StaxWriter writer, String attrId, String attrVal) {
		Map<String, String> attributes = StaxIdentifiableWriterUtilV3.getAttributes(comp);
		if(attrId != null) {
			attributes.put(attrId, attrVal);
		}
		writer.writeAttributes(attributes);
		StaxAnnotableWriterUtilV3.writeBean(comp, writer);
		StaxRefUtilV3.writeReference(comp.getConceptRef(), writer, "ConceptIdentity");
		if(comp.getRepresentation() != null) {
			boolean incMultiLingual = (comp.getType() != COMPONENT_TYPE.DIMENSION);
			StaxRepresentationWriterUtilV3.writeRepresentation(comp.getRepresentation(), writer, "LocalRepresentation", false, incMultiLingual); 
		}
	}
	

	private void writeMeasureList(MeasureListBean measList, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		if(measList == null) {
			return;
		}
		StaxIdentifiableWriterUtilV3.writeBean(measList, "MeasureList", externalLinks, writer);
		for(MeasureDimensionBean measure : measList.getMeasures()) {
			writer.writeStartElement(NS, "Measure");
			String status = measure.isMandatory() ? "mandatory" : "optional";
			writeComponent(measure, externalLinks, writer, "usage", status);
			writer.writeEndElement(); //End Measure
		}
		writer.writeEndElement(); //End MeasureList
	}

	private void writeGroups(List<GroupBean> groups, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		if(ObjectUtil.validCollection(groups)) {
			for(GroupBean groupBean : groups) {
				StaxIdentifiableWriterUtilV3.writeBean(groupBean, "Group", externalLinks, writer);
				for(String dimRef : groupBean.getDimensionRefs()) {
					writer.writeStartElement(NS, "GroupDimension");
					StaxRefUtilV3.writeLocalReference(dimRef, writer, "DimensionReference");
					writer.writeEndElement();
				}
				writer.writeEndElement(); //End Group
			}
		}
	}

	private void writeAttributeList(AttributeListBean attrList, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		if(attrList == null || attrList.getAttributes() == null || attrList.getAttributes().size() == 0) {
			return;
		}
		StaxIdentifiableWriterUtilV3.writeBean(attrList, "AttributeList", externalLinks, writer);
		for(AttributeBean attr : attrList.getAttributes()) {
			writer.writeStartElement(NS, "Attribute");

			String statusStr = attr.isMandatory()? "mandatory" : "optional";
			writeComponent(attr, externalLinks, writer, "usage", statusStr); 
			
			for(ICrossReferenceBean conceptRole : attr.getConceptRoles()) {
				StaxRefUtilV3.writeReference(conceptRole, writer, "ConceptRole");
			}
			writer.writeStartElement(NS, "AttributeRelationship");
			switch(attr.getAttachmentLevel()) {
			case DATA_SET:
				writer.writeStartElement(NS, "Dataflow");
				writer.writeEndElement(); //End Dataflow
				break;
			case DIMENSION_GROUP:
				for(String dimRef : attr.getDimensionReferences()) {
					StaxRefUtilV3.writeLocalReference(dimRef, writer, "Dimension");
				}
				break;
			case GROUP:
				StaxRefUtilV3.writeLocalReference(attr.getAttachmentGroup(), writer, "Group");
				break;
			case OBSERVATION:
				if(ObjectUtil.validCollection(attr.getDimensionReferences())) {
					for(String dimRef : attr.getDimensionReferences()) {
						StaxRefUtilV3.writeLocalReference(dimRef, writer, "Dimension");
					}
				} else {
					writer.writeStartElement(NS, "Observation");
					writer.writeEndElement(); //End Observation
				}
				break;
			}
			writer.writeEndElement(); //End AttributeRelationship
			if(ObjectUtil.validCollection(attr.getMeasureReferences())) {
				writer.writeStartElement(NS, "MeasureRelationship");
				for(String dimRef : attr.getMeasureReferences()) {
					StaxRefUtilV3.writeLocalReference(dimRef, writer, "Measure");
				}
				writer.writeEndElement(); //End MeasureRelationship
			}
			writer.writeEndElement(); //End Attribute
		}
		writer.writeEndElement(); //End AttributeList
	}

}
