package io.sdmx.format.ml.engine.structure.writer.v3.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationUnitSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxContactWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxOrgUnitSchemeWriterEngineV3 extends AbstractV3Writer<OrganisationUnitSchemeBean> implements IFusionSingleton {
	private static StaxOrgUnitSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxOrgUnitSchemeWriterEngineV3() {}

	public static StaxOrgUnitSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxOrgUnitSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "OrganisationUnitScheme";
	}

	@Override
	protected void writeMaintainableInternal(OrganisationUnitSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(OrganisationUnitBean org : maint.getItems()) {
			StaxNameableWriterUtilV3.writeBean(org, "OrganisationUnit", externalLinks, writer);
			StaxRefUtilV3.writeLocalReference(org.getParentUnit(), writer, "Parent");
			StaxContactWriterUtilV3.writeContact(org.getContacts(), writer);
			writer.writeEndElement(); //End Org
		}
	}

}
