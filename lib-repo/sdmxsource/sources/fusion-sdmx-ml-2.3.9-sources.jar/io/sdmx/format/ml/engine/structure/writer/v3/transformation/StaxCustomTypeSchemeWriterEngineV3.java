package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeBean;
import io.sdmx.api.sdmx.model.beans.transformation.ICustomTypeSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCustomTypeSchemeWriterEngineV3 extends StaxAbstractVTLSchemeWriterEngineV3<ICustomTypeSchemeBean> implements IFusionSingleton {
	private static StaxCustomTypeSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCustomTypeSchemeWriterEngineV3() {}

	public static StaxCustomTypeSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCustomTypeSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CustomTypeScheme";
	}

	@Override
	protected void writeMaintainableInternal(ICustomTypeSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
	}

	private void writeItems(List<ICustomTypeBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ICustomTypeBean item : items) {
			StaxNameableWriterUtilV3.writeBean(item, "CustomType", externalLinks, writer);
			if(item.getVtlScalarType() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlScalarType", item.getVtlScalarType());
			}
			if(item.getDataType() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "DataType", item.getDataType());
			}
			if(item.getVtlLiteralFormat() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "VtlLiteralFormat", item.getVtlLiteralFormat());
			}
			if(item.getOutputFormat() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "OutputFormat", item.getOutputFormat());
			}
			if(item.getNullValue() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "NullValue", item.getNullValue());
			}
			writer.writeEndElement();
		}
	}
}
