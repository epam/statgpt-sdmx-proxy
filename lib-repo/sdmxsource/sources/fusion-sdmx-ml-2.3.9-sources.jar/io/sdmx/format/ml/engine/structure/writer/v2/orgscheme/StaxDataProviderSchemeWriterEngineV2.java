package io.sdmx.format.ml.engine.structure.writer.v2.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxDataProviderSchemeWriterEngineV2 extends StaxAbstractOrganisationSchemeWriterEngineV2<DataProviderSchemeBean, DataProviderBean> implements IFusionSingleton {
	private static StaxDataProviderSchemeWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDataProviderSchemeWriterEngineV2() {}

	public static StaxDataProviderSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDataProviderSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "OrganisationScheme";
	}

	@Override
	protected String getOrgNodeName() {
		return "DataProvider";
	}

	@Override
    protected String getGroupNodeName() {
        return "DataProviders";
    }


}
