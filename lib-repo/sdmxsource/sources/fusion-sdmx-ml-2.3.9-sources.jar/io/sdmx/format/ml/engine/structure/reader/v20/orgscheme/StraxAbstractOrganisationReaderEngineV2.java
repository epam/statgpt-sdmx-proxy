package io.sdmx.format.ml.engine.structure.reader.v20.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.OrganisationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;

public abstract class StraxAbstractOrganisationReaderEngineV2 implements IFusionSingleton {

    protected void analyseOrganisation(IStaxReader reader, OrganisationMutableBean anOrg) {
        StaxIdentifiableUtil.processAttributes(anOrg, reader);
        reader.moveNextNode();
        while(StaxNameableUtil.processNode(anOrg, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }
        while (reader.getElementName().equals("MaintenanceContact") ||
                reader.getElementName().equals("CollectorContact") ||
                reader.getElementName().equals("DisseminatorContact") ||
                reader.getElementName().equals("ReporterContact") ||
                reader.getElementName().equals("OtherContact")) {
            // ignore this entire node
            reader.skipToEndNode(reader.getElementName());
            reader.moveNextNode();
        }
        if(reader.getElementName().equals("Annotations")) {
            StaxAnnotableUtil.processAnnotations(anOrg, reader);
            reader.moveNextNode(); //Move to the start/end of the next node
        }
    }
    
}
