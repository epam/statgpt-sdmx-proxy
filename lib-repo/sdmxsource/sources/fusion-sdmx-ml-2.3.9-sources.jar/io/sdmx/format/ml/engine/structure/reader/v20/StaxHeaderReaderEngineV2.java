package io.sdmx.format.ml.engine.structure.reader.v20;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.header.DatasetStructureReferenceBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.api.sdmx.model.mutable.base.ContactMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxContactUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.beans.base.ContactBeanImpl;
import io.sdmx.im.beans.base.TextTypeWrapperImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.header.PartyBeanImpl;
import io.sdmx.im.mutable.base.ContactMutableBeanImpl;
import io.sdmx.utils.core.date.DateUtil;

public class StaxHeaderReaderEngineV2 {

	public static HeaderBean readerHeader(IStaxReader reader) {
		//All the attributes required to build a header
		Map<String, String> additionalAttributes = new HashMap<>();
		IURNSingle<DataProviderBean> dataProviderReference = null;
		List<DatasetStructureReferenceBean> structure = new ArrayList<>();
		DATASET_ACTION datasetAction = null; 
		String id = null; 
		List<TextTypeWrapper>  name = new ArrayList<>();
		List<TextTypeWrapper> source = new ArrayList<>();
		List<PartyBean> receiver = new ArrayList<>(); 
		PartyBean sender = null; 
		boolean test = false;
		Date prepared = null;

		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("ID")) {
					id = reader.getElementText();
				} else if(nodeName.equals("Test")) {
					test = Boolean.valueOf(reader.getElementText());
				} else if(nodeName.equals("Prepared")) {
					prepared = DateUtil.formatDate(reader.getElementText(), true);
				} else if(nodeName.equals("Sender")) {
					sender = processParty(reader);
				} else if(nodeName.equals("Receiver")) {
					receiver.add(processParty(reader));
				}  else if(nodeName.equals("Name")) {
					name.add(new TextTypeWrapperImpl(StaxStructureUtil.getText(reader), "Name", null));
				} else if(nodeName.equals("Source")) {
					source.add(new TextTypeWrapperImpl(StaxStructureUtil.getText(reader), "Source", null));
				} else if(nodeName.equals("Truncated")) {
					//Ignore - deprecated
				} else if(nodeName.equals("KeyFamilyRef")) {
					//Ignore
				} else if(nodeName.equals("KeyFamilyAgency")) {
					//Ignore
				} else if(nodeName.equals("DataSetAgency")) {
					//Ignore
				} else if(nodeName.equals("DataSetID")) {
					//Ignore
				} else if(nodeName.equals("DataSetAction")) {
					datasetAction = DATASET_ACTION.getAction(reader.getElementText());
				} else if(nodeName.equals("Extracted")) {
					//Ignore
				} else if(nodeName.equals("ReportingBegin")) {
					//Ignore
				} else if(nodeName.equals("ReportingEnd")) {
					//Ignore
				}  else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("Header")) {
				break;
			}
		}

		return new HeaderBeanImpl(additionalAttributes, 
				structure, 
				dataProviderReference, 
				datasetAction, 
				id, 
				null, 
				null, 
				null, 
				prepared, 
				null, 
				null, 
				name, 
				source, 
				receiver, 
				sender, 
				test);
	}

	private static PartyBean processParty(IStaxReader reader) {
		String id = StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true);
		String exitNode = reader.getElementName();

		List<TextTypeWrapper> name = null;
		List<ContactBean> contacts = null;
		String timeZone = null;
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Name")) {
					if(name == null) {
						name= new ArrayList<>();
					}
					name.add(new TextTypeWrapperImpl(StaxStructureUtil.getText(reader), "Name", null));
				} else if(nodeName.equals("Contact")) {
					if(contacts == null) {
						contacts= new ArrayList<>();
					}
					contacts.add(processContact(reader));
				} else if(nodeName.equals("Timezone")) {
					timeZone = reader.getElementText();
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}

			} else if(nodeName.equals(exitNode)) {
				break;
			}
		}
		return new PartyBeanImpl(name, id, contacts, timeZone);
	}

	private static ContactBean processContact(IStaxReader reader) {
		ContactMutableBean contact = new ContactMutableBeanImpl();
		StaxContactUtil.processBean(contact, reader);
		return new ContactBeanImpl(contact);
	}

}
