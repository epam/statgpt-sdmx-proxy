package io.sdmx.format.ml.api.manager;

import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;

public interface RegistrationParsingManager {

	/**
	 * Process a SMDX document to retrieve the Registrations, these can either be in
	 * a QueryRegistrationResponse message or inside a SubmitRegistrationRequest message
	 * @param dataLocation
	 * @return
	 */
	List<RegistrationInformation> parseRegistrations(ReadableDataLocation dataLocation);
	
}
