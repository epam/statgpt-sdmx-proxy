package io.sdmx.format.ml.engine.structure.writer.v3.mapping;

import java.util.List;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedRelationshipBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IMappedValueBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IRepresentationMapRefBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRepresentationMapWriterEngineV3 extends AbstractV3Writer<IRepresentationMapBean> implements IFusionSingleton {
	private static StaxRepresentationMapWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRepresentationMapWriterEngineV3() {}

	public static StaxRepresentationMapWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRepresentationMapWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "RepresentationMap";
	}

	@Override
	protected void writeMaintainableInternal(IRepresentationMapBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(IRepresentationMapRefBean ref : maint.getSourceRef()) {
			if(ref.getEnumerationRef() != null) {
				StaxRefUtilV3.writeReference(ref.getEnumerationRef(), writer, "SourceCodelist");
			} else {
				writer.writeElement(NS, "SourceDataType", ref.getTextType().getSdmx21Value());
			}
		}
		for(IRepresentationMapRefBean ref : maint.getTargetRef()) {
			if(ref.getEnumerationRef() != null) {
				StaxRefUtilV3.writeReference(ref.getEnumerationRef(), writer, "TargetCodelist");
			} else {
				writer.writeElement(NS, "TargetDataType", ref.getTextType().getSdmx21Value());
			}
		}
		writeMappedValues(maint.getMappedValues(), writer);
	}
	
	private void writeMappedValues(List<IMappedRelationshipBean> maps, StaxWriter writer) {
		for(IMappedRelationshipBean map : maps) {
			writer.writeStartElement(NS, "RepresentationMapping");
			writeMappedValue(map, writer);
			writer.writeEndElement(); //End RepresentationMapping
		}
	}
	
	private void writeMappedValue(IMappedRelationshipBean map, StaxWriter writer) {
		if(map.getValidityPeriod() != null) {
			SdmxPeriod period = map.getValidityPeriod();
			if(period.hasStartPeriod()) {
				//NOTE SDMX Schema for 3.0 expects a full date, 2008 is invalid, 2008-01-01 is okay
				writer.writeAttribute("validFrom", DateUtil.formatDate(period.getStartPeriod().getDate(), TIME_FORMAT.DATE));
			}
			if(period.hasEndPeriod()) {
				//NOTE SDMX Schema for 3.0 expects a full date, 2008 is invalid, 2008-12-31 is okay
				writer.writeAttribute("validTo", DateUtil.formatDate(period.getEndPeriod().getDate(), TIME_FORMAT.DATE));
			}
		}
		StaxAnnotableWriterUtilV3.writeBean(map, writer);
		writeSourceValues(map.getSourceValue(), writer);
		for(String target : map.getTargetValue()) {
			// A target value can be null or blank, so ensure that the writer actually writes the value
			writer.writeElementAllowBlank(NS, "TargetValue", target);
		}
	}
	
	private void writeSourceValues(List<IMappedValueBean> sourceValues, StaxWriter writer) {
		for(IMappedValueBean map : sourceValues) {
			writer.writeStartElement(NS, "SourceValue");
			writeSourceValue(map, writer);
			writer.writeEndElement(); //End SourceValue
		}
	}
	
	private void writeSourceValue(IMappedValueBean sourceValue, StaxWriter writer) {
		if(sourceValue.isRegEx()) {
			writer.writeAttribute("isRegEx", sourceValue.isRegEx());
		}
		if(sourceValue.getStartIndex() > 0) {
			writer.writeAttribute("startIndex", sourceValue.getStartIndex());
		}
		if(sourceValue.getEndIndex() > 0) {
			writer.writeAttribute("endIndex", sourceValue.getEndIndex());
		}
		writer.writeElementText(sourceValue.getValue());
	}
}
