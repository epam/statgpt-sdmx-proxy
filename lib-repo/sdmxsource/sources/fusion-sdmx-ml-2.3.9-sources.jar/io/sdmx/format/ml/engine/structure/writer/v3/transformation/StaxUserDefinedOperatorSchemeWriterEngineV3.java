package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorBean;
import io.sdmx.api.sdmx.model.beans.transformation.IUserDefinedOperatorSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxUserDefinedOperatorSchemeWriterEngineV3 extends StaxAbstractVTLSchemeWriterEngineV3<IUserDefinedOperatorSchemeBean> implements IFusionSingleton {
	private static StaxUserDefinedOperatorSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxUserDefinedOperatorSchemeWriterEngineV3() {}

	public static StaxUserDefinedOperatorSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxUserDefinedOperatorSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "UserDefinedOperatorScheme";
	}

	@Override
	protected void writeMaintainableInternal(IUserDefinedOperatorSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
		if(maint.getVtlMappingSchemeRef() != null) {
			StaxRefUtilV3.writeReference(maint.getVtlMappingSchemeRef(), writer, "VtlMappingScheme");
		}
		if(maint.getRulesetSchemeRef() != null) {
			for(ICrossReferenceBean ref : maint.getRulesetSchemeRef()) {
				StaxRefUtilV3.writeReference(ref, writer, "RulesetScheme");
			}
		}
	}

	private void writeItems(List<IUserDefinedOperatorBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(IUserDefinedOperatorBean item : items) {
			StaxNameableWriterUtilV3.writeBean(item, "UserDefinedOperator", externalLinks, writer);
			if(item.getOperatorDefinition() != null) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "OperatorDefinition", item.getOperatorDefinition());
			}
			writer.writeEndElement();
		}
	}
}
