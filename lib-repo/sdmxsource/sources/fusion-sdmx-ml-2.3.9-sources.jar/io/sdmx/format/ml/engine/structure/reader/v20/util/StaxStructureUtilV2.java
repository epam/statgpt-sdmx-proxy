package io.sdmx.format.ml.engine.structure.reader.v20.util;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.api.sdmx.model.mutable.categoryscheme.CategorisationMutableBean;
import io.sdmx.im.mutable.categoryscheme.CategorisationMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;

public class StaxStructureUtilV2 {

    /**
     * Creates a CategorisationBean from the supplied Mutable and structure reference
     * @param maintBean
     * @param catRef
     * @return
     */
    public static CategorisationBean createCategorisation(MaintainableMutableBean maintBean, StructureReferenceBean catRef, SDMX_STRUCTURE_TYPE strucType) {
        CategorisationMutableBean catMut = new CategorisationMutableBeanImpl();

        StructureReferenceBean dfRef = new StructureReferenceBeanImpl(maintBean.getAgencyId(), maintBean.getId(), maintBean.getVersion(), strucType);
        catMut.setStructureReference(dfRef);
        catMut.setCategoryReference(catRef);

        catMut.setNames(maintBean.getNames());

        catMut.setAgencyId(maintBean.getAgencyId());

        return catMut.getImmutableInstance();
    }

    public static StructureReferenceBean obtainKeyFamilyRefForDSD(IStaxReader reader) {
        return obtainKeyFamilyRef(reader,
                "KeyFamilyRef",
                "KeyFamilyID",
                "KeyFamilyAgencyID",
                SDMX_STRUCTURE_TYPE.DSD);
    }

    public static StructureReferenceBean obtainKeyFamilyRefForMSD(IStaxReader reader) {
        return obtainKeyFamilyRef(reader,
                "MetadataStructureRef",
                "MetadataStructureID",
                "MetadataStructureAgencyID",
                SDMX_STRUCTURE_TYPE.MSD);
    }

    private static StructureReferenceBean obtainKeyFamilyRef(IStaxReader reader,
            String elementStartName,
            String elementId,
            String elementAgencyId,
            SDMX_STRUCTURE_TYPE structType) {
        String urn = null;
        String acyId = null;
        String id = null;
        String version = null;

        while (!(reader.getElementName().equals(elementStartName) && !reader.isStartElement())) {
            reader.moveNextNode();
            if (reader.getElementName().equals("URN")) {
                urn = reader.getElementText();
            } else if (reader.getElementName().equals(elementId)) {
                id = reader.getElementText();
            } else if (reader.getElementName().equals(elementAgencyId)) {
                acyId = reader.getElementText();
            } else if (reader.getElementName().equals("Version")) {
                version = reader.getElementText();
            }
        }

        if (ObjectUtil.validOneString(acyId, id, version)) {
            return new StructureReferenceBeanImpl(acyId, id, version, structType);
        }
        return new StructureReferenceBeanImpl(urn, structType);
    }

    public static StructureReferenceBean processCategoryRef(IStaxReader reader) {
        String urn = null;
        String acyId = null;
        String id = null;
        String version = null;
        List<String> identifiableIds = new ArrayList<>();

        while (reader.moveNextNode()) {
            if (reader.getElementName().equals("CategoryRef") && !reader.isStartElement()) {
                break;
            }
            if (reader.getElementName().equals("URN")) {
                urn = reader.getElementText();
            } else if (reader.getElementName().equals("CategorySchemeID")) {
                id = reader.getElementText();
            } else if (reader.getElementName().equals("CategorySchemeAgencyID")) {
                acyId = reader.getElementText();
            } else if (reader.getElementName().equals("CategorySchemeVersion")) {
                version = reader.getElementText();
            } else if (reader.getElementName().equals("CategoryID")) {
                // Walk the Category and potential sub-Categories creating a List of Identifiable IDs
                int count = 1;
                while(reader.moveNextNode()) {
                    if (reader.getElementName().contentEquals("ID") && reader.isStartElement()) {
                        identifiableIds.add(reader.getElementText());
                    }
                    if (reader.getElementName().contentEquals("CategoryID")) {
                        if (reader.isStartElement()) {
                            count++;
                        } else if (!reader.isStartElement()) {
                            count --;
                            if (count == 0) {
                                // Reached the end of the ORIGINAL CategoryID
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (ObjectUtil.validOneString(acyId, id, version)) {
            return new StructureReferenceBeanImpl(acyId, id, version, SDMX_STRUCTURE_TYPE.CATEGORY, identifiableIds.stream().toArray(String[]::new));
        }
        return new StructureReferenceBeanImpl(urn, SDMX_STRUCTURE_TYPE.CATEGORY);
    }

    public static StructureReferenceBean processCodelistRef(IStaxReader reader, String expectedStopNode) {
        return processRef(reader, expectedStopNode, SDMX_STRUCTURE_TYPE.CODE_LIST, "CodelistID");
    }

    public static StructureReferenceBean processConceptSchemeRef(IStaxReader reader, String expectedStopNode) {
        return processRef(reader, expectedStopNode, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, "ConceptSchemeID");
    }

    public static StructureReferenceBean processCategorySchemeRef(IStaxReader reader, String expectedStopNode) {
        return processRef(reader, expectedStopNode, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME, "CategorySchemeID");
    }

    public static StructureReferenceBean processOrganisationSchemeRef(IStaxReader reader, String expectedStopNode) {
        return processRef(reader, expectedStopNode, SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME, "OrganisationSchemeID");
    }

    private static StructureReferenceBean processRef(IStaxReader reader, String expectedStopNode, SDMX_STRUCTURE_TYPE type, String idNode) {
        String urn = null;
        String acyId = null;
        String id = null;
        String version = null;

        // TODO - what to do about alias here ?
        String alias = null;

        while (reader.moveNextNode()) {
            if (reader.getElementName().equals(expectedStopNode) && !reader.isStartElement()) {
                break;
            }
            if (reader.getElementName().equals("URN")) {
                urn = reader.getElementText();
            } else if (reader.getElementName().equals("AgencyID")) {
                acyId = reader.getElementText();
            } else if (reader.getElementName().equals(idNode)) {
                id = reader.getElementText();
            } else if (reader.getElementName().equals("Version")) {
                version = reader.getElementText();
            } else if (reader.getElementName().equals("Alias")) {
                alias = reader.getElementName();
            }
        }

        // As preference, use the AgencyId, ID, Version over URN
        if (ObjectUtil.validOneString(acyId, id, version)) {
            return new StructureReferenceBeanImpl(acyId, id, version, type);
        }
        return new StructureReferenceBeanImpl(urn, type);
    }
}
