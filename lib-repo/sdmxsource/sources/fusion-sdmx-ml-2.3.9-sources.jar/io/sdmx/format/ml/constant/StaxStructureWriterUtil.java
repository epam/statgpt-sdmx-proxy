package io.sdmx.format.ml.constant;

import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.utils.core.xml.Namespace;

public class StaxStructureWriterUtil {
	public static final Namespace XML_NS = new Namespace("http://www.w3.org/XML/1998/namespace", "xml");
	public static final Namespace MESSAGE_NS = new Namespace("http://www.sdmx.org/resources/sdmxml/schemas/v2_1/message", "mes");
	public static final Namespace STRCUTURE_NS = new Namespace("http://www.sdmx.org/resources/sdmxml/schemas/v2_1/structure", "str");
	public static final Namespace COMMON_NS = new Namespace("http://www.sdmx.org/resources/sdmxml/schemas/v2_1/common", "com");
	public static final Namespace REGISTRY_NS = new Namespace("http://www.sdmx.org/resources/sdmxml/schemas/v2_1/registry", "reg");
	
	public static final Namespace MESSAGE_NS_3_0 = new Namespace(SdmxConstants.MESSAGE_NS_3_0, "mes");
	public static final Namespace STRCUTURE_NS_3_0 = new Namespace(SdmxConstants.STRUCTURE_NS_3_0, "str");
	public static final Namespace COMMON_NS_3_0 = new Namespace(SdmxConstants.COMMON_NS_3_0, "com");
	public static final Namespace REGISTRY_NS_3_0 = new Namespace(SdmxConstants.REGISTRY_NS_3_0, "reg");
}
