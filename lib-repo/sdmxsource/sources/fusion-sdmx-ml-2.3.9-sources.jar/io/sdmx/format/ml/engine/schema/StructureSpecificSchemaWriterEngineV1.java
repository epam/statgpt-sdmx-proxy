package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.engine.SchemaWriterEngine;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.model.constraint.ConstrainedCodes;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;

public class StructureSpecificSchemaWriterEngineV1 implements SchemaWriterEngine {
	private static StructureSpecificSchemaWriterEngineV1 INSTANCE;

	public static StructureSpecificSchemaWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StructureSpecificSchemaWriterEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}


	@Override
	public void writeSchema(ConstrainedCodes validCodes, String dimensionAtObservation, boolean prettyPrint, OutputStream out) {
		SchemaLocationManager schemaLocation = SingletonStore.getSingleton(SchemaLocationManager.class);
		SDMX_SCHEMA schema = SDMX_SCHEMA.VERSION_ONE;
		CompactSchemaCreator schemaWriter = new CompactSchemaCreatorSdmx(validCodes, dimensionAtObservation, 
				schemaLocation.getSchemaLocation(schema), schema, out, prettyPrint);
		schemaWriter.createSchema();
	}

}
