package io.sdmx.format.ml.engine.structure.writer.v2.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxNameableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxStructureWriterUtilV2;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class StaxAbstractOrganisationSchemeWriterEngineV2<T extends OrganisationSchemeBean<Y>, Y extends OrganisationBean>  extends AbstractV2Writer<T> {

	@Override
	protected void writeMaintainableInternal(T maint, StaxWriter writer) {
	    if (maint.getItems().isEmpty()) {
	        return;
	    }

        writer.writeStartElement(StaxStructureWriterUtilV2.STRUCTURE_NS, this.getGroupNodeName());

        for(Y org : maint.getItems()) {
            StaxNameableWriterUtilV2.writeBean(org, getOrgNodeName(), writer);
//	          StaxContactWriterUtil.writeContact(org.getContacts(), writer);
            StaxAnnotableWriterUtilV2.writeBean(org, writer);
            writer.writeEndElement(); //End Org
        }
        writer.writeEndElement();  // End "Agencies" / "DataProviders" / "DataConsumers"
	}

	protected abstract String getOrgNodeName();

	protected abstract String getGroupNodeName();

}
