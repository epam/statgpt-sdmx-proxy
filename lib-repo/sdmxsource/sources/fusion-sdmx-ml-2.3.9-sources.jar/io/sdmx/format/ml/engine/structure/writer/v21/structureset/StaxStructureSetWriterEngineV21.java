package io.sdmx.format.ml.engine.structure.writer.v21.structureset;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.mapping.ComponentMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.ItemSchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.RelatedStructuresBean;
import io.sdmx.api.sdmx.model.beans.mapping.RepresentationMapRefBean;
import io.sdmx.api.sdmx.model.beans.mapping.SchemeMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureMapBean;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxAnnotableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxTextFormatWriterUtil;
import io.sdmx.im.beans.base.AnnotationBeanImpl;
import io.sdmx.im.mutable.base.AnnotationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxStructureSetWriterEngineV21 extends AbstractV21Writer<StructureSetBean> implements IFusionSingleton {
	private static StaxStructureSetWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxStructureSetWriterEngineV21() {}

	public static StaxStructureSetWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureSetWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "StructureSet";
	}

	@Override
	protected void writeMaintainableInternal(StructureSetBean maint, StaxWriter writer) {
		writeRelatedStructures(maint.getRelatedStructures(), writer);
		writeItemSchemeMap(maint.getOrganisationSchemeMapList(), "OrganisationSchemeMap", "OrganisationMap", writer);
		writeItemSchemeMap(maint.getCategorySchemeMapList(),"CategorySchemeMap" , "CategoryMap", writer);
		writeItemSchemeMap(maint.getCodelistMapList(), "CodelistMap", "CodeMap", writer);
		writeItemSchemeMap(maint.getConceptSchemeMapList(), "ConceptSchemeMap", "ConceptMap", writer);
		writeStructureMap(maint.getStructureMapList(), writer);

	}

	private void writeRelatedStructures(RelatedStructuresBean relatedStructuresBean, StaxWriter writer) {
		if(relatedStructuresBean != null) {
			StaxRefUtil.writeReferences(relatedStructuresBean.getCategorySchemeRef(), writer, "RelatedStructure");
			StaxRefUtil.writeReferences(relatedStructuresBean.getConceptSchemeRef(), writer, "RelatedStructure");
			StaxRefUtil.writeReferences(relatedStructuresBean.getDataStructureRef(), writer, "RelatedStructure");
			StaxRefUtil.writeReferences(relatedStructuresBean.getHierCodelistRef(), writer, "RelatedStructure");
			StaxRefUtil.writeReferences(relatedStructuresBean.getMetadataStructureRef(), writer, "RelatedStructure");
			StaxRefUtil.writeReferences(relatedStructuresBean.getOrgSchemeRef(), writer, "RelatedStructure");
		}
	}

	private void writeStructureMap(List<StructureMapBean> structureMaps, StaxWriter writer) {
		for(StructureMapBean structureMap : structureMaps) {
			writeSchemeMap(structureMap, "StructureMap", writer);
			for(ComponentMapBean compMap : structureMap.getComponents()) {
				writer.writeStartElement(NS, "ComponentMap");

				//FR-3298 BIS - Structure Mapping Enhancements - N-to-N Mapping
				//Store additional Source Concepts and Target Concepts as Annotations
				List<AnnotationBean> annotations = new ArrayList<>(compMap.getAnnotations());
				for(int i=1; i < compMap.getMapConceptRef().size(); i++) {
					AnnotationMutableBean annotation = new AnnotationMutableBeanImpl();
					annotation.setTitle("SOURCE");
					annotation.setId(compMap.getMapConceptRef().get(i));
					annotations.add(new AnnotationBeanImpl(annotation, null));
				}
				for(int i=1; i < compMap.getMapTargetConceptRef().size(); i++) {
					AnnotationMutableBean annotation = new AnnotationMutableBeanImpl();
					annotation.setTitle("TARGET");
					annotation.setId(compMap.getMapTargetConceptRef().get(i));
					annotations.add(new AnnotationBeanImpl(annotation, null));
				}
				StaxAnnotableWriterUtil.writeAnnotations(annotations, writer);

				writeRefHack(compMap.getMapConceptRef().get(0), writer, "Source");
				writeRefHack(compMap.getMapTargetConceptRef().get(0), writer, "Target");
				if(compMap.getRepMapRef() != null) {
					writer.writeStartElement(NS, "RepresentationMapping");
					RepresentationMapRefBean repMap = compMap.getRepMapRef();
					if(repMap.getCodelistMap() != null) {
						StaxRefUtil.writeLocalReference(repMap.getCodelistMap().getId(), writer, "CodelistMap");
					}
					StaxTextFormatWriterUtil.writeTextFormat(repMap.getToTextFormat(), writer, "ToTextFormat");
					if(repMap.getToValueType() != null) {
						switch(repMap.getToValueType()) {
						case DESCRIPTION:
							writer.writeElement(NS, "ToValueType", "Description");
							break;
						case NAME:
							writer.writeElement(NS, "ToValueType", "Name");
							break;
						case VALUE:
							writer.writeElement(NS, "ToValueType", "Value");
							break;
						}
					}
					if(ObjectUtil.validMap(repMap.getValueMappings())) {
						writer.writeStartElement(NS, "ValueMap");
						for(String source : repMap.getValueMappings().keySet()) {
							for(String target : repMap.getValueMappings().get(source)) {
								writer.writeStartElement(NS, "ValueMapping");
								writer.writeAttribute("source", source);
								writer.writeAttribute("target", target);
		 						writer.writeEndElement(); // End ValueMapping
							}
						}
 						writer.writeEndElement(); // End ValueMap
					}
					writer.writeEndElement(); // End RepresentationMapping
				}
				writer.writeEndElement(); // End ComponentMap
			}
			writer.writeEndElement(); // End StructureMap
		}
	}

	/**
	 * This type of Ref is completely stupid and not in keeping with every other ref in the schema
	 * as it expects a containerID and no agencyID - therefore don't use the generic reference method as it will
	 * create an invalid reference
	 */
	private void writeRefHack(String id, StaxWriter writer, String nodeName) {
		writer.writeStartElement(NS, nodeName);
		writer.writeStartElement(null, "Ref");  //No namespace
		writer.writeAttribute("containerID", "DimensionDescriptor");
		writer.writeAttribute("id", id);
		writer.writeAttribute("class", "Dimension");
		writer.writeAttribute("package", "datastructure");
		writer.writeEndElement(); //End Ref
		writer.writeEndElement(); //End nodeName

	}

	private void writeItemSchemeMap(List<? extends ItemSchemeMapBean<? extends ItemMapBean>> itemSchemes, String nodeName, String mapNodeName, StaxWriter writer) {
		for(ItemSchemeMapBean<? extends ItemMapBean> itemScheme : itemSchemes) {
			writeSchemeMap(itemScheme, nodeName, writer);
			for(ItemMapBean itemMap : itemScheme.getItems()) {
				writer.writeStartElement(NS, mapNodeName);
				StaxAnnotableWriterUtil.writeBean(itemMap, writer);
				StaxRefUtil.writeLocalReference(itemMap.getSourceId(), writer, "Source");
				StaxRefUtil.writeLocalReference(itemMap.getTargetId(), writer, "Target");
				writer.writeEndElement(); // End mapNodeName
			}
			writer.writeEndElement(); // End nodeName
		}
	}

	private void writeSchemeMap(SchemeMapBean itemScheme, String nodeName, StaxWriter writer) {
		if(itemScheme != null) {
			StaxNameableWriterUtil.writeBean(itemScheme, nodeName, writer);
			StaxRefUtil.writeReference(itemScheme.getSourceRef().getURN(), writer, "Source");
			StaxRefUtil.writeReference(itemScheme.getTargetRef().getURN(), writer, "Target");
		}
	}
}
