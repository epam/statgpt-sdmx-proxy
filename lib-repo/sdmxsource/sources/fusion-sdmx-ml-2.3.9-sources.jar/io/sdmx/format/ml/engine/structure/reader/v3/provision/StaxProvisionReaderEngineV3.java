package io.sdmx.format.ml.engine.structure.reader.v3.provision;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.registry.ProvisionAgreementMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.registry.ProvisionAgreementMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxProvisionReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<ProvisionAgreementMutableBean> {
	private static StaxProvisionReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxProvisionReaderEngineV3() {}

	public static StaxProvisionReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxProvisionReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
        return "ProvisionAgreements";
    }
    
    @Override
    protected String getRootNodeName() {
        return "ProvisionAgreement";
    }

    @Override
    protected ProvisionAgreementMutableBean processMaintainable(IStaxReader reader) {
		ProvisionAgreementMutableBean provisonAgreement = new ProvisionAgreementMutableBeanImpl();
		StaxMaintainableUtil.processBean(provisonAgreement, reader);
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("Dataflow")) {
				provisonAgreement.setStructureUsage(StaxStructureRefReaderV3.getStructureReference(reader,  SDMX_STRUCTURE_TYPE.DATAFLOW));
			} else if(elementName.equals("DataProvider")) {
				provisonAgreement.setDataproviderRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATA_PROVIDER));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return provisonAgreement;
	}
}
