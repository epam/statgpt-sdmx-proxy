package io.sdmx.format.ml.engine.structure.reader.v20.orgscheme;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.sdmx.model.mutable.base.DataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.DataProviderSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.im.mutable.base.DataProviderMutableBeanImpl;
import io.sdmx.im.mutable.base.DataProviderSchemeMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * In SDMX 2.0, AgencyBeans, DataConsumers and DataProviders are all under "OrganisationScheme"
 * Simply process each type in this class
 */
public class StaxDataProviderSchemeReaderEngineV2 extends StraxAbstractOrganisationReaderEngineV2 {
    private static StaxDataProviderSchemeReaderEngineV2 INSTANCE;

    //Private constructor - lazy load instance
    private StaxDataProviderSchemeReaderEngineV2() {}

    public static StaxDataProviderSchemeReaderEngineV2 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxDataProviderSchemeReaderEngineV2();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    public DataProviderSchemeMutableBean processMaintainable(IStaxReader reader) {
        DataProviderSchemeMutableBean bean = new DataProviderSchemeMutableBeanImpl();

        List<DataProviderMutableBean> orgs = processItems(reader);
        for (DataProviderMutableBean org : orgs) {
            bean.addItem(org);
        }
        return bean;
    }

    private List<DataProviderMutableBean> processItems(IStaxReader reader) {
        List<DataProviderMutableBean> retSet = new ArrayList<>();
        reader.moveNextNode();

        do {
            DataProviderMutableBean agency = new DataProviderMutableBeanImpl();
            analyseOrganisation(reader, agency );
            retSet.add(agency);
            reader.moveNextNode();
        } while(reader.isStartElement() && reader.getElementName().equals("DataProvider"));

        return retSet;
    }
}
