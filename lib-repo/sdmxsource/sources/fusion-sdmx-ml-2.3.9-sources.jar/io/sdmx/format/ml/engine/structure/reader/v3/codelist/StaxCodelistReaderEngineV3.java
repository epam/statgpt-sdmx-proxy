package io.sdmx.format.ml.engine.structure.reader.v3.codelist;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.ICodelistInheritanceRuleMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistInheritanceRuleMutableBean;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.im.util.model.ValidityPeriodUtil;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxCodelistReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<CodelistMutableBean> {
	private static StaxCodelistReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistReaderEngineV3() {}

	public static StaxCodelistReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "Codelists";
    }

    @Override
    protected String getRootNodeName() {
        return "Codelist";
    }
    
    @Override
    protected CodelistMutableBean processMaintainable(IStaxReader reader) {
        CodelistMutableBean maint = new CodelistMutableBeanImpl();
        StaxItemSchemeUtil.processBean(maint, reader);

        while(reader.isStartElement()) {
            if(reader.getElementName().equals("Code")) {
                CodeMutableBean aCode = processCode(reader);
                maint.addItem(aCode);
                reader.moveNextNode();
            } else if(reader.getElementName().equals("CodelistExtension")) {
                maint.addInheritenceRules(processExtension(reader));
                reader.moveNextNode();
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
        }
        ValidityPeriodUtil.processValidityAnnotations(maint);
        return maint;
    }

	private ICodelistInheritanceRuleMutableBean processExtension(IStaxReader reader) {
		String exitNode = reader.getElementName();
		CodelistInheritanceRuleMutableBean rule = new CodelistInheritanceRuleMutableBean();
		rule.setPrefix(reader.getAttributeValue("prefix"));
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Codelist")) {
					rule.setCodelistRef(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE_LIST));
				} else if(nodeName.equals("InclusiveCodeSelection")) {
					processExtension(reader, rule, true);
				} else if(nodeName.equals("ExclusiveCodeSelection")) {
					processExtension(reader, rule, false);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitNode)) {
				break;
			}
		}
		return rule;
	}

	private void processExtension(IStaxReader reader, ICodelistInheritanceRuleMutableBean rule, boolean isIncluded) {
		String exitNode = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("MemberValue")) {
					boolean isCascade = "true".equals(reader.getAttributeValue("cascadeValues"));
					String id = reader.getElementText();
					if(isIncluded) {
						rule.addInclusiveInheritenceId(id);
						if(isCascade) {
							rule.addInclusiveInheritenceCascades(id);
						}
					} else {
						rule.addExclusiveInheritenceId(id);
						if(isCascade) {
							rule.addExclusiveInheritenceCascades(id);
						}
					}
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitNode)) {
				break;
			}
		}
	}
	
	private CodeMutableBean processCode(IStaxReader reader) {
		CodeMutableBean code = new CodeMutableBeanImpl();
		StaxNameableUtil.processBean(code, reader);

		if(reader.isStartElement()) {
			if(!reader.getElementName().equals("Parent")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			code.setParentCode(StaxStructureRefReaderV3.getLocalReference(reader));
			reader.moveNextNode();  //Move to end of parent element
		}
		//Leave on an end element
		return code;
	}
	
}