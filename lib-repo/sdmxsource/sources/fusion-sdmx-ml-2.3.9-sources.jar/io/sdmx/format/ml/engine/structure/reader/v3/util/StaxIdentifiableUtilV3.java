package io.sdmx.format.ml.engine.structure.reader.v3.util;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.ILinkBean;
import io.sdmx.api.sdmx.model.mutable.base.IdentifiableMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.util.model.testinstances.TestLinkUtil;

public class StaxIdentifiableUtilV3 {

	public static void processBean(IdentifiableMutableBean bean, IStaxReader reader) {
		processAttributes(bean, reader);
		StaxAnnotableUtilV3.processBean(bean, reader);
		if(reader.isStartElement()) {
			while(reader.getElementName().equals("Link")) {
				String rel = reader.getAttributeValue("rel");
				String hRefStr = reader.getAttributeValue("url");
				String urnStr = reader.getAttributeValue("urn");
				String type = reader.getAttributeValue("type");
				ILinkBean link = TestLinkUtil.createLink(rel, hRefStr, urnStr, type);
				bean.addLink(link);
				reader.moveNextStartNode();
			}
		}
	}
	
	/**
	 * populates the Identifiable with 'id' and 'uri' attribute values read from the current XML node. 
	 * @param identifiableBean
	 * @param staxReader
	 */
	public static void processAttributes(IdentifiableMutableBean identifiableBean, IStaxReader staxReader) {
		Map<String, String> attributes = staxReader.getAttributes();
		identifiableBean.setId(StaxStructureUtil.getAttribute(attributes, "id", false));  //Id may not be mandatory for an identifiable that inherits it from a concept if not provided
		identifiableBean.setUri(StaxStructureUtil.getAttribute(attributes, "uri", false));
	}

	
}
