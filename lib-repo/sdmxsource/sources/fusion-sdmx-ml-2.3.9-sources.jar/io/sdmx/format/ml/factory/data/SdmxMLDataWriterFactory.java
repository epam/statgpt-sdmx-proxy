package io.sdmx.format.ml.factory.data;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.data.DataWriterFactory;
import io.sdmx.core.sdmx.format.SdmxDataFormat;
import io.sdmx.api.sdmx.engine.DataWriterEngine;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.format.ml.engine.data.writer.CompactDataWriterEngine;
import io.sdmx.format.ml.engine.data.writer.GenericDataWriterEngine;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SdmxMLDataWriterFactory implements DataWriterFactory, IFusionSingleton {
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMLDataWriterFactory.class);

	private static SdmxMLDataWriterFactory INSTANCE;

	//Private constructor - lazy load instance
	private SdmxMLDataWriterFactory() {}

	public static SdmxMLDataWriterFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLDataWriterFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public static SdmxMLDataWriterFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public DataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat instanceof SdmxDataFormat) {
			boolean prettyPrint;
			if (dataQuery == null) {
				prettyPrint = false;

				String pp = System.getProperty("data.prettyprint");
				if ("true".equals(pp)) {
				    prettyPrint = true;
				}
			} else {
			    String pp = dataQuery.getParameter("prettyPrint");
			    if (pp != null) {
			        prettyPrint = "true".equalsIgnoreCase(pp);
			    } else {
			        pp = dataQuery.getParameter("data.prettyprint");
			        prettyPrint = "true".equalsIgnoreCase(pp);
			    }
			}

			DataWriterEngine dwe = null;
			SdmxDataFormat sdmxDataFormat = (SdmxDataFormat) dataFormat;
			switch(sdmxDataFormat.getSdmxDataFormat().getBaseDataFormat()) {
			case COMPACT:
				dwe = new CompactDataWriterEngine(sdmxDataFormat.getSdmxDataFormat().getSchemaVersion(), out, prettyPrint);
				break;
			case GENERIC:
				dwe = new GenericDataWriterEngine(sdmxDataFormat.getSdmxDataFormat().getSchemaVersion(), out, prettyPrint);
				break;
			case CROSS_SECTIONAL:
				throw new SdmxNotImplementedException("Cross Sectional Data");
			}

			if (dwe != null) {
				if (dataQuery != null) {
					String dimAtObs = dataQuery.dimensionAtObservation();
					if (ObjectUtil.validString(dimAtObs) && !dimAtObs.equalsIgnoreCase(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
						throw new SdmxNotImplementedException("The parameter 'dimensionAtObservation' is not supported when querying for SDMX-ML data");
					}
				}
			}
			return dwe;
		}
		return null;
	}
}
