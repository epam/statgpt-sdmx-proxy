package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRefUtil {
	private static final String DELIMITER = "~";
	
	public static void writeLocalReference(String id, StaxWriter writer, String elementName) {
		if(!ObjectUtil.validString(id)) {
			return;
		}
		writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName);
		writer.writeStartElement(null, "Ref");  //No namespace
		writer.writeAttribute("id", id);
		writer.writeEndElement(); //End Ref
		writer.writeEndElement(); //End Start Element
	}
	
	public static void writeReference(ICrossReferenceBean<?> crossReference, StaxWriter writer) {
		writeReference(crossReference, writer, null);
	}
	
	public static void writeReferences(List<? extends ICrossReferenceBean<?>> refs, StaxWriter writer, String elementName) {
		for(ICrossReferenceBean<?> ref : refs) {
			writeReference(ref, writer, elementName);
		}
	}
	public static void writeReference(ICrossReferenceBean<?> crossReference, StaxWriter writer, String elementName) {
		if(crossReference == null) {
			return;
		}
		writeReference(crossReference.getReference(), writer, elementName);
	}
	
	public static void writeReference(IURN<?> crossReference, StaxWriter writer, String elementName) {
		if(crossReference == null) {
			return;
		}
		if(elementName != null) {
			writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName);
		}
		
		Map<String, String> attributes = new HashMap<>();	
		
		if(crossReference.getIdentifiableId() != null) {
			String fullId = crossReference.getFullIdentifiableId();
			if(fullId.contains(DELIMITER)) {
				String containerId = fullId.substring(0, fullId.lastIndexOf(DELIMITER));
				String targetId = fullId.substring(fullId.indexOf(DELIMITER)+1, fullId.length());
				attributes.put("maintainableParentID", containerId);  //TODO What is this?
				attributes.put("id", targetId);
			} else {
				attributes.put("id", fullId);
			}
			if(ObjectUtil.validString(crossReference.getMaintainableId())) {
				attributes.put("maintainableParentID", crossReference.getMaintainableId());
			}
			if(!crossReference.getVersion().isAll()) {
				attributes.put("maintainableParentVersion", crossReference.getVersion().toString());
			}
		} else {
			if(ObjectUtil.validString(crossReference.getMaintainableId())) {
				attributes.put("id", crossReference.getMaintainableId());
			}
			if(!crossReference.getVersion().isAll()) {
				attributes.put("version", crossReference.getVersion().toString());
			}
		}
		if(ObjectUtil.validString(crossReference.getAgencyId())) {
			attributes.put("agencyID", crossReference.getAgencyId());
		}
		attributes.put("package", crossReference.getStructureType().getUrnPackage());
		attributes.put("class", crossReference.getStructureType().getUrnClass());
		writer.writeElement(null, "Ref", attributes);  //No namespace
		writer.writeEndElement(); //End Ref
		if(elementName != null) {
			writer.writeEndElement(); //End Start Element
		}
	}
}
