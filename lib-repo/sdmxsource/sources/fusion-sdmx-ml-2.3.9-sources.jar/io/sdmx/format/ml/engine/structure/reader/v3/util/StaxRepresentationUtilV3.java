package io.sdmx.format.ml.engine.structure.reader.v3.util;

import java.util.Map;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.RepresentationMutableBean;
import io.sdmx.im.mutable.base.RepresentationMutableBeanImpl;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxRepresentationUtilV3 {

	public static RepresentationMutableBean processBean(IStaxReader reader) {
		RepresentationMutableBean bean = new RepresentationMutableBeanImpl();
		processBean(reader, bean);
		return bean;
	}
	
	public static void processBean(IStaxReader reader, RepresentationMutableBean bean) {
		String exitNode = reader.getElementName();
		Map<String, String> attributes = reader.getAttributes();
		Integer minOccurs = StaxStructureUtil.getAttributeAsInteger(attributes, "minOccurs", false);
		Integer maxOccurs = StaxStructureUtil.getAttributeAsInteger(attributes, "maxOccurs", false);
		if(minOccurs != null) {
			bean.setMinOccurs(minOccurs);
		}
		if(maxOccurs != null) {
			bean.setMaxOccurs(maxOccurs);
		}
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("TextFormat")) {
					bean.setTextFormat(StaxTextFormatUtilV3.processBean(reader));
				} else if(nodeName.equals("Enumeration")) {
					bean.setRepresentation(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.VALUE_LIST, SDMX_STRUCTURE_TYPE.CODE_LIST));
				} else if(nodeName.equals("EnumerationFormat")) {
					bean.setTextFormat(StaxTextFormatUtilV3.processBean(reader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitNode)) {
				break;
			}
		}
	}
	
}
