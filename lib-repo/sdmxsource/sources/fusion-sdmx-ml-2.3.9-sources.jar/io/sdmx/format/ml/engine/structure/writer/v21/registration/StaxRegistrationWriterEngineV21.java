package io.sdmx.format.ml.engine.structure.writer.v21.registration;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.DataSourceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRegistrationWriterEngineV21  implements StaxMaintainableWriterEngine<RegistrationBean>, IFusionSingleton {
	private static StaxRegistrationWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRegistrationWriterEngineV21() {}

	public static StaxRegistrationWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRegistrationWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	private static final Namespace NS = StaxStructureWriterUtil.REGISTRY_NS;

	@Override
	public void writeMaintainable(RegistrationBean maint, StaxWriter writer) {
		writer.writeStartElement(NS, "Registration");
		Map<String, String> attributes = new HashMap<>();
		attributes.put("id", maint.getId());
		if( maint.getValidFrom() != null) {
			attributes.put("validFrom", maint.getValidFrom().getDateInSdmxFormat());
		}
		if( maint.getValidTo() != null) {
			attributes.put("validTo", maint.getValidTo().getDateInSdmxFormat());
		}
		if( maint.getLastUpdated() != null) {
			attributes.put("lastUpdated", maint.getLastUpdated().getDateInSdmxFormat());
		}
		attributes.put("indexTimeSeries", Boolean.toString(maint.getIndexTimeSeries().isTrue()));
		attributes.put("indexDataSet", Boolean.toString(maint.getIndexDataset().isTrue()));
		attributes.put("indexAttributes", Boolean.toString(maint.getIndexAttributes().isTrue()));
		attributes.put("indexReportingPeriod", Boolean.toString(maint.getIndexReportingPeriod().isTrue()));

		writer.writeAttributes(attributes);

		writer.writeStartElement(StaxStructureWriterUtil.REGISTRY_NS, "ProvisionAgreement");
		StaxRefUtil.writeReference(maint.getProvisionAgreementRef(), writer);
		writer.writeEndElement();

		writer.writeStartElement(NS, "Datasource");

		DataSourceBean ds = maint.getDataSource();
		if(ds.isSimpleDatasource()) {
			writer.writeElement(NS, "SimpleDataSource", ds.getDataUrl().toString());
		} else {
			writer.writeStartElement(NS, "QueryableDataSource");
			writer.writeAttribute("isRESTDatasource", Boolean.toString(ds.isRESTDatasource()));
			writer.writeAttribute("isWebServiceDatasource", Boolean.toString(ds.isWebServiceDatasource()));
			writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "DataURL", ds.getDataUrl().toString());
			if(ds.getWSDLUrl() != null) {
				writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "WSDLURL", ds.getWSDLUrl().toString());
			}
			if(ds.getWadlUrl() != null) {
				writer.writeElement(StaxStructureWriterUtil.COMMON_NS, "WADLURL", ds.getWadlUrl().toString());
			}
			writer.writeEndElement();  //End QueryableDataSource
		}


		writer.writeEndElement();  //End Datasource
		writer.writeEndElement();  //End Registration
	}
}
