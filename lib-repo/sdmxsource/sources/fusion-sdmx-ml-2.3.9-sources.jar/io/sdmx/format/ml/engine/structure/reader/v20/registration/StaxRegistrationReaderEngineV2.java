package io.sdmx.format.ml.engine.structure.reader.v20.registration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.mutable.base.DataSourceMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.RegistrationMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.api.engine.StaxRegistrationReaderEngine;
import io.sdmx.im.RegistrationInformationImpl;
import io.sdmx.im.mutable.base.DataSourceMutableBeanImpl;
import io.sdmx.im.mutable.registry.RegistrationMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxRegistrationReaderEngineV2 implements StaxRegistrationReaderEngine, IFusionSingleton {
	private static StaxRegistrationReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxRegistrationReaderEngineV2() {}
	public static StaxRegistrationReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxRegistrationReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	@Override
    public String getContainerNodeName() {
        return "RegistrationRequest";
    }

	@Override
	public List<RegistrationInformation> readRegistrations(IStaxReader reader) {
		List<RegistrationInformation> returnList = new ArrayList<>();
		while(reader.moveNextStartNode()) {
			String nodeName = reader.getElementName();
			DATASET_ACTION action = DATASET_ACTION.INFORMATION;
			 if(nodeName.equals("Registration")) {
				String actionStr = reader.getAttributeValue(null, "Action");
				if(actionStr != null) {
					action = DATASET_ACTION.getAction(actionStr);
				}
				returnList.add(new RegistrationInformationImpl(action, buildRegistration(reader, action)));
			}
		}

		return returnList;
	}

	private RegistrationBean buildRegistration(IStaxReader reader, DATASET_ACTION action) {
		RegistrationMutableBean regMutable = new RegistrationMutableBeanImpl();
		regMutable.setId(reader.getAttributeValue(null, "id"));
		if(regMutable.getId() == null) {
			if(action == DATASET_ACTION.DELETE || action == DATASET_ACTION.REPLACE) {
				throw new IllegalArgumentException("Registration submissions with REPLACE or DELETE actions must contain an id identifying the Registration to perform this action on");
			}
			regMutable.setId(MaintainableUtil.generateRandomId());
		}
		regMutable.setValidFrom(readDate(reader, "ValidFrom"));
		regMutable.setValidTo(readDate(reader, "ValidTo"));
		regMutable.setLastUpdated(readDate(reader, "LastUpdated"));

		while(reader.moveNextNode()) {
			String element = reader.getElementName();
			if(reader.isStartElement()) {
				 if(element.equals("ProvisionAgreementRef")) {
					 String provUrn = reader.getAttributeValue(null, "URN");
					 if(ObjectUtil.validString(provUrn)) {
						 regMutable.setProvisionAgreementRef(new StructureReferenceBeanImpl(provUrn));
						} else {
							throw new SdmxNotImplementedException("Registrations submitted in version 2.0 of SDMX must reference a " +
									"Provision agreement by URN.  Note : The 2.1 URN syntax for provision agreements must be used; the 2.0 URN syntax for provision agreements is not longer supported");
						}

				 } else if(element.equals("Datasource")) {
					 parseDatasource(reader, regMutable);
				 }
			} else if(element.equals("Registration")) {
				break;
			}
		}
		return regMutable.getImmutableInstance();
	}

	private void parseDatasource(IStaxReader reader, RegistrationMutableBean regMutable) {
		DataSourceMutableBean datasource = new DataSourceMutableBeanImpl();
		regMutable.setDataSource(datasource);
		while(reader.moveNextNode()) {
			String element = reader.getElementName();
			if(reader.isStartElement()) {
				 if(element.equals("SimpleDatasource")) {
						datasource.setSimpleDatasource(true);
						datasource.setRESTDatasource(false);
						datasource.setDataUrl(reader.getElementText());
				 } else if(element.equals("QueryableDatasource")) {
					 parseQueryableDatasource(reader, datasource);
				 }
			} else if(element.equals("Datasource")) {
				break;
			}
		}
	}


	private void parseQueryableDatasource(IStaxReader reader, DataSourceMutableBean datasource) {
		datasource.setSimpleDatasource(false);
		datasource.setRESTDatasource(readBool(reader, "isRESTDatasource").isTrue());
		while(reader.moveNextNode()) {
			String element = reader.getElementName();
			if(reader.isStartElement()) {
				switch(element) {
				case "DataUrl" :
					datasource.setDataUrl(reader.getElementText());
					break;
				case "WSDLUrl" :
					datasource.setWSDLUrl(reader.getElementText());
					break;
				}
			} else if(element.equals("QueryableDatasource")) {
				break;
			}
		}
	}

	private TERTIARY_BOOL readBool(IStaxReader reader, String attributeValue) {
		String value = reader.getAttributeValue(null, attributeValue);
		if(value != null) {
			return TERTIARY_BOOL.parseBoolean(Boolean.parseBoolean(value));
		}
		return TERTIARY_BOOL.UNSET;
	}

	private Date readDate(IStaxReader reader, String attributeValue) {
		String value = reader.getAttributeValue(null, attributeValue);
		if(value != null) {
			return SdmxDateImpl.getSdmxDate(value).getDate();
		}
		return null;
	}
}
