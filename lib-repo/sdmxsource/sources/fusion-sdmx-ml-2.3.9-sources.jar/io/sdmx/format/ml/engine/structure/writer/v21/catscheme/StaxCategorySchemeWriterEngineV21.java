package io.sdmx.format.ml.engine.structure.writer.v21.catscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCategorySchemeWriterEngineV21 extends AbstractV21Writer<CategorySchemeBean> implements IFusionSingleton {
	private static StaxCategorySchemeWriterEngineV21 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorySchemeWriterEngineV21() {}

	public static StaxCategorySchemeWriterEngineV21 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorySchemeWriterEngineV21();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CategoryScheme";
	}

	@Override
	protected void writeMaintainableInternal(CategorySchemeBean maint, StaxWriter writer) {
		writeCategories(maint.getItems(), writer);
	}

	private void writeCategories(List<CategoryBean> categories, StaxWriter writer) {
		for(CategoryBean cat : categories) {
			StaxNameableWriterUtil.writeBean(cat, "Category", writer);
			writeCategories(cat.getItems(), writer);
			writer.writeEndElement();
		}
	}
}
