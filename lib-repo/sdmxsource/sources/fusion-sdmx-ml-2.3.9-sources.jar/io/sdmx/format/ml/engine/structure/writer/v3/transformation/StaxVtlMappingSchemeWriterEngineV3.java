package io.sdmx.format.ml.engine.structure.writer.v3.transformation;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.transformation.IVtlCodelistMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlConceptMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlDataflowMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingBean;
import io.sdmx.api.sdmx.model.beans.transformation.IVtlMappingSchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxVtlMappingSchemeWriterEngineV3 extends AbstractV3Writer<IVtlMappingSchemeBean> implements IFusionSingleton {
	private static StaxVtlMappingSchemeWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxVtlMappingSchemeWriterEngineV3() {}

	public static StaxVtlMappingSchemeWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxVtlMappingSchemeWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "VtlMappingScheme";
	}

	@Override
	protected void writeMaintainableInternal(IVtlMappingSchemeBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeItems(maint.getItems(), externalLinks, writer);
	}

	private void writeItems(List<IVtlMappingBean> items, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(IVtlMappingBean item : items) {
			StaxNameableWriterUtilV3.writeBean(item, "VtlMapping", externalLinks, writer, CollectionUtil.buildMapValues("alias "+ item.getAlias()));
			switch(item.getStructureType()) {
			case VTL_DATAFLOW_MAPPING:
				writeMapping((IVtlDataflowMappingBean)item, writer);
				break;
			case VTL_CODELIST_MAPPING :
				writeMapping((IVtlCodelistMappingBean)item, writer);
				break;
			case VTL_CONCEPT_MAPPING :
				writeMapping((IVtlConceptMappingBean)item, writer);
				break;
			}
			writer.writeEndElement();
		}
	}

	private void writeMapping(IVtlCodelistMappingBean item, StaxWriter writer) {
		StaxRefUtilV3.writeReference(item.getMapped(), writer, "Codelist");
	}

	private void writeMapping(IVtlConceptMappingBean item, StaxWriter writer) {
		StaxRefUtilV3.writeReference(item.getMapped(), writer, "Concept");
	}

	private void writeMapping(IVtlDataflowMappingBean item, StaxWriter writer) {
		StaxRefUtilV3.writeReference(item.getMapped(), writer, "Dataflow");
		writeFlowMapping(item.getToMethod(), item.getToSubSpace(), false, writer);
		writeFlowMapping(item.getFromMethod(), item.getFromSubSpace(), true, writer);
	}

	private void writeFlowMapping(String method, List<String> subspace, boolean isFrom, StaxWriter writer) {
		if(method == null && !ObjectUtil.validCollection(subspace)) {
			return;
		}
		writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, isFrom ? "FromVtlMapping" : "ToVtlMapping");
		if(method != null) {
			writer.writeAttribute("method", method);
		}
		if(ObjectUtil.validCollection(subspace)) {
			writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, isFrom ? "FromVtlSuperSpace" : "ToVtlSubSpace");
			for(String key : subspace) {
				writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Key", key);
			}
			writer.writeEndElement();
		}
		writer.writeEndElement();
	}
}
