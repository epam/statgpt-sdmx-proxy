package io.sdmx.format.ml.engine.structure.reader.v20.hcl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchicalCodelistMutableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodelistRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxHclReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<HierarchicalCodelistMutableBean> {
	private static StaxHclReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHclReaderEngineV2() {}
	public static StaxHclReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHclReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }


	@Override
    public String getContainerNodeName() {
        return "HierarchicalCodelists";
    }
    
    @Override
    protected String getRootNodeName() {
        return "HierarchicalCodelist";
    }
    
    @Override
    protected HierarchicalCodelistMutableBean processMaintainable(IStaxReader reader) {
        HierarchicalCodelistMutableBean template = new HierarchicalCodelistMutableBeanImpl();
		StaxMaintainableUtilV2.processBean(template, reader);

		Map<String, StructureReferenceBean> clRefMap = new HashMap<>();
		List<HierarchyMutableBean> mutableList = new ArrayList<>();
		
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("CodelistRef")) {
				processCodelistRef(reader, clRefMap);
			} else if(nodeName.equals("Hierarchy")) {
				mutableList.add(processHierarchy(reader, clRefMap));
			} else if(reader.getElementName().equals("Annotations")) {
			    reader.skipCurrentNode();
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
			reader.moveNextNode();
		}
		clRefMap.forEach((k, v) -> {
            CodelistRefMutableBean clRef = new CodelistRefMutableBeanImpl();
            clRef.setAlias(k);
            clRef.setCodelistReference(v);
            template.addCodelistRef(clRef);
        });
		template.setHierarchies(mutableList);
		

		return template;
	}

	/**
	 * Start node is str:CodelistRef
	 * @param reader
	 * @return
	 */
	private void processCodelistRef(IStaxReader reader, Map<String, StructureReferenceBean> map) {
		
	    reader.moveNextNode();  // Move to the first element in the CodelistRef

	    String alias = null;
        String agencyId = null;
        String maintainableId = null;
        String version = null;
        String urn = null;

        
        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("URN")) {
                urn = reader.getElementText();
            } else if(nodeName.equals("AgencyID")) {
                agencyId = reader.getElementText();
            } else if(nodeName.equals("CodelistID")) {
                maintainableId = reader.getElementText();
            } else if(nodeName.equals("Version")) {
                version = reader.getElementText();
            } else if(nodeName.equals("Alias")) {
            	alias = reader.getElementText();
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }

        StructureReferenceBean sRef;
        if (ObjectUtil.validOneString(agencyId, maintainableId, version)) {
            sRef = new StructureReferenceBeanImpl(agencyId, maintainableId, version, SDMX_STRUCTURE_TYPE.CODE_LIST);
        } else {
            sRef = new StructureReferenceBeanImpl(urn, SDMX_STRUCTURE_TYPE.CODE_LIST);
        }
        map.put(alias, sRef);
	}


	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private HierarchyMutableBean processHierarchy(IStaxReader reader, Map<String, StructureReferenceBean> clRef) {
		HierarchyMutableBean returnBean = new HierarchyMutableBeanImpl();
        StaxIdentifiableUtil.processAttributes(returnBean, reader);

        // TODO: What about the attributes: Version / isFinal / validFrom / validTo
        // these can't be applied to the Hierarchy which is an Identifiable Bean!

		StaxNameableUtil.processBean(returnBean, reader);

		Map<Integer, LevelMutableBean> levelMap = new HashMap<>();

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("CodeRef")) {
				returnBean.addHierarchicalCodeBean(processHierarchicalCode(reader, null, clRef));
			} else if(nodeName.equals("Level")) {
			    // Store in the levelMap
			    processChildLevel(reader, levelMap);
			} else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(returnBean, reader);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
			reader.moveNextNode();
		}

//		if (!levelMap.isEmpty()) {
//		    returnBean.setFormalLevels(true);
//		}

		LevelMutableBean previousLevel = null;
		for (int i=levelMap.size(); i > 0; i--) {
		    LevelMutableBean lmb = levelMap.get(i);
		    if (lmb == null) {
		        // Copied from the 2.0 constructor - create a default Level
		        lmb = new LevelMutableBeanImpl();
                lmb.setId("DEFAULT");
                lmb.addName("en", "Default");
		    }
		    lmb.setChildLevel(previousLevel);
		    previousLevel = lmb;
		    if (i==1) {
		        returnBean.setChildLevel(lmb);
		    }
		}

		return returnBean;
	}

	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private CodeRefMutableBean processHierarchicalCode(IStaxReader reader, CodeRefMutableBean parent, Map<String, StructureReferenceBean> clRefMap) {
		CodeRefMutableBean returnBean = new CodeRefMutableBeanImpl();
		reader.moveNextNode();  // Move to the first element in the CodeRef

		String codelistAlias = null;
		String codeId = null;
		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("URN")) {
			    String urn = reader.getElementText();
			    StructureReferenceBean codeReference = new StructureReferenceBeanImpl(urn);
			    returnBean.setCodeReference(codeReference);
			} else if(nodeName.equals("CodelistAliasRef")) {
				codelistAlias = reader.getElementText();
			} else if(nodeName.equals("CodeID")) {
				codeId = reader.getElementText();
			} else if(nodeName.equals("CodeRef")) {
			    returnBean.addCodeRef(processHierarchicalCode(reader, returnBean, clRefMap));
			} else if(nodeName.equals("LevelRef")) {
			    String val;
			    if (parent == null) {
			        val = reader.getElementText();
			    } else {
			        val = parent.getLevelReference() + "." + reader.getElementText();
			    }
			    returnBean.setLevelReference(val);
			} else if(nodeName.equals("NodeAliasID")) {
			    returnBean.setId(reader.getElementText());
			} else if(nodeName.equals("Version")) {
                returnBean.setVersion(reader.getElementText());
			} else if(nodeName.equals("ValidFrom")) {
			    String strVal = reader.getElementText();
			    returnBean.setValidFrom( DateUtil.formatDate(strVal, true) );
			} else if(nodeName.equals("ValidTo")) {
			    String strVal = reader.getElementText();
                returnBean.setValidTo( DateUtil.formatDate(strVal, true) );
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		if(returnBean.getCodeReference() == null && codelistAlias != null && codeId != null) {
			StructureReferenceBean codelistRef = clRefMap.get(codelistAlias);
			if(codelistRef == null) {
				throw new SdmxSemmanticException("Hierarchical Codelist reference not found by alias: " +codelistAlias);
			}
			returnBean.setCodeReference(new StructureReferenceBeanImpl(codelistRef, SDMX_STRUCTURE_TYPE.CODE, codeId));
		}
		
		return returnBean;
	}


	/**
	 * Start node is Level
	 * @param reader
	 * @return
	 */
	private LevelMutableBean processChildLevel(IStaxReader reader, Map<Integer, LevelMutableBean> levelMap) {
		LevelMutableBean returnBean = new LevelMutableBeanImpl();
		// Process Id and URN
		returnBean.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", false));

		reader.moveNextNode();

		// Process Name and Description
		while(StaxNameableUtil.processNode(returnBean, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Order")) {
			    String order = reader.getElementText();
			    try {
			        int orderAsInt = Integer.parseInt(order);
			        levelMap.put(orderAsInt, returnBean);
			    } catch (Exception e) {
			        throw new SdmxException("Unable to parse 'Order' node which has value: '" + order + "'");
			    }
			} else if(nodeName.equals("CodingType")) {
			    TextFormatMutableBean tf = new TextFormatMutableBeanImpl();

		        Map<String, String> attributes = reader.getAttributes();

		        tf.setTextType(StaxStructureUtil.getAttributeAsTextType(attributes, "textType", false));
		        tf.setSequence(StaxStructureUtil.getAttributeAsTeritaryBoolean(attributes, "isSequence", false));
		        tf.setMinLength(StaxStructureUtil.getAttributeAsBigInteger(attributes, "minLength", false));
		        tf.setMaxLength(StaxStructureUtil.getAttributeAsBigInteger(attributes, "maxLength", false));
//		        tf.setStartValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "startValue", false));
//		        tf.setEndValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "endValue", false));
		        tf.setInterval(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "interval", false));
		        tf.setTimeInterval(StaxStructureUtil.getAttribute(attributes, "timeInterval", false));
		        tf.setDecimals(StaxStructureUtil.getAttributeAsBigInteger(attributes, "decimals", false));
		        tf.setPattern(StaxStructureUtil.getAttribute(attributes, "pattern", false));

		        returnBean.setCodingFormat(tf);


//			    returnBean.setCodingFormat(StaxTextFormatUtil.processBean(reader));
			    reader.moveNextNode();
			} else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(returnBean, reader);
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
			reader.moveNextNode();
		}
		return returnBean;
	}
}
