package io.sdmx.format.ml.engine.structure.writer.v21.util;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxIdentifiableWriterUtil {

	public static void writeBean(IdentifiableBean ident, String elementName, StaxWriter writer) {
		writeBean(ident, elementName, writer, null);
	}
	
	public static void writeBean(IdentifiableBean ident, String elementName, StaxWriter writer, Map<String, String> attrs) {
		Map<String, String> attributes = getAttributes(ident);
		if(attrs != null) {
			attributes.putAll(attrs);
		}
		writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName, attributes);
		StaxAnnotableWriterUtil.writeBean(ident, writer);
	}

	public static Map<String, String> getAttributes(IdentifiableBean ident) {
		Map<String, String> attributes = new HashMap<>();
		attributes.put("id", ident.getId());
		attributes.put("urn", ident.getUrn());
		if(ident.getUri() != null) {
			attributes.put("uri", ident.getUri().toString());
		}
		return attributes;
	}

}
