package io.sdmx.format.ml.factory.metadata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.factory.metadata.IMetadataReaderFactory;
import io.sdmx.format.ml.constant.SDMXML_VERSION;
import io.sdmx.format.ml.engine.metadata.v21.SdmxMLMetadataSetReaderEngineV21;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

public class SdmxMLMetadataReaderFactory implements IMetadataReaderFactory, IFusionSingleton {
	private static SdmxMLMetadataReaderFactory INSTANCE;
	
	private static final Logger LOG = LoggerFactory.getLogger(SdmxMLMetadataReaderFactory.class);

	public static SdmxMLMetadataReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new SdmxMLMetadataReaderFactory();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	public static SdmxMLMetadataReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}

	@Override
	public Integer getPriority() {
		return 10;
	}

	@Override
	public IReferenceMetadataContainer parse(ReadableDataLocation rdl) {
		if(rdl.getFormat() == FILE_FORMAT.XML) {
			SDMXML_VERSION v = getSdmxMLVersion(rdl);
			if(v != null) {
				switch(v) {
				case V1:
					break;
				case V2:
					break;
				case V21:
					SdmxMLMetadataSetReaderEngineV21 reader = SingletonStore.getSingleton(SdmxMLMetadataSetReaderEngineV21.class, false);
					if(reader != null) {
						return reader.parse(rdl);
					}
					break;
				case V3:
					break;
				}
				throw new SdmxNotImplementedException("Reading Reference Metadata at version "+v.getVersion()+" is not implmenented");
			}
		}
		return null;
	}

	private SDMXML_VERSION getSdmxMLVersion(ReadableDataLocation rdl) {
		try {
			switch(SdmxMessageUtil.getSchemaVersion(rdl)) {
			case VERSION_ONE: return SDMXML_VERSION.V1;
			case VERSION_THREE: return SDMXML_VERSION.V3;
			case VERSION_TWO: return SDMXML_VERSION.V2;
			case VERSION_TWO_POINT_ONE : return SDMXML_VERSION.V21;
			default:
				return null;
			}
		} catch(Throwable th) {
			LOG.debug("not sdmx", th);
		}
		return null;
	}
}
