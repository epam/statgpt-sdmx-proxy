package io.sdmx.format.ml.engine.structure.reader.v21.hcl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.HierarchicalCodelistMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodelistRefMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxTextFormatUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.HierarchicalCodelistMutableBeanImpl;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodelistRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxHclReaderEngineV21 extends AbstractStaxMaintainableReaderEngine<HierarchicalCodelistMutableBean> {
    private static StaxHclReaderEngineV21 INSTANCE;

    //Private constructor - lazy load instance
    private StaxHclReaderEngineV21() {}
    public static StaxHclReaderEngineV21 getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new StaxHclReaderEngineV21();
            FusionBeanStore.registerInstance(INSTANCE);
        }

        return INSTANCE;
    }

    @Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "HierarchicalCodelists";
    }
    
    @Override
    protected String getRootNodeName() {
        return "HierarchicalCodelist";
    }
    
    @Override
    protected HierarchicalCodelistMutableBean processMaintainable(IStaxReader reader) {
        HierarchicalCodelistMutableBean template = new HierarchicalCodelistMutableBeanImpl();
        StaxMaintainableUtil.processBean(template, reader);

        Map<String, StructureReferenceBean> clRefMap = new HashMap<>();
        List<HierarchyMutableBean> mutableList = new ArrayList<>();

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("IncludedCodelist")) {
                processCodelistRef(reader, clRefMap);
            } else if(nodeName.equals("Hierarchy")) {
                mutableList.add(processHierarchy(reader, clRefMap));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        clRefMap.forEach((k, v) -> {
            CodelistRefMutableBean clRef = new CodelistRefMutableBeanImpl();
            clRef.setAlias(k);
            clRef.setCodelistReference(v);
            template.addCodelistRef(clRef);
        });
        template.setHierarchies(mutableList);
        
        return template;
    }

    /**
     * Start node is IncludedCodelist
     * @param reader
     * @return
     */
    private void processCodelistRef(IStaxReader reader, Map<String, StructureReferenceBean> map) {
        String alias = reader.getAttributeValue(null, "alias");
        StructureReferenceBean sRef = StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE_LIST);
        map.put(alias, sRef);
    }


    /**
     * Start node is IncludedCodelist
     * @param reader
     * @return
     */
    private HierarchyMutableBean processHierarchy(IStaxReader reader, Map<String, StructureReferenceBean> clRef) {
        HierarchyMutableBean returnBean = new HierarchyMutableBeanImpl();
        returnBean.setFormalLevels(StaxStructureUtil.getAttributeAsTeritaryBoolean(reader.getAttributes(), "leveled", false).isTrue());

        StaxNameableUtil.processBean(returnBean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("HierarchicalCode")) {
                returnBean.addHierarchicalCodeBean(processHierarchicalCode(reader, clRef));
            } else if(nodeName.equals("Level")) {
                returnBean.setChildLevel(processChildLevel(reader));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return returnBean;
    }

    /**
     * Start node is IncludedCodelist
     * @param reader
     * @return
     */
    private CodeRefMutableBean processHierarchicalCode(IStaxReader reader, Map<String, StructureReferenceBean> clRefMap) {
        CodeRefMutableBean returnBean = new CodeRefMutableBeanImpl();
        Map<String, String> attributes = reader.getAttributes();
        returnBean.setValidFrom(StaxStructureUtil.getAttributeAsDate(attributes, "validFrom", false));
        returnBean.setValidTo(StaxStructureUtil.getAttributeAsDate(attributes, "validTo", false));

        StaxIdentifiableUtil.processBean(returnBean, reader);


        String codelistAlias = null;
        String codeId = null;

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("Code")) {
                returnBean.setCodeReference(StaxStructureUtil.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE));
            } else if(nodeName.equals("CodelistAliasRef")) {
                codelistAlias = reader.getElementText();
            } else if(nodeName.equals("CodeID")) {
                codeId = StaxStructureUtil.getLocalReference(reader);
            } else if(nodeName.equals("Level")) {
                returnBean.setLevelReference(StaxStructureUtil.getLocalReference(reader));
            } else if(nodeName.equals("HierarchicalCode")) {
                returnBean.addCodeRef(processHierarchicalCode(reader, clRefMap));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        if(returnBean.getCodeReference() == null && codelistAlias != null && codeId != null) {
            StructureReferenceBean codelistRef = clRefMap.get(codelistAlias);
            if(codelistRef == null) {
                throw new SdmxSemmanticException("Hierarchical Codelist reference not found by alias: " +codelistAlias);
            }
            returnBean.setCodeReference(new StructureReferenceBeanImpl(codelistRef, SDMX_STRUCTURE_TYPE.CODE, codeId));
        }
        return returnBean;
    }


    /**
     * Start node is IncludedCodelist
     * @param reader
     * @return
     */
    private LevelMutableBean processChildLevel(IStaxReader reader) {
        LevelMutableBean returnBean = new LevelMutableBeanImpl();
        StaxNameableUtil.processBean(returnBean, reader);

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("CodingFormat")) {
                returnBean.setCodingFormat(StaxTextFormatUtil.processBean(reader));
                reader.moveNextNode();
            } else if(nodeName.equals("Level")) {
                returnBean.setChildLevel(processChildLevel(reader));
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }
        return returnBean;
    }
}
