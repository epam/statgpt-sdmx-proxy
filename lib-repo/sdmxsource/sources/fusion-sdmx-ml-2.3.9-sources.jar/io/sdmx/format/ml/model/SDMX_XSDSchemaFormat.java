package io.sdmx.format.ml.model;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;

/**
 *  Format for xsd files (XML schema)
 */
public class SDMX_XSDSchemaFormat implements SchemaFormat {
	private static final long serialVersionUID = 1L;
	
	private static Map<SDMX_VERSION, SDMX_XSDSchemaFormat> singletons = new HashMap<>();
	
	private FormatDetails formatDetails;
	private SDMX_VERSION version;
	
	private SDMX_XSDSchemaFormat(SDMX_VERSION version) {
		formatDetails = new FormatDetailsImpl("xsd", "xsd", "application/xml", false);
		this.version = version;
	}
	
	public static SDMX_XSDSchemaFormat getInstance(SDMX_VERSION version) {
		SDMX_XSDSchemaFormat format = singletons.get(version);
		if(format == null) {
			format = new SDMX_XSDSchemaFormat(version);
			singletons.put(version, format);
		}
		return format;
	}
	
	public SDMX_VERSION getVersion() {
		return version;
	}

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SDMX_XSDSchemaFormat) {
			SDMX_XSDSchemaFormat that = (SDMX_XSDSchemaFormat)obj;
			return  that.getVersion() == this.getVersion();
		}
		return false;
	}

	@Override
	public String toString() {
		return version+formatDetails.getAcceptHeaders()[0];
	}
}
