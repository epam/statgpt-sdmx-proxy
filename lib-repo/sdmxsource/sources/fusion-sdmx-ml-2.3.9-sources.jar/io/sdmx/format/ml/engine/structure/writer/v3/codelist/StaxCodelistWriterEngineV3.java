package io.sdmx.format.ml.engine.structure.writer.v3.codelist;

import java.util.List;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.codelist.ICodelistInheritanceRuleBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxNameableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCodelistWriterEngineV3 extends AbstractV3Writer<CodelistBean> implements IFusionSingleton {
	private static StaxCodelistWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistWriterEngineV3() {}

	public static StaxCodelistWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "Codelist";
	}

	@Override
	protected void writeMaintainableInternal(CodelistBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeCodes(maint.getItems(), externalLinks, writer);
		writeExtension(maint, writer);

	}

	private void writeCodes(List<CodeBean> codes, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(CodeBean code : codes) {
			StaxNameableWriterUtilV3.writeBean(code, "Code", externalLinks, writer);
			if(code.getParentCode() != null) {
				StaxRefUtilV3.writeLocalReference(code.getParentCode(), writer, "Parent");
			}
			writer.writeEndElement();
		}
	}

	private void writeExtension(CodelistBean cl, StaxWriter writer) {
		if(!cl.isInherited()) {
			//Only write the extension if it is in the raw form, i.e. not inherited
			if(ObjectUtil.validCollection(cl.getInheritedCodelists())) {
				for(ICodelistInheritanceRuleBean clInheritance : cl.getInheritedCodelists()) {
					writeInheritanceRuleBean(clInheritance, writer);
				}
			}
		}
	}

	private void writeInheritanceRuleBean(ICodelistInheritanceRuleBean rule, StaxWriter writer) {
		writer.writeStartElement(NS, "CodelistExtension");
		if(rule.getPrefix() != null) {
			writer.writeAttribute("prefix", rule.getPrefix());
		}
		StaxRefUtilV3.writeReference(rule.getCodelistRef(), writer, "Codelist");
		writeInheritanceMembers(rule.getInclusiveInheritenceIds(), rule.getInclusiveInheritenceCascades(), true, writer);
		writeInheritanceMembers(rule.getExclusiveInheritenceIds(), rule.getExclusiveInheritenceCascades(), false, writer);
		writer.writeEndElement();
	}

	private void writeInheritanceMembers(List<String> members, Set<String> cascade, boolean included, StaxWriter writer) {
		if(ObjectUtil.validCollection(members)) {
			String elementName = included ? "InclusiveCodeSelection" : "ExclusiveCodeSelection";
			writer.writeStartElement(NS, elementName);
			for(String member : members) {
				writer.writeStartElement(NS, "MemberValue");
				if(cascade.contains(member)) {
					writer.writeAttribute("cascadeValues", true);
				}
				writer.writeElementText(member);
				writer.writeEndElement();
			}
			writer.writeEndElement();
		}
	}
}
