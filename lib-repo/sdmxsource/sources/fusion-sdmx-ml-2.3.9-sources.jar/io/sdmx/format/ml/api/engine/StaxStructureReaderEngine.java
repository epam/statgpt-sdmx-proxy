package io.sdmx.format.ml.api.engine;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.builder.IBeansBuilder;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

public interface StaxStructureReaderEngine {

	
	/**
	 * Parses the ReadableDataLocation to build the SdmxBeans, returns null if the structure format can not be determined from
	 * the information provided in the ReadableDataLocation (or from the underlying data)
	 * @param rdl
	 * @return
	 */
	SdmxBeans getSdmxBeans(ReadableDataLocation rdl, IBeansBuilder builder);
	
}
