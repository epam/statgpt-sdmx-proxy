package io.sdmx.format.ml.engine.structure.reader.v3.util;

import java.util.Map;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.TextFormatMutableBean;
import io.sdmx.im.mutable.base.TextFormatMutableBeanImpl;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxTextFormatUtilV3 {

	public static TextFormatMutableBean processBean(IStaxReader reader) {
		TextFormatMutableBean bean = new TextFormatMutableBeanImpl();
		
		Map<String, String> attributes = reader.getAttributes();
		
		bean.setTextType(StaxStructureUtil.getAttributeAsTextType(attributes, "textType", false));
		bean.setSequence(StaxStructureUtil.getAttributeAsTeritaryBoolean(attributes, "isSequence", false));
		bean.setInterval(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "interval", false));
		bean.setStartValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "startValue", false));
		bean.setEndValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "endValue", false));
		bean.setTimeInterval(StaxStructureUtil.getAttribute(attributes, "timeInterval", false));
		bean.setStartTime(StaxStructureUtil.getAttributeAsDate(attributes, "startTime", false));
		bean.setEndTime(StaxStructureUtil.getAttributeAsDate(attributes, "endTime", false));
		bean.setMinLength(StaxStructureUtil.getAttributeAsBigInteger(attributes, "minLength", false));
		bean.setMaxLength(StaxStructureUtil.getAttributeAsBigInteger(attributes, "maxLength", false));
		bean.setMinValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "minValue", false));
		bean.setMaxValue(StaxStructureUtil.getAttributeAsBigDecimal(attributes, "maxValue", false));
		bean.setDecimals(StaxStructureUtil.getAttributeAsBigInteger(attributes, "decimals", false));
		bean.setPattern(StaxStructureUtil.getAttribute(attributes, "pattern", false));
		bean.setMultiLingual(StaxStructureUtil.getAttributeAsTeritaryBoolean(attributes, "isMultiLingual", false));
		return bean;
		
	}
}
