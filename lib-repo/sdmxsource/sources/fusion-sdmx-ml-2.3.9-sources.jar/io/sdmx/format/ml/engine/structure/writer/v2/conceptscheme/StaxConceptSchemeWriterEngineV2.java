package io.sdmx.format.ml.engine.structure.writer.v2.conceptscheme;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxNameableWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;


public class StaxConceptSchemeWriterEngineV2 extends AbstractV2Writer<ConceptSchemeBean> implements IFusionSingleton {
	private static StaxConceptSchemeWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxConceptSchemeWriterEngineV2() {}
	public static StaxConceptSchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxConceptSchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "ConceptScheme";
	}

	@Override
	protected void writeMaintainableInternal(ConceptSchemeBean maint, StaxWriter writer) {
		writeConcepts(maint.getItems(), writer);
	}

	private void writeConcepts(List<ConceptBean> concepts, StaxWriter writer) {
		for(ConceptBean concept : concepts) {
		    Map<String, String> attrs = new HashMap<>();
		    RepresentationBean coreRepresentation = concept.getRepresentation();
            if (coreRepresentation != null &&
                coreRepresentation.getRepresentation() != null) {
            	ICrossReferenceBean<? extends EnumeratedListBean> maintRef = coreRepresentation.getRepresentation();
                attrs.put("coreRepresentation", maintRef.getReference().getMaintainableId());
                attrs.put("coreRepresentationAgency", maintRef.getReference().getAgencyId());
            }
            if(concept.getParentConcept() != null) {
                attrs.put("parent", concept.getParentConcept());
            }

			StaxNameableWriterUtilV2.writeBean(concept, "Concept", writer, attrs);

			StaxAnnotableWriterUtilV2.writeAnnotations(concept.getAnnotations(), writer);

			writer.writeEndElement(); //End Concept
		}
	}
}
