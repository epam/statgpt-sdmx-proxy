package io.sdmx.format.ml.engine.schema;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataAttributeContainer;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataAttributeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.metadata.MetadataStructureSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.resource.PropertiesToMap;

/**
 * Placeholder for possible future work - not used except for test case
 */
public class ReferenceMetadataSchemaGenerator {
	private static final String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";
	private Map<SDMX_SCHEMA, String> schemaLocationMap = new HashMap<>();

	public ReferenceMetadataSchemaGenerator(Properties properties) {
		if (properties == null) {
			properties = new Properties();
		}
		Map<String, String> propsMap = PropertiesToMap.createMap(properties);
		for(String schemaVersion : propsMap.keySet()) {
			schemaLocationMap.put(SDMX_SCHEMA.valueOf(schemaVersion), propsMap.get(schemaVersion));
		}
	}

	public void generateSchema(MetadataStructureSuperBean msdSB, OutputStream out)  {
		if(msdSB == null) {
			throw new RuntimeException("Can not generate schema, no Metadata Structure supplied");
		}
		try {
			generateSchemaInternal(msdSB, out);
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}
	}

	private void generateSchemaInternal(MetadataStructureSuperBean msdSB, OutputStream out) throws XMLStreamException {
		XMLOutputFactory xmlOutputfactory = XMLOutputFactory.newInstance();

		String encoding = StandardCharsets.UTF_8.toString();
		XMLStreamWriter writer = xmlOutputfactory.createXMLStreamWriter(out, encoding);
		writer.writeStartDocument(encoding, "1.0");

		writer.writeStartElement("xs", "schema", SCHEMA_NS);    // Start Schema - not ended till end of document
		writer.writeNamespace("xs", SCHEMA_NS);
		writer.writeAttribute("version", "1.0");

		Set<EnumeratedListBean<EnumeratedItemBean>> codelists = new HashSet<>();
		extractCodelists(msdSB, codelists);
		for(EnumeratedListBean<EnumeratedItemBean> cl : codelists) {
			writeCodelist(writer, null, cl);
		}
		writer.writeStartElement(SCHEMA_NS, "element");
		writer.writeAttribute("name", msdSB.getId());
		processMetadataAttributeContainer(writer, null, msdSB);
		writer.writeEndElement();
		writer.writeEndElement();
		writer.writeEndDocument();
		writer.flush();
		writer.close();
	}

	private void extractCodelists(MetadataAttributeContainer mac, Set<EnumeratedListBean<EnumeratedItemBean>> set) {
		for(MetadataAttributeSuperBean maSb : mac.getMetadataAttributes()) {
			EnumeratedListBean<EnumeratedItemBean> cl = maSb.getCodelist(true);
			if(cl != null) {
				set.add(cl);
			}
			extractCodelists(maSb, set);
		}
	}

	private void processMetadataAttributeContainer(XMLStreamWriter writer, MetadataAttributeSuperBean parent, MetadataAttributeContainer mac) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "complexType");
		if(mac != null && ObjectUtil.validCollection(mac.getMetadataAttributes())) {
			writer.writeStartElement(SCHEMA_NS, "sequence");
			for(MetadataAttributeSuperBean maSb : mac.getMetadataAttributes()) {
				writer.writeStartElement(SCHEMA_NS, "element");
				writer.writeAttribute("name", maSb.getId());
				if(maSb.getBuiltFrom().getMinOccurs() >= 0) {
					writer.writeAttribute("minOccurs", Integer.toString(maSb.getBuiltFrom().getMinOccurs()));
				}
				if(maSb.getBuiltFrom().getMaxOccurs() >= 0) {
					writer.writeAttribute("maxOccurs",Integer.toString(maSb.getBuiltFrom().getMaxOccurs()));
				}

				//Recursive
				processMetadataAttributeContainer(writer, maSb, maSb);
				writer.writeEndElement();  // end element
			}
			writer.writeEndElement();  // end sequence
		}
		writeAllowableContent(writer, parent);
		writer.writeEndElement();  // end complexType
	}

	private void writeAllowableContent(XMLStreamWriter writer, MetadataAttributeSuperBean parent) throws XMLStreamException {
		if(parent != null) {
			if(parent.getCodelist(true) != null) {
				writer.writeStartElement(SCHEMA_NS, "attribute");
				writer.writeAttribute("name", "value");
				writer.writeAttribute("use", "required");
				writer.writeAttribute("type", getCodelistReference(parent.getCodelist(true)));
				writer.writeEndElement();  // end attribute
			} else {
				TextFormatBean tf = parent.getTextFormat();
				if(tf != null && tf.getTextType() != null) {
					writer.writeStartElement(SCHEMA_NS, "attribute");
					writer.writeAttribute("name", "value");
					writer.writeAttribute("use", "required");
					String type = "xs:string";
					type = determineSchemaType(tf, tf.getTextType());
					writer.writeAttribute("type", type);
					writer.writeEndElement();  // end attribute
				}
			}
		}
	}


	private void writeCodelist(XMLStreamWriter writer, Map<String, Set<String>> validCodeMap, EnumeratedListBean<EnumeratedItemBean> codelist) throws XMLStreamException {
		writer.writeStartElement(SCHEMA_NS, "simpleType");
		writer.writeAttribute("name", getCodelistReference(codelist));
		writer.writeStartElement(SCHEMA_NS, "restriction");
		writer.writeAttribute("base", "xs:string");
		for(EnumeratedItemBean code : codelist.getItems()) {
			processCode(writer, code);
		}
		writer.writeEndElement();	// End restriction
		writer.writeEndElement();	// End simpleType
	}

	private  String getCodelistReference(EnumeratedListBean<EnumeratedItemBean> codelist) {
		String version = codelist.getVersion().toString().replaceAll("\\.", "_");
		return codelist.getAgencyId() + "." + codelist.getId() + "." + version;
	}

	private void processCode(XMLStreamWriter writer, EnumeratedItemBean code) throws XMLStreamException {
		boolean validForOutput = true;
		if(validForOutput) {
			writer.writeStartElement(SCHEMA_NS, "enumeration");
			writer.writeAttribute("value", code.getId());
			writer.writeStartElement(SCHEMA_NS, "annotation");
			for(TextTypeWrapper tt : code.getDescriptions()) {
				writer.writeStartElement(SCHEMA_NS, "documentation");
				writer.writeAttribute("xml:lang", tt.getLocale());
				writer.writeCharacters(tt.getValue());
				writer.writeEndElement();	// End Documentation
			}
			writer.writeEndElement();  // End Annotation
			writer.writeEndElement();  // End Enumeration
		}
	}

	protected String determineSchemaType(TextFormatBean tf, TEXT_TYPE textType) {
		switch(textType) {
		case ALPHA :
			return "common:AlphaType";

		case ALPHA_NUMERIC:
			return "common:AlphaNumericType";

		case BASIC_TIME_PERIOD:
			return "common:BasicTimePeriodType";

		case BIG_INTEGER:
			return "xs:integer";

		case BOOLEAN:
			return "xs:boolean";

		case COUNT:
			return "xs:integer";

		case DATE_TIME:
			return "xs:dateTime";

		case DAY:
			return "xs:gDay";

		case DECIMAL:
			return "xs:decimal";

		case DOUBLE:
			if(tf.getDecimals() != null) {
				//FR-1598 Exported Schema contains fractionDigits for OBS_VALUE which is not allowed
				return "xs:decimal";
			}
			return "xs:double";

		case DURATION:
			return "xs:duration";

		case EXCLUSIVE_VALUE_RANGE:
			return "xs:decimal";

		case FLOAT:
			return "xs:float";

		case GREGORIAN_DAY:
			return "xs:date";

		case GREGORIAN_TIME_PERIOD:
			return "common:GregorianTimePeriodType";

		case GREGORIAN_YEAR:
			return "xs:gYear";

		case GREGORIAN_YEAR_MONTH:
			return "xs:gYearMonth";

		case INCLUSIVE_VALUE_RANGE:
			return "xs:decimal";

		case INCREMENTAL:
			return "xs:decimal";

		case INTEGER:
			return "xs:int";

		case LONG:
			return "xs:long";

		case MONTH:
			return "xs:gMonth";

		case MONTH_DAY:
			return "xs:gMonthDay";

		case NUMERIC:
			return "common:NumericType";

		case OBSERVATIONAL_TIME_PERIOD:
			return "common:ObservationalTimePeriodType";

		case REPORTING_DAY:
			return "common:ReportingDayType";

		case REPORTING_MONTH:
			return "common:ReportingMonthType";

		case REPORTING_QUARTER:
			return "common:ReportingQuarterType";

		case REPORTING_SEMESTER:
			return "common:ReportingSemesterType";

		case REPORTING_TIME_PERIOD:
			return "common:ReportingTimePeriodType";

		case REPORTING_TRIMESTER:
			return "common:ReportingTrimesterType";

		case REPORTING_WEEK:
			return "common:ReportingWeekType";

		case REPORTING_YEAR:
			return "common:ReportingYearType";

		case SHORT:
			return "xs:short";

		case STANDARD_TIME_PERIOD:
			return "common:StandardTimePeriodType";

		case STRING:
			return "xs:string";

		case TIME:
			return "xs:time";

		case URI:
			return "xs:anyURI";

		case XHTML:
			return "common:StructuredText";
		default:
			return "xs:string";
		}
	}

}
