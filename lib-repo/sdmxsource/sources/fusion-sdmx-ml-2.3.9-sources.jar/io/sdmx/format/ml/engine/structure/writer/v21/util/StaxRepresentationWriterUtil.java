package io.sdmx.format.ml.engine.structure.writer.v21.util;

import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxRepresentationWriterUtil {

	public static void writeRepresentation(RepresentationBean representation, StaxWriter writer, String elementName) {
		writeRepresentation(representation, writer, elementName, true);
	}
	
	public static void writeRepresentation(RepresentationBean representation, StaxWriter writer, String elementName, boolean incMultiLingual) {
		if(representation != null) {
			writer.writeStartElement(StaxStructureWriterUtil.STRCUTURE_NS, elementName);
			
			if(representation.getRepresentation() == null) {
				StaxTextFormatWriterUtil.writeTextFormat(representation.getTextFormat(), writer, "TextFormat", incMultiLingual);
			} else {
				StaxRefUtil.writeReference(representation.getRepresentation(), writer, "Enumeration");
				StaxTextFormatWriterUtil.writeTextFormat(representation.getTextFormat(), writer, "EnumerationFormat", incMultiLingual);
			}
			
			writer.writeEndElement();
		}
	}
}
