package io.sdmx.format.ml.engine.structure.reader.v3.transformation;

import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationMutableBean;
import io.sdmx.api.sdmx.model.mutable.transformation.INamePersonalisationSchemeMutableBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.transformation.NamePersonalisationMutableBean;
import io.sdmx.im.mutable.transformation.NamePersonalisationSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxNamePersonalisationSchemeReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<INamePersonalisationSchemeMutableBean> implements IFusionSingleton {
	private static StaxNamePersonalisationSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxNamePersonalisationSchemeReaderEngineV3() {}

	public static StaxNamePersonalisationSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxNamePersonalisationSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	public String getContainerNodeName() {
		return "NamePersonalisationSchemes";
	}
	
	@Override
	protected String getRootNodeName() {
		return "NamePersonalisationScheme";
	}

	@Override
	protected INamePersonalisationSchemeMutableBean processMaintainable(IStaxReader reader) {
		INamePersonalisationSchemeMutableBean maint = new NamePersonalisationSchemeMutableBean();
		maint.setVtlVersion(reader.getAttributeValue(null, "vtlVersion"));
		StaxItemSchemeUtil.processBean(maint, reader);
		while(reader.isStartElement()) {
			if(!reader.getElementName().equals("NamePersonalisation")) {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			INamePersonalisationMutableBean item = readItem(reader);
			maint.addItem(item);
			reader.moveNextNode();
		}
		return maint;
	}

	private INamePersonalisationMutableBean readItem(IStaxReader reader) {
		INamePersonalisationMutableBean item = new NamePersonalisationMutableBean();
		item.setVtlArtefact(reader.getAttributeValue("vtlArtefact"));
		StaxNameableUtil.processBean(item, reader);
		do {
			if(reader.isStartElement()) {
				switch(reader.getElementName()) {
				case "VtlDefaultName" :
					item.setVtlDefaultName(reader.getElementText());
					break;
				case "PersonalisedName" :
					item.setPersonalisedName(reader.getElementText());
					break;
				}
			} else if(reader.getElementName().equals("NamePersonalisation")) {
				break;
			}
		} while(reader.moveNextNode());
		return item;
	}
}
