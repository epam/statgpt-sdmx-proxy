package io.sdmx.format.ml.engine.structure.reader.v3.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.ItemMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.ItemSchemeMutableBean;
import io.sdmx.format.ml.util.StaxStructureUtil;

public class StaxItemSchemeUtilV3  {
	
	public static void processBean(ItemSchemeMutableBean<? extends ItemMutableBean> bean, IStaxReader reader) {
		boolean isPartial = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "isPartial", false, false);
		bean.setPartial(isPartial);
		StaxMaintainableUtilV3.processBean(bean, reader);
	}
}
