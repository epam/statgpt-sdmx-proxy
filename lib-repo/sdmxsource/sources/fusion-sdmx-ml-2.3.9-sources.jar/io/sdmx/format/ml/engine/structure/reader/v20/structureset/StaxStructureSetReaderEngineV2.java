package io.sdmx.format.ml.engine.structure.reader.v20.structureset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TO_VALUE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.mutable.base.AnnotationMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.SchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.StructureMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CategorySchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.CodelistMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ComponentMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ConceptSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.ItemSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.OrganisationSchemeMapMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.RepresentationMapRefMutableBean;
import io.sdmx.api.sdmx.model.mutable.mapping.StructureSetMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxMaintainableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxNameableUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v20.util.StaxStructureUtilV2;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxAnnotableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxTextFormatUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.mapping.CategorySchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.CodelistMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ComponentMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ConceptSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.ItemMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.OrganisationSchemeMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.RepresentationMapRefMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureMapMutableBeanImpl;
import io.sdmx.im.mutable.mapping.StructureSetMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class StaxStructureSetReaderEngineV2 extends AbstractStaxMaintainableReaderEngine<StructureSetMutableBean> {
	private static StaxStructureSetReaderEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxStructureSetReaderEngineV2() {}
	public static StaxStructureSetReaderEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxStructureSetReaderEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "StructureSets";
    }
    
    @Override
    protected String getRootNodeName() {
        return "StructureSet";
    }

    @Override
    protected StructureSetMutableBean processMaintainable(IStaxReader reader) {
		StructureSetMutableBean maint = new StructureSetMutableBeanImpl();
		StaxMaintainableUtilV2.processBean(maint, reader);

		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("RelatedStructures")) {
			    processRelatedStructures(maint, reader);
			} else if(elementName.equals("StructureMap")) {
			    maint.addStructureMap(processStructureMap(reader, maint));
			}  else if(elementName.equals("CodelistMap")) {
			    maint.addCodelistMap(processCodelistMap(reader));
			} else if(elementName.equals("CategorySchemeMap")) {
			    maint.addCategorySchemeMap(processCategoryScheme(reader));
			} else if(elementName.equals("ConceptSchemeMap")) {
			    maint.addConceptSchemeMap(processConceptSchemeMap(reader));
			} else if(elementName.equals("OrganisationSchemeMap")) {
				maint.addOrganisationSchemeMap(processOrganisationScheme(reader));
			} else if(reader.getElementName().equals("Annotations")) {
                StaxAnnotableUtil.processAnnotations(maint, reader);
            } else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return maint;
	}

	private void processRelatedStructures(StructureSetMutableBean maint, IStaxReader reader) {
	    while (!(reader.getElementName().equals("RelatedStructures") && !reader.isStartElement())) {
	        reader.moveNextNode();
            if (reader.getElementName().equals("KeyFamilyRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.DSD, "KeyFamilyID", "KeyFamilyAgencyID", maint, reader);
            }
            if (reader.getElementName().equals("MetadataStructureRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.MSD, "MetadataStructureID", "MetadataStructureAgencyID", maint, reader);
            }
            if (reader.getElementName().equals("ConceptSchemeRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, "ConceptSchemeID", "AgencyID", maint, reader);
            }
            if (reader.getElementName().equals("CategorySchemeRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME, "CategorySchemeID", "AgencyID", maint, reader);
            }
            if (reader.getElementName().equals("OrganisationSchemeRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME, "OrganisationSchemeID", "AgencyID", maint, reader);
            }
            if (reader.getElementName().equals("HierarchicalCodelistRef")) {
                processRelatedStructureRef(SDMX_STRUCTURE_TYPE.HIERARCHY, "HierarchicalCodelistID", "AgencyID", maint, reader);
            }
	    }
    }

	private void processRelatedStructureRef(SDMX_STRUCTURE_TYPE strucType, String idNode, String acyNode, StructureSetMutableBean maint, IStaxReader reader) {
        reader.moveNextNode();
        String agencyId = null;
        String maintainableId = null;
        String version = null;
        String urn = null;

        while(reader.isStartElement()) {
            String nodeName = reader.getElementName();
            if(nodeName.equals("URN")) {
                urn = reader.getElementText();
            } else if(nodeName.equals(idNode)) {
                maintainableId = reader.getElementText();
            } else if(nodeName.equals(acyNode)) {
                agencyId = reader.getElementText();
            } else if(nodeName.equals("Version")) {
                version = reader.getElementText();
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            reader.moveNextNode();
        }

        StructureReferenceBean sRef;
        if (ObjectUtil.validOneString(agencyId, maintainableId, version)) {
            sRef = new StructureReferenceBeanImpl(agencyId, maintainableId, version, strucType);
        } else {
            sRef = new StructureReferenceBeanImpl(urn, strucType);
        }

        maint.addRelatedStructure(sRef);
    }

    private OrganisationSchemeMapMutableBean processOrganisationScheme(IStaxReader reader) {
		OrganisationSchemeMapMutableBean orgMap = new OrganisationSchemeMapMutableBeanImpl();
		processOrganisationSchemeMap(orgMap, reader, null);
//		processCodeMap(orgMap, reader);
		return orgMap;
	}

	private CodelistMapMutableBean processCodelistMap(IStaxReader reader) {
		CodelistMapMutableBean codelistMap = new CodelistMapMutableBeanImpl();
		processMapScheme(codelistMap, reader, SDMX_STRUCTURE_TYPE.CODE_LIST);
		processCodeMap(codelistMap, reader);
		return codelistMap;
	}

	private CategorySchemeMapMutableBean processCategoryScheme(IStaxReader reader) {
		CategorySchemeMapMutableBean csMap = new CategorySchemeMapMutableBeanImpl();
		procesCategorySchemeMap(csMap, reader, SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME);
		processCategoryMap(csMap, reader);
		return csMap;
	}


	private ConceptSchemeMapMutableBean processConceptSchemeMap(IStaxReader reader) {
		ConceptSchemeMapMutableBean conceptSchemeMap = new ConceptSchemeMapMutableBeanImpl();
		procesConceptSchemeMap(conceptSchemeMap, reader, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
		processConceptMap(conceptSchemeMap, reader);
		return conceptSchemeMap;
	}

	private StructureMapMutableBean processStructureMap(IStaxReader reader, StructureSetMutableBean ss) {
		StructureMapMutableBean structureMap = new StructureMapMutableBeanImpl();
		processMapScheme(structureMap, reader, null);

		while(reader.isStartElement()) {
			while(reader.isStartElement()) {
				StaxAnnotableUtil.processBean(structureMap, reader);

				ComponentMapMutableBean compMap = new ComponentMapMutableBeanImpl();
				StaxStructureUtil.checkStartNode(reader, "Source");
				compMap.addMapConceptRef(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();

				StaxStructureUtil.checkStartNode(reader, "Target");
				compMap.addMapTargetConceptRef(StaxStructureUtil.getLocalReference(reader));
				reader.moveNextNode();

				List<AnnotationMutableBean> annotations =  structureMap.getAnnotations();
				if(annotations != null) {
					List<AnnotationMutableBean> newAnnotations = new ArrayList<>();
					for(AnnotationMutableBean annotationMutableBean : annotations) {
						if("SOURCE".equals(annotationMutableBean.getTitle())) {
							compMap.addMapConceptRef(annotationMutableBean.getId());
						} else if("TARGET".equals(annotationMutableBean.getTitle())) {
							compMap.addMapTargetConceptRef(annotationMutableBean.getId());
						} else {
							newAnnotations.add(annotationMutableBean);
						}
						structureMap.setAnnotations(newAnnotations);
					}
				}

				if(reader.isStartElement() && reader.getElementName().equals("RepresentationMapping")) {
					compMap.setRepMapRef(processRepresentationMapRef(reader, ss));
					reader.moveNextNode();
				}
				structureMap.addComponent(compMap);
			}
			reader.moveNextNode();
		}

		return structureMap;
	}

	private RepresentationMapRefMutableBean processRepresentationMapRef(IStaxReader reader, StructureSetMutableBean ss) {
		RepresentationMapRefMutableBean repMap = new RepresentationMapRefMutableBeanImpl();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("CodelistMap")) {
					repMap.setCodelistMapRef(StaxStructureUtil.getLocalReference(reader));
				} else if(nodeName.equals("ToTextFormat")) {
					repMap.setToTextFormat(StaxTextFormatUtil.processBean(reader));
				} else if(nodeName.equals("ToValueType")) {
					String toValue = reader.getElementText();
					if(toValue.equals("Name")) {
						repMap.setToValueType(TO_VALUE.NAME);
					} else if(toValue.equals("Description")) {
						repMap.setToValueType(TO_VALUE.DESCRIPTION);
					} else if(toValue.equals("Value")) {
						repMap.setToValueType(TO_VALUE.VALUE);
					} else {
						throw new SdmxSemmanticException("Unexpected ToValueType of '"+toValue+"'.  Expecting 'Name', 'Description', or 'Value'");
					}
				} else if(nodeName.equals("ValueMap")) {
					repMap.setValueMappings(processValueMap(reader));
				}
			} else if(nodeName.equals("RepresentationMapping")) {
				break;
			}
		}
		return repMap;
	}

	private Map<String, Set<String>> processValueMap(IStaxReader reader) {
		Map<String, Set<String>> returnMap = new LinkedHashMap<>();

		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("ValueMapping")) {
					String source = StaxStructureUtil.getAttribute(reader.getAttributes(), "source", false);
					String target = StaxStructureUtil.getAttribute(reader.getAttributes(), "target", false);
					if(!ObjectUtil.validOneString(source, target)) {
						throw new SdmxSemmanticException("Value Mapping has an empty source value mapped to an empty target value, this is not allowed");
					}
					if(source == null) {
						source = "";
					}
					if(target == null) {
						target = "";
					}
					Set<String> targetSet = returnMap.get(source);
					if(targetSet == null) {
						targetSet = new HashSet<>();
						returnMap.put(source, targetSet);
					}
					targetSet.add(target);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals("ValueMap")) {
				break;
			}
		}
		return returnMap;
	}


	private void processMapScheme(SchemeMapMutableBean map, IStaxReader reader, SDMX_STRUCTURE_TYPE targetStructure) {
	    map.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
	    reader.moveNextNode();
        while(StaxNameableUtilV2.processNode(map, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }

        if (reader.getElementName().equals("CodelistRef") ||
            reader.getElementName().equals("HierarchicalCodelistRef")) {
            if (reader.getElementName().equals("CodelistRef")) {
                map.setSourceRef(StaxStructureUtilV2.processCodelistRef(reader, "CodelistRef"));
            } else {
                // FUNC HierarchicalCodelistRef
            }
            reader.moveNextNode();
        } else {
            throw new SdmxSemmanticException("Missing expected XML element - either: 'CodelistRef' or 'HierarchicalCodelistRef' expected");
        }

        if (reader.getElementName().equals("TargetCodelistRef") ||
            reader.getElementName().equals("TargetHierarchicalCodelistRef")) {
            if (reader.getElementName().equals("TargetCodelistRef")) {
                map.setTargetRef(StaxStructureUtilV2.processCodelistRef(reader, "TargetCodelistRef"));
            } else {
                // FUNC TargetHierarchicalCodelistRef
            }
            reader.moveNextNode();
        } else {
            throw new SdmxSemmanticException("Missing expected XML element - either: 'TargetCodelistRef' or 'TargetHierarchicalCodelistRef' expected");
	    }
	}

	private void processOrganisationSchemeMap(OrganisationSchemeMapMutableBean map, IStaxReader reader, SDMX_STRUCTURE_TYPE targetStructure) {
        map.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
        reader.moveNextNode();
        while(StaxNameableUtilV2.processNode(map, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }

        if (!reader.getElementName().equals("OrganisationSchemeRef")) {
            throw new SdmxSemmanticException("Missing expected XML element - 'OrganisationSchemeRef' expected");
        }
        StructureReferenceBean organisationSchemeRef = StaxStructureUtilV2.processOrganisationSchemeRef(reader, "OrganisationSchemeRef");
        map.setSourceRef(organisationSchemeRef);

        reader.moveNextNode();
        if (!reader.getElementName().equals("TargetOrganisationSchemeRef")) {
            throw new SdmxSemmanticException("Missing expected XML element - 'TargetOrganisationSchemeRef' expected");
        }
        StructureReferenceBean targetOrganisationSchemeRef = StaxStructureUtilV2.processOrganisationSchemeRef(reader, "TargetOrganisationSchemeRef");
        map.setTargetRef(targetOrganisationSchemeRef);

        reader.moveNextNode();
        processOrganisationMap(map, reader);
    }

	private void procesConceptSchemeMap(SchemeMapMutableBean map, IStaxReader reader, SDMX_STRUCTURE_TYPE targetStructure) {
        map.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
        reader.moveNextNode();
        while(StaxNameableUtilV2.processNode(map, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }

        if (reader.getElementName().equals("ConceptSchemeRef")) {
            map.setSourceRef(StaxStructureUtilV2.processConceptSchemeRef(reader, "ConceptSchemeRef"));
            reader.moveNextNode();
        } else {
            throw new SdmxSemmanticException("Missing expected XML element - expected: 'ConceptSchemeRef'");
        }

        if (reader.getElementName().equals("TargetConceptSchemeRef")) {
            map.setTargetRef(StaxStructureUtilV2.processConceptSchemeRef(reader, "TargetConceptSchemeRef"));
            reader.moveNextNode();
        } else {
            throw new SdmxSemmanticException("Missing expected XML element - expected: 'TargetConceptSchemeRef'");
        }
    }

	private void procesCategorySchemeMap(SchemeMapMutableBean map, IStaxReader reader, SDMX_STRUCTURE_TYPE targetStructure) {
	    map.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
	    reader.moveNextNode();
	    while(StaxNameableUtilV2.processNode(map, reader)) {
	        //Processing Nodes
	        reader.moveNextNode();
	    }

	    if (reader.getElementName().equals("CategorySchemeRef")) {
	        map.setSourceRef(StaxStructureUtilV2.processCategorySchemeRef(reader, "CategorySchemeRef"));
	        reader.moveNextNode();
	    } else {
	        throw new SdmxSemmanticException("Missing expected XML element - expected: 'CategorySchemeRef'");
	    }

	    if (reader.getElementName().equals("TargetCategorySchemeRef")) {
	        map.setTargetRef(StaxStructureUtilV2.processCategorySchemeRef(reader, "TargetCategorySchemeRef"));
	        reader.moveNextNode();
	    } else {
	        throw new SdmxSemmanticException("Missing expected XML element - expected: 'TargetCategorySchemeRef'");
	    }
	}

	private void processCodeMap(ItemSchemeMapMutableBean map, IStaxReader reader) {
	    while(reader.isStartElement() && reader.getElementName().equals("CodeMap")) {
	        reader.moveNextNode();
	        ItemMapMutableBean itemMap = new CodeMapMutableBeanImpl();
//	        if(map instanceof CodelistMapMutableBean){
//	            itemMap = new CodeMapMutableBeanImpl();
//	        }

	        StaxStructureUtil.checkStartNode(reader, "MapCodeRef");
	        itemMap.setSourceId(reader.getElementText());
	        reader.moveNextNode();

	        StaxStructureUtil.checkStartNode(reader, "MapTargetCodeRef");
	        itemMap.setTargetId(reader.getElementText());
	        reader.moveNextNode();

	        map.addItem(itemMap);
	        reader.moveNextNode();
	    }

	}

	private void processConceptMap(ItemSchemeMapMutableBean map, IStaxReader reader) {
        while(reader.isStartElement() && reader.getElementName().equals("ConceptMap")) {
            reader.moveNextNode();
            ItemMapMutableBean itemMap = new ItemMapMutableBeanImpl();

            StaxStructureUtil.checkStartNode(reader, "ConceptID");
            itemMap.setSourceId(reader.getElementText());
            reader.moveNextNode();

            StaxStructureUtil.checkStartNode(reader, "TargetConceptID");
            itemMap.setTargetId(reader.getElementText());
            reader.moveNextNode();

            map.addItem(itemMap);
            reader.moveNextNode();
        }
    }

	private void processOrganisationMap(OrganisationSchemeMapMutableBean map, IStaxReader reader) {
        while(reader.isStartElement() && reader.getElementName().equals("OrganisationMap")) {
            reader.moveNextNode();
            ItemMapMutableBean itemMap = new ItemMapMutableBeanImpl();

            StaxStructureUtil.checkStartNode(reader, "OrganisationID");
            itemMap.setSourceId(reader.getElementText());
            reader.moveNextNode();

            StaxStructureUtil.checkStartNode(reader, "TargetOrganisationID");
            itemMap.setTargetId(reader.getElementText());
            reader.moveNextNode();

            map.addItem(itemMap);
            reader.moveNextNode();
        }

    }

	/**
	 * Expected start node: CategoryMap
	 * @param map
	 * @param reader
	 */
	private void processCategoryMap(ItemSchemeMapMutableBean map, IStaxReader reader) {
        while(reader.isStartElement() && reader.getElementName().equals("CategoryMap")) {
            // TODO: categoryAlias
            ItemMapMutableBean itemMap = new ItemMapMutableBeanImpl();

            reader.moveNextNode();
            StaxStructureUtil.checkStartNode(reader, "CategoryID");
            processCategoryIDNode("CategoryID", map, itemMap, reader);

            reader.moveNextNode();

            StaxStructureUtil.checkStartNode(reader, "TargetCategoryID");
            processCategoryIDNode("TargetCategoryID", map, itemMap, reader);

            map.addItem(itemMap);
            reader.moveNextNode();
            reader.moveNextNode();
        }
	}

	/**
	 * Expected start node: CategoryID
	 */
	private void processCategoryIDNode(String expectedEndNode, ItemSchemeMapMutableBean map, ItemMapMutableBean itemMap, IStaxReader reader) {
        reader.moveNextNode();
        StaxStructureUtil.checkStartNode(reader, "ID");

        if (expectedEndNode.equals("CategoryID")) {
            itemMap.setSourceId(reader.getElementText());
        } else {
            itemMap.setTargetId(reader.getElementText());
        }

        while (reader.moveNextNode()) {

            if (!reader.isStartElement() && reader.getElementName().contentEquals(expectedEndNode)) {
                return;
            }

            if (reader.getElementName().contentEquals("CategoryVersion")) {
                // TODO
                reader.moveNextNode();
            } else if (reader.getElementName().equals("CategoryID")) {
                processCategoryIDNode("CategoryID", map, itemMap, reader);
                reader.moveNextNode();
                return;
            } else {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
        }
    }
}
