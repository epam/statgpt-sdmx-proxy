package io.sdmx.format.ml.engine.structure.writer.v1.codelist;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v1.AbstractV1Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxCodelistWriterEngineV1 extends AbstractV1Writer<CodelistBean> implements IFusionSingleton {
	private static StaxCodelistWriterEngineV1 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCodelistWriterEngineV1() {}

	public static StaxCodelistWriterEngineV1 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCodelistWriterEngineV1();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CodeList";
	}

	private void writeElement(MaintainableBean maint, StaxWriter writer) {
	    Map<String, String> attributes = new HashMap<>();
	    attributes.put("id", maint.getId());
        attributes.put("version", maint.getVersion().toString());
        attributes.put("agency", maint.getAgencyId());

        if (maint.getUri() != null) {
            attributes.put("uri", maint.getUri().toString());
        }
        if (maint.isExternalReference()) {
            attributes.put("isExternalReference", Boolean.toString(maint.isExternalReference()));
        }

        String elementName = "CodeList";

        writer.writeElement(NS, elementName, attributes);
        StaxTextWriterUtilV2.writeTextTypes(maint.getNames(), writer, "Name");
	}

	@Override
	protected void writeMaintainableInternal(CodelistBean maint, StaxWriter writer) {
	    writeElement(maint, writer);
        writeCodes(maint.getItems(), writer);
        StaxAnnotableWriterUtilV2.writeBean(maint, writer);
        writer.writeEndElement();
	}

	private void writeCodes(List<CodeBean> codes, StaxWriter writer) {
		for(CodeBean code : codes) {
		    Map<String, String> attributes = new HashMap<>();
		    attributes.put("value", code.getId());

		    writer.writeElement(NS, "Code", attributes);
		    StaxTextWriterUtilV2.writeTextTypes(code.getNames(), writer, "Description");

		    StaxAnnotableWriterUtilV2.writeAnnotations(code.getAnnotations(), writer);
		    writer.writeEndElement(); // End code
		}
	}
}
