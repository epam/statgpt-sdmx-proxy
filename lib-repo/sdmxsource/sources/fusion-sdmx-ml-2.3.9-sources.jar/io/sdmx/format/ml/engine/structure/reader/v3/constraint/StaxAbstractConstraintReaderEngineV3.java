package io.sdmx.format.ml.engine.structure.reader.v3.constraint;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.registry.IConstrainedKeyValue;
import io.sdmx.api.sdmx.model.mutable.registry.ConstrainedDataKeyMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintAttachmentMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintDataKeySetMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ConstraintMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.beans.registry.ConstrainedKeyValue;
import io.sdmx.im.mutable.registry.ConstrainedDataKeyMutableBeanImpl;
import io.sdmx.im.mutable.registry.ConstraintDataKeySetMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintAttachmentMutableBeanImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public abstract class StaxAbstractConstraintReaderEngineV3<T extends ConstraintMutableBean> extends AbstractStaxMaintainableReaderEngine<T> {

	protected void processDataKeySet(IStaxReader reader, ConstraintMutableBean constraint) {
		ConstraintDataKeySetMutableBean includedKeys = new ConstraintDataKeySetMutableBeanImpl();
		ConstraintDataKeySetMutableBean excludedKeys = new ConstraintDataKeySetMutableBeanImpl();
		processConstraintKey(reader, includedKeys, excludedKeys);
		if(ObjectUtil.validCollection(includedKeys.getConstrainedDataKeys())) {
			constraint.setIncludedSeriesKeys(includedKeys);
		}
		if(ObjectUtil.validCollection(excludedKeys.getConstrainedDataKeys())) {
			constraint.setExcludedSeriesKeys(excludedKeys);
		}
	}
	
	protected void processMetadataKeySet(IStaxReader reader, ConstraintMutableBean constraint) {
		ConstraintDataKeySetMutableBean includedKeys = new ConstraintDataKeySetMutableBeanImpl();
		ConstraintDataKeySetMutableBean excludedKeys = new ConstraintDataKeySetMutableBeanImpl();
		processConstraintKey(reader, includedKeys, excludedKeys);
		if(ObjectUtil.validCollection(includedKeys.getConstrainedDataKeys())) {
			constraint.setIncludedMetadataKeys(includedKeys);
		}
		if(ObjectUtil.validCollection(excludedKeys.getConstrainedDataKeys())) {
			constraint.setExcludedMetadataKeys(excludedKeys);
		}
	}

	private void processConstraintKey(IStaxReader reader,
			ConstraintDataKeySetMutableBean includedKeys,
			ConstraintDataKeySetMutableBean excludedKeys) {

		boolean isIncluded = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "isIncluded", true, true);
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				StaxStructureUtil.checkStartNode(reader, "Key");
				Map<String, String> attributes = reader.getAttributes();
				String validFrom = attributes.get("validFrom");
				String validTo = attributes.get("validTo");
				
				Boolean isStillIncluded;
				String asString = StaxStructureUtil.getAttribute(attributes, "include", false);
				if(asString == null) {
					isStillIncluded = null;
				} else {
					isStillIncluded = Boolean.valueOf(asString);
				}
				
				ConstrainedDataKeyMutableBean key = processConstraintKeyValues(reader);
				key.setValidFrom(validFrom);
				key.setValidTo(validTo);
				if(isIncluded) {
					if(isStillIncluded != null && isStillIncluded.booleanValue() == false) {
						excludedKeys.addConstrainedDataKey(key);
					} else {
						includedKeys.addConstrainedDataKey(key);
					}
				} else {
					if(isStillIncluded != null && isStillIncluded.booleanValue() == false) {
						includedKeys.addConstrainedDataKey(key);
					} else {
						excludedKeys.addConstrainedDataKey(key);
					}
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
	}

	private ConstrainedDataKeyMutableBean processConstraintKeyValues(IStaxReader reader) {
		ConstrainedDataKeyMutableBean key = new ConstrainedDataKeyMutableBeanImpl();

		List<IConstrainedKeyValue> keyValues = new ArrayList<>();
		List<IConstrainedKeyValue> componentValues = new ArrayList<>();
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				List<IConstrainedKeyValue> list;
				if(nodeName.equals("KeyValue")) {
					list = keyValues;
				} else if(nodeName.equals("Component")) {
					list = componentValues;
				} else {
					throw new SdmxSemmanticException("Unexpected XML element : " + reader.getXMLPath()  + ". Expected XML element: KeyValue or Component");
				}
				Map<String, String>  attributes = reader.getAttributes();
				boolean removePrefix = StaxStructureUtil.getAttributeAsBoolean(attributes, "removePrefix", false, false);
				String id = StaxStructureUtil.getAttribute(attributes, "id", true);
				id = StringUtil.cleanString(id);
				reader.moveNextNode();
				StaxStructureUtil.checkStartNode(reader, "Value");
				String value = reader.getElementText();
				value = StringUtil.cleanString(value);
				list.add(ConstrainedKeyValue.getInstance(id, removePrefix, value));
				reader.skipToEndNode(nodeName);
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		key.setKeyValues(keyValues);
		key.setComponentValues(componentValues);
		return key;
	}


	protected ConstraintAttachmentMutableBean processConstraintAttachment(IStaxReader reader) {
		ConstraintAttachmentMutableBean constraintAttach = new ContentConstraintAttachmentMutableBeanImpl();
		while(reader.moveNextNode()) {
			String elementName = reader.getElementName();
			if(reader.isStartElement()) {
				if(elementName.equals("DataProvider")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATA_PROVIDER));
				} else if(elementName.equals("MetadataSet")) {
					//TODO What about the 3.0 model - do we just drop support for this in version 2.1?
					//constraintAttach.setDataOrMetadataSetReference(processDataAndMetadataSetReference(reader, false));
				} else if(elementName.equals("SimpleDataSource")) {
					constraintAttach.addDataSources(reader.getElementText());
				} else if(elementName.equals("DataStructure")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DSD));
				} else if(elementName.equals("MetadataStructure")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.MSD));
				}  else if(elementName.equals("Dataflow")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.DATAFLOW));
				}  else if(elementName.equals("Metadataflow")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.METADATA_FLOW));
				}  else if(elementName.equals("ProvisionAgreement")) {
					constraintAttach.addStructureReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT));
				}  else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(elementName.equals("ConstraintAttachment")) {
				break;
			}
		}
		return constraintAttach;
	}

}
