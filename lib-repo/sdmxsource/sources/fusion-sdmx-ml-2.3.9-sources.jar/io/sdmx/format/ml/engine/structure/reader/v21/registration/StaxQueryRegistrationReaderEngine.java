package io.sdmx.format.ml.engine.structure.reader.v21.registration;

import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxReader;

public class StaxQueryRegistrationReaderEngine implements IFusionSingleton {
	private static StaxQueryRegistrationReaderEngine INSTANCE;

	//Private constructor - lazy load instance
	private StaxQueryRegistrationReaderEngine() {}

	public static StaxQueryRegistrationReaderEngine getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxQueryRegistrationReaderEngine();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	public StructureReferenceBean parseQueryRegistrationRequest(StaxReader reader) {
		String nodeName = reader.getElementName();
		if(!nodeName.equals("QueryRegistrationRequest")) {
			reader.skipToNode("QueryRegistrationRequest");
		}
		reader.moveNextNode();
		nodeName = reader.getElementName();
		SDMX_STRUCTURE_TYPE structureType = SDMX_STRUCTURE_TYPE.ANY;
		switch(nodeName) {
		case "ProvisionAgreement" :
			structureType  = SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT;
			break;
		case "DataProvider" :
			structureType  = SDMX_STRUCTURE_TYPE.DATA_PROVIDER;
			break;
		case "Dataflow" :
			structureType  = SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT;
			break;
		case "All" :
			structureType  = SDMX_STRUCTURE_TYPE.ANY;
			break;
		}
		return StaxStructureUtil.getStructureReference(reader, structureType);
	}

}
