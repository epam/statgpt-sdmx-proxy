package io.sdmx.format.ml.engine.structure.reader.v3.hcl;

import java.util.Map;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.mutable.base.HierarchyMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.LevelMutableBean;
import io.sdmx.api.sdmx.model.mutable.reference.CodeRefMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.AbstractStaxMaintainableReaderEngine;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxTextFormatUtil;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxMaintainableUtilV3;
import io.sdmx.format.ml.engine.structure.reader.v3.util.StaxStructureRefReaderV3;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.codelist.HierarchyMutableBeanImpl;
import io.sdmx.im.mutable.codelist.LevelMutableBeanImpl;
import io.sdmx.im.mutable.reference.CodeRefMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxHclReaderEngineV3 extends AbstractStaxMaintainableReaderEngine<HierarchyMutableBean> {
	private static StaxHclReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHclReaderEngineV3() {}
	public static StaxHclReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHclReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}

		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	public String getContainerNodeName() {
        return "Hierarchies";
    }
	
    @Override
    protected String getRootNodeName() {
        return "Hierarchy";
    }
    
	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
    @Override
    protected HierarchyMutableBean processMaintainable(IStaxReader reader) {
		HierarchyMutableBean returnBean = new HierarchyMutableBeanImpl();
		returnBean.setFormalLevels(StaxStructureUtil.getAttributeAsTeritaryBoolean(reader.getAttributes(), "hasFormalLevels", false).isTrue());

		StaxMaintainableUtilV3.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("HierarchicalCode")) {
				returnBean.addHierarchicalCodeBean(processHierarchicalCode(reader));
			} else if(nodeName.equals("Level")) {
				returnBean.setChildLevel(processChildLevel(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}

	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private CodeRefMutableBean processHierarchicalCode(IStaxReader reader) {
		CodeRefMutableBean returnBean = new CodeRefMutableBeanImpl();
		Map<String, String> attributes = reader.getAttributes();
		returnBean.setValidFrom(StaxStructureUtil.getAttributeAsDate(attributes, "validFrom", false));
		returnBean.setValidTo(StaxStructureUtil.getAttributeAsDate(attributes, "validTo", false));

		StaxIdentifiableUtil.processBean(returnBean, reader);


		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("Code")) {
				returnBean.setCodeReference(StaxStructureRefReaderV3.getStructureReference(reader, SDMX_STRUCTURE_TYPE.CODE));
			} else if(nodeName.equals("Level")) {
				returnBean.setLevelReference(StaxStructureRefReaderV3.getLocalReference(reader));
			} else if(nodeName.equals("HierarchicalCode")) {
				returnBean.addCodeRef(processHierarchicalCode(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}


	/**
	 * Start node is IncludedCodelist
	 * @param reader
	 * @return
	 */
	private LevelMutableBean processChildLevel(IStaxReader reader) {
		LevelMutableBean returnBean = new LevelMutableBeanImpl();
		StaxNameableUtil.processBean(returnBean, reader);

		while(reader.isStartElement()) {
			String nodeName = reader.getElementName();
			if(nodeName.equals("CodingFormat")) {
				returnBean.setCodingFormat(StaxTextFormatUtil.processBean(reader));
				reader.moveNextNode();
			} else if(nodeName.equals("Level")) {
				returnBean.setChildLevel(processChildLevel(reader));
			} else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return returnBean;
	}
}
