package io.sdmx.format.ml.util;

import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.format.ml.exception.SchemaValidationException;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.xml.StaxReader;

public class XMLParser {
     private static final Logger LOG = LoggerFactory.getLogger(XMLParser.class);
     private static boolean enableValidation=true;
     private static Map<SDMX_SCHEMA, URI> schemaLocations = new HashMap<>();
     private static Map<SDMX_SCHEMA, Schema> schemas = new HashMap<>();

     private static final SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

     static {
         try {
        	 schemaLocations.put(SDMX_SCHEMA.VERSION_ONE, XMLParser.class.getClassLoader().getResource("xsd/1_0/SDMXMessage.xsd").toURI());
             schemaLocations.put(SDMX_SCHEMA.VERSION_TWO, XMLParser.class.getClassLoader().getResource("xsd/2_0/SDMXMessage.xsd").toURI());
             schemaLocations.put(SDMX_SCHEMA.VERSION_TWO_POINT_ONE, XMLParser.class.getClassLoader().getResource("xsd/2_1/SDMXMessage.xsd").toURI());
             schemaLocations.put(SDMX_SCHEMA.VERSION_THREE, XMLParser.class.getClassLoader().getResource("xsd/3_0/SDMXMessage.xsd").toURI());

             for(SDMX_SCHEMA schemaVersion : schemaLocations.keySet()) {
                 URI schemaUri = schemaLocations.get(schemaVersion);
                 StreamSource source = new StreamSource(schemaUri.toString());
                 schemas.put(schemaVersion, schemaFactory.newSchema(source));
             }
         } catch (URISyntaxException e) {
             throw new RuntimeException(e);
         } catch (SAXException e) {
             throw new RuntimeException(e);
         }
     }

     /**
      * Validates the XML against the schema version.  Throws a validation exception if any schema errors are found.
      * <p/>
      * <strong>NOTE : </strong>In order for this method to work, the schema location must be set, and be accessible via a uri.
      * @param xmlLocation - the URI of the XML location
      * @param schemaVersion - the schema version to validate against
      * @param extraLocations - any extra schemas required for validation
      * @throws ValidationException
      */
     public static void validateXML(ReadableDataLocation sourceData, SDMX_SCHEMA schemaVersion, ReadableDataLocation...extraLocations) throws SdmxSyntaxException {
         // FR-3083: Check for XXE Attack
         StaxReader reader = new StaxReader(sourceData);
         while(reader.moveNextNode()) {
             if(!reader.hasDocType()) {
                 break;
             }
             throw new SdmxNotImplementedException("DOCTYPE is not supported.  Please remove DOCTYPE from XML and resubmit");
         }
         validateXML(sourceData.getInputStream(), schemaVersion, extraLocations);
     }

     public static void validateXML(InputStream xml, SDMX_SCHEMA schemaVersion, ReadableDataLocation...extraLocations) throws SdmxSyntaxException {
         LOG.debug("Validate XML Enabled :" + enableValidation);
         if(!enableValidation) {
             LOG.warn("Validation disabled");
             return;
         }
         if(!schemaLocations.containsKey(schemaVersion)) {
             throw new IllegalArgumentException("Schema location has not been set for schema : " + schemaVersion);
         }

         if(extraLocations != null) {
             URI schema = schemaLocations.get(schemaVersion);
             validateXML(xml, schema, extraLocations);
         } else {
             validateXML(xml, schemaLocations.get(schemaVersion));
         }
     }

     public static void validateXML(InputStream xmlLocation, URI schemaURI, ReadableDataLocation... schemaLocation) throws SdmxSyntaxException {
         LOG.debug("Validate XML Enabled :" + enableValidation);
         if(!enableValidation) {
             LOG.warn("Validation disabled");
             return;
         }


         Source[] schemaSource = new Source[schemaLocation.length+1];
         LOG.debug("Create Schema" + schemaURI.toString());
         schemaSource[0] = new StreamSource(schemaURI.toString());
         if(schemaLocation != null) {
             for(int i = 0; i < schemaLocation.length; i++) {
                 LOG.debug("Create Stream Source" + schemaLocation[i]);
                 schemaSource[i+1] = new StreamSource(schemaLocation[i].getInputStream());
             }
         }

         LOG.debug("Create Schema from Source[]");
         Schema schema;
         //Note: any parse called is no thread safe, if this is called by two threads then the following error will occur:
         //      org.xml.sax.SAXException: FWK005 parse may not be called while parsing.
         synchronized (schemaFactory) {
             try {
                 schema = schemaFactory.newSchema(schemaSource);
             } catch (SAXException e) {
                 throw new RuntimeException(e);
             }
         }
         validateXML(xmlLocation, schema);
     }


     private static void validateXML(InputStream xmlLocation, Schema schema) throws SdmxSyntaxException {
         LOG.debug("Validate XML Enabled :" + enableValidation);
         if(!enableValidation) {
             LOG.warn("Validation disabled");
             return;
         }

         StreamSource source = null;

         try {
             Validator schemaValidator = schema.newValidator();

             ErrorHandler eh = new ErrorHandler();
             schemaValidator.setErrorHandler(eh);

             source = new StreamSource(xmlLocation);

             LOG.debug("Validate XML");
             schemaValidator.validate(source);
             source.getInputStream().close();
             LOG.debug("Validation complete");
             if (eh.getErrors().size() > 0) {
                 // Create a "report" for all of the errors that occurred
                 List<String> validationErrors = new ArrayList<>();
                 for (SAXParseException ex : eh.getErrors()) {
                     String message = ex.getMessage() + "line/column: " + ex.getLineNumber() + "/" + ex.getColumnNumber();
                     validationErrors.add(message);
                 }
                 throw new SchemaValidationException(validationErrors);
             }
             LOG.debug("XML is Valid");
         } catch (Throwable th) {
             if(th instanceof SchemaValidationException) {
                 throw (SchemaValidationException)th;
             }
             throw new SchemaValidationException(th);
         } finally {
             if(source != null) {
                 StreamUtil.closeStream(source.getInputStream());
             }
         }
     }

     /*
      * This class is a bit of a work-around for a possible bug that exists within the validate routine of the Validator class.
      * When validating an XML file against a schema the problem is that if the validation of the file fails,
      * then the file becomes locked until the application terminates.
      * If the input file was valid then the file does not become locked and everything is fine.
      * So, when an error is encountered, it is simply stored in a List and validation continues successfully.
      * Once the validation has completed, this class must be asked if there were any errors and act accordingly.
      */
     protected static class ErrorHandler extends DefaultHandler {
         private List<SAXParseException> errors = new ArrayList<>();

         public List<SAXParseException> getErrors() {
             return errors;
         }

         @Override
         public void error( SAXParseException parseException ) throws SAXException {
             LOG.error("SAXParseException", parseException);
             errors.add(parseException);
         }

         @Override
         public void fatalError( SAXParseException parseException ) throws SAXException {
             LOG.error("SAXParseException", parseException);
             errors.add(parseException);
         }

         @Override
         public void warning( SAXParseException parseException ) throws SAXException {
             LOG.error("SAXParseException", parseException);
             errors.add(parseException);
         }
     }

     //SPRING CONTROLLED
     public void setEnableValidation(boolean enableValidation) {
         XMLParser.enableValidation = enableValidation;
     }
}