package io.sdmx.format.ml.engine.structure.writer.v21.transformation;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.transformation.IVtlSchemeBean;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;

public abstract class StaxAbstractVTLSchemeWriterEngineV21<T extends IVtlSchemeBean> extends AbstractV21Writer<T> { 

	@Override
	protected Map<String, String> getAdditionalMaintainableAttributes(T maint) {
		Map<String, String> map = new HashMap<>();
		map.put("vtlVersion", maint.getVtlVersion());
		return map; 
	}
	
}
