package io.sdmx.format.ml.engine.structure.writer.v2.hcl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.codelist.LevelBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxNameableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxTextFormatWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxHclWriterEngineV2 extends AbstractV2Writer<HierarchyBean> implements IFusionSingleton {
	private static StaxHclWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxHclWriterEngineV2() {}

	public static StaxHclWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxHclWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "HierarchicalCodelist";
	}

	@Override
	protected void writeMaintainableInternal(HierarchyBean maint, StaxWriter writer) {
		Map<String, String> attrs = new HashMap<>();
		StaxNameableWriterUtilV2.writeBean(maint, "Hierarchy", writer, attrs);
		writeHierarchicalCode(maint.getHierarchicalCodeBeans(), writer);
		writeLevel(maint.getLevel(), writer, 1);
		writer.writeEndElement(); // End Hierarchy
	}

	private void writeHierarchicalCode(List<HierarchicalCodeBean> hCode, StaxWriter writer) {
		for(HierarchicalCodeBean currentHCode : hCode) {
			writer.writeStartElement(NS, "CodeRef");
			writer.writeElement(NS, "URN", currentHCode.getCodeReference().getTargetUrn());

			if (!currentHCode.getCodeRefs().isEmpty()) {
				writeHierarchicalCode(currentHCode.getCodeRefs(), writer);
			}

			if(currentHCode.getLevel(false) != null) {
				writer.writeElement(NS, "LevelRef", currentHCode.getLevel(false).asReference().getTargetUrn());
			}

			writer.writeElement(NS, "NodeAliasID", currentHCode.getId());
			if(currentHCode.getVersion() != null) {
				writer.writeElement(NS, "Version", currentHCode.getVersion().toString());
			}

			if(currentHCode.getValidFrom() != null) {
				writer.writeElement(NS, "ValidFrom", currentHCode.getValidFrom().toString());
			}
			if(currentHCode.getValidTo() != null) {
				writer.writeElement(NS, "ValidTo", currentHCode.getValidTo().toString());
			}

			writer.writeEndElement(); // End URN
		}
	}

	private void writeLevel(LevelBean level, StaxWriter writer, int depth) {
		if (level == null) {
			return;
		}

		StaxNameableWriterUtilV2.writeBean(level, "Level", writer);
		StaxTextFormatWriterUtil.writeTextFormat(level.getCodingFormat(), writer, "CodingFormat");
		writer.writeElement(NS, "Order", ""+depth);
		StaxAnnotableWriterUtilV2.writeAnnotations(level.getAnnotations(), writer);
		writer.writeEndElement(); // End Level

		if (level.getChildLevel() != null) {
			writeLevel(level.getChildLevel(), writer, ++depth);
		}
	}
}
