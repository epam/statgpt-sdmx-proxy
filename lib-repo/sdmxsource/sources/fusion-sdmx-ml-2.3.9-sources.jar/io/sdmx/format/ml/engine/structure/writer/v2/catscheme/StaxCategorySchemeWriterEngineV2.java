package io.sdmx.format.ml.engine.structure.writer.v2.catscheme;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.categoryscheme.CategoryBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorySchemeBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxNameableWriterUtilV2;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;


public class StaxCategorySchemeWriterEngineV2 extends AbstractV2Writer<CategorySchemeBean> implements IFusionSingleton {
	private static StaxCategorySchemeWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxCategorySchemeWriterEngineV2() {}
	public static StaxCategorySchemeWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxCategorySchemeWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "CategoryScheme";
	}

	@Override
	protected void writeMaintainableInternal(CategorySchemeBean maint, StaxWriter writer) {
		writeCategories(maint.getItems(), writer);
	}

	private void writeCategories(List<CategoryBean> categories, StaxWriter writer) {
		for(CategoryBean cat : categories) {
			StaxNameableWriterUtilV2.writeBean(cat, "Category", writer);
			writeCategories(cat.getItems(), writer);
			StaxAnnotableWriterUtilV2.writeAnnotations(cat.getAnnotations(), writer);
			writer.writeEndElement();
		}
	}
}
