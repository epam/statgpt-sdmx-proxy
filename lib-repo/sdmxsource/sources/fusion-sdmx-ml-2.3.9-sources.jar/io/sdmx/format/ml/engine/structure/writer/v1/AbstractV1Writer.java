package io.sdmx.format.ml.engine.structure.writer.v1;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.engine.structure.writer.v1.util.StaxStructureWriterUtilV1;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

public abstract class AbstractV1Writer<T extends MaintainableBean> implements StaxMaintainableWriterEngine<T> {
	protected static Namespace NS = StaxStructureWriterUtilV1.STRUCTURE_NS;


	@Override
	public final void writeMaintainable(T maint, StaxWriter writer) {
	    // For V1.0 defer all work to concrete class
		writeMaintainableInternal(maint, writer);
	}

	protected abstract String getRootNodeName();

	protected abstract void writeMaintainableInternal(T maint, StaxWriter writer);
}
