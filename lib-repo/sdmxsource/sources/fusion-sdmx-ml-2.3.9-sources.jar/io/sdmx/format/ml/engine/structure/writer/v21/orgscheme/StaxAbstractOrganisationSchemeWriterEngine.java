package io.sdmx.format.ml.engine.structure.writer.v21.orgscheme;

import io.sdmx.api.sdmx.model.beans.base.OrganisationBean;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.format.ml.engine.structure.writer.v21.AbstractV21Writer;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxContactWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxNameableWriterUtil;
import io.sdmx.utils.core.xml.StaxWriter;


public abstract class StaxAbstractOrganisationSchemeWriterEngine<T extends OrganisationSchemeBean<Y>, Y extends OrganisationBean>  extends AbstractV21Writer<T>  {

	@Override
	protected void writeMaintainableInternal(T maint, StaxWriter writer) {
		for(Y org : maint.getItems()) {
			StaxNameableWriterUtil.writeBean(org, getOrgNodeName(), writer);
			StaxContactWriterUtil.writeContact(org.getContacts(), writer);
			writer.writeEndElement(); //End Org
		}
	}
	
	
	protected abstract String getOrgNodeName();
	
}
