package io.sdmx.format.ml.engine.structure.writer.v3.codelist;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.valuelist.ValueItemBean;
import io.sdmx.api.sdmx.model.beans.valuelist.ValueListBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxAnnotableWriterUtilV3;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxTextWriterUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxValuelistWriterEngineV3 extends AbstractV3Writer<ValueListBean> implements IFusionSingleton {
	private static StaxValuelistWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxValuelistWriterEngineV3() {}

	public static StaxValuelistWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxValuelistWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
	public void destroyInstance() {
		INSTANCE = null;
	}

	@Override
	protected String getRootNodeName() {
		return "ValueList";
	}

	@Override
	protected void writeMaintainableInternal(ValueListBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		writeValues(maint.getItems(), externalLinks, writer);
	}

	private void writeValues(List<ValueItemBean> codes, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		for(ValueItemBean code : codes) {
			writer.writeStartElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), "ValueItem");
			writer.writeAttribute("id", code.getId());
			StaxAnnotableWriterUtilV3.writeBean(code, writer);
			StaxTextWriterUtilV3.writeTextTypes(code.getNames(), writer, "Name");
			StaxTextWriterUtilV3.writeTextTypes(code.getDescriptions(), writer, "Description");
			writer.writeEndElement();
		}
	}

}
