package io.sdmx.format.ml.engine.structure.writer.v3.msd;

import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.format.ml.engine.structure.writer.v3.AbstractV3Writer;
import io.sdmx.format.ml.engine.structure.writer.v3.util.StaxRefUtilV3;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxMetadataflowWriterEngineV3 extends AbstractV3Writer<MetadataFlowBean> implements IFusionSingleton {
	private static StaxMetadataflowWriterEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataflowWriterEngineV3() {}

	public static StaxMetadataflowWriterEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataflowWriterEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "Metadataflow";
	}

	@Override
	protected void writeMaintainableInternal(MetadataFlowBean maint, IExternalMaintainableLinks externalLinks, StaxWriter writer) {
		StaxRefUtilV3.writeReference(maint.getMetadataStructureRef().getReference(), writer, "Structure");
		for(ICrossReferenceBeanBase target : maint.getTargets()) {
			StaxRefUtilV3.writeReference(target.getReference(), writer, "Target");
		}
	}
}
